# QA report: LT-ASM-001 Rev C (LT-OUT-001 Rev D + LT-INN-001 Rev C), clean rebuild

Date 2026-10-31. Every number below was measured on the delivered files in `CAD/`.

## Solids (NX)

| Part | Volume | Mass Al 6061 | Faces | Check |
|---|---|---|---|---|
| LT-OUT-001 Rev D | 392 576 mm³ | 1.06 kg | 594 | one solid, Examine Geometry clean, no feature errors |
| LT-INN-001 Rev C | 347 792 mm³ | 0.94 kg | 649 | one solid, Examine Geometry clean, no feature errors |

Shared exterior: 6 faces in total. The knee drum gives 2 cones and 2 planes, the thigh body is 1 lofted skin, and the
hip mouth is 1 plane. The smallest curvature radius of the skin is at least 8 mm. Zebra and gloss views show no folds
(`../Renders/exterior_knee_junction_gloss.png`).

## Fit (`fit_check_AP242.json`, STEP AP242 read with OpenCascade)

- Interference volume: **0.0 mm³**.
- Points of the inner surface inside the outer: 0 of 600 000 (worst −0.004 mm, meshing noise). NX's own check on the
  assembly reports faces touching only.
- Mating axes with **0.00 offset**:
  - 7 bosses: screw holes, nubs / pockets and columns
  - pins P1–P3
  - knee-cover pins N1 / N2
  - knee axis
  
  Hip pins in slots S1 / S2: 0.03 / 0.02.
- Joint planes, outer / inner:

  | Joint | Outer | Inner | Gap |
  |---|---|---|---|
  | rim / lip | 34.76 | 35.32 | 0.56 |
  | boss faces (datum A) | 36.07 | 36.07 | contact |
  | tongue / rebate | 36.07 | 36.19 | 0.12 |
  | nub top / pocket floor | 39.04 | 39.17 | 0.13 |
  | P3 lug | 36.24 | 36.36 | 0.12 |

## Deviation from the scans (two-way, area weighted; maps `deviation_*.png`, 0–1.5 mm scale)

| Part | median | within 0.5 mm | within 1.0 mm | CAD → scan median |
|---|---|---|---|---|
| LT-OUT-001 | 0.106 | 79.6 % | 90.8 % | 0.122 |
| LT-INN-001 | 0.113 | 76.7 % | 88.5 % | 0.131 |

Where the larger deviations are, and why:
- Knee fairing (around the knee drum): the surface is faired smooth instead of following scan noise.
- Interior ribs and gussets: modelled straight and at constant thickness.
- Root fillets: R3 throughout.

These are accepted simplifications for a clean, manufacturable model.

## Drawings

Every dimension on the sheets is read back from the model. None failed, and no text overlaps another item.

| Set | Sheets | Dimensions |
|---|---|---|
| LT-ASM-001 | 2 | 13 |
| LT-OUT-001 | 4 | 20 |
| LT-INN-001 | 4 | 15 |

## Known open points
- +X lower side of the knee fairing (Y 50–70): a soft wave is visible in zebra stripes. It is not visible in normal
  shading.
- The panel-line grooves are 5–6 separate segments, not one continuous groove. They break where the projected curve
  crosses face boundaries and openings.
- A few interior root-fillet edges were refused by NX and left sharp. Each one is a short edge where several features
  meet.
