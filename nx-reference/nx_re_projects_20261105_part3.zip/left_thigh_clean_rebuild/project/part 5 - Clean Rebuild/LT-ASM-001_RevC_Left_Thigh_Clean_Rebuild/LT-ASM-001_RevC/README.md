# LT-ASM-001 Rev C: Left Thigh, clean feature-based rebuild

Outer shell **LT-OUT-001 Rev D**, inner shell **LT-INN-001 Rev C** and their assembly **LT-ASM-001 Rev C**.

The two shells were modelled again from scratch in Siemens NX 2206. The earlier revisions matched the scan well, but
their feature trees followed the scan surface patch by patch. A screw boss, for example, was made of many small faces
where one cylinder belongs. This revision is built the way the part would be designed:

- **One shared exterior.** Both parts are cut from the same envelope:
  - the knee drum: one extrude of a Ø137.80 circle, drafted 1.7° both ways from datum A;
  - the thigh body: one lofted skin through 19 section curves fitted to both scans and faired so the surface runs
    smoothly (no folds or ripples where the body meets the drum);
  - the 3.1 mm wall: one Shell feature.
  The outer is that body below the rim plane, the inner the body above the lip plane. The two halves therefore meet
  exactly by construction.
- **Every mating feature is driven by the same named values in both parts.** The 7 screw bosses are each one Ø15
  cylinder. The Ø10 nubs sit in Ø10.05 pockets, the Ø4 pins in Ø4 holes, the hip pins in the hip slots. The tongue
  and rebate run along the joint only where the scan has them.
- **Interior structure from design features.** Knee bore and hip bore are revolved profiles, the bolt circles are
  patterns of one hole, and the ribs and gussets are planar features from sketched centre lines. Root fillets are
  R3, and the panel lines are a Ø1.25 groove along a projected curve.

Each part file has a readable history of named features (`BOSS_COLUMNS`, `KNEE_BORE`, `HIP_BOLT_PATTERN`, `TAB_C`,
`ROOT_BLEND_RIBS`, ...). The key sizes are named expressions: `wall`, `z_A`, `z_rim`, `z_lip`, `drum_D`,
`boss_D`, `nub_D`, `pocket_D`, `pin_D`, `knee_bolt_n`, `hip_bolt_n`, ... Every sketch is fully constrained.

## Parts

| Item | Part number | Rev | Volume | Mass (Al 6061) | Faces |
|---|---|---|---|---|---|
| 1 | LT-OUT-001 outer shell | D | 392 576 mm³ | 1.06 kg | 594 |
| 2 | LT-INN-001 inner shell | C | 347 792 mm³ | 0.94 kg | 649 |
| | **LT-ASM-001 assembly** | C | | **2.00 kg** | |

## Fit check (STEP AP242 files, read with OpenCascade, independent of NX)

- **Interference volume: 0.0 mm³.** None of 600 000 points sampled on the inner shell lies inside the outer
  (worst −0.004 mm, meshing noise). NX's own check on the assembly: faces touch only.
- **Mating axes:** all 7 bosses (screw holes, nubs / pockets, columns), the 3 pins P1–P3, the 2 knee-cover pins and
  the knee axis are coaxial with **0.00** offset. Hip pins in slots S1 / S2: 0.03 / 0.02.
- **Joint planes** are unchanged from the previous revisions: rim 34.76 / lip 35.32 (0.56 gap), boss faces 36.07
  (datum A, contact), tongue 36.07 / rebate 36.19, nub tops 39.04 / pocket floors 39.17, P3 lug 36.24 / 36.36.

## Deviation from the scans (two-way, area weighted)

| Part | median | within 0.5 mm | within 1.0 mm |
|---|---|---|---|
| LT-OUT-001 Rev D | 0.11 mm | 79.6 % | 90.8 % |
| LT-INN-001 Rev C | 0.11 mm | 76.7 % | 88.5 % |

The earlier revisions were closer to the scan (about 90 % within 0.5 mm) because they copied the scan surface patch by
patch. This revision keeps the exterior smooth and draws the interior with regular features. Most of the difference
is in:
- the knee fairing, where the surface is faired instead of following scan noise;
- interior ribs, which are now straight and of constant thickness.

## Contents

| Folder / file | What it is |
|---|---|
| `CAD/LT-ASM-001_Left_Thigh_Assembly_AP214.step` / `_AP242.step` | Assembly STEP: one assembly with the two parts at their modelled position |
| `CAD/LT-OUT-001_Left_Thigh_Outer_AP214.step` / `_AP242.step`, `.x_t`, `.stl` | Outer shell: STEP, Parasolid, STL |
| `CAD/LT-INN-001_Left_Thigh_Inner_AP214.step` / `_AP242.step`, `.x_t`, `.stl` | Inner shell: STEP, Parasolid, STL |
| `CAD/*.prt` | Native NX files: the assembly and the two parts with their full feature history (reference set `SOLID`). Keep the three .prt files together |
| `Drawings/LT-ASM-001.pdf` (+ per-sheet PDF / DWG, NX drawing) | Assembly drawing, 2 x A1: general arrangement and parts list; mating interface (sections, details F and G, interface table) |
| `Drawings/LT-OUT-001.pdf`, `Drawings/LT-INN-001.pdf` (+ per-sheet PDF / DWG, NX drawings) | Part drawings, 4 x A1 each, third angle, GD&T per ISO 1101 |
| `Renders/` | Shaded views of the assembly and of each open side |

## Coordinate system (shared by both parts)

- Origin: on the knee axis, at the knee floor plane of LT-OUT-001.
- +Z: the knee axis, pointing from the outer shell towards the inner shell.
- +Y: from the knee towards the hip. The hip axis is the line X = 37.97, Z = 35.18.
- Units: mm.

## Notes

1. Fasteners: the CAD shows the 7 boss joints, but no screws are defined (fasteners by customer).
2. Use the two parts of this revision together. The interfaces have the same values as LT-OUT-001 Rev C /
   LT-INN-001 Rev B, but the exterior and interior faces are new.
