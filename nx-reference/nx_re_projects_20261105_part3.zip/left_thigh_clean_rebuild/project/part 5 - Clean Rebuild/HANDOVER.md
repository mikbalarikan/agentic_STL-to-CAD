# HANDOVER: Left Thigh clean rebuild (part 5), state at 2026-10-31 ~19:40

Read this first, then `PLAN.md` in the same folder (method, rules, history of the fold fix).

## Goal (user's words, summarised)
Redo LT-OUT-001 (outer shell), LT-INN-001 (inner shell) and the assembly LT-ASM-001 from scratch. Use clean design
features (one cylinder per boss, no scan-traced patchwork, no "pinçik" faces). The joint interfaces must be exact.
**First quality rule: the exterior surface must be clean** (the user rejected a fold at the knee-body junction; fixed).
Old packages (part 1 / 2 / 4 folders) are reference only: never modify them.

## Where everything is
- Work folder (scripts + runs): `C:\NX_MCP_WORKSPACE\lt_clean`
  - `an\` scan analysis (venv `C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe`)
  - `nx\` NX journals; run them with `C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1`
  - `work\` data (sections.json = current faired sections v9, ext.npz, cached scans npz, renders)
  - `deliver\` **the delivery being assembled**: `CAD\` final (done), `README.md` (written), `Drawings\` `Renders\` `QA\` (empty, to fill)
- Delivery target: `Desktop\Left Thight Reverse Engineer\part 5 - Clean Rebuild\` (this folder). `wip_2026-10-31\` holds older WIP copies only.

## Re-run chain (all PASS as of now)
1. `an\b2_fit.py` (env LAMK=1e-2 INSET_TB=1.6) → `an\b3_smooth.py work\sections_v9raw.json work\sections.json v9 1` (env WV=20 NU=1). Already done, do not redo unless the exterior changes. Always zebra-check (`an\d5_surf.py`) before NX.
2. `nx\run_all.ps1 -B base9 -A A9 -P P15` = base envelope + Shell (`b_base.py`), split + tongue/rebate (`p_stageA.py`), feature stages (`p_build.py` + `stages.py`, stage lists in the .ps1). Current final build: `nx\P15` (stage A: `nx\A9`). Shortcut from stage A: `nx\run_parts_only.ps1 -A A9 -P <new>`.
3. `nx\run_deliver.ps1 -P P15 -Tag <n>` = `finalize.py` (both parts → `deliver\CAD`, revs out D / inn C) → `build_asm.py` (assembly + STEP) → `dwg_asm.py`, `dwg_out.py`, `dwg_inn.py`. Drawings only: `nx\run_dwgs.ps1 -Tag <n>`.
4. QA: `an\d3_fit.py <out.stl> <inn.stl> <tag>` (mesh), OCP STEP fit = `part 4 - Assembly\an\fit_check.py <inn AP242> <out AP242> <inn stl> <out stl> qa\fit_AP242.json` (done: `qa\fit_AP242.json`), scan deviation `an\d1_dev.py <stl> out_scan|inn_scan <tag>`, renders `an\e1_show.py <out stl> <inn stl> <tag>` (→ `work\show_<tag>*.png`).

## Verified results (final CAD in `deliver\CAD`)
- Outer LT-OUT-001 Rev D: 392 575.9 mm3 (from `_finalize_out.json`), 1.06 kg, 594 faces, one solid, body_ok, no feature errors.
- Inner LT-INN-001 Rev C: 347 791.7 mm3 (from `_finalize_inn.json`), 0.94 kg, 649 faces, one solid, body_ok.
- Exterior: 6 envelope faces (drum 2 cones + 2 planes, 1 loft, hip mouth), min curvature radius ≥ 8 mm, zebra clean.
- Fit (OCP on AP242): interference 0.0 mm3, 0 inner points inside outer, all boss / pin / cover-pin / knee axes coaxial 0.00, hip pins in slots 0.03 / 0.02; joint planes unchanged (34.76/35.32, 36.07, 36.07/36.19, 39.04/39.17, 36.24/36.36).
- Scan deviation (two-way, area weighted): outer p50 0.106, 79.6 % < 0.5 mm, 90.8 % < 1 mm; inner p50 0.113, 76.7 % / 88.5 %. (Old Rev C/B ≈ 91 / 89.5 % < 0.5: the user accepted lower numbers for a clean model.)
- Drawings tag 3: `nx\dwgA3` (assembly, 13 dims), `nx\dwgO3` (outer, 20 dims), `nx\dwgI3` (inner, 15 dims): PASS, 0 errors, 0 overlaps.
- `nx\dwgA4` (finished, PASS, 13 dims, 0 errors, 0 overlaps; table not yet checked by eye): assembly drawing rerun with interface-table text fixed (NX printed "-" for cells "0.00"/"0.0"; now "NONE (0.00)" / "NONE") and assembly mass 2.00 kg. Check `nx\dwgA4\dwg_result.json` and look at the PDF table on SH2.

## Remaining work (in order)
1. Look at `nx\dwgA4\LT-ASM-001.pdf` SH2 table (cells readable, not "-") and title-block mass 2.00 kg. If OK it replaces dwgA3.
2. Look at every sheet of `nx\dwgO3\LT-OUT-001.pdf` and `nx\dwgI3\LT-INN-001.pdf` by eye (user's drawing rules: dimension text 5 mm in white space never crossing part lines, arrow balloons outside the part, GD&T frames, few short notes). Things to verify: outer SH4 feature table rows H1–H5 now "FLOOR HOLE (IN BOSS Ø6) / Ø2.6 x 8 DEEP", level table rewritten; inner SH2 has no disc-slot callout any more; inner SH4 table (H1–H8 channel cover bosses, N1–N4 pins, L1/L2 lugs). Fix in `dwg_out.py` / `dwg_inn.py` and rerun `run_dwgs.ps1` if needed.
3. Copy into `deliver\`: Drawings = `LT-ASM-001*`, `LT-OUT-001*`, `LT-INN-001*` (.pdf, _SHn.pdf, _SHn.dwg, _dwg.prt; no json/log/dump); Renders = `work\show_FINAL_*.png` (+ a gloss knee-junction view, `work\surf\v9_knee_top_gloss.png`); QA = `qa\fit_AP242.json`, deviation maps `work\dev\FINout_*.png`, `FINinn_*.png`, a short `QA\REPORT.md` with the numbers above.
4. Fix the volumes in `deliver\README.md`: it says 392 571 / 347 556, the finalized values are 392 576 / 347 792 mm3.
5. Copy `deliver\` to `part 5 - Clean Rebuild\deliver` and zip it as `LT-ASM-001_RevC_Left_Thigh_Clean_Rebuild.zip` (pattern: `part 4 - Assembly\an\package.py`; skip `_*.json` and `.log`), testzip.
6. Draft `part 5 - Clean Rebuild\CLIENT_MESSAGE.txt` for Paul Clark (plain, short; do NOT send anything).
7. Update `PLAN.md` status + the memory file `lt-clean-rebuild-loft-fairing.md` (project memory dir) with final paths.

## Known open points (report to the user, do not silently patch)
- +X lower side of the knee fairing (Y 50–70): soft wave in zebra. Real shape or fit — not investigated.
- Panel-line grooves (SEAM_A/B) come out as 5–6 separate segments (projection breaks at loft face boundaries / holes), not one continuous groove.
- Revision letters used: outer Rev D, inner Rev C, assembly Rev C — the user has not confirmed the numbering.
- Root blends R3: some edges refused and were left sharp (see `nx\P15\build_*.json` ROOT_BLEND_* rows: blended / edges).

## Traps learned (also in memory `lt-clean-rebuild-loft-fairing.md`)
- NX may run other users' journals (Chest session, part 3) at the same time: only stop run_journal processes whose command line contains `lt_clean`.
- Mass with accuracy 0.999999 takes minutes on these bodies; builds use 0.99.
- Shell needs loft min curvature radius well above the 3.1 wall; tolerance 0.05.
- Root blends must stay out of the hip joint zone (y>258, z 30–50) or the two parts overlap 0.5 mm.
- Drawing scripts load `dwglib` from the part 1 / part 2 / part 4 folders (read only use); NX drops table cell text "0.00".
