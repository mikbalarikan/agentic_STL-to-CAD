# LT-OUT-001 / LT-INN-001 / LT-ASM-001 — clean rebuild from scratch (started 2026-10-31)

Reference only (read-only): the Rev C outer / Rev B inner / Rev B assembly packages and both scans.
Work folder (scripts, runs): `C:\NX_MCP_WORKSPACE\lt_clean` (`an\` = scan analysis, `nx\` = NX journals, `work\` = data).

## Why
The delivered parts match the scan but their trees are scan-tracing patchwork (outer: 502 feature rows, 123 cylinders,
95 splines, 60 Replace Face...). Screw bosses are faceted, the joint band has thin slivers. This rebuild models the
design intent with few clean features and makes the two parts mate by construction.

## Method (top-down, one envelope for both parts)
1. **Masters**: one expression set shared by both parts (wall, drum, joint levels, boss table, pin table, hip axis).
2. **Envelope** (identical in both part files, same journal module):
   - knee drum = one Revolve about the knee axis (Z): Ø137.8 at datum A (Z 36.07), 1.7° draft both ways
     (fitted on both scans: p50 0.06 mm), top Z 83.62, bottom Z -13.9;
   - thigh body = one Through Curves loft over 19 closed section splines (Y -50 ... 287.4), fitted to both scans'
     exterior (body zone p95 0.3 mm), hidden inside the drum where the drum is the surface;
   - Unite → one solid, 10 faces.
3. **Shell** 3.1 mm inward (measured wall: 3.07-3.10 on both scans and the old CAD), hip mouth open.
4. **Split** at the joint: outer = Trim Body below the rim plane Z 34.76; inner = Trim Body above the lip plane Z 35.32
   (0.56 shadow gap, measured on both scans).
5. **Joint**: tongue (outer, 1.65 wide from the inside face, top Z 36.07) and rebate (inner, 2.0 wide, floor Z 36.19)
   by Divide Face + Offset Region on the joint faces, only where the scans have them. Bosses meet face to face at
   datum A Z 36.07; Ø10 nubs (outer, top 39.04) in Ø10 pockets (inner, floor 39.17); Ø4 pins in Ø4 holes.
6. Per part: knee features (revolves + one bolt-circle pattern), hip features (revolves about the hip axis + pattern),
   7 boss columns (one cylinder each = one face), pins, ribs (Rib feature from sketches), pads, openings, holes.
7. **Exterior styling last**: recessed side panels and panel lines (Divide Face + Offset Region), no mesh-traced pads.
8. Assembly: both at the origin (designed in place), fit gate (interference, coaxial pairs, joint planes), drawing,
   STEP, package.

## Rules for this job
- Every feature is a design feature (cylinder, revolve, rib, planar pad, hole, pattern). Nothing traced from a mesh
  cluster. A small deviation is documented, not patched.
- Faces of one design surface stay one face (boss = one cylinder, drum = one cone per half).
- Mating geometry comes from the same masters in both parts.

## Exterior quality rule (user, 2026-10-31)
First quality requirement: the exterior surface must be clean. Every envelope change is previewed in Python with zebra
stripes (`an/b3_smooth.py`) before it goes to NX; the NX envelope is checked again with `an/d5_surf.py`.
The first envelope had a fold on top at the knee-body junction (Y 40-65): the hidden knee sections sat 3 mm below the
drum top while the real sections at Y 50/62 sit on it. Fix (sections v4): hidden top/bottom inset 1.0, corner radius
continuous in Y, stiffer knee section fits, and per-pole longitudinal fairing across stations with a keep-inside-drum
constraint. Deviation cost in the knee fairing ~1 mm locally, accepted for a clean surface.

## Status (handed over 2026-10-31 evening: see HANDOVER.md for what is left)
- [x] Scan analysis: drum fit, wall, joint band widths, envelope sections (2026-10-31)
- [x] NX test: envelope (drum + loft) unites to one 10-face solid; deviation p50 0.10 mm (panels / seams not yet)
- [x] Envelope v9 (2026-10-31): 6 faces (drum 2 cones + 2 planes, one loft face, hip-mouth plane), Shell 3.1 in 20 s.
      Knee-junction fold fixed (convex knee targets, faired sections, min curvature radius ≥ 8 mm). Chain:
      `an/b2_fit.py` (LAMK=1e-2 INSET_TB=1.6) → `an/b3_smooth.py` (WV=20 NU=1, mu 1) → `nx/run_all.ps1`.
- [x] Both parts built (run `nx/P13`, WIP copies in `wip_2026-10-31`): one solid each, no feature errors.
      Outer 562 faces / inner 644 faces (most are root blends and the 30 + 26 bolt holes).
      Scan deviation: outer p50 0.105, 79.6 % within 0.5 mm; inner p50 0.113, 76.6 % (old Rev C / Rev B 91 / 89.5 %).
- [x] FIXED (no root blends in the hip joint zone, run P14): 0.5 mm overlap at the hip end (x -14 / 90, y 265-266, z 36-46): root blends of both parts in the same
      corner above datum A. Fix: no root blends on the hip plate / web in the joint zone, then re-run the fit check.
- [ ] OPEN: +X lower side, knee fairing: a soft V in the zebra at Y 50-70 (real shape or fit, to check).
- [x] Shell + split + joint in both parts
- [x] Knee + hip features
- [x] Bosses, pins, holes
- [x] Ribs, pads, openings
- [x] Exterior panels / panel lines
- [x] Assembly, fit gate, drawings, package (2026-10-31): final build `nx/P15` (tabs C/D, clip K1, lugs D/3 added),
      CAD `deliver/CAD`, drawings `nx/dwgA4`, `dwgO5`, `dwgI5` (all PASS, 0 errors, 0 overlaps, checked by eye),
      fit 0.0 mm3. Package: `deliver/` here + `LT-ASM-001_RevC_Left_Thigh_Clean_Rebuild.zip` (59 entries, testzip OK),
      `CLIENT_MESSAGE.txt` draft. Nothing sent. Re-package: `an/package.py nx/dwgA4 nx/dwgO5 nx/dwgI5`.
- [ ] OPEN (reported to the user): seam grooves come out in 5-6 segments; a few root-blend edges refused (left sharp);
      revision letters outer D / inner C / assembly C not confirmed by the user.
