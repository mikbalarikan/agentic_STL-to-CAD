# STATUS — Left Thigh clean rebuild v2 (part 7)

Updated: 2026-10-31 (orchestrator, Opus 5.5). Work folder: `C:\NX_MCP_WORKSPACE\lt_clean2`.

## Phase
- [x] P0 Setup: part 5 scripts copied to `lt_clean2\ref5`, scans + deviation caches in `lt_clean2\work`,
      agent brief `lt_clean2\COMMON.md`, baseline zone script re-run (`an\z0b.py`).
- [x] P1 Measure (zones), results in `lt_clean2\work\m1..m5`:
  - M1 knee drum: two drafted cones, R 68.85 @ Z 36.07, draft 1.6°, top Z 83.60 (ch 3.1), bottom Z -13.90 (ch 3.3);
    fits 99.8-100 % — the drum was not part 5's problem. +X: body leaves the drum at a hard step edge.
  - M2 body: 10-station loft (72 poles) 95.6 % / p90 0.19 on body exterior (part 5 91.8 % / 0.44); min convex
    radius 9.9; wall median 3.07.
  - M3 hip end: lateral shoulder cones + loft to the mouth circle R 70.9 (Y 287.39), real crease Y 253-268 that
    part 5 smoothed away (1-1.5 mm off); inner hip plate is stepped (266.52 / 269.57 / 272.37 / 276.96), part 5 had a slab.
  - M4 joint: levels re-measured (outer rim 34.80, tongue 36.05, w 1.60; inner lip 35.31, rebate floor 36.08,
    w 1.85); part 5's joint-band loss came from the envelope / +X wall, not the joint features.
  - M5 + orchestrator check: the +X band is an EXTERIOR RECESSED PANEL, depth ~1.1-1.2 (wall behind 1.9 outer /
    2.0 inner), Y 54.5-259, boundary = smooth arc in angle about the hip axis (apex 40.5° at Y 110), across the joint.
    Part 5 had no panel (its envelope sat on the recess floor, so its inner wall was 1.2 too deep).
- [x] P2 Inventory: `FEATURES_out.json` (57 rows) + `FEATURES_inn.json` (102 rows); design table `nx\design2.py` +
      `nx\masters2.json` (new: B1 lobe, tilted pad + 2 ring bosses, arc rib R100.8, oval slot, stepped hip web
      266.55-269.60, blocks to 272.40, ramped ribs, B2 dome cyl R6.55, +X panel); build-order changes `work\dt\CHANGES.md`.
      51 feature masks tightened (originals `work\masks\orig\`); the old master itself fails ~25 masks (reported as such).
- [~] P3 Envelope: OCP preview done (`work\s1\`, recipe `envelope_spec.json`): drum revolve + ONE 26-section loft
      (knee fairing D-sections, hip) ∩ shoulder cone (tilt 2.2°, 24.8°, R 70.97) ∪ drum; tail wall = separate sheet,
      thicken 3.1. Exterior within 1 mm of envelope 97.0 % (part 5 91.0); drum 99.8, knee fairing 98.5 (29), body 96.3
      (91.5), hip 94.65 (90.0). Zebra checked by orchestrator: clean, soft V at +X shoulder Y 55-70, crease sharp by design.
      OCC cannot shell the union → NX build now (fallback: shell parts separately).
      NX build `nx\b_base2.py` → `nx\base_v2\` (exact 72-pole sections, Shell tol 0.2 since 0.05-0.15 corrupt silently).
      Verifier `work\v3\VERDICT.txt`: PASS-WITH-NOTES — G-ext out 95.0 / inn 95.2, wall median 3.100 (98.7 % ±0.1),
      zebra = preview, NX vs preview p99 0.084 (Y 200-235, not blocking). Hip zone 88.9 / 89.7 (tabs/blocks come in P5).
      DEFECT: tail wall (Y -51..-38, +X) built as a wavy spline flap → fix round 1 done (`work\t5\FIX1.txt`): revolve skin
      (axis fit (-26.4,14.2), cone 26° + R260 barrel), straight free edge = radial plane 50.5°, no step, no self-intersection;
      tail skin 99.4 / 97.7 % within 0.5. Orchestrator sections (`work\t5\orch_tail_sec.png`): the drum-to-skin region is
      SOLID in scan + old master → fix round 2 done (`work\t5\FIX2.txt`): TAIL_BLOCK = Z-prism (drum inner r 65.25,
      R10 fillet, flat y -32.55) clipped by skin, 50.5° plane, roof plane; matches scan ~0.1 mm at z 10-50; one solid,
      no self-intersection. P3 ACCEPTED. Notes → P5: concave dip R4.6 at (66.47,-29.04) left flat (≤1.1 mm over 5×50 mm,
      do as a cylinder cut), 0.3 ledge at the fillet start; pin pocket Ø10.5 at (61.40,-40.10) z 52-78 (inner).
      Tail re-verification folded into the P4 verifier.
- [~] P4 Split + joint + xpanel_cut: built (`nx\p_stageA2.py` → `nx\A_v2\`, `BUILD_P4.txt`). Builder numbers:
      G-ext out 96.0 / inn 96.2; G-wall 91.3 / 87.6 (inn: unbuilt features); G-band 85.6 / 82.6 (inn misses outside the
      panel); panel floor 100 % within 0.5; joint interference 0, z gap 0.025-0.029, side clearance 0.26. Note: rebate
      zones ~1 mm longer in the scan → widen rebate rectangles 0.5/end in P5 (axial clearance).
      Verifier `work\v4\VERDICT.txt`: validity PASS, joint PASS (interference 0, gap 0.025-0.029), panel depth exact, panel
      floor 100 %; inn G-wall 87.6 / G-band 82.6 fail but 72 % of misses inside feature masks (99.3 % without them).
      Defects → fix round 1 running: panel end y1 258.9 vs scan ~261.5, boundary p90 ~2 mm, out depth scan 1.10,
      tail tip sharp V at (62,-51), TG1 start 3.4 late, rebate +0.5/end.
      Fix round 1 done: panel y0 53.5 / y1 261.5 + planar run-out (floor 1.1→2.1 over y 250-260), boundary 17-pt spline
      p90 0.28 / 0.43, depth 1.10 both (masters2 updated), tail tip blend R2.5, zones re-measured, rebate +0.5/end.
      Builder gates: out G-ext 96.3 / G-wall 91.7 / G-band 86.2; inn 96.5 / 87.8 / 83.1. Fresh re-verify running (`work\v4r1\`).
      P5a builder started in parallel (`nx\stages2.py`, `nx\P5a\`).
      Re-verify `work\v4r1\VERDICT.txt`: PASS (panel, joint, tail tip). **P4 ACCEPTED.** Watch items: inn 1 coplanar STL
      sliver near the tail (x 59-65, y -49..-38, z 66-77) — check in NX at P7; envelope patch y 240-262 just past the panel
      end corner, scan 0.5-1.4 below the envelope (~300 mm² per part) — revisit after P5 (crease/run-out zone).
- [ ] P4 Split + joint
- [ ] P5 Features in stages — plan (build order of `work\dt\CHANGES.md` §1): 5a knee + hip adds/cuts; 5b bosses/pins,
      ear, ribs, tabs, pads, clip; 5c mating_cut, tabs_cut, inner knee cuts/holes/window, hub, pins, reliefs, side openings,
      tail dip cylinder; 5d root_blends, seams, finalize. Fresh verifier after each group. NOTE for 5b: EAR_B1 hull ≈ the P3
      TAIL_BLOCK (same tail line, flat y -32.35/-32.55, B1 circle) → reconcile, don't double-build; the Ø10.5 pocket at
      (61.40,-40.10) = B1 boss pocket (mating_cut, POCKET_D 10.05).
  - 5a built (`nx\P5a\`, `nx\stages2.py`, `p_build2.py`, `BUILD_P5a.txt`, `mask_table.txt`): 10 stages, 1 solid each.
    Builder: out G-ext 96.7 / G-wall 92.1 / G-band 93.6; inn 96.5 / 92.4 / 82.5. Vault 0.24, arc rib 0.40 (part 5 12.2),
    hip blocks 0.05-0.07 (part 5 4.3). Remaining > 0.5 attributed to root fillets / later stages. Saved prts are unclipped.
    Orchestrator looked at the knee/hip renders: clean. Fresh verifier running (`work\v5a\`); 5b builder started in parallel.
    Verifier `work\v5a\VERDICT.txt`: PASS with D1 (a knee cut hollows the TAIL_BLOCK out to the drum outer cone, ~800 mm²,
    up to 5.8 mm) + D2 arc-rib step 60.75° + D3 run-rib t 2.40 + D4 root radii (R1.75 floor-side, R5 disc-side, R3.2 hip
    plate, R3.0 pad, R5 lugs → root_blends). All re-measurements (bores, PCD, ribs, vault R6.50, arc rib R100.8, hip web/
    blocks) within 0.08. inn G-wall now 92.4 (pass); inn G-band 82.5 still fails. D1-D3 handed to the 5b builder (fix round 1).
  - 5b built (`nx\P5b\`, `BUILD_P5b.txt`, runner `nx\p_build3.py`), saved CLIPPED. D1 cause = clip against E0 removed the
    tail block (fixed by stage `tail_env_e0` uniting the tail into E0); D2/D3 applied; D4 recorded (`ROOT_BLEND_MEASURED`).
    New stage `tail_dip` (R4.62 cylinder cut). Ear flat -32.55. Builder gates (pure): out 96.8 / 93.2 / 91.2, G-total 88.6;
    inn 96.6 / 92.7 / 82.9, G-total 85.3. Orchestrator saw a suspect oval opening through the inner skin near the ear/tail
    (`p5b_inn_ear.png`) → fresh verifier checks it (`work\v5b\`). 5c builder started in parallel (`nx\P5c\`).
    Verifier `work\v5b\VERDICT.txt`: FAIL — `tail_dip` breaks the skin (inn 78.5 mm², out 24 mm²); scan has a concave R~6.6
    fillet there, not a dip. Values V1 G_P1 t 2.05, V2 inner arm ends x -2.25, V3 I_DIAG ramp end u 42.2, V4 inner lugs
    9.05/9.20, V5 IG_HIP point (11.0, 75.55); missing TAB_D/LUG_D foot, PAD_RIGHT hollow frame, 327° spoke wedge web;
    0.3-0.46 skin step at y -38. Everything else within 0.1. Fix round 1 handed to the 5c builder (owns NX; reruns P5b+P5c).
    Fix round 1 done (`nx\P5c\BUILD_P5c.txt` section B): tail_dip KEPT but z-limited (builder: scan has a real hollow at
    out z 11-35 / inn z 37-57; skin breakthrough gone) — verifier to rule; V1-V5 applied; 327° wedge web added (3.27→0.60);
    PAD_RIGHT ring bosses with holes (0.63→0.33); TAB_D/LUG_D foot = root blend (→5d); seam step y -38 OPEN (needs base
    loft end rebuild).
  - 5c built (`nx\P5c\`): builder gates out 96.9 / 93.6 / 93.3, G-total 91.4 (old 91.1); inn 97.3 / 95.4 / 96.8,
    G-total 90.4 (old 89.5); G-feat 44/57 out, 79/103 inn. Fresh verifier (P5b-r1 + P5c) running (`work\v5c\`);
    5d builder (root_blends, seams as clean curves, finalize) started in parallel (`nx\P5d\`).
    Verifier `work\v5c\VERDICT.txt`: gates PASS (out 96.94/93.63/93.32/91.38, inn 97.26/95.43/96.75/90.39; masks 44/57,
    79/103 — old master 40/71), P5c features within 0.1-0.15; FAIL on CAD-only defects: S1 PX post not in scan
    (orchestrator confirmed in sections y 160-172), S2 MX outlines up to 9.9 mm off, S3 PAD_RIGHT filled to the wall,
    S4 tail_dip = groove R5.80 at (66.50,-27.85) y≤-30 (current one thins wall to 1.22), S5 inner N1/N2 lug D; + V4 9.20/9.30,
    hip pins 4.00, missing trough wall beside ARM_B2_D (341 mm²), ear lobe/inner lip interference 15.7 mm³.
    → P5c fix round 1 handed to the 5d builder (owns NX). Seam step y -38 = OPEN POINT (0.3-0.45 mm, ~150 mm²/part).
  - P5c fix round 1 + 5d DONE (builder, `nx\P5d\BUILD_P5d.txt`; P5b_prev2 / P5c_prev kept): S1 post deleted (loop p90
    9.0 → 0.5), S2 MX rebuilt (TAB_D 0.26, LUG_D 0.61; MX tool extended to x -15, tabs subtracted from the tool),
    S3 pad = 1.95 slab, S4 R5.80 dip wall 3.1, S5 N1/N2 (N2 0.56, N1 0.70 = underside flare, not fixed: would be a terrace),
    V4 + hip pins applied, trough land, ear interference 0. Root blends measured from the scan: out 47/52, inn 88/115 edges
    (R5.0 floor/rib roots, hip plate R3.0 / R7.1); variable-radius roots left sharp. Seams: D1.25 tube, depth 0.6, fair
    splines (A 8 pts, B 5 pts); B gaps (out 85 % / inn 72 % coverage) and first 20 mm of A open. Finalize: attributes,
    Rev E / Rev D, Al 6061-T6, out 391 118 mm³ 1.056 kg, inn 343 109 mm³ 0.926 kg.
    Builder gates: G-total out 94.5 / inn 94.0, G-wall 95.8 / 97.1, masks 51/57, 85/103, CAD→scan p90 0.56 / 0.64.
    Orchestrator looked at p5d renders (ribs, roots, seams): clean. Fresh verifier on P5c-r1 + P5d running (`work\v5d\`).
    Verifier `work\v5d\VERDICT.txt`: gates reproduced (94.53 / 93.96), valid, 0 mm³ interference, no skin hole, roots
    clean; FAIL D1 tail_dip end ledge (wall 1.74-2.2), D2 trough root/lump/end wall, D3 clip stem rectangle vs scan
    obround 6.1 R3.05, D4 seam depth 0.57 vs 0.67-0.76 + B gaps, D5 MX loops 0.6-1.0 undersized.
    → fix round 2 of 3 handed to the 5d builder.
    Fix round 2 done (`nx\P5d`, prev in `nx\P5d_prev`, BUILD_P5d.txt Part E): G-total out 94.7 / inn 94.1, masks 52/57,
    85/103, 0 mm³. D1 dip bounded by scan wall line; D2 trough = inclined floor plane + end ramp (mask 0.34); D3 clip stem
    obround R3.05 (orchestrator checked sections: on the scan); D4 tube D1.45, B gaps were a stale-face bug, now 100/95 %;
    D5 inner +0.45 only, outer kept (builder's cut-face check says unbiased). Orchestrator saw a sharp arm-side floor
    corner + small step at s=30 in the trough section → asked the verifier. Fresh verifier v5e running.
    Verifier `work\v5e\VERDICT.txt`: gates reproduced, valid, 0 mm³, renders clean; D3 closed (head tab 26 mm² OPEN: no
    scan surface), D5 outer confirmed unbiased (+0.01), inner confirmed; R5 trough root exists. FAIL (small): D1 run-out
    ends thin wall (1.86 out / 2.28 inn), D2 CAD-only slot at trough end (109 mm²), D4 seam path offset outer A/B;
    optional MX corner R11, SPOKE_OUT_327 polygon. → fix round 3 (FINAL) handed to the builder; leftovers = OPEN.
    Fix round 3 done (BUILD_P5d.txt Part F, prev `nx\P5d_prev2`): G-total 94.7 / 94.1, masks 54/57, 86/103, 0 mm³.
    D1 outer run-out follows the leaning wall (no ledge), inner dip end 0.32 → 0.56 (OPEN), R4 corner fillet not
    buildable (2 mm edge, OPEN); D2 prism ends s 33 + z 0 plateau (ARM_B2_D_SHELF .47); D4 outer SEAM_A .47, SEAM_B .43;
    MX corner R11; SPOKE_OUT_327 .45. Orchestrator saw narrow CAD-only slots ~8.5 deep at trough end s 34-36
    (`nx\P5d\c4_out_trough_end.png`) → OPEN POINT (fix rounds used up), measured by P7 QA.
    P5 ACCEPTED as final (fix-round limit reached).
- [x] P6 Assembly + fit: LT-ASM-001 Rev D, OCC fit 0.0 mm³, all mating axes 0.00, hip pins 0.15 in slots; inner AP242 OCC-invalid (2 hub faces), AP214 valid
- [x] P7 Full QA (`deliver\QA\REPORT.txt`)
- [x] P8 Drawings (out 4, inn 4, asm 2 sheets) + renders + package in `deliver\` (README written). Note: drawing note 4 'INTERNAL CORNERS R3 MAX' is out of date (v2 roots R5 / R7.1) → fix before zip.
- [x] STOP: summary shown 2026-11-01; user OK ('Not düzelt, zipi hazırla'). Note 4 fixed ('ROOT BLENDS PER 3D MODEL, R5 TYP', nx\P8\dwgO6 / dwgI6),
  zip `LT-ASM-001_RevD_Left_Thigh_Clean_Rebuild_v2.zip` (100 files) + `CLIENT_MESSAGE.txt` draft. NOT sent to the client.

## Gate table (filled by the verifiers)
| Gate | Target | Outer | Inner |
|---|---|---|---|
| G-ext | ≥ 93 % | 97.3 PASS | 97.7 PASS |
| G-wall | ≥ 90 % | 96.1 PASS | 97.2 PASS |
| G-band | ≥ 85 % | 97.2 PASS | 97.6 PASS |
| G-feat | p90 ≤ 0.5 each | 54/57 FAIL (old 40/57) | 86/103 FAIL (old 71/103; 11 = sharp variable roots) |
| G-total | ≥ 88 % | 94.7 PASS | 94.1 PASS |
| G-surf | zebra clean, Shell OK | smooth; y -38 step 0.3-0.45 OPEN | same |
| G-clean | no blobs, census | no blobs/terraces; trough end slots OPEN | clean |
| G-fit | 0.0 mm³ | 0.0 PASS (40M pts) | |

P7 QA (fresh verifier, `work\q7`, `deliver\QA\REPORT.txt`): zone table (old / part5 / v2) — out drum 88.5/87.1/97.8,
body 91.6/76.1/95.0, hip end 92.4/84.2/91.5, tail 86.4/81.7/97.9, joint 92.2/83.5/95.5, ribs 90.4/64.2/96.6,
roots 52/50/82, seams 88.7/88.0/92.1; inn drum 87.4/80.6/94.2, body 91.3/75.9/95.2, hip end 91.0/71.9/89.3,
tail 79.4/83.2/96.3, joint 88.5/82.3/96.1, ribs 89.7/63.3/94.8, roots 58/51/86, seams 95.5/84.4/91.1.
Below old master: hip end (both, gussets GUS_G/IG B6/B7, HIP_PLATE) and inner seams.

Baseline: old Rev C / Rev B 91.1 / 89.5 %; part 5 79.6 / 76.7 %.

## Open points
1. G-feat: out 3 masks (FLATSPOT_X70Y88 .79, COVERPIN_N1 .75, ROOT_BLENDS_R3 .70), inn 17 (11 sharp variable-radius
   roots ARM_B2_D 2.07 ... ; CH_CAP_RUN 1.00, SPOKE_OUT_161 .69, ...). CH_CAP_RING mask empty (mask-list issue).
2. Hip end below old master (gussets B6/B7, HIP_PLATE).
3. Outer trough end CAD-only slots (s 33.5-37.9, depth ≤ 8.6, x 52-55 y 60-67) + bowl cavity 12.6 mm².
4. y -38 skin step 0.3-0.45 mm (~150 mm²/part) — needs base loft end rebuild.
5. Envelope skin 1.2 mm proud at hip side (out 162 / inn 219 mm²).
6. Inner SEAM_A .63, inner dip end .56, D1 R4 corner fillet not buildable.
7. Clip head tab (no scan surface); connector pad / hip slots not re-measured; pocket/pin scan bias kept 10.05 / 4.0.

## P9 Deviation_Check (2026-11-01, user request)
- NX overlay parts (CAD + full scan facet body, layer 10): `nx\P9\overlay.py` / `run_ovl.ps1`, both PASS, probe p50 0.06 / 0.05, p95 0.48 / 0.76 mm.
- Images: `an\p9_overlay.py` -> `work\p9` (overlay views + sections, checked).
- Copied to `deliver\Deviation_Check`; zip rebuilt (115 files, 417 MB); CLIENT_MESSAGE package list updated. Nothing sent.
