# Deviation_Check: CAD and scan overlaid

The delivered NX parts with the scan STL in the same coordinate frame, so the CAD can be compared with the scan
directly.

## NX parts (open in NX 2206 or newer)

| File | Contents |
|---|---|
| `LT-OUT-001_Left_Thigh_Outer_vs_SCAN.prt` | outer shell Rev E (solid, grey) + outer scan (convergent facet body `SCAN_STL_OUTER`, orange, 50 % see-through, layer 10) |
| `LT-INN-001_Left_Thigh_Inner_vs_SCAN.prt` | inner shell Rev D (solid, grey) + inner scan (`SCAN_STL_INNER`, orange, 50 % see-through, layer 10) |

- These are copies of the delivered parts. The parts in `CAD\` do not contain the scan.
- The scan is the full-resolution scan (about 7.3 M facets), so the files are large and slow to open.
- Small scan fragments (stray scan islands) are kept as `..._FRAGMENT_n` bodies on the same layer.
- To check the deviation in NX: Analysis > Deviation Gauge (scan facet body against the CAD faces), or hide
  layer 10 to see the CAD alone.

Spot check inside NX when the files were made: distance from 400 random scan points to the CAD solid, median 0.06 mm
(outer) / 0.05 mm (inner), 95th percentile 0.48 / 0.76 mm.

Frame (CAD, scan and assembly): origin on the knee axis, +Z towards the inner shell, +Y towards the hip.

## Images

- `overlay_<out|inn>_<view>.png`: CAD in grey, scan in see-through orange, from five directions.
  Where grey shows through, the CAD lies slightly above the scan surface; where orange dominates, the scan lies above.
- `sections_<out|inn>.png`: plane sections of the CAD (thin blue) over the scan (thick orange) at Y = -20, 40, 100,
  160, 220, 270 and one Z plane.

Colour deviation maps and the zone-by-zone numbers are in `QA\` (`dev_*.png`, `REPORT.txt`).
