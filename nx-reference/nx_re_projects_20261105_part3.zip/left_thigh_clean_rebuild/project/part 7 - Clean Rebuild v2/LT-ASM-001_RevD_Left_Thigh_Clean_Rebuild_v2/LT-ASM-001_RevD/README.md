# LT-ASM-001 Rev D: Left Thigh, clean rebuild v2

Outer shell **LT-OUT-001 Rev E**, inner shell **LT-INN-001 Rev D** and their assembly **LT-ASM-001 Rev D**, rebuilt
from zero in Siemens NX 2206 as clean design features that follow the scan more closely than the earlier masters.

How the shared exterior is built:
- **Knee drum:** one revolve with a 1.6° draft.
- **Body:** one 26-section Through Curves loft, trimmed by the shoulder cone.
- **Tail:** one revolve skin with a block filling the gap to the drum.
- **Wall:** one 3.1 mm Shell.
- **Split:** the outer is the body below the joint, the inner the body above it.

How the features are made:
- **Mating features:** driven by the same named values in both parts.
- **Interior structure:** columns, ribs, spokes, gussets and openings, each measured from the scan as one clean
  feature (cylinder, plane, arc, rib). There are no traced outlines, blobs or terraces.
- **Root blends:** each radius is measured from the scan, mostly R5.0, with R3.0 / R7.1 at the hip plate. Roots
  whose scan radius changes along the edge are left sharp.
- **Panel grooves:** a D1.45 tube along one fair spline per seam.

## Parts

| Item | Part number | Rev | Volume | Mass (Al 6061-T6) |
|---|---|---|---|---|
| 1 | LT-OUT-001 outer shell | E | 391 118 mm³ | 1.06 kg |
| 2 | LT-INN-001 inner shell | D | 343 109 mm³ | 0.93 kg |
| | **LT-ASM-001 assembly** | D | | **1.98 kg** |

## Deviation from the scans (share of scan area within 0.5 mm of the CAD)

| Part | Old master (Rev C / B) | Part 5 (Rev D / C) | **v2 (this)** |
|---|---|---|---|
| LT-OUT-001 | 91.1 % | 79.6 % | **94.7 %** |
| LT-INN-001 | 89.5 % | 76.7 % | **94.1 %** |

Zone-by-zone numbers, failing feature masks, deviation maps, zebra and the clean-feature census are in `QA\REPORT.txt`.

## Fit check (STEP, read with OpenCascade, independent of NX)

- **Interference: 0.0 mm³.**
- **Coaxiality:** all mating axes are coaxial, offset 0.00 (knee axis, 7 bosses, 3 pins, hip ring). The hip pins
  sit in their slots with 0.15 radial clearance.
- **Joint planes:** rim 34.80 / lip 35.31, tongue 36.05 / rebate 36.08, boss faces 36.07 (datum A, contact).
- **Inner STEP:** use the AP214 file for non-NX CAD. OpenCascade flags 2 hub faces in the inner AP242 file. NX
  reads that file healthy.

## Folders

- `CAD\`: NX prt (parts + assembly), STEP AP214 + AP242, Parasolid x_t, STL, fit-check results
- `Drawings\`: PDF per sheet + combined PDF + DWG per sheet (outer 4, inner 4, assembly 2 sheets)
- `Renders\`: CAD-only renders
- `QA\`: gate report, deviation maps, zebra, census
- `Deviation_Check\`: NX parts with the scan STL overlaid in the same frame, overlay images and sections
