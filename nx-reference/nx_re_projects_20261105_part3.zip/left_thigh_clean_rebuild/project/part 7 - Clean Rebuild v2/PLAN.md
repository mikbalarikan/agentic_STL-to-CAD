# LT-OUT-001 / LT-INN-001 / LT-ASM-001: clean rebuild v2, scan-gated (planned 2026-10-31)

## Why this run exists
Part 5 (clean rebuild) made a clean model, but the scan fit dropped: outer 91.1 → 79.6 %, inner 89.5 → 76.7 %
(area within 0.5 mm, scan → CAD). The user's words: "clean from scratch" never meant "not matching the scan". The part
must be clean AND built to the scan. Part 5 checked the scan only at the end. This run checks the scan **at every
feature**.

Where part 5 lost the points (measured 2026-10-31 by `lt_clean2\an\z0_baseline_zones.py`, old → part 5):

| Zone | Outer | Inner | Points lost |
|---|---|---|---|
| Exterior (within 1 mm of envelope) | 95.4 → 89.8 | 94.9 → 91.0 | 1.5-1.9 |
| Inner wall face (Shell 3.1) | 93.0 → 87.6 | 94.4 → 89.0 | 1.0-1.2 |
| Band 1-2.4 mm under the envelope | 93 → **22** | 89 → **23** | **3.6-3.9** |
| Interior features (bosses, ribs, pads, pockets) | 86.4 → 75.0 | 79.5 → 59.9 | **4.7-6.3** |

The 1-2.4 mm band is almost all on the **+X side, along the whole length (Y -60 … 260), about 1.1-1.3 mm off**:
a recessed panel or surface step that part 5 modelled wrongly or did not model. The interior features were sized from
master values, not checked against their own scan region.

## User decisions (2026-10-31, Q&A in the planning session)
1. **Start from zero, envelope included.** Part 5 (`part 5 - Clean Rebuild`, `C:\NX_MCP_WORKSPACE\lt_clean`) is
   reference only: read its scripts, reuse code that works, never modify it.
2. **Envelope = zoned surfaces**: knee drum (revolve), body loft, hip end as separate faces, G1/G2 at the joins.
   Each face is fitted tightly to its own scan zone. (Part 5's fold came from forcing hidden sections into one loft.)
3. **Gates per zone, not one number** (see Gates).
4. **Conflict rule**: when a clean feature misses the scan, fix the feature from scan measurements: type, size,
   position, angle, or one more clean feature. Never a blob, a traced outline or a terrace
   (memory: re-no-auto-blob-fixes). If it still fails after 3 tries, write it in the report as an open point and move on.
5. **+X band**: measure its boundary and depth on the scan first, then model it as one clean design feature
   (recessed panel on an offset surface, or a step in the envelope), whichever matches the design intent.
6. **Feature inventory = scan + the user's hand-edited masters** (outer Rev C
   `part 1\Deviation_Check\LT-OUT-001_RevC_Left_Thigh_Outer_vs_SCAN.prt`, inner
   `part 2 - Inner\Deviation_Check\LT-INN-001_Left_Thigh_Inner_vs_SCAN.prt`; both read only). Every feature gets a
   parameter row measured on the scan (value, how it was measured, scan region mask) before NX.
7. **Outer and inner together**, shared masters, then assembly.
8. **Only one user stop: before packaging.** Run autonomously until then. Ask the user only if blocked.
9. **Full package**: prt + STEP + drawings (PDF + DWG, user's drawing rules) + renders + QA report + zip + client
   message draft. **Nothing is sent.**
10. **Folders**: deliver to `part 7 - Clean Rebuild v2` (this folder), work in `C:\NX_MCP_WORKSPACE\lt_clean2`.
    Revisions: **outer Rev E, inner Rev D, assembly Rev D**.
11. **Agents**: Opus 5.5 orchestrates; many Sonnet 5.5 subagents by role (below). An independent verifier after
    every stage. At most 3 fix rounds per stage, then report.

## Gates (every one per part, measured by the verifier, not by the builder)
Deviation is area-weighted scan → CAD unless stated; zones are defined on the NEW envelope.
- G-ext: exterior (scan within 1 mm of the envelope) **≥ 93 %** within 0.5 mm.
- G-wall: inner wall face (scan 2.4-3.9 mm inside the envelope) **≥ 90 %**.
- G-band: the +X step / panel band **≥ 85 %**.
- G-feat: every interior feature, inside its own scan mask: **p90 ≤ 0.5 mm**.
- G-total: whole part **≥ 88 %** within 0.5 mm, plus CAD → scan p90 reported.
- G-surf: zebra clean (no fold, no wave the scan does not have), min curvature radius > 2 × wall, Shell works.
- G-clean: CAD-only renders show no irregular outline, terrace or blob; one design surface = one face
  (boss = one cylinder); feature census logged (count by type).
- G-fit: assembly interference 0.0 mm³, coaxial pairs 0.00, joint planes as in masters
  (part 5 values 34.76 / 35.32, 36.07, 36.07 / 36.19, 39.04 / 39.17 are a starting point, re-measured).
Baseline to beat: old Rev C / Rev B (91.1 / 89.5 %), part 5 (79.6 / 76.7 %).

## Phases
- **P0 Setup**: read part 5 HANDOVER.md, PLAN.md, scripts (`an\`, `nx\stages.py`, `ltenv.py`, `finalize.py`,
  `dwg_*.py`) and the memories listed below. Copy what is reusable into `lt_clean2`. Write `MASTERS.json` skeleton.
- **P1 Measure (parallel Sonnet)**: one agent per zone (knee drum, body, hip end, joint band, +X band, interior of
  outer, interior of inner). Output: zone masks, primitive fits, sections. Wall thickness map.
- **P2 Inventory (parallel Sonnet)**: outer and inner feature lists from the masters + scan; parameter table
  `FEATURES_out.json` / `FEATURES_inn.json` (id, type, params, scan mask, source). Orchestrator reviews for blobs.
- **P3 Envelope**: zoned surfaces fitted in Python first (zebra + zone deviation), then NX (sew, Shell 3.1).
  Gates G-ext, G-surf, G-wall before going on.
- **P4 Split + joint**: trim at the joint planes, tongue / rebate from shared masters, scan-gated.
- **P5 Features in stages** (knee, hip, bosses/pins, ribs, pads/pockets, openings/holes, +X panel, styling):
  NX builder (serial, one NX at a time) → verifier (G-feat on that stage's masks + CAD-only render) → fix ≤ 3 rounds.
- **P6 Assembly + fit**: build_asm, fit gate (reuse `part 4 - Assembly\an\fit_check.py`).
- **P7 Full QA**: all gates, zone table, deviation maps, CAD-only renders. Report in `qa\REPORT.md`.
- **P8 Drawings + package**: drawings by the user's rules, package (not zipped yet) → **STOP: show the user**
  (zone table vs old and part 5, renders, open points). Zip + client message only after their OK.

## Agent roles (Sonnet 5.5 unless stated)
- Orchestrator (Opus 5.5): plans each phase, briefs agents, reads results, keeps `STATUS.md` in this folder current.
- Measurer (×N, parallel): scan analysis only, Python (venv `C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe`).
- Inventory analyst (×2): outer / inner feature tables.
- Surface fitter (envelope, Python + zebra).
- NX builder: journals via `C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1`; only one NX run at
  a time; only stop run_journal processes whose command line contains `lt_clean2`.
- Verifier (fresh agent each time, never the builder): own measurement, own renders, PASS / REVISE with numbers.
- Drafter: drawings from the final CAD.

## Rules carried over
- Every feature is a design feature. A small deviation is documented, not patched.
- Exterior surface clean first; preview every surface change with zebra in Python before NX.
- Shell tolerance 0.05; mass accuracy 0.99 during builds; volume calls are slow, use point containment.
- Root blends stay out of the hip joint zone (y > 258, z 30-50).
- NX table cells "0.00" print as "-".
- Never touch part 1 … part 6 folders or `lt_clean`; the chest session (part 6, `ch_clean`) may run NX at the same time.

Memories to read (project memory dir `C:\Users\marya\.claude\projects\H--My-Drive-NX-HARNESS-VERSIONS-v2\memory`):
`lt-clean-rebuild-loft-fairing.md`, `left-thigh-outer-re-project.md`, `re-no-auto-blob-fixes.md`,
`drawing-style-rules.md`, `nx-headless-export-traps-g4.md`, `nx-drafting-traps-m3.md`.
