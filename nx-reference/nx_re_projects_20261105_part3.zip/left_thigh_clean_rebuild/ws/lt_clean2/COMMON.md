# lt_clean2 — common brief for every agent (Left Thigh clean rebuild v2, 2026-10-31)

Job: robot left thigh, two shells from scans: OUTER LT-OUT-001 (lower half, z < ~35) and INNER LT-INN-001
(upper half, z > ~35). Rebuild both as CLEAN design-feature NX parts that ALSO follow the scan. Plan / gates:
`C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 7 - Clean Rebuild v2\PLAN.md` (read it).

## Frame (both parts, both scans, = assembly frame), mm
Origin on the knee axis at the knee floor plane. +Z = knee axis towards the inner shell. +Y = towards the hip.
Knee drum about the Z axis, R ~68.9 at Z 37.25 (part 5 fit: `work/drum.json`, draft 1.7 deg both ways), drum top
(inner knee disc) Z 83.62, drum bottom (outer) Z -13.9. Body runs Y ~-50 … 287.4 (hip mouth plane Y 287.4).
Hip axis along Y at X 37.97, Z 35.18. Joint: outer rim Z 34.76, inner lip Z 35.32, datum A Z 36.07. Wall ~3.1.

## Data
- Python venv (has numpy, trimesh, open3d, pyvista, shapely, scipy, matplotlib):
  `C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe`. System python lacks these.
- `an\lib.py` (this folder): `lib.load("out_scan"|"inn_scan", 1500000)` -> (v, f) decimated scans (cached npz in
  `work\`), `lib.load("out_cad"|"inn_cad")` = OLD hand-edited masters (outer Rev C / inner Rev B, 91.1 / 89.5 %
  within 0.5 mm of the scan), `lib.section(v, f, axis, val)`, `lib.tri_data(v, f)` -> centres, normals, areas.
- Old master STLs: `...\part 4 - Assembly\src_revB\outer\LT-OUT-001_Left_Thigh_Outer.stl` and `...\inner\...`
  (+ AP242 STEP beside them). Old master prts (READ ONLY): `part 1\Deviation_Check\LT-OUT-001_RevC_Left_Thigh_Outer_vs_SCAN.prt`,
  `part 2 - Inner\Deviation_Check\LT-INN-001_Left_Thigh_Inner_vs_SCAN.prt`.
- Part 5 (previous clean run, 79.6 / 76.7 %): scripts copied to `ref5\an` and `ref5\nx` (reference, reuse code freely,
  but its paths point to `C:\NX_MCP_WORKSPACE\lt_clean` which is READ ONLY). Part 5 envelope mesh: `work\env_part5.stl`.
  Part 5 design table: `ref5\nx\design.py`; masters: `ref5\nx\ltenv.py`; feature stages: `ref5\nx\stages.py`.
- Per-triangle deviation arrays (scan triangle centres c, scan->CAD distance d1, CAD samples pts, CAD->scan d2):
  `work\dev_oldC.npz`, `work\dev_oldInnB.npz` (old masters), `work\dev_FINout.npz`, `work\dev_FINinn.npz` (part 5).
  Index i of c/d1 = triangle i of `lib.load(scan, 1500000)`.

## Conventions
- Scan masks: `work\masks\<out|inn>_<name>.npy` = int64 indices into the triangles of `lib.load(scan, 1500000)`.
- Every measured value: value, method (fit type, residual), scan mask file, number of triangles used.
- Write scripts in `an\` with a short prefix per role (given in your brief), outputs in `work\<role>\`.
- English in files. Do not touch `C:\NX_MCP_WORKSPACE\lt_clean`, nor any `Desktop\Left Thight Reverse Engineer\part 1..6` folder.
- Design-intent rule (user, hard): every feature must be a clean design feature (cylinder, plane, revolve, rib,
  offset panel, fair loft). NEVER a blob, a traced deviation-cluster outline or a terrace. Round fitted values to
  design intent (0.05 mm / 0.5 deg) when the scan noise allows it.
- Look at your own plots (Read the PNG) before you report.
