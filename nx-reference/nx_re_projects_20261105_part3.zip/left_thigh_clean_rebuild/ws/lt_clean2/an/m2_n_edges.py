import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
P=np.load("work/m2/ext_pts.npy")
a_all=np.degrees(np.arctan2(P[:,2]-35,P[:,0]-40)); r_all=np.hypot(P[:,0]-40,P[:,2]-35)
print("Y  edge- (theta<0)   edge+ (theta>0): positions of |dr|>0.45 jumps between 0.75deg bins")
for y in range(70,262,6):
    m=np.abs(P[:,1]-y)<=1.0
    a=a_all[m]; r=r_all[m]; out=[]
    for sgn in (-1,1):
        bins=np.arange(5,60,0.75)
        med=[]
        for b in bins:
            s=(sgn*a>=b)&(sgn*a<b+0.75)
            med.append(np.median(r[s]) if s.sum()>=3 else np.nan)
        med=np.array(med); dd=np.diff(med)
        sl=np.nanmedian(np.abs(dd))
        idx=np.where(np.abs(dd)>max(0.45,6*sl))[0]
        out.append([(round(sgn*(bins[i]+0.75),1),round(dd[i],2)) for i in idx])
    print(y,out[0],out[1])
