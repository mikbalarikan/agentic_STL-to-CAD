"""+X panel zone check: argv which tag. Zones defined on the BASE envelope (nx/base_v2/envelope.stl) so new/old/p5 are comparable.
 floor  : scan tris in the panel outline with 0.9 <= de < 1.6 (recess floor, exterior), normal pointing out
 inner  : scan tris in the panel outline with 1.5 <= de < 2.7 and normal pointing inward (wall inner face behind the panel)"""
import sys, os, numpy as np, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
import open3d as o3d, trimesh
which, tag = sys.argv[1:3]
sgn = 1 if which == "out" else -1
v, f = lib.load({"out": "out_scan", "inn": "inn_scan"}[which], 1500000)
c, nn, ar = lib.tri_data(v, f); w = ar / ar.sum()
m = trimesh.load("nx/base_v2/envelope.stl", process=False)
s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32)))
Cc = o3d.core.Tensor(c.astype(np.float32)); de = s.compute_distance(Cc).numpy()
hx, hz = 37.97, 35.18
th = np.degrees(np.arctan2(-sgn * (c[:, 2] - hz), c[:, 0] - hx))
Y = [54.5, 80, 110, 150, 210, 246, 259]; TH = [28.0, 37.8, 40.5, 38.2, 30.8, 24.5, 15.0]
from scipy.interpolate import CubicSpline
cs = CubicSpline(Y, TH)
thb = cs(np.clip(c[:, 1], 54.5, 259))
inz = (c[:, 1] > 60) & (c[:, 1] < 254) & (th > 3) & (th < thb - 2.5) & (c[:, 0] > hx + 5)
rad = np.array([c[:, 0] - hx, 0 * c[:, 0], -sgn * (c[:, 2] - hz)]).T
nrm_out = (nn[:, 0] * (c[:, 0] - hx) + nn[:, 2] * (c[:, 2] - hz)) > 0          # normal points away from the hip axis
zones = {"floor": inz & (de >= 0.9) & (de < 1.6) & nrm_out, "inner": inz & (de >= 1.6) & (de < 2.6)}
REF = {"out": {"old": "dev_oldC.npz", "p5": "dev_FINout.npz"}, "inn": {"old": "dev_oldInnB.npz", "p5": "dev_FINinn.npz"}}[which]
D = {"new": np.load(f"work/dev_{tag}_{which}.npz")["d1"]}
for k, fn in REF.items(): D[k] = np.load(os.path.join(lib.W, fn))["d1"]
out = {}
for z, mk in zones.items():
    if mk.sum() == 0: print(z, "empty"); continue
    out[z] = {"n": int(mk.sum()), "area_pct_of_scan": round(float(w[mk].sum() * 100), 2), **{k: round(float(w[mk & (d < 0.5)].sum() / w[mk].sum() * 100), 1) for k, d in D.items()}}
    print(z, out[z])
json.dump(out, open(f"work/gates/{tag}_panelzone_{which}.json", "w"), indent=1)
