"""Final exports + spec json for the envelope (tag H7)."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_build import *
from s1_tailsheet import tail_sheet, open_curve
from OCP.STEPControl import STEPControl_Writer, STEPControl_AsIs
import s1_conedef as CD, m2_loft as L
tag = 'H7'
d = np.load(os.path.join(S1, f'loft_{tag}.npz')); st = d['st']; P = d['P']
env, lo, body, dr = build(tag, verbose=True)
def step(shape, path):
    w = STEPControl_Writer(); w.Transfer(shape, STEP_MODE); w.Write(path)
from OCP.STEPControl import STEPControl_AsIs as STEP_MODE
step(env, os.path.join(S1, 'env_v1.step'))
step(lo, os.path.join(S1, 'feat_body_loft.step')); step(dr, os.path.join(S1, 'feat_drum.step')); step(cone_solid(), os.path.join(S1, 'feat_cone.step')); step(body, os.path.join(S1, 'feat_body_loft_x_cone.step'))
td = np.load(os.path.join(S1, 'tail_poles.npz')); sh = tail_sheet(td['P'], td['Ys']); step(sh, os.path.join(S1, 'feat_tail_sheet.step'))
V, F = to_mesh(env, 0.01, 0.03); import trimesh
trimesh.Trimesh(V, F, process=False).export(os.path.join(S1, 'env_v1.stl'))
V2, F2 = to_mesh(sh, 0.01, 0.03); trimesh.Trimesh(V2, F2, process=False).export(os.path.join(S1, 'tail_sheet_v1.stl'))
print('exported', len(F), len(F2), 'vol', volume(env))
# ---- spec
c = CD.CONE; A0, u = CD.axis(c); k = np.tan(np.radians(c['alpha'])); over = 4.0
B = A0 + over * u
uu = np.arange(144) / 144.0; lf = L.Loft(st, 72, P)
spec = dict(
 title='LT envelope v1 (surface fitter P3)', frame='assembly frame, mm. Origin on knee axis at knee floor plane, +Z knee axis, +Y to hip. Body Y-range -38 .. 287.39.',
 order_of_features=['F1 drum revolve', 'F2 body+hip Through Curves loft (26 periodic sections)', 'F3 shoulder cone solid', 'F4 Intersect loft with cone', 'F5 Unite drum', 'F6 (separate) tail wall sheet loft'],
 notes=['Single closed solid after F5. Hip mouth plane Y=287.39 is the planar end cap of the loft (F2), to be removed by Shell (3.1).',
        'The +X recessed panel is NOT in this envelope: the smooth envelope runs over it (band floor is 1.12 below).',
        'Tail wall (Y -51..-38) is a free-standing wall in the scan: model it as a sheet (F6) and Thicken 3.1 inward AFTER Shell, then Unite; do not Shell it as part of the solid.'],
 F1_drum=dict(type='Revolve about Z axis through origin, 360 deg', profile_rz_closed_polygon=[[round(a, 4), round(b, 4)] for a, b in drum_profile()],
              parameters=dict(R_at_parting=68.85, parting_Z=36.07, draft_deg=1.6, top_plane_Z=83.6, bottom_plane_Z=-13.9, top_chamfer='3.1 x 45 deg', bottom_chamfer='3.3 x 45 deg'),
              how='Sketch the polygon (r,z) in XZ plane: bottom plane Z -13.9 from axis to r 64.5, 3.3x45 chamfer to cone, cone up to the parting vertex (68.85, 36.07), cone up to Z 80.5, 3.1x45 chamfer to the top plane Z 83.6, back to axis. Revolve 360. Chamfers are sharp-corner legs along plane and cone.'),
 F2_body_loft=dict(type='Through Curves (cubic), solid, closed periodic sections', n_sections=len(st), degree=3, periodic=True, n_poles=72,
                   section_param='Each section = closed periodic uniform cubic B-spline in the plane Y=const, 72 poles (x,z) listed in order pole 0 .. 71. Pole j sits at polar angle ~5*j deg about (40,35), counter-clockwise in the (x,z) plane (+X -> +Z -> -X -> -Z), pole 0 at +X. All sections same start and direction -> use Alignment: Parameter (all start points at u=0 = (P0+4P1+P2)/6).',
                   v_interpolation='cubic through the stations (tensor model: cubic spline in Y of the poles, not-a-knot). OCC ThruSections used for the numbers here.',
                   end_caps='planar caps at the first (Y -38) and last (Y 287.39) sections',
                   sections=[dict(Y=float(y), poles_xz=[[round(float(a), 4), round(float(b), 4)] for a, b in P[i]],
                                  curve_points_144_xz=[[round(float(a), 3), round(float(b), 3)] for a, b in lf.curve(float(y), uu)[0]]) for i, y in enumerate(st)]),
 F3_cone=dict(type='Cone primitive (solid), used as Intersect tool', cone_params_design=c, axis_point_at_mouth_plane_xyz=[c['X0'], c['Ym'], c['Z0']],
              axis_direction_toward_apex=[round(float(a), 5) for a in u], note='axis tilted about Z by tau deg (dX/dY = tan tau); cone grows towards -Y with half angle alpha; radius measured perpendicular to the axis = R0 - tan(alpha)*s, s = distance along +u from the axis point.',
              ocp_construction=dict(base_center_xyz=[round(float(a), 4) for a in B], direction_xyz=[round(float(a), 5) for a in -u], base_radius=round(c['R0'] - k * over, 4), height=360.0, half_angle_deg=c['alpha'],
                                    top_radius=round(c['R0'] - k * over + k * 360, 3)),
              fit='free true-cone fit on lateral shoulder triangles (|phi|<25 or >118 about the hip axis, Y 270-286.8): residual median 0.105 / std 0.157 mm; axis through hip axis point with coaxial cones: 0.208 / 0.29 (worse). Two coaxial cones (+X half 22.8 deg, -X half 26.9 deg) fit as well (sd 0.126 / 0.184) - alternative if a tilted axis is not wanted.'),
 F4_intersect='Intersect (Boolean) loft (F2) with the cone solid (F3), keep the intersection -> crease edge Y 253-268 is the natural intersection edge (sharp). OCC fillet of the crease (R 1.5-5) failed; leave sharp.',
 F5_unite='Unite F4 result with the drum (F1). Loft top/bottom are exactly 0.5 mm inside the drum top/bottom planes (83.1 / -13.4) over r < 64.4 on purpose (no coplanar faces; coplanar B-spline/plane union failed in OCC), loft reaches 83.6 / -13.9 only outside the drum disc. The loft wall leaves the drum cone on the -X side crossing it at about 20 deg (Y 50-54), no tangent grazing.',
 F6_tail_sheet=dict(type='Through Curves (cubic, OPEN sections) -> sheet, then Thicken 3.1 inward after Shell and Unite', n_sections=len(td['Ys']), degree=3, n_poles=int(td['P'].shape[1]),
                    knots='clamped uniform: [0,0,0,0, 8 interior knots linspace(0,1,10)[1:-1]... see open_curve in s1_tailsheet.py] (NX: Studio Spline by poles, not closed)',
                    sections=[dict(Y=float(y), poles_xz=[[round(float(a), 4), round(float(b), 4)] for a, b in pp]) for y, pp in zip(td['Ys'], td['P'])]),
)
json.dump(spec, open(os.path.join(S1, 'envelope_spec.json'), 'w'), indent=1)
print('spec written')
