"""P5d root radius by 2D section fit. For each concave CAD edge sample: scan vertices in a slab (+-0.25) perpendicular to the edge, in the corner wedge.
Flank lines = CAD face lines shifted to the scan flank (median offset of the scan points 4-10 mm along each face), corner = their intersection,
R = least squares circle tangent to both lines (centre on the bisector). argv: which. -> work/p5d/rootfit_<which>.json"""
import sys, os, json, collections
import numpy as np
from scipy.spatial import cKDTree
from scipy.optimize import minimize_scalar
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
which = sys.argv[1]
data = json.load(open(rf"C:\NX_MCP_WORKSPACE\lt_clean2\nx\P5d\probe2\{which}_edges.json"))
v, f = lib.load(which + "_scan", 1500000)
# densify: use triangle centres + vertices
c, nn, ar = lib.tri_data(v, f)
pts = np.vstack([v, c]); T = cKDTree(pts)
SKIP = ("HOLE", "BORE", "IDENTICAL", "SLOT", "SIDE_OPEN", "CBORE", "TONGUE", "JOINT_TRIM", "CLIP_TO_ENV", "XPANEL", "TAIL", "DRUM", "BODY_LOFT",
        "SPIGOT", "PINS_P", "OPENING", "WINDOW", "RELIEF", "POCKET", "OVAL")
def fitone(p, d1, d2, tang):
    a = np.arccos(np.clip(d1 @ d2, -1, 1))
    if a < np.radians(30) or a > np.radians(170): return None
    b = d1 + d2; b /= np.linalg.norm(b)
    idx = T.query_ball_point(p, 16.0)
    if len(idx) < 50: return None
    q = pts[idx] - p
    q = q[np.abs(q @ tang) < 0.25]
    if len(q) < 30: return None
    e1 = b; e2 = np.cross(tang, b); e2 /= np.linalg.norm(e2)
    X = np.c_[q @ e1, q @ e2]
    D1 = np.array([d1 @ e1, d1 @ e2]); D2 = np.array([d2 @ e1, d2 @ e2])
    def nrm(D): return np.array([-D[1], D[0]])
    lines = []
    for D, o in ((D1, D2), (D2, D1)):
        n = nrm(D)
        if n @ o < 0: n = -n                      # n points into the void side (towards the other face direction)
        s = X @ D; dist = X @ n                   # along face, signed distance (void side +)
        m = (s > 4) & (s < 11) & (np.abs(dist) < 0.8)
        if m.sum() < 8: return None
        off = np.median(dist[m])
        lines.append((D, n, off, float(np.std(dist[m]))))
    (Da, na, oa, sa), (Db, nb, ob, sb) = lines
    # corner K: na.K = oa, nb.K = ob
    M = np.array([na, nb]); 
    try: K = np.linalg.solve(M, np.array([oa, ob]))
    except Exception: return None
    Y = X - K
    da = Y @ na; db = Y @ nb
    wedge = (da > 0.12) & (db > 0.12) & (np.linalg.norm(Y, axis=1) < 9.0)
    if wedge.sum() < 10: return {"R": 0.0, "n": int(wedge.sum()), "rms": 0.0, "shiftA": oa, "shiftB": ob, "ang": float(np.degrees(a))}
    bb = np.array([1.0, 0.0]); sh = np.sin(a / 2)
    # bisector direction in plane from corner K: (Da + Db) normalised
    bis = Da + Db; bis /= np.linalg.norm(bis)
    Yw = Y[wedge]
    def cost(R):
        cen = bis * R / sh
        r = np.linalg.norm(Yw - cen, axis=1)
        # only points within the arc span: angle from the centre between the tangent points ~ points on the corner side of the centre
        sel = (Yw @ bis) < (R / sh)
        if sel.sum() < 5: return 1e3
        return float(np.sqrt(np.mean((r[sel] - R) ** 2)))
    best = minimize_scalar(cost, bounds=(0.3, 12.0), method="bounded")
    R = float(best.x); rms = float(best.fun)
    return {"R": R, "n": int(wedge.sum()), "rms": rms, "shiftA": float(oa), "shiftB": float(ob), "ang": float(np.degrees(a))}
final = []
for r in data["rows"]:
    nm = " ".join(r["n"])
    if any(k in nm for k in SKIP): continue
    if r["L"] < 1.0: continue
    fits = []
    for s in r["smp"]:
        d1, d2, p = np.array(s["d1"]), np.array(s["d2"]), np.array(s["p"])
        # edge tangent = d1 x d2 direction
        tg = np.cross(d1, d2); ln = np.linalg.norm(tg)
        if ln < 0.05: continue
        res = fitone(p, d1, d2, tg / ln)
        if res: res["p"] = s["p"]; fits.append(res)
    if not fits: continue
    good = [x for x in fits if x["R"] > 0 and x["rms"] < 0.35]
    final.append({"tag": r["tag"], "n": r["n"], "L": r["L"], "bb": r["bb"], "fits": fits,
                  "R_med": float(np.median([x["R"] for x in good])) if good else None, "ngood": len(good)})
json.dump(final, open(rf"C:\NX_MCP_WORKSPACE\lt_clean2\work\p5d\rootfit_{which}.json", "w"))
g = collections.defaultdict(list)
for r in final: g[tuple(sorted(x.split("_Z")[0] for x in r["n"]))].append(r)
print("pair nEdges Ltot | R medians of edges (good fits) | median rms | shift")
for k, L in sorted(g.items(), key=lambda kv: -sum(x["L"] for x in kv[1])):
    Rm = [x["R_med"] for x in L if x["R_med"] is not None]
    rms = [fz["rms"] for x in L for fz in x["fits"] if fz["R"] > 0]
    sh = [abs(fz["shiftA"]) + abs(fz["shiftB"]) for x in L for fz in x["fits"]]
    print(k, len(L), round(sum(x["L"] for x in L), 1), "|", ("%.2f [%.2f..%.2f] n=%d" % (np.median(Rm), np.min(Rm), np.max(Rm), len(Rm))) if Rm else "-", "|", round(float(np.median(rms)), 3) if rms else "-", "|", round(float(np.median(sh)), 2))
