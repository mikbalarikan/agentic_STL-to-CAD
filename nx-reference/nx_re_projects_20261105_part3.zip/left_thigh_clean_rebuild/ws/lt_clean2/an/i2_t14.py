from i2_rows import *
from scipy.signal import find_peaks
r=np.hypot(c[:,0],c[:,1]); th=np.degrees(np.arctan2(c[:,1],c[:,0]))%360
# window edges 1deg bins
for zl,zh in ((45,55),):
    m=(np.abs(n[:,2])<0.5)&(r>62)&(r<72)&(c[:,2]>=zl)&(c[:,2]<zh)
    h,ed=np.histogram(th[m],bins=np.arange(0,361,1),weights=a[m])
    on=h>0.5; ch=np.flatnonzero(on[1:]!=on[:-1])+1
    print("wall presence transitions at deg:",ch.tolist())
# disc floor level
m=(n[:,2]<-0.9)&(np.abs(c[:,2]-80)<1.0)&(r<66)&(d>2.0); print("disc floor",level_fit(m)["z"],level_fit(m)["n"])
# hole H list: z levels near each
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
for k,(x,y) in DS.CH_HOLES.items():
    rr=np.hypot(c[:,0]-x,c[:,1]-y); h=(np.abs(n[:,2])<0.4)&(rr<8)&(d>0.5)
    hist,ed=np.histogram(rr[h],bins=np.arange(0,8,0.1),weights=a[h]); pk,_=find_peaks(hist,height=hist.max()*0.06,distance=2)
    print(k,[(round(ed[i]+.05,1),int(hist[i])) for i in pk])
