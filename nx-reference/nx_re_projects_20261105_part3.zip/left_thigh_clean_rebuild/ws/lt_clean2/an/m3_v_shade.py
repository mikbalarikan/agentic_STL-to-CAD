import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,ax=plt.subplots(2,2,figsize=(26,22))
L=np.array([0.5,-0.3,0.8]); L/=np.linalg.norm(L)
for i,(tag,sn) in enumerate((('inn','inn_scan'),('out','out_scan'))):
    v,f=lib.load(sn,1500000); c,nn,a=lib.tri_data(v,f); m=np.load(f"work/masks/{tag}_ext_hip.npy"); m=m[c[m,1]>205]
    sgn=1 if tag=='inn' else -1
    sel=(c[m,2]*sgn>0 if False else slice(None))
    sh=(nn[m]*L).sum(1)
    ax[i,0].scatter(c[m,1],c[m,0],c=sh,s=1.2,cmap='gray'); ax[i,0].set_title(f"{tag}: exterior shaded, (Y,X) projection along Z"); ax[i,0].set_aspect('equal')
    ax[i,1].scatter(c[m,1],c[m,2],c=(nn[m]*np.array([0.8,-0.3,0.5])).sum(1),s=1.2,cmap='gray'); ax[i,1].set_title(f"{tag}: (Y,Z) along X"); ax[i,1].set_aspect('equal')
plt.tight_layout(); plt.savefig("work/m3/shade.png",dpi=40)
