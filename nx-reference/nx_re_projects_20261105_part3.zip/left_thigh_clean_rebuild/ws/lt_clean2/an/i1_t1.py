from i1_common import *
from i1_fit import *
S = load_all(); c,n,a,de = S['c'],S['n'],S['a'],S['de']
p0,e,nn,L = frame((-2.3,166.0),(80.0,166.0))
s,u = local(c,p0,e,nn)
m = (s>10)&(s<60)&(abs(u)<8)&(de>1)
print(m.sum())
import collections
z=c[m,2]; 
for zz in np.arange(-30,10,1.0):
    k=m&(c[:,2]>=zz)&(c[:,2]<zz+1)
    if k.sum()>50: print(zz,k.sum(), "nz mean %.2f"%n[k,2].mean(), "u mean %.1f"%u[k].mean())
