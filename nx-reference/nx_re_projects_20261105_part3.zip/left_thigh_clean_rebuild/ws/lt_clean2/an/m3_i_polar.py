import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HX,HZ=37.97,35.18
NB=720
def polar_ref(v,f,ys,zsel=None):
    """R_ref[yi, bin] = max r of section points in angular bin (exterior)"""
    out=np.full((len(ys),NB),np.nan)
    for i,y in enumerate(ys):
        s=lib.section(v,f,1,y)
        if len(s)==0: continue
        L=np.linalg.norm(s[:,1]-s[:,0],axis=1); n=np.maximum(1,(L/0.3).astype(int))
        pts=[]
        for k in range(len(s)):
            t=np.linspace(0,1,n[k]+1)[:,None]; pts.append(s[k,0]+t*(s[k,1]-s[k,0]))
        P=np.vstack(pts)
        if zsel is not None: P=P[zsel(P[:,2])]
        r=np.hypot(P[:,0]-HX,P[:,2]-HZ); th=np.degrees(np.arctan2(P[:,2]-HZ,P[:,0]-HX))
        b=((th+180)/360*NB).astype(int)%NB
        np.maximum.at(np.nan_to_num(out[i],nan=-1) if False else out[i],b,r) if False else None
        tmp=np.full(NB,-1.0); np.maximum.at(tmp,b,r); tmp[tmp<0]=np.nan; out[i]=tmp
    return out
if __name__=="__main__":
    ys=np.arange(200,288.01,0.5)
    e5=trimesh.load("work/env_part5.stl",process=False); ve,fe=np.asarray(e5.vertices),np.asarray(e5.faces)
    R={}
    R['env5']=polar_ref(ve,fe,ys)
    for tag in ('out','inn'):
        zs=(lambda z:z<35.0) if tag=='out' else (lambda z:z>35.0)
        R[tag+'_cad']=polar_ref(*lib.load(tag+'_cad'),ys,zs)
    np.savez("work/m3/polar_ref.npz",ys=ys,**R)
