"""M4: exterior edge break at the rim (outer) and lip (inner), relative to the local rim / lip level, per chain."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
from m4_x import *
CO = Caster(*lib.load("out_scan", 1500000)); CI = Caster(*lib.load("inn_scan", 1500000))
import pickle
C = pickle.load(open(os.path.join(lib.W, "m4", "cmp.pkl"), "rb"))
out = {}
for nm in NAMES:
    p = D[nm + "__p"]; n = D[nm + "__n"]; S = len(p)
    rim = np.array([r.get("rim", np.nan) for r in C["scan"] if r["chain"] == nm]); lip = np.array([r.get("lip", np.nan) for r in C["scan"] if r["chain"] == nm])
    def ext(Cc, z): return 12 - Cc.hit(np.c_[p + 12 * n, z], np.c_[-n, np.zeros(S)])
    res = {}
    for lab, Cc, lv, sg in (("outer_rim", CO, rim, -1), ("inner_lip", CI, lip, +1)):
        ref = ext(Cc, lv + sg * 1.2)
        res[lab] = {("%+.2f" % (sg * d)): round(float(np.nanmedian(ext(Cc, lv + sg * d) - ref)), 3) for d in (0.9, 0.6, 0.4, 0.3, 0.2, 0.1, 0.05)}
    out[nm] = res
    print(nm, json.dumps(res))
json.dump(out, open(os.path.join(lib.W, "m4", "edge_break.json"), "w"), indent=1)
