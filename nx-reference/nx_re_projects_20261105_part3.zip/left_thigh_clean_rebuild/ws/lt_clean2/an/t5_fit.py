"""t5: tail panel design fit. Surface of revolution about a vertical axis at c: lower cone / barrel arc / roof cone, free edge plane through Z at ang 50.5.
Writes work/t5/t5_tail.json"""
import sys, json; sys.path.insert(0,'an')
import numpy as np, lib, trimesh
from scipy.optimize import least_squares
CX,CY=-26.4,14.2
ANG_CONE=26.0; ANG_ROOF=63.25
RV=260.0; ZC=35.4
def zones():
    out={}
    for nm in ("out_scan","inn_scan"):
        v,f=lib.load(nm,1500000); c,n,a=lib.tri_data(v,f)
        r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
        rad=(n[:,0]*c[:,0]+n[:,1]*c[:,1])/np.maximum(r,1e-6)
        base=(c[:,1]<-39.5)&(c[:,1]>-56)&(ang>51.5)&(ang<64)&(r>69)
        out[nm]=(c,n,a,r,ang,rad,base)
    return out
Z=zones()
rho=lambda P: np.hypot(P[:,0]-CX,P[:,1]-CY)
# lower cone  (outer scan, z -12.5..6.5, exterior)
c,n,a,r,ang,rad,base=Z["out_scan"]
m=base&(rad>0.5)&(c[:,2]>-12.5)&(c[:,2]<6.5)
P=c[m]; k=np.tan(np.radians(ANG_CONE))
a1=np.median(rho(P)-k*P[:,2]); print("cone a1 %.3f k %.4f (n %d) resid p50 %.3f p90 %.3f"%(a1,k,m.sum(),np.median(abs(rho(P)-k*P[:,2]-a1)),np.percentile(abs(rho(P)-k*P[:,2]-a1),90)))
# barrel: rho = rho0 - (Rv - sqrt(Rv^2-(z-zc)^2))
P=[]
for nm,(zlo,zhi) in (("out_scan",(10.5,33)),("inn_scan",(37,59))):
    c,n,a,r,ang,rad,base=Z[nm]; mm=base&(rad>0.9)&(c[:,2]>zlo)&(c[:,2]<zhi); P.append(c[mm])
P=np.vstack(P); sag=lambda z: RV-np.sqrt(RV**2-(z-ZC)**2)
rho0=np.median(rho(P)+sag(P[:,2])); rr=rho(P)+sag(P[:,2])-rho0
print("barrel rho0 %.3f Rv %.1f zc %.2f (n %d) resid p50 %.3f p90 %.3f"%(rho0,RV,ZC,len(P),np.median(abs(rr)),np.percentile(abs(rr),90)))
# roof: z = B0 - tan(roof)*rho
c,n,a,r,ang,rad,base=Z["inn_scan"]
n0=np.array([0.755,-0.476,0.450])
m=(ang>51)&(ang<66)&(c[:,1]<-39.5)&(r>69)&(r<83)&(c[:,2]>55)&(c[:,2]<86)&(n@n0>0.97)
P=c[m]; kr=np.tan(np.radians(ANG_ROOF)); B0=np.median(P[:,2]+kr*rho(P)); rr=P[:,2]+kr*rho(P)-B0
print("roof B0 %.3f slope %.4f (n %d) z-resid p50 %.3f p90 %.3f"%(B0,kr,m.sum(),np.median(abs(rr)),np.percentile(abs(rr),90)))
# corners
zz=np.linspace(-14,15,29001); cone=a1+k*zz; bar=rho0-sag(zz)
zcrease=zz[np.argmin(abs(cone-bar))]; print("crease z %.3f rho %.3f"%(zcrease,a1+k*zcrease))
zz=np.linspace(50,70,20001); bar=rho0-sag(zz); roof=(B0-zz)/kr
zroof=zz[np.argmin(abs(bar-roof))]; print("barrel/roof corner z %.3f rho %.3f"%(zroof,rho0-sag(zroof)))
d=dict(cx=CX,cy=CY,cone_deg=ANG_CONE,cone_a1=a1,rho0=rho0,Rv=RV,zc=ZC,roof_deg=ANG_ROOF,roof_B0=B0,z_crease=float(zcrease),z_roof=float(zroof),
       free_edge_ang=50.5,y_junction=-38.0,z_bot=-13.9,z_top=83.62,wall=3.1)
json.dump(d,open("work/t5/t5_tail.json","w"),indent=1)
# 3-D check: distance of scan exterior tris to the analytic surface (profile function)
def prof(z):
    z=np.asarray(z,float); o=np.where(z<zcrease,a1+k*z,np.where(z<zroof,rho0-sag(z),np.nan))
    return o
tot=[]
for nm in ("out_scan","inn_scan"):
    c,n,a,r,ang,rad,base=Z[nm]; mm=base&(rad>0.9)&(c[:,2]>-12)&(c[:,2]<(33 if nm=="out_scan" else 60))&((c[:,2]<33) if nm=="out_scan" else (c[:,2]>37))
    pr=prof(c[mm,2]); d_=rho(c[mm])-pr
    # normal distance approx = d*cos(slope)
    print(nm,"n",mm.sum(),"radial resid p50 %.3f p90 %.3f p95 %.3f max %.3f"%(np.median(abs(d_)),np.percentile(abs(d_),90),np.percentile(abs(d_),95),abs(d_).max()))
    for z0,z1 in ((-12,0),(0,10),(10,20),(20,33),(37,48),(48,60)):
        q=mm&(c[:,2]>=z0)&(c[:,2]<z1)
        if q.sum()>20:
            dd=rho(c[q])-prof(c[q,2]); print("   z %3d..%3d n %4d p50 %.3f p90 %.3f mean %+.3f"%(z0,z1,q.sum(),np.median(abs(dd)),np.percentile(abs(dd),90),dd.mean()))
# junction step vs envelope at y=-38
env=trimesh.load("nx/base_v2/envelope.stl")
S,fi=trimesh.sample.sample_surface(env,1500000,seed=2); N=env.face_normals[fi]
ok=(abs(S[:,1]+38.0)<0.4)&(S[:,0]>52)&(N[:,0]>0.2)&(S[:,2]>-13)&(S[:,2]<62)
E=S[ok]; dz=rho(E)-prof(E[:,2]); 
print("junction y=-38 envelope vs profile, n",ok.sum())
for z0 in range(-12,62,6):
    q=(E[:,2]>=z0)&(E[:,2]<z0+6)&np.isfinite(dz)
    if q.sum()>3: print("   z %3d..%3d  env-prof radial %+.3f (min %+.3f max %+.3f)"%(z0,z0+6,dz[q].mean(),dz[q].min(),dz[q].max()))
