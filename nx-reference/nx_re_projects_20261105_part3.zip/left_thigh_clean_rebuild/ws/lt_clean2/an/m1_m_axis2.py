import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
def pts(n,zr,ar):
    v,f=lib.load(n,1500000); c,nn,ar_=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    radial=(c[:,0]*nn[:,0]+c[:,1]*nn[:,1])/np.maximum(r,1e-9)
    m=(r>65)&(r<70.5)&(radial>0.97)&(ang>ar[0])&(ang<ar[1])&(c[:,2]>zr[0])&(c[:,2]<zr[1])
    return c[m]
for nm,zr in (("out_scan",(-9,7)),("inn_scan",(63,80))):
    for ar in ((-125,45),(-125,-30),(-30,45),(-60,45)):
        P=pts(nm,zr,ar)
        # per scan: cone with free axis (x0,y0), tilt, R(z)
        def res(q):
            x=P[:,0]-(q[0]+q[3]*(P[:,2]-36)); y=P[:,1]-(q[1]+q[4]*(P[:,2]-36)); return np.hypot(x,y)-(q[2]+0.0275*(P[:,2]-36)*(1 if nm=="out_scan" else -1))
        s=least_squares(res,[0,0,68.8,0,0],loss="soft_l1",f_scale=.1)
        # no-tilt
        def res0(q):
            return np.hypot(P[:,0]-q[0],P[:,1]-q[1])-(q[2]+0.0275*(P[:,2]-36)*(1 if nm=="out_scan" else -1))
        s0=least_squares(res0,[0,0,68.8],loss="soft_l1",f_scale=.1)
        print(nm,ar,len(P),'notilt',s0.x.round(3),'p90',np.percentile(np.abs(res0(s0.x)),90).round(3),'| tilt',s.x.round(3),'p90',np.percentile(np.abs(res(s.x)),90).round(3))
