from i2_view import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
show("v_oval1",-12,12,36,56,30,'z',(70,95),mask=np.ones(len(c),bool),size=9)
show("v_oval2",25,60,170,200,18,'z',(70,110),mask=np.ones(len(c),bool),size=11)
show("v_arc",-40,60,40,95,12,'z',(70,86),size=14)
