import sys; sys.path.insert(0,'an')
import numpy as np, lib
from scipy.optimize import least_squares
P=[]
for nm in ("out_scan","inn_scan"):
    v,f=lib.load(nm,1500000); c,n,a=lib.tri_data(v,f)
    sel=(c[:,0]>40)&(c[:,1]<-30)&(c[:,1]>-56)
    cc=c[sel];nn=n[sel];aa=a[sel]
    r=np.hypot(cc[:,0],cc[:,1]); ang=np.degrees(np.arctan2(cc[:,0],-cc[:,1]))
    rad=(nn[:,0]*cc[:,0]+nn[:,1]*cc[:,1])/r
    ext=(rad>0.9)&(r>69)&(ang>52.5)&(ang<64)&(cc[:,1]<-39)&(cc[:,2]>-8)&(cc[:,2]<61)&(((cc[:,2]<33)&(nm=="out_scan"))|((cc[:,2]>37)&(nm=="inn_scan")))
    P.append(cc[ext])
P=np.vstack(P); print(len(P))
kz=np.arange(-8,62.1,3.0)
def model(q,P,free):
    x0,y0=(q[0],q[1]) if free else (0,0)
    rk=q[2:]
    r=np.hypot(P[:,0]-x0,P[:,1]-y0)
    return r-np.interp(P[:,2],kz,rk)
for free in (False,True):
    q0=np.r_[0,0,np.interp(kz,[-8,5,15,30,50,60],[71,77,80,80.8,80.5,79.5])]
    s=least_squares(model,q0,args=(P,free),loss='soft_l1',f_scale=0.1)
    r=model(s.x,P,free)
    print("free",free,"centre %.2f %.2f"%(s.x[0],s.x[1]) if free else "", "rms %.3f p90 %.3f"%(np.sqrt(np.mean(r**2)),np.percentile(abs(r),90)))
    print(np.round(s.x[2:],2))
