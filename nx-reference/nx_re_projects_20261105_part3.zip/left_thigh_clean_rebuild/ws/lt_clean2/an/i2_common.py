import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
W = lib.W; O = os.path.join(W, "i2"); os.makedirs(O, exist_ok=True)
MASKS = os.path.join(W, "masks"); os.makedirs(MASKS, exist_ok=True)
_cache = {}
def scan():
    if "s" not in _cache:
        v, f = lib.load("inn_scan", 1500000); c, n, a = lib.tri_data(v, f)
        _cache["s"] = (v, f, c, n, a)
    return _cache["s"]
def de():
    p = os.path.join(O, "de.npy")
    if os.path.exists(p): return np.load(p)
    import trimesh, open3d as o3d
    v, f, c, n, a = scan()
    env = trimesh.load(os.path.join(W, "env_part5.stl"), process=False)
    sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.core.Tensor(np.asarray(env.vertices, np.float32)), o3d.core.Tensor(np.asarray(env.faces, np.uint32)))
    d = sc.compute_distance(o3d.core.Tensor(c.astype(np.float32))).numpy()
    np.save(p, d); return d
def dev():
    A = np.load(os.path.join(W, "dev_FINinn.npz"))["d1"]; B = np.load(os.path.join(W, "dev_oldInnB.npz"))["d1"]
    return A, B   # part5, old
def p90(x): return float(np.percentile(x, 90)) if len(x) else float("nan")
