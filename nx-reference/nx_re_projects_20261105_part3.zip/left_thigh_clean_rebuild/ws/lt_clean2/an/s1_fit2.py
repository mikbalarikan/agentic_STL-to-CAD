"""Tensor loft fit knee+body+hip with cone-cut hip. usage: s1_fit2.py tag st1,st2,... NP"""
import sys, os, time, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_lib import *
import m2_loft as L
from s1_fit import anchors, shifted, CX0, CZ0
HX, HZ = 37.97, 35.18
import s1_conedef as CD
rho = CD.rho
ray_point = CD.ray_point

def hip_data(D, wedge_deg=(36, 112), cap=0.35):
    y, x, z = D[:, 0], D[:, 1], D[:, 2]
    phi = np.degrees(np.arctan2(z - HZ, x - HX)); ap = np.abs(phi)
    wedge = (ap < wedge_deg[0]) | (ap > wedge_deg[1])
    rh = rho(y, x, z)
    hip = y >= 244
    clsC = hip & wedge & (rh > -0.8)
    # clamp skin cells that are nearer than cap to the cone
    cl = hip & ~wedge & (rh > -cap)
    if cl.any():
        for i in np.where(cl)[0]:
            tt = np.arctan2(z[i] - CZ0, x[i] - CX0); D[i, 1], D[i, 2] = ray_point(y[i], tt, -cap)
    return D[~clsC], D[clsC]

def loft_rho_at(lf, Y, th):
    uu = np.linspace(0, 1, 1440, endpoint=False); C = lf.curve(Y, uu)[0]
    tc = np.mod(np.arctan2(C[:, 1] - CZ0, C[:, 0] - CX0), 2 * np.pi); rc = np.hypot(C[:, 0] - CX0, C[:, 1] - CZ0)
    o = np.argsort(tc); r = np.interp(np.mod(th, 2 * np.pi), tc[o], rc[o], period=2 * np.pi)
    return CX0 + r * np.cos(th), CZ0 + r * np.sin(th)

if __name__ == '__main__':
    tag = sys.argv[1]; st = [float(s) for s in sys.argv[2].split(',')]; NP = int(sys.argv[3])
    lam_t = float(os.environ.get('LT', 1e-2)); lam_y = float(os.environ.get('LY', 1e-3))
    D = np.load(os.path.join(S1, 'cells_raw.npy')); D = D[(D[:, 0] < 286.4) & (D[:, 0] >= st[0] - 1.0)]
    D = shifted(D)
    Dd, Dc = hip_data(D)
    print('cells', len(D), 'class C', len(Dc))
    A = anchors(ymin=st[0])
    A = A[A[:, 0] >= st[0]]
    # mouth: all around the cone (circle) + 0.3, so the cone owns the rim
    mo = []
    for thd in np.arange(-180, 180, 3.0):
        xx, zz = ray_point(287.39, np.radians(thd), 0.3); mo.append((287.39, xx, zz, 1.0))
    extra = np.array(mo)
    for rnd in range(int(os.environ.get('ROUNDS', 4))):
        y = np.r_[Dd[:, 0], A[:, 0], extra[:, 0]]; x = np.r_[Dd[:, 1], A[:, 1], extra[:, 1]]; z = np.r_[Dd[:, 2], A[:, 2], extra[:, 2]]
        wt = np.r_[np.ones(len(Dd)), np.full(len(A), 1.0), np.full(len(extra), float(os.environ.get('WX', 6.0)))]
        th = np.arctan2(z - CZ0, x - CX0)
        m = (y >= st[0] - 1) & (y <= st[-1] + 1)
        t0 = time.time()
        lf, keep, sr, u = L.fit(st, NP, y[m], th[m], x[m], z[m], wt[m], lam_t=lam_t, lam_y=lam_y)
        # cone-lateral violation: only beyond the crease (class C cells) up to the mouth
        viol = []
        thc = np.degrees(np.arctan2(Dc[:, 2] - CZ0, Dc[:, 1] - CX0)); tb = np.round(thc / 2.0).astype(int)
        for b_ in np.unique(tb):
            yc = Dc[tb == b_, 0].min(); th_ = np.radians(b_ * 2.0)
            for Y in np.arange(max(yc + 3.0, 250), 287.4, 2.0):
                uu = np.linspace(0, 1, 1440, endpoint=False); C = lf.curve(Y, uu)[0]
                tcc = np.mod(np.arctan2(C[:, 1] - CZ0, C[:, 0] - CX0), 2 * np.pi); rcc = np.hypot(C[:, 0] - CX0, C[:, 1] - CZ0)
                o = np.argsort(tcc); r = np.interp(np.mod(th_, 2 * np.pi), tcc[o], rcc[o], period=2 * np.pi)
                px, pz = CX0 + r * np.cos(th_), CZ0 + r * np.sin(th_)
                if rho(Y, px, pz) < 0.8 or rho(Y, px, pz) > 6.0:
                    xx, zz = ray_point(Y, th_, 1.0); viol.append((Y, xx, zz, 1.0))
        print('round', rnd, 'fit', round(time.time() - t0, 1), 'viol', len(viol), flush=True)
        if not viol: break
        extra = np.vstack([extra, np.array(viol)]) if len(extra) else np.array(viol)
    np.savez(os.path.join(S1, f'loft_{tag}.npz'), st=st, P=lf.P)
