"""P5d: from work/p5d/rootfit_<w>.json build the ROOT_EDGES table (design2 block). Selection rules are printed in the header."""
import sys, json, collections
import numpy as np
which = sys.argv[1]
d = json.load(open(rf"C:\NX_MCP_WORKSPACE\lt_clean2\work\p5d\rootfit_{which}.json"))
LADDER = [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0, 7.5, 8.0, 8.5, 9.0, 9.5, 10.0]
def snap(R):
    if 4.6 <= R <= 5.5: return 5.0
    return min(LADDER, key=lambda x: abs(x - R))
def fam(names):
    n = " ".join(names)
    if which == "out":
        if "KNEE_FLOOR" in n: return "FLOOR"
        if "COVER_PIN" in n: return "COVERPIN"
        if "HIP_" in n or "CONN_PAD" in n: return "HIP"
        if "G_" in n and "G_P1" in n or " G_" in n or n.startswith("G_") or "/G_" in n: return "GUSSET"
        if any(k in n for k in ("RIBS", "R_DIAG", "LOWRIB", "R_P2")): return "RIB"
        if any(k in n for k in ("BOSS_COLUMNS", "BOSS_ARMS", "FLOOR_BOSSES", "WALL_FLANGE")): return "COLUMN"
        return "OTHER"
    else:
        if "KNEE_DISC_FILL" in n: return "DISC"
        if "COVER_PIN" in n or "WEB_N2" in n: return "COVERPIN"
        if "CH_" in n or "SPOKES" in n or "ARC_RIB" in n: return "CH"
        if "HIP_" in n or "IG_HIP" in n: return "HIP"
        if any(k in n for k in ("IRIBS", "I_DIAG", "I_LONG", "IG_")): return "RIB"
        if any(k in n for k in ("BOSS_COLUMNS", "BOSS_ARMS", "WALL_FLANGE")): return "COLUMN"
        return "OTHER"
SKIP = ("HOLE", "BORE", "IDENTICAL", "SLOT", "SIDE_OPEN", "CBORE", "TONGUE", "JOINT_TRIM", "CLIP", "XPANEL", "TAIL", "DRUM", "BODY_LOFT", "SPIGOT", "PINS_P",
        "OPENING", "WINDOW", "RELIEF", "POCKET", "OVAL", "SHELL/SHELL", "PIN_LUGS_P", "LUG_3", "LUG_D", "TAB_", "HIP_RING", "EAR_B1", "VAULT", "WEDGE", "PAD_RIGHT", "HIP_PINS", "CLEARANCE")
rows = []; skipped = collections.Counter(); why = []
for r in d:
    nm = "/".join(x.split("_Z")[0] for x in r["n"]); bb = r["bb"]
    if any(k in nm for k in SKIP): skipped["name"] += 1; continue
    if bb[4] > 258.0 and bb[2] < 50.0 and bb[5] > 30.0 and not (bb[1] > 262 and bb[4] < 280 and bb[5] < 33.0): pass
    if bb[4] > 258.0 and bb[2] < 50.0 and bb[5] > 30.0: skipped["hipzone"] += 1; why.append((r["tag"], nm, "hip joint zone")); continue
    if bb[2] >= 33.4 and bb[5] <= 38.6: skipped["jointband"] += 1; continue
    if r["L"] < 3.0: skipped["short"] += 1; continue
    good = [x["R"] for x in r["fits"] if x["R"] > 0.9 and x["R"] < 10.5 and x["rms"] < 0.35]
    zero = [x for x in r["fits"] if x["R"] == 0.0]
    if len(good) < 2 or len(good) < 0.5 * len(r["fits"]): skipped["nofit/unclean"] += 1; why.append((r["tag"], nm, "unclean fits %s" % [round(x["R"], 1) for x in r["fits"]])); continue
    med = float(np.median(good))
    if max(good) > 1.4 * med or min(good) < 0.7 * med: skipped["spread"] += 1; why.append((r["tag"], nm, "R varies %s" % [round(x, 1) for x in good])); continue
    if med >= 10.0: skipped["R>=10"] += 1; continue
    rows.append({"ang": round(float(np.median([x["ang"] for x in r["fits"]])), 1), "fam": fam(r["n"]), "R": snap(med), "Rmed": round(med, 2), "bb": [round(x, 2) for x in bb], "L": r["L"], "pair": nm})
print("selected", len(rows), "skipped", dict(skipped))
g = collections.defaultdict(list)
for x in rows: g[(x["fam"], x["R"])].append(x)
for k in sorted(g, key=lambda k: (-k[1], k[0])):
    print(k, len(g[k]), "L", round(sum(x["L"] for x in g[k]), 1), sorted(set(x["pair"] for x in g[k]))[:6])
json.dump({"rows": rows, "why": why}, open(rf"C:\NX_MCP_WORKSPACE\lt_clean2\work\p5d\roottable_{which}.json", "w"))
for t in why: print("  skip", t)
