from s1_build import *
import trimesh
m=trimesh.load(os.path.join(S1,'env_H3.stl'),process=False); v=np.asarray(m.vertices)
for Y in [270,276,282]:
    q=v[(np.abs(v[:,1]-Y)<0.8)]
    ph=np.degrees(np.arctan2(q[:,2]-HZ,q[:,0]-HX)); w=np.abs(ph)<8
    r=np.hypot(q[w,0]-(HX+0.0349*(Y-287.39)),q[w,2]-HZ); print(Y,w.sum(),'env rho',r.min().round(2),r.max().round(2),'cone R',round(71+0.4663*(287.39-Y),2))
