import sys; sys.path.insert(0,'an')
import numpy as np, lib
for nm in ("out_scan","inn_scan"):
    v,f=lib.load(nm,1500000); c,n,a=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    # end face: normal mostly tangential (pointing towards smaller angle) in xy
    tx,ty=np.cos(np.radians(ang)),np.sin(np.radians(ang))   # d/dang direction at ang: x=r sin a,y=-r cos a -> dx=r cos a, dy=r sin a
    tang=n[:,0]*tx+n[:,1]*ty
    m=(r>71)&(r<82)&(ang>48)&(ang<54)&(c[:,2]>12)&(c[:,2]<60)&(tang<-0.9)&(abs(n[:,2])<0.3)&(c[:,1]<-40)
    if nm=="out_scan": m&=(c[:,2]<34)
    else: m&=(c[:,2]>36)
    P=c[m]; w=a[m]
    print(nm,"end-face tris",m.sum(),"area %.1f"%w.sum())
    xy=P[:,:2]; mu=(xy*w[:,None]).sum(0)/w.sum()
    u,s,vt=np.linalg.svd((xy-mu)*np.sqrt(w)[:,None],full_matrices=False)
    d=vt[0]; nrm=np.array([-d[1],d[0]])
    off=(xy-mu)@nrm
    print("  line dir %.3f %.3f  angle of line (deg from +x) %.2f ; mean pt %.2f %.2f; resid rms %.3f ; dist of line to origin %.2f"%(d[0],d[1],np.degrees(np.arctan2(d[1],d[0])),mu[0],mu[1],np.sqrt(np.average(off**2,weights=w)),abs(mu@nrm)))
    # angle of free-edge points about origin
    ang_e=np.degrees(np.arctan2(P[:,0],-P[:,1]))
    print("  ang of end-face centres about origin: med %.2f p5 %.2f p95 %.2f; normal ang %.2f"%(np.median(ang_e),np.percentile(ang_e,5),np.percentile(ang_e,95), np.degrees(np.arctan2(nrm[0],-nrm[1]))))
    # z-dependence of the line (is the edge vertical?)
    for z0 in (15,25,35,45,55):
        mm=(P[:,2]>z0-5)&(P[:,2]<z0+5)
        if mm.sum()>5: print("   z~%d  mean xy %.2f %.2f ang %.2f"%(z0,*P[mm,:2].mean(0),np.median(ang_e[mm])))
