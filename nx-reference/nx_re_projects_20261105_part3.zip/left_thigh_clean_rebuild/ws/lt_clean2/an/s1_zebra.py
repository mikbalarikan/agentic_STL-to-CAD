"""Zebra + gloss renders of an envelope STL. usage s1_zebra.py env.stl tag"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, trimesh, pyvista as pv
from s1_lib import S1
pv.OFF_SCREEN = True
stl, tag = sys.argv[1], sys.argv[2]
m = trimesh.load(stl, process=False); m.merge_vertices()
mesh = pv.PolyData(np.asarray(m.vertices), np.hstack([np.full((len(m.faces), 1), 3), m.faces]).ravel())
mesh = mesh.compute_normals(cell_normals=False, point_normals=True, split_vertices=True, feature_angle=25)
n = mesh.point_data["Normals"]
d = np.array([0.6, -0.3, 0.75]); d /= np.linalg.norm(d)
mesh.point_data["zebra"] = (np.floor((n @ d) * 16) % 2).astype(float)
d2 = np.array([-0.5, 0.2, 0.84]); d2 /= np.linalg.norm(d2)
mesh.point_data["zebra2"] = (np.floor((n @ d2) * 16) % 2).astype(float)
views = {"kneeTopPX": ((0.9, -0.5, 0.9), (35, 20, 60), 330, "zebra"), "kneeBotPX": ((0.9, -0.5, -0.9), (35, 20, 10), 330, "zebra"),
         "kneeSidePX": ((1, -0.15, 0.1), (40, 30, 35), 380, "zebra"), "kneeMX": ((-0.8, 0.5, 0.5), (0, 55, 35), 330, "zebra2"),
         "bodyPX": ((1, -0.6, 0.6), (40, 150, 40), 520, "zebra"), "bodyTop": ((0.2, -0.5, 1), (40, 150, 40), 560, "zebra2"),
         "bodyBot": ((0.2, -0.5, -1), (40, 150, 40), 560, "zebra"),
         "hipPX": ((1, 0.3, 0.5), (38, 265, 35), 360, "zebra"), "hipMX": ((-1, 0.3, 0.5), (38, 265, 35), 360, "zebra2"),
         "hipTop": ((0.2, 0.5, 1), (38, 265, 35), 360, "zebra2"), "hipEnd": ((0.3, 1, 0.3), (38, 270, 35), 420, "zebra")}
sel = sys.argv[3].split(',') if len(sys.argv) > 3 else list(views)
for nm in sel:
    dv, fo, dist, zk = views[nm]
    for mode in ("gloss", "zebra"):
        p = pv.Plotter(window_size=(1100, 800))
        if mode == "gloss": p.add_mesh(mesh, color="#a9bccf", smooth_shading=True, specular=1.0, specular_power=40)
        else: p.add_mesh(mesh, scalars=zk, cmap="gray", smooth_shading=True, show_scalar_bar=False)
        dv_ = np.array(dv, float); fo_ = np.array(fo, float)
        p.camera.focal_point = fo_; p.camera.position = fo_ + dist * dv_ / np.linalg.norm(dv_); p.camera.up = (0, 0, 1)
        p.screenshot(os.path.join(S1, f"z_{tag}_{nm}_{mode}.png")); p.close()
print('ok')
