from i2_rows import *
import glob, json
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS, math
rows = []
x, y, z = c[:, 0], c[:, 1], c[:, 2]
base = {}
for f_ in glob.glob(os.path.join(ROWS, "*.json")):
    for r in json.load(open(f_)): base[r["id"]] = r
def root_line(fid, parent, wmax=8.0, nzr=(-0.985, -0.1), zlo=None):
    r = base[parent]; p = r["params"]
    if "p0" not in p or p.get("t") is None: return
    p0, p1, t = np.array(p["p0"]), np.array(p["p1"]), p["t"]
    u, wv, nu, nw, L, e = line_frame(p0, p1); hw = t / 2
    cen = 0.0
    zf = r["params"].get("edge", {}).get("z", r["params"].get("edge", {}).get("z_low", 40.0)) if isinstance(r["params"].get("edge"), dict) else 40.0
    zf = zf if zf else 40.0
    fits = []; mk = np.zeros(N, bool)
    for sgn in (-1, 1):
        ww = sgn * wv
        q = (ww > hw + 0.05) & (ww < hw + wmax) & (u > -0.7) & (u < L + 0.7) & (n[:, 2] > nzr[0]) & (n[:, 2] < nzr[1]) & (d >= 2.0) & (z > (zlo or zf + 0.3))
        mk |= q
        qc = q & (u > 0.2 * L) & (u < 0.8 * L)
        P = np.c_[ww[qc] - hw, z[qc]]
        if len(P) > 80:
            cx_, cz_, R_, rms_ = circle_fit(P); fits.append(dict(side=int(sgn), R=R_, rms=rms_, n=len(P)))
    good = [f_["R"] for f_ in fits if f_["rms"] < 0.3]
    rows.append(make_row(fid, "root_fillet", dict(parent=parent, fits=fits, R_clean=float(np.median(good)) if good else None, zone_halfwidth=wmax),
                         "tilted tris (-0.985<nz<-0.1) within 8 mm of the rib wall: circle fit in (offset, z) per side; R reported only for rms<0.3", None, mk, dict(R=3.0)))
for pid in ("I_TRANS_Y166", "I_DIAG", "I_LONG_HIP", "ARM_B3_R", "ARM_B3_D", "ARM_B4_R", "ARM_B2_D", "CH_RUN_RIB_L", "CH_RUN_RIB_R"):
    root_line(pid + "_root", pid, wmax=(9.0 if "LONG" in pid else 7.0))
# rings / spokes (disc floor 80.0 is flat): polar
r0 = np.hypot(x, y); th0 = np.degrees(np.arctan2(y, x)) % 360
for fid, parent, rface_in, rface_out in (("CH_RING_IN_root", "CH_RING_IN", 32.26, 34.85), ("CH_RING_OUT_root", "CH_RING_OUT", 44.70, 42.33)):
    fits = []; mk = np.zeros(N, bool)
    for nm, rf, sgn in ((("disc side", rface_in, -1), ("floor side", rface_out, 1)) if "IN" in fid else (("disc side", rface_in, 1), ("floor side", rface_out, -1))):
        off = sgn * (r0 - rf)
        q = (off > 0.05) & (off < 8) & (th0 > 80) & (th0 < 335) & (n[:, 2] < -0.1) & (n[:, 2] > -0.985) & (z > 75.3) & (d >= 2.0)
        if nm.startswith("floor"): continue   # channel floor arch: measured below
        mk |= q
        P = np.c_[off[q], z[q]]
        if len(P) > 80:
            cx_, cz_, R_, rms_ = circle_fit(P); fits.append(dict(side=nm, R=R_, rms=rms_, n=len(P)))
    good = [f_["R"] for f_ in fits if f_["rms"] < 0.3]
    rows.append(make_row(fid, "root_fillet", dict(parent=parent, fits=fits, R_clean=float(np.median(good)) if good else None), "polar: tilted tris next to the rib faces on the disc side, circle fit in (r-offset, z)", None, mk, dict(R=3.0)))
# channel floor arch (ring): circle fit in (r, z) between the rib faces
arch = (r0 > 35.0) & (r0 < 42.2) & (th0 > 120) & (th0 < 300) & (n[:, 2] < -0.1) & (z > 75.3) & (z < 78.2) & (d >= 2.0)
cxa, cza, Ra, rmsa = circle_fit(np.c_[r0[arch], z[arch]])
json.dump(dict(R=Ra, centre_r=cxa, centre_z=cza, crest_z=cza + Ra, rms=rmsa, n=int(arch.sum())), open(os.path.join(O, "extra_arch.json"), "w"))
print("channel floor arch", Ra, cxa, cza, cza + Ra, rmsa, arch.sum())
dump("roots", rows)
