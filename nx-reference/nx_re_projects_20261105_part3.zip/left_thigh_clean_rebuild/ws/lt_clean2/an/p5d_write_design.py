import json
out = ["", "# ============================================================================================ P5d: root blends + seams (builder, 2026-11-01)",
"# ROOT_EDGES: concave sharp edges of the P5c bodies that get a root blend, from the scan by 2D section fit (an/p5d_rootfit.py, an/p5d_roottable.py;",
"# data work/p5d/rootfit_<w>.json). Per edge: slab (+-0.25) perpendicular to the edge in the scan vertices, flank lines = the CAD faces shifted to the scan flanks,",
"# R = least squares circle tangent to both lines (rms of the fit < 0.35, >= 2 good samples, spread 0.7..1.4 x median, 1 <= R < 10), snapped to 0.5 (4.6..5.5 -> 5.0).",
"# Not blended (measured, reported): edges with no fillet in the scan (R fit 0), unclean/varying fits, edges < 3 mm, hip joint zone (y > 258, z 30..50), joint band, cut/hole/joint features.",
"# Rows: (family, R, bbox(xmin,ymin,zmin,xmax,ymax,zmax) of the edge, length, creator-feature pair, interior angle deg). Edges are matched by bbox (+-1.0) and length, NOT by tag.",
"ROOT_MATCH_TOL = 1.0",
"ROOT_EDGES = {"]
for w in ("out", "inn"):
    d = json.load(open(r"C:\NX_MCP_WORKSPACE\lt_clean2\work\p5d\roottable_%s.json" % w))
    out.append('    "%s": [' % w)
    for r in sorted(d["rows"], key=lambda r: (-r["R"], r["fam"], r["bb"])):
        out.append('        ("%s", %s, %s, %s, "%s", %s),' % (r["fam"], r["R"], tuple(r["bb"]), r["L"], r["pair"], r["ang"]))
    out.append("    ],")
out.append("}")
p = r"C:\NX_MCP_WORKSPACE\lt_clean2\nx\design2.py"
d = open(p).read()
a = d.index("# ============================================================================================ P5d: root blends + seams")
b = d.index("# ============================================================================================ P5c fix round 1")
d = d[:a].rstrip("\n") + "\n" + "\n".join(out) + "\n\n" + d[b:]
open(p, "w").write(d)
