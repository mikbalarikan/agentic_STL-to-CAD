import numpy as np, pyvista as pv, sys
pv.OFF_SCREEN = True
P = "nx/P5c/"
mo = pv.read(P + "out_P5c.stl"); mi = pv.read(P + "inn_P5c.stl")
def shot(name, mesh, pos, focal, par, up=(0, 0, 1), size=(1500, 1000), color="lightsteelblue", clim=None, axis=2):
    p = pv.Plotter(off_screen=True, window_size=size, lighting="none"); p.set_background("white")
    if clim:
        mesh = mesh.copy(); mesh["h"] = mesh.points[:, axis]
        p.add_mesh(mesh, scalars="h", clim=clim, cmap="coolwarm", show_scalar_bar=False, smooth_shading=False, specular=0.1, ambient=0.35, diffuse=0.65)
    else:
        p.add_mesh(mesh, color=color, smooth_shading=False, specular=0.1, ambient=0.35, diffuse=0.65)
    p.camera_position = [pos, focal, up]; p.camera.enable_parallel_projection(); p.camera.parallel_scale = par
    d = np.array(focal, float) - np.array(pos, float); d /= np.linalg.norm(d)
    side = np.cross(d, np.array(up, float)); side /= np.linalg.norm(side)
    u = np.cross(side, d)
    for k, (a, b, inten) in enumerate(((0.8, 0.7, 0.55), (-0.9, 0.2, 0.25), (0.1, -0.8, 0.2))):
        lp = np.array(focal, float) + 300 * (-d * 0.6 + side * a + u * b)
        p.add_light(pv.Light(position=tuple(lp), focal_point=tuple(focal), intensity=inten, light_type="scene light"))
    p.screenshot(P + name); p.close(); print(name)
# knee +X corner (ear / tail), seen from outside-above and from inside
shot("p5b_out_ear.png", mo, (140, -120, 90), (62, -42, 15), 38, clim=(-14, 37))
shot("p5b_inn_ear.png", mi, (140, -120, 20), (62, -42, 60), 38, clim=(35, 85))
shot("p5b_out_ear_top.png", mo, (62, -42, 300), (62, -42, 15), 28, up=(0, 1, 0), clim=(-14, 37))
shot("p5b_inn_ear_bot.png", mi, (62, -42, -200), (62, -42, 60), 28, up=(0, 1, 0), clim=(35, 85))
# ribs and gussets from the joint side
shot("p5b_out_ribs.png", mo, (40, 110, 400), (40, 110, 0), 190, up=(0, 1, 0), size=(1000, 1700), clim=(-25, 37))
shot("p5b_inn_ribs.png", mi, (40, 110, -300), (40, 110, 70), 190, up=(0, 1, 0), size=(1000, 1700), clim=(35, 95))
shot("p5b_out_gussets_obl.png", mo, (-120, 150, 150), (40, 215, 10), 95, clim=(-25, 37))
shot("p5b_inn_gussets_obl.png", mi, (-120, 150, -20), (40, 215, 60), 95, clim=(35, 95))
# pad and tabs
shot("p5b_out_pad.png", mo, (60, 60, 120), (92, 110, 30), 30, clim=(20, 36))
shot("p5b_out_tabs_D.png", mo, (-80, 150, 40), (-19, 186, 4), 25, clim=(-4, 12))
shot("p5b_out_clip_tabC.png", mo, (150, 150, 100), (94, 207, 5), 25, clim=(-4, 21))
shot("p5b_inn_lugs.png", mi, (-80, 150, -10), (-19, 186, 66), 25, clim=(55, 80))
