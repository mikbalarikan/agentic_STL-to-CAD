import sys, os, numpy as np, json
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
res={}
for scan,key,sgn in (("out_scan","out",-1),("inn_scan","inn",1)):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    t=np.load(os.path.join(lib.W,"m5",f"{key}_thick.npy")); dot=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["dot"]
    th=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))
    thin=(dot<0)&(t>1.6)&(t<2.25)&(c[:,0]>40)&(np.abs(th)<75)
    print(key,"thin n",thin.sum(),"area",ar[thin].sum())
    rows=[]
    for y0 in range(56,270,6):
        m=thin&(c[:,1]>=y0)&(c[:,1]<y0+6)
        if m.sum()<30: continue
        a=sgn*th[m]; k=a>=np.percentile(a,97)   # extreme side = away from joint
        p=c[m][k].mean(0); rows.append([y0+3,th[m][k].mean(),*p, np.percentile(a,3)*sgn])
        print(f" y{y0+3:4d} n{m.sum():5d} theta_edge {th[m][k].mean():6.1f} (min side {np.percentile(a,3)*sgn:6.1f}) edge xyz {np.round(p,1)}")
    res[key]=rows
json.dump(res,open(os.path.join(lib.W,"m5","edge_pts.json"),"w"))
