import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from m1_r_design import profile,dist2poly,stats,S
out={}
for lab,design,ax in (("part5",(68.9,37.25,1.7,-13.9,83.62,3.4,3.3),(0,0)),("rec_origin",(68.85,36.07,1.6,-13.9,83.6,3.3,3.1),(0,0)),("rec_axisfit",(68.85,36.07,1.6,-13.9,83.6,3.3,3.1),(0.14,-0.01))):
    poly=profile(*design); out[lab]={}
    for nm,pre in (("out_scan","out"),("inn_scan","inn")):
        ids=np.load(f"work/masks/{pre}_ext_drum.npy"); c=S[nm][0][ids]; w=S[nm][2][ids]
        rho=np.hypot(c[:,0]-ax[0],c[:,1]-ax[1]); d,_=dist2poly(rho,c[:,2],poly); out[lab][nm]=stats(d,w)
        s=out[lab][nm]; print(lab,nm,"n",s['n'],"<=.5 %.4f <=.3 %.4f p50 %.3f p90 %.3f p95 %.3f p99 %.3f"%(s['le0p5'],s['le0p3'],s['p50'],s['p90'],s['p95'],s['p99']))
json.dump(out,open("work/m1/_cmp_part5.json","w"),indent=1)
