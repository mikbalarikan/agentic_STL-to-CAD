import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_f_data as FD
P=np.load("work/m2/ext_pts.npy"); x,y,z=P[:,0],P[:,1],P[:,2]
ov=np.hypot(x,y)-FD.drum_R(np.clip(z,-13.9,83.62))   # >0 outside drum cone
th=np.degrees(np.arctan2(z-35,x-40))
print("Y: protrusion beyond drum (mm) max in sectors +X(|th|<45) top(45..135) -X bottom(-135..-45); and area fraction beyond 1mm")
for yy in range(28,84,4):
    m=(np.abs(y-yy)<=1)
    row=[]
    for nm,sel in (("+X",np.abs(th)<45),("top",(th>=45)&(th<135)),("-X",np.abs(th)>=135),("bot",(th<=-45)&(th>-135))):
        s=m&sel&(z>-13)&(z<83)   # skip drum discs
        o=ov[s]
        row.append("%s: n=%d p95 %.1f frac>1mm %.2f"%(nm,s.sum(),np.percentile(o,95) if s.sum() else np.nan,(o>1).mean() if s.sum() else np.nan))
    print(yy," | ".join(row))
