import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
os.environ["EXTP"]="work/m2/ext_pts_long.npy"
import numpy as np, m2_loft as L, m2_g_fit as G
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
tag=sys.argv[1]; d=np.load(f"work/m2/loft_{tag}.npz"); st=d["st"]; lf=L.Loft(st,d["P"].shape[1],d["P"])
V,F,ys,u=G.mesh_of(lf,st[0],st[-1]); S=G.scan_pts(235,288); dd=G.dist_to(V,F,S[:,:3])
th=np.arctan2(S[:,2]-35,S[:,0]-40); r=np.hypot(S[:,0]-40,S[:,2]-35); sg=np.zeros(len(S)); uu=np.linspace(0,1,1440,endpoint=False); yy=np.round(S[:,1])
for y0 in np.unique(yy):
    m=yy==y0; C=lf.curve(y0,uu)[0]; rc=np.hypot(C[:,0]-40,C[:,1]-35); tc=np.mod(np.arctan2(C[:,1]-35,C[:,0]-40),2*np.pi); o=np.argsort(tc)
    sg[m]=r[m]-np.interp(np.mod(th[m],2*np.pi),tc[o],rc[o],period=2*np.pi)
sd=np.sign(sg)*dd
fig,ax=plt.subplots(1,1,figsize=(22,10)); sc=ax.scatter(np.degrees(th),S[:,1],c=np.clip(sd,-1.5,1.5),s=1.5,cmap='seismic'); plt.colorbar(sc); ax.grid(True); ax.set_title(tag)
plt.savefig(f"work/m2/hipmap_{tag}.png",dpi=45)
