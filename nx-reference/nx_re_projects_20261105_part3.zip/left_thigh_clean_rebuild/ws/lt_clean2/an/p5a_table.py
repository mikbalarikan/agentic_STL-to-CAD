import json, re
pat = {'out': r'KNEE_|FLOORHOLE|COVERPIN|HIP_PLATE|HIP_RING_BORE',
       'inn': r'KNEE_DISC|HUB_UNDER|^CH_(RING|RUN|H\d)|SPOKE|MISS_B2|MISS_ARC|HIP_WEB|HIP_BLOCK|HIP_PAD|HIP_RING_CLEAR|^B[67]_col'}
lines = []
for w, a, b in (('out', 'p5aout_out', 'p5aoutx_out'), ('inn', 'p5ainn_inn', 'p5ainnx_inn')):
    A = json.load(open('work/gates/%s.json' % a)); B = json.load(open('work/gates/%s.json' % b))
    lines.append('%s zones  pure: %s' % (w, {k: v['new'] for k, v in A['zones'].items()}))
    lines.append('%s zones  +preview: %s   (old %s, p5 %s)' % (w, {k: v['new'] for k, v in B['zones'].items()}, {k: v['old'] for k, v in B['zones'].items()}, {k: v['p5'] for k, v in B['zones'].items()}))
    lines.append('%s CAD->scan p50/p90/within0.5  pure %.3f/%.2f/%.1f  +preview %.3f/%.2f/%.1f' % (w, A['cad_to_scan']['p50'], A['cad_to_scan']['p90'], A['cad_to_scan']['within05'], B['cad_to_scan']['p50'], B['cad_to_scan']['p90'], B['cad_to_scan']['within05']))
    lines.append('%-26s %6s %8s %8s %8s %8s' % ('mask (%s_f_)' % w, 'n', 'pure', '+preview', 'old', 'part5'))
    for k, v in sorted(A['features'].items()):
        if re.search(pat[w], k) and not k.endswith('_root') and 'CAP' not in k:
            vb = B['features'][k]
            lines.append('%-26s %6d %8.2f %8.2f %8.2f %8.2f' % (k, v['n'], v['new'], vb['new'], v['old'], v['p5']))
    lines.append('')
open('nx/P5a/mask_table.txt', 'w').write('\n'.join(lines))
print('\n'.join(lines))
