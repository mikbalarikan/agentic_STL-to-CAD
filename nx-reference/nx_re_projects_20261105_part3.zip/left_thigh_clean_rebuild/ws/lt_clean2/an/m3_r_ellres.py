import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.optimize import least_squares
HX,HZ=37.97,35.18
D=np.load("work/m3/ext_pts.npz"); P=D['P']; th=D['th']
def ell(p,x,z):
    u=(x-p[0])/p[2]; w=(z-p[1])/p[3]; q=np.hypot(u,w); return np.hypot(x-p[0],z-p[1])*(1-1/q)
fig,ax=plt.subplots(2,4,figsize=(26,10))
for a,y in zip(ax.flat,(230,240,250,258,262,266,270,276)):
    k=(abs(P[:,1]-y)<0.6)&(abs(P[:,2]-HZ)>4); x,z=P[k,0],P[k,2]
    e=least_squares(ell,[HX,HZ,80,75],args=(x,z)).x; r=ell(e,x,z); t=th[k]
    a.plot(t,r,'k.',ms=2); a.set_title(f"Y={y} ellipse resid (mm) a={e[2]:.1f} b={e[3]:.1f} cx={e[0]:.1f}"); a.grid(True); a.set_ylim(-4,4)
plt.tight_layout(); plt.savefig("work/m3/ell_resid_theta.png",dpi=45)
