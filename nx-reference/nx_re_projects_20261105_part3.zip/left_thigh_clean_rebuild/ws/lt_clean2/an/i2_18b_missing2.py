from i2_rows import *
import json
rows = []
x, y, z = c[:, 0], c[:, 1], c[:, 2]
# dome pocket ceiling between ARM_B2_D and the +X wall
tab = []
for y0 in range(20, 64, 4):
    s = (x > 67) & (x < 73) & (y >= y0) & (y < y0 + 4) & (n[:, 2] < -0.2) & (z > 55) & (z < 80) & (d >= 2.0)
    if s.sum() > 15: tab.append((y0 + 2, round(float(np.percentile(z[s], 5)), 2)))
mk = (x > 61) & (x < 82) & (y > 20) & (y < 62) & (n[:, 2] < -0.1) & (z > 55) & (z < 80) & (d >= 2.0)
rows.append(make_row("MISS_B2_DOME", "pocket_ceiling", dict(ceiling_z_at_x70_by_y=tab, bounds="x 62..80, y 22..58",
                     note="shell is locally thick between ARM_B2_D and the +X wall: the underside is a domed ceiling (z 64.5 at y 45, 70.7 at y 52, 75 at y 58)"),
                     "ceiling level (5th pct of z, nz<-0.2) in 4 mm y-bins at x 67..73", None, mk, dict(note="part 5 ceiling ~70.5 flat-topped at y 45, sharp corners")))
dump("missing2", rows)
rows2 = []
mk = (x > 52) & (x < 80) & (y > -52) & (y < -22) & (d >= 2.0) & (z > 36)
rows2.append(make_row("MISS_B1_EAR", "ear_lobe", dict(column_centre=[61.2, -40.2], column_D=15.2, edge_line_from=[53.0, -43.5], edge_line_to=[62.0, -50.6],
                      note="teardrop lobe around the B1 column: straight edge ~(53,-43.5)->(62,-50.6) tangent to the column, joined to the drum wall; its walls are vertical (p90 6.5 mm in part 5)"),
                      "column fit (B1_col) + outline read from the plan view; vertical wall cluster x 56..77, y -51..-24", None, mk,
                      dict(note="part 5: plain D15 column extruded z 36..83.5 (B1_EAR stage)")))
dump("missing3", rows2)
