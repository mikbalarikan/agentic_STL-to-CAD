from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS, math
rows = []
x, y, z = c[:, 0], c[:, 1], c[:, 2]
# ---------------- MISSING 1: arc rib between ARM_B3_R and the cable-channel run (not in part 5)
m0 = (n[:, 2] < -0.9) & (x > -3) & (x < 48) & (y > 58) & (y < 82) & (d >= 2.0) & ((np.abs(z - 65.08) < 0.2) | (np.abs(z - 71.07) < 0.2))
P = []
for x0 in np.arange(-2, 47, 2.0):
    s = m0 & (x >= x0) & (x < x0 + 2)
    if s.sum() > 8: lo, hi = np.percentile(y[s], [3, 97]); P.append((x[s].mean(), (lo + hi) / 2))
cx, cy, R, rms = circle_fit(np.array(P))
rr = np.hypot(x - cx, y - cy); th = np.degrees(np.arctan2(y - cy, x - cx))
th_lo, th_hi = np.degrees(np.arctan2(61.5 - cy, 46.5 - cx)), np.degrees(np.arctan2(78.4 - cy, -3.5 - cx))
w = (np.abs(n[:, 2]) < 0.4) & (np.abs(rr - R) < 3) & (z > 60) & (z < 72) & (th > min(th_lo, th_hi)) & (th < max(th_lo, th_hi)) & (d >= 2.0)
h, ed = np.histogram(rr[w], bins=np.arange(R - 3, R + 3, 0.05), weights=a[w])
from scipy.signal import find_peaks
pk, _ = find_peaks(h, height=h.max() * 0.15, distance=5); pr = sorted([ed[i] + .025 for i in pk], key=lambda v_: -h[int((v_ - (R - 3)) / 0.05)])[:2]
pr = sorted(pr)
free = []
for t0 in np.arange(min(th_lo, th_hi), max(th_lo, th_hi), 3):
    s = m0 & (th >= t0) & (th < t0 + 3)
    if s.sum() > 5: free.append((round(float(t0 + 1.5), 1), round(float(np.median(z[s])), 2)))
mk = (np.abs(rr - R) < 3.4) & (th > min(th_lo, th_hi) - 1) & (th < max(th_lo, th_hi) + 1) & (d >= 2.0) & (z > 36.5) & (z < 79) & (x > -6) & (x < 50) & (y > 56) & (y < 84)
rows.append(make_row("MISS_ARC_RIB", "arc_rib", dict(arc_centre=[cx, cy], arc_R=R, t=(pr[1] - pr[0]) if len(pr) == 2 else None, wall_radii=pr, free_edge_by_angle=free, free_z_levels=[65.08, 71.07],
                     from_xy=[-3.5, 78.4], to_xy=[46.5, 61.5], note="starts at the end of ARM_B3_R (x -4), ends on the channel run rib; free edge 65.08 up to x~39, 71.07 after"),
                     "centre line of the free-edge faces per 2 mm x-bin -> circle fit; wall radii from histogram", rms, mk, dict(note="not modelled in part 5")))
# ---------------- MISSING 2: oval slot at (0, 46) in the disc floor
xs, ys = 0.5, 46.0
r_ = np.hypot(x - xs, y - ys)
ms = (np.abs(n[:, 2]) < 0.3) & (r_ < 3.5) & (z > 76) & (z < 84) & (d >= 0.3)
ex_ = (np.percentile(x[ms], 1), np.percentile(x[ms], 99)); ey_ = (np.percentile(y[ms], 1), np.percentile(y[ms], 99))
mk = (np.hypot(x - (ex_[0] + ex_[1]) / 2, y - (ey_[0] + ey_[1]) / 2) < 5.0) & (z > 76) & (z < 85) & (d >= 0.3) & (np.abs(n[:, 2]) < 0.7)
rows.append(make_row("MISS_OVAL_SLOT", "slot", dict(centre=[(ex_[0] + ex_[1]) / 2, (ey_[0] + ey_[1]) / 2], width_x=ex_[1] - ex_[0], length_y=ey_[1] - ey_[0],
                     note="through slot in the disc floor between the channel ring end and the arc rib"), "extent of the vertical wall tris within 3.5 mm of (0.5,46)", None, mk, dict(note="not modelled in part 5")))
dump("missing", rows)
