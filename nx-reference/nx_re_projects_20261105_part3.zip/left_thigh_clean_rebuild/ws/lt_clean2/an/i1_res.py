import i1_run
from i1_core import *
cov=np.zeros(len(c),bool)
for f_ in FEATS: cov[np.load(os.path.join(MASKS,f"out_f_{f_['id']}.npy"))]=True
deep=de>=3.9; bad=(d5>=.5)
lostm=deep&bad&(d0<.5)
print("deep area %.2f%%, deep&bad5 %.2f%% (lost vs old %.2f%%); covered share of lost: %.2f%%"%(a[deep].sum()/TOT*100,a[deep&bad].sum()/TOT*100,a[lostm].sum()/TOT*100,a[lostm&cov].sum()/TOT*100))
print("uncovered lost %.2f%%  uncovered bad(any old) %.2f%%"%(a[lostm&~cov].sum()/TOT*100,a[deep&bad&~cov].sum()/TOT*100))
np.save(os.path.join(I1,"cov.npy"),cov)
# grid cluster of uncovered lost
m=lostm&~cov
import scipy.ndimage as ndi
gx=np.floor((c[:,0]+80)/2).astype(int); gy=np.floor((c[:,1]+70)/2).astype(int)
H=np.zeros((130,190)); np.add.at(H,(gx[m],gy[m]),a[m])
lab,nl=ndi.label(H>0.5, structure=np.ones((3,3)))
rows=[]
for k in range(1,nl+1):
    cells=np.argwhere(lab==k); s=H[lab==k].sum()
    rows.append((s/TOT*100, cells[:,0].mean()*2-80+1, cells[:,1].mean()*2-70+1, len(cells)))
rows.sort(reverse=True)
for r_ in rows[:25]: print("  %.3f%%  at x %.0f y %.0f  (%d cells)"%r_)
