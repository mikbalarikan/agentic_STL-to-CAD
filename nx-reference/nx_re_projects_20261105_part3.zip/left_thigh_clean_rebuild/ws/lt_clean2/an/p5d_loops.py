import numpy as np
from scipy import ndimage as ndi
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
res=0.5
for w in ("out","inn"):
    d=np.load(f"work/p5d/c2/e0cls_{w}.npz"); p=d["pts"]; n=d["nrm"]; dP=d["dP"]; dS=d["dS"]
    z0,z1=(-14,37.5) if w=="out" else (33.5,100)
    for side,sel in (("PX",n[:,0]>0.5),("MX",n[:,0]<-0.5)):
        m=sel&(p[:,2]>z0)&(p[:,2]<z1)&(p[:,1]>100)&(p[:,1]<250)&(np.abs(p[:,2]-(35.2))>0.0)
        # exclude the joint-plane strip
        ys=np.arange(100,250,res); zs=np.arange(z0,z1,res)
        iy=((p[m,1]-100)/res).astype(int); iz=((p[m,2]-z0)/res).astype(int)
        shape=(len(ys),len(zs)); cnt=np.zeros(shape); oc=np.zeros(shape); os_=np.zeros(shape)
        np.add.at(cnt,(iy,iz),1); np.add.at(oc,(iy,iz),dP[m]>0.8); np.add.at(os_,(iy,iz),dS[m]>0.8)
        have=cnt>0
        A=have&(oc/np.maximum(cnt,1)>0.5); B=have&(os_/np.maximum(cnt,1)>0.5)
        A=ndi.binary_opening(A,iterations=2); B=ndi.binary_opening(B,iterations=2)
        def big(M,minpix=400):
            lab,k=ndi.label(M); out=np.zeros_like(M)
            for i in range(1,k+1):
                if (lab==i).sum()>=minpix: out|=(lab==i)
            return out
        A=big(A); B=big(B)
        # restrict to region of the big opening(s): where A or B
        bA=A&~ndi.binary_erosion(A); bB=B&~ndi.binary_erosion(B)
        dtB=ndi.distance_transform_edt(~bB)*res; dtA=ndi.distance_transform_edt(~bA)*res
        a2b=dtB[bA]; b2a=dtA[bB]
        print(w,side,"CAD-open area %.0f mm2, scan-open area %.0f mm2, symmetric diff %.0f mm2 | CAD loop->scan loop p50 %.2f p90 %.2f max %.2f | scan->CAD p50 %.2f p90 %.2f max %.2f"%(A.sum()*res*res,B.sum()*res*res,(A^B).sum()*res*res,np.median(a2b) if len(a2b) else -1,np.percentile(a2b,90) if len(a2b) else -1,a2b.max() if len(a2b) else -1,np.median(b2a) if len(b2a) else -1,np.percentile(b2a,90) if len(b2a) else -1,b2a.max() if len(b2a) else -1))
        # clusters of A&~B (CAD open, scan closed) and B&~A
        for nm,M in (("CAD-open scan-closed",A&~B),("scan-open CAD-closed",B&~A)):
            M=ndi.binary_opening(M,iterations=2); lab,k=ndi.label(M)
            for i in range(1,k+1):
                q=lab==i; a=q.sum()*res*res
                if a>12:
                    yy,zz=np.where(q); print("     %s %.0f mm2 y %.0f..%.0f z %.0f..%.0f"%(nm,a,ys[yy.min()],ys[yy.max()],zs[zz.min()],zs[zz.max()]))
        fig,ax=plt.subplots(figsize=(14,5)); img=np.zeros(shape+(3,)); img[A&B]=(.4,.4,.4); img[A&~B]=(1,0,0); img[B&~A]=(0,0,1); img[~A&~B&have]=(.85,.95,.85)
        ax.imshow(img.transpose(1,0,2),origin="lower",extent=(100,250,z0,z1),aspect="equal"); ax.set_title(f"{w} {side}: grey both open, red CAD-only open, blue scan-only open")
        fig.tight_layout(); fig.savefig(f"work/p5d/c2/loop_{w}_{side}.png",dpi=70); plt.close(fig)
