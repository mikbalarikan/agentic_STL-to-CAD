import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
key,scan,dn,oldn,sg,f=sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4],int(sys.argv[5]),sys.argv[6]
v,fa=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,fa); w=ar/ar.sum()
st=np.load(os.path.join(lib.W,f"dev_{dn}.npz"))["d1"]; old=np.load(os.path.join(lib.W,oldn))["d1"]
dnw=np.load(os.path.join(lib.W,"m5",f))
sel2=(c[:,0]>32)&(c[:,1]>48)&(c[:,1]<268)
d=np.where(sel2,dnw,st)
band=np.zeros(len(c),bool); band[np.load(os.path.join(lib.W,"masks",f"{key}_band.npy"))]=1
cz=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz")); dot=cz["dot"]; th_=np.load(os.path.join(lib.W,"m5",f"{key}_thick.npy"))
th=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))*sg
pc=lambda m,x: w[m&(x<0.5)].sum()/w[m].sum()*100
print(key,"total p5",round(w[st<.5].sum()*100,2),"new",round(w[d<.5].sum()*100,2),"old",round(w[old<.5].sum()*100,2))
print(" band p5",round(pc(band,st),1),"new",round(pc(band,d),1),"old",round(pc(band,old),1))
intf=band&(dot<0); extf=band&(dot>=0)
print(" band int-facing share",round(w[intf].sum()/w[band].sum()*100,1),"new ok",round(pc(intf,d),1))
print(" band ext-facing share",round(w[extf].sum()/w[band].sum()*100,1),"new ok",round(pc(extf,d),1),"old ok",round(pc(extf,old),1))
for nm,m in (("int, thin 1.6-2.3",intf&(th_>1.6)&(th_<2.3)),("int, other",intf&~((th_>1.6)&(th_<2.3)))):
    print(" ",nm,"share of band",round(w[m].sum()/w[band].sum()*100,1),"new ok",round(pc(m,d),1))
# residual of int thin: where
m=intf&(th_>1.6)&(th_<2.3)&(d>=0.5)
print(" thin residual tris",m.sum(),"theta pct",np.round(np.percentile(th[m],[10,50,90]),1),"y pct",np.round(np.percentile(c[m,1],[10,50,90]),0),"d pct",np.round(np.percentile(d[m],[10,50,90]),2))
np.save(os.path.join(lib.W,"m5",f"{key}_dfix.npy"),d)
A=intf&(th_>1.6)&(th_<2.3)
B=extf&(c[:,0]>60)&(c[:,1]>115)&(c[:,1]<195)&(th>5)&(th<55)
Cc=extf&~B
rim=(np.abs(c[:,2]-35.5)<5)
D1_=intf&~A&rim; D2_=intf&~A&~rim
print(" categories (share of band, new ok, old ok):")
for nm,m in (("A panel thin wall",A),("B ext skin y115-195 th5-55",B),("C other ext-facing",Cc),("D1 int other near joint rim",D1_),("D2 int other elsewhere",D2_)):
    print(f"   {nm:30s} {w[m].sum()/w[band].sum()*100:5.1f}%  new {pc(m,d):5.1f}  old {pc(m,old):5.1f}  p5 {pc(m,st):5.1f}")
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,axs=plt.subplots(1,2,figsize=(20,8))
cols={"B":'orange',"C":'g',"D1":'k',"D2":'m'}
for ax,(xl,lab) in zip(axs,((c[:,0]>60,"x>60"),(c[:,0]<=60,"x<=60"))):
    for nm,m in (("C",Cc),("D2",D2_),("B",B),("D1",D1_)):
        mm=m&xl&(d>=0.5)
        ax.scatter(c[mm,1][::2],th[mm][::2],s=1,c=cols[nm],label=nm)
    ax.legend(markerscale=8);ax.set_title(f"{key} residual (d>=0.5) band tris by category, {lab}; y vs theta*sg");ax.grid(alpha=.3)
plt.savefig(os.path.join(lib.W,"m5",f"resid_{key}.png"),dpi=55)
for nm,m in (("B",B),("C",Cc),("D2",D2_)):
    print(nm,"x>60 share of area",round(w[m&(c[:,0]>60)].sum()/w[m].sum()*100,1))
