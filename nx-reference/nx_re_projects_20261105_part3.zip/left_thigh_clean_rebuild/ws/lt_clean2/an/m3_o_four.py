import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
D=np.load("work/m3/ext_pts.npz"); P=D['P']; r=D['r']; th=np.radians(D['th'])
# use |theta| (mirror symmetric) -> cos series, plus sin check
def fit(y,N,sinterms=False):
    k=(abs(P[:,1]-y)<0.7)&(abs(np.degrees(th))<175)&(abs(np.degrees(th))>5)
    t=th[k]; rr=r[k]
    cols=[np.cos(n*t) for n in range(N+1)]
    if sinterms: cols+= [np.sin(n*t) for n in range(1,N+1)]
    A=np.stack(cols,1); co,res,_,_=np.linalg.lstsq(A,rr,rcond=None); e=rr-A@co
    return co,e
print('Y   N=2 N=3 N=4 N=6 N=8 resid std (cos-only);  with sin N=4')
for y in (230,240,250,258,262,266,270,276,282,286):
    s=[fit(y,N)[1].std() for N in (2,3,4,6,8)]
    print(y,' '.join('%.3f'%x for x in s),' sin4: %.3f'%fit(y,4,True)[1].std(), ' coeffs N=4:',fit(y,4)[0].round(2))
