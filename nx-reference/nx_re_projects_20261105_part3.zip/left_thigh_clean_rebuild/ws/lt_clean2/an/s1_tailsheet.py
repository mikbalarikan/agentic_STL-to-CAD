from s1_geo import *
from s1_lib import *
from OCP.Geom import Geom_BSplineCurve
def open_curve(P2, y, NPL=12):
    poles = TColgp_Array1OfPnt(1, NPL)
    for i, (x, z) in enumerate(P2): poles.SetValue(i + 1, gp_Pnt(float(x), float(y), float(z)))
    interior = np.linspace(0, 1, NPL - 2)[1:-1]
    kn = np.r_[0.0, interior, 1.0]; mu = np.r_[4, [1] * len(interior), 4]
    K = TColStd_Array1OfReal(1, len(kn)); M = TColStd_Array1OfInteger(1, len(kn))
    for i, (k, m) in enumerate(zip(kn, mu)): K.SetValue(i + 1, float(k)); M.SetValue(i + 1, int(m))
    return Geom_BSplineCurve(poles, K, M, 3, False)
def tail_sheet(Ps, ys):
    ts = BRepOffsetAPI_ThruSections(False, False, 1e-6)
    for P2, y in zip(Ps, ys):
        e = BRepBuilderAPI_MakeEdge(open_curve(P2, y)).Edge(); ts.AddWire(BRepBuilderAPI_MakeWire(e).Wire())
    ts.Build(); return ts.Shape()
if __name__ == '__main__':
    d = np.load(os.path.join(S1, 'tail_poles.npz')); sh = tail_sheet(d['P'], d['Ys'])
    V, F = to_mesh(sh, 0.03); import trimesh; trimesh.Trimesh(V, F, process=False).export(os.path.join(S1, 'tail_sheet.stl')); print(len(F))
    from s1_eval import zones, P, A
    m = zones['knee_tail(Y<-34)']; dd = dist_to_mesh(P[m], V, F); print('tail zone vs sheet', stats(dd, A[m]))
    # inside the sheet's Y/z extent only
    mm = m & (P[:, 1] > -50.8) & (P[:, 1] < -38) & (P[:, 2] < 62) ; dd = dist_to_mesh(P[mm], V, F); print('tail zone (Y -51..-38,z<62, outside drum)', stats(dd, A[mm]), mm.sum())
