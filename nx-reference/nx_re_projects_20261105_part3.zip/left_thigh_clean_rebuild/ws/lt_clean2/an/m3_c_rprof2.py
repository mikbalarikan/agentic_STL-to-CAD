import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
HX,HZ=37.97,35.18
sc={n:lib.load(n,1500000) for n in ('out_scan','inn_scan')}
angs=[-150,-120,-90,-60,-30,0,30,60,90,120,150,180]
print('ang',angs)
for y in list(range(262,290,2))+[287,288]:
    row=[]
    for a in angs:
        n='out_scan' if (a<0 or abs(a)>=175 and False) else 'inn_scan'
        if a==0 or a==180: 
            row.append(np.nan);continue
        v,f=sc[n]; c,_,_=lib.tri_data(v,f)
        m=(abs(c[:,1]-y)<0.7)
        th=np.degrees(np.arctan2(c[m,2]-HZ,c[m,0]-HX)); r=np.hypot(c[m,0]-HX,c[m,2]-HZ)
        k=abs(th-a)<5
        row.append(np.percentile(r[k],95) if k.sum()>5 else np.nan)
    print(y,' '.join(f"{x:6.2f}" for x in row))
