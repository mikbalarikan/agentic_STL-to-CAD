from i1_common import *
S = load_all()
c,a,de,d5,d0 = S['c'],S['a'],S['de'],S['d5'],S['d0']
print(len(c), c.min(0), c.max(0), a.sum())
deep = de>3.9
print("deep tris", deep.sum(), "area", a[deep].sum()/a.sum())
print("deep within0.5 old", a[deep&(d0<.5)].sum()/a[deep].sum(), "p5", a[deep&(d5<.5)].sum()/a[deep].sum())
print("de pcts", np.percentile(de,[50,90,99,100]))
