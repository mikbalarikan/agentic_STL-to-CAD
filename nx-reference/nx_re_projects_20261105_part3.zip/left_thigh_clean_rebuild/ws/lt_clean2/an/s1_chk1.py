from s1_eval import *
import trimesh
m=trimesh.load(os.path.join(S1,'env_H3.stl'),process=False); v,f=np.asarray(m.vertices),np.asarray(m.faces)
HX,HZ=37.97,35.18
phi=np.degrees(np.arctan2(z-HZ,x-HX))
for lo,hi in [(0,12),(15,25),(-12,0)]:
  for Y in [266,270,276,282,286]:
    q=(np.abs(y-Y)<1.5)&(phi>=lo)&(phi<hi)
    sd=signed_dist(P[q],v,f)
    print(lo,hi,Y,q.sum(),'signed dist median %.2f p10 %.2f p90 %.2f'%(np.median(sd),*np.percentile(sd,[10,90])))
