from i1_core import *
from i1_rib import *
from i1_help import *
import i1_blk2
from i1_blk2 import do_rib
import json

MISSING = []

# ---------------------------------------------------------------- re-fit ARM_B2_D as a 5 mm rib + shelf
r, ct = fit_rib(S, (73.6, 33.1), (55.16, 55.52), 5.0, 36.0, de_min=1.0, sa=8.0, sb=2.0, win=12.0)
p, e, nu, L, cand, s, u = ct
cxs = (s > 6) & (s < 27) & (de > 0.5)
up = cxs & (n[:, 2] > 0.95)
rib_u = u[up & (abs(c[:, 2] - 36.0) < 0.3) & (abs(u) < 5)]
shelf = cxs & (n[:, 2] > 0.6) & (abs(c[:, 2] - 4.6) < 0.7) & (u < -3.2) & (u > -11)
sh_u = u[shelf]
rib_edges = (float(np.percentile(rib_u, 1)), float(np.percentile(rib_u, 99))) if len(rib_u) > 20 else None
shelf_edges = (float(np.percentile(sh_u, 1)), float(np.percentile(sh_u, 99))) if len(sh_u) > 20 else None
zsh = float(np.median(c[shelf, 2])) if shelf.sum() > 10 else None
idx = np.where(cxs & (u > -11.5) & (u < 3.5) & (s > 4) & (s < 27) & (de > 1.0))[0]
t_rib = (rib_edges[1] - rib_edges[0]) if rib_edges else None
mid = (rib_edges[0] + rib_edges[1]) / 2 if rib_edges else 0
P0 = p + nu * mid; P1 = p + e * L + nu * mid
add("ARM_B2_D_SHELF", "arm + shelf", dict(rib_p0=P0, rib_p1=P1, rib_t=t_rib, rib_top=36.0, shelf_u_range=shelf_edges, shelf_top=zsh,
    shelf_note="shelf on the -u side (knee side), width = u range"), "u-histogram of top faces in the section frame of the arm", None, idx,
    dict(p0=(73.6, 33.1), p1=(55.16, 55.52), t=3.0, top=36.07, shelf=None),
    f"arm is {t_rib:.1f} mm thick (part 5 3.0), centre line off {mid:+.2f}; a shelf at z {zsh} {shelf_edges} beside it is missing in part 5 (the red band)", "arm t5 + shelf as an extrude of a 6 mm wide strip to z 4.6 (rectangle)")
MISSING.append("ARM_B2_D_SHELF")

# ---------------------------------------------------------------- missing low ribs (top 4.95, t 5) from B2 and B1 toward the knee ring
for fid, p0_, p1_, note in (("LOWRIB_B2", (52.5, 21.5), (70.0, 27.0), "radial low rib B2 -> knee ring"), ("LOWRIB_B1", (47.5, -33.0), (58.0, -37.5), "radial low rib B1 -> knee ring")):
    rec = do_rib(fid, "rib (MISSING in part 5)", p0_, p1_, 5.0, "rib", 4.95, 4.95, de_fit=1.0, de_mask=1.0, sa=1.0, sb=2.0, note=note)
    MISSING.append(fid)

# ---------------------------------------------------------------- right pad with two bosses (missing)
bx = (c[:, 0] > 84) & (c[:, 0] < 103) & (c[:, 1] > 92) & (c[:, 1] < 130) & (c[:, 2] > 26.5) & (de > 0.3)
X = c[bx, :2]; w_ = a[bx]
mu = np.average(X, axis=0, weights=w_); cv = np.cov((X - mu).T, aweights=w_); ev, evec = np.linalg.eigh(cv)
ax_ = evec[:, 1]; ang = float(np.degrees(np.arctan2(ax_[1], ax_[0])))
lx_ = (X - mu) @ ax_; ly_ = (X - mu) @ np.array([-ax_[1], ax_[0]])
ext = (float(np.percentile(lx_, 0.5)), float(np.percentile(lx_, 99.5)), float(np.percentile(ly_, 0.5)), float(np.percentile(ly_, 99.5)))
upz = bx & (n[:, 2] > 0.95)
pk = peaks(c[upz, 2], a[upz], 0.1, 0.04, rng=(26.5, 36.5))
bosses = []
for gx, gy in ((88.8, 99.3), (95.0, 121.7)):
    rr_ = np.hypot(c[:, 0] - gx, c[:, 1] - gy)
    wl = (rr_ < 5.5) & (rr_ > 1.0) & (abs(n[:, 2]) < 0.25) & (c[:, 2] > 25) & (c[:, 2] < 37) & (de > 0.3)
    if wl.sum() > 40:
        cx, cy, R, res, nn = circle_fit_robust(c[wl, 0], c[wl, 1]); bosses.append((cx, cy, 2 * R, res))
idx = np.where(bx | ((c[:, 0] > 84) & (c[:, 0] < 103) & (c[:, 1] > 92) & (c[:, 1] < 130) & (c[:, 2] > 20) & (c[:, 2] < 27) & (de > 0.3) & (abs(n[:, 2]) < 0.5)))[0]
add("PAD_RIGHT_2BOSS", "pad (MISSING in part 5)", dict(centre=mu, long_axis_deg=ang, extent_local=ext, top_plane_peaks=[(round(q[0], 2), round(q[1], 2)) for q in pk[:5]], boss_circles=bosses),
    "PCA of tris z>26.5 in the box + plane peaks + circle fits of the two boss rings", None, idx, None,
    "rectangular pad on the +X wall edge (x 85-100, y 96-128, tilted about %.0f deg), top ~29.5, rim 33.9, two ring bosses; part 5 has nothing here (only the skin)" % ang,
    "extrude the tilted rectangle (measured centre/angle/extent) to z 29.5 + two boss cylinders + rim frame to 33.85 (all primitives)")
MISSING.append("PAD_RIGHT_2BOSS")

# ---------------------------------------------------------------- B1 ear cell
idx = np.where((c[:, 0] > 54) & (c[:, 0] < 82) & (c[:, 1] > -53) & (c[:, 1] < -17) & (de > 0.2) & ~((np.hypot(c[:, 0] - 61.35, c[:, 1] + 40.01) < 8.3)))[0]
m = np.zeros(len(c), bool); m[idx] = True
fl = m & (n[:, 2] > 0.95) & (abs(c[:, 2]) < 0.4); wt = m & (n[:, 2] > 0.95) & (abs(c[:, 2] - 35.95) < 0.3)
rk2 = np.hypot(c[:, 0], c[:, 1]); thk2 = np.degrees(np.arctan2(c[:, 1], c[:, 0]))
add("EAR_B1_CELL", "wall cell (envelope gap)", dict(floor_z=float(np.median(c[fl, 2])) if fl.sum() else None, wall_top_z=35.95, wall_r_range=(float(np.percentile(rk2[wt], 1)), float(np.percentile(rk2[wt], 99))) if wt.sum() else None,
    wall_angle_range=(float(np.percentile(thk2[wt], 1)), float(np.percentile(thk2[wt], 99))) if wt.sum() else None, boss_ring_arc_present=True),
    "plane peaks + polar extents of the z35.95 faces", None, idx, None,
    "the scan has a curved wall cell (floor z 0.05, outer wall top 35.95, ramp fillet band at (65-75,-33..-28), concentric arc wall round B1) outside part-5 envelope; CAD has only the Ø15 column",
    "envelope/drum-wall extension: sector extrude (r 62-80, angle range) to z 35.95 + arc wall R~13 round B1; needs the zone owner (drum) decision")
MISSING.append("EAR_B1_CELL")

# ---------------------------------------------------------------- flat pad / pocket blob (62-74,78-95)
bz = (c[:, 0] > 60) & (c[:, 0] < 76) & (c[:, 1] > 76) & (c[:, 1] < 97) & (de > 1.0)
fl = bz & (n[:, 2] > 0.95) & (abs(c[:, 2] + 4.95) < 0.12)
if fl.sum() > 30:
    mu2 = np.average(c[fl, :2], axis=0, weights=a[fl]); ex_ = (np.percentile(c[fl, 0], [1, 99]), np.percentile(c[fl, 1], [1, 99]))
    add("FLATSPOT_X70Y88", "flat spot (MISSING in part 5)", dict(centre=mu2, z=-4.95, x_range=ex_[0], y_range=ex_[1]), "plane peak z -4.95 + extent", None, np.where(fl)[0], None,
        "a flat horizontal facet on the sloping floor", "document only; part of the +X band/floor surface (zone owner)")
    MISSING.append("FLATSPOT_X70Y88")

# ---------------------------------------------------------------- P3 side pad
bp = (c[:, 0] > -47) & (c[:, 0] < -29) & (c[:, 1] > 247) & (c[:, 1] < 263) & (de > 0.3)
up = bp & (n[:, 2] > 0.95) & (c[:, 2] > 30)
pk = peaks(c[up, 2], a[up], 0.1, 0.04, rng=(30, 40))
add("PAD_LEFT_P3", "pad (MISSING in part 5)", dict(top_peaks=[(round(q[0], 2), round(q[1], 2)) for q in pk[:4]], x_range=(float(np.percentile(c[up, 0], 1)), float(np.percentile(c[up, 0], 99))),
    y_range=(float(np.percentile(c[up, 1], 1)), float(np.percentile(c[up, 1], 99)))), "plane peaks + extent of upward faces above z30", None, np.where(bp & (de > 0.3) & (c[:, 2] > 5))[0], None,
    "a raised wall/pad strip (top 36.25 / 35.05) between the P3 lug and the left wall; part 5 has only the P3 lug", "extrude rectangle to 36.25 with a 35.05 step")
MISSING.append("PAD_LEFT_P3")
json.dump(MISSING, open(os.path.join(I1, "missing.json"), "w"))
