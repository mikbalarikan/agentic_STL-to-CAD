import sys, numpy as np, trimesh
sys.path.insert(0,'an'); import lib
G={"TG1 MX body":lambda c:(c[:,0]<-10)&(c[:,1]<200),"TG3 MX hip":lambda c:(c[:,0]<10)&(c[:,1]>200),"TG2 PX knee":lambda c:(c[:,0]>55)&(c[:,1]<80),"TG4 PX hip":lambda c:(c[:,0]>70)&(c[:,1]>200)}
def ext(c, key):
    y=c[key(c),1]; return (round(float(y.min()),1), round(float(y.max()),1)) if len(y) else None
for w, mk, z0, z1 in (("out","joint_tongue_side",35.2,35.9),("inn","joint_rebate_side",35.4,36.0)):
    v,f=lib.load(w+"_scan",1500000); c,nn,ar=lib.tri_data(v,f); m=np.load(f"work/masks/{w}_{mk}.npy"); cs=c[m]
    for tag,path in (("r0",f"nx/A_v2/{w}_A_r0.stl"),("r1",f"nx/A_v2/{w}_A.stl")):
        cm=trimesh.load(path); tc=cm.triangles_center; n=cm.face_normals
        k=(tc[:,2]>z0)&(tc[:,2]<z1)&(np.abs(n[:,2])<0.05); cc=tc[k]
        print(w,tag,"CAD", {g:ext(cc,f) for g,f in G.items()})
    # scan robust ends: 1st/99th percentile of y of mask tris per group
    print(w,"scan mask y (p1,p99)", {g:(round(float(np.percentile(cs[f(cs),1],1)),1),round(float(np.percentile(cs[f(cs),1],99)),1)) for g,f in G.items()})
