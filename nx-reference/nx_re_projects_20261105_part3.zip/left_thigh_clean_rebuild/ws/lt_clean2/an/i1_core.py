"""I1 core: shared data + feature registry."""
import json, os
from i1_common import *
from i1_fit import *
S = load_all()
c, n, a, de, d5, d0 = S['c'], S['n'], S['a'], S['de'], S['d5'], S['d0']
TOT = a.sum()
FEATS = []
OUTJSON = r"C:\NX_MCP_WORKSPACE\lt_clean2\FEATURES_out.json"

def wp90(d, idx):
    if len(idx) == 0: return float("nan")
    x = d[idx]; w = a[idx]; o = np.argsort(x); cw = np.cumsum(w[o])
    return float(x[o][min(np.searchsorted(cw, 0.9 * cw[-1]), len(o) - 1)])

def rnd(x, q=0.05):
    if isinstance(x, (list, tuple, np.ndarray)): return [rnd(t, q) for t in x]
    if isinstance(x, dict): return {k: rnd(v, q) for k, v in x.items()}
    if isinstance(x, (float, np.floating)):
        return float(round(round(x / q) * q, 3)) if np.isfinite(x) else None
    if isinstance(x, (np.integer,)): return int(x)
    return x

def add(fid, typ, params, method, residual, idx, p5=None, diag="", rec="", ftype=None, q=0.05):
    idx = np.unique(np.asarray(idx, dtype=np.int64))
    np.save(os.path.join(MASKS, f"out_f_{fid}.npy"), idx)
    o90, p90_ = wp90(d0, idx), wp90(d5, idx)
    lost = (a[idx][(d0[idx] < .5) & (d5[idx] >= .5)].sum() - a[idx][(d5[idx] < .5) & (d0[idx] >= .5)].sum()) / TOT * 100
    over5 = a[idx][d5[idx] >= .5].sum() / TOT * 100
    over0 = a[idx][d0[idx] >= .5].sum() / TOT * 100
    rec_ = dict(id=fid, type=typ, params=rnd(params, q), method=method, residual=rnd(residual, 0.001) if residual is not None else None,
                n_tris=int(len(idx)), area_mm2=round(float(a[idx].sum()), 1), mask="work\masks\out_f_%s.npy" % fid, part5_value=p5,
                old_p90=round(o90, 2), part5_p90=round(p90_, 2), lost_pts_vs_old=round(float(lost), 3), over05_pts_part5=round(float(over5), 3),
                over05_pts_old=round(float(over0), 3), diagnosis=diag, recommendation=rec)
    FEATS.append(rec_)
    flag = "***" if p90_ > 0.5 else "   "
    print(f"{flag}{fid:18s} {typ:14s} n={len(idx):6d} old {o90:5.2f} p5 {p90_:5.2f} lost {lost:6.3f} over5 {over5:6.3f}  {diag[:110]}")
    return rec_

def disc(x, y, r, dmin=2.5, extra=None):
    m = (np.hypot(c[:, 0] - x, c[:, 1] - y) < r) & (de > dmin)
    if extra is not None: m &= extra
    return np.where(m)[0]
