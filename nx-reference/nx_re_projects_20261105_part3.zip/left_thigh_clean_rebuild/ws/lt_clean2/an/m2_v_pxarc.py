import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
P=[]
for n,s in (("out_scan","out"),("inn_scan","inn")):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f); ex=np.load(f"work/m2/ext_{s}.npy"); P.append(c[ex])
P=np.vstack(P)
for y in (-30,-20,-10,0,10,20,30,40,50,60):
    q=P[(np.abs(P[:,1]-y)<=0.6)&(P[:,0]>np.sqrt(max(68.9**2-y**2,0))+1.0)&(P[:,2]>-10)&(P[:,2]<80)]
    if len(q)<50: print(y,len(q)); continue
    f=lambda p: np.hypot(q[:,0]-p[0],q[:,2]-p[1])-p[2]
    r=least_squares(f,[0,35,84],loss='soft_l1',f_scale=0.3)
    res=f(r.x); print(y,len(q),"circle cx %.1f cz %.1f R %.2f  resid p50 %.2f p95 %.2f"%(*r.x,np.median(abs(res)),np.percentile(abs(res),95)),"zrange",q[:,2].min().round(1),q[:,2].max().round(1))
