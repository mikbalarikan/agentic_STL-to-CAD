import sys, numpy as np, trimesh
sys.path.insert(0,"an"); import lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
tag=sys.argv[1]; src=sys.argv[2]
v,f=lib.load("out_scan",1500000); S=trimesh.Trimesh(v,f,process=False); C=trimesh.load(src,process=False)
p0=np.array([74.65,33.95]); p1=np.array([55.05,55.40]); d=(p1-p0)/np.linalg.norm(p1-p0); n=np.array([d[1],-d[0]])
ss=[26,28,30,31,32,33,34,36]
fig,ax=plt.subplots(2,4,figsize=(20,9))
for a,s in zip(ax.ravel(),ss):
    o=np.array([*(p0+s*d),0.0]); nrm=np.array([d[0],d[1],0.0])
    for M,c in ((S,"r"),(C,"b")):
        sec=M.section(plane_origin=o,plane_normal=nrm)
        if sec is None: continue
        for e in sec.entities:
            P=sec.vertices[e.points]; off=(P[:,0]-o[0])*n[0]+(P[:,1]-o[1])*n[1]
            a.plot(off,P[:,2],c,lw=0.8)
    a.set_xlim(-4,18); a.set_ylim(-14,12); a.set_aspect("equal"); a.grid(alpha=.3); a.set_title(f"s={s} (off across arm, z) red scan blue CAD")
plt.tight_layout(); plt.savefig(f"nx/P5d/{tag}.png",dpi=60)
