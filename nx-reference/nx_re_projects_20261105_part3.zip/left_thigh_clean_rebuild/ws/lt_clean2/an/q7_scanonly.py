import numpy as np, sys, glob, os, collections
sys.path.insert(0,"an"); import lib
from sklearn.cluster import DBSCAN
OUT=open("work/q7/scanonly.txt","w")
def P(*a):
    s=" ".join(str(x) for x in a); print(s); OUT.write(s+"\n")
for w in ("out","inn"):
    v,f=lib.load({"out":"out_scan","inn":"inn_scan"}[w],1500000); c,nn,ar=lib.tri_data(v,f)
    dd=np.load(f"work/dev_q7{w}_{w}.npz"); d1=dd["d1"]; de=dd["de"]
    owner=np.full(len(c),-1); names=[]
    for mp in sorted(glob.glob(f"work/masks/{w}_f_*.npy")): names.append(os.path.basename(mp)[len(w)+3:-4]); owner[np.load(mp)]=len(names)-1
    m=d1>1.0; P(f"##### {w}: scan area >1.0 mm from CAD: {ar[m].sum():.0f} mm2 ({ar[m].sum()/ar.sum()*100:.1f} %), >2.0: {ar[d1>2].sum():.0f} mm2")
    idx=np.where(m)[0]; lab=DBSCAN(eps=3,min_samples=5).fit_predict(c[idx]); rows=[]
    for l in set(lab)-{-1}:
        k=idx[lab==l]; a=ar[k].sum()
        if a<60: continue
        ow=owner[k]; cnt=collections.Counter(ow[ow>=0]).most_common(2)
        rows.append((a,c[k].min(0).round(0),c[k].max(0).round(0),d1[k].max(),np.median(d1[k]),"EXT" if np.median(de[k])<1 else "int",",".join(f"{names[i]}({n*100//len(k)}%)" for i,n in cnt) or "no mask"))
    for r in sorted(rows,key=lambda x:-x[0])[:22]: P("  %5.0f mm2 bbox %s %s max %.1f med %.1f %s near %s"%r)
