"""Curvature + zebra of the loft: grid (u,y), principal curvatures from first/second fundamental forms (finite differences)."""
import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_loft as L
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
def grid(lf,y0,y1,dy=1.0,nu=720):
    ys=np.arange(y0,y1+1e-6,dy); u=np.arange(nu)/nu
    C=lf.curve(ys,u); X=np.zeros(C.shape[:2]+(3,)); X[...,0]=C[...,0]; X[...,2]=C[...,1]; X[...,1]=ys[:,None]
    return ys,u,X
def curv(X,du,dy):
    # param: i (y), j (u, periodic)
    Xu=(np.roll(X,-1,1)-np.roll(X,1,1))/(2*du); Xuu=(np.roll(X,-1,1)-2*X+np.roll(X,1,1))/du**2
    Xv=np.gradient(X,dy,axis=0); Xvv=np.gradient(Xv,dy,axis=0); Xuv=np.gradient(Xu,dy,axis=0)
    n=np.cross(Xu,Xv); n/=np.linalg.norm(n,axis=-1,keepdims=True)
    # orient outward
    c=X.copy(); c[...,0]-=40; c[...,2]-=35; c[...,1]=0
    s=np.sign((n*c).sum(-1)); n*=s[...,None]
    E=(Xu*Xu).sum(-1);F=(Xu*Xv).sum(-1);G=(Xv*Xv).sum(-1)
    l=(Xuu*n).sum(-1); m=(Xuv*n).sum(-1); nn=(Xvv*n).sum(-1)
    den=E*G-F**2; K=(l*nn-m**2)/den; H=(G*l-2*F*m+E*nn)/(2*den)
    disc=np.sqrt(np.maximum(H**2-K,0)); k1=H+disc; k2=H-disc   # sign: n outward, convex -> k negative? use sign convention below
    return n,k1,k2
if __name__=="__main__":
    tag=sys.argv[1]; yr=(float(sys.argv[2]),float(sys.argv[3])) if len(sys.argv)>3 else None
    d=np.load(f"work/m2/loft_{tag}.npz"); lf=L.Loft(d["st"],d["P"].shape[1],d["P"])
    y0,y1=yr if yr else (d["st"][0],d["st"][-1])
    ys,u,X=grid(lf,y0,y1); nu=len(u); n,k1,k2=curv(X,2*np.pi/nu,ys[1]-ys[0])
    # with outward normal, convex surface has negative curvature in this convention
    kc=-np.minimum(k1,k2)    # largest convex curvature (>0 convex)
    kcc=np.maximum(k1,k2)    # largest concave curvature (>0 concave)
    sl=slice(2,-2)
    print("min convex radius %.2f mm (max conv curv %.4f)"%(1/np.nanmax(kc[sl]),np.nanmax(kc[sl])))
    print("min concave radius %.2f mm"%(1/max(np.nanmax(kcc[sl]),1e-9)))
    for p in (99,99.9): print("p%s convex curvature -> radius %.2f"%(p,1/np.percentile(kc[sl],p)))
    ik=np.unravel_index(np.nanargmax(kc[sl]),kc[sl].shape); print("worst convex at y=%.1f u=%.3f"%(ys[ik[0]+2],u[ik[1]]))
    # inflection / concave count
    print("concave fraction (k>0.002): %.4f"%((kcc[sl]>0.002).mean()))
    fig,axs=plt.subplots(2,3,figsize=(30,16))
    im=axs[0,0].imshow(np.clip(1/np.maximum(kc,1e-6),0,60),origin='lower',aspect='auto',extent=[0,360,ys[0],ys[-1]],cmap='viridis_r',vmax=60); axs[0,0].set_title("min convex radius (mm), clipped 60"); plt.colorbar(im,ax=axs[0,0])
    im=axs[0,1].imshow(np.clip(kcc,-0.0,0.02),origin='lower',aspect='auto',extent=[0,360,ys[0],ys[-1]],cmap='magma'); axs[0,1].set_title("concave curvature 1/mm"); plt.colorbar(im,ax=axs[0,1])
    Hm=-(k1+k2)/2; im=axs[0,2].imshow(np.clip(Hm,-0.02,0.04),origin='lower',aspect='auto',extent=[0,360,ys[0],ys[-1]],cmap='coolwarm'); axs[0,2].set_title("mean curvature"); plt.colorbar(im,ax=axs[0,2])
    for ax,Ld,t in zip(axs[1],((0.0,0.6,0.8),(0.8,0.2,0.5),(0.3,0.9,0.2)),("zebra light A","zebra B","zebra C")):
        Ld=np.array(Ld)/np.linalg.norm(Ld); s=(n*Ld).sum(-1); ax.imshow(np.sin(2*np.pi*14*s)>0,origin='lower',aspect='auto',extent=[0,360,ys[0],ys[-1]],cmap='gray'); ax.set_title(t)
    for ax in axs.ravel(): ax.set_xlabel("u*360 (0=+X, 90=+Z, 180=-X, 270=-Z)"); ax.set_ylabel("Y")
    plt.tight_layout(); plt.savefig(f"work/m2/curv_{tag}.png",dpi=40)
