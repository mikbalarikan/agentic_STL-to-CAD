import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
AX=(0.12,-0.02); Rp,zp,t=68.80,36.85,0.0275   # first-pass
THR=float(sys.argv[1]) if len(sys.argv)>1 else 0.35
res={}
fig,axs=plt.subplots(2,1,figsize=(22,13))
for a,(nm,zr) in zip(axs,(("out_scan",(-10.5,35)),("inn_scan",(35.5,80.5)))):
    v,f=lib.load(nm,1500000); c,nn,ar=lib.tri_data(v,f)
    x=c[:,0]-AX[0]; y=c[:,1]-AX[1]; r=np.hypot(x,y); ang=np.degrees(np.arctan2(x,-y))
    radial=(x*nn[:,0]+y*nn[:,1])/np.maximum(r,1e-9)
    dev=r-(Rp-np.abs(c[:,2]-zp)*t)
    ok=(radial>0.9)&(np.abs(dev)<THR)&(c[:,2]>zr[0])&(c[:,2]<zr[1])
    cand=(radial>0.5)&(np.abs(dev)<3)&(c[:,2]>zr[0])&(c[:,2]<zr[1])
    zb=np.arange(zr[0],zr[1],1.0); ab=np.arange(-180,181,1.0)
    rows=[]
    for z0 in zb:
        k=ok&(c[:,2]>=z0)&(c[:,2]<z0+1); k2=cand&(c[:,2]>=z0)&(c[:,2]<z0+1)
        h=np.histogram(ang[k],ab)[0]; h2=np.histogram(ang[k2],ab)[0]
        good=(h>=2)&(h>=0.5*h2)     # bin mostly drum-like
        # main arc containing ang 10 (bin 190), allow 2 deg gaps
        i0=190
        if not good[i0]: 
            j=np.where(good[170:215])[0]
            if len(j)==0: rows.append((z0+.5,np.nan,np.nan)); continue
            i0=170+j[0]
        L=i0
        gap=0
        while L>0:
            if good[L-1]: L-=1; gap=0
            elif gap<2 and good[max(L-3,0):L].any(): L-=1; gap+=1
            else: break
        # trim trailing gaps
        while not good[L]: L+=1
        R=i0; gap=0
        while R<359:
            if good[R+1]: R+=1; gap=0
            elif gap<2 and good[R+1:R+4].any(): R+=1; gap+=1
            else: break
        while not good[R]: R-=1
        rows.append((z0+.5,ab[L],ab[R]+1))
    rows=np.array(rows); res[nm]=rows.tolist()
    # dev map for plot
    m=(radial>0.5)&(c[:,2]>zr[0])&(c[:,2]<zr[1])&(np.abs(dev)<3)
    h,_,_=np.histogram2d(ang[m],c[m,2],bins=[np.arange(-180,181,2),np.arange(zr[0],zr[1]+.01,1)])
    a.scatter(ang[m][::20],c[m,2][::20],c=dev[m][::20],s=1,cmap='RdBu_r',vmin=-.6,vmax=.6)
    a.plot(rows[:,1],rows[:,0],'g-',lw=2); a.plot(rows[:,2],rows[:,0],'m-',lw=2); a.set_xlim(-180,180); a.set_title(f"{nm} drum arc limits (|dev|<{THR})"); a.grid(True,alpha=.3)
    for rr in rows[::4]: print(nm,rr)
plt.tight_layout(); plt.savefig("work/m1/boundary_check.png",dpi=55)
json.dump(res,open("work/m1/_boundary_raw.json","w"))
