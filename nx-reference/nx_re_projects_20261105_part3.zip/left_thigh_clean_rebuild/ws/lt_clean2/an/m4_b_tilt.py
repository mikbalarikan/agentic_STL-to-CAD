"""M4 step 1b: joint tilt model. Families of horizontal patches (rim, tongue top, boss) fitted with a common tilt
z = k_family + bx*x + by*y (least squares on patch vertices)."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
from m4_a_planes import patches, fit_plane
res = {}
fam_rng = {"out_scan": [("rim", 1, 34.4, 35.3), ("tongue", 1, 35.7, 36.5), ("boss", 1, 38.8, 39.4)],
           "inn_scan": [("lip", -1, 35.1, 35.6), ("rebate", -1, 35.8, 36.4), ("boss", -1, 38.8, 39.4)]}
for scan in ("out_scan", "inn_scan"):
    v, f = lib.load(scan, 1500000); c, nn, a = lib.tri_data(v, f)
    rows = []   # (family idx, x, y, z)
    pat = []
    for sgn in (1, -1):
        m, lab, nc = patches(v, f, c, nn, a, sgn)
        for k in range(nc):
            idx = m[lab == k]
            if a[idx].sum() < 8: continue
            P = v[np.unique(f[idx])]
            z = P[:, 2].mean()
            for fi, (nm, s, lo, hi) in enumerate(fam_rng[scan]):
                if s == sgn and lo < z < hi:
                    # robust: trim vertices beyond 2 sigma of own plane
                    pat.append((fi, P))
    fams = fam_rng[scan]
    def solve(pat, use_tilt=True):
        A = []; b = []
        for fi, P in pat:
            r = np.zeros((len(P), len(fams) + 2)); r[:, fi] = 1; r[:, -2] = P[:, 0]; r[:, -1] = P[:, 1]
            if not use_tilt: r[:, -2:] = 0
            A.append(r); b.append(P[:, 2])
        A = np.vstack(A); b = np.concatenate(b)
        sol, *_ = np.linalg.lstsq(A, b, rcond=None)
        return sol, (b - A @ sol)
    sol, r = solve(pat)
    sol0, r0 = solve(pat, False)
    print(scan, "common tilt fit: ", {fams[i][0]: round(sol[i], 3) for i in range(len(fams))}, "bx %.5f by %.5f (deg %.3f, %.3f)" % (sol[-2], sol[-1], np.degrees(sol[-2]), np.degrees(sol[-1])), "rms %.4f vs no-tilt %.4f" % (r.std(), r0.std()))
    res[scan] = dict(levels={fams[i][0]: float(sol[i]) for i in range(len(fams))}, bx=float(sol[-2]), by=float(sol[-1]), rms_tilt=float(r.std()), rms_flat=float(r0.std()))
    # per-patch residual after tilt
    for fi, P in pat:
        zz = P[:, 2] - sol[fi] - sol[-2] * P[:, 0] - sol[-1] * P[:, 1]
        print("   %-7s x%7.1f y%7.1f  mean res %+.3f sd %.3f" % (fams[fi][0], P[:, 0].mean(), P[:, 1].mean(), zz.mean(), zz.std()))
json.dump(res, open(os.path.join(lib.W, "m4", "tilt.json"), "w"), indent=1)
