from i1_core import *
from i1_rib import frame, local
def xs(nm,p0,p1,s0,s1,half=12,step=1.0):
    p,e,nu,L=frame(p0,p1); s,u=local(c,p,e,nu)
    m=(s>s0)&(s<s1)&(abs(u)<half)&(de>0.5)
    print(nm,"L=%.1f"%L)
    row=[]
    for u0 in np.arange(-half,half,step):
        k=m&(u>=u0)&(u<u0+step)
        up=k&(n[:,2]>0.6)
        row.append("%+.0f:%s"%(u0,("%.1f"%np.percentile(c[up,2],90)) if up.sum()>3 else "."))
    print("  "," ".join(row))
xs("ARM_B2_D band",(73.6,33.1),(55.16,55.52),10,22)
xs("radial B2",(75.85,29.86),(50,22),8,20,8)
xs("rib B1",(61.35,-40.0),(46,-32),8,13,8)
