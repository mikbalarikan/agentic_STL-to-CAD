"""fit clean plan paths (line / tangent line-arc-line / spline) to measured groove centres (valid stations, both parts averaged by taking the out data; inn shown too)"""
import json, numpy as np
from scipy.optimize import least_squares
from scipy.interpolate import CubicSpline
def centres(w, n, smax=None):
    r = json.load(open(f"work/p5d/seam_{w}.json"))[n]; Q = np.array(r["Q"]); ok = np.array(r["ok"]); dep = np.array(r["depth"]); s = np.array(r["s"])
    m = ok & (dep > 0.35)
    if smax: m &= s <= smax
    return Q[m], s[m]
def dist_poly(P, C):
    # distance of points P to polyline C (dense)
    d = np.full(len(P), 1e9)
    for a, b in zip(C[:-1], C[1:]):
        ab = b - a; L2 = ab @ ab
        t = np.clip(((P - a) @ ab) / max(L2, 1e-12), 0, 1)
        d = np.minimum(d, np.linalg.norm(P - (a + t[:, None] * ab), axis=1))
    return d
def lal(par, n=400):
    x0, y0, th0, L1, R, phi, L2 = par
    pts = [(x0, y0)]; x, y, th = x0, y0, th0
    t = np.linspace(0, 1, 60)
    seg = [np.c_[x0 + t * L1 * np.cos(th0), y0 + t * L1 * np.sin(th0)]]
    x, y = seg[0][-1]
    cx, cy = x - R * np.sin(th) * np.sign(phi), y + R * np.cos(th) * np.sign(phi)
    a0 = np.arctan2(y - cy, x - cx)
    aa = a0 + np.linspace(0, phi, 200)
    arc = np.c_[cx + abs(R) * np.cos(aa), cy + abs(R) * np.sin(aa)]
    th2 = th0 + phi
    x, y = arc[-1]
    seg2 = np.c_[x + t * L2 * np.cos(th2), y + t * L2 * np.sin(th2)]
    return np.vstack([seg[0], arc, seg2])
for w in ("out", "inn"):
    for n, smax in (("A", 232.0), ("B", 145.0)):
        P, s = centres(w, n, smax)
        print(w, n, "pts", len(P), "span s %.0f..%.0f" % (s.min(), s.max()))
        # line fit
        c = P.mean(0); u, sv, vt = np.linalg.svd(P - c); dv = vt[0]; dl = np.abs((P - c) @ vt[1])
        print("  line      p50 %.2f p90 %.2f max %.2f" % (np.median(dl), np.percentile(dl, 90), dl.max()))
        if n == "A":
            best = None
            for R0 in (25, 35, 50):
              for ph in (1.2, 1.8, 2.4):
                p0 = [P[0, 0], P[0, 1], np.arctan2(*(P[8] - P[0])[::-1]), 60.0, R0, -ph, 40.0]
                f = lambda p: dist_poly(P, lal(p))
                try:
                    r = least_squares(f, p0, loss="soft_l1", f_scale=0.3)
                except Exception: continue
                e = f(r.x)
                if best is None or np.percentile(e, 90) < np.percentile(best[1], 90): best = (r.x, e)
            x, e = best
            print("  line-arc-line p50 %.2f p90 %.2f max %.2f  par x0 %.2f y0 %.2f th0 %.1f L1 %.1f R %.1f phi %.1f L2 %.1f" % (np.median(e), np.percentile(e, 90), e.max(), x[0], x[1], np.degrees(x[2]), x[3], x[4], np.degrees(x[5]), x[6]))
            np.save(f"work/p5d/seamfit_{w}_A_lal.npy", x)
        # spline with k points (equal spacing in s), fit by moving points
        for k in (4, 5, 6, 7):
            idx = np.linspace(0, len(P) - 1, k).astype(int)
            X0 = P[idx].ravel()
            def fs(X):
                K = X.reshape(-1, 2); d = np.r_[0, np.cumsum(np.linalg.norm(np.diff(K, axis=0), axis=1))]
                cs = CubicSpline(d, K, bc_type="natural"); t = np.linspace(0, d[-1], 600); return dist_poly(P, cs(t))
            r = least_squares(fs, X0, loss="soft_l1", f_scale=0.3); e = fs(r.x)
            print("  spline k=%d p50 %.2f p90 %.2f max %.2f" % (k, np.median(e), np.percentile(e, 90), e.max()))
            if k == 5 and n == "A" or k == 4 and n == "B": np.save(f"work/p5d/seamfit_{w}_{n}_spl{k}.npy", r.x.reshape(-1, 2))
