import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, json, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
ys=[200,230,246,258,266,272,278,284,287]
P5=trimesh=None
import trimesh
e5=trimesh.load("work/env_part5.stl",process=False); ve,fe=np.asarray(e5.vertices),np.asarray(e5.faces)
S={n:lib.load(n,1500000) if 'scan' in n else lib.load(n) for n in('out_scan','inn_scan','out_cad','inn_cad')}
fig,ax=plt.subplots(3,3,figsize=(21,18))
for a,y in zip(ax.flat,ys):
    for n,c,lw in (('out_scan','k',.6),('inn_scan','b',.6),('out_cad','r',.4),('inn_cad','m',.4)):
        for p,q in lib.section(*S[n],1,y): a.plot([p[0],q[0]],[p[2],q[2]],c+'-',lw=lw)
    for p,q in lib.section(ve,fe,1,y): a.plot([p[0],q[0]],[p[2],q[2]],'g-',lw=.8)
    a.plot(37.97,35.18,'r+',ms=12); a.set_aspect('equal'); a.set_title(f"Y={y}"); a.grid(True)
plt.tight_layout(); plt.savefig("work/m3/ysec.png",dpi=55)
