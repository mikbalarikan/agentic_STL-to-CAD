from i1_common import *
from i1_rib import *
import ref5_design as DS, sys
S=load_all()
def go(nm,p0,p1,t0,top0=None):
    r,ct=fit_rib(S,p0,p1,t0,top0,de_min=3.0)
    prof,nn=top_profile(S,ct,r,t0)
    print(f"{nm:13s} L={r['L']:.0f} t={r.get('t',np.nan):.2f} off={r.get('off',np.nan):+.2f} rot={r.get('rot_deg',np.nan):+.2f}  top:", " | ".join("s%.0f-%.0f z%.1f->%.1f"%q for q in prof))
for nm,(a,b,top,t) in DS.OUT_RIBS.items(): go(nm,a,b,t,top)
for nm,(a,b,z0,z1,t) in DS.OUT_GUSSETS.items(): go(nm,a,b,t,(z0+z1)/2)
for nm,(a,bo,bi) in DS.ARMS.items(): go(nm,a,bo,3.0)
for nm,(a,b,w) in DS.FLANGES.items(): go(nm,a,b,w)
