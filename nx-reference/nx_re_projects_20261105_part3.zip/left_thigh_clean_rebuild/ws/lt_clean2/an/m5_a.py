import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, trimesh, open3d as o3d
env = trimesh.load(os.path.join(lib.W,"env_part5.stl"), process=False)
print("watertight", env.is_watertight, env.bounds)
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(np.asarray(env.vertices,np.float32)), o3d.core.Tensor(np.asarray(env.faces,np.uint32)))
for scan,key in (("out_scan","out"),("inn_scan","inn")):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f); w=ar/ar.sum()
    q=o3d.core.Tensor(c.astype(np.float32))
    sd=sc.compute_signed_distance(q).numpy()
    de=np.abs(sd)
    band=(de>=1)&(de<2.4)
    print(scan,"band tris",band.sum(),"area%",w[band].sum()*100,"signed neg share",(sd[band]<0).mean())
    print(" nx mean",nn[band].mean(0), "x>0 share", (c[band,0]>0).mean())
    # outward normal relative: dot of scan normal with direction to env
    np.save(os.path.join(lib.W,"masks",f"{key}_band.npy"),np.where(band)[0])
    np.save(os.path.join(lib.W,"m5",f"{key}_sd.npy"),sd)
    b=c[band]
    print(" X range pct",np.percentile(b[:,0],[1,25,50,75,99]),"Y",np.percentile(b[:,1],[1,50,99]),"Z",np.percentile(b[:,2],[1,50,99]))
