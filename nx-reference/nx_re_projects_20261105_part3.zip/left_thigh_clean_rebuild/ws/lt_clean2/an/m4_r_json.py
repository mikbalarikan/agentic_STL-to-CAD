"""M4: assemble joint.json from stations (scan), tilt fits and zone runs."""
import sys, os, json, pickle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
from scipy.ndimage import median_filter
from m4_x import NAMES, T
W4 = os.path.join(lib.W, "m4")
C = pickle.load(open(os.path.join(W4, "cmp.pkl"), "rb")); tilt = json.load(open(os.path.join(W4, "tilt.json")))
patches = json.load(open(os.path.join(W4, "patches.json")))
def g(src, ch, k): return np.array([r.get(k, np.nan) for r in C[src] if r["chain"] == ch], float)
def st(a):
    a = a[np.isfinite(a)]
    return None if len(a) < 3 else dict(median=round(float(np.median(a)), 3), p10=round(float(np.percentile(a, 10)), 3), p90=round(float(np.percentile(a, 90)), 3), n=int(len(a)))
def runs(m, minlen=3):
    out = []; i = 0
    while i < len(m):
        if m[i]:
            j = i
            while j + 1 < len(m) and m[j + 1]: j += 1
            if j - i + 1 >= minlen: out.append((i, j))
            i = j + 1
        else: i += 1
    return out
J = {"frame": "assembly frame (as COMMON.md); scans = lib.load(scan, 1500000)", "levels": {}, "chains": {}, "zones": {}, "notes": []}
# ---- levels: per-vertex median of patch families + tilt model + station medians
allrows = {k: [] for k in ("rim", "tongue_top", "lip", "rebate_floor")}
for ch in NAMES:
    for k in allrows: allrows[k].append(g("scan", ch, k)[np.isfinite(g("scan", ch, k))])
lv = {}
for k, v in allrows.items():
    a = np.concatenate(v); lv[k] = dict(station_median=round(float(np.median(a)), 3), p5=round(float(np.percentile(a, 5)), 3), p95=round(float(np.percentile(a, 95)), 3), n=int(len(a)))
J["levels"]["station_medians"] = lv
J["levels"]["tilt_fit_out_scan"] = tilt["out_scan"]; J["levels"]["tilt_fit_inn_scan"] = tilt["inn_scan"]
# patch table
J["levels"]["patches"] = patches
# area-weighted plane level per family from patches
def aw(scan, lo, hi, sgn):
    rows = [r for r in patches[scan] if r["sgn"] == sgn and lo < r["z"] < hi]
    A = np.array([r["area"] for r in rows]); Z = np.array([r["z"] for r in rows])
    return dict(area_weighted=round(float((A * Z).sum() / A.sum()), 3), min=round(float(Z.min()), 3), max=round(float(Z.max()), 3), n_patches=len(rows), tilt_max_deg=round(float(max(r["tilt"] for r in rows)), 2))
J["levels"]["plane_fits"] = {
    "out_rim": aw("out_scan", 34.4, 35.3, 1), "out_tongue_top": aw("out_scan", 35.7, 36.5, 1), "out_boss_face": aw("out_scan", 38.8, 39.4, 1),
    "inn_lip": aw("inn_scan", 35.1, 35.6, -1), "inn_rebate_floor": aw("inn_scan", 35.8, 36.4, -1), "inn_boss_face": aw("inn_scan", 38.8, 39.4, -1)}
# ---- widths per chain
for ch in NAMES:
    ow = g("scan", ch, "o_tout") - g("scan", ch, "o_tin"); iw = g("scan", ch, "i_tout") - g("scan", ch, "i_tin")
    sh = g("scan", ch, "shoulder"); lw = g("scan", ch, "lip_w")
    okO = (ow > 1.7) & (ow < 3.5); okI = (iw > 1.7) & (iw < 3.5)
    tw = np.where(okO, ow - sh, np.nan); rw = np.where(okI, iw - lw, np.nan)
    # tongue inside-edge offset from the wall inside face: first t with Ho>35.5 versus o_tin  (from stations.npz)
    Dd = np.load(os.path.join(W4, "stations.npz")); Ho = Dd[ch + "__Ho"]; tin = g("scan", ch, "o_tin")
    off = np.full(len(tin), np.nan)
    for i in range(len(tin)):
        hi = np.where((Ho[i] > 35.5) & (Ho[i] < 36.8) & (T > tin[i] - 0.6) & (T < tin[i] + 3))[0] if np.isfinite(tin[i]) else []
        if len(hi) >= 3 and okO[i]: off[i] = T[hi[0]] - tin[i]
    istep = g("scan", ch, "i_tin") - g("scan", ch, "o_tin")
    J["chains"][ch] = dict(length=float(g("scan", ch, "s")[-1]), wall_outer_z34p3=st(np.where(okO, ow, np.nan)), wall_inner_z36p6=st(np.where(okI, iw, np.nan)),
                           tongue_width=st(tw), shoulder_outer=st(np.where(okO, sh, np.nan)), tongue_inside_edge_offset_from_wall_face=st(off),
                           rebate_width=st(rw), lip_width_inner=st(np.where(okI, lw, np.nan)), interior_face_step_inner_minus_outer=st(np.where(okO & okI, istep, np.nan)),
                           exterior_step_inner_proud=st(g("scan", ch, "step")), outer_ext_edge_drift_z34p0_to_34p6=st(g("scan", ch, "o_edge")), inner_ext_edge_drift_z36p4_to_35p5=st(g("scan", ch, "i_edge")),
                           rim=st(g("scan", ch, "rim")), lip=st(g("scan", ch, "lip")), tongue_top=st(g("scan", ch, "tongue_top")), rebate_floor=st(g("scan", ch, "rebate_floor")))
# ---- zone runs
for ch in NAMES:
    s = g("scan", ch, "s"); x = g("scan", ch, "x"); y = g("scan", ch, "y")
    tg = np.array([bool(r.get("tongue", False)) for r in C["scan"] if r["chain"] == ch]); rb = np.array([bool(r.get("rebate", False)) for r in C["scan"] if r["chain"] == ch])
    tg5 = np.array([bool(r.get("tongue", False)) for r in C["p5"] if r["chain"] == ch])
    ow = median_filter(np.nan_to_num(g("scan", ch, "o_tout") - g("scan", ch, "o_tin"), nan=0.0), 7)
    zz = {}
    for nm, m in (("tongue_outer", tg), ("rebate_inner", rb), ("tongue_part5", tg5), ("wall_thin_lt2p6_outer", (ow > 1.5) & (ow < 2.6))):
        zz[nm] = [dict(s0=float(s[i]), s1=float(s[j]), x0=round(float(x[i]), 1), y0=round(float(y[i]), 1), x1=round(float(x[j]), 1), y1=round(float(y[j]), 1), y_range=[round(float(min(y[i:j + 1])), 1), round(float(max(y[i:j + 1])), 1)]) for i, j in runs(m)]
    J["zones"][ch] = zz
json.dump(J, open(os.path.join(W4, "joint.json"), "w"), indent=1, default=lambda o: float(o) if isinstance(o, (np.floating, np.integer)) else str(o))
for ch in NAMES:
    c = J["chains"][ch]
    print(ch, {k: (v["median"] if isinstance(v, dict) else v) for k, v in c.items() if k != "length"})
    for nm, v in J["zones"][ch].items(): print("    ", nm, [(round(r["s0"]), round(r["s1"]), r["y_range"]) for r in v])
print(json.dumps(J["levels"]["station_medians"]), json.dumps(J["levels"]["plane_fits"]))
