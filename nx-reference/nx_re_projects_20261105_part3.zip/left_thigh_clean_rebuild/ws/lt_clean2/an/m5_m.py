import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
for scan,key,sg in (("out_scan","out",-1),("inn_scan","inn",1)):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    t=np.load(os.path.join(lib.W,"m5",f"{key}_thick.npy")); dot=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["dot"]
    th=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))*sg
    base=(dot<0)&(t>1.5)&(t<3.6)&(c[:,0]>40)&(th>5)&(th<25)
    for y0 in list(np.arange(44,70,2.0))+list(np.arange(250,290,2.0)):
        m=base&(c[:,1]>=y0)&(c[:,1]<y0+2)
        if m.sum()>10: print(key,int(y0),"n",m.sum(),"thin frac",round((t[m]<2.5).mean(),2),"med t",round(np.median(t[m]),2))
