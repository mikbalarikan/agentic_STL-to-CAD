import sys, os, numpy as np, json
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, trimesh, open3d as o3d, scipy.spatial as sp
env = trimesh.load(os.path.join(lib.W,"env_part5.stl"), process=False)
esc = o3d.t.geometry.RaycastingScene(); esc.add_triangles(o3d.core.Tensor(np.asarray(env.vertices,np.float32)), o3d.core.Tensor(np.asarray(env.faces,np.uint32)))
AN = [(54.5,28),(62,31),(70,35),(80,37.8),(94,39.7),(110,40.5),(126,40.2),(150,38.2),(178,34.8),(210,30.8),(230,28),(246,24.5),(254,21),(259,15)]
Y0,Y1=54.5,259.0
ay=np.array([a for a,b in AN]); at=np.array([b for a,b in AN])
def tb(y): return np.interp(y,ay,at)
def run(key,scan,devnew,tthin,stepN=True,tag=""):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f); w=ar/ar.sum()
    sg=-1 if key=="out" else 1
    A=np.load(os.path.join(lib.W,f"dev_{devnew}.npz")); pts=np.load(os.path.join(lib.W,"m5",f"{key}_p5pts.npz"))["pts"].copy()
    r=esc.compute_closest_points(o3d.core.Tensor(pts.astype(np.float32))); cp=r["points"].numpy(); depth=np.linalg.norm(cp-pts,axis=1)
    th=np.degrees(np.arctan2(pts[:,2]-35.18,pts[:,0]-37.97))*sg
    inreg=(pts[:,0]>40)&(pts[:,1]>Y0)&(pts[:,1]<Y1)&(th>0.3)&(th<tb(pts[:,1]))
    inner=(depth>2.6)&(depth<3.7)
    # inner-face samples: only those whose env-normal faces inward: use point lying inside; ok by depth
    mv=inreg&inner
    print(key,"moved samples",mv.sum(),"depth med before",np.median(depth[mv]))
    newp=pts.copy()
    u=(cp[mv]-pts[mv]); un=u/np.maximum(np.linalg.norm(u,axis=1,keepdims=True),1e-9)
    newp[mv]=cp[mv]-un*tthin
    # step walls at boundary: sample points between depth tthin and 3.1 along boundary curve
    extra=[]
    if stepN:
        ys=np.arange(Y0,Y1,0.1); 
        for y in ys:
            ang=np.radians(tb(y)*sg)
            # point on env along ray from hip axis at angle -> closest env via ray cast outward from hip axis
            o=np.array([37.97,y,35.18]); d=np.array([np.cos(ang),0,np.sin(ang)])
            rr=esc.cast_rays(o3d.core.Tensor(np.hstack([o,d])[None].astype(np.float32)))
            th_=rr["t_hit"].numpy()[0]
            if not np.isfinite(th_): continue
            p=o+d*th_; n=-d  # inward approx
            for dd in np.arange(tthin,3.2,0.1): extra.append(p-d*dd)
        # end walls y=Y0,Y1: sample across theta
        for yy in (Y0,Y1):
            for t_ in np.arange(0.5,tb(yy),0.15):
                ang=np.radians(t_*sg); o=np.array([37.97,yy,35.18]); d=np.array([np.cos(ang),0,np.sin(ang)])
                rr=esc.cast_rays(o3d.core.Tensor(np.hstack([o,d])[None].astype(np.float32))); h=rr["t_hit"].numpy()[0]
                if not np.isfinite(h): continue
                p=o+d*h
                for dd in np.arange(tthin,3.2,0.1): extra.append(p-d*dd)
        extra=np.array(extra)
        newp=np.vstack([newp,extra])
    # distances
    tr0=sp.cKDTree(pts); tr1=sp.cKDTree(newp)
    d0,_=tr0.query(c,workers=-1); d1,_=tr1.query(c,workers=-1)
    band=np.zeros(len(c),bool); band[np.load(os.path.join(lib.W,"masks",f"{key}_band.npy"))]=1
    # region in scan
    ths=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))*sg
    sreg=(c[:,0]>40)&(c[:,1]>Y0-3)&(c[:,1]<Y1+3)&(ths>-3)&(ths<tb(c[:,1])+3)
    def pc(m,d): return w[m&(d<0.5)].sum()/w[m].sum()*100
    old=np.load(os.path.join(lib.W,"dev_oldC.npz" if key=="out" else "dev_oldInnB.npz"))["d1"]
    res=dict(band_old=pc(band,old),band_p5_stored=pc(band,A["d1"]),band_p5_proxy=pc(band,d0),band_new=pc(band,d1),
             total_p5_proxy=w[d0<0.5].sum()*100,total_new=w[d1<0.5].sum()*100,total_old=w[old<0.5].sum()*100,
             region_p5=pc(sreg,d0),region_new=pc(sreg,d1),region_old=pc(sreg,old),
             nonband_changed=float(w[(~band)&(d0<0.5)].sum()*100-w[(~band)&(d1<0.5)].sum()*100))
    print(key,tag,{k:round(v,2) for k,v in res.items()})
    return res,d1,band,c,w
if __name__=="__main__":
    R={}
    for key,scan,dn,tt in (("out","out_scan","FINout",1.9),("inn","inn_scan","FINinn",2.0)):
        for tt2 in (tt,):
            R[key]=run(key,scan,dn,tt2,True,f"t={tt2}")[0]
    json.dump(R,open(os.path.join(lib.W,"m5","test1.json"),"w"),indent=1)
