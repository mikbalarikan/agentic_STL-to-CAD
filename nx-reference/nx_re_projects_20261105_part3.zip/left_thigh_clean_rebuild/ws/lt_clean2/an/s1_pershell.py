import sys
from s1_eval import *
res={}
for nm,path in [('v1','work/s1/env_v1.stl,work/s1/tail_sheet_v1.stl'),('part5','work/env_part5.stl')]:
    out,dd=run(path,verbose=False)
    for z in ['drum','body_all (excl band,foot)','hip (excl band)','knee_fair(-38<Y<30)']:
        for k,s in enumerate(['outer','inner']):
            mk=zones[z]&(sid==k); res[(nm,z,s)]=stats(dd[mk],A[mk])
    # also G-ext per shell
    near=dd<1.0
    for k,s in enumerate(['outer','inner']):
        mk=near&~band&(sid==k); res[(nm,'G-ext',s)]=stats(dd[mk],A[mk])
for z in ['drum','knee_fair(-38<Y<30)','body_all (excl band,foot)','hip (excl band)','G-ext']:
    print(f'{z:30s}', ' | '.join(f"{nm} {s}: {res[(nm,z,s)]['pct']:.1f}% p90 {res[(nm,z,s)]['p90']:.3f}" for nm in ['v1','part5'] for s in ['outer','inner']))
