import sys
from s1_shell import *
from s1_build import build
from s1_geo import *
from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
tag=sys.argv[1]
env,lo,body,dr=build(tag,verbose=False)
u=ShapeUpgrade_UnifySameDomain(env,True,True,True); u.Build(); env2=u.Shape()
print('faces before',len(faces(env)),'after',len(faces(env2)),'valid',valid(env2),round(volume(env2)))
def test(shape,name,mf,t=3.1,jn=GeomAbs_Arc):
    lst=TopTools_ListOfShape(); lst.Append(mf); mk=BRepOffsetAPI_MakeThickSolid(); t0=time.time()
    try:
        mk.MakeThickSolidByJoin(shape,lst,-t,1e-3,BRepOffset_Skin,True,False,jn); mk.Build()
    except Exception as e: print(name,'EXC',str(e)[:80]); return
    s=mk.Shape() if mk.IsDone() else None
    print(name,t,'done',mk.IsDone(),'valid',valid(s) if s else None,'vol',round(volume(s)) if s else None,'orig',round(volume(shape)),round(time.time()-t0,1),flush=True)
test(env2,'unified env',mouth_face(env2))
test(env2,'unified env t=1.0',mouth_face(env2),1.0)
