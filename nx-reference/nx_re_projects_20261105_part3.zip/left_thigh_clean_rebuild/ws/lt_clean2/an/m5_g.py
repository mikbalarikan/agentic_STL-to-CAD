import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, open3d as o3d
for scan,key in (("out_scan","out"),("inn_scan","inn")):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    sc=o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(v.astype(np.float32)),o3d.core.Tensor(f.astype(np.uint32)))
    z=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz")); dot=z["dot"]; d=z["d"]
    # wall thickness: ray from centre along -n (into material from an interior face)
    o=c-nn*0.02; dirs=-nn
    r=sc.cast_rays(o3d.core.Tensor(np.hstack([o,dirs]).astype(np.float32)))
    t=r["t_hit"].numpy(); 
    t[~np.isfinite(t)]=-1
    np.save(os.path.join(lib.W,"m5",f"{key}_thick.npy"),t)
    intf=dot<0
    ok=intf&(t>0)&(t<8)
    print(scan,"int-facing with thickness",ok.sum())
    band=np.zeros(len(c),bool); band[np.load(os.path.join(lib.W,"masks",f"{key}_band.npy"))]=1
    for nm,m in (("band int",band&ok),("nonband int, x>60",(~band)&ok&(c[:,0]>60)),("nonband int x<60",(~band)&ok&(c[:,0]<60))):
        print(" ",nm,m.sum(),"thick pct 10/50/90",np.round(np.percentile(t[m],[10,50,90]),2),"env depth med",np.round(np.median(d[m]),2))
