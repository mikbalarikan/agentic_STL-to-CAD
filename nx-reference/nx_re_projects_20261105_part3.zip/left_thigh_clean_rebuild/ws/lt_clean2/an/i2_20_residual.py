from i2_rows import *
import glob, json
from scipy import ndimage as ndi
rows = []
for f_ in sorted(glob.glob(os.path.join(ROWS, "*.json"))): rows += json.load(open(f_))
cov = np.zeros(N, bool)
for r in rows:
    idx = np.load(os.path.join(MASKS, f"inn_f_{r['id']}.npy")); cov[idx] = True
print("rows", len(rows), "covered tris", cov.sum())
deep = d >= 2.4
bad = deep & (p5 >= 0.5)
print("deep & bad (p5>=0.5) area % of total:", w_area[bad].sum() * 100, " covered by features:", w_area[bad & cov].sum() * 100, " uncovered:", w_area[bad & ~cov].sum() * 100)
print("deep area covered %", w_area[deep & cov].sum() * 100, " deep area total", w_area[deep].sum() * 100)
# lost vs old (old good, p5 bad)
lost = deep & (old < 0.5) & (p5 >= 0.5)
print("lost deep (old ok, p5 bad) total %", w_area[lost].sum() * 100, "covered", w_area[lost & cov].sum() * 100, "uncovered", w_area[lost & ~cov].sum() * 100)
# cluster the uncovered bad tris in plan: raster 1 mm
s = 2.0; x0, y0 = -75, -75
un = bad & ~cov
H, Wd = int(380 * s), int(200 * s)
im = np.zeros((H, Wd))
X = ((c[un, 0] - x0) * s).astype(int); Y = ((c[un, 1] - y0) * s).astype(int)
np.add.at(im, (Y, X), w_area[un] * 100)
bw = ndi.binary_closing(im > 0, iterations=2); lab, nl = ndi.label(ndi.binary_dilation(bw, iterations=2))
print("clusters", nl)
out = []
for k in range(1, nl + 1):
    sel = np.zeros(N, bool); ii = lab[Y, X] == k; sel[np.flatnonzero(un)[ii]] = True
    if w_area[sel].sum() * 100 < 0.04: continue
    out.append((w_area[sel].sum() * 100, k, sel))
out.sort(key=lambda t: -t[0])
for A, k, sel in out[:40]:
    cc = c[sel]; print(f"cluster {k:3d} area {A:.3f}%  x {cc[:,0].min():.0f}..{cc[:,0].max():.0f} y {cc[:,1].min():.0f}..{cc[:,1].max():.0f} z {np.percentile(cc[:,2],5):.0f}..{np.percentile(cc[:,2],95):.0f} p5p90 {p90(p5[sel]):.2f} oldp90 {p90(old[sel]):.2f} de med {np.median(d[sel]):.1f}")
np.save(os.path.join(O, "uncovered_bad.npy"), np.flatnonzero(un))
