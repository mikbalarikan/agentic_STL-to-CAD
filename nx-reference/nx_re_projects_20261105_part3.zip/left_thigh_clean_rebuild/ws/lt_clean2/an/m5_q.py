import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, trimesh, open3d as o3d
env = trimesh.load(os.path.join(lib.W,"env_part5.stl"), process=False)
esc = o3d.t.geometry.RaycastingScene(); esc.add_triangles(o3d.core.Tensor(np.asarray(env.vertices,np.float32)), o3d.core.Tensor(np.asarray(env.faces,np.uint32)))
for cad,key,sg in (("out_cad","out",-1),("inn_cad","inn",1)):
    v,f=lib.load(cad); c,nn,ar=lib.tri_data(v,f)
    sc=o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(v.astype(np.float32)),o3d.core.Tensor(f.astype(np.uint32)))
    r=esc.compute_closest_points(o3d.core.Tensor(c.astype(np.float32))); cp=r["points"].numpy(); pid=r["primitive_ids"].numpy()
    en=np.asarray(env.face_normals)[pid]; dot=(nn*en).sum(1)
    o=c-nn*0.02; rr=sc.cast_rays(o3d.core.Tensor(np.hstack([o,-nn]).astype(np.float32))); t=rr["t_hit"].numpy(); t[~np.isfinite(t)]=-1
    th=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))*sg
    print(key,"tris",len(f),"area",ar.sum())
    m=(dot<0)&(t>0)&(t<8)&(c[:,0]>40)&(c[:,1]>56)&(c[:,1]<258)
    for lo,hi in ((0,5),(5,10),(10,20),(20,30),(30,36),(36,40),(40,46)):
        k=m&(th>=lo)&(th<hi); 
        if k.sum()>5: print(f"  th {lo}-{hi} n{k.sum()} area{ar[k].sum():.0f} thick p25/50/75",np.round(np.percentile(t[k],[25,50,75]),2))
    tri_n=len(f); print("  tris in thin region",((th>2)&(th<28)&(c[:,0]>40)&(c[:,1]>60)&(c[:,1]<250)&(dot<0)).sum(),"(mesh facet count: old master is planar-faceted STL)")
