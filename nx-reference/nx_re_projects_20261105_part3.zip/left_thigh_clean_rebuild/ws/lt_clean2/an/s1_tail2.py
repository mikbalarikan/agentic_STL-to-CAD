from s1_eval import *
m=zones['knee_tail(Y<-34)']|(none&(y<-30)&(y>=-34)&(z<84.2)&~foot)
Q=P[m]
ys=np.arange(-50.5,-31,1.0); xs=[]
for y0 in ys:
    q=Q[np.abs(Q[:,1]-y0)<0.5]
    xs.append(np.percentile(q[:,0],99.5) if len(q)>20 else np.nan)
xs=np.array(xs); print(np.c_[ys,xs].round(2))
ok=np.isfinite(xs)&(ys<-36); c=np.polyfit(ys[ok],xs[ok],1); print('x=%.4f*y+%.3f'%tuple(c), 'angle to Y axis deg',np.degrees(np.arctan(c[0])))
print('res',np.round(xs[ok]-np.polyval(c,ys[ok]),2))
