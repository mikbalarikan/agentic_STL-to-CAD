"""P5d root radius measurement per concave CAD edge: ray along the bisector from the void into the corner, scan hit vs CAD hit.
t = d_cad - d_scan (material the scan has in the corner that the sharp CAD lacks); R = t / (1/sin(a/2) - 1), a = interior angle.
argv: which(out|inn). Writes work/p5d/rootmeas_<which>.json + prints per name-pair table."""
import sys, os, json, collections
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, trimesh
import open3d as o3d
which = sys.argv[1]
cadp = sys.argv[2] if len(sys.argv) > 2 else rf"C:\NX_MCP_WORKSPACE\lt_clean2\nx\P5c\{which}_P5c.stl"
data = json.load(open(rf"C:\NX_MCP_WORKSPACE\lt_clean2\nx\P5d\probe\{which}_edges.json"))
v, f = lib.load(which + "_scan", 1500000)
def sc(vv, ff):
    s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(np.asarray(vv, np.float32)), o3d.core.Tensor(np.asarray(ff, np.uint32))); return s
S = sc(v, f)
m = trimesh.load(cadp, process=False); C = sc(m.vertices, m.faces)
rows = []
for r in data["rows"]:
    for s in r["smp"]:
        d1, d2 = np.array(s["d1"]), np.array(s["d2"])
        b = d1 + d2; nb = np.linalg.norm(b)
        if nb < 0.05: continue
        b /= nb
        cosa = float(np.clip(d1 @ d2, -1, 1)); a = np.arccos(cosa)
        p = np.array(s["p"])
        rows.append((r["tag"], p, b, a))
P = np.array([x[1] for x in rows]); B = np.array([x[2] for x in rows]); A = np.array([x[3] for x in rows])
HS = 6.0
res = {}
def hit(Sc, org):
    rays = np.hstack([org, -B]).astype(np.float32)
    return Sc.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
org = P + HS * B
hs = hit(S, org); hc = hit(C, org)
t = hc - hs
k = 1 / np.sin(A / 2) - 1
R = t / np.maximum(k, 1e-3)
out = collections.defaultdict(list)
tagpos = {}
for (tag, p, b, a), tt, rr, h1, h2 in zip(rows, t, R, hs, hc):
    out[tag].append((float(tt), float(rr), float(h1), float(h2), float(np.degrees(a))))
rowsj = {r["tag"]: r for r in data["rows"]}
final = []
for tag, L in out.items():
    L = np.array(L)
    ok = np.isfinite(L[:, 0]) & (np.abs(L[:, 2] - HS) < HS) & (np.abs(L[:, 3] - HS) < 1.0) | (np.isfinite(L[:,0]) & (np.abs(L[:,3]-HS) < 1.0))
    ok &= np.isfinite(L[:, 0]) & (L[:, 3] < 1e3) & (L[:, 2] < 1e3)
    if ok.sum() == 0: continue
    rr = L[ok, 1]
    final.append({"tag": tag, "n": rowsj[tag]["n"], "L": rowsj[tag]["L"], "bb": rowsj[tag]["bb"], "R_med": float(np.median(rr)),
                  "R_all": [round(float(x), 2) for x in L[:, 1]], "t_med": float(np.median(L[ok, 0])), "ang": float(np.median(L[:, 4])), "nok": int(ok.sum())})
json.dump(final, open(rf"C:\NX_MCP_WORKSPACE\lt_clean2\work\p5d\rootmeas_{which}.json", "w"))
g = collections.defaultdict(list)
for r in final:
    g[tuple(sorted(x.split("_Z")[0] for x in r["n"]))].append(r)
print("pair  nedges  Ltot  R_med(median of edge medians) q25 q75 | tmed")
for k, L in sorted(g.items(), key=lambda kv: -sum(x["L"] for x in kv[1])):
    Rm = np.array([x["R_med"] for x in L]); Tm = np.array([x["t_med"] for x in L])
    print(k, len(L), round(sum(x["L"] for x in L), 1), round(float(np.median(Rm)), 2), round(float(np.percentile(Rm, 25)), 2), round(float(np.percentile(Rm, 75)), 2), "|", round(float(np.median(Tm)), 2))
