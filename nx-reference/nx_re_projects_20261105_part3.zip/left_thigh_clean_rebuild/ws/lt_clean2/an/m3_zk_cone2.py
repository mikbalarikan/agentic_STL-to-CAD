import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.optimize import least_squares
HX,HZ=37.97,35.18; YM=287.39
D=np.load("work/m3/ext_pts.npz"); P=D['P']; r=D['r']; th=D['th']
def cone_sd(p,X):
    x0,z0,tx,tz,R0,t=p
    d=np.array([tx,1.0,tz]); d/=np.linalg.norm(d)
    q=X-np.array([x0,YM,z0]); s=q@d; perp=q-np.outer(s,d); rho=np.linalg.norm(perp,axis=1)
    return (rho-(R0-t*s))*np.cos(np.arctan(t))   # >0 : outside the cone
def fit(mask,p0=[HX,HZ,0,0,70.9,0.46]):
    X=P[mask]; s=least_squares(cone_sd,p0,args=(X,)).x; e=cone_sd(s,X); return s,e
out={}
for nm,m in (('lateral both',((abs(th)<18)|(abs(th)>135))),('+X |th|<18',abs(th)<18),('-X |th|>135',abs(th)>135),('upper-lateral +X(th 115..170)',(th>115)&(th<170)),('lower -X',(th<-115)&(th>-170))):
    mm=m&(P[:,1]>270)&(P[:,1]<287.0)
    s,e=fit(mm)
    print('%-32s n=%6d x0=%.2f z0=%.2f tilt(tx,tz)=(%.4f,%.4f) R0=%.3f t=%.4f ang=%.2f  res std %.3f p95 %.3f'%(nm,mm.sum(),*s,np.degrees(np.arctan(s[5])),e.std(),np.percentile(abs(e),95)))
    out[nm]=list(map(float,s))
s,_=fit((abs(th)<18)|(abs(th)>135)&(P[:,1]>270)); 
mm=((abs(th)<18)|(abs(th)>135))&(P[:,1]>270)&(P[:,1]<287); s,_=fit(mm)
sd=cone_sd(s,P)
print('signed dist to lateral cone, all exterior pts: Y>=266: frac within +-0.5 : %.1f%% ; frac inside (<-0.5) %.1f%%, outside (>+0.5) %.1f%%'%tuple(100*np.array([ (abs(sd[P[:,1]>=266])<.5).mean(), (sd[P[:,1]>=266]<-.5).mean(), (sd[P[:,1]>=266]>.5).mean()])))
fig,ax=plt.subplots(1,1,figsize=(16,8)); k=slice(None,None,8)
sc=ax.scatter(P[k,1],th[k],c=sd[k],s=2,cmap='bwr',vmin=-6,vmax=6); plt.colorbar(sc); ax.set_xlim(240,288); ax.set_title('signed distance of exterior to fitted lateral cone (blue: scan inside cone)'); plt.savefig('work/m3/cone_map.png',dpi=50)
json.dump(dict(fits=out,lateral=list(map(float,s))),open('work/m3/cone_fit.json','w'),indent=1)
