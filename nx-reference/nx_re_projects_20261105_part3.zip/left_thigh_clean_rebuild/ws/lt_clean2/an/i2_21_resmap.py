from i2_rows import *
import glob, json
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
rows = []
for f_ in sorted(glob.glob(os.path.join(ROWS, "*.json"))): rows += json.load(open(f_))
cov = np.zeros(N, bool)
for r in rows: cov[np.load(os.path.join(MASKS, f"inn_f_{r['id']}.npy"))] = True
un = np.load(os.path.join(O, "uncovered_bad.npy")); U = np.zeros(N, bool); U[un] = True
fig, axs = plt.subplots(1, 2, figsize=(22, 17))
for ax, ttl, col in ((axs[0], "uncovered bad deep (colour = scan z)", c[:, 2]), (axs[1], "uncovered bad deep (colour = p5 dev)", np.minimum(p5, 3))):
    deep = d >= 2.4
    ax.scatter(c[deep & ~U, 0], c[deep & ~U, 1], s=0.05, c='#dddddd', rasterized=True)
    sc = ax.scatter(c[U, 0], c[U, 1], s=0.3, c=col[U], cmap='turbo', vmin=(36 if col is c[:, 2] else 0), vmax=(105 if col is c[:, 2] else 3), rasterized=True)
    ax.set_aspect('equal'); ax.set_title(ttl); plt.colorbar(sc, ax=ax, shrink=0.5)
plt.tight_layout(); plt.savefig(os.path.join(O, "uncovered.png"), dpi=60)
