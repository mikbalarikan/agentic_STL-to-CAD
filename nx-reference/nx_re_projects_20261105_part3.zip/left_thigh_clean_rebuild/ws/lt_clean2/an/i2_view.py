from i2_common import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import ndimage as ndi
v,f,c,n,a = scan(); d = de(); p5, old = dev()
def raster(x0,x1,y0,y1,s,val,mask,mode='min',fill=2):
    mm = mask&(c[:,0]>=x0)&(c[:,0]<x1)&(c[:,1]>=y0)&(c[:,1]<y1)
    X=((c[mm,0]-x0)*s).astype(int); Y=((c[mm,1]-y0)*s).astype(int)
    H=int((y1-y0)*s)+1; Wd=int((x1-x0)*s)+1
    im=np.full((H,Wd),np.nan); o=np.argsort(-val[mm]) if mode=='min' else np.argsort(val[mm]); im[Y[o],X[o]]=val[mm][o]
    nanm=np.isnan(im)
    if nanm.any() and fill>0:
        dist,idx=ndi.distance_transform_edt(nanm,return_indices=True)
        im=im[tuple(idx)]; im[dist>fill]=np.nan
    return im
def show(name,x0,x1,y0,y1,s,kind='z',zr=(70,92),mask=None,mode=None,overlay=None,dpi=80,size=14):
    if mask is None: mask=d>=1.5
    if kind=='z': val=c[:,2]; mode=mode or 'min'; vr=zr
    elif kind=='dev5': val=np.minimum(p5,2); mode=mode or 'max'; vr=(0,1.5)
    elif kind=='dev0': val=np.minimum(old,2); mode=mode or 'max'; vr=(0,1.5)
    im=raster(x0,x1,y0,y1,s,val,mask,mode)
    fig,ax=plt.subplots(figsize=(size,size*(y1-y0)/(x1-x0)))
    ax.imshow(im,origin='lower',extent=[x0,x1,y0,y1],cmap='turbo',vmin=vr[0],vmax=vr[1]); ax.set_aspect('equal')
    if overlay: overlay(ax)
    ax.set_xlim(x0,x1); ax.set_ylim(y0,y1); ax.grid(alpha=.25); ax.set_title(name)
    plt.tight_layout(); plt.savefig(os.path.join(O,name+".png"),dpi=dpi); plt.close()
if __name__=="__main__":
    show("v_knee_c",-50,50,-50,60,10,'z',(72,92))
