import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
def circ(x,y,r0):
    s=least_squares(lambda p: np.hypot(x-p[0],y-p[1])-p[2],[0,0,r0],loss="soft_l1",f_scale=.1); return s.x, np.abs(s.fun).mean()
v,f=lib.load("inn_scan",1500000); c,nn,ar=lib.tri_data(v,f); r=np.hypot(c[:,0],c[:,1]); z=c[:,2]
# hole in top disc: vertical wall triangles near r~25.5 at z 80..83.5 (normals radial inward->outward of hole)
m=(abs(nn[:,2])<0.2)&(r>23)&(r<28)&(z>81)&(z<83.6)
print('inner top disc central hole',len(c[m]),circ(c[m,0],c[m,1],25.5))
m=(abs(nn[:,2])<0.2)&(r>60)&(r<65.5)&(z>70)&(z<80)&(nn[:,0]*c[:,0]+nn[:,1]*c[:,1]<0)
print('inner inside wall (bore of drum)', circ(c[m,0],c[m,1],64.)[0], 'n',m.sum(), 'ang filter none')
ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
m=(abs(nn[:,2])<0.2)&(r>60)&(r<65.5)&(z>64)&(z<79)&((nn[:,0]*c[:,0]+nn[:,1]*c[:,1])<0)&(ang>-130)&(ang<45)
print('inner drum inside wall',circ(c[m,0],c[m,1],64.),len(c[m]), 'rho med',np.median(r[m]))
v,f=lib.load("out_scan",1500000); c,nn,ar=lib.tri_data(v,f); r=np.hypot(c[:,0],c[:,1]); z=c[:,2]; ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
m=(abs(nn[:,2])<0.2)&(r>60)&(r<65.5)&(z>-13)&(z<-1)&((nn[:,0]*c[:,0]+nn[:,1]*c[:,1])<0)&(ang>-130)&(ang<45)
print('outer drum inside wall',circ(c[m,0],c[m,1],63.),len(c[m]))
m=(abs(nn[:,2])<0.2)&(r>44)&(r<48)&(z>-9)&(z<-7)
print('outer floor inner edge r~46',circ(c[m,0],c[m,1],46.),m.sum())
# top-disc ring/hole outside edges etc
