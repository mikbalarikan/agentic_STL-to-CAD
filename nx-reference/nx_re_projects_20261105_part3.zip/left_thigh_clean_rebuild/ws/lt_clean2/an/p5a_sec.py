"""plan section (z = const) of scan vs CAD stl: argv which z x0 x1 y0 y1 out.png cad.stl [cad2.stl]"""
import sys, numpy as np, trimesh, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,'an')
import lib
which, z, x0, x1, y0, y1, out = sys.argv[1:8]; z=float(z); x0,x1,y0,y1=map(float,(x0,x1,y0,y1))
cads=sys.argv[8:]
v,f=lib.load({'out':'out_scan','inn':'inn_scan'}[which],1500000)
fig,ax=plt.subplots(figsize=(11,11*(y1-y0)/(x1-x0)))
def draw(m,col,lw,lab):
    s=m.section(plane_origin=[0,0,z],plane_normal=[0,0,1])
    if s is None: return
    first=True
    for e in s.entities:
        p=s.vertices[e.points]
        ax.plot(p[:,0],p[:,1],col,lw=lw,label=lab if first else None); first=False
draw(trimesh.Trimesh(v,f,process=False),'k-',0.6,'scan')
cols=['r-','b-','g-']
for i,c in enumerate(cads):
    draw(trimesh.load(c,process=False),cols[i],0.9,c.split('/')[-1])
ax.set_xlim(x0,x1); ax.set_ylim(y0,y1); ax.set_aspect('equal'); ax.grid(alpha=.3); ax.legend(); ax.set_title('z=%g'%z)
fig.savefig(out,dpi=90,bbox_inches='tight')
