from i1_common import *
S = load_all()
for nm,xl,yl in (("A",(-70,125),(190,290)),("B",(40,125),(85,215)),("C",(-70,125),(-70,95)),("D",(-70,100),(60,200))):
    plot_win(S,xl,yl,os.path.join(I1,f"zoom_{nm}.png"))
