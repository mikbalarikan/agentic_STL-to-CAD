import sys, numpy as np, trimesh, open3d as o3d
po, pi = sys.argv[1:3]
def scn(p):
    m = trimesh.load(p, process=False); s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32))); return s
so, si = scn(po), scn(pi)
rng = np.random.default_rng(1)
lo = np.array([-85, -60, 33.0]); hi = np.array([145, 300, 46.0])
tot = 0; N = 0
for k in range(6):
    P = rng.uniform(lo, hi, (1000000, 3)).astype(np.float32)
    a = so.compute_occupancy(o3d.core.Tensor(P)).numpy() > 0.5; b = si.compute_occupancy(o3d.core.Tensor(P)).numpy() > 0.5
    c = a & b; tot += c.sum(); N += len(P)
    if k == 0: ov = P[c]
vol = np.prod(hi - lo)
print("overlap pts", tot, "of", N, "volume mm3 %.1f" % (tot / N * vol))
if tot:
    print("bbox of overlap pts (first 1e6):", ov.min(0).round(1) if len(ov) else None, ov.max(0).round(1) if len(ov) else None)
