import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
HX,HZ=37.97,35.18
for tag,sn in (('out','out_scan'),('inn','inn_scan')):
    v,f=lib.load(sn,1500000); c,nn,a=lib.tri_data(v,f)
    r=np.hypot(c[:,0]-HX,c[:,2]-HZ); th=np.degrees(np.arctan2(c[:,2]-HZ,c[:,0]-HX))
    zsel=(c[:,2]<34.5) if tag=='out' else (c[:,2]>35.9)
    print(tag,'wall (radial, ext-int) by Y, median over theta bins; int = min r > 55')
    for y in (278,280,282,284,286,287.0):
        m=(abs(c[:,1]-y)<0.5)&zsel&(r>55)
        b=np.floor(th[m]/5).astype(int); out=[]
        for u in np.unique(b):
            rr=r[m][b==u]
            if len(rr)>10: out.append((rr.max(),rr.min()))
        out=np.array(out); w=out[:,0]-out[:,1]
        print('  Y%.1f ext R %.2f  int R %.2f  radial wall median %.2f (p10 %.2f p90 %.2f) n=%d'%(y,np.median(out[:,0]),np.median(out[:,1]),np.median(w),np.percentile(w,10),np.percentile(w,90),len(out)))
