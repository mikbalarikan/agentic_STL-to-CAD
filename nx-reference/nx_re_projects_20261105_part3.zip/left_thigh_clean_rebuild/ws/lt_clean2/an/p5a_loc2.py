import sys, numpy as np
sys.path.insert(0,'an')
import lib
which, tag, mask = sys.argv[1:4]
v,f = lib.load({'out':'out_scan','inn':'inn_scan'}[which],1500000)
c,nn,ar = lib.tri_data(v,f)
d = np.load('work/dev_%s_%s.npz'%(tag,which))['d1']
m = np.load('work/masks/%s_f_%s.npy'%(which,mask))
dm=d[m]; cm=c[m]; nm=nn[m]
ang=np.degrees(np.arctan2(cm[:,1],cm[:,0]))%360; r=np.hypot(cm[:,0],cm[:,1]); z=cm[:,2]
bad=dm>0.5
print('n',len(m),'bad',bad.sum())
def hist(name,x,bins):
    h,_=np.histogram(x[bad],bins); a,_=np.histogram(x,bins)
    print(name,[ (int(b0),int(hh),int(aa)) for b0,hh,aa in zip(bins[:-1],h,a) if aa>0])
hist('ang',ang,np.arange(150,250,5))
hist('r',r,np.arange(50,75,2))
hist('z',z,np.arange(-10,40,2))
print('normals bad mean',nm[bad].mean(0).round(2))
