import sys
from s1_build import *
from s1_lib import dist_to_mesh
import m2_loft as L, trimesh
tag='H7'; d=np.load(f'work/s1/loft_{tag}.npz'); st=d['st']; P=d['P']; lf=L.Loft(st,72,P)
lo=loft(P,st); V,F=to_mesh(lo,0.01,0.03)
ys=np.arange(-36,286,1.37); uu=np.arange(0,1,1/360)
C=lf.curve(ys,uu); pts=np.stack([C[:,:,0],np.repeat(ys[:,None],len(uu),1),C[:,:,1]],-1).reshape(-1,3)
dd=dist_to_mesh(pts,V,F); print('tensor(cubic-spline-in-Y) vs OCC ThruSections: max %.3f p99 %.3f p50 %.4f'%(dd.max(),np.percentile(dd,99),np.median(dd)))
print('num solids/shells in env:')
env,lo,body,dr=build(tag,verbose=False)
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_SHELL, TopAbs_FACE
for nm,t in [('solids',TopAbs_SOLID),('shells',TopAbs_SHELL),('faces',TopAbs_FACE)]:
    ex=TopExp_Explorer(env,t); n=0
    while ex.More(): n+=1; ex.Next()
    print(nm,n)
