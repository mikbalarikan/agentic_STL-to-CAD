from i2_rows import *
import json
rows={r["id"]:r for f_ in __import__("glob").glob(os.path.join(ROWS,"*.json")) for r in json.load(open(f_))}
r=rows["ARM_B2_D"]; p0=np.array(r["params"]["p0"]); p1=np.array(r["params"]["p1"])
u,wv,nu,nw,L,e=line_frame(p0,p1); m=np.load(os.path.join(MASKS,"inn_f_ARM_B2_D.npy"))
for u0 in np.arange(-2,L+2,3):
    s=m[(u[m]>=u0)&(u[m]<u0+3)]
    if len(s)>30: print(f"u {u0:5.1f} n {len(s):5d} p5 p90 {p90(p5[s]):.2f} old {p90(old[s]):.2f} z med {np.median(c[s,2]):.1f} wv med {np.median(wv[s]):.2f}")
print("L",L)
