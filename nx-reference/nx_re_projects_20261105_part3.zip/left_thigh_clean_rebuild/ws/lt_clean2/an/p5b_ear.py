import sys, os
sys.path.insert(0,'an')
import numpy as np, lib
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import design2 as D  # nx on path
