from i1_common import *
from i1_fit import *
S=load_all(); c,n,a,de=S['c'],S['n'],S['a'],S['de']
hx,hz=37.97,35.18
rr=np.hypot(c[:,0]-hx,c[:,2]-hz)
m0=(c[:,1]>255)
print("n tris y>255:",m0.sum())
print("faces facing +-y (|ny|>0.95): y planes by r_hip bin")
for sign in (1,-1):
    print("ny sign",sign)
    for r0 in range(0,80,3):
        m=m0&(rr>=r0)&(rr<r0+3)&(sign*n[:,1]>0.95)
        if m.sum()<30: continue
        pk=peaks(c[m,1],a[m],0.1,0.07,rng=(255,290))
        print("  r %d-%d: "%(r0,r0+3)," ".join("y%.2f(%.2f)"%p for p in pk[:4]))
print("cylindrical walls about hip axis (normals radial in xz) vs y")
nr=((c[:,0]-hx)*n[:,0]+(c[:,2]-hz)*n[:,2])/np.maximum(rr,1e-6)
m=m0&(abs(n[:,1])<0.2)&(abs(nr)>0.95)
for y0 in np.arange(255,290,1.5):
    k=m&(c[:,1]>=y0)&(c[:,1]<y0+1.5)
    if k.sum()<40: continue
    pk=peaks(rr[k],a[k],0.15,0.08,rng=(0,80))
    print("  y %.1f: "%y0," ".join("r%.2f(%.2f,nr%+.0f)"%(p[0],p[1],np.sign(np.median(nr[k&(abs(rr-p[0])<.3)]))) for p in pk[:5]))
