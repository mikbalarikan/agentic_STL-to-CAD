import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.interpolate import CubicSpline
HX,HZ=37.97,35.18; YM=287.39
areas=[];Ps=[]
for tag,sn in (('out','out_scan'),('inn','inn_scan')):
    v,f=lib.load(sn,1500000); c,nn,a=lib.tri_data(v,f); m=np.load(f"work/masks/{tag}_ext_hip.npy"); Ps.append(c[m]); areas.append(a[m])
P=np.vstack(Ps); A=np.concatenate(areas)
r=np.hypot(P[:,0]-HX,P[:,2]-HZ); th=np.arctan2(P[:,2]-HZ,P[:,0]-HX)
NH=8
def basis(t,N=NH): return np.stack([np.cos(n*t) for n in range(N+1)]+[np.sin(n*t) for n in range(1,N+1)],1)
def sect(y,w=0.5):
    k=(abs(P[:,1]-y)<w)&(abs(P[:,2]-HZ)>0.0)
    B=basis(th[k]); co=np.linalg.lstsq(B,r[k],rcond=None)[0]; return co
def model(ys):
    ys=np.array(ys,float); C=np.array([sect(y if y<YM-0.2 else YM-0.5,0.5) for y in ys])
    # mouth section: circle exactly (hip axis centred)  at YM
    return CubicSpline(ys,C,axis=0,bc_type='not-a-knot')
def evalm(cs,y0=None):
    ok=P[:,1]<=YM
    co=cs(np.clip(P[:,1],cs.x[0],cs.x[-1])); rr=(basis(th)*co).sum(1)
    d=r-rr; return d
def rep(d,lo):
    k=P[:,1]>=lo
    w=A[k]; g=abs(d[k])<0.5
    return 100*(w*g).sum()/w.sum(), np.percentile(abs(d[k]),[50,90,99])
sets={'p5-like 246,264,278,287.4':[246,264,278,YM],
 '4: 258,270,280,287.4':[258,270,280,YM],
 '5: 250,260,270,279,287.4':[250,260,270,279,YM],
 '5: 262,270,276,282,287.4':[262,270,276,282,YM],
 '6: 244,252,260,268,277,287.4':[244,252,260,268,277,YM],
 '3: 266,277,287.4':[266,277,YM],
 '4: 266,272,279,287.4':[266,272,279,YM],
 '7: 240,248,256,264,272,280,287.4':[240,248,256,264,272,280,YM]}
for nme,ys in sets.items():
    cs=model(ys); d=evalm(cs)
    out=[]
    for lo in (ys[0],266,272):
        pc,pp=rep(d,lo); out.append('Y>=%g: %.1f%% p50/90/99 %s'%(lo,pc,np.round(pp,2)))
    print(nme,' | '.join(out))

import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
cs=model([240,248,256,264,272,280,YM]); d=evalm(cs)
fig,ax=plt.subplots(1,2,figsize=(24,8))
k=slice(None,None,6)
s=ax[0].scatter(P[k,1],np.degrees(th[k]),c=d[k],s=2,cmap='bwr',vmin=-1.5,vmax=1.5); plt.colorbar(s,ax=ax[0]); ax[0].set_xlim(225,290)
big=abs(d)>0.6
ax[1].plot(P[big,0],P[big,2],'r.',ms=1); ax[1].set_aspect('equal'); ax[1].set_title('|resid|>0.6 points (X,Z)')
plt.savefig("work/m3/loft7_resid.png",dpi=50)
