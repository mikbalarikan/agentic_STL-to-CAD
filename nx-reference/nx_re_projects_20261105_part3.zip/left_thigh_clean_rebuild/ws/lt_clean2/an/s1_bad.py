import sys
from s1_eval import *
import pyvista as pv; pv.OFF_SCREEN=True
tag=sys.argv[1]; dd=np.load(os.path.join(S1,f'dd_{tag}.npy'))
msk=(zones['knee_fair(-38<Y<30)']|zones['body_28-64 (excl band,foot)'])&(dd>0.6)
print(msk.sum(), 'of', (zones['knee_fair(-38<Y<30)']|zones['body_28-64 (excl band,foot)']).sum())
Q=P[msk]; C=np.minimum(dd[msk],8)
for nm,dv in [('top',(0.01,-0.2,1)),('px',(1,-0.1,0.0)),('bot',(0.01,-0.2,-1)),('mx',(-1,-0.1,0.2))]:
    p=pv.Plotter(window_size=(1200,800)); p.add_mesh(pv.PolyData(Q),scalars=C,cmap='jet',point_size=3,show_scalar_bar=True)
    dv=np.array(dv,float);dv/=np.linalg.norm(dv); fo=np.array([30,10,35.]); p.camera.focal_point=fo;p.camera.position=fo+330*dv;p.camera.up=(0,0,1) if nm in('px','mx') else (0,1,0)
    p.screenshot(os.path.join(S1,f'bad_{tag}_{nm}.png'));p.close()
