"""Wall thickness: from points on the fitted loft (theta,y grid) cast inward rays through both scans.
hit1 = exterior skin (entry, normal against ray), hit2 = interior face (exit, normal along ray). thickness = t2-t1 (along loft normal)."""
import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, m2_loft as L, m2_g_fit as G, m2_f_data as FD
import open3d as o3d
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
tag=sys.argv[1]
d=np.load(f"work/m2/loft_{tag}.npz"); lf=L.Loft(d["st"],d["P"].shape[1],d["P"])
S={n:lib.load(n,1500000) for n in ("out_scan","inn_scan")}
V=np.vstack([S[n][0] for n in S]); F=np.vstack([S["out_scan"][1],S["inn_scan"][1]+len(S["out_scan"][0])])
sc=o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(V.astype(np.float32)),o3d.core.Tensor(F.astype(np.uint32)))
ys=np.arange(max(d["st"][0],60),min(d["st"][-1],262)+0.01,2.0); nu=360
u=(np.arange(nu)+0.5)/nu
C=lf.curve(ys,u)  # (ny,nu,2)
# loft normals: finite differences
Cu=np.roll(C,-1,1)-np.roll(C,1,1)
tx,tz=Cu[...,0],Cu[...,1]; nx,nz=tz,-tx; nn=np.hypot(nx,nz); nx/=nn; nz/=nn
# orientation: outward = away from (40,35)
sg=np.sign(nx*(C[...,0]-40)+nz*(C[...,1]-35)); nx*=sg; nz*=sg
dy=np.gradient(C,axis=0)/2.0  # d(x,z)/dy per mm -> normal gets y component
ny_=-(nx*dy[...,0]+nz*dy[...,1])   # n = (nx,ny,nz) orthogonal to (dx/dy,1,dz/dy)
nrm=np.stack([nx,ny_,nz],-1); nrm/=np.linalg.norm(nrm,axis=-1,keepdims=True)
P=np.stack([C[...,0],np.broadcast_to(ys[:,None],C.shape[:2]),C[...,1]],-1)
org=(P+1.2*nrm).reshape(-1,3); dr=(-nrm).reshape(-1,3)
def cast(o,dv):
    r=np.hstack([o,dv]).astype(np.float32); t=np.zeros(len(o)); pn=np.zeros((len(o),3))
    for i in range(0,len(o),400000):
        h=sc.cast_rays(o3d.core.Tensor(r[i:i+400000])); t[i:i+400000]=h["t_hit"].numpy(); pn[i:i+400000]=h["primitive_normals"].numpy()
    return t,pn
t1,n1=cast(org,dr)
ok1=np.isfinite(t1)&(t1<4.0)&((n1*dr).sum(1)<0)
o2=org+dr*(np.where(ok1,t1,0)+0.4)[:,None]
t2,n2=cast(o2,dr)
ok2=ok1&np.isfinite(t2)&(t2<9)&((n2*dr).sum(1)>0)
th=np.where(ok2,t2+0.4,np.nan)
# thickness along the true normal; skin offset check
skin=np.where(ok1,t1-1.2,np.nan)
T=th.reshape(len(ys),nu); SK=skin.reshape(len(ys),nu)
np.savez(f"work/m2/wall_{tag}.npz",ys=ys,u=u,T=T,SK=SK,P=P)
ang=np.degrees(np.arctan2(C[...,1]-35,C[...,0]-40))
print("hit1 ok %.3f hit2 ok %.3f"%(ok1.mean(),ok2.mean()))
v=T[np.isfinite(T)]; print("wall all: median %.3f p10 %.3f p90 %.3f"%(np.median(v),*np.percentile(v,[10,90])))
inb=np.isfinite(T)&(np.abs(T-3.1)<0.35); print("within 3.1+-0.35 : %.1f%% of valid"%(100*inb.sum()/np.isfinite(T).sum()))
for nm,(a0,a1) in {"+X (|th|<30)":(-30,30),"top (60..120)":(60,120),"-X (|th|>150)":(150,181),"bottom (-120..-60)":(-120,-60)}.items():
    m=(ang>=a0)&(ang<=a1) if nm!="-X (|th|>150)" else (np.abs(ang)>=150)
    x=T[m&np.isfinite(T)]; print(nm,"median %.2f p10 %.2f p90 %.2f n=%d"%(np.median(x),*np.percentile(x,[10,90]),len(x)))
fig,ax=plt.subplots(1,1,figsize=(18,9))
im=ax.imshow(np.where(np.isfinite(T),T,np.nan),origin='lower',aspect='auto',extent=[0,360,ys[0],ys[-1]],cmap='jet',vmin=2.4,vmax=4.0)
ax.set_xlabel("u (loft section parameter, 0..360 = u=0 -> +X, 90 +Z, 180 -X, 270 -Z)"); ax.set_ylabel("Y"); plt.colorbar(im,label="wall mm"); plt.savefig(f"work/m2/wallmap_{tag}.png",dpi=60)
