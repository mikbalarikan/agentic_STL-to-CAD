import sys, os, numpy as np
sys.path.insert(0, 'an'); import lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
which, tag, mname = sys.argv[1:4]
v, f = lib.load({"out": "out_scan", "inn": "inn_scan"}[which], 1500000)
c, nn, ar = lib.tri_data(v, f)
d = np.load(f"work/dev_{tag}_{which}.npz")["d1"]
m = np.load(f"work/masks/{which}_{mname}.npy")
fig, ax = plt.subplots(1, 2, figsize=(16, 9))
for a, (title, dd) in zip(ax, (("d1 (new)", d),)*2):
    pass
bad = m[d[m] >= 0.5]; good = m[d[m] < 0.5]
ax[0].scatter(c[good,0], c[good,1], s=1, c='g'); ax[0].scatter(c[bad,0], c[bad,1], s=1, c='r'); ax[0].set_aspect('equal'); ax[0].set_title(f'{mname} plan: green ok red >0.5 (n bad {len(bad)} of {len(m)})')
ax[1].scatter(c[m,1], c[m,2], s=1, c=np.clip(d[m],0,2), cmap='jet'); ax[1].set_title('y-z, colour d1 0..2'); 
plt.savefig(f'work/gates/{tag}_{mname}.png', dpi=80)
print('z of bad', np.percentile(c[bad,2],[5,50,95]), 'z of good', np.percentile(c[good,2],[5,50,95]) if len(good) else None)
# bad x,y ranges coarse
H, xe, ye = np.histogram2d(c[bad,0], c[bad,1], bins=[np.arange(-90,150,20), np.arange(-60,310,20)])
for i in range(H.shape[0]):
    row = ''.join('%5d'%H[i,j] if H[i,j] else '    .' for j in range(H.shape[1]))
    print('x%4d'%xe[i], row)
print('y   ', ''.join('%5d'%y for y in ye[:-1]))
