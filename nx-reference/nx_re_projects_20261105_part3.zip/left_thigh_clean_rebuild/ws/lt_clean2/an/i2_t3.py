from i2_fit import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
for k,(x,y) in DS.BOSSES.items():
    col=cyl_fit((x,y),6.8,8.6,36.5,60)
    cc=(col['cx'],col['cy']) if col else (x,y)
    pk=cyl_fit(cc,4.4,5.8,36.5,38.9); cb=cyl_fit(cc,4.4,6.0,45.6,70); bo=cyl_fit(cc,2.5,4.0,39.6,44.6)
    f=lambda q: None if q is None else (round(q['cx'],2),round(q['cy'],2),'D',round(q['D'],2),'rms',round(q['rms'],3),'dr',round(q['draft_deg'],2),'n',q['n'],'z',round(q['z_lo'],1),round(q['z_hi'],1))
    print(k,"col",f(col)); print("   pocket",f(pk)); print("   cbore",f(cb)); print("   bore",f(bo))
    mf=lambda lo,hi,s: level_fit((np.hypot(c[:,0]-cc[0],c[:,1]-cc[1])>lo)&(np.hypot(c[:,0]-cc[0],c[:,1]-cc[1])<hi)&(n[:,2]*s>0.9)&(d>1))
