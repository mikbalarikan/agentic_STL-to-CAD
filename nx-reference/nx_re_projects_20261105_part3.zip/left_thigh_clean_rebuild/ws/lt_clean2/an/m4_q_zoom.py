import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np, trimesh
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
P5 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 5 - Clean Rebuild\deliver\CAD"
def ld(p):
    m = trimesh.load(p, process=False); m.merge_vertices(); return np.asarray(m.vertices, float), np.asarray(m.faces)
S = {"scan_out": lib.load("out_scan", 1500000), "scan_inn": lib.load("inn_scan", 1500000), "old_out": lib.load("out_cad"), "old_inn": lib.load("inn_cad"),
     "p5_out": ld(P5 + r"\LT-OUT-001_Left_Thigh_Outer.stl"), "p5_inn": ld(P5 + r"\LT-INN-001_Left_Thigh_Inner.stl")}
wins = {"knee_PX (#16/#12)": (45, 100, -62, -5), "PX_wall_thin (#29)": (70, 110, 40, 140), "PX_hip_thin (#34/#32)": (95, 125, 170, 290), "MX_hip (#11)": (-55, -25, 235, 290), "PX_wall_bump (#22/#24)": (55, 100, -15, 60), "MX_wall (#2)": (-65, -20, 20, 100)}
for scope, (zo, zi) in (("lower z=33", (33.0, None)), ("upper z=38", (None, 38.0))):
    fig, axs = plt.subplots(2, 3, figsize=(21, 14))
    for ax, (nm, (x0, x1, y0, y1)) in zip(axs.ravel(), wins.items()):
        for key, col, lw in ((("scan_out", "scan_inn")[zo is None], "k", 1.4), (("p5_out", "p5_inn")[zo is None], "tab:red", 1.0), (("old_out", "old_inn")[zo is None], "tab:green", 1.0)):
            v, f = S[key]; seg = lib.section(v, f, 2, zo if zo is not None else zi)
            ax.add_collection(LineCollection(seg[:, :, :2], colors=col, lw=lw, label=key))
        ax.set_xlim(x0, x1); ax.set_ylim(y0, y1); ax.set_aspect("equal"); ax.grid(lw=.3); ax.set_title(nm + "  " + scope); ax.legend(fontsize=7, loc="best")
    fig.tight_layout(); fig.savefig(os.path.join(lib.W, "m4", "zoom_%s.png" % scope.split()[0]), dpi=48)
