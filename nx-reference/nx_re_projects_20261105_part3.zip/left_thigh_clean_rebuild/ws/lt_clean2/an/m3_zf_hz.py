import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
v,f=lib.load('inn_scan',1500000); vc,fc=lib.load('inn_cad')
fig,ax=plt.subplots(2,2,figsize=(16,16))
for j,(nm,x0) in enumerate((('B6',97.95),('B7',-22.0))):
    a=ax[0,j]
    for y in (264.95,):
        for (vv,ff),c in (((v,f),'k'),((vc,fc),'r')):
            for p,q in lib.section(vv,ff,1,y): a.plot([p[0],q[0]],[p[2],q[2]],c+'-',lw=.8)
    a.set_xlim(x0-14,x0+14); a.set_ylim(55,100); a.set_aspect('equal'); a.grid(True); a.set_title(f"{nm} Y=264.95 (XZ)")
    a=ax[1,j]
    for (vv,ff),c in (((v,f),'k'),((vc,fc),'r')):
        for p,q in lib.section(vv,ff,0,x0): a.plot([p[1],q[1]],[p[2],q[2]],c+'-',lw=.8)
    a.set_xlim(250,280); a.set_ylim(55,105); a.set_aspect('equal'); a.grid(True); a.set_title(f"{nm} X={x0} (YZ)")
plt.tight_layout(); plt.savefig("work/m3/holes_sec.png",dpi=55)
