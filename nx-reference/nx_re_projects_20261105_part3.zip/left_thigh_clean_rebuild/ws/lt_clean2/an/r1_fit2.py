import sys, os, json, numpy as np, trimesh, open3d as o3d
from scipy.interpolate import CubicSpline
from scipy.spatial import cKDTree
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
AX, AZ = 37.97, 35.18
def sc(m):
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32))); return s
def cast(s, o, dd):
    a = s.cast_rays(o3d.core.Tensor(np.hstack([o, dd]).astype(np.float32))); return a["t_hit"].numpy(), a["primitive_normals"].numpy()
se = sc(trimesh.load("nx/base_v2/envelope.stl", process=False))
def depthgrid(ss, sg, ys, ths):
    Y, T = np.meshgrid(ys, np.radians(ths), indexing="ij")
    dv = np.stack([np.cos(T), np.zeros_like(T), sg*np.sin(T)], -1).reshape(-1, 3)
    o = np.stack([np.full(Y.size, AX), Y.ravel(), np.full(Y.size, AZ)], 1) + 500*dv
    te, ne = cast(se, o, -dv); tm, _ = cast(ss, o, -dv)
    ne = ne/np.linalg.norm(ne, axis=1, keepdims=True)
    return ((tm-te)*np.abs((ne*dv).sum(1))).reshape(Y.shape), (500-te).reshape(Y.shape)
ths = np.arange(0.5, 50.0, 0.1)
ys = np.arange(53.0, 262.6, 0.25)
TG = {}
for w, sg in (("out", -1), ("inn", 1)):
    v, f = lib.load(w + "_scan", 1500000); ss = sc(trimesh.Trimesh(v, f, process=False))
    D, Rr = depthgrid(ss, sg, ys, ths)
    pts = []
    for i, y in enumerate(ys):
        floor = np.median(D[i, (ths > 2) & (ths < 6)]); floor = 1.09 if y < 249 else min(max(floor, 1.0), 2.3)
        if floor < 0.9: continue
        rec = D[i] > 0.5*floor
        if rec[:20].sum() < 5: continue
        k0 = np.argmax(rec)
        # first index after which 3 deg (30 samples) are all non-recess
        j = None
        for q in range(k0, len(ths)-2):
            if rec[q:q+2].sum() == 0: j = q; break
        if j is not None: pts.append((y, ths[j], Rr[i, j]))
    TG[w] = np.array(pts)
    print(w, len(pts), "e.g.", [(round(a,2), round(b,1)) for a, b, c in pts[::24]])
np.savez("work/r1/edge2.npz", out=TG["out"], inn=TG["inn"])
