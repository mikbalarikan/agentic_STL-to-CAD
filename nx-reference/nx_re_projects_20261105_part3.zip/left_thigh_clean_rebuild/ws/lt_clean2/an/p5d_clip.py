import sys, numpy as np
sys.path.insert(0,"an"); import lib, trimesh
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
v,f=lib.load("out_scan",1500000); C=trimesh.load(sys.argv[1],process=False)
fig,ax=plt.subplots(1,4,figsize=(22,6))
for a,z in zip(ax,(-6,-3,0.5,3)):
    for (vv,ff),c in (((v,f),"r"),((np.asarray(C.vertices),np.asarray(C.faces)),"b")):
        for s in lib.section(vv,ff,2,float(z)): a.plot(s[:,0],s[:,1],c,lw=.8)
    a.set_xlim(80,110); a.set_ylim(192,222); a.set_aspect("equal"); a.grid(alpha=.3); a.set_title(f"z={z}")
plt.tight_layout(); plt.savefig(sys.argv[2],dpi=55)
