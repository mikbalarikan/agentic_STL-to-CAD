import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
v,f=lib.load("inn_scan",1500000); c,nn,ar=lib.tri_data(v,f)
r=np.hypot(c[:,0],c[:,1])
m=(nn[:,2]>0.99)&(np.abs(c[:,2]-83.55)<0.6)&(r<64.5)&(r>26)&(c[:,1]<66)
print(m.sum())
for r0 in range(26,66,4):
    k=m&(r>=r0)&(r<r0+4)
    if k.sum(): print(r0,k.sum(),np.percentile(c[k,2],[5,50,95]).round(3))
A=np.c_[np.ones(m.sum()),c[m,0],c[m,1]]; s=np.linalg.lstsq(A,c[m,2],rcond=None)[0]; print('plane',s, 'tilt deg',np.degrees(np.hypot(s[1],s[2])))
res=c[m,2]-A@s; print('res',np.percentile(np.abs(res),[50,90,99]))
ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
for a0 in range(-180,180,45):
    k=m&(ang>=a0)&(ang<a0+45)
    if k.sum(): print('ang',a0,k.sum(),np.median(c[k,2]).round(3))
