from i2_fit import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
from scipy.signal import find_peaks
for k,(x,y) in DS.BOSSES.items():
    r=rz((x,y)); m=(r<10)&(np.abs(n[:,2])<0.5)&(c[:,2]>35)&(d>1.0)
    cx,cy,rr,rms=circle_fit(c[m&(r>6.5)&(r<8.5)][:,:2]) if (m&(r>6.5)&(r<8.5)).sum()>50 else (0,0,0,0)
    r=rz((cx,cy)); m=(r<10)&(np.abs(n[:,2])<0.5)&(c[:,2]>35)&(d>1.0)
    h,ed=np.histogram(r[m],bins=np.arange(0,10,0.1),weights=a[m]); pk,_=find_peaks(h,height=h.max()*0.05,distance=2)
    print(k,(x,y),"fit col",round(cx,2),round(cy,2),round(rr*2,2),round(rms,3),"peaks r:",[(round(ed[i]+.05,1),int(h[i])) for i in pk])
    # z levels of -z / +z faces within r<10
    hz=(np.abs(n[:,2])>0.9)&(r<10)&(d>1.0)
    zz=c[hz,2]; h2,e2=np.histogram(zz,bins=np.arange(30,100,0.25),weights=a[hz]); pk2,_=find_peaks(h2,height=h2.max()*0.06,distance=2)
    print("    levels",[(round(e2[i]+.12,2),int(h2[i]),'dn' if np.median(n[hz&(np.abs(c[:,2]-e2[i]-.12)<.3),2])<0 else 'up') for i in pk2])
