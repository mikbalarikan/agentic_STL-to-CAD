import sys,os,time
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_g_fit as G
st=[float(s) for s in sys.argv[1].split(",")]; NP=int(sys.argv[2]); tag=sys.argv[3]
lf,keep,sr=G.run(st,NP)
np.savez(f"work/m2/loft_{tag}.npz",st=st,P=lf.P)
V,F,ys,u=G.mesh_of(lf,st[0],st[-1])
S=G.scan_pts(60,255); d=G.dist_to(V,F,S[:,:3])
def rep(m): 
    f,p90,p50=G.stats(d[m],S[m,3]); return "%.1f%% p90 %.3f"%(100*f,p90)
y=S[:,1]
print(tag,"K",len(st),"NP",NP,"| 60-255:",rep(y>0),"| 60-100:",rep(y<100),"| 100-255:",rep(y>=100),"| 100-250:",rep((y>=100)&(y<=250)),flush=True)
