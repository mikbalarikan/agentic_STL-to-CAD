import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
HX,HZ=37.97,35.18
res={}
for tag,sn,devs,zs in (('out','out_scan',('dev_FINout','dev_oldC'),lambda z:z<34.9),('inn','inn_scan',('dev_FINinn','dev_oldInnB'),lambda z:z>35.5)):
    v,f=lib.load(sn,1500000); c,nn,a=lib.tri_data(v,f)
    ext=np.zeros(len(c),bool); ext[np.load(f"work/masks/{tag}_ext_hip.npy")]=True
    r=np.hypot(c[:,0]-HX,c[:,2]-HZ); rd=np.stack([(c[:,0]-HX)/np.maximum(r,1e-9),0*r,(c[:,2]-HZ)/np.maximum(r,1e-9)],1); nr=(nn*rd).sum(1)
    base=(c[:,1]>264.5)&(c[:,1]<288)&~ext
    if tag=='out': base&=True
    plate=base&(abs(nn[:,1])>0.97)
    ringod=base&(abs(r-52.55)<0.4)&(abs(nn[:,1])<0.3)
    bore=base&((abs(r-40.97)<0.4)|(abs(r-42.97)<0.4)|(abs(r-48.76)<0.4))&(abs(nn[:,1])<0.3)
    tube=base&(c[:,1]>277.5)&(r>60)&(nr<-0.3)
    zones={'all interior Y>264.5 (non-ext)':base,'plate/pad Y-faces':plate,'ring OD cyl r52.55':ringod,'bore cyls r40.97/42.97/48.76':bore,'tube interior Y>277.5':tube}
    print('==',tag)
    for nm,m in zones.items():
        row={}
        for d in devs:
            d1=np.load(f"work/{d}.npz")['d1']; w=a[m]; ok=d1[m]<=0.5
            row[d]=(round(100*(w*ok).sum()/max(w.sum(),1e-9),1),round(float(np.percentile(d1[m],90)),2))
        print('  %-34s n=%6d area %6.0f  %s'%(nm,m.sum(),a[m].sum(),row)); res[tag+':'+nm]=dict(n=int(m.sum()),area=float(a[m].sum()),**{k:list(vv) for k,vv in row.items()})
        if nm.startswith('all'): np.save(f"work/masks/{tag}_int_hip.npy",np.where(m)[0].astype(np.int64))
json.dump(res,open('work/m3/int_dev.json','w'),indent=1)
