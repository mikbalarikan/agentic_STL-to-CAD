import sys, os, json, numpy as np
sys.path.insert(0, "an"); import lib
for w in ("out", "inn"):
    v, f = lib.load(w + "_scan", 1500000); c, nn, ar = lib.tri_data(v, f)
    for s in "AB":
        m = np.load(rf"work\masks\{w}_f_SEAM_{s}.npy"); cc = c[m]; n = nn[m]
        print(w, s, len(m), "bbox", cc.min(0).round(1), cc.max(0).round(1), "mean normal", n.mean(0).round(2), "area", ar[m].sum().round(0))
