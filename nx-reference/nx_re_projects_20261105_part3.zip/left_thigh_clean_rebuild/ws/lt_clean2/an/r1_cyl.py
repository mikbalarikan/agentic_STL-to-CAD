import sys, os, numpy as np, trimesh, open3d as o3d
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
AX, AZ = 37.97, 35.18
def sc(m):
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32))); return s
def cast(s, o, d): return s.cast_rays(o3d.core.Tensor(np.hstack([o, d]).astype(np.float32)))["t_hit"].numpy()
se = sc(trimesh.load("nx/base_v2/envelope.stl", process=False))
for w, sg in (("out", -1), ("inn", 1)):
    v, f = lib.load(w + "_scan", 1500000); ss = sc(trimesh.Trimesh(v, f, process=False))
    print(w, "r_floor_scan (radial about hip axis) rows y, cols theta 2,4,6,8,10,12,14")
    for y in (236, 242, 246, 250, 252, 254, 256, 257, 258, 259, 260):
        row = []
        for th in (2, 4, 6, 8, 10, 12, 14):
            t = np.radians(th); dv = np.array([[np.cos(t), 0, sg*np.sin(t)]]); o = np.array([[AX, y, AZ]]) + 500*dv
            te = cast(se, o, -dv)[0]; tm = cast(ss, o, -dv)[0]
            row.append((500-tm, 500-te))
        print(" y%3d floor r:" % y, " ".join("%6.2f" % a for a, b in row), "  env r:", " ".join("%6.2f" % b for a, b in row))
