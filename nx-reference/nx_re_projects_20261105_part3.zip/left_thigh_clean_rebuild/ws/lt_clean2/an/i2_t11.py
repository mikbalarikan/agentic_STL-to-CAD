from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
for k,(p0,p1,z,t) in DS.INN_RIBS.items():
    r,m,(q0,q1)=rib2(p0,p1,t); e=edge_pw(q0,q1,r["t"]); print(k,{kk:vv for kk,vv in e.items() if kk!="table"}); print("  ",e["table"][:40])
