from i1_core import *
import ref5_design as DS
from i1_help import *
rk = np.hypot(c[:, 0], c[:, 1]); thk = np.degrees(np.arctan2(c[:, 1], c[:, 0])) % 360

# ================================================================== KNEE revolve (about Z through origin)
def lvl(m, rng=(-20, 45)):
    pk = peaks(c[m, 2], a[m], 0.08, 0.1, rng=rng); return pk[0][0] if pk else np.nan
sec = ((thk > 215) & (thk < 330))      # clean sector: no side opening, no ears
zfloor = lvl(sec & (rk > 56.5) & (rk < 61) & (n[:, 2] > 0.95))
zstep1 = lvl(sec & (rk > 49) & (rk < 54) & (n[:, 2] > 0.95)); zstep2 = lvl(sec & (rk > 46.2) & (rk < 47.8) & (n[:, 2] > 0.95))
zrec = lvl(sec & (rk > 50) & (rk < 60) & (n[:, 2] < -0.95), (-20, 5))
def rw(zlo, zhi, r0, r1, sign=None):
    m = sec & (abs(n[:, 2]) < 0.25) & (c[:, 2] > zlo) & (c[:, 2] < zhi) & (rk > r0) & (rk < r1)
    if sign is not None:
        nr = (c[:, 0] * n[:, 0] + c[:, 1] * n[:, 1]) / np.maximum(rk, 1e-6); m &= (sign * nr > 0.9)
    if m.sum() < 20: return np.nan, 0
    return float(np.median(rk[m])), int(m.sum())
def rwfit(zlo, zhi, r0, r1):
    m = (abs(n[:, 2]) < 0.25) & (c[:, 2] > zlo) & (c[:, 2] < zhi) & (rk > r0) & (rk < r1) & (thk > 215) & (thk < 330)
    if m.sum() < 30: return None
    cx, cy, R, res, nn = circle_fit_robust(c[m, 0], c[m, 1]); return 2 * R, (cx, cy), res, nn
thru = rwfit(-8.2, -6.2, 45, 47.2); step = rwfit(-5.9, -4.3, 47, 49.5); bore = rwfit(-4.0, -0.2, 54, 56); rec = rwfit(-13.6, -8.5, 62, 64)
print("knee levels: floor %.2f  step1 %.2f step2 %.2f recess %.2f" % (zfloor, zstep1, zstep2, zrec))
print("D thru", thru, "step", step, "bore", bore, "rec", rec)
idx_ring = np.where((rk > 45) & (rk < 64.2) & (c[:, 2] > -9) & (c[:, 2] < 1.0) & (de > 1.5) & ~((rk > 49.5) & (rk < 53.5) & (abs(n[:, 2]) < 0.3)))[0]
par = dict(D_through=thru[0] if thru else None, z_through_step=zstep2, D_step=step[0] if step else None, z_step_floor=zstep1, D_bore=bore[0] if bore else None,
           z_floor=zfloor, z_recess_floor=zrec, axis_xy=(thru[1] if thru else None))
add("KNEE_BORE_REV", "revolve", par, "circle fits of axisymmetric wall tris per level (sector 215-330 deg) + plane peaks", thru[2] if thru else None, idx_ring,
    dict(D_through=92.1, z_through_step=-6.1, D_step=96.0, D_bore=110.0, bore_depth=4.12, z_recess=-8.35), "compare in params", "")
# recess (underside)
idx_rec = np.where((rk > 45) & (rk < 66) & (c[:, 2] < -8.2) & (c[:, 2] > -14.5) & (de > 0.3) & (n[:, 2] < 0.5))[0]
add("KNEE_RECESS_REV", "revolve", dict(D_recess=rec[0] if rec else None, z_recess_floor=zrec, z_bottom=-13.85), "circle fit of recess wall tris", rec[2] if rec else None, idx_rec,
    dict(D_recess=125.5, z_recess_floor=-8.35), "", "")
# floor ring
idx_fl = np.where((rk > 55.3) & (rk < 64.3) & (c[:, 2] > -1) & (c[:, 2] < 8) & (de > 1.5) & (n[:, 2] > 0.5))[0]
add("KNEE_FLOOR_PLANE", "plane", dict(z=zfloor, r_in=55.0, r_out=62.0), "plane peak", None, idx_fl, dict(z=0.0), "", "")

# bolt circle holes
holes = []
for k in range(30):
    a0 = k * 12.0
    m = (abs(n[:, 2]) < 0.25) & (c[:, 2] > -9) & (c[:, 2] < -3) & (rk > 48.3) & (rk < 54.6) & (thk >= a0) & (thk < a0 + 12)
    if m.sum() < 25: continue
    cx, cy, R, res, nn = circle_fit_robust(c[m, 0], c[m, 1])
    if 2.2 < R < 3.5: holes.append((cx, cy, 2 * R, res, nn))
H = np.array(holes); print("bolt holes found", len(H))
if len(H):
    rc = np.hypot(H[:, 0], H[:, 1]); ang = np.degrees(np.arctan2(H[:, 1], H[:, 0])) % 12
    print("PCD %.2f  D %.2f  phase %.2f  rms of r %.3f" % (2 * rc.mean(), H[:, 2].mean(), np.median(ang), rc.std()))
    idxh = np.where((rk > 48.2) & (rk < 54.8) & (c[:, 2] > -9) & (c[:, 2] < -3.9) & (abs(n[:, 2]) < 0.4))[0]
    add("KNEE_BOLT_HOLES", "hole pattern", dict(n=len(H), PCD=2 * rc.mean(), D=H[:, 2].mean(), phase_deg=float(np.median(ang)), PCD_scatter=rc.std()), "per-hole circle fits (wall tris), 30 sectors",
        float(H[:, 3].mean()), idxh, dict(n=30, PCD=102.92, D=5.7, phase_deg=6.0), "", "")
# side opening of the drum wall
sel = (abs(c[:, 2] - 7.5) < 0.12) & (n[:, 2] > 0.95) & (rk > 56) & (rk < 69) & (thk > 100) & (thk < 300)
ang = np.percentile(thk[sel], [0.2, 99.8])
idx_so = np.where((rk > 55) & (rk < 70) & (thk > 150) & (thk < 250) & (c[:, 2] > 4) & (c[:, 2] < 12) & (de > 0.5))[0]
add("KNEE_SIDE_OPENING", "cut", dict(ang0=ang[0], ang1=ang[1], z_top=float(np.median(c[sel, 2])), r0=float(np.percentile(rk[sel], 1)), r1=float(np.percentile(rk[sel], 99))),
    "plane z7.5 tris angular extent", None, idx_so, dict(ang0=154.6, ang1=245.7, z_top=7.49), "", "")
