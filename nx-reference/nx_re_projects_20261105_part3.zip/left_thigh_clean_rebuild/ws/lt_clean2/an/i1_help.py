from i1_core import *
import ref5_design as DS
from i1_rib import BOSS_XY, PIN_XY

def ringsel(x, y, r0, r1, zlo, zhi, dmin=2.5):
    r = np.hypot(c[:, 0] - x, c[:, 1] - y)
    nr = ((c[:, 0] - x) * n[:, 0] + (c[:, 1] - y) * n[:, 1]) / np.maximum(r, 1e-6)
    return (r > r0) & (r < r1) & (abs(n[:, 2]) < 0.25) & (c[:, 2] > zlo) & (c[:, 2] < zhi) & (de > dmin) & (abs(nr) > 0.9)

def cfit(x, y, r0, r1, zlo, zhi, dmin=2.5):
    m = ringsel(x, y, r0, r1, zlo, zhi, dmin)
    if m.sum() < 20: return None
    cx, cy, R, res, nn = circle_fit_robust(c[m, 0], c[m, 1])
    return dict(cx=cx, cy=cy, D=2 * R, res=res, n=nn, z=float(np.median(c[m, 2])))

def plane_at(x, y, r0, r1, zlo, zhi, sign=1, dmin=2.5):
    r = np.hypot(c[:, 0] - x, c[:, 1] - y)
    m = (r >= r0) & (r < r1) & (sign * n[:, 2] > 0.95) & (c[:, 2] > zlo) & (c[:, 2] < zhi) & (de > dmin)
    if m.sum() < 8: return None, 0
    pk = peaks(c[m, 2], a[m], 0.08, 0.05, rng=(zlo, zhi))
    if not pk: return float(np.median(c[m, 2])), int(m.sum())
    return pk[0][0], int(m.sum())

