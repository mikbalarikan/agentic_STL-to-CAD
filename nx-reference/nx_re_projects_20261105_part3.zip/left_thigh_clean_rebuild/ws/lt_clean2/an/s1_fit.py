"""Tensor loft fit (knee + body [+ hip]) with synthetic hidden anchors. usage: s1_fit.py tag st1,st2,... NP"""
import sys, os, time, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_lib import *
import m2_loft as L, m2_o_fitband as B
CX0, CZ0 = 40.0, 35.0
ZT, ZB = 83.6, -13.9
def Rw(z): return 68.8588 - np.tan(np.radians(1.6)) * np.abs(np.clip(z, -13.9, 83.6) - 36.07)

def anchors(ymin=-38, ymax=62, dl=3.5, rtop=61.0):
    pts = []
    for y in np.arange(ymin, ymax + 0.1, 3.0):
        # top / bottom flats inside the drum
        xl = -np.sqrt(max(rtop**2 - y**2, 0)); xr = np.sqrt(max(64.2**2 - y**2, 0))
        if xr > xl + 1:
            for x in np.arange(xl, xr, 3.0):
                r = np.hypot(x, y)
                dz = 0.5
                if r < 64.4: pts += [(y, x, ZT - dz, 1), (y, x, ZB + dz, 1)]
        # hidden -X wall, inside the drum
        if y <= 52:
            for z in np.arange(6, 63, 4.0):
                r = Rw(z); w = np.sqrt(max(r**2 - y**2, 0))
                dd = dl if y <= 44 else dl + (0.3 - dl) * (y - 44) / 8.0
                if w - dd > 2: pts.append((y, -(w - dd), z, 1))
    return np.array(pts)

def shifted(D, edge_fn=None):
    """band shift of M2 (floor 1.12 out) for Y>=56 only"""
    D = D.copy()
    d = np.load(os.path.join(W, 'm2/loft_A72.npz')); lf0 = L.Loft(d['st'], d['P'].shape[1], d['P'])
    ib = B.inband(D[:, 0], D[:, 1], D[:, 2], -1.5) & (D[:, 0] >= 56)
    edge = B.inband(D[:, 0], D[:, 1], D[:, 2], 1.0) & ~ib & (D[:, 0] >= 56)
    uu = np.linspace(0, 1, 720, endpoint=False)
    for i in np.where(ib)[0]:
        y, x, z = D[i, :3]
        C = lf0.curve(y, uu)[0]; k = np.argmin((C[:, 0] - x)**2 + (C[:, 1] - z)**2); t = C[(k + 1) % 720] - C[k - 1]
        n = np.array([t[1], -t[0]]); n /= np.linalg.norm(n)
        if n @ np.array([x - CX0, z - CZ0]) < 0: n = -n
        ramp = float(np.clip((264 - y) / 8.0, 0, 1)); D[i, 1] += 1.12 * ramp * n[0]; D[i, 2] += 1.12 * ramp * n[1]
    return D[~edge]

def get_data(ymax_data=262.5):
    D = np.load(os.path.join(S1, 'cells_raw.npy'))   # y,x,z,a
    # cells above y 66: drop z>84.3 only in knee
    D = D[(D[:, 0] < ymax_data)]
    return shifted(D)

if __name__ == '__main__':
    tag = sys.argv[1]; st = [float(s) for s in sys.argv[2].split(',')]; NP = int(sys.argv[3])
    lam_t = float(os.environ.get('LT', 1e-2)); lam_y = float(os.environ.get('LY', 1e-3))
    D = get_data()
    A = anchors()
    y = np.r_[D[:, 0], A[:, 0]]; x = np.r_[D[:, 1], A[:, 1]]; z = np.r_[D[:, 2], A[:, 2]]
    wt = np.r_[np.ones(len(D)), np.full(len(A), float(os.environ.get('WA', 1.0)))]
    th = np.arctan2(z - CZ0, x - CX0)
    m = (y >= st[0] - 1) & (y <= st[-1] + 1)
    t0 = time.time()
    lf, keep, sr, u = L.fit(st, NP, y[m], th[m], x[m], z[m], wt[m], lam_t=lam_t, lam_y=lam_y)
    print('fit', time.time() - t0, 'keep', keep.mean(), flush=True)
    np.savez(os.path.join(S1, f'loft_{tag}.npz'), st=st, P=lf.P)
