from i2_rows import *
x,y,z=c[:,0],c[:,1],c[:,2]
for R in (3.0,3.5,4.0,4.5):
    r_=np.hypot(x-0.5,y-46)
    ms=(np.abs(n[:,2])<0.3)&(r_<R)&(z>76)&(z<84)&(d>=0.3)
    print(R,ms.sum(), np.percentile(x[ms],[1,99]).round(2) if ms.sum() else None, np.percentile(y[ms],[1,99]).round(2) if ms.sum() else None)
