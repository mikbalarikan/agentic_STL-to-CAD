from s1_lib import *
import pyvista as pv; pv.OFF_SCREEN=True
P=[];C=[]
for s in ['out','inn']:
    v,f,c,n,a=scan(s); e=np.load(f'{W}/m2/ext_{s}.npy')&(c[:,1]<90)
    P.append(c[e]); C.append(c[e][:,2])
P=np.vstack(P);C=np.concatenate(C)
for nm,dv in [('px',(1,0,0.0)),('pxt',(1,-0.5,0.7)),('top',(0.01,0.01,1)),('pxb',(1,-0.5,-0.7))]:
    p=pv.Plotter(window_size=(1400,900)); p.add_mesh(pv.PolyData(P),scalars=C,cmap='viridis',point_size=3,show_scalar_bar=False)
    dv=np.array(dv,float);dv/=np.linalg.norm(dv); fo=np.array([30,10,35.]); p.camera.focal_point=fo;p.camera.position=fo+350*dv;p.camera.up=(0,0,1)
    p.screenshot(os.path.join(S1,f'view1_{nm}.png'));p.close()
