from i2_rows import *

import glob, json, math

sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")

import design as DS

rows = []

for f_ in sorted(glob.glob(os.path.join(ROWS, "*.json"))): rows += json.load(open(f_))

dropped = [r["id"] for r in rows if r["params"].get("note") in ("no walls", "fit failed", "no side walls found")]

rows = [r for r in rows if r["id"] not in dropped]

arch = json.load(open(os.path.join(O, "extra_arch.json")))





def dist_line(pt, a0, a1):

    a0, a1, pt = map(lambda v: np.array(v, float), (a0, a1, pt)); e = (a1 - a0) / np.linalg.norm(a1 - a0); v = pt - a0

    return float(abs(v[0] * e[1] - v[1] * e[0]))





def auto(r):

    """returns (cause_tags, diagnosis, recommendation)"""

    t = r["type"]; p = r["params"]; v5 = r["part5_value"]; tags = []; txt = []; rec = []



    def chk(name, meas, ref, tol, unit="mm", label=None):

        if meas is None or ref is None: return

        if abs(meas - ref) > tol:

            tags.append(name); txt.append(f"{label or name} {meas:.2f} vs part5 {ref:.2f} ({meas-ref:+.2f} {unit})")

    if t == "boss_col":

        chk("size", p["D"], 15.0, 0.25, label="column D")

        cx = p["centre"]; ref = v5["centre"]

        if math.hypot(cx[0] - ref[0], cx[1] - ref[1]) > 0.25: tags.append("position"); txt.append(f"centre ({cx[0]:.2f},{cx[1]:.2f}) vs ({ref[0]},{ref[1]})")

        if p.get("draft_deg") is not None and abs(p["draft_deg"]) > 0.4: txt.append(f"wall draft {p['draft_deg']:.2f} deg")

    elif t == "pocket":

        chk("size", p["D"], DS.POCKET_D, 0.12, label="pocket D"); chk("height", p["floor_z"], DS.POCKET_FLOOR, 0.1, label="pocket floor z")

        if p.get("taper_deg") is not None and abs(p["taper_deg"]) > 1.0:

            tags.append("type"); txt.append(f"scan pocket wall is tapered {p['taper_deg']:.1f} deg (narrows upward), part5 straight")

    elif t == "bore_cbore":

        chk("size", p["bore_D"], DS.SCREW_D, 0.2, label="bore D"); chk("size", p["cbore_D"], DS.CBORE_D, 0.2, label="cbore D"); chk("height", p["cbore_floor_z"], DS.CBORE_FLOOR, 0.1, label="cbore floor z")

    elif t in ("rib", "gusset", "arm", "flange", "run_rib", "cap_rib"):

        tt = p.get("t"); ref_t = v5.get("t")

        chk("size", tt, ref_t, 0.12, label="thickness")

        if "p0" in v5 and p.get("p0"):

            d0 = dist_line(p["p0"], v5["p0"], v5["p1"]); d1 = dist_line(p["p1"], v5["p0"], v5["p1"])

            if max(d0, d1) > 0.3: tags.append("position"); txt.append(f"centre line off the part5 line by {d0:.2f} / {d1:.2f} mm at the ends")

        ed = p.get("edge") or {}

        k = ed.get("kind")

        if k == "flat-ramp-flat":

            tags.append("type")

            txt.append(f"free edge ramps {ed.get('z_low'):.2f} -> {ed.get('z_high'):.2f} ({ed.get('ramp_angle_deg'):.1f} deg, u {ed.get('u_ramp_start'):.0f}..{ed.get('u_ramp_end'):.0f}); part5 has one level")

            rec.append("cut the free edge with an inclined plane (ramp) + flat; do not extrude to one level")

        elif k == "irregular":

            tags.append("type"); txt.append(f"free edge is not one flat level or line (z {ed.get('z_min')}..{ed.get('z_max')}), see edge_table")

            rec.append("rebuild the free edge from the edge_table as ramp + flat segments")

        elif k == "flat" and isinstance(v5.get("free_z"), (int, float)): chk("height", ed.get("z"), v5["free_z"], 0.12, label="free edge z")

    elif t == "pin":

        chk("size", p["D"], v5["D"], 0.15, label="pin D"); chk("height", p.get("root_z"), v5["root_z"], 0.1, label="root z"); chk("size", p.get("length"), v5["length"], 0.15, label="length")

        if p.get("centre") and math.hypot(p["centre"][0] - v5["centre"][0], p["centre"][1] - v5["centre"][1]) > 0.2: tags.append("position")

    elif t == "lug_hole":

        chk("size", p["lug_D"], 9.0, 0.25, label="lug D"); chk("size", p["hole_D"], 4.0, 0.2, label="hole D"); chk("height", p.get("face_z"), v5["face_z"], 0.1, label="face z")

    elif t == "hole_boss":

        if p.get("centre") and math.hypot(p["centre"][0] - v5["centre"][0], p["centre"][1] - v5["centre"][1]) > 0.3:

            tags.append("position"); txt.append(f"hole centre ({p['centre'][0]:.2f},{p['centre'][1]:.2f}) vs part5 ({v5['centre'][0]},{v5['centre'][1]})")

        chk("size", p.get("hole_D"), v5["hole_D"], 0.2, label="hole D")

        if p.get("hole_end_z") and abs(p["hole_end_z"] - v5["hole_end_z"]) > 0.5:

            tags.append("height"); txt.append(f"hole ends at z {p['hole_end_z']:.1f} (part5 {v5['hole_end_z']:.1f}): the depth follows the skin, not a fixed 6.0")

    elif t == "spoke":

        chk("size", p["t"], 3.0, 0.2, label="thickness")

        if abs(((p["angle_deg"] - v5["angle"]) + 180) % 360 - 180) > 1.0: tags.append("position"); txt.append(f"angle {p['angle_deg']:.2f} vs {v5['angle']}")

    elif t == "ring_rib":

        chk("position", p["centre_r"], v5["centre_r"], 0.15, label="centre radius"); chk("size", p["t"], 2.5, 0.2, label="thickness")

    if not txt: txt.append("dimensions within tolerance of part 5")

    return tags, "; ".join(txt), "; ".join(rec)





NOTES = {

    "MISS_ARC_RIB": ("missing", "Rib not modelled in part 5: arc rib R100.8 about (-10.2,-22.1), t 3.1, runs from the end of ARM_B3_R (x -4) to the cable-channel run rib (x 46); free edge flat 65.08 up to x~39, then a step to 71.07. Part 5 has nothing here (p90 11.7 mm).",

                     "add as one 3-point arc rib: arc through (-3.5,78.2) (22,73.3) (46.2,61.8), thin extrude t 3.1 from the skin down to 65.08, second level 71.07 from x 39.5; blend into ARM_B3_R and the run rib"),

    "MISS_OVAL_SLOT": ("missing", "through slot in the knee disc floor not modelled: 4.1 x 5.0 mm at (0.1,46.0), long axis Y", "cut a slot 4.1 x 5.0 (full radius ends) through the disc floor, centre (0.1,46.0)"),

    "HIP_WEB": ("size", "the plate between the side blocks is 3.05 thick in the scan (faces y 266.53 / 269.58); part 5 built 1.7 (y 266.5 .. 268.2)", "extrude the web y 266.55 -> 269.55 (t 3.0)"),

    "HIP_BLOCK_L": ("size", "side blocks end at y 272.38 in the scan (one +Y face level); part 5 runs them to 276.85 (4.5 mm too long); inner x face at -14.4 (clearance r 52.35)", "end the blocks at y 272.4 (thickness 5.85 from 266.55); the pad stays to 276.95"),

    "HIP_BLOCK_R": ("size", "same as the left block: end face y 272.38 vs part 5 276.85; inner x face 90.4", "end the blocks at y 272.4"),

    "I_DIAG": ("type", "free edge is flat 70.08 for u<19, ramps 11.6 deg up to 75.17 at u 44, then flat 75.17; part 5 is flat 75.15 for the whole length (rib missing up to 5 mm over the first 25 mm). Line also 0.3 mm off at the knee end.", "build the rib to 70.08 and cut the ramp with ONE inclined plane (11.6 deg) so the upper part stays at 75.17"),

    "I_LONG_HIP": ("type", "free edge ramps 84.2 -> 90.58 over the first 36 mm (9.9 deg, u 3.5..40), then flat 90.58; part 5 is flat 90.57 from the start. Root blend in the scan is large (R~7 on the -X side) and part 5 has none on this rib.", "cut the first 40 mm of the free edge with a 10 deg plane; give the rib root a clean R7 face blend"),

    "CH_RUN_RIB_L": ("type", "free edge flat 75.07 until u~110 (y~95), then ramps up ~6.1 deg to z 79.9 at the top end (y 135); part 5 stays at 75.07 along the whole run (up to 5 mm too low). The floor ramps in step.", "ramp the run (ribs + floor) with ONE inclined plane from u 112, angle 6.1 deg, rising to ~80 at y 135"),

    "CH_RUN_RIB_R": ("type", "same ramp as the left run rib: flat 75.07, then up 6.2 deg from u~117; merges into the skin on the +X side", "same single ramp plane as the left rib"),

    "CH_RUN_FLOOR": ("type", "the run floor is not a flat 76.87 plate: 76.9 -> 76.65 (y -5..45), 77.0 (y 55..85), then ramps 77.5 -> 81.3 over y 95..155 (same ramp as the ribs); cross-section is an arch", "model the floor as an arched channel (R~8, like the ring) and cut the same ramp plane at the top end"),

    "CH_RING_FLOOR": ("type", "floor between the ring ribs is a cylindrical arch (R%.1f about r %.2f, crest z %.2f); part 5 builds a flat land at 76.87" % (arch["R"], arch["centre_r"], arch["crest_z"]), "revolve an arched channel section (R%.1f, crest %.2f) instead of the flat floor" % (arch["R"], arch["crest_z"])),

    "CH_H6": ("position", "hole H6 sits at (72.9,128.4) in the scan, part 5 placed it at (77.2,128.4): 4.3 mm off in X; hole is larger too (D 4.1)", "move H6 to (72.9,128.4), D 4.1; end boss follows the ramp"),

    "HUB": ("type", "hub wall OD 40.0 (part 5 40.23); shoulder plane z 86.06 from r 20.0 to 21.5, then a clean R10 blend (centre r 28.15, z 93.5, rms 0.04) down to the disc top at r~28; part 5 has a vertical shoulder step D43.6 and no R10", "revolve profile: hub wall r 20.0 up to 86.06, flat to r 21.5, arc R10 tangent to the disc top plane (z 83.57)"),

    "KNEE_WINDOW": ("size", "window edges at 155.25 and 244.75 deg (symmetric about 200 deg, 89.5 wide), lintel z 62.52; part 5 154.6 / 245.7", "set the window from 155.25 to 244.75 deg"),

    "B6_col": ("size", "column D15.1 and position match part 5; the deviating tris (p90 2.7) are the +Y side of the column (60..120 deg, z 39..72) where part 5's hip side block wraps it up to y 276.85, scan block ends at 272.38", "fix HIP_BLOCK_R end face (y 272.4); no change to the column"),

    "B7_col": ("size", "same as B6: column D15.1 correct; deviation is on the +Y side (60..120 deg) caused by the hip side block that is 4.5 mm too long", "fix HIP_BLOCK_L end face (y 272.4)"),

    "B1_col": ("type", "part 5 extrudes a tall B1 'ear' column (z 36..83.5); the scan column (D~15.1-15.3, centre 61.2,-40.2) stops at the sloping skin (z~76) and its wall zone bulges out to the ear shape; deviating tris at 240-270 deg and 120-150 deg", "limit the B1 ear to the skin (extrude up to the envelope, not to 83.5); ear outline belongs to the envelope job"),

    "ARM_B2_D": ("type", "arm line/thickness ok (t 3.16 vs 3.0) but the zone beside it is wrong: between the arm and the +X wall the shell is locally thick and its underside is a dome (z 64.5 at y 45, 70.7 at y 52, 75 at y 58; part 5 ~70.5 flat top); deviation falls from 1.6 at the B2 end to 0.3 at the run rib", "see MISS_B2_DOME; set arm t 3.15"),

    "MISS_B2_DOME": ("missing", "the underside of the shell between ARM_B2_D, the B2 column and the +X wall is a domed ceiling up to 6 mm lower than part 5 (thick local wall); p90 3.2", "model as one revolved/ellipsoidal pocket cut (dome) from the arm side, or an offset-surface thickening of that skin patch; measure the dome in a follow-up (centre ~ (70,45), z 64.5 crest)"),

    "MISS_B1_EAR": ("missing", "the B1 ear is a teardrop lobe (column D15.2 at (61.2,-40.2) + a straight edge (53,-43.5)->(62,-50.6) + the drum arc), its vertical walls run z 36..~76 and stop at the sloping skin; part 5 built only the plain D15 column up to 83.5 (the ear walls are missing, p90 6.5 over 0.47% of the scan area)", "ear = hull of the column circle and two tangent lines to the drum wall, extruded from z 36.07 up to the envelope (not a fixed height); outline is two lines + one arc, not a traced curve"),
    "SPOKE_OUT_327": ("position", "spoke is geometrically on the part 5 line (angle 326.9, t 3.16) but its outer end runs into the B1 ear lobe and the run rib start; p90 3.7 comes from the lobe wall at r>57 and a free edge that dips to 73.8 near the run rib", "see MISS_B1_EAR; shorten the spoke to the run rib / lobe junction"),
    "SPOKE_OUT_108": ("type", "the spoke lies on the same line as ARM_B3_D (angle 108); the scan continues the full-height arm into the spoke, the deviation sits at the arm-to-spoke transition (free edge 36.07 -> 75.07)", "build arm + spoke as one rib along the 108 deg line with the free edge stepping from 36.07 to 75.07 at the ring side of the window zone"),
    "B7_bore": ("size", "cbore wall fit D 11.11 is a partial wall (n 395); the deviating tris are at the skin mouth of the counterbore (z>76), where the scan has a conical lead-in / spot face, not in the bore itself (wall p90 0.1 below z 76)", "optional: add a 0.5 x 45 deg lead-in at the cbore mouth; no change to bore / cbore diameters"),
    "IG_B7": ("type", "gusset free edge in the scan is a line z = 67.0 - 1.12 u (48 deg, reaches 36.07 at u 27.8) with a short flat at z 42.6; part 5 line 64.9 -> 36.07 over 33.2 (41 deg)", "re-sketch the gusset as a triangle with the measured slope (48 deg), end at u 27.8; keep the flat notch only if it is a real tool step"),

    "IG_B6": ("type", "same as IG_B7 (mirror at the other boss): 48 deg slope, ends at u 27.8; part 5 41 deg over 33.2", "same re-sketch as IG_B7"),

    "IG_HIP_L": ("type", "gusset free edge: ramp from ~92 at the hip plate side... measured table: 88.7@3.7, 82.2@7.8, 76.2@11.7 then flat 75.5 (slight slope) to the plate; part 5 is one straight line 90.4 -> 72.6", "ramp (54 deg) then flat 75.5 to the plate"),

    "IG_HIP_R": ("type", "same as IG_HIP_L: ramp 88.5 -> 76 over u 3.7..11.7, flat 75.5; part 5 one line 90.4 -> 72.6", "same as IG_HIP_L"),

}

out = []

for r in rows:

    tags, txt, rec = auto(r)

    if r["id"] in NOTES:

        cause, txt, rec = NOTES[r["id"]]; tags = [cause]

    if r["part5_p90"] is not None and r["part5_p90"] <= 0.5: cat = "ok"

    else: cat = tags[0] if tags else "root-fillet/draft"

    if cat == "root-fillet/draft" and r["type"] != "root_fillet":

        txt = (txt + "; " if txt != "dimensions within tolerance of part 5" else "") + "primitive matches part 5, the deviation sits in the root blends / wall draft / 0.1-0.2 mm thickness drift (see the *_root rows)"

        rec = rec or "keep the primitive; add the measured root blend and wall draft"

    r["diagnosis"] = ("OK (p90<=0.5): " if cat == "ok" else "") + txt

    r["recommendation"] = rec

    r["cause"] = cat

    out.append(r)

for r in out:

    if r["type"] == "root_fillet":

        R = r["params"].get("R_clean")

        r["diagnosis"] = "zone of the root blend next to %s: scan %s vs part5 R3.0; p90 %.2f" % (r["params"]["parent"], ("R%.1f (clean circle fit)" % R) if R else "radius is not a clean circle (rms>0.3, blend runs into a sloped skin)", r["part5_p90"] or 0)

        r["cause"] = "fillet" if (r["part5_p90"] or 0) > 0.5 else "ok"

        r["recommendation"] = "face blend of the measured radius on this rib root (one blend feature per rib), radius from a section fit at the rib middle" if r["cause"] == "fillet" else ""

ROOT_NOTES = {
    "CH_RING_IN_root": "root blends on the disc side of the ring ribs are R5.0 (section y=0 circle fits: outer rib face R5.01 rms 0.007, inner rib face R4.76 rms 0.007) vs part 5 R3.0 (p5 section fit R3.01)",
    "CH_RING_OUT_root": "same R5 blend on the disc side of the outer ring rib (R5.01 at y=0); part 5 R3.0",
    "CH_RUN_RIB_R_root": "blend on the +X side of the right run rib is R4.3-4.9 (y=0/10 section fits, rms 0.01, oblique cut) vs part 5 R3.0",
    "CH_RUN_RIB_L_root": "same family of blend (R~4.5-5) next to the left run rib; skin-side fits not clean",
    "I_LONG_HIP_root": "blend on the -X side ~R6.6-7 (rms 0.8, skin slopes there), +X side not clean; part 5 has R3 / none; the zone is the single largest blend error after the ramps",
}
for r in out:
    if r["id"] in ROOT_NOTES: r["diagnosis"] = ROOT_NOTES[r["id"]] + "; p90 %.2f" % (r["part5_p90"] or 0); r["recommendation"] = "set the root blend of this rib family to R5 (verify on a section), one face-blend feature per rib" if r["id"].startswith("CH_") else "measure the blend on a section normal to the rib and set one face-blend radius (about R5-7)"; r["cause"] = "fillet" if (r["part5_p90"] or 0) > 0.5 else "ok"
out.sort(key=lambda r: -(r["points_lost"] or 0))

for r in out:

    r["points_lost_pct_total"] = r.pop("points_lost")

json.dump(out, open(r"C:\NX_MCP_WORKSPACE\lt_clean2\FEATURES_inn.json", "w"), indent=1)

json.dump(dict(dropped=dropped), open(os.path.join(O, "dropped.json"), "w"))

from collections import Counter

print("rows", len(out), Counter(r["type"] for r in out)); print("dropped", dropped)

print("rows with part5_p90>0.5:", sum(1 for r in out if (r['part5_p90'] or 0) > 0.5))

for r in out[:25]: print(f"{r['id']:20s} {r['type']:11s} lost {r['points_lost_pct_total']:+.3f}  p5 {r['part5_p90']}  old {r['old_p90']}  cause {r['cause']}")

