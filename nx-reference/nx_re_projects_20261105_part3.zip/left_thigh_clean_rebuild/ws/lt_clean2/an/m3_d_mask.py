import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
HX,HZ=37.97,35.18
os.makedirs("work/masks",exist_ok=True)
res={}
for n,tag,zsel in (('out_scan','out',lambda z:z<36.5),('inn_scan','inn',lambda z:z>34.5)):
    v,f=lib.load(n,1500000); c,nn,a=lib.tri_data(v,f)
    sel=np.where((c[:,1]>200)&(c[:,1]<290)&zsel(c[:,2]))[0]
    cc=c[sel]; r=np.hypot(cc[:,0]-HX,cc[:,2]-HZ); th=np.degrees(np.arctan2(cc[:,2]-HZ,cc[:,0]-HX))
    # radial direction & normal outwardness
    rd=np.stack([(cc[:,0]-HX)/r,np.zeros(len(r)),(cc[:,2]-HZ)/r],1)
    out_n=(nn[sel]*rd).sum(1)
    yb=np.floor(cc[:,1]/1.0).astype(int); tb=np.floor((th+180)/2).astype(int)
    key=yb*1000+tb
    order=np.argsort(key); ks=key[order]
    uniq,start=np.unique(ks,return_index=True)
    mx=np.full(len(cc),-1e9)
    rm=np.maximum.reduceat(r[order],start)
    cnt=np.diff(np.append(start,len(ks)))
    mx[order]=np.repeat(rm,cnt)
    # neighbouring-bin max to be robust: use per-bin max (outer skin) with 1 mm tolerance
    m=(r>mx-1.0)&(out_n>0.3)
    idx=sel[m]
    np.save(f"work/masks/{tag}_ext_hip.npy",idx.astype(np.int64))
    res[tag]=len(idx); print(tag,len(idx),'tris of',len(sel),'area',a[idx].sum())
