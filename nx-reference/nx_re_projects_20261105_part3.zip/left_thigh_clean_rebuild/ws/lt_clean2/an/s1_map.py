import sys
from s1_eval import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
tag=sys.argv[1]; y0=float(sys.argv[2]); y1=float(sys.argv[3]); dd=np.load(os.path.join(S1,f'dd_{tag}.npy'))
th=np.degrees(np.arctan2(z-35,x-40))
m=(y>=y0)&(y<=y1)&((z<84.3)|(y>66))&(dd<20)&~foot
fig,ax=plt.subplots(1,1,figsize=(16,max(5,(y1-y0)/30)))
sc=ax.scatter(y[m][::2],th[m][::2],c=np.minimum(dd[m][::2],1.5),s=0.3,cmap='jet',vmin=0,vmax=1.5); plt.colorbar(sc)
th2=th; ax.set_xlabel('Y');ax.set_ylabel('theta about (40,35) deg'); ax.set_title(tag)
plt.tight_layout(); plt.savefig(os.path.join(S1,f'map_{tag}_{int(y0)}_{int(y1)}.png'),dpi=70)
