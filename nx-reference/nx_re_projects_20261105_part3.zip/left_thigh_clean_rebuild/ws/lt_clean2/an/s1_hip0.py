from s1_lib import *
d=np.load(os.path.join(S1,'ext_all.npz')); P=d['P']; x,y,z=P.T
HX,HZ=37.97,35.18
def cone(Y):
    return 37.97+0.0349*(Y-287.39), 35.18, 71.0+0.4663*(287.39-Y)
phi=np.degrees(np.arctan2(z-HZ,x-HX))
rr=np.hypot(x-HX,z-HZ)
print('rows: Y ; cols phi: scan max r (about hip axis) / cone r (same ray)')
phis=[0,15,25,35,45,60,90,120,130,140,155,180,-155,-90,-45,-25,-10]
print('Y   '+' '.join(f'{p:>9d}' for p in phis))
for Y in [235,245,250,255,258,261,264,267,270,274,278,282,286.5]:
    row=[]
    for p in phis:
        m=(np.abs(y-Y)<1)&(np.abs(((phi-p)+180)%360-180)<2)
        if m.sum()<3: row.append('   -     ');continue
        # cone r along ray
        ax,az,R=cone(Y); th=np.radians(p); dx,dz=np.cos(th),np.sin(th)
        ox,oz=HX-ax,HZ-az; b=ox*dx+oz*dz; c=ox*ox+oz*oz-R*R; rc=-b+np.sqrt(b*b-c)
        row.append(f'{np.percentile(rr[m],90):4.1f}/{rc:4.1f}')
    print(f'{Y:5.1f} '+' '.join(row))
