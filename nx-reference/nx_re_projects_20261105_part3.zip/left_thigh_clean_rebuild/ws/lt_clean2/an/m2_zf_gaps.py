import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
P=np.load("work/m2/ext_pts_long.npy"); th=np.degrees(np.arctan2(P[:,2]-35,P[:,0]-40))
print("Y: angular gaps (no exterior skin) in 2deg bins, theta ranges")
for y in list(range(130,190,5))+list(range(180,250,5)):
    m=np.abs(P[:,1]-y)<=1.0; h=np.histogram(th[m],bins=np.arange(-180,182,2))[0]
    z=np.where(h==0)[0]; rng=[]
    if len(z):
        s=z[0];p=z[0]
        for i in z[1:]:
            if i!=p+1: rng.append((s*2-180,p*2-178)); s=i
            p=i
        rng.append((s*2-180,p*2-178))
    print(y,[r for r in rng if r[1]-r[0]>=4])
