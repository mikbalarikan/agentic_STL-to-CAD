import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
for n in ("out_scan","inn_scan"):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f)
    print(n,len(f),v.min(0).round(1),v.max(0).round(1))
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    radial=(c[:,0]*nn[:,0]+c[:,1]*nn[:,1])/np.maximum(r,1e-9)
    m=(r>60)&(r<75)&(radial>0.9)&(c[:,1]<10)
    for z0 in range(-20,95,5):
        k=m&(c[:,2]>=z0)&(c[:,2]<z0+5)
        if k.sum()>20:
            print(z0,k.sum(),np.percentile(r[k],[5,50,95]).round(2), np.percentile(ang[k],[1,99]).round(0))
