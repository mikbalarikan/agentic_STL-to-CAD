import sys,os,itertools
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from m1_s_grid import score,p90
rows=[]
for dd,Rp,zp in itertools.product((1.6,1.65,1.7,1.75,1.8),(68.85,68.9,68.95,69.0),(36.07,37.0)):
    o=score((Rp,zp,dd,-13.9,83.6,3.3,3.1),(0,0)); r=[]
    for nm in o:
        d,who,w=o[nm]; k=(who==2)|(who==3); r.append((p90(d[k],w[k]),np.average(d[k],weights=w[k])))
    rows.append((max(r[0][0],r[1][0]),dd,Rp,zp,r))
rows.sort(key=lambda a:a[0])
for a in rows[:10]: print(a[1:4],'out p90/mean %.3f %.3f  inn %.3f %.3f'%(a[4][0]+a[4][1]))
