import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, m5_r as R
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,axs=plt.subplots(2,1,figsize=(14,12))
ay=np.array([a for a,b in R.AN]); at=np.array([b for a,b in R.AN])
for ax,(scan,key,sg) in zip(axs,(("out_scan","out",-1),("inn_scan","inn",1))):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    t=np.load(os.path.join(lib.W,"m5",f"{key}_thick.npy")); dot=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["dot"]
    th=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))*sg
    m=(dot<0)&(t>0)&(t<6)&(c[:,0]>40)&(th>-2)&(th<65)
    s=ax.scatter(c[m,1][::2],th[m][::2],s=1,c=t[m][::2],cmap='jet',vmin=1.5,vmax=3.6)
    ax.plot(ay,at,'k-',lw=2); ax.plot([54.5,54.5],[0,28],'k-',lw=2); ax.plot([259,259],[0,15],'k-',lw=2)
    ax.set_title(f"{key}: wall thickness on inner face (colour), proposed panel outline (black); x = Y, y = angle about hip axis from joint plane"); ax.grid(alpha=.3); plt.colorbar(s,ax=ax)
plt.savefig(os.path.join(lib.W,"m5","panel_outline.png"),dpi=60)
