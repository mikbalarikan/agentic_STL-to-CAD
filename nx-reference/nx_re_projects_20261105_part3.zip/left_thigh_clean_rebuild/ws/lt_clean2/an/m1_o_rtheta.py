import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
AX=(0.12,-0.02); Rp,zp,t=68.80,36.85,0.0275
fig,ax=plt.subplots(2,1,figsize=(20,12))
for a,(n,zs) in zip(ax,(("out_scan",[-9,-5,0,4,14,30]),("inn_scan",[40,55,66,72,78]))):
    v,f=lib.load(n,1500000)
    for z in zs:
        s=lib.section(v,f,2,z); p=s.reshape(-1,3)
        x=p[:,0]-AX[0]; y=p[:,1]-AX[1]; r=np.hypot(x,y); ang=np.degrees(np.arctan2(x,-y))
        d=r-(Rp-abs(z-zp)*t); m=(r>58)&(d>-4)&(d<8)
        a.plot(ang[m],d[m],'.',ms=2,label=f"z={z}")
    a.set_ylim(-3,8); a.set_xlim(-180,180); a.grid(True); a.legend(markerscale=6); a.set_title(n+" r - cone(z) vs angle (all section points r>58)")
plt.tight_layout(); plt.savefig("work/m1/rtheta.png",dpi=55)
