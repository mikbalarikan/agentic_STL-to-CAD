import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
P=np.load("work/m2/ext_pts.npy")
print("Y  xmin xmax zmin zmax  (percentile 0.5/99.5)")
for y in range(30,272,10):
    q=P[np.abs(P[:,1]-y)<=1.0]; x,z=q[:,0],q[:,2]
    print(y,len(q),np.percentile(x,[0.3,99.7]).round(1),np.percentile(z,[0.3,99.7]).round(1), "z@xmax",z[np.argmax(x)].round(1),"x@zmax",x[np.argmax(z)].round(1),"x@zmin",x[np.argmin(z)].round(1))
