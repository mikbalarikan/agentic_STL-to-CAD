import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HX,HZ=37.97,35.18
D=np.load("work/m3/ext_pts.npz"); P=D['P']; r=D['r']; th=D['th']
ya=np.arange(240.5,287.0,1.0); ta=np.arange(-172.5,173,5.0)
G=np.full((len(ya),len(ta)),np.nan)
for i,y in enumerate(ya):
    ky=abs(P[:,1]-y)<0.5
    for j,t in enumerate(ta):
        k=ky&(abs(th-t)<2.5)
        if k.sum()>=4: G[i,j]=np.median(r[k])
np.save("work/m3/Rgrid.npy",G)
print('nan frac',np.isnan(G).mean())
# for Y>=262 compare to mean-profile
for y0 in (252,258,262,266):
    i0=int(y0-240.5); sub=G[i0:]; Rc=np.nanmean(sub,1)
    X=sub-Rc[:,None]
    ok=~np.isnan(X).any(0); U,s,Vt=np.linalg.svd(X[:,ok],full_matrices=False)
    print('Y>=',y0,'singular values of R-mean(R):',s[:4].round(2),' (rows',sub.shape[0],')')
# shape mode g(theta): ratio of (R(y,th)-Rbar(y)) to its value at Y=262
i262=int(262-240.5); base=G[i262]-np.nanmean(G[i262])
for y in (250,256,262,266,270,274,278,282,285,286):
    i=int(y-240.5); d=G[i]-np.nanmean(G[i]); ok=~np.isnan(d)&~np.isnan(base)
    k=(d[ok]@base[ok])/(base[ok]@base[ok]); res=d[ok]-k*base[ok]
    print('Y',y,'Rbar %.2f amp %.3f (rel to Y262) resid std %.3f'%(np.nanmean(G[i]),k,res.std()))
