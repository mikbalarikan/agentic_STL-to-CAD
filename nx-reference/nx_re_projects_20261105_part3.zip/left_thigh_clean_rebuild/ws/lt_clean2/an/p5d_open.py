"""E0 skin classification map: green both closed (skipped), red = CAD open scan closed, blue = scan open CAD closed, black = both open."""
import numpy as np, trimesh, open3d as o3d, sys
sys.path.insert(0,"an"); import lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
def sc(m):
    s=o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices,np.float32)),o3d.core.Tensor(np.asarray(m.faces,np.uint32))); return s
for w in ("out","inn"):
    E=trimesh.load(f"nx/P5c/{w}_E0.stl"); P=trimesh.load(f"nx/P5c/{w}_P5c.stl")
    v,f=lib.load({"out":"out_scan","inn":"inn_scan"}[w],1500000); S=trimesh.Trimesh(v,f,process=False)
    pts,fi=trimesh.sample.sample_surface(E,3000000,seed=5); nrm=E.face_normals[fi]
    Q=o3d.core.Tensor(pts.astype(np.float32)); dP=sc(P).compute_distance(Q).numpy(); dS=sc(S).compute_distance(Q).numpy()
    np.savez(f"work/p5d/c2/e0cls_{w}.npz",pts=pts,nrm=nrm,dP=dP,dS=dS)
    for nm,sel,ax in (("PX",nrm[:,0]>0.5,(1,2)),("MX",nrm[:,0]<-0.5,(1,2)),("TOP",nrm[:,2]>0.5,(0,1)),("BOT",nrm[:,2]<-0.5,(0,1))):
        zr=(pts[:,2]<37.5) if w=="out" else (pts[:,2]>33.5)
        m=sel&zr
        cp=dP[m]>0.4; cs=dS[m]>0.4
        fig,a=plt.subplots(figsize=(14,7)); p=pts[m][:,list(ax)]
        a.scatter(p[~cp&~cs][:,0],p[~cp&~cs][:,1],s=0.2,c="#cfe8cf")
        a.scatter(p[cs&~cp][:,0],p[cs&~cp][:,1],s=1,c="b",label="scan open, CAD closed")
        a.scatter(p[cp&~cs][:,0],p[cp&~cs][:,1],s=1.5,c="r",label="CAD open, scan closed")
        a.scatter(p[cp&cs][:,0],p[cp&cs][:,1],s=0.6,c="k",label="both open")
        a.set_aspect("equal"); a.legend(markerscale=8); a.set_title(f"{w} {nm} view axes {ax}"); a.grid(alpha=.3)
        fig.tight_layout(); fig.savefig(f"work/p5d/c2/open_{w}_{nm}.png",dpi=70); plt.close(fig)
