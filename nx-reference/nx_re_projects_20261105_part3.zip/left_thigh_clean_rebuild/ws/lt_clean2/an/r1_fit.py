"""Fit ONE spline to the scan step edge of the +X panel. Writes work/r1/panel_fit.json"""
import sys, os, json, numpy as np, trimesh, open3d as o3d
from scipy.interpolate import CubicSpline
from scipy.spatial import cKDTree
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
AX, AZ = 37.97, 35.18
d = np.load("work/r1/edge.npz"); ys = d["y"]
def sc(m):
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32))); return s
def cast(s, o, dd):
    a = s.cast_rays(o3d.core.Tensor(np.hstack([o, dd]).astype(np.float32))); return a["t_hit"].numpy(), a["primitive_normals"].numpy()
se = sc(trimesh.load("nx/base_v2/envelope.stl", process=False))
def rad(y, th, sg):
    t = np.radians(th); dv = np.array([[np.cos(t), 0, sg*np.sin(t)]]); o = np.array([[AX, y, AZ]]) + 500*dv
    return 500 - cast(se, o, -dv)[0][0]
# corner polylines (y as function of theta) from step profiles
def corner(w, sg, y_lo, y_hi, side):
    v, f = lib.load(w + "_scan", 1500000); ss = sc(trimesh.Trimesh(v, f, process=False)); P = []
    for th in np.arange(2.0, 24.01, 1.0):
        T = np.radians(th); dv = np.array([np.cos(T), 0, sg*np.sin(T)]); yy = np.arange(y_lo, y_hi, 0.1)
        o = np.stack([np.full(len(yy), AX), yy, np.full(len(yy), AZ)], 1) + 500*dv
        te, ne = cast(se, o, -np.tile(dv, (len(yy), 1))); tm, _ = cast(ss, o, -np.tile(dv, (len(yy), 1)))
        ne = ne/np.linalg.norm(ne, axis=1, keepdims=True); dn = (tm-te)*np.abs((ne*dv).sum(1)); rec = dn > 0.55
        if side == "start":
            k = np.where(rec)[0]
            if len(k) and k[0] > 0: P.append((yy[k[0]], th))
        else:
            k = np.where(rec[:np.argmax(yy > 259.8)] if False else rec)[0]
            if len(k):
                # last recessed y before the plateau of 'no recess'; require contiguous from 250
                run = np.argmax(~rec[(yy > 250)]) if (~rec[(yy > 250)]).any() else None
                if run: P.append((yy[yy > 250][run], th))
    return P
res = {}
for w, sg in (("out", -1), ("inn", 1)):
    st = corner(w, sg, 50, 60, "start"); en = corner(w, sg, 245, 266, "end")
    res[w] = {"start": st, "end": en}
    print(w, "start corner (y,theta):", [(round(a, 2), b) for a, b in st][:24])
    print(w, "end corner (y,theta):", [(round(a, 2), b) for a, b in en][:24])
json.dump(res, open("work/r1/corners.json", "w"))
