import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, trimesh, open3d as o3d
env = trimesh.load(os.path.join(lib.W,"env_part5.stl"), process=False)
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(np.asarray(env.vertices,np.float32)), o3d.core.Tensor(np.asarray(env.faces,np.uint32)))
for scan,key in (("out_scan","out"),("inn_scan","inn")):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f); w=ar/ar.sum()
    r=sc.compute_closest_points(o3d.core.Tensor(c.astype(np.float32)))
    cp=r["points"].numpy(); pid=r["primitive_ids"].numpy()
    en=np.asarray(env.face_normals)[pid]
    d=np.linalg.norm(cp-c,axis=1)
    dot=(nn*en).sum(1)
    band=np.load(os.path.join(lib.W,"masks",f"{key}_band.npy"))
    m=np.zeros(len(c),bool); m[band]=1
    ext=d<0.5
    print(scan)
    for name,mm in (("band",m),("exterior d<0.5",ext),("wall 2.4-3.9",(d>=2.4)&(d<3.9)),("all 1-2.4 incl",(d>=1)&(d<2.4))):
        print(f" {name:16s} n={mm.sum():7d} dot(scan n, env n) pct 10/50/90:",np.round(np.percentile(dot[mm],[10,50,90]),2),"frac dot>0",round((dot[mm]>0).mean(),2))
    np.savez(os.path.join(lib.W,"m5",f"{key}_cp.npz"),cp=cp,en=en,dot=dot,d=d)
