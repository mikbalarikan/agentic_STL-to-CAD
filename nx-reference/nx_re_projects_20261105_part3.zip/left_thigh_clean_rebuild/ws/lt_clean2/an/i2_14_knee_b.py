from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS, math
rows = []
r0 = np.hypot(c[:, 0], c[:, 1]); th0 = np.degrees(np.arctan2(c[:, 1], c[:, 0])) % 360
# ---------------- ring ribs of the cable channel (C): wall circle fits + levels
def wall_circle(rn, a0, a1, z0=70, z1=80):
    m = (np.abs(n[:, 2]) < 0.5) & (np.abs(r0 - rn) < 0.8) & (th0 > a0) & (th0 < a1) & (c[:, 2] > z0) & (c[:, 2] < z1) & (d >= 2.0)
    h, ed = np.histogram(r0[m], bins=np.arange(rn - 0.8, rn + 0.85, 0.05), weights=a[m]); k = np.argmax(h); rc = ed[k] + .025
    m &= np.abs(r0 - rc) < 0.35
    if m.sum() < 50: return None
    cx, cy, R, rms = circle_fit(c[m][:, :2], a[m]); 
    # draft: r vs z
    A = np.c_[c[m, 2], np.ones(m.sum())]; sl = np.linalg.lstsq(A, r0[m], rcond=None)[0][0]
    return dict(cx=cx, cy=cy, R=R, rms=rms, n=int(m.sum()), slope_deg=float(np.degrees(np.arctan(sl))))
walls = {}
for nm, rn in (("in_inner", 32.4), ("in_outer", 34.9), ("out_inner", 42.4), ("out_outer", 44.6)):
    walls[nm] = wall_circle(rn, 120, 300)
    print(nm, walls[nm])
ri_f = level_fit((n[:, 2] < -0.9) & (r0 > 32.9) & (r0 < 34.4) & (th0 > 120) & (th0 < 300) & (c[:, 2] > 72) & (c[:, 2] < 78), tol=0.3)
ro_f = level_fit((n[:, 2] < -0.9) & (r0 > 42.9) & (r0 < 44.1) & (th0 > 120) & (th0 < 300) & (c[:, 2] > 72) & (c[:, 2] < 78), tol=0.3)
fl_f = level_fit((n[:, 2] < -0.9) & (r0 > 36.0) & (r0 < 41.2) & (th0 > 120) & (th0 < 300) & (c[:, 2] > 74) & (c[:, 2] < 80), tol=0.3)
dsk = level_fit((n[:, 2] < -0.9) & (r0 > 46) & (r0 < 62) & (th0 > 120) & (th0 < 300) & (c[:, 2] > 78) & (c[:, 2] < 82), tol=0.3)
def pk(nm): w = walls.get(nm); return (w["R"], (w["cx"], w["cy"])) if w else (None, None)
rows_ring = {}
for rid, (a_, b_), (nmi, nmo), fl_lvl, p5c in (("CH_RING_IN", ("in_inner", "in_outer"), ("in_inner", "in_outer"), ri_f, DS.CH_R_IN), ("CH_RING_OUT", ("out_inner", "out_outer"), ("out_inner", "out_outer"), ro_f, DS.CH_R_OUT)):
    wi, wo = walls[nmi], walls[nmo]
    if not (wi and wo): continue
    cen = (wi["R"] + wo["R"]) / 2; t = wo["R"] - wi["R"]
    mk = (np.abs(r0 - cen) < t / 2 + 0.8) & (th0 > 75) & (th0 < 335) & (c[:, 2] > 72) & (c[:, 2] < 80.5) & (d >= 2.0)
    rows.append(make_row(rid, "ring_rib", dict(centre_r=cen, t=t, axis=[(wi["cx"] + wo["cx"]) / 2, (wi["cy"] + wo["cy"]) / 2], r_inner_face=wi["R"], r_outer_face=wo["R"], free_z=fl_lvl["z"] if fl_lvl else None,
                         draft_deg=[wi["slope_deg"], wo["slope_deg"]]), "circle fits of the two wall faces (angles 120..300, de>=2) + free-edge level", max(wi["rms"], wo["rms"]), mk,
                         dict(centre_r=p5c, t=DS.CH_RIB_T, free_z=DS.CH_RIB_BOTTOM, angle_from=DS.CH_A_TOP, angle_to=330.0)))
mk = (r0 > 34.9 - 0.3) & (r0 < 42.4 + 0.3) & (th0 > 75) & (th0 < 335) & (c[:, 2] > 72) & (c[:, 2] < 80.5) & (d >= 2.0)
rows.append(make_row("CH_RING_FLOOR", "plane", dict(z=fl_lvl["z"] if (fl_lvl := fl_f) else None), "level fit nz<-0.9 between the ring ribs", fl_f["rms"] if fl_f else None, mk, dict(z=DS.CH_FLOOR)))
# ---------------- channel ring ends: C start (top) end angle and the notch seen in the scan
for lvl_name, rlo, rhi in (("rib_in", 32.0, 35.3), ("floor", 36, 41.3), ("rib_out", 42.0, 45.0)):
    m = (n[:, 2] < -0.5) & (r0 > rlo) & (r0 < rhi) & (c[:, 2] > 72) & (c[:, 2] < 79) & (d >= 2.0)
    hh, ed = np.histogram(th0[m], bins=np.arange(0, 360, 1.0), weights=a[m]); on = hh > 0.3 * np.median(hh[hh > 0])
    chg = np.flatnonzero(on[1:] != on[:-1]) + 1; print("ring presence", lvl_name, [float(ed[i]) for i in chg])
# ---------------- spokes
def spoke(fid, ang, ra, rb, p5v):
    p0 = (ra * math.cos(math.radians(ang)), ra * math.sin(math.radians(ang))); p1 = (rb * math.cos(math.radians(ang)), rb * math.sin(math.radians(ang)))
    r, m, (q0, q1) = rib2(p0, p1, 3.0, de_min=2.0, zmin=60.0, win=3.5, u_in=(0.15, 0.85)) if False else rib2(p0, p1, 3.0, de_min=2.0, zmin=60.0, win=3.5)
    if not np.isfinite(r.get("t", np.nan)):
        rows.append(make_row(fid, "spoke", dict(note="fit failed"), "rib2", None, m, p5v)); return
    ang_m = math.degrees(math.atan2(q1[1] - q0[1], q1[0] - q0[0])) % 360
    # perpendicular offset of the measured line from the axis (should be ~0 for a radial spoke)
    off = (q0[0] * math.sin(math.radians(ang_m)) - q0[1] * math.cos(math.radians(ang_m)))
    e = edge_pw(q0, q1, r["t"], step=2.0, zmin=60.0)
    rows.append(make_row(fid, "spoke", dict(angle_deg=ang_m, t=r["t"], offset_from_axis=off, free_edge={k: v for k, v in e.items() if k not in ("table", "rms_line", "line_slope", "line_z0")}, edge_table=e["table"], u_extent=r.get("u_ext"),
                         p0=q0.tolist(), p1=q1.tolist()), "rib2 along the nominal radial line (de>=2, z>60)", None, m, p5v))
for a_ in DS.SPOKES_IN: spoke(f"SPOKE_IN_{int(a_)}", a_, 12.0, 31.0, dict(angle=a_, t=DS.SPOKE_T, r_from=10.5, r_to=DS.CH_R_IN, bottom_z=DS.SPOKE_BOTTOM))
for a_ in DS.SPOKES_OUT: spoke(f"SPOKE_OUT_{int(a_)}", a_, 46.0, 63.0, dict(angle=a_, t=DS.SPOKE_T, r_from=DS.CH_R_OUT, r_to=66.5, bottom_z=DS.SPOKE_BOTTOM))
dump("knee_b", rows)
