"""P4 fix round 1: scan measurements of the +X panel (depth, end walls, boundary). Rays about the hip axis."""
import sys, os, json
import numpy as np, trimesh, open3d as o3d
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
AX, AZ = 37.97, 35.18
def sc(m):
    s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32))); return s
def cast(s, o, d):
    a = s.cast_rays(o3d.core.Tensor(np.hstack([o, d]).astype(np.float32))); return a["t_hit"].numpy(), a["primitive_normals"].numpy()
env = trimesh.load("nx/base_v2/envelope.stl", process=False); se = sc(env)
out = {}
for w, sg, tgt in (("out", -1, 1.2), ("inn", 1, 1.1)):
    v, f = lib.load(w + "_scan", 1500000); ss = sc(trimesh.Trimesh(v, f, process=False))
    def depth_grid(ys, ths):
        Y, T = np.meshgrid(ys, np.radians(ths), indexing="ij")
        dv = np.stack([np.cos(T), np.zeros_like(T), sg * np.sin(T)], -1).reshape(-1, 3)
        o = np.stack([np.full(Y.size, AX), Y.ravel(), np.full(Y.size, AZ)], 1) + 500 * dv
        te, ne = cast(se, o, -dv); tm, _ = cast(ss, o, -dv)
        # normal depth: radial depth * cos(angle radial/normal)
        ne = ne / np.linalg.norm(ne, axis=1, keepdims=True); cosang = np.abs((ne * dv).sum(1))
        return ((tm - te) * cosang).reshape(Y.shape), (tm - te).reshape(Y.shape)
    # (A) floor depth: interior y 75..240, theta 6..(edge-6) using interpolated old boundary; histogram mode
    BT = np.array([(54.5, 28.0), (80.0, 37.8), (110.0, 40.5), (150.0, 38.2), (210.0, 30.8), (246.0, 24.5), (259.0, 15.0)])
    ys = np.arange(75, 241, 3.0); ths = np.arange(6, 36, 1.0)
    dn, dr = depth_grid(ys, ths)
    mask = np.array([[ (t < np.interp(y, BT[:, 0], BT[:, 1]) - 6) for t in ths] for y in ys])
    d = dn[mask]; d = d[(d > 0.6) & (d < 1.8)]
    h, e = np.histogram(d, bins=np.arange(0.6, 1.8, 0.02)); mode = e[np.argmax(h)] + 0.01
    print(f"[{w}] floor normal depth interior n {len(d)}: p10 {np.percentile(d,10):.3f} p25 {np.percentile(d,25):.3f} p50 {np.median(d):.3f} p75 {np.percentile(d,75):.3f} p90 {np.percentile(d,90):.3f} mode {mode:.2f} mean {d.mean():.3f}")
    # per-y median
    pj = [(float(y), round(float(np.median(dn[i][mask[i]])), 3)) for i, y in enumerate(ys) if mask[i].sum() > 3]
    print("   per-y median depth:", pj[::6])
    out[w] = {"depth_p50": float(np.median(d)), "depth_mode": float(mode), "depth_mean": float(d.mean())}
    # (B) end walls: depth profile along y at several theta
    for thd in (5, 8, 12, 16):
        yy = np.arange(48, 60, 0.25); a, _ = depth_grid(yy, [thd]); a = a[:, 0]
        yz = np.arange(250, 268, 0.25); b, _ = depth_grid(yz, [thd]); b = b[:, 0]
        print(f"[{w}] theta {thd} start profile y:", " ".join(f"{y:.1f}:{x:.2f}" for y, x in zip(yy[::2], a[::2])))
        print(f"[{w}] theta {thd} end profile y:", " ".join(f"{y:.1f}:{x:.2f}" for y, x in zip(yz[::2], b[::2])))
    # (C) boundary edge theta(y): first theta (from 2 deg outward) where normal depth < 0.5*tgt after recess
    thf = np.arange(1.0, 55.0, 0.1); ysb = np.arange(56, 262, 2.0)
    dnb, drb = depth_grid(ysb, thf)
    E = []
    for i, y in enumerate(ysb):
        rec = dnb[i] > 0.5 * tgt
        if not rec[:30].any(): E.append(np.nan); continue
        k0 = np.argmax(rec); nr = np.where(~rec[k0:])[0]
        E.append(thf[k0 + nr[0]] if len(nr) else np.nan)
    E = np.array(E)
    print(f"[{w}] edge theta(y):", " ".join(f"{y:.0f}:{e:.1f}" for y, e in zip(ysb[::2], E[::2])))
    out[w]["edge"] = {"y": ysb.tolist(), "theta": [None if np.isnan(x) else float(x) for x in E]}
json.dump(out, open("work/r1/meas.json", "w"), indent=1)
