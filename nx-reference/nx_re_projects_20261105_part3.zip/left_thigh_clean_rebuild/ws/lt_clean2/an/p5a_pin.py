import sys, numpy as np
sys.path.insert(0,'an')
import lib
v,f = lib.load('out_scan',1500000)
c,nn,ar = lib.tri_data(v,f)
d = np.load('work/dev_p5aoutx_out.npz')['d1']
for nm,(px,py) in (('N1',(-30.9,-51.4)),('N2',(-56.7,19.5))):
    m=np.load('work/masks/out_f_COVERPIN_%s.npy'%nm); cm=c[m]; dm=d[m]
    rr=np.hypot(cm[:,0]-px,cm[:,1]-py)
    print(nm)
    for z0,z1 in ((-9,0),(0,7.5),(7.5,14.7),(14.7,40)):
        for r0,r1 in ((0,2),(2,4.5),(4.5,6),(6,40)):
            s=(cm[:,2]>=z0)&(cm[:,2]<z1)&(rr>=r0)&(rr<r1)
            if s.sum()>20: print('  z %5.1f-%5.1f r %4.1f-%4.1f n %5d p50 %.2f p90 %.2f'%(z0,z1,r0,r1,s.sum(),np.median(dm[s]),np.percentile(dm[s],90)))
