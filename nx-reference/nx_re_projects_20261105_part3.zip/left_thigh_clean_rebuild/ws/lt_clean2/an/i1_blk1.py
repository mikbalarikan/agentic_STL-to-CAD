from i1_core import *
import ref5_design as DS
from i1_rib import BOSS_XY, PIN_XY
from i1_help import *

# ---------------------------------------------------------------- bosses B1..B7
for k, (x, y) in DS.BOSSES.items():
    col = cfit(x, y, 6.8, 8.4, 6, 35.5); sp = cfit(x, y, 4.3, 5.8, 36.5, 39.2); ho = cfit(x, y, 1.8, 3.6, 27, 42)
    zc, _ = plane_at(x, y, 5.6, 7.1, 34, 37.5); zs, _ = plane_at(x, y, 3.0, 4.6, 38, 40)
    zh, _ = plane_at(x, y, 0, 2.0, 20, 40)
    cx, cy = (sp['cx'], sp['cy']) if sp else (x, y)
    par = dict(x=cx, y=cy, D_col=col['D'] if col else None, D_spigot=sp['D'] if sp else None, D_hole=ho['D'] if ho else None,
               z_col_top=zc, z_spigot_top=zs, z_hole_bottom=zh, hole_depth=(zs - zh) if (zs and zh) else None)
    p5 = dict(x=x, y=y, D_col=DS.BOSS_D, D_spigot=DS.NUB_D, D_hole=DS.NUB_HOLE_D, z_col_top=DS.Z_A, z_spigot_top=DS.NUB_TOP, hole_depth=DS.NUB_HOLE_DEPTH)
    idx = disc(x, y, 8.3)
    diffs = []
    if col and abs(col['D'] - 15) > 0.2: diffs.append(f"column D {col['D']:.2f} vs 15 (partly contaminated by blends/ears)")
    if zh and zs and abs((zs - zh) - 12.0) > 0.4: diffs.append(f"hole depth {zs-zh:.2f} vs 12")
    add(f"BOSS_{k}", "boss", par, "circle fit (robust LS) on wall tris per radial ring; plane peaks for tops", ho['res'] if ho else None, idx, p5,
        "; ".join(diffs) or "column/spigot/hole match part 5", "")

# ---------------------------------------------------------------- pins / lugs
for k, (x, y, top_o, pin_top, face_i) in DS.PINS.items():
    lug = cfit(x, y, 3.8, 5.2, 12, 34, 1.5); pin = cfit(x, y, 1.5, 2.6, top_o + 0.5, 45, 1.5)
    ztop, _ = plane_at(x, y, 2.4, 4.4, 30, 38, 1, 1.5)
    zt2 = None
    r = np.hypot(c[:, 0] - x, c[:, 1] - y)
    mm = (r < 2.0) & (n[:, 2] > 0.95) & (c[:, 2] > 36) & (de > 1.5)
    zt2 = float(np.median(c[mm, 2])) if mm.sum() > 5 else None
    par = dict(x=pin['cx'] if pin else x, y=pin['cy'] if pin else y, D_lug=lug['D'] if lug else None, D_pin=pin['D'] if pin else None, z_lug_top=ztop, z_pin_top=zt2)
    p5 = dict(x=x, y=y, D_lug=DS.PIN_LUG_D, D_pin=DS.PIN_D, z_lug_top=top_o, z_pin_top=pin_top)
    diffs = []
    if ztop and abs(ztop - top_o) > 0.1: diffs.append(f"lug top {ztop:.2f} vs {top_o}")
    if zt2 and abs(zt2 - pin_top) > 0.15: diffs.append(f"pin top {zt2:.2f} vs {pin_top}")
    add(f"PIN_{k}", "pin+lug", par, "circle fit lug/pin walls, plane peaks", pin['res'] if pin else None, disc(x, y, 5.3, 1.5), p5, "; ".join(diffs) or "matches part 5", "")
