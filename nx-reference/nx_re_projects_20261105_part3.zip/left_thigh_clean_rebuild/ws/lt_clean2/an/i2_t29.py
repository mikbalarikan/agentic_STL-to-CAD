from i2_rows import *
x,y,z=c[:,0],c[:,1],c[:,2]
m=(n[:,2]<-0.9)&(x>-3)&(x<48)&(y>58)&(y<82)&(d>=2.0)&((np.abs(z-65.08)<0.2)|(np.abs(z-71.07)<0.2))
P=[]
for x0 in np.arange(-2,47,2.0):
    s=m&(x>=x0)&(x<x0+2)
    if s.sum()>8: 
        # centre = midpoint between 5th and 95th percentile of y (rib band), half-width
        lo,hi=np.percentile(y[s],[3,97]); P.append((x[s].mean(),(lo+hi)/2,(hi-lo)))
P=np.array(P); print(np.round(P,2))
cx,cy,R,rms=circle_fit(P[:,:2]); print("circle centreline: centre",round(cx,2),round(cy,2),"R",round(R,2),"rms",round(rms,3))
# line fit
A=np.c_[P[:,0],np.ones(len(P))]; s_=np.linalg.lstsq(A,P[:,1],rcond=None)[0]; print("line rms",np.sqrt(np.mean((A@s_-P[:,1])**2)))
