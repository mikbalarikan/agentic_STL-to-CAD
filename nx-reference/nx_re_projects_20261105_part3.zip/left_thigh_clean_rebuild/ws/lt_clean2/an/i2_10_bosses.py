from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
rows = []
def col_robust(cc, nom=7.5):
    """column radius from angular sector medians (arms/fillets excluded)"""
    r = np.hypot(c[:, 0] - cc[0], c[:, 1] - cc[1]); th = np.degrees(np.arctan2(c[:, 1] - cc[1], c[:, 0] - cc[0])) % 360
    m = (np.abs(n[:, 2]) < 0.4) & (r > nom - 0.7) & (r < nom + 0.7) & (c[:, 2] > 37.5) & (c[:, 2] < 58) & (d >= 2.0)
    meds = []
    for k in range(24):
        s = m & (th >= k * 15) & (th < k * 15 + 15)
        if s.sum() > 40: meds.append((k * 15 + 7.5, wmed(r[s], a[s]), float(np.std(r[s])), int(s.sum())))
    return meds
for bid, (x, y) in DS.BOSSES.items():
    col = cyl_fit((x, y), 6.8, 8.6, 37.0, 58.0)
    cc = (col["cx"], col["cy"]) if col else (x, y)
    meds = col_robust(cc, col["r"] if col else 7.5)
    rr = np.array([mm[1] for mm in meds]) if meds else np.array([np.nan])
    # circle fit through the sector medians (position + diameter robust against arms)
    pts = np.array([[cc[0] + mm[1] * np.cos(np.radians(mm[0])), cc[1] + mm[1] * np.sin(np.radians(mm[0]))] for mm in meds]) if len(meds) > 5 else None
    if pts is not None:
        cx, cy, rad0, rms = circle_fit(pts); cc = (cx, cy)
        rad = float(np.percentile(rr, 20))   # fillets / arm roots only add: the low sectors are the free cylinder
    else: rad = col["r"] if col else np.nan; rms = np.nan
    r = np.hypot(c[:, 0] - cc[0], c[:, 1] - cc[1])
    pk = cyl_fit(cc, 4.4, 5.8, 36.6, 38.9); cb = cyl_fit(cc, 4.4, 6.0, 45.6, 70, de_min=0.3); bo = cyl_fit(cc, 2.5, 4.0, 39.6, 44.6)
    # levels: boss end face (nz<0, r 5.8..7.2), pocket floor, cbore floor (nz>0)
    face = level_fit((r > 5.8) & (r < 7.2) & (n[:, 2] < -0.9) & (c[:, 2] < 37.5) & (c[:, 2] > 34.5) & (d > 1))
    pfl = level_fit((r < 4.6) & (n[:, 2] < -0.9) & (c[:, 2] > 38.2) & (c[:, 2] < 40.5) & (d > 1))
    cfl = level_fit((r > 3.4) & (r < 5.0) & (n[:, 2] > 0.9) & (c[:, 2] > 43.5) & (c[:, 2] < 47) & (d > 0.3))
    # rows
    mcol = (c[:, 2] > 35.0) & (d >= 2.0) & (((np.abs(n[:, 2]) < 0.6) & (np.abs(r - rad) < 0.8)) | ((n[:, 2] < -0.9) & (r > 5.6) & (r < rad + 0.5) & (c[:, 2] < 37.5)))
    mpk = (r < 5.6) & (c[:, 2] > 35.0) & (c[:, 2] < 39.4) & (d >= 2.0)
    mbo = (r < 5.6) & (c[:, 2] >= 39.4) & (d >= 1.0) & ((np.abs(n[:, 2]) < 0.7) | ((n[:, 2] > 0.9) & (c[:, 2] < 47)))
    p5 = dict(D=15.0, centre=[x, y], face_z=36.07)
    rows.append(make_row(f"{bid}_col", "boss_col", dict(centre=[cc[0], cc[1]], D=2 * rad, draft_deg=col["draft_deg"] if col else None, face_z=face["z"] if face else None, z_bottom=col["z_lo"] if col else None, sector_r_min=float(rr.min()), sector_r_max=float(rr.max())),
                         "circle fit through 15-deg sector medians of the horizontal wall (arm sectors excluded)", rms, mcol, p5))
    p5p = dict(D=DS.POCKET_D, floor_z=DS.POCKET_FLOOR, centre=[x, y])
    rows.append(make_row(f"{bid}_pocket", "pocket", dict(centre=[pk["cx"], pk["cy"]] if pk else None, D=pk["D"] if pk else None, taper_deg=pk["draft_deg"] if pk else None, floor_z=pfl["z"] if pfl else None),
                         "cylinder fit horizontal wall z 36.6..38.9 + floor level (nz<-0.9)", pk["rms"] if pk else None, mpk, p5p))
    p5b = dict(bore_D=DS.SCREW_D, cbore_D=DS.CBORE_D, cbore_floor_z=DS.CBORE_FLOOR)
    rows.append(make_row(f"{bid}_bore", "bore_cbore", dict(bore_D=bo["D"] if bo else None, bore_centre=[bo["cx"], bo["cy"]] if bo else None, cbore_D=cb["D"] if cb else None, cbore_centre=[cb["cx"], cb["cy"]] if cb else None, cbore_floor_z=cfl["z"] if cfl else None),
                         "cylinder fits bore z 39.6..44.6, cbore z>45.6; cbore floor level (nz>0.9)", (bo or {}).get("rms"), mbo, p5b))
dump("bosses", rows)
