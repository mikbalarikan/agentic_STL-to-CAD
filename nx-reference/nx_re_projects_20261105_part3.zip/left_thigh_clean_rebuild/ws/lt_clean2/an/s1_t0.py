from s1_geo import *
import m2_loft as L
d=np.load('work/s1/loft_K1.npz'); st=d['st']; P=d['P']
# compare OCC curve with M2 formula
c=bspline_section(P[5],10.0)
t=np.array([0.0,0.37,1.2,5.0,17.3])
for tt in t:
    p=c.Value(tt); print(tt,(p.X(),p.Z()))
B=L.bbasis(np.array([0.0,1/72,2/72]),72); print((B@P[5])[:3])
print(c.FirstParameter(),c.LastParameter(),c.IsPeriodic())
