import sys,os,json,time
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_g_fit as G, m2_loft as L, m2_f_data as FD, trimesh
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
st=[float(s) for s in sys.argv[1].split(",")]; tag=sys.argv[2]
lf,keep,sr=G.run(st,40)
np.savez(f"work/m2/loft_{tag}.npz",st=st,P=lf.P)
V,F,ys,u=G.mesh_of(lf,st[0],st[-1])
S=G.scan_pts(max(st[0],60),st[-1]); d=G.dist_to(V,F,S[:,:3])
print("loft",[round(100*G.stats(d,S[:,3])[0],1),*np.round(G.stats(d,S[:,3])[1:],3)])
m5=trimesh.load("work/env_part5.stl",process=False)
d5=G.dist_to(np.asarray(m5.vertices),np.asarray(m5.faces),S[:,:3]); print("part5",[round(100*G.stats(d5,S[:,3])[0],1),*np.round(G.stats(d5,S[:,3])[1:],3)])
np.savez(f"work/m2/dev_{tag}.npz",S=S,d=d,d5=d5)
th=np.degrees(np.arctan2(S[:,2]-FD.CZ0,S[:,0]-FD.CX0))
fig,axs=plt.subplots(1,2,figsize=(22,14))
for ax,dd,t in zip(axs,(d,d5),("loft "+tag,"part 5 envelope")):
    sc=ax.scatter(th,S[:,1],c=dd,s=1,cmap='jet',vmin=0,vmax=1.0); ax.set_title(t); ax.set_xlabel("theta deg (0=+X, 90=+Z)"); ax.set_ylabel("Y"); ax.grid(True)
plt.colorbar(sc,ax=axs); plt.savefig(f"work/m2/devmap_{tag}.png",dpi=55)
