"""P4 fix 1: panel points (y, theta, r) for out / inn + probes + run-out plane -> nx/A_v2/panel_pts.json"""
import numpy as np, json, math
import open3d as o3d
mesh = o3d.io.read_triangle_mesh(r"nx/base_v2/envelope.stl")
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mesh))
hx, hz = 37.97, 35.18
fit = json.load(open("work/r1/panel_fit.json"))
Y = list(fit["y"]); TH = list(fit["theta"])
if Y[-1] > 261.5: Y, TH = Y[:-1], TH[:-1]          # last knot sits on the y1 plane
assert abs(Y[0] - 53.5) < 1e-9 and abs(Y[-1] - 261.5) < 1e-9, (Y[0], Y[-1])
PAD = 3.0
s0 = (TH[1] - TH[0]) / (Y[1] - Y[0]); s1 = (TH[-1] - TH[-2]) / (Y[-1] - Y[-2])
ye = [Y[0] - PAD] + Y + [Y[-1] + PAD]; the = [TH[0] - s0 * PAD] + TH + [TH[-1] + s1 * PAD]
def rad(y, th, sgn):
    t = math.radians(th)
    ray = o3d.core.Tensor([[hx, y, hz, math.cos(t), 0.0, -sgn * math.sin(t)]], dtype=o3d.core.Dtype.Float32)
    return float(sc.cast_rays(ray)["t_hit"].numpy()[0])
out = {"pad": PAD, "hx": hx, "hz": hz, "design_y": Y, "design_theta": TH, "theta_min": -4.0, "theta_max": 62.0,
       "plane": json.load(open("work/r1/runout_plane.json"))}
for name, sgn in (("out", 1), ("inn", -1)):
    out[name] = {"sgn": sgn, "pts": [{"y": y, "theta": round(t, 4), "r": round(rad(y, t, sgn), 4), "design": (0 < i < len(ye) - 1)} for i, (y, t) in enumerate(zip(ye, the))]}
    pr = []
    for y in (48.0, 53.0, 80.0, 110.0, 150.0, 200.0, 240.0, 252.0, 258.0, 262.2, 265.0):
        for th in (-14.0, -4.0, 0.5, 2.0, 3.0, 6.0, 10.0, 20.0, 25.0, 50.0, 56.0, 75.0):
            pr.append({"y": y, "theta": th, "r": round(rad(y, th, sgn), 4)})
    out[name]["probes"] = pr
    print(name, [(p["y"], p["theta"], p["r"]) for p in out[name]["pts"]])
json.dump(out, open("nx/A_v2/panel_pts.json", "w"), indent=1)
