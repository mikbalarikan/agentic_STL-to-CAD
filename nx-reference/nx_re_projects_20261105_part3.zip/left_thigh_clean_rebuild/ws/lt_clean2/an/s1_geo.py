"""OCP helpers: periodic cubic B-spline sections, ThruSections loft, drum revolve, booleans, meshing."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from OCP.gp import gp_Pnt, gp_Ax2, gp_Dir, gp_Ax1
from OCP.TColgp import TColgp_Array1OfPnt
from OCP.TColStd import TColStd_Array1OfReal, TColStd_Array1OfInteger
from OCP.Geom import Geom_BSplineCurve
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeEdge, BRepBuilderAPI_MakeWire, BRepBuilderAPI_MakeFace, BRepBuilderAPI_MakePolygon
from OCP.BRepOffsetAPI import BRepOffsetAPI_ThruSections
from OCP.BRepPrimAPI import BRepPrimAPI_MakeRevol, BRepPrimAPI_MakeCone, BRepPrimAPI_MakeBox
from OCP.BRepAlgoAPI import BRepAlgoAPI_Fuse, BRepAlgoAPI_Common, BRepAlgoAPI_Cut
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.StlAPI import StlAPI_Writer
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.ShapeFix import ShapeFix_Shape
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.TopTools import TopTools_ListOfShape

def bspline_section(P, y):
    """P (N,2) poles (x,z) -> closed periodic cubic uniform B-spline curve at plane Y=y (curve in 3D: x, y, z)."""
    N = len(P)
    poles = TColgp_Array1OfPnt(1, N)
    for i, (x, z) in enumerate(P): poles.SetValue(i + 1, gp_Pnt(float(x), float(y), float(z)))
    knots = TColStd_Array1OfReal(1, N + 1); mults = TColStd_Array1OfInteger(1, N + 1)
    for i in range(N + 1): knots.SetValue(i + 1, float(i)); mults.SetValue(i + 1, 1)
    return Geom_BSplineCurve(poles, knots, mults, 3, True)

def section_wire(P, y):
    c = bspline_section(P, y)
    e = BRepBuilderAPI_MakeEdge(c).Edge()
    return BRepBuilderAPI_MakeWire(e).Wire()

def loft(Ps, ys, solid=True, ruled=False):
    ts = BRepOffsetAPI_ThruSections(solid, ruled, 1e-6)
    ts.SetSmoothing(False); ts.SetContinuity(__import__('OCP.GeomAbs', fromlist=['GeomAbs_C2']).GeomAbs_C2)
    ts.SetMaxDegree(8)
    for P, y in zip(Ps, ys): ts.AddWire(section_wire(P, y))
    ts.Build()
    return ts.Shape()

def drum_profile(R0=68.85, zp=36.07, dr=1.6, zt=83.6, zb=-13.9, ct=3.1, cb=3.3):
    t = np.tan(np.radians(dr)); R = lambda z: R0 - t * abs(z - zp)
    return [(0, zb), (R(zb) - cb, zb), (R(zb + cb), zb + cb), (R0, zp), (R(zt - ct), zt - ct), (R(zt) - ct, zt), (0, zt)]

def drum(**kw):
    pr = drum_profile(**kw)
    poly = BRepBuilderAPI_MakePolygon()
    for r, z in pr: poly.Add(gp_Pnt(r, 0, z))
    poly.Close()
    face = BRepBuilderAPI_MakeFace(poly.Wire()).Face()
    return BRepPrimAPI_MakeRevol(face, gp_Ax1(gp_Pnt(0, 0, 0), gp_Dir(0, 0, 1))).Shape()

def fuse(a, b, fuzzy=None):
    op = BRepAlgoAPI_Fuse(a, b)
    if fuzzy: op.SetFuzzyValue(fuzzy)
    op.Build(); return op.Shape()
def common(a, b, fuzzy=None):
    op = BRepAlgoAPI_Common(a, b)
    if fuzzy: op.SetFuzzyValue(fuzzy)
    op.Build(); return op.Shape()
def cut(a, b):
    op = BRepAlgoAPI_Cut(a, b); op.Build(); return op.Shape()

def volume(s):
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g); return g.Mass()
def valid(s): return BRepCheck_Analyzer(s).IsValid()

def to_mesh(shape, lin=0.05, ang=0.1):
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_FACE
    from OCP.BRep import BRep_Tool
    from OCP.TopLoc import TopLoc_Location
    from OCP.TopoDS import TopoDS
    BRepMesh_IncrementalMesh(shape, lin, False, ang, True)
    V = []; F = []; n0 = 0
    ex = TopExp_Explorer(shape, TopAbs_FACE)
    while ex.More():
        f = TopoDS.Face_s(ex.Current()); loc = TopLoc_Location()
        tri = BRep_Tool.Triangulation_s(f, loc)
        if tri is not None:
            tr = loc.Transformation()
            pts = []
            for i in range(1, tri.NbNodes() + 1):
                p = tri.Node(i).Transformed(tr); pts.append((p.X(), p.Y(), p.Z()))
            rev = f.Orientation().name == 'TopAbs_REVERSED'
            for i in range(1, tri.NbTriangles() + 1):
                a, b, c = tri.Triangle(i).Get()
                F.append((a - 1 + n0, c - 1 + n0, b - 1 + n0) if rev else (a - 1 + n0, b - 1 + n0, c - 1 + n0))
            V += pts; n0 += len(pts)
        ex.Next()
    return np.array(V), np.array(F)

def save_stl(shape, path, lin=0.03, ang=0.05):
    BRepMesh_IncrementalMesh(shape, lin, False, ang, True)
    w = StlAPI_Writer(); w.ASCIIMode = False; w.Write(shape, path)
