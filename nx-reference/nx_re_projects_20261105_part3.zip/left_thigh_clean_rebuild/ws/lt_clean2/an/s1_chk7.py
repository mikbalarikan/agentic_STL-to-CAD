from s1_eval import *
import trimesh, s1_conedef as CD
m=trimesh.load(os.path.join(S1,'env_H5.stl'),process=False); v,f=np.asarray(m.vertices),np.asarray(m.faces)
import open3d as o3d
sc=o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(v.astype(np.float32)),o3d.core.Tensor(f.astype(np.uint32)))
HX,HZ=37.97,35.18
phi=np.degrees(np.arctan2(z-HZ,x-HX))
print('Y   scan_x(med, phi+-3)  env_x(ray from (30,Y,HZ) +X)  cone_x')
for Y in [240,246,250,254,257,259,260,261,262,263,264,265,266,268,272]:
    q=(np.abs(y-Y)<0.6)&(np.abs(phi)<3)
    if q.sum()<3: continue
    t=sc.cast_rays(o3d.core.Tensor(np.array([[60,Y,HZ,1,0,0]],np.float32)))['t_hit'].numpy()[0]
    xc,_=CD.ray_point(Y,0.0,0.0,CX0=40.0,CZ0=HZ)
    print(Y,round(np.median(x[q]),2),round(60+float(t),2),round(xc,2),'  n',q.sum())
