import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,axs=plt.subplots(2,2,figsize=(18,10))
for r,(scan,key) in enumerate((("out_scan","out"),("inn_scan","inn"))):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    z=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz")); dot=z["dot"]; d=z["d"]
    th=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))
    band=np.zeros(len(c),bool); band[np.load(os.path.join(lib.W,"masks",f"{key}_band.npy"))]=1
    m=band&(dot>0)
    print(key,"ext-facing band n",m.sum(),"depth pct",np.round(np.percentile(d[m],[10,50,90]),2))
    ax=axs[r,0]; s=ax.scatter(c[m,1],th[m],s=1,c=d[m],cmap='jet',vmin=1,vmax=2.4); ax.set_title(f"{key} ext-facing band, y vs theta, colour depth below env"); plt.colorbar(s,ax=ax)
    # all exterior facing tris with d>0.3 too
    m2=(dot>0)&(d>0.5)&(d<4)
    ax=axs[r,1]; s=ax.scatter(c[m2,1],th[m2],s=1,c=d[m2],cmap='jet',vmin=0.5,vmax=3); ax.set_title("all ext-facing 0.5<d<4"); plt.colorbar(s,ax=ax)
plt.savefig(os.path.join(lib.W,"m5","ext_map.png"),dpi=60)
