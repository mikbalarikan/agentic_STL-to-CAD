import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from scipy.optimize import least_squares
HX,HZ=37.97,35.18
D=np.load("work/m3/ext_pts.npz"); P=D['P']
def design(X):
    x,y,z=X.T
    return np.stack([x*x,y*y,z*z,x*y,x*z,y*z,x,y,z,np.ones(len(x))],1)
def sampson(co,X):
    x,y,z=X.T; q=design(X)@co
    gx=2*co[0]*x+co[3]*y+co[4]*z+co[6]; gy=2*co[1]*y+co[3]*x+co[5]*z+co[7]; gz=2*co[2]*z+co[4]*x+co[5]*y+co[8]
    return q/np.maximum(np.sqrt(gx**2+gy**2+gz**2),1e-12)
O=np.array([HX,260.0,HZ])
for ylo in (270,274,266,262):
    k=(P[:,1]>ylo)&(P[:,1]<287.0)&(abs(P[:,2]-HZ)>4); X=(P[k]-O)/50.0
    u,sv,vt=np.linalg.svd(design(X),full_matrices=False); co=vt[-1]
    f=lambda c: sampson(c/np.linalg.norm(c[:3]),X)*50
    co=least_squares(f,co).x; co/=np.linalg.norm(co[:3]); e=f(co)
    A=np.array([[co[0],co[3]/2,co[4]/2],[co[3]/2,co[1],co[5]/2],[co[4]/2,co[5]/2,co[2]]])
    w,V=np.linalg.eigh(A); cen=np.linalg.solve(2*A,-co[6:9]) if abs(np.linalg.det(A))>1e-9 else None
    print('Y>%d n=%d  quadric Sampson res std %.3f mm  p95 %.3f'%(ylo,k.sum(),e.std(),np.percentile(abs(e),95)))
    print('   eigenvalues',w.round(4),'det',np.linalg.det(A).round(6))
    if cen is not None:
        qc=co[9]+0.5*co[6:9]@cen
        print('   centre (mm)',(cen*50+O).round(2),' semi-axes if ellipsoid:',np.sqrt(np.abs(-qc/w))*50, 'axes dirs',V.round(3).tolist())
