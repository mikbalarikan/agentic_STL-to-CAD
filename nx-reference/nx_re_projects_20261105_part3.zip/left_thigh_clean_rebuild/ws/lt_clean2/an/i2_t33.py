from i2_sec import *
from i2_view import show
v,f=mesh("scan"); vp,fp=mesh("p5"); vo,fo=mesh("old")
show("v_pk",30,95,0,75,12,'z',(36,85),mask=np.ones(1499999,bool),size=11)
fig,axs=plt.subplots(1,3,figsize=(24,8))
for ax,(y0,xl,zl) in zip(axs,((20.0,(30,95),(30,95)),(30.0,(30,95),(30,95)),(40.0,(30,95),(30,95)))):
    for (vv,ff,col,lw) in ((vo,fo,'g',1.0),(vp,fp,'r',1.2),(v,f,'k',1.0)):
        for seg in lib.section(vv,ff,1,float(y0)): ax.plot(seg[:,0],seg[:,2],col+'-',lw=lw)
    ax.set_xlim(*xl); ax.set_ylim(*zl); ax.set_aspect('equal'); ax.grid(alpha=.3); ax.set_title(f"y={y0}")
plt.tight_layout(); plt.savefig(os.path.join(O,"pk_secs.png"),dpi=55)
