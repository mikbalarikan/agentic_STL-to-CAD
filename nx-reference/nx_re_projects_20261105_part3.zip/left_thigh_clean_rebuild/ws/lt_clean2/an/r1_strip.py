import sys, numpy as np
sys.path.insert(0,'an'); import lib
w, tags = sys.argv[1], sys.argv[2:]
sg = 1 if w == "out" else -1
v,f=lib.load(w+"_scan",1500000); c,nn,ar=lib.tri_data(v,f)
th=np.degrees(np.arctan2(-sg*(c[:,2]-35.18), c[:,0]-37.97))
for lo,hi,name in ((258.9,262.5,"end strip y 258.9-262.5"),(250,258.9,"ramp y 250-258.9"),(52.5,54.5,"start strip y 52.5-54.5")):
    m=(c[:,1]>lo)&(c[:,1]<hi)&(th>2)&(th<14)&(c[:,0]>60)
    # only exterior skin triangles: near base envelope surface (distance<3) via normals pointing out
    nout=(nn[:,0]*(c[:,0]-37.97)+nn[:,2]*(c[:,2]-35.18))>0
    m&=nout
    m&=(np.load(f'work/dev_{tags[0]}_{w}.npz')['de']<3.0)
    print(name, "n", m.sum(), " ".join(f"{t}: {100*ar[m&(np.load(f'work/dev_{t}_{w}.npz')['d1']<0.5)].sum()/ar[m].sum():.1f}%" for t in tags))
