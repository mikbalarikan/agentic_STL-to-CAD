from i1_common import *
from i1_rib import *
import ref5_design as DS, sys
S = load_all(); c,n,a,de=S['c'],S['n'],S['a'],S['de']
def prof(nm,p0,p1,t0,step=6,win=None):
    p,e,nu,L=frame(p0,p1); s,u=local(c,p,e,nu); win=win or t0/2+4
    base=(abs(u)<win)&(de>3.0)&~excl_mask(c)
    print(nm,"L=%.0f"%L)
    for s0 in np.arange(0,L,step):
        m=base&(s>=s0)&(s<s0+step)
        top=m&(n[:,2]>0.9)&(abs(u)<t0/2)
        zt=np.median(c[top,2]) if top.sum()>5 else np.nan
        nu3=nu[0]*n[:,0]+nu[1]*n[:,1]
        wr=m&(nu3>0.9)&(u>0)&(abs(n[:,2])<.3); wl=m&(nu3<-0.9)&(u<0)&(abs(n[:,2])<.3)
        ur=np.median(u[wr]) if wr.sum()>5 else np.nan; ul=np.median(u[wl]) if wl.sum()>5 else np.nan
        # height of walls
        zr=(c[wr,2].min(),c[wr,2].max()) if wr.sum()>5 else (np.nan,np.nan)
        print("  s %5.1f top z %7.2f (%4d) uL %6.2f uR %6.2f t %5.2f  wallR z %6.1f..%6.1f"%(s0+step/2,zt,top.sum(),ul,ur,ur-ul,*zr))
for nm in sys.argv[1:]:
    if nm in DS.OUT_RIBS: a_,b_,top,t=DS.OUT_RIBS[nm]; prof(nm,a_,b_,t)
    elif nm in DS.OUT_GUSSETS: a_,b_,z0,z1,t=DS.OUT_GUSSETS[nm]; prof(nm,a_,b_,t)
    elif nm in DS.ARMS: a_,b_,_=DS.ARMS[nm]; prof(nm,a_,_[0],3.0)
