"""Tail wall: open cubic B-spline sections (clamped) at Y stations, fitted to the free-standing wall; sheet loft."""
import sys
from s1_eval import *
from scipy.interpolate import make_lsq_spline, BSpline
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
NPL = 12
Ys = [-50.8, -47.0, -43.5, -40.0, -38.0]
def Rw(z): return 68.8588 - np.tan(np.radians(1.6)) * np.abs(np.clip(z, -13.9, 83.6) - 36.07)
sel = (y > -52) & (y < -36.5) & (z < 84.2) & ((zones['knee_tail(Y<-34)']) | (none & (y >= -37) & (y < -36.5) & ~foot))
sel &= np.hypot(x, y) > Rw(z) + 1.2
Q = P[sel]; print(len(Q))
def fit_station(Y, w=0.8):
    q = Q[np.abs(Q[:, 1] - Y) < w]
    zc = {-50.8: 55, -47.0: 62, -43.5: 61.0, -40.0: 62, -38.0: 62}[Y]; q = q[q[:, 2] < zc]
    if Y == -43.5: q = q[~((q[:, 0] < 66.5) & (q[:, 2] > 40))]
    th = np.arctan2(q[:, 2] - 35, q[:, 0] - 40)
    # cell medians in 2deg bins to equalize density
    b = np.round(np.degrees(th) / 2).astype(int); out = []
    for k in np.unique(b):
        m = b == k
        if m.sum() >= 2: out.append((np.degrees(th[m]).mean(), np.median(q[m, 0]), np.median(q[m, 2])))
    out = np.array(sorted(out))
    t = (out[:, 0] - out[0, 0]) / (out[-1, 0] - out[0, 0])
    knots = np.r_[[0] * 4, np.linspace(0, 1, NPL - 2)[1:-1], [1] * 4]
    spl = make_lsq_spline(t, out[:, 1:3], knots, k=3)
    res = np.linalg.norm(spl(t) - out[:, 1:3], axis=1)
    return spl, out, res
poles = []
fig, ax = plt.subplots(1, len(Ys), figsize=(5 * len(Ys), 8))
for a, Y in zip(ax, Ys):
    spl, out, res = fit_station(Y); poles.append(spl.c); 
    tt = np.linspace(0, 1, 200); c = spl(tt)
    a.plot(out[:, 1], out[:, 2], 'k.', ms=3); a.plot(c[:, 0], c[:, 1], 'r-'); a.set_aspect('equal'); a.set_title(f'Y={Y} res max {res.max():.2f} n {len(out)}')
    print(Y, len(out), 'ang', out[0, 0].round(1), out[-1, 0].round(1), 'res max', res.max().round(3), 'rms', np.sqrt((res**2).mean()).round(3))
plt.tight_layout(); plt.savefig(os.path.join(S1, 'tail_fit.png'), dpi=45)
np.savez(os.path.join(S1, 'tail_poles.npz'), Ys=Ys, P=np.array(poles))
