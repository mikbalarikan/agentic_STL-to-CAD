import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, trimesh
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
env = trimesh.load(os.path.join(lib.W,"env_part5.stl"), process=False)
ev,ef=np.asarray(env.vertices),np.asarray(env.faces)
key,scan,cad=sys.argv[1],sys.argv[2],sys.argv[3]; Zs=eval(sys.argv[4]); xl=eval(sys.argv[5]); yl=eval(sys.argv[6])
v,f=lib.load(scan,1500000); cv,cf=lib.load(cad); c,nn,ar=lib.tri_data(v,f)
band=np.load(os.path.join(lib.W,"masks",f"{key}_band.npy")); dot=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["dot"]
fig,axs=plt.subplots(1,len(Zs),figsize=(7*len(Zs),11))
for ax,Z in zip(np.atleast_1d(axs),Zs):
    for (vv,ff,col,lw) in ((cv,cf,"b",2.5),(ev,ef,"r",1.2),(v,f,"k",.8)):
        for a,b in lib.section(vv,ff,2,Z): ax.plot([a[0],b[0]],[a[1],b[1]],col,lw=lw)
    sel=band[np.abs(c[band,2]-Z)<1.0]
    ax.scatter(c[sel,0],c[sel,1],s=8,c=np.where(dot[sel]>0,'g','m'),zorder=5)
    ax.set_xlim(*xl);ax.set_ylim(*yl);ax.set_aspect('equal');ax.grid(alpha=.3);ax.set_title(f"{key} Z={Z}")
plt.tight_layout();plt.savefig(os.path.join(lib.W,"m5",sys.argv[7]),dpi=60)
