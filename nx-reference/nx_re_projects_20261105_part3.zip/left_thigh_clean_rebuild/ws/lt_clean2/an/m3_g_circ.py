import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
HX,HZ=37.97,35.18
D=np.load("work/m3/ext_pts.npz"); P=D['P']
def circfit(x,z):
    def fn(p): return np.hypot(x-p[0],z-p[1])-p[2]
    p=least_squares(fn,[HX,HZ,np.hypot(x-HX,z-HZ).mean()]).x
    return p, fn(p)
print("circle fit of exterior skin in Y slabs (both scans), centre free")
for y in np.arange(250,288,3.0):
    k=abs(P[:,1]-y)<0.6
    p,res=circfit(P[k,0],P[k,2])
    print("Y%.1f n=%d c=(%.2f,%.2f) R=%.2f  res std %.2f p2p %.2f"%(y,k.sum(),p[0],p[1],p[2],res.std(),np.ptp(res)))
for y in (286.5,287.0,287.3):
    k=abs(P[:,1]-y)<0.25
    p,res=circfit(P[k,0],P[k,2]); print("Y%.2f"%y,p.round(3),res.std().round(3),k.sum())
# mouth-face outer edge
for n,tag,zs in (('out_scan','out',lambda z:z<34),('inn_scan','inn',lambda z:z>37)):
    v,f=lib.load(n,1500000); c,nn,a=lib.tri_data(v,f)
    m=(c[:,1]>286.8)&(abs(nn[:,1])>0.9)&zs(c[:,2])
    th=np.degrees(np.arctan2(c[m,2]-HZ,c[m,0]-HX)); r=np.hypot(c[m,0]-HX,c[m,2]-HZ)
    print(tag,'mouth face outer/inner edge r by angle:')
    for t in range(-180,181,30):
        k=abs(th-t)<10
        if k.sum()>20: print('  th',t,'r_out %.2f r_in %.2f'%(np.percentile(r[k],98),np.percentile(r[k],2)))
    p,res=circfit(c[m,0][r>69.8],c[m,2][r>69.8]); print('  outer edge circle',p.round(3),res.std().round(3))
    p,res=circfit(c[m,0][r<68.5],c[m,2][r<68.5]); print('  inner edge circle',p.round(3),res.std().round(3))
