import sys; sys.path.insert(0,"an")
from v5e_occ import *
from sklearn.cluster import DBSCAN
so=scene("nx/P5d/out_P5d_final.stl"); si=scene("nx/P5d/inn_P5d_final.stl")
rng=np.random.default_rng(11)
lo=np.array([-70,-70,33.0]); hi=np.array([125,292,46.0]); vol=np.prod(hi-lo)
tot=0; hit=[]; N=0
for _ in range(10):
    p=lo+rng.random((1000000,3))*(hi-lo); N+=len(p)
    a=occ(so,p); 
    if a.any():
        b=occ(si,p[a]); hit.append(p[a][b])
H=np.vstack(hit) if hit else np.zeros((0,3))
print("points",N,"hits",len(H),"overlap vol mm3 %.1f"%(len(H)/N*vol),"(point volume %.2f mm3 each)"%(vol/N))
if len(H):
    lab=DBSCAN(eps=4,min_samples=1).fit_predict(H)
    for l in np.unique(lab):
        k=H[lab==l]; print("  cluster n%d vol %.1f bbox"%(len(k),len(k)/N*vol),k.min(0).round(1),k.max(0).round(1))
