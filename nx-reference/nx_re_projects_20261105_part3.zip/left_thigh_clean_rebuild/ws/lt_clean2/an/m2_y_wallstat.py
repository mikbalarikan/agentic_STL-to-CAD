import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_o_fitband as B
d=np.load("work/m2/wall_U72.npz"); ys=d["ys"]; T=d["T"]; P=d["P"]
th=np.degrees(np.arctan2(P[...,2]-35,P[...,0]-40))
band=np.abs(th)<B.edge(ys)[:,None]-3
out=~band&np.isfinite(T); inb=band&np.isfinite(T)
res={}
for nm,m in (("outside_band",out),("band",inb)):
    x=T[m]; res[nm]=dict(n=int(len(x)),median=float(np.median(x)),p10=float(np.percentile(x,10)),p90=float(np.percentile(x,90)),
        frac_pm035=float((abs(x-np.median(x))<0.35).mean()),frac_3p1_pm035=float((abs(x-3.1)<0.35).mean()))
    print(nm,res[nm])
# clean (plain wall) region: exclude thick (>3.5) neighbours -> median of clean
x=T[out]; c=x[(x<3.5)]; res["outside_band_plain"]=dict(median=float(np.median(c)),p05=float(np.percentile(c,5)),p95=float(np.percentile(c,95)),frac_of_valid=float(len(c)/len(x)))
print("plain wall (<3.5) outside band: median %.3f p05 %.3f p95 %.3f frac of valid %.2f"%(np.median(c),np.percentile(c,5),np.percentile(c,95),len(c)/len(x)))
# trend with Y of the plain wall
print("Y-trend of plain wall (outside band, 3.5>T):")
for lo in range(60,262,20):
    m=out&(ys[:,None]>=lo)&(ys[:,None]<lo+20)&(T<3.5)
    if m.sum()>50: print(lo,"median %.3f p10 %.3f p90 %.3f"%(np.median(T[m]),*np.percentile(T[m],[10,90])))
print("sector trend (outside band, plain):")
for nm,(a,b) in (("top 45..135",(45,135)),("-X |th|>135",(135,181)),("bottom -135..-45",(-135,-45))):
    m=out&(T<3.5)&((np.abs(th)>=135) if nm.startswith("-X") else ((th>=a)&(th<b)))
    print(nm,"median %.3f p10 %.3f p90 %.3f n=%d"%(np.median(T[m]),*np.percentile(T[m],[10,90]),m.sum()))
# thick areas: grid
print("thick (>3.5) fraction outside band by 45deg sector x 40 mm Y:")
uu=np.mod(np.degrees(np.arctan2(P[...,2]-35,P[...,0]-40)),360)
for lo in range(60,262,40):
    row=[]
    for s in range(0,360,45):
        m=out&(ys[:,None]>=lo)&(ys[:,None]<lo+40)&(uu>=s)&(uu<s+45)
        row.append("%.2f"%((T[m]>3.5).mean() if m.sum() else np.nan))
    print(lo,row)
json.dump(res,open("work/m2/wall_stats.json","w"),indent=1)
