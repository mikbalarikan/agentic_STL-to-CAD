import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_loft as L, m2_g_fit as G, m2_f_data as FD, m2_o_fitband as B, m2_q_env as Q
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
tag=sys.argv[1]
d=np.load(f"work/m2/loft_{tag}.npz"); st=d["st"]; lf=L.Loft(st,d["P"].shape[1],d["P"])
V,F,ys,u=G.mesh_of(lf,st[0],st[-1]); S=G.scan_pts(60,st[-1]); dd=G.dist_to(V,F,S[:,:3]); ib=B.inband(S[:,1],S[:,0],S[:,2],1.0)
# signed: positive when scan outside the loft: use radial compare
th=np.arctan2(S[:,2]-35,S[:,0]-40); r=np.hypot(S[:,0]-40,S[:,2]-35)
sg=np.zeros(len(S)); uu=np.linspace(0,1,1440,endpoint=False)
yy=np.round(S[:,1]/1.0)
for y0 in np.unique(yy):
    m=yy==y0; C=lf.curve(y0,uu)[0]; rc=np.hypot(C[:,0]-40,C[:,1]-35); tc=np.mod(np.arctan2(C[:,1]-35,C[:,0]-40),2*np.pi); o=np.argsort(tc)
    sg[m]=r[m]-np.interp(np.mod(th[m],2*np.pi),tc[o],rc[o],period=2*np.pi)
sd=np.sign(sg)*dd
np.savez(f"work/m2/sdev_{tag}.npz",S=S,sd=sd,ib=ib)
tdeg=np.degrees(th)
fig,ax=plt.subplots(1,1,figsize=(22,14))
sc=ax.scatter(tdeg,S[:,1],c=np.clip(sd,-1.2,1.2),s=1.2,cmap='seismic'); plt.colorbar(sc); ax.grid(True); ax.set_xlabel("theta (0=+X, 90=+Z)"); ax.set_ylabel("Y"); ax.set_title(f"signed dev scan - loft {tag} (red = scan outside)")
plt.savefig(f"work/m2/sdevmap_{tag}.png",dpi=50)
for lo,hi in ((60,70),(70,80),(80,100),(100,150),(150,200),(200,250),(250,256),(256,262)):
    m=(S[:,1]>=lo)&(S[:,1]<hi)&~ib; f,p90,p50=G.stats(dd[m],S[m,3]); print(lo,hi,"%.1f%% p90 %.3f n=%d"%(100*f,p90,m.sum()))
