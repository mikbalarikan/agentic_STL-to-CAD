import json, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter1d
fig, ax = plt.subplots(2, 2, figsize=(13, 8))
for i, w in enumerate(("out", "inn")):
    for j, n in enumerate("AB"):
        r = json.load(open(f"work/p5d/seam_{w}.json"))[n]; Q = np.array(r["Q"]); ok = np.array(r["ok"]) & (np.array(r["depth"]) > 0.35); s = np.array(r["s"])
        Q = Q[ok]; s = s[ok]
        # contiguous set only
        sm = np.c_[gaussian_filter1d(Q[:, 0], 3, mode="nearest"), gaussian_filter1d(Q[:, 1], 3, mode="nearest")]
        d = np.gradient(sm, axis=0); th = np.unwrap(np.arctan2(d[:, 1], d[:, 0]))
        ds = np.hypot(*d.T); ar = np.r_[0, np.cumsum(ds[:-1])]
        ax[i, j].plot(ar, np.degrees(th), ".-", ms=2); ax[i, j].set_title(f"{w} {n} heading deg vs arclen (station-based)"); ax[i, j].grid()
        print(w, n, "n", len(Q), "heading start %.1f end %.1f" % (np.degrees(th[0]), np.degrees(th[-1])), "first/last", Q[0].round(1), Q[-1].round(1))
plt.savefig("work/p5d/seam_heading.png", dpi=70)
