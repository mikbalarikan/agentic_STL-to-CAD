from i2_fit import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
def show(k,r,m):
    keep={kk:(np.round(vv,3) if isinstance(vv,(float,np.floating)) else vv) for kk,vv in r.items() if kk in("t","centre_off","free_z","free_slope_z_per_mm","fillet_R","fillet_rms","floor_z","u_ext","env_z0","env_zL","env_angle_deg","env_rms","draft_l","angle_deg","p0m","p1m")}
    print(k,keep,metrics(m))
for k,(p0,p1,z,t) in DS.INN_RIBS.items():
    r,m,_=rib2(p0,p1,t); show(k,r,m)
for k,(p0,p1,z0,z1,t) in DS.INN_GUSSETS.items():
    r,m,_=rib2(p0,p1,t,sloped=True); print("   nominal z0,z1",z0,z1); show(k,r,m)
for k,(a_,bo,bi) in DS.ARMS.items():
    r,m,_=rib2(a_,bi,3.0); show(k,r,m)
