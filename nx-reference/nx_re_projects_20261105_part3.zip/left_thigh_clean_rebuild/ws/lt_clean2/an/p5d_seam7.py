"""final seam path design values: greedy points + bounded LS refit (+-3 mm), rounded to 0.5 mm; report p50/p90/max to the measured centres. -> work/p5d/seam_paths.json"""
import json, numpy as np
from scipy.optimize import least_squares
exec(open("an/p5d_seam6.py").read().split("OUT = {}")[0])
CFG = {"A": (20, 215), "B": (0, 145)}
OUT = {}
for w in ("out", "inn"):
    for n, (smin, smax) in CFG.items():
        r = json.load(open(f"work/p5d/seam_{w}.json"))[n]; Q = np.array(r["Q"]); ok = np.array(r["ok"]) & (np.array(r["depth"]) > 0.35); s = np.array(r["s"])
        m = ok & (s <= smax) & (s >= smin); Q = Q[m]
        Qs = np.c_[gaussian_filter1d(Q[:, 0], 2, mode="nearest"), gaussian_filter1d(Q[:, 1], 2, mode="nearest")]
        idx = [0, len(Qs) - 1]
        for it in range(12):
            K = Qs[sorted(idx)]; e = dist_poly(Q, spl(K))
            if np.percentile(e, 90) < 0.3 and e.max() < 0.8: break
            wi = int(np.argmax(e))
            if wi in idx: break
            idx.append(wi)
        K0 = Qs[sorted(idx)]
        if n == 'B' and len(K0) < 5:
            K0 = Qs[np.linspace(0, len(Qs) - 1, 5).astype(int)]
        f = lambda X: dist_poly(Q, spl(X.reshape(-1, 2)))
        r_ = least_squares(f, K0.ravel(), bounds=(K0.ravel() - 3, K0.ravel() + 3))
        Kf = np.round(r_.x.reshape(-1, 2) * 2) / 2
        e = dist_poly(Q, spl(Kf))
        print(w, n, "k", len(Kf), "p50 %.2f p90 %.2f max %.2f" % (np.median(e), np.percentile(e, 90), e.max()), Kf.tolist())
        OUT[f"{w}_{n}"] = {"pts": Kf.tolist(), "p50": float(np.median(e)), "p90": float(np.percentile(e, 90)), "max": float(e.max()), "k": len(Kf), "nst": len(Q), "s_range": [smin, smax]}
json.dump(OUT, open("work/p5d/seam_paths.json", "w"), indent=1)
