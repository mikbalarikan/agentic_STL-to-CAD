import sys
from s1_shell import *
from s1_build import build, cone_solid
from s1_geo import *
tag=sys.argv[1]
env,lo,body,dr=build(tag,verbose=False)
def test(shape,name,mf,t=3.1,jn=GeomAbs_Arc):
    lst=TopTools_ListOfShape(); lst.Append(mf); mk=BRepOffsetAPI_MakeThickSolid(); t0=time.time()
    mk.MakeThickSolidByJoin(shape,lst,-t,1e-3,BRepOffset_Skin,True,False,jn); mk.Build()
    s=mk.Shape() if mk.IsDone() else None
    print(name,t,'done',mk.IsDone(),'valid',valid(s) if s else None,'vol',round(volume(s)) if s else None,'orig',round(volume(shape)),round(time.time()-t0,1),flush=True)
    return s
def cutY(shape,Yc):
    box=BRepPrimAPI_MakeBox(gp_Pnt(-300,-300,-300),gp_Pnt(500,Yc,300)).Shape()
    b=common(shape,box)
    for f in faces(b):
        a=BRepAdaptor_Surface(f)
        if a.GetType()==GeomAbs_Plane and abs(a.Plane().Location().Y()-Yc)<1e-3 and abs(a.Plane().Axis().Direction().Y())>0.99: return b,f
for Yc in [float(a) for a in sys.argv[2].split(',')]:
    b,f=cutY(env,Yc); test(b,f'env cut at {Yc}',f)
