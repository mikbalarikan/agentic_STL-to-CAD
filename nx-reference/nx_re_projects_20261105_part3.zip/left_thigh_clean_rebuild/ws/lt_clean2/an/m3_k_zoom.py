import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
e5=trimesh.load("work/env_part5.stl",process=False); ve,fe=np.asarray(e5.vertices),np.asarray(e5.faces)
S={n:(lib.load(n,1500000) if 'scan' in n else lib.load(n)) for n in('out_scan','inn_scan','out_cad','inn_cad')}
ys=[244,252,258,262,266,272]
fig,ax=plt.subplots(2,6,figsize=(30,10))
for j,y in enumerate(ys):
  for row,(xl,zl) in enumerate((((-50,-20),(-5,75)),((95,125),(-5,75)))):
    a=ax[row,j]
    for n,c,lw in (('out_scan','k',.8),('inn_scan','b',.8),('out_cad','r',.5),('inn_cad','m',.5)):
        for p,q in lib.section(*S[n],1,y): a.plot([p[0],q[0]],[p[2],q[2]],c+'-',lw=lw)
    for p,q in lib.section(ve,fe,1,y): a.plot([p[0],q[0]],[p[2],q[2]],'g-',lw=1)
    a.set_xlim(*xl); a.set_ylim(*zl); a.set_aspect('equal'); a.grid(True); a.set_title(f"Y={y}")
plt.tight_layout(); plt.savefig("work/m3/zoom_sides.png",dpi=50)
