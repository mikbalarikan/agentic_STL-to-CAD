import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
O = lib.load("out_scan", 1500000); I = lib.load("inn_scan", 1500000)
OC = lib.load("out_cad"); IC = lib.load("inn_cad")
cases = [("y=100 -X", 1, 100, (-48, -24)), ("y=0 +X", 1, 0, (72, 92)), ("y=220 +X", 1, 220, (104, 124)), ("y=250 -X", 1, 250, (-50, -30)),
         ("y=270 hip", 1, 270, (-50, -25)), ("x=0 knee", 0, 0, (-72, -58))]
fig, axs = plt.subplots(2, 3, figsize=(18, 10))
for ax, (nm, axis, val, rng) in zip(axs.ravel(), cases):
    for (v, f), colr, lw in ((O, "tab:blue", 1.0), (I, "tab:red", 1.0), (OC, "tab:cyan", 0.6), (IC, "tab:orange", 0.6)):
        s = lib.section(v, f, axis, val)
        h = 0 if axis == 1 else 1
        ax.add_collection(LineCollection(s[:, :, [h, 2]], colors=colr, lw=lw))
    ax.set_xlim(*rng); ax.set_ylim(30, 43); ax.set_aspect("equal"); ax.grid(lw=0.3); ax.set_title(nm)
fig.tight_layout(); fig.savefig(os.path.join(lib.W, "m4", "xsec.png"), dpi=60)
