import numpy as np, pyvista as pv, sys
pv.OFF_SCREEN = True
P = "nx/P5a/"
mo = pv.read(P + "out_P5a.stl"); mi = pv.read(P + "inn_P5a.stl")
def shot(name, mesh, pos, focal, par, up=(0, 0, 1), size=(1500, 1000), color="lightsteelblue", clim=None, axis=2):
    p = pv.Plotter(off_screen=True, window_size=size, lighting="none"); p.set_background("white")
    if clim:
        mesh = mesh.copy(); mesh["h"] = mesh.points[:, axis]
        p.add_mesh(mesh, scalars="h", clim=clim, cmap="coolwarm", show_scalar_bar=False, smooth_shading=False, specular=0.1, ambient=0.35, diffuse=0.65)
    else:
        p.add_mesh(mesh, color=color, smooth_shading=False, specular=0.1, ambient=0.35, diffuse=0.65)
    p.camera_position = [pos, focal, up]; p.camera.enable_parallel_projection(); p.camera.parallel_scale = par
    d = np.array(focal, float) - np.array(pos, float); d /= np.linalg.norm(d)
    side = np.cross(d, np.array(up, float)); side /= np.linalg.norm(side)
    u = np.cross(side, d)
    for k, (a, b, inten) in enumerate(((0.8, 0.7, 0.55), (-0.9, 0.2, 0.25), (0.1, -0.8, 0.2))):
        lp = np.array(focal, float) + 300 * (-d * 0.6 + side * a + u * b)
        p.add_light(pv.Light(position=tuple(lp), focal_point=tuple(focal), intensity=inten, light_type="scene light"))
    p.screenshot(P + name); p.close(); print(name)
# outer knee, seen from inside (from +Z down), colour = z
shot("p5a_out_knee_inside.png", mo, (10, 10, 400), (10, 10, 0), 105, up=(0, 1, 0), clim=(-14, 10))
shot("p5a_out_knee_inside_obl.png", mo, (200, -200, 250), (10, 20, 0), 110, up=(0, 0, 1), clim=(-14, 36))
# inner knee, seen from inside (from -Z up), colour = z
shot("p5a_inn_knee_inside.png", mi, (10, 10, -300), (10, 10, 80), 105, up=(0, 1, 0), clim=(74, 86))
shot("p5a_inn_knee_inside_obl.png", mi, (200, -200, -150), (30, 40, 80), 100, up=(0, 0, 1), clim=(60, 90))
# hip end inside: looking +Y towards the hip plate
shot("p5a_out_hip_inside.png", mo, (38, 120, 150), (38, 272, 25), 70, up=(0, 0, 1), size=(1400, 1000), clim=(-30, 40))
shot("p5a_inn_hip_inside.png", mi, (38, 120, -60), (38, 272, 70), 70, up=(0, 0, 1), size=(1400, 1000), clim=(35, 100))
