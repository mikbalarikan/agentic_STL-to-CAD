"""fitting helpers on the inner scan (frame of COMMON.md)"""
from i2_common import *
v, f, c, n, a = scan(); d = de(); p5, old = dev()
w_area = a / a.sum()
N = len(c)
def wmed(x, w=None):
    if len(x) == 0: return float("nan")
    if w is None: return float(np.median(x))
    o = np.argsort(x); cw = np.cumsum(w[o]); return float(x[o][np.searchsorted(cw, cw[-1] / 2)])
def circle_fit(xy, w=None):
    """algebraic (Kasa) circle fit, then geometric refinement; returns cx,cy,r,rms"""
    x, y = xy[:, 0], xy[:, 1]
    A = np.c_[2 * x, 2 * y, np.ones(len(x))]; b = x * x + y * y
    if w is not None: sw = np.sqrt(w); A = A * sw[:, None]; b = b * sw
    s = np.linalg.lstsq(A, b, rcond=None)[0]
    cx, cy = s[0], s[1]; r = np.sqrt(max(s[2] + cx * cx + cy * cy, 0))
    for _ in range(5):  # Gauss-Newton on geometric residual
        dx, dy = x - cx, y - cy; rr = np.hypot(dx, dy) + 1e-12
        J = np.c_[-dx / rr, -dy / rr, -np.ones(len(x))]; res = rr - r
        if w is not None: J = J * sw[:, None]; res = res * sw
        st = np.linalg.lstsq(J, -res, rcond=None)[0]; cx += st[0]; cy += st[1]; r += st[2]
    rr = np.hypot(x - cx, y - cy)
    return float(cx), float(cy), float(r), float(np.sqrt(np.mean((rr - r) ** 2)))
def metrics(mask):
    """area, p90 old, p90 part5, share within .5, points lost (net, % of total scan area)"""
    m = mask
    if m.sum() == 0: return dict(n_tris=0, area_mm2=0, old_p90=None, part5_p90=None, old_in05=None, part5_in05=None, points_lost=0)
    ww = w_area[m]
    lost = (w_area[m & (old < .5) & (p5 >= .5)].sum() - w_area[m & (p5 < .5) & (old >= .5)].sum()) * 100
    return dict(n_tris=int(m.sum()), area_mm2=round(float(a[m].sum()), 1), old_p90=round(p90(old[m]), 2), part5_p90=round(p90(p5[m]), 2),
                old_in05=round(float(ww[old[m] < .5].sum() / ww.sum() * 100), 1), part5_in05=round(float(ww[p5[m] < .5].sum() / ww.sum() * 100), 1),
                points_lost=round(float(lost), 3))
def save_mask(fid, m):
    np.save(os.path.join(MASKS, f"inn_f_{fid}.npy"), np.flatnonzero(m).astype(np.int64))
def rz(centre):  # radial distance to a vertical axis
    return np.hypot(c[:, 0] - centre[0], c[:, 1] - centre[1])
def line_frame(p0, p1):
    p0 = np.array(p0, float); p1 = np.array(p1, float); L = np.linalg.norm(p1 - p0); e = (p1 - p0) / L
    u = (c[:, 0] - p0[0]) * e[0] + (c[:, 1] - p0[1]) * e[1]; wv = -(c[:, 0] - p0[0]) * e[1] + (c[:, 1] - p0[1]) * e[0]
    nu = n[:, 0] * e[0] + n[:, 1] * e[1]; nw = -n[:, 0] * e[1] + n[:, 1] * e[0]
    return u, wv, nu, nw, L, e
def side_pos(wv, aw, lo, hi, bw=0.1):
    """position of a wall inside [lo,hi]: weighted median of the dense core (histogram peak +- 0.4)"""
    if len(wv) < 20: return float("nan"), 0
    h, ed = np.histogram(wv, bins=np.arange(lo, hi + bw, bw), weights=aw)
    k = np.argmax(h); cen = ed[k] + bw / 2; sel = np.abs(wv - cen) < 0.35
    return wmed(wv[sel], aw[sel]), int(sel.sum())
def rib_fit(p0, p1, t_nom, win=None, u_in=(0.12, 0.88), de_min=2.0, zmin=36.0, zmax=None, free_z=None):
    """vertical rib along p0-p1 hanging from the skin (down = -Z). Returns dict + mask."""
    u, wv, nu, nw, L, e = line_frame(p0, p1)
    win = win or (t_nom / 2 + 2.2)
    band = (np.abs(wv) < win) & (u > -1) & (u < L + 1) & (d >= de_min) & (c[:, 2] > zmin)
    if zmax: band &= c[:, 2] < zmax
    res = {}
    # side walls: normals across the rib
    side = band & (np.abs(nw) > 0.7) & (u > u_in[0] * L) & (u < u_in[1] * L)
    wl, nl = side_pos(wv[side & (wv < 0)], a[side & (wv < 0)], -win, 0.0); wr, nr = side_pos(wv[side & (wv > 0)], a[side & (wv > 0)], 0.0, win)
    # the wall closer to the nominal side if there are wide gaps: refine using nominal +- (t/2+1)
    res["w_left"], res["w_right"] = wl, wr; res["n_side"] = (nl, nr)
    res["centre_off"] = (wl + wr) / 2; res["t"] = wr - wl
    # wall line slope along u (angle error)
    ang = {}
    for nm, sgn, wpos in (("l", -1, wl), ("r", 1, wr)):
        s = side & (np.abs(wv - wpos) < 0.45)
        if s.sum() > 30:
            A = np.c_[u[s], np.ones(s.sum())]; sl = np.linalg.lstsq(A, wv[s], rcond=None)[0][0]; ang[nm] = np.degrees(np.arctan(sl))
            # draft: w vs z
            B = np.c_[c[s, 2], np.ones(s.sum())]; dz = np.linalg.lstsq(B, wv[s], rcond=None)[0][0]; ang["draft_" + nm] = np.degrees(np.arctan(dz)) * sgn
    res["angle_deg"] = ang
    # free edge (faces -Z) inside the rib width
    tt = res["t"] if np.isfinite(res["t"]) else t_nom
    fe = band & (n[:, 2] < -0.9) & (np.abs(wv - res["centre_off"]) < tt / 2 - 0.2) & (u > u_in[0] * L) & (u < u_in[1] * L)
    if fe.sum() > 10:
        zz = c[fe, 2]; h, ed = np.histogram(zz, bins=np.arange(zz.min(), zz.max() + 0.2, 0.1), weights=a[fe])
        # lowest dense level
        dense = np.flatnonzero(h > h.max() * 0.25); k = dense[0]; zc = ed[k] + .05; sel = fe & (np.abs(c[:, 2] - zc) < 0.3)
        res["free_z"] = wmed(c[sel, 2], a[sel]); res["free_n"] = int(sel.sum())
        # slope along u
        if sel.sum() > 30:
            A = np.c_[u[sel], np.ones(sel.sum())]; sl, ic = np.linalg.lstsq(A, c[sel, 2], rcond=None)[0]; res["free_slope_z_per_mm"] = float(sl); res["free_z_at0"] = float(ic); res["free_z_atL"] = float(ic + sl * L)
            res["free_u"] = (float(np.percentile(u[sel], 1)), float(np.percentile(u[sel], 99)))
        # sloped free edge (gussets): tris facing mostly down but tilted
    # general: points on the free edge for sloped rib (nz in -0.95..-0.3)
    mask = band & (np.abs(wv - res["centre_off"]) < tt / 2 + 0.7) & (u > -0.7) & (u < L + 0.7)
    res["L"] = L; res["e"] = e
    return res, mask

def cyl_fit(c0, rlo, rhi, zlo, zhi, nzmax=0.5, de_min=1.0, iters=3, rtol=None):
    """vertical cylinder wall: horizontal-normal tris with radius in [rlo,rhi] from c0 and z in [zlo,zhi]. Returns dict."""
    cx, cy = c0
    for _ in range(iters):
        r = np.hypot(c[:, 0] - cx, c[:, 1] - cy)
        m = (np.abs(n[:, 2]) < nzmax) & (r >= rlo) & (r <= rhi) & (c[:, 2] >= zlo) & (c[:, 2] <= zhi) & (d >= de_min)
        if m.sum() < 30: return None
        # keep dense radius core
        h, ed = np.histogram(r[m], bins=np.arange(rlo, rhi + 0.05, 0.05), weights=a[m]); k = np.argmax(h); rc = ed[k] + 0.025
        m &= np.abs(r - rc) < 0.5
        if m.sum() < 30: return None
        cx, cy, rad, rms = circle_fit(c[m][:, :2], a[m])
    r = np.hypot(c[:, 0] - cx, c[:, 1] - cy)
    # r vs z slope (draft)
    A = np.c_[c[m, 2], np.ones(m.sum())]; sl, ic = np.linalg.lstsq(A, r[m], rcond=None)[0]
    return dict(cx=cx, cy=cy, r=rad, D=2 * rad, rms=rms, n=int(m.sum()), draft_deg=float(np.degrees(np.arctan(sl))), z_lo=float(np.percentile(c[m, 2], 2)), z_hi=float(np.percentile(c[m, 2], 98)), mask=m)
def level_fit(m, nzsign=-1, tol=0.35, pct=None):
    """flat face: robust level of tris selected by mask m (normal sign nzsign): densest 0.1mm bin -> median"""
    if m.sum() < 5: return None
    zz = c[m, 2]; h, ed = np.histogram(zz, bins=np.arange(zz.min() - .05, zz.max() + .15, 0.1), weights=a[m]); k = np.argmax(h); zc = ed[k] + .05
    s = m & (np.abs(c[:, 2] - zc) < tol)
    return dict(z=wmed(c[s, 2], a[s]), n=int(s.sum()), rms=float(np.sqrt(np.average((c[s, 2] - wmed(c[s, 2], a[s])) ** 2, weights=a[s]))), mask=s)

def _fitline(u, w, aw):
    A = np.c_[u, np.ones(len(u))] * np.sqrt(aw)[:, None]; b = w * np.sqrt(aw)
    s = np.linalg.lstsq(A, b, rcond=None)[0]; return float(s[0]), float(s[1])
def rib2(p0, p1, t_nom, sloped=False, de_min=2.0, zmin=36.0, zmax=None, win=None, iters=2, root=True, wall_z=None):
    """vertical rib (thin wall hanging from the skin) near centre line p0-p1. Iterative re-alignment.
    sloped: free edge is an inclined line (gusset): free edge = lower envelope."""
    p0 = np.array(p0, float); p1 = np.array(p1, float)
    for it in range(iters + 1):
        res, mask = rib_fit(p0, p1, t_nom, win=win, de_min=de_min, zmin=zmin, zmax=zmax)
        u, wv, nu, nw, L, e = line_frame(p0, p1)
        wl, wr = res["w_left"], res["w_right"]
        if not (np.isfinite(wl) and np.isfinite(wr)): return res, mask, (p0, p1)
        if it == iters: break
        band = (np.abs(wv - res["centre_off"]) < (wr - wl) / 2 + 0.6) & (u > 0.1 * L) & (u < 0.9 * L) & (d >= de_min) & (c[:, 2] > zmin) & (np.abs(nw) > 0.7)
        sl = band & (wv < res["centre_off"]); sr = band & (wv > res["centre_off"])
        if sl.sum() < 50 or sr.sum() < 50: break
        al, bl = _fitline(u[sl], wv[sl], a[sl]); ar, br = _fitline(u[sr], wv[sr], a[sr])
        am, bm = (al + ar) / 2, (bl + br) / 2; perp = np.array([-e[1], e[0]])
        q0 = p0 + perp * bm; q1 = p0 + e * L + perp * (bm + am * L)
        p0, p1 = q0, q1
    # extents along the rib (side walls, +-1 mm tolerance), free edge extents
    u, wv, nu, nw, L, e = line_frame(p0, p1)
    tt = res["t"]; cen = res["centre_off"]
    sw = (np.abs(wv - cen) < tt / 2 + 0.5) & (np.abs(nw) > 0.7) & (d >= de_min) & (c[:, 2] > zmin) & (u > -15) & (u < L + 15)
    if zmax: sw &= c[:, 2] < zmax
    bins = np.arange(-15, L + 15, 1.0); h, _ = np.histogram(u[sw], bins=bins, weights=a[sw])
    thr = np.median(h[(bins[:-1] > 0.2 * L) & (bins[:-1] < 0.8 * L)]) * 0.25
    ok = np.flatnonzero(h > thr)
    if len(ok):
        # contiguous run containing the middle
        mid = int(np.argmin(np.abs(bins[:-1] - L / 2))); lo = mid; hi = mid
        while lo - 1 >= 0 and h[lo - 1] > thr: lo -= 1
        while hi + 1 < len(h) and h[hi + 1] > thr: hi += 1
        res["u_ext"] = (float(bins[lo]), float(bins[hi + 1]))
    # sloped free edge (lower envelope)
    if sloped:
        fe = (np.abs(wv - cen) < tt / 2 - 0.2) & (u > -1) & (u < L + 1) & (d >= de_min) & (n[:, 2] < -0.3) & (c[:, 2] > zmin)
        ub = np.arange(0, L, 2.0); pts = []
        for k in range(len(ub)):
            s = fe & (u >= ub[k]) & (u < ub[k] + 2)
            if s.sum() > 8:
                zlow = np.percentile(c[s, 2], 5); ss = s & (c[:, 2] < zlow + 0.6); pts.append((u[ss].mean(), wmed(c[ss, 2], a[ss]), a[ss].sum()))
        if len(pts) > 5:
            P = np.array(pts); keep = np.ones(len(P), bool)
            for _ in range(3):
                A = np.c_[P[keep, 0], np.ones(keep.sum())]; sl_, ic = np.linalg.lstsq(A, P[keep, 1], rcond=None)[0]
                rr = P[:, 1] - (sl_ * P[:, 0] + ic); keep = np.abs(rr) < max(0.5, 2.5 * np.std(rr[keep]))
            res["env_slope"] = float(sl_); res["env_z0"] = float(ic); res["env_zL"] = float(ic + sl_ * L); res["env_rms"] = float(np.std(rr[keep])); res["env_u"] = (float(P[keep, 0].min()), float(P[keep, 0].max()))
            res["env_angle_deg"] = float(np.degrees(np.arctan(sl_)))
    # root fillet + floor level next to the rib
    if root:
        hw = tt / 2; zf = res.get("free_z", res.get("env_z0", 40.0))
        fl = (np.abs(wv - cen) > hw + 4.5) & (np.abs(wv - cen) < hw + 10) & (u > 0.2 * L) & (u < 0.8 * L) & (n[:, 2] < -0.95) & (d >= de_min) & (c[:, 2] > zf + 1.0)
        if fl.sum() > 30:
            zz = c[fl, 2]; h, ed = np.histogram(zz, bins=np.arange(zz.min() - .05, zz.max() + .15, 0.1), weights=a[fl])
            k = np.flatnonzero(h > h.max() * 0.3)[0]; zc = ed[k] + .05
            s_ = fl & (np.abs(c[:, 2] - zc) < 0.3); res["floor_z"] = wmed(c[s_, 2], a[s_])
            zfl = res["floor_z"]
            if not sloped:
                pts = []
                for sgn in (-1, 1):
                    ww = (wv - cen) * sgn
                    q = (ww > hw + 0.05) & (ww < hw + 4.5) & (u > 0.2 * L) & (u < 0.8 * L) & (n[:, 2] < -0.1) & (n[:, 2] > -0.98) & (d >= de_min) & (c[:, 2] > zf + 0.4) & (c[:, 2] < zfl - 0.05)
                    pts.append(np.c_[ww[q] - hw, c[q, 2]])
                P = np.vstack(pts)
                if len(P) > 60:
                    cx_, cz_, r_, rms_ = circle_fit(P)
                    res["fillet_R"] = r_; res["fillet_rms"] = rms_; res["fillet_n"] = len(P); res["fillet_centre"] = (cx_, cz_)
    res["p0m"] = p0.tolist(); res["p1m"] = p1.tolist(); res["L"] = L; res.pop("e", None)
    return res, mask, (p0, p1)

def profile_along(p0, p1, w0, w1, step=10.0, u0=0.0, u1=None, de_min=1.5, nzmax=-0.9, zmin=70.0, zmax=95.0):
    """z levels (facing down) of the strip w in [w0,w1] across the line p0-p1, per u-bin: list of (u, centre_xy, lowest dense level, n)."""
    u, wv, nu, nw, L, e = line_frame(p0, p1); u1 = L if u1 is None else u1
    out = []
    for ub in np.arange(u0, u1, step):
        s = (u >= ub) & (u < ub + step) & (wv > w0) & (wv < w1) & (n[:, 2] < nzmax) & (d >= de_min) & (c[:, 2] > zmin) & (c[:, 2] < zmax)
        if s.sum() < 15: out.append((float(ub + step / 2), None, 0)); continue
        zz = c[s, 2]; h, ed = np.histogram(zz, bins=np.arange(zz.min() - .05, zz.max() + .15, 0.1), weights=a[s])
        k = np.flatnonzero(h > h.max() * 0.3)[0]; zc = ed[k] + .05; ss = s & (np.abs(c[:, 2] - zc) < 0.25)
        out.append((float(ub + step / 2), float(wmed(c[ss, 2], a[ss])), int(ss.sum())))
    return out

def edge_pw(p0, p1, t, step=4.0, zmin=36.0, zmax=125.0, nzmax=-0.3, de_min=1.5):
    """free edge z(u) along a rib: lower-envelope per bin on the rib centre strip; returns table + best piecewise-linear
    description (flat / line / flat+ramp)."""
    u, wv, nu, nw, L, e = line_frame(p0, p1)
    tab = []
    for ub in np.arange(0, L, step):
        s = (u >= ub) & (u < ub + step) & (np.abs(wv) < max(t / 2 - 0.35, 0.3)) & (n[:, 2] < nzmax) & (d >= de_min) & (c[:, 2] > zmin) & (c[:, 2] < zmax)
        if s.sum() < 6: continue
        zl = np.percentile(c[s, 2], 5); ss = s & (c[:, 2] < zl + 0.5)
        tab.append((float(u[ss].mean()), float(wmed(c[ss, 2], a[ss])), int(ss.sum())))
    T = np.array(tab)
    if len(T) < 5: return dict(table=tab, kind="n/a")
    U, Z = T[:, 0], T[:, 1]
    # drop ends interrupted by bosses / plates: iteratively trim leading / trailing bins that jump > 1.2 mm from their neighbour
    ok = np.ones(len(U), bool)
    zmed = np.median(Z)
    for _ in range(12):
        idx = np.flatnonzero(ok)
        if len(idx) > 6 and abs(Z[idx[0]] - Z[idx[1]]) > 1.2: ok[idx[0]] = False
        if len(idx) > 6 and abs(Z[idx[-1]] - Z[idx[-2]]) > 1.2: ok[idx[-1]] = False
    U, Z = U[ok], Z[ok]
    def lin(U_, Z_):
        A = np.c_[U_, np.ones(len(U_))]; s_ = np.linalg.lstsq(A, Z_, rcond=None)[0]; return s_, float(np.sqrt(np.mean((A @ s_ - Z_) ** 2)))
    s1, rms1 = lin(U, Z)
    best = None
    for i1 in range(0, len(U) - 2):
        for i2 in range(i1 + 2, len(U)):
            b1, b2 = U[i1] - step / 2, U[i2] - step / 2
            x = np.clip(U, b1, b2) - b1
            A = np.c_[x, np.ones(len(U))]; s_ = np.linalg.lstsq(A, Z, rcond=None)[0]; rr = float(np.sqrt(np.mean((A @ s_ - Z) ** 2)))
            if best is None or rr < best[0] - 1e-9: best = (rr, float(b1), float(b2), float(s_[0]), float(s_[1]))
    out = dict(table=[(round(float(a_), 1), round(float(b_), 2)) for a_, b_ in zip(U, Z)], rms_line=rms1, line_slope=float(s1[0]), line_z0=float(s1[1]), u_used=(float(U[0]), float(U[-1])))
    if rms1 < 0.1 and abs(s1[0]) * (U[-1] - U[0]) < 0.3: out.update(kind="flat", z=float(np.median(Z)))
    elif rms1 < 0.1: out.update(kind="line", z_at0=float(s1[1]), z_atL=float(s1[1] + s1[0] * L), angle_deg=float(np.degrees(np.arctan(s1[0]))))
    elif best and best[0] < 0.15:
        rr, b1, b2, sl_, z0_ = best
        out.update(kind="flat-ramp-flat", u_ramp_start=b1, u_ramp_end=b2, z_low=z0_, z_high=z0_ + sl_ * (b2 - b1), ramp_angle_deg=float(np.degrees(np.arctan(sl_))), rms_pw=rr)
    else: out.update(kind="irregular", z_min=float(Z.min()), z_max=float(Z.max()), best_rms=best[0] if best else None)
    return out
