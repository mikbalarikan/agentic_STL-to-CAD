from i2_rows import *
for bid,cc in (("B6",(97.95,265.0)),("B7",(-21.98,265.0)),("B1",(61.3,-40.1)),("B2",(75.86,29.85))):
    m=np.load(os.path.join(MASKS,f"inn_f_{bid}_col.npy")); bad=m[p5[m]>=1.0]
    th=np.degrees(np.arctan2(c[bad,1]-cc[1],c[bad,0]-cc[0]))%360; zz=c[bad,2]
    h,ed=np.histogram(th,bins=np.arange(0,361,30))
    print(bid,"mask",len(m),"bad(>1)",len(bad),"angle hist (30deg):",h.tolist()," z pct",np.percentile(zz,[5,50,95]).round(1)," dev med",np.median(p5[bad]).round(2), "signed? old",np.median(old[bad]).round(2))
