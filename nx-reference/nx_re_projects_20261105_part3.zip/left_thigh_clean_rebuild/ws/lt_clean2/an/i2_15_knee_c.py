from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS, math
rows = []
r0 = np.hypot(c[:, 0], c[:, 1]); th0 = np.degrees(np.arctan2(c[:, 1], c[:, 0])) % 360
def mk_rib(fid, typ, p0, p1, t, p5v, **kw):
    r, m, (q0, q1) = rib2(p0, p1, t, **kw)
    if not np.isfinite(r.get("t", np.nan)):
        rows.append(make_row(fid, typ, dict(note="no walls"), "rib2", None, m, p5v)); return None
    e = edge_pw(q0, q1, r["t"], step=3.0, zmin=60.0)
    rows.append(make_row(fid, typ, dict(p0=q0.tolist(), p1=q1.tolist(), length=r["L"], t=r["t"], u_extent=r.get("u_ext"), free_edge={k: v for k, v in e.items() if k not in ("table", "rms_line", "line_slope", "line_z0")}, edge_table=e["table"]),
                         "rib2 side-wall lines + free-edge envelope", e.get("rms_pw") or e.get("rms_line"), m, p5v))
    return r, (q0, q1), e
RL = mk_rib("CH_RUN_RIB_L", "run_rib", DS.CH_J_IN, DS.CH_TOP_L, DS.CH_RIB_T, dict(p0=DS.CH_J_IN, p1=DS.CH_TOP_L, t=DS.CH_RIB_T, free_z=DS.CH_RIB_BOTTOM), zmin=60.0, win=3.5)
RR = mk_rib("CH_RUN_RIB_R", "run_rib", DS.CH_J_OUT, DS.CH_TOP_R, DS.CH_RIB_T, dict(p0=DS.CH_J_OUT, p1=DS.CH_TOP_R, t=DS.CH_RIB_T, free_z=DS.CH_RIB_BOTTOM), zmin=60.0, win=3.5)
# run floor: strip between the rib centre lines (use the measured lines when available)
pL0, pL1 = (RL[1] if RL else (np.array(DS.CH_J_IN), np.array(DS.CH_TOP_L)))
pR0, pR1 = (RR[1] if RR else (np.array(DS.CH_J_OUT), np.array(DS.CH_TOP_R)))
# parametrise by v along the left rib: floor tris between the two lines
def side_of(p0, p1, X):
    e_ = (p1 - p0) / np.linalg.norm(p1 - p0); return -(X[:, 0] - p0[0]) * e_[1] + (X[:, 1] - p0[1]) * e_[0]
sl_ = side_of(pL0, pL1, c); sr_ = side_of(pR0, pR1, c)
u_l = ((c[:, 0] - pL0[0]) * (pL1[0] - pL0[0]) + (c[:, 1] - pL0[1]) * (pL1[1] - pL0[1])) / np.linalg.norm(pL1 - pL0)
between = (sl_ < -1.6) & (sr_ > 1.6) & (u_l > 5) & (c[:, 1] < 136)
fm = between & (n[:, 2] < -0.9) & (c[:, 2] > 74) & (c[:, 2] < 84) & (d >= 1.5)
prof = []
for y0 in range(-10, 136, 10):
    s = fm & (c[:, 1] >= y0) & (c[:, 1] < y0 + 10)
    if s.sum() > 20:
        lv = level_fit(s, tol=0.3); prof.append((y0 + 5, lv["z"] if lv else None))
fl = level_fit(fm & (c[:, 1] < 90), tol=0.3)
rows.append(make_row("CH_RUN_FLOOR", "plane", dict(z_flat=fl["z"] if fl else None, profile_y_z=prof), "level fit between the run ribs, y<90 (flat) + 10 mm station table", fl["rms"] if fl else None,
                     between & (c[:, 2] > 72) & (c[:, 2] < 85) & (d >= 1.5) & (n[:, 2] < -0.3), dict(z=DS.CH_FLOOR)))
# caps
cap_ring_p0 = (DS.CH_R_IN - 1.25) * np.array([math.cos(math.radians(DS.CH_A_TOP)), math.sin(math.radians(DS.CH_A_TOP))])
cap_ring_p1 = (DS.CH_R_OUT + 1.25) * np.array([math.cos(math.radians(DS.CH_A_TOP)), math.sin(math.radians(DS.CH_A_TOP))])
mk_rib("CH_CAP_RING", "cap_rib", cap_ring_p0, cap_ring_p1, DS.CH_RIB_T, dict(p0=cap_ring_p0.tolist(), p1=cap_ring_p1.tolist(), t=DS.CH_RIB_T), zmin=60.0, win=3.5)
mk_rib("CH_CAP_RUN", "cap_rib", (DS.CH_TOP_L[0] - 1.25, 135.0), (DS.CH_TOP_R[0] + 1.25, 135.0), DS.CH_RIB_T, dict(p0=[DS.CH_TOP_L[0] - 1.25, 135.0], p1=[DS.CH_TOP_R[0] + 1.25, 135.0], t=DS.CH_RIB_T), zmin=60.0, win=3.5)
# holes H1..H8
for k, (x, y) in DS.CH_HOLES.items():
    h = cyl_fit((x, y), 1.0, 2.4, 60.0, 90.0, de_min=0.3, iters=3)
    cc = (h["cx"], h["cy"]) if h else (x, y); rr_ = np.hypot(c[:, 0] - cc[0], c[:, 1] - cc[1])
    bot = level_fit((rr_ < 1.3) & (n[:, 2] > 0.9) & (c[:, 2] > 70) & (c[:, 2] < 95), tol=0.3)
    boss_top = level_fit((rr_ > 1.8) & (rr_ < 3.0) & (n[:, 2] < -0.9) & (c[:, 2] > 70) & (c[:, 2] < 90) & (d >= 1.0), tol=0.3)
    bw = cyl_fit(cc, 2.6, 4.6, 70.0, 85.0, de_min=1.0, iters=2)
    mk = (rr_ < 4.8) & (c[:, 2] > 68) & (c[:, 2] < 95) & (d >= 1.0)
    rows.append(make_row(f"CH_{k}", "hole_boss", dict(centre=[cc[0], cc[1]], hole_D=h["D"] if h else None, hole_end_z=bot["z"] if bot else None, boss_face_z=boss_top["z"] if boss_top else None,
                         boss_D=bw["D"] if bw else None, boss_centre=[bw["cx"], bw["cy"]] if bw else None), "cylinder fit hole wall; hole-end / boss-face levels; boss wall fit", h["rms"] if h else None, mk,
                         dict(centre=[x, y], hole_D=DS.CH_HOLE_D, depth=DS.CH_HOLE_DEPTH, boss_D=DS.CH_BOSS_D, boss_face_z=DS.CH_RIB_BOTTOM, hole_end_z=DS.CH_RIB_BOTTOM + DS.CH_HOLE_DEPTH)))
dump("knee_c", rows)
