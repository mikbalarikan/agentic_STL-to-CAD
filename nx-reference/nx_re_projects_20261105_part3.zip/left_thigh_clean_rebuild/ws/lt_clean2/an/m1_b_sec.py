import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,ax=plt.subplots(2,4,figsize=(24,12))
for i,(n,zs) in enumerate((("out_scan",[-12,0,20,34]),("inn_scan",[37,50,70,82]))):
    v,f=lib.load(n,1500000)
    for j,z in enumerate(zs):
        s=lib.section(v,f,2,z); a=ax[i,j]
        for p,q in s: a.plot([p[0],q[0]],[p[1],q[1]],'k-',lw=.5)
        a.set_aspect('equal'); a.set_title(f"{n} z={z}"); a.set_xlim(-100,130); a.set_ylim(-100,140)
        t=np.linspace(0,2*np.pi,200); a.plot(68.5*np.cos(t),68.5*np.sin(t),'r:',lw=.6); a.grid(True)
plt.savefig("work/m1/sections.png",dpi=70)
