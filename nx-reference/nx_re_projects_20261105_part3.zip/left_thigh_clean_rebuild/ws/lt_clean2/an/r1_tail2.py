import sys, os, numpy as np, trimesh
from shapely.geometry import LineString, Point
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
C0 = np.array([62.3, -51.3])
def chains(mesh, z):
    s = mesh.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1])
    return [] if s is None else [s.vertices[e.points][:, :2] for e in s.entities]
def fit_line(P):
    c = P.mean(0); u, s_, vt = np.linalg.svd(P - c); return c, vt[0]
def fillet(V, d1, d2, R, n=40):
    # d1,d2 unit directions from V along the two sides
    ang = np.arccos(np.clip(d1 @ d2, -1, 1)); t = R / np.tan(ang / 2)
    p1 = V + d1 * t; p2 = V + d2 * t; bis = (d1 + d2); bis /= np.linalg.norm(bis)
    cen = V + bis * R / np.sin(ang / 2)
    a1 = np.arctan2(*(p1 - cen)[::-1]); a2 = np.arctan2(*(p2 - cen)[::-1])
    da = (a2 - a1 + np.pi) % (2 * np.pi) - np.pi
    arc = np.array([cen + R * np.array([np.cos(a1 + da * k), np.sin(a1 + da * k)]) for k in np.linspace(0, 1, n)])
    return np.vstack([V + d1 * 12, arc, V + d2 * 12]), np.degrees(ang), t
out = {}
for w, zs in (("out", (0, 10, 20, 30)), ("inn", (40, 50, 60))):
    v, f = lib.load(w + "_scan", 1500000); sm = trimesh.Trimesh(v, f, process=False)
    cm = trimesh.load(f"nx/A_v2/{w}_A_r0.stl")
    for z in zs:
        ch = [p for p in chains(cm, z) if (np.linalg.norm(p - C0, axis=1) < 3).any()]
        if not ch: print(w, z, "no chain"); continue
        p = max(ch, key=len); i0 = np.argmin(np.linalg.norm(p - C0, axis=1))
        # walk arc length both ways
        seg = np.r_[0, np.cumsum(np.linalg.norm(np.diff(p, axis=0), axis=1))]; s0 = seg[i0]
        A = p[(seg > s0 + 2) & (seg < s0 + 12)]; B = p[(seg < s0 - 2) & (seg > s0 - 12)]
        if len(A) < 2 or len(B) < 2: print(w, z, "short"); continue
        ca, da = fit_line(A); cb, db = fit_line(B)
        M = np.array([da, -db]).T; t = np.linalg.solve(M, cb - ca); V = ca + da * t[0]
        d1 = da if (A.mean(0) - V) @ da > 0 else -da; d2 = db if (B.mean(0) - V) @ db > 0 else -db
        sp = np.vstack([q[np.linalg.norm(q - V, axis=1) < 7] for q in chains(sm, z) if (np.linalg.norm(q - V, axis=1) < 7).any()])
        best = None
        for R in np.arange(0.0, 6.01, 0.25):
            ln = LineString(fillet(V, d1, d2, R)[0]) if R > 0 else LineString([V + d1 * 12, V, V + d2 * 12])
            dd = np.array([ln.distance(Point(q)) for q in sp]); sc_ = np.sqrt((dd ** 2).mean())
            if best is None or sc_ < best[1]: best = (R, sc_, dd.max())
            if R in (0.0,): r0 = (sc_, dd.max())
        ang = np.degrees(np.arccos(np.clip(d1 @ d2, -1, 1)))
        print(f"{w} z{z}: V {V.round(2)} interior angle {ang:.1f}  R=0 rms {r0[0]:.2f} max {r0[1]:.2f} | best R {best[0]:.2f} rms {best[1]:.3f} max {best[2]:.2f} (n {len(sp)})")
        out[(w, z)] = best[0]
print(out)
