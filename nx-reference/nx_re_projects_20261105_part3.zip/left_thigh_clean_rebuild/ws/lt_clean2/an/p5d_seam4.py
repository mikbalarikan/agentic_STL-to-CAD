import json, numpy as np, sys
sys.argv=[sys.argv[0]]
exec(open("an/p5d_seam3.py").read().split("for w in (\"out\", \"inn\"):")[0])
x=np.load("work/p5d/seamfit_out_A_lal.npy"); P,s=centres("out","A",232.0)
C=lal(x); e=dist_poly(P,C)
print("out A lal p50 %.2f p90 %.2f max %.2f"%(np.median(e),np.percentile(e,90),e.max()), "x0 %.2f y0 %.2f th0 %.1f L1 %.1f R %.1f phi %.1f L2 %.1f"%(x[0],x[1],np.degrees(x[2]),x[3],x[4],np.degrees(x[5]),x[6]))
print("start",C[0],"end",C[-1]); 
print("worst stations", s[np.argsort(-e)[:6]], np.sort(e)[::-1][:6])
S=np.load("work/p5d/seamfit_out_A_spl5.npy"); print("spl5",S.round(2).tolist())
S=np.load("work/p5d/seamfit_out_B_spl4.npy"); print("B spl4",S.round(2).tolist())
P,s=centres("out","B",145.0)
c=P.mean(0); u,sv,vt=np.linalg.svd(P-c); print("B line dir",vt[0], "ends", (c+ vt[0]*((P-c)@vt[0]).min()).round(2), (c+vt[0]*((P-c)@vt[0]).max()).round(2))
