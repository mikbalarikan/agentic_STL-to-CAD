import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from scipy.optimize import least_squares
D=np.load("work/m3/ext_pts.npz"); P=D['P']; r=D['r']; th=D['th']
YM=287.39
def fitarc(y,rr,p0):
    f=lambda p: np.hypot(y-p[0],rr-p[1])-p[2]
    s=least_squares(f,p0).x; return s,f(s)
# 1. mean over theta  (use all ext points weights) -> sphere about axis, and torus arc
for ylo in (262,266,270,274):
    k=(P[:,1]>ylo)&(P[:,1]<287.0)
    y=P[k,1]; rr=r[k]
    # sphere on axis: centre (Yc, 0)
    f=lambda p: np.hypot(y-p[0],rr)-p[1]
    s=least_squares(f,[255,78]).x; e=f(s)
    # cone: r=a+b*y
    A=np.c_[np.ones(k.sum()),y]; co=np.linalg.lstsq(A,rr,rcond=None)[0]; ec=rr-A@co
    print('Y>%d all points: sphere-on-axis Yc=%.2f Rs=%.2f res std %.3f | cone r=%.2f%+.4f y (half angle %.2f deg) res std %.3f'%(ylo,s[0],s[1],e.std(),co[0],co[1],np.degrees(np.arctan(-co[1])),ec.std()))
# 2. per-theta arcs in (Y,R)
print('per-theta (Y,R) circle fits, Y 264..287')
for t in range(-165,180,30):
    k=(abs(th-t)<4)&(P[:,1]>264)&(P[:,1]<287.0)
    if k.sum()<100: continue
    s,e=fitarc(P[k,1],r[k],[250,0,78]) if False else fitarc(P[k,1],r[k],[240,10,70])
    # slope at mouth, value at mouth
    y=287.39; dy=y-s[0]; Rm=s[1]+np.sqrt(max(s[2]**2-dy**2,0)) if True else 0
    Rm_=s[1]+np.sqrt(s[2]**2-dy**2); slope=-dy/np.sqrt(s[2]**2-dy**2)
    print(' th%4d n=%5d arc c=(%.1f,%.1f) rho=%.1f res %.3f ; at mouth R=%.2f slope %.3f'%(t,k.sum(),s[0],s[1],s[2],e.std(),Rm_,slope))
