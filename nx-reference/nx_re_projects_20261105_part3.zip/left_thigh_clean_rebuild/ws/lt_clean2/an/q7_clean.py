"""G-clean census: CAD-only material (CAD outward of scan >1 mm), CAD void (CAD inward >1) and misaligned CAD surface (>1 mm from scan, normals opposed); clusters > 20 mm2 classified by nearest feature mask + exterior/interior."""
import numpy as np, trimesh, open3d as o3d, sys, glob, os, collections
sys.path.insert(0,"an"); import lib
from sklearn.cluster import DBSCAN
from v5e_occ import scene
OUT=open("work/q7/clean.txt","w")
def Pr(*a):
    s=" ".join(str(x) for x in a); print(s); OUT.write(s+"\n")
for w in sys.argv[1:] or ["out","inn"]:
    v,f=lib.load({"out":"out_scan","inn":"inn_scan"}[w],1500000); c,nn,ar=lib.tri_data(v,f)
    owner=np.full(len(c),-1); names=[]
    for mp in sorted(glob.glob(f"work/masks/{w}_f_*.npy")):
        n=os.path.basename(mp)[len(w)+3:-4]; names.append(n); owner[np.load(mp)]=len(names)-1   # last mask wins
    s=o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(v.astype(np.float32)),o3d.core.Tensor(f.astype(np.uint32)))
    P=trimesh.load(f"nx/P5d/{w}_P5d_final.stl",process=False)
    E=scene(f"nx/P5d/{w}_E0.stl")
    pts,fi=trimesh.sample.sample_surface(P,2000000,seed=3); ncad=P.face_normals[fi]; dens=len(pts)/P.area
    r=s.compute_closest_points(o3d.core.Tensor(pts.astype(np.float32)))
    q=r["points"].numpy(); pid=r["primitive_ids"].numpy().astype(int); ns=nn[pid]
    sg=((pts-q)*ns).sum(1); al=(ncad*ns).sum(1); d=np.linalg.norm(pts-q,axis=1)
    de=E.compute_distance(o3d.core.Tensor(pts.astype(np.float32))).numpy()
    Pr(f"##### {w}: CAD area {P.area:.0f} mm2; >1 mm from scan {(d>1).sum()/dens:.0f} mm2; >2 mm {(d>2).sum()/dens:.0f}")
    tot=collections.OrderedDict()
    for nm,m in (("EXTRA MATERIAL (CAD outward of scan >1)",(sg>1.0)&(al>0.3)),("CAD-ONLY SURFACE / opposed normals (>1 mm)",(d>1.0)&(al<=0.3)),("CAD VOID (CAD inward of scan >1)",(sg<-1.0)&(al>0.3))):
        Pr(f"-- {nm}: {m.sum()/dens:.0f} mm2 total")
        qq=pts[m]
        if len(qq)==0: continue
        lab=DBSCAN(eps=2.5,min_samples=5).fit_predict(qq); rows=[]
        for l in set(lab)-{-1}:
            k=np.where(m)[0][lab==l]; a=len(k)/dens
            if a<=20: continue
            ow=owner[pid[k]]; cnt=collections.Counter(ow[ow>=0]).most_common(2); lab_f=",".join(f"{names[i]}({n*100//len(k)}%)" for i,n in cnt) or "no feature mask"
            ext="EXT" if np.median(de[k])<1.0 else "int"
            rows.append((a,qq[lab==l].min(0).round(0),qq[lab==l].max(0).round(0),np.abs(sg[k]).max(),np.median(np.abs(sg[k])),ext,lab_f))
        for r_ in sorted(rows,key=lambda x:-x[0]): Pr("   %5.0f mm2 bbox %s %s max %.1f med %.1f %s  near: %s"%r_)
        Pr(f"   clusters > 20 mm2: {len(rows)}, area {sum(x[0] for x in rows):.0f} mm2")
