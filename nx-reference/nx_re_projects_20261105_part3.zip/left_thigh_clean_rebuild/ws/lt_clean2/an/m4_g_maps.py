import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
D = np.load(os.path.join(lib.W, "m4", "stations.npz"))
names = ["KNEE_ARC", "PX_WALL", "PX_HIP", "MX_WALL", "MX_HIP"]
fig, axs = plt.subplots(len(names), 2, figsize=(22, 4 * len(names)))
for r, nm in enumerate(names):
    s = D[nm + "__s"]; T = D[nm + "__T"]; p = D[nm + "__p"]
    for c, key, ttl in ((0, "Ho", "outer scan top surface (from above)"), (1, "Hi", "inner scan bottom surface (from below)")):
        H = D[nm + "__" + key]
        ax = axs[r, c]
        im = ax.imshow(H.T, origin="lower", aspect="auto", extent=[s[0], s[-1], T[0], T[-1]], vmin=34.3, vmax=36.5, cmap="turbo")
        ax.set_title(f"{nm}: {ttl}  (s mm vs t from lip centre, +t outward)")
        for i in range(0, len(s), 20): ax.text(s[i], T[-1] + 0.1, "(%d,%d)" % (p[i, 0], p[i, 1]), fontsize=6, rotation=45)
        plt.colorbar(im, ax=ax, pad=0.01)
fig.tight_layout(); fig.savefig(os.path.join(lib.W, "m4", "height_maps.png"), dpi=50)
