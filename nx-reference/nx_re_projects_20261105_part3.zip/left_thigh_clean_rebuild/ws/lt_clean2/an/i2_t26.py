from i2_rows import *
import glob, json
from scipy import ndimage as ndi
rows = []
for f_ in sorted(glob.glob(os.path.join(ROWS, "*.json"))): rows += json.load(open(f_))
cov = np.zeros(N, bool)
for r in rows:
    if r["id"] in ("JOINT_BOSS_FACES","LIP_FACE"): continue
    cov[np.load(os.path.join(MASKS, f"inn_f_{r['id']}.npy"))] = True
# arms / full-height ribs: faces at the joint levels (nz<-0.9, z 35..37.5): which are NOT covered by any feature mask
m=(n[:,2]<-0.9)&(c[:,2]>35.0)&(c[:,2]<37.5)
print("joint-level faces total area",a[m].sum(),"uncovered",a[m&~cov].sum())
un=m&~cov
s=2.0; x0,y0=-75,-75
im=np.zeros((int(380*s),int(200*s))); X=((c[un,0]-x0)*s).astype(int); Y=((c[un,1]-y0)*s).astype(int); np.add.at(im,(Y,X),a[un])
lab,nl=ndi.label(ndi.binary_dilation(im>0,iterations=3))
for k in range(1,nl+1):
    sel=np.zeros(N,bool); sel[np.flatnonzero(un)[lab[Y,X]==k]]=True
    if a[sel].sum()<8: continue
    cc=c[sel]; print(f"cluster {k} area {a[sel].sum():.0f} mm2 x {cc[:,0].min():.0f}..{cc[:,0].max():.0f} y {cc[:,1].min():.0f}..{cc[:,1].max():.0f} z {np.median(cc[:,2]):.2f}")
