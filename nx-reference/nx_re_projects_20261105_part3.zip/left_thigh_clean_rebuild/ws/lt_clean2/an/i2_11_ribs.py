from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
rows = []
def rib_row(fid, typ, p0, p1, t, p5val, sloped=False, **kw):
    r, m, (q0, q1) = rib2(p0, p1, t, sloped=sloped, **kw)
    if not np.isfinite(r.get("t", np.nan)):
        rows.append(make_row(fid, typ, dict(note="no side walls found"), "rib2", None, m, p5val)); return None
    e = edge_pw(q0, q1, r["t"])
    prm = dict(p0=q0.tolist(), p1=q1.tolist(), length=r["L"], t=r["t"], u_extent=r.get("u_ext"), draft_deg=[r["angle_deg"].get("draft_l"), r["angle_deg"].get("draft_r")],
               edge={k: v for k, v in e.items() if k not in ("table", "rms_line", "line_slope", "line_z0")}, edge_table=e["table"])
    resid = r["t"] * 0 + (e.get("rms_pw") or e.get("rms_line") or 0)
    rows.append(make_row(fid, typ, prm, "rib2: iterative side-wall line fits (|n.w|>0.7, de>=2) + free-edge lower envelope (edge_pw)", resid, m, p5val))
    return r
for k, (p0, p1, z, t) in DS.INN_RIBS.items():
    rib_row(k, "rib", p0, p1, t, dict(p0=p0, p1=p1, t=t, free_z=z))
for k, (p0, p1, z0, z1, t) in DS.INN_GUSSETS.items():
    rib_row(k, "gusset", p0, p1, t, dict(p0=p0, p1=p1, t=t, z_at_p0=z0, z_at_p1=z1), sloped=True)
for k, (a_, bo, bi) in DS.ARMS.items():
    rib_row(k, "arm", a_, bi, DS.ARM_W, dict(start=a_, end=bi, t=DS.ARM_W, free_z="joint plane z_A 36.07"))
for k, (a_, b_, w) in DS.FLANGES.items():
    rib_row(k, "flange", a_, b_, w, dict(p0=a_, p1=b_, t=w), win=4.0)
dump("ribs", rows)
