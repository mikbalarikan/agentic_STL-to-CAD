from i2_rows import *
r=np.hypot(c[:,0],c[:,1]); th=np.degrees(np.arctan2(c[:,1],c[:,0]))%360
for zl,zh in ((40,45),(50,55),(58,62),(62.8,66),(70,76),(78,82)):
    m=(np.abs(n[:,2])<0.5)&(r>60)&(r<72)&(c[:,2]>=zl)&(c[:,2]<zh)
    h,ed=np.histogram(th[m],bins=np.arange(0,361,5),weights=a[m])
    print(zl,zh," ".join(f"{int(x/10):d}" if x>5 else "." for x in h))
print("deg bins of 5, from 0:")
# hub profile (upper side faces up) 
m=(n[:,2]>0.2)&(r>19)&(r<40)&(c[:,2]>83)&(c[:,2]<95)
for r0 in np.arange(19,40,1.0):
    s=m&(r>=r0)&(r<r0+1)
    if s.sum()>10: print(r0+.5, round(np.median(c[s,2]),2), s.sum())
