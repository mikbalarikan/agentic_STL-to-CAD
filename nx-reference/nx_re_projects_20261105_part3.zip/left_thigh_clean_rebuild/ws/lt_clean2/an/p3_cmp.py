import sys, numpy as np, open3d as o3d, trimesh
a, b = sys.argv[1], sys.argv[2]
def scene(m):
    sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(m.vertices), o3d.utility.Vector3iVector(m.faces))))
    return sc
A = trimesh.load(a); B = trimesh.load(b)
print(a, "vol", A.volume, "area", A.area, "wt", A.is_watertight); print(b, "vol", B.volume, "area", B.area, "wt", B.is_watertight)
def d(src, dst):
    p, _ = trimesh.sample.sample_surface(src, 400000, seed=2)
    sc = scene(dst)
    return sc.compute_distance(o3d.core.Tensor(p.astype(np.float32))).numpy()
for n, s, t in (("A->B", A, B), ("B->A", B, A)):
    x = d(s, t)
    print(n, "max %.4f p99 %.4f p95 %.4f mean %.4f" % (x.max(), np.percentile(x, 99), np.percentile(x, 95), x.mean()))
