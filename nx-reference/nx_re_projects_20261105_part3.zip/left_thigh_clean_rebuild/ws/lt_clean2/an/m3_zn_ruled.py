import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
exec(open('an/m3_s_loft.py').read().split("sets={")[0])
from scipy.interpolate import interp1d
def ruled(ys):
    C=np.array([sect(y if y<YM-0.2 else YM-0.5,0.5) for y in ys])
    C[-1]=0; C[-1][0]=70.85   # exact circle at mouth
    return interp1d(ys,C,axis=0,kind='linear')
def ev(model,ys):
    co=model(np.clip(P[:,1],ys[0],ys[-1])); rr=(basis(th)*co).sum(1); return r-rr
out={}
for ys in ([262,YM],[264,YM],[266,YM],[268,YM],[262,275,YM],[264,275,YM],[266,276,YM],[262,270,278,YM],[266,272,279,YM]):
    m=ruled(ys); d=ev(m,ys); a1,p1=rep(d,ys[0]); a2,_=rep(d,272)
    print('ruled sections',ys,': %.1f%% (Y>=%g) p50/90/99 %s ; %.1f%% (Y>=272)'%(a1,ys[0],np.round(p1,2),a2))
    out[str(ys)]=dict(pct=a1,p=list(map(float,p1)),pct272=a2)
json.dump(out,open('work/m3/ruled_test.json','w'),indent=1)
