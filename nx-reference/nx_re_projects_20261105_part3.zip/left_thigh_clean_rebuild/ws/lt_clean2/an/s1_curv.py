"""Principal curvature radii on the exposed faces of the envelope B-rep. usage s1_curv.py tag [fuzzy]"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_build import *
from s1_shell import faces
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomLProp import GeomLProp_SLProps
from OCP.BRep import BRep_Tool
from s1_lib import dist_to_mesh
import trimesh
def run(env, mesh_path, nu=220, nv=160):
    m = trimesh.load(mesh_path, process=False); v, f = np.asarray(m.vertices), np.asarray(m.faces)
    out = []
    for fc in faces(env):
        a = BRepAdaptor_Surface(fc, True); tp = a.GetType().name
        if tp == 'GeomAbs_Plane': continue
        surf = BRep_Tool.Surface_s(fc)
        sgn = -1.0 if fc.Orientation().name == 'TopAbs_REVERSED' else 1.0
        us = np.linspace(a.FirstUParameter(), a.LastUParameter(), nu); vs = np.linspace(a.FirstVParameter(), a.LastVParameter(), nv)
        uv = np.array([(uu, vv) for uu in us for vv in vs]); pts = np.array([[a.Value(u, w).X(), a.Value(u, w).Y(), a.Value(u, w).Z()] for u, w in uv])
        d = dist_to_mesh(pts, v, f); sel = d < 0.05
        if sel.sum() < 30: continue
        cx = []; 
        for (u, w) in uv[sel]:
            pr = GeomLProp_SLProps(surf, float(u), float(w), 2, 1e-7)
            if pr.IsCurvatureDefined(): cx.append((pr.MaxCurvature() * sgn, pr.MinCurvature() * sgn, pts[0][0]))
        cx = np.array(cx)
        # with outward normal: convex = curvature negative (centre of curvature inside)
        k = np.r_[cx[:, 0], cx[:, 1]]
        conv = -k[k < 0]; conc = k[k > 0]
        rc = (1 / conv) if len(conv) else np.array([np.inf]); rv = (1 / conc) if len(conc) else np.array([np.inf])
        out.append(dict(type=tp, n=int(sel.sum()), min_convex_R=float(np.min(rc)), p01_convex_R=float(np.percentile(rc, 0.1)), min_concave_R=float(np.min(rv)), p01_concave_R=float(np.percentile(rv, 0.1))))
    return out
if __name__ == '__main__':
    tag = sys.argv[1]; fz = float(sys.argv[2]) if len(sys.argv) > 2 else None
    env, lo, body, dr = build(tag, verbose=False)
    r = run(env, os.path.join(S1, f'env_{tag}.stl'))
    for x in r: print(x)
    json.dump(r, open(os.path.join(S1, f'curv_{tag}.json'), 'w'), indent=1)
