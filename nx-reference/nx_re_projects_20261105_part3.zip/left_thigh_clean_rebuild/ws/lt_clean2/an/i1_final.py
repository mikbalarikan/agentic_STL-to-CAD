import i1_run
from i1_core import *
import json, collections
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

OV = {
 "KNEE_BORE_REV": ("OK. Through bore D92.0 (part 5 92.1), step D95.9 (96.0), bore D110.0, levels -6.1 / -4.1 / 0.05 match part 5.", "keep part 5 values (92.0 / 96.0 / 110 / -6.1 / -4.1 / 0.05)"),
 "KNEE_RECESS_REV": ("Underside recess wall median radius 62.96 (D126.0 fit 126.1) vs part 5 125.5; wall runs to z -13.85, floor -8.35. Marginal.", "recess D126.0, floor -8.35"),
 "KNEE_FLOOR_PLANE": ("Floor z 0.05 matches. p90 comes from the ring r 60-64.5 where the scan steps up (z 0.15 at r 60-62, z 4.95 at r 62-64, wall top 7.5/34.75 beyond); part 5 has no step ring.", "add a revolved step ring z 4.95, r 62-64.5 (one revolve)"),
 "KNEE_SIDE_OPENING": ("Angles 155.0-244.75 and z 7.5 match (part 5 154.6-245.7). Deviation is at the wall-end flanges, not the opening.", "set angles 155.0 / 244.75"),
 "BOSS_B1": ("Column/spigot/hole match, but the whole B1 ear (wall cell outside the part-5 envelope, see EAR_B1_CELL) lies in this mask.", "see EAR_B1_CELL"),
 "TAB_C": ("Faces u 142.90 / 145.45 match part 5 (142.92 / 145.50); p90 comes from the slab outline/height (scan z range reaches the P3 platform 36.25, part 5 tab top 20.2).", "re-measure the slab outline (w, top z) on the scan; keep the 45 deg planes"),
 "TAB_D": ("Faces x -20.4 / -18.0 match (part 5 -20.42 / -18.03). Scan y range 179.3-192.9 (part 5 181.5-191.85) and top z 9.6 (part 5 8.15): slab too small.", "slab y 179.3-192.9, top z 9.6"),
 "COVERPIN_N1": ("Pin D2.85 (part 5 3.0), lug D7.4 (part 5 8.0), pin tip z 14.7 (len 7.2, part 5 6.93), lug base z 7.5 ok.", "pin D2.9 len 7.2, lug D7.4, web as measured"),
 "COVERPIN_N2": ("Pin D2.95, lug D7.5 (part 5 8.0), tip z 14.6, base 7.45.", "pin D2.95, lug D7.5"),
 "ROOT_BLENDS_R3": ("Circle fit of the transition tris is poor (rms 0.75): the floor next to the rib is sloped, so no clean radius is measurable this way; 3.0-3.4 indicated.", "keep R3.0 (not contradicted)"),
 "BOSS_B6": ("Marginal (0.50): column, spigot, hole match; deviation not isolated to a geometry error (gusset G_B6 meets this boss).", "no change; fix G_B6"),
 "BOSS_B7": ("Marginal (0.50): matches; gusset G_B7 meets this boss.", "no change; fix G_B7"),
 "PIN_P1": ("Lug D8.95, pin D4.0, lug top 34.8 match part 5. Marginal 0.6, gusset G_P1 meets the lug (its top profile is wrong).", "fix G_P1 (top rises 0.4 to 16.3 over s 4-12)"),
 "PIN_P2": ("Lug D8.9, pin D4.0 match. Marginal 0.6, rib R_P2_WALL joins here.", "fix R_P2_WALL"),
}
for f_ in FEATS:
    k = f_['id']
    if k in OV: f_['diagnosis'], f_['recommendation'] = OV[k]
    if k == "KNEE_BORE_REV": f_['params'].pop('axis_xy', None)
    if k.startswith("FLOORHOLE_H") and k != "FLOORHOLE_H1":
        w = f_['params'].get('hole_wall_z'); dep = (-0.3 - w[0] + 0.3) if w else None
        f_['diagnosis'] = f"hole D2.6 ok; hole depth only {dep:.1f} mm (scan wall z {w}) vs part 5 8.0; boss D {f_['params']['D_boss']} vs 6.0 (tapered, varies 5.1-5.8 per boss); Part 5 cuts the hole 3x too deep."
        f_['recommendation'] = f"hole depth {dep:.1f}, boss D {f_['params']['D_boss']} per boss"
    if k == "FLOORHOLE_H1":
        f_['diagnosis'] = "hole D3.05 (part 5 2.6), wall z -8.1..-0.3 (depth ~7.8), sits in a concave pocket D8.3-9.1 (wall z -11..-0.5); part 5 has only a D2.6 hole"
        f_['recommendation'] = "hole D3.05 depth 7.8 + D9 counterbore pocket, floor -4.2"
    if f_['part5_p90'] > 0.5 and not f_['diagnosis']:
        f_['diagnosis'] = "p90 > 0.5, cause not isolated by the fit; see plan plot"
    if k.startswith("RIB_") or k.startswith("GUS_") or k.startswith("ARM_") or k.startswith("LOWRIB"):
        if not f_['recommendation']: f_['recommendation'] = "rebuild from the measured p0/p1/t/top_profile in params (rib = thin extrude of the centre line; top = flat or one sloped plane + landing)"
OVR = {"GUS_G_B6": "G_B6: plate t 4.0 (part 5 3.0); sloped top line z = 8.9 + 1.33 (s-12) from s~2 (z -7) to a flat landing z 27.6 for s 26-34; part 5 line -15.5 -> 36.07 is ~8 mm low and has no landing.",
       "GUS_G_B7": "G_B7: same shape as G_B6 (t 4.0, slope 1.33, landing z 27.7 at y 250-258); part 5 has t 3.0 and a line ~8 mm low.",
       "RIB_R_DIAG_B": "R_DIAG_B: scan t 3.05 (part 5 3.5), centre line 0.7-1.2 mm off part 5 along the whole 84 mm; top 0.0 ok.",
       "RIB_R_DIAG_A": "R_DIAG_A: top z 0.0 for s 0-23 then ramps down to -5.0 at s 46 and stays -5 (part 5 flat -5.0); centre line rotated -1.3 deg (+1.2 / -0.8 mm).",
       "RIB_R_DIAG_B_UP": "R_DIAG_B_UP: top -5.0 ok, centre line 0.7 / 1.7 mm off, rotated -2.6 deg.",
       "RIB_R_X0": "R_X0: t 3.3 (part 5 3.0), centre line rotated -2.0 deg (+1.3 / -0.9 mm), top 0.0 ok."}
for f_ in FEATS:
    if f_['id'] in OVR: f_['diagnosis'] = OVR[f_['id']] + " | " + f_['diagnosis']
FEATS.sort(key=lambda r: (-r['lost_pts_vs_old'], -r['over05_pts_part5']))
json.dump(FEATS, open(OUTJSON, "w"), indent=1)
cnt = collections.Counter(f_['type'] for f_ in FEATS)
print(cnt)

# ---------------- plots
deep = np.where(de > 2.0)[0]
def plan(ids, out, title):
    fig, ax = plt.subplots(figsize=(11, 22))
    ax.scatter(c[deep, 0], c[deep, 1], s=0.3, c="#cfcfcf", linewidths=0, rasterized=True)
    allidx = []
    for fid in ids:
        allidx.append(np.load(os.path.join(MASKS, f"out_f_{fid}.npy")))
    ii = np.unique(np.concatenate(allidx)); ii = ii[np.argsort(c[ii, 2])]
    sc = ax.scatter(c[ii, 0], c[ii, 1], c=d5[ii], s=1.2, cmap="jet", vmin=0, vmax=1.5, linewidths=0, rasterized=True)
    plt.colorbar(sc, shrink=.35, label="part 5 deviation (mm)")
    for f_ in FEATS:
        if f_['id'] in ids and f_['part5_p90'] > 0.5 and f_['lost_pts_vs_old'] > 0.1 or (f_['id'] in ids and f_['over05_pts_part5'] > 0.35):
            m_ = np.load(os.path.join(MASKS, f"out_f_{f_['id']}.npy")); ax.annotate(f_['id'], (c[m_, 0].mean(), c[m_, 1].mean()), fontsize=7, color="k")
    ax.set_aspect("equal"); ax.grid(alpha=.3); ax.set_title(title)
    fig.savefig(out, dpi=75, bbox_inches="tight"); plt.close(fig)
plan([f_['id'] for f_ in FEATS], os.path.join(I1, "feature_masks_part5_dev.png"), "all feature masks, colour = part 5 scan->CAD deviation")
plan([f_['id'] for f_ in FEATS if f_['part5_p90'] > 0.5], os.path.join(I1, "feature_masks_flagged.png"), "flagged features (part 5 p90 > 0.5)")

# ---------------- report
cov = np.zeros(len(c), bool)
for f_ in FEATS: cov[np.load(os.path.join(MASKS, f"out_f_{f_['id']}.npy"))] = True
deepm = de >= 3.9
L = ["# I1 report: LT-OUT-001 interior + small feature inventory", "",
     f"Features measured: {len(FEATS)} rows ({', '.join(f'{k} {v}' for k, v in sorted(cnt.items()))}). Scan: 1.5M-tri decimation; deviation arrays dev_FINout (part 5) / dev_oldC (old).", "",
     "Interior ('deep', env distance >= 3.9 mm) area is 41.3 % of the part: old 86.4 % / part 5 75.0 % within 0.5 mm.",
     f"Feature masks cover {a[cov & deepm].sum()/a[deepm].sum()*100:.1f} % of that deep area, and {a[cov & deepm & (d5>=.5)].sum()/a[deepm & (d5>=.5)].sum()*100:.1f} % of the deep area where part 5 is off by >= 0.5 mm.", "",
     "Method: ribs/gussets/arms = linear LS of both vertical walls + per-1mm top profile with piecewise-linear fit; bosses/pins/holes = robust circle fits per radial ring; knee/hip = axisymmetric radius/plane peaks; openings = occupancy contour. 'lost' = points of total area that were within 0.5 mm for the old master and are not for part 5 (inside the mask).", "",
     "| # | id | type | n tris | old p90 | part 5 p90 | lost pts vs old | over0.5 pts (part 5) | diagnosis |", "|---|---|---|---|---|---|---|---|---|"]
for i, f_ in enumerate(FEATS):
    L.append(f"| {i+1} | {f_['id']} | {f_['type']} | {f_['n_tris']} | {f_['old_p90']} | {f_['part5_p90']}{' **' if f_['part5_p90']>0.5 else ''} | {f_['lost_pts_vs_old']} | {f_['over05_pts_part5']} | {f_['diagnosis'][:230].replace('|','/')} |")
L += ["", "## Missing in part 5 (scan features with no part 5 counterpart)"]
for fid in json.load(open(os.path.join(I1, "missing.json"))):
    f_ = next(x for x in FEATS if x['id'] == fid); L.append(f"- **{fid}**: {f_['diagnosis']} -> {f_['recommendation']}")
L += ["", "## Traced-outline traps (propose primitives)",
      "- PAD_RIGHT_2BOSS and EAR_B1_CELL look like cluster outlines if fitted from deviation; build instead as tilted rectangle + 2 cylinders + rim frame, and a sector/arc-wall cell (r, angle range, wall t 3) - listed with measured values.",
      "- OPENING_MX / OPENING_PX: use the polygon `outline_yz` from the scan occupancy contour (lines + arcs), not a free spline.",
      "- ARM_B2_D shelf: a 6 mm wide rectangle strip to z 4.4, not a traced band.", "",
      "## Not covered / open",
      "- Uncovered deep area where part 5 is off: the exterior-skin-adjacent zones (+X band, envelope) belong to other analysts; the (68,88) shallow facet is only logged.",
      "- Hip connector pad, conn holes, hip locating slots S1/S2 and the clip rails were not separately fitted (hip plate/ring/bolts rows give their p90; the connector pad lies in HIP_PLATE mask).", "",
      "Plots: feature_masks_part5_dev.png, feature_masks_flagged.png (same folder). Script chain: an\\i1_run.py -> an\\i1_final.py."]
open(os.path.join(I1, "REPORT.md"), "w", encoding="utf-8").write("\n".join(L))
print("top by lost:")
for f_ in FEATS[:12]: print(f"  {f_['id']:22s} lost {f_['lost_pts_vs_old']:.3f} over5 {f_['over05_pts_part5']:.3f} p5 {f_['part5_p90']}")
print("sum lost top10", sum(f_['lost_pts_vs_old'] for f_ in FEATS[:10]), "all", sum(f_['lost_pts_vs_old'] for f_ in FEATS))
print("uncovered lost %.2f" % (a[deepm & (d5 >= .5) & (d0 < .5) & ~cov].sum() / TOT * 100))
