import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
P=[]
for n,s in (("out_scan","out"),("inn_scan","inn")):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f); ex=np.load(f"work/m2/ext_{s}.npy")
    k=ex&(c[:,1]>=28)&(c[:,1]<=288); P.append(np.c_[c[k],ar[k],np.full(k.sum(),0 if s=="out" else 1)])
P=np.vstack(P); np.save("work/m2/ext_pts_long.npy",P); print(P.shape)
import m2_f_data as FD
D=FD.cells(36,288,P=P); np.save("work/m2/cells_long.npy",D); print(D.shape)
