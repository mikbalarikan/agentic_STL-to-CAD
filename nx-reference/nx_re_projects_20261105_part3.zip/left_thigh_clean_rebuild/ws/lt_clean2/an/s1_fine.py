import sys
from s1_build import *
tag=sys.argv[1]; lin=float(sys.argv[2]); ang=float(sys.argv[3])
env,lo,body,dr=build(tag,verbose=False)
import time; t=time.time()
V,F=to_mesh(env,lin,ang); print(len(F),time.time()-t)
import trimesh; trimesh.Trimesh(V,F,process=False).export(os.path.join(S1,f'envfine_{tag}.stl'))
