"""M4 step 2b: stations on the 5 joint chains + height profiles / wall faces by ray casting. Saves work/m4/stations.npz"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
from scipy.ndimage import gaussian_filter1d
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\an")
from rays import Caster
from m4_e_stations import lip_points, chains, centreline, W4

NAMES = {4: "KNEE_ARC", 1: "PX_WALL", 0: "PX_HIP", 2: "MX_HIP", 3: "MX_WALL"}
if __name__ == "__main__":
    P, idx = lip_points(); nc, lab = chains(P)
    CO = Caster(*lib.load("out_scan", 1500000)); CI = Caster(*lib.load("inn_scan", 1500000))
    T = np.arange(-6.0, 8.01, 0.1)
    ZO = np.arange(33.0, 34.71, 0.1)        # outer exterior-face levels (below the rim)
    ZI = np.arange(35.4, 37.01, 0.1)        # inner exterior-face levels (above the lip)
    res = {}
    for k in range(nc):
        if (lab == k).sum() < 200: continue
        cen, A, B = centreline(P[lab == k])
        sm = np.c_[gaussian_filter1d(cen[:, 1], 2, mode="nearest"), gaussian_filter1d(cen[:, 2], 2, mode="nearest")]
        s = cen[:, 0]
        tg = np.gradient(sm, axis=0); tg /= np.linalg.norm(tg, axis=1)[:, None]
        n = np.c_[tg[:, 1], -tg[:, 0]]
        ref = np.c_[np.full(len(sm), 20.0), np.clip(sm[:, 1], 0, 230)]
        sg = np.sign(((sm - ref) * n).sum(1)); sg[sg == 0] = 1
        if np.median(sg) < 0: n = -n
        # sign flips along a chain would signal a bad reference: report
        print(NAMES[k], "len %.0f" % s[-1], "n at start", n[0].round(2), "mid", n[len(n) // 2].round(2), "end", n[-1].round(2))
        S = len(s)
        # vertical rays
        Ho = np.full((S, len(T)), np.nan); Hi = np.full((S, len(T)), np.nan)
        q = sm[:, None, :] + T[None, :, None] * n[:, None, :]          # S,T,2
        qf = q.reshape(-1, 2)
        o = np.c_[qf, np.full(len(qf), 37.0)]; d = np.tile([0, 0, -1.0], (len(qf), 1))
        Ho = (37.0 - CO.hit(o, d)).reshape(S, len(T))
        o = np.c_[qf, np.full(len(qf), 33.8)]; d = np.tile([0, 0, 1.0], (len(qf), 1))
        Hi = (33.8 + CI.hit(o, d)).reshape(S, len(T))
        # horizontal rays
        def faces(C, zs):
            tin = np.full((S, len(zs)), np.nan); tout = np.full((S, len(zs)), np.nan)
            for j, z in enumerate(zs):
                o1 = np.c_[sm - 7 * n, np.full(S, z)]; d1 = np.c_[n, np.zeros(S)]
                tin[:, j] = -7 + C.hit(o1, d1)
                o2 = np.c_[sm + 12 * n, np.full(S, z)]; d2 = np.c_[-n, np.zeros(S)]
                tout[:, j] = 12 - C.hit(o2, d2)
            return tin, tout
        oin, oout = faces(CO, ZO)
        iin, iout = faces(CI, ZI)
        # extra levels for the tongue/rebate faces
        ZT = np.arange(35.0, 36.01, 0.1); tin_t, tout_t = faces(CO, ZT)
        ZR = np.arange(35.4, 36.01, 0.1); rin_t, rout_t = faces(CI, ZR)
        res[NAMES[k]] = dict(s=s, p=sm, n=n, T=T, Ho=Ho, Hi=Hi, ZO=ZO, oin=oin, oout=oout, ZI=ZI, iin=iin, iout=iout, ZT=ZT, tin_t=tin_t, tout_t=tout_t, ZR=ZR, rin_t=rin_t, rout_t=rout_t)
    flat = {f"{nm}__{kk}": vv for nm, dd in res.items() for kk, vv in dd.items()}
    np.savez(os.path.join(W4, "stations.npz"), **flat)
    print("saved", list(res))
