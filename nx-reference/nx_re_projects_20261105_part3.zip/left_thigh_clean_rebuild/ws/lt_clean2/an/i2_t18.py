from i2_view import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
show("v_lugD",-45,-5,165,200,18,'z',(36,95),size=12)
show("v_lug3",-55,-15,225,260,18,'z',(36,95),size=12)
