import sys
from s1_shell import *
from s1_build import build, cone_solid
from s1_geo import *
tag=sys.argv[1]
env,lo,body,dr=build(tag,verbose=False)
def test(shape,name,mf,t=3.1,jn=GeomAbs_Arc):
    lst=TopTools_ListOfShape(); lst.Append(mf); mk=BRepOffsetAPI_MakeThickSolid(); t0=time.time()
    mk.MakeThickSolidByJoin(shape,lst,-t,1e-3,BRepOffset_Skin,True,False,jn); mk.Build()
    s=mk.Shape() if mk.IsDone() else None
    print(name,t,'done',mk.IsDone(),'valid',valid(s) if s else None,'vol',round(volume(s)) if s else None,'orig',round(volume(shape)),round(time.time()-t0,1),flush=True)
    return s
test(body,'body loft∩cone'.replace('∩','^'),mouth_face(body))
loft_only=lo
# loft only, closing face at mouth (the cap at 287.39)
test(lo,'loft only',mouth_face(lo))
# env without cone
env2=fuse(lo,dr); test(env2,'loft+drum (no cone)',mouth_face(env2))
test(env,'full env',mouth_face(env))
