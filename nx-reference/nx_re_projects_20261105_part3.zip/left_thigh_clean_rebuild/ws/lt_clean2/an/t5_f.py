import sys; sys.path.insert(0,'an')
import numpy as np, lib, trimesh, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,2,figsize=(16,9))
for k,(a0,a1) in enumerate(((56,58),(51,52.5))):
    for nm,col in (("out_scan","tab:blue"),("inn_scan","tab:red")):
        v,f=lib.load(nm,1500000)
        ang=np.degrees(np.arctan2(v[:,0],-v[:,1])); r=np.hypot(v[:,0],v[:,1])
        m=(ang>a0)&(ang<a1)&(r>55)&(r<90)&(v[:,2]>-20)&(v[:,2]<80)
        ax[k].plot(r[m],v[m,2],'.',ms=1,color=col)
    ax[k].set_aspect('equal'); ax[k].grid(); ax[k].set_title("ang %g..%g  (rho,z)"%(a0,a1))
plt.savefig("work/t5/profile_rz.png",dpi=80)
