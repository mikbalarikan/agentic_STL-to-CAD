from i2_rows import *
import json, trimesh, open3d as o3d
from shapely.geometry import LineString, Point
from scipy.interpolate import splprep, splev
rows = []
x, y, z = c[:, 0], c[:, 1], c[:, 2]
# signed distance to the part-5 envelope (negative inside)
p = os.path.join(O, "sd.npy")
if os.path.exists(p): sd = np.load(p)
else:
    env = trimesh.load(os.path.join(W, "env_part5.stl"), process=False)
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(np.asarray(env.vertices, np.float32)), o3d.core.Tensor(np.asarray(env.faces, np.uint32)))
    sd = sc.compute_signed_distance(o3d.core.Tensor(c.astype(np.float32))).numpy(); np.save(p, sd)
print("sd pct", np.percentile(sd, [1, 5, 50, 95, 99]))
seams = json.load(open(r"C:\NX_MCP_WORKSPACE\lt_clean\work\seams.json"))
for nm, pts in seams.items():
    P = np.array(pts); tck, u = splprep([P[:, 0], P[:, 1]], k=3, s=0); uu = np.linspace(0, 1, 400); sx, sy = splev(uu, tck)
    ls = LineString(np.c_[sx, sy])
    # distance of every exterior tri to the polyline (vectorised on candidates)
    cand = np.flatnonzero((np.abs(sd) < 1.2) & (d < 1.2) & (x > P[:, 0].min() - 3) & (x < P[:, 0].max() + 3) & (y > P[:, 1].min() - 3) & (y < P[:, 1].max() + 3))
    from shapely import points as sp_points, distance as sp_dist
    dist = sp_dist(sp_points(c[cand, 0], c[cand, 1]), ls)
    near = cand[dist < 1.6]; dn = dist[dist < 1.6]
    # groove depth profile across: depth = max(0, -sd) for exterior skin tris (outer surface: n.outward). take tris within 0.5 of path
    core = near[dn < 0.5]
    ring = cand[(dist > 1.0) & (dist < 2.5)]
    base_ = np.median(-sd[ring]) if len(ring) > 20 else 0.0
    depth = (np.percentile(-sd[core], 90) - base_) if len(core) else None
    # width: lateral extent of tris with sd < -0.25 within 2 mm
    gm = near[(sd[near] < -0.25)]
    wid = (np.percentile(dn[np.isin(near, gm)], 95) * 2) if len(gm) else None
    mk = np.zeros(len(c), bool); mk[near] = True
    rows.append(make_row("SEAM_" + nm, "groove", dict(depth_p90=depth, width_p95=wid, n_core=int(len(core)), path_pts=len(P)), "scan tris within 1.6 mm of the plan spline, outer skin (|sd|<1.2): depth = p90 of -signed distance to the envelope",
                         None, mk, dict(width=1.25, depth=0.62, D_tube=1.25)))
# lip face
lip = level_fit((n[:, 2] < -0.9) & (z > 35.05) & (z < 35.6) & (d >= 0.0), tol=0.15)
mk = (n[:, 2] < -0.9) & (z > 35.0) & (z < 35.6)
rows.append(make_row("LIP_FACE", "plane", dict(z=lip["z"] if lip else None), "level fit of the parting (lip) face, nz<-0.9, z 35.05..35.6", lip["rms"] if lip else None, mk, dict(z=35.32)))
bf = (n[:, 2] < -0.9) & (z > 35.8) & (z < 36.4)
bl = level_fit(bf, tol=0.15)
rows.append(make_row("JOINT_BOSS_FACES", "plane", dict(z=bl["z"] if bl else None), "level fit of boss / arm / P3 end faces at datum A", bl["rms"] if bl else None, bf, dict(z=36.07)))
dump("seams_lip", rows)
