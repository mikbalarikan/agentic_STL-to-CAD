import sys, numpy as np, trimesh, open3d as o3d
for w in ("out","inn"):
    e=trimesh.load(f"nx/P5c/{w}_E0.stl",process=False); c=trimesh.load(f"nx/P5c/{w}_P5c.stl",process=False)
    pts,_=trimesh.sample.sample_surface(e,600000,seed=2)
    s=o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(c.vertices,np.float32)),o3d.core.Tensor(np.asarray(c.faces,np.uint32)))
    d=s.compute_distance(o3d.core.Tensor(pts.astype(np.float32))).numpy()
    sel=(pts[:,0]>55)&(pts[:,0]<78)&(pts[:,1]>-40)&(pts[:,1]<-20)
    bad=sel&(d>0.3)
    print(w,"E0 samples near the dip",sel.sum(),"farther than 0.3 from the CAD:",bad.sum(), (pts[bad].min(0).round(1),pts[bad].max(0).round(1)) if bad.any() else "")
    allbad=(d>0.3)
    print("   whole E0: >0.3 from CAD", allbad.sum(), "of", len(d))
