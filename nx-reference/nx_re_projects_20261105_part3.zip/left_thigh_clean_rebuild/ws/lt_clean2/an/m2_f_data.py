"""Cell-binned exterior data for the loft fit (slab 2 mm in Y x 2 deg about (40,35)); drum footprint removed."""
import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
CX0,CZ0=40.0,35.0
def drum_R(z): return 68.9119-np.abs(z-37.2532)*0.02967
def cells(ymin=36,ymax=272,dy=2.0,dth=2.0,P=None):
    if P is None: P=np.load("work/m2/ext_pts.npy")
    x,y,z,a=P[:,0],P[:,1],P[:,2],P[:,3]
    drum=(np.hypot(x,y)<drum_R(np.clip(z,-13.9,83.62))+0.8)&(z>-14.7)&(z<84.4)&(y<75)
    P=P[~drum&(y>=ymin)&(y<=ymax)]
    x,y,z,a=P[:,0],P[:,1],P[:,2],P[:,3]
    th=np.arctan2(z-CZ0,x-CX0)
    iy=np.floor((y-ymin)/dy).astype(int); it=np.floor((th+np.pi)/np.radians(dth)).astype(int)
    key=iy*1000+it
    o=np.argsort(key); key=key[o]; P=P[o]; th=th[o]
    u,st,cnt=np.unique(key,return_index=True,return_counts=True)
    out=[]
    for s,c in zip(st,cnt):
        if c<3: continue
        q=P[s:s+c]
        out.append((np.median(q[:,1]),np.median(q[:,0]),np.median(q[:,2]),q[:,3].sum()))
    D=np.array(out)
    return D   # y,x,z,area
if __name__=="__main__":
    D=cells(); print(D.shape); np.save("work/m2/cells.npy",D)
