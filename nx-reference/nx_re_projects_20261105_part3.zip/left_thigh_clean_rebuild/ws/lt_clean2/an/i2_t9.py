from i2_sec import *
v,f=mesh("scan"); vp,fp=mesh("p5")
ys=[180,200,230,250,258,262]
fig,axs=plt.subplots(3,2,figsize=(22,16))
for ax,y0 in zip(axs.flat,ys):
    for (vv,ff,col,lw) in ((vp,fp,'r',1.0),(v,f,'k',.8)):
        for seg in lib.section(vv,ff,1,float(y0)): ax.plot(seg[:,0],seg[:,2],col+'-',lw=lw)
    ax.set_xlim(-30,115); ax.set_ylim(30,115); ax.grid(alpha=.3); ax.set_aspect('equal'); ax.set_title(f"y={y0}")
plt.tight_layout(); plt.savefig(os.path.join(O,"hip_secs.png"),dpi=55)
