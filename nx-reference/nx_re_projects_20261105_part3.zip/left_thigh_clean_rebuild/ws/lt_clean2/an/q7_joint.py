import trimesh, numpy as np
for w in ("out","inn"):
    M=trimesh.load(f"nx/P5d/{w}_P5d_final.stl",process=True)
    n=M.face_normals; c=M.triangles_center; a=M.area_faces
    m=(np.abs(n[:,2])>0.999)&(c[:,2]>30)&(c[:,2]<42)
    z=np.round(c[m,2],2); u,inv=np.unique(z,return_inverse=True); ar=np.bincount(inv,a[m])
    print(w,"horizontal planes z 30..42 (z, area mm2, normal sign):")
    for zz,aa in zip(u,ar):
        if aa>20: print("   z %.2f area %.0f  nz %s"%(zz,aa,"+" if n[m][z==zz][:,2].mean()>0 else "-"))
    print("  bbox",M.bounds.round(2).tolist(),"volume %.0f"%M.volume,"watertight",M.is_watertight)
