from i2_sec import *
v,f=mesh("scan"); vp,fp=mesh("p5")
ys=[-10,0,10,20,30,40,50,60,70,80,90,100,110,120,130,138]
fig,axs=plt.subplots(4,4,figsize=(22,16))
for ax,y0 in zip(axs.flat,ys):
    for (vv,ff,col,lw) in ((vp,fp,'r',1.0),(v,f,'k',.8)):
        for seg in lib.section(vv,ff,1,float(y0)): ax.plot(seg[:,0],seg[:,2],col+'-',lw=lw)
    ax.set_xlim(20,100); ax.set_ylim(60,95); ax.grid(alpha=.3); ax.set_title(f"y={y0}")
plt.tight_layout(); plt.savefig(os.path.join(O,"run_secs.png"),dpi=55)
