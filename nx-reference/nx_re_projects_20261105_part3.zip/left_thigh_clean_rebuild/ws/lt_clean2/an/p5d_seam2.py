import json, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig, ax = plt.subplots(2, 2, figsize=(14, 10))
seams = json.load(open("work/seams.json"))
for i, w in enumerate(("out", "inn")):
    d = json.load(open(f"work/p5d/seam_{w}.json"))
    for j, n in enumerate("AB"):
        r = d[n]; Q = np.array(r["Q"]); dep = np.array(r["depth"]); ok = np.array(r["ok"])
        a = ax[i, 0]
        a.plot(Q[ok, 0], Q[ok, 1], ".", ms=3, label=f"{w} {n} measured"); a.plot(Q[~ok, 0], Q[~ok, 1], "rx", ms=4)
        P = np.array(seams[n]); a.plot(P[:, 0], P[:, 1], "ko", ms=4)
        a.set_aspect("equal"); a.legend()
        ax[i, 1].plot(r["s"], dep, label=f"{n}"); ax[i, 1].plot(r["s"], r["width"], "--", label=f"{n} width")
        ax[i, 1].legend(); ax[i, 1].set_title(w)
plt.savefig("work/p5d/seam_paths.png", dpi=80)
for w in ("out","inn"):
    d = json.load(open(f"work/p5d/seam_{w}.json"))
    for n in "AB":
        r=d[n]; s=np.array(r["s"]); ok=np.array(r["ok"]); dep=np.array(r["depth"])
        # print ranges where not ok
        bad=np.where(~ok)[0]; print(w,n,"not-grooved station idx", bad.tolist()[:40], "s of ends", s[0], s[-1])
