import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
P=[]
for k,n in enumerate(("out_scan","inn_scan")):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    radial=(c[:,0]*nn[:,0]+c[:,1]*nn[:,1])/np.maximum(r,1e-9)
    m=(r>66)&(r<70.5)&(radial>0.97)&(np.abs(ang-10)<35)&(c[:,2]>-9)&(c[:,2]<79)
    P.append(np.c_[c[m],np.full(m.sum(),k)])
P=np.vstack(P)
def model(q,kind):
    # q: Rp,zp,t, x0o,y0o, x0i,y0i  (per-scan axis) or shared
    Rp,zp,t=q[:3]
    if kind=="shared": x0=np.full(len(P),q[3]); y0=np.full(len(P),q[4])
    else: x0=np.where(P[:,3]==0,q[3],q[5]); y0=np.where(P[:,3]==0,q[4],q[6])
    d=np.hypot(P[:,0]-x0,P[:,1]-y0)
    return d-(Rp-np.abs(P[:,2]-zp)*t)
for kind,q0 in (("shared",[68.8,36.8,.0275,.17,-.1]),("perscan",[68.8,36.8,.0275,.17,-.1,.1,-.1])):
    s=least_squares(model,q0,args=(kind,),loss="soft_l1",f_scale=.1); r=np.abs(model(s.x,kind))
    print(kind,s.x.round(4),'draft deg',np.degrees(np.arctan(s.x[2])).round(4),'p50/p90/p95',np.percentile(r,[50,90,95]).round(4))
# per-scan cone fits with own axis
for k in (0,1):
    Q=P[P[:,3]==k]
    def res(q):
        d=np.hypot(Q[:,0]-q[3],Q[:,1]-q[4]); return d-(q[0]-np.abs(Q[:,2]-q[1])*q[2])
    s=least_squares(res,[68.8,36.8,.0275,.1,-.1],loss="soft_l1",f_scale=.1)
    print('scan',k,s.x.round(4),'draft',np.degrees(np.arctan(s.x[2])).round(3),'p90',np.percentile(np.abs(res(s.x)),90).round(4))
# fixed-axis-at-origin variants / design roundings
def evalset(Rp,zp,dd,ax=(0.17,-0.10)):
    t=np.tan(np.radians(dd)); d=np.hypot(P[:,0]-ax[0],P[:,1]-ax[1]); r=np.abs(d-(Rp-np.abs(P[:,2]-zp)*t))
    return np.percentile(r,[50,90,95,99]).round(3), (r<0.1).mean().round(3)
print('design A (68.8,36.8,1.6 off axis)',evalset(68.8,36.8,1.6))
print('design B (68.75,36.8,1.55)',evalset(68.75,36.8,1.55))
print('design C origin axis (68.9,36.8,1.6)',evalset(68.9,36.8,1.6,(0,0)))
for zp in (36.07,35.5,36.8,37.25):
  for dd in (1.5,1.55,1.6,1.7):
    s=least_squares(lambda q: np.hypot(P[:,0]-.17,P[:,1]+.1)-(q[0]-np.abs(P[:,2]-zp)*np.tan(np.radians(dd))),[68.8],loss="soft_l1",f_scale=.1)
    r=np.abs(np.hypot(P[:,0]-.17,P[:,1]+.1)-(s.x[0]-np.abs(P[:,2]-zp)*np.tan(np.radians(dd))))
    print(zp,dd,'Rp',s.x[0].round(3),np.percentile(r,[50,90,95]).round(3))
