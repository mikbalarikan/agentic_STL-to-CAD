"""Exterior sections of the body at fine Y: polar profiles r(theta) about (cx(y), 35). Writes work/m2/secs.npz + masks."""
import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
P=[];TRI={}
for n,s in (("out_scan","out"),("inn_scan","inn")):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f); ex=np.load(f"work/m2/ext_{s}.npy")
    idx=np.where(ex&(c[:,1]>=28)&(c[:,1]<=275))[0]
    np.save(f"work/masks/{s}_ext_body.npy",idx); print(s,len(idx))
    P.append(np.c_[c[idx],ar[idx],np.full(len(idx),0 if s=="out" else 1)])
P=np.vstack(P); np.save("work/m2/ext_pts.npy",P)
Ys=np.arange(30,271,2.0)
NB=720
th=(np.arange(NB)+0.5)/NB*2*np.pi-np.pi
R=np.full((len(Ys),NB),np.nan); CEN=np.zeros((len(Ys),2))
for i,y in enumerate(Ys):
    m=np.abs(P[:,1]-y)<=1.0
    q=P[m]; x,z=q[:,0],q[:,2]
    cx=(x.min()+x.max())/2; cz=35.0; CEN[i]=(cx,cz)
    r=np.hypot(x-cx,z-cz); a=np.arctan2(z-cz,x-cx)
    b=((a+np.pi)/(2*np.pi)*NB).astype(int)%NB
    for k in range(NB):
        s=b==k
        if s.sum()>=2: R[i,k]=r[s].mean()
np.savez("work/m2/secs.npz",Ys=Ys,R=R,CEN=CEN,th=th)
fig,ax=plt.subplots(1,1,figsize=(14,12))
for i,y in enumerate(Ys):
    if i%5: continue
    ok=~np.isnan(R[i]); ax.plot(CEN[i,0]+R[i][ok]*np.cos(th[ok]),CEN[i,1]+R[i][ok]*np.sin(th[ok]),'.',ms=1.5,label=str(y))
ax.set_aspect('equal'); ax.legend(ncol=3); ax.grid(True); plt.savefig("work/m2/ext_overlay.png",dpi=60)
