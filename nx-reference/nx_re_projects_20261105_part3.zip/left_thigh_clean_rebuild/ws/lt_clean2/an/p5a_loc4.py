import sys, numpy as np
sys.path.insert(0,'an')
import lib
which, tag, mask = sys.argv[1:4]
v,f = lib.load({'out':'out_scan','inn':'inn_scan'}[which],1500000)
c,nn,ar = lib.tri_data(v,f)
d = np.load('work/dev_%s_%s.npz'%(tag,which))['d1']
m = np.load('work/masks/%s_f_%s.npy'%(which,mask))
dm=d[m]; cm=c[m]; nm=nn[m]; bad=dm>0.5
print(mask,len(m),'bad',bad.sum(),'p90 %.2f'%np.percentile(dm,90))
for nme,i,b in (('x',0,np.arange(-45,125,15)),('y',1,np.arange(265,280,1.5)),('z',2,np.arange(-35,45,8))):
    h,_=np.histogram(cm[bad,i],b); a,_=np.histogram(cm[:,i],b)
    print(nme,[(round(float(b0),1),int(hh),int(aa)) for b0,hh,aa in zip(b[:-1],h,a) if aa>0])
# normal direction of bad
print('bad normal mean',nm[bad].mean(0).round(2),'|ny|>0.9 frac',(abs(nm[bad][:,1])>0.9).mean().round(2))
