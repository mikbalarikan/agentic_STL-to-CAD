"""Design-table writer: tighten feature masks by SCAN-INTRINSIC geometry (type of surface: wall / free-edge / plane /
radial around a fitted centre). The design values only locate the primitive; tolerances (0.45) are below the 0.5 gate.
Writes work/masks/<w>_f_<ID>.npy (originals kept in work/masks/orig), report work/dt/tighten_report.json"""
import sys, os, json, shutil
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an"); sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\nx")
import numpy as np, lib
from matplotlib.path import Path
import design2 as D
W = r"C:\NX_MCP_WORKSPACE\lt_clean2\work"
data = {}
for w in ("out", "inn"):
    v, f = lib.load(w + "_scan", 1500000); c, n, a = lib.tri_data(v, f)
    data[w] = dict(c=c, n=n, a=a, old=np.load(W + (r"\dev_oldC.npz" if w == "out" else r"\dev_oldInnB.npz"))["d1"],
                   p5=np.load(W + (r"\dev_FINout.npz" if w == "out" else r"\dev_FINinn.npz"))["d1"])


def zprof(poly, s):
    xs = [p[0] for p in poly]; zs = [p[1] for p in poly]
    return np.interp(s, xs, zs)


def rib_mask(w, p0, p1, t, poly=None, flat=None, up=True, tol=0.45, ztol=0.6, extra_s=1.0):
    """wall tris (normal along the lateral axis, on one of the two wall planes) + free-edge tris (normal along the
    up/down axis, z within ztol of the profile)."""
    d = data[w]; c, n = d["c"], d["n"]
    p0 = np.array(p0, float); p1 = np.array(p1, float); L = np.linalg.norm(p1 - p0); u = (p1 - p0) / L; wv = np.array([-u[1], u[0]])
    dd = c[:, :2] - p0; s = dd @ u; l = dd @ wv
    inb = (s > -extra_s) & (s < L + extra_s)
    wall = inb & (abs(l) - t / 2 > -tol) & (abs(l) - t / 2 < tol) & (abs(n[:, :2] @ wv) > 0.9)
    zt = zprof(poly, s) if poly is not None else np.full(len(c), flat)
    nz = n[:, 2] if up else -n[:, 2]
    top = inb & (abs(l) < t / 2 + 0.3) & (nz > 0.25) & (abs(c[:, 2] - zt) < ztol)
    return wall | top


def radial_mask(w, ctr, rmax, zr=None):
    d = data[w]; c = d["c"]
    r = np.hypot(c[:, 0] - ctr[0], c[:, 1] - ctr[1]); m = r <= rmax
    if zr:
        m &= (c[:, 2] >= zr[0]) & (c[:, 2] <= zr[1])
    return m


def plane_mask(w, axis, level, nmin=0.97, tol=0.35, extra=None):
    d = data[w]; c, n = d["c"], d["n"]
    m = (abs(n[:, axis]) > nmin) & (abs(c[:, axis] - level) < tol)
    return m if extra is None else m & extra


R = []


def apply(w, fid, newmask_bool, why, note=""):
    d = data[w]; p = os.path.join(W, "masks", "%s_f_%s.npy" % (w, fid))
    orig = os.path.join(W, "masks", "orig", os.path.basename(p))
    if not os.path.exists(orig):
        shutil.copyfile(p, orig)
    old = np.load(orig)
    keep = old[newmask_bool[old]]
    pc = lambda arr, idx: (round(float(np.percentile(arr[idx], 90)), 2) if len(idx) > 5 else None)
    row = dict(w=w, id=fid, n_orig=int(len(old)), n_new=int(len(keep)), why=why, note=note,
               old_p90_orig=pc(d["old"], old), old_p90_new=pc(d["old"], keep), p5_p90_orig=pc(d["p5"], old), p5_p90_new=pc(d["p5"], keep))
    if len(keep) >= 200 or (len(keep) >= 40 and len(old) < 400):
        np.save(p, keep); row["written"] = True
    else:
        row["written"] = False; row["note"] += " (too few tris left: mask NOT replaced)"
    R.append(row); return row


# ------------------------------------------------------------------ outer ribs / gussets / low ribs
o = "out"
p0, p1, t, poly = D.OUT_RIBS_RAMP["R_DIAG_A"]; apply(o, "RIB_R_DIAG_A", rib_mask(o, p0, p1, t, poly=poly), "rib: 2 wall planes + ramped top")
p0, p1, z, t = D.OUT_RIBS["R_DIAG_B_UP"]; apply(o, "RIB_R_DIAG_B_UP", rib_mask(o, p0, p1, t, flat=z), "rib: 2 walls + flat top -5.0")
p0, p1, t, poly = D.OUT_GUSSETS["G_B7"]; apply(o, "GUS_G_B7", rib_mask(o, p0, p1, t, poly=poly, ztol=1.0), "gusset: 2 walls + sloped top / landing")
p0, p1, t, poly = D.OUT_GUSSETS["G_P1"]; apply(o, "GUS_G_P1", rib_mask(o, p0, p1, t, poly=poly, ztol=1.0), "gusset: 2 walls + ramp")
p0, p1, t, poly = D.OUT_GUSSETS["G_LONG_HIP"]; apply(o, "GUS_G_LONG_HIP", rib_mask(o, p0, p1, t, poly=poly, ztol=1.0), "gusset: 2 walls + 9.9 deg ramp")
for nm in ("LOWRIB_B2", "LOWRIB_B1"):
    p0, p1, t, z = D.LOWRIBS[nm]; apply(o, nm, rib_mask(o, p0, p1, t, flat=z), "low rib: 2 walls + flat top 5.0")
apply(o, "BOSS_B1", radial_mask(o, D.BOSSES["B1"], 8.1), "column / spigot / hole only (r <= 8.1); ear lobe has its own mask")
apply(o, "BOSS_B7", radial_mask(o, D.BOSSES["B7"], 8.1), "column / spigot / hole only (r <= 8.1)")
for k, h in D.KNEE_HOLE_FLOOR.items():
    apply(o, "FLOORHOLE_" + k, radial_mask(o, (h[0], h[1]), 3.4 if h[2] is None else h[2] / 2 + 0.5), "hole wall + boss only", "boss D tapers 5.1-5.8")
c_ = data[o]["c"]; n_ = data[o]["n"]; r_ = np.hypot(c_[:, 0], c_[:, 1])
apply(o, "KNEE_FLOOR_PLANE", plane_mask(o, 2, 0.0, 0.97, 0.3, extra=(r_ < 60.2) & (r_ > 55.0)), "floor plane r 55-60.2 only (ring r 60-64.5 = opening wall-end root)")
st, eo, ei = D.ARMS["ARM_B2_D"]; u = np.array(eo) - np.array(st); L = np.linalg.norm(u); u /= L; wv = np.array([-u[1], u[0]])
dd = c_[:, :2] - np.array(st); s_ = dd @ u; l_ = dd @ wv
strip = (s_ > 0) & (s_ < L + 1) & (l_ > 3.6 - 0.45) & (l_ < 9.8 + 0.45) & (c_[:, 2] > 3.0) & (c_[:, 2] < 6.5)
apply(o, "ARM_B2_D_SHELF", strip, "strip top z 4.45 + its side walls (z 3-6.5) in the strip frame", "arm frame from design2.ARMS")
P = D.PAD_RIGHT; th = np.radians(P["angle_deg"]); uu = np.array([np.cos(th), np.sin(th)]); ww = np.array([-np.sin(th), np.cos(th)])
dd = c_[:, :2] - np.array(P["origin"]); U = dd @ uu; Wc = dd @ ww
pl = P["plate"]
inpl = (U > pl["u"][0] - .45) & (U < pl["u"][1] + .45) & (Wc > pl["w"][0] - .45) & (Wc < pl["w"][1] + .45)
apply(o, "PAD_RIGHT_2BOSS", inpl & (c_[:, 2] > 27.5) & (c_[:, 2] < 36.0) & ((n_[:, 2] > 0.9) | (abs(n_[:, 2]) < 0.3)),
      "plate / frame / rings: tris inside the pad rectangle at z 27.5-36 (tops and side walls)")
E = D.EAR_B1; cx, cy = E["circle_centre"]
poly_ = [(61.2, -32.35), (73.17, -32.35)] + [(80 * np.cos(a), 80 * np.sin(a)) for a in np.radians(np.linspace(np.degrees(np.arctan2(-32.35, 73.17)), np.degrees(np.arctan2(-50.6, 62.0)), 12))] + [(53.0, -43.5), (53.6, -40.0)]
pth = Path(poly_)
inpoly = pth.contains_points(c_[:, :2]) | (np.hypot(c_[:, 0] - cx, c_[:, 1] - cy) < E["circle_R"] + 0.5)
apply(o, "EAR_B1_CELL", inpoly & (c_[:, 2] > 8.0) & (c_[:, 2] < 37.0) & ((n_[:, 2] > 0.95) | (abs(n_[:, 2]) < 0.3)), "lobe top (z~36) and vertical sides inside the lobe plan hull (z > 8)")

# ------------------------------------------------------------------ inner
i = "inn"; ci = data[i]["c"]; ni = data[i]["n"]
for nm in ("CH_RUN_RIB_L", "CH_RUN_RIB_R"):
    p0, p1, t, poly = D.CH_RUN[nm]; apply(i, nm, rib_mask(i, p0, p1, t, poly=poly, up=False, ztol=0.6), "run rib: 2 walls + ramped free edge")
p0, p1, t, poly = D.INN_RIBS_RAMP["I_LONG_HIP"]; apply(i, "I_LONG_HIP", rib_mask(i, p0, p1, t, poly=poly, up=False), "rib: 2 walls + ramped free edge 9.95 deg")
for nm in ("IG_P1", "IG_P2"):
    p0, p1, t, poly = D.INN_GUSSETS[nm]; apply(i, nm, rib_mask(i, p0, p1, t, poly=poly, up=False, ztol=1.0), "gusset: 2 walls + sloped free edge")
fe = {r["id"]: r for r in json.load(open(r"C:\NX_MCP_WORKSPACE\lt_clean2\FEATURES_inn.json"))}
for nm in ("SPOKE_IN_22", "SPOKE_IN_108", "SPOKE_IN_161", "SPOKE_IN_227", "SPOKE_IN_327", "SPOKE_OUT_108", "SPOKE_OUT_327"):
    q = fe[nm]["params"]; apply(i, nm, rib_mask(i, q["p0"], q["p1"], q["t"], flat=75.07, up=False, extra_s=0.5), "spoke: 2 walls + free edge 75.07")
q = fe["FL_KNEE_MX"]["params"]; apply(i, "FL_KNEE_MX", rib_mask(i, q["p0"], q["p1"], q["t"], flat=36.07, up=False), "flange: 2 walls + free face 36.07")
apply(i, "B1_col", radial_mask(i, D.BOSSES["B1"], 8.1), "column only (r <= 8.1); the lobe has its own mask")
apply(i, "B2_pocket", radial_mask(i, D.BOSSES["B2"], 5.6, zr=(36.0, 39.5)), "pocket wall + floor only (r <= 5.6, z 36-39.5)")
for b in ("B1", "B2", "B7"):
    zr = (39.0, 76.0) if b == "B7" else (39.0, 90.0)
    apply(i, b + "_bore", radial_mask(i, D.BOSSES[b], 5.6, zr=zr),
          "bore + counterbore only (r <= 5.6), mouth lead-in z>76 excluded" if b == "B7" else "bore + counterbore only (r <= 5.6)")
for h, (hx, hy) in D.CH_HOLES.items():
    if h != "H3":
        apply(i, "CH_" + h, radial_mask(i, (hx, hy), 3.5), "hole wall + boss only (r <= 3.5)")
apply(i, "LIP_FACE", plane_mask(i, 2, 35.31, 0.97, 0.3), "lip plane tris only (|nz|>0.97, |z-35.31|<0.3)")
yb = D.INN_HIP["blocks"]["y1"]
for nm in ("HIP_BLOCK_L", "HIP_BLOCK_R"):
    apply(i, nm, plane_mask(i, 1, yb, 0.97, 0.35) | ((abs(ni[:, 0]) > 0.97) & (abs(abs(ci[:, 0] - 37.97) - 52.6) < 0.5)), "block end face y 272.4 + inner x faces (clearance cylinder side)")
ang = np.degrees(np.arctan2(ci[:, 1], ci[:, 0])) % 360; ri = np.hypot(ci[:, 0], ci[:, 1])
win = ((abs(ang - 155.0) < 1.5) | (abs(ang - 245.0) < 1.5)) | ((abs(ci[:, 2] - 62.55) < 0.3) & (ni[:, 2] < -0.9))
apply(i, "KNEE_WINDOW", win & (ri > 54) & (ri < 70) & (ci[:, 2] > 36) & (ci[:, 2] < 64), "window side edges (155 / 245 deg) + lintel plane 62.55")
st, eo, ei = D.ARMS["ARM_B2_D"]; u = np.array(ei) - np.array(st); L = np.linalg.norm(u); u /= L
nvec = np.array([-u[1], u[0]])
if nvec[0] < 0:
    nvec = -nvec
dd = ci[:, :2] - np.array(st); s_ = dd @ u; o_ = dd @ nvec
apply(i, "MISS_B2_DOME", (s_ >= 12) & (s_ <= 27) & (o_ >= 1.8) & (o_ <= 9.5) & (ni[:, 2] < -0.2) & (ci[:, 2] > 50) & (ci[:, 2] < 80),
      "vault ceiling s 12..27, off 1.8..9.5 from the arm (cylinder R6.5, 30 deg)")
acx, acy = D.ARC_RIB["centre"]; ra = np.hypot(ci[:, 0] - acx, ci[:, 1] - acy); aa = np.degrees(np.arctan2(ci[:, 1] - acy, ci[:, 0] - acx))
rad = np.column_stack([ci[:, 0] - acx, ci[:, 1] - acy]) / np.maximum(ra, 1e-9)[:, None]; nr = (ni[:, :2] * rad).sum(1)
arcm = (aa > 55) & (aa < 87) & ((((abs(ra - 99.25) < 0.45) | (abs(ra - 102.35) < 0.45)) & (abs(nr) > 0.9)) | ((abs(ra - 100.8) < 1.9) & (ni[:, 2] < -0.25) & (ci[:, 2] > 63) & (ci[:, 2] < 72.5)))
apply(i, "MISS_ARC_RIB", arcm, "arc rib R100.8: 2 wall radii + free edge 65.1 / 71.05")
sx, sy = D.OVAL_SLOT["centre"]
apply(i, "MISS_OVAL_SLOT", (abs(ci[:, 0] - sx) < 2.6) & (abs(ci[:, 1] - sy) < 3.1), "slot region only")
inp = pth.contains_points(ci[:, :2]) | (np.hypot(ci[:, 0] - cx, ci[:, 1] - cy) < E["circle_R"] + 0.5)
apply(i, "MISS_B1_EAR", inp & (ci[:, 2] > 37.0) & (ci[:, 2] < 78.0) & (abs(ni[:, 2]) < 0.3), "lobe vertical walls only (|nz|<0.3) inside the lobe plan hull")
json.dump(R, open(W + r"\dt\tighten_report.json", "w"), indent=1)
for r in R:
    print("%-4s %-18s n %6d -> %6d  old p90 %5s -> %5s | p5 p90 %5s -> %5s %s" % (r["w"], r["id"], r["n_orig"], r["n_new"], r["old_p90_orig"], r["old_p90_new"], r["p5_p90_orig"], r["p5_p90_new"], "" if r["written"] else "NOT WRITTEN"))
