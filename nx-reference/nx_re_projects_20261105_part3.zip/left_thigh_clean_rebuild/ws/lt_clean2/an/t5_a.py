import sys; sys.path.insert(0,'an')
import numpy as np, lib
from scipy.optimize import least_squares
D={}
for nm in ("out_scan","inn_scan"):
    v,f=lib.load(nm,1500000); c,n,a=lib.tri_data(v,f)
    sel=(c[:,0]>40)&(c[:,1]<-30)&(c[:,1]>-56)
    cc=c[sel];nn=n[sel];aa=a[sel]
    r=np.hypot(cc[:,0],cc[:,1]); ang=np.degrees(np.arctan2(cc[:,0],-cc[:,1]))
    rad=(nn[:,0]*cc[:,0]+nn[:,1]*cc[:,1])/r
    ext=(rad>0.85)&(r>69)&(ang>52)&(ang<67)
    D[nm]=(cc[ext],r[ext],ang[ext],aa[ext])
# profile r(z), by 1.5mm bins, both scans
print("z  r_out r_inn")
zs=np.arange(-10,66,2.0)
for z0 in zs:
    s=[]
    for nm in D:
        cc,r,ang,aa=D[nm]; m=(cc[:,2]>=z0)&(cc[:,2]<z0+2)
        s.append("%7.2f(%4d)"%(np.median(r[m]),m.sum()) if m.sum()>15 else "   -   ")
    print("%5.1f"%(z0+1)," ".join(s))
# angle dependence at z 20..30: fit circle in XY
for nm in D:
    cc,r,ang,aa=D[nm]; m=(cc[:,2]>20)&(cc[:,2]<32)
    P=cc[m][:,:2]
    def res(q): return np.hypot(P[:,0]-q[0],P[:,1]-q[1])-q[2]
    q=least_squares(res,[0,0,80],loss='soft_l1',f_scale=0.1).x
    print(nm,"circle z20-32 centre %.2f %.2f R %.3f resid rms %.3f"%(q[0],q[1],q[2],np.sqrt(np.mean(res(q)**2))))
    # fixed centre 0,0 : r vs ang
    for a0 in range(52,67,3):
        mm=m&(ang>=a0)&(ang<a0+3); print("   ang %d..%d r med %.3f n %d"%(a0,a0+3,np.median(r[mm]),mm.sum()))
