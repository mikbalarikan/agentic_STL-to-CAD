import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from m1_r_design import profile,dist2poly,nrm_poly,stats,S,SEG
J=json.load(open("work/m1/_final_partial.json")); DES=J["design"]
Z=np.load("work/m1/_R.npz"); 
R={nm:{k:Z[f"{nm}_{k}"] for k in ("m","d","sd","who","ang","rho","z","ar")} for nm in ("out_scan","inn_scan")}
t=np.tan(np.radians(DES["draft"]))
AXD=(0,0)
# ---- proper-drum masks & scores
FINAL={}
PROPER_L=-138.0
for nm,r in R.items():
    pre="out" if nm=="out_scan" else "inn"; m=r["m"]
    proper=m&((np.isin(r["who"],(0,5)))|(r["ang"]>=PROPER_L))
    blend=m&~proper
    np.save(f"work/masks/{pre}_ext_drum.npy",np.where(proper)[0].astype(np.int64))
    np.save(f"work/masks/{pre}_ext_drum_blendX.npy",np.where(blend)[0].astype(np.int64))
    for sname,ids in (("cone",(2,3)),("chamfer",(1,4)),("topplane",(5,)),("botplane",(0,))):
        k=proper&np.isin(r["who"],ids)
        if k.sum()>0: np.save(f"work/masks/{pre}_ext_drum_{sname}.npy",np.where(k)[0].astype(np.int64))
        else:
            p=f"work/masks/{pre}_ext_drum_{sname}.npy"
            if os.path.exists(p): os.remove(p)
    FINAL[nm]={"ALL":stats(r["d"][proper],r["ar"][proper])}
    for i,s in enumerate(SEG):
        k=proper&(r["who"]==i)
        if k.sum()>50: FINAL[nm][s]=stats(r["d"][k],r["ar"][k])
    print(nm,"proper",proper.sum(),"blend",blend.sum(),{k:(round(v['le0p5'],4),round(v['p90'],3)) for k,v in FINAL[nm].items()})
# ---- R(z) residual plot (cone only, ang -30..48) signed
fig,ax=plt.subplots(2,1,figsize=(14,9))
for a,(nm,zr) in zip(ax,(("out_scan",(-11,35)),("inn_scan",(35,81)))):
    r=R[nm]; k=r["m"]&np.isin(r["who"],(2,3))&(r["ang"]>-30)&(r["ang"]<48)
    zb=np.arange(zr[0],zr[1],1.0); med=[];lo=[];hi=[];zc=[]
    for z0 in zb:
        q=k&(r["z"]>=z0)&(r["z"]<z0+1)
        if q.sum()>30: zc.append(z0+.5); med.append(np.median(r["sd"][q])); lo.append(np.percentile(r["sd"][q],10)); hi.append(np.percentile(r["sd"][q],90))
    a.plot(zc,med,'b-o',ms=3,label="design (origin axis, Rp 68.85@36.07, 1.6 deg): median signed r-R"); a.fill_between(zc,lo,hi,alpha=.2)
    # best-fit axis (0.14,-0.01)
    c=S[nm][0]; x=c[:,0]-0.14; y=c[:,1]+0.01; rho=np.hypot(x,y); 
    # all angles -135..50 band (wide) with origin axis
    kw=r["m"]&np.isin(r["who"],(2,3))&(r["ang"]>-135)&(r["ang"]<48)
    med2=[]
    for z0 in zb:
        q=kw&(r["z"]>=z0)&(r["z"]<z0+1); med2.append(np.median(r["sd"][q]) if q.sum()>30 else np.nan)
    a.plot(zb+.5,med2,'r-s',ms=3,label="wide arc -135..48")
    a.axhline(0,color='k',lw=.5); a.axhline(.1,color='g',ls=':'); a.axhline(-.1,color='g',ls=':'); a.set_ylim(-.4,.4); a.grid(True); a.legend(); a.set_title(f"{nm}: R(z) residual to recommended design (shaded p10-p90 of narrow arc)"); a.set_xlabel("z")
plt.tight_layout(); plt.savefig("work/m1/Rz_residual.png",dpi=70); plt.close()
# ---- unrolled deviation map
fig,ax=plt.subplots(2,1,figsize=(22,13))
for a,nm in zip(ax,("out_scan","inn_scan")):
    r=R[nm]; m=r["m"]&(r["ang"]>-175)&(r["ang"]<51)
    sc=a.scatter(r["ang"][m][::6],r["z"][m][::6],c=r["sd"][m][::6],s=1.2,cmap="RdBu_r",vmin=-.3,vmax=.3)
    a.set_xlim(-180,60); a.set_title(f"{nm}: signed deviation scan - recommended drum design (mm), unrolled; red = scan outside"); a.set_xlabel("angle (0 = -Y, +90 = +X)"); a.set_ylabel("z"); a.grid(True,alpha=.3); plt.colorbar(sc,ax=a)
plt.tight_layout(); plt.savefig("work/m1/unrolled_dev_design.png",dpi=60); plt.close()
json.dump(FINAL,open("work/m1/_final_scores.json","w"),indent=1)
