import sys, numpy as np, open3d as o3d
sys.path.insert(0,"an"); import lib
from v5e_occ import scene
from scipy import ndimage
a0=np.array([74.65,33.95]); a1=np.array([55.05,55.40]); d=(a1-a0)/np.linalg.norm(a1-a0); n=np.array([d[1],-d[0]])
if n[0]<0: n=-n
v,f=lib.load("out_scan",1500000); S=scene((v,f)); C=scene("nx/P5d/out_P5d_final.stl")
h=0.05; ss=np.arange(28,40.01,h); oo=np.arange(-2,16.01,h); SS,OO=np.meshgrid(ss,oo,indexing="ij"); N=SS.size
xy=a0+SS[...,None]*d+OO[...,None]*n
def top(sc):
    o=np.c_[xy.reshape(-1,2),np.full(N,10.0)]
    t=sc.cast_rays(o3d.core.Tensor(np.c_[o,np.tile([0,0,-1.0],(N,1))].astype(np.float32)))["t_hit"].numpy(); z=o[:,2]-t; z[~np.isfinite(t)]=np.nan; return z.reshape(SS.shape)
zs=top(S); zc=top(C); dz=zc-zs
m=np.isfinite(dz)&(dz<-3.0)
L,k=ndimage.label(m)
print("CAD-only slots (CAD floor >3 mm below the scan surface, ray from z+10 down), grid 0.05")
for i in range(1,k+1):
    q=L==i; ar=q.sum()*h*h
    if ar<0.5: continue
    xyq=xy[q]
    print(" slot: area %.1f mm2, s %.2f..%.2f, off %.2f..%.2f, width(off) %.2f, depth below scan max %.1f med %.1f, CAD floor z %.1f..%.1f (scan z %.1f..%.1f); frame x %.1f..%.1f y %.1f..%.1f"%(ar,SS[q].min(),SS[q].max(),OO[q].min(),OO[q].max(),OO[q].max()-OO[q].min(),-dz[q].min(),-np.median(dz[q]),zc[q].min(),zc[q].max(),zs[q].min(),zs[q].max(),xyq[:,0].min(),xyq[:,0].max(),xyq[:,1].min(),xyq[:,1].max()))
m2=np.isfinite(dz)&(dz>3.0)
L,k=ndimage.label(m2); print("CAD material proud >3 (CAD z higher):")
for i in range(1,k+1):
    q=L==i; ar=q.sum()*h*h
    if ar<0.5: continue
    print(" area %.1f s %.1f..%.1f off %.1f..%.1f max %.1f"%(ar,SS[q].min(),SS[q].max(),OO[q].min(),OO[q].max(),dz[q].max()))
