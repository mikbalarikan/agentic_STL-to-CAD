from i2_rows import *
un=np.zeros(N,bool); un[np.load(os.path.join(O,"uncovered_bad.npy"))]=True
nz=n[:,2]
cls={"flat down (nz<-0.97)":nz<-0.97,"fillet-like (-0.97..-0.15)":(nz>=-0.97)&(nz<-0.15),"vertical (|nz|<0.15)":np.abs(nz)<=0.15,"up facing (nz>0.15)":nz>0.15}
tot=w_area[un].sum()*100
for k,m in cls.items(): print(f"{k:30s} {w_area[un&m].sum()*100:5.2f}% of total scan area ({w_area[un&m].sum()*100/tot*100:4.0f}% of uncovered bad)")
# thick wall? tris with de in 2.4..3.9 flat-down vs deeper
for lo,hi in ((2.4,3.9),(3.9,6),(6,12),(12,99)):
    m=un&(d>=lo)&(d<hi); print("de",lo,hi,f"{w_area[m].sum()*100:5.2f}%")
