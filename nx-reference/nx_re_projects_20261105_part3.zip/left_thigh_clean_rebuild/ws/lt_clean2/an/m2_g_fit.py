import sys,os,json,time
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import m2_loft as L, m2_f_data as FD
import open3d as o3d
def mesh_of(lf,y0,y1,dy=0.5,nu=720):
    ys=np.arange(y0,y1+1e-6,dy); u=np.arange(nu)/nu
    C=lf.curve(ys,u)  # (ny,nu,2)
    V=np.zeros((len(ys),nu,3)); V[:,:,0]=C[:,:,0]; V[:,:,2]=C[:,:,1]; V[:,:,1]=ys[:,None]
    ny=len(ys); idx=np.arange(ny*nu).reshape(ny,nu)
    a=idx[:-1,:]; b=idx[:-1,(np.arange(nu)+1)%nu]; c=idx[1:,:]; d=idx[1:,(np.arange(nu)+1)%nu]
    F=np.vstack([np.c_[a.ravel(),b.ravel(),c.ravel()],np.c_[b.ravel(),d.ravel(),c.ravel()]])
    return V.reshape(-1,3),F,ys,u
def dist_to(V,F,pts):
    sc=o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.core.Tensor(V.astype(np.float32)),o3d.core.Tensor(F.astype(np.uint32)))
    d=sc.compute_signed_distance(o3d.core.Tensor(pts.astype(np.float32))).numpy() if False else sc.compute_distance(o3d.core.Tensor(pts.astype(np.float32))).numpy()
    return d
def scan_pts(ymin,ymax):
    P=np.load(os.environ.get("EXTP","work/m2/ext_pts.npy"))
    drum=(np.hypot(P[:,0],P[:,1])<FD.drum_R(np.clip(P[:,2],-13.9,83.62))+0.8)&(P[:,2]>-14.7)&(P[:,2]<84.4)&(P[:,1]<75)
    P=P[~drum&(P[:,1]>=ymin)&(P[:,1]<=ymax)]
    return P
def stats(d,a):
    o=np.argsort(d); cs=np.cumsum(a[o])/a.sum()
    return float((a[d<=0.5].sum())/a.sum()), float(d[o][np.searchsorted(cs,0.9)]), float(d[o][np.searchsorted(cs,0.5)])
def run(st,NP=40,lam_t=1e-2,lam_y=1e-3,D=None,verbose=True):
    if D is None: D=np.load("work/m2/cells.npy")
    y=D[:,0];x=D[:,1];z=D[:,2];a=D[:,3]
    th=np.arctan2(z-FD.CZ0,x-FD.CX0)
    m=(y>=st[0]-1)&(y<=st[-1]+1)
    lf,keep,sr,u=L.fit(st,NP,y[m],th[m],x[m],z[m],np.ones(m.sum()),lam_t=lam_t,lam_y=lam_y)
    return lf,keep,sr
if __name__=="__main__":
    st=[float(s) for s in sys.argv[1].split(",")]; NP=int(sys.argv[2]) if len(sys.argv)>2 else 40
    t=time.time(); lf,keep,sr=run(st,NP); print("fit",time.time()-t, "keep",keep.mean())
    V,F,ys,u=mesh_of(lf,st[0],st[-1])
    ymin=max(st[0],60); S=scan_pts(ymin,st[-1])
    d=dist_to(V,F,S[:,:3]); f,p90,p50=stats(d,S[:,3]); print("K",len(st),"within0.5 %.1f p90 %.3f p50 %.3f"%(100*f,p90,p50))
