import json, re, sys
which = sys.argv[1]
d = json.load(open(r'work/gates/%s.json' % sys.argv[2]))
pat = {'out': r'KNEE_|FLOORHOLE|COVERPIN|HIP_PLATE|HIP_RING_BORE|FLG_FL',
       'inn': r'KNEE_DISC|HUB_UNDER|^CH_|SPOKE|MISS_B2|MISS_ARC|HIP_WEB|HIP_BLOCK|HIP_PAD|HIP_RING_CLEAR|B6_col|B7_col'}[which]
print('zones', {k: (v['new'], v['old'], v['p5']) for k, v in d['zones'].items()}, 'cad->scan', d['cad_to_scan'])
for k, v in sorted(d['features'].items()):
    if re.search(pat, k):
        print('%-26s n %6d  new %6.2f  old %6.2f  p5 %6.2f  %s' % (k, v['n'], v['new'], v['old'], v['p5'], 'ok' if v['new'] <= 0.5 else 'FAIL'))
