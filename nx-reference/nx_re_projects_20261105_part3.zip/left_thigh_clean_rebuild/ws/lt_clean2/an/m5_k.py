import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
for scan,key,sg in (("out_scan","out",-1),("inn_scan","inn",1)):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    t=np.load(os.path.join(lib.W,"m5",f"{key}_thick.npy")); dot=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["dot"]
    th=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))*sg
    for (y0,y1) in ((205,235),(80,125)):
        m=(dot<0)&(t>0)&(t<8)&(c[:,1]>=y0)&(c[:,1]<y1)&(c[:,0]>40)
        print(key,"y",y0,y1)
        for a in np.arange(0,48,2.0):
            k=m&(th>=a)&(th<a+2)
            if k.sum()>20: print(f"  th {a:4.0f}-{a+2:2.0f} n{k.sum():5d} thick p25/50/75 {np.round(np.percentile(t[k],[25,50,75]),2)}")
