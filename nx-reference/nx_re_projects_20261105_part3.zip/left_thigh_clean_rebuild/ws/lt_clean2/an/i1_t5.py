from i1_common import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt, sys
S=load_all(); c,n,de=S['c'],S['n'],S['de']
x0,x1,y0,y1=[float(t) for t in sys.argv[1:5]]; out=sys.argv[5]; zl=(float(sys.argv[6]),float(sys.argv[7])) if len(sys.argv)>7 else (-30,40)
m=(de>2.0)&(c[:,0]>x0)&(c[:,0]<x1)&(c[:,1]>y0)&(c[:,1]<y1)
idx=np.where(m)[0]; idx=idx[np.argsort(c[idx,2])]
fig,ax=plt.subplots(1,2,figsize=(18,18*(y1-y0)/(x1-x0)/2+1))
sc=ax[0].scatter(c[idx,0],c[idx,1],c=c[idx,2],s=3,cmap='turbo',vmin=zl[0],vmax=zl[1],linewidths=0); plt.colorbar(sc,ax=ax[0],shrink=.6)
sc=ax[1].scatter(c[idx,0],c[idx,1],c=n[idx,2],s=3,cmap='coolwarm',vmin=-1,vmax=1,linewidths=0); plt.colorbar(sc,ax=ax[1],shrink=.6)
for a_ in ax: a_.set_aspect('equal'); a_.grid(True,alpha=.4); a_.set_xlim(x0,x1); a_.set_ylim(y0,y1)
fig.savefig(out,dpi=60,bbox_inches='tight')
