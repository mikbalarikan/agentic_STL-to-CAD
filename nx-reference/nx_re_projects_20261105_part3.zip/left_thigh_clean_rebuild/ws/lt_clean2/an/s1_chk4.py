from s1_build import *
from s1_shell import faces
from OCP.BRepAdaptor import BRepAdaptor_Surface
c=cone_solid()
for f in faces(c):
    a=BRepAdaptor_Surface(f)
    print(a.GetType().name)
    if a.GetType().name=='GeomAbs_Cone':
        co=a.Cone(); ax=co.Axis(); p=ax.Location(); d=ax.Direction()
        print('loc',p.X(),p.Y(),p.Z(),'dir',d.X(),d.Y(),d.Z(),'RefR',co.RefRadius(),'semi',np.degrees(co.SemiAngle()))
