import sys; sys.path.insert(0,'an')
import numpy as np, lib, json
T=json.load(open("work/t5/t5_tail.json")); cx,cy=T["cx"],T["cy"]; k=np.tan(np.radians(26.0)); a1=T["cone_a1"]
v,f=lib.load("out_scan",1500000); c,n,a=lib.tri_data(v,f)
r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
m=(ang>52.5)&(ang<62)&(c[:,1]<-39)&(c[:,2]<-5)&(c[:,2]>-14.2)&(r>60)&(r<75)&(n[:,2]<0.2)
P=c[m]; rho=np.hypot(P[:,0]-cx,P[:,1]-cy)
print(m.sum())
for z0 in np.arange(-14,-5,0.5):
    q=(P[:,2]>=z0)&(P[:,2]<z0+0.5)
    if q.sum()>3: print("z %.2f..%.2f n %3d rho_c min %.2f med %.2f max %.2f   cone %.2f"%(z0,z0+.5,q.sum(),rho[q].min(),np.median(rho[q]),rho[q].max(),a1+k*(z0+.25)))
# bottom-facing flat tris
mb=(ang>52.5)&(ang<62)&(c[:,1]<-39)&(c[:,2]<-12)&(n[:,2]<-0.9)
print("bottom-facing n",mb.sum(),"z med %.3f rho_c %.2f..%.2f"%(np.median(c[mb,2]) if mb.sum() else 0,np.hypot(c[mb,0]-cx,c[mb,1]-cy).min() if mb.sum() else 0,np.hypot(c[mb,0]-cx,c[mb,1]-cy).max() if mb.sum() else 0))
