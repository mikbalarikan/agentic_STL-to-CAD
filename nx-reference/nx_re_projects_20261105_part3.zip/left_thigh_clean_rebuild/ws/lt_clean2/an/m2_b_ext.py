"""Exterior skin by voxel flood fill of the union of both scans. Writes work/m2/ext_flag_{out,inn}.npy (bool per tri)."""
import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy import ndimage as ndi
H=0.6
S={}
for n in ("out_scan","inn_scan"):
    S[n]=lib.load(n,1500000)
allv=np.vstack([S[n][0] for n in S]); lo=allv.min(0)-6; hi=allv.max(0)+6
dim=np.ceil((hi-lo)/H).astype(int); print(dim, dim.prod()/1e6)
occ=np.zeros(dim,bool)
def vox(p): return np.clip(np.floor((p-lo)/H).astype(int),0,dim-1)
for n,(v,f) in S.items():
    c,nn,ar=lib.tri_data(v,f)
    for p in (c,v):
        i=vox(p); occ[i[:,0],i[:,1],i[:,2]]=True
occ=ndi.binary_dilation(occ,structure=np.ones((3,3,3),bool),iterations=1)
cap=int((287.0-lo[1])/H); occ[:,cap:cap+2,:]=True
emp=~occ
lab,nl=ndi.label(emp)
ext=lab==lab[0,0,0]
print("labels",nl,"ext voxels",ext.sum(),"empty",emp.sum())
# size of other empty components
sz=ndi.sum(emp,lab,range(1,nl+1)); print("other comps",sorted(sz)[-5:])
np.save(r"work/m2/vox_ext.npy",ext); np.save(r"work/m2/vox_lo.npy",lo)
for n,(v,f) in S.items():
    c,nn,ar=lib.tri_data(v,f)
    fl=np.zeros(len(f),bool); side=np.zeros(len(f),int)
    for d in (1.2,1.8):
        for sg in (1,-1):
            i=vox(c+sg*d*nn); e=ext[i[:,0],i[:,1],i[:,2]]
            fl|=e
            if d==1.2: side[e]=sg
    np.save(f"work/m2/ext_flag_{n[:3]}.npy",fl); np.save(f"work/m2/ext_side_{n[:3]}.npy",side)
    print(n,fl.mean(), (side==1).sum(), (side==-1).sum())
