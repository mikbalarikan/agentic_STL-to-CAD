"""Envelope loft: fit to exterior outside the +X band plus the band floor shifted out by BAND_DEPTH along the section normal."""
import sys,os,time,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_loft as L, m2_g_fit as G, m2_f_data as FD, m2_o_fitband as B
BAND_DEPTH=1.12
def shifted_cells(first_tag="A72"):
    D=np.load(os.environ.get("CELLS","work/m2/cells.npy")).copy()
    d=np.load(f"work/m2/loft_{first_tag}.npz"); lf0=L.Loft(d["st"],d["P"].shape[1],d["P"])
    ib=B.inband(D[:,0],D[:,1],D[:,2],-1.5)          # core of the band only (edges unshifted -> dropped)
    edge=B.inband(D[:,0],D[:,1],D[:,2],1.0)&~ib
    for i in np.where(ib)[0]:
        y,x,z=D[i,:3]
        uu=np.linspace(0,1,720,endpoint=False); C=lf0.curve(y,uu)[0]
        k=np.argmin((C[:,0]-x)**2+(C[:,1]-z)**2); t=C[(k+1)%720]-C[k-1]; n=np.array([t[1],-t[0]]); n/=np.linalg.norm(n)
        if <REDACTED>([x-FD.CX0,z-FD.CZ0])<0: n=-n
        ramp=float(np.clip((264-y)/8.0,0,1)); D[i,1]+=BAND_DEPTH*ramp*n[0]; D[i,2]+=BAND_DEPTH*ramp*n[1]
    return D[~edge]
def score(lf,st,tag,verbose=True):
    V,F,ys,u=G.mesh_of(lf,st[0],st[-1])
    S=G.scan_pts(60,255); d=G.dist_to(V,F,S[:,:3]); ib=B.inband(S[:,1],S[:,0],S[:,2],1.0); y=S[:,1]
    out={}
    def rep(nm,m):
        f,p90,p50=G.stats(d[m],S[m,3]); out[nm]=(round(100*f,2),round(p90,3),round(p50,3)); return "%s %.1f%% p90 %.3f"%(nm,100*f,p90)
    msg=" | ".join([rep("outside_band",~ib&(y<=255)),rep("outside_60_100",~ib&(y<100)),rep("outside_100_250",~ib&(y>=100)&(y<=250)),rep("outside_250_255",~ib&(y>250))])
    return out,msg,(S,d,ib)
if __name__=="__main__":
    st=[float(s) for s in sys.argv[1].split(",")]; NP=int(sys.argv[2]); tag=sys.argv[3]
    D=shifted_cells()
    lf,keep,sr=G.run(st,NP,D=D)
    np.savez(f"work/m2/loft_{tag}.npz",st=st,P=lf.P)
    out,msg,_=score(lf,st,tag); print(tag,"K",len(st),"NP",NP,msg,flush=True)
