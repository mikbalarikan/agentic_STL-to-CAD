import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HX,HZ=37.97,35.18
pts=[]
for n,tag in (('out_scan','out'),('inn_scan','inn')):
    v,f=lib.load(n,1500000); c,nn,a=lib.tri_data(v,f); m=np.load(f"work/masks/{tag}_ext_hip.npy"); pts.append(c[m])
P=np.vstack(pts); r=np.hypot(P[:,0]-HX,P[:,2]-HZ); th=np.degrees(np.arctan2(P[:,2]-HZ,P[:,0]-HX))
np.savez("work/m3/ext_pts.npz",P=P,r=r,th=th)
fig,ax=plt.subplots(1,2,figsize=(22,8))
for t in range(-165,180,15):
    k=abs(th-t)<3; 
    if k.sum()<50: continue
    yb=np.arange(200,289,2.0); R=[np.median(r[k&(abs(P[:,1]-y)<1)]) if (k&(abs(P[:,1]-y)<1)).sum()>3 else np.nan for y in yb]
    ax[0].plot(yb,R,label=str(t))
ax[0].legend(ncol=3,fontsize=7); ax[0].grid(True); ax[0].set_title('R(Y) per angle')
sc=ax[1].scatter(P[::20,1],th[::20],c=r[::20],s=2,cmap='jet'); plt.colorbar(sc); ax[1].set_title('R map (Y,theta)')
plt.tight_layout(); plt.savefig("work/m3/ry.png",dpi=55)
