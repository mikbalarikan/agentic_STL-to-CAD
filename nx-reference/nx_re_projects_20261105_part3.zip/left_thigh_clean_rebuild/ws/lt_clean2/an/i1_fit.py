"""I1 fit helpers: rib/gusset fit in a local frame, cylinder fit, plateau finder."""
import numpy as np

def frame(p0, p1):
    p0 = np.asarray(p0, float); p1 = np.asarray(p1, float)
    L = np.linalg.norm(p1 - p0); e = (p1 - p0) / L; n = np.array([-e[1], e[0]])
    return p0, e, n, L

def local(c, p0, e, n):
    d = c[:, :2] - p0
    return d @ e, d @ n

def wmed(x, w=None):
    if len(x) == 0: return np.nan
    if w is None: return float(np.median(x))
    o = np.argsort(x); cw = np.cumsum(w[o]); return float(x[o][np.searchsorted(cw, cw[-1] / 2)])

def linfit_robust(s, y, it=4, k=2.5):
    """y = a + b s with iterative clipping. returns a, b, rms, n"""
    m = np.ones(len(s), bool)
    for _ in range(it):
        if m.sum() < 5: break
        A = np.c_[np.ones(m.sum()), s[m]]
        a, b = np.linalg.lstsq(A, y[m], rcond=None)[0]
        r = y - (a + b * s); sd = max(r[m].std(), 0.05)
        m = np.abs(r) < k * sd
    return float(a), float(b), float(r[m].std()) if m.sum() > 2 else np.nan, int(m.sum())

def circle_fit(x, y):
    A = np.c_[2 * x, 2 * y, np.ones(len(x))]
    b = x ** 2 + y ** 2
    sol = np.linalg.lstsq(A, b, rcond=None)[0]
    cx, cy = sol[0], sol[1]; r = np.sqrt(sol[2] + cx ** 2 + cy ** 2)
    res = np.sqrt(((np.hypot(x - cx, y - cy) - r) ** 2).mean())
    return cx, cy, r, res

def circle_fit_robust(x, y, it=4, k=2.5):
    m = np.ones(len(x), bool)
    for _ in range(it):
        if m.sum() < 8: break
        cx, cy, r, res = circle_fit(x[m], y[m])
        d = np.abs(np.hypot(x - cx, y - cy) - r); sd = max(d[m].std(), 0.03)
        m = d < k * sd
    return cx, cy, r, res, int(m.sum())

def peaks(z, w=None, bw=0.1, minshare=0.05, rng=None):
    """histogram peaks of z (weights w): list of (z, share)"""
    if len(z) == 0: return []
    lo, hi = (z.min(), z.max()) if rng is None else rng
    nb = max(int((hi - lo) / bw), 3)
    h, ed = np.histogram(z, bins=nb, range=(lo, hi), weights=w)
    tot = h.sum(); out = []
    hs = np.convolve(h, [1, 2, 1], 'same')
    for i in range(1, nb - 1):
        if hs[i] >= hs[i - 1] and hs[i] > hs[i + 1] and h[max(i-1,0):i+2].sum() / tot >= minshare:
            out.append((float(0.5 * (ed[i] + ed[i + 1])), float(h[max(i-1,0):i+2].sum() / tot)))
    return sorted(out, key=lambda t: -t[1])

def pw_fit(s, z, maxseg=4, minlen=3.0, tol=0.18, w=None):
    """piecewise-linear fit z(s) with independent segments (bins already aggregated). returns list of (s0,s1,z0,z1,rms)"""
    o = np.argsort(s); s = np.asarray(s)[o]; z = np.asarray(z)[o]; n = len(s)
    if n < 4: return []
    w = np.ones(n) if w is None else np.asarray(w)[o]
    def seg(i, j):  # inclusive i..j
        ss, zz, ww = s[i:j + 1], z[i:j + 1], w[i:j + 1]
        if len(ss) < 2: return 0.0, (0, zz[0])
        A = np.c_[np.ones(len(ss)), ss]
        sw = np.sqrt(ww)
        co = np.linalg.lstsq(A * sw[:, None], zz * sw, rcond=None)[0]
        r = zz - A @ co
        return float((ww * r ** 2).sum()), co
    INF = 1e18
    best = None
    cost = {}
    for K in range(1, maxseg + 1):
        # dp[k][j] = min cost covering 0..j with k segments
        dp = [[INF] * n for _ in range(K + 1)]; bk = [[-1] * n for _ in range(K + 1)]
        for j in range(n):
            if s[j] - s[0] >= minlen or j == n - 1 or True:
                dp[1][j] = seg(0, j)[0]
        for k in range(2, K + 1):
            for j in range(n):
                for i in range(1, j + 1):
                    if s[j] - s[i] < minlen * 0.6 or dp[k - 1][i - 1] >= INF: continue
                    cst = dp[k - 1][i - 1] + seg(i, j)[0]
                    if cst < dp[k][j]: dp[k][j] = cst; bk[k][j] = i
        if dp[K][n - 1] >= INF: continue
        rms = np.sqrt(dp[K][n - 1] / w.sum())
        # backtrack
        segs = []; j = n - 1; k = K
        while k >= 1:
            i = bk[k][j] if k > 1 else 0
            segs.append((i, j)); j = i - 1; k -= 1
        segs = segs[::-1]
        cost[K] = (rms, segs)
        if rms < tol:
            best = K; break
    if best is None:
        best = min(cost, key=lambda k: cost[k][0] + 0.02 * k) if cost else None
    if best is None: return []
    rms, segs = cost[best]
    out = []
    for i, j in segs:
        _, co = seg(i, j)
        out.append((float(s[i]), float(s[j]), float(co[0] + co[1] * s[i]), float(co[0] + co[1] * s[j])))
    return out
