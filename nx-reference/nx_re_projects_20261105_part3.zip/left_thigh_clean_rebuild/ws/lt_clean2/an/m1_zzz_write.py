import json,numpy as np
W="work/m1/"
C=json.load(open(W+"_cands.json")); B=json.load(open(W+"_boundary.json")); F=json.load(open(W+"_final_scores.json")); P5=json.load(open(W+"_cmp_part5.json")); E=json.load(open(W+"_edges.json")); PF=json.load(open(W+"_final_partial.json"))
deg=lambda t: float(np.degrees(np.arctan(t)))
cand={}
for k,v in C.items():
    s=v["stats"]; cand[k]=dict(params=[round(x,5) for x in v["params"]],mean=round(s["mean"],4),p50=round(s["p50"],4),p90=round(s["p90"],4),p95=round(s["p95"],4),frac_le_0p1=round(s["w_le_0p1"],3))
J={
 "frame":"assembly frame, mm; angle = atan2(x,-y), 0 = -Y, +90 = +X, +/-180 = +Y (hip side)",
 "method":"area-weighted fits on drum exterior triangles (radial normal > 0.95, |dev|<0.3, ang -135..50) of both scans, soft_l1; n=109779 tris; masks in work/masks",
 "axis":{"scan_fit_shared":{"x0":0.137,"y0":-0.012,"note":"shared best-fit axis of both scans, tilt 0.08 deg (negligible)"},
         "per_scan_offset":{"outer_scan":[0.20,0.07],"inner_scan":[0.05,-0.06],"note":"bore/floor/drum circles of each scan are mutually offset ~0.15 mm = scan registration, not design"},
         "recommended":"Z axis through the origin (0,0); alternative (0.14,-0.01) halves p90 but breaks coaxial-with-origin intent"},
 "profile_finding":"two straight drafted cones meeting in a sharp parting line (fillet sag 0.0007 mm, i.e. none); equal draft both sides; no barrel (spline6/poly show no gain)",
 "candidates_on_cone_points":cand,
 "cone_free_fit":{"Rp":68.855,"zp":37.21,"draft_deg":deg(0.0275),"draft_outer_deg":deg(0.0266),"draft_inner_deg":deg(0.0282),"note":"zp is poorly determined (no scan data between z 34.5 and 35.4; cones meet 0.05 mm apart at 36.07 with shared axis)"},
 "top":{"plane_z_median_central_disc_r26_50":83.57,"plane_z_ring_r52_64":83.62,"recommended_z":83.60,"step_ring_vs_disc_mm":0.05,"chamfer":{"fit_plane_leg":E["inn_scan"]["radial_leg"],"fit_cone_leg":E["inn_scan"]["axial_leg"],"angle_deg":E["inn_scan"]["chamfer_angle"],"recommended":"3.1 x 45 deg (grid optimum with plane at 83.60; line fit against ring plane 83.63 gives 3.2)"},"n_plane_tris":E["inn_scan"]["n_plane"],"n_chamfer_tris":E["inn_scan"]["n_ch"]},
 "bottom":{"ring_face_z":-13.91,"recommended_z":-13.90,"ring_face_rho":[63.0,64.1],"bore_rho":63.0,"chamfer":{"fit_plane_leg":E["out_scan"]["radial_leg"],"fit_cone_leg":E["out_scan"]["axial_leg"],"angle_deg":E["out_scan"]["chamfer_angle"],"recommended":"3.3 x 45 deg"},"n_plane_tris":E["out_scan"]["n_plane"],"n_chamfer_tris":E["out_scan"]["n_ch"],"floor_inside_cup_z":-8.35,"note":"floor z -8.35 (annulus rho 46..63, 24 holes) is interior, not exterior"},
 "recommended_design":{"axis":"Z through origin","parting_plane_z":36.07,"R_at_parting":68.85,"diameter_at_parting":137.7,"draft_deg_both_ways":1.6,"R_at_bottom_plane":round(68.85-(36.07+13.9)*np.tan(np.radians(1.6)),3),"R_at_top_plane":round(68.85-(83.6-36.07)*np.tan(np.radians(1.6)),3),"top_plane_z":83.60,"top_chamfer":3.1,"bottom_plane_z":-13.90,"bottom_chamfer":3.3,"bottom_ring_face_rho_from":63.0,"top_disc_hole_rho":"not part of the exterior; interior hole at rho ~25.5"},
 "scores_proper_drum_mask_area_weighted":{k:{kk:{x:round(y,4) for x,y in vv.items() if x in ("n","area","p50","p90","p95","p99","le0p3","le0p5")} for kk,vv in v.items()} for k,v in F.items()},
 "compare_same_masks":P5,
 "join_boundary":{
   "plusX":{"type":"hard step edge, NOT tangent: the body wall starts 2.7 (z -9) .. 7 (z 0..) mm outside the cone at this edge","angle_deg":50.5,"tolerance_deg":0.5,"fit_outer":B.get("plusX_edge_fit_out"),"fit_inner":B.get("plusX_edge_fit_inn"),"edge_points_scan,z,ang,x,y":B["plusX_step_edge"]},
   "minusX":{"type":"tangent blend: body wall leaves the cone smoothly; ang at dev 0.3 mm and 1.0 mm (scan,z,ang,x,y on design cone)","dev0p3":B["minusX_tangent_blend_dev0p3"],"dev1p0":B["minusX_tangent_blend_dev1p0"],"mid_zone_note":"for outer z 7.3..34.5 and inner z 35.4..62.7 the departure sits at about -139.5 deg (constant, meridian)"},
   "window_cutout":{"ang":[-115,-25],"outer_z_top":7.3,"inner_z_bottom":62.7,"note":"between z 7.3 and 62.7 the drum wall has a window from -115 to -25 deg; free edges, not joins. The strips -139..-115 (arm) and -25..50.5 remain in the window zone"},
   "top_plane_and_ring":"top disc (inner) and bottom ring (outer) are full 360 deg; no ang limit; top plane continues to the neck beyond rho 64.4 (not drum)"},
 "features_on_drum_exterior":{
   "ear_strip_inner_+X":{"desc":"narrow strip beyond the +X step edge, flush with the cone (dev ~0)","ang":[55,59],"z":B["ear_strip"].get("inn_scan",{}).get("z"),"note":"inner scan only; belongs to the +X body zone, not to the revolve"},
   "none_else":"no holes, grooves, steps, flats or round faces on the cone, chamfers or planes beyond the window and the two edges; only outliers (|dev|>0.3) are the -X blend band"},
 "masks":"work/masks/{out,inn}_ext_drum.npy (+ _cone, _chamfer, _topplane, _botplane, _blendX)"
}
json.dump(J,open(W+"drum_fit.json","w"),indent=1)
print("ok")
