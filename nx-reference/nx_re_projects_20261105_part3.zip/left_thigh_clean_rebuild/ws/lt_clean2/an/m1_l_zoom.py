import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
AX=(0.169,-0.100); Rp,zp,t=68.7673,36.8481,0.0275
fig,ax=plt.subplots(2,4,figsize=(26,14))
cases=[("out_scan",z) for z in (-9,-4,4,14)]+[("inn_scan",z) for z in (44,60,69,78)]
for a,(n,z) in zip(ax.flat,cases):
    v,f=lib.load(n,1500000); s=lib.section(v,f,2,z)
    for p,q in s: a.plot([p[0],q[0]],[p[1],q[1]],'k-',lw=.6)
    th=np.linspace(0,2*np.pi,400); R=Rp-abs(z-zp)*t
    a.plot(AX[0]+R*np.cos(th),AX[1]+R*np.sin(th),'r-',lw=.5)
    for ang in range(-180,180,30):
        a.plot([0,100*np.sin(np.radians(ang))],[0,-100*np.cos(np.radians(ang))],'g:',lw=.3); a.text(75*np.sin(np.radians(ang)),-75*np.cos(np.radians(ang)),str(ang),color='g',fontsize=8)
    a.set_aspect('equal'); a.set_xlim(-95,95); a.set_ylim(-80,110); a.set_title(f"{n} z={z}"); a.grid(True,alpha=.3)
plt.tight_layout(); plt.savefig("work/m1/sections_zoom.png",dpi=55)
