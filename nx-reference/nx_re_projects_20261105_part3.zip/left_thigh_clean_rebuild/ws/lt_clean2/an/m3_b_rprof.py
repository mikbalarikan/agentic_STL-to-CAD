import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
HX,HZ=37.97,35.18
for n in ('out_scan','inn_scan'):
    v,f=lib.load(n,1500000); c,nn,a=lib.tri_data(v,f)
    print(n)
    for y in range(200,290,6):
        m=(abs(c[:,1]-y)<1.5)
        r=np.hypot(c[m,0]-HX,c[m,2]-HZ); th=np.degrees(np.arctan2(c[m,2]-HZ,c[m,0]-HX))
        # exterior: max r per 10deg bin
        out=[]
        for t0 in range(-180,180,45):
            k=(th>=t0)&(th<t0+45)
            out.append(np.percentile(r[k],98) if k.sum()>20 else np.nan)
        print(y,' '.join(f"{x:7.2f}" for x in out))
