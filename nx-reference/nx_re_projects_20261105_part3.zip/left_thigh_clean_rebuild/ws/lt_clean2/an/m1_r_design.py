"""M1 stage B: design profile, chamfer/plane fits, masks, scores, maps."""
import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
S={nm:lib.tri_data(*lib.load(nm,1500000)) for nm in ("out_scan","inn_scan")}

def profile(Rp,zp,dd,Zb,Zt,cb,ct):
    """closed-form outer profile polyline (rho,z) from bottom plane inner edge to top plane inner edge."""
    t=np.tan(np.radians(dd)); n=np.sqrt(1+t*t)
    Rc=lambda z: Rp-abs(z-zp)*t
    Rb=Rc(Zb); Rtop=Rc(Zt)
    pts=[(Rb-cb-1.2,Zb),(Rb-cb,Zb),(Rb+cb*t/n,Zb+cb/n)]       # bottom: ring face, chamfer end on cone
    pts+=[(Rp,zp)]
    pts+=[(Rtop+ct*t/n,Zt-ct/n),(Rtop-ct,Zt),(Rtop-ct-40,Zt)]
    return np.array(pts)
def dist2poly(rho,z,poly):
    best=np.full(len(rho),1e9); who=np.zeros(len(rho),int)
    for i in range(len(poly)-1):
        a,b=poly[i],poly[i+1]; ab=b-a; L2=ab@ab
        u=np.clip(((rho-a[0])*ab[0]+(z-a[1])*ab[1])/L2,0,1)
        d=np.hypot(rho-(a[0]+u*ab[0]),z-(a[1]+u*ab[1])); m=d<best; best[m]=d[m]; who[m]=i
    return best,who
def nrm_poly(poly):
    """outward 2D normal (nr,nz) per segment (profile traversed bottom->top: outward = right-hand)"""
    out=[]
    for i in range(len(poly)-1):
        d=poly[i+1]-poly[i]; d/=np.hypot(*d); out.append((d[1],-d[0]))
    return np.array(out)

def evaluate(design,axis,loose=1.5,verbose=True):
    Rp,zp,dd,Zb,Zt,cb,ct=design
    poly=profile(*design); nr=nrm_poly(poly)
    res={}
    for nm,(c,nn,ar) in S.items():
        x=c[:,0]-axis[0]; y=c[:,1]-axis[1]; rho=np.hypot(x,y); ang=np.degrees(np.arctan2(x,-y))
        d,who=dist2poly(rho,c[:,2],poly)
        # normal alignment with segment outward normal
        ur=np.c_[x,y]/np.maximum(rho,1e-9)[:,None]
        nrad=nn[:,0]*ur[:,0]+nn[:,1]*ur[:,1]
        dot=nrad*nr[who,0]+nn[:,2]*nr[who,1]
        zr=(-14.5,35.0) if nm=="out_scan" else (35.4,84.2)
        m=(d<loose)&(dot>np.cos(np.radians(25)))&(ang>-175)&(ang<50.9)&(c[:,2]>zr[0])&(c[:,2]<zr[1])
        # keep only segments: 1 bottom chamfer,3,2? who: 0 ring,1 chamfer,2 cone lo,3 cone hi,4 chamfer top,5 plane top
        # planes need rho gating (disc) : handled by polyline length (ring 1.2, top 14 wide) -> extend top plane to hole by separate mask
        res[nm]=(m,d,who,ang,rho,dot)
    return poly,res

def stats(a,w):
    o=np.argsort(a); cw=np.cumsum(w[o])/w.sum(); q=lambda p:float(a[o][min(np.searchsorted(cw,p),len(a)-1)])
    return dict(n=int(len(a)),area=float(w.sum()),mean=float(np.average(a,weights=w)),p50=q(.5),p90=q(.9),p95=q(.95),p99=q(.99),le0p1=float(w[a<.1].sum()/w.sum()),le0p3=float(w[a<.3].sum()/w.sum()),le0p5=float(w[a<.5].sum()/w.sum()))
SEG=["bottom_ring_plane","bottom_chamfer","cone_lower","cone_upper","top_chamfer","top_plane"]
def report(design,axis,label):
    poly,res=evaluate(design,axis)
    out={}
    for nm,(m,d,who,ang,rho,dot) in res.items():
        w=S[nm][2]
        out[nm]={"ALL":stats(d[m],w[m])}
        for i,s in enumerate(SEG):
            k=m&(who==i)
            if k.sum()>20: out[nm][s]=stats(d[k],w[k])
    return out
if __name__=="__main__":
    base=(68.86,36.07,1.6,-13.91,83.60,3.3,3.2)
    # least squares fit of all design params with axis free
    pol0,res0=evaluate(base,(0.137,-0.012),loose=1.0)
    IDX={nm:np.where(res0[nm][0]&((res0[nm][2]>0) if nm=="inn_scan" else (res0[nm][2]<5)))[0][::3] for nm in res0}
    def cost(q):
        design=(q[0],36.07,q[1],q[2],q[3],q[4],q[5]); axis=(q[6],q[7]); poly=profile(*design); r=[]
        for nm,idx in IDX.items():
            c=S[nm][0][idx]; rho=np.hypot(c[:,0]-axis[0],c[:,1]-axis[1]); d,_=dist2poly(rho,c[:,2],poly); r.append(d)
        return np.concatenate(r)
    q0=[68.86,1.58,-13.91,83.62,3.3,3.2,0.137,-0.012]
    s=least_squares(cost,q0,loss="soft_l1",f_scale=.1,diff_step=1e-3)
    print("fit all:",np.round(s.x,4))
    json.dump(list(s.x),open("work/m1/_designfit.json","w"))
    for label,design,axis in (
        ("fit",(s.x[0],36.07,s.x[1],s.x[2],s.x[3],s.x[4],s.x[5]),(s.x[6],s.x[7])),
        ("rec_axis(0.14,-0.01)",(68.85,36.07,1.6,-13.9,83.6,3.3,3.2),(0.14,-0.01)),
        ("rec_origin",(68.9,36.07,1.7,-13.9,83.6,3.3,3.2),(0,0)),
        ("origin_fitR",(68.88,36.07,1.6,-13.9,83.6,3.3,3.2),(0,0)),
        ("part5",(68.9,37.25,1.7,-13.9,83.62,3.4,3.3),(0,0))):
        o=report(design,axis,label)
        print(label,design,axis)
        for nm in o:
            for k,v in o[nm].items():
                print(f"   {nm[:3]} {k:18s} n {v['n']:6d} area {v['area']:8.0f} p50 {v['p50']:.3f} p90 {v['p90']:.3f} <=.3 {v['le0p3']:.3f} <=.5 {v['le0p5']:.3f}")
