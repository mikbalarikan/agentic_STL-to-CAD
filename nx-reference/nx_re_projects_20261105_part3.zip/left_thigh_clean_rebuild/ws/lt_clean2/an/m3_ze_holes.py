import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
out={}
v,f=lib.load('inn_scan',1500000); c,nn,a=lib.tri_data(v,f)
for nm,(x0,y0) in (('B6_cbore',(98.0,265.0)),('B7_cbore',(-22.5,264.5))):
    near=(np.hypot(c[:,0]-x0,c[:,1]-y0)<9)&(c[:,2]>60)
    wall=near&(abs(nn[:,2])<0.25)&(c[:,2]>85)
    # cylinder wall: fit circle in xy on wall tris with z>85 (cbore wall) & within 7
    X=c[wall,0];Y=c[wall,1]
    p=least_squares(lambda p:np.hypot(X-p[0],Y-p[1])-p[2],[x0,y0,5]).x
    e=np.hypot(X-p[0],Y-p[1])-p[2]
    # keep only points with |e|<0.5 iterate (ignore the through hole)
    k=abs(e)<0.6; p=least_squares(lambda p:np.hypot(X[k]-p[0],Y[k]-p[1])-p[2],p).x
    # floors: planar faces with nz~+1 inside the circle
    rr=np.hypot(c[:,0]-p[0],c[:,1]-p[1])
    fl=(rr<p[2]-0.5)&(nn[:,2]>0.97)&(c[:,2]>60)
    h,e2=np.histogram(c[fl,2],bins=np.arange(60,115,0.2),weights=a[fl]); i=np.argmax(h)
    top=(rr>p[2]+0.8)&(rr<p[2]+3)&(c[:,2]>85); zt=np.median(c[top,2])
    # through hole radius: wall tris below floor
    th=(rr<4)&(abs(nn[:,2])<0.25)&(c[:,2]<e2[i]-0.3)&(c[:,2]>60)
    rt=np.median(rr[th]) if th.sum()>5 else np.nan
    print(nm,'centre (%.2f,%.2f) D=%.2f (n=%d, resid std %.3f) floor z=%.2f skin z around %.2f -> depth %.2f ; through-hole D~%.2f (n=%d)'%(p[0],p[1],2*p[2],k.sum(),e[k].std(),e2[i]+.1,zt,zt-(e2[i]+.1),2*rt,th.sum()))
    out[nm]=dict(cx=float(p[0]),y=float(p[1]),D=float(2*p[2]),floor_z=float(e2[i]+.1),skin_z=float(zt),through_D=float(2*rt))
json.dump(out,open('work/m3/holes_tmp.json','w'))
