import sys; sys.path.insert(0,'an')
import numpy as np, lib
from scipy.optimize import least_squares
def get(zlo,zhi):
    P=[]
    for nm in ("out_scan","inn_scan"):
        v,f=lib.load(nm,1500000); c,n,a=lib.tri_data(v,f)
        sel=(c[:,0]>40)&(c[:,1]<-30)&(c[:,1]>-56)
        cc=c[sel];nn=n[sel]
        r=np.hypot(cc[:,0],cc[:,1]); ang=np.degrees(np.arctan2(cc[:,0],-cc[:,1]))
        rad=(nn[:,0]*cc[:,0]+nn[:,1]*cc[:,1])/r
        ext=(rad>0.9)&(r>69)&(ang>52.5)&(ang<64)&(cc[:,1]<-39)&(cc[:,2]>zlo)&(cc[:,2]<zhi)&(((cc[:,2]<33)&(nm=="out_scan"))|((cc[:,2]>37)&(nm=="inn_scan")))
        P.append(cc[ext])
    return np.vstack(P)
P=get(10.5,60)
print(len(P))
# model: rho = hypot(x-x0,y-y0); rho_model(z)= rho0 - (Rv - sqrt(Rv^2-(z-zc)^2))
def mod(q,P,free,fix):
    x0,y0=(q[0],q[1]) if free else (0,0)
    rho0,Rv,zc=q[2:5]
    rho=np.hypot(P[:,0]-x0,P[:,1]-y0)
    return rho-(rho0-(Rv-np.sqrt(Rv**2-(P[:,2]-zc)**2)))
for free in (False,True):
    for Rv0 in (200,):
        q0=[0,0,80.9,Rv0,35.5] if not free else [-30,17,116.8,Rv0,35.5]
        s=least_squares(mod,q0,args=(P,free,None),loss='soft_l1',f_scale=0.1)
        r=mod(s.x,P,free,None)
        print("free",free,np.round(s.x,3),"rms %.3f p50 %.3f p90 %.3f p95 %.3f"%(np.sqrt(np.mean(r**2)),np.median(abs(r)),np.percentile(abs(r),90),np.percentile(abs(r),95)))
# constrained: centre fixed on a sweep of candidates (x0,y0)
print("sweep centre along direction of free-fit, fixed rho0 free")
for t in (0,10,20,30,45,60,80):
    d=np.array([-31.6,17.0])/np.hypot(-31.6,17.0)
    c0=d*t
    def m2(q): return mod(np.r_[c0,q],P,True,None)
    s=least_squares(m2,[80+t*0.9,200,35.5],loss='soft_l1',f_scale=0.1); r=m2(s.x)
    print(" t %3d centre %.1f %.1f rho0 %.2f Rv %.1f zc %.2f  p50 %.3f p90 %.3f"%(t,*c0,*s.x,np.median(abs(r)),np.percentile(abs(r),90)))
