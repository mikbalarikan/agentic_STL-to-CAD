"""scan (black) vs CAD (red) sections. usage: p5c_secs.py [tag]  -> nx/P5c/sec_*.png"""
import sys; sys.path.insert(0,'an')
import numpy as np, lib, trimesh, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
tag="P5c"
cad={w:trimesh.load(f"nx/P5c/{w}_{tag}.stl",process=False) for w in ("out","inn")}
scan={w:lib.load(w+"_scan",1500000) for w in ("out","inn")}
# name, which, axis, value, (h axis idx, v axis idx), xlim, ylim
ITEMS=[
 ("tabD_x-19","out",0,-19.2,(1,2),(176,196),(-5,10)),
 ("lugD_x-19","inn",0,-19.2,(1,2),(176,196),(58,74)),
 ("tabD_x-21p3_foot","out",0,-21.3,(1,2),(176,196),(-5,10)),
 ("ear_out_z20","out",2,20.0,(0,1),(45,80),(-55,-20)),
 ("ear_out_z33","out",2,33.0,(0,1),(45,80),(-55,-20)),
 ("ear_out_z6","out",2,6.0,(0,1),(45,80),(-55,-20)),
 ("ear_inn_z70","inn",2,70.0,(0,1),(45,80),(-55,-20)),
 ("pad_ring1","out",0,None,None,None,None),
 ("wedge327_z72","inn",2,72.0,(0,1),(34,66),(-46,-20)),
 ("wedge327_z68","inn",2,68.0,(0,1),(34,66),(-46,-20)),
 ("tail_seam_out_z10","out",2,10.0,(0,1),(40,90),(-52,-24)),
 ("tail_seam_inn_z61","inn",2,61.0,(0,1),(40,90),(-52,-24)),
 ("spigot_B2_out_y29p85","out",1,29.85,(0,2),(55,97),(20,45)),
 ("pocket_B2_inn_y29p85","inn",1,29.85,(0,2),(55,97),(30,95)),
 ("hip_bolts_out_y272","out",1,272.0,(0,2),(-25,100),(-25,95)),
 ("hip_out_x38_yz","out",0,38.0,(1,2),(262,285),(-25,95)),
 ("hub_inn_x0","inn",0,0.0,(1,2),(-45,45),(68,98)),
 ("oval_inn_x0p15","inn",0,0.15,(1,2),(35,55),(70,90)),
 ("window_inn_z58","inn",2,58.0,(0,1),(-75,-30),(-45,50)),
 ("holeH1_inn_y62","inn",1,62.35,(0,2),(45,75),(70,92)),
]
for nm,w,ax,val,hv,xl,yl in ITEMS:
    if val is None: continue
    fig,a=plt.subplots(figsize=(10,8))
    for src,col,lw in (("scan","k",0.8),("cad","r",0.9)):
        if src=="scan": v,f=scan[w]
        else: v,f=np.asarray(cad[w].vertices),np.asarray(cad[w].faces)
        S=lib.section(v,f,ax,val)
        for s in S: a.plot(s[:,hv[0]],s[:,hv[1]],col+"-",lw=lw)
    a.set_xlim(*xl); a.set_ylim(*yl); a.set_aspect("equal"); a.grid(True); a.set_title(f"{nm} {w} axis{ax}={val} scan black / CAD red")
    plt.tight_layout(); plt.savefig(f"nx/P5c/sec_{nm}.png",dpi=70); plt.close()
    print(nm)
