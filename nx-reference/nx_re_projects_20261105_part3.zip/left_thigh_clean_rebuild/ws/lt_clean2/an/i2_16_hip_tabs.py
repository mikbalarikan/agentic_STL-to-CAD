from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS, math
from scipy.signal import find_peaks
rows = []
def levels(m, vals, lo, hi, bw=0.1, thr=0.15):
    if m.sum() < 5: return []
    h, ed = np.histogram(vals[m], bins=np.arange(lo, hi, bw), weights=a[m]); pk, _ = find_peaks(h, height=h.max() * thr, distance=3)
    return [(round(float(ed[i] + bw / 2), 2), int(h[i])) for i in pk]
base = (d >= 1.5) & (c[:, 2] > 36)
x, y, z = c[:, 0], c[:, 1], c[:, 2]
# ---- hip blocks (plate side blocks), web, pad, ring clearance
lv_l = levels(base & (np.abs(n[:, 1]) > 0.9) & (x < -17) & (x > -26) & (z < 60), y, 255, 285)
lv_r = levels(base & (np.abs(n[:, 1]) > 0.9) & (x > 91) & (x < 100) & (z < 60), y, 255, 285)
for nm, sx0, sx1, xin in (("HIP_BLOCK_L", -35, -10, -14.35), ("HIP_BLOCK_R", 85, 120, 90.35)):
    blk = base & (y > 265.5) & (y < 276.5) & (x > sx0) & (x < sx1) & (z < 100)
    # y-end face level (facing +y) and start face (-y)
    f_end = level_fit(blk & (n[:, 1] > 0.9) & (np.abs(y - 272.35) < 1.5) , tol=0.3) if False else None
    ye = levels(blk & (n[:, 1] > 0.9) & (z < 60), y, 266, 278, 0.05, 0.3)
    ys = levels(blk & (n[:, 1] < -0.9) & (z < 60), y, 262, 278, 0.05, 0.3)
    xf = levels(blk & (np.abs(n[:, 0]) > 0.9) & (z < 60), x, sx0, sx1, 0.05, 0.3)
    rows.append(make_row(nm, "hip_block", dict(face_y_plus_levels=ye, face_y_minus_levels=ys, face_x_levels=xf, end_y=ye[0][0] if ye else None), "plane levels by 0.05 mm histograms of the face normals", None, blk,
                         dict(y0=DS.HIP_Y0, y1=DS.HIP_Y1, clear_D=105.25)))
web = base & (y > 265.5) & (y < 270.3) & (x > -14) & (x < 90) & (np.abs(n[:, 1]) > 0.5)
yy = levels(web & (np.abs(n[:, 1]) > 0.9), y, 262, 274, 0.05, 0.1)
rows.append(make_row("HIP_WEB", "plate", dict(face_y_levels=yy, thickness=(max(l[0] for l in yy) - min(l[0] for l in yy)) if len(yy) > 1 else None), "plane levels of the plate faces (normals +-y)", None,
                     base & (y > 265.8) & (y < 270.4) & (x > -16) & (x < 92) & (z < 105), dict(y0=DS.HIP_Y0, y1=268.2)))
pad = base & (y > 265.5) & (y < 278) & (x > 20) & (x < 56) & (z > 82) & (z < 95)
pz = level_fit(pad & (n[:, 2] < -0.9) & (np.abs(z - 85.3) < 0.8), tol=0.25)
px = levels(pad & (np.abs(n[:, 0]) > 0.9), x, 18, 58, 0.05, 0.3); py = levels(pad & (np.abs(n[:, 1]) > 0.9), y, 262, 280, 0.05, 0.2)
rows.append(make_row("HIP_PAD", "pad", dict(bottom_z=pz["z"] if pz else None, x_faces=px, y_faces=py), "level / plane histograms of the pad faces", pz["rms"] if pz else None,
                     (y > 265.8) & (y < 277.5) & (x > 19.5) & (x < 56.5) & (z > 80) & (d >= 0.8) & ~((n[:, 2] > 0.7)), dict(x0=21.97, x1=53.97, y0=266.5, y1=276.85, z=85.32)))
# ring clearance cylinder about the hip axis (along Y): circle fit in (x,z)
hx, hz = 37.97, 35.18
rr = np.hypot(x - hx, z - hz)
m = (np.abs(n[:, 1]) < 0.3) & (y > 266.8) & (y < 272.0) & (rr > 49) & (rr < 56) & (z > 40) & (d >= 1.5)
if m.sum() > 100:
    h_, ed = np.histogram(rr[m], bins=np.arange(49, 56, 0.05), weights=a[m]); rc = ed[np.argmax(h_)] + .025; m &= np.abs(rr - rc) < 0.4
    cx_, cz_, R_, rms_ = circle_fit(np.c_[x[m], z[m]], a[m])
    rows.append(make_row("HIP_RING_CLEARANCE", "cyl_cut_y", dict(axis_xz=[cx_, cz_], D=2 * R_, n=int(m.sum())), "circle fit in (x,z) of the clearance wall around the outer hip ring, y 266.8..272", rms_,
                         (np.abs(rr - R_) < 1.0) & (y > 266.4) & (y < 272.6) & (z > 40) & (d >= 1.5) & (np.abs(n[:, 1]) < 0.7), dict(axis_xz=[hx, hz], D=105.25)))
# ---- lugs D / 3
mD = (x > -23) & (x < -15) & (y > 172) & (y < 194) & (z > 55) & (z < 85) & (d >= 1.0)
xl = levels(mD & (np.abs(n[:, 0]) > 0.9), x, -23, -15, 0.05, 0.15)
zb = level_fit(mD & (n[:, 2] < -0.9) & (z < 70), tol=0.3)
ye_ = levels(mD & (np.abs(n[:, 1]) > 0.9), y, 172, 194, 0.1, 0.2)
# hole axis x: circle in (y,z)
mh = mD & (np.abs(n[:, 0]) < 0.35) & (np.hypot(y - 188.4, z - 65.6) < 3.0)
hh = None
if mh.sum() > 50:
    cy_, cz2, R2, rms2 = circle_fit(np.c_[y[mh], z[mh]], a[mh]); hh = dict(centre_yz=[cy_, cz2], D=2 * R2, rms=rms2)
rows.append(make_row("LUG_D", "tab", dict(x_faces=xl, y_faces=ye_, bottom_z=zb["z"] if zb else None, hole=hh), "plane level histograms (0.05 mm) + hole circle fit in (y,z)", hh["rms"] if hh else None, mD, dict(x0=-20.5, x1=-17.9, y0=177.0, y1=191.45, z0=62.1, hole_D=2.6, hole_yz=[188.4, 65.6])))
O3 = np.array([-34.0, 238.5]); U3 = np.array([0.61527086, -0.78831578]); W3 = np.array([0.78831578, 0.61527086])
s_ = (x - O3[0]) * U3[0] + (y - O3[1]) * U3[1]; t_ = (x - O3[0]) * W3[0] + (y - O3[1]) * W3[1]; nW = n[:, 0] * W3[0] + n[:, 1] * W3[1]
m3 = (np.abs(s_) < 6) & (t_ > -4) & (t_ < 3.5) & (z > 40) & (z < 85) & (d >= 1.0)
tl = levels(m3 & (np.abs(nW) > 0.9), t_, -4, 3.5, 0.05, 0.15)
sl_ = levels(m3 & (np.abs(n[:, 0] * U3[0] + n[:, 1] * U3[1]) > 0.9), s_, -6, 6, 0.05, 0.15)
zb3 = level_fit(m3 & (n[:, 2] < -0.9) & (z < 70), tol=0.3)
rows.append(make_row("LUG_3", "tab", dict(t_faces_along_W=tl, s_faces_along_U=sl_, bottom_z=zb3["z"] if zb3 else None, O=O3.tolist(), U=U3.tolist(), W=W3.tolist()), "plane level histograms in the lug frame (O,U,W)", None, m3,
                     dict(t=[-1.65, 0.95], s=[-3.5, 3.1], z0=50.08, hole_D=2.6)))
dump("hip_tabs", rows)
