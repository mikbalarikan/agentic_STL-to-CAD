import sys; sys.path.insert(0,'an')
import numpy as np, lib, trimesh
v,f=lib.load("out_scan",1500000)
m=trimesh.Trimesh(*lib.load("out_scan",1500000),process=False)
env=trimesh.load("nx/base_v2/envelope.stl")
def sect(mesh,z):
    l=mesh.section(plane_origin=[0,0,z],plane_normal=[0,0,1])
    if l is None: return np.zeros((0,2))
    return np.vstack([e for e in [np.array(s)[:,:2] for s in l.discrete]])
for z in (10,20,30):
    S=sect(m,z); E=sect(env,z)
    print("z",z)
    for y in range(-52,-20,3):
        a=S[(abs(S[:,1]-y)<0.7)&(S[:,0]>45)]; b=E[(abs(E[:,1]-y)<0.7)&(E[:,0]>45)]
        print("  y %4d scan x max %s  env x max %s"%(y, a[:,0].max().round(2) if len(a) else None, b[:,0].max().round(2) if len(b) else None))
