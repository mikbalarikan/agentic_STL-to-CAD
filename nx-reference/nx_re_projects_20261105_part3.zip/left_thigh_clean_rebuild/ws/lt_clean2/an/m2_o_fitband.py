"""Loft fit with the +X band excluded from the data; then band depth map."""
import sys,os,time
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_loft as L, m2_g_fit as G, m2_f_data as FD
EDGE=np.array([(0,38.5),(60,38.5),(76,39),(88,40.5),(100,41.8),(112,42.5),(130,41.5),(142,40),(154,39.5),(166,37),(178,36.5),(184,35),(190,25),(196,25.5),(202,27),(208,28),(214,30),(220,32),(232,35),(244,38),(256,41.8),(264,41.8),(264.5,0.0),(400,0.0)])
def edge(y): return np.interp(y,EDGE[:,0],EDGE[:,1])
def inband(y,x,z,pad=1.0):
    th=np.degrees(np.arctan2(z-FD.CZ0,x-FD.CX0)); return np.abs(th)<edge(y)+pad
if __name__=="__main__":
    st=[float(s) for s in sys.argv[1].split(",")]; NP=int(sys.argv[2]); tag=sys.argv[3]
    D=np.load("work/m2/cells.npy"); keepc=~inband(D[:,0],D[:,1],D[:,2])
    lf,keep,sr=G.run(st,NP,D=D[keepc])
    np.savez(f"work/m2/loft_{tag}.npz",st=st,P=lf.P)
    V,F,ys,u=G.mesh_of(lf,st[0],st[-1])
    S=G.scan_pts(60,255); d=G.dist_to(V,F,S[:,:3]); ib=inband(S[:,1],S[:,0],S[:,2],0.0)
    y=S[:,1]
    def rep(m):
        f,p90,p50=G.stats(d[m],S[m,3]); return "%.1f%% p90 %.3f"%(100*f,p90)
    print(tag,"all",rep(y>0),"| outside band",rep(~ib),"| in band",rep(ib),"| band 100-255",rep(ib&(y>100)),flush=True)
    # band depth: signed radial
    th=np.arctan2(S[:,2]-FD.CZ0,S[:,0]-FD.CX0); r=np.hypot(S[:,0]-FD.CX0,S[:,2]-FD.CZ0)
    dep=np.full(len(S),np.nan)
    uu=np.linspace(0,1,2880,endpoint=False)
    for y0 in np.unique(np.round(S[ib,1]/2)*2):
        m=ib&(np.abs(S[:,1]-y0)<=1.0)
        C=lf.curve(y0,uu)[0]; rc=np.hypot(C[:,0]-FD.CX0,C[:,1]-FD.CZ0); tc=np.mod(np.arctan2(C[:,1]-FD.CZ0,C[:,0]-FD.CX0),2*np.pi)
        o=np.argsort(tc); dep[m]=np.interp(np.mod(th[m],2*np.pi),tc[o],rc[o],period=2*np.pi)-r[m]
    np.savez(f"work/m2/band_{tag}.npz",S=S,dep=dep,d=d,ib=ib)
    for lo,hi in ((60,100),(100,140),(140,160),(160,185),(185,215),(215,255)):
        m=ib&(y>=lo)&(y<hi)&np.isfinite(dep); 
        if m.sum()>20: print(" band Y %d-%d depth (loft-floor) median %.2f p10 %.2f p90 %.2f"%(lo,hi,np.median(dep[m]),*np.percentile(dep[m],[10,90])))
