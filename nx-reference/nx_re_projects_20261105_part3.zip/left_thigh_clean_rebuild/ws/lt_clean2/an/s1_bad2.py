import sys
from s1_eval import *
import pyvista as pv; pv.OFF_SCREEN=True
tag=sys.argv[1]; zn=sys.argv[2]; thr=float(sys.argv[3]); dd=np.load(os.path.join(S1,f'dd_{tag}.npy'))
msk=zones[zn]&(dd>thr)
print(zn, msk.sum(), 'of', zones[zn].sum())
Q=P[msk]; C=np.minimum(dd[msk],3)
fo=Q.mean(0)
for nm,dv in [('a',(0.3,-0.8,0.5)),('b',(-0.8,0.2,0.5)),('c',(0.2,-0.3,-1)),('d',(0.3,-0.2,1))]:
    p=pv.Plotter(window_size=(1100,800)); p.add_mesh(pv.PolyData(Q),scalars=C,cmap='jet',point_size=3,show_scalar_bar=True)
    dv=np.array(dv,float);dv/=np.linalg.norm(dv); p.camera.focal_point=fo;p.camera.position=fo+ float(sys.argv[4])*dv;p.camera.up=(0,0,1) if nm in('a','b') else (0,1,0)
    p.screenshot(os.path.join(S1,f'bad2_{tag}_{nm}.png'));p.close()
