import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
# signed deviation of scan exterior points vs old master, via nearest old-CAD triangle centre normal
fig,ax=plt.subplots(2,3,figsize=(27,14))
for j,(side,sel) in enumerate((('-X flank',lambda c:c[:,0]<-36),('+X flank',lambda c:c[:,0]>108),('top/bottom',lambda c:(c[:,0]>-30)&(c[:,0]<110)))):
  for i,(tag,sn,cn,dn) in enumerate((('out','out_scan','out_cad','dev_oldC'),('inn','inn_scan','inn_cad','dev_oldInnB'))):
    v,f=lib.load(sn,1500000); c,nn,a=lib.tri_data(v,f)
    vc,fc=lib.load(cn); cc,nc,ac=lib.tri_data(vc,fc)
    m=np.load(f"work/masks/{tag}_ext_hip.npy"); m=m[(c[m,1]>235)&sel(c[m])]
    t=cKDTree(cc); d,ix=t.query(c[m]); s=((c[m]-cc[ix])*nc[ix]).sum(1)
    if j==2:
        s_=ax[i,j].scatter(c[m,1],c[m,0],c=s,s=1.5,cmap='bwr',vmin=-1.5,vmax=1.5); ax[i,j].set_ylabel('X')
    else:
        s_=ax[i,j].scatter(c[m,1],c[m,2],c=s,s=1.5,cmap='bwr',vmin=-1.5,vmax=1.5); ax[i,j].set_ylabel('Z')
    plt.colorbar(s_,ax=ax[i,j]); ax[i,j].set_title(f"{tag} scan ext signed dev vs old master, {side}"); ax[i,j].set_xlabel('Y'); ax[i,j].grid(True)
plt.tight_layout(); plt.savefig("work/m3/ext_feat_map.png",dpi=45)
