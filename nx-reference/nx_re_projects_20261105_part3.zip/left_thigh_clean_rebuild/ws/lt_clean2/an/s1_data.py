from s1_lib import *
out=dict(P=[],a=[],sid=[],band=[],zd=[],zb=[],zh=[],nrm=[])
for k,s in enumerate(['out','inn']):
    v,f,c,n,a=scan(s); e=np.load(f'{W}/m2/ext_{s}.npy')
    idx=np.where(e)[0]
    def fl(nm):
        z=np.zeros(len(c),bool); z[mask(s,nm)]=True; return z[idx]
    out['P'].append(c[idx]); out['a'].append(a[idx]); out['sid'].append(np.full(len(idx),k)); out['nrm'].append(n[idx])
    out['band'].append(fl('band')); out['zd'].append(fl('ext_drum')); out['zb'].append(fl('ext_body')); out['zh'].append(fl('ext_hip'))
out={k:np.concatenate(v) for k,v in out.items()}
np.savez(os.path.join(S1,'ext_all.npz'),**out)
P=out['P']; print(P.shape, 'band',out['band'].sum(),'drum',out['zd'].sum(),'body',out['zb'].sum(),'hip',out['zh'].sum())
none=~(out['zd']|out['zb']|out['zh'])
print('in no zone',none.sum(), out['a'][none].sum())
for y0,y1 in [(-60,-45),(-45,-30),(-30,-15),(-15,0),(0,30),(30,64),(64,80)]:
    m=none&(P[:,1]>=y0)&(P[:,1]<y1); print(y0,y1,m.sum(),out['a'][m].sum().round())
