import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
sys.argv=['x']
exec(open('an/m3_s_loft.py').read().split("sets={")[0])
import itertools
rows=[]
for y0 in (258,262,266,270):
    for nint in (1,2,3):
        best=None
        # candidate intermediate positions on 1mm grid, limited choose by coarse search 2mm
        cand=np.arange(y0+3,YM-2,2.0)
        for combo in itertools.combinations(cand,nint):
            ys=[y0,*combo,YM]
            d=evalm(model(ys)); pc,pp=rep(d,y0)
            if best is None or pc>best[0]: best=(pc,ys,pp,rep(d,272)[0])
        print('start %d, %d intermediate: best %.1f%% (Y>=start) , %.1f%% (Y>=272), p50/90/99 %s ; sections %s'%(y0,nint,best[0],best[3],np.round(best[2],2),[round(float(x),1) for x in best[1]]),flush=True)
        rows.append(dict(y0=y0,nint=nint,pct=float(best[0]),pct272=float(best[3]),sections=[float(x) for x in best[1]],p=[float(x) for x in best[2]]))
json.dump(rows,open('work/m3/loft_search.json','w'),indent=1)
