from i2_common import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
v,f,c,n,a = scan(); d = de(); p5, old = dev()
print("de pct", np.percentile(d,[50,75,90,95,99]))
w=a/a.sum()
for lo,hi in ((0,1),(1,2.4),(2.4,3.9),(3.9,99)):
    m=(d>=lo)&(d<hi); print(lo,hi,"area%",w[m].sum()*100,"p5<0.5",w[m&(p5<.5)].sum()/w[m].sum()*100,"old",w[m&(old<.5)].sum()/w[m].sum()*100)
# plan maps of deep tris
m = d>=1.5
s=4; x0,y0=-75,-75
def img(val, mask, mode):
    X=((c[mask,0]-x0)*s).astype(int); Y=((c[mask,1]-y0)*s).astype(int)
    H=int((300+80)*s); Wd=int((200)*s)
    im=np.full((H,Wd),np.nan)
    o=np.argsort(-val[mask] if mode=='min' else val[mask])  # last write wins
    im[Y[o],X[o]]=val[mask][o]
    return im
fig,ax=plt.subplots(1,3,figsize=(21,17))
for k,(val,t,mode,vm) in enumerate(((c[:,2],"scan z of deep tris (min z shown)",'min',(36,100)),(np.minimum(p5,3),"part5 dev",'max',(0,2)),(np.minimum(old,3),"old dev",'max',(0,2)))):
    im=img(val,m,mode); ax[k].imshow(im,origin='lower',extent=[x0,x0+im.shape[1]/s,y0,y0+im.shape[0]/s],cmap='turbo',vmin=vm[0],vmax=vm[1]); ax[k].set_title(t); ax[k].set_aspect('equal')
plt.tight_layout(); plt.savefig(os.path.join(O,"overview.png"),dpi=60)
