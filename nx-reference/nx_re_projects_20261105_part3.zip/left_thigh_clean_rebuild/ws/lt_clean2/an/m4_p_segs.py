"""M4: runs where part 5 wall faces are > 0.5 off the scan (outer z34.3, inner z36.6), with the old master for comparison."""
import sys, os, pickle, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
from m4_x import NAMES
W4 = os.path.join(lib.W, "m4")
C = pickle.load(open(os.path.join(W4, "cmp.pkl"), "rb"))
def g(src, ch, k): return np.array([r.get(k, np.nan) for r in C[src] if r["chain"] == ch], float)
def runs(m, minlen=4):
    out = []; i = 0
    while i < len(m):
        if m[i]:
            j = i
            while j + 1 < len(m) and m[j + 1]: j += 1
            if j - i + 1 >= minlen: out.append((i, j))
            i = j + 1
        else: i += 1
    return out
segs = []
for part, kin, kout in (("outer@z34.3", "o_tin", "o_tout"), ("inner@z36.6", "i_tin", "i_tout")):
    for ch in NAMES:
        s = g("scan", ch, "s"); x = g("scan", ch, "x"); y = g("scan", ch, "y")
        for face, key in (("exterior", kout), ("interior", kin)):
            e5 = g("p5", ch, key) - g("scan", ch, key); eo = g("old", ch, key) - g("scan", ch, key)
            if face == "interior": e5 = np.where(abs(e5) > 3, np.nan, e5)
            m = np.isfinite(e5) & (abs(e5) > 0.5)
            for i, j in runs(m):
                sl = slice(i, j + 1)
                wsc = (g("scan", ch, kout) - g("scan", ch, kin))[sl]; w5 = (g("p5", ch, kout) - g("p5", ch, kin))[sl]
                seg = dict(part=part, chain=ch, face=face, s0=float(s[i]), s1=float(s[j]), y0=float(y[i]), y1=float(y[j]), x0=float(x[i]), x1=float(x[j]),
                           p5_err_mean=float(np.nanmean(e5[sl])), p5_err_max=float(e5[sl][np.nanargmax(abs(e5[sl]))]), old_err_mean=float(np.nanmean(eo[sl])),
                           wall_scan=float(np.nanmedian(wsc)), wall_p5=float(np.nanmedian(w5)))
                segs.append(seg)
                print("%-12s %-9s %-8s s %5.0f-%5.0f  (%6.1f,%6.1f)->(%6.1f,%6.1f)  p5 err mean %+.2f max %+.2f | old %+.2f | wall scan %.2f p5 %.2f" % (part, ch, face, seg["s0"], seg["s1"], seg["x0"], seg["y0"], seg["x1"], seg["y1"], seg["p5_err_mean"], seg["p5_err_max"], seg["old_err_mean"], seg["wall_scan"], seg["wall_p5"]))
json.dump(segs, open(os.path.join(W4, "p5_face_segments.json"), "w"), indent=1)
