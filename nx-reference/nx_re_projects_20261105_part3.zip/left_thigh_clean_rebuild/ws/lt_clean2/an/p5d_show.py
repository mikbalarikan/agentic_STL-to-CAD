import json,sys
w=sys.argv[1]; flt=sys.argv[2:] 
d=json.load(open(rf"C:\NX_MCP_WORKSPACE\lt_clean2\work\p5d\rootfit_{w}.json"))
for r in sorted(d,key=lambda r:(sorted(x.split('_Z')[0] for x in r['n']),-r['L'])):
    nm="/".join(x.split('_Z')[0] for x in r['n'])
    if flt and not any(k in nm for k in flt): continue
    bb=r['bb']
    print(r['tag'],nm,'L',r['L'],'bb',[round(x) for x in bb],'R',[ (round(x['R'],1),round(x['rms'],2)) for x in r['fits']])
