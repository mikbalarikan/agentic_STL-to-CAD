import sys, numpy as np, trimesh, pyvista as pv, open3d as o3d
sys.path.insert(0,"an"); import lib
from v5e_occ import scene
pv.OFF_SCREEN=True
O="work/q7/"
def cam(p,c0,d,up,par):
    d=np.array(d,float); d/=np.linalg.norm(d); p.camera.position=tuple(c0+d*1000); p.camera.focal_point=tuple(c0); p.camera.up=up; p.camera.parallel_projection=True; p.camera.parallel_scale=par
for w in ("out","inn"):
    v,f=lib.load({"out":"out_scan","inn":"inn_scan"}[w],1500000)
    dd=np.load(f"work/dev_q7{w}_{w}.npz"); d1=dd["d1"]
    M=trimesh.load(f"nx/P5d/{w}_P5d_final.stl",process=True); S=scene((v,f))
    dv=S.compute_distance(o3d.core.Tensor(np.asarray(M.vertices,np.float32))).numpy()
    cad=pv.wrap(M); cad.point_data["dist"]=dv
    sc=pv.PolyData(v,np.c_[np.full(len(f),3),f].ravel()); sc.cell_data["dist"]=d1
    c0=np.array(cad.center); sgn=-1 if w=="out" else 1   # open side (joint plane) direction
    views={"PX":((1,0.15,0.1),(0,0,1),190),"MX":((-1,0.15,0.1),(0,0,1),190),
           "IN":((0.05,0.1,-sgn),(0,1,0),190)}   # looking at the open side (inside)
    # outer open side faces +z -> camera from +z; inner open side faces -z -> camera from -z
    views["IN"]=((0.05,0.1,1 if w=="out" else -1),(0,1,0),190)
    for nm,(mesh,lab) in (("cad",(cad,"CAD distance to scan (mm)")),("scan",(sc,"scan distance to CAD (mm)"))):
        for vn,(d,up,par) in views.items():
            p=pv.Plotter(off_screen=True,window_size=(1500,900)); p.set_background("white")
            p.add_mesh(mesh,scalars="dist",cmap="turbo",clim=(0,1.5),smooth_shading=False,scalar_bar_args={"title":lab,"n_labels":4},ambient=0.3)
            cam(p,c0,d,up,par); p.add_text(f"LT-{'OUT' if w=='out' else 'INN'}-001 {lab} view {vn}",font_size=10)
            p.screenshot(f"{O}dev_{nm}_{w}_{vn}.png"); p.close()
    # CAD-only renders
    V={"outside_PX":((1,0.15,0.1),(0,0,1),190),"outside_MX":((-1,0.15,0.1),(0,0,1),190),
       "outside_end":((0.0,-0.2,-1 if w=="out" else 1),(0,1,0),190),
       "inside_a":((0.4,-0.5,1 if w=="out" else -1),(0,1,0),190),"inside_b":((-0.4,0.5,1 if w=="out" else -1),(0,1,0),190)}
    for vn,(d,up,par) in V.items():
        p=pv.Plotter(off_screen=True,window_size=(1500,900)); p.set_background("white")
        p.add_mesh(cad,color="#c9d3dc",smooth_shading=False,specular=0.25,ambient=0.25)
        fe=cad.extract_feature_edges(boundary_edges=False,feature_angle=35,manifold_edges=False,non_manifold_edges=False)
        if fe.n_points: p.add_mesh(fe,color="#303030",line_width=1.0)
        cam(p,c0,d,up,par); p.screenshot(f"{O}cad_{w}_{vn}.png"); p.close()
    print(w,"done")
