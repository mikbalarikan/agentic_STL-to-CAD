import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.spatial import cKDTree
HX,HZ=37.97,35.18
for tag,sn in (('out','out_scan'),('inn','inn_scan')):
    v,f=lib.load(sn,1500000); c,nn,a=lib.tri_data(v,f); m=np.load(f"work/masks/{tag}_ext_hip.npy")
    r=np.hypot(c[:,0]-HX,c[:,2]-HZ); rd=np.stack([(c[:,0]-HX)/np.maximum(r,1e-9),0*r,(c[:,2]-HZ)/np.maximum(r,1e-9)],1); nr=(nn*rd).sum(1)
    zsel=(c[:,2]<34.5) if tag=='out' else (c[:,2]>35.9)
    ints=np.where((c[:,1]>262)&(c[:,1]<288)&zsel&(nr<-0.3)&(r>55))[0]
    t=cKDTree(c[ints])
    for lo,hi in ((262,270),(270,278),(278,284),(284,287)):
        k=m[(c[m,1]>lo)&(c[m,1]<hi)&(abs(c[m,2]-HZ)>8)]; k=k[::7]
        d,_=t.query(c[k]); print(tag,'Y%d-%d  nearest-interior distance (normal wall) p10/50/90: %.2f %.2f %.2f'%(lo,hi,*np.percentile(d,[10,50,90])))
