import sys
from s1_build import *
from s1_shell import faces
from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet
from OCP.TopExp import TopExp, TopExp_Explorer
from OCP.TopAbs import TopAbs_EDGE, TopAbs_FACE
from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Surface
tag=sys.argv[1]; Rf=float(sys.argv[2])
env,lo,body,dr=build(tag,verbose=False)
fs=faces(body)
print([BRepAdaptor_Surface(f).GetType().name for f in fs])
m=TopTools_IndexedDataMapOfShapeListOfShape(); TopExp.MapShapesAndAncestors_s(body,TopAbs_EDGE,TopAbs_FACE,m)
mk=BRepFilletAPI_MakeFillet(body); n=0
for i in range(1,m.Extent()+1):
    e=TopoDS.Edge_s(m.FindKey(i)); lst=m.FindFromIndex(i)
    types=[BRepAdaptor_Surface(TopoDS.Face_s(x)).GetType().name for x in lst]
    if 'GeomAbs_Cone' in types and 'GeomAbs_BSplineSurface' in types:
        mk.Add(Rf,e); n+=1
print('crease edges',n)
mk.Build(); print('done',mk.IsDone())
if mk.IsDone():
    s=mk.Shape(); print('valid',valid(s),volume(s),volume(body))
    env2=fuse(s,dr); V,F=to_mesh(env2,0.03); import trimesh; trimesh.Trimesh(V,F,process=False).export(os.path.join(S1,f'env_{tag}_cr{int(Rf)}.stl'))
