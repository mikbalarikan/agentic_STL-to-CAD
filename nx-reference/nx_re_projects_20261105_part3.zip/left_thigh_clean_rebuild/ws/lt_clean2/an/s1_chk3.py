from s1_build import *
import trimesh, open3d as o3d
import sys
env,lo,body,dr=build(sys.argv[1],verbose=False)
sc=o3d.t.geometry.RaycastingScene()
def addmesh(shape):
    V,F=to_mesh(shape,0.02); sc=o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(V.astype(np.float32)),o3d.core.Tensor(F.astype(np.uint32))); return sc
S={'env':addmesh(env),'loft':addmesh(lo),'cone':addmesh(cone_solid())}
for Y in [262,266,270,276,282,286]:
    xa=HX+0.0349*(Y-287.39)
    row=[]
    for dx,dz in [(1,0),(-1,0),(0,1),(0,-1),(0.7,0.7)]:
        r=[]
        for k,s in S.items():
            ray=o3d.core.Tensor(np.array([[xa,Y,HZ,dx,0,dz]],np.float32)); t=s.cast_rays(ray)['t_hit'].numpy()[0]; r.append(f'{k}:{t:6.2f}')
        row.append(' '.join(r))
    print(Y,'cone R',round(71+0.4663*(287.39-Y),2),'|',' || '.join(row))
