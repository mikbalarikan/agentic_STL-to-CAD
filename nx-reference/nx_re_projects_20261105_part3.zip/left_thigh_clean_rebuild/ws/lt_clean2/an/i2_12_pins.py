from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
rows = []
def rr_(cc): return np.hypot(c[:, 0] - cc[0], c[:, 1] - cc[1])
def tip_level(cc, rmax, zlo, zhi, sign=-1):
    r = rr_(cc); m = (r < rmax) & (n[:, 2] * sign > 0.9) & (c[:, 2] > zlo) & (c[:, 2] < zhi) & (d > 0.5)
    return level_fit(m)
# ---- knee cover pins N1/N2 (pin Ø3 hanging from the lintel at Z 62.57, lug Ø8 + web)
for k, (x, y) in DS.KNEE_COVER_PINS.items():
    pin = cyl_fit((x, y), 1.0, 2.3, 55.0, 62.2, de_min=0.3)
    cc = (pin["cx"], pin["cy"]) if pin else (x, y)
    tip = tip_level(cc, 1.4, 50, 62.0, -1); root = tip_level(cc, 6.0, 61.5, 64.0, -1)
    lug = cyl_fit(cc, 2.8, 5.0, 56.0, 62.2, de_min=0.3)
    r = rr_(cc)
    mpin = (r < 2.4) & (c[:, 2] < 62.9) & (c[:, 2] > 50) & (d > 0.3)
    mlug = (r >= 2.4) & (r < 6.0) & (c[:, 2] < 62.9) & (c[:, 2] > 50) & (d > 0.3)
    rows.append(make_row(f"{k}_pin", "pin", dict(centre=[cc[0], cc[1]], D=pin["D"] if pin else None, tip_z=tip["z"] if tip else None, root_z=root["z"] if root else None,
                         length=(root["z"] - tip["z"]) if tip and root else None, draft_deg=pin["draft_deg"] if pin else None),
                         "cylinder fit on the pin wall z55..62.2 + tip / lintel levels", pin["rms"] if pin else None, mpin,
                         dict(centre=[x, y], D=DS.N_PIN_D, root_z=DS.N_PIN_FACE, length=DS.N_PIN_LEN)))
    rows.append(make_row(f"{k}_lug", "lug", dict(centre=[lug["cx"], lug["cy"]] if lug else None, D=lug["D"] if lug else None, web_note="see knee window"),
                         "cylinder fit z56..62.2, r 2.8..5", lug["rms"] if lug else None, mlug, dict(D=8.0, web_t=6.0)))
# ---- hip pins N3/N4 (Ø4 down from the hip pad underside 85.32)
for k, (x, y) in DS.HIP_PINS.items():
    pin = cyl_fit((x, y), 1.4, 2.8, 79.0, 85.0, de_min=0.3)
    cc = (pin["cx"], pin["cy"]) if pin else (x, y)
    tip = tip_level(cc, 1.6, 70, 85.0, -1); root = tip_level(cc, 8.0, 84.5, 86.5, -1)
    r = rr_(cc); mpin = (r < 2.8) & (c[:, 2] < 85.6) & (c[:, 2] > 70) & (d > 0.3)
    rows.append(make_row(f"{k}_pin", "pin", dict(centre=[cc[0], cc[1]], D=pin["D"] if pin else None, tip_z=tip["z"] if tip else None, root_z=root["z"] if root else None, length=(root["z"] - tip["z"]) if tip and root else None),
                         "cylinder fit z79..85 + tip / pad levels", pin["rms"] if pin else None, mpin, dict(centre=[x, y], D=DS.HIP_PIN_D, root_z=DS.HIP_PIN_FACE, length=DS.HIP_PIN_LEN)))
# ---- inner pin lugs P1..P3 (Ø9 lug, Ø4 hole)
for k, (x, y, to, pt, fi) in DS.PINS.items():
    lug = cyl_fit((x, y), 3.8, 5.6, 38.0, 70.0, de_min=0.3)
    cc = (lug["cx"], lug["cy"]) if lug else (x, y)
    hole = cyl_fit(cc, 1.2, 3.0, 36.6, 46.0, de_min=0.3)
    r = rr_(cc)
    face = level_fit((r < 4.4) & (n[:, 2] < -0.9) & (c[:, 2] > 34.8) & (c[:, 2] < 37.5) & (d > 0.3))
    hfl = level_fit((r < 1.8) & (n[:, 2] < -0.9) & (c[:, 2] > 38.0) & (c[:, 2] < 52) & (d > 0.3))
    mk = (r < 5.8) & (c[:, 2] > 34.5) & (d >= 1.0)
    rows.append(make_row(f"{k}_lug_inn", "lug_hole", dict(centre=[cc[0], cc[1]], lug_D=lug["D"] if lug else None, hole_D=hole["D"] if hole else None, hole_centre=[hole["cx"], hole["cy"]] if hole else None,
                         face_z=face["z"] if face else None, hole_floor_z=hfl["z"] if hfl else None),
                         "cylinder fits (lug wall z38..70, hole wall z36.6..46) + face / hole-floor levels", (hole or lug or {}).get("rms"), mk,
                         dict(centre=[x, y], lug_D=DS.PIN_LUG_D, hole_D=DS.PIN_HOLE_D, hole_depth=DS.PIN_HOLE_DEPTH, face_z=fi)))
dump("pins", rows)
