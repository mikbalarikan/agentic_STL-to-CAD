import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
Ys=[40,60,80,100,130,160,190,220,250,265]
fig,axs=plt.subplots(2,5,figsize=(30,12))
for ax,y in zip(axs.ravel(),Ys):
    for n,c in (("out_scan","r"),("inn_scan","b")):
        v,f=lib.load(n,1500000); s=lib.section(v,f,1,y)
        for a,b in s[::1]: ax.plot([a[0],b[0]],[a[2],b[2]],c,lw=.5)
    ax.set_aspect('equal'); ax.set_title(f"Y={y}"); ax.grid(True)
plt.tight_layout(); plt.savefig("work/m2/view_secs.png",dpi=60)
