import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,2,figsize=(16,9))
for a,(n,zl) in zip(ax,(("out_scan",(-17,-2)),("inn_scan",(72,86)))):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    m=(np.abs(ang-10)<35)&(c[:,2]>zl[0])&(c[:,2]<zl[1])&(r>40)
    sc=a.scatter(r[m],c[m,2],c=nn[m,2],s=1,cmap='coolwarm',vmin=-1,vmax=1); a.set_aspect('equal'); a.set_title(n); a.grid(True)
    a.set_xlim(40,72); plt.colorbar(sc,ax=a,shrink=.5)
plt.savefig("work/m1/ends_rz.png",dpi=70)
