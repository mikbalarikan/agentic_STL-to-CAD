import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HX,HZ=37.97,35.18; NB=720
Z=np.load("work/m3/polar_ref.npz"); ys=Z['ys']
def fill(a):
    a=a.copy(); x=np.arange(NB)
    for i in range(len(a)):
        g=~np.isnan(a[i])
        if g.sum()>10: a[i]=np.interp(x,x[g],a[i][g],period=NB)
    return a
def resid(P,key):
    R=fill(Z[key]); r=np.hypot(P[:,0]-HX,P[:,2]-HZ); th=np.degrees(np.arctan2(P[:,2]-HZ,P[:,0]-HX))
    b=((th+180)/360*NB).astype(int)%NB; yi=np.clip(np.round((np.minimum(P[:,1],287.0)-ys[0])/0.5).astype(int),0,len(ys)-1)
    return r-R[yi,b],th
fig,ax=plt.subplots(2,2,figsize=(22,12)); out={}
for j,(tag,sn) in enumerate((('out','out_scan'),('inn','inn_scan'))):
    v,f=lib.load(sn,1500000); c,nn,a=lib.tri_data(v,f); m=np.load(f"work/masks/{tag}_ext_hip.npy"); P=c[m]
    for i,key in enumerate(('env5',tag+'_cad')):
        d,th=resid(P,key); out[(tag,key)]=d
        s=ax[j,i].scatter(P[::10,1],th[::10],c=d[::10],s=2,cmap='bwr',vmin=-2,vmax=2); plt.colorbar(s,ax=ax[j,i]); ax[j,i].set_title(f"{tag} scan r - {key} (radial, mm)")
        print(tag,key,'radial resid p5/p50/p95',np.percentile(d,[5,50,95]).round(2))
        for y0,y1 in ((200,230),(230,250),(250,262),(262,272),(272,280),(280,288)):
            k=(P[:,1]>=y0)&(P[:,1]<y1); print('   Y%d-%d mean %.2f p5 %.2f p95 %.2f'%(y0,y1,d[k].mean(),np.percentile(d[k],5),np.percentile(d[k],95)))
plt.tight_layout(); plt.savefig("work/m3/resid_map.png",dpi=55)
