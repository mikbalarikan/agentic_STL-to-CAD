import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_o_fitband as B
d=np.load("work/m2/wall_A72.npz"); ys=d["ys"]; u=d["u"]; T=d["T"]; P=d["P"]
th=np.degrees(np.arctan2(P[...,2]-35,P[...,0]-40))
for lo,hi in ((60,80),(80,100),(100,120),(120,140),(140,160),(185,215),(215,240),(240,262)):
    m=(ys>=lo)&(ys<hi)
    for nm,sel in (("band",np.abs(th)<B.edge(ys)[:,None]-3),("outside-band",np.abs(th)>B.edge(ys)[:,None]+3)):
        x=T[m][sel[m]&np.isfinite(T[m])]
        if len(x)>20: print(lo,hi,nm,"n",len(x),"wall median %.2f p10 %.2f p90 %.2f"%(np.median(x),*np.percentile(x,[10,90])))
