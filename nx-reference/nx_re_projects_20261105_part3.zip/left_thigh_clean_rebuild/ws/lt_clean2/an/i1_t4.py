from i1_common import *
from i1_rib import *
S = load_all(); c,n,a,de=S['c'],S['n'],S['a'],S['de']
# gusset G_B7 / G_B6: x window around centre x, y 215..262; print upward-face z by (y, x)
for nm,x0 in (("G_B7",-22.0),("G_B6",97.95)):
    print(nm)
    for y0 in range(220,264,4):
        row=[]
        for dx in np.arange(-8,8.1,2.0):
            m=(abs(c[:,0]-(x0+dx))<1.0)&(c[:,1]>=y0)&(c[:,1]<y0+4)&(n[:,2]>0.7)&(de>3.0)
            row.append("%6.1f"%np.median(c[m,2]) if m.sum()>3 else "   .  ")
        print(" y%3d "%y0," ".join(row))
