from i1_core import *
from i1_rib import *
import ref5_design as DS

def design_top(kind, par, s, L):
    if kind == "rib": return np.full_like(s, par)
    z0, z1 = par
    return z0 + (z1 - z0) * s / L

def do_rib(fid, typ, p0, p1, t0, kind, dpar, top_guess, extra_ex=(), sa=0.0, sb=0.0, zrange=None, de_fit=3.0, de_mask=3.3, pad=0.9, p5extra=None, note=""):
    r, ct = fit_rib(S, p0, p1, t0, top_guess, de_min=de_fit, sa=sa, sb=sb, extra_ex=extra_ex, zrange=zrange)
    p, e, nu, L, cand, s, u = ct
    prof, ntop = top_profile(S, ct, r, t0, de_min=de_fit, extra_ex=extra_ex, zrange=zrange)
    idx = rib_mask(S, ct, r, t0, de_min=de_mask, pad=pad, extra_ex=extra_ex)
    one = ""
    if "t" not in r:
        # one wall only
        if "uR" in r: r["off"] = r["uR"][0] - t0 / 2; r["rot_deg"] = float(np.degrees(np.arctan(r["uR"][1]))); r["t"] = t0; one = "one wall found only (t assumed design)"
        elif "uL" in r: r["off"] = r["uL"][0] + t0 / 2; r["rot_deg"] = float(np.degrees(np.arctan(r["uL"][1]))); r["t"] = t0; one = "one wall found only (t assumed design)"
        else: r["off"] = 0.0; r["rot_deg"] = 0.0; r["t"] = t0; one = "no wall found"
        idx = rib_mask(S, ct, r, t0, de_min=de_mask, pad=pad, extra_ex=extra_ex)
    # centre line endpoints
    c0 = r["off"]; c1 = r["off"] + np.tan(np.radians(r["rot_deg"])) * L
    if "uR" in r and "uL" in r:
        c0 = (r["uR"][0] + r["uL"][0]) / 2; c1 = (r["uR"][0] + r["uR"][1] * L + r["uL"][0] + r["uL"][1] * L) / 2
    P0 = p + nu * c0; P1 = p + e * L + nu * c1
    # profile as polyline in (s, z)
    pl = []
    for (s0, s1, z0, z1) in prof:
        pl.append([s0, z0]); pl.append([s1, z1])
    # merge
    mp = []
    for q in pl:
        if mp and abs(mp[-1][0] - q[0]) < 1.5 and abs(mp[-1][1] - q[1]) < 0.5: continue
        mp.append(q)
    # abs coordinates: along-rib position as (x,y)
    abs_pl = [[round(float(p[0] + e[0] * q[0] + nu[0] * (c0 + (c1 - c0) * q[0] / L)), 2), round(float(p[1] + e[1] * q[0] + nu[1] * (c0 + (c1 - c0) * q[0] / L)), 2), round(float(q[1]), 2)] for q in mp]
    par = dict(p0=P0, p1=P1, t=r["t"], top_profile_xyz=abs_pl, wall_fit_rms=(r["uR"][2] if "uR" in r else None), rot_deg=r["rot_deg"])
    # diagnosis: compare with design
    diffs = []
    dist0 = c0; dist1 = c1
    if max(abs(dist0), abs(dist1)) > 0.3: diffs.append(f"centre line off {dist0:+.2f}/{dist1:+.2f} mm (p0/p1 normal) vs part 5")
    if abs(r["t"] - t0) > 0.25: diffs.append(f"thickness {r['t']:.2f} vs {t0}")
    if prof:
        err = []
        for (s0, s1, z0, z1) in prof:
            ss = np.array([s0, s1]); zd = design_top(kind, dpar, ss, L)
            err += list(np.array([z0, z1]) - zd)
        mx = max(err, key=abs)
        if abs(mx) > 0.4: diffs.append(f"top profile differs by up to {mx:+.1f} mm (scan {len(prof)} segment(s): " + "; ".join("s%.0f-%.0f z%.1f->%.1f" % q for q in prof) + ")")
    if one: diffs.append(one)
    if note: diffs.append(note)
    p5v = dict(p0=p0, p1=p1, t=t0, top=dpar)
    resid = r["uR"][2] if "uR" in r else None
    return add(fid, typ, par, f"rib walls: linear LS of vertical-wall tris (|nz|<.3) both sides; top: per-1mm median z + piecewise-linear fit ({len(prof)} seg); n_top_tris={ntop}", resid, idx, p5v,
               "; ".join(diffs) or "matches part 5 within 0.3 mm", "")

# ----------------------------------------------------------------- ribs
for nm, (a_, b_, top, t) in DS.OUT_RIBS.items():
    kw = {}
    if nm == "R_P2_WALL": kw = dict(sa=1.0, sb=1.0, extra_ex=((108.97, 194.32, 5.6),))
    do_rib("RIB_" + nm, "rib", a_, b_, t, "rib", top, top, **kw)
for nm, (a_, b_, z0, z1, t) in DS.OUT_GUSSETS.items():
    do_rib("GUS_" + nm, "gusset", a_, b_, t, "gus", (z0, z1), (z0 + z1) / 2)
for nm, (a_, bo, bi) in DS.ARMS.items():
    do_rib("ARM_" + nm, "arm", a_, bo, 3.0, "rib", 36.07, 36.07)
for nm, (a_, b_, w) in DS.FLANGES.items():
    do_rib("FLG_" + nm, "flange", a_, b_, w, "rib", 7.49, 7.49, note="part 5 flange top = boss/arm height Z_A (clipped to envelope)")
