from i1_core import *
def box(nm,x0,x1,y0,y1,dmin=1.0):
    m=(c[:,0]>x0)&(c[:,0]<x1)&(c[:,1]>y0)&(c[:,1]<y1)&(de>dmin)
    up=m&(n[:,2]>0.95)
    print(nm,"n",m.sum(),"area %.0f"%a[m].sum(),"d5>.5 area %.0f"%a[m&(d5>.5)].sum())
    pk=peaks(c[up,2],a[up],0.1,0.04,rng=(-40,90))
    print("   up planes:"," ".join("z%.2f(%.2f)"%p for p in pk[:6]))
box("M1 upper band B2",56,80,38,60); box("M2 radial rib B2",50,70,17,29); box("M3 rib B1",45,58,-38,-26)
box("M4 B1 ear",58,82,-52,-18); box("M5 pad right",86,102,94,130); box("M6 pocket blob",62,74,78,95)
box("M7 tabC area",-46,-30,248,262); box("M8 (18,94)",12,24,85,105)
