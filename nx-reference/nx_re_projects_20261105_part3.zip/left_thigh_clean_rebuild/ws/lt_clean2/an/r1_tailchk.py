import sys, os, numpy as np, trimesh
from shapely.geometry import LineString, Point
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
C0 = np.array([62.3, -51.3])
def chains(mesh, z):
    s = mesh.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1]); return [] if s is None else [s.vertices[e.points][:, :2] for e in s.entities]
for w, zs in (("out", (0, 10, 20, 30)), ("inn", (40, 50, 60))):
    v, f = lib.load(w + "_scan", 1500000); sm = trimesh.Trimesh(v, f, process=False)
    for tag, path in (("r0", f"nx/A_v2/{w}_A_r0.stl"), ("r1", f"nx/A_v2/{w}_A.stl")):
        cm = trimesh.load(path); row = []
        for z in zs:
            cc = [LineString(p) for p in chains(cm, z) if (np.linalg.norm(p - C0, axis=1) < 6).any()]
            sp = [q[np.linalg.norm(q - C0, axis=1) < 5] for q in chains(sm, z)]; sp = [q for q in sp if len(q)]
            if not cc or not sp: row.append((z, None)); continue
            sp = np.vstack(sp); dd = np.array([min(l.distance(Point(q)) for l in cc) for q in sp])
            row.append((z, round(float(np.percentile(dd, 90)), 2), round(float(dd.max()), 2)))
        print(w, tag, "scan->CAD section within 5 mm of the corner (z, p90, max):", row)
