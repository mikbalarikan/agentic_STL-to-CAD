"""M4 step 2c: per-station joint parameters from the profiles -> work/m4/stations.csv + perimeter plots."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
W4 = os.path.join(lib.W, "m4")
D = np.load(os.path.join(W4, "stations.npz"))
names = ["KNEE_ARC", "PX_WALL", "PX_HIP", "MX_WALL", "MX_HIP"]
T = D["KNEE_ARC__T"]
def col(ZA, z): return int(np.argmin(abs(ZA - z)))
rows = []
def med(x):
    x = x[np.isfinite(x)]
    return float(np.median(x)) if len(x) >= 2 else np.nan
for nm in names:
    s = D[nm + "__s"]; p = D[nm + "__p"]; n = D[nm + "__n"]
    Ho = D[nm + "__Ho"]; Hi = D[nm + "__Hi"]
    oin, oout = D[nm + "__oin"], D[nm + "__oout"]; ZO = D[nm + "__ZO"]
    iin, iout = D[nm + "__iin"], D[nm + "__iout"]; ZI = D[nm + "__ZI"]
    for i in range(len(s)):
        r = dict(chain=nm, s=float(s[i]), x=float(p[i, 0]), y=float(p[i, 1]))
        # outer: faces at z 34.3 ; inner: faces at z 36.6
        r["o_tin"] = float(oin[i, col(ZO, 34.3)]); r["o_tout"] = float(oout[i, col(ZO, 34.3)])
        r["i_tin"] = float(iin[i, col(ZI, 36.6)]); r["i_tout"] = float(iout[i, col(ZI, 36.6)])
        r["o_wall"] = r["o_tout"] - r["o_tin"]; r["i_wall"] = r["i_tout"] - r["i_tin"]
        r["step"] = float(iout[i, col(ZI, 35.8)] - oout[i, col(ZO, 34.3)])    # + = inner exterior face proud of the outer
        r["o_edge"] = float(oout[i, col(ZO, 34.6)] - oout[i, col(ZO, 34.0)])   # exterior corner drift towards rim
        r["i_edge"] = float(iout[i, col(ZI, 35.5)] - iout[i, col(ZI, 36.4)])
        to = r["o_tout"]; ti = r["i_tout"]
        # ---- outer profile
        if np.isfinite(to):
            win = (T > to - 4.8) & (T < to + 0.3)
            H = Ho[i]
            hi = win & (H > 35.5) & (H < 36.8)
            r["tongue"] = bool(hi.sum() >= 3)
            if r["tongue"]:
                tb = T[hi].max()
                r["o_tb"] = float(tb)
                r["tongue_top"] = med(H[(T > tb - 0.7) & (T < tb - 0.2)])
                r["shoulder"] = float(to - tb)
                r["rim"] = med(H[(T > tb + 0.3) & (T < to - 0.5)])
            else:
                r["rim"] = med(H[(T > to - 2.4) & (T < to - 0.45)])
        # ---- inner profile
        if np.isfinite(ti):
            win = (T > ti - 4.8) & (T < ti + 0.3)
            H = Hi[i]
            hi = win & (H > 35.8) & (H < 36.5)
            r["rebate"] = bool(hi.sum() >= 3)
            if r["rebate"]:
                tc = T[hi].max()
                r["i_tc"] = float(tc)
                r["rebate_floor"] = med(H[(T > tc - 0.7) & (T < tc - 0.2)])
                r["lip_w"] = float(ti - tc)
                r["lip"] = med(H[(T > tc + 0.3) & (T < ti - 0.5)])
            else:
                r["lip"] = med(H[(T > ti - 2.4) & (T < ti - 0.45)])
        rows.append(r)
import csv
keys = sorted({k for r in rows for k in r}, key=lambda k: ["chain", "s", "x", "y"].index(k) if k in ("chain", "s", "x", "y") else 99)
with open(os.path.join(W4, "stations.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); [w.writerow(r) for r in rows]
np.save(os.path.join(W4, "stations_rows.npy"), np.array(rows, dtype=object), allow_pickle=True)
print(len(rows), "stations")
