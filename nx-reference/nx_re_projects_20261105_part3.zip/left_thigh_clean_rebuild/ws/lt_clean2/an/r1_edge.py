"""Scan step edge theta_b(y) of the +X panel (both parts), fine y grid; saves work/r1/edge.npz"""
import sys, os, numpy as np, trimesh, open3d as o3d
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
AX, AZ = 37.97, 35.18
def sc(m):
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32))); return s
def cast(s, o, d):
    a = s.cast_rays(o3d.core.Tensor(np.hstack([o, d]).astype(np.float32))); return a["t_hit"].numpy(), a["primitive_normals"].numpy()
se = sc(trimesh.load("nx/base_v2/envelope.stl", process=False))
ys = np.arange(52.0, 263.01, 0.25); ths = np.arange(0.5, 50.0, 0.1)
R = {}
for w, sg in (("out", -1), ("inn", 1)):
    v, f = lib.load(w + "_scan", 1500000); ss = sc(trimesh.Trimesh(v, f, process=False))
    E = np.full(len(ys), np.nan); Rr = np.full(len(ys), np.nan)
    for i, y in enumerate(ys):
        T = np.radians(ths); dv = np.stack([np.cos(T), np.zeros_like(T), sg*np.sin(T)], 1)
        o = np.stack([np.full(len(T), AX), np.full(len(T), y), np.full(len(T), AZ)], 1) + 500*dv
        te, ne = cast(se, o, -dv); tm, _ = cast(ss, o, -dv)
        ne = ne/np.linalg.norm(ne, axis=1, keepdims=True); dn = (tm-te)*np.abs((ne*dv).sum(1))
        rec = dn > 0.55
        if rec[:20].sum() < 5: continue
        k0 = np.argmax(rec); nr = np.where(~rec[k0:])[0]
        if len(nr): E[i] = ths[k0+nr[0]]; Rr[i] = 500 - te[k0+nr[0]]
    R[w] = (E, Rr)
np.savez("work/r1/edge.npz", y=ys, out=R["out"][0], inn=R["inn"][0], rout=R["out"][1], rinn=R["inn"][1])
for w in ("out", "inn"):
    E = R[w][0]
    print(w, "edge theta at y:", " ".join(f"{y:.1f}:{e:.1f}" for y, e in zip(ys, E) if (y % 1 == 0 and (y < 60 or y > 252)) ))
