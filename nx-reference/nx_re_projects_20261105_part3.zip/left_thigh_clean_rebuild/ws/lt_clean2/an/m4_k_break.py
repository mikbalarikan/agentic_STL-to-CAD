import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
MK = os.path.join(lib.W, "masks")
for scan, tag, new, old in (("out_scan", "out", "FINout", "oldC"), ("inn_scan", "inn", "FINinn", "oldInnB")):
    v, f = lib.load(scan, 1500000); c, nn, a = lib.tri_data(v, f); A = a.sum()
    dn = np.load(os.path.join(lib.W, f"dev_{new}.npz"))["d1"]; do = np.load(os.path.join(lib.W, f"dev_{old}.npz"))["d1"]
    band = (c[:, 2] > 30) & (c[:, 2] < 42)
    lost = band & (dn >= .5) & (do < .5); gain = band & (dn < .5) & (do >= .5)
    print(scan, "lost %.3f%% gain %.3f%%" % (a[lost].sum() / A * 100, a[gain].sum() / A * 100))
    zb = [30, 33, 34.6, 35.4, 35.9, 36.5, 38, 42]
    print("  z-bin          lost%   gain%   | horizontal lost%  steep lost%")
    for z0, z1 in zip(zb[:-1], zb[1:]):
        m = (c[:, 2] >= z0) & (c[:, 2] < z1)
        h = np.abs(nn[:, 2]) > 0.9
        print("  %5.1f-%5.1f  %6.3f  %6.3f  | %6.3f  %6.3f" % (z0, z1, a[lost & m].sum() / A * 100, a[gain & m].sum() / A * 100, a[lost & m & h].sum() / A * 100, a[lost & m & ~h].sum() / A * 100))
