from i2_rows import *
import glob, json
from scipy import ndimage as ndi
rows = []
for f_ in sorted(glob.glob(os.path.join(ROWS, "*.json"))): rows += json.load(open(f_))
cov = np.zeros(N, bool)
for r in rows:
    if r["id"] in ("JOINT_BOSS_FACES","LIP_FACE"): continue
    cov[np.load(os.path.join(MASKS, f"inn_f_{r['id']}.npy"))] = True
x,y,z=c[:,0],c[:,1],c[:,2]
m=(n[:,2]<-0.97)&(z>36.5)&(z<79.7)&(d>=2.0)&~cov
print("down-facing flat faces (rib bottoms etc.) uncovered, area",a[m].sum())
s=2.0; x0,y0=-75,-75
im=np.zeros((int(380*s),int(200*s))); X=((x[m]-x0)*s).astype(int); Y=((y[m]-y0)*s).astype(int); np.add.at(im,(Y,X),a[m])
lab,nl=ndi.label(ndi.binary_dilation(im>0,iterations=2))
out=[]
for k in range(1,nl+1):
    sel=np.zeros(N,bool); sel[np.flatnonzero(m)[lab[Y,X]==k]]=True
    if a[sel].sum()<6: continue
    out.append((a[sel].sum(),sel))
out.sort(key=lambda t:-t[0])
for A,sel in out[:30]:
    cc=c[sel]; print(f"area {A:6.0f} mm2  x {cc[:,0].min():.0f}..{cc[:,0].max():.0f} y {cc[:,1].min():.0f}..{cc[:,1].max():.0f}  z med {np.median(cc[:,2]):.2f}  p5 p90 {p90(p5[sel]):.2f}")
