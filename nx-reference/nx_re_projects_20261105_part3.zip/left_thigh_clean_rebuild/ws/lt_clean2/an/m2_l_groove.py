import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
P=np.load("work/m2/ext_pts.npy")
fig,axs=plt.subplots(2,4,figsize=(28,12))
spots=[(150,(35,-25)),(150,(-8,78)),(150,(90,78)),(150,(-8,-7)),(250,(37,110)),(250,(10,106)),(220,(36,110)),(190,(10,95))]
for ax,(y,(cx,cz)) in zip(axs.ravel(),spots):
    q=P[(np.abs(P[:,1]-y)<=0.4)&(np.hypot(P[:,0]-cx,P[:,2]-cz)<10)]
    ax.plot(q[:,0],q[:,2],'k.',ms=4); ax.set_aspect('equal'); ax.set_title(f"Y={y} near {cx},{cz}"); ax.grid(True)
plt.tight_layout(); plt.savefig("work/m2/groove_zoom.png",dpi=45)
