import sys; sys.path.insert(0,'an')
import numpy as np, lib, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
# TAB_D foot sections: x slices through the tab / foot, y-z plane
fig,axs=plt.subplots(2,3,figsize=(18,10))
for r,(w,zr) in enumerate((("out",(-5,10)),("inn",(59,74)))):
    v,f=lib.load(w+"_scan",1500000)
    for k,xv in enumerate((-21.8,-21.2,-19.0)):
        S=lib.section(v,f,0,xv); ax=axs[r,k]
        for s in S: ax.plot(s[:,1],s[:,2],'k-',lw=0.8)
        ax.set_xlim(176,196); ax.set_ylim(*zr); ax.set_aspect('equal'); ax.grid(True); ax.set_title(f"{w} x={xv}")
plt.tight_layout(); plt.savefig("work/p5c/tabD_foot_sec.png",dpi=70)
