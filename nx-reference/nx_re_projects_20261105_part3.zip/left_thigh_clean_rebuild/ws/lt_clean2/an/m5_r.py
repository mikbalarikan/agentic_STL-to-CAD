import sys, os, numpy as np, json
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, trimesh, open3d as o3d, scipy.spatial as sp
env = trimesh.load(os.path.join(lib.W,"env_part5.stl"), process=False)
esc = o3d.t.geometry.RaycastingScene(); esc.add_triangles(o3d.core.Tensor(np.asarray(env.vertices,np.float32)), o3d.core.Tensor(np.asarray(env.faces,np.uint32)))
AN = [(54.5,28),(62,31),(70,35),(80,37.8),(94,39.7),(110,40.5),(126,40.2),(150,38.2),(178,34.8),(210,30.8),(230,28),(246,24.5),(254,21),(259,15)]
Y0,Y1=54.5,259.0
HIP=np.array([37.97,0,35.18])
def tbf(AN):
    ay=np.array([a for a,b in AN]); at=np.array([b for a,b in AN]); return lambda y: np.interp(y,ay,at)
def envhit(y,thdeg,sg):
    ang=np.radians(thdeg*sg); o=np.stack([np.full_like(y,HIP[0]),y,np.full_like(y,HIP[2])],1); d=np.stack([np.cos(ang),np.zeros_like(ang),np.sin(ang)],1)
    r=esc.cast_rays(o3d.core.Tensor(np.hstack([o,d]).astype(np.float32))); h=r["t_hit"].numpy()
    return o+d*h[:,None], d, h
def prep(key,scan):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    P=np.load(os.path.join(lib.W,"m5",f"{key}_p5pts.npz")); pts=P["pts"]
    loc=(pts[:,0]>25)&(pts[:,1]>40)&(pts[:,1]<275)
    pts=pts[loc]
    r=esc.compute_closest_points(o3d.core.Tensor(pts.astype(np.float32))); cp=r["points"].numpy(); depth=np.linalg.norm(cp-pts,axis=1)
    return dict(key=key,v=v,f=f,c=c,nn=nn,ar=ar,pts=pts,cp=cp,depth=depth)
def model(D,tthin,AN,sg,step=True):
    tb=tbf(AN); pts=D["pts"]; cp=D["cp"]; depth=D["depth"]
    th=np.degrees(np.arctan2(pts[:,2]-35.18,pts[:,0]-37.97))*sg
    mv=(pts[:,0]>40)&(pts[:,1]>Y0)&(pts[:,1]<Y1)&(th>0.3)&(th<tb(pts[:,1]))&(depth>2.6)&(depth<3.7)
    newp=pts.copy(); u=cp[mv]-pts[mv]; un=u/np.maximum(np.linalg.norm(u,axis=1,keepdims=True),1e-9); newp[mv]=cp[mv]-un*tthin
    extra=[]
    if step:
        ys=np.arange(Y0,Y1,0.1); p,d,h=envhit(ys,tb(ys),sg)
        for dd in np.arange(tthin,3.2,0.1): extra.append(p-d*dd)
        for yy in (Y0,Y1):
            ths=np.arange(0.5,float(tb(np.array([yy]))[0]),0.15); p,d,h=envhit(np.full(len(ths),yy),ths,sg)
            for dd in np.arange(tthin,3.2,0.1): extra.append(p-d*dd)
        extra=np.vstack(extra); extra=extra[np.isfinite(extra).all(1)]
        newp=np.vstack([newp,extra])
    return newp,mv
def evaluate(D,newp,sg,AN,old):
    c=D["c"]; ar=D["ar"]; w=ar/ar.sum(); key=D["key"]
    sel=(c[:,0]>20)&(c[:,1]>35)&(c[:,1]<280)
    ci=np.where(sel)[0]
    d0,_=sp.cKDTree(D["pts"]).query(c[ci],workers=-1); d1,_=sp.cKDTree(newp).query(c[ci],workers=-1)
    D0=np.full(len(c),9.0); D1=D0.copy(); D0[ci]=d0; D1[ci]=d1
    return D0,D1
if __name__=="__main__":
    out={}
    for key,scan,dn,tt,sg,oldn in (("out","out_scan","FINout",1.9,-1,"dev_oldC.npz"),("inn","inn_scan","FINinn",2.0,1,"dev_oldInnB.npz")):
        D=prep(key,scan); c=D["c"]; w=D["ar"]/D["ar"].sum()
        st=np.load(os.path.join(lib.W,f"dev_{dn}.npz"))["d1"]; old=np.load(os.path.join(lib.W,oldn))["d1"]
        band=np.zeros(len(c),bool); band[np.load(os.path.join(lib.W,"masks",f"{key}_band.npy"))]=1
        newp,mv=model(D,tt,AN,sg)
        D0,D1=evaluate(D,newp,sg,AN,old)
        # use stored d1 outside the local box for totals
        sel=(c[:,0]>20)&(c[:,1]>35)&(c[:,1]<280)
        d_new=np.where(sel,D1,st)
        np.save(os.path.join(lib.W,"m5",f"{key}_dnew_v1.npy"),d_new)
        pc=lambda m,d: w[m&(d<0.5)].sum()/w[m].sum()*100
        print(key,"band: old",round(pc(band,old),1),"p5",round(pc(band,st),1),"new",round(pc(band,d_new),1),"| total old",round(w[old<.5].sum()*100,1),"p5",round(w[st<.5].sum()*100,1),"new",round(w[d_new<.5].sum()*100,1),flush=True)
