from i1_common import *
from i1_fit import *
from i1_rib import BOSS_XY, PIN_XY
import sys
S=load_all(); c,n,a,de=S['c'],S['n'],S['a'],S['de']
def boss(nm,x,y,rmax=12):
    r=np.hypot(c[:,0]-x,c[:,1]-y); m=(r<rmax)&(de>2.5)
    print(nm,(x,y))
    wall=m&(abs(n[:,2])<0.25)
    pk=peaks(r[wall],a[wall],0.15,0.04,rng=(0,rmax))
    print("  wall radius peaks:",[(round(p,2),round(sh,2)) for p,sh in pk[:6]])
    up=m&(n[:,2]>0.95)
    pz=peaks(c[up,2],a[up],0.1,0.03,rng=(c[up,2].min(),c[up,2].max())) if up.sum() else []
    for z,sh in pz[:6]:
        k=up&(abs(c[:,2]-z)<0.15)
        print("   plane z %.2f share %.2f  r range %.1f-%.1f"%(z,sh,np.percentile(r[k],5),np.percentile(r[k],95)))
for k,(x,y) in BOSS_XY.items(): boss(k,x,y)
