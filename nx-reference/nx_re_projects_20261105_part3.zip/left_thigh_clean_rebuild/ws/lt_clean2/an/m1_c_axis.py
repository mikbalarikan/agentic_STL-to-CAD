import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
rows=[]
for n in ("out_scan","inn_scan"):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    radial=(c[:,0]*nn[:,0]+c[:,1]*nn[:,1])/np.maximum(r,1e-9)
    m=(r>66)&(r<70.5)&(radial>0.97)&(np.abs(ang-10)<35)&(c[:,2]>-11)&(c[:,2]<81)
    for z0 in range(-10,80,5):
        k=m&(c[:,2]>=z0)&(c[:,2]<z0+5)
        if k.sum()<100: continue
        x,y=c[k,0],c[k,1]
        s=least_squares(lambda p: np.hypot(x-p[0],y-p[1])-p[2],[0,0,68],loss="soft_l1",f_scale=.1)
        res=np.hypot(x-s.x[0],y-s.x[1])-s.x[2]
        rows.append((n,z0+2.5,s.x[0],s.x[1],s.x[2],np.abs(res).mean(),k.sum()))
        print(n,z0+2.5,s.x.round(3),round(np.abs(res).mean(),3),k.sum())
# axis line fit on all
R=np.array([[r[1],r[2],r[3]] for r in rows])
for i,nm in ((1,'x0'),(2,'y0')):
    p=np.polyfit(R[:,0],R[:,i],1); print(nm,'slope',p[0],'(deg',np.degrees(np.arctan(p[0])),') at z=0',p[1])
