import sys, numpy as np, trimesh, open3d as o3d
sys.path.insert(0,"an"); import lib
from v5e_occ import scene
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
a0=np.array([74.65,33.95]); a1=np.array([55.05,55.40]); d=(a1-a0)/np.linalg.norm(a1-a0); n=np.array([d[1],-d[0]])
if n[0]<0: n=-n
v,f=lib.load("out_scan",1500000); S=scene((v,f)); C=scene("nx/P5d/out_P5d_final.stl")
ss=np.arange(24,40.01,0.25); oo=np.arange(-2,12.01,0.25); SS,OO=np.meshgrid(ss,oo,indexing="ij")
xy=a0+SS[...,None]*d+OO[...,None]*n; N=SS.size
def top(sc,sgn):
    o=np.c_[xy.reshape(-1,2),np.full(N,60.0 if sgn>0 else -60.0)]
    r=np.c_[o,np.tile([0,0,-sgn],(N,1))].astype(np.float32)
    t=sc.cast_rays(o3d.core.Tensor(r))["t_hit"].numpy(); z=o[:,2]-sgn*t; z[~np.isfinite(t)]=np.nan; return z.reshape(SS.shape)
res={}
for nm,sgn in (("from above (first surface hit going down)",1),("from below (z-60 going up)",-1)):
    zs=top(S,sgn); zc=top(C,sgn); dz=zc-zs
    print(nm)
    for lab,m in (("CAD lower than scan by >1 (CAD-only slot / missing material)",dz<-1.0),("CAD higher than scan by >1",dz>1.0)):
        m=m&np.isfinite(dz)
        if not m.any(): print("  ",lab,": none"); continue
        a=m.sum()*0.0625
        # connected clusters
        from scipy import ndimage
        L,k=ndimage.label(m)
        for i in range(1,k+1):
            q=(L==i); ar=q.sum()*0.0625
            if ar<3: continue
            xyz=np.c_[xy[q],zc[q]]
            print("  %s: cluster area %.1f mm2, s %.1f..%.1f off %.1f..%.1f, depth max %.1f med %.1f, z %.1f..%.1f; frame x %.1f..%.1f y %.1f..%.1f"%(lab[:12],ar,SS[q].min(),SS[q].max(),OO[q].min(),OO[q].max(),np.abs(dz[q]).max(),np.median(np.abs(dz[q])),np.nanmin(zc[q]),np.nanmax(zc[q]),xy[q][:,0].min(),xy[q][:,0].max(),xy[q][:,1].min(),xy[q][:,1].max()))
    fig,ax=plt.subplots(1,3,figsize=(21,6))
    for a,Z,t in zip(ax,(zs,zc,dz),("scan z","CAD z","CAD-scan")):
        im=a.pcolormesh(SS,OO,Z,cmap="RdBu" if t=="CAD-scan" else "viridis",vmin=-6 if t=="CAD-scan" else None,vmax=6 if t=="CAD-scan" else None,shading="auto"); a.set_title(t+" "+nm[:9]); a.set_xlabel("s along arm"); a.set_ylabel("off"); plt.colorbar(im,ax=a); a.set_aspect("equal")
    fig.savefig(f"work/q7/trough_map_{'above' if sgn>0 else 'below'}.png",dpi=55)
