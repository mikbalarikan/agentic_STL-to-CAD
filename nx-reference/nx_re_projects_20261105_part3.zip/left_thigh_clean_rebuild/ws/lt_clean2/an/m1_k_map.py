import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
AX=(0.169,-0.100); Rp,zp,t=68.7673,36.8481,0.0275
fig,axs=plt.subplots(2,1,figsize=(22,13))
D={}
for a,(nm,zr) in zip(axs,(("out_scan",(-15,36)),("inn_scan",(34,85)))):
    v,f=lib.load(nm,1500000); c,nn,ar=lib.tri_data(v,f)
    x=c[:,0]-AX[0]; y=c[:,1]-AX[1]; r=np.hypot(x,y); ang=np.degrees(np.arctan2(x,-y))
    radial=(x*nn[:,0]+y*nn[:,1])/np.maximum(r,1e-9)
    dev=r-(Rp-np.abs(c[:,2]-zp)*t)
    m=(radial>0.6)&(r>58)&(c[:,2]>zr[0])&(c[:,2]<zr[1])&(np.abs(dev)<4)
    ab=np.arange(-180,181,2.0); zb=np.arange(zr[0],zr[1]+1,1.0)
    S=np.full((len(zb)-1,len(ab)-1),np.nan)
    ia=np.digitize(ang[m],ab)-1; iz=np.digitize(c[m,2],zb)-1; d=dev[m]
    from collections import defaultdict
    key=iz*len(ab)+ia
    o=np.argsort(key); ks=key[o]; ds=d[o]; u,st=np.unique(ks,return_index=True)
    for k,s,e in zip(u,st,list(st[1:])+[len(ks)]):
        if 0<=k//len(ab)<S.shape[0] and 0<=k%len(ab)<S.shape[1] and e-s>=2: S[k//len(ab),k%len(ab)]=np.median(ds[s:e])
    D[nm]=(ab,zb,S)
    im=a.pcolormesh(ab,zb,S,cmap='RdBu_r',vmin=-0.6,vmax=0.6,shading='flat'); a.set_title(f"{nm}: median dev r - cone (mm), axis ({AX})"); a.set_xlabel("angle (0=-Y, +90=+X, +-180=+Y)"); a.set_ylabel("z"); plt.colorbar(im,ax=a)
    a.set_xticks(range(-180,181,30)); a.grid(True,alpha=.3)
plt.tight_layout(); plt.savefig("work/m1/unrolled_dev_wide.png",dpi=60)
np.save("work/m1/_dev_out.npy",D["out_scan"][2]); np.save("work/m1/_dev_inn.npy",D["inn_scan"][2])
