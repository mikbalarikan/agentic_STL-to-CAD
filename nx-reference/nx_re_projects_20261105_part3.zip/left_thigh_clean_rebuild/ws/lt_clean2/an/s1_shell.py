"""Shell proxy: OCP MakeThickSolid 3.1 inward with the mouth face (plane Y=287.39) removed."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_geo import *
from OCP.BRepOffsetAPI import BRepOffsetAPI_MakeThickSolid
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Plane, GeomAbs_Intersection, GeomAbs_Arc
from OCP.BRepGProp import BRepGProp
from OCP.BRepOffset import BRepOffset_Skin
def faces(shape):
    ex = TopExp_Explorer(shape, TopAbs_FACE); out = []
    while ex.More(): out.append(TopoDS.Face_s(ex.Current())); ex.Next()
    return out
def mouth_face(shape, Y=287.39):
    best = None
    for f in faces(shape):
        a = BRepAdaptor_Surface(f)
        if a.GetType() == GeomAbs_Plane:
            pl = a.Plane(); n = pl.Axis().Direction(); p = pl.Location()
            if abs(abs(n.Y()) - 1) < 1e-6 and abs(p.Y() - Y) < 1e-3:
                g = GProp_GProps(); BRepGProp.SurfaceProperties_s(f, g)
                if best is None or g.Mass() > best[0]: best = (g.Mass(), f)
    return best[1] if best else None
def shell_test(env, t=3.1, join=GeomAbs_Arc, tol=1e-3):
    mf = mouth_face(env)
    if mf is None: return None, 'no mouth face'
    lst = TopTools_ListOfShape(); lst.Append(mf)
    mk = BRepOffsetAPI_MakeThickSolid()
    t0 = time.time()
    mk.MakeThickSolidByJoin(env, lst, -t, tol, BRepOffset_Skin, True, False, join)
    mk.Build()
    ok = mk.IsDone()
    if not ok: return None, 'not done'
    s = mk.Shape()
    return s, f'done valid={valid(s)} vol={volume(s):.0f} time={time.time()-t0:.1f}'
if __name__ == '__main__':
    from s1_build import build
    tag = sys.argv[1]; env, lo, body, dr = build(tag, verbose=False)
    for jn, nm in [(GeomAbs_Arc, "arc"), (GeomAbs_Intersection, "intersection")]:
        try:
            s, msg = shell_test(env, 3.1, jn)
            print(nm, msg)
            if s is not None:
                V, F = to_mesh(s, 0.1); print(' faces', len(faces(s)))
        except Exception as e: print(nm, 'EXC', e)
