import sys; sys.path.insert(0,'an')
import numpy as np, lib, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,1,figsize=(9,11))
for nm,col in (("out_scan","tab:blue"),("inn_scan","tab:green")):
    v,f=lib.load(nm,1500000); c,n,a=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    tx,ty=np.cos(np.radians(ang)),np.sin(np.radians(ang)); tang=n[:,0]*tx+n[:,1]*ty
    m=(ang>49.5)&(ang<51.5)&(tang<-0.85)&(c[:,1]<-38)
    ax.plot(r[m],c[m,2],'.',ms=2,color=col)
    print(nm,m.sum(),"rho %.1f..%.1f z %.1f..%.1f area %.0f"%(r[m].min(),r[m].max(),c[m,2].min(),c[m,2].max(),a[m].sum()))
ax.set_aspect('equal'); ax.grid(); ax.set_title("free-edge end face tris (rho about origin, z)")
plt.savefig("work/t5/endface.png",dpi=65)
