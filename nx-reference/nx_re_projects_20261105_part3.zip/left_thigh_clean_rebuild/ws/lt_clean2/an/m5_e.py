import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,axs=plt.subplots(2,3,figsize=(18,11))
for r,(scan,key) in enumerate((("out_scan","out"),("inn_scan","inn"))):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    band=np.load(os.path.join(lib.W,"masks",f"{key}_band.npy")); z=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz")); dot=z["dot"][band]; cb=c[band]
    sub=slice(None,None,3)
    for fac,col in ((dot>0,'g'),(dot<=0,'m')):
        axs[r,0].scatter(cb[fac][::3,0],cb[fac][::3,2],s=1,c=col)
        axs[r,1].scatter(cb[fac][::3,1],cb[fac][::3,2],s=1,c=col)
        axs[r,2].scatter(cb[fac][::3,0],cb[fac][::3,1],s=1,c=col)
    axs[r,0].set_title(f"{key} X-Z (green ext-facing, magenta int-facing)");axs[r,1].set_title("Y-Z");axs[r,2].set_title("X-Y")
    print(key,"ext-facing area share", (ar[band][dot>0].sum()/ar[band].sum()), "int", ar[band][dot<=0].sum()/ar[band].sum())
    for nm,fac in (("ext",dot>0),("int",dot<=0)):
        b=cb[fac]; print(" ",nm,"n",fac.sum(),"x pct",np.round(np.percentile(b[:,0],[5,50,95]),1),"z pct",np.round(np.percentile(b[:,2],[5,50,95]),1),"y pct",np.round(np.percentile(b[:,1],[5,50,95]),1))
plt.savefig(os.path.join(lib.W,"m5","band_scatter.png"),dpi=65)
