import sys
from s1_shell import *
from s1_build import build, cone_solid
from s1_geo import *
d=np.load('work/s1/loft_K1.npz'); st=d['st']; P=d['P']
lo=loft(P,st,solid=True)
# mouth-like closing face = last cap (Y=262) : find planar face at y=262
def capface(shape,Y):
    for f in faces(shape):
        a=BRepAdaptor_Surface(f)
        if a.GetType()==GeomAbs_Plane and abs(a.Plane().Location().Y()-Y)<1e-3: return f
cf=capface(lo,262.0)
for t in [3.1]:
    for jn,nm in [(GeomAbs_Arc,'arc'),(GeomAbs_Intersection,'int')]:
        lst=TopTools_ListOfShape(); lst.Append(cf); mk=BRepOffsetAPI_MakeThickSolid(); t0=time.time()
        mk.MakeThickSolidByJoin(lo,lst,-t,1e-3,BRepOffset_Skin,True,False,jn); mk.Build()
        s=mk.Shape() if mk.IsDone() else None
        print('loft K1',nm,t,'done',mk.IsDone(),'valid',valid(s) if s else None,'vol',round(volume(s)) if s else None,'orig',round(volume(lo)),round(time.time()-t0,1))
# drum alone
dr=drum(); 
for f in faces(dr):
    a=BRepAdaptor_Surface(f)
    if a.GetType()==GeomAbs_Plane and abs(a.Plane().Location().Z()-(-13.9))<1e-3: cf=f
lst=TopTools_ListOfShape(); lst.Append(cf); mk=BRepOffsetAPI_MakeThickSolid(); mk.MakeThickSolidByJoin(dr,lst,-3.1,1e-3,BRepOffset_Skin,True,False,GeomAbs_Arc); mk.Build()
s=mk.Shape(); print('drum',valid(s),round(volume(s)),round(volume(dr)))
