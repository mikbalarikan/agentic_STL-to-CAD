from i1_common import *
from i1_fit import *
S=load_all(); c,n,a,de=S['c'],S['n'],S['a'],S['de']
r=np.hypot(c[:,0],c[:,1]); th=np.degrees(np.arctan2(c[:,1],c[:,0]))
# restrict to angular sector away from features: theta 200..330 (lower half, y<0)
sec=(th>-150)&(th<-30)
print("upward (nz>0.95) planes by r bin")
for sign,lab in ((1,"up"),(-1,"down")):
    print(lab)
    for r0 in range(30,72,2):
        m=sec&(r>=r0)&(r<r0+2)&(sign*n[:,2]>0.95)
        if m.sum()<30: continue
        pk=peaks(c[m,2],a[m],0.1,0.08,rng=(-40,90))
        print("  r %d-%d: "%(r0,r0+2)," ".join("z%.2f(%.2f)"%p for p in pk[:4]))
print("radial (|nz|<0.2) walls: r vs z")
m=sec&(abs(n[:,2])<0.25)&(r>30)&(r<80)
for z0 in np.arange(-20,45,2.0):
    k=m&(c[:,2]>=z0)&(c[:,2]<z0+2)
    if k.sum()<20: continue
    pk=peaks(r[k],a[k],0.15,0.1,rng=(30,80))
    print("  z %.0f..%.0f: "%(z0,z0+2)," ".join("r%.2f(%.2f)"%p for p in pk[:4]))
