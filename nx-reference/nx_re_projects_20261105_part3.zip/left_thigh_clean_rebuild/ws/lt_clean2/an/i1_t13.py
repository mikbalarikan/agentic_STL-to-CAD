from i1_core import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import stages_consts as K
fig,axs=plt.subplots(2,2,figsize=(18,12))
for row,(side,xm) in enumerate((("MX",(c[:,0]<-15)),("PX",(c[:,0]>85)))):
    m=xm&(c[:,1]>120)&(c[:,1]<270)
    idx=np.where(m)[0]
    for col,(nm,dd) in enumerate((("d5",d5),("d0",d0))):
        ax=axs[row,col]; sc=ax.scatter(c[idx,1],c[idx,2],c=dd[idx],s=1.5,cmap='jet',vmin=0,vmax=2,linewidths=0)
        segs=K.O2_MX if side=="MX" else K.O3_PX
        pts=[(s_[0][1],s_[0][2]) for s_ in segs]; pts.append(pts[0])
        ax.plot([p[0] for p in pts],[p[1] for p in pts],'k-',lw=1)
        ax.set_aspect('equal'); ax.set_title(side+" "+nm); ax.grid(True,alpha=.3)
fig.savefig(os.path.join(I1,"side_open.png"),dpi=60,bbox_inches='tight')
