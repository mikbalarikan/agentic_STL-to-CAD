"""Tongue / rebate fit in the assembly frame: out_A.stl vs inn_A.stl. Interference volume (manifold3d) and gaps."""
import sys, json, numpy as np, trimesh, open3d as o3d
A = r"nx/A_v2/"
mo = trimesh.load(A + "out_A.stl", process=True); mi = trimesh.load(A + "inn_A.stl", process=True)
print("watertight", mo.is_watertight, mi.is_watertight, "vol", mo.volume, mi.volume)
out = {"watertight": [bool(mo.is_watertight), bool(mi.is_watertight)]}
try:
    inter = trimesh.boolean.intersection([mo, mi], engine="manifold")
    iv = float(inter.volume) if len(inter.faces) else 0.0
except Exception as e:
    iv = None; print("boolean failed", e)
print("interference volume mm3:", iv); out["interference_mm3"] = iv
def sc(m):
    s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32)))
    return s
so, si = sc(mo), sc(mi)
# tongue top faces: out triangles with normal +Z at z 36.05 ; rebate floor: inn triangles normal -Z at z 36.08
def flat(m, z, nz, tol=0.02):
    t = m.triangles_center; n = m.face_normals
    k = (np.abs(t[:, 2] - z) < tol) & (n[:, 2] * nz > 0.999)
    return k, m.area_faces[k].sum()
for nm, m, z, nz in (("out tongue top", mo, 36.05, 1), ("inn rebate floor", mi, 36.08, -1), ("out rim", mo, 34.8, 1), ("inn lip", mi, 35.31, -1)):
    k, a = flat(m, z, nz); print(f"{nm}: z {z} area {a:.1f} mm2 ({k.sum()} tris)"); out[nm] = {"area": float(a), "tris": int(k.sum())}
# vertical gap: from out tongue-top sample points up to inn
k, a = flat(mo, 36.05, 1)
P, _ = trimesh.sample.sample_surface(mo.submesh([np.where(k)[0]], append=True), 20000, seed=1)
rays = np.hstack([P + [0, 0, 1e-3], np.tile([0, 0, 1.0], (len(P), 1))]).astype(np.float32)
t = si.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
g = t[np.isfinite(t)]
if len(g): print("tongue top -> inn above: gap min %.3f p50 %.3f p95 %.3f max %.3f  (n %d of %d)" % (g.min(), np.median(g), np.percentile(g, 95), g.max(), len(g), len(P)))
out["z_gap"] = {"min": float(g.min()), "p50": float(np.median(g)), "max": float(g.max()), "n": int(len(g)), "of": int(len(P))} if len(g) else None
# side clearance: tongue vertical side faces (z 35.2..35.9) sample -> distance to inn surface
tc = mo.triangles_center; nv = mo.face_normals
ks = (tc[:, 2] > 35.0) & (tc[:, 2] < 35.95) & (np.abs(nv[:, 2]) < 0.05)
if ks.any():
    Q, _ = trimesh.sample.sample_surface(mo.submesh([np.where(ks)[0]], append=True), 40000, seed=2)
    Q = Q[(Q[:, 2] > 35.4) & (Q[:, 2] < 35.9)]
    d = si.compute_distance(o3d.core.Tensor(Q.astype(np.float32))).numpy()
    print("tongue side faces z35.4..35.9 -> inn surface: min %.3f p5 %.3f p50 %.3f p95 %.3f (n %d)" % (d.min(), np.percentile(d, 5), np.median(d), np.percentile(d, 95), len(d)))
    out["side_clear"] = {"min": float(d.min()), "p5": float(np.percentile(d, 5)), "p50": float(np.median(d)), "p95": float(np.percentile(d, 95)), "n": int(len(d))}
# overall min distance of out to inn near the joint (|z-35.4|<2)
S, _ = trimesh.sample.sample_surface(mo, 400000, seed=3); S = S[np.abs(S[:, 2] - 35.4) < 2.0]
d = si.compute_distance(o3d.core.Tensor(S.astype(np.float32))).numpy()
print("out joint region -> inn: min %.3f  p1 %.3f" % (d.min(), np.percentile(d, 1))); out["min_dist_out_inn"] = float(d.min())
json.dump(out, open(A + "fit_check.json", "w"), indent=1)
