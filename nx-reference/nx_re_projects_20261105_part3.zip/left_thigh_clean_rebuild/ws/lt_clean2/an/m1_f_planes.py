import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,2,figsize=(18,9))
for a,(n,sgn) in zip(ax,(("out_scan",-1),("inn_scan",1))):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f)
    m=(sgn*nn[:,2]>0.95)
    # histogram z of such triangles weighted by area
    h,e=np.histogram(c[m,2],bins=np.arange(-20,95,0.2),weights=ar[m])
    top=np.argsort(h)[::-1][:6]; print(n,[(round(e[i],1),round(h[i])) for i in top])
    zz=e[top[0]]+0.1
    k=m&(np.abs(c[:,2]-zz)<0.4)
    a.scatter(c[k,0],c[k,1],s=1,c=c[k,2],cmap='viridis'); a.set_aspect('equal'); a.grid(True); a.set_title(f"{n} plane z~{zz:.1f}")
    print(' z pct',np.percentile(c[k,2],[5,50,95]).round(3), 'y max',c[k,1].max())
plt.savefig("work/m1/planes_xy.png",dpi=60)
