import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,axs=plt.subplots(2,2,figsize=(18,12))
for r,(scan,key) in enumerate((("out_scan","out"),("inn_scan","inn"))):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    t=np.load(os.path.join(lib.W,"m5",f"{key}_thick.npy")); dot=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["dot"]
    th=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))
    m=(dot<0)&(t>0)&(t<8)&(c[:,0]>40)
    for ax,(lo,hi) in zip(axs[r],((0,4.5),(1.6,2.2))):
        mm=m&(t>=lo)&(t<=hi)
        sc=ax.scatter(c[mm,1],th[mm],s=1,c=t[mm],cmap='jet',vmin=1.5,vmax=3.5)
        ax.set_title(f"{key}: y vs theta(about hip axis), int-facing x>40, thickness {lo}-{hi}"); ax.grid(alpha=.3)
    plt.colorbar(sc,ax=axs[r,1])
plt.savefig(os.path.join(lib.W,"m5","thin_map.png"),dpi=60)
