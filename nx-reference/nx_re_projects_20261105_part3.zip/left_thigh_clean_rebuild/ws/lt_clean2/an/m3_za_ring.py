import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
HX,HZ=37.97,35.18
res={}
def plane_y(c,nn,a,y0,sel,w=0.2):
    m=sel&(abs(nn[:,1])>0.985)&(abs(c[:,1]-y0)<w)
    y=c[m,1]; ww=a[m]; mu=np.average(y,weights=ww); sd=np.sqrt(np.average((y-mu)**2,weights=ww))
    # refine
    m2=sel&(abs(nn[:,1])>0.985)&(abs(c[:,1]-mu)<0.12); y=c[m2,1]; ww=a[m2]
    mu=np.average(y,weights=ww); sd=np.sqrt(np.average((y-mu)**2,weights=ww))
    return mu,sd,int(m2.sum()),float(ww.sum()),np.where(m2)[0]
for tag,sn,cn,zs in (('out','out_scan','out_cad',lambda z:z<34.5),('inn','inn_scan','inn_cad',lambda z:z>35.9)):
    v,f=lib.load(sn,1500000); c,nn,a=lib.tri_data(v,f)
    vo,fo=lib.load(cn); co,no,ao=lib.tri_data(vo,fo)
    sel=zs(c[:,2]); selo=zs(co[:,2])
    print('==',tag)
    R={}
    for y0 in (266.55,269.5,271.4,272.4,272.8,276.9,281.0,287.4):
        try:
            mu,sd,n,ar,idx=plane_y(c,nn,a,y0,sel); muo,sdo,no_,aro,_=plane_y(co,no,ao,y0,selo)
            print('  plane Y~%.2f: scan Y=%.3f sd %.3f n=%d area %.0f | old Y=%.3f'%(y0,mu,sd,n,ar,muo))
            R['%.2f'%y0]=dict(scan_Y=round(mu,3),sd=round(sd,3),n=n,area=round(ar),old_Y=round(muo,3))
        except Exception as e: print('  plane',y0,'fail',e)
    res[tag]=R
# ring radii: outer scan, triangles with normal radial, Y in 267-276.5 and in 277-286.5
v,f=lib.load('out_scan',1500000); c,nn,a=lib.tri_data(v,f)
r=np.hypot(c[:,0]-HX,c[:,2]-HZ); rd=np.stack([(c[:,0]-HX)/r,0*r,(c[:,2]-HZ)/r],1); nr=(nn*rd).sum(1)
for lo,hi,lab in ((267,276.5,'plate band'),(277.5,286.5,'mouth tube'),(281.5,286.5,'tube2')):
    m=(c[:,1]>lo)&(c[:,1]<hi)&(abs(nn[:,1])<0.2)&(abs(nr)>0.95)&(r<100)
    h,e=np.histogram(r[m],bins=np.arange(40,80,0.1),weights=a[m])
    pk=[(round(e[i]+0.05,2),int(h[i]),'out' if True else '') for i in range(1,len(h)-1) if h[i]>30 and h[i]>=h[i-1] and h[i]>=h[i+1]]
    print(lab,'radial cylinder surfaces r(area,sign by nr):',pk)
    # separate by sign of nr
    for sg in (+1,-1):
        mm=m&(np.sign(nr)==sg)
        h,e=np.histogram(r[mm],bins=np.arange(40,80,0.1),weights=a[mm])
        pk=[(round(e[i]+0.05,2),int(h[i])) for i in range(1,len(h)-1) if h[i]>30 and h[i]>=h[i-1] and h[i]>=h[i+1]]
        print('   nr sign',sg,pk)
json.dump(res,open('work/m3/planes.json','w'),indent=1)
