import sys, numpy as np, trimesh, open3d as o3d
sys.path.insert(0,"an"); import lib
from v5e_occ import scene, occ
OUT=open("work/q7/step.txt","w")
def P(*a):
    s=" ".join(str(x) for x in a); print(s); OUT.write(s+"\n")
for w,zb in (("out",[(-1,5),(5,11),(11,17),(17,25),(25,33)]),("inn",[(66,84),(60,66),(54,60),(46,54),(38,46)])):
    v,f=lib.load({"out":"out_scan","inn":"inn_scan"}[w],1500000); c,n,a=lib.tri_data(v,f)
    dd=np.load(f"work/dev_q7{w}_{w}.npz"); d1=dd["d1"]; de=dd["de"]
    C=scene(f"nx/P5d/{w}_P5d_final.stl")
    m0=(de<0.8)&(c[:,0]>45)&(c[:,1]<-20)&(c[:,1]>-55)
    ins=occ(C,c[m0]); sd=np.zeros(len(c)); sd[m0]=np.where(ins,-d1[m0],d1[m0])   # negative = scan inside CAD = CAD proud
    P(f"== {w}: signed scan->CAD (neg = CAD proud), median per y band 3 mm, x>45, de<0.8")
    for lo,hi in zb:
        s=f"  z{lo}..{hi}: "
        for y0 in range(-52,-22,3):
            q=m0&(c[:,1]>=y0)&(c[:,1]<y0+3)&(c[:,2]>=lo)&(c[:,2]<hi)
            s+=f"y{y0}:{np.median(sd[q]):+.2f} " if q.sum()>8 else f"y{y0}:  -   "
        P(s)
    q=m0&(c[:,1]<-41)&(c[:,1]>-52); 
    for thr in (0.3,0.4): P(f"  wedge skin y<-41: area CAD proud >{thr}: {a[q&(sd<-thr)].sum():.0f} mm2 of {a[q].sum():.0f}")
