"""Cell data (Y 2mm x theta 2deg about (40,35)) of the exterior for the tensor fit. Knee: no drum footprint, no top boss.
Columns: y,x,z,area,flag(0 normal,1 band core shifted)  -> work/s1/cells.npy"""
from s1_lib import *
CX0,CZ0=40.0,35.0
d=np.load(os.path.join(S1,'ext_all.npz')); P=d['P']; A=d['a']
x,y,z=P.T
def drum_R(z): return 68.8588-np.tan(np.radians(1.6))*np.abs(np.clip(z,-13.9,83.6)-36.07)
R_out=70.5
foot=(np.hypot(x,y)<drum_R(z)+0.8)&(z>-14.7)&(z<84.4)&(y<75)
bad=(z>84.3)&(y<66)        # top boss ring etc
rr=np.hypot(x,y)
plane=((np.abs(z-83.6)<0.2)|(np.abs(z+13.9)<0.2))&(rr>66.0)&(rr<R_out)&(y<75)
ok=(~foot|plane)&~bad&(y>-60)&(y<300)
x,y,z,A=x[ok],y[ok],z[ok],A[ok]
th=np.arctan2(z-CZ0,x-CX0)
dy,dth=2.0,2.0
iy=np.floor((y+60)/dy).astype(int); it=np.floor((th+np.pi)/np.radians(dth)).astype(int)
key=iy*1000+it; o=np.argsort(key); key=key[o]
X=np.c_[y,x,z,A][o]
u,st,cnt=np.unique(key,return_index=True,return_counts=True)
out=[]
for s,c in zip(st,cnt):
    if c<3: continue
    q=X[s:s+c]; out.append((np.median(q[:,0]),np.median(q[:,1]),np.median(q[:,2]),q[:,3].sum()))
D=np.array(out); print(D.shape)
np.save(os.path.join(S1,'cells_raw.npy'),D)
