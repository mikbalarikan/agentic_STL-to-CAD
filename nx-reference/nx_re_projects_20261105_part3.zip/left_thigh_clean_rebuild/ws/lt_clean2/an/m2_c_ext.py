"""Exterior skin: a triangle is exterior if (a) a ray along its normal and (b) a ray radially outward (from axis X40,Z35 parallel to Y)
both escape the union of both scans. Open3D RaycastingScene (embree). Writes work/m2/ext_{out,inn}.npy (bool per tri)."""
import sys,os,time
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
import open3d as o3d
CX,CZ=40.0,35.0
S={n:lib.load(n,1500000) for n in ("out_scan","inn_scan")}
V=np.vstack([S[n][0] for n in S]); F=np.vstack([S["out_scan"][1], S["inn_scan"][1]+len(S["out_scan"][0])])
sc=o3d.t.geometry.RaycastingScene()
sc.add_triangles(o3d.core.Tensor(V.astype(np.float32)),o3d.core.Tensor(F.astype(np.uint32)))
def escapes(p,d,off=0.08):
    o=(p+off*d).astype(np.float32); r=np.hstack([o,d.astype(np.float32)])
    out=np.zeros(len(p),bool)
    for i in range(0,len(p),500000):
        t=sc.cast_rays(o3d.core.Tensor(r[i:i+500000]))["t_hit"].numpy()
        out[i:i+500000]=np.isinf(t)
    return out
for n,(v,f) in S.items():
    t0=time.time()
    c,nn,ar=lib.tri_data(v,f)
    e1=escapes(c,nn)
    rv=np.c_[c[:,0]-CX,np.zeros(len(c)),c[:,2]-CZ]; rv/=np.maximum(np.linalg.norm(rv,axis=1),1e-9)[:,None]
    e2=escapes(c,rv)
    ex=e1&e2
    np.save(f"work/m2/ext_{n[:3]}.npy",ex); np.save(f"work/m2/ext_n_{n[:3]}.npy",e1); np.save(f"work/m2/ext_r_{n[:3]}.npy",e2)
    print(n,"normal-escape",e1.mean(),"radial-escape",e2.mean(),"both",ex.mean(),time.time()-t0)
