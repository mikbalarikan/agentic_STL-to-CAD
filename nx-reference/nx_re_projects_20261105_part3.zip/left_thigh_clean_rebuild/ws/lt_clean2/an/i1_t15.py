from i1_core import *
r=np.hypot(c[:,0],c[:,1]); th=np.degrees(np.arctan2(c[:,1],c[:,0]))%360
for z0,lab in ((7.5,"z7.5"),(4.95,"z4.95"),(34.75,"z34.75"),(0.1,"z0.1"),(-4.15,"z-4.15")):
    m=(abs(c[:,2]-z0)<0.12)&(n[:,2]>0.95)&(r>46)&(r<70)
    h,_=np.histogram(th[m],bins=36,range=(0,360),weights=a[m])
    print(lab,"area by 10deg:"," ".join("%d"%x for x in h))
    if lab=="z7.5":
        sel=m&(th>100)&(th<300); print("  angle range",np.percentile(th[sel],[0.5,99.5]),"r range",np.percentile(r[sel],[1,99]))
