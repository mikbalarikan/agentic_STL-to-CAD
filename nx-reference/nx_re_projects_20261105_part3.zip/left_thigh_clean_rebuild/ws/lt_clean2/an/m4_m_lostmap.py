import sys, os, pickle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
W4 = os.path.join(lib.W, "m4"); MK = os.path.join(lib.W, "masks")
CL = pickle.load(open(os.path.join(W4, "clusters.pkl"), "rb"))
fig, axs = plt.subplots(1, 2, figsize=(20, 22))
for ax, (scan, tag, new, old) in zip(axs, (("out_scan", "out", "FINout", "oldC"), ("inn_scan", "inn", "FINinn", "oldInnB"))):
    v, f = lib.load(scan, 1500000); c, nn, a = lib.tri_data(v, f)
    dn = np.load(os.path.join(lib.W, f"dev_{new}.npz"))["d1"]; do = np.load(os.path.join(lib.W, f"dev_{old}.npz"))["d1"]
    band = (c[:, 2] > 30) & (c[:, 2] < 42)
    lost = band & (dn >= .5) & (do < .5); gain = band & (dn < .5) & (do >= .5)
    ax.scatter(c[band, 0][::15], c[band, 1][::15], s=0.3, c="0.85")
    z = c[:, 2]
    for lo, hi, col, lab in ((30, 34.6, "tab:blue", "z30-34.6 (plain wall)"), (34.6, 36.5, "tab:red", "z34.6-36.5 (joint features)"), (36.5, 42, "tab:green", "z36.5-42 (upper wall)")):
        m = lost & (z >= lo) & (z < hi); ax.scatter(c[m, 0], c[m, 1], s=1.5, c=col, label="lost " + lab)
    ax.scatter(c[gain, 0], c[gain, 1], s=0.8, c="gold", label="gained (p5 ok, old bad)")
    for r in CL[tag][:14]:
        ax.annotate("#%d" % r["k"], (r["cx"], r["cy"]), fontsize=11, color="k", weight="bold")
    ax.set_aspect("equal"); ax.grid(lw=0.3); ax.legend(loc="lower left", markerscale=6); ax.set_title(f"{scan}: band z30-42 triangles: old ok -> part 5 bad (>0.5)")
fig.tight_layout(); fig.savefig(os.path.join(W4, "lost_map.png"), dpi=45)
