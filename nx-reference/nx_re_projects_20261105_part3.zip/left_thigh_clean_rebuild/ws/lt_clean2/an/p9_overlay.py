﻿"""P9 overlay images for the Deviation_Check folder: CAD (grey) with the scan (orange, see-through) in the same
frame, and plane sections of both. CAD = delivered STL, scan = lib scans (part frame)."""
import sys, numpy as np, trimesh, pyvista as pv
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
sys.path.insert(0, "an"); import lib
pv.OFF_SCREEN = True
O = "work/p9/"; D = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 7 - Clean Rebuild v2\deliver\CAD\\"
NM = {"out": "LT-OUT-001_Left_Thigh_Outer", "inn": "LT-INN-001_Left_Thigh_Inner"}
def cam(p, c0, d, up, par):
    d = np.array(d, float); d /= np.linalg.norm(d); p.camera.position = tuple(c0 + d * 1000)
    p.camera.focal_point = tuple(c0); p.camera.up = up; p.camera.parallel_projection = True; p.camera.parallel_scale = par
for w in ("out", "inn"):
    v, f = lib.load(w + "_scan", 1500000)
    M = trimesh.load(D + NM[w] + ".stl", process=True)
    cad = pv.wrap(M); sc = pv.PolyData(v, np.c_[np.full(len(f), 3), f].ravel())
    c0 = np.array(cad.center); o = 1 if w == "out" else -1
    views = {"side_PX": ((1, 0.15, 0.1), (0, 0, 1)), "side_MX": ((-1, 0.15, 0.1), (0, 0, 1)),
             "inside": ((0.05, 0.1, o), (0, 1, 0)), "outside": ((0.0, -0.2, -o), (0, 1, 0)),
             "inside_iso": ((0.4, -0.5, o), (0, 1, 0))}
    for vn, (d, up) in views.items():
        p = pv.Plotter(off_screen=True, window_size=(1600, 1000)); p.set_background("white")
        p.add_mesh(cad, color="#b8c4cf", smooth_shading=False, specular=0.2, ambient=0.25, label="NX CAD")
        p.add_mesh(sc, color="#ff7a1a", opacity=0.45, smooth_shading=False, ambient=0.3, label="Scan STL")
        p.add_legend(bcolor="white", size=(0.16, 0.09), loc="upper right")
        cam(p, c0, d, up, 190); p.add_text(f"{NM[w][:10]}  NX CAD (grey) + scan STL (orange, see-through)  view {vn}", font_size=10)
        p.screenshot(f"{O}overlay_{w}_{vn}.png"); p.close()
    # sections: Y = const (across the body) and Z = const (through the wall)
    cv, cf = np.asarray(M.vertices), np.asarray(M.faces)
    cuts = [(1, y) for y in (-20, 40, 100, 160, 220, 270)] + [(2, 10.0 if w == "out" else 60.0)]
    fig, ax = plt.subplots(2, 4, figsize=(22, 11)); ax = ax.ravel()
    for k, (a, val) in enumerate(cuts):
        A = ax[k]; i, j = (0, 2) if a == 1 else (0, 1)
        for vv, ff, col, lw, lab in ((v, f, "#ff7a1a", 2.6, "scan STL"), (cv, cf, "#1f3a93", 0.9, "NX CAD")):
            s = lib.section(vv, ff, a, val)
            if len(s): A.add_collection(LineCollection(s[:, :, [i, j]], colors=col, linewidths=lw, label=lab))
        A.autoscale(); A.set_aspect("equal"); A.margins(0.08); A.grid(alpha=0.3)
        A.set_title(f"{'Y' if a == 1 else 'Z'} = {val:g} mm"); A.set_xlabel("X"); A.set_ylabel("Z" if a == 1 else "Y")
        if k == 0: A.legend(loc="best")
    ax[-1].axis("off")
    ax[-1].text(0.02, 0.6, f"{NM[w]}\nsections of the delivered CAD (blue, thin)\nover the scan (orange, thick)\n"
                "same frame: origin on the knee axis,\n+Z towards the inner shell, +Y towards the hip", fontsize=13, va="top")
    fig.tight_layout(); fig.savefig(f"{O}sections_{w}.png", dpi=110); plt.close(fig)
    print(w, "done")
