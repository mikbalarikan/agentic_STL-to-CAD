import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
P=[]
for k,n in enumerate(("out_scan","inn_scan")):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    radial=(c[:,0]*nn[:,0]+c[:,1]*nn[:,1])/np.maximum(r,1e-9)
    m=(r>66)&(r<70.5)&(radial>0.97)&(np.abs(ang-10)<35)&(c[:,2]>-9)&(c[:,2]<79)
    P.append(np.c_[c[m],np.full(m.sum(),k)])
P=np.vstack(P); print(len(P))
def rad(p,ax):  # distance from axis
    x0,y0,tx,ty=ax
    x=P[:,0]-(x0+tx*(P[:,2]-36)); y=P[:,1]-(y0+ty*(P[:,2]-36)); return np.hypot(x,y)
def prof(p,z,kind):
    if kind=="cone2": Rp,zp,ti,to=p; return np.where(z>zp,Rp-(z-zp)*ti,Rp-(zp-z)*to)
    if kind=="cone1": Rp,zp,t=p; return Rp-np.abs(z-zp)*t
    if kind=="poly2": return np.polyval(p,z)
    if kind=="poly4": return np.polyval(p,z)
    if kind=="line_out_in": pass
    if kind=="cylfillet":  # cones with parting fillet radius rf (profile plane)
        Rp,zp,ti,to,rf=p
        a1,a2=np.arctan(to),np.arctan(ti)
        # lines: below zp rises with slope to; above zp falls with slope ti. fillet circle tangent to both (convex)
        # tangent length = rf*tan((a1+a2)/2)
        d=rf*np.tan((a1+a2)/2)
        zl,zh=zp-d*np.cos(a1),zp+d*np.cos(a2)
        out=np.where(z>zp,Rp-(z-zp)*ti,Rp-(zp-z)*to)
        # circle center
        cz=zl+rf*np.sin(a1)*1.0; cR=Rp-d*np.sin(a1)-0+rf*np.cos(a1)  # approx center below peak
        cR=(Rp-d*np.sin(a1))-rf*np.cos(a1)
        cz=zl-(-rf*np.sin(a1))*0 + (-rf*np.sin(a1))*(-1)
        cz=zl+rf*np.sin(a1)
        arc=cR+np.sqrt(np.maximum(rf**2-(z-cz)**2,0))
        return np.where((z>zl)&(z<zh),arc,out)
def fit(kind,p0,axfree=True,axfix=(0,0,0,0)):
    n=len(p0)
    def res(q):
        ax=q[n:] if axfree=="full" else ((q[n],q[n+1],0,0) if axfree else axfix)
        return rad(None,ax)-prof(q[:n],P[:,2],kind)
    q0=list(p0)+([0,0,0,0] if axfree=="full" else ([0,0] if axfree else []))
    s=least_squares(res,q0,loss="soft_l1",f_scale=.1); r=res(s.x)
    return s.x,r
for kind,p0 in (("cone1",[68.9,37,.03]),("cone2",[68.9,37,.03,.03]),("cylfillet",[68.95,37,.03,.03,200]),("poly2",[0,0,68]),("poly4",[0,0,0,0,68])):
    for af in (False,True,"full"):
        x,r=fit(kind,p0,af)
        a=np.abs(r); print(f"{kind:9s} ax={af!s:5s} mean|r| {a.mean():.4f} p50 {np.median(a):.4f} p90 {np.percentile(a,90):.4f} p95 {np.percentile(a,95):.4f} x={np.round(x,4)}")
