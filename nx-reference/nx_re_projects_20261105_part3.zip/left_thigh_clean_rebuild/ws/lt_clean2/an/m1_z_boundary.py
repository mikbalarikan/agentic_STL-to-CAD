import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
Rp,zp,dd=68.85,36.07,1.6; t=np.tan(np.radians(dd)); Rc=lambda z: Rp-np.abs(z-zp)*t
out={"plusX_step_edge":[],"minusX_tangent_blend_dev0p3":[],"minusX_tangent_blend_dev1p0":[],"ear_strip":{}}
earz={}
for nm,zr in (("out_scan",(-10.4,34.6)),("inn_scan",(35.4,80.3))):
    v,f=lib.load(nm,1500000); c,nn,ar=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1])); radial=(c[:,0]*nn[:,0]+c[:,1]*nn[:,1])/np.maximum(r,1e-9)
    dev=r-Rc(c[:,2]); ok=(radial>0.9)&(np.abs(dev)<0.5)
    zs=np.arange(zr[0]+.5,zr[1],2.0)
    for z in zs:
        k=ok&(abs(c[:,2]-z)<1.0)
        e=k&(ang>40)&(ang<53.5)
        if e.sum()>5:
            a=np.sort(ang[e])[-4:].mean()  # edge angle
            R=Rc(z); out["plusX_step_edge"].append((scan:=nm[:3],round(float(z),1),round(float(a),2),round(float(R*np.sin(np.radians(a))),2),round(float(-R*np.cos(np.radians(a))),2)))
        ee=k&(ang>53.5)&(ang<65)
        if ee.sum()>5: earz.setdefault(nm,[]).append((float(z),float(ang[ee].min()),float(ang[ee].max()),int(ee.sum())))
    # -X blend: section-based
    for z in zs:
        if nm=="out_scan" and (z>7 or z<-10.4): continue
        if nm=="inn_scan" and z<63: continue
        sec=lib.section(v,f,2,z).reshape(-1,3); X=sec[:,0]; Y=sec[:,1]; R=np.hypot(X,Y); A=np.degrees(np.arctan2(X,-Y)); D=R-Rc(z)
        m=(R>60)&(R<85)&(A<-100)&(A>-178)
        o=np.argsort(A[m]); a=A[m][o]; d=D[m][o]
        for thr,key in ((0.3,"minusX_tangent_blend_dev0p3"),(1.0,"minusX_tangent_blend_dev1p0")):
            j=np.where((d>thr)&(a<-120))[0]
            if len(j): 
                aa=float(a[j].max()); out[key].append((nm[:3],round(float(z),1),round(aa,1),round(float(Rc(z)*np.sin(np.radians(aa))),2),round(float(-Rc(z)*np.cos(np.radians(aa))),2)))
# line fits of +X edge
for sc in ("out","inn"):
    E=np.array([(e[1],e[2]) for e in out["plusX_step_edge"] if e[0]==sc])
    if len(E)>3:
        p=np.polyfit(E[:,0],E[:,1],1); print(sc,"+X edge ang = %.3f + %.5f*z  range %.2f..%.2f"%(p[1],p[0],E[:,1].min(),E[:,1].max()),"z",E[:,0].min(),E[:,0].max())
        out["plusX_edge_fit_"+sc]=dict(ang0=float(p[1]),slope_deg_per_mm=float(p[0]),ang_min=float(E[:,1].min()),ang_max=float(E[:,1].max()),z_range=[float(E[:,0].min()),float(E[:,0].max())])
for k,v in earz.items():
    zz=np.array([a[0] for a in v]); print("ear",k,"z",zz.min(),zz.max(),"ang",np.round([a[1] for a in v][:5],1),np.round([a[2] for a in v][:5],1)); out["ear_strip"][k]=dict(z=[float(zz.min()),float(zz.max())],ang_min=float(np.median([a[1] for a in v])),ang_max=float(np.median([a[2] for a in v])),n_bins=len(v))
print([ (a[1],a[2]) for a in out["minusX_tangent_blend_dev0p3"]])
print([ (a[1],a[2]) for a in out["minusX_tangent_blend_dev1p0"]])
json.dump(out,open("work/m1/_boundary.json","w"),indent=1)
