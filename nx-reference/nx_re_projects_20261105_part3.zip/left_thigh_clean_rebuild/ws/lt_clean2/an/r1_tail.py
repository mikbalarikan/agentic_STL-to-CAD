import sys, os, numpy as np, trimesh
from shapely.geometry import LineString, Point, Polygon, MultiPoint
from shapely.ops import unary_union
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
C0 = np.array([62.0, -51.0])
def polys(mesh, z):
    s = mesh.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1])
    if s is None: return []
    return [s.vertices[e.points][:, :2] for e in s.entities]
res = {}
for w, zs in (("out", (-10, 0, 10, 20, 30)), ("inn", (40, 50, 60))):
    v, f = lib.load(w + "_scan", 1500000); sm = trimesh.Trimesh(v, f, process=False)
    cm = trimesh.load(f"nx/A_v2/{w}_A_r0.stl")
    for z in zs:
        sc = [p for p in polys(sm, z)]; cc = polys(cm, z)
        def near(pl, r=10):
            out = []
            for p in pl:
                k = np.linalg.norm(p - C0, axis=1) < r
                if k.any(): out.append(p[k])
            return np.vstack(out) if out else np.zeros((0, 2))
        sp = near(sc, 9); cp = near(cc, 9)
        if len(sp) < 5 or len(cp) < 5: print(w, z, "no data", len(sp), len(cp)); continue
        # CAD corner vertex: point of CAD pts farthest along the corner direction = max x - ... use point of cp closest to extreme in direction away from body (+x,-y)
        d = (cp - C0) @ np.array([1, -1]) / 1.414
        v0 = cp[np.argmax(d)]
        # scan extreme in same direction
        ds = (sp - C0) @ np.array([1, -1]) / 1.414
        s0 = sp[np.argmax(ds)]
        print(f"{w} z{z}: CAD vertex {v0.round(2)} scan extreme {s0.round(2)} overshoot along diag {d.max()-ds.max():.2f}")
        # fit candidate fillet radii: model CAD polyline opened with radius R, distance to scan pts within 5 mm of the vertex
        poly_c = LineString(cp[np.argsort(np.arctan2(cp[:,1]-C0[1], cp[:,0]-C0[0]))]) if False else None
        res[(w, z)] = (v0, s0)
json.dump({f"{k[0]}_{k[1]}": [v.tolist() for v in vv] for k, vv in res.items()}, open("work/r1/tail_corner.json", "w")) if False else None
