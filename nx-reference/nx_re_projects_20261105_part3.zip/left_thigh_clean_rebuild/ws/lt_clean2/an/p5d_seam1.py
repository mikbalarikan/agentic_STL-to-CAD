"""P5d seam measurement: transects of the scan exterior surface across the part-5 seam path (work/seams.json), groove centre / depth / width per station.
argv: which. Iterates the centre line twice. Writes work/p5d/seam_<w>.json (stations) and prints stats."""
import sys, os, json, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, open3d as o3d
from scipy.interpolate import CubicSpline
which = sys.argv[1]
v, f = lib.load(which + "_scan", 1500000)
S = o3d.t.geometry.RaycastingScene()
S.add_triangles(o3d.core.Tensor(v.astype(np.float32)), o3d.core.Tensor(f.astype(np.uint32)))
seams = json.load(open(r"C:\NX_MCP_WORKSPACE\lt_clean2\work\seams.json"))
out = which == "out"
z0, dz = (-300.0, 1.0) if out else (300.0, -1.0)
sign = -1.0 if out else 1.0         # depth = sign*(zbase - z)... outer exterior faces -Z: groove = higher z
def height(X, Y):
    rays = np.c_[X, Y, np.full_like(X, z0), np.zeros_like(X), np.zeros_like(X), np.full_like(X, dz)].astype(np.float32)
    t = S.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
    z = z0 + dz * t
    z[~np.isfinite(t)] = np.nan
    return z
res = {}
OFF = np.arange(-7.0, 7.01, 0.2)
for name, pts in seams.items():
    P = np.array(pts, float)
    for it in range(3):
        d = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]
        cs = CubicSpline(d, P, bc_type="natural")
        ss = np.arange(0, d[-1], 2.0)
        Q = cs(ss); T = cs(ss, 1); T /= np.linalg.norm(T, axis=1)[:, None]; N = np.c_[-T[:, 1], T[:, 0]]
        cen = []; dep = []; wid = []; ok = []
        for q, n in zip(Q, N):
            X = q[0] + OFF * n[0]; Y = q[1] + OFF * n[1]
            z = height(X, Y)
            if np.isnan(z).sum() > 5: cen.append(np.nan); dep.append(np.nan); wid.append(np.nan); ok.append(False); continue
            fin = np.isfinite(z)
            z = np.interp(OFF, OFF[fin], z[fin])
            side = np.abs(OFF) > 3.6
            A = np.c_[OFF[side], np.ones(side.sum())]; co = np.linalg.lstsq(A, z[side], rcond=None)[0]
            base = co[0] * OFF + co[1]
            dp = sign * (base - z)          # >0 = groove
            dp = np.convolve(dp, np.ones(3) / 3, mode="same")
            k = np.nanargmax(dp[3:-3]) + 3
            m = dp[k]
            # centre as the centroid of the part above half depth
            hi = dp > 0.5 * m
            idx = np.where(hi)[0]
            # contiguous run containing k
            lo_i = k
            while lo_i > 0 and hi[lo_i - 1]: lo_i -= 1
            hi_i = k
            while hi_i < len(OFF) - 1 and hi[hi_i + 1]: hi_i += 1
            c = np.sum(OFF[lo_i:hi_i + 1] * dp[lo_i:hi_i + 1]) / np.sum(dp[lo_i:hi_i + 1])
            cen.append(c); dep.append(m); wid.append(OFF[hi_i] - OFF[lo_i] + 0.2); ok.append(m > 0.25)
        cen = np.array(cen); dep = np.array(dep); wid = np.array(wid); ok = np.array(ok)
        if it < 2:
            # move the stations to the measured centre, rebuild a spline through every 4th station
            good = ok & np.isfinite(cen)
            Qn = Q + cen[:, None] * N
            sel = np.where(good)[0]
            # smooth the offsets
            P = Qn[sel][::3]
            if len(P) < 4: break
    good = ok & np.isfinite(cen)
    print(name, "stations", len(ss), "grooved", int(good.sum()), "len %.0f" % d[-1])
    print("  depth median %.2f p10 %.2f p90 %.2f max %.2f | width(half depth) median %.2f p10 %.2f p90 %.2f | |centre offset| to start path p90 %.2f" % (
        np.median(dep[good]), np.percentile(dep[good], 10), np.percentile(dep[good], 90), dep[good].max(), np.median(wid[good]), np.percentile(wid[good], 10), np.percentile(wid[good], 90), 0))
    res[name] = {"s": ss.tolist(), "Q": (Q + cen[:, None] * N).tolist(), "depth": dep.tolist(), "width": wid.tolist(), "ok": ok.tolist()}
json.dump(res, open(rf"C:\NX_MCP_WORKSPACE\lt_clean2\work\p5d\seam_{which}.json", "w"))
