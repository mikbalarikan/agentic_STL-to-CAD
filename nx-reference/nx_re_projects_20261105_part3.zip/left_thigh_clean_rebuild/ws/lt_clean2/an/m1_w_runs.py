import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
Rp,zp,t=68.85,36.07,np.tan(np.radians(1.6))
for nm,zs in (("out_scan",(2,12,20,30)),("inn_scan",(40,50,60,68))):
    v,f=lib.load(nm,1500000); c,nn,ar=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1])); radial=(c[:,0]*nn[:,0]+c[:,1]*nn[:,1])/np.maximum(r,1e-9)
    dev=r-(Rp-abs(c[:,2]-zp)*t)
    for z in zs:
        k=(radial>0.9)&(np.abs(dev)<0.5)&(abs(c[:,2]-z)<0.6)
        h=np.histogram(ang[k],np.arange(-180,181,1))[0]>=2
        runs=[];i=0
        while i<360:
            if h[i]:
                j=i
                while j<359 and (h[j+1] or (j<358 and h[j+2])): j+=1
                runs.append((i-180,j-180+1)); i=j+1
            else: i+=1
        print(nm,z,runs)
