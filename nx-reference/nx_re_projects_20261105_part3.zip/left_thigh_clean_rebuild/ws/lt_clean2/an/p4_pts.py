import numpy as np, json, math
import open3d as o3d
from scipy.interpolate import CubicSpline
mesh = o3d.io.read_triangle_mesh(r"nx/base_v2/envelope.stl")
sc = o3d.t.geometry.RaycastingScene()
sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mesh))
hx, hz = 37.97, 35.18
Y = [54.5, 80.0, 110.0, 150.0, 210.0, 246.0, 259.0]
TH = [28.0, 37.8, 40.5, 38.2, 30.8, 24.5, 15.0]
PAD = 3.0
cs = CubicSpline(Y, TH)             # not-a-knot: cubic run-out of the design spline
def rad(y, th, sgn):
    t = math.radians(th)
    ray = o3d.core.Tensor([[hx, y, hz, math.cos(t), 0.0, -sgn * math.sin(t)]], dtype=o3d.core.Dtype.Float32)
    return float(sc.cast_rays(ray)["t_hit"].numpy()[0])
out = {"pad": PAD, "hx": hx, "hz": hz, "design_y": Y, "design_theta": TH, "theta_min": -4.0, "theta_max": 62.0}
ye = [Y[0] - PAD] + Y + [Y[-1] + PAD]
the = [float(cs(Y[0] - PAD))] + TH + [float(cs(Y[-1] + PAD))]
print("run-out", the[0], the[-1])
for name, sgn in (("out", 1), ("inn", -1)):
    out[name] = {"sgn": sgn, "pts": [{"y": y, "theta": round(t, 4), "r": round(rad(y, t, sgn), 4), "design": (0 < i < len(ye) - 1)}
                                     for i, (y, t) in enumerate(zip(ye, the))]}
    pr = []
    for y in (80.0, 110.0, 150.0, 200.0, 240.0):
        for th in (-14.0, -4.0 + 0.0, 10.0, 20.0, 50.0, 56.0, 75.0):
            pr.append({"y": y, "theta": th, "r": round(rad(y, th, sgn), 4)})
    for y in (48.0, 53.5, 260.0, 265.0):
        for th in (10.0, 20.0):
            pr.append({"y": y, "theta": th, "r": round(rad(y, th, sgn), 4)})
    out[name]["probes"] = pr
    print(name, [(p["y"], p["theta"], p["r"]) for p in out[name]["pts"]])
json.dump(out, open("nx/A_v2/panel_pts.json", "w"), indent=1)
