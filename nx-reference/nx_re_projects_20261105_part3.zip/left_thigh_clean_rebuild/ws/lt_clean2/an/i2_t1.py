from i2_fit import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
for k,(p0,p1,z,t) in DS.INN_RIBS.items():
    r,m=rib_fit(p0,p1,t); print(k, {kk:(np.round(vv,3) if not isinstance(vv,dict) else vv) for kk,vv in r.items() if kk not in('e',)}, metrics(m))
