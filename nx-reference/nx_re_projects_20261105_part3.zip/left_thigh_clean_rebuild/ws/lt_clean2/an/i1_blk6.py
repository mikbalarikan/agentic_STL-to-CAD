from i1_core import *
from i1_rib import *
from i1_help import *
import json
import stages_consts as K
from scipy.spatial import cKDTree
import shapely.geometry as sg
import contourpy

# ---------------------------------------------------------------- side openings (outline from occupancy of the wall in y-z)
def opening(fid, side, part5_segs, ylim, zlim):
    xm = (c[:, 0] < -15) if side == "MX" else (c[:, 0] > 85)
    m = xm & (c[:, 1] > ylim[0]) & (c[:, 1] < ylim[1]) & (c[:, 2] > zlim[0]) & (c[:, 2] < zlim[1])
    px = 0.8
    ny_, nz_ = int((ylim[1] - ylim[0]) / px), int((zlim[1] - zlim[0]) / px)
    H = np.zeros((nz_, ny_))
    iy = np.clip(((c[m, 1] - ylim[0]) / px).astype(int), 0, ny_ - 1); iz = np.clip(((c[m, 2] - zlim[0]) / px).astype(int), 0, nz_ - 1)
    np.add.at(H, (iz, iy), 1)
    from scipy import ndimage as ndi
    occ = ndi.binary_closing(H > 0, iterations=1)
    emp = ~occ
    lab, nl = ndi.label(emp)
    # opening = the empty component that touches the top of the window or the biggest interior one
    from shapely import contains_xy
    p5g = sg.Polygon([(sg_[0][1], sg_[0][2]) for sg_ in part5_segs]).buffer(0)
    gy_, gz_ = np.meshgrid(ylim[0] + (np.arange(ny_) + 0.5) * px, zlim[0] + (np.arange(nz_) + 0.5) * px)
    inp5 = contains_xy(p5g, gy_, gz_)
    ov = ndi.sum(inp5 & emp, lab, range(1, nl + 1)); k = 1 + int(np.argmax(ov))
    comp = lab == k
    gen = contourpy.contour_generator(z=np.pad(comp.astype(float), 1))
    lines = gen.lines(0.5)
    ln = max(lines, key=len) - 1.0
    ys = ylim[0] + (ln[:, 0] + 0.5) * px; zs = zlim[0] + (ln[:, 1] + 0.5) * px
    clipb = sg.box(-1e3, -1e3, 1e3, 35.0)
    near = p5g.buffer(15)
    keep = np.array([near.contains(sg.Point(y_, z_)) and z_ <= 35.0 and z_ > zlim[0] + 1 for y_, z_ in zip(ys, zs)])
    ys, zs = ys[keep], zs[keep]
    bnd = p5g.exterior
    dists = np.array([bnd.distance(sg.Point(y_, z_)) for y_, z_ in zip(ys, zs)])
    line = sg.LineString(np.c_[ys, zs]).simplify(0.6) if len(ys) > 2 else None
    hd = float(dists.max()); sym = None
    p5 = p5g
    class _P: pass
    poly = line
    tree = cKDTree(np.c_[ys, zs]); pts = np.c_[c[m, 1], c[m, 2]]
    dist, _ = tree.query(pts)
    idx = np.where(m)[0][dist < 4.0]
    # only keep the part of the boundary below the rim z 35 for the outer (opening is cut by the inner above)
    verts = [(round(float(y_), 1), round(float(z_), 1)) for y_, z_ in list(line.coords)]
    add(fid, "side opening (cut)", dict(outline_yz=verts, outline_offset_median=float(np.median(dists)), outline_offset_p90=float(np.percentile(dists, 90)), outline_offset_max=hd),
        "empty-component contour of the wall occupancy (0.8 mm pixels), simplified 0.5 mm", None, idx, dict(outline=[(s_[0][1], s_[0][2]) for s_ in part5_segs]),
        f"scan opening outline (points within 15 mm of the part 5 outline) is off the part 5 polygon by median {np.median(dists):.1f} / p90 {np.percentile(dists,90):.1f} / max {hd:.1f} mm; see outline_yz",
        "re-draw the opening polygon from outline_yz (lines + 2 arcs), not the part 5 polygon")
    return poly

try:
    opening("OPENING_MX", "MX", K.O2_MX, (150, 260), (-15, 36.5))
except Exception as ex:
    print("MX opening failed", ex)
try:
    opening("OPENING_PX", "PX", K.O3_PX, (115, 215), (-15, 36.5))
except Exception as ex:
    print("PX opening failed", ex)

# ---------------------------------------------------------------- seams: groove depth along the part-5 seam polylines
try:
    sj = json.load(open(r"C:\NX_MCP_WORKSPACE\lt_clean\work\seams.json"))
    for nm, pts in sj.items():
        P = np.array(pts); seg = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]
        t = np.linspace(0, seg[-1], max(int(seg[-1] / 0.5), 4)); L2 = np.c_[np.interp(t, seg, P[:, 0]), np.interp(t, seg, P[:, 1])]
        tree = cKDTree(L2); dd, _ = tree.query(c[:, :2])
        ext = (de < 1.2)
        core = ext & (dd < 0.45); side = ext & (dd > 1.5) & (dd < 3.0)
        idx = np.where(ext & (dd < 2.0))[0]
        if core.sum() < 20: continue
        dep = float(np.median(de[side]) - np.median(de[core])) if side.sum() > 20 else None
        add("SEAM_" + nm, "seam groove", dict(length=float(seg[-1]), n_points=len(pts), median_de_on_line=float(np.median(de[core])), median_de_beside=float(np.median(de[side])) if side.sum() else None,
            depth_proxy=dep), "scan distance to part-5 envelope on the seam line vs 1.5-3 mm beside", None, idx, dict(D=1.25, depth=0.62, n_points=len(pts)), "", "exterior zone (G-ext); keep as a clean tube groove")
except Exception as ex:
    print("seams failed", ex)

# ---------------------------------------------------------------- root blend radius (R_TRANS_Y166 section) and joint rim
p, e, nu, L = frame((-2.3, 166.0), (80.0, 166.0)); s_, u_ = local(c, p, e, nu)
m = (s_ > 15) & (s_ < 70) & (u_ > 1.6) & (u_ < 9) & (de > 3.0)
fl = m & (u_ > 6.5) & (n[:, 2] > 0.95)
zfl = float(np.median(c[fl, 2])) if fl.sum() else None
fm = m & (abs(n[:, 2]) > 0.25) & (abs(n[:, 2]) < 0.97) & (c[:, 2] < -6)
if fm.sum() > 100:
    cu, cz, R, res, nn = circle_fit_robust(u_[fm], c[fm, 2])
    add("ROOT_BLENDS_R3", "fillet", dict(R=R, fit_rms=res, n_used=nn, floor_z_beside_rib=zfl), "circle fit in the rib section (u,z) of the transition tris at the R_TRANS_Y166 base", res, np.where(fm)[0], dict(R=3.0),
        f"measured root radius {R:.2f} (part 5 R3.0)", "keep one Edge Blend R=%.1f" % round(R * 2) / 2 if False else "")
rim = (n[:, 2] > 0.95) & (abs(c[:, 2] - 34.75) < 0.15) & (de > 0.2)
if rim.sum() > 50:
    pk = peaks(c[(n[:, 2] > 0.95) & (c[:, 2] > 33.5) & (c[:, 2] < 37.5) & (de > 0.2), 2], None, 0.05, 0.02, rng=(33.5, 37.5))
    add("JOINT_RIM", "joint planes", dict(plane_peaks=[(round(q[0], 2), round(q[1], 2)) for q in pk[:5]]), "z histogram of upward faces 33.5-37.5", None,
        np.where((n[:, 2] > 0.95) & (c[:, 2] > 33.5) & (c[:, 2] < 37.0) & (de > 0.2) & (np.hypot(c[:, 0] - 0, c[:, 1] - 0) > 60))[0], dict(z_rim=34.76, z_A=36.07),
        "", "owned by the joint-band analyst; listed for completeness")
