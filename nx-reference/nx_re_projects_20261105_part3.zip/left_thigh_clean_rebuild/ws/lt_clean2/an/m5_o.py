import sys, os, numpy as np, trimesh
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, scipy.spatial as sp
R=r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 5 - Clean Rebuild\deliver\CAD"
for key,fn,scan,dn in (("out","LT-OUT-001_Left_Thigh_Outer.stl","out_scan","FINout"),("inn","LT-INN-001_Left_Thigh_Inner.stl","inn_scan","FINinn")):
    m=trimesh.load(os.path.join(R,fn),process=False); print(key,len(m.faces),m.area,m.bounds.tolist())
    pts,fi=trimesh.sample.sample_surface(m,int(m.area/0.012))   # ~0.11 mm spacing
    np.savez(os.path.join(lib.W,"m5",f"{key}_p5pts.npz"),pts=pts,fi=fi,fn=m.face_normals[fi])
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f); w=ar/ar.sum()
    d,_=sp.cKDTree(pts).query(c,workers=-1); st=np.load(os.path.join(lib.W,f"dev_{dn}.npz"))["d1"]
    print(" npts",len(pts),"proxy <0.5:",w[d<0.5].sum()*100,"stored:",w[st<0.5].sum()*100)
