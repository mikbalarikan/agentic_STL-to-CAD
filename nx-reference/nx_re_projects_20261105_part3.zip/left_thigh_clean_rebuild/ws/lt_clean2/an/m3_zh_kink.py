import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
D=np.load("work/m3/ext_pts.npz"); P=D['P']; r=D['r']; th=D['th']
angs=[-170,-150,-135,-120,-105,-90,-60,-30,-15,15,30,60,90,105,120,135,150,170]
fig,ax=plt.subplots(3,6,figsize=(36,18))
for a,t in zip(ax.flat,angs):
    k=(abs(th-t)<2)&(P[:,1]>240)
    yb=np.arange(240,287.6,0.5); R=np.array([np.median(r[k&(abs(P[:,1]-y)<0.4)]) if (k&(abs(P[:,1]-y)<0.4)).sum()>3 else np.nan for y in yb])
    a.plot(yb,R,'k.-',ms=3,lw=.5)
    sl=np.gradient(R,yb); a2=a.twinx(); a2.plot(yb,sl,'r-',lw=.8); a2.set_ylim(-.8,.4)
    a.set_title(f"theta {t}  R(Y) and slope"); a.grid(True)
plt.tight_layout(); plt.savefig("work/m3/kink.png",dpi=40)
