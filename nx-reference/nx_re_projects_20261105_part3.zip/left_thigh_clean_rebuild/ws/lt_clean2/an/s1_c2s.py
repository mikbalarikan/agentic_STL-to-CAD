"""CAD->scan: envelope surface samples vs union of both scans (interior of the scan counts as scan). usage s1_c2s.py env.stl tag"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_lib import *
import trimesh, open3d as o3d
m = trimesh.load(sys.argv[1], process=False); tag = sys.argv[2]
pts, fi = trimesh.sample.sample_surface(m, 400000)
nrm = m.face_normals[fi]
V = []; F = []; n0 = 0
for s in ['out', 'inn']:
    v, f, c, n, a = scan(s); V.append(v); F.append(f + n0); n0 += len(v)
sc = o3d.t.geometry.RaycastingScene()
sc.add_triangles(o3d.core.Tensor(np.vstack(V).astype(np.float32)), o3d.core.Tensor(np.vstack(F).astype(np.uint32)))
d = sc.compute_distance(o3d.core.Tensor(pts.astype(np.float32))).numpy()
x, y, z = pts.T
skip = (np.abs(y - 287.39) < 0.05) | (np.abs(y + 51) < 0.05) | ((z < -13.8) & (np.hypot(x, y) < 63.2))
dd = d[~skip]; print('samples', len(dd), 'frac >0.5: %.3f  >1: %.3f  >2: %.3f' % ((dd > .5).mean(), (dd > 1).mean(), (dd > 2).mean()))
np.savez(os.path.join(S1, f'c2s_{tag}.npz'), pts=pts[~skip], d=dd)
import pyvista as pv; pv.OFF_SCREEN = True
sel = dd > 0.7
print('bad samples', sel.sum())
for nm, dv in [('a', (0.5, -0.8, 0.6)), ('b', (-0.8, -0.3, 0.5)), ('c', (0.3, -0.4, -1)), ('d', (0.3, -0.3, 1)), ('e', (0.3, 1, 0.5))]:
    p = pv.Plotter(window_size=(1200, 800))
    p.add_mesh(pv.PolyData(pts[~skip][sel]), scalars=np.minimum(dd[sel], 4), cmap='jet', point_size=3, show_scalar_bar=True)
    dv = np.array(dv, float); dv /= np.linalg.norm(dv); fo = np.array([40, 110, 35.]); p.camera.focal_point = fo; p.camera.position = fo + 600 * dv
    p.camera.up = (0, 0, 1) if nm in 'abe' else (0, 1, 0); p.screenshot(os.path.join(S1, f'c2s_{tag}_{nm}.png')); p.close()
