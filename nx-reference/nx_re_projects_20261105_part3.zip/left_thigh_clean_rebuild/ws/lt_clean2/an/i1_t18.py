from i1_core import *
import sys
x0,x1,y0,y1=[float(t) for t in sys.argv[1:5]]
plot_win(S,(x0,x1),(y0,y1),sys.argv[5],min_de=1.0,cols=("z","d5","d0"),size=float(sys.argv[6]) if len(sys.argv)>6 else 9)
