import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, trimesh
HX,HZ=37.97,35.18
sc={n:lib.load(n,1500000) for n in ('out_scan','inn_scan')}
for tag,sn,dn in (('out','out_scan',('dev_FINout','dev_oldC')),('inn','inn_scan',('dev_FINinn','dev_oldInnB'))):
    v,f=sc[sn]; c,nn,a=lib.tri_data(v,f); m=np.load(f"work/masks/{tag}_ext_hip.npy")
    print(tag,'mask',len(m),'area',a[m].sum().round(0))
    ys=c[m,1]
    for d in dn:
        z=np.load(f"work/{d}.npz"); d1=z['d1'][m]
        print(' ',d,'keys',list(z.keys()) if d==dn[0] else '')
        for y0,y1 in ((200,230),(230,250),(250,262),(262,272),(272,280),(280,288),(200,290)):
            k=(ys>=y0)&(ys<y1); w=a[m][k]
            if k.sum()==0: continue
            ok=(d1[k]<=0.5)
            print('    Y%d-%d  within0.5: %.1f%%  p50 %.2f p90 %.2f p99 %.2f'%(y0,y1,100*(w*ok).sum()/w.sum(),*[np.percentile(d1[k],q) for q in (50,90,99)]))
