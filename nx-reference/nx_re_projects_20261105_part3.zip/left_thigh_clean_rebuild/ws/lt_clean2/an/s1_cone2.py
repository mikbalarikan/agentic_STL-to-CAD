from s1_lib import *
from scipy.optimize import least_squares
d=np.load(os.path.join(S1,'ext_all.npz')); P=d['P']; A=d['a']; x,y,z=P.T
HX,HZ=37.97,35.18
phi=np.degrees(np.arctan2(z-HZ,x-HX))
wedge=(np.abs(phi)<25)|(np.abs(phi)>118)
m=wedge&(y>270)&(y<286.8)
Q=P[m]
def rho_true(p,Q):
    X0,Z0,tau,sig,R0,k=p
    u=np.array([np.sin(tau),np.cos(tau)*np.cos(sig),np.sin(sig)]); u/=np.linalg.norm(u)
    D=Q-np.array([X0,287.39,Z0]); s=D@u; perp=D-s[:,None]*u
    return np.linalg.norm(perp,axis=1)-(R0-k*s)
def fitit(p0,free,Q):
    p=np.array(p0,float)
    for it in range(5):
        r=rho_true(p,Q); keep=np.abs(r)<max(0.5,2.5*np.median(np.abs(r)))
        f=lambda q: rho_true(np.where(free,q,p0full),Q[keep])
        p0full=p.copy(); q0=p[free]
        def g(qf):
            pp=p0full.copy(); pp[free]=qf; return rho_true(pp,Q[keep])
        s=least_squares(g,q0); p[free]=s.x
    return p,np.std(rho_true(p,Q[keep])),np.median(np.abs(rho_true(p,Q[keep]))),keep.mean()
p,sd,med,kp=fitit([38,35.18,0,0,71,0.46],np.array([1,1,1,1,1,1],bool),Q); print('free',np.round(p,4),'tau deg',np.degrees(p[2]).round(3),'sd',sd.round(3),'med',med.round(3),kp.round(3))
p,sd,med,kp=fitit([HX,HZ,0,0,71,0.46],np.array([0,0,0,0,1,1],bool),Q); print('axis=hip no tilt',np.round(p,4),'sd',sd.round(3),'med',med.round(3))
p,sd,med,kp=fitit([HX,HZ,0,0,71,0.46],np.array([0,0,1,0,1,1],bool),Q); print('axis thru hip pt, tau free',np.round(p,4),np.degrees(p[2]).round(3),'sd',sd.round(3),'med',med.round(3))
# wider data: all Y 266-286.8 wedge
print('--- per side')
for nm,mm in [('+X',(np.abs(phi)<25)),('-X',(np.abs(phi)>118)),('+X upper (z>35)',(phi>0)&(phi<25)),('+X lower',(phi<0)&(phi>-25)),('-X upper',(phi>118)),('-X lower',(phi<-118))]:
    Qs=P[mm&(y>270)&(y<286.8)]
    for lab,p0,free in [('coaxial R0,k',[HX,HZ,0,0,71,0.46],[0,0,0,0,1,1]),('coax+tau',[HX,HZ,0,0,71,0.46],[0,0,1,0,1,1]),('free axis',[38,35.18,0,0,71,0.46],[1,1,1,1,1,1])]:
        p,sd,med,kp=fitit(p0,np.array(free,bool),Qs); print(nm,lab,'n',len(Qs),np.round(p,3),'tau deg %.2f'%np.degrees(p[2]),'sd %.3f med %.3f'%(sd,med))
