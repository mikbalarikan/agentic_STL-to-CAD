import sys
from s1_shell import *
from s1_build import build, cone_solid
from OCP.BRepOffsetAPI import BRepOffsetAPI_MakeOffsetShape
tag=sys.argv[1]
env,lo,body,dr=build(tag,verbose=False)
def try_thick(shape,name,t,join=GeomAbs_Arc,mf=None,tol=1e-3):
    mf=mf or mouth_face(shape)
    lst=TopTools_ListOfShape(); lst.Append(mf)
    mk=BRepOffsetAPI_MakeThickSolid(); t0=time.time()
    try:
        mk.MakeThickSolidByJoin(shape,lst,-t,tol,BRepOffset_Skin,True,False,join); mk.Build()
        s=mk.Shape() if mk.IsDone() else None
        print(name,t,'done',mk.IsDone(), 'valid',valid(s) if s else None,'vol',round(volume(s)) if s else None,'orig',round(volume(shape)),'t',round(time.time()-t0,1),flush=True)
    except Exception as e: print(name,t,'EXC',str(e)[:100])
# loft body only (with mouth)
try_thick(body,'body_loft_cone',3.1)
try_thick(body,'body',1.0)
# offset surface of full env
mk=BRepOffsetAPI_MakeOffsetShape(); t0=time.time()
mk.PerformByJoin(env,-3.1,1e-3,BRepOffset_Skin,False,False,GeomAbs_Arc); 
print('offsetshape env -3.1 done',mk.IsDone(),'valid',valid(mk.Shape()) if mk.IsDone() else None,'vol',round(volume(mk.Shape())) if mk.IsDone() else None,'t',round(time.time()-t0,1))
