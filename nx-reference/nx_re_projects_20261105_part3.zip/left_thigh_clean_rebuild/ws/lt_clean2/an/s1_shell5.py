import sys
from s1_shell import *
from s1_build import build, cone_solid
from s1_geo import *
from OCP.gp import gp_Pnt as Pn
tag=sys.argv[1]
d=np.load(f'work/s1/loft_{tag}.npz'); st=d['st']; P=d['P']
lo=loft(P[4:],st[4:]); 
def test(shape,name,cf,t=3.1,jn=GeomAbs_Arc):
    lst=TopTools_ListOfShape(); lst.Append(cf); mk=BRepOffsetAPI_MakeThickSolid(); t0=time.time()
    mk.MakeThickSolidByJoin(shape,lst,-t,1e-3,BRepOffset_Skin,True,False,jn); mk.Build()
    s=mk.Shape() if mk.IsDone() else None
    print(name,t,'done',mk.IsDone(),'valid',valid(s) if s else None,'vol',round(volume(s)) if s else None,'orig',round(volume(shape)),round(time.time()-t0,1),flush=True)
# cut the lofted+coned body at Y=Yc to see whether the mouth zone matters
for Yc in [283.0,285.0,286.5]:
    box=BRepPrimAPI_MakeBox(gp_Pnt(-200,-100,-200),gp_Pnt(400,Yc,300)).Shape()
    b=common(common(lo,cone_solid()),box)
    cf=None
    for f in faces(b):
        a=BRepAdaptor_Surface(f)
        if a.GetType()==GeomAbs_Plane and abs(a.Plane().Location().Y()-Yc)<1e-3 and abs(a.Plane().Axis().Direction().Y())>0.99: cf=f
    if cf is None: print(Yc,'no cap'); continue
    test(b,f'cut at {Yc}',cf)
