import numpy as np
ZT, ZB = 83.6, -13.9
def snap(P, st, ymax=66.0, tol=0.12):
    P = P.copy(); n = 0
    for k, y in enumerate(st):
        if y > ymax: continue
        z = P[k, :, 1]
        m = np.abs(z - ZT) < tol; P[k, m, 1] = ZT; n += m.sum()
        m = np.abs(z - ZB) < tol; P[k, m, 1] = ZB; n += m.sum()
    return P, n
