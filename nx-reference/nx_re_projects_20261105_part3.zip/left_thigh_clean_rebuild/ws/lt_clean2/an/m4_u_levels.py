import sys, os, pickle, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
W4 = os.path.join(lib.W, "m4")
C = pickle.load(open(os.path.join(W4, "cmp.pkl"), "rb")); T = json.load(open(os.path.join(W4, "tilt.json")))["out_scan"]
fig, axs = plt.subplots(1, 2, figsize=(16, 6))
cols = dict(KNEE_ARC="tab:gray", PX_WALL="tab:blue", PX_HIP="tab:purple", MX_WALL="tab:green", MX_HIP="tab:olive")
for ax, keys, ttl in ((axs[0], ("rim", "tongue_top"), "OUTER scan: rim / tongue top vs Y"), (axs[1], ("lip", "rebate_floor"), "INNER scan: lip / rebate floor vs Y")):
    for k, mk in zip(keys, ("o", "s")):
        for ch in cols:
            R = [r for r in C["scan"] if r["chain"] == ch and np.isfinite(r.get(k, np.nan))]
            ax.plot([r["y"] for r in R], [r[k] for r in R], mk, ms=2.5, c=cols[ch], label=f"{k} {ch}" if mk == "o" else None)
    ax.set_xlabel("Y (mm)"); ax.set_title(ttl); ax.grid(lw=.3)
    ax.legend(fontsize=7, ncol=2)
axs[0].set_ylim(34.5, 36.5); axs[1].set_ylim(35.0, 36.4)
fig.tight_layout(); fig.savefig(os.path.join(W4, "levels_vs_y.png"), dpi=60)
