import sys, numpy as np, trimesh, open3d as o3d, json
sys.path.insert(0,'an'); import lib
res={}
for which,items in (("out",(("tongue_top",36.05,1),("rim",34.8,1),("tongue_side",None,0))),("inn",(("rebate_floor",36.08,-1),("lip",35.31,-1),("rebate_side",None,0)))):
    v,f=lib.load(which+"_scan",1500000)
    s=o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(v.astype(np.float32)), o3d.core.Tensor(f.astype(np.uint32)))
    m=trimesh.load(f"nx/A_v2/{which}_A.stl")
    tc=m.triangles_center; n=m.face_normals
    for nm,z,nz in items:
        if z is not None: k=(np.abs(tc[:,2]-z)<0.02)&(n[:,2]*nz>0.999)
        else:
            zl,zh=((34.85,36.0) if which=="out" else (35.36,36.03)); k=(tc[:,2]>zl)&(tc[:,2]<zh)&(np.abs(n[:,2])<0.05)&(np.abs(tc[:,0])<300)
        sub=m.submesh([np.where(k)[0]],append=True); P,_=trimesh.sample.sample_surface(sub,30000,seed=1)
        d=s.compute_distance(o3d.core.Tensor(P.astype(np.float32))).numpy()
        res[which+"_"+nm]={"area":round(float(sub.area),1),"p50":round(float(np.median(d)),3),"p90":round(float(np.percentile(d,90)),3),"within05":round(float((d<0.5).mean()*100),1)}
        print(which,nm,res[which+"_"+nm])
json.dump(res,open("nx/A_v2/cad2scan.json","w"),indent=1)
