import sys, numpy as np
sys.path.insert(0,'an')
import lib
which, tag, mask = sys.argv[1:4]
v,f = lib.load({'out':'out_scan','inn':'inn_scan'}[which],1500000)
c,nn,ar = lib.tri_data(v,f)
d = np.load('work/dev_%s_%s.npz'%(tag,which))['d1']
m = np.load('work/masks/%s_f_%s.npy'%(which,mask))
dm=d[m]; cm=c[m]; nm=nn[m]
bad=dm>0.5
print(mask,'n',len(m),'bad',bad.sum(),'bbox all',cm.min(0).round(1),cm.max(0).round(1))
if bad.any():
    cb=cm[bad]; print('bad bbox',cb.min(0).round(1),cb.max(0).round(1),'mean',cb.mean(0).round(1),'p50 d bad %.2f'%np.median(dm[bad]))
    r=np.hypot(cm[:,0],cm[:,1]); ang=np.degrees(np.arctan2(cm[:,1],cm[:,0]))%360
    for nm_,x,bins in (('r',r,np.arange(0,80,4)),('z',cm[:,2],np.arange(60,100,4)),('ang',ang,np.arange(0,360,10))):
        h,_=np.histogram(x[bad],bins); a,_=np.histogram(x,bins)
        print(nm_,[(int(b0),int(hh),int(aa)) for b0,hh,aa in zip(bins[:-1],h,a) if aa>0])
