"""compare the CAD groove with the scan groove along the measured centre stations: CAD depth, CAD centre offset (p50/p90), coverage."""
import sys, json, numpy as np, trimesh, open3d as o3d
sys.path.insert(0, "an"); import lib
OFF = np.arange(-4.0, 4.01, 0.2)
for w in ("out", "inn"):
    m = trimesh.load(f"nx/P5d/{w}_P5d.stl", process=False)
    S = o3d.t.geometry.RaycastingScene(); S.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32)))
    out = w == "out"; z0, dz = (-300.0, 1.0) if out else (300.0, -1.0); sign = -1.0 if out else 1.0
    d = json.load(open(f"work/p5d/seam_{w}.json"))
    for n in "AB":
        r = d[n]; Q = np.array(r["Q"]); ok = np.array(r["ok"]) & (np.array(r["depth"]) > 0.35); s = np.array(r["s"]); sc_dep = np.array(r["depth"])
        T = np.gradient(Q, axis=0); T /= np.linalg.norm(T, axis=1)[:, None]; N = np.c_[-T[:, 1], T[:, 0]]
        rng = (s >= (20 if n == "A" else 0)) & (s <= (215 if n == "A" else 145)) & ok
        dep = []; cen = []; pos = []; sg = []
        for i in np.where(rng)[0]:
            X = Q[i, 0] + OFF * N[i, 0]; Y = Q[i, 1] + OFF * N[i, 1]
            rays = np.c_[X, Y, np.full_like(X, z0), np.zeros_like(X), np.zeros_like(X), np.full_like(X, dz)].astype(np.float32)
            t = S.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy(); z = z0 + dz * t
            if not np.isfinite(z).all(): continue
            side = np.abs(OFF) > 2.6
            co = np.polyfit(OFF[side], z[side], 1); dp = sign * ((co[0] * OFF + co[1]) - z)
            k = np.argmax(dp); dep.append(dp[k]); cen.append(OFF[k]); pos.append((Q[i,0],Q[i,1],s[i])); sg.append((s[i],OFF[k],N[i,0],N[i,1]))
        dep = np.array(dep); cen = np.array(cen)
        sg = np.array(sg)
        for a_,b_ in ((0,25),(25,55),(55,110),(110,220)):
            q=(sg[:,0]>=a_)&(sg[:,0]<b_)
            if q.any(): print('   signed CAD-centre minus scan-centre along N=(-Ty,Tx), s %d-%d: median %.2f  N=(%.2f,%.2f)'%(a_,b_,np.median(sg[q,1]),np.median(sg[q,2]),np.median(sg[q,3])))
        bad = [p for p, d_ in zip(pos, dep) if d_ < 0.3]
        if bad: print('   missing groove at s:', sorted(set(int(p[2]) // 10 * 10 for p in bad)), 'e.g.', [tuple(round(c) for c in p) for p in bad[::6]])
        print(w, n, "stations", len(dep), "CAD depth median %.2f p10 %.2f | scan depth median %.2f | CAD groove coverage (depth>0.3) %.0f%% | centre offset |c| p50 %.2f p90 %.2f" % (
            np.median(dep), np.percentile(dep, 10), np.median(sc_dep[rng]), 100 * (dep > 0.3).mean(), np.median(np.abs(cen)), np.percentile(np.abs(cen), 90)))
