import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
D=np.load("work/m2/secs.npz"); Ys=D["Ys"]; R=D["R"]; th=np.degrees(D["th"]); CEN=D["CEN"]
fig,axs=plt.subplots(2,4,figsize=(28,12))
for ax,y in zip(axs.ravel(),(80,100,120,150,180,200,230,250)):
    i=int(np.argmin(abs(Ys-y)));
    # use fixed centre (40,35) polar instead: recompute from points
    P=np.load("work/m2/ext_pts.npy"); q=P[np.abs(P[:,1]-y)<=1.0]
    a=np.degrees(np.arctan2(q[:,2]-35,q[:,0]-40)); r=np.hypot(q[:,0]-40,q[:,2]-35)
    m=np.abs(a)<70; ax.plot(a[m],r[m],'k.',ms=2); ax.set_title(f"Y={y} r(theta) about (40,35)"); ax.grid(True)
plt.tight_layout(); plt.savefig("work/m2/band_profile.png",dpi=45)
