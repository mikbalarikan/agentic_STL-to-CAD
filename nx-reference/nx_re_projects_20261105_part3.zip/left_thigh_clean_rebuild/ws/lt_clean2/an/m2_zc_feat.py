import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from scipy import ndimage as ndi
d=np.load("work/m2/sdev_X72.npz"); S=d["S"]; sd=d["sd"]; ib=d["ib"]
th=np.degrees(np.arctan2(S[:,2]-35,S[:,0]-40)); y=S[:,1]
m=(np.abs(sd)>0.3)&~ib
H=np.zeros((720,260),bool)  # theta 0.5deg x y 1mm from 60
it=((th[m]+180)/0.5).astype(int).clip(0,719); iy=(y[m]-60).astype(int).clip(0,259)
H[it,iy]=True
H=ndi.binary_closing(H,np.ones((3,3)))
lab,n=ndi.label(H,structure=np.ones((3,3)))
feats=[]
for k in range(1,n+1):
    ii=np.argwhere(lab==k)
    if len(ii)<40: continue
    t=ii[:,0]*0.5-180; yy=ii[:,1]+60
    # extent in mm: approximate arc length (r~70-100) along theta + Y
    A=np.c_[t*np.pi/180*85,yy]; A0=A-A.mean(0); u,s,vt=np.linalg.svd(A0,full_matrices=False)
    length=(A0@vt[0]).max()-(A0@vt[0]).min(); width=(A0@vt[1]).max()-(A0@vt[1]).min()
    sel=m&(((th+180)/0.5).astype(int).clip(0,719)[:,None]*0==0)[:,0]
    # signed depth of points in component
    ids=lab[((th+180)/0.5).astype(int).clip(0,719),(y-60).astype(int).clip(0,259)]==k
    ids&=m
    feats.append(dict(id=k,n=len(ii),length=float(length),width=float(width),theta=[float(t.min()),float(t.max())],Y=[float(yy.min()),float(yy.max()),],
        sd_median=float(np.median(sd[ids])) if ids.sum() else None,sd_p10=float(np.percentile(sd[ids],10)) if ids.sum() else None,sd_p90=float(np.percentile(sd[ids],90)) if ids.sum() else None))
feats=sorted(feats,key=lambda f:-f["n"])
for f in feats[:25]: print({k:(np.round(v,1).tolist() if isinstance(v,(list,float)) else v) for k,v in f.items()})
json.dump(feats,open("work/m2/features_raw.json","w"),indent=1)
