import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
D=np.load("work/m3/ext_pts.npz"); P=D['P']; r=D['r']; th=D['th']
yb=np.arange(240,287.1,0.5); res=[]
for t in range(-175,176,5):
    k=(abs(th-t)<2.5)&(P[:,1]>240)
    R=np.array([np.median(r[k&(abs(P[:,1]-y)<0.4)]) if (k&(abs(P[:,1]-y)<0.4)).sum()>3 else np.nan for y in yb])
    if np.isnan(R).any(): continue
    best=(0,None)
    for i,y in enumerate(yb):
        if y<248 or y>280: continue
        a=(yb>=y-7)&(yb<=y-1.5); b=(yb>=y+1.5)&(yb<=y+7)
        sa=np.polyfit(yb[a],R[a],1)[0]; sb=np.polyfit(yb[b],R[b],1)[0]
        d=sa-sb
        if d>best[0]: best=(d,(y,sa,sb))
    if best[1]: res.append((t,best[1][0],best[1][1],best[1][2],np.degrees(np.arctan(best[1][1])-np.arctan(best[1][2]))))
res=np.array(res)
print(' theta  Ycrease  slope_before slope_after  kink_deg')
for r_ in res: print('%5d %7.1f %9.3f %9.3f %7.1f'%tuple(r_))
np.save('work/m3/crease.npy',res)
fig,ax=plt.subplots(1,2,figsize=(18,6)); ax[0].plot(res[:,0],res[:,1],'ko-'); ax[0].set_title('Y of max slope break vs theta'); ax[0].grid(True)
ax[1].plot(res[:,0],res[:,4],'ro-'); ax[1].set_title('slope break (deg)'); ax[1].grid(True); plt.savefig('work/m3/crease.png',dpi=50)
