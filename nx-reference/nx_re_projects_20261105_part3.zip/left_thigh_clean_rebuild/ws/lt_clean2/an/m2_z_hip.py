import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
P=[]
for n,s in (("out_scan","out"),("inn_scan","inn")):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f); ex=np.load(f"work/m2/ext_{s}.npy"); P.append(c[ex])
P=np.vstack(P); np.save("work/m2/ext_pts_all.npy",P)
cols=plt.cm.viridis(np.linspace(0,1,8))
fig,axs=plt.subplots(1,2,figsize=(30,13))
for c,y in zip(cols,(240,250,256,262,268,274,280,286)):
    q=P[np.abs(P[:,1]-y)<=0.5]; axs[0].plot(q[:,0],q[:,2],'.',ms=2,color=c,label=str(y))
axs[0].legend(); axs[0].set_aspect('equal'); axs[0].grid(True)
# extents vs Y
for k,(nm,fn) in enumerate((("xmax",lambda q:q[:,0].max()),("xmin",lambda q:q[:,0].min()),("zmax",lambda q:q[:,2].max()),("zmin",lambda q:q[:,2].min()))):
    yy=np.arange(230,288,1.0); vv=[fn(P[np.abs(P[:,1]-y)<=0.5]) if (np.abs(P[:,1]-y)<=0.5).sum()>20 else np.nan for y in yy]
    axs[1].plot(yy,vv,label=nm)
axs[1].legend(); axs[1].grid(True); axs[1].set_xlabel("Y")
plt.tight_layout(); plt.savefig("work/m2/hip_secs.png",dpi=40)
