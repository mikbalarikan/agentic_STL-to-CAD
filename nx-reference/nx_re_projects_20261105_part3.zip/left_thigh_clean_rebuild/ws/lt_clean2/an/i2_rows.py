"""row collection helpers"""
import json
from i2_fit import *
ROWS = os.path.join(O, "rows"); os.makedirs(ROWS, exist_ok=True)
def r2(x, k=2):
    if isinstance(x, (float, np.floating)): return None if not np.isfinite(x) else round(float(x), k)
    if isinstance(x, (int, np.integer)): return int(x)
    if isinstance(x, (list, tuple, np.ndarray)): return [r2(i, k) for i in x]
    if isinstance(x, dict): return {kk: r2(vv, k) for kk, vv in x.items()}
    return x
def make_row(fid, typ, params, method, residual, mask, p5val, diag=None, rec=None, extra=None):
    save_mask(fid, mask)
    m = metrics(mask)
    row = dict(id=fid, type=typ, params=r2(params), method=method, residual=r2(residual, 3), n_tris=m["n_tris"], mask=f"work\masks\inn_f_{fid}.npy",
               part5_value=r2(p5val), old_p90=m["old_p90"], part5_p90=m["part5_p90"], area_mm2=m["area_mm2"], part5_in05_pct=m["part5_in05"], old_in05_pct=m["old_in05"],
               points_lost=m["points_lost"], diagnosis=diag or "", recommendation=rec or "")
    if extra: row.update(extra)
    return row
def dump(group, rows):
    json.dump(rows, open(os.path.join(ROWS, group + ".json"), "w"), indent=1)
    for r in rows: print(f"{r['id']:16s} {r['type']:10s} p5 {r['part5_p90']} old {r['old_p90']} lost {r['points_lost']:+.3f} n {r['n_tris']}  {r['params'] if len(str(r['params']))<200 else str(r['params'])[:200]}")
