from i2_common import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS, math
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
v,f,c,n,a = scan(); d = de(); p5, old = dev()
m = d>=1.5
def zimg(x0,x1,y0,y1,s, val, vmin, vmax, cmap='turbo', mode='min'):
    mm = m&(c[:,0]>=x0)&(c[:,0]<x1)&(c[:,1]>=y0)&(c[:,1]<y1)
    X=((c[mm,0]-x0)*s).astype(int); Y=((c[mm,1]-y0)*s).astype(int)
    H=int((y1-y0)*s)+1; Wd=int((x1-x0)*s)+1
    im=np.full((H,Wd),np.nan); o=np.argsort(-val[mm] if mode=='min' else val[mm]); im[Y[o],X[o]]=val[mm][o]
    from scipy import ndimage as ndi
    nanm=np.isnan(im)
    if nanm.any():
        idx=ndi.distance_transform_edt(nanm,return_distances=False,return_indices=True)
        far=ndi.distance_transform_edt(nanm)>3
        im=im[tuple(idx)]; im[far]=np.nan
    return im
def overlay(ax):
    for k,(x,y) in DS.BOSSES.items():
        ax.add_patch(plt.Circle((x,y),7.5,fill=False,ec='w',lw=.8)); ax.text(x,y,k,color='w',fontsize=7,ha="center",clip_on=True)
    for k,(a_,b_,w) in {**{k:(v_[0],v_[2],3) for k,v_ in DS.ARMS.items()}}.items():
        ax.plot([a_[0],b_[0]],[a_[1],b_[1]],'w-',lw=.6)
    for k,(p0,p1,z0,z1,t) in DS.INN_GUSSETS.items(): ax.plot([p0[0],p1[0]],[p0[1],p1[1]],'m-',lw=.8); ax.text(*p0,k,color='m',fontsize=6,clip_on=True)
    for k,(p0,p1,z,t) in DS.INN_RIBS.items(): ax.plot([p0[0],p1[0]],[p0[1],p1[1]],'c-',lw=.8); ax.text(*p0,k,color='c',fontsize=6,clip_on=True)
    for k,(x,y) in DS.KNEE_COVER_PINS.items(): ax.add_patch(plt.Circle((x,y),1.5,fill=False,ec='k')); ax.text(x,y,k,fontsize=6,clip_on=True)
    for k,(x,y) in DS.HIP_PINS.items(): ax.add_patch(plt.Circle((x,y),2,fill=False,ec='k')); ax.text(x,y,k,fontsize=6,clip_on=True)
    for k,(x,y) in DS.CH_HOLES.items(): ax.add_patch(plt.Circle((x,y),3,fill=False,ec='k',lw=.5)); ax.text(x,y,k,fontsize=6,clip_on=True)
    for k,(x,y,*_) in DS.PINS.items(): ax.add_patch(plt.Circle((x,y),4.5,fill=False,ec='w',ls=':')); ax.text(x,y,k,color='w',fontsize=6,clip_on=True)
    for r in (DS.CH_R_IN,DS.CH_R_OUT):
        t=np.radians(np.linspace(DS.CH_A_TOP,330,100)); ax.plot(r*np.cos(t),r*np.sin(t),'y-',lw=.6)
    ax.plot([DS.CH_J_IN[0],DS.CH_TOP_L[0]],[DS.CH_J_IN[1],DS.CH_TOP_L[1]],'y-',lw=.6); ax.plot([DS.CH_J_OUT[0],DS.CH_TOP_R[0]],[DS.CH_J_OUT[1],DS.CH_TOP_R[1]],'y-',lw=.6)
    for a_ in DS.SPOKES_IN: ax.plot([10.5*math.cos(math.radians(a_)),DS.CH_R_IN*math.cos(math.radians(a_))],[10.5*math.sin(math.radians(a_)),DS.CH_R_IN*math.sin(math.radians(a_))],'g-',lw=.6)
    for a_ in DS.SPOKES_OUT: ax.plot([DS.CH_R_OUT*math.cos(math.radians(a_)),66.5*math.cos(math.radians(a_))],[DS.CH_R_OUT*math.sin(math.radians(a_)),66.5*math.sin(math.radians(a_))],'g-',lw=.6)
ZR={"knee":(70,92),"mid":(60,92),"hip":(60,95)}
REG={"knee":(-72,122,-72,92),"mid":(-60,122,80,190),"hip":(-60,122,175,292)}
if __name__=="__main__":
    for name,(x0,x1,y0,y1) in REG.items():
        s=6
        for kind in ("z","dev"):
            if kind=="z": im=zimg(x0,x1,y0,y1,s,c[:,2],0,0,'turbo','min')
            else: im=zimg(x0,x1,y0,y1,s,np.minimum(p5,2.0),0,1.5,'turbo','max')
            fig,ax=plt.subplots(figsize=(15,15*(y1-y0)/(x1-x0)))
            ax.imshow(im,origin='lower',extent=[x0,x1,y0,y1],cmap='turbo',vmin=(ZR[name][0] if kind=='z' else 0),vmax=(ZR[name][1] if kind=='z' else 1.5))
            overlay(ax); ax.set_xlim(x0,x1); ax.set_ylim(y0,y1); ax.set_title(name+" "+kind)
            plt.tight_layout(); plt.savefig(os.path.join(O,f"zoom_{name}_{kind}.png"),dpi=70); plt.close()
