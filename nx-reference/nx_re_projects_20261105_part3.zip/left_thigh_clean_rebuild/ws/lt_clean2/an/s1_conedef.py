"""True cone (primitive) of the hip shoulders: axis point at the mouth plane, tilt about Z, half angle, mouth radius."""
import numpy as np
from scipy.optimize import brentq
CONE = dict(X0=39.4, Z0=35.0, Ym=287.39, tau=2.2, R0=70.97, alpha=24.8)   # deg
def axis(c=CONE):
    t = np.radians(c['tau']); u = np.array([np.sin(t), np.cos(t), 0.0]); return np.array([c['X0'], c['Ym'], c['Z0']]), u
def rho(Y, x, z, c=CONE):
    """signed radial gap to the cone (perpendicular to the axis): >0 outside the cone surface"""
    A0, u = axis(c); P = np.stack(np.broadcast_arrays(x, Y, z), -1) - A0
    s = P @ u; perp = np.linalg.norm(P - s[..., None] * u, axis=-1)
    return perp - (c['R0'] - np.tan(np.radians(c['alpha'])) * s)
def ray_point(Y, th, off, CX0=40.0, CZ0=35.0, c=CONE):
    f = lambda t: float(rho(Y, CX0 + t * np.cos(th), CZ0 + t * np.sin(th), c)) - off
    t = brentq(f, 20, 250); return CX0 + t * np.cos(th), CZ0 + t * np.sin(th)
