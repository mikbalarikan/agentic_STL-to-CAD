import json,sys,re
which=sys.argv[1]; new=sys.argv[2]; base=sys.argv[3]   # gate tags
A=json.load(open('work/gates/%s.json'%new)); B=json.load(open('work/gates/%s.json'%base))
L=['%s zones P5c: %s'%(which,{k:v['new'] for k,v in A['zones'].items()}),
   '%s zones P5b(x preview, previous run): %s   (old %s, p5 %s)'%(which,{k:v['new'] for k,v in B['zones'].items()},{k:v['old'] for k,v in A['zones'].items()},{k:v['p5'] for k,v in A['zones'].items()}),
   '%s CAD->scan p50/p90/within0.5  P5c %.3f/%.2f/%.1f   P5b_x %.3f/%.2f/%.1f'%(which,A['cad_to_scan']['p50'],A['cad_to_scan']['p90'],A['cad_to_scan']['within05'],B['cad_to_scan']['p50'],B['cad_to_scan']['p90'],B['cad_to_scan']['within05']),
   'G-feat P5c %d/%d   P5b_x %d/%d'%(A['n_feat']-A['n_feat_fail'],A['n_feat'],B['n_feat']-B['n_feat_fail'],B['n_feat']),
   '%-26s %6s %7s %8s %7s %7s  flag'%('mask','n','P5c','P5b_x','old','part5')]
for k,v in sorted(A['features'].items()):
    b=B['features'].get(k)
    if b is None: continue
    fl=''
    if v['new']>0.5: fl+='>0.5 '
    if v['new']>b['new']+0.05: fl+='WORSE '
    if v['new']<=0.5 and b['new']>0.5: fl+='fixed'
    L.append('%-26s %6d %7.2f %8.2f %7.2f %7.2f  %s'%(k,v['n'],v['new'],b['new'],v['old'],v['p5'],fl))
print('\n'.join(L))
