from i2_fit import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
for nm,(p0,p1) in (("L",(DS.CH_J_IN,DS.CH_TOP_L)),("R",(DS.CH_J_OUT,DS.CH_TOP_R))):
    print(nm,[ (round(u),z) for u,z,nn in profile_along(p0,p1,-0.8,0.8,10.0)])
# floor between ribs: centre line mid
mid0=((DS.CH_J_IN[0]+DS.CH_J_OUT[0])/2,(DS.CH_J_IN[1]+DS.CH_J_OUT[1])/2); mid1=((DS.CH_TOP_L[0]+DS.CH_TOP_R[0])/2,135)
print("floor mid",[(round(u),z) for u,z,nn in profile_along(mid0,mid1,-2.5,2.5,10.0)])
