"""P4 mask table: % of scan area within 0.5 mm (scan->CAD) for new / old / part 5 on the joint masks and the panel zone.
argv: tag(p4out|p4inn) which"""
import sys, os, glob, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
tag, which = sys.argv[1:3]
v, f = lib.load({"out": "out_scan", "inn": "inn_scan"}[which], 1500000)
c, nn, ar = lib.tri_data(v, f); w = ar / ar.sum()
new = np.load(os.path.join(lib.W, f"dev_{tag}_{which}.npz"))["d1"]
REF = {"out": {"old": "dev_oldC.npz", "p5": "dev_FINout.npz"}, "inn": {"old": "dev_oldInnB.npz", "p5": "dev_FINinn.npz"}}[which]
D = {"new": new}
for k, fn in REF.items():
    D[k] = np.load(os.path.join(lib.W, fn))["d1"]
def pct(m, d): return float(w[m & (d < 0.5)].sum() / w[m].sum() * 100)
def p90(m, d):
    dd, ww = d[m], w[m]; o = np.argsort(dd); cw = np.cumsum(ww[o]) / ww.sum(); return float(dd[o][min(np.searchsorted(cw, 0.9), len(o) - 1)])
rows = {}
names = sorted(set(os.path.basename(p)[len(which) + 1:-4] for p in glob.glob(os.path.join(lib.W, "masks", f"{which}_*.npy"))))
sel = [n for n in names if any(k in n.lower() for k in ("joint", "tongue", "rebate", "lip", "band"))]
print(f"{'mask':34s} {'n':>7s} " + " ".join(f"{k:>7s}" for k in D) + "   (% within 0.5)   p90 new")
for n in sel:
    m = np.zeros(len(c), bool); m[np.load(os.path.join(lib.W, "masks", f"{which}_{n}.npy"))] = True
    if m.sum() == 0: continue
    rows[n] = {"n": int(m.sum()), **{k: round(pct(m, d), 1) for k, d in D.items()}, "p90_new": round(p90(m, D["new"]), 3)}
    print(f"{n:34s} {m.sum():7d} " + " ".join(f"{rows[n][k]:7.1f}" for k in D) + f"   {rows[n]['p90_new']:.2f}")
json.dump(rows, open(os.path.join(lib.W, "gates", f"{tag}_masks_{which}.json"), "w"), indent=1)
