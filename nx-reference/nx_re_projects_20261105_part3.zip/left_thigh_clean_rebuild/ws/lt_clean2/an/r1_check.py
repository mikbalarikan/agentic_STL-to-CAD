"""r1 self-check of the +X panel on nx/A_v2/<w>_A.stl : boundary vs scan edge (p90), depth, end-region floor.  argv: tag"""
import sys, os, json, numpy as np, trimesh, open3d as o3d
from scipy.spatial import cKDTree
from scipy.ndimage import median_filter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
AX, AZ = 37.97, 35.18
tag = sys.argv[1]
def sc(m):
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32))); return s
def cast(s, o, dd):
    a = s.cast_rays(o3d.core.Tensor(np.hstack([o, dd]).astype(np.float32))); return a["t_hit"].numpy(), a["primitive_normals"].numpy()
se = sc(trimesh.load("nx/base_v2/envelope.stl", process=False))
def depthgrid(ss, sg, ys, ths):
    Y, T = np.meshgrid(ys, np.radians(ths), indexing="ij")
    dv = np.stack([np.cos(T), np.zeros_like(T), sg*np.sin(T)], -1).reshape(-1, 3)
    o = np.stack([np.full(Y.size, AX), Y.ravel(), np.full(Y.size, AZ)], 1) + 500*dv
    te, ne = cast(se, o, -dv); tm, _ = cast(ss, o, -dv)
    ne = ne/np.linalg.norm(ne, axis=1, keepdims=True)
    return ((tm-te)*np.abs((ne*dv).sum(1))).reshape(Y.shape), (500-te).reshape(Y.shape)
def edges(ss, sg):
    ths = np.arange(0.5, 50.0, 0.1); ys = np.arange(53.0, 262.6, 0.25); D, Rr = depthgrid(ss, sg, ys, ths); P = []
    for i, y in enumerate(ys):
        floor = np.median(D[i, (ths > 2) & (ths < 6)]); floor = 1.09 if y < 249 else min(max(floor, 1.0), 2.3)
        if floor < 0.9: continue
        rec = D[i] > 0.5*floor
        if rec[:20].sum() < 5: continue
        k0 = np.argmax(rec)
        for q in range(k0, len(ths)-2):
            if rec[q:q+2].sum() == 0: P.append((y, ths[q], Rr[i, q])); break
    return np.array(P)
def poly(P):
    P = P[~((P[:, 0] > 242.5) & (P[:, 0] < 249.5))]
    return np.c_[P[:, 0], P[:, 2]*np.radians(P[:, 1])]
out = {}
for w, sg in (("out", -1), ("inn", 1)):
    v, f = lib.load(w + "_scan", 1500000); ssn = sc(trimesh.Trimesh(v, f, process=False))
    cm = trimesh.load(f"nx/A_v2/{w}_A.stl"); scad = sc(cm)
    Es, Ec = edges(ssn, sg), edges(scad, sg)
    ps, pc = poly(Es), poly(Ec)
    # restrict scan polyline to its clean y-range 53.5..262; distance both ways
    d1 = cKDTree(pc).query(ps)[0]; d2 = cKDTree(ps).query(pc)[0]
    print(f"[{w}] boundary scan->CAD edge: p50 {np.median(d1):.2f} p90 {np.percentile(d1,90):.2f} max {d1.max():.2f} | CAD->scan p90 {np.percentile(d2,90):.2f} max {d2.max():.2f}  (n {len(ps)}/{len(pc)})")
    for lo, hi in ((53.5, 261.5), (56, 258), (53.5, 70), (70, 240), (240, 261.5)):
        k = (ps[:, 0] >= lo) & (ps[:, 0] <= hi)
        if k.any(): print(f"   y {lo}-{hi}: n {k.sum()} p50 {np.median(d1[k]):.2f} p90 {np.percentile(d1[k],90):.2f} max {d1[k].max():.2f}")
    for y0 in (60, 70, 80, 90, 100, 110, 124.5, 135, 150, 165, 180, 195, 210, 220, 231, 240):
        a = Es[np.argmin(abs(Es[:, 0]-y0))]; b = Ec[np.argmin(abs(Ec[:, 0]-y0))]
        print(f"      y {y0}: scan theta {a[1]:.2f} CAD theta {b[1]:.2f}  diff {b[1]-a[1]:+.2f} deg")
    worst = np.argsort(-d1)[:4]; print("   worst y:", [(round(float(ps[i, 0]), 1), round(float(d1[i]), 2)) for i in worst])
    # depth interior
    ys = np.arange(75, 241, 3.0); ths = np.arange(6, 36, 1.0)
    BT = np.array([(53.5, 8.5), (59, 27.5), (80, 38), (124.5, 40.5), (150, 38.5), (210, 31.5), (249.5, 24.5)])
    mask = np.array([[t < np.interp(y, BT[:, 0], BT[:, 1]) - 6 for t in ths] for y in ys])
    for nm, ss_ in (("scan", ssn), ("CAD", scad)):
        dn, _ = depthgrid(ss_, sg, ys, ths); d = dn[mask]; d = d[(d > 0.6) & (d < 1.8)]
        print(f"[{w}] floor depth {nm}: p50 {np.median(d):.3f} mean {d.mean():.3f} (n {len(d)})")
    # end region floor profile CAD vs scan at theta 3,6,9,12
    yy = np.arange(248, 263.1, 0.5); rows = []
    for th in (3, 6, 9, 12):
        a, _ = depthgrid(ssn, sg, yy, [th]); b, _ = depthgrid(scad, sg, yy, [th]); a = a[:, 0]; b = b[:, 0]
        k = yy < 261.0
        rows.append((th, float(np.sqrt(np.mean((a[k]-b[k])**2))), float(np.abs(a[k]-b[k]).max())))
    print(f"[{w}] end region (y 248..261) depth CAD vs scan rms/max per theta:", [(t, round(r, 2), round(m, 2)) for t, r, m in rows])
    print(f"[{w}] end wall y (half depth) at theta 5,8: ", end="")
    for th in (5, 8):
        yy2 = np.arange(255, 266, 0.05)
        for nm, ss_ in (("scan", ssn), ("CAD", scad)):
            a, _ = depthgrid(ss_, sg, yy2, [th]); a = a[:, 0]; mx = a.max(); k = np.where(a > 0.5*mx)[0]; print(f"{nm} {yy2[k[-1]]:.2f} (max depth {mx:.2f})", end=" | ")
    print()
    for th in (5, 8):
        yy3 = np.arange(48, 60, 0.05)
        for nm, ss_ in (("scan", ssn), ("CAD", scad)):
            a, _ = depthgrid(ss_, sg, yy3, [th]); a = a[:, 0]; k = np.where(a > 0.55)[0]; print(f"   start wall theta {th} {nm}: y {yy3[k[0]]:.2f}", end="")
    print()
    out[w] = {"edge_p50": float(np.median(d1)), "edge_p90": float(np.percentile(d1, 90)), "edge_max": float(d1.max())}
json.dump(out, open(f"work/gates/{tag}_panel_check.json", "w"), indent=1)
