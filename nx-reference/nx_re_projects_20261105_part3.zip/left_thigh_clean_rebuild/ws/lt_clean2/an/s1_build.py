"""Build envelope B-rep: (loft ∩ cone) ∪ drum. usage: s1_build.py loft_tag out_tag"""
import sys, os, time, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_geo import *
from s1_lib import S1, W
HX, HZ, YM = 37.97, 35.18, 287.39
import s1_conedef as CD
def cone_solid(c=None, H=360.0, over=4.0):
    c = c or CD.CONE
    A0, u = CD.axis(c); k = np.tan(np.radians(c['alpha']))
    B = A0 + over * u; Rb = c['R0'] - k * over
    ax = gp_Ax2(gp_Pnt(*B), gp_Dir(*(-u)))
    return BRepPrimAPI_MakeCone(ax, Rb, Rb + k * H, H).Shape()
def build(tag, cone=True, out=None, drum_kw=None, verbose=True):
    d = np.load(os.path.join(S1, f'loft_{tag}.npz')); st, P = d['st'], d['P']
    t0 = time.time(); lo = loft(P, st); 
    if verbose: print('loft', valid(lo), round(volume(lo)), round(time.time() - t0, 1))
    body = lo
    if cone:
        body = common(lo, cone_solid()); 
        if verbose: print('common', valid(body), round(volume(body)), round(time.time() - t0, 1))
    dr = drum(**(drum_kw or {}))
    env = fuse(body, dr)
    if verbose: print('fuse', valid(env), round(volume(env)), round(time.time() - t0, 1))
    return env, lo, body, dr
if __name__ == '__main__':
    tag = sys.argv[1]; out = sys.argv[2] if len(sys.argv) > 2 else tag
    env, lo, body, dr = build(tag)
    save_stl(env, os.path.join(S1, f'env_{out}.stl'), 0.03, 0.05)
    print('saved')
