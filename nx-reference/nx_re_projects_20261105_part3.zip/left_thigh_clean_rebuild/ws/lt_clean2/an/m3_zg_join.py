import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
D=np.load("work/m3/ext_pts.npz"); P=D['P']; r=D['r']; th=D['th']
rows={}
angs=list(range(-165,166,30))
print('theta  | Y=250: R slope curv | Y=258 | Y=262 | Y=266 | Y=272 | mouth')
for t in angs:
    k=(abs(th-t)<3)
    line=[]
    for y in (250,258,262,266,272):
        kk=k&(abs(P[:,1]-y)<5)
        if kk.sum()<30: line.append((np.nan,)*3); continue
        co=np.polyfit(P[kk,1]-y,r[kk],2); line.append((co[2],co[1],2*co[0]))
    rows[t]=line
    print('%5d | '%t+' | '.join('%.2f %.3f %.4f'%l for l in line))
json.dump({str(k):v for k,v in rows.items()},open('work/m3/join_slopes.json','w'))
