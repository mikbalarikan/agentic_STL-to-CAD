import numpy as np, math, open3d as o3d
mesh = o3d.io.read_triangle_mesh(r"nx/base_v2/envelope.stl")
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mesh))
hx,hz=37.97,35.18
base=np.array([39.5536,291.3871,35.0]); d=np.array([-0.03839,-0.99926,0]); d/=np.linalg.norm(d)
for sgn in (1,-1):
  for y in (240,250,255,257,259):
    row=[]
    for th in (0,10,20,30):
        t=math.radians(th)
        ray=o3d.core.Tensor([[hx,y,hz,math.cos(t),0,-sgn*math.sin(t)]],dtype=o3d.core.Dtype.Float32)
        r=float(sc.cast_rays(ray)["t_hit"].numpy()[0])
        p=np.array([hx+r*math.cos(t),y,hz-sgn*r*math.sin(t)])
        v=p-base; s=v@d; rad=np.linalg.norm(v-s*d)
        cone_r=69.1217+0.46206*s
        row.append(round(rad-cone_r,2))
    print(sgn,y,row)
