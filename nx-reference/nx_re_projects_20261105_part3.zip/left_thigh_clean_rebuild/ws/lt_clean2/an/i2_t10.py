from i2_rows import *
for bid,cc in (("B6",(97.95,264.95)),("B7",(-22.0,264.93)),("B1",(61.35,-40.01))):
    r=np.hypot(c[:,0]-cc[0],c[:,1]-cc[1])
    m=(r<5.6)&(d>=0.3)&(c[:,2]>39.4)
    print(bid)
    for z0 in range(40,110,6):
        s=m&(c[:,2]>=z0)&(c[:,2]<z0+6)
        if s.sum()>20:
            rr=r[s]; print("  z",z0,"n",s.sum(),"p5 p90",round(p90(p5[s]),2),"r med",round(np.median(rr),2),"r p10-p90",np.round(np.percentile(rr,[10,90]),2), "nz med",round(np.median(n[s,2]),2), "d med",round(np.median(d[s]),1))
