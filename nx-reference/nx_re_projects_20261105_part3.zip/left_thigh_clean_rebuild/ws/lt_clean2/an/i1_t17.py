from i1_core import *
hx,hz=37.97,35.18
rr=np.hypot(c[:,0]-hx,c[:,2]-hz); phi=np.degrees(np.arctan2(c[:,2]-hz,c[:,0]-hx))%360
m=(abs(c[:,1]-276.85)<0.2)&(n[:,1]>0.95)&(rr>44.7)&(rr<46.7)
h,ed=np.histogram(phi[m],bins=720,range=(0,360),weights=a[m])
gap=h<0.02*h.max()
# segments of gaps
segs=[];i=0
while i<720:
    if gap[i]:
        j=i
        while j<720 and gap[j]: j+=1
        segs.append((ed[i],ed[j])); i=j
    else: i+=1
print(len(segs)); print([ (round(s0,1),round(s1,1),round(s1-s0,1)) for s0,s1 in segs])
mid=np.array([(s0+s1)/2 for s0,s1 in segs]); w=np.array([s1-s0 for s0,s1 in segs])
print("mean width deg",w.mean(),"-> counterbore D approx",2*45.7*np.sin(np.radians(w.mean()/2)))
d=np.diff(mid); print("pitch",np.median(d), "phase",np.median(mid%(360/26)))
