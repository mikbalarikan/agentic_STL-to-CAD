import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from scipy.optimize import least_squares
HX,HZ=37.97,35.18; YM=287.39
D=np.load("work/m3/ext_pts.npz"); P=D['P']; r=D['r']; th=D['th']
cr=np.load('work/m3/crease.npy')
def ycrease(t):
    a=abs(t); 
    return 266.0 if a>130 or a<20 else None
lat=((abs(th)<18)|(abs(th)>135))&(P[:,1]>270)&(P[:,1]<287.0)
X=P[lat]; print('lateral points',len(X))
def cone_res(p,X):
    x0,z0,tx,tz,R0,t=p   # axis passes (x0,YM,z0) direction (tx,1,tz) normalised; radius at mouth plane R0; slope t=dR/d(-s)
    d=np.array([tx,1.0,tz]); d/=np.linalg.norm(d)
    q=X-np.array([x0,YM,z0]); s=q@d; perp=q-np.outer(s,d); rho=np.linalg.norm(perp,axis=1)
    # distance to cone surface: rho = R0 - t*s  (s negative towards body) -> use geometric approx
    c=np.cos(np.arctan(t)); return (rho-(R0-t*s))*c
for name,p0 in (('free',[HX,HZ,0.0,0.0,70.85,0.42]),):
    s=least_squares(cone_res,p0,args=(X,)).x; e=cone_res(s,X)
    print('general cone fit (lateral zones, Y 270-287):',s.round(4),'res std %.3f p95 %.3f'%(e.std(),np.percentile(abs(e),95)),'half angle %.2f deg'%np.degrees(np.arctan(s[5])))
    # constrain axis through hip axis (revolve cone about hip axis, no tilt)
    s2=least_squares(lambda q:cone_res([HX,HZ,0,0,q[0],q[1]],X),[70.85,0.42]).x; e2=cone_res([HX,HZ,0,0,*s2],X)
    print('coaxial cone (revolve about hip axis): R0=%.3f t=%.4f half angle %.2f deg res std %.3f p95 %.3f'%(s2[0],s2[1],np.degrees(np.arctan(s2[1])),e2.std(),np.percentile(abs(e2),95)))
    # per side
    for nm,mm in (('+X side |th|<18',abs(X[:,0]-HX)>0)&(np.abs(np.degrees(np.arctan2(X[:,2]-HZ,X[:,0]-HX)))<18),('-X side |th|>135',np.abs(np.degrees(np.arctan2(X[:,2]-HZ,X[:,0]-HX)))>135)):
        s3=least_squares(lambda q:cone_res([HX,HZ,0,0,q[0],q[1]],X[mm]),[70.85,0.42]).x; e3=cone_res([HX,HZ,0,0,*s3],X[mm])
        print('  coaxial cone, %s: R0=%.3f t=%.4f (%.2f deg) res std %.3f'%(nm,s3[0],s3[1],np.degrees(np.arctan(s3[1])),e3.std()))
json.dump(dict(general=list(map(float,s)),coaxial=list(map(float,s2))),open('work/m3/cone_fit.json','w'))
