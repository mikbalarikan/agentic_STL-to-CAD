from s1_lib import *
from scipy.optimize import least_squares
d=np.load(os.path.join(S1,'ext_all.npz')); P=d['P']; A=d['a']; x,y,z=P.T
HX,HZ=37.97,35.18
phi=np.degrees(np.arctan2(z-HZ,x-HX))
wedge=(np.abs(phi)<25)|(np.abs(phi)>118)
m=wedge&(y>270)&(y<286.8)
Q=P[m]; Aq=A[m]
def res(p,Q):
    X0,Z0,tx,tz,R0,k=p
    dy=Q[:,1]-287.39
    return np.hypot(Q[:,0]-(X0+tx*dy),Q[:,2]-(Z0+tz*dy))-(R0-k*dy)
p0=[38,35.2,0,0,70.9,0.46]
for it in range(4):
    r=res(p0,Q); keep=np.abs(r)<max(0.5,2.5*np.median(np.abs(r)))
    s=least_squares(res,p0,args=(Q[keep],)); p0=s.x
    print(it,keep.mean(),np.round(p0,4),np.std(res(p0,Q[keep])))
r=res(p0,Q); print('within .3',(np.abs(r)<.3).mean(),'p95',np.percentile(np.abs(r),95))
# coaxial with tilt only
for fix in ['axis=hip, no tilt']:
    def res2(p,Q):
        R0,k=p; dy=Q[:,1]-287.39
        return np.hypot(Q[:,0]-HX,Q[:,2]-HZ)-(R0-k*dy)
    s=least_squares(res2,[70.9,0.46],args=(Q,)); print(fix,s.x,np.std(s.fun))
np.save(os.path.join(S1,'cone_p.npy'),p0)
print('---- constrained: axis through hip axis point at mouth, free tx, R0, k')
def res3(p,Q):
    tx,R0,k=p; dy=Q[:,1]-287.39
    return np.hypot(Q[:,0]-(HX+tx*dy),Q[:,2]-HZ)-(R0-k*dy)
q=[0.04,71.0,0.46]
for it in range(4):
    r=res3(q,Q); keep=np.abs(r)<max(0.5,2.5*np.median(np.abs(r)))
    s=least_squares(res3,q,args=(Q[keep],)); q=s.x
print(np.round(q,4),np.std(res3(q,Q[keep])), 'half-angle',np.degrees(np.arctan(q[2])),'tilt deg',np.degrees(np.arctan(q[0])))
for tx,R0,k in [(0.0436,71.0,0.4663),(0.0437,71.0,0.4663),(0.04,70.95,0.46),(0.0436,70.9,0.4663)]:
    r=res3([tx,R0,k],Q); kp=np.abs(r)<0.8; print(tx,R0,k,'med|r|',np.median(np.abs(r[kp])).round(3),'std',np.std(r[kp]).round(3),'frac<.3',(np.abs(r)<.3).mean().round(3))
