"""I1 common: scan data, deviations, envelope distance (cached)."""
import os, sys, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
W = lib.W; I1 = os.path.join(W, "i1"); os.makedirs(I1, exist_ok=True)
MASKS = os.path.join(W, "masks")

def load_all():
    v, f = lib.load("out_scan", 1500000)
    c, n, a = lib.tri_data(v, f)
    p = os.path.join(I1, "cache.npz")
    if os.path.exists(p):
        z = np.load(p); de = z["de"]
    else:
        import trimesh, open3d as o3d
        env = trimesh.load(os.path.join(W, "env_part5.stl"), process=False)
        sc = o3d.t.geometry.RaycastingScene()
        sc.add_triangles(o3d.core.Tensor(np.asarray(env.vertices, np.float32)), o3d.core.Tensor(np.asarray(env.faces, np.uint32)))
        de = sc.compute_distance(o3d.core.Tensor(c.astype(np.float32))).numpy()
        np.savez(p, de=de)
    d5 = np.load(os.path.join(W, "dev_FINout.npz"))["d1"]
    d0 = np.load(os.path.join(W, "dev_oldC.npz"))["d1"]
    return dict(v=v, f=f, c=c, n=n, a=a, de=de, d5=d5, d0=d0)

def p90(d, m, w=None):
    x = d[m]
    return float(np.percentile(x, 90)) if len(x) else float("nan")

def plot_win(S, xlim, ylim, out, min_de=2.0, cols=("z", "d5"), size=9, extra=None):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    c = S['c']; m = (S['de'] > min_de) & (c[:, 0] > xlim[0]) & (c[:, 0] < xlim[1]) & (c[:, 1] > ylim[0]) & (c[:, 1] < ylim[1])
    idx = np.where(m)[0]; idx = idx[np.argsort(c[idx, 2])]
    asp = (ylim[1]-ylim[0])/(xlim[1]-xlim[0])
    fig, axs = plt.subplots(1, len(cols), figsize=(size*len(cols)/ max(asp,.5)**0.0*0.55*2, size*asp*0.55*2))
    for ax, nm in zip(np.atleast_1d(axs), cols):
        col = {"z": c[:, 2], "d5": S['d5'], "d0": S['d0']}[nm]
        kw = dict(cmap="turbo", vmin=-30, vmax=40) if nm == "z" else dict(cmap="jet", vmin=0, vmax=2)
        sc = ax.scatter(c[idx, 0], c[idx, 1], c=col[idx], s=1.5, linewidths=0, **kw)
        ax.set_xlim(xlim); ax.set_ylim(ylim); ax.set_aspect('equal'); ax.grid(True, alpha=.3); ax.set_title(nm)
        plt.colorbar(sc, ax=ax, shrink=.5)
        if extra: extra(ax)
    fig.savefig(out, dpi=80, bbox_inches='tight'); plt.close(fig)
