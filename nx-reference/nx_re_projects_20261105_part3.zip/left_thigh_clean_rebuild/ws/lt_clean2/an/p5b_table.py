import json, re, sys
which = sys.argv[1]
pure, xx = sys.argv[2], sys.argv[3]
pat = {'out': r'^(BOSS_B|ARM_ARM|FLG_|PIN_P|EAR_B1|RIB_R_|GUS_G|LOWRIB|TAB_|CLIP|PAD_RIGHT|FLOORHOLE|KNEE_|HIP_PLATE|COVERPIN|HIP_RING_BORE)',
       'inn': r'^(B\d_col|ARM_B|P\d_lug_inn|FL_KNEE|MISS_B1|I_|IG_|LUG_|KNEE_DISC|HUB_UNDER|CH_(RING|RUN|H\d)|SPOKE|MISS_B2|MISS_ARC|HIP_WEB|HIP_BLOCK|HIP_PAD|HIP_RING_CLEAR)'}[which]
A = json.load(open('work/gates/%s.json' % pure)); B = json.load(open('work/gates/%s.json' % xx))
L = ['%s zones pure: %s' % (which, {k: v['new'] for k, v in A['zones'].items()}),
     '%s zones +preview: %s   (old %s, p5 %s)' % (which, {k: v['new'] for k, v in B['zones'].items()}, {k: v['old'] for k, v in B['zones'].items()}, {k: v['p5'] for k, v in B['zones'].items()}),
     '%s CAD->scan p50/p90/within0.5  pure %.3f/%.2f/%.1f  +preview %.3f/%.2f/%.1f' % (which, A['cad_to_scan']['p50'], A['cad_to_scan']['p90'], A['cad_to_scan']['within05'], B['cad_to_scan']['p50'], B['cad_to_scan']['p90'], B['cad_to_scan']['within05']),
     '%-24s %6s %7s %8s %7s %7s' % ('mask', 'n', 'pure', '+preview', 'old', 'part5')]
for k, v in sorted(A['features'].items()):
    if re.search(pat, k) and not k.endswith('_root') and 'CAP' not in k and k != 'ARM_B2_D_SHELF':
        vb = B['features'][k]
        flag = '' if vb['new'] <= 0.5 else '  *'
        L.append('%-24s %6d %7.2f %8.2f %7.2f %7.2f%s' % (k, v['n'], v['new'], vb['new'], v['old'], v['p5'], flag))
print('\n'.join(L))
