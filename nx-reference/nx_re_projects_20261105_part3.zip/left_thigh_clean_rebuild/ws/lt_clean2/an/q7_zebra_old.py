import sys, numpy as np, trimesh, pyvista as pv
sys.path.insert(0,"an"); import lib
pv.OFF_SCREEN=True
for w,nm in (("out","out_cad"),("inn","inn_cad")):
    v,f=lib.load(nm)
    M=trimesh.Trimesh(v,f,process=True); pm=pv.wrap(M); nn=M.vertex_normals
    d=np.array([1,0.15,0.1]); d/=np.linalg.norm(d); vdir=-d
    R=vdir[None,:]-2*(nn@vdir)[:,None]*nn; pm.point_data["zeb"]=np.sin(np.arcsin(np.clip(R[:,2],-1,1))*18)
    p=pv.Plotter(off_screen=True,window_size=(1500,1000)); p.set_background("white")
    p.add_mesh(pm,scalars="zeb",cmap="gray",clim=(-0.2,0.2),interpolate_before_map=True,smooth_shading=True,show_scalar_bar=False,ambient=0.9,diffuse=0.0,specular=0)
    c0=np.array(pm.center); p.camera.position=tuple(c0+d*900); p.camera.focal_point=tuple(c0); p.camera.up=(0,0,1); p.camera.parallel_projection=True; p.camera.parallel_scale=190
    p.screenshot(f"work/q7/zebra_oldmaster_{w}_PX.png"); p.close()
