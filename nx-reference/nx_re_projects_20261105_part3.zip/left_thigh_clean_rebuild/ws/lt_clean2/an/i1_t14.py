from i1_core import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
v,f=S['v'],S['f']
E=np.sort(np.r_[f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]],axis=1)
key=E[:,0]*len(v)+E[:,1]
u,cnt=np.unique(key,return_counts=True)
b=u[cnt==1]; be=np.c_[b//len(v),b%len(v)]
print("boundary edges",len(be))
np.save(os.path.join(I1,"bedges.npy"),be)
mid=(v[be[:,0]]+v[be[:,1]])/2
fig,ax=plt.subplots(1,2,figsize=(18,9))
ax[0].scatter(mid[:,0],mid[:,1],s=1); ax[0].set_aspect('equal'); ax[0].set_title("plan")
ax[1].scatter(mid[:,1],mid[:,2],s=1,c=mid[:,0],cmap='coolwarm'); ax[1].set_aspect('equal'); ax[1].set_title("y-z")
fig.savefig(os.path.join(I1,"bedges.png"),dpi=55,bbox_inches='tight')
