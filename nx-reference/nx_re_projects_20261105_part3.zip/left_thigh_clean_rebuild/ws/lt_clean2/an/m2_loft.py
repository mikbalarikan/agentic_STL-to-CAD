"""Tensor loft model of the body exterior: K stations (Y_k), each a closed periodic cubic uniform B-spline section
with NP poles (x,z); between stations cubic-spline interpolation of the poles in Y (like NX Through Curves, cubic).
Fit to exterior points by robust least squares with reparametrisation."""
import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from scipy.interpolate import CubicSpline
CX0,CZ0=40.0,35.0

def bbasis(u,n):
    t=u*n; i=np.floor(t).astype(int); s=t-i
    b=np.zeros((len(u),n))
    w=[(1-s)**3/6,(3*s**3-6*s**2+4)/6,(-3*s**3+3*s**2+3*s+1)/6,s**3/6]
    for k in range(4): np.add.at(b,(np.arange(len(u)),(i+k)%n),w[k])
    return b

def ywts(st,y,bc='not-a-knot'):
    K=len(st)
    if K==2: bc='natural'
    cs=CubicSpline(st,np.eye(K),bc_type=bc,extrapolate=True)
    return cs(y)

class Loft:
    def __init__(s,st,NP,poles=None):
        s.st=np.asarray(st,float); s.NP=NP; s.P=poles   # P: (K,NP,2)
    def curve(s,y,u):
        W=ywts(s.st,np.atleast_1d(y))      # (ny,K)
        Pk=np.einsum('yk,kjc->yjc',W,s.P)  # (ny,NP,2)
        B=bbasis(u,s.NP)
        return np.einsum('uj,yjc->yuc',B,Pk)
    def pts(s,y,u):   # paired y,u arrays
        W=ywts(s.st,y); B=bbasis(u,s.NP)
        Pk=np.einsum('yk,kjc->yjc',W,s.P)
        return np.einsum('yj,yjc->yc',B,Pk)

def fit(st,NP,Y,TH,X,Z,wt,lam_t=1e-2,lam_y=1e-3,iters=6,tol=0.3,reparam=2,verbose=False):
    K=len(st); u=(TH/(2*np.pi))%1.0
    keep=np.ones(len(Y),bool)
    D2=np.zeros((NP,NP))
    for i in range(NP): D2[i,i]=-2;D2[i,(i-1)%NP]=1;D2[i,(i+1)%NP]=1
    Dy=np.zeros((K-2,K))
    for i in range(K-2): Dy[i,i:i+3]=[1,-2,1]
    Rt=np.kron(np.eye(K),D2); Ry=np.kron(Dy,np.eye(NP))
    reg=lam_t*Rt.T@Rt+lam_y*Ry.T@Ry
    Wy=ywts(st,Y)
    tgt=np.c_[X,Z]
    for rp in range(reparam+1):
        B=bbasis(u,NP)
        A=(Wy[:,:,None]*B[:,None,:]).reshape(len(Y),K*NP)  # index k*NP+j
        w=wt.copy()
        for it in range(iters):
            Aw=A[keep]*w[keep,None]
            M=Aw.T@A[keep]+reg*w[keep].sum()/ (K*NP)
            sol=np.linalg.solve(M,Aw.T@tgt[keep])
            P=sol.reshape(K,NP,2)
            res=A@sol-tgt
            # signed radial residual w.r.t. centre: >0 = model outside data (data inside)
            rad=np.c_[X-CX0,Z-CZ0]; rad/=np.linalg.norm(rad,axis=1)[:,None]
            sr=(res*rad).sum(1)
            keep=(np.abs(sr)<max(tol,2.5*np.median(np.abs(sr[keep]))))
        L=Loft(st,NP,P)
        if rp<reparam:   # reparametrise: nearest point on the model section at the data's y
            uu=np.linspace(0,1,1440,endpoint=False)
            for y0 in np.unique(Y):
                m=Y==y0
                C=L.curve(y0,uu)[0]
                d=((tgt[m][:,None,:]-C[None,:,:])**2).sum(2)
                u[m]=uu[np.argmin(d,axis=1)]
    return Loft(st,NP,P),keep,sr,u
