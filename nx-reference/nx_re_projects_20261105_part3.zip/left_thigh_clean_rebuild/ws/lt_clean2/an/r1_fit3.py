import numpy as np, json
from scipy.interpolate import CubicSpline
from scipy.ndimage import median_filter
d = np.load("work/r1/edge2.npz")
def clean(a):
    y, t, r = a.T
    m = (y >= 53.0) & (y <= 262.3) & ~((y > 242.5) & (y < 249.5))
    y, t, r = y[m], t[m], r[m]
    # outliers: residual from running median (mid part only)
    med = median_filter(t, size=61, mode="nearest"); bad = (np.abs(t - med) > 2.5) & (y > 62) & (y < 256)
    return y[~bad], t[~bad], r[~bad], int(bad.sum())
O = clean(d["out"]); I = clean(d["inn"])
print("outliers removed", O[3], I[3])
yg = np.arange(53.5, 262.01, 0.25)
def interp(Z):
    return np.interp(yg, Z[0], Z[1]), np.interp(yg, Z[0], Z[2])
to, ro = interp(O); ti, ri = interp(I)
print("out-inn theta diff: rms %.2f max %.2f deg" % (np.sqrt(np.mean((to-ti)**2)), np.abs(to-ti).max()))
tm = 0.5*(to+ti); rm = 0.5*(ro+ri)
# target polyline in (y, s=r*theta_rad)
S = rm*np.radians(tm); T = np.c_[yg, S]
# resample the target uniformly by arclength for error metric
seg = np.r_[0, np.cumsum(np.hypot(np.diff(T[:,0]), np.diff(T[:,1])))]; u = np.arange(0, seg[-1], 0.25)
Tt = np.c_[np.interp(u, seg, T[:,0]), np.interp(u, seg, T[:,1])]
def rinterp(y): return np.interp(y, yg, rm)
def spl_curve(ky, kth):
    kr = rinterp(np.array(ky)); ks = kr*np.radians(kth); P = np.c_[ky, ks]
    t = np.r_[0, np.cumsum(np.hypot(np.diff(P[:,0]), np.diff(P[:,1])))]
    cs = CubicSpline(t, P, bc_type="not-a-knot"); tt = np.linspace(0, t[-1], 4000); return cs(tt)
def err(ky, kth):
    C = spl_curve(ky, kth); from scipy.spatial import cKDTree
    d1 = cKDTree(C).query(Tt)[0]   # target -> spline
    d2 = cKDTree(Tt).query(C)[0]
    return d1, d2
cand = list(range(0, len(yg)))
tsm = np.convolve(np.pad(tm, 6, mode='edge'), np.ones(13)/13, mode='valid')
def th_at(y): return float(np.interp(y, yg, tsm if 62 < y < 255 else tm))
def rnd(y, th): return round(y/0.05)*0.05, round(th/0.5)*0.5
sel = [53.5, 59.0, 69.0, 80.0, 95.0, 110.0, 124.5, 137.0, 150.0, 165.0, 180.0, 195.0, 210.0, 231.0, 249.5, 259.5, 261.5]
for it in range(14):
    pts = [rnd(y, th_at(y)) for y in sel]
    ky = [p[0] for p in pts]; kth = [p[1] for p in pts]
    d1, d2 = err(ky, kth)
    print(f"n {len(sel)}  target->spline p50 {np.median(d1):.2f} p90 {np.percentile(d1,90):.2f} max {d1.max():.2f}   spline->target p90 {np.percentile(d2,90):.2f} max {d2.max():.2f}")
    if np.percentile(d1, 90) < 0.35 and d1.max() < 0.9 or len(sel) >= 24: break
    k = np.argmax(d1); yk = Tt[k, 0]
    sel = sorted(set(sel + [round(yk/0.5)*0.5]))
print("knots (y, theta):", [(round(a,2), b) for a, b in zip(ky, kth)])
json.dump({"y": ky, "theta": kth, "p90": float(np.percentile(d1,90)), "max": float(d1.max())}, open("work/r1/panel_fit.json", "w"))
