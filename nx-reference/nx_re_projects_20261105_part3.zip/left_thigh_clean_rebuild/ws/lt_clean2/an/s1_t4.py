import sys
from s1_build import *
tag=sys.argv[1]
d=np.load(f'work/s1/loft_{tag}.npz'); st=d['st']; P=d['P']
lo=loft(P,st); dr=drum()
body=common(lo,cone_solid())
print('loft',volume(lo),'body',volume(body),'drum',volume(dr))
for fz in [None,1e-4,1e-3,0.01,0.05]:
    cm=common(body,dr,fz); fu=fuse(body,dr,fz)
    print('fuzzy',fz,'common',round(volume(cm)),'fuse',round(volume(fu)),'expected',round(volume(body)+volume(dr)-volume(cm)),'valid',valid(fu))
