"""section plots scan vs CAD at z levels, window around given centre. argv: which cad_stl out_png cx cy half z1,z2,.. [axis]"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, trimesh
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
which, cadp, outp, cx, cy, half, zs = sys.argv[1:8]
axis = int(sys.argv[8]) if len(sys.argv) > 8 else 2
cx, cy, half = float(cx), float(cy), float(half)
zs = [float(z) for z in zs.split(',')]
v, f = lib.load(which + '_scan', 1500000)
cad = trimesh.load(cadp, process=False)
cv, cf = np.asarray(cad.vertices), np.asarray(cad.faces)
n = len(zs); fig, ax = plt.subplots(1, n, figsize=(5 * n, 5.2))
ax = np.atleast_1d(ax)
ia, ib = [i for i in range(3) if i != axis]
for a, z in zip(ax, zs):
    for (vv, ff, col, lw) in ((v, f, 'tab:red', 0.8), (cv, cf, 'k', 0.8)):
        s = lib.section(vv, ff, axis, z)
        for sg in s:
            if abs(sg[:, ia].mean() - cx) < half * 1.5 and abs(sg[:, ib].mean() - cy) < half * 1.5:
                a.plot(sg[:, ia], sg[:, ib], col, lw=lw)
    a.set_xlim(cx - half, cx + half); a.set_ylim(cy - half, cy + half); a.set_aspect('equal'); a.set_title('%s=%g (red scan, black CAD)' % ('xyz'[axis], z)); a.grid(alpha=.3)
plt.tight_layout(); plt.savefig(outp, dpi=80)
