import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_loft as L, m2_o_fitband as B, m2_q_env as Q
d=np.load("work/m2/loft_U72.npz"); st=d["st"]; P=d["P"]; lf=L.Loft(st,P.shape[1],P)
R=json.load(open("work/m2/_final_stats.json"))
def sec(y,n=144): return lf.curve(y,np.arange(n)/n)[0]
# slopes at the interfaces
for y in (60,250):
    a=sec(y-0.5);b=sec(y+0.5); sl=np.linalg.norm(b-a,axis=1); print("Y",y,"max |d(x,z)/dY| %.3f median %.3f"%(sl.max(),np.median(sl)))
    c=sec(y,720); print("  x range %.1f..%.1f z range %.1f..%.1f"%(c[:,0].min(),c[:,0].max(),c[:,1].min(),c[:,1].max()))
for y in (56,60,64,68,72):
    c=lf.curve(y,np.linspace(0,1,1440))[0]; print("  Y %d loft ztop %.2f zbot %.2f xmin %.1f xmax %.1f"%(y,c[:,1].max(),c[:,1].min(),c[:,0].min(),c[:,0].max()))
wall=json.load(open("work/m2/wall_stats.json"))
J=dict(
 description="Body loft v1 (M2): exterior envelope of the thigh body, zone Y 60..262 (use to Y 250, joint plane to the hip end). Through-Curves style loft of closed periodic cubic uniform B-spline sections.",
 frame="assembly frame; section poles are (x,z) at the station Y; polar centre for the fit (40,35)",
 section_param=dict(type="closed periodic cubic B-spline, uniform knots, %d poles per section; pole j ~ polar angle 360*j/%d deg from +X, counter-clockwise in the (x,z) plane (+X -> +Z -> -X -> -Z); first pole at +X"%(P.shape[1],P.shape[1]),np=int(P.shape[1])),
 loft_interp="between stations cubic spline (not-a-knot) of the poles in Y (as NX Through Curves, degree 3 in V)",
 stations_Y=[float(s) for s in st],
 poles_xz=P.tolist(),
 section_points_144_xz={str(float(y)):sec(y).round(4).tolist() for y in st},
 envelope_note="Envelope = smooth exterior WITHOUT the +X recessed panel: the band floor was shifted out by %.2f mm along the section normal before fitting (wall behind the band is 1.98 mm instead of 3.10 mm, so the envelope continues under the band)."%Q.BAND_DEPTH,
 fit=dict(method="tensor least squares on 2 deg x 2 mm cell medians of the exterior skin (both scans), robust (one pass tolerance 0.3 mm), 2 reparametrisation passes, drum footprint cone removed (Y<75), +X band shifted, band edges dropped",
          data_masks=["work/masks/out_ext_body.npy","work/masks/inn_ext_body.npy"], tri_used_for_score=int(R["loft_body_outside_band_60_255"]["n_tri"])),
 deviation=dict({k:v for k,v in R.items() if k not in ("per_10mm",)}),
 per_10mm_Y_loft_pct_p90_part5_pct_p90=R["per_10mm"],
 sweep=[dict(cfg="K10 NP72 (final)",pct=95.6,p90=0.189),dict(cfg="K10 NP64",pct=94.8,p90=0.211),dict(cfg="K10 NP56",pct=93.7,p90=0.252),dict(cfg="K9 NP72 (60,70,84,105,135,170,205,240,262)",pct=93.3,p90=0.342),dict(cfg="K8 NP72 (60,72,100,135,175,210,240,262)",pct=92.8,p90=0.362)],
 curvature=dict(min_convex_radius_mm=9.93,where="Y=64, u=0.153 (upper-/lower -X corners)",p99_convex_radius=18.9,min_concave_radius_mm=18.2,note="concave exterior only in the Y 60-80 corner transition and the diagonal facet valleys; shell inward 3.1 is safe (min convex radius 9.9 > 6.2)"),
 wall=dict(plain_wall_outside_band=dict(median=3.072,p05=2.606,p95=3.273),outside_band_all=wall["outside_band"],plus_x_band=wall["band"],note="+X band wall 1.98 mm = 3.10 - 1.12"),
 band=dict(depth_mm=1.12,measured_dist_to_envelope=R["band_dist_to_env"],edge_theta_by_Y=B.EDGE.tolist(),ends="fades out Y 262-266, starts before Y 60 (still there at 60)"),
)
json.dump(J,open("work/m2/body_fit.json","w"),indent=1,default=float); print("ok")
