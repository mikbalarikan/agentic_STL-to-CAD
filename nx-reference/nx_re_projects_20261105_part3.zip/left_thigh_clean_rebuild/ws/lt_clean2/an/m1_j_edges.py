import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
AX=(0.169,-0.100)
def tls(x,y):
    X=np.c_[x,y]; m=X.mean(0); u,s,vt=np.linalg.svd(X-m,full_matrices=False); d=vt[0]; n=vt[1]
    res=(X-m)@n; return m,d,n,res
out={}
for nm,sgn,zr in (("inn_scan",1,(76,85)),("out_scan",-1,(-15,-9))):
    v,f=lib.load(nm,1500000); c,nn,ar=lib.tri_data(v,f)
    x=c[:,0]-AX[0]; y=c[:,1]-AX[1]; r=np.hypot(x,y); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    radial=(x*nn[:,0]+y*nn[:,1])/np.maximum(r,1e-9)
    win=(np.abs(ang-10)<35)&(c[:,2]>zr[0])&(c[:,2]<zr[1])
    # plane face
    pl=win&(sgn*nn[:,2]>0.99)&(r>55)&(r<66.5)&((sgn>0)|(c[:,2]<-12))&((sgn<0)|(c[:,2]>80))
    zpl=np.median(c[pl,2]); 
    # chamfer: normal between 0.45..0.9 in z (sgn), radial>0.4
    ch=win&(sgn*nn[:,2]>0.4)&(sgn*nn[:,2]<0.92)&(radial>0.35)&(r>64.0)
    m0,d,n,res=tls(r[ch],c[ch,2])
    print(nm,'plane z',zpl.round(3),'n',pl.sum(),'p5-95',np.percentile(c[pl,2],[5,95]).round(3),'r range',np.percentile(r[pl],[1,99]).round(2))
    ang_ch=np.degrees(np.arctan2(abs(d[1]),abs(d[0])))
    print('  chamfer n',ch.sum(),'angle from radial axis (deg, 45=chamfer 45)',ang_ch.round(2),'tls res p90',np.percentile(np.abs(res),90).round(3),'r range',np.percentile(r[ch],[2,98]).round(2),'z range',np.percentile(c[ch,2],[2,98]).round(2))
    # intersections: chamfer line with plane z=zpl and with cone r(z)
    t=(zpl-m0[1])/d[1]; rpl=m0[0]+t*d[0]
    Rcone=lambda z: 68.7673-abs(z-36.8481)*0.0275
    # solve chamfer line with cone
    from scipy.optimize import brentq
    g=lambda s: (m0[0]+s*d[0])-Rcone(m0[1]+s*d[1]); s0=brentq(g,-40,40); rc,zc=m0[0]+s0*d[0],m0[1]+s0*d[1]
    print('  chamfer meets plane at r',rpl.round(3),'cone at r,z',round(rc,3),round(zc,3),' => radial leg',round(rc-rpl,3),'axial leg',round(abs(zc-zpl),3))
    # radial leg on cone: sizes along axes
    out[nm]=dict(z_plane=float(zpl),r_plane_edge=float(rpl),r_cone_edge=float(rc),z_cone_edge=float(zc),radial_leg=float(rc-rpl),axial_leg=float(abs(zc-zpl)),chamfer_angle=float(ang_ch),n_plane=int(pl.sum()),n_ch=int(ch.sum()))
    # r-z profile of chamfer region residuals to straight line vs round: bin along line
    s=(np.c_[r[ch],c[ch,2]]-m0)@d; 
    bins=np.linspace(s.min(),s.max(),9)
    print('  line residual by position along chamfer:',[float(np.round(res[(s>=bins[i])&(s<bins[i+1])].mean(),3)) for i in range(8)])
json.dump(out,open("work/m1/_edges.json","w"),indent=1)
