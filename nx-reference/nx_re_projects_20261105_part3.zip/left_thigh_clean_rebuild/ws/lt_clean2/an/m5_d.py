import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, trimesh
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
env = trimesh.load(os.path.join(lib.W,"env_part5.stl"), process=False)
ev,ef=np.asarray(env.vertices),np.asarray(env.faces)
key,scan,cad=sys.argv[1],sys.argv[2],sys.argv[3]; Y=float(sys.argv[4]); xl=eval(sys.argv[5]); zl=eval(sys.argv[6])
v,f=lib.load(scan,1500000); cv,cf=lib.load(cad); c,nn,ar=lib.tri_data(v,f)
band=np.load(os.path.join(lib.W,"masks",f"{key}_band.npy")); dot=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["dot"]
fig,ax=plt.subplots(figsize=(11,9))
for (vv,ff,col,lw) in ((cv,cf,"b",2.5),(ev,ef,"r",1.2),(v,f,"k",.8)):
    for a,b in lib.section(vv,ff,1,Y): ax.plot([a[0],b[0]],[a[2],b[2]],col,lw=lw)
sel=band[np.abs(c[band,1]-Y)<1.5]
ax.scatter(c[sel,0],c[sel,2],s=12,c=np.where(dot[sel]>0,'g','m'),zorder=5)
ax.set_xlim(*xl);ax.set_ylim(*zl);ax.set_aspect('equal');ax.grid(alpha=.3)
ax.set_title(f"{key} Y={Y} black scan red env5 blue old; green ext-facing magenta int-facing")
plt.savefig(os.path.join(lib.W,"m5",f"zoom_{key}_Y{int(Y)}.png"),dpi=80)
