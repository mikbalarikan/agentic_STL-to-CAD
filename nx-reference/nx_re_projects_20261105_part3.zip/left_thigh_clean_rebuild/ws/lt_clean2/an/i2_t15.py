from i2_rows import *
r0=np.hypot(c[:,0],c[:,1])
for lo,hi in ((21.8,27.5),(22.0,26.0),(21.5,28.5)):
    s=(n[:,2]>0.15)&(r0>=lo)&(r0<hi)&(c[:,2]>83.3)&(c[:,2]<87)
    P=np.c_[r0[s],c[s,2]]
    cx,cz,R,rms=circle_fit(P,a[s]); print(lo,hi,"centre r,z",round(cx,2),round(cz,2),"R",round(R,2),"rms",round(rms,3),"n",s.sum())
# shoulder flat extent
s=(n[:,2]>0.95)&(r0>19.5)&(r0<24)&(np.abs(c[:,2]-86.05)<0.15)
print("flat shoulder r range",np.percentile(r0[s],[1,50,99]))
