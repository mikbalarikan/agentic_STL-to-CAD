import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_loft as L, m2_g_fit as G
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
tag=sys.argv[1]; Ys=[float(s) for s in sys.argv[2].split(",")]
d=np.load(f"work/m2/loft_{tag}.npz"); lf=L.Loft(d["st"],d["P"].shape[1],d["P"])
P=np.load("work/m2/ext_pts.npy")
fig,axs=plt.subplots(2,(len(Ys)+1)//2,figsize=(8*((len(Ys)+1)//2),14))
for ax,y in zip(axs.ravel(),Ys):
    q=P[np.abs(P[:,1]-y)<=0.5]; ax.plot(q[:,0],q[:,2],'k.',ms=2)
    C=lf.curve(y,np.linspace(0,1,1440))[0]; ax.plot(C[:,0],C[:,1],'r-',lw=.8)
    ax.set_aspect('equal'); ax.set_title(f"Y={y}"); ax.grid(True)
plt.tight_layout(); plt.savefig(f"work/m2/secchk_{tag}.png",dpi=50)
