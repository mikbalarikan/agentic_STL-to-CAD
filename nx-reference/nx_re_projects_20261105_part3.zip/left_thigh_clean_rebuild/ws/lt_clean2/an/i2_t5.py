from i2_sec import *
secplot("sec_y110",1,110.0,(20,115),(30,100),"section y=110")
secplot("sec_y60",1,60.0,(20,115),(30,100),"section y=60")
secplot("sec_y165",1,165.9,(-30,115),(30,115),"section y=165.9")
