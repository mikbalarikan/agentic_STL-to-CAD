import sys, numpy as np, open3d as o3d
sys.path.insert(0,"an"); import lib
from scipy.optimize import least_squares
v,f=lib.load("out_scan",1500000)
S=o3d.t.geometry.RaycastingScene(); S.add_triangles(o3d.core.Tensor(v.astype(np.float32)),o3d.core.Tensor(f.astype(np.uint32)))
p0=np.array([74.65,33.95]); p1=np.array([55.05,55.40]); d=(p1-p0)/np.linalg.norm(p1-p0); n=np.array([d[1],-d[0]])
pts=[]; tab={}
for s in np.arange(4,36,2.0):
    row=[]
    for off in np.arange(2,16.1,1.0):
        xy=p0+s*d+off*n
        r=np.array([[xy[0],xy[1],14.0,0,0,-1]],np.float32)
        t=S.cast_rays(o3d.core.Tensor(r))["t_hit"].numpy()[0]
        z=14-t if np.isfinite(t) else np.nan
        row.append(z)
        if np.isfinite(z) and z<12.5 and z>-12 and 3<=off<=14 and 8<=s<=30: pts.append((s,off,z))
    tab[s]=row
print("z of first surface from above, off 2..16 step 1")
for s,row in tab.items(): print("s %2d"%s," ".join("%5.1f"%z if np.isfinite(z) else "  nan" for z in row))
P=np.array(pts); print(len(P))
def res(p):
    off0,z0,phi,R=p  # axis point at s=20: (off0, z0), descending angle phi (rad) w.r.t. the arm direction
    a=np.array([np.cos(phi),0,-np.sin(phi)])   # in (s,off,z) frame
    q=P-np.array([20,off0,z0]); proj=q@a; perp=q-np.outer(proj,a)
    return np.linalg.norm(perp,axis=1)-R
r=least_squares(res,[8.5,0,np.radians(30),8],loss="soft_l1",f_scale=0.5)
e=res(r.x); print("cyl fit off0 %.2f z0(at s20) %.2f phi %.1f deg R %.2f | rms %.2f p90 %.2f"%(r.x[0],r.x[1],np.degrees(r.x[2]),r.x[3],np.sqrt(np.mean(e**2)),np.percentile(np.abs(e),90)))
np.save("work/p5d/bowl_fit.npy",r.x)
