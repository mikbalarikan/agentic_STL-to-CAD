"""G-surf: zebra renders of the CAD exterior skin + curvature census (skin = CAD faces within 0.1 mm of the envelope E0)."""
import sys, numpy as np, trimesh, pyvista as pv, open3d as o3d
sys.path.insert(0,"an"); from v5e_occ import scene
from scipy import ndimage
pv.OFF_SCREEN=True
OUT=open("work/q7/surf.txt","w")
def P(*a):
    s=" ".join(str(x) for x in a); print(s); OUT.write(s+"\n")
VIEWS={"A_side_PX":((1,0.15,0.1),(0,0,1)),"B_side_MX":((-1,0.15,0.1),(0,0,1)),"C_knee_end":((0.2,-1,0.5),(0,0,1)),"D_hip_end":((0.2,1,0.4),(0,0,1))}
for w in ("out","inn"):
    M=trimesh.load(f"nx/P5d/{w}_P5d_final.stl",process=True)
    E=scene(f"nx/P5d/{w}_E0.stl")
    cen=M.triangles_center; de=E.compute_distance(o3d.core.Tensor(cen.astype(np.float32))).numpy()
    sk=np.where(de<0.1)[0]; P(f"== {w}: skin faces {len(sk)} of {len(M.faces)}, area {M.area_faces[sk].sum():.0f} mm2 of {M.area:.0f}")
    S=M.submesh([sk],append=True)
    pm=pv.wrap(S); pm=pm.clean()
    nrm=trimesh.Trimesh(S.vertices,S.faces,process=True).vertex_normals
    # curvature
    pm2=pv.wrap(trimesh.Trimesh(S.vertices,S.faces,process=True)); H=pm2.curvature("mean"); Kg=pm2.curvature("gaussian")
    # smooth over 1-ring to kill tessellation noise
    Hs=np.abs(H); r=1/np.maximum(Hs,1e-6)
    P(f"   mean-curvature radius (1/|H|) percentiles of vertices: p1 {np.percentile(r,1):.1f} p5 {np.percentile(r,5):.1f} p50 {np.percentile(r,50):.0f} mm; share with 1/|H|<6.2 mm (2 x wall): {(r<6.2).mean()*100:.2f} %")
    low=np.where(r<6.2)[0]
    if len(low):
        from sklearn.cluster import DBSCAN
        pts=pm2.points[low]; lab=DBSCAN(eps=3,min_samples=4).fit_predict(pts)
        rows=[]
        for l in set(lab)-{-1}:
            k=lab==l; rows.append((k.sum(),pts[k].min(0).round(0),pts[k].max(0).round(0),r[low][k].min()))
        P(f"   low-radius vertex clusters (n>=4): {len(rows)} ; biggest:")
        for x in sorted(rows,key=lambda t:-t[0])[:10]: P("     n %d bbox %s %s min R %.1f"%x)
    # Gaussian-curvature sign-change ripples are listed via zebra renders
    pm2.point_data["n"]=trimesh.Trimesh(S.vertices,S.faces,process=True).vertex_normals
    for vn,(dirv,up) in VIEWS.items():
        d=np.array(dirv,float); d/=np.linalg.norm(d)   # camera direction (from focus to camera)
        nn=pm2.point_data["n"]; vdir=-d
        R=vdir[None,:]-2*(nn@vdir)[:,None]*nn   # reflected view ray
        # zebra: stripes in the reflected ray's elevation angle
        pm2.point_data["zeb"]=np.sin(np.arcsin(np.clip(R[:,2],-1,1))*18)+0.35*np.sin(np.arctan2(R[:,1],R[:,0])*12)*0
        p=pv.Plotter(off_screen=True,window_size=(1500,1000)); p.set_background("white")
        p.add_mesh(pm2,scalars="zeb",cmap="gray",clim=(-0.2,0.2),interpolate_before_map=True,smooth_shading=True,show_scalar_bar=False,ambient=0.9,diffuse=0.0,specular=0)
        c0=np.array(pm2.center); p.camera.position=tuple(c0+d*900); p.camera.focal_point=tuple(c0); p.camera.up=up; p.camera.parallel_projection=True; p.camera.parallel_scale=190 if "end" not in vn else 110
        p.screenshot(f"work/q7/zebra_{w}_{vn}.png"); p.close()
    # curvature colour map side view
    p=pv.Plotter(off_screen=True,window_size=(1500,1000)); p.set_background("white")
    pm2.point_data["Hc"]=np.clip(H,-0.1,0.1)
    p.add_mesh(pm2,scalars="Hc",cmap="coolwarm",clim=(-0.06,0.06),smooth_shading=True,show_scalar_bar=True,scalar_bar_args={"title":"mean curv 1/mm"})
    c0=np.array(pm2.center); d=np.array([1,0.15,0.1]); d/=np.linalg.norm(d); p.camera.position=tuple(c0+d*900); p.camera.focal_point=tuple(c0); p.camera.up=(0,0,1); p.camera.parallel_projection=True; p.camera.parallel_scale=190
    p.screenshot(f"work/q7/curv_{w}_PX.png"); p.close()
