import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
e5=trimesh.load("work/env_part5.stl",process=False); ve,fe=np.asarray(e5.vertices),np.asarray(e5.faces)
fig,ax=plt.subplots(2,4,figsize=(28,12))
cfg=[('out_scan','out_cad',-1,[5,20,30]),('out_scan','out_cad',+1,[5,20,30]),('inn_scan','inn_cad',-1,[40,50,60]),('inn_scan','inn_cad',+1,[40,50,60])]
for col,(sn,cn,sd,zs) in enumerate(cfg):
    vs,fs=lib.load(sn,1500000); vc,fc=lib.load(cn)
    for row,z in enumerate((zs[0],zs[1])):
        a=ax[row,col]
        for (v,f),c,lab in (((vs,fs),'k','scan'),((vc,fc),'r','old'),((ve,fe),'g','p5')):
            s=lib.section(v,f,2,z)
            # outermost x per segment point
            pts=np.vstack([s[:,0],s[:,1]]) if len(s) else np.zeros((0,3))
            k=(pts[:,0]*sd>20)&(pts[:,1]>205)
            p=pts[k]; o=np.argsort(p[:,1]); a.plot(p[o,1],p[o,0],c+'.',ms=1.5 if lab=='scan' else 1,label=lab)
        a.set_title(f"{sn} {'+X' if sd>0 else '-X'} z={z}: outer-x vs Y"); a.grid(True); a.set_xlim(205,290)
        lo,hi=(a.get_ylim()); 
plt.tight_layout(); plt.savefig("work/m3/flank_prof.png",dpi=45)
