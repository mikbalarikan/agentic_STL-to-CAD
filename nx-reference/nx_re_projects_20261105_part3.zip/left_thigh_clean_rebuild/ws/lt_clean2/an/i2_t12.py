from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
from scipy.signal import find_peaks
def probe(name,cc,R=12):
    r=np.hypot(c[:,0]-cc[0],c[:,1]-cc[1]); m=(r<R)&(d>0.5)
    print(name,cc,"n",m.sum())
    h=(np.abs(n[:,2])<0.4)&m
    hist,ed=np.histogram(r[h],bins=np.arange(0,R,0.1),weights=a[h]); pk,_=find_peaks(hist,height=hist.max()*0.08,distance=2)
    print("  horiz r-peaks",[(round(ed[i]+.05,1),int(hist[i])) for i in pk])
    for sgn,lab in ((-1,'dn'),(1,'up')):
        v_=m&(n[:,2]*sgn>0.9); 
        if v_.sum()<5: continue
        zz=c[v_,2]; hh,e2=np.histogram(zz,bins=np.arange(zz.min(),zz.max()+0.3,0.25),weights=a[v_]); pk2,_=find_peaks(hh,height=hh.max()*0.1,distance=2)
        print("  ",lab,"levels",[(round(e2[i]+.12,2),int(hh[i])) for i in pk2])
for k,(x,y) in DS.KNEE_COVER_PINS.items(): probe(k,(x,y),8)
for k,(x,y) in DS.HIP_PINS.items(): probe(k,(x,y),8)
for k,(x,y,*_) in DS.PINS.items(): probe(k,(x,y),9)
