"""M4 module: joint parameters per station from (outer caster, inner caster) on the fixed station set work/m4/stations.npz"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\an")
import numpy as np
from rays import Caster
import lib
NAMES = ["KNEE_ARC", "PX_WALL", "PX_HIP", "MX_WALL", "MX_HIP"]
D = np.load(os.path.join(lib.W, "m4", "stations.npz"))
T = D["KNEE_ARC__T"]
ZO = np.arange(33.0, 34.71, 0.1); ZI = np.arange(35.4, 37.01, 0.1)
def col(ZA, z): return int(np.argmin(abs(ZA - z)))
def med(x):
    x = x[np.isfinite(x)]
    return float(np.median(x)) if len(x) >= 2 else np.nan
def mesh_caster(path):
    import trimesh
    m = trimesh.load(path, process=False); m.merge_vertices()
    return Caster(np.asarray(m.vertices, float), np.asarray(m.faces))
def measure(CO, CI):
    rows = []
    for nm in NAMES:
        s = D[nm + "__s"]; p = D[nm + "__p"]; n = D[nm + "__n"]; S = len(s)
        q = p[:, None, :] + T[None, :, None] * n[:, None, :]; qf = q.reshape(-1, 2)
        Ho = (37.0 - CO.hit(np.c_[qf, np.full(len(qf), 37.0)], np.tile([0, 0, -1.0], (len(qf), 1)))).reshape(S, len(T))
        Hi = (33.8 + CI.hit(np.c_[qf, np.full(len(qf), 33.8)], np.tile([0, 0, 1.0], (len(qf), 1)))).reshape(S, len(T))
        def face(C, z):
            tin = -7 + C.hit(np.c_[p - 7 * n, np.full(S, z)], np.c_[n, np.zeros(S)])
            tout = 12 - C.hit(np.c_[p + 12 * n, np.full(S, z)], np.c_[-n, np.zeros(S)])
            return tin, tout
        o_tin, o_tout = face(CO, 34.3); i_tin, i_tout = face(CI, 36.6); i_tout58 = face(CI, 35.8)[1]
        o_t34 = face(CO, 34.0)[1]; o_t346 = face(CO, 34.6)[1]; i_t355 = face(CI, 35.5)[1]; i_t364 = face(CI, 36.4)[1]
        for i in range(S):
            r = dict(chain=nm, s=float(s[i]), x=float(p[i, 0]), y=float(p[i, 1]), o_tin=o_tin[i], o_tout=o_tout[i], i_tin=i_tin[i], i_tout=i_tout[i])
            r["step"] = i_tout58[i] - o_tout[i]; r["o_edge"] = o_t346[i] - o_t34[i]; r["i_edge"] = i_t355[i] - i_t364[i]
            to = o_tout[i]; ti = i_tout[i]; H = Ho[i]
            if np.isfinite(to):
                win = (T > to - 4.8) & (T < to + 0.3); hi = win & (H > 35.5) & (H < 36.8)
                r["tongue"] = bool(hi.sum() >= 3)
                if r["tongue"]:
                    tb = T[hi].max(); r["o_tb"] = float(tb); r["tongue_top"] = med(H[(T > tb - 0.7) & (T < tb - 0.2)]); r["shoulder"] = float(to - tb)
                    r["rim"] = med(H[(T > tb + 0.3) & (T < to - 0.5)])
                else: r["rim"] = med(H[(T > to - 2.4) & (T < to - 0.45)])
            else: r["tongue"] = False
            H = Hi[i]
            if np.isfinite(ti):
                win = (T > ti - 4.8) & (T < ti + 0.3); hi = win & (H > 35.8) & (H < 36.5)
                r["rebate"] = bool(hi.sum() >= 3)
                if r["rebate"]:
                    tc = T[hi].max(); r["i_tc"] = float(tc); r["rebate_floor"] = med(H[(T > tc - 0.7) & (T < tc - 0.2)]); r["lip_w"] = float(ti - tc)
                    r["lip"] = med(H[(T > tc + 0.3) & (T < ti - 0.5)])
                else: r["lip"] = med(H[(T > ti - 2.4) & (T < ti - 0.45)])
            else: r["rebate"] = False
            rows.append(r)
    return rows
