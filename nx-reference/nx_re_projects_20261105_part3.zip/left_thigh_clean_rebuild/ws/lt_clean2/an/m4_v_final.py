import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
W4 = os.path.join(lib.W, "m4")
J = json.load(open(os.path.join(W4, "joint.json")))
J["recommended"] = {
 "inner": {"z_lip": 35.31, "z_rebate_floor": 36.08, "z_boss_face": 39.07, "w_rebate": 1.85, "lip_land_width": 1.40,
           "note": "inner scan is flat to 0.003 deg / 0.03 mm over the whole perimeter; part 5 / old master rebate floor 36.19 was 0.11 high, rebate 2.0 wide was 0.15 too wide"},
 "outer": {"z_rim": 34.80, "z_tongue_top": 36.05, "z_boss_face": 39.05, "t_tongue": 1.60, "tongue_inside_edge_offset": 0.0, "shoulder_land_width": 1.40,
           "note": "outer scan joint planes tilt as one rigid plane (0.041 deg about Y-ish, 0.048 deg about X-ish; z rises 0.0008/mm with Y and 0.0007/mm towards -X, +0.2 mm at the -X hip vs the +X knee); flat design level = area-weighted mean, worst error 0.15-0.3 mm, below the 0.5 gate. Optional: tilt model z = k + bx*x + by*y with bx=-0.00072, by=+0.00085, k_rim=34.752, k_tongue=35.984, k_boss=38.977."},
 "shadow_gap_z": 0.51, "exterior_step_inner_proud": 0.14, "interior_step_inner_minus_outer": -0.07,
 "exterior_edge_round_outer_rim": 0.2, "exterior_edge_round_inner_lip": 0.1,
 "wall_at_joint": {"outer_normal": 3.05, "inner_normal": 3.20, "outer_knee_arc": 3.15, "inner_knee_arc": 3.27, "outer_thin_px": 1.85, "inner_thin_px": 2.05},
 "tongue_rebate_zones_Y": {"PX_knee_wall": [-49.9, 52.0], "MX_wall": [30.1, 179.5], "MX_hip": [242.2, 286.5], "PX_hip": [261.7, 286.8]},
 "flat_joint_zones_Y_no_tongue": {"KNEE_ARC (x -29..52, y -62..-44)": "whole arc", "PX_wall": [52.0, 135.0], "PX_hip_wall": [179.6, 261.7]},
 "thin_wall_zones_Y_px": {"PX_wall": [53.7, 124.4], "PX_hip_wall": [179.6, 187.6, 201.1, 261.7]},
 "hip_datumA_flanges_note": "horizontal faces at the hip mouth: outer 36.14 (x 88-116, y 257-287) and 36.27 (x -43..-12, y 241-287), inner 36.077 on the same footprints: datum A contact flanges, not part of the tongue band",
 "part5_old_value_check": {"z_rim 34.76": "ok (scan 34.72-35.09)", "z_lip 35.32": "ok", "z_A tongue top 36.07": "ok as mean (scan 35.96-36.27)", "z_rebate 36.19": "0.11 too high, use 36.08", "t_tongue 1.65": "1.60", "w_rebate 2.0": "1.85"}}
json.dump(J, open(os.path.join(W4, "joint.json"), "w"), indent=1)
print("ok", os.path.getsize(os.path.join(W4, "joint.json")))
