from i1_common import *
from i1_fit import *
import ref5_design as DS, sys
S=load_all(); c,n,a,de=S['c'],S['n'],S['a'],S['de']
def probe(nm,x,y,rmax=9,dmin=2.5):
    r=np.hypot(c[:,0]-x,c[:,1]-y); m=(r<rmax)&(de>dmin)
    nr=((c[:,0]-x)*n[:,0]+(c[:,1]-y)*n[:,1])/np.maximum(r,1e-6)
    wall=m&(abs(n[:,2])<0.25)&(abs(nr)>0.9)
    print(nm,(x,y))
    # radius clusters by iterative peak
    pk=peaks(r[wall],a[wall],0.12,0.04,rng=(0,rmax))
    for p,sh in pk[:5]:
        k=wall&(abs(r-p)<0.3)
        if k.sum()<15: continue
        cx,cy,R,res,nn=circle_fit_robust(c[k,0],c[k,1])
        print("   wall R%.2f D%.2f c(%.2f,%.2f) res%.3f z %.1f..%.1f n%d nr_sign %+.1f"%(p,2*R,cx,cy,res,np.percentile(c[k,2],5),np.percentile(c[k,2],95),nn,np.median(nr[k])))
    up=m&(n[:,2]>0.95)
    if up.sum():
        for z,sh in peaks(c[up,2],a[up],0.1,0.04,rng=(c[up,2].min(),c[up,2].max()))[:5]:
            k=up&(abs(c[:,2]-z)<0.15); print("   plane z %.2f (n%d) r %.1f-%.1f"%(z,k.sum(),np.percentile(r[k],5),np.percentile(r[k],95)))
for k,(x,y,*_) in DS.PINS.items(): probe(k,x,y,8)
for k,(x,y) in DS.FLOOR_HOLES.items(): probe("FLOOR_"+k,x,y,6,2.5)
for k,(x,y) in DS.KNEE_COVER_PINS.items(): probe("COVER_"+k,x,y,8,1.5)
probe("CLIP",94.42,206.92,9,1.5)
