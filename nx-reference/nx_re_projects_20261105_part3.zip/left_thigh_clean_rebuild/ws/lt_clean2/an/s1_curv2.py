"""Curvature radius map of the loft surface itself (exposed part only), with locations. usage s1_curv2.py tag"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_build import *
from s1_shell import faces
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomLProp import GeomLProp_SLProps
from OCP.BRep import BRep_Tool
from s1_lib import dist_to_mesh
import trimesh
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
tag = sys.argv[1]
d = np.load(os.path.join(S1, f'loft_{tag}.npz')); st, P = d['st'], d['P']
lo = loft(P, st)
m = trimesh.load(os.path.join(S1, f'env_{tag}.stl'), process=False); v, f = np.asarray(m.vertices), np.asarray(m.faces)
fcs = [fc for fc in faces(lo) if BRepAdaptor_Surface(fc, True).GetType().name == 'GeomAbs_BSplineSurface']
print('bspline faces', len(fcs))
fc = fcs[0]; a = BRepAdaptor_Surface(fc, True); surf = BRep_Tool.Surface_s(fc)
sgn = -1.0 if fc.Orientation().name == 'TopAbs_REVERSED' else 1.0
us = np.linspace(a.FirstUParameter(), a.LastUParameter(), 360); vs = np.linspace(a.FirstVParameter(), a.LastVParameter(), 400)
print('u', a.FirstUParameter(), a.LastUParameter(), 'v', a.FirstVParameter(), a.LastVParameter())
rows = []
for uu in us:
    for vv in vs:
        p = a.Value(uu, vv); pr = GeomLProp_SLProps(surf, float(uu), float(vv), 2, 1e-7)
        if pr.IsCurvatureDefined(): rows.append((uu, vv, p.X(), p.Y(), p.Z(), pr.MaxCurvature() * sgn, pr.MinCurvature() * sgn))
R = np.array(rows); pts = R[:, 2:5]
dd = dist_to_mesh(pts, v, f); ex = dd < 0.05
kmax, kmin = R[:, 5], R[:, 6]
cv = np.where(np.minimum(kmax, kmin) < 0, 1 / np.abs(np.minimum(kmax, kmin)), np.inf)    # convex radius
cc = np.where(np.maximum(kmax, kmin) > 0, 1 / np.maximum(kmax, kmin), np.inf)       # concave radius
for nm, rr in [('convex', cv), ('concave', cc)]:
    r = rr[ex]; print(nm, 'min', r.min().round(2), 'p0.1', np.percentile(r, 0.1).round(2), 'p1', np.percentile(r, 1).round(2), 'n<6.2', (r < 6.2).sum(), 'n<8', (r < 8).sum(), 'of', ex.sum())
    j = np.where(ex & (rr < 8))[0]
    if len(j):
        q = pts[j]; print('  locations R<8: Y', q[:, 1].min().round(1), q[:, 1].max().round(1), 'x', q[:, 0].min().round(1), q[:, 0].max().round(1), 'z', q[:, 2].min().round(1), q[:, 2].max().round(1))
        h, e = np.histogram(q[:, 1], bins=np.arange(-40, 290, 10)); print('  Y hist', dict((int(a_), int(b_)) for a_, b_ in zip(e[:-1], h) if b_))
np.save(os.path.join(S1, f'curv2_{tag}.npy'), np.c_[pts, cv, cc, ex])
fig, axs = plt.subplots(2, 1, figsize=(16, 9))
for ax, rr, nm in zip(axs, [cv, cc], ['convex R', 'concave R']):
    sc = ax.scatter(R[ex, 3], np.degrees(np.arctan2(R[ex, 4] - 35, R[ex, 2] - 40)), c=np.minimum(rr[ex], 30), s=0.4, cmap='jet_r', vmin=4, vmax=30); plt.colorbar(sc, ax=ax); ax.set_title(nm)
plt.tight_layout(); plt.savefig(os.path.join(S1, f'curv_{tag}.png'), dpi=60)
