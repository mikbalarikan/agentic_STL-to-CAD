import numpy as np, pyvista as pv, sys
pv.OFF_SCREEN = True
P = "nx/P5d/"
mo = pv.read(P + "out_P5d.stl"); mi = pv.read(P + "inn_P5d.stl")
def shot(name, mesh, pos, focal, par, up=(0, 0, 1), size=(1500, 1000), clim=None, axis=2):
    p = pv.Plotter(off_screen=True, window_size=size, lighting="none"); p.set_background("white")
    if clim:
        mesh = mesh.copy(); mesh["h"] = mesh.points[:, axis]
        p.add_mesh(mesh, scalars="h", clim=clim, cmap="coolwarm", show_scalar_bar=False, smooth_shading=False, specular=0.1, ambient=0.35, diffuse=0.65)
    else:
        p.add_mesh(mesh, color="lightsteelblue", smooth_shading=False, specular=0.1, ambient=0.35, diffuse=0.65)
    p.camera_position = [pos, focal, up]; p.camera.enable_parallel_projection(); p.camera.parallel_scale = par
    d = np.array(focal, float) - np.array(pos, float); d /= np.linalg.norm(d)
    side = np.cross(d, np.array(up, float)); side /= np.linalg.norm(side); u = np.cross(side, d)
    for k, (a, b, inten) in enumerate(((0.8, 0.7, 0.55), (-0.9, 0.2, 0.25), (0.1, -0.8, 0.2))):
        lp = np.array(focal, float) + 300 * (-d * 0.6 + side * a + u * b)
        p.add_light(pv.Light(position=tuple(lp), focal_point=tuple(focal), intensity=inten, light_type="scene light"))
    p.screenshot(P + name); p.close(); print(name)
shot("p5d_out_roots_knee.png", mo, (60, 60, 400), (50, 60, 0), 55, up=(0, 1, 0), clim=(-12, 12))
shot("p5d_out_roots_ribs.png", mo, (40, 200, 400), (40, 130, -10), 80, up=(0, 1, 0), size=(1500, 1400), clim=(-45, 5))
shot("p5d_out_trough_pad.png", mo, (180, 60, 160), (80, 80, 10), 60, up=(0, 0, 1), clim=(-10, 36))
shot("p5d_out_seams.png", mo, (30, 150, -400), (30, 190, -10), 130, up=(0, 1, 0), size=(1500, 1500))
shot("p5d_inn_roots_under.png", mi, (30, 100, -400), (30, 100, 80), 130, up=(0, 1, 0), size=(1500, 1500), clim=(62, 92))
shot("p5d_inn_roots_hip.png", mi, (40, 200, -400), (40, 230, 70), 70, up=(0, 1, 0), clim=(60, 100))
shot("p5d_inn_seams.png", mi, (30, 150, 400), (30, 190, 80), 130, up=(0, 1, 0), size=(1500, 1500))
