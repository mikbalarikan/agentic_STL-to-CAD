import sys, numpy as np
sys.path.insert(0,'an')
import lib
v,f = lib.load('out_scan',1500000)
c,nn,ar = lib.tri_data(v,f)
res = np.load('work/dev_p5aout_out.npz')['d1']
p5 = np.load('work/dev_FINout.npz')['d1']
old = np.load('work/dev_oldC.npz')['d1']
m = np.load('work/masks/out_f_HIP_RING_BORE.npy')
hx,hz=37.97,35.18
x=c[m,0]-hx; z=c[m,2]-hz
ang=np.arctan2(z,x)
R=np.hypot(x,z)
# bolt holes
k=np.arange(26); a0=np.radians(13.65+13.75*k)
near=np.zeros(len(m),bool)
for a in a0:
    bx,bz=45.725*np.cos(a),45.725*np.sin(a)
    near|= np.hypot(x-bx,z-bz)<4.6
print('in bolt-hole zone',near.mean())
for nm,d in (('new',res),('old',old),('p5',p5)):
    dm=d[m]
    print(nm,'all %.2f'%np.percentile(dm,90),'excl bolt zone %.2f'%np.percentile(dm[~near],90), 'bolt zone %.2f'%np.percentile(dm[near],90))
dm=res[m][~near]; cm=c[m][~near]
bad=dm>0.5
print('bad',bad.mean(), cm[bad].min(0).round(1) if bad.any() else '', cm[bad].max(0).round(1) if bad.any() else '')
Rr=R[~near]
for lo,hi in [(0,41.5),(41.5,43.5),(43.5,49.5),(49.5,60)]:
    s=(Rr>=lo)&(Rr<hi)
    if s.any(): print('R %g-%g n %d p90 %.2f'%(lo,hi,s.sum(),np.percentile(dm[s],90)))
