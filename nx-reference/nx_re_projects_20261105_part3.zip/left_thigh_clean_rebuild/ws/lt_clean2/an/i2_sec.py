from i2_common import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt, trimesh
P5STL = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 5 - Clean Rebuild\deliver\CAD\LT-INN-001_Left_Thigh_Inner.stl"
_m={}
def mesh(name):
    if name not in _m:
        if name=="p5":
            p=os.path.join(W,"p5_inn.npz")
            if os.path.exists(p): z=np.load(p); _m[name]=(z["v"],z["f"])
            else:
                m=trimesh.load(P5STL,process=False); m.merge_vertices(); v,f=np.asarray(m.vertices,float),np.asarray(m.faces); np.savez(p,v=v,f=f); _m[name]=(v,f)
        elif name=="old": _m[name]=lib.load("inn_cad")
        else: _m[name]=lib.load("inn_scan",1500000)
    return _m[name]
def secplot(fn, axis, val, lim_h, lim_z, title="", slab=0.3, pts=None, size=(14,8)):
    """axis: 0 = x const (plot y,z), 1 = y const (plot x,z)"""
    fig,ax=plt.subplots(figsize=size)
    hax = 1 if axis==0 else 0
    for name,col in (("p5","r"),("old","g")):
        v,f=mesh(name); s=lib.section(v,f,axis,val)
        for seg in s: ax.plot(seg[:,hax],seg[:,2],col+"-",lw=1)
    v,f=mesh("scan"); 
    c=v[f].mean(1); mm=np.abs(c[:,axis]-val)<slab
    s=lib.section(v,f,axis,val)
    for seg in s: ax.plot(seg[:,hax],seg[:,2],"k-",lw=.7)
    ax.set_xlim(*lim_h); ax.set_ylim(*lim_z); ax.set_aspect('equal'); ax.grid(alpha=.3); ax.set_title(title+" (scan black, part5 red, old green)")
    plt.tight_layout(); plt.savefig(os.path.join(O,fn+".png"),dpi=80); plt.close()
if __name__=="__main__":
    secplot("sec_y0",1,0.0,(-75,75),(30,100),"section y=0")
