import sys, os, numpy as np, trimesh, open3d as o3d
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
AX, AZ = 37.97, 35.18
def sc(m):
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32))); return s
def cast(s, o, d): return s.cast_rays(o3d.core.Tensor(np.hstack([o, d]).astype(np.float32)))["t_hit"].numpy()
se = sc(trimesh.load("nx/base_v2/envelope.stl", process=False))
for w, sg in (("out", -1), ("inn", 1)):
    v, f = lib.load(w + "_scan", 1500000); ss = sc(trimesh.Trimesh(v, f, process=False))
    P = []
    for y in np.arange(251.0, 260.0, 0.5):
        for th in np.arange(1.0, 12.1, 1.0):
            t = np.radians(th); dv = np.array([[np.cos(t), 0, sg*np.sin(t)]]); o = np.array([[AX, y, AZ]]) + 500*dv
            tm = cast(ss, o, -dv)[0]; te = cast(se, o, -dv)[0]
            if (tm - te) > 1.3 and (tm-te) < 2.4: P.append(o[0] - dv[0]*tm)
    P = np.array(P); print(w, len(P))
    c = P.mean(0); u, s_, vt = np.linalg.svd(P - c); n = vt[2]; res = (P - c) @ n
    print(" plane normal", n.round(4), "centre", c.round(2), "resid rms %.3f max %.3f" % (res.std(), abs(res).max()), "sing", s_.round(2))
    # cylinder about hip axis? residual of r const
    r = np.hypot(P[:,0]-AX, P[:,2]-AZ); print(" r range", r.min().round(2), r.max().round(2))
    # cone about hip axis: r = a + b*y
    A = np.c_[np.ones(len(P)), P[:,1]]; co, *_ = np.linalg.lstsq(A, r, rcond=None); print(" cone r=a+b y:", co.round(4), "rms", (A@co-r).std().round(3))
    # plane fit as y = f(x,z)? nz etc
    ang = np.degrees(np.arctan2(sg*(P[:,2]-AZ), P[:,0]-AX)); A = np.c_[np.ones(len(P)), P[:,1], ang]; co, *_ = np.linalg.lstsq(A, r, rcond=None); print(" r=a+b y+c th:", co.round(4), "rms", (A@co-r).std().round(3))
