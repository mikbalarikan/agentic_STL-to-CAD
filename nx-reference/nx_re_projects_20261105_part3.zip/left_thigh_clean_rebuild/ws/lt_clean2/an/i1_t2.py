from i1_common import *
from i1_rib import *
import ref5_design as DS
S = load_all()
def show(nm, p0, p1, t0, top0=None, **kw):
    r, ct = fit_rib(S, p0, p1, t0, top0, **kw)
    mi = rib_mask(S, ct, r, t0)
    d5, d0, a = S['d5'], S['d0'], S['a']
    print(f"{nm:14s} L={r['L']:.0f} t={r.get('t',np.nan):.2f} off={r.get('off',np.nan):+.2f} rot={r.get('rot_deg',np.nan):+.2f} top0={r.get('top_z0',np.nan):.2f} top1={r.get('top_z1',np.nan):.2f} n_top={r.get('top_n')} | mask {len(mi)} p90 old {np.percentile(d0[mi],90):.2f} p5 {np.percentile(d5[mi],90):.2f}")
for nm,(a,b,top,t) in DS.OUT_RIBS.items(): show(nm,a,b,t,top)
for nm,(a,b,z0,z1,t) in DS.OUT_GUSSETS.items(): show(nm,a,b,t,(z0+z1)/2)
for nm,(a,bo,bi) in DS.ARMS.items(): show(nm,a,bo,3.0,None)
for nm,(a,b,w) in DS.FLANGES.items(): show(nm,a,b,w,None)
