import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
HX,HZ=37.97,35.18
fig,ax=plt.subplots(2,4,figsize=(28,11))
for row,(tag,sn,zs) in enumerate((('inn','inn_scan',lambda z:z>HZ+30),('out','out_scan',lambda z:z<HZ-30))):
    v,f=lib.load(sn,1500000)
    for col,y in enumerate((236,250,262,270)):
        s=lib.section(v,f,1,y); P=np.vstack([s[:,0],s[:,1]]); P=P[zs(P[:,2])]
        r=np.hypot(P[:,0]-HX,P[:,2]-HZ); th=np.degrees(np.arctan2(P[:,2]-HZ,P[:,0]-HX))
        # outermost by theta bin 0.5
        b=np.floor(th*2).astype(int); o=np.argsort(b); 
        ub=np.unique(b); R=np.array([r[b==u].max() for u in ub]); T=ub/2
        # smooth baseline: running median 15deg
        from scipy.ndimage import median_filter
        base=median_filter(R,size=41,mode='nearest')
        a=ax[row,col]; a.plot(T,R-base,'k-',lw=.8); a.set_ylim(-1.2,1.2); a.grid(True); a.set_title(f"{tag} Y={y}: R - medianfilt(R) vs theta"); 
        # list notable dips
        d=R-base; idx=np.where(d<-0.25)[0]
        if len(idx): print(tag,y,'dips at theta',T[idx][[0,-1]], 'min %.2f'%d.min(), 'n',len(idx))
plt.tight_layout(); plt.savefig("work/m3/seam.png",dpi=40)
