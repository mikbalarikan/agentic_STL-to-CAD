from i1_core import *
import ref5_design as DS
from i1_help import *
hx, hz = 37.97, 35.18

# ================================================================= floor bosses / holes
def hole_probe(x, y, rmax):
    r = np.hypot(c[:, 0] - x, c[:, 1] - y)
    nr = ((c[:, 0] - x) * n[:, 0] + (c[:, 1] - y) * n[:, 1]) / np.maximum(r, 1e-6)
    wall = (r < rmax) & (abs(n[:, 2]) < 0.25) & (abs(nr) > 0.9) & (de > 2.0)
    return r, nr, wall

for k, (x, y) in DS.FLOOR_HOLES.items():
    r, nr, wall = hole_probe(x, y, 8)
    hole = wall & (nr < -0.9) & (r < 2.0)           # concave = hole wall
    bossw = wall & (nr > 0.9) & (r > 2.0) & (r < 3.6)
    ph = None; pb = None
    if hole.sum() > 20:
        cx, cy, R, res, nn = circle_fit_robust(c[hole, 0], c[hole, 1]); ph = (cx, cy, 2 * R, res, float(c[hole, 2].min()), float(c[hole, 2].max()))
    if bossw.sum() > 20:
        cx, cy, R, res, nn = circle_fit_robust(c[bossw, 0], c[bossw, 1]); pb = (cx, cy, 2 * R, res, float(c[bossw, 2].min()), float(c[bossw, 2].max()))
    rb = (r < 1.0) & (n[:, 2] > 0.9) & (de > 2.0) & (c[:, 2] < 5)
    zb = float(np.median(c[rb, 2])) if rb.sum() > 4 else None
    rt = (r > 1.6) & (r < 2.4) & (n[:, 2] > 0.9) & (de > 2.0) & (c[:, 2] < 5)
    zt = float(np.median(c[rt, 2])) if rt.sum() > 4 else None
    par = dict(x=(ph or pb or (x, y))[0], y=(ph or pb or (x, y))[1], D_hole=ph[2] if ph else None, D_boss=pb[2] if pb else None, z_boss_top=zt, z_hole_bottom=zb,
               hole_depth=(zt - zb) if (zt is not None and zb is not None) else None, hole_wall_z=(ph[4], ph[5]) if ph else None)
    diffs = []
    if ph and abs(ph[2] - 2.6) > 0.15: diffs.append(f"hole D {ph[2]:.2f} vs 2.6")
    if par['hole_depth'] is not None and abs(par['hole_depth'] - 8.0) > 0.8: diffs.append(f"hole depth {par['hole_depth']:.1f} vs 8.0")
    if pb and abs(pb[2] - 6.0) > 0.3 and k != "H1": diffs.append(f"boss D {pb[2]:.2f} vs 6.0")
    if zt is not None and abs(zt - 0.0) > 0.3 and k != "H1": diffs.append(f"boss top {zt:.2f} vs 0")
    add("FLOORHOLE_" + k, "floor boss+hole" if k != "H1" else "floor hole", par, "circle fits on hole / boss wall tris, plane peaks", ph[3] if ph else None, disc(x, y, 6.0, 2.0), dict(x=x, y=y, D_hole=2.6, D_boss=6.0 if k != "H1" else None, hole_depth=8.0, z_boss_top=0.0),
        "; ".join(diffs) or "matches part 5", "")

# ================================================================= knee cover pins N1 / N2
for k, (x, y) in DS.KNEE_COVER_PINS.items():
    r, nr, wall = hole_probe(x, y, 9)
    pin = wall & (r < 2.2) & (nr > 0.9) & (c[:, 2] > 7.8); lug = wall & (r > 2.2) & (r < 4.3) & (nr > 0.9) & (c[:, 2] < 7.4)
    pp = lg = None
    if pin.sum() > 15: cx, cy, R, res, nn = circle_fit_robust(c[pin, 0], c[pin, 1]); pp = (cx, cy, 2 * R, res, float(c[pin, 2].max()))
    if lug.sum() > 15: cx, cy, R, res, nn = circle_fit_robust(c[lug, 0], c[lug, 1]); lg = (cx, cy, 2 * R, res, float(c[lug, 2].min()), float(c[lug, 2].max()))
    rb = (r < 2.0) & (n[:, 2] > 0.9) & (c[:, 2] > 8.5) & (c[:, 2] < 20) & (de > 1.0)
    ztip = float(np.median(c[rb, 2])) if rb.sum() > 4 else (pp[4] if pp else None)
    rl = (r > 2.2) & (r < 3.5) & (n[:, 2] > 0.95) & (abs(c[:, 2] - 7.5) < 0.4)
    zbase = float(np.median(c[rl, 2])) if rl.sum() > 4 else None
    par = dict(x=pp[0] if pp else x, y=pp[1] if pp else y, D_pin=pp[2] if pp else None, z_base=zbase, z_tip=ztip, len=(ztip - zbase) if (ztip and zbase) else None,
               D_lug=lg[2] if lg else None, lug_z=(lg[4], lg[5]) if lg else None)
    diffs = []
    if par['len'] and abs(par['len'] - DS.N_PIN_LEN) > 0.4: diffs.append(f"pin length {par['len']:.2f} vs {DS.N_PIN_LEN}")
    if lg and abs(lg[2] - 8.0) > 0.4: diffs.append(f"lug D {lg[2]:.2f} vs 8.0")
    if pp and abs(pp[2] - 3.0) > 0.2: diffs.append(f"pin D {pp[2]:.2f} vs 3.0")
    add("COVERPIN_" + k, "pin+lug+web", par, "circle fits pin/lug walls, plane peaks", pp[3] if pp else None, disc(x, y, 8.5, 1.0, c[:, 2] > -9),
        dict(x=x, y=y, D_pin=3.0, len=DS.N_PIN_LEN, z_base=7.49, D_lug=8.0, web_t=6.0), "; ".join(diffs) or "matches part 5", "")

# ================================================================= clip (post + head + rails + ring)
th = np.radians(-4.6); a1 = np.array([np.cos(th), np.sin(th)]); a2 = np.array([-np.sin(th), np.cos(th)]); OA = np.array([94.42, 206.92])
dd = c[:, :2] - OA; lx = dd @ a1; ly = dd @ a2
box = (abs(lx) < 4.8) & (abs(ly) < 7.6)
idx = np.where(box & (c[:, 2] > 1.0) & (de > 0.2))[0]
r_ = np.hypot(dd[:, 0], dd[:, 1])
mpost = box & (n[:, 2] > 0.95) & (abs(ly) < 4.5) & (r_ > 2.8) & (r_ < 4.2)
zp = float(np.median(c[mpost, 2])) if mpost.sum() > 5 else None
mrail = box & (n[:, 2] > 0.95) & (abs(ly) > 4.5) & (abs(ly) < 7.0) & (c[:, 2] > 5.0); zr = float(np.median(c[mrail, 2])) if mrail.sum() > 5 else None
mring = (r_ < 2.4) & (r_ > 1.5) & (n[:, 2] > 0.95) & (c[:, 2] > 3); zring = float(np.median(c[mring, 2])) if mring.sum() > 5 else None
mh = (r_ < 3.0) & (abs(n[:, 2]) < 0.25) & (c[:, 2] > 3) & (c[:, 2] < 8) & (de > 0.2)
hp = circle_fit_robust(c[mh, 0], c[mh, 1]) if mh.sum() > 20 else None
mhead = box & (c[:, 2] > 5.5) & (n[:, 2] > 0.5)
ext = (lx[mhead].min(), lx[mhead].max(), ly[mhead].min(), ly[mhead].max()) if mhead.sum() > 10 else None
par = dict(hole_xy=(hp[0], hp[1]) if hp else None, D_hole=2 * hp[2] if hp else None, z_post_top=zp, z_rail_top=zr, z_ring_top=zring, head_extent_local=ext)
diffs = []
if zp and abs(zp - 4.78) > 0.2: diffs.append(f"post top {zp:.2f} vs 4.78")
if zr and abs(zr - 7.7) > 0.3: diffs.append(f"rail top {zr:.2f} vs 7.7")
if zring and abs(zring - 6.2) > 0.3: diffs.append(f"ring top {zring:.2f} vs 6.2")
add("CLIP_HEAD", "clip", par, "plane peaks in the rotated box (-4.6 deg), circle fit hole", hp[3] if hp else None, idx, dict(O=tuple(OA), post_top=4.78, rail_top=7.7, ring_top=6.2, hole_D=2.7), "; ".join(diffs) or "matches part 5", "")

# ================================================================= tabs
E_ = np.array([np.sqrt(.5), np.sqrt(.5)]); D_ = np.array([np.sqrt(.5), -np.sqrt(.5)])
uu = c[:, 0] * E_[0] + c[:, 1] * E_[1]; ww = c[:, 0] * D_[0] + c[:, 1] * D_[1]
mC = (uu > 141.2) & (uu < 147.0) & (ww > -198.5) & (ww < -188.0) & (c[:, 2] > -3) & (de > 0.3)
fa = mC & (abs(n[:, 0] * E_[0] + n[:, 1] * E_[1]) > 0.95)
pk = peaks(uu[fa], a[fa], 0.05, 0.1, rng=(141, 147.5))
par = dict(face_u=[round(p[0], 2) for p in pk[:3]], z_range=(float(np.percentile(c[mC, 2], 1)), float(np.percentile(c[mC, 2], 99))))
add("TAB_C", "tab", par, "plane peaks of the two faces of the 45 deg slab", None, np.where(mC)[0], dict(u0=142.92, u1=145.50, w=(-197, -189.78), z_top=20.21), "", "")
mD = (c[:, 0] > -22.5) & (c[:, 0] < -16.5) & (c[:, 1] > 179) & (c[:, 1] < 193.5) & (c[:, 2] > -4) & (de > 0.3)
fa = mD & (abs(n[:, 0]) > 0.95)
pk = peaks(c[fa, 0], a[fa], 0.05, 0.1, rng=(-23, -16))
par = dict(face_x=[round(p[0], 2) for p in pk[:3]], z_range=(float(np.percentile(c[mD, 2], 1)), float(np.percentile(c[mD, 2], 99))), y_range=(float(np.percentile(c[mD, 1], 1)), float(np.percentile(c[mD, 1], 99))))
add("TAB_D", "tab", par, "plane peaks of the two faces", None, np.where(mD)[0], dict(x=(-20.42, -18.03), y=(181.5, 191.85), z_top=8.15), "", "")

# ================================================================= hip
rr = np.hypot(c[:, 0] - hx, c[:, 2] - hz); phi = np.degrees(np.arctan2(c[:, 2] - hz, c[:, 0] - hx)) % 360
yb = (c[:, 1] > 265.5) & (c[:, 1] < 277.5)
m0 = yb & (n[:, 1] < -0.95) & (rr > 55) & (rr < 70); y0 = float(np.median(c[m0, 1])) if m0.sum() > 10 else None
m1 = yb & (n[:, 1] > 0.95) & (rr > 54.5) & (rr < 66); y1 = float(np.median(c[m1, 1])) if m1.sum() > 10 else None
m1b = (c[:, 1] > 275) & (c[:, 1] < 277.5) & (n[:, 1] > 0.95) & (rr > 40) & (rr < 52); y1b = float(np.median(c[m1b, 1])) if m1b.sum() > 10 else None
idx = np.where(yb & (rr > 53.5) & (de > 1.5))[0]
add("HIP_PLATE", "plate", dict(y_inside=y0, y_end_outer=y1, y_end_inner=y1b), "plane peaks of the plate faces", None, idx, dict(y0=DS.HIP_Y0, y1=DS.HIP_Y1), "", "")
idx = np.where(yb & (rr < 53.5) & (de > 0.5))[0]
par = {}
for lab, (ya, yb_, r0, r1) in {"r_bore_A": (265.6, 268.8, 47, 50), "r_bore_B": (269.6, 270.9, 42, 44.5), "r_bore_C": (271.6, 275.5, 39.5, 42.5), "r_ring_od": (266.5, 276.5, 51, 54)}.items():
    mm = yb & (abs(c[:, 1] - (ya + yb_) / 2) < (yb_ - ya) / 2) & (abs(n[:, 1]) < 0.25) & (rr > r0) & (rr < r1)
    par[lab] = float(np.median(rr[mm])) if mm.sum() > 20 else None
for lab, (ya, yb_, r0, r1, sg) in {"y_step_A": (268.5, 270.5, 43.2, 48.4, -1), "y_step_B": (270.5, 272.5, 41.2, 42.9, -1)}.items():
    mm = yb & (n[:, 1] * sg > 0.95) & (rr > r0) & (rr < r1) & (c[:, 1] > ya) & (c[:, 1] < yb_)
    par[lab] = float(np.median(c[mm, 1])) if mm.sum() > 10 else None
add("HIP_RING_BORE", "revolve", par, "median radius of axisymmetric walls about the hip axis, plane peaks", None, idx, dict(r_bore_A=48.77, r_bore_B=42.98, r_bore_C=40.99, r_ring_od=52.5, y_step_A=269.45, y_step_B=271.4), "", "")
m = (abs(c[:, 1] - 276.85) < 0.2) & (n[:, 1] > 0.95) & (rr > 44.7) & (rr < 46.7)
hh, ed = np.histogram(phi[m], bins=720, range=(0, 360), weights=a[m]); gap = hh < 0.02 * hh.max()
segs = []; i = 0
while i < 720:
    if gap[i]:
        j = i
        while j < 720 and gap[j]: j += 1
        segs.append((ed[i], ed[j])); i = j
    else: i += 1
mid = np.array([(s0 + s1) / 2 for s0, s1 in segs[1:-1]]); wd = np.array([s1 - s0 for s0, s1 in segs[1:-1]])
idx = np.where(((rr > 42) & (rr < 50) & (c[:, 1] > 270) & (c[:, 1] < 277.3) & (abs(n[:, 1]) < 0.4)) | ((rr > 42) & (rr < 50) & (abs(c[:, 1] - 276.9) < 0.3) & (n[:, 1] > 0.9)))[0]
add("HIP_BOLT_HOLES", "hole pattern", dict(n=int(len(segs) - 1), pitch_deg=float(np.median(np.diff(mid))), phase_deg=float(np.median(mid % 13.846)), cbore_D=float(2 * 45.7 * np.sin(np.radians(wd.mean() / 2)))),
    "angular gaps in the end face ring r45.7", None, idx, dict(n=26, PCD=91.45, D=4.07, cbore_D=7.53, cbore_depth=4.15), "", "")
