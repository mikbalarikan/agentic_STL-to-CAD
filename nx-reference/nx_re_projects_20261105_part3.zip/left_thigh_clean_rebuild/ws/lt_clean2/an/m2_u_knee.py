import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
P=[]
for n,s in (("out_scan","out"),("inn_scan","inn")):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f); ex=np.load(f"work/m2/ext_{s}.npy"); P.append(c[ex])
P=np.vstack(P)
fig,axs=plt.subplots(2,4,figsize=(32,15))
for ax,y in zip(axs.ravel(),(-40,-20,0,15,30,45,55,65)):
    q=P[np.abs(P[:,1]-y)<=0.6]; ax.plot(q[:,0],q[:,2],'k.',ms=2)
    R=np.sqrt(max(68.9**2-y**2,0)); ax.plot([-R,-R,R,R],[-13.9,83.6,83.6,-13.9],'r-',lw=.8)
    ax.set_aspect('equal'); ax.set_title(f"Y={y} drum half width {R:.1f}"); ax.grid(True)
plt.tight_layout(); plt.savefig("work/m2/knee_secs.png",dpi=40)
