"""Voxel proxy of Shell 3.1: wall-thickness feasibility of the closed envelope. usage s1_shellproxy.py env.stl tag"""
import sys, os, time, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_lib import *
import trimesh
from scipy import ndimage as ndi
m = trimesh.load(sys.argv[1], process=False); tag = sys.argv[2]
v, f = np.asarray(m.vertices), np.asarray(m.faces)
print('watertight', m.is_watertight, 'volume', m.volume)
H = 0.8; lo = v.min(0) - 3; hi = v.max(0) + 3; dim = np.ceil((hi - lo) / H).astype(int); print(dim, dim.prod() / 1e6)
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(v.astype(np.float32)), o3d.core.Tensor(f.astype(np.uint32)))
occ = np.zeros(dim, bool)
gx = lo[0] + (np.arange(dim[0]) + 0.5) * H; gz = lo[2] + (np.arange(dim[2]) + 0.5) * H
t0 = time.time()
for j in range(dim[1]):
    y = lo[1] + (j + 0.5) * H
    X, Z = np.meshgrid(gx, gz, indexing='ij'); pts = np.c_[X.ravel(), np.full(X.size, y), Z.ravel()].astype(np.float32)
    occ[:, j, :] = sc.compute_occupancy(o3d.core.Tensor(pts)).numpy().reshape(dim[0], dim[2]) > 0.5
print('occupancy', time.time() - t0, occ.sum() * H**3)
d = ndi.distance_transform_edt(occ, sampling=H)
t = 3.1
core = d >= t
lab, n = ndi.label(core); sizes = ndi.sum(core, lab, range(1, n + 1))
print('core components', n, 'sizes (voxels)', sorted(sizes.astype(int))[-5:])
# shell thickness feasibility: every solid voxel must be within 3.1+1.2 of the core (otherwise region thinner than ~6.2 or sharp tip)
dist_core = ndi.distance_transform_edt(~core, sampling=H)
thin = occ & (dist_core > t + 1.6)
print('thin-region voxels', int(thin.sum()), 'volume mm3', thin.sum() * H**3)
lab2, n2 = ndi.label(thin)
res = dict(core_components=int(n), thin_voxels=int(thin.sum()), thin_mm3=float(thin.sum() * H**3))
if n2:
    big = np.argsort(ndi.sum(thin, lab2, range(1, n2 + 1)))[::-1][:6]
    clusters = []
    for b in big:
        idx = np.argwhere(lab2 == b + 1); c = lo + (idx.mean(0) + 0.5) * H; ext = (idx.max(0) - idx.min(0) + 1) * H
        clusters.append(dict(center=[round(float(a), 1) for a in c], size=[round(float(a), 1) for a in ext], voxels=int((lab2 == b + 1).sum())))
        print('  thin cluster at', clusters[-1])
    res['clusters'] = clusters
json.dump(res, open(os.path.join(S1, f'shellproxy_{tag}.json'), 'w'), indent=1)
# local thickness estimate along medial ridge omitted; report min d at the ridge crudely: max of d per (x,z) column along y
