from i2_rows import *
x,y,z=c[:,0],c[:,1],c[:,2]
m=(n[:,2]<-0.9)&(z>35.8)&(z<79.0)&(x>-8)&(x<58)&(y>48)&(y<85)&(d>=2.0)
# cluster per x-bin: lowest z tris (rib free edge) -> where is the rib?
for x0 in np.arange(-8,58,4.0):
    s=m&(x>=x0)&(x<x0+4)
    if s.sum()<5: print(x0,"none"); continue
    zz=z[s]; lo=s&(z<np.percentile(zz,10)+1.0)
    print(f"x {x0:4.0f}..{x0+4:4.0f}  low-z tris n={lo.sum():4d} z med {np.median(z[lo]):6.2f}  y med {np.median(y[lo]):6.2f} y range {np.percentile(y[lo],5):.1f}..{np.percentile(y[lo],95):.1f}")
