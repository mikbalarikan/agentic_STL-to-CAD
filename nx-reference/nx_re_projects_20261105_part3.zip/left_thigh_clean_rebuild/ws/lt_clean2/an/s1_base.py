from s1_lib import *
import trimesh
m=trimesh.load(os.path.join(W,'env_part5.stl'),process=False)
v5,f5=np.asarray(m.vertices),np.asarray(m.faces)
res={}
for s in ['out','inn']:
    v,f,c,n,a=scan(s)
    for z in ['ext_drum','ext_body','ext_hip']:
        mk=mask(s,z); d=dist_to_mesh(c[mk],v5,f5); res[s+'_'+z]=stats(d,a[mk]); print(s,z,res[s+'_'+z], flush=True)
