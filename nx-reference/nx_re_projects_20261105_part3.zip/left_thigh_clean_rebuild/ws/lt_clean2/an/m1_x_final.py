"""M1 final: masks, scores, plots, join boundary, features, JSON."""
import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from m1_r_design import profile,dist2poly,nrm_poly,stats,S,SEG
from scipy import ndimage
OUT="work/m1/"; os.makedirs("work/masks",exist_ok=True)
DES=dict(Rp=68.85,zp=36.07,draft=float(sys.argv[1]) if len(sys.argv)>1 else 1.6,Zb=-13.9,Zt=83.6,cb=3.3,ct=3.1)
AXD=(0.0,0.0); AXF=(0.14,-0.01)
design=(DES["Rp"],DES["zp"],DES["draft"],DES["Zb"],DES["Zt"],DES["cb"],DES["ct"])
poly=profile(*design); nr=nrm_poly(poly); t=np.tan(np.radians(DES["draft"]))
def evalset(axis,loose=1.5):
    R={}
    for nm,(c,nn,ar) in S.items():
        x=c[:,0]-axis[0]; y=c[:,1]-axis[1]; rho=np.hypot(x,y); ang=np.degrees(np.arctan2(x,-y))
        d,who=dist2poly(rho,c[:,2],poly)
        # signed distance
        # closest segment normal
        a=poly[who]; sd=((rho-a[:,0])*nr[who,0]+(c[:,2]-a[:,1])*nr[who,1])
        ur=np.c_[x,y]/np.maximum(rho,1e-9)[:,None]
        dot=(nn[:,0]*ur[:,0]+nn[:,1]*ur[:,1])*nr[who,0]+nn[:,2]*nr[who,1]
        zr=(-14.5,35.0) if nm=="out_scan" else (35.4,84.2)
        rho_edge_top=poly[5,0]+0.3; 
        planeok=((who==5)&(rho<=rho_edge_top)&(rho>20))|((who==0)&(rho<=poly[1,0]+0.2)&(rho>poly[0,0]-0.1))
        cone=((who>=1)&(who<=4))&(ang>-175)&(ang<50.9)
        m=(d<loose)&(dot>np.cos(np.radians(25)))&(c[:,2]>zr[0])&(c[:,2]<zr[1])&(planeok|cone)
        # plane segs only valid in own scan
        if nm=="out_scan": m&=(who<=2)
        else: m&=(who>=3)|((who==2)&(c[:,2]>35.4))
        R[nm]=dict(m=m,d=d,sd=sd,who=who,ang=ang,rho=rho,z=c[:,2],ar=ar)
    return R
Rd=evalset(AXD); Rf=evalset(AXF)
res={"design":DES,"design_axis_origin":AXD,"alt_axis_fit":AXF}
sc={}
for lab,R in (("origin",Rd),("axis_fit",Rf)):
    sc[lab]={}
    for nm,r in R.items():
        m=r["m"]; w=r["ar"]
        sc[lab][nm]={"ALL":stats(r["d"][m],w[m])}
        for i,sname in enumerate(SEG):
            k=m&(r["who"]==i)
            if k.sum()>50: sc[lab][nm][sname]=stats(r["d"][k],w[k])
res["scores"]=sc
for lab in sc:
    print(lab)
    for nm in sc[lab]:
        for k,v in sc[lab][nm].items(): print(f"  {nm[:3]} {k:18s} n {v['n']:6d} area {v['area']:7.0f} p50 {v['p50']:.3f} p90 {v['p90']:.3f} <=.3 {v['le0p3']:.3f} <=.5 {v['le0p5']:.3f}")
# masks
for nm,r in Rd.items():
    pre="out" if nm=="out_scan" else "inn"; m=r["m"]
    np.save(f"work/masks/{pre}_ext_drum.npy",np.where(m)[0].astype(np.int64))
    for sname,ids in (("cone",(1+1,1+2)),("chamfer",(1,4)),("topplane",(5,)),("botplane",(0,))):
        k=m&np.isin(r["who"],ids if sname!="cone" else (2,3))
        if sname=="chamfer": k=m&np.isin(r["who"],(1,4))
        if k.sum()>0: np.save(f"work/masks/{pre}_ext_drum_{sname}.npy",np.where(k)[0].astype(np.int64))
    print(pre,"mask tris",m.sum(),"area",r["ar"][m].sum().round(0),"ang range cone 1-99%",np.percentile(r["ang"][m&np.isin(r["who"],(2,3))],[1,99]).round(1))
# ---- feature search: signed dev outliers in loose mask
feat=[]
for nm,r in Rd.items():
    m=r["m"]&(np.abs(r["sd"])>0.3)
    # grid cluster in (ang, z)
    A=r["ang"][m]; Z=r["z"][m]; SD=r["sd"][m]; W=r["ar"][m]
    gi=np.floor((A+180)/2).astype(int); gj=np.floor((Z+20)/1).astype(int)
    G=np.zeros((200,130)); 
    np.add.at(G,(gi,gj),W)
    lab,n=ndimage.label(G>0.5,structure=np.ones((3,3)))
    for l in range(1,n+1):
        k=lab[gi,gj]==l
        if W[k].sum()<8: continue
        feat.append(dict(scan=nm,area=float(W[k].sum()),ang=[float(A[k].min()),float(A[k].max())],z=[float(Z[k].min()),float(Z[k].max())],sd_mean=float(np.average(SD[k],weights=W[k])),sd_range=[float(np.percentile(SD[k],5)),float(np.percentile(SD[k],95))]))
feat.sort(key=lambda a:-a["area"]); res["outlier_clusters_sd_gt_0p3"]=feat[:25]
for f_ in feat[:15]: print("feat",f_["scan"][:3],"area %.0f"%f_["area"],"ang",np.round(f_["ang"],0),"z",np.round(f_["z"],1),"sd mean %.2f"%f_["sd_mean"])
json.dump(res,open(OUT+"_final_partial.json","w"),indent=1)
np.savez(OUT+"_R.npz",**{f"{nm}_{k}":v for nm,r in Rd.items() for k,v in r.items()})
