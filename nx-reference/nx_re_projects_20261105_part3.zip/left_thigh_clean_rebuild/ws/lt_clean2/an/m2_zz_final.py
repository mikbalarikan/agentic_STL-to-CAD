import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, trimesh, m2_loft as L, m2_g_fit as G, m2_o_fitband as B, m2_q_env as Q, m2_f_data as FD
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
tag="U72"; d=np.load(f"work/m2/loft_{tag}.npz"); st=d["st"]; P=d["P"]; lf=L.Loft(st,P.shape[1],P)
V,F,ys,u=G.mesh_of(lf,st[0],st[-1])
S=G.scan_pts(60,255); y=S[:,1]; dd=G.dist_to(V,F,S[:,:3]); ib=B.inband(y,S[:,0],S[:,2],1.0); a=S[:,3]
m5=trimesh.load("work/env_part5.stl",process=False); d5=G.dist_to(np.asarray(m5.vertices),np.asarray(m5.faces),S[:,:3])
R={}
def st_(nm,m,dv):
    f,p90,p50=G.stats(dv[m],a[m]); R[nm]=dict(within_0p5_pct=round(100*f,2),p90=round(p90,3),p50=round(p50,3),n_tri=int(m.sum()),area_mm2=round(float(a[m].sum()),0)); return R[nm]
for nm,m in (("body_outside_band_60_255",~ib),("outside_60_100",~ib&(y<100)),("outside_100_250",~ib&(y>=100)&(y<=250)),("outside_250_255",~ib&(y>250)),("all_60_255_incl_band",y>0)):
    st_("loft_"+nm,m,dd); st_("part5_"+nm,m,d5)
# band: floor should be loft - 1.12 (distance to envelope ~1.12)
bm=B.inband(y,S[:,0],S[:,2],-3.0)&(y<=256)
db=np.abs(dd-Q.BAND_DEPTH); st_("band_floor_vs_env_minus_1p12",bm,db)
R["band_dist_to_env"]=dict(median=round(float(np.median(dd[bm])),3),p10=round(float(np.percentile(dd[bm],10)),3),p90=round(float(np.percentile(dd[bm],90)),3))
print(json.dumps(R,indent=1))
# per-Y-band table
tab=[]
for lo in range(60,256,10):
    m=~ib&(y>=lo)&(y<lo+10); f,p90,_=G.stats(dd[m],a[m]); f5,p905,_=G.stats(d5[m],a[m]); tab.append((lo,round(100*f,1),round(p90,2),round(100*f5,1),round(p905,2)))
R["per_10mm"]=tab
# sections figure
Pts=np.load("work/m2/ext_pts.npy")
Ys=[60,70,82,100,125,155,185,215,240,255]
fig,axs=plt.subplots(2,5,figsize=(40,17))
for ax,yy in zip(axs.ravel(),Ys):
    q=Pts[np.abs(Pts[:,1]-yy)<=0.5]; ax.plot(q[:,0],q[:,2],'k.',ms=2)
    C=lf.curve(yy,np.linspace(0,1,1440))[0]; ax.plot(C[:,0],C[:,1],'r-',lw=.8)
    pol=lf.P  # station poles
    ax.set_aspect('equal'); ax.set_title(f"Y={yy}"); ax.grid(True)
plt.tight_layout(); plt.savefig("work/m2/final_sections.png",dpi=38)
# deviation map
th=np.degrees(np.arctan2(S[:,2]-35,S[:,0]-40))
fig,axs=plt.subplots(1,2,figsize=(24,14))
for ax,dv,t in zip(axs,(dd,d5),("loft U72 (K10, NP72) vs scan","part 5 envelope vs scan")):
    sc=ax.scatter(th,y,c=np.where(ib,np.nan,dv),s=1,cmap='jet',vmin=0,vmax=1.0); ax.set_title(t+" (+X band masked)"); ax.set_xlabel("theta deg (0=+X, 90=+Z)"); ax.set_ylabel("Y"); ax.grid(True)
plt.colorbar(sc,ax=axs); plt.savefig("work/m2/final_devmap.png",dpi=45)
json.dump(R,open("work/m2/_final_stats.json","w"),indent=1,default=float)
