import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
import open3d as o3d
W = lib.W; S1 = os.path.join(W, 's1'); os.makedirs(S1, exist_ok=True)
_scan = {}
def scan(s):
    if s not in _scan:
        v, f = lib.load(s + '_scan', 1500000); c, n, a = lib.tri_data(v, f)
        _scan[s] = (v, f, c, n, a)
    return _scan[s]
def mask(s, nm): return np.load(os.path.join(W, 'masks', f'{s}_{nm}.npy'))
def dist_to_mesh(pts, v, f):
    sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.core.Tensor(np.asarray(v, np.float32)), o3d.core.Tensor(np.asarray(f, np.uint32)))
    return sc.compute_distance(o3d.core.Tensor(np.asarray(pts, np.float32))).numpy()
def signed_dist(pts, v, f):
    sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.core.Tensor(np.asarray(v, np.float32)), o3d.core.Tensor(np.asarray(f, np.uint32)))
    return sc.compute_signed_distance(o3d.core.Tensor(np.asarray(pts, np.float32))).numpy()
def stats(d, a, t=0.5):
    w = a / a.sum(); o = np.argsort(d); cw = np.cumsum(w[o])
    p90 = d[o][np.searchsorted(cw, 0.9)]
    return dict(pct=round(100 * w[d <= t].sum(), 2), p90=round(float(p90), 3), n=len(d))
