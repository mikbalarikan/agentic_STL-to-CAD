import sys
from s1_shell import *
from s1_build import build, cone_solid
from s1_geo import *
tag=sys.argv[1]
d=np.load(f'work/s1/loft_{tag}.npz'); st=d['st']; P=d['P']
def capface(shape,Y):
    for f in faces(shape):
        a=BRepAdaptor_Surface(f)
        if a.GetType()==GeomAbs_Plane and abs(a.Plane().Location().Y()-Y)<1e-3: return f
def test(shape,name,cf,t=3.1,jn=GeomAbs_Arc):
    lst=TopTools_ListOfShape(); lst.Append(cf); mk=BRepOffsetAPI_MakeThickSolid(); t0=time.time()
    mk.MakeThickSolidByJoin(shape,lst,-t,1e-3,BRepOffset_Skin,True,False,jn); mk.Build()
    s=mk.Shape() if mk.IsDone() else None
    print(name,t,'done',mk.IsDone(),'valid',valid(s) if s else None,'vol',round(volume(s)) if s else None,'orig',round(volume(shape)),round(time.time()-t0,1),flush=True)
for sub,name in [(slice(2,None),'loft from Y-34'),(slice(0,None),'loft full H')]:
    s2=st[sub]; P2=P[sub]
    lo=loft(P2,s2); test(lo,name,capface(lo,s2[-1]))
    lo2=common(lo,cone_solid()); 
    test(lo2,name+' + cone',mouth_face(lo2))
