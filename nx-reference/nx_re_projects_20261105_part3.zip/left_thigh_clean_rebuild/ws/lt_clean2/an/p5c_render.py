import numpy as np, pyvista as pv, sys
pv.OFF_SCREEN = True
P = "nx/P5c/"
mo = pv.read(P + "out_P5c.stl"); mi = pv.read(P + "inn_P5c.stl")
def shot(name, mesh, pos, focal, par, up=(0, 0, 1), size=(1500, 1000), color="lightsteelblue", clim=None, axis=2):
    p = pv.Plotter(off_screen=True, window_size=size, lighting="none"); p.set_background("white")
    if clim:
        mesh = mesh.copy(); mesh["h"] = mesh.points[:, axis]
        p.add_mesh(mesh, scalars="h", clim=clim, cmap="coolwarm", show_scalar_bar=False, smooth_shading=False, specular=0.1, ambient=0.35, diffuse=0.65)
    else:
        p.add_mesh(mesh, color=color, smooth_shading=False, specular=0.1, ambient=0.35, diffuse=0.65)
    p.camera_position = [pos, focal, up]; p.camera.enable_parallel_projection(); p.camera.parallel_scale = par
    d = np.array(focal, float) - np.array(pos, float); d /= np.linalg.norm(d)
    side = np.cross(d, np.array(up, float)); side /= np.linalg.norm(side)
    u = np.cross(side, d)
    for k, (a, b, inten) in enumerate(((0.8, 0.7, 0.55), (-0.9, 0.2, 0.25), (0.1, -0.8, 0.2))):
        lp = np.array(focal, float) + 300 * (-d * 0.6 + side * a + u * b)
        p.add_light(pv.Light(position=tuple(lp), focal_point=tuple(focal), intensity=inten, light_type="scene light"))
    p.screenshot(P + name); p.close(); print(name)
which = sys.argv[1:] or ["all"]
def on(k): return "all" in which or k in which
if on("side"):
    shot("p5c_out_side_PX.png", mo, (400, 162, 14), (110, 162, 14), 36, clim=(98, 130), axis=0)
    shot("p5c_out_side_MX.png", mo, (-400, 212, 14), (-30, 212, 14), 42, clim=(-80, -20), axis=0)
    shot("p5c_inn_side_PX.png", mi, (400, 162, 44), (110, 162, 44), 36, clim=(98, 130), axis=0)
    shot("p5c_inn_side_MX.png", mi, (-400, 212, 50), (-30, 212, 50), 42, clim=(-80, -20), axis=0)
if on("hub"):
    shot("p5c_inn_hub.png", mi, (130, -110, 190), (0, 0, 85), 40, clim=(80, 94))
    shot("p5c_inn_hub_top.png", mi, (0, 0, 400), (0, 0, 85), 36, up=(0, 1, 0), clim=(80, 94))
if on("knee"):
    shot("p5c_inn_knee_under.png", mi, (0, 0, -300), (30, 80, 80), 95, up=(0, 1, 0), size=(1500, 1500), clim=(62, 86))
    shot("p5c_inn_knee_holes.png", mi, (60, 40, -300), (58, 95, 80), 42, up=(0, 1, 0), clim=(74, 86))
    shot("p5c_inn_window.png", mi, (-300, 10, 30), (-60, 10, 55), 45, up=(0, 0, 1), clim=(-80, -20), axis=0)
    shot("p5c_inn_oval.png", mi, (0, 0, -300), (0, 46, 80), 14, up=(0, 1, 0), clim=(74, 86))
if on("hip"):
    shot("p5c_out_hip_end.png", mo, (38, 500, 35), (38, 277, 35), 70, up=(0, 0, 1), clim=(266, 282), axis=1)
    shot("p5c_out_hip_obl.png", mo, (150, 400, 150), (38, 277, 20), 70, up=(0, 0, 1), clim=(266, 282), axis=1)
    shot("p5c_inn_hip_end.png", mi, (38, 500, 70), (38, 277, 70), 70, up=(0, 0, 1), clim=(266, 282), axis=1)
    shot("p5c_inn_hip_obl.png", mi, (150, 400, 160), (38, 277, 70), 70, up=(0, 0, 1), clim=(266, 282), axis=1)
if on("mate"):
    shot("p5c_out_mating.png", mo, (30, 100, 400), (30, 100, 30), 175, up=(0, 1, 0), size=(1100, 1700), clim=(30, 42))
    shot("p5c_inn_mating.png", mi, (30, 100, -300), (30, 100, 40), 175, up=(0, 1, 0), size=(1100, 1700), clim=(34, 50))
    shot("p5c_inn_mating_top.png", mi, (30, 100, 400), (30, 100, 70), 175, up=(0, 1, 0), size=(1100, 1700), clim=(40, 94))
    shot("p5c_out_boss_B2.png", mo, (120, -20, 120), (76, 30, 38), 22, clim=(28, 42))
    shot("p5c_inn_boss_B2.png", mi, (120, -20, -60), (76, 30, 40), 22, clim=(34, 50))
