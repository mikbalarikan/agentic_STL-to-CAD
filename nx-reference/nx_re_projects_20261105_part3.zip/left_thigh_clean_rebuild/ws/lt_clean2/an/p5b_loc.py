"""where are the high-deviation triangles of a mask. argv: which devtag mask [thr]"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
which, tag, mask = sys.argv[1:4]
thr = float(sys.argv[4]) if len(sys.argv) > 4 else 0.5
v, f = lib.load(which + '_scan', 1500000); c, nn, ar = lib.tri_data(v, f)
d = np.load('work/dev_%s_%s.npz' % (tag, which))['d1']
m = np.load('work/masks/%s_f_%s.npy' % (which, mask))
hi = m[d[m] > thr]
print(mask, 'n', len(m), 'hi', len(hi), 'p90 %.2f' % np.percentile(d[m], 90))
if len(hi):
    print(' hi centre x %.1f..%.1f y %.1f..%.1f z %.1f..%.1f' % (c[hi, 0].min(), c[hi, 0].max(), c[hi, 1].min(), c[hi, 1].max(), c[hi, 2].min(), c[hi, 2].max()))
    print(' hi median', np.median(c[hi], axis=0).round(2), ' mean d %.2f' % d[hi].mean())
    # histogram by z
    h, e = np.histogram(c[hi, 2], bins=8)
    print(' z hist', list(zip(e[:-1].round(1), h)))
    print(' normal mean', nn[hi].mean(axis=0).round(2))
