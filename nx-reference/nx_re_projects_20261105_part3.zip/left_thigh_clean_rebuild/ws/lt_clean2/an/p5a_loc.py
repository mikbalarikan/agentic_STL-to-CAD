import sys, numpy as np
sys.path.insert(0,'an')
import lib
which, tag, mask = sys.argv[1:4]
v,f = lib.load({'out':'out_scan','inn':'inn_scan'}[which],1500000)
c,nn,ar = lib.tri_data(v,f)
d = np.load('work/dev_%s_%s.npz'%(tag,which))['d1']
m = np.load('work/masks/%s_f_%s.npy'%(which,mask))
dm = d[m]; cm=c[m]; nm=nn[m]
print(mask,'n',len(m),'p50 %.2f p90 %.2f max %.2f'%(np.median(dm),np.percentile(dm,90),dm.max()), 'bbox', cm.min(0).round(1), cm.max(0).round(1))
bad = dm>0.5
print('bad frac %.3f'%bad.mean())
if bad.any():
    cb=cm[bad]; print('bad bbox',cb.min(0).round(1),cb.max(0).round(1),'mean',cb.mean(0).round(1))
    ax = sys.argv[4] if len(sys.argv)>4 else None
    if ax=='hip':
        r = np.hypot(cm[:,0]-37.97, cm[:,2]-35.18); 
        for lo,hi in [(0,41.5),(41.5,43.5),(43.5,49.5),(49.5,60)]:
            s=(r>=lo)&(r<hi)
            if s.any(): print('R %g-%g n %d p90 %.2f y range %.1f-%.1f'%(lo,hi,s.sum(),np.percentile(dm[s],90),cm[s,1].min(),cm[s,1].max()))
        ys = np.round(cm[:,1]).astype(int)
        for y in sorted(set(ys[bad])):
            s=ys==y
            print(' y',y,'n',s.sum(),'p50 %.2f'%np.median(dm[s]))
