"""Zone deviation scan->envelope on the exterior points. usage: s1_eval.py env.stl [tag]"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_lib import *
import trimesh
d = np.load(os.path.join(S1, 'ext_all.npz')); P = d['P']; A = d['a']; sid = d['sid']
x, y, z = P.T
def Rw(z): return 68.8588 - np.tan(np.radians(1.6)) * np.abs(np.clip(z, -13.9, 83.6) - 36.07)
foot = (np.hypot(x, y) < Rw(z) + 0.8) & (z > -14.7) & (z < 84.4)
import m2_o_fitband as B
zd, zb, zh = d['zd'], d['zb'], d['zh']
band = B.inband(y, x, z, 0.0) & (y >= 54) & (y <= 264) & ~foot & (z < 84.3)
bandcore = B.inband(y, x, z, -1.5) & (y >= 56) & (y <= 262) & ~foot & (z < 84.3)
none = ~(zd | zb | zh)
zones = {
 'drum': zd,
 'knee_fair(-38<Y<30)': none & (y < 30) & (y >= -38) & (z < 84.2) & ~foot,
 'knee_tail(Y<-38, z<62)': none & (y < -38) & (z < 62) & ~foot,
 'knee_tail(Y<-38, z>=62)': none & (y < -38) & (z >= 62) & (z < 84.2) & ~foot,
 'body_28-64 (excl band,foot)': zb & (y < 64) & ~band & ~foot,
 'body_64-262 (excl band)': zb & (y >= 64) & (y < 262) & ~band,
 'body_all (excl band,foot)': zb & ~band & ~foot,
 'hip (excl band)': zh & ~band,
 'hip_all (incl band 200-264)': zh,
}
def run(path, tag=None, verbose=True):
    paths = path.split(',')
    ms = [trimesh.load(p, process=False) for p in paths]
    v = np.vstack([np.asarray(m.vertices) for m in ms]); n0 = 0; fl = []
    for m in ms: fl.append(np.asarray(m.faces) + n0); n0 += len(m.vertices)
    f = np.vstack(fl)
    m0 = ms[0]; v0, f0 = np.asarray(m0.vertices), np.asarray(m0.faces)
    dd = dist_to_mesh(P, v, f)
    out = {}
    for k, msk in zones.items():
        out[k] = stats(dd[msk], A[msk])
        if verbose: print(f'{k:34s} {out[k]}')
    # band vs envelope - 1.12
    sd = signed_dist(P[bandcore], v0, f0)    # negative inside
    db = np.abs(sd + 1.12)
    out['band(floor vs env-1.12)'] = stats(db, A[bandcore])
    if verbose: print(f'{"band(floor vs env-1.12)":34s} {out["band(floor vs env-1.12)"]}')
    # whole exterior within 1 mm of envelope
    near = dd < 1.0
    out['G-ext (scan within 1mm)'] = stats(dd[near & ~band], A[near & ~band])
    if verbose: print(f'{"G-ext":34s} {out["G-ext (scan within 1mm)"]}')
    return out, dd
if __name__ == '__main__':
    out, dd = run(sys.argv[1])
    np.save(os.path.join(S1, 'dd_' + (sys.argv[2] if len(sys.argv) > 2 else 'x') + '.npy'), dd)
