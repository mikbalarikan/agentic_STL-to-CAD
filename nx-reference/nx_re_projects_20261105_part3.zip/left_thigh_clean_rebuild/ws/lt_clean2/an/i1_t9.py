from i1_common import *
from i1_fit import *
from i1_rib import BOSS_XY, PIN_XY
S=load_all(); c,n,a,de=S['c'],S['n'],S['a'],S['de']
def ring(x,y,r0,r1,zlo,zhi,dx=0,dy=0):
    r=np.hypot(c[:,0]-x,c[:,1]-y)
    m=(r>r0)&(r<r1)&(abs(n[:,2])<0.25)&(c[:,2]>zlo)&(c[:,2]<zhi)&(de>2.5)
    # radial normal criterion
    nr=((c[:,0]-x)*n[:,0]+(c[:,1]-y)*n[:,1])/np.maximum(r,1e-6)
    return m&(abs(nr)>0.9)
for k,(x,y) in BOSS_XY.items():
    out=[]
    for lab,(r0,r1,zl,zh) in (("col",(6.8,8.4,5,35.5)),("col_hi",(6.8,8.4,25,35.5)),("col_lo",(6.8,8.4,-10,15)),("spig",(4.3,5.8,36.5,39.2)),("hole",(1.8,3.6,27,42))):
        m=ring(x,y,r0,r1,zl,zh)
        if m.sum()<20: out.append(f"{lab}: n={m.sum()}"); continue
        cx,cy,R,res,nn=circle_fit_robust(c[m,0],c[m,1])
        out.append(f"{lab}: c({cx:.2f},{cy:.2f}) D{2*R:.2f} res{res:.3f} n{nn} z{np.median(c[m,2]):.1f}")
    print(k,(x,y)); [print("   ",o) for o in out]
