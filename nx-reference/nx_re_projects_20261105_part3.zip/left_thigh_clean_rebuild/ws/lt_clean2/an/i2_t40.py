from i2_sec import *
from i2_fit import circle_fit
v,f=mesh("scan"); vp,fp=mesh("p5")
def fit(vv,ff,y0,xlo,xhi,zlo,zhi):
    s=lib.section(vv,ff,1,float(y0)).reshape(-1,3); m=(s[:,0]>xlo)&(s[:,0]<xhi)&(s[:,2]>zlo)&(s[:,2]<zhi)
    P=s[m][:,[0,2]]; 
    if len(P)<10: return None
    cx,cz,R,rms=circle_fit(P); return round(R,2),round(rms,3),round(cx,2),round(cz,2),len(P)
for y0 in (-10,0,10):
    print("y",y0,"scan right-of-run-rib fillet",fit(v,f,y0,47.5,60,75.5,79.8),"p5",fit(vp,fp,y0,47.5,60,75.5,79.8))
print("ring outer face fillet (y=0, x -50..-45.5)",fit(v,f,0,-52,-45.3,75.5,79.8),"p5",fit(vp,fp,0,-52,-45.3,75.5,79.8))
print("ring inner face fillet (y=0, x -32..-26)",fit(v,f,0,-31.8,-25,75.5,79.8),"p5",fit(vp,fp,0,-31.8,-25,75.5,79.8))
