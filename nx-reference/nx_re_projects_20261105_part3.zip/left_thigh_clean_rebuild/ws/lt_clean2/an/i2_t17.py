from i2_rows import *
from scipy.signal import find_peaks
def levels(m, axis, lo, hi, bw=0.1, thr=0.1):
    h,ed=np.histogram(c[m,axis],bins=np.arange(lo,hi,bw),weights=a[m]); pk,_=find_peaks(h,height=h.max()*thr,distance=3)
    return [(round(ed[i]+bw/2,2),int(h[i])) for i in pk]
base=(d>=1.5)&(c[:,2]>36)
print("blocks left  ny faces y:",levels(base&(np.abs(n[:,1])>0.9)&(c[:,0]<-17)&(c[:,0]>-26)&(c[:,2]<60),1,255,285))
print("blocks right ny faces y:",levels(base&(np.abs(n[:,1])>0.9)&(c[:,0]>91)&(c[:,0]<100)&(c[:,2]<60),1,255,285))
print("pad ny faces y:",levels(base&(np.abs(n[:,1])>0.9)&(c[:,0]>24)&(c[:,0]<52)&(c[:,2]>82)&(c[:,2]<86),1,255,285))
print("web/center: ny faces y x 10..66 z>85:",levels(base&(np.abs(n[:,1])>0.9)&(c[:,0]>8)&(c[:,0]<68)&(c[:,2]>86)&(c[:,2]<100),1,255,285))
print("pad nz<0 z levels:",levels(base&(n[:,2]<-0.9)&(c[:,0]>22)&(c[:,0]<54)&(c[:,1]>266)&(c[:,1]<278),2,60,100,0.1))
print("pad x faces (nx) at y 268-276, z 86-100:",levels(base&(np.abs(n[:,0])>0.9)&(c[:,1]>268)&(c[:,1]<276)&(c[:,2]>82)&(c[:,2]<100)&(c[:,0]>10)&(c[:,0]<70),0,10,70))
print("plate-block x faces y 268-275, z 40-70:",levels(base&(np.abs(n[:,0])>0.9)&(c[:,1]>267.5)&(c[:,1]<275)&(c[:,2]>40)&(c[:,2]<70),0,-30,120))
print("hip pad region: y-faces for pad z 85.3: ", levels(base&(np.abs(n[:,1])>0.9)&(c[:,2]>84)&(c[:,2]<95)&(c[:,0]>20)&(c[:,0]<56),1,255,285))
print("---- web region")
for x0,x1 in ((-12,8),(14,22),(54,62),(68,88)):
    m=base&(np.abs(n[:,1])>0.9)&(c[:,0]>x0)&(c[:,0]<x1)&(c[:,1]>262)&(c[:,1]<280)&(c[:,2]<100)
    print(x0,x1,levels(m,1,262,280,0.1,0.15), "sign:", [round(float(np.median(n[m&(np.abs(c[:,1]-l[0])<0.3),1])),1) for l in levels(m,1,262,280,0.1,0.15)])
