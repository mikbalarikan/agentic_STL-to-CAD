import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
e5=trimesh.load("work/env_part5.stl",process=False); ve,fe=np.asarray(e5.vertices),np.asarray(e5.faces)
S={n:(lib.load(n,1500000) if 'scan' in n else lib.load(n)) for n in('out_scan','inn_scan','out_cad','inn_cad')}
sty=(('out_scan','k',.9,'out scan'),('inn_scan','b',.9,'inn scan'),('out_cad','r',.5,'old out'),('inn_cad','m',.5,'old inn'))
def draw(a,axis,val,ix,iy):
    for n,c,lw,lab in sty:
        for p,q in lib.section(*S[n],axis,val): a.plot([p[ix],q[ix]],[p[iy],q[iy]],c+'-',lw=lw)
    for p,q in lib.section(ve,fe,axis,val): a.plot([p[ix],q[ix]],[p[iy],q[iy]],'g-',lw=1.3)
    a.grid(True)
fig,ax=plt.subplots(2,3,figsize=(33,19))
for a,x in zip(ax.flat,(-42,-30,10,38,100,114)):
    draw(a,0,x,1,2); a.set_xlim(225,292); a.set_title(f"X={x}: (Y horizontal, Z vertical)  black/blue scans, red/magenta old, green part5"); a.set_aspect('equal')
plt.tight_layout(); plt.savefig("work/m3/cuts_X.png",dpi=42)
fig,ax=plt.subplots(2,3,figsize=(33,19))
for a,z in zip(ax.flat,(-30,0,20,50,80,100)):
    draw(a,2,z,1,0); a.set_xlim(225,292); a.set_title(f"Z={z}: (Y horizontal, X vertical)"); a.set_aspect('equal')
plt.tight_layout(); plt.savefig("work/m3/cuts_Z.png",dpi=42)
