import numpy as np, pyvista as pv, trimesh, open3d as o3d
pv.OFF_SCREEN = True
S = "nx/A_v2/"; P = "nx/A_v2/png_r1/"
m = trimesh.load("nx/base_v2/envelope.stl", process=False)
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32)))
def depth(mesh):
    mesh = mesh.copy()
    d = sc.compute_distance(o3d.core.Tensor(np.asarray(mesh.points, np.float32))).numpy()
    mesh["depth"] = d
    return mesh
mo = depth(pv.read(S + "out_A.stl")); mi = depth(pv.read(S + "inn_A.stl"))
def shot(name, pos, focal, par, size=(1500, 900), up=(0, 0, 1)):
    p = pv.Plotter(off_screen=True, window_size=size); p.set_background("white")
    for mm in (mo, mi):
        p.add_mesh(mm, scalars="depth", clim=(0, 1.4), cmap="turbo", show_scalar_bar=False, smooth_shading=False)
    p.add_scalar_bar if False else None
    p.camera_position = [pos, focal, up]; p.camera.enable_parallel_projection(); p.camera.parallel_scale = par
    p.screenshot(P + name); p.close(); print(name)
shot("panel_depth_plusX.png", (400, 150, 35), (60, 150, 35), 140)
shot("panel_depth_oblique_up.png", (330, 40, 200), (80, 150, 35), 150)
shot("panel_depth_oblique_dn.png", (330, 40, -130), (80, 150, 35), 150)
# r1 close-ups: panel end corner (y 255-263), start corner, tail tip corner
shot("r1_panel_end_out.png", (230, 258, -60), (100, 258, 14), 28, size=(1200, 900))
shot("r1_panel_end_inn.png", (230, 258, 130), (100, 258, 56), 28, size=(1200, 900))
shot("r1_panel_start_out.png", (230, 55, -60), (95, 56, 14), 28, size=(1200, 900))
shot("r1_tail_tip_out.png", (140, -120, 0), (62, -51, 20), 22, size=(1200, 900))
shot("r1_tail_tip_inn.png", (140, -120, 80), (62, -51, 50), 22, size=(1200, 900))
