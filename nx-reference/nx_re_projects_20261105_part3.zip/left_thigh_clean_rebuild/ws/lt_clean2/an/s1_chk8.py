import sys
from s1_lib import *
import m2_loft as L
tag=sys.argv[1]; d=np.load(f'work/s1/loft_{tag}.npz'); lf=L.Loft(d['st'],72,d['P'])
def Rw(z): return 68.8588-np.tan(np.radians(1.6))*abs(np.clip(z,-13.9,83.6)-36.07)
uu=np.linspace(0,1,2880,endpoint=False)
for zq in [10,36,60,75]:
    print('z',zq,'Y: loft r from drum axis - R_drum(z) on -X side')
    row=[]
    for Y in [40,44,46,48,50,52,54,56,58,60,62]:
        C=lf.curve(Y,uu)[0]
        m=(C[:,0]<0)
        # find point on -X side with z closest zq
        j=np.argmin(np.where(m,np.abs(C[:,1]-zq),1e9)); x_,z_=C[j]
        row.append(f'{Y}:{np.hypot(x_,Y)-Rw(z_):+.2f}')
    print(' '.join(row))
