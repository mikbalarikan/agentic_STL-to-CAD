import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
P=np.load("work/m2/ext_pts_long.npy")
a_all=np.degrees(np.arctan2(P[:,2]-35,P[:,0]-40)); r_all=np.hypot(P[:,0]-40,P[:,2]-35)
fig,axs=plt.subplots(2,4,figsize=(28,12))
for ax,y in zip(axs.ravel(),(256,262,266,270,274,278,282,286)):
    m=(np.abs(P[:,1]-y)<=0.8)&(np.abs(a_all)<80); ax.plot(a_all[m],r_all[m],'k.',ms=2); ax.set_title(f"Y={y}"); ax.grid(True)
plt.tight_layout(); plt.savefig("work/m2/hip_band_profile.png",dpi=40)
