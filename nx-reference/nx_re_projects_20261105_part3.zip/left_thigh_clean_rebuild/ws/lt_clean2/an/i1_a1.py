from i1_common import *
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
S = load_all(); c,de,d5,d0 = S['c'],S['de'],S['d5'],S['d0']
deep = de>2.0
idx = np.where(deep)[0]; idx = idx[np.argsort(c[idx,2])]
for nm,col,cm,vmin,vmax in (("z",c[:,2],"turbo",-40,40),("d5",d5,"jet",0,2),("d0",d0,"jet",0,2)):
    fig,ax = plt.subplots(figsize=(12,26))
    sc=ax.scatter(c[idx,0],c[idx,1],c=col[idx],s=0.6,cmap=cm,vmin=vmin,vmax=vmax,linewidths=0,rasterized=True)
    ax.set_aspect('equal'); ax.grid(True,alpha=.3); plt.colorbar(sc,shrink=.4); ax.set_title(nm)
    ax.set_xticks(range(-80,130,20)); ax.set_yticks(range(-60,300,20))
    fig.savefig(os.path.join(I1,f"plan_{nm}.png"),dpi=70,bbox_inches='tight'); plt.close(fig)
