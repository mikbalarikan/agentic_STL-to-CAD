import sys, os, numpy as np, trimesh, open3d as o3d, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import lib
AX, AZ = 37.97, 35.18
def sc(m):
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32))); return s
def cast(s, o, d): return s.cast_rays(o3d.core.Tensor(np.hstack([o, d]).astype(np.float32)))["t_hit"].numpy()
se = sc(trimesh.load("nx/base_v2/envelope.stl", process=False))
P = []
for w, sg in (("out", -1), ("inn", 1)):
    v, f = lib.load(w + "_scan", 1500000); ss = sc(trimesh.Trimesh(v, f, process=False))
    for y in np.arange(251.0, 260.6, 0.5):
        for th in np.arange(1.0, 13.1, 1.0):
            t = np.radians(th); dv = np.array([[np.cos(t), 0, sg*np.sin(t)]]); o = np.array([[AX, y, AZ]]) + 500*dv
            tm = cast(ss, o, -dv)[0]; te = cast(se, o, -dv)[0]
            if 1.35 < (tm - te) < 2.4:
                p = o[0] - dv[0]*tm
                if sg == 1: p[2] = 2*AZ - p[2]       # mirror inn onto out
                P.append(p)
P = np.array(P); print("pts", len(P))
def fit(ty, tz):
    ty, tz = np.radians(ty), np.radians(tz)
    n = np.array([-np.cos(ty)*np.cos(tz), -np.sin(ty)*np.cos(tz), np.sin(tz)])
    d = P @ n; return n, d.mean(), d.std(), np.abs(d - d.mean()).max()
best = None
for ty in np.arange(0, 7.01, 0.5):
    for tz in np.arange(0, 9.01, 0.5):
        n, d0, sd, mx = fit(ty, tz)
        if best is None or sd < best[2]: best = (ty, tz, sd, mx, d0)
print("best rounded angles ty %.1f tz %.1f: rms %.3f max %.3f d0 %.3f" % best)
ty, tz, sd, mx, d0 = best
n, d0, sd, mx = fit(ty, tz); d0 = round(d0/0.05)*0.05
json.dump({"ty": ty, "tz": tz, "d0": d0, "n": n.tolist(), "rms": sd, "max": mx}, open("work/r1/runout_plane.json", "w"))
print("plane n", n.round(4), "d0", d0)
