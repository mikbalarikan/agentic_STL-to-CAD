import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
v,f=lib.load('inn_scan',1500000); c,nn,a=lib.tri_data(v,f)
d5=np.load('work/dev_FINinn.npz')['d1']; do=np.load('work/dev_oldInnB.npz')['d1']
m=np.load('work/masks/inn_int_hip.npy'); m=m[abs(nn[m,1])>0.97]
bad=m[d5[m]>0.5]
print('inner Y-faces',len(m),'bad in p5',len(bad))
h,e=np.histogram(c[bad,1],bins=np.arange(264,289,0.5),weights=a[bad]); 
for i in np.where(h>20)[0]: print('  bad area by Y %.1f-%.1f: %.0f'%(e[i],e[i+1],h[i]))
fig,ax=plt.subplots(1,3,figsize=(30,9))
for a_,(lo,hi,t) in zip(ax,((266,267,'Y 266-267 (plate inner face)'),(269,273,'Y 269-273 (pad faces)'),(276,278,'Y 276-278 (plate end face)'))):
    k=m[(c[m,1]>lo)&(c[m,1]<hi)]
    s=a_.scatter(c[k,0],c[k,2],c=d5[k],s=2,cmap='jet',vmin=0,vmax=3); plt.colorbar(s,ax=a_); a_.set_aspect('equal'); a_.set_title('inn p5 dev (scan->CAD) '+t); a_.plot(37.97,35.18,'k+',ms=15)
plt.savefig('work/m3/inn_plate_dev.png',dpi=45)
