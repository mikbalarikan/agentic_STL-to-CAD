import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
O = lib.load("out_scan", 1500000); I = lib.load("inn_scan", 1500000)
fig, ax = plt.subplots(1, 1, figsize=(14, 24))
for (v, f), z, colr, lw in ((O, 34.3, "0.5", 0.7), (O, 35.4, "tab:blue", 1.2), (O,37.0,"tab:green",0.8),(I, 37.0, "0.75", 0.6), (I, 35.7, "tab:red", 1.0)):
    s = lib.section(v, f, 2, z)
    ax.add_collection(LineCollection(s[:, :, :2], colors=colr, lw=lw))
ax.set_aspect("equal"); ax.autoscale(); ax.grid(lw=0.3)
ax.set_xticks(np.arange(-70, 130, 10)); ax.set_yticks(np.arange(-70, 300, 10))
ax.set_title("grey out z34.3 | blue out z35.4 (tongue) | green out z37 | light inn z37 | red inn z35.7 (lip)")
fig.tight_layout(); fig.savefig(os.path.join(lib.W, "m4", "plan.png"), dpi=60)
