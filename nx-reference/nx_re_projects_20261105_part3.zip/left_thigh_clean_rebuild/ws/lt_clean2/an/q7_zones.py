"""Zone table old / part5 / v2 (area-weighted % scan->CAD within 0.5). Zones from the frame (priority hip > tail > drum > body), joint band + feature families as overlays."""
import sys, os, re, glob, numpy as np
sys.path.insert(0, "an"); import lib
OUT = open("work/q7/zones.txt", "w")
def P(*a):
    s = " ".join(str(x) for x in a); print(s); OUT.write(s + "\n")
REF = {"out": ("dev_oldC.npz", "dev_FINout.npz"), "inn": ("dev_oldInnB.npz", "dev_FINinn.npz")}
FAM = [("bosses/columns/bores", r"^(BOSS_|B\d_(col|bore|pocket)|HUB_BORE|HUB$)"),
       ("ribs/arms/spokes/gussets", r"^(ARM_|RIB_|LOWRIB|CH_RUN_RIB(_L|_R)?$|I_DIAG$|I_LONG_HIP$|I_TRANS_Y166$|SPOKE_|GUS_|IG_|MISS_ARC_RIB|HIP_WEB|HIP_BLOCK)"),
       ("rib/arm roots", r"(_root$|^ROOT_BLENDS)"),
       ("seams", r"^SEAM_"),
       ("pins/lugs/tabs/clip/ears", r"^(PIN_|N\d_(pin|lug)|P\d_lug|LUG_|COVERPIN|TAB_|CLIP|EAR_|HUB_SCREW|MISS_B1_EAR|MISS_B2_DOME)"),
       ("holes/openings/windows", r"(OPENING|HOLE|KNEE_BOLT|KNEE_BORE|KNEE_RECESS|KNEE_SIDE|HIP_BOLT|HIP_RING|CH_H\d|KNEE_WINDOW|FL_KNEE|FLG_|MISS_OVAL)"),
       ("floors/plates/pads/rings/lip", r"^(KNEE_FLOOR|KNEE_DISC|HIP_PLATE|HIP_PAD|CH_RING|CH_RUN_FLOOR|CH_CAP|PAD_|LIP_|JOINT_|FLATSPOT|HUB_UNDER|KNEE_FLOOR_PLANE)")]
for w in ("out", "inn"):
    v, f = lib.load({"out": "out_scan", "inn": "inn_scan"}[w], 1500000); c, nn, ar = lib.tri_data(v, f); wt = ar / ar.sum()
    D = {"old": np.load("work/" + REF[w][0])["d1"], "p5": np.load("work/" + REF[w][1])["d1"], "v2": np.load(f"work/dev_q7{w}_{w}.npz")["d1"]}
    x, y, z = c.T; r = np.hypot(x, y)
    hip = y > 240; tail = (y < -25) & ~hip; drum = (r < 72) & (y < 40) & ~hip & ~tail
    jb = np.abs(z - 35.5) < 2.5
    body = ~(hip | tail | drum)
    Z = [("knee drum (r<72,-25<=y<40)", drum), ("body loft (rest)", body & ~jb), ("hip end (y>240)", hip), ("tail (y<-25)", tail), ("joint band (|z-35.5|<2.5)", jb), ("whole part", np.ones(len(c), bool))]
    for nm, rx in FAM:
        m = np.zeros(len(c), bool)
        for mp in glob.glob(f"work/masks/{w}_f_*.npy"):
            n = os.path.basename(mp)[len(w) + 3:-4]
            if re.search(rx, n): m[np.load(mp)] = True
        Z.append(("feat: " + nm, m))
    P(f"== {w}   zone                             area%   old    p5    v2   (scan->CAD within 0.5 mm, area weighted)")
    for nm, m in Z:
        s = wt[m].sum()
        if s <= 0: continue
        P(f"   {nm:36s} {s*100:5.1f} " + " ".join(f"{wt[m & (D[k] < 0.5)].sum() / s * 100:6.1f}" for k in ("old", "p5", "v2")))
