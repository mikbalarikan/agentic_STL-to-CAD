from s1_eval import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
m=zones['knee_tail(Y<-34)']
Q=P[m]
fig,axs=plt.subplots(1,3,figsize=(24,9))
axs[0].scatter(Q[:,0],Q[:,1],c=Q[:,2],s=1); axs[0].set_aspect('equal'); axs[0].set_title('top view x,y color z')
axs[1].scatter(Q[:,1],Q[:,2],c=Q[:,0],s=1); axs[1].set_aspect('equal'); axs[1].set_title('y,z color x')
for y0 in [-36,-39,-42,-45,-48]:
    q=Q[np.abs(Q[:,1]-y0)<0.7]; axs[2].plot(q[:,0],q[:,2],'.',ms=2,label=str(y0))
axs[2].legend(); axs[2].set_aspect('equal'); axs[2].grid()
plt.tight_layout(); plt.savefig(os.path.join(S1,'tail.png'),dpi=50)
print(Q[:,1].min(), len(Q))
