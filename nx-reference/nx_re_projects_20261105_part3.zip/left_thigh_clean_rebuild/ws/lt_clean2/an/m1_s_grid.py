import sys,os,json,itertools
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from m1_r_design import *
base=(68.86,36.07,1.6,-13.9,83.6,3.3,3.2)
pol0,res0=evaluate(base,(0.14,-0.01),loose=1.0)
IDX={nm:np.where(res0[nm][0])[0] for nm in res0}
def score(design,axis):
    poly=profile(*design); out={}
    for nm,idx in IDX.items():
        c=S[nm][0][idx]; w=S[nm][2][idx]; rho=np.hypot(c[:,0]-axis[0],c[:,1]-axis[1]); d,who=dist2poly(rho,c[:,2],poly)
        out[nm]=(d,who,w)
    return out
def p90(d,w):
    o=np.argsort(d); cw=np.cumsum(w[o])/w.sum(); return d[o][np.searchsorted(cw,.9)]
if __name__=='__main__':
    print("cone grid (axis fixed (0.14,-0.01)); score = p90 of cone segs, and mean")
    for dd,Rp,zp in itertools.product((1.5,1.55,1.6,1.7),(68.8,68.85,68.9),(36.07,)):
        o=score((Rp,zp,dd,-13.9,83.6,3.3,3.2),(0.14,-0.01))
        r=[]
        for nm in o:
            d,who,w=o[nm]; k=(who==2)|(who==3); r.append((p90(d[k],w[k]),np.average(d[k],weights=w[k])))
        print(dd,Rp,[tuple(np.round(a,3)) for a in r])
    print("chamfer grid")
    for cb,ct,Zt,Zb in itertools.product((3.2,3.3,3.4),(3.0,3.1,3.2,3.3),(83.6,83.62),(-13.9,-13.91)):
        o=score((68.85,36.07,1.6,Zb,Zt,cb,ct),(0.14,-0.01))
        d,who,w=o["out_scan"]; k=who==1; a=(p90(d[k],w[k]),np.average(d[k],weights=w[k]))
        d,who,w=o["inn_scan"]; k=who==4; b=(p90(d[k],w[k]),np.average(d[k],weights=w[k]))
        d,who,w=o["inn_scan"]; k=who==5; c=(p90(d[k],w[k]),np.average(d[k],weights=w[k]))
        print(f"cb {cb} ct {ct} Zt {Zt} Zb {Zb}: bot chamf p90 {a[0]:.3f} mean {a[1]:.3f} | top chamf p90 {b[0]:.3f} mean {b[1]:.3f} | top plane p90 {c[0]:.3f} mean {c[1]:.3f}")
