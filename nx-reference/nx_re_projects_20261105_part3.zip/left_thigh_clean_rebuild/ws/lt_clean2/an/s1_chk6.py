import sys
from s1_eval import *
dd=np.load(os.path.join(S1,f'dd_{sys.argv[1]}.npy'))
m=zones['drum']&(dd>2)
Q=P[m]; print(len(Q)); print('x',Q[:,0].min(),Q[:,0].max(),'y',Q[:,1].min(),Q[:,1].max(),'z',Q[:,2].min(),Q[:,2].max())
ang=np.degrees(np.arctan2(Q[:,0],-Q[:,1])); print('ang',ang.min(),ang.max())
import numpy as np
for z0 in [0,20,36,50,70]:
    q=Q[np.abs(Q[:,2]-z0)<3]
    if len(q): print(z0,len(q),'x',q[:,0].min().round(1),q[:,0].max().round(1),'y',q[:,1].min().round(1),q[:,1].max().round(1))
