"""M4: same station measurement on scan / part 5 / old masters -> work/m4/cmp.npz (rows lists)"""
import sys, os, pickle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
from m4_x import *
P5 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 5 - Clean Rebuild\deliver\CAD"
out = {}
out["scan"] = measure(Caster(*lib.load("out_scan", 1500000)), Caster(*lib.load("inn_scan", 1500000)))
out["p5"] = measure(mesh_caster(P5 + r"\LT-OUT-001_Left_Thigh_Outer.stl"), mesh_caster(P5 + r"\LT-INN-001_Left_Thigh_Inner.stl"))
out["old"] = measure(Caster(*lib.load("out_cad")), Caster(*lib.load("inn_cad")))
pickle.dump(out, open(os.path.join(lib.W, "m4", "cmp.pkl"), "wb"))
def g(rows, ch, k): return np.array([r.get(k, np.nan) for r in rows if r["chain"] == ch], float)
for ch in NAMES:
    print(ch)
    for k in ["rim", "tongue_top", "shoulder", "lip", "rebate_floor", "lip_w", "step", "o_edge", "i_edge"]:
        s = []
        for nm in ("scan", "p5", "old"):
            a = g(out[nm], ch, k); a = a[np.isfinite(a)]
            s.append("%s %7.3f (n%3d)" % (nm, np.median(a) if len(a) else np.nan, len(a)))
        print("   %-12s" % k, " | ".join(s))
    for k in ("tongue", "rebate"):
        print("   %-12s" % k, " | ".join("%s %.2f" % (nm, np.mean([r[k] for r in out[nm] if r["chain"] == ch])) for nm in ("scan", "p5", "old")))
