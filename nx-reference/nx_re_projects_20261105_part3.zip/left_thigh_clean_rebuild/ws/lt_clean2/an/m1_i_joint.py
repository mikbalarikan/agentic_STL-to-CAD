import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
P=[]
for k,n in enumerate(("out_scan","inn_scan")):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f)
    r=np.hypot(c[:,0],c[:,1]); ang=np.degrees(np.arctan2(c[:,0],-c[:,1]))
    radial=(c[:,0]*nn[:,0]+c[:,1]*nn[:,1])/np.maximum(r,1e-9)
    m=(r>66)&(r<70.5)&(radial>0.97)&(np.abs(ang-10)<35)&(c[:,2]>-9)&(c[:,2]<79)
    P.append(np.c_[c[m],np.full(m.sum(),k)])
P=np.vstack(P)
print('zmax outer',P[P[:,3]==0,2].max(),'zmin inner',P[P[:,3]==1,2].min())
def res(q):
    # q: ao, ai (R at z=36.07 for each scan), t, x0,y0 shared
    d=np.hypot(P[:,0]-q[3],P[:,1]-q[4]); a=np.where(P[:,3]==0,q[0],q[1])
    return d-(a-np.where(P[:,3]==0,q[2]*(36.07-P[:,2])*-1*-1,q[2]*(P[:,2]-36.07)))
# outer: R rises with z: R=a+t(z-36.07) ; inner: R=a-t(z-36.07)
def res(q):
    d=np.hypot(P[:,0]-q[3],P[:,1]-q[4]); z=P[:,2]-36.07
    return d-np.where(P[:,3]==0,q[0]+q[2]*z,q[1]-q[2]*z)
s=least_squares(res,[68.8,68.8,.0275,.17,-.1],loss="soft_l1",f_scale=.1)
print('shared axis, free R at 36.07 for outer/inner:',s.x.round(4),'step',(s.x[1]-s.x[0]).round(4),'p90',np.percentile(np.abs(res(s.x)),90).round(4))
# with each scan its own axis, same slope
def res2(q):
    x0=np.where(P[:,3]==0,q[3],q[5]); y0=np.where(P[:,3]==0,q[4],q[6]); d=np.hypot(P[:,0]-x0,P[:,1]-y0); z=P[:,2]-36.07
    return d-np.where(P[:,3]==0,q[0]+q[2]*z,q[1]-q[2]*z)
s=least_squares(res2,[68.8,68.8,.0275,.17,-.1,.1,0],loss="soft_l1",f_scale=.1)
print('own axes:',s.x.round(4),'step',(s.x[1]-s.x[0]).round(4),'p90',np.percentile(np.abs(res2(s.x)),90).round(4))
# continuity check: with own axes, R at 36.07 equal? and axis offset between scans
