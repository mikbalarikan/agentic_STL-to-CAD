"""greedy minimum-point fair spline fit to the measured groove centres (valid stations), per part and seam. Writes work/p5d/seam_paths.json (design values)."""
import json, numpy as np
from scipy.interpolate import CubicSpline
from scipy.ndimage import gaussian_filter1d
def dist_poly(P, C):
    d = np.full(len(P), 1e9)
    for a, b in zip(C[:-1], C[1:]):
        ab = b - a; L2 = ab @ ab
        t = np.clip(((P - a) @ ab) / max(L2, 1e-12), 0, 1)
        d = np.minimum(d, np.linalg.norm(P - (a + t[:, None] * ab), axis=1))
    return d
def spl(K):
    d = np.r_[0, np.cumsum(np.linalg.norm(np.diff(K, axis=0), axis=1))]
    cs = CubicSpline(d, K, bc_type="natural"); t = np.linspace(0, d[-1], 400); return cs(t)
OUT = {}
for w in ("out", "inn"):
    for n, smax, smin in (("A", 232.0, 20.0), ("B", 145.0, 0.0)):
        r = json.load(open(f"work/p5d/seam_{w}.json"))[n]; Q = np.array(r["Q"]); ok = np.array(r["ok"]) & (np.array(r["depth"]) > 0.35); s = np.array(r["s"])
        m = ok & (s <= smax) & (s >= smin)
        Q = Q[m]
        Qs = np.c_[gaussian_filter1d(Q[:, 0], 2, mode="nearest"), gaussian_filter1d(Q[:, 1], 2, mode="nearest")]
        idx = [0, len(Qs) - 1]
        hist = []
        while True:
            K = np.round(Qs[sorted(idx)] * 2) / 2          # design values, 0.5 mm
            C = spl(K); e = dist_poly(Q, C)
            hist.append((len(idx), float(np.percentile(e, 90)), float(e.max())))
            if (np.percentile(e, 90) < 0.35 and e.max() < 1.0) or len(idx) >= 14: break
            # add the station with the largest error that is not in idx
            worst = int(np.argmax(e)); 
            if worst in idx: break
            idx.append(worst)
        print(w, n, "stations", len(Q), "k", len(idx), " p50 %.2f p90 %.2f max %.2f" % (np.median(e), np.percentile(e, 90), e.max()), "hist", [(a, round(b, 2), round(c, 2)) for a, b, c in hist])
        OUT[f"{w}_{n}"] = {"pts": K.tolist(), "p50": float(np.median(e)), "p90": float(np.percentile(e, 90)), "max": float(e.max()), "k": len(idx), "nst": len(Q)}
json.dump(OUT, open("work/p5d/seam_paths.json", "w"), indent=1)
