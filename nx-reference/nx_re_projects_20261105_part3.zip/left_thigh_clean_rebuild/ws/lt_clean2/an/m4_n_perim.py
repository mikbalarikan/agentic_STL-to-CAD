"""M4: perimeter plots: scan joint parameters and wall-face errors of part 5 / old master along each chain."""
import sys, os, pickle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from m4_x import NAMES
W4 = os.path.join(lib.W, "m4")
C = pickle.load(open(os.path.join(W4, "cmp.pkl"), "rb"))
def g(src, ch, k): return np.array([r.get(k, np.nan) for r in C[src] if r["chain"] == ch], float)
# ---- figure 1: scan joint levels / widths per chain
fig, axs = plt.subplots(5, 3, figsize=(24, 20))
for r, ch in enumerate(NAMES):
    s = g("scan", ch, "s"); y = g("scan", ch, "y"); x = g("scan", ch, "x")
    ax = axs[r, 0]
    for k, col in (("rim", "tab:blue"), ("tongue_top", "tab:cyan"), ("lip", "tab:red"), ("rebate_floor", "tab:orange")):
        ax.plot(s, g("scan", ch, k), ".", ms=3, c=col, label=k)
    ax.axhline(36.07, c="k", lw=0.4); ax.set_ylim(34.4, 36.5); ax.set_title(f"{ch}: joint levels (scan)"); ax.legend(ncol=4, fontsize=7); ax.grid(lw=.3)
    ax2 = ax.twiny(); ax2.set_xlim(ax.get_xlim()); ax2.set_xticks(s[::20]); ax2.set_xticklabels(["(%d,%d)" % (a, b) for a, b in zip(x[::20], y[::20])], fontsize=6, rotation=45)
    ax = axs[r, 1]
    ow = g("scan", ch, "o_tout") - g("scan", ch, "o_tin"); iw = g("scan", ch, "i_tout") - g("scan", ch, "i_tin")
    tw = np.where(np.isfinite(g("scan", ch, "shoulder")), ow - g("scan", ch, "shoulder"), np.nan); rw = iw - g("scan", ch, "lip_w")
    ax.plot(s, np.clip(ow, 0, 6), ".", ms=3, c="tab:blue", label="wall thickness outer z34.3 (ribs>3.5)"); ax.plot(s, np.clip(iw, 0, 6), ".", ms=3, c="tab:red", label="wall thickness inner z36.6")
    ax.plot(s, tw, "-", c="tab:cyan", label="tongue width (wall - shoulder)"); ax.plot(s, rw, "-", c="tab:orange", label="rebate width (wall - lip_w)")
    ax.plot(s, g("scan", ch, "shoulder"), ":", c="b", label="shoulder (outer)"); ax.plot(s, g("scan", ch, "lip_w"), ":", c="r", label="lip width (inner)")
    ax.set_ylim(0, 5); ax.legend(fontsize=6, ncol=2); ax.grid(lw=.3); ax.set_title(f"{ch}: widths (mm)")
    ax = axs[r, 2]
    ax.plot(s, g("scan", ch, "step"), "-", c="k", label="exterior step inner-outer (scan)"); ax.plot(s, g("scan", ch, "o_edge"), "-", c="b", label="outer ext. edge drift z34.0->34.6")
    ax.plot(s, g("scan", ch, "i_edge"), "-", c="r", label="inner ext. edge drift z36.4->35.5"); ax.plot(s, g("p5", ch, "step"), "--", c="g", label="step part 5")
    ax.set_ylim(-0.6, 0.6); ax.legend(fontsize=6); ax.grid(lw=.3); ax.set_title(f"{ch}: exterior step / edge (mm, + = inner proud)")
    for a in axs[r]: a.set_xlabel("arc s (mm)")
fig.tight_layout(); fig.savefig(os.path.join(W4, "perimeter_scan.png"), dpi=48)
# ---- figure 2: face-position error of part 5 and old vs scan
fig, axs = plt.subplots(5, 2, figsize=(22, 18))
for r, ch in enumerate(NAMES):
    s = g("scan", ch, "s")
    for c_, (lab, kin, kout) in enumerate((("outer, z=34.3", "o_tin", "o_tout"), ("inner, z=36.6", "i_tin", "i_tout"))):
        ax = axs[r, c_]
        for src, col in (("p5", "tab:red"), ("old", "tab:green")):
            ax.plot(s, g(src, ch, kout) - g("scan", ch, kout), "-", c=col, label=f"{src} exterior face - scan")
            d = g(src, ch, kin) - g("scan", ch, kin); d = np.where(abs(d) > 3, np.nan, d)
            ax.plot(s, d, "--", c=col, label=f"{src} interior face - scan")
        ax.axhline(0.5, c="k", lw=.4); ax.axhline(-0.5, c="k", lw=.4); ax.set_ylim(-3, 3); ax.grid(lw=.3); ax.legend(fontsize=6, ncol=2); ax.set_title(f"{ch} {lab}: wall-face position error along +t (outward)")
fig.tight_layout(); fig.savefig(os.path.join(W4, "perimeter_faces_err.png"), dpi=48)
