"""Zone gates of one part against its scan, plus the same zones evaluated for the old master and part 5.
argv: which(out|inn) cad_stl envelope_stl tag
Zones are defined on the GIVEN (new) envelope: de = unsigned distance scan triangle centre -> envelope.
  G-ext  : de < 1.0            target >= 93 % within 0.5 (scan -> CAD, area weighted)
  G-wall : 2.4 <= de < 3.9     target >= 90 %
  G-band : mask work/masks/<w>_band.npy             target >= 85 %
  G-feat : each mask work/masks/<w>_f_*.npy         p90 <= 0.5
  G-total: whole scan          target >= 88 %, CAD -> scan p90 reported
Writes work/gates/<tag>_<which>.json + prints the table. Also saves dev_<tag>_<which>.npz (d1 per triangle, d2)."""
import sys, os, glob, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import open3d as o3d
import trimesh

which, cad, envp, tag = sys.argv[1:5]
scan = {"out": "out_scan", "inn": "inn_scan"}[which]
REF = {"out": {"old": "dev_oldC.npz", "p5": "dev_FINout.npz"}, "inn": {"old": "dev_oldInnB.npz", "p5": "dev_FINinn.npz"}}[which]


def scene(path):
    m = trimesh.load(path, process=False)
    s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32)))
    return m, s


v, f = lib.load(scan, 1500000)
c, nn, ar = lib.tri_data(v, f)
w = ar / ar.sum()
C = o3d.core.Tensor(c.astype(np.float32))
_, se = scene(envp)
de = se.compute_distance(C).numpy()
cm, sc = scene(cad)
d1 = sc.compute_distance(C).numpy()
ss = o3d.t.geometry.RaycastingScene()
ss.add_triangles(o3d.core.Tensor(v.astype(np.float32)), o3d.core.Tensor(f.astype(np.uint32)))
pts, _ = trimesh.sample.sample_surface(cm, 400000, seed=1)
d2 = ss.compute_distance(o3d.core.Tensor(pts.astype(np.float32))).numpy()
os.makedirs(os.path.join(lib.W, "gates"), exist_ok=True)
np.savez(os.path.join(lib.W, f"dev_{tag}_{which}.npz"), d1=d1, de=de, d2=d2)

D = {"new": d1}
for k, fn in REF.items():
    p = os.path.join(lib.W, fn)
    if os.path.exists(p):
        D[k] = np.load(p)["d1"]


def pct(m, d):
    s = w[m].sum()
    return float(w[m & (d < 0.5)].sum() / s * 100) if s > 0 else float("nan")


def wp90(m, d):
    if not m.any():
        return float("nan")
    dd, ww = d[m], w[m]
    o = np.argsort(dd); cw = np.cumsum(ww[o]) / ww.sum()
    return float(dd[o][min(np.searchsorted(cw, 0.9), len(o) - 1)])


allm = np.ones(len(c), bool)
zones = {"G-ext": (de < 1.0, 93.0), "G-wall": ((de >= 2.4) & (de < 3.9), 90.0), "G-total": (allm, 88.0)}
bp = os.path.join(lib.W, "masks", f"{which}_band.npy")
if os.path.exists(bp):
    bm = np.zeros(len(c), bool); bm[np.load(bp)] = True
    zones["G-band"] = (bm, 85.0)
res = {"tag": tag, "which": which, "cad": cad, "envelope": envp, "zones": {}, "features": {},
       "cad_to_scan": {"p50": float(np.median(d2)), "p90": float(np.percentile(d2, 90)), "within05": float(np.mean(d2 < 0.5) * 100)}}
print(f"{tag} {which}   zone            area%   " + "  ".join(f"{k:>7s}" for k in D) + "  target  gate")
for z, (m, tgt) in zones.items():
    vals = {k: pct(m, d) for k, d in D.items()}
    ok = vals["new"] >= tgt
    res["zones"][z] = {"area_pct": float(w[m].sum() * 100), **{k: round(x, 2) for k, x in vals.items()}, "target": tgt, "pass": bool(ok)}
    print(f"   {z:18s} {w[m].sum()*100:6.1f}  " + "  ".join(f"{vals[k]:7.1f}" for k in D) + f"  {tgt:6.1f}  {'PASS' if ok else 'FAIL'}")
fails = 0
for mp in sorted(glob.glob(os.path.join(lib.W, "masks", f"{which}_f_*.npy"))):
    m = np.zeros(len(c), bool); m[np.load(mp)] = True
    nm = os.path.basename(mp)[len(which) + 3:-4]
    vals = {k: wp90(m, d) for k, d in D.items()}
    ok = vals["new"] <= 0.5
    fails += not ok
    res["features"][nm] = {"n": int(m.sum()), **{k: round(x, 3) for k, x in vals.items()}, "pass": bool(ok)}
res["n_feat"] = len(res["features"]); res["n_feat_fail"] = fails
print(f"   G-feat: {len(res['features']) - fails}/{len(res['features'])} masks p90 <= 0.5")
for nm, r in sorted(res["features"].items(), key=lambda t: -t[1]["new"])[:15]:
    if not r["pass"]:
        print(f"      FAIL {nm:24s} n {r['n']:6d}  p90 " + "  ".join(f"{k} {r[k]:.2f}" for k in D))
print(f"   CAD->scan p50 {res['cad_to_scan']['p50']:.3f} p90 {res['cad_to_scan']['p90']:.3f}")
json.dump(res, open(os.path.join(lib.W, "gates", f"{tag}_{which}.json"), "w"), indent=1)
