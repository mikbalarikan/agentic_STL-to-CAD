import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_loft as L
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
tag=sys.argv[1]; Ys=[float(s) for s in sys.argv[2].split(",")]
d=np.load(f"work/m2/loft_{tag}.npz"); lf=L.Loft(d["st"],d["P"].shape[1],d["P"])
P=np.load("work/m2/ext_pts.npy")
fig,axs=plt.subplots(2,len(Ys),figsize=(6*len(Ys),13))
for j,y in enumerate(Ys):
  q=P[np.abs(P[:,1]-y)<=0.5]; C=lf.curve(y,np.linspace(0,1,2880))[0]
  for i,(xl,zl) in enumerate((((-48,-10),(30,90)),((-48,-10),(-18,40)))):
    ax=axs[i,j]; ax.plot(q[:,0],q[:,2],'k.',ms=3); ax.plot(C[:,0],C[:,1],'r-',lw=1)
    ax.set_xlim(*xl); ax.set_ylim(*zl); ax.set_aspect('equal'); ax.grid(True); ax.set_title(f"Y={y}")
plt.tight_layout(); plt.savefig(f"work/m2/zoom_{tag}.png",dpi=45)
