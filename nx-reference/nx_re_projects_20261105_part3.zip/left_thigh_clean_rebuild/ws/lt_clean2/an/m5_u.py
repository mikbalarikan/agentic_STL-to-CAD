import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
for key,scan,dn,sg in (("out","out_scan","FINout",-1),("inn","inn_scan","FINinn",1)):
    v,fa=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,fa); w=ar/ar.sum()
    st=np.load(os.path.join(lib.W,f"dev_{dn}.npz"))["d1"]; d=np.load(os.path.join(lib.W,"m5",f"{key}_dfix.npy"))
    band=np.zeros(len(c),bool); band[np.load(os.path.join(lib.W,"masks",f"{key}_band.npy"))]=1
    dot=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["dot"]; de=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["d"]
    th_=np.load(os.path.join(lib.W,"m5",f"{key}_thick.npy"))
    lost=(~band)&(st<0.5)&(d>=0.5); gain=(~band)&(st>=0.5)&(d<0.5)
    print(key,"non-band lost",round(w[lost].sum()*100,2),"gain",round(w[gain].sum()*100,2))
    for nm,m in (("int-facing",lost&(dot<0)),("ext-facing",lost&(dot>=0))):
        print("  ",nm,round(w[m].sum()*100,2),"env depth pct 10/50/90",np.round(np.percentile(de[m],[10,50,90]),2) if m.sum() else "", "thick",np.round(np.percentile(th_[m],[10,50,90]),2) if m.sum() else "")
    m=lost&(dot<0)
    print("   y pct",np.round(np.percentile(c[m,1],[5,50,95]),0),"theta",np.round(np.percentile(np.degrees(np.arctan2(c[m,2]-35.18,c[m,0]-37.97))*sg,[5,50,95]),0))
