import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
v,fa=lib.load("out_scan",1500000); c,nn,ar=lib.tri_data(v,fa); w=ar/ar.sum()
z=np.load(os.path.join(lib.W,"m5","out_cp.npz")); dot=z["dot"]; dd=z["d"]
th=-np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))
# ext-facing skin tris (any depth <4) in y 100-200, x>60: depth map
m=(dot>0.9)&(dd<4)&(c[:,0]>60)&(c[:,1]>100)&(c[:,1]<200)&(th>-5)&(th<60)
print("n",m.sum())
for y0 in range(100,200,10):
    row=[]
    for t0 in range(0,60,6):
        k=m&(c[:,1]>=y0)&(c[:,1]<y0+10)&(th>=t0)&(th<t0+6)
        row.append(f"{np.median(dd[k]):4.1f}" if k.sum()>8 else "  . ")
    print(y0," ".join(row))
print("cols theta 0,6,...54")
