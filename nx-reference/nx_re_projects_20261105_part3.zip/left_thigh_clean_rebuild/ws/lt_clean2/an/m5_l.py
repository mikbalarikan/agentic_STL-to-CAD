import sys, os, numpy as np, json
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib
out={}
for scan,key,sg in (("out_scan","out",-1),("inn_scan","inn",1)):
    v,f=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,f)
    t=np.load(os.path.join(lib.W,"m5",f"{key}_thick.npy")); dot=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))["dot"]
    th=np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))*sg
    base=(dot<0)&(t>1.5)&(t<3.6)&(c[:,0]>40)
    rows=[]
    for y0 in np.arange(60,262,4.0):
        m=base&(c[:,1]>=y0)&(c[:,1]<y0+4)
        bt=None; ths=np.arange(5,60,1.0)
        fr=[]
        for a in ths:
            k=m&(th>=a)&(th<a+1)
            fr.append(((t[k]<2.5).mean(), k.sum()) if k.sum()>=15 else (np.nan,k.sum()))
        # first crossing above 0.5 -> below, after thin start
        thin=[(a,x[0]) for a,x in zip(ths,fr) if not np.isnan(x[0])]
        cross=np.nan
        for (a,x),(a2,x2) in zip(thin[:-1],thin[1:]):
            if x>0.5 and x2<=0.5 and a>15: cross=a2; break
        rows.append((y0+2,cross)); 
    out[key]=rows
    print(key,[(int(y),None if np.isnan(x) else float(x)) for y,x in rows])
json.dump({k:[(float(a),None if np.isnan(b) else float(b)) for a,b in v] for k,v in out.items()},open(os.path.join(lib.W,"m5","edge_theta.json"),"w"))
