import sys, numpy as np, trimesh, open3d as o3d
sys.path.insert(0,'an')
import lib
pts=[tuple(float(t) for t in p.split(',')) for p in sys.argv[1].split(';')]
def scene(v,f):
    s=o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(np.asarray(v,np.float32)),o3d.core.Tensor(np.asarray(f,np.uint32))); return s
for a_ in sys.argv[2:]:
    if a_.startswith('scan:'):
        v,f=lib.load({'inn':'inn_scan','out':'out_scan'}[a_[5:]],1500000)
    else:
        m=trimesh.load(a_,process=False); v,f=m.vertices,m.faces
    s=scene(v,f); print(a_.split('/')[-1])
    for (x,y) in pts:
        zs=[]; z0=-60.0
        for _ in range(14):
            res=s.cast_rays(o3d.core.Tensor(np.array([[x,y,z0,0,0,1]],np.float32)))
            t=res['t_hit'].numpy()[0]
            if not np.isfinite(t): break
            z0=z0+t; zs.append(round(float(z0),2)); z0+=0.01
        print('  (%g,%g)'%(x,y),zs)
