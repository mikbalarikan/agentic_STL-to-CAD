from s1_lib import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import trimesh
m=trimesh.load(os.path.join(W,'env_part5.stl'),process=False); v5,f5=np.asarray(m.vertices),np.asarray(m.faces)
P=[]
for s in ['out','inn']:
    v,f,c,n,a=scan(s); e=np.load(f'{W}/m2/ext_{s}.npy'); P.append(c[e])
P=np.vstack(P)
Ys=[-50,-40,-30,-20,-10,0,10,20,30,40,50,60]
fig,axs=plt.subplots(3,4,figsize=(28,20))
for ax,y in zip(axs.ravel(),Ys):
    q=P[np.abs(P[:,1]-y)<=0.5]; ax.plot(q[:,0],q[:,2],'k.',ms=2)
    sg=lib.section(v5,f5,1,y)
    for s_ in sg: ax.plot(s_[:,0],s_[:,2],'g-',lw=.8)
    ax.set_xlim(20,100); ax.set_ylim(-20,95); ax.set_aspect('equal'); ax.set_title(f'Y={y}'); ax.grid(True)
plt.tight_layout(); plt.savefig(os.path.join(S1,'knee_px.png'),dpi=45)
