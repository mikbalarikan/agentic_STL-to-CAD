import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from scipy.optimize import least_squares
HX,HZ=37.97,35.18
D=np.load("work/m3/ext_pts.npz"); P=D['P']
def ell_res(p,x,z,sup=False):
    cx,cz,a,b=p[:4]; n=p[4] if sup else 2.0
    # geometric-ish: scaled radial residual
    u=(x-cx)/a; w=(z-cz)/b
    q=(np.abs(u)**n+np.abs(w)**n)**(1/n)   # =1 on curve
    rr=np.hypot(x-cx,z-cz)
    return rr*(1-1/q)
rows=[]
print("Y  circle(res std) | ellipse(res std; cx,cz,a,b) | superellipse (n)")
for y in (240,246,250,254,258,262,266,270,274,278,282,285,286.5,287.2):
    k=(abs(P[:,1]-y)<0.6)
    # drop joint-lip zone |z-HZ|<4 and nan
    k&=abs(P[:,2]-HZ)>4
    x,z=P[k,0],P[k,2]
    c=least_squares(lambda p:np.hypot(x-p[0],z-p[1])-p[2],[HX,HZ,75]).x; ec=np.hypot(x-c[0],z-c[1])-c[2]
    e=least_squares(ell_res,[HX,HZ,80,75],args=(x,z)).x; ee=ell_res(e,x,z)
    s=least_squares(ell_res,[*e,2.2],args=(x,z,True)).x; es=ell_res(s,x,z,True)
    print("%.1f circ %.3f (R%.2f) | ell %.3f c=(%.2f,%.2f) a=%.2f b=%.2f | sup %.3f n=%.2f a=%.2f b=%.2f"%(y,ec.std(),c[2],ee.std(),e[0],e[1],e[2],e[3],es.std(),s[4],s[2],s[3]))
    rows.append((y,*e,*s))
np.save("work/m3/ell_rows.npy",np.array(rows))
