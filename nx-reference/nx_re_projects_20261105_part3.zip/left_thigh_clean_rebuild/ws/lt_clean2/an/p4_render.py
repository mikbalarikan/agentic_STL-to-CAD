import numpy as np, pyvista as pv, os
pv.OFF_SCREEN = True
A = "nx/A_v2/"; P = A + "png/"
S = "work/p4snap/"; mo = pv.read(S + "out_A.stl"); mi = pv.read(S + "inn_A.stl")
def shot(name, meshes, pos, focal, up=(0,0,1), size=(1500, 900), scalars=None, zoom=1.0, par=None):
    p = pv.Plotter(off_screen=True, window_size=size)
    p.set_background("white")
    for m, kw in meshes:
        p.add_mesh(m, smooth_shading=False, **kw)
    p.camera_position = [pos, focal, up]
    if par: p.camera.enable_parallel_projection(); p.camera.parallel_scale = par
    p.camera.zoom(zoom)
    p.screenshot(P + name); p.close(); print(name)
base = dict(color="#c8ccd2", specular=0.3, diffuse=0.9, ambient=0.25)
cin = dict(color="#e8b36a", specular=0.3, diffuse=0.9, ambient=0.25)
ctr = np.array([105, 150, 35.0])
# panel: both parts from +X, and an oblique from +X upper / lower
shot("panel_plusX_both.png", [(mo, base), (mi, cin)], (400, 150, 35), (60, 150, 35), par=140)
shot("panel_plusX_oblique_up.png", [(mo, base), (mi, cin)], (330, 40, 200), (80, 150, 35), par=150)
shot("panel_plusX_oblique_dn.png", [(mo, base), (mi, cin)], (330, 40, -130), (80, 150, 35), par=150)
# panel edge close-up near the spline apex (y 110, theta 40 -> z 35.18-60*sin40 / x 38+60*cos40)
shot("panel_edge_closeup_out.png", [(mo, base)], (200, 70, -60), (84, 110, 0), par=40)
shot("panel_edge_closeup_inn.png", [(mi, cin)], (200, 70, 130), (84, 110, 70), par=40)
# joint: out from above coloured by z (tongue), inn from below
mo2 = mo.copy(); mo2["z"] = mo2.points[:, 2]
mi2 = mi.copy(); mi2["z"] = mi2.points[:, 2]
shot("joint_out_top.png", [(mo2, dict(scalars="z", clim=(34.7, 36.1), cmap="viridis", show_scalar_bar=True))], (40, 130, 400), (40, 130, 35), up=(0, 1, 0), par=170, size=(900, 1500))
shot("joint_inn_bottom.png", [(mi2, dict(scalars="z", clim=(35.2, 36.2), cmap="viridis", show_scalar_bar=True))], (40, 130, -300), (40, 130, 35), up=(0, 1, 0), par=170, size=(900, 1500))
# close-ups of the tongue TG1 and the hip tongue TG3
shot("tongue_TG1_out.png", [(mo, base)], (-60, 60, 70), (-27, 100, 35), par=18)
shot("rebate_TG1_inn.png", [(mi, cin)], (-60, 60, 0), (-27, 100, 35.5), par=18)
shot("tongue_TG3_TG4_hip_out.png", [(mo, base)], (40, 330, 120), (40, 270, 35), par=70)
