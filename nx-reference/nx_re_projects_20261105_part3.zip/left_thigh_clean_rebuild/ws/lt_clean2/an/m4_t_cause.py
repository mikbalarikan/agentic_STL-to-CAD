"""M4: attribute the band loss (old ok -> part 5 bad) to location causes; table + map."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
W4 = os.path.join(lib.W, "m4")
CAUSES = [  # name, x0,x1,y0,y1, text
 ("K1 knee +X junction", 45, 82, -55, -12, "p5 loft flares the +X knee wall out by up to 11 mm (and pad circle R7 around boss 62,-40); scan wall wraps the boss; tongue missing y -37..-23"),
 ("K2 +X wall bump y -12..30", 76, 90, -12, 30, "wall 0.8 mm too far out on both faces (loft/fairing), thickness right"),
 ("K3 +X rib roots y 30..52", 56, 90, 30, 52, "rib/boss root fillets and wall step at y 50-55 differ (interior face +1 mm)"),
 ("W1 +X thin wall y 52..128", 79, 105, 52, 128, "scan wall 1.8 (outer) / 2.1 (inner) thick, p5 Shell 3.1: interior face 1.0-1.2 mm off"),
 ("W2 +X hip thin wall y 175..252", 105, 124, 175, 252, "same thin wall, scan 1.9 / 2.05, p5 3.1"),
 ("H1 +X hip end y 252..290", 85, 125, 252, 292, "wall widening to 3.2 at y 262 and exterior +0.9 mm out; p5 tongue starts y 266.6 (scan 261.7)"),
 ("X1 -X wall lower y 20..100", -66, -22, 20, 100, "exterior 0.8 mm out at y 51-64 (wall bend), rib root at y 31 and 88-91 (+1.5 interior face)"),
 ("X2 -X wall upper y 100..182", -50, -15, 100, 182, "rib/boss roots at y 154-157, 172-175 (small)"),
 ("X3 -X hip y 235..290", -50, -25, 235, 292, "exterior 1.0-1.4 out + interior face +1.3 at y 250-268 (old master was 2 mm in)"),
]
res = {}
fig, axs = plt.subplots(1, 2, figsize=(18, 22))
for ax, (scan, tag, new, old) in zip(axs, (("out_scan", "out", "FINout", "oldC"), ("inn_scan", "inn", "FINinn", "oldInnB"))):
    v, f = lib.load(scan, 1500000); c, nn, a = lib.tri_data(v, f); A = a.sum()
    dn = np.load(os.path.join(lib.W, f"dev_{new}.npz"))["d1"]; do = np.load(os.path.join(lib.W, f"dev_{old}.npz"))["d1"]
    band = (c[:, 2] > 30) & (c[:, 2] < 42)
    lost = band & (dn >= .5) & (do < .5); gain = band & (dn < .5) & (do >= .5)
    ass = np.full(len(c), -1)
    for k, (nm, x0, x1, y0, y1, _) in enumerate(CAUSES):
        m = (c[:, 0] >= x0) & (c[:, 0] < x1) & (c[:, 1] >= y0) & (c[:, 1] < y1) & (ass < 0)
        ass[m] = k
    z = c[:, 2]
    r = {}
    for k, (nm, *_rest) in enumerate(CAUSES + [("other", 0, 0, 0, 0, "")]):
        kk = k if k < len(CAUSES) else -1
        m = ass == kk
        r[nm] = dict(lost_pts=round(float(a[lost & m].sum() / A * 100), 3), gain_pts=round(float(a[gain & m].sum() / A * 100), 3),
                     lost_z30_34p6=round(float(a[lost & m & (z < 34.6)].sum() / A * 100), 3), lost_z34p6_36p5=round(float(a[lost & m & (z >= 34.6) & (z < 36.5)].sum() / A * 100), 3), lost_z36p5_42=round(float(a[lost & m & (z >= 36.5)].sum() / A * 100), 3))
    res[tag] = r
    print(scan, "total lost %.3f gain %.3f net %.3f" % (a[lost].sum() / A * 100, a[gain].sum() / A * 100, (a[lost].sum() - a[gain].sum()) / A * 100))
    for nm, d in r.items(): print("   %-34s lost %.3f gain %.3f  | z<34.6 %.3f  34.6-36.5 %.3f  >36.5 %.3f" % (nm, d["lost_pts"], d["gain_pts"], d["lost_z30_34p6"], d["lost_z34p6_36p5"], d["lost_z36p5_42"]))
    cols = plt.cm.tab10(np.arange(10))
    ax.scatter(c[band, 0][::20], c[band, 1][::20], s=0.3, c="0.88")
    for k, (nm, x0, x1, y0, y1, _) in enumerate(CAUSES):
        m = lost & (ass == k); ax.scatter(c[m, 0], c[m, 1], s=1.5, color=cols[k], label=nm)
        ax.add_patch(plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ec=cols[k], lw=0.6, ls=":"))
    m = lost & (ass < 0); ax.scatter(c[m, 0], c[m, 1], s=1.5, c="k", label="other")
    ax.set_aspect("equal"); ax.grid(lw=.3); ax.legend(fontsize=8, loc="lower left", markerscale=6); ax.set_title(scan + ": band loss by cause region")
fig.tight_layout(); fig.savefig(os.path.join(W4, "loss_by_cause.png"), dpi=45)
json.dump(dict(causes=[dict(name=c_[0], box=c_[1:5], text=c_[5]) for c_ in CAUSES], table=res), open(os.path.join(W4, "loss_by_cause.json"), "w"), indent=1)
