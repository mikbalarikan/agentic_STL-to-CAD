"""t5 check: mesh validity, scan->CAD on tail region before/after, renders. usage: t5_chk.py shell_after.stl [shell_before.stl]"""
import sys; sys.path.insert(0,'an')
import numpy as np, trimesh, open3d as o3d, lib
after=sys.argv[1]; before=sys.argv[2] if len(sys.argv)>2 else "nx/base_v2/shell_r0.stl"
def info(fn):
    m=trimesh.load(fn,process=True); comps=m.split(only_watertight=False)
    big=max(comps,key=lambda q:len(q.faces))
    om=o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(big.vertices),o3d.utility.Vector3iVector(big.faces))
    print(fn,"components",len(comps),[len(q.faces) for q in comps][:6],"watertight(main)",big.is_watertight,"vol %.1f"%big.volume,
          "edge-manifold",om.is_edge_manifold(),"vertex-manifold",om.is_vertex_manifold(),"self-intersecting",om.is_self_intersecting())
    return big
def scan2cad(m,label):
    sc=o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(m.vertices.astype(np.float32)),o3d.core.Tensor(m.faces.astype(np.uint32)))
    for nm in ("out_scan","inn_scan"):
        v,f=lib.load(nm,1500000); c,n,a=lib.tri_data(v,f)
        sel=(c[:,0]>45)&(c[:,1]<-25)
        d=sc.compute_distance(o3d.core.Tensor(c[sel].astype(np.float32))).numpy()
        w=a[sel]
        print("  %s %-8s tail region (X>45,Y<-25): n %5d  area-weighted within0.5 %.1f%%  within0.3 %.1f%%  p50 %.3f p90 %.3f max %.2f"%(label,nm,sel.sum(),100*w[d<=0.5].sum()/w.sum(),100*w[d<=0.3].sum()/w.sum(),np.median(d),np.percentile(d,90),d.max()))
print("== AFTER"); mA=info(after); scan2cad(mA,"after")
print("== BEFORE"); mB=info(before); scan2cad(mB,"before")
import t5_r
t5_r.render([(mA,"#c9d3dc")],"work/t5/cad_tail_iso_r2.png")
t5_r.render([(mA,"#c9d3dc")],"work/t5/cad_tail_px_r2.png",cd=(1,0,0))
t5_r.render([(mA,"#c9d3dc")],"work/t5/cad_tail_top_r2.png",cd=(0.6,-0.8,1.4))
t5_r.render([(mA,"#c9d3dc")],"work/t5/cad_tail_isoB_r2.png",cd=(0.6,-1,-0.3))
