"""M4 step 4: where part 5 deviates > 0.5 and the old master does not, inside the joint band. Clusters + causes."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np, trimesh, open3d as o3d
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
W4 = os.path.join(lib.W, "m4"); MK = os.path.join(lib.W, "masks")
P5 = {"out": r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 5 - Clean Rebuild\deliver\CAD\LT-OUT-001_Left_Thigh_Outer.stl",
      "inn": r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 5 - Clean Rebuild\deliver\CAD\LT-INN-001_Left_Thigh_Inner.stl"}
def closest(path, q):
    m = trimesh.load(path, process=False); m.merge_vertices()
    sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.core.Tensor(np.asarray(m.vertices, np.float32)), o3d.core.Tensor(np.asarray(m.faces, np.uint32)))
    r = sc.compute_closest_points(o3d.core.Tensor(q.astype(np.float32)))
    return r["points"].numpy().astype(float)
out = {}
for scan, tag, new, old in (("out_scan", "out", "FINout", "oldC"), ("inn_scan", "inn", "FINinn", "oldInnB")):
    v, f = lib.load(scan, 1500000); c, nn, a = lib.tri_data(v, f)
    dn = np.load(os.path.join(lib.W, f"dev_{new}.npz"))["d1"]; do = np.load(os.path.join(lib.W, f"dev_{old}.npz"))["d1"]
    J = np.load(os.path.join(MK, f"{tag}_joint.npy"))
    w = a / a.sum()
    inJ = np.zeros(len(c), bool); inJ[J] = True
    band = (c[:, 2] > 30) & (c[:, 2] < 42)
    print(scan, "joint mask area share %.2f%%" % (w[J].sum() * 100), "in band z30-42 any: %.2f%%" % (w[band].sum() * 100))
    for nm, mk in (("joint mask", inJ), ("band z30-42 (all)", band)):
        print("   %-18s new<.5 %5.1f%%  old<.5 %5.1f%%  | lost share (old ok, new bad) %.3f%% gained %.3f%% net %.3f pts" % (nm, w[mk & (dn < .5)].sum() / w[mk].sum() * 100, w[mk & (do < .5)].sum() / w[mk].sum() * 100,
              w[mk & (do < .5) & (dn >= .5)].sum() * 100, w[mk & (dn < .5) & (do >= .5)].sum() * 100, (w[mk & (do < .5) & (dn >= .5)].sum() - w[mk & (dn < .5) & (do >= .5)].sum()) * 100))
    bad = np.where(band & (dn >= 0.5) & (do < 0.5))[0]
    print("   bad (band, new>=.5, old<.5): n %d area %.1f mm2 = %.3f%% of scan" % (len(bad), a[bad].sum(), w[bad].sum() * 100))
    # cluster
    t = cKDTree(c[bad]); pr = t.query_pairs(2.5, output_type="ndarray")
    G = coo_matrix((np.ones(len(pr)), (pr[:, 0], pr[:, 1])), shape=(len(bad),) * 2)
    nc, lab = connected_components(G, directed=False)
    cp = closest(P5[tag], c[bad])
    vec = c[bad] - cp                      # scan minus part-5 surface
    cl = []
    for k in range(nc):
        m = lab == k; ar = a[bad[m]].sum()
        if ar < 4: continue
        ii = bad[m]
        cl.append(dict(k=int(k), n=int(m.sum()), area=float(ar), share=float(ar / a.sum() * 100), cx=float(c[ii, 0].mean()), cy=float(c[ii, 1].mean()), cz=float(c[ii, 2].mean()),
                       x0=float(c[ii, 0].min()), x1=float(c[ii, 0].max()), y0=float(c[ii, 1].min()), y1=float(c[ii, 1].max()), z0=float(c[ii, 2].min()), z1=float(c[ii, 2].max()),
                       dn=float(dn[ii].mean()), do=float(do[ii].mean()), nz=float(np.average(nn[ii, 2], weights=a[ii])), dvec=[float(x) for x in np.average(vec[m], axis=0, weights=a[ii])],
                       nxy=[float(x) for x in np.average(nn[ii, :2], axis=0, weights=a[ii])], idx=ii))
    cl.sort(key=lambda r: -r["area"])
    out[tag] = cl
    np.save(os.path.join(MK, f"{tag}_joint_bad.npy"), bad.astype(np.int64))
    print("   clusters >=4 mm2:", len(cl), " covering %.1f%% of bad area" % (100 * sum(r["area"] for r in cl) / a[bad].sum()))
    for r in cl[:25]:
        print("   #%-4d A%6.1f (%.3f%%) X[%7.1f,%7.1f] Y[%7.1f,%7.1f] Z[%5.2f,%5.2f]  dFIN %.2f dOLD %.2f  nz %+.2f  scan-minus-p5 (%+.2f %+.2f %+.2f)" % (r["k"], r["area"], r["share"], r["x0"], r["x1"], r["y0"], r["y1"], r["z0"], r["z1"], r["dn"], r["do"], r["nz"], *r["dvec"]))
import pickle; pickle.dump(out, open(os.path.join(W4, "clusters.pkl"), "wb"))
