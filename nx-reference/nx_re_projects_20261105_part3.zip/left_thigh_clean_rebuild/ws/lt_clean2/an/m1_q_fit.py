"""M1 stage A: iterate drum cone mask + candidate profile fits. Writes work/m1/_fit.json"""
import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.optimize import least_squares
S={}
for nm in ("out_scan","inn_scan"):
    v,f=lib.load(nm,1500000); c,nn,ar=lib.tri_data(v,f); S[nm]=(c,nn,ar)
ZR={"out_scan":(-10.3,35.0),"inn_scan":(35.4,80.2)}
AX=np.array([0.12,-0.02]); Rp,zp,t=68.80,36.85,0.0275
for it in range(3):
    P=[];
    for k,nm in enumerate(S):
        c,nn,ar=S[nm]; x=c[:,0]-AX[0]; y=c[:,1]-AX[1]; r=np.hypot(x,y); ang=np.degrees(np.arctan2(x,-y))
        radial=(x*nn[:,0]+y*nn[:,1])/np.maximum(r,1e-9); dev=r-(Rp-np.abs(c[:,2]-zp)*t)
        m=(radial>0.95)&(np.abs(dev)<0.3)&(c[:,2]>ZR[nm][0])&(c[:,2]<ZR[nm][1])&(ang>-135)&(ang<50.0)
        P.append(np.c_[c[m],np.full(m.sum(),k),ar[m]])
    P=np.vstack(P)
    def res(q,P=P):
        d=np.hypot(P[:,0]-q[3],P[:,1]-q[4]); return d-(q[0]-np.abs(P[:,2]-q[1])*q[2])
    s=least_squares(res,[Rp,zp,t,AX[0],AX[1]],loss="soft_l1",f_scale=.1)
    Rp,zp,t=s.x[:3]; AX=s.x[3:5]
    print(it,len(P),s.x.round(4))
np.save("work/m1/_P_cone.npy",P)
out={}
w=P[:,4]
def stats(r):
    a=np.abs(r); 
    o=np.argsort(a); cw=np.cumsum(w[o])/w.sum()
    return dict(mean=float(np.average(a,weights=w)),p50=float(a[o][np.searchsorted(cw,.5)]),p90=float(a[o][np.searchsorted(cw,.9)]),p95=float(a[o][np.searchsorted(cw,.95)]),p99=float(a[o][np.searchsorted(cw,.99)]),w_le_0p1=float(w[a<0.1].sum()/w.sum()),w_le_0p3=float(w[a<0.3].sum()/w.sum()),w_le_0p5=float(w[a<0.5].sum()/w.sum()))
z=P[:,2]
def rad(ax,tilt=(0,0)):
    return np.hypot(P[:,0]-(ax[0]+tilt[0]*(z-36)),P[:,1]-(ax[1]+tilt[1]*(z-36)))
cands={}
def fitc(name,fun,q0,nax):
    # fun(q,z)->R ; axis params appended
    def r(q):
        ax=q[len(q0):len(q0)+2] if nax>=2 else (0,0); tl=q[len(q0)+2:len(q0)+4] if nax==4 else (0,0)
        return rad(ax,tl)-fun(q[:len(q0)],z)
    qq=list(q0)+([0.1,0]if nax>=2 else [])+([0,0] if nax==4 else [])
    s=least_squares(r,qq,loss="soft_l1",f_scale=.1)
    cands[name]=dict(params=[float(a) for a in s.x],stats=stats(r(s.x)))
fitc("cone_sym_origin",lambda q,z:q[0]-np.abs(z-q[1])*q[2],[68.8,36.8,.0275],0)
fitc("cone_sym_axis",lambda q,z:q[0]-np.abs(z-q[1])*q[2],[68.8,36.8,.0275],2)
fitc("cone_sym_axis_tilt",lambda q,z:q[0]-np.abs(z-q[1])*q[2],[68.8,36.8,.0275],4)
fitc("cone_2slopes_axis",lambda q,z:np.where(z>q[1],q[0]-(z-q[1])*q[2],q[0]-(q[1]-z)*q[3]),[68.8,36.8,.0275,.0275],2)
fitc("cone_zp3607_sym_axis",lambda q,z:q[0]-np.abs(z-36.07)*q[1],[68.8,.0275],2)
fitc("poly2_axis",lambda q,z:np.polyval(q,z),[0,0,68.8],2)
fitc("poly4_axis",lambda q,z:np.polyval(q,(z-36)),[0,0,0,0,68.8],2)
# spline (cubic, 6 knots) revolve
from scipy.interpolate import CubicSpline
kn=np.linspace(-10,80,7)
fitc("spline6_axis",lambda q,z:CubicSpline(kn,q,bc_type='natural')(z),[68.0,68.2,68.6,68.8,68.6,68.2,67.7],2)
# cone + parting fillet (sag at peak): R = cone - sag(z) where fillet radius rf tangent -> sag = rf - sqrt(rf^2 - ...)  approximated by hyperbola smoothing
fitc("cone_sym_smooth_peak",lambda q,z:q[0]-q[2]*(np.sqrt((z-q[1])**2+q[3]**2)-abs(q[3])),[68.8,36.8,.0275,1.0],2)
for k,v in cands.items(): print(f"{k:24s} mean {v['stats']['mean']:.4f} p50 {v['stats']['p50']:.4f} p90 {v['stats']['p90']:.4f} p95 {v['stats']['p95']:.4f} <=.1 {v['stats']['w_le_0p1']:.3f} params {np.round(v['params'],4).tolist()}")
json.dump(cands,open("work/m1/_cands.json","w"),indent=1)
