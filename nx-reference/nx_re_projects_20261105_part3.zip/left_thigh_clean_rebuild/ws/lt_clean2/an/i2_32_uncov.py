from i2_rows import *
import json
from scipy import ndimage as ndi
F = json.load(open(r"C:\NX_MCP_WORKSPACE\lt_clean2\FEATURES_inn.json"))
covall = np.zeros(N, bool)
for r in F:
    if r["id"] in ("JOINT_BOSS_FACES", "LIP_FACE"): continue
    covall[np.load(os.path.join(MASKS, f"inn_f_{r['id']}.npy"))] = True
lost = (d >= 3.9) & (old < .5) & (p5 >= .5) & ~covall
x, y, z = c[:, 0], c[:, 1], c[:, 2]
s = 2.0; x0, y0 = -75, -75
im = np.zeros((int(380 * s), int(200 * s))); X = ((x[lost] - x0) * s).astype(int); Y = ((y[lost] - y0) * s).astype(int); np.add.at(im, (Y, X), w_area[lost] * 100)
lab, nl = ndi.label(ndi.binary_dilation(im > 0, iterations=3))
out = []
for k in range(1, nl + 1):
    sel = np.zeros(N, bool); sel[np.flatnonzero(lost)[lab[Y, X] == k]] = True
    out.append((w_area[sel].sum() * 100, sel))
out.sort(key=lambda t: -t[0])
res = []
for A, sel in out[:12]:
    cc = c[sel]; nz_ = n[sel, 2]
    kind = "tilted (blend / sloped wall)" if np.median(nz_) < -0.15 and np.median(nz_) > -0.97 else ("vertical wall" if abs(np.median(nz_)) < 0.15 else "flat")
    row = dict(area_pct=round(A, 3), x=[round(float(cc[:, 0].min())), round(float(cc[:, 0].max()))], y=[round(float(cc[:, 1].min())), round(float(cc[:, 1].max()))], z=[round(float(np.percentile(cc[:, 2], 5))), round(float(np.percentile(cc[:, 2], 95)))], p5_p90=round(p90(p5[sel]), 2), old_p90=round(p90(old[sel]), 2), de_med=round(float(np.median(d[sel])), 1), kind=kind)
    res.append(row); print(row)
json.dump(res, open(os.path.join(O, "uncovered_lost_clusters.json"), "w"), indent=1)
