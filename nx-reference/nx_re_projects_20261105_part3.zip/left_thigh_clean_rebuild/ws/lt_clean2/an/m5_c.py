import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, trimesh
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
env = trimesh.load(os.path.join(lib.W,"env_part5.stl"), process=False)
ev,ef=np.asarray(env.vertices),np.asarray(env.faces)
D={}
for scan,cad,key in (("out_scan","out_cad","out"),("inn_scan","inn_cad","inn")):
    v,f=lib.load(scan,1500000); cv,cf=lib.load(cad)
    c,nn,ar=lib.tri_data(v,f)
    band=np.load(os.path.join(lib.W,"masks",f"{key}_band.npy")); cpz=np.load(os.path.join(lib.W,"m5",f"{key}_cp.npz"))
    dot=cpz["dot"]
    for Y in (0,100,200):
        fig,axs=plt.subplots(1,2,figsize=(16,8))
        for ax,(xl,yl) in zip(axs,[(None,None),(None,None)]):
            for (vv,ff,col,lab,lw) in ((v,f,'k','scan',.6),(ev,ef,'r','env5',.8),(cv,cf,'b','oldmaster',.6)):
                s=lib.section(vv,ff,1,Y)
                for a,b in s: ax.plot([a[0],b[0]],[a[2],b[2]],col,lw=lw)
            # band tris
            sel=band[np.abs(c[band,1]-Y)<3]
            ax.scatter(c[sel,0],c[sel,2],s=4,c=np.where(dot[sel]>0,'g','m'))
            ax.set_aspect('equal')
        axs[1].set_xlim(60,125); 
        zz=c[(np.abs(c[:,1]-Y)<3)]
        axs[0].set_title(f"{key} Y={Y} black scan red env5 blue old; band tris green=ext-facing magenta=int-facing")
        plt.savefig(os.path.join(lib.W,"m5",f"sec_{key}_Y{Y}.png"),dpi=80); plt.close()
