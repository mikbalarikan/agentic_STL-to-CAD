import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, m2_loft as L, m2_g_fit as G, m2_f_data as FD, m2_o_fitband as B, m2_q_env as Q
st=[float(s) for s in sys.argv[1].split(",")]; NP=int(sys.argv[2]); tag=sys.argv[3]
D=Q.shifted_cells(); lf,keep,sr=G.run(st,NP,D=D); np.savez(f"work/m2/loft_{tag}.npz",st=st,P=lf.P)
V,F,ys,u=G.mesh_of(lf,st[0],st[-1])
S=G.scan_pts(st[0],255); d=G.dist_to(V,F,S[:,:3]); ib=B.inband(S[:,1],S[:,0],S[:,2],1.0); y=S[:,1]
for lo,hi in ((40,52),(52,60),(60,70),(70,100),(100,250)):
    m=(y>=lo)&(y<hi)&~ib&(y>=st[0]); 
    if m.sum(): f,p90,p50=G.stats(d[m],S[m,3]); print(tag,lo,hi,"%.1f%% p90 %.3f"%(100*f,p90))
# hidden protrusion: loft vertices beyond the drum where drum should own the surface
Vx=V[V[:,1]<60]; ov=np.hypot(Vx[:,0],Vx[:,1])-FD.drum_R(np.clip(Vx[:,2],-13.9,83.62)); inz=(Vx[:,2]>-13.9)&(Vx[:,2]<83.62)
th=np.degrees(np.arctan2(Vx[:,2]-35,Vx[:,0]-40)); mm=inz&(np.abs(th)>50)
print("loft vertices Y<60, theta>50 (not +X side): max protrusion beyond drum %.2f mm, frac>0.5: %.3f"%(ov[mm].max(),(ov[mm]>0.5).mean()))
