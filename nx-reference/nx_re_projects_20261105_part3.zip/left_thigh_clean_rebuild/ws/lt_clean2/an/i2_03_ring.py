from i2_common import *
v,f,c,n,a = scan(); d = de(); p5,old=dev()
r=np.hypot(c[:,0],c[:,1]); th=np.degrees(np.arctan2(c[:,1],c[:,0]))%360
h=(np.abs(n[:,2])<0.5)&(d>2.0)&(c[:,2]>70)&(c[:,2]<92)
for a0,a1 in ((110,320),(120,200),(200,260),(260,320)):
    m=h&(th>a0)&(th<a1)&(r>8)&(r<72)
    hist,ed=np.histogram(r[m],bins=np.arange(8,72,0.25),weights=a[m])
    from scipy.signal import find_peaks
    pk,_=find_peaks(hist,height=hist.max()*0.03,distance=2)
    print(a0,a1,[(round(ed[i]+.125,2),round(hist[i])) for i in pk])
