"""M4 step 2a: perimeter stations from the inner-scan lip face (centreline of the strip), with vertical-ray height
profiles (outer scan from above, inner scan from below) and horizontal wall faces at several z."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra, connected_components
from scipy.ndimage import gaussian_filter1d
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\an")
from rays import Caster
from m4_a_planes import patches

W4 = os.path.join(lib.W, "m4")
def lip_points():
    v, f = lib.load("inn_scan", 1500000); c, nn, a = lib.tri_data(v, f)
    m, lab, nc = patches(v, f, c, nn, a, -1, 35.0, 35.7, 0.9)
    keep = []
    for k in range(nc):
        idx = m[lab == k]
        if a[idx].sum() > 8: keep.append(idx)
    idx = np.concatenate(keep)
    return c[idx, :2], idx

def chains(P):
    t = cKDTree(P)
    pr = t.query_pairs(3.0, output_type="ndarray")
    G = coo_matrix((np.ones(len(pr)), (pr[:, 0], pr[:, 1])), shape=(len(P),) * 2)
    nc, lab = connected_components(G, directed=False)
    return nc, lab

def centreline(P, step=1.0):
    t = cKDTree(P)
    d, nb = t.query(P, k=10)
    r = np.repeat(np.arange(len(P)), 10)
    G = coo_matrix((d.ravel() + 1e-6, (r, nb.ravel())), shape=(len(P),) * 2).tocsr()
    G = G.maximum(G.T)
    d0 = dijkstra(G, indices=0, directed=False); d0[~np.isfinite(d0)] = -1
    A = int(np.argmax(d0))
    dA = dijkstra(G, indices=A, directed=False); dA[~np.isfinite(dA)] = -1
    B = int(np.argmax(dA))
    s = dA
    bins = np.arange(0, s.max() + step, step)
    cen = []
    for i in range(len(bins) - 1):
        m = (s >= bins[i]) & (s < bins[i + 1])
        if m.sum() >= 3: cen.append((0.5 * (bins[i] + bins[i + 1]), *P[m].mean(0), m.sum()))
    return np.array(cen), P[A], P[B]

if __name__ == "__main__":
    P, idx = lip_points()
    nc, lab = chains(P)
    print("components", nc, [int((lab == k).sum()) for k in range(nc)])
    out = {}
    for k in range(nc):
        if (lab == k).sum() < 200: continue
        cen, A, B = centreline(P[lab == k])
        print(k, "len %.0f" % cen[-1, 0], "A", A.round(1), "B", B.round(1), len(cen))
        out[k] = cen
    np.savez(os.path.join(W4, "chains_raw.npz"), **{str(k): v for k, v in out.items()})
