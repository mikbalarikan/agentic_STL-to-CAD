from i2_view import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
def ov(ax):
    for k,(x,y) in DS.CH_HOLES.items(): ax.add_patch(plt.Circle((x,y),3,fill=False,ec='w',lw=.6)); ax.text(x,y+3.5,k,color='w',fontsize=7)
    ax.plot([DS.CH_J_IN[0],DS.CH_TOP_L[0]],[DS.CH_J_IN[1],DS.CH_TOP_L[1]],'w-',lw=.6); ax.plot([DS.CH_J_OUT[0],DS.CH_TOP_R[0]],[DS.CH_J_OUT[1],DS.CH_TOP_R[1]],'w-',lw=.6)
show("v_run1",25,95,-30,70,12,'z',(74,82),overlay=ov,size=12)
show("v_run2",25,100,60,140,12,'z',(74,82),overlay=ov,size=12)
