import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
HX,HZ=37.97,35.18
for n,tag,zs in (('out_scan','out',lambda z:z<34),('inn_scan','inn',lambda z:z>37),('out_cad','oc',lambda z:z<34),('inn_cad','ic',lambda z:z>37)):
    v,f=lib.load(n,1500000) if 'scan' in n else lib.load(n); c,nn,a=lib.tri_data(v,f)
    m=(c[:,1]>285)&(abs(nn[:,1])>0.9)&zs(c[:,2])
    y=c[m,1]; r=np.hypot(c[m,0]-HX,c[m,2]-HZ)
    print(tag,'mouth-face tris',m.sum(),'Y pct',np.percentile(y,[1,10,50,90,99]).round(2),'area',a[m].sum().round(0))
    w=a[m]; yy=np.average(y,weights=w); print('  Y mean',yy.round(3),'r range',np.percentile(r,[1,5,50,95,99]).round(2))
    # plane fit
    A=np.c_[c[m,0],c[m,2],np.ones(m.sum())]; co=np.linalg.lstsq(A,y,rcond=None)[0]; res=y-A@co
    print('  plane y=%.4f x%+.5f z%+.5f'%(co[2],co[0],co[1]),'res std',res.std().round(3))
    # outer exterior profile last mm
    m2=(nn[:,1]>-0.5)&(nn[:,1]<0.5)&(c[:,1]>280)&zs(c[:,2])
    r2=np.hypot(c[:,0]-HX,c[:,2]-HZ)
    for y0 in np.arange(280,288.2,0.8):
        k=m2&(abs(c[:,1]-y0)<0.4)&(r2>60)
        if k.sum()>5: print('   Y%.1f maxr(p97) %.2f  p50 %.2f n=%d'%(y0,np.percentile(r2[k],97),np.median(r2[k]),k.sum()))
