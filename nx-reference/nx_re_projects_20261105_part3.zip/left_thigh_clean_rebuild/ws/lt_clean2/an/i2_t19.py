from i2_rows import *
x,y,z=c[:,0],c[:,1],c[:,2]
m=(n[:,2]<-0.9)&(z<37.5)
h,ed=np.histogram(z[m],bins=np.arange(34.5,37.5,0.05),weights=a[m])
from scipy.signal import find_peaks
pk,_=find_peaks(h,height=h.max()*0.02,distance=2)
for i in pk:
    s=m&(np.abs(z-ed[i]-.025)<0.1); 
    print("level",round(ed[i]+.025,2),"area",round(a[s].sum()),"x",np.percentile(x[s],[2,98]).round(0),"y",np.percentile(y[s],[2,98]).round(0))
# plan view of levels
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(10,16))
s=m
sc=ax.scatter(x[s],y[s],c=z[s],s=0.3,cmap='turbo',vmin=35.0,vmax=36.5); ax.set_aspect('equal'); plt.colorbar(sc); 
plt.savefig(os.path.join(O,"joint_levels.png"),dpi=70)
