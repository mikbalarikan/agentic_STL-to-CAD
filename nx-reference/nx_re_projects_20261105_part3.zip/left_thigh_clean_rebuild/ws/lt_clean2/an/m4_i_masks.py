"""M4 step 3: masks (int64 triangle indices into lib.load(scan,1500000)) -> work/masks/{out,inn}_joint*.npy"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
from scipy.spatial import cKDTree
from m4_a_planes import patches
W4 = os.path.join(lib.W, "m4"); MK = os.path.join(lib.W, "masks")
D = np.load(os.path.join(W4, "stations.npz"))
names = ["KNEE_ARC", "PX_WALL", "PX_HIP", "MX_WALL", "MX_HIP"]
rows = list(np.load(os.path.join(W4, "stations_rows.npy"), allow_pickle=True))
SP = np.vstack([D[n + "__p"] for n in names])
# station flags for tongue / rebate
fl_t = np.array([r.get("tongue", False) for r in rows]); fl_r = np.array([r.get("rebate", False) for r in rows])
# rows are in the same order as names -> SP
assert len(rows) == len(SP)
FAM = {"out_scan": dict(rim=(1, 34.4, 35.3), tongue_top=(1, 35.7, 36.5), boss_face=(1, 38.8, 39.4)),
       "inn_scan": dict(lip=(-1, 35.1, 35.6), rebate_floor=(-1, 35.8, 36.4), boss_face=(-1, 38.8, 39.4))}
res = {}
for scan, tag in (("out_scan", "out"), ("inn_scan", "inn")):
    v, f = lib.load(scan, 1500000); c, nn, a = lib.tri_data(v, f)
    n = len(f); sel = {}
    famidx = {k: [] for k in FAM[scan]}
    for sgn in (1, -1):
        m, lab, nc = patches(v, f, c, nn, a, sgn, 30, 42, 0.97)
        for k in range(nc):
            idx = m[lab == k]
            if a[idx].sum() < 8: continue
            zz = c[idx, 2].mean()
            for nm, (s, lo, hi) in FAM[scan].items():
                if s == sgn and lo < zz < hi: famidx[nm].append(idx)
    famidx = {k: (np.concatenate(v_) if v_ else np.zeros(0, int)) for k, v_ in famidx.items()}
    tr = cKDTree(SP)
    d2, ks = tr.query(c[:, :2])
    inband = (c[:, 2] > 30) & (c[:, 2] < 42)
    near = inband & (d2 <= 6.0)
    horiz = np.unique(np.concatenate(list(famidx.values())))
    joint = np.where(near | np.isin(np.arange(n), horiz))[0]
    np.save(os.path.join(MK, f"{tag}_joint.npy"), joint.astype(np.int64))
    for nm, idx in famidx.items():
        np.save(os.path.join(MK, f"{tag}_joint_{nm}.npy"), np.sort(idx).astype(np.int64))
    # side faces of the tongue (outer) / rebate (inner): steep triangles close to the top/floor patches
    top = famidx["tongue_top" if tag == "out" else "rebate_floor"]
    if len(top):
        t3 = cKDTree(c[top])
        d3, _ = t3.query(c)
        steep = np.abs(nn[:, 2]) < 0.6
        zlo, zhi = (34.7, 36.15) if tag == "out" else (35.25, 36.15)
        side = np.where(steep & (d3 < 1.8) & (c[:, 2] > zlo) & (c[:, 2] < zhi) & (d2 <= 6.0))[0]
        np.save(os.path.join(MK, f"{tag}_joint_{'tongue_side' if tag=='out' else 'rebate_side'}.npy"), side.astype(np.int64))
        famidx["side"] = side
    # exterior shadow-gap faces: steep triangles at the wall exterior (plan station distance <= 6, farthest side) in the 2 mm below rim / above lip
    ext = np.where((np.abs(nn[:, 2]) < 0.6) & (d2 <= 6.0) & (c[:, 2] > (33.0 if tag == "out" else 35.3)) & (c[:, 2] < (34.8 if tag == "out" else 37.5)))[0]
    # keep the exterior-facing ones (normal . outward station normal > 0.7)
    N = np.vstack([D[nm + "__n"] for nm in names])
    outw = (nn[ext, :2] * N[ks[ext]]).sum(1) > 0.7
    # and close to the exterior wall face: signed offset along normal from station within [0, 3]
    off = ((c[ext, :2] - SP[ks[ext]]) * N[ks[ext]]).sum(1)
    ext = ext[outw & (off > -0.5) & (off < 4.0)]
    np.save(os.path.join(MK, f"{tag}_joint_ext_wall.npy"), ext.astype(np.int64)); famidx["ext_wall"] = ext
    res[tag] = {"joint": (int(len(joint)), float(a[joint].sum()))}
    for k, idx in famidx.items(): res[tag][k] = (int(len(idx)), float(a[idx].sum()))
    print(tag, res[tag])
json.dump(res, open(os.path.join(W4, "masks_summary.json"), "w"), indent=1)
