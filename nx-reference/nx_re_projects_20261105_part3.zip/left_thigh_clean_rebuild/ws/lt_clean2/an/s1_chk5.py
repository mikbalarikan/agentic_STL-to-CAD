from s1_build import *
import s1_conedef as CD
import open3d as o3d
V,F=to_mesh(cone_solid(),0.02); sc=o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(V.astype(np.float32)),o3d.core.Tensor(F.astype(np.uint32)))
# compare rho formula: points at rho=0 along rays
for Y in [262,276,286]:
    for th in [0,90,180,270]:
        x,z=CD.ray_point(Y,np.radians(th),0.0)
        # ray from (40,Y,35) along dir, distance to cone mesh
        d=np.array([x-40,0,z-35]); L=np.linalg.norm(d); d/=L
        t=sc.cast_rays(o3d.core.Tensor(np.array([[40,Y,35,*d]],np.float32)))['t_hit'].numpy()[0]
        print(Y,th,'formula',round(L,2),'ocp',round(float(t),2))
