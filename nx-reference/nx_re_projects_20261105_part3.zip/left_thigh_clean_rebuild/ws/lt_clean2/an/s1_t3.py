import sys
from s1_build import *
from s1_snap import snap
tag=sys.argv[1]
d=np.load(f'work/s1/loft_{tag}.npz'); st=d['st']
for sn in [False,True]:
    P=d['P']
    if sn: P,n=snap(P,st)
    lo=loft(P,st); dr=drum()
    for fz in [None,0.02,0.1]:
        cm=common(lo,dr,fz); fu=fuse(lo,dr,fz)
        print('snap',sn,'fuzzy',fz,'common',round(volume(cm)),'fuse',round(volume(fu)),'expected',round(volume(lo)+volume(dr)-volume(cm)),valid(fu))
