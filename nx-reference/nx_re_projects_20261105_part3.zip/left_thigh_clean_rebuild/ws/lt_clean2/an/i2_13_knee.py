from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS, math
rows = []
r0 = np.hypot(c[:, 0], c[:, 1]); th0 = np.degrees(np.arctan2(c[:, 1], c[:, 0])) % 360
# ---------------- disc floor, hub, bore, screws
dm = (n[:, 2] < -0.9) & (np.abs(c[:, 2] - 80.0) < 1.0) & (r0 < 66.5) & (d >= 2.0)
lf = level_fit(dm)
rows.append(make_row("KNEE_DISC_FLOOR", "plane", dict(z=lf["z"], normal=[0, 0, -1]), "level fit nz<-0.9 z 79..81, r<66.5", lf["rms"],
                     (n[:, 2] < -0.9) & (np.abs(c[:, 2] - 80.0) < 1.2) & (r0 < 66.5) & (d >= 2.0) & (r0 > 20), dict(z=80.02)))
hub = cyl_fit((0, 0), 19.0, 21.0, 87.0, 92.5, de_min=0.0, iters=2)
hub_top = level_fit((n[:, 2] > 0.9) & (r0 < 19.5) & (c[:, 2] > 90))
sh_lvl = level_fit((n[:, 2] > 0.9) & (r0 > 20.5) & (r0 < 21.6) & (c[:, 2] > 85) & (c[:, 2] < 87.5), tol=0.3)
# profile of the shoulder / blend (r -> z), facing up
prof = []
for rr_ in np.arange(20.0, 30.0, 1.0):
    s = (n[:, 2] > 0.15) & (r0 >= rr_) & (r0 < rr_ + 1) & (c[:, 2] > 83) & (c[:, 2] < 93)
    if s.sum() > 20: prof.append((rr_ + .5, wmed(c[s, 2], a[s])))
mhub = (r0 < 31.0) & (r0 > 10.4) & (c[:, 2] > 83.3) & (d >= 0.0) & ~((n[:, 2] < -0.9))
rows.append(make_row("HUB", "revolve", dict(OD=hub["D"] if hub else None, top_z=hub_top["z"] if hub_top else None, shoulder_z=sh_lvl["z"] if sh_lvl else None, blend_profile_rz=prof,
                     centre=[hub["cx"], hub["cy"]] if hub else None), "cylinder fit hub wall z87..92.5 about the knee axis; top / shoulder levels; r-z profile of the blend", hub["rms"] if hub else None, mhub,
                     dict(OD=40.23, top_z=93.0, shoulder_D=43.6, shoulder_z=86.2)))
bore = cyl_fit((0, 0), 8.5, 11.5, 80.0, 93.0, de_min=0.0, iters=2)
rows.append(make_row("HUB_BORE", "hole", dict(D=bore["D"] if bore else None, centre=[bore["cx"], bore["cy"]] if bore else None), "cylinder fit bore wall", bore["rms"] if bore else None,
                     (r0 < 11.5) & (np.abs(n[:, 2]) < 0.6) & (c[:, 2] > 79), dict(D=19.9)))
under = (r0 > 10.4) & (r0 < 21.5) & (n[:, 2] < -0.9) & (c[:, 2] < 82)
lu = level_fit(under)
rows.append(make_row("HUB_UNDERSIDE", "plane", dict(z=lu["z"] if lu else None), "level fit nz<-0.9 under the hub", lu["rms"] if lu else None, under, dict(z=80.02)))
# screws: 4 holes
for k in range(4):
    ang = math.radians(45 + 90 * k); x, y = 15 * math.cos(ang), 15 * math.sin(ang)
    h = cyl_fit((x, y), 0.8, 2.6, 80.0, 93.0, de_min=0.0, iters=3)
    cc = (h["cx"], h["cy"]) if h else (x, y); rr_ = np.hypot(c[:, 0] - cc[0], c[:, 1] - cc[1])
    rows.append(make_row(f"HUB_SCREW{k+1}", "hole", dict(centre=[cc[0], cc[1]], D=h["D"] if h else None, pcd=2 * math.hypot(*cc), angle_deg=math.degrees(math.atan2(cc[1], cc[0])) % 360),
                         "cylinder fit hole wall", h["rms"] if h else None, (rr_ < 3.4) & (np.abs(n[:, 2]) < 0.7) & (c[:, 2] > 79), dict(centre=[x, y], D=3.3, pcd=30.0)))
# ---------------- side window of the drum wall
tr = []
m = (np.abs(n[:, 2]) < 0.5) & (r0 > 62) & (r0 < 72) & (c[:, 2] >= 45) & (c[:, 2] < 58)
hh, ed = np.histogram(th0[m], bins=np.arange(100, 340, 0.25), weights=a[m]); on = hh > 0.1 * np.median(hh[hh > 0]) if (hh > 0).any() else hh > 0
chg = np.flatnonzero(on[1:] != on[:-1]) + 1
edges = [float(ed[i]) for i in chg]
lint = level_fit((n[:, 2] < -0.9) & (r0 > 62) & (r0 < 69) & (th0 > 170) & (th0 < 230) & (c[:, 2] > 60) & (c[:, 2] < 65), tol=0.4)
wm = (r0 > 54) & (r0 < 72) & (th0 > 150) & (th0 < 250) & (c[:, 2] > 35.0) & (c[:, 2] < 66) & (d >= 1.0)
rows.append(make_row("KNEE_WINDOW", "opening", dict(angle_edges_deg=edges, lintel_z=lint["z"] if lint else None), "wall presence vs angle (0.25 deg bins), lintel level", None, wm,
                     dict(angle_from=154.6, angle_to=245.7, lintel_z=62.57)))
dump("knee_a", rows)
