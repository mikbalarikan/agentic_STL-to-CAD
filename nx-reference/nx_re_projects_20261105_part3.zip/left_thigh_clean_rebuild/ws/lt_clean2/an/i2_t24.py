from i2_sec import *
v,f=mesh("scan"); vp,fp=mesh("p5"); vo,fo=mesh("old")
fig,axs=plt.subplots(1,3,figsize=(24,8))
for ax,(y0,xl,zl) in zip(axs,((220.0,(22,54),(84,110)),(166.0,(10,70),(70,92)),(-0.0,(-52,-26),(72,84)))):
    ax_=1
    for (vv,ff,col,lw) in ((vo,fo,'g',1.0),(vp,fp,'r',1.2),(v,f,'k',1.0)):
        for seg in lib.section(vv,ff,1,float(y0)): ax.plot(seg[:,0],seg[:,2],col+'-',lw=lw)
    ax.set_xlim(*xl); ax.set_ylim(*zl); ax.set_aspect('equal'); ax.grid(alpha=.3); ax.set_title(f"y={y0}")
plt.tight_layout(); plt.savefig(os.path.join(O,"fillet_check.png"),dpi=60)
