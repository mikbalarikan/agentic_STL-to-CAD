import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig,axs=plt.subplots(1,4,figsize=(36,9))
for ax,y in zip(axs,(70,130,190,250)):
  for n,s in (("out_scan","out"),("inn_scan","inn")):
    v,f=lib.load(n,1500000); c,nn,ar=lib.tri_data(v,f); fl=np.load(f"work/m2/ext_{s}.npy")
    m=np.abs(c[:,1]-y)<0.4
    ax.scatter(c[m&fl,0],c[m&fl,2],s=2,c='r'); ax.scatter(c[m&~fl,0],c[m&~fl,2],s=2,c='b')
  ax.set_aspect('equal')
plt.tight_layout();plt.savefig("work/m2/chk_flag.png",dpi=50)
