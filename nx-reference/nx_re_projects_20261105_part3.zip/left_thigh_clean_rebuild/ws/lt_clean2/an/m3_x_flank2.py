import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
e5=trimesh.load("work/env_part5.stl",process=False); ve,fe=np.asarray(e5.vertices),np.asarray(e5.faces)
def outer_x(v,f,z,sd,ys):
    s=lib.section(v,f,2,z); P=np.vstack([s[:,0],s[:,1]]); out=[]
    for y in ys:
        k=abs(P[:,1]-y)<0.4; out.append((P[k,0]*sd).max()*sd if k.sum() else np.nan)
    return np.array(out)
ys=np.arange(230,287.5,0.5)
fig,ax=plt.subplots(2,4,figsize=(28,11))
cfg=[('out_scan','out_cad',-1,(8,20)),('out_scan','out_cad',1,(8,20)),('inn_scan','inn_cad',-1,(45,60)),('inn_scan','inn_cad',1,(45,60))]
for col,(sn,cn,sd,zz) in enumerate(cfg):
    vs,fs=lib.load(sn,1500000); vc,fc=lib.load(cn)
    for row,z in enumerate(zz):
        a=ax[row,col]
        for (v,f),c,lab in (((vs,fs),'k','scan'),((vc,fc),'r','old'),((ve,fe),'g','p5')):
            a.plot(ys,outer_x(v,f,z,sd,ys),c+'-',label=lab)
        a.set_title(f"{sn} {'+X' if sd>0 else '-X'} z={z}: outermost x(Y)"); a.grid(True)
ax[0,0].legend(); plt.tight_layout(); plt.savefig("work/m3/flank_prof2.png",dpi=45)
