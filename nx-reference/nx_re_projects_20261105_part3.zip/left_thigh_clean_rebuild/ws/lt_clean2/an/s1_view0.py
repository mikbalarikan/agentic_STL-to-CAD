from s1_lib import *
import pyvista as pv; pv.OFF_SCREEN=True
pts=[];col=[]
for s in ['out','inn']:
    v,f,c,n,a=scan(s)
    for nm,k in [('ext_drum',0),('ext_body',1),('ext_hip',2),('band',3)]:
        mk=mask(s,nm)[::3]; pts.append(c[mk]); col.append(np.full(len(mk),k))
P=np.vstack(pts);C=np.concatenate(col)
for nm,dv in [('top',(0.3,-0.3,1)),('px',(1,-0.2,0.2)),('bot',(0.3,-0.3,-1)),('mx',(-1,-0.2,0.3))]:
    p=pv.Plotter(window_size=(1400,900)); p.add_mesh(pv.PolyData(P),scalars=C,cmap='tab10',point_size=2,render_points_as_spheres=False,show_scalar_bar=False)
    dv=np.array(dv,float);dv/=np.linalg.norm(dv); fo=np.array([40,110,35.]); p.camera.focal_point=fo;p.camera.position=fo+700*dv;p.camera.up=(0,0,1)
    p.screenshot(os.path.join(S1,f'view0_{nm}.png'));p.close()
