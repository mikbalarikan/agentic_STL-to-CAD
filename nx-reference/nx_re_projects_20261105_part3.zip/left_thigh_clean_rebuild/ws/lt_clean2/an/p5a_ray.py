"""z hits of vertical rays through points (r along angle, + lateral off) for several meshes. argv: ang off r1,r2,.. mesh1 mesh2 ..  (mesh 'scan:inn' = decimated scan)"""
import sys, numpy as np, trimesh, open3d as o3d
sys.path.insert(0,'an')
import lib
ang=float(sys.argv[1]); off=float(sys.argv[2]); rs=[float(x) for x in sys.argv[3].split(',')]
a=np.radians(ang); u=np.array([np.cos(a),np.sin(a)]); n=np.array([-u[1],u[0]])
def scene(v,f):
    s=o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(np.asarray(v,np.float32)),o3d.core.Tensor(np.asarray(f,np.uint32))); return s
meshes={}
for a_ in sys.argv[4:]:
    if a_.startswith('scan:'):
        v,f=lib.load({'inn':'inn_scan','out':'out_scan'}[a_[5:]],1500000)
    else:
        m=trimesh.load(a_,process=False); v,f=m.vertices,m.faces
    meshes[a_.split('/')[-1]]=scene(v,f)
pts=[u*r+n*off for r in rs]
o=np.array([[p[0],p[1],-60.0] for p in pts],np.float32); d=np.tile(np.array([0,0,1],np.float32),(len(pts),1))
for k,s in meshes.items():
    # all hits: cast repeatedly
    print(k)
    for i,r in enumerate(rs):
        zs=[]; org=o[i].copy()
        for _ in range(12):
            res=s.cast_rays(o3d.core.Tensor(np.concatenate([org,[0,0,1]])[None].astype(np.float32)))
            t=res['t_hit'].numpy()[0]
            if not np.isfinite(t): break
            z=org[2]+t; zs.append(round(float(z),2)); org[2]=z+0.01
        print('  r',r,zs)
