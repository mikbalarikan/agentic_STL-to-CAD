import i1_run
from i1_core import *
for f_ in FEATS:
    if f_['id'].startswith(("FLOORHOLE","COVERPIN","KNEE_","TAB_","HIP_PLATE","BOSS_B1","ROOT")) : print(f_['id'], f_['params'])
