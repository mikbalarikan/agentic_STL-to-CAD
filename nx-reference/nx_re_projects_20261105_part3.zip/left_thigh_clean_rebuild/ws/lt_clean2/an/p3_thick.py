import sys, numpy as np, open3d as o3d, trimesh
shell, env = sys.argv[1], sys.argv[2]
e = trimesh.load(env); s = trimesh.load(shell)
pts, fi = trimesh.sample.sample_surface(e, 60000, seed=1)
n = e.face_normals[fi]
sc = o3d.t.geometry.RaycastingScene()
sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(s.vertices), o3d.utility.Vector3iVector(s.faces))))
o = pts - n * 0.05; d = -n
r = sc.cast_rays(o3d.core.Tensor(np.hstack([o, d]).astype(np.float32)))
t = r['t_hit'].numpy() + 0.05; P0 = pts
ok = np.isfinite(t) & ~(abs(pts[:,1]-287.39)<0.1) & ~(abs(pts[:,1]+38)<0.1)
bad = ok & (t < 2.9); print('thin pts', P0[bad][:8].round(1).tolist(), bad.sum()); print('thin bbox', P0[bad].min(0).round(1) if bad.any() else '', P0[bad].max(0).round(1) if bad.any() else '')
big = ok & (t > 3.4); print('thick n', big.sum(), P0[big][:5].round(1).tolist())
t = t[ok]
print("rays", len(ok), "hit", ok.sum())
print("thickness: min %.3f p1 %.3f p5 %.3f median %.3f p95 %.3f p99 %.3f max %.3f" % (t.min(), *np.percentile(t, [1, 5, 50, 95, 99]), t.max()))
print("frac within 3.1+-0.1: %.4f ; +-0.2: %.4f ; <2.9: %.4f ; >3.4: %.4f" % (np.mean(abs(t-3.1)<0.1), np.mean(abs(t-3.1)<0.2), np.mean(t<2.9), np.mean(t>3.4)))
print("shell vol", s.volume, "watertight", s.is_watertight)
