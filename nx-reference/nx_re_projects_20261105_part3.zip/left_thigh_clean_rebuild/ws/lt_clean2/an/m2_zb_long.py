import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
os.environ["EXTP"]="work/m2/ext_pts_long.npy"; os.environ["CELLS"]="work/m2/cells_long.npy"
import numpy as np, m2_loft as L, m2_g_fit as G, m2_o_fitband as B, m2_q_env as Q
st=[float(s) for s in sys.argv[1].split(",")]; NP=int(sys.argv[2]); tag=sys.argv[3]
D=Q.shifted_cells(); lf,keep,sr=G.run(st,NP,D=D); np.savez(f"work/m2/loft_{tag}.npz",st=st,P=lf.P)
V,F,ys,u=G.mesh_of(lf,st[0],st[-1]); S=G.scan_pts(60,st[-1]); d=G.dist_to(V,F,S[:,:3]); ib=B.inband(S[:,1],S[:,0],S[:,2],1.0); y=S[:,1]
for lo,hi in ((60,70),(70,100),(100,250),(250,262),(262,275),(275,288)):
    m=(y>=lo)&(y<hi)&~ib
    if m.sum(): f,p90,p50=G.stats(d[m],S[m,3]); print(tag,lo,hi,"%.1f%% p90 %.3f"%(100*f,p90),flush=True)
m=~ib&(y<=250); f,p90,p50=G.stats(d[m],S[m,3]); print(tag,"60-250 outside band %.1f%% p90 %.3f"%(100*f,p90))
m=~ib; f,p90,p50=G.stats(d[m],S[m,3]); print(tag,"60-end outside band %.1f%% p90 %.3f"%(100*f,p90))
