from i2_rows import *
import json
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import ndimage as ndi
F = json.load(open(r"C:\NX_MCP_WORKSPACE\lt_clean2\FEATURES_inn.json"))
cov = np.zeros(N, bool); lab_idx = {}
for r in F:
    idx = np.load(os.path.join(MASKS, f"inn_f_{r['id']}.npy")); lab_idx[r["id"]] = idx
    if r["id"] in ("JOINT_BOSS_FACES", "LIP_FACE") or r["type"] == "root_fillet": continue
    cov[idx] = True
covall = np.zeros(N, bool)
for r in F:
    if r["id"] in ("JOINT_BOSS_FACES", "LIP_FACE"): continue
    covall[lab_idx[r["id"]]] = True
deep = d >= 3.9
print("deep (de>=3.9) area share %.1f%%; p5 in 0.5 on deep: %.1f%% (old %.1f%%)" % (w_area[deep].sum() * 100, w_area[deep & (p5 < .5)].sum() / w_area[deep].sum() * 100, w_area[deep & (old < .5)].sum() / w_area[deep].sum() * 100))
lost = deep & (old < .5) & (p5 >= .5)
print("deep lost (old ok, p5 bad) = %.2f%% of total; covered by feature masks (incl root rows) %.2f%%, by non-root features %.2f%%, uncovered %.2f%%" % (w_area[lost].sum() * 100, w_area[lost & covall].sum() * 100, w_area[lost & cov].sum() * 100, w_area[lost & ~covall].sum() * 100))
bad = deep & (p5 >= .5)
print("deep bad (p5>=.5) = %.2f%%, covered %.2f%%" % (w_area[bad].sum() * 100, w_area[bad & covall].sum() * 100))
# uncovered lost: where (zone type): wall-like (near perimeter) vs other
un = lost & ~covall
x, y, z = c[:, 0], c[:, 1], c[:, 2]
print("uncovered lost by de band:", {f"{lo}-{hi}": round(w_area[un & (d >= lo) & (d < hi)].sum() * 100, 2) for lo, hi in ((3.9, 6), (6, 12), (12, 99))})
# coarse y-bins
for y0 in range(-70, 290, 40):
    s = un & (y >= y0) & (y < y0 + 40); print(f"  y {y0:4d}..{y0+40:4d}: {w_area[s].sum()*100:.2f}%")
# ------- plan plots
def plan(fname, x0, x1, y0, y1, ids=None, s=0.35, label_top=30, title=""):
    fig, ax = plt.subplots(figsize=(13, 13 * (y1 - y0) / (x1 - x0)))
    bg = (x > x0) & (x < x1) & (y > y0) & (y < y1) & (d >= 2.4)
    ax.scatter(x[bg], y[bg], s=0.05, c="#d8d8d8", rasterized=True)
    order = np.argsort([-(len(lab_idx[r["id"]])) for r in F])
    for i in order:
        r = F[i]
        if r["id"] in ("JOINT_BOSS_FACES", "LIP_FACE"): continue
        if ids is not None and r["id"] not in ids: continue
        idx = lab_idx[r["id"]]; idx = idx[(x[idx] > x0) & (x[idx] < x1) & (y[idx] > y0) & (y[idx] < y1)]
        if len(idx) == 0: continue
        sc = ax.scatter(x[idx], y[idx], s=s, c=np.minimum(p5[idx], 2.0), cmap="turbo", vmin=0, vmax=2.0, rasterized=True)
    ax.set_aspect("equal"); ax.set_xlim(x0, x1); ax.set_ylim(y0, y1); ax.grid(alpha=.25)
    cb = plt.colorbar(sc, ax=ax, shrink=0.5); cb.set_label("part 5 deviation, scan -> CAD (mm), clipped at 2")
    Fs = sorted(F, key=lambda r: -(r["points_lost_pct_total"] or 0))
    k = 0
    for r in Fs:
        if r["id"] in ("JOINT_BOSS_FACES", "LIP_FACE"): continue
        if ids is not None and r["id"] not in ids: continue
        idx = lab_idx[r["id"]]
        if len(idx) == 0: continue
        cx, cy = np.median(x[idx]), np.median(y[idx])
        if not (x0 < cx < x1 and y0 < cy < y1): continue
        ax.text(cx, cy, r["id"], fontsize=6.5, color="k", ha="center", va="center", bbox=dict(boxstyle="round,pad=0.12", fc="w", ec="none", alpha=0.65), clip_on=True)
        k += 1
        if k >= label_top: break
    ax.set_title(title or fname)
    plt.tight_layout(); plt.savefig(os.path.join(O, fname), dpi=75); plt.close()
plan("plan_all.png", -72, 125, -72, 292, label_top=40, s=0.12, title="all feature masks coloured by part 5 deviation (labels: top losses)")
plan("plan_knee.png", -72, 100, -72, 100, label_top=60, s=0.3, title="knee zone")
plan("plan_mid.png", -50, 125, 90, 200, label_top=40, s=0.3, title="mid body")
plan("plan_hip.png", -50, 125, 195, 292, label_top=40, s=0.3, title="hip zone")
# bar chart top 30
Fs = sorted(F, key=lambda r: -(r["points_lost_pct_total"] or 0))[:30]
fig, ax = plt.subplots(figsize=(11, 9))
ax.barh([r["id"] for r in Fs][::-1], [r["points_lost_pct_total"] for r in Fs][::-1], color=["#c0392b" if r["cause"] in ("missing", "size", "type", "position", "height") else "#e67e22" for r in Fs][::-1])
ax.set_xlabel("points lost vs old master (% of total inner scan area, net)"); ax.set_title("top 30 features by points lost (red: wrong/missing feature, orange: fillet/draft zone)")
plt.tight_layout(); plt.savefig(os.path.join(O, "top_losses.png"), dpi=75)
