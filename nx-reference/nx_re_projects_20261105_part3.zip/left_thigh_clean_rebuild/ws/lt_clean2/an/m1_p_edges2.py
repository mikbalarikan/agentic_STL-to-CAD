import sys,os,json
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
AX=(0.12,-0.02); Rp,zp,t=68.80,36.85,0.0275
for nm,zr in (("out_scan",(-10.5,35)),("inn_scan",(35.5,80.5))):
    v,f=lib.load(nm,1500000); c,nn,ar=lib.tri_data(v,f)
    x=c[:,0]-AX[0]; y=c[:,1]-AX[1]; r=np.hypot(x,y); ang=np.degrees(np.arctan2(x,-y))
    radial=(x*nn[:,0]+y*nn[:,1])/np.maximum(r,1e-9)
    dev=r-(Rp-np.abs(c[:,2]-zp)*t)
    ok=(radial>0.9)&(np.abs(dev)<0.3)&(c[:,2]>zr[0])&(c[:,2]<zr[1])
    print(nm)
    # +X edge
    for z0 in np.arange(zr[0],zr[1],8):
        k=ok&(c[:,2]>=z0)&(c[:,2]<z0+1)&(ang>30)&(ang<70)
        if k.sum()>5:
            i=np.argsort(ang[k])[-5:]; ids=np.where(k)[0][i]
            print(f" +X edge z~{z0+.5:.1f}: ang max {ang[ids].max():.2f}  x,y = {c[ids,0].mean():.2f},{c[ids,1].mean():.2f} ")
    # -25 edge
    for z0 in (12,20,28) if nm=="out_scan" else (40,48,56):
        k=ok&(c[:,2]>=z0)&(c[:,2]<z0+1)&(ang>-60)&(ang<0)
        i=np.argsort(ang[k])[:5]; ids=np.where(k)[0][i]; print(f" -X free edge z~{z0}: ang min {ang[ids].min():.2f} x,y {c[ids,0].mean():.2f},{c[ids,1].mean():.2f}")
    # window horizontal edge
    k=ok&(ang>-100)&(ang<-35)
    zz=c[k,2]
    if nm=="out_scan": print(' window edge (outer) z max of drum in ang -100..-35:',np.percentile(zz,[99.5,99.9,100]).round(2))
    else: print(' window edge (inner) z min of drum in ang -100..-35:',np.percentile(zz,[0,0.1,0.5]).round(2))
    # smooth departure at -X: angle where dev>0.1,0.3,1.0 per z (using section points)
    s0=[]
    for z in np.arange(zr[0]+1,zr[1]-1,2):
        if nm=="out_scan" and z>7: continue
        if nm=="inn_scan" and z<63: continue
        sec=lib.section(v,f,2,z).reshape(-1,3); X=sec[:,0]-AX[0]; Y=sec[:,1]-AX[1]; R=np.hypot(X,Y); A=np.degrees(np.arctan2(X,-Y)); D=R-(Rp-abs(z-zp)*t)
        m=(R>60)&(R<80)&(A<-90)&(A>-175)
        o=np.argsort(A[m]); a=A[m][o]; d=D[m][o]
        # walking from -100 toward -175: first angle where d>thr (monotone departure)
        res=[]
        for thr in (0.1,0.3,1.0):
            j=np.where((d>thr)&(a<-105))[0]
            res.append(round(float(a[j].max()),1) if len(j) else None)
        print(f" -X departure z={z:.0f}: ang at dev>0.1/0.3/1.0:",res)
