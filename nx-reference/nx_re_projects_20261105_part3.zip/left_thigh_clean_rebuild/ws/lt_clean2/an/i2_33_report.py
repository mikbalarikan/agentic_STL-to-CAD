import json, os
from collections import Counter
F = json.load(open(r"C:\NX_MCP_WORKSPACE\lt_clean2\FEATURES_inn.json"))
U = json.load(open(r"C:\NX_MCP_WORKSPACE\lt_clean2\work\i2\uncovered_lost_clusters.json"))
O = r"C:\NX_MCP_WORKSPACE\lt_clean2\work\i2"


def short(p, n=110):
    if p is None: return ""
    s = json.dumps(p, separators=(",", ":")) if not isinstance(p, str) else p
    return s if len(s) <= n else s[:n - 1] + "~"


def keyparams(r):
    p = r["params"]; t = r["type"]
    g = lambda k, d=2: (round(p[k], d) if isinstance(p.get(k), (int, float)) else p.get(k))
    if t == "boss_col": return f"D {g('D')}, c ({p['centre'][0]:.2f},{p['centre'][1]:.2f}), face z {g('face_z')}"
    if t == "pocket": return f"D {g('D')}, taper {g('taper_deg',1)} deg, floor z {g('floor_z')}"
    if t == "bore_cbore": return f"bore D {g('bore_D')}, cbore D {g('cbore_D')}, cbore floor z {g('cbore_floor_z')}"
    if t in ("rib", "gusset", "arm", "flange", "run_rib", "cap_rib"):
        e = p.get("edge") or {}; k = e.get("kind")
        es = {"flat": f"flat z {e.get('z')}", "line": "line", "flat-ramp-flat": f"ramp {e.get('z_low')}->{e.get('z_high')} ({e.get('ramp_angle_deg')} deg)"}.get(k, k)
        return f"t {g('t')}, L {g('length',1)}, edge {es}"
    if t == "pin": return f"D {g('D')}, tip {g('tip_z')}, root {g('root_z')}, len {g('length')}"
    if t == "lug_hole": return f"lug D {g('lug_D')}, hole D {g('hole_D')}, face z {g('face_z')}"
    if t == "hole_boss": return f"c ({p['centre'][0]:.2f},{p['centre'][1]:.2f}), hole D {g('hole_D')}, end z {g('hole_end_z')}"
    if t == "spoke": return f"angle {g('angle_deg')}, t {g('t')}"
    if t == "ring_rib": return f"centre r {g('centre_r')}, t {g('t')}, free z {g('free_z')}"
    if t == "root_fillet": return f"R {g('R_clean',1)} (clean fit only)"
    return short({k: v for k, v in p.items() if k not in ("edge_table",)}, 100)


top = F[:10]
cnt = Counter(r["type"] for r in F)
miss = [r for r in F if r["id"].startswith("MISS_")]
bad = [r for r in F if (r["part5_p90"] or 0) > 0.5]
L = []
A = L.append
A("# I2 report: inner shell LT-INN-001, interior / small-feature inventory (2026-10-31)")
A("")
A("Scripts: `an/i2_*.py` (run order i2_10 .. i2_19, i2_17, i2_18, i2_18b, i2_30 collect, i2_31 plots, i2_32 uncovered, i2_33 report). Masks: `work/masks/inn_f_<ID>.npy` (indices into `lib.load('inn_scan',1500000)`). Data: `FEATURES_inn.json` (%d rows)." % len(F))
A("Deviation = scan -> CAD triangle-centre distance (arrays `dev_FINinn` = part 5, `dev_oldInnB` = old master). p90 is area-unweighted over the mask triangles. `points_lost` = (area of mask where old <0.5 and part 5 >=0.5) minus (area where part 5 <0.5 and old >=0.5), in percent of the total scan area; masks overlap a little at junctions, so the column does not add up exactly.")
A("")
A("## Summary")
A("- Rows: %d (%s)." % (len(F), ", ".join(f"{k} {v}" for k, v in sorted(cnt.items(), key=lambda kv: -kv[1]))))
A("- Rows with part 5 p90 > 0.5 mm inside their own scan mask: **%d of %d**; by cause: %s." % (len(bad), len(F), ", ".join(f"{k} {v}" for k, v in Counter(r['cause'] for r in bad).most_common())))
A("- Reproduced the loss: deep zone (scan > 3.9 mm inside the envelope) is 32.2 % of the scan area; within 0.5 mm: old 79.5 %, part 5 59.9 %. Of the 7.27 % of the total scan area that went old-good to part-5-bad in that zone, the feature masks hold 5.7 % (5.5 % outside the root-blend rows). The remaining ~1.6 % sits in wall zones, see 'Not feature items' below.")
A("- The loss is concentrated in a few wrong or missing features, not spread over the table: HIP_WEB, MISS_B1_EAR, MISS_ARC_RIB, I_DIAG, the two hip side blocks, ARM_B2_D zone, the channel run (ribs, floor) and the hip/I_LONG_HIP ribs. Screw boss columns (D 15.1, centres exact), pockets, bore/counterbores, pins, pin lugs, hub bore and screw holes, channel ring ribs and spokes are within 0.1-0.2 mm of part 5 (p90 0.14-0.66, i.e. blend and draft level); the exceptions are the B6/B7 columns (caused by the hip block), B1 (ear), channel holes H6 (4.3 mm off in X) and H7 (end level), the B7 cbore mouth, the outer spokes at 108 and 327 deg (arm/ear junctions), and P1/P2 lug D 9.3 (part 5 9.0).")
A("- The scan shows ramped free edges (inclined plane + flat) on I_DIAG, I_LONG_HIP, both channel run ribs and the run floor, steeper gussets than part 5, and a large root blend on I_LONG_HIP; part 5 modelled all of them as one flat level.")
A("")
A("Images: `plan_all.png`, `plan_knee.png`, `plan_mid.png`, `plan_hip.png` (feature masks coloured by part 5 deviation, labels = highest losses), `top_losses.png`, `overview.png`, `zoom_*_dev.png`, section plots `sec_*`, `run_secs.png`, `hip_secs*.png`, `b1_secs.png`, `b2_secs.png`, `pk_secs.png`, `fillet_check.png`.")
A("")
A("![plan](plan_all.png)")
A("")
A("![top losses](top_losses.png)")
A("")
A("## Top 10 by points lost")
A("| # | id | type | lost (% total) | part 5 p90 | old p90 | cause | what is wrong (measured) |")
A("|--|--|--|--|--|--|--|--|")
for i, r in enumerate(top, 1):
    A(f"| {i} | {r['id']} | {r['type']} | {r['points_lost_pct_total']:+.2f} | {r['part5_p90']} | {r['old_p90']} | {r['cause']} | {r['diagnosis']} |")
A("")
A("## Missing features (not in part 5's tables)")
for r in miss:
    A(f"- **{r['id']}**: {r['diagnosis']}  Fix: {r['recommendation']}")
A("")
A("## Not feature items (wall / envelope zone, other analysts)")
A("Uncovered 'old good, part 5 bad' clusters in the deep zone after all rows (percent of total scan area):")
A("| area % | x | y | z | part 5 p90 | old p90 | kind |")
A("|--|--|--|--|--|--|--|")
for u in U[:8]:
    A(f"| {u['area_pct']} | {u['x'][0]}..{u['x'][1]} | {u['y'][0]}..{u['y'][1]} | {u['z'][0]}..{u['z'][1]} | {u['p5_p90']} | {u['old_p90']} | {u['kind']} |")
A("These are the +X wall (x 67..81, y -18..20: wall inner face sloped, see the +X band), the wall next to the P3 lug and the left knee wedge (x -42..-25, y 50..64 and 251..266): wall thickness / draft, not ribs or bosses.")
A("")
A("## Traced-outline risks and the clean primitive instead")
A("- MISS_B1_EAR / B1 zone: the only 'fit' from the deviation map is the lobe outline. Clean primitive: hull of the column circle (D 15.2 at 61.2,-40.2) and two tangent lines to the drum wall, extruded up to the envelope.")
A("- MISS_B2_DOME: the thick-wall pocket ceiling would be a traced terrace. Clean primitive: one domed (revolved or ellipsoid) pocket cut, or an offset-surface thickening of that skin patch; crest z ~64.5 at (70,45), rising to 75 at y 58 (needs one more measurement round before NX).")
A("- Channel floor (ring and run): flat plate + fillets would be a patchwork; the scan floor is one cylindrical arch R~8.4 (ring: centre r 38.47, crest 77.07) with the same inclined ramp plane at the top of the run.")
A("- Ramps (I_DIAG, I_LONG_HIP, channel run, hip gussets): one inclined plane cut each (angle + two levels from the edge tables), never a stepped terrace.")
A("- Arc rib: one 3-point arc (R100.8), not a spline through measured points.")
A("- Root blends: one measured-radius face blend per rib (I_LONG_HIP ~R7 on the -X side; ring ribs R~2.7-5.7 vs R3.0 in part 5); fit radii are only trusted where the rms < 0.3 mm (see `root_fillet` rows).")
A("")
A("## Checked and fine (part 5 p90 <= 0.5, nothing to change)")
ok = [r["id"] for r in F if r["cause"] == "ok" and r["type"] != "root_fillet"]
A(", ".join(ok))
A("")
A("## Full table, ordered by points lost")
A("| id | type | measured (key params) | part 5 | old p90 | p5 p90 | in 0.5 % (p5) | lost % | tris | cause | diagnosis |")
A("|--|--|--|--|--|--|--|--|--|--|--|")
for r in F:
    A(f"| {r['id']} | {r['type']} | {keyparams(r)} | {short(r['part5_value'],70)} | {r['old_p90']} | {r['part5_p90']} | {r['part5_in05_pct']} | {r['points_lost_pct_total']:+.3f} | {r['n_tris']} | {r['cause']} | {r['diagnosis'][:230]} |")
A("")
A("## Method notes and caveats")
A("- Scan: `lib.load('inn_scan',1500000)` (decimated, triangle centres are sparse: wall positions need 100+ triangles per fit, all fits report n and rms). Interior = distance to `env_part5.stl` >= 2 mm.")
A("- Primitive fits: circle fits (Kasa + Gauss-Newton) for cylinders; rib side walls from normals across the rib, iterative centre-line re-alignment; free edges from the lower envelope of down-facing triangles per 2-4 mm bin, described as flat / ramp+flat from a clamped-ramp least squares (`edge_pw`). Levels by 0.1 mm histogram + median.")
A("- Boss column Ø is taken from the 20th percentile of 15-degree sector radii (arms and root blends only add); the pocket wall is tapered ~2 deg in the scan (narrows upward), a draft not in part 5 but small (p90 pocket rows <= 0.57).")
A("- `hole_boss` end levels follow the skin (z 80.2 .. 91.7), the part 5 fixed depth 6.0 is wrong on H2..H8; positions of H1..H5, H7, H8 are within 0.1 of part 5, H6 is 4.3 mm off.")
A("- Seams: groove depth ~0.8 (part 5 0.62), width unresolved on the 1.5 M-triangle decimation; rows are for completeness.")
A("- Not measured / dropped: CH_CAP_RING (no separate cap rib found at 75 deg: the C ends open with a notch), screw-hole threads, hub screw bosses on the outside.")
open(os.path.join(O, "REPORT.md"), "w", encoding="utf-8").write("\n".join(L))
print("written", len(L), "lines")
