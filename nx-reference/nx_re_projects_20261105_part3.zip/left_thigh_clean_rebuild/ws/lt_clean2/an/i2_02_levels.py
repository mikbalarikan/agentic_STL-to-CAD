from i2_common import *
v,f,c,n,a = scan(); d = de()
h = (np.abs(n[:,2])>0.97)&(d>1.5)
print("horiz interior tris",h.sum(), "area",a[h].sum())
z=c[h,2]; ww=a[h]
hist,ed=np.histogram(z,bins=np.arange(30,115,0.2),weights=ww)
# peaks
from scipy.signal import find_peaks
pk,_=find_peaks(hist,height=hist.max()*0.01,distance=3)
for i in pk: print(f"z {ed[i]:.1f} area {hist[i]:.0f} (signs: nz<0 {a[h][(c[h,2]>ed[i])&(c[h,2]<ed[i]+.2)&(n[h,2]<0)].sum():.0f})")
