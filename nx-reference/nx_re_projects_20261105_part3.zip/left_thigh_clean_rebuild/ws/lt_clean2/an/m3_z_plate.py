import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
HX,HZ=37.97,35.18
for tag,sn,cn,zs in (('out','out_scan','out_cad',lambda z:z<34.5),('inn','inn_scan','inn_cad',lambda z:z>35.9)):
  for nm,(v,f) in (('scan',lib.load(sn,1500000)),('old',lib.load(cn))):
    c,nn,a=lib.tri_data(v,f)
    m=(c[:,1]>255)&(abs(nn[:,1])>0.985)&zs(c[:,2])
    y=c[m,1]; w=a[m]
    h,e=np.histogram(y,bins=np.arange(255,289,0.1),weights=w)
    pk=[(e[i]+0.05,h[i]) for i in range(1,len(h)-1) if h[i]>40 and h[i]>=h[i-1] and h[i]>=h[i+1]]
    print(tag,nm,'planar +-Y faces (Y, area/0.1mm bin):',[(round(p,2),int(a_)) for p,a_ in pk])
