import numpy as np, trimesh
G={"TG1 MX body":lambda c:(c[:,0]<-10)&(c[:,1]<200),"TG3 MX hip":lambda c:(c[:,0]<10)&(c[:,1]>200),"TG2 PX knee":lambda c:(c[:,0]>55)&(c[:,1]<80),"TG4 PX hip":lambda c:(c[:,0]>70)&(c[:,1]>200)}
res={}
for w,z,nz in (("out",36.05,1),("inn",36.08,-1)):
    m=trimesh.load(f"nx/A_v2/{w}_A.stl"); tc=m.triangles_center; n=m.face_normals
    k=(np.abs(tc[:,2]-z)<0.02)&(n[:,2]*nz>0.999); c=tc[k]
    res[w]={g:(round(float(c[f(c),1].min()),2),round(float(c[f(c),1].max()),2)) for g,f in G.items() if f(c).any()}
    print(w,"flat face y-extent (triangle centres):",res[w])
for g in res["out"]:
    a=res["out"][g]; b=res["inn"].get(g)
    if b: print(g,"rebate - tongue: start %+.2f end %+.2f"%(a[0]-b[0], b[1]-a[1]))
