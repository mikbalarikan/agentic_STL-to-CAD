import time
from s1_geo import *
d=np.load('work/s1/loft_K1.npz'); st=d['st']; P=d['P']
t=time.time(); s=loft(P,st); print('loft',time.time()-t, valid(s), volume(s))
dr=drum(); print('drum',valid(dr),volume(dr))
t=time.time(); u=fuse(s,dr); print('fuse',time.time()-t,valid(u),volume(u))
t=time.time(); V,F=to_mesh(u,0.05); print('mesh',time.time()-t,len(F))
import trimesh; m=trimesh.Trimesh(V,F); print(m.is_watertight, m.volume)
m.export('work/s1/t1.stl')
