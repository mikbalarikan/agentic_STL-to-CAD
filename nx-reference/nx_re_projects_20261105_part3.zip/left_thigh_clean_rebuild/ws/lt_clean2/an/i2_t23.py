from i2_rows import *
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\ref5\nx")
import design as DS
def fillet_R(p0,p1,t,u0f=0.3,u1f=0.7,zlo=None,wmax=9.0,nzr=(-0.985,-0.1)):
    u,wv,nu,nw,L,e=line_frame(p0,p1); hw=t/2
    res=[]
    for sgn in (-1,1):
        ww=sgn*wv
        q=(ww>hw+0.05)&(ww<hw+wmax)&(u>u0f*L)&(u<u1f*L)&(n[:,2]>nzr[0])&(n[:,2]<nzr[1])&(d>=2.0)&(c[:,2]>(zlo if zlo else 40))
        P=np.c_[ww[q]-hw,c[q,2]]
        if len(P)>80:
            cx,cz,R,rms=circle_fit(P); res.append((sgn,round(R,2),round(rms,3),len(P),round(cx,2),round(cz,2)))
    return res
p0,p1=(38.0,170.0),(38.0,260.0)
print("I_LONG_HIP",fillet_R(p0,p1,3.22,0.35,0.9,zlo=88))
# knee spoke / ring: use floor 80 flat: circle fit around ring outer rib faces (radial coordinate) at disc floor
r0=np.hypot(c[:,0],c[:,1]); th0=np.degrees(np.arctan2(c[:,1],c[:,0]))%360
for nm,(rface,sgn) in {"ring_in inner face r32.26":(32.26,-1),"ring_in outer face 34.85":(34.85,1),"ring_out inner 42.33":(42.33,-1),"ring_out outer 44.70":(44.70,1)}.items():
    off=sgn*(r0-rface)
    q=(off>0.05)&(off<8)&(th0>130)&(th0<300)&(n[:,2]<-0.1)&(n[:,2]>-0.985)&(c[:,2]>75.3)&(d>=2.0)
    # only tris on the side that opens to the DISC (z up to 80) for outer faces, floor 76.9 for inner faces
    P=np.c_[off[q],c[q,2]]
    if len(P)>80:
        cx,cz,R,rms=circle_fit(P); print(nm,"R",round(R,2),"rms",round(rms,3),"n",len(P),"centre off,z",round(cx,2),round(cz,2))
