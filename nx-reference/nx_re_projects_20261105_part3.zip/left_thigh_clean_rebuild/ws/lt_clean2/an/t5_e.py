import sys; sys.path.insert(0,'an')
import numpy as np, trimesh
from scipy.optimize import least_squares
exec(open('an/t5_d.py').read().split("P=get(10.5,60)")[0])
P=get(10.5,60)
env=trimesh.load("nx/base_v2/envelope.stl")
# envelope exterior samples near junction, outside drum
S,fi=trimesh.sample.sample_surface(env,600000,seed=1); N=env.face_normals[fi]
ok=(S[:,0]>55)&(S[:,1]>-38.5)&(S[:,1]<-30)&(S[:,2]>10.5)&(S[:,2]<60)&(N[:,0]>0.4)
E=S[ok]; print("env samples",len(E))
def mod(q,P):
    x0,y0,rho0,Rv,zc=q
    rho=np.hypot(P[:,0]-x0,P[:,1]-y0)
    return rho-(rho0-(Rv-np.sqrt(Rv**2-(P[:,2]-zc)**2)))
def stats(r): return "p50 %.3f p90 %.3f max %.3f"%(np.median(abs(r)),np.percentile(abs(r),90),abs(r).max())
for t in (0,20,30,45):
    d=np.array([-31.6,17.0])/np.hypot(-31.6,17.0); c0=d*t
    m=lambda q: np.r_[mod(np.r_[c0,q],P)]
    s=least_squares(m,[80+t*0.9,260,35.4],loss='soft_l1',f_scale=0.1)
    q=np.r_[c0,s.x]
    print("t",t,"tail scan:",stats(mod(q,P)),"| env junction:",stats(mod(q,E)), "mean env signed %.3f"%mod(q,E).mean())
    # joint fit scan + env
    w=0.5
    m2=lambda qq: np.r_[mod(np.r_[c0,qq],P), w*mod(np.r_[c0,qq],E[::max(1,len(E)//len(P))])]
    s2=least_squares(m2,s.x,loss='soft_l1',f_scale=0.1); q2=np.r_[c0,s2.x]
    print("    joint:",np.round(q2,2),"scan",stats(mod(q2,P)),"env",stats(mod(q2,E)))
