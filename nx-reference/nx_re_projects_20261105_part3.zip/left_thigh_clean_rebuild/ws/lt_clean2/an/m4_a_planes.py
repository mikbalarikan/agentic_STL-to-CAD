"""M4 step 1: connected near-horizontal patches in the joint band, plane fit per patch."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
OUT = os.path.join(lib.W, "m4")

def patches(v, f, c, nn, a, sgn, zlo=30, zhi=42, nzmin=0.97):
    m = np.where((nn[:, 2] * sgn > nzmin) & (c[:, 2] > zlo) & (c[:, 2] < zhi))[0]
    # adjacency via shared vertices
    vi = f[m]
    n = len(m)
    rows = np.repeat(np.arange(n), 3); cols = vi.ravel()
    A = coo_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, v.shape[0])).tocsr()
    G = A @ A.T
    nc, lab = connected_components(G, directed=False)
    return m, lab, nc

def fit_plane(P):
    cen = P.mean(0)
    u, s, vt = np.linalg.svd(P - cen, full_matrices=False)
    nrm = vt[2]
    if nrm[2] < 0: nrm = -nrm
    res = (P - cen) @ nrm
    return cen, nrm, res

if __name__ == "__main__":
    allr = {}
    for scan in ("out_scan", "inn_scan"):
        v, f = lib.load(scan, 1500000); c, nn, a = lib.tri_data(v, f)
        rows = []
        for sgn in (1, -1):
            m, lab, nc = patches(v, f, c, nn, a, sgn)
            for k in range(nc):
                idx = m[lab == k]; ar = a[idx].sum()
                if ar < 8: continue
                P = v[np.unique(f[idx])]
                cen, nrm, res = fit_plane(P)
                tilt = np.degrees(np.arccos(min(1, abs(nrm[2]))))
                rows.append(dict(sgn=sgn, k=int(k), n=int(len(idx)), area=float(ar), z=float(cen[2]), zmin=float(P[:, 2].min()), zmax=float(P[:, 2].max()),
                                 tilt=float(tilt), rms=float(res.std()), x0=float(P[:,0].min()), x1=float(P[:,0].max()), y0=float(P[:,1].min()), y1=float(P[:,1].max())))
        rows.sort(key=lambda r: (r['sgn'], r['z']))
        print(scan)
        for r in rows: print("  s%+d n%6d A%7.1f z%7.3f [%6.2f,%6.2f] tilt%5.2f rms%.3f  X[%6.1f,%6.1f] Y[%6.1f,%6.1f]" % (r['sgn'], r['n'], r['area'], r['z'], r['zmin'], r['zmax'], r['tilt'], r['rms'], r['x0'], r['x1'], r['y0'], r['y1']))
        allr[scan] = rows
    json.dump(allr, open(os.path.join(OUT, "patches.json"), "w"), indent=1)
