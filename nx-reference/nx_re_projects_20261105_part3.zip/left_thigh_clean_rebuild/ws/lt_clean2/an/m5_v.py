import sys, os, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean2\an")
import lib, scipy.spatial as sp
from scipy.ndimage import gaussian_filter
import m5_r as R
key,scan,dn,tt,sg="out","out_scan","FINout",1.9,-1
v,fa=lib.load(scan,1500000); c,nn,ar=lib.tri_data(v,fa); w=ar/ar.sum()
st=np.load(os.path.join(lib.W,f"dev_{dn}.npz"))["d1"]
band=np.zeros(len(c),bool); band[np.load(os.path.join(lib.W,"masks",f"{key}_band.npy"))]=1
z=np.load(os.path.join(lib.W,"m5","out_cp.npz")); dot=z["dot"]; dd=z["d"]
P=np.load(os.path.join(lib.W,"m5","out_p5pts.npz"))["pts"]
loc=(P[:,0]>40)&(P[:,1]>95)&(P[:,1]<215)
pts=P[loc]; print("local pts",len(pts),flush=True)
D=dict(pts=pts)
import open3d as o3d
r=R.esc.compute_closest_points(o3d.core.Tensor(pts.astype(np.float32))); cp=r["points"].numpy(); depth=np.linalg.norm(cp-pts,axis=1)
D.update(cp=cp,depth=depth)
# dome field from scan skin
th=-np.degrees(np.arctan2(c[:,2]-35.18,c[:,0]-37.97))
m=(dot>0.9)&(dd<4)&(c[:,0]>60)&(c[:,1]>95)&(c[:,1]<215)&(th>-5)&(th<60)
ys=np.arange(95,215,4.0); ts=np.arange(-4,60,2.0)
S=np.zeros((len(ys),len(ts)))
for i,y0 in enumerate(ys):
    for j,t0 in enumerate(ts):
        k=m&(c[:,1]>=y0)&(c[:,1]<y0+4)&(th>=t0)&(th<t0+2)
        S[i,j]=np.median(dd[k]) if k.sum()>5 else 0.0
S=np.where(S<0.25,0,S)
from scipy.interpolate import RegularGridInterpolator
Sf=RegularGridInterpolator((ys+2,ts+1),gaussian_filter(S,1.0),bounds_error=False,fill_value=0)
print("dome max",S.max(),flush=True)
# models
tb=R.tbf(R.AN)
thp=np.degrees(np.arctan2(pts[:,2]-35.18,pts[:,0]-37.97))*sg
s=Sf(np.stack([pts[:,1],thp],1)); 
newp,mv=R.model(D,tt,R.AN,sg)   # panel only
# panel+dome: start from panel-moved pts; exterior pts (depth<0.6) shift by s; inner-unmoved (2.6-3.7 & not panel) shift s; panel-moved points depth s+tt
nd=newp.copy()
n_=len(pts)
cpn=cp; u=cpn-pts; un=u/np.maximum(np.linalg.norm(u,axis=1,keepdims=True),1e-9)
ext=(depth<0.6)&(pts[:,0]>60)
inn=(depth>2.6)&(depth<3.7)&(pts[:,0]>40)
base=pts.copy()
nd[:n_][ext]=pts[ext]+(-un[ext])*0   # placeholder
# exterior: points on env => move inward along -outward: cp - un*s  (un points from pt to cp, ~0 length for ext) -> use env normal approximation via cp-pts unreliable; use radial from hip axis
rad=np.stack([pts[:,0]-37.97,np.zeros(len(pts)),pts[:,2]-35.18],1); rad/=np.linalg.norm(rad,axis=1,keepdims=True)
nd[:n_]=newp[:n_]
nd[:n_][ext]=pts[ext]-rad[ext]*s[ext,None]
mvi=inn&~mv
nd[:n_][mvi]=pts[mvi]-rad[mvi]*s[mvi,None]
nd[:n_][mv]=newp[:n_][mv]-rad[mv]*s[mv,None]
nd=np.vstack([nd[:n_],newp[n_:]])   # step wall pts unchanged (approx)
sel=(c[:,0]>60)&(c[:,1]>105)&(c[:,1]<205)
ci=np.where(sel)[0]
res={}
for nm,PP in (("p5",pts),("panel",newp),("panel+dome",nd)):
    dm,_=sp.cKDTree(PP).query(c[ci],workers=-1); res[nm]=dm
    print(nm,"region(x>60,y105-205) all ok%",round(w[ci][dm<.5].sum()/w[ci].sum()*100,1),"band ok%",round(w[ci][band[ci]&(dm<.5)].sum()/w[ci][band[ci]].sum()*100,1),"nonband ok%",round(w[ci][(~band[ci])&(dm<.5)].sum()/w[ci][~band[ci]].sum()*100,1),flush=True)
