import sys, numpy as np, trimesh
sys.path.insert(0,'an'); import lib
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
which, stl, ycut, x0, x1, out = sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4]), float(sys.argv[5]), sys.argv[6]
zlo, zhi = float(sys.argv[7]), float(sys.argv[8])
v, f = lib.load({"out":"out_scan","inn":"inn_scan"}[which], 1500000)
cad = trimesh.load(stl, process=False)
fig, ax = plt.subplots(figsize=(12,6))
for nm, (vv, ff), col in (("scan",(v,f),'k'),("cad",(cad.vertices, cad.faces),'r')):
    m = trimesh.Trimesh(np.asarray(vv), np.asarray(ff), process=False)
    s = m.section(plane_origin=[0,ycut,0], plane_normal=[0,1,0])
    if s is None: continue
    for e in s.entities:
        p = s.vertices[e.points]
        ax.plot(p[:,0], p[:,2], col, lw=1 if nm=='cad' else 0.6, label=nm)
ax.set_xlim(x0,x1); ax.set_ylim(zlo,zhi); ax.set_aspect('equal'); ax.grid(True); ax.set_title(f'{which} y={ycut}')
h,l = ax.get_legend_handles_labels(); ax.legend(dict(zip(l,h)).values(), dict(zip(l,h)).keys())
plt.savefig(out, dpi=90)
