import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
Z=np.load("work/m3/polar_ref.npz"); ys=Z['ys']; NB=720
D=np.load("work/m3/ext_pts.npz"); P=D['P']; r=D['r']; th=D['th']
def fill(a):
    a=a.copy(); x=np.arange(NB)
    for i in range(len(a)):
        g=~np.isnan(a[i]); 
        if g.sum()>10: a[i]=np.interp(x,x[g],a[i][g],period=NB)
    return a
E=fill(Z['env5']); OC=fill(Z['out_cad']); IC=fill(Z['inn_cad'])
angs=[-175,-150,-120,-90,-60,-30,-8,8,30,60,90,120,150,175]
fig,ax=plt.subplots(3,5,figsize=(30,16))
for a,t in zip(ax.flat,angs):
    b=int((t+180)/360*NB)
    k=abs(th-t)<1.5
    a.plot(P[k,1],r[k],'k.',ms=1,alpha=.5)
    a.plot(ys,E[:,b],'g-',lw=1.5,label='part5 env')
    a.plot(ys,(OC if t<0 or True else IC)[:,b],'r-',lw=.8,label='old out' ); a.plot(ys,IC[:,b],'m-',lw=.8,label='old inn')
    a.set_xlim(215,290); a.set_ylim(66,85); a.grid(True); a.set_title(f"theta {t}")
ax.flat[0].legend()
plt.tight_layout(); plt.savefig("work/m3/ry_cmp.png",dpi=45)
