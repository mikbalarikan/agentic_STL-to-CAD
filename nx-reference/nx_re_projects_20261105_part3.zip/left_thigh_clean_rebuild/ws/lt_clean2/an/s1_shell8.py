import sys
from s1_shell import *
from s1_geo import *
from s1_build import cone_solid
def test(shape,name,mf,t=3.1,jn=GeomAbs_Arc):
    lst=TopTools_ListOfShape(); lst.Append(mf); mk=BRepOffsetAPI_MakeThickSolid(); t0=time.time()
    try:
        mk.MakeThickSolidByJoin(shape,lst,-t,1e-3,BRepOffset_Skin,True,False,jn); mk.Build()
    except Exception as e: print(name,'EXC',str(e)[:80]); return
    s=mk.Shape() if mk.IsDone() else None
    print(name,t,'done',mk.IsDone(),'valid',valid(s) if s else None,'vol',round(volume(s)) if s else None,'orig',round(volume(shape)),round(time.time()-t0,1),flush=True)
def capf(shape,Y):
    for f in faces(shape):
        a=BRepAdaptor_Surface(f)
        if a.GetType()==GeomAbs_Plane and abs(a.Plane().Location().Y()-Y)<1e-3 and abs(a.Plane().Axis().Direction().Y())>0.99: return f
# 1) K1 union
d=np.load('work/s1/loft_K1.npz'); lo=loft(d['P'],d['st']); u=fuse(lo,drum()); print('K1 fuse valid',valid(u),round(volume(u)))
test(u,'K1 loft+drum',capf(u,262.0))
# 2) drum + simple fairing: cylinder block union? use H7 loft truncated: loft from index 3 (Y -11) to 62 only
d=np.load('work/s1/loft_H7.npz'); st=d['st']; P=d['P']
for i0,i1 in [(3,12),(0,12),(5,14)]:
    lo=loft(P[i0:i1],st[i0:i1]); u=fuse(lo,drum()); print('H7 stations',st[i0],st[i1-1],'fuse valid',valid(u),round(volume(u)))
    test(u,f'H7 loft {st[i0]}..{st[i1-1]} + drum',capf(u,st[i1-1]))
