"""sections: scan exterior pts + envelope. usage s1_secs.py tag y1,y2,... [xlim x0,x1 zlim z0,z1] out"""
import sys
from s1_eval import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import trimesh
tag=sys.argv[1]; Ys=[float(a) for a in sys.argv[2].split(',')]; out=sys.argv[3]
m=trimesh.load(os.path.join(S1,f'env_{tag}.stl'),process=False); v,f=np.asarray(m.vertices),np.asarray(m.faces)
n=len(Ys); cols=min(n,4); rows=(n+cols-1)//cols
fig,axs=plt.subplots(rows,cols,figsize=(7*cols,6.5*rows)); axs=np.atleast_1d(axs).ravel()
for ax,Y in zip(axs,Ys):
    q=P[np.abs(y-Y)<=0.5]; ax.plot(q[:,0],q[:,2],'k.',ms=1.5)
    for s_ in lib.section(v,f,1,Y): ax.plot(s_[:,0],s_[:,2],'r-',lw=0.9)
    ax.set_aspect('equal'); ax.set_title(f'Y={Y}'); ax.grid(True)
    if len(sys.argv)>4:
        xl=[float(a) for a in sys.argv[4].split(',')]; zl=[float(a) for a in sys.argv[5].split(',')]; ax.set_xlim(*xl); ax.set_ylim(*zl)
plt.tight_layout(); plt.savefig(os.path.join(S1,out),dpi=40)
