from i1_core import *
hx,hz=37.97,35.18
rr=np.hypot(c[:,0]-hx,c[:,2]-hz); phi=np.degrees(np.arctan2(c[:,2]-hz,c[:,0]-hx))%360
nr=((c[:,0]-hx)*n[:,0]+(c[:,2]-hz)*n[:,2])/np.maximum(rr,1e-6)
m=(c[:,1]>267.5)&(c[:,1]<272.4)&(abs(n[:,1])<0.3)&(rr>43)&(rr<48.3)
print(m.sum())
ph=np.sort(phi[m]); gaps=np.where(np.diff(ph)>3)[0]
print("clusters",len(gaps)+1)
edges=np.r_[0,gaps+1,len(ph)]
cl=[ph[edges[i]:edges[i+1]] for i in range(len(edges)-1)]
print([round(float(np.mean(q)),1) for q in cl])
# fit hole circles in (x,z)
res=[]
for q in cl:
    k=m&(phi>=q.min()-0.01)&(phi<=q.max()+0.01)
    if k.sum()<20: continue
    cx,cz,R,rs,nn=circle_fit_robust(c[k,0],c[k,2]); res.append((cx,cz,2*R,rs,nn))
R=np.array(res); print(len(R)); 
rc=np.hypot(R[:,0]-hx,R[:,1]-hz); print("PCD",2*rc.mean(),"D",R[:,2].mean(),R[:,2].std(),"scatter",rc.std())
ang=np.degrees(np.arctan2(R[:,1]-hz,R[:,0]-hx))%(360/26); print("phase",np.median(ang), ang.std())
