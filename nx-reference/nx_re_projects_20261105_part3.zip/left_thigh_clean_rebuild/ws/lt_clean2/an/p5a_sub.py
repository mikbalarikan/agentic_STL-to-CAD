import sys, numpy as np
sys.path.insert(0,'an')
import lib
def run(which, tag, mask, sel, label):
    v,f = lib.load({'out':'out_scan','inn':'inn_scan'}[which],1500000)
    c,nn,ar = lib.tri_data(v,f)
    d = np.load('work/dev_%s_%s.npz'%(tag,which))['d1']
    m = np.load('work/masks/%s_f_%s.npy'%(which,mask)); cm=c[m]; dm=d[m]
    s = sel(cm)
    print('%-18s %-34s n %5d/%5d p90 %.2f (all %.2f)'%(mask,label,s.sum(),len(m),np.percentile(dm[s],90),np.percentile(dm,90)))
r=lambda c: np.hypot(c[:,0],c[:,1])
run('inn','p5ainnx','SPOKE_OUT_327',lambda c: r(c)<56,'r<56 (before the B1 lobe)')
run('inn','p5ainnx','SPOKE_OUT_161',lambda c: r(c)<55,'r<55')
run('inn','p5ainnx','CH_RING_OUT',lambda c: c[:,2]<76,'z<76 (rib flank, no disc root)')
run('inn','p5ainnx','SPOKE_IN_227',lambda c: r(c)>22,'r>22 (outside the hub)')
run('out','p5aoutx','HIP_PLATE',lambda c: (c[:,1]>267.0),'y>267 (not the wall roots)')
run('out','p5aoutx','COVERPIN_N1',lambda c: (np.hypot(c[:,0]+30.9,c[:,1]+51.4)<6),'within 6 of the pin axis')
run('out','p5aoutx','COVERPIN_N2',lambda c: (np.hypot(c[:,0]+56.7,c[:,1]-19.5)<6),'within 6 of the pin axis')
run('out','p5aoutx','KNEE_SIDE_OPENING',lambda c: (c[:,2]>7.0),'z>7 (cut top + wall end faces)')
