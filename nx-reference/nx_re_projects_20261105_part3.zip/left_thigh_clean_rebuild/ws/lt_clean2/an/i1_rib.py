from i1_common import *
from i1_fit import *
import numpy as np

BOSS_XY = {"B1": (61.35, -40.01), "B2": (75.85, 29.86), "B3": (-25.10, 77.45), "B4": (-17.05, 165.91),
           "B5": (86.45, 165.96), "B6": (97.95, 264.95), "B7": (-22.00, 264.93)}
PIN_XY = {"P1": (97.46, 131.44), "P2": (108.97, 194.32), "P3": (-38.09, 245.35)}

def excl_mask(c, extra=()):
    m = np.zeros(len(c), bool)
    for (x, y) in list(BOSS_XY.values()):
        m |= np.hypot(c[:, 0] - x, c[:, 1] - y) < 9.0
    for (x, y) in list(PIN_XY.values()):
        m |= np.hypot(c[:, 0] - x, c[:, 1] - y) < 6.0
    for (x, y, r) in extra:
        m |= np.hypot(c[:, 0] - x, c[:, 1] - y) < r
    return m

def fit_rib(S, p0, p1, t0, top0=None, de_min=3.0, sa=0.0, sb=0.0, zfloor=None, extra_ex=(), zrange=None, win=None):
    """fit a vertical rib along centre line p0-p1 (plan). Returns dict."""
    c, n, a, de = S['c'], S['n'], S['a'], S['de']
    p, e, nu, L = frame(p0, p1)
    s, u = local(c, p, e, nu)
    win = win or (t0 / 2 + 3.5)
    cand = (s > -1) & (s < L + 1) & (abs(u) < win) & (de > de_min)
    if zrange is not None: cand &= (c[:, 2] > zrange[0]) & (c[:, 2] < zrange[1])
    ex = excl_mask(c, extra_ex)
    cand &= ~ex
    nu3 = nu[0] * n[:, 0] + nu[1] * n[:, 1]
    # side walls
    side_base = cand & (abs(n[:, 2]) < 0.3) & (s > sa) & (s < L - sb)
    top_guess = top0 if top0 is not None else np.nan
    res = {"L": float(L)}
    # top surface
    topm = cand & (n[:, 2] > 0.9) & (abs(u) < t0 / 2 + 0.8) & (s > sa) & (s < L - sb)
    if topm.sum() > 20:
        # restrict to dominant z cluster near guess (or histogram peak among upward faces)
        zz = c[topm, 2]
        if top0 is not None:
            near = abs(zz - top0) < 15
        else:
            near = np.ones(len(zz), bool)
        pk = peaks(zz[near], a[topm][near], 0.2, 0.02) if near.sum() else []
        zc = pk[0][0] if pk else float(np.median(zz))
        sel = topm.copy(); sel[topm] = abs(zz - zc) < 3.0 + 0 * zz
        A, B, rms, nn_ = linfit_robust(s[sel], c[sel, 2], it=4, k=2.0)
        res["top_a"] = A; res["top_b"] = B; res["top_rms"] = rms; res["top_n"] = nn_
        res["top_z_mid"] = A + B * L / 2; res["top_z0"] = A; res["top_z1"] = A + B * L
        res["top_slope_deg"] = float(np.degrees(np.arctan(B)))
        ztop = res["top_z_mid"]
    else:
        ztop = top0 if top0 is not None else (np.nanmedian(c[cand, 2]) if cand.any() else 0)
        res["top_n"] = 0
    # walls: height window just below the top
    zlo = ztop - 9 - 0 ; 
    wm = side_base & (c[:, 2] < ztop + 0.5 + 0) & (c[:, 2] > ztop - 9)
    if "top_b" in res:
        zt_s = res["top_a"] + res["top_b"] * s
        wm = side_base & (c[:, 2] < zt_s - 0.3) & (c[:, 2] > zt_s - 9)
    wr = wm & (nu3 > 0.9) & (u > 0); wl = wm & (nu3 < -0.9) & (u < 0)
    for nm, w in (("R", wr), ("L", wl)):
        if w.sum() > 15:
            a_, b_, rms, k_ = linfit_robust(s[w], u[w], it=4, k=2.0)
            res["u" + nm] = (a_, b_, rms, k_)
    if "uR" in res and "uL" in res:
        aR, bR = res["uR"][:2]; aL, bL = res["uL"][:2]
        sm = L / 2
        uR = aR + bR * sm; uL = aL + bL * sm
        res["t"] = float(uR - uL); res["off"] = float((uR + uL) / 2); res["rot_deg"] = float(np.degrees(np.arctan((bR + bL) / 2)))
        res["t_ends"] = (float((aR - aL)), float((aR + bR * L) - (aL + bL * L)))
    return res, (p, e, nu, L, cand, s, u)

def rib_mask(S, ctxt, res, t_def, de_min=3.0, pad=0.9, extra_ex=()):
    p, e, nu, L, cand, s, u = ctxt
    c, de = S['c'], S['de']
    off = res.get("off", 0.0); t = res.get("t", t_def)
    rot = np.tan(np.radians(res.get("rot_deg", 0.0)))
    uc = u - (off + rot * s)
    m = (s > -0.5) & (s < L + 0.5) & (abs(uc) < t / 2 + pad) & (de > de_min) & ~excl_mask(c, extra_ex)
    return np.where(m)[0]

def top_profile(S, ctxt, res, t_def, de_min=3.0, bin_=1.0, nzmin=0.3, extra_ex=(), maxseg=4, zrange=None):
    """per-bin top z along the rib centre line -> piecewise-linear profile [(s0,s1,z0,z1)] (s from p0)."""
    p, e, nu, L, cand, s, u = ctxt
    c, n, de = S['c'], S['n'], S['de']
    off = res.get("off", 0.0); t = res.get("t", t_def); rot = np.tan(np.radians(res.get("rot_deg", 0.0)))
    uc = u - (off + rot * s)
    m = (abs(uc) < max(t / 2 - 0.3, 0.6)) & (s > -0.5) & (s < L + 0.5) & (de > de_min) & (n[:, 2] > nzmin) & ~excl_mask(c, extra_ex)
    if zrange is not None: m &= (c[:, 2] > zrange[0]) & (c[:, 2] < zrange[1])
    idx = np.where(m)[0]
    if len(idx) < 10: return [], 0
    sb = np.floor(s[idx] / bin_).astype(int)
    S_, Z_, W_ = [], [], []
    for b in np.unique(sb):
        k = idx[sb == b]
        if len(k) < 3: continue
        # top = upper cluster: median of the top 60 percent by z
        zz = c[k, 2]; thr = np.percentile(zz, 40)
        S_.append((b + 0.5) * bin_); Z_.append(float(np.median(zz[zz >= thr]))); W_.append(len(k))
    if len(S_) < 4: return [], len(idx)
    pf = pw_fit(np.array(S_), np.array(Z_), maxseg=maxseg)
    pf = [q for q in pf if q[1] - q[0] >= 3.0]
    return pf, len(idx)
