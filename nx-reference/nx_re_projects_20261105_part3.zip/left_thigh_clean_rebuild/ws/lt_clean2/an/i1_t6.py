from i1_common import *
from i1_rib import *
import ref5_design as DS, sys
S=load_all(); c,n,a,de=S['c'],S['n'],S['a'],S['de']
def gprof(nm,p0,p1,t0,step=4,ex=()):
    p,e,nu,L=frame(p0,p1); s,u=local(c,p,e,nu)
    print(nm,"L=%.0f"%L,"p0",p0,"p1",p1)
    nu3=nu[0]*n[:,0]+nu[1]*n[:,1]
    for s0 in np.arange(-2,L+2,step):
        m=(s>=s0)&(s<s0+step)&(abs(u)<t0/2+4)&(de>3.0)&~excl_mask(c,ex)
        tp=m&(n[:,2]>0.3)&(abs(u)<t0/2-0.2)
        zt=np.median(c[tp,2]) if tp.sum()>3 else np.nan
        zmax=np.percentile(c[tp,2],95) if tp.sum()>3 else np.nan
        wr=m&(nu3>0.9)&(u>0)&(abs(n[:,2])<.5); wl=m&(nu3<-0.9)&(u<0)&(abs(n[:,2])<.5)
        ur=np.median(u[wr]) if wr.sum()>3 else np.nan; ul=np.median(u[wl]) if wl.sum()>3 else np.nan
        print("  s %5.1f topz med %6.2f p95 %6.2f n%3d  uL %6.2f uR %6.2f t %5.2f"%(s0+step/2,zt,zmax,tp.sum(),ul,ur,ur-ul))
nm=sys.argv[1]
if nm in DS.OUT_GUSSETS: a_,b_,z0,z1,t=DS.OUT_GUSSETS[nm]; gprof(nm,a_,b_,t)
elif len(sys.argv)>4: gprof(nm,eval(sys.argv[2]),eval(sys.argv[3]),float(sys.argv[4]))
