import sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import numpy as np, lib
from scipy.cluster.vq import kmeans2
from scipy.sparse.csgraph import connected_components
from scipy.spatial import cKDTree
HX,HZ=37.97,35.18
for tag,sn,dn in (('out','out_scan','dev_oldC'),('inn','inn_scan','dev_oldInnB')):
    v,f=lib.load(sn,1500000); c,nn,a=lib.tri_data(v,f); m=np.load(f"work/masks/{tag}_ext_hip.npy")
    d1=np.load(f"work/{dn}.npz")['d1']
    # restrict to Y>240
    k=m[(d1[m]>0.6)&(c[m,1]>240)]
    print(tag,'mask tris with old-master dev>0.6:',len(k))
    if len(k)==0: continue
    X=c[k]; t=cKDTree(X); pairs=t.query_pairs(2.5,output_type='ndarray')
    import scipy.sparse as sp
    G=sp.coo_matrix((np.ones(len(pairs)),(pairs[:,0],pairs[:,1])),shape=(len(X),)*2)
    nc,lab=connected_components(G,directed=False)
    for i in range(nc):
        q=lab==i
        if q.sum()<40: continue
        ar=a[k][q].sum(); b0=X[q].min(0); b1=X[q].max(0)
        th=np.degrees(np.arctan2(X[q,2].mean()-HZ,X[q,0].mean()-HX))
        print('  cluster n=%d area %.0f  centre (%.1f,%.1f,%.1f) th %.0f  bbox x[%.1f,%.1f] y[%.1f,%.1f] z[%.1f,%.1f]  maxdev %.2f'%(q.sum(),ar,*X[q].mean(0),th,b0[0],b1[0],b0[1],b1[1],b0[2],b1[2],d1[k][q].max()))
