"""r-z scatter about the knee axis (drum-only directions, angle from -Y within +-50 deg) for both scans."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, axs = plt.subplots(1, 2, figsize=(26, 12))
for n, colr in (("out_scan", "b"), ("inn_scan", "r"), ("out_cad", "c"), ("inn_cad", "m")):
    v, f = lib.load(n, 1500000) if "scan" in n else lib.load(n)
    c, nn, ar = lib.tri_data(v, f)
    r = np.hypot(c[:, 0], c[:, 1]); a = np.degrees(np.arctan2(c[:, 0], -c[:, 1]))
    m = np.abs(a) < 40
    for ax, (zl, rl) in zip(axs, (((-16, 8), (0, 72)), ((72, 96), (0, 72)))):
        mm = m & (c[:, 2] > zl[0]) & (c[:, 2] < zl[1])
        ax.plot(r[mm], c[mm, 2], ".", ms=0.6, color=colr, alpha=0.4)
        ax.set_xlim(*rl); ax.set_ylim(*zl); ax.grid(lw=0.3); ax.set_aspect("equal")
        ax.set_xticks(np.arange(rl[0], rl[1], 2)); ax.set_yticks(np.arange(zl[0], zl[1], 1))
fig.tight_layout(); fig.savefig(os.path.join(lib.W, "knee_rz.png"), dpi=50); print("ok")
