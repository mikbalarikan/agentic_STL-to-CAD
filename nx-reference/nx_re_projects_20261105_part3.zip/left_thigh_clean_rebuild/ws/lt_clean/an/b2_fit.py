"""Body loft sections v2.
Body stations (Y >= KNEE_Y): one-sided robust periodic B-spline fit to the exterior (polar max data).
Knee stations: target region = (rounded rectangle inset INSET inside the drum section) U (real exterior outside the
drum footprint, closed through the centre), smoothed by a morphological closing; its boundary is then fitted.
Writes work/sections.json and work/fit_sections.png."""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import b1_fit as b1
from shapely.geometry import Polygon, Point
from shapely.ops import unary_union
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DR = b1.DR
NP = int(os.environ.get("NP", 40))
INSET = 3.0                                   # side inset of the hidden section inside the drum
INSET_TB = float(os.environ.get("INSET_TB", 0.6))  # top / bottom inset: small, so the body top runs on smoothly
RC = float(os.environ.get("RC", 12.0))
CLOSE = 5.0
KNEE_Y = 70.0
STATIONS = [float(a) for a in os.environ.get(
    "ST", "-46,-36,-22,-4,16,34,50,62,76,92,112,135,165,195,222,246,264,278,287.4").split(",")]


def hidden_rect(y):
    zt, zb = DR["ztop"] - INSET_TB, DR["zbot"] + INSET_TB
    ww = np.sqrt(max(min(b1.drum_R(DR["ztop"]), b1.drum_R(DR["zbot"])) ** 2 - y ** 2, 0)) - INSET
    rc = float(np.interp(y, [-60, 15, 62], [RC, RC, 8.0]))   # continuous: corners tighten towards the emergence
    if ww < rc + 2:
        return None
    from shapely.geometry import box
    return box(-ww + rc, zb + rc, ww - rc, zt - rc).buffer(rc, 32)


def knee_target(y, P, ctr):
    x, z = P[:, 0], P[:, 1]
    w = np.sqrt(np.maximum(b1.drum_R(np.clip(z, DR["zbot"], DR["ztop"])) ** 2 - y ** 2, 0))
    real = (np.abs(x) > w + 0.4) & (np.hypot(x - b1.B1[0], y - b1.B1[1]) > 13.0) & ((x > 0) | (y > 40)) & (y > -36)
    R = P[real]
    polys = []
    H = hidden_rect(y)
    if H is not None:
        polys.append(H)
    if len(R) > 5:
        d = R - ctr
        a = np.arctan2(d[:, 1], d[:, 0]); o = np.argsort(a); R = R[o]; a = a[o]
        # split into arcs at angular gaps, each arc closed through the centre
        gaps = np.where(np.diff(a) > np.radians(6))[0]
        for seg in np.split(np.arange(len(R)), gaps + 1):
            if len(seg) > 4:
                pg = Polygon(np.vstack([ctr, R[seg]])).buffer(0)
                polys.append(pg)
    U = unary_union(polys)
    if os.environ.get("CONVEX", "1") == "1":
        U = U.convex_hull                      # the exterior is convex here: no dips between hidden and real data
    else:
        U = U.buffer(CLOSE, 32).buffer(-CLOSE, 32)
    if U.geom_type == "MultiPolygon":
        U = max(U.geoms, key=lambda g: g.area)
    # polar sampling of the boundary
    ang = np.linspace(-np.pi, np.pi, 721)[:-1]
    from shapely.geometry import LineString
    ext = U.exterior
    out = []
    for t in ang:
        ray = LineString([ctr, ctr + 400 * np.array([np.cos(t), np.sin(t)])])
        ip = ray.intersection(ext)
        pts = [ip] if ip.geom_type == "Point" else list(getattr(ip, "geoms", []))
        if pts:
            p = max(pts, key=lambda q: q.distance(Point(ctr)))
            out.append((p.x, p.y))
    T = np.array(out)
    return T, R


def fit_points(T, ctr, robust=True, lam_k=1e-3, np_=NP):
    d = T - ctr
    th = np.mod(np.arctan2(d[:, 1], d[:, 0]), 2 * np.pi)
    u = th / (2 * np.pi)
    B = b1.bspline_basis(u, np_)
    lam = lam_k * len(u) / np_
    D2 = np.zeros((np_, np_))
    for i in range(np_):
        D2[i, i] = -2; D2[i, (i - 1) % np_] = 1; D2[i, (i + 1) % np_] = 1
    keep = np.ones(len(u), bool)
    for it in range(6 if robust else 1):
        M = B[keep].T @ B[keep] + lam * D2.T @ D2
        C = np.linalg.solve(M, B[keep].T @ T[keep])
        fit = B @ C
        rd = np.hypot(*(T - ctr).T) - np.hypot(*(fit - ctr).T)
        if robust:
            keep = rd > -0.35
    return C, rd, keep


def main():
    secs = []
    n = len(STATIONS); nc = 5; nr = (n + nc - 1) // nc
    fig, axs = plt.subplots(nr, nc, figsize=(nc * 5.5, nr * 5))
    for ax, y in zip(axs.ravel(), STATIONS):
        sel = b1.keys[np.abs(b1.kv - y) <= 1.6]
        if len(sel) == 0:
            sel = [b1.keys[np.argmin(np.abs(b1.kv - y))]]
        P = np.vstack([b1.ext[k][:, :2] for k in sel])
        ctr = np.array([(P[:, 0].min() + P[:, 0].max()) / 2, (P[:, 1].min() + P[:, 1].max()) / 2])
        if y < KNEE_Y:
            ctr = np.array([10.0, 35.0])
            T, R = knee_target(y, P, ctr)
            C, rd, keep = fit_points(T, ctr, robust=False, lam_k=float(os.environ.get("LAMK", 3e-4)))
            cur = b1.bspline_basis(np.linspace(0, 1, 1441)[:-1], NP) @ C
            m = b1.drum_inside(cur[:, 0], np.full(len(cur), y), cur[:, 1])
            # deviation to the real data (outside the drum)
            if len(R):
                dd = np.min(np.linalg.norm(R[:, None, :] - cur[None, ::4, :], axis=2), axis=1)
                dev = float(np.percentile(dd, 95))
            else:
                dev = 0.0
            # protrusion out of the drum where the curve is NOT near real data
            near = np.zeros(len(cur), bool)
            if len(R):
                near = np.min(np.linalg.norm(cur[:, None, :] - R[None, ::3, :], axis=2), axis=1) < 3.0
            prot = float(-m[~near].min()) if (~near).any() else 0.0
            if (~near).any():
                k = np.argmin(np.where(~near, m, 1e9)); print("      worst protrusion at", cur[k].round(2))
            if len(R) == 0:
                prot = float(-m.min())
            secs.append({"y": y, "poles": [[float(c[0]), y, float(c[1])] for c in C], "res_p95": dev,
                         "protrusion": prot})
            ax.plot(P[:, 0], P[:, 1], ".", ms=1, color="0.75")
            ax.plot(R[:, 0], R[:, 1], ".", ms=2, color="g")
            print(f"Y {y:7.1f} knee  real {len(R):4d}  dev p95 {dev:.3f}  protrusion out of drum {prot:6.2f}")
        else:
            if 135 <= y <= 180:
                P = P[~((P[:, 0] > 88) & (P[:, 1] > -8) & (P[:, 1] < 66))]
            C, rd, keep = fit_points(P, ctr, robust=True, lam_k=2e-3)
            cur = b1.bspline_basis(np.linspace(0, 1, 1441)[:-1], NP) @ C
            res = np.abs(rd[keep])
            secs.append({"y": y, "poles": [[float(c[0]), y, float(c[1])] for c in C],
                         "res_p95": float(np.percentile(res, 95)), "protrusion": 0.0})
            ax.plot(P[:, 0], P[:, 1], ".", ms=1, color="0.6")
            print(f"Y {y:7.1f} body  n {len(P):4d}  res p50 {np.median(res):.3f} p95 {np.percentile(res, 95):.3f}")
        ax.plot(cur[:, 0], cur[:, 1], "b-", lw=0.8)
        ax.plot(C[:, 0], C[:, 1], "r.", ms=3)
        zz = np.linspace(DR["zbot"], DR["ztop"], 50)
        xx = np.sqrt(np.maximum(b1.drum_R(zz) ** 2 - y ** 2, 0))
        ax.plot(xx, zz, "k:", -xx, zz, "k:", lw=0.6)
        ax.axhline(DR["ztop"], color="k", ls=":", lw=0.5); ax.axhline(DR["zbot"], color="k", ls=":", lw=0.5)
        ax.set_title(f"Y {y}  p95 {secs[-1]['res_p95']:.2f}  prot {secs[-1]['protrusion']:.2f}")
        ax.set_aspect("equal"); ax.grid(lw=0.3)
    fig.tight_layout(); fig.savefig(os.path.join(lib.W, "fit_sections.png"), dpi=60)
    json.dump({"sections": secs, "drum": {k: float(v) for k, v in DR.items()}, "np": NP},
              open(os.path.join(lib.W, "sections.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
