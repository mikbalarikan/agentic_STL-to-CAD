"""Cache meshes and render overview views of the reference CAD (outer / inner) for planning."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import pyvista as pv

pv.OFF_SCREEN = True
out = os.path.join(lib.W, "views"); os.makedirs(out, exist_ok=True)

meshes = {}
for n in ("out_cad", "inn_cad"):
    v, f = lib.load(n)
    print(n, len(v), len(f), v.min(0).round(2), v.max(0).round(2))
    meshes[n] = pv.PolyData(v, np.hstack([np.full((len(f), 1), 3), f]).ravel())
for n in ("out_scan", "inn_scan"):
    v, f = lib.load(n, 1500000)
    print(n, len(v), len(f), v.min(0).round(2), v.max(0).round(2))

views = {"top": ((0, 0, 1), (0, 1, 0)), "bot": ((0, 0, -1), (0, 1, 0)),
         "px": ((1, 0, 0), (0, 0, 1)), "mx": ((-1, 0, 0), (0, 0, 1)),
         "iso": ((1, -1, 1.2), (0, 0, 1)), "isob": ((-1, 1, -1.2), (0, 0, 1))}
for n, m in meshes.items():
    for vn, (d, up) in views.items():
        p = pv.Plotter(window_size=(1400, 1400))
        p.add_mesh(m, color="lightsteelblue", smooth_shading=False, specular=0.3)
        c = np.array(m.center)
        p.camera.focal_point = c
        p.camera.position = c + 900 * np.array(d) / np.linalg.norm(d)
        p.camera.up = up
        p.enable_parallel_projection()
        p.reset_camera(); p.camera.zoom(1.3)
        p.screenshot(os.path.join(out, f"{n}_{vn}.png")); p.close()
print("ok")
