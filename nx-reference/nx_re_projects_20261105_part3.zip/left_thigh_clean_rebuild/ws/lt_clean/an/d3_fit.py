"""Mesh fit check of the two part STLs (same frame): points of each part inside the other (signed distance),
gap histogram near the joint. argv: out_stl inn_stl tag"""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import open3d as o3d
import trimesh

o, i, tag = sys.argv[1], sys.argv[2], sys.argv[3]
M = {}
for k, pth in (("out", o), ("inn", i)):
    m = trimesh.load(pth, process=False); m.merge_vertices()
    M[k] = m
res = {}
for a, b in (("inn", "out"), ("out", "inn")):
    sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.core.Tensor(np.asarray(M[b].vertices, np.float32)), o3d.core.Tensor(np.asarray(M[b].faces, np.uint32)))
    pts, _ = trimesh.sample.sample_surface(M[a], 600000, seed=2)
    sd = sc.compute_signed_distance(o3d.core.Tensor(pts.astype(np.float32))).numpy()
    inside = sd < -0.02
    res[f"{a}_in_{b}"] = {"n_inside": int(inside.sum()), "min_sd": float(sd.min())}
    if inside.any():
        P = pts[inside]
        # cluster summary: bbox of inside points by coarse grid
        keys = np.round(P / 10).astype(int)
        u, cnt = np.unique(keys, axis=0, return_counts=True)
        top = np.argsort(-cnt)[:12]
        res[f"{a}_in_{b}"]["clusters"] = [{"at10": (u[t] * 10).tolist(), "n": int(cnt[t]),
                                             "min_sd": float(sd[inside][(keys == u[t]).all(1)].min())} for t in top]
    near = (sd > -0.02) & (sd < 1.0)
    res[f"{a}_near_{b}"] = int(near.sum())
print(json.dumps(res, indent=1))
json.dump(res, open(os.path.join(lib.W, f"fit_{tag}.json"), "w"), indent=1)
