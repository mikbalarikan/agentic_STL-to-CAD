"""Side depth maps along X (both scans together): from -X and from +X. Openings show as deep hits."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
from rays import Caster
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
v1, f1 = lib.load("out_scan", 1500000); v2, f2 = lib.load("inn_scan", 1500000)
C = Caster(np.vstack([v1, v2]), np.vstack([f1, f2 + len(v1)]))
st = 0.4
Y, Z = np.meshgrid(np.arange(-70, 290, st), np.arange(-45, 115, st))
for side, x0, d in (("mx", -200.0, 1), ("px", 300.0, -1)):
    o = np.c_[np.full(Y.size, x0), Y.ravel(), Z.ravel()]
    t = C.hit(o, np.tile([d, 0, 0], (Y.size, 1)))
    X = (x0 + d * t).reshape(Y.shape)
    np.savez(os.path.join(lib.W, f"side_{side}.npz"), Y=Y, Z=Z, X=X)
    fig, ax = plt.subplots(figsize=(36, 17))
    im = ax.imshow(X, origin="lower", extent=(Y.min(), Y.max(), Z.min(), Z.max()), cmap="turbo")
    ax.contour(Y, Z, np.nan_to_num(X, nan=0), levels=np.arange(-80, 130, 2), colors="k", linewidths=0.15)
    ax.set_xticks(np.arange(-70, 290, 5)); ax.set_yticks(np.arange(-45, 115, 5)); ax.grid(lw=0.3, color="w")
    ax.tick_params(labelsize=7); plt.colorbar(im, ax=ax, shrink=0.5); ax.set_title(side)
    fig.tight_layout(); fig.savefig(os.path.join(lib.W, f"side_{side}.png"), dpi=50)
print("ok")
