"""Exterior contour data per Y station (both scans combined): polar max about the section centre.
Writes work/ext.npz: for each station Y, points (k,2) [x,z] of the exterior and the angle grid max radius."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

M = [lib.load(n, 1500000) for n in ("out_scan", "inn_scan")]
YS = np.round(np.arange(-66.0, 287.01, 1.5), 2)
NA = 360
out = {}
sil = []
for y in YS:
    pts = []
    for v, f in M:
        s = lib.section(v, f, 1, y)
        if len(s):
            pts.append(s.mean(1)[:, [0, 2]])
    if not pts:
        continue
    P = np.vstack(pts)
    c = np.array([(P[:, 0].min() + P[:, 0].max()) / 2, (P[:, 1].min() + P[:, 1].max()) / 2])
    d = P - c
    r = np.hypot(d[:, 0], d[:, 1]); a = np.arctan2(d[:, 1], d[:, 0])
    k = ((a + np.pi) / (2 * np.pi) * NA).astype(int) % NA
    rmax = np.full(NA, np.nan); amax = np.full(NA, np.nan)
    order = np.lexsort((r, k))
    last = np.r_[k[order][1:] != k[order][:-1], True]
    rmax[k[order][last]] = r[order][last]
    E = c + np.c_[np.cos(a[order][last]), np.sin(a[order][last])] * r[order][last][:, None]
    out[f"{y:.2f}"] = np.c_[E, k[order][last]]
    sil.append((y, P[:, 0].min(), P[:, 0].max(), P[:, 1].min(), P[:, 1].max()))
np.savez(os.path.join(lib.W, "ext.npz"), **out)
sil = np.array(sil)
np.save(os.path.join(lib.W, "sil.npy"), sil)
fig, ax = plt.subplots(2, 1, figsize=(16, 10))
ax[0].plot(sil[:, 0], sil[:, 1], label="xmin"); ax[0].plot(sil[:, 0], sil[:, 2], label="xmax")
yy = np.linspace(-68, 68, 200)
ax[0].plot(yy, -np.sqrt(68.9 ** 2 - yy ** 2), "k:", yy, np.sqrt(68.9 ** 2 - yy ** 2), "k:")
ax[1].plot(sil[:, 0], sil[:, 3], label="zmin"); ax[1].plot(sil[:, 0], sil[:, 4], label="zmax")
ax[1].axhline(83.62, color="k", ls=":"); ax[1].axhline(-13.9, color="k", ls=":")
for a_ in ax:
    a_.grid(); a_.legend()
fig.savefig(os.path.join(lib.W, "silhouette.png"), dpi=70)
print("stations", len(out))
