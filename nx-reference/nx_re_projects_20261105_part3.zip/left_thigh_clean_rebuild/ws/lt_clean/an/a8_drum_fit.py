"""Fit the knee drum: r(z) = Rp - |z - zp| * tan(a) on drum-only directions (both scans). Also the top plane."""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
from scipy.optimize import least_squares

pts = []
for n in ("out_scan", "inn_scan"):
    v, f = lib.load(n, 1500000)
    c, nn, ar = lib.tri_data(v, f)
    r = np.hypot(c[:, 0], c[:, 1])
    ang = np.degrees(np.arctan2(c[:, 0], -c[:, 1]))
    radial = (c[:, 0] * nn[:, 0] + c[:, 1] * nn[:, 1]) / np.maximum(r, 1e-9)
    m = (r > 66) & (r < 71) & (np.abs(ang) < 70) & (radial > 0.95) & (c[:, 2] > -10) & (c[:, 2] < 81)
    pts.append(np.c_[r[m], c[m, 2], np.full(m.sum(), 0 if n == "out_scan" else 1)])
P = np.vstack(pts)


def res(p):
    Rp, zp, t = p
    return P[:, 0] - (Rp - np.abs(P[:, 1] - zp) * t)


s = least_squares(res, [68.9, 35.0, 0.03], loss="soft_l1", f_scale=0.1)
Rp, zp, t = s.x
r = res(s.x)
print(f"drum: Rp {Rp:.3f} (D {2*Rp:.3f}) zp {zp:.3f} draft {np.degrees(np.arctan(t)):.3f} deg  res p50 {np.median(np.abs(r)):.3f} p95 {np.percentile(np.abs(r),95):.3f}")
for k in (0, 1):
    m = P[:, 2] == k
    s2 = least_squares(lambda p: P[m, 0] - (p[0] - np.abs(P[m, 1] - zp) * p[1]), [Rp, t], loss="soft_l1", f_scale=0.1)
    print(f"  {'outer' if k == 0 else 'inner'} half: Rp {s2.x[0]:.3f} draft {np.degrees(np.arctan(s2.x[1])):.3f}")
# top plane of the knee disc (inner) and bottom ring (outer)
v, f = lib.load("inn_scan", 1500000)
c, nn, ar = lib.tri_data(v, f)
r = np.hypot(c[:, 0], c[:, 1])
m = (nn[:, 2] > 0.995) & (r > 25) & (r < 60) & (c[:, 2] > 82)
print("knee disc top z p50", np.median(c[m, 2]).round(3), "p5/p95", np.percentile(c[m, 2], [5, 95]).round(3))
# top chamfer: points with normal ~45 deg near the top edge
m = (c[:, 2] > 78) & (r > 62) & (nn[:, 2] > 0.4) & (nn[:, 2] < 0.9) & (np.abs(np.degrees(np.arctan2(c[:, 0], -c[:, 1]))) < 70)
print("top chamfer: n", m.sum(), "r range", np.percentile(r[m], [5, 95]).round(2), "z range", np.percentile(c[m, 2], [5, 95]).round(2),
      "normal z p50", np.median(nn[m, 2]).round(3))
json.dump({"Rp": Rp, "zp": zp, "tan": t}, open(os.path.join(lib.W, "drum.json"), "w"))
for zf in (34.76, 35.32, 36.07, 37.25):
    s3 = least_squares(lambda p: P[:, 0] - (p[0] - np.abs(P[:, 1] - zf) * p[1]), [Rp, t], loss="soft_l1", f_scale=0.1)
    rr = P[:, 0] - (s3.x[0] - np.abs(P[:, 1] - zf) * s3.x[1])
    print(f"zp fixed {zf}: Rp {s3.x[0]:.3f} draft {np.degrees(np.arctan(s3.x[1])):.3f} res p50 {np.median(np.abs(rr)):.3f} p95 {np.percentile(np.abs(rr),95):.3f}")
    for k in (0, 1):
        m = P[:, 2] == k
        print("    half", k, "mean res", rr[m].mean().round(3))
