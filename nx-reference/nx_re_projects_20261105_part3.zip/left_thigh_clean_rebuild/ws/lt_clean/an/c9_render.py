"""Render an STL (CAD) from standard views. argv: stl tag [views: name=dx,dy,dz ...]"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import trimesh
import pyvista as pv
pv.OFF_SCREEN = True
stl, tag = sys.argv[1], sys.argv[2]
m = trimesh.load(stl, process=False)
mesh = pv.PolyData(np.asarray(m.vertices), np.hstack([np.full((len(m.faces), 1), 3), m.faces]).ravel())
views = dict(a.split("=") for a in sys.argv[3:]) if len(sys.argv) > 3 else {
    "iso": "1,-1,1.3", "top": "0.001,0,1", "iso2": "-1,1,1.3", "bot": "0.3,-0.3,-1"}
out = os.path.join(lib.W, "render"); os.makedirs(out, exist_ok=True)
for nm, d in views.items():
    d = np.array([float(t) for t in d.split(",")])
    p = pv.Plotter(window_size=(1600, 1300))
    p.add_mesh(mesh, color="#9db4cc", specular=0.4, smooth_shading=False, show_edges=False)
    p.enable_eye_dome_lighting() if False else None
    c = np.array(mesh.center)
    p.camera.focal_point = c
    p.camera.position = c + 800 * d / np.linalg.norm(d)
    p.camera.up = (0, 1, 0) if abs(d[2]) > 0.95 * np.linalg.norm(d) else (0, 0, 1)
    p.reset_camera(); p.camera.zoom(1.15)
    p.screenshot(os.path.join(out, f"{tag}_{nm}.png")); p.close()
print("ok")
