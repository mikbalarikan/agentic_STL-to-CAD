"""Measure straight ribs / arms in a plan section: points of the section inside a box are split into the two long
faces (PCA side), each face line fitted; returns centre line, width, extent along the rib.
argv: mesh z name x0,y0,x1,y1 [name box ...]"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib


def measure(P):
    c = P.mean(0)
    U, S, Vt = np.linalg.svd(P - c)
    t = Vt[0]; n = Vt[1]
    s = (P - c) @ t; d = (P - c) @ n
    # two faces: split by sign of d, take points well inside the extent (avoid end caps)
    lo, hi = np.percentile(s, [8, 92])
    m = (s > lo) & (s < hi)
    a = d[m & (d > 0)]; b = d[m & (d < 0)]
    w = np.median(a) - np.median(b)
    mid = (np.median(a) + np.median(b)) / 2
    p0 = c + t * s.min() + n * mid; p1 = c + t * s.max() + n * mid
    return p0, p1, w, np.std(a), np.std(b)


if __name__ == "__main__":
    name, z = sys.argv[1], float(sys.argv[2])
    v, f = lib.load(name, 1500000) if "scan" in name else lib.load(name)
    sg = lib.section(v, f, 2, z)[:, :, :2]
    pts = sg.reshape(-1, 2)
    for i in range(3, len(sys.argv), 2):
        nm = sys.argv[i]; x0, y0, x1, y1 = map(float, sys.argv[i + 1].split(","))
        m = (pts[:, 0] > x0) & (pts[:, 0] < x1) & (pts[:, 1] > y0) & (pts[:, 1] < y1)
        if m.sum() < 10:
            print(nm, "no points"); continue
        p0, p1, w, sa, sb = measure(pts[m])
        print(f"{nm:10s} z {z}: ({p0[0]:7.2f},{p0[1]:7.2f}) -> ({p1[0]:7.2f},{p1[1]:7.2f})  w {w:5.2f}  "
              f"face scatter {sa:.2f}/{sb:.2f}  n {m.sum()}")
