"""Fit the body loft sections (closed periodic cubic B-splines, uniform knots in polar angle) to the exterior.
Drum-owned exterior (cone side, knee top disc, bottom) is replaced by an inset target so the loft hides inside the
drum there. Writes work/sections.json {sections: [{y, poles}], drum: {...}} and a plot."""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DR = dict(Rp=68.9, zp=36.07, tan=np.tan(np.radians(1.7)), ztop=83.62, zbot=-13.9)
NP = int(os.environ.get("NP", 32))          # poles per section
INSET = 3.0
RC = 14.0       # corner radius of the synthetic (hidden) drum section
STATIONS = [float(a) for a in os.environ.get("ST", "-56,-44,-30,-12,8,28,46,60,74,90,110,135,165,195,222,246,264,278,287.4").split(",")]
ext = np.load(os.path.join(lib.W, "ext.npz"))
keys = np.array(sorted(ext.files, key=float)); kv = keys.astype(float)


def drum_R(z):
    return DR["Rp"] - np.abs(z - DR["zp"]) * DR["tan"]


def drum_inside(x, y, z, m=0.0):
    """signed: >0 inside the drum by that much (approx, min of side/top/bottom margins)."""
    R = drum_R(np.clip(z, DR["zbot"], DR["ztop"]))
    side = R - np.hypot(x, y)
    return np.minimum(np.minimum(side, DR["ztop"] - z), z - DR["zbot"])


B1 = (61.35, -40.01)
KNEE_Y = 70.0


def station_points(y, half=1.6):
    sel = keys[np.abs(kv - y) <= half]
    if len(sel) == 0:
        sel = [keys[np.argmin(np.abs(kv - y))]]
    P = np.vstack([ext[k][:, :2] for k in sel])
    if y >= KNEE_Y:
        # side pocket on +X (Y 137..177): a recess, not the envelope
        if 135 <= y <= 180:
            P = P[~((P[:, 0] > 88) & (P[:, 1] > -8) & (P[:, 1] < 66))]
        return P, np.zeros(len(P), bool)
    # knee zone: real data only outside the drum footprint (and away from the B1 lug); the drum footprint
    # itself is replaced by its own boundary inset by INSET (synthetic, hidden inside the drum)
    x, z = P[:, 0], P[:, 1]
    w = np.sqrt(np.maximum(drum_R(np.clip(z, DR["zbot"], DR["ztop"])) ** 2 - y ** 2, 0))
    real = (np.abs(x) > w + 0.4) & (np.hypot(x - B1[0], y - B1[1]) > 13.0) & ((x > 0) | (y > 40))
    S = []
    if abs(y) < DR["Rp"]:
        # rounded rectangle inside the drum section: half width = min drum half width - INSET
        zt, zb = DR["ztop"] - INSET, DR["zbot"] + INSET
        ww = np.sqrt(max(min(drum_R(DR["ztop"]), drum_R(DR["zbot"])) ** 2 - y ** 2, 0)) - INSET
        if ww > RC + 2:
            t = np.linspace(0, 2 * np.pi, 720, endpoint=False)
            hx, hz = ww - RC, (zt - zb) / 2 - RC
            cx, cz = 0.0, (zt + zb) / 2
            # superposition: rectangle with round corners as a capsule-like param curve
            px = np.clip(np.cos(t) * 1e3, -hx, hx) + RC * np.cos(t)
            pz = np.clip(np.sin(t) * 1e3, -hz, hz) + RC * np.sin(t)
            S += [np.c_[cx + px, cz + pz]]
    S = np.vstack(S) if S else np.zeros((0, 2))
    Q = np.vstack([P[real], S])
    hid = np.r_[np.zeros(real.sum(), bool), np.ones(len(S), bool)]
    return Q, hid


def bspline_basis(u, n, deg=3):
    """periodic uniform cubic B-spline basis, n control points, u in [0,1). Returns (len(u), n)."""
    t = u * n
    i = np.floor(t).astype(int); s = t - i
    b = np.zeros((len(u), n))
    w = [(1 - s) ** 3 / 6, (3 * s ** 3 - 6 * s ** 2 + 4) / 6, (-3 * s ** 3 + 3 * s ** 2 + 3 * s + 1) / 6, s ** 3 / 6]
    for k in range(4):
        np.add.at(b, (np.arange(len(u)), (i + k) % n), w[k])
    return b


def fit_section(y, P, hid, ctr):
    d = P - ctr
    th = np.mod(np.arctan2(d[:, 1], d[:, 0]), 2 * np.pi)
    # polar max per 1 deg bin: the outermost of real and synthetic
    k = (th / (2 * np.pi) * 360).astype(int) % 360
    r = np.hypot(d[:, 0], d[:, 1])
    o = np.lexsort((r, k)); last = np.r_[k[o][1:] != k[o][:-1], True]
    sel = o[last]
    P, hid, d, th = P[sel], hid[sel], d[sel], th[sel]
    tgt = P.copy()
    w = np.where(hid, 0.08, 1.0)
    u = th / (2 * np.pi)
    B = bspline_basis(u, NP)
    lam = 4e-3 * len(u) / NP
    D2 = np.zeros((NP, NP))
    for i in range(NP):
        D2[i, i] = -2; D2[i, (i - 1) % NP] = 1; D2[i, (i + 1) % NP] = 1
    keep = np.ones(len(u), bool)
    for it in range(14):
        A = B * w[:, None]
        M = A[keep].T @ B[keep] + lam * D2.T @ D2
        C = np.linalg.solve(M, A[keep].T @ tgt[keep])
        fit = B @ C
        rd = np.hypot(*(tgt - ctr).T) - np.hypot(*(fit - ctr).T)
        keep = (rd > -0.35) | hid                   # drop real data well inside the fit (grooves, windows, ribs)
        if hid.any():
            # hidden zone: the curve must stay >= 1.5 inside the drum; pull harder where it does not
            m = drum_inside(fit[:, 0], np.full(len(fit), y), fit[:, 1])
            bad = hid & (m < 1.5)
            w[bad] *= 3.0
            w = np.minimum(w, 20.0)
    return C, fit, tgt, hid, rd


def main():
    secs = []
    n = len(STATIONS); nc = 5; nr = (n + nc - 1) // nc
    fig, axs = plt.subplots(nr, nc, figsize=(nc * 5.5, nr * 5))
    for ax, y in zip(axs.ravel(), STATIONS):
        P, hid0 = station_points(y)
        ctr = np.array([(P[:, 0].min() + P[:, 0].max()) / 2, (P[:, 1].min() + P[:, 1].max()) / 2])
        if y < KNEE_Y:
            ctr = np.array([max(ctr[0], 10.0), 35.0])
        C, fit, tgt, hid, rd = fit_section(y, P, hid0, ctr)
        P = tgt
        uu = np.linspace(0, 1, 721)[:-1]
        cur = bspline_basis(uu, NP) @ C
        vis = ~hid
        res = rd[vis & (rd > -0.35)]
        secs.append({"y": y, "poles": [[float(c[0]), y, float(c[1])] for c in C],
                     "res_p95": float(np.percentile(np.abs(res), 95)) if len(res) else 0.0})
        ax.plot(P[:, 0], P[:, 1], ".", ms=1, color="0.6")
        ax.plot(tgt[hid, 0], tgt[hid, 1], ".", ms=1, color="orange")
        ax.plot(cur[:, 0], cur[:, 1], "b-", lw=0.8)
        ax.plot(C[:, 0], C[:, 1], "r.:", ms=3, lw=0.4)
        zz = np.linspace(DR["zbot"], DR["ztop"], 50)
        xx = np.sqrt(np.maximum(drum_R(zz) ** 2 - y ** 2, 0))
        ax.plot(xx, zz, "k:", -xx, zz, "k:", lw=0.6)
        ax.set_title(f"Y {y}  res p95 {secs[-1]['res_p95']:.2f}")
        ax.set_aspect("equal"); ax.grid(lw=0.3)
        uu2 = np.linspace(0, 1, 1441)[:-1]; cc = bspline_basis(uu2, NP) @ C
        mm = drum_inside(cc[:, 0], np.full(len(cc), y), cc[:, 1])
        secs[-1]["poke"] = float(mm[(mm > -15)].min()) if y < KNEE_Y else 0.0
        print(f"poke(min margin near drum) {secs[-1]['poke']:6.2f}  Y {y:7.1f}  n {len(P):5d} hidden {hid.sum():5d}  res p50 {np.median(np.abs(res)) if len(res) else 0:.3f} p95 {secs[-1]['res_p95']:.3f}")
    fig.tight_layout(); fig.savefig(os.path.join(lib.W, "fit_sections.png"), dpi=60)
    json.dump({"sections": secs, "drum": {k: float(v) for k, v in DR.items()}, "np": NP},
              open(os.path.join(lib.W, "sections.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
