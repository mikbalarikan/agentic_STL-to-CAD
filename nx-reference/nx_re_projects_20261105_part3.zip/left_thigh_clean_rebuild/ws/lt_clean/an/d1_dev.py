"""Two-way deviation CAD STL vs its scan. argv: cad_stl scan(out_scan|inn_scan) tag
scan->CAD: unsigned distance of scan triangle centres to the CAD surface (missing / extra geometry shows as large).
CAD->scan: unsigned distance of CAD samples to the scan. Maps: scan points coloured by distance (0..1.5)."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import open3d as o3d
import trimesh
import pyvista as pv
pv.OFF_SCREEN = True

stl, scan, tag = sys.argv[1], sys.argv[2], sys.argv[3]
m = trimesh.load(stl, process=False)
cv, cf = np.asarray(m.vertices, float), np.asarray(m.faces)
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.core.Tensor(cv.astype(np.float32)), o3d.core.Tensor(cf.astype(np.uint32)))
v, f = lib.load(scan, 1500000)
c, nn, ar = lib.tri_data(v, f)
d1 = sc.compute_distance(o3d.core.Tensor(c.astype(np.float32))).numpy()
ss = o3d.t.geometry.RaycastingScene(); ss.add_triangles(o3d.core.Tensor(v.astype(np.float32)), o3d.core.Tensor(f.astype(np.uint32)))
pts, _ = trimesh.sample.sample_surface(m, 400000, seed=1)
d2 = ss.compute_distance(o3d.core.Tensor(pts.astype(np.float32))).numpy()
w = ar / ar.sum()
def wp(d, q):
    o = np.argsort(d); cw = np.cumsum(w[o]); return d[o][np.searchsorted(cw, q)]
print(f"{tag}: scan->CAD (area-weighted) p50 {wp(d1,0.5):.3f} p90 {wp(d1,0.9):.3f} p95 {wp(d1,0.95):.3f}  within 0.5: {w[d1<0.5].sum()*100:.1f}%  within 1.0: {w[d1<1.0].sum()*100:.1f}%")
print(f"{tag}: CAD->scan p50 {np.median(d2):.3f} p90 {np.percentile(d2,90):.3f} p95 {np.percentile(d2,95):.3f}  within 0.5: {np.mean(d2<0.5)*100:.1f}%")
np.savez(os.path.join(lib.W, f"dev_{tag}.npz"), c=c, d1=d1, pts=pts, d2=d2)
cloud = pv.PolyData(c); cloud["d"] = np.clip(d1, 0, 1.5)
cad = pv.PolyData(pts); cad["d"] = np.clip(d2, 0, 1.5)
out = os.path.join(lib.W, "dev"); os.makedirs(out, exist_ok=True)
up_dir = 1 if "out" in scan else -1
for nm, cl, d in (("scan_open", cloud, (0.3, -0.5, up_dir)), ("scan_out", cloud, (0.3, -0.5, -up_dir)),
                  ("cad_open", cad, (0.3, -0.5, up_dir))):
    p = pv.Plotter(window_size=(1500, 1200))
    p.add_mesh(cl, scalars="d", cmap="jet", clim=(0, 1.5), point_size=2)
    ctr = c.mean(0); dd = np.array(d, float)
    p.camera.focal_point = ctr; p.camera.position = ctr + 700 * dd / np.linalg.norm(dd); p.camera.up = (0, 1, 0)
    p.screenshot(os.path.join(out, f"{tag}_{nm}.png")); p.close()
