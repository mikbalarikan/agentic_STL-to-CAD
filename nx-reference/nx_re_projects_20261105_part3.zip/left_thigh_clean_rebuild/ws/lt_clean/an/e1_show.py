"""Presentation renders of the two parts (gloss), assembled and each open side. argv: out_stl inn_stl tag"""
import sys, os
import numpy as np, trimesh, pyvista as pv
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
pv.OFF_SCREEN = True
o, i, tag = sys.argv[1:4]
def pd(p):
    m = trimesh.load(p, process=False); return pv.PolyData(np.asarray(m.vertices), np.hstack([np.full((len(m.faces), 1), 3), m.faces]).ravel())
O, I = pd(o), pd(i)
shots = {"asm_top": ([(O, "#5b8fd6"), (I, "#c9cdd2")], (0.8, -0.5, 1.0), (30, 110, 40)),
         "asm_side": ([(O, "#5b8fd6"), (I, "#c9cdd2")], (1, -0.4, 0.3), (30, 110, 40)),
         "outer_open": ([(O, "#5b8fd6")], (0.5, -0.4, 1.0), (30, 110, 0)),
         "inner_open": ([(I, "#c9cdd2")], (0.5, -0.4, -1.0), (30, 110, 70))}
for nm, (ms, d, f) in shots.items():
    p = pv.Plotter(window_size=(1600, 1200)); p.set_background("white")
    for m, c in ms:
        p.add_mesh(m, color=c, smooth_shading=True, split_sharp_edges=True, specular=0.6, specular_power=30)
    d = np.array(d, float); f = np.array(f, float)
    p.camera.focal_point = f; p.camera.position = f + 700 * d / np.linalg.norm(d); p.camera.up = (0, 1, 0) if abs(d[2]) > 0.9 else (0, 0, 1)
    p.reset_camera(); p.camera.zoom(1.25)
    p.screenshot(os.path.join(lib.W, f"show_{tag}_{nm}.png")); p.close()
from PIL import Image
ims = [Image.open(os.path.join(lib.W, f"show_{tag}_{n}.png")) for n in shots]
w, h = ims[0].size; W = Image.new("RGB", (w * 2, h * 2), "white")
for k, im in enumerate(ims): W.paste(im, ((k % 2) * w, (k // 2) * h))
W.resize((w, h)).save(os.path.join(lib.W, f"show_{tag}.png")); print("ok")
