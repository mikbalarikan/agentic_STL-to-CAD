"""Close-up renders of a scan region. argv: mesh(out_scan|inn_scan|out_cad|inn_cad) tag cx,cy,cz half dir(x,y,z) [more...]
Clips the mesh to a box of +-half around the centre, renders from dir."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import pyvista as pv
pv.OFF_SCREEN = True
name = sys.argv[1]
v, f = lib.load(name, 1500000) if "scan" in name else lib.load(name)
mesh = pv.PolyData(v, np.hstack([np.full((len(f), 1), 3), f]).ravel())
os.makedirs(os.path.join(lib.W, "zoom"), exist_ok=True)
for spec in sys.argv[2:]:
    tag, c, h, d = spec.split("@")
    c = np.array([float(t) for t in c.split(",")]); h = float(h); d = np.array([float(t) for t in d.split(",")])
    sub = mesh.clip_box([c[0] - h, c[0] + h, c[1] - h, c[1] + h, c[2] - h, c[2] + h], invert=False)
    p = pv.Plotter(window_size=(1000, 1000))
    p.add_mesh(sub, color="lightsteelblue", specular=0.5, smooth_shading=False)
    p.add_axes()
    p.camera.focal_point = c; p.camera.position = c + 4 * h * d / np.linalg.norm(d)
    p.camera.up = (0, 1, 0) if abs(d[2]) > 0.8 * np.linalg.norm(d) else (0, 0, 1)
    p.screenshot(os.path.join(lib.W, "zoom", f"{name}_{tag}.png")); p.close()
print("ok")
