"""Surface quality views of an STL: glossy render from the knee-top angle + zebra stripes (reflection-line style:
stripes of the normal's component along a fixed direction). argv: stl tag"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import trimesh
import pyvista as pv
pv.OFF_SCREEN = True
stl, tag = sys.argv[1], sys.argv[2]
m = trimesh.load(stl, process=False); m.merge_vertices()
mesh = pv.PolyData(np.asarray(m.vertices), np.hstack([np.full((len(m.faces), 1), 3), m.faces]).ravel())
mesh = mesh.compute_normals(cell_normals=False, point_normals=True, split_vertices=True, feature_angle=25)
n = mesh.point_data["Normals"]
d = np.array([0.6, -0.3, 0.75]); d /= np.linalg.norm(d)
mesh.point_data["zebra"] = (np.floor((n @ d) * 18) % 2).astype(float)
out = os.path.join(lib.W, "surf"); os.makedirs(out, exist_ok=True)
views = {"knee_top": ((0.9, -0.2, 1.0), (35, 55, 80), 260), "knee_top2": ((-0.6, -0.3, 1.0), (30, 60, 80), 260),
         "knee_bot": ((0.9, -0.2, -1.0), (35, 55, -10), 260), "body": ((1, -0.6, 0.6), (40, 150, 40), 520)}
for nm, (dv, fo, dist) in views.items():
    for mode in ("gloss", "zebra"):
        p = pv.Plotter(window_size=(1400, 1000))
        if mode == "gloss":
            p.add_mesh(mesh, color="#a9bccf", smooth_shading=True, specular=1.0, specular_power=40)
        else:
            p.add_mesh(mesh, scalars="zebra", cmap="gray", smooth_shading=True, show_scalar_bar=False)
        dv_ = np.array(dv, float); fo_ = np.array(fo, float)
        p.camera.focal_point = fo_; p.camera.position = fo_ + dist * dv_ / np.linalg.norm(dv_); p.camera.up = (0, 0, 1)
        p.screenshot(os.path.join(out, f"{tag}_{nm}_{mode}.png")); p.close()
print("ok")
