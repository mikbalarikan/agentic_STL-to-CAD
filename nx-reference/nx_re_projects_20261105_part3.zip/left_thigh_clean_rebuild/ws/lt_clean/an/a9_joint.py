"""Joint band widths: horizontal rays at several Z through the walls along the body (+X and -X sides) and the drum.
Gives exterior / interior wall positions per Z level -> tongue width (outer) and lip width (inner)."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
from rays import Caster

C = {n: Caster(*lib.load(n, 1500000)) for n in ("out_scan", "inn_scan")}
ZS = [33.5, 34.5, 35.0, 35.6, 35.9, 36.4, 37.5]


def probe(origin_in, d):
    """origin inside the cavity, d unit outward. Returns per scan per z: (inner face dist, outer face dist from inside)."""
    out = {}
    for n, c in C.items():
        row = []
        for z in ZS:
            o_in = np.array([origin_in[0], origin_in[1], z])
            t_in = c.hit(o_in[None], d[None])[0]               # first hit going out = inner face
            o_out = o_in + d * 200
            t_out = c.hit(o_out[None], -d[None])[0]            # first hit coming in = outer face
            row.append((t_in, 200 - t_out if np.isfinite(t_out) else np.nan))
        out[n] = row
    return out


samples = []
for y in range(80, 250, 10):
    samples.append(((40.0, float(y)), np.array([1.0, 0, 0])))
    samples.append(((40.0, float(y)), np.array([-1.0, 0, 0])))
for a in range(100, 260, 15):                      # drum, angle from +X
    d = np.array([np.cos(np.radians(a)), np.sin(np.radians(a)), 0])
    samples.append(((0.0, 0.0), d))
rows = []
for (o, d) in samples:
    r = probe(o, d)
    rows.append((o, d, r))
    s = f"o {o} d {d[:2].round(2)} |"
    for n in ("out_scan", "inn_scan"):
        s += f" {n[:3]}:"
        for z, (a, b) in zip(ZS, r[n]):
            s += f" {z}:{a:6.2f}/{b:6.2f}"
    print(s)
np.save(os.path.join(lib.W, "joint_rows.npy"), np.array(rows, dtype=object), allow_pickle=True)
