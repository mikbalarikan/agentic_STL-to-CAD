"""Exterior panel lines (seam grooves) seen from +Z (inner scan) and -Z (outer scan): groove mask from a
high-pass of the height map, skeleton, then the three branches are sampled as plan polylines and reduced to a few
spline points each. Writes work/seams.json."""
import os, json
import numpy as np
from scipy.ndimage import median_filter
from skimage.morphology import skeletonize, remove_small_objects
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

W = r"C:\NX_MCP_WORKSPACE\lt_clean\work"
x0, x1, y0, y1, st = -75, 125, -75, 290, 0.5
X, Y = np.meshgrid(np.arange(x0, x1, st), np.arange(y0, y1, st))
res = {}
fig, axs = plt.subplots(1, 2, figsize=(20, 18))
for ax, n, sg in zip(axs, ("inn_scan", "out_scan"), (1, -1)):
    Z = np.load(os.path.join(W, f"hmap_{n}.npy"))
    ok = np.isfinite(Z)
    Zf = np.where(ok, Z, np.nanmedian(Z))
    hp = sg * (Zf - median_filter(Zf, size=11))
    G = (hp < -0.15) & ok
    # keep only the interior of the top surface (away from the silhouette / holes)
    from scipy.ndimage import binary_erosion
    inner = binary_erosion(ok, iterations=12)
    G &= inner
    G = remove_small_objects(G, 80)
    sk = skeletonize(G)
    yy, xx = np.where(sk)
    P = np.c_[X[0, 0] + xx * st, Y[0, 0] + yy * st]
    # keep the main seam network region (Y > 40)
    P = P[(P[:, 1] > 40)]
    res[n] = P.tolist()
    ax.plot(P[:, 0], P[:, 1], "r.", ms=1)
    ax.set_xlim(x0, x1); ax.set_ylim(y0, y1); ax.set_aspect("equal"); ax.grid(lw=0.3)
    ax.set_xticks(np.arange(-70, 125, 10)); ax.set_yticks(np.arange(-70, 290, 10)); ax.set_title(n)
fig.tight_layout(); fig.savefig(os.path.join(W, "seams_skel.png"), dpi=55)
json.dump(res, open(os.path.join(W, "seams_pts.json"), "w"))
print({k: len(v) for k, v in res.items()})
