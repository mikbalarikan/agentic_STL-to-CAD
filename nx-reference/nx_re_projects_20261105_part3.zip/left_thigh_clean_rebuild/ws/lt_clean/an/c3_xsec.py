"""XZ sections at given Y of scans (zoom). argv: tag ys xlim zlim"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
tag = sys.argv[1]; ys = [float(a) for a in sys.argv[2].split(",")]
xl = [float(a) for a in sys.argv[3].split(",")]; zl = [float(a) for a in sys.argv[4].split(",")]
axis = int(os.environ.get("AXIS", 1))
M = {n: lib.load(n, 1500000) for n in ("out_scan", "inn_scan")}
n = len(ys); nc = min(n, int(os.environ.get("NC", 4))); nr = (n + nc - 1) // nc
sc = 0.13
fig, axs = plt.subplots(nr, nc, figsize=(nc * (xl[1] - xl[0]) * sc, nr * (zl[1] - zl[0]) * sc), squeeze=False)
for ax, y in zip(axs.ravel(), ys):
    for k, colr in (("out_scan", "tab:blue"), ("inn_scan", "tab:red")):
        v, f = M[k]
        s = lib.section(v, f, axis, y)
        ij = [a for a in range(3) if a != axis]
        ax.add_collection(LineCollection(s[:, :, ij], colors=colr, lw=0.8))
    ax.set_xlim(*xl); ax.set_ylim(*zl); ax.set_aspect("equal"); ax.set_title(f"{'XYZ'[axis]} {y}")
    ax.set_xticks(np.arange(xl[0], xl[1] + 1, 5)); ax.set_yticks(np.arange(zl[0], zl[1] + 1, 5)); ax.grid(lw=0.3)
    ax.tick_params(labelsize=6)
fig.tight_layout(); fig.savefig(os.path.join(lib.W, f"xs_{tag}.png"), dpi=60); print("ok")
