"""Height map of the exterior seen from +Z (inner scan top) and -Z (outer scan bottom) near the knee."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
from rays import Caster
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

x0, x1, y0, y1, st = -75, 125, -75, 290, 0.5
X, Y = np.meshgrid(np.arange(x0, x1, st), np.arange(y0, y1, st))
fig, axs = plt.subplots(1, 2, figsize=(22, 18))
for ax, (n, zs, d, lo, hi) in zip(axs, (("inn_scan", 200, -1, 80, 112), ("out_scan", -200, 1, -42, -10))):
    v, f = lib.load(n, 1500000)
    C = Caster(v, f)
    o = np.c_[X.ravel(), Y.ravel(), np.full(X.size, zs)]
    t = C.hit(o, np.tile([0, 0, d], (X.size, 1)))
    Z = (zs + d * t).reshape(X.shape)
    np.save(os.path.join(lib.W, f"hmap_{n}.npy"), Z)
    im = ax.imshow(Z, origin="lower", extent=(x0, x1, y0, y1), cmap="viridis", vmin=lo, vmax=hi)
    lv = np.arange(lo, hi, 0.25)
    ax.contour(X, Y, Z, levels=lv, colors="k", linewidths=0.3)
    gy, gx = np.gradient(Z, st)
    g = np.hypot(gx, gy)
    ax.imshow(np.where(g > 0.6, 1.0, np.nan), origin="lower", extent=(x0, x1, y0, y1), cmap="Reds", alpha=0.5)
    ax.set_title(n); plt.colorbar(im, ax=ax, shrink=0.5); ax.grid(lw=0.3)
fig.tight_layout(); fig.savefig(os.path.join(lib.W, "hmap_knee.png"), dpi=60)
print("ok")
