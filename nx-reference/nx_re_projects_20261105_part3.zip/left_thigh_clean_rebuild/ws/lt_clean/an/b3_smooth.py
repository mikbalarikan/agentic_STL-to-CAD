"""Fair the loft: longitudinal smoothing of the section poles across stations (2nd difference along Y, non-uniform
spacing), weighted so the well-fitted body stations hold and the knee stations follow; then a preview surface
(cubic interpolation across stations, B-spline around) with zebra renders, before anything goes to NX.
argv: in_json out_json tag [mu] """
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import b1_fit as b1
from scipy.interpolate import CubicSpline
import pyvista as pv
pv.OFF_SCREEN = True

src, dst, tag = sys.argv[1], sys.argv[2], sys.argv[3]
mu = float(sys.argv[4]) if len(sys.argv) > 4 else 30.0
WV = float(os.environ.get("WV", 1.0))
NU = float(os.environ.get("NU", 0.0))
WB = float(os.environ.get("WB", 1000.0))
d = json.load(open(src))
S = d["sections"]
Y = np.array([s["y"] for s in S])
C0 = np.array([[[p[0], p[2]] for p in s["poles"]] for s in S])      # (ns, np, 2) x,z
ns, npl, _ = C0.shape
# per-pole weights: body stations fixed; knee stations: poles that shape visible surface hold, hidden poles are free
dr = d["drum"]; tn = np.tan(np.radians(1.7))
def inside_margin(x, y, z):
    R = dr["Rp"] - np.abs(np.clip(z, dr["zbot"], dr["ztop"]) - dr["zp"]) * tn
    return np.minimum(np.minimum(R - np.hypot(x, y), dr["ztop"] - z), z - dr["zbot"])
uu = (np.arange(npl) + 0.0) / npl
Bp = b1.bspline_basis((np.arange(npl * 8) + 0.5) / (npl * 8), npl)
W = np.ones((ns, npl))
for k in range(ns):
    if Y[k] >= 70:
        W[k] = WB if Y[k] < 280 else 1000.0
        continue
    cur = Bp @ C0[k]
    m = inside_margin(cur[:, 0], np.full(len(cur), Y[k]), cur[:, 1])
    # pole p influences samples p-2..p+1 (cubic); visible if any influenced sample is outside the drum (margin < 0.8)
    for p_ in range(npl):
        idx = [((p_ - 2 + j) % npl) * 8 + q for j in range(4) for q in range(8)]
        W[k, p_] = WV if (m[idx] < 0.8).any() else 0.01
D = np.zeros((ns - 2, ns))
for k in range(1, ns - 1):
    h0, h1 = Y[k] - Y[k - 1], Y[k + 1] - Y[k]
    D[k - 1, k - 1] = 2 / (h0 * (h0 + h1)); D[k - 1, k] = -2 / (h0 * h1); D[k - 1, k + 1] = 2 / (h1 * (h0 + h1))
hbar = np.mean(np.diff(Y))
hidden0 = []
for k in range(ns):
    cur = Bp @ C0[k]
    hidden0.append(inside_margin(cur[:, 0], np.full(len(cur), Y[k]), cur[:, 1]) > 0.8)
for it in range(60):
    # joint solve: data weights + longitudinal 2nd difference + circumferential 2nd difference (knee stations)
    N = ns * npl
    idx = lambda k, p_: k * npl + p_
    Wd = np.diag(W.ravel())
    LY = np.kron(D, np.eye(npl))                                    # (ns-2)*npl x N
    Dt = np.zeros((npl, npl))
    for p_ in range(npl):
        Dt[p_, p_] = -2; Dt[p_, (p_ - 1) % npl] = 1; Dt[p_, (p_ + 1) % npl] = 1
    knee = np.diag((Y < 70).astype(float))
    LT = np.kron(knee, Dt)
    A = Wd + mu * hbar ** 4 * LY.T @ LY + NU * LT.T @ LT
    rhs = Wd @ C0.reshape(N, 2)
    C = np.linalg.solve(A, rhs).reshape(ns, npl, 2)
    bad = 0
    for k in range(ns):
        if Y[k] >= 70:
            continue
        cur = Bp @ C[k]
        m = inside_margin(cur[:, 0], np.full(len(cur), Y[k]), cur[:, 1])
        viol = hidden0[k] & (m < 0.5)          # was hidden, now pokes out (or nearly)
        if viol.any():
            for sidx in np.where(viol)[0]:
                p_ = (sidx // 8 + 1) % npl
                for j in (-1, 0, 1, 2):
                    W[k, (p_ + j) % npl] = min(W[k, (p_ + j) % npl] * 3, 1000.0)
            bad += int(viol.sum())
    if bad == 0:
        break
print("constraint iterations", it + 1, "violating samples left", bad)
for k in range(ns):
    if Y[k] < 70:
        cur = Bp @ C[k]
        m = inside_margin(cur[:, 0], np.full(len(cur), Y[k]), cur[:, 1])
        v = hidden0[k] & (m < 0.5)
        print(f"   station {Y[k]}: hidden samples poking (<0.5 margin) {v.sum()}, min margin of hidden {m[hidden0[k]].min():.2f}")
uu_ = np.linspace(0, 1, 2000, endpoint=False); Bq = b1.bspline_basis(uu_, npl)
rmin = []
for k in range(ns):
    P_ = Bq @ C[k]; d1 = np.gradient(P_, axis=0); d2 = np.gradient(d1, axis=0)
    kk = np.abs(d1[:, 0] * d2[:, 1] - d1[:, 1] * d2[:, 0]) / np.linalg.norm(d1, axis=1) ** 3
    rmin.append(round(float(1 / kk.max()), 2))
print("min radius per station", list(zip(Y.tolist(), rmin)))
mv = np.linalg.norm(C - C0, axis=2)
for k in range(ns):
    print(f"Y {Y[k]:7.1f}  pole move max {mv[k].max():.2f} mean {mv[k].mean():.2f}")
out = dict(d)
out["sections"] = [{"y": float(Y[k]), "poles": [[float(c[0]), float(Y[k]), float(c[1])] for c in C[k]]} for k in range(ns)]
json.dump(out, open(dst, "w"), indent=1)

# ---- preview surface
nu, nv = 240, 400
u = np.linspace(0, 1, nu, endpoint=False)
B = b1.bspline_basis(u, npl)                                   # (nu, np)
Pts = np.einsum("up,kpc->kuc", B, C)                           # (ns, nu, 2) section curves
yy = np.linspace(Y[0], Y[-1], nv)
cs = CubicSpline(Y, Pts, axis=0, bc_type="natural")
G = cs(yy)                                                     # (nv, nu, 2)
X = G[:, :, 0]; Zs = G[:, :, 1]; YY = np.repeat(yy[:, None], nu, axis=1)
grid = pv.StructuredGrid(np.c_[X, X[:, :1]], np.c_[YY, YY[:, :1]], np.c_[Zs, Zs[:, :1]])
surf = grid.extract_surface().triangulate()
dr = d["drum"]; t = np.tan(np.radians(1.7))
drum = pv.Cylinder(center=(0, 0, (dr["ztop"] + dr["zbot"]) / 2), direction=(0, 0, 1), radius=dr["Rp"],
                   height=dr["ztop"] - dr["zbot"], resolution=240).triangulate()
surf = surf.compute_normals(point_normals=True, cell_normals=False, auto_orient_normals=True)
nrm = surf.point_data["Normals"]
dd = np.array([0.6, -0.3, 0.75]); dd /= np.linalg.norm(dd)
surf.point_data["zebra"] = (np.floor((nrm @ dd) * 18) % 2).astype(float)
outd = os.path.join(lib.W, "surf"); os.makedirs(outd, exist_ok=True)
for nm, (dv, fo, dist) in {"knee_top": ((0.9, -0.2, 1.0), (35, 55, 80), 260), "body": ((1, -0.6, 0.6), (40, 150, 40), 520),
                           "knee_bot": ((0.9, -0.2, -1.0), (35, 55, -10), 260), "mx": ((-1, 0.2, 0.5), (0, 100, 35), 450), "px": ((1, -0.3, 0.35), (60, 120, 35), 420)}.items():
    p = pv.Plotter(window_size=(1400, 1000))
    p.add_mesh(surf, scalars="zebra", cmap="gray", smooth_shading=True, show_scalar_bar=False)
    p.add_mesh(drum, color="#c8a882", smooth_shading=True)
    dv_ = np.array(dv, float); fo_ = np.array(fo, float)
    p.camera.focal_point = fo_; p.camera.position = fo_ + dist * dv_ / np.linalg.norm(dv_); p.camera.up = (0, 0, 1)
    p.screenshot(os.path.join(outd, f"pre_{tag}_{nm}.png")); p.close()
# protrusion of the preview out of the drum top / bottom faces (inside the drum footprint)
sp = np.asarray(surf.points)
inR = np.hypot(sp[:, 0], sp[:, 1]) < dr["Rp"] - 3.5
_i = np.argmax(np.where(inR, sp[:, 2], -1e9)); _j = np.argmin(np.where(inR, sp[:, 2], 1e9))
print("   highest inside footprint at", sp[_i].round(2), " lowest at", sp[_j].round(2))
print("preview over drum top (max z - ztop):", round(float((sp[inR, 2] - dr["ztop"]).max()), 3),
      " under drum bottom:", round(float((dr["zbot"] - sp[inR, 2]).max()), 3))
# deviation of the preview to the scans' exterior (body + knee fairing outside the drum)
from rays import Caster
import open3d as o3d
sc = o3d.t.geometry.RaycastingScene()
sv = np.asarray(surf.points, np.float32); sf = surf.faces.reshape(-1, 4)[:, 1:].astype(np.uint32)
sc.add_triangles(o3d.core.Tensor(sv), o3d.core.Tensor(sf))
ext = np.load(os.path.join(lib.W, "ext.npz"))
P = []
for k in ext.files:
    y = float(k); e = ext[k][:, :2]
    P.append(np.c_[e[:, 0], np.full(len(e), y), e[:, 1]])
P = np.vstack(P)
R = np.hypot(P[:, 0], P[:, 1])
inside_drum = (R < dr["Rp"] + 0.5) & (P[:, 2] > dr["zbot"] - 0.5) & (P[:, 2] < dr["ztop"] + 0.5)
Q = P[~inside_drum]
dq = sc.compute_distance(o3d.core.Tensor(Q.astype(np.float32))).numpy()
for lo, hi in ((-70, 70), (70, 290)):
    m = (Q[:, 1] >= lo) & (Q[:, 1] < hi)
    print(f"preview dev Y {lo}..{hi}: p50 {np.median(dq[m]):.3f} p90 {np.percentile(dq[m],90):.3f} p95 {np.percentile(dq[m],95):.3f}")
