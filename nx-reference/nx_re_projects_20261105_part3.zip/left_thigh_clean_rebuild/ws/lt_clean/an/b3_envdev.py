"""Deviation of a CAD envelope STL against the scans' exterior. argv: cad_stl tag
Exterior scan points = scan triangles whose closest CAD point is within 4 mm and whose normal agrees (>0.7).
Signed distance = (scan point - closest CAD point) . CAD normal  (+ = scan outside the CAD)."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import open3d as o3d
import trimesh
import pyvista as pv
pv.OFF_SCREEN = True

stl, tag = sys.argv[1], sys.argv[2]
m = trimesh.load(stl, process=False); m.merge_vertices()
cv, cf = np.asarray(m.vertices, float), np.asarray(m.faces)
sc = o3d.t.geometry.RaycastingScene()
sc.add_triangles(o3d.core.Tensor(cv.astype(np.float32)), o3d.core.Tensor(cf.astype(np.uint32)))
cc, cn, ca = lib.tri_data(cv, cf)
allp, alld = [], []
for n in ("out_scan", "inn_scan"):
    v, f = lib.load(n, 1500000)
    c, nn, ar = lib.tri_data(v, f)
    q = sc.compute_closest_points(o3d.core.Tensor(c.astype(np.float32)))
    p = q["points"].numpy().astype(float); tid = q["primitive_ids"].numpy()
    N = cn[tid]
    d = ((c - p) * N).sum(1)
    ok = (np.linalg.norm(c - p, axis=1) < 4) & ((nn * N).sum(1) > 0.7)
    allp.append(c[ok]); alld.append(d[ok])
P = np.vstack(allp); D = np.concatenate(alld)
print(f"{tag}: n {len(D)}  |d| p50 {np.median(np.abs(D)):.3f} p90 {np.percentile(np.abs(D),90):.3f} "
      f"p95 {np.percentile(np.abs(D),95):.3f}  within 0.25 {np.mean(np.abs(D)<0.25)*100:.1f}%  within 0.5 {np.mean(np.abs(D)<0.5)*100:.1f}%")
for y0 in range(-70, 290, 30):
    mm = (P[:, 1] >= y0) & (P[:, 1] < y0 + 30)
    if mm.sum() > 100:
        dd = D[mm]
        print(f"   y {y0:4d}..{y0+30:4d}  n {mm.sum():7d}  mean {dd.mean():+.3f}  |d| p50 {np.median(np.abs(dd)):.3f} p95 {np.percentile(np.abs(dd),95):.3f}")
np.savez(os.path.join(lib.W, f"envdev_{tag}.npz"), P=P, D=D)
cloud = pv.PolyData(P); cloud["d"] = np.clip(D, -1, 1)
for nm, d, up in (("top", (0.3, -0.5, 1), (0, 0, 1)), ("bot", (0.3, -0.5, -1), (0, 0, 1)), ("px", (1, -0.2, 0.2), (0, 0, 1)), ("mx", (-1, 0.2, 0.2), (0, 0, 1))):
    pl = pv.Plotter(window_size=(1500, 1100))
    pl.add_mesh(cloud, scalars="d", cmap="coolwarm", clim=(-1, 1), point_size=2, render_points_as_spheres=False)
    ctr = P.mean(0)
    pl.camera.focal_point = ctr; pl.camera.position = ctr + 650 * np.array(d) / np.linalg.norm(d); pl.camera.up = up
    pl.screenshot(os.path.join(lib.W, f"envdev_{tag}_{nm}.png")); pl.close()
