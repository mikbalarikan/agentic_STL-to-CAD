"""Close views of the assembled exterior (scans) - argv: name=dir(x,y,z)@focus(x,y,z)@dist ..."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import pyvista as pv
pv.OFF_SCREEN = True
src = os.environ.get("SRC", "scan")
names = ("out_scan", "inn_scan") if src == "scan" else ("out_cad", "inn_cad")
ms = []
for n, colr in zip(names, ("lightsteelblue", "wheat")):
    v, f = lib.load(n, 1500000) if "scan" in n else lib.load(n)
    ms.append((pv.PolyData(v, np.hstack([np.full((len(f), 1), 3), f]).ravel()), colr))
os.makedirs(os.path.join(lib.W, "look"), exist_ok=True)
for a in sys.argv[1:]:
    nm, rest = a.split("=", 1); d, fo, dist = rest.split("@")
    d = np.array([float(t) for t in d.split(",")]); fo = np.array([float(t) for t in fo.split(",")])
    p = pv.Plotter(window_size=(1300, 1000))
    for m, colr in ms:
        p.add_mesh(m, color=colr, specular=0.4, smooth_shading=True)
    p.camera.focal_point = fo
    p.camera.position = fo + float(dist) * d / np.linalg.norm(d)
    p.camera.up = (0, 0, 1) if abs(d[2]) < 0.9 * np.linalg.norm(d) else (0, 1, 0)
    p.screenshot(os.path.join(lib.W, "look", nm + ".png")); p.close()
print("ok")
