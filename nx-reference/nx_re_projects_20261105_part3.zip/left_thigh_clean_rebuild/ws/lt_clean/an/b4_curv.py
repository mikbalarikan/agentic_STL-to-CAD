"""Minimum principal curvature radius of the loft preview (cubic across stations), with locations. argv: sections_json"""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import b1_fit as b1
from scipy.interpolate import CubicSpline
d = json.load(open(sys.argv[1])); S = d["sections"]
Y = np.array([s["y"] for s in S]); C = np.array([[[p[0], p[2]] for p in s["poles"]] for s in S]); npl = C.shape[1]
nu, nv = 720, 1200
u = np.linspace(0, 1, nu, endpoint=False); B = b1.bspline_basis(u, npl)
Pts = np.einsum("up,kpc->kuc", B, C)
yy = np.linspace(Y[0], Y[-1], nv); G = CubicSpline(Y, Pts, axis=0, bc_type="natural")(yy)
X = np.dstack([G[:, :, 0], np.repeat(yy[:, None], nu, 1), G[:, :, 1]])     # (nv, nu, 3)
Su = (np.roll(X, -1, 1) - np.roll(X, 1, 1)) / 2; Sv = np.gradient(X, axis=0)
Suu = np.roll(X, -1, 1) - 2 * X + np.roll(X, 1, 1); Svv = np.gradient(Sv, axis=0)
Suv = np.gradient(Su, axis=0)
N = np.cross(Su, Sv); N /= np.linalg.norm(N, axis=2)[:, :, None]
E_ = (Su * Su).sum(2); F_ = (Su * Sv).sum(2); G_ = (Sv * Sv).sum(2)
L = (Suu * N).sum(2); M = (Suv * N).sum(2); Nn = (Svv * N).sum(2)
K = (L * Nn - M * M) / (E_ * G_ - F_ * F_); H = (E_ * Nn - 2 * F_ * M + G_ * L) / (2 * (E_ * G_ - F_ * F_))
kmax = np.abs(H) + np.sqrt(np.maximum(H * H - K, 0))
R = 1 / kmax
R[[0, 1, -2, -1], :] = 1e9
dr = d["drum"]
inside = (np.hypot(X[:, :, 0], X[:, :, 1]) < dr["Rp"] - 1) & (X[:, :, 2] < dr["ztop"]) & (X[:, :, 2] > dr["zbot"])
for lab, m in (("all", np.ones_like(inside)), ("outside drum", ~inside)):
    r = np.where(m, R, 1e9); i = np.unravel_index(np.argmin(r), r.shape)
    print(f"{lab}: min radius {r[i]:.2f} at {X[i].round(1)}  count<5: {(r<5).sum()}  count<3.5: {(r<3.5).sum()}")
    idx = np.argwhere(r < 4)
    if len(idx):
        P = X[idx[:, 0], idx[:, 1]]
        print("    Y range of R<4:", P[:, 1].min().round(1), P[:, 1].max().round(1), " sample", P[::max(1, len(P)//6)].round(1).tolist())
