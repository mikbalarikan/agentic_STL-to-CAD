"""Joint map: plan sections of the scans near the joint band, plotted together so the tongue / rebate extent
along the rim loop can be read. Outer scan at Z 34.0 (full wall) and 35.6 (tongue only); inner at 36.6 (full) and
35.7 (lip only)."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection

O = lib.load("out_scan", 1500000); I = lib.load("inn_scan", 1500000)
fig, ax = plt.subplots(1, 1, figsize=(14, 24))
for (v, f), z, colr, lw in ((O, 34.0, "0.6", 0.6), (O, 35.6, "tab:blue", 1.2), (I, 36.6, "0.85", 0.6), (I, 35.75, "tab:red", 1.0)):
    s = lib.section(v, f, 2, z)
    ax.add_collection(LineCollection(s[:, :, :2], colors=colr, lw=lw))
ax.set_aspect("equal"); ax.autoscale(); ax.grid(lw=0.3)
ax.set_xticks(np.arange(-70, 130, 10)); ax.set_yticks(np.arange(-70, 300, 10))
ax.set_title("grey: outer Z34 | blue: outer Z35.6 (tongue) | light: inner Z36.6 | red: inner Z35.75 (lip)")
fig.tight_layout(); fig.savefig(os.path.join(lib.W, "jointmap.png"), dpi=55)
print("ok")
