"""Open-side depth maps: outer scan seen from +Z (first hit going down), inner scan seen from -Z (first hit going up).
Saved as npz (X, Y grid + Z) and plotted with contour levels, so the floors / pads / rib tops can be read."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
from rays import Caster
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

st = 0.4
x0, x1, y0, y1 = -72, 122, -72, 290
X, Y = np.meshgrid(np.arange(x0, x1, st), np.arange(y0, y1, st))
for n, zs, d, lo, hi in (("out_scan", 120.0, -1, -42, 40), ("inn_scan", -60.0, 1, 34, 112)):
    v, f = lib.load(n, 1500000)
    C = Caster(v, f)
    o = np.c_[X.ravel(), Y.ravel(), np.full(X.size, zs)]
    t = C.hit(o, np.tile([0, 0, d], (X.size, 1)))
    Z = (zs + d * t).reshape(X.shape)
    np.savez(os.path.join(lib.W, f"depth_{n}.npz"), X=X, Y=Y, Z=Z)
    fig, ax = plt.subplots(figsize=(20, 36))
    im = ax.imshow(Z, origin="lower", extent=(x0, x1, y0, y1), cmap="turbo", vmin=lo, vmax=hi, interpolation="nearest")
    ax.contour(X, Y, Z, levels=np.arange(lo, hi, 1.0), colors="k", linewidths=0.15)
    ax.set_xticks(np.arange(-70, 125, 5)); ax.set_yticks(np.arange(-70, 290, 5)); ax.grid(lw=0.2, color="w")
    plt.colorbar(im, ax=ax, shrink=0.3)
    ax.set_title(n)
    fig.tight_layout(); fig.savefig(os.path.join(lib.W, f"depth_{n}.png"), dpi=45)
print("ok")
