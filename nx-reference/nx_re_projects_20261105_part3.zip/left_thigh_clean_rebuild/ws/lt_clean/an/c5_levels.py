"""Level regions from a depth map: contour of |Z - level| < tol. argv: mesh level tol tag xlim ylim"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
n, lev, tol, tag = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), sys.argv[4]
xl = [float(a) for a in sys.argv[5].split(",")]; yl = [float(a) for a in sys.argv[6].split(",")]
d = np.load(os.path.join(lib.W, f"depth_{n}.npz")); X, Y, Z = d["X"], d["Y"], d["Z"]
M = (np.abs(Z - lev) < tol).astype(float)
sc = 0.16
fig, ax = plt.subplots(figsize=((xl[1] - xl[0]) * sc, (yl[1] - yl[0]) * sc))
ax.imshow(np.where(np.isfinite(Z), Z, np.nan), origin="lower", extent=(X.min(), X.max(), Y.min(), Y.max()), cmap="Greys", alpha=0.35)
ax.contour(X, Y, M, levels=[0.5], colors="r", linewidths=0.8)
ax.contour(X, Y, np.nan_to_num(Z, nan=-99), levels=np.arange(-40, 120, 2), colors="b", linewidths=0.15)
ax.set_xlim(*xl); ax.set_ylim(*yl); ax.set_aspect("equal")
ax.set_xticks(np.arange(xl[0], xl[1] + 1, 5)); ax.set_yticks(np.arange(yl[0], yl[1] + 1, 5))
ax.set_xticks(np.arange(xl[0], xl[1] + 1, 1), minor=True); ax.set_yticks(np.arange(yl[0], yl[1] + 1, 1), minor=True)
ax.grid(which="major", lw=0.4); ax.grid(which="minor", lw=0.08); ax.tick_params(labelsize=7)
ax.set_title(f"{n} level {lev} +-{tol}")
fig.tight_layout(); fig.savefig(os.path.join(lib.W, f"lev_{tag}.png"), dpi=60); print("ok")
