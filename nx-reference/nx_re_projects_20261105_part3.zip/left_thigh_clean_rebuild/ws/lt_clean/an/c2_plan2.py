"""Overlay plan sections of several meshes: argv: tag xlim ylim mesh:z:color ...  (fine grid, 1 mm minor)"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
tag = sys.argv[1]; xl = [float(a) for a in sys.argv[2].split(",")]; yl = [float(a) for a in sys.argv[3].split(",")]
W = (xl[1] - xl[0]); H = (yl[1] - yl[0]); sc = 0.16
fig, ax = plt.subplots(figsize=(W * sc, H * sc))
cache = {}
for spec in sys.argv[4:]:
    n, z, colr = spec.split(":", 2)
    if n not in cache:
        cache[n] = lib.load(n, 1500000) if "scan" in n else lib.load(n)
    v, f = cache[n]
    s = lib.section(v, f, 2, float(z))
    ax.add_collection(LineCollection(s[:, :, :2], colors=colr, lw=0.9, label=f"{n} z{z}"))
ax.set_xlim(*xl); ax.set_ylim(*yl); ax.set_aspect("equal")
ax.set_xticks(np.arange(xl[0], xl[1] + 1, 5)); ax.set_yticks(np.arange(yl[0], yl[1] + 1, 5))
ax.set_xticks(np.arange(xl[0], xl[1] + 1, 1), minor=True); ax.set_yticks(np.arange(yl[0], yl[1] + 1, 1), minor=True)
ax.grid(which="major", lw=0.4); ax.grid(which="minor", lw=0.1)
ax.tick_params(labelsize=7); ax.legend(loc="upper left", fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(lib.W, f"p2_{tag}.png"), dpi=60); print("ok")
