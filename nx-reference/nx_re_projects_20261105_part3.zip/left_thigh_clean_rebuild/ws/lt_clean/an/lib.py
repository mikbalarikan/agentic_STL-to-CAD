"""Shared data for the clean LT rebuild: reference CAD + aligned scans in the common (assembly) frame."""
import os, json
import numpy as np

ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"
W = r"C:\NX_MCP_WORKSPACE\lt_clean\work"
os.makedirs(W, exist_ok=True)

SRC = {
    "out_cad": os.path.join(ROOT, r"part 4 - Assembly\src_revB\outer\LT-OUT-001_Left_Thigh_Outer.stl"),
    "inn_cad": os.path.join(ROOT, r"part 4 - Assembly\src_revB\inner\LT-INN-001_Left_Thigh_Inner.stl"),
    "out_scan": os.path.join(ROOT, r"part 1\work\overlay\scan_in_part_frame.stl"),
    "inn_scan": os.path.join(ROOT, r"part 2 - Inner\work\overlay\scan_in_part_frame.stl"),
}


def load(name, target=None):
    """(v, f) float64 / int; cached as npz. target = decimate to this many faces (scans)."""
    tag = name if target is None else f"{name}_{target}"
    p = os.path.join(W, tag + ".npz")
    if os.path.exists(p):
        d = np.load(p)
        return d["v"], d["f"]
    import trimesh
    m = trimesh.load(SRC[name], process=False)
    m.merge_vertices()
    v, f = np.asarray(m.vertices, float), np.asarray(m.faces)
    if target and len(f) > target:
        import open3d as o3d
        om = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
        om = om.simplify_quadric_decimation(target)
        v, f = np.asarray(om.vertices, float), np.asarray(om.triangles)
    np.savez(p, v=v, f=f)
    return v, f


def section(v, f, axis, val):
    """Plane section axis=val -> segments (k,2,3)."""
    s = v[:, axis] - val
    S = s[f]
    mn, mx = S.min(1), S.max(1)
    hit = (mn < 0) & (mx > 0)
    F = f[hit]; S = S[hit]; P = v[F]
    out = np.zeros((len(F), 2, 3)); cnt = np.zeros(len(F), int)
    for i, j in ((0, 1), (1, 2), (2, 0)):
        si, sj = S[:, i], S[:, j]
        cr = (si * sj) < 0
        t = np.where(cr, si / np.where(cr, si - sj, 1), 0)
        p = P[:, i] + t[:, None] * (P[:, j] - P[:, i])
        for k in (0, 1):
            m = cr & (cnt == k)
            out[m, k] = p[m]; cnt[m] += 1; cr = cr & ~m
    return out[cnt == 2]


def tri_data(v, f):
    a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
    n = np.cross(b - a, c - a)
    ar = np.linalg.norm(n, axis=1)
    return (a + b + c) / 3, n / np.maximum(ar, 1e-12)[:, None], ar / 2
