"""Skin wall thickness: from exterior points cast a ray inward, distance to the next surface. Scans and CAD."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
from rays import Caster

rng = np.random.default_rng(1)
for n in ("out_scan", "inn_scan", "out_cad", "inn_cad"):
    v, f = lib.load(n, 1500000) if "scan" in n else lib.load(n)
    m = Caster(v, f)
    c, nn, ar = lib.tri_data(v, f)
    # exterior-ish: normal pointing away from a body centre line (x=40, z=35) in the body zone
    cx, cz = 40.0, 35.0
    d = np.c_[c[:, 0] - cx, np.zeros(len(c)), c[:, 2] - cz]
    d /= np.linalg.norm(d, axis=1)[:, None]
    ext = ((nn * d).sum(1) > 0.85) & (c[:, 1] > 60) & (c[:, 1] < 285)
    idx = rng.choice(np.where(ext)[0], 8000, p=ar[ext] / ar[ext].sum())
    o = c[idx] - nn[idx] * 0.02
    tt = m.hit(o, -nn[idx])
    t = np.full(len(idx), np.nan)
    t = tt + 0.02
    ok = np.isfinite(t) & (t < 8)
    print(n, "n", ok.sum(), "wall p10/p25/p50/p75/p90:",
          np.percentile(t[ok], [10, 25, 50, 75, 90]).round(3))
    for y0 in range(60, 285, 25):
        mm = ok & (c[idx, 1] >= y0) & (c[idx, 1] < y0 + 25)
        if mm.sum() > 30:
            print(f"   y {y0:3d}-{y0+25:3d}  n {mm.sum():4d}  p25 {np.percentile(t[mm],25):.2f}  p50 {np.median(t[mm]):.2f}  p75 {np.percentile(t[mm],75):.2f}")
