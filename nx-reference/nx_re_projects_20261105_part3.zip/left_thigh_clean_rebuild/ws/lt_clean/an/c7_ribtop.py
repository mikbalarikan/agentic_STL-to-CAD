"""Rib top level along a centre line from the depth map (median of the max of a 1 mm band). argv: mesh name x0,y0,x1,y1 ..."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
n = sys.argv[1]
d = np.load(os.path.join(lib.W, f"depth_{n}.npz")); X, Y, Z = d["X"], d["Y"], d["Z"]
x0g, y0g, st = X[0, 0], Y[0, 0], X[0, 1] - X[0, 0]
sgn = 1 if "out" in n else -1
for i in range(2, len(sys.argv), 2):
    nm = sys.argv[i]; a, b, c, e = map(float, sys.argv[i + 1].split(","))
    t = np.linspace(0.1, 0.9, 60)
    vals = []
    for tt in t:
        px, py = a + (c - a) * tt, b + (e - b) * tt
        ix, iy = int(round((px - x0g) / st)), int(round((py - y0g) / st))
        w = Z[iy - 2:iy + 3, ix - 2:ix + 3]
        vals.append(np.nanmax(w) if sgn > 0 else np.nanmin(w))
    vals = np.array(vals)
    print(f"{nm:12s} top p10/p50/p90 {np.nanpercentile(vals,10):7.2f} {np.nanmedian(vals):7.2f} {np.nanpercentile(vals,90):7.2f}  start {vals[0]:.2f} end {vals[-1]:.2f}")
