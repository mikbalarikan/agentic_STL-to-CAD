"""Ray casting with open3d (no rtree in the venv)."""
import numpy as np
import open3d as o3d


class Caster:
    def __init__(self, v, f):
        self.s = o3d.t.geometry.RaycastingScene()
        self.s.add_triangles(o3d.core.Tensor(v.astype(np.float32)), o3d.core.Tensor(f.astype(np.uint32)))

    def hit(self, o, d):
        r = np.c_[o, d].astype(np.float32)
        a = self.s.cast_rays(o3d.core.Tensor(r))
        t = a["t_hit"].numpy().astype(float)
        t[~np.isfinite(t)] = np.nan
        return t

    def sdist(self, p):
        return self.s.compute_signed_distance(o3d.core.Tensor(p.astype(np.float32))).numpy()

    def udist(self, p):
        return self.s.compute_distance(o3d.core.Tensor(p.astype(np.float32))).numpy()
