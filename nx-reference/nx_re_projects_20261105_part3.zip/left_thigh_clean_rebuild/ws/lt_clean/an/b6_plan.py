"""Plan sections (Z levels) of one mesh, big plot with a fine grid. argv: mesh z1,z2,.. tag [xlim ylim]"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
name, zs, tag = sys.argv[1], [float(a) for a in sys.argv[2].split(",")], sys.argv[3]
v, f = lib.load(name, 1500000) if "scan" in name else lib.load(name)
cols = plt.cm.tab10(np.linspace(0, 1, 10))
fig, ax = plt.subplots(1, 1, figsize=(16, 26))
for i, z in enumerate(zs):
    s = lib.section(v, f, 2, z)
    ax.add_collection(LineCollection(s[:, :, :2], colors=[cols[i % 10]], lw=0.9, label=f"z {z}"))
ax.set_aspect("equal"); ax.autoscale(); ax.grid(lw=0.3)
if len(sys.argv) > 4:
    xl = [float(a) for a in sys.argv[4].split(",")]; yl = [float(a) for a in sys.argv[5].split(",")]
    ax.set_xlim(*xl); ax.set_ylim(*yl)
x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
ax.set_xticks(np.arange(np.floor(x0 / 10) * 10, x1, 10)); ax.set_yticks(np.arange(np.floor(y0 / 10) * 10, y1, 10))
ax.legend(loc="upper left")
fig.tight_layout(); fig.savefig(os.path.join(lib.W, f"plan_{tag}.png"), dpi=55); print("ok")
