"""Package the clean rebuild: copy drawings into deliver/Drawings, copy deliver/ to the part 5 folder, zip it.
usage: package.py <asm_dwg_dir> <out_dwg_dir> <inn_dwg_dir>"""
import os, sys, shutil, zipfile
W = r"C:\NX_MCP_WORKSPACE\lt_clean"
DST_ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 5 - Clean Rebuild"
TOP = "LT-ASM-001_RevC_Left_Thigh_Clean_Rebuild"
dwg = os.path.join(W, "deliver", "Drawings")
if os.path.exists(dwg):
    shutil.rmtree(dwg)
os.makedirs(dwg)
for d in sys.argv[1:4]:
    for f in sorted(os.listdir(d)):
        if f.endswith((".pdf", ".dwg", "_dwg.prt")):
            shutil.copy2(os.path.join(d, f), os.path.join(dwg, f))
skip = lambda f: f.startswith("_") or f.endswith((".log", ".json")) and not f.startswith("fit_check")
out = os.path.join(DST_ROOT, "deliver")
if os.path.exists(out):
    shutil.rmtree(out)
pkg = os.path.join(DST_ROOT, TOP, "LT-ASM-001_RevC")
if os.path.exists(os.path.join(DST_ROOT, TOP)):
    shutil.rmtree(os.path.join(DST_ROOT, TOP))
for base, dirs, files in os.walk(os.path.join(W, "deliver")):
    rel = os.path.relpath(base, os.path.join(W, "deliver"))
    for dst in (out, pkg):
        os.makedirs(os.path.join(dst, rel), exist_ok=True)
        for f in files:
            if skip(f):
                continue
            shutil.copy2(os.path.join(base, f), os.path.join(dst, rel, f))
zp = os.path.join(DST_ROOT, TOP + ".zip")
if os.path.exists(zp):
    os.remove(zp)
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for base, dirs, files in os.walk(os.path.join(DST_ROOT, TOP)):
        rel = os.path.relpath(base, DST_ROOT)
        z.write(base, rel + "/")
        for f in sorted(files):
            z.write(os.path.join(base, f), os.path.join(rel, f))
with zipfile.ZipFile(zp) as z:
    names = z.namelist(); bad = z.testzip()
print("zip", zp, round(os.path.getsize(zp) / 1e6, 1), "MB entries", len(names), "testzip", bad)
for n in names:
    print("  ", n)
