"""Zoomed depth map with 1 mm filled bands. argv: mesh tag xlim ylim lo hi"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
n, tag = sys.argv[1], sys.argv[2]
xl = [float(a) for a in sys.argv[3].split(",")]; yl = [float(a) for a in sys.argv[4].split(",")]
lo, hi = float(sys.argv[5]), float(sys.argv[6])
d = np.load(os.path.join(lib.W, f"depth_{n}.npz")); X, Y, Z = d["X"], d["Y"], d["Z"]
sc = 0.16
fig, ax = plt.subplots(figsize=((xl[1] - xl[0]) * sc + 2, (yl[1] - yl[0]) * sc))
cs = ax.contourf(X, Y, np.clip(np.nan_to_num(Z, nan=lo), lo, hi), levels=np.arange(lo, hi + 1, 1.0), cmap="nipy_spectral")
ax.contour(X, Y, np.nan_to_num(Z, nan=lo), levels=np.arange(lo, hi + 1, 1.0), colors="k", linewidths=0.1)
plt.colorbar(cs, ax=ax, shrink=0.5)
ax.set_xlim(*xl); ax.set_ylim(*yl); ax.set_aspect("equal")
ax.set_xticks(np.arange(xl[0], xl[1] + 1, 5)); ax.set_yticks(np.arange(yl[0], yl[1] + 1, 5))
ax.grid(lw=0.3, color="w"); ax.tick_params(labelsize=7)
fig.tight_layout(); fig.savefig(os.path.join(lib.W, f"dz_{tag}.png"), dpi=60); print("ok")
