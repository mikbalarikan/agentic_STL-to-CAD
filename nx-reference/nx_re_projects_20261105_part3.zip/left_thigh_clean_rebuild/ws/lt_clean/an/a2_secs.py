"""XZ sections at Y stations: outer CAD (blue), inner CAD (red), scans (grey) - to plan the envelope."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection

M = {n: lib.load(n) for n in ("out_cad", "inn_cad")}
M.update({n: lib.load(n, 1500000) for n in ("out_scan", "inn_scan")})
col = {"out_scan": "0.75", "inn_scan": "0.75", "out_cad": "tab:blue", "inn_cad": "tab:red"}
ys = [float(a) for a in sys.argv[1].split(",")] if len(sys.argv) > 1 else \
    [-60, -30, 0, 30, 50, 70, 90, 110, 130, 150, 170, 190, 210, 230, 250, 262, 270, 276, 282, 286]
axis = int(sys.argv[2]) if len(sys.argv) > 2 else 1
tag = sys.argv[3] if len(sys.argv) > 3 else "Y"
n = len(ys); nc = 4; nr = (n + nc - 1) // nc
fig, axs = plt.subplots(nr, nc, figsize=(nc * 6, nr * 5))
for ax, y in zip(axs.ravel(), ys):
    for k in ("out_scan", "inn_scan", "out_cad", "inn_cad"):
        v, f = M[k]
        s = lib.section(v, f, axis, y)
        ij = [a for a in range(3) if a != axis]
        ax.add_collection(LineCollection(s[:, :, ij], colors=col[k], lw=0.6 if "scan" in k else 0.8))
    ax.set_title(f"{tag} = {y}")
    ax.set_aspect("equal"); ax.autoscale(); ax.grid(lw=0.3)
for ax in axs.ravel()[n:]:
    ax.axis("off")
fig.tight_layout()
fn = os.path.join(lib.W, f"secs_{tag}.png")
fig.savefig(fn, dpi=70); print(fn)
