"""r-y scatter about the hip axis (X 37.97, Z 35.18, along Y) for Y 250..290, both scans; only directions below
the axis (outer) and above (inner) plotted in separate panels."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
HX, HZ = 37.97, 35.18
fig, axs = plt.subplots(2, 1, figsize=(16, 22))
for n, colr in (("out_scan", "b"), ("inn_scan", "r")):
    v, f = lib.load(n, 1500000)
    c, nn, ar = lib.tri_data(v, f)
    dx, dz = c[:, 0] - HX, c[:, 2] - HZ
    r = np.hypot(dx, dz); a = np.degrees(np.arctan2(dz, dx))
    for ax, sel in zip(axs, ((a < -60) & (a > -120), (a > 60) & (a < 120))):
        mm = sel & (c[:, 1] > 255) & (r < 80)
        ax.plot(c[mm, 1], r[mm], ".", ms=0.6, color=colr, alpha=0.4)
for ax, t in zip(axs, ("below hip axis (-Z)", "above hip axis (+Z)")):
    ax.set_xlim(255, 290); ax.set_ylim(35, 80); ax.set_aspect("equal"); ax.grid(lw=0.3); ax.set_title(t)
    ax.set_xticks(np.arange(255, 290, 1)); ax.set_yticks(np.arange(35, 80, 1))
fig.tight_layout(); fig.savefig(os.path.join(lib.W, "hip_ry.png"), dpi=50); print("ok")
