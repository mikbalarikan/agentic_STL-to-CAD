"""Compare CAD STL vs scan in sections. argv: cad_stl scan tag axis vals xlim zlim"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib, trimesh
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
stl, scan, tag, axis = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
vals = [float(a) for a in sys.argv[5].split(",")]
xl = [float(a) for a in sys.argv[6].split(",")]; zl = [float(a) for a in sys.argv[7].split(",")]
m = trimesh.load(stl, process=False); cv, cf = np.asarray(m.vertices, float), np.asarray(m.faces)
sv, sf = lib.load(scan, 1500000)
n = len(vals); sc = 0.12
fig, axs = plt.subplots(n, 1, figsize=((xl[1] - xl[0]) * sc, n * (zl[1] - zl[0]) * sc), squeeze=False)
ij = [a for a in range(3) if a != axis]
for ax, v in zip(axs[:, 0], vals):
    ax.add_collection(LineCollection(lib.section(sv, sf, axis, v)[:, :, ij], colors="0.55", lw=1.2))
    ax.add_collection(LineCollection(lib.section(cv, cf, axis, v)[:, :, ij], colors="r", lw=0.7))
    ax.set_xlim(*xl); ax.set_ylim(*zl); ax.set_aspect("equal"); ax.grid(lw=0.3); ax.set_title(f"{'XYZ'[axis]} = {v}")
    ax.set_xticks(np.arange(xl[0], xl[1] + 1, 5)); ax.set_yticks(np.arange(zl[0], zl[1] + 1, 5)); ax.tick_params(labelsize=6)
fig.tight_layout(); fig.savefig(os.path.join(lib.W, f"cmp_{tag}.png"), dpi=60); print("ok")
