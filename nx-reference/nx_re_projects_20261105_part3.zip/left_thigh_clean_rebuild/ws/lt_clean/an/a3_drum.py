"""Knee drum: exterior radius vs Z on the knee axis (both scans), and the hip sleeve circle fit."""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib

for n in ("out_scan", "inn_scan", "out_cad", "inn_cad"):
    v, f = lib.load(n, 1500000) if "scan" in n else lib.load(n)
    c, nn, ar = lib.tri_data(v, f)
    r = np.hypot(c[:, 0], c[:, 1])
    ang = np.degrees(np.arctan2(c[:, 0], -c[:, 1]))  # 0 = -Y (away from the body)
    radial = (c[:, 0] * nn[:, 0] + c[:, 1] * nn[:, 1]) / np.maximum(r, 1e-9)
    m = (r > 60) & (np.abs(ang) < 60) & (radial > 0.9)
    print(n)
    for z0 in np.arange(-16, 96, 4):
        mm = m & (c[:, 2] >= z0) & (c[:, 2] < z0 + 4)
        if mm.sum() > 50:
            rr = r[mm]
            print(f"  z {z0:5.1f}..{z0+4:5.1f}  n {mm.sum():6d}  r p50 {np.median(rr):7.3f}  p90 {np.percentile(rr, 90):7.3f}  max {rr.max():7.3f}")
    # hip sleeve: Y > 279, radius about the hip axis
    hx, hz = 37.97, 35.18
    rh = np.hypot(c[:, 0] - hx, c[:, 2] - hz)
    radh = ((c[:, 0] - hx) * nn[:, 0] + (c[:, 2] - hz) * nn[:, 2]) / np.maximum(rh, 1e-9)
    for y0 in (277, 279, 281, 283, 285, 286.5):
        mm = (c[:, 1] > y0) & (c[:, 1] < y0 + 1.5) & (radh > 0.9) & (rh > 55)
        if mm.sum() > 50:
            P = c[mm][:, [0, 2]]
            A = np.c_[2 * P, np.ones(len(P))]
            sol = np.linalg.lstsq(A, (P ** 2).sum(1), rcond=None)[0]
            R = np.sqrt(sol[2] + sol[0] ** 2 + sol[1] ** 2)
            res = np.hypot(P[:, 0] - sol[0], P[:, 1] - sol[1]) - R
            print(f"  hip y {y0}: n {mm.sum()} centre ({sol[0]:.2f},{sol[1]:.2f}) R {R:.3f} res p95 {np.percentile(np.abs(res),95):.3f}")
