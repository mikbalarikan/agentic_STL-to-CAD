"""Tongue / rebate extent along the interior loop of the new shell at the rim plane.
Interior loop = section of the shell STL at Z 34.76 (inner loop). For each loop point p with outward normal n
(towards the wall), sample the outer scan's section at Z 35.6 near p + 0.8 n (tongue material) and the inner scan's
section at Z 35.75 near p + 0.8 n (lip material there means NO rebate).  argv: shell_stl"""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib
import trimesh
from scipy.spatial import cKDTree
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

m = trimesh.load(sys.argv[1], process=False); m.merge_vertices()
v, f = np.asarray(m.vertices, float), np.asarray(m.faces)
seg = lib.section(v, f, 2, 34.76)[:, :, :2]
# chain the segments into loops
from collections import defaultdict
key = lambda p: (round(p[0], 4), round(p[1], 4))
adj = defaultdict(list)
for a, b in seg:
    adj[key(a)].append(key(b)); adj[key(b)].append(key(a))
seen = set(); loops = []
for s in list(adj):
    if s in seen:
        continue
    loop = [s]; seen.add(s); cur = s; prev = None
    while True:
        nx_ = [q for q in adj[cur] if q != prev and q not in seen]
        if not nx_:
            break
        prev, cur = cur, nx_[0]; loop.append(cur); seen.add(cur)
    if len(loop) > 50:
        loops.append(np.array(loop))
L = sorted(loops, key=lambda a: -len(a))
print("loops", [len(a) for a in L])
me = trimesh.load(sys.argv[1].replace("t1_shell", "t1_env"), process=False); me.merge_vertices()
ext = lib.section(np.asarray(me.vertices, float), np.asarray(me.faces), 2, 34.76)[:, :, :2].mean(1)
te = cKDTree(ext)
loop = L[0]
de, _ = te.query(loop)
ins = de > 2.0
# the interior run = longest cyclic run of ins
idx = np.where(ins)[0]
# rotate so that the loop starts at an exterior point
st = np.where(~ins)[0][0]
loop = np.roll(loop, -st, axis=0); ins = np.roll(ins, -st)
ii = np.where(ins)[0]
inner = loop[ii[0]:ii[-1] + 1]
print("interior points", len(inner))
# resample every 1 mm
d = np.r_[0, np.cumsum(np.linalg.norm(np.diff(inner, axis=0), axis=1))]
s = np.arange(0, d[-1], 1.0)
P = np.c_[np.interp(s, d, inner[:, 0]), np.interp(s, d, inner[:, 1])]
T = np.gradient(P, axis=0); T /= np.linalg.norm(T, axis=1)[:, None]
N = np.c_[T[:, 1], -T[:, 0]]
_, k = te.query(P)
sgn = np.sign(((ext[k] - P) * N).sum(1)).mean()
N = N * sgn                               # towards the wall / exterior
res = {}
for nm, z, colr in (("out_scan", 35.6, "b"), ("inn_scan", 35.75, "r")):
    vv, ff = lib.load(nm, 1500000)
    sg = lib.section(vv, ff, 2, z)[:, :, :2].mean(1)
    tr = cKDTree(sg)
    for off in (0.0, 1.65, 2.0):
        dd, _ = tr.query(P + off * N)
        res[f"{nm}_{off}"] = dd
tongue = (res["out_scan_0.0"] < 0.45) & (res["out_scan_1.65"] < 0.45)
# lip of the inner sits in the outer part of the wall; at 0.8 from the inside face: inner material there = no rebate
rebate = (res["inn_scan_0.0"] > 0.6) & (res["inn_scan_2.0"] < 0.45)
np.savez(os.path.join(lib.W, "tongue_loop.npz"), P=P, N=N, s=s, tongue=tongue, rebate=rebate)


def runs(mask):
    out = []; i = 0; n = len(mask)
    while i < n:
        if mask[i]:
            j = i
            while j + 1 < n and mask[j + 1]:
                j += 1
            out.append((i, j)); i = j + 1
        else:
            i += 1
    return out


for nm, mk in (("tongue (outer)", tongue), ("rebate (inner)", rebate)):
    print(nm)
    for i, j in runs(mk):
        if j - i > 4:
            print(f"   s {s[i]:6.0f}..{s[j]:6.0f}  len {j-i:4d}  from ({P[i,0]:7.2f},{P[i,1]:7.2f}) to ({P[j,0]:7.2f},{P[j,1]:7.2f})")
fig, ax = plt.subplots(figsize=(14, 24))
ax.plot(P[:, 0], P[:, 1], "-", color="0.7", lw=0.5)
ax.plot(P[tongue, 0], P[tongue, 1], "b.", ms=3, label="tongue (outer scan)")
ax.plot(P[rebate, 0] + 1.5 * N[rebate, 0], P[rebate, 1] + 1.5 * N[rebate, 1], "r.", ms=2, label="rebate (inner scan)")
for k in range(0, len(P), 50):
    ax.text(P[k, 0], P[k, 1], f"{s[k]:.0f}", fontsize=7)
ax.set_aspect("equal"); ax.grid(lw=0.3); ax.legend()
fig.tight_layout(); fig.savefig(os.path.join(lib.W, "tongue_loop.png"), dpi=55)
