"""Interior feature helpers: fully constrained sketches of circles / centre-line segments on the XY datum plane,
extruded along Z between two levels (tools overshoot the skin; one CLIP_TO_ENVELOPE intersect trims them)."""
import NXOpen
import nxh, nxf

P3 = NXOpen.Point3d


def sketch(part, D, name):
    return nxf.new_sketch(part, D.xy, D.x, D.origin, name=name)


def circle(part, sk, x, y, d):
    return nxf.sketch_circle(part, sk, nxh.point(part, float(x), float(y), 0.0), d)


def segment(part, sk, a, b):
    """line a -> b (plan points), both ends held on smart points: DOF 0."""
    pa, pb = nxh.point(part, float(a[0]), float(a[1]), 0.0), nxh.point(part, float(b[0]), float(b[1]), 0.0)
    ln = part.Curves.CreateLine(P3(float(a[0]), float(a[1]), 0.0), P3(float(b[0]), float(b[1]), 0.0))
    nxf.add(sk, ln, infer=False)
    aa, ab = nxf.sketch_anchor(part, sk, pa), nxf.sketch_anchor(part, sk, pb)
    sk.CreateCoincidentConstraint(nxf.cg(ln, nxf.CP.StartVertex), nxf.cg(aa))
    sk.CreateCoincidentConstraint(nxf.cg(ln, nxf.CP.EndVertex), nxf.cg(ab))
    return ln


def finish(sk):
    return nxf.finish_sketch(sk)


def extrude_z(part, sk, z0, z1, op=None, target=None, thin=None, name=None):
    """extrude the whole sketch along +Z from level z0 to z1 (formulas allowed)."""
    f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), (0, 0, 1),
                       start=z0, end=z1, op=op, target=target, thin=thin)
    if name:
        f.SetName(name)
    return f


def main_body(part):
    return [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked][0]


def envelope_ref(part):
    return [b for b in part.Bodies if b.IsSolidBody and b.IsBlanked][0]


def feat(part, name):
    return [f for f in part.Features.GetFeatures() if f.Name == name][0]
