import os, sys, traceback
for k in ("NXH_DIR", "NXCK_DIR", "NXRE_DIR"):
    sys.path.insert(0, os.environ[k])
import NXOpen, nxh, nxre
src, out = sys.argv[1], sys.argv[2]
res = {}
try:
    part = nxh.open_part(src)
    for i, b in enumerate([b for b in part.Bodies if b.IsSolidBody]):
        nxre.stl_export(part, b, os.path.join(out, f"body{i}{'_blank' if b.IsBlanked else ''}.stl"), chord=0.02)
        fl = []
        for f in b.GetFaces():
            p, n = nxh.face_mid_normal(f)
            fl.append((str(f.SolidFaceType), [round(c, 2) for c in p], [round(c, 3) for c in n]))
        res[f"body{i}"] = {"vol": nxh.volume(part, b), "faces": fl, "blank": b.IsBlanked}
    res["features"] = [(f.Name or f.FeatureType, f.FeatureType) for f in part.Features.GetFeatures()]
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(out, "insp.json"), res)
