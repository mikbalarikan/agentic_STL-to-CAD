

# ====================================================================== exterior panel lines
def seams(ctx):
    """panel lines: plan splines (scan-measured, same plan on top and bottom) projected along Z onto the
    exterior skin of this part, a D1.25 tube along each projection subtracted (groove 1.25 wide, 0.62 deep)."""
    import json as _json
    import curvekit as ck
    part = ctx["part"]
    data = _json.load(open("C:/NX_MCP_WORKSPACE/lt_clean/work/seams.json"))
    out = ctx["out"]
    zs, vec = (-200.0, (0, 0, 1)) if out else (200.0, (0, 0, -1))
    ex(ctx, "seam_D", 1.25, "panel line groove (tube diameter)")
    body = E(ctx)
    names = _creator_names(part, body)
    skin = [fc for fc in body.GetFaces() if names.get(fc.Tag) == "BODY_LOFT"]
    ctx["step"]("seam_faces", n=len(skin))
    for nm, pts in data.items():
        f, sp = ck.studio_spline(part, [(x, y, zs) for x, y in pts], degree=3)
        f.SetName("SEAM_%s_PLAN" % nm)
        b = part.Features.CreateProjectCurveBuilder(NXOpen.Features.Feature.Null)
        try:
            PB = NXOpen.Features.ProjectCurveBuilder
            b.Tolerance = 0.01
            nxh.fill_section(part, b.SectionToProject, curves=[sp])
            b.FaceToProjectTo.Add(nxh.collector(part, faces=skin))
            b.ProjectionDirectionMethod = PB.DirectionType.AlongVector
            b.ProjectionVector = nxh.direction(part, vec)
            b.InputCurvesOption.Associative = True
            fp = b.Commit()
        finally:
            b.Destroy()
        fp.SetName("SEAM_%s_ON_SKIN" % nm)
        cs = [e for e in fp.GetEntities() if isinstance(e, NXOpen.Curve)]
        ft, tb = nxf.tube(part, "seam_D", curves=cs)
        ft.SetName("SEAM_%s_TUBE" % nm)
        fs = nxh.subtract(part, E(ctx), [tb])
        try:
            fs.SetName("SEAM_%s_GROOVE" % nm)
        except Exception:
            pass
        ctx["step"]("SEAM_" + nm, n_curves=len(cs), length=round(sum(c.GetLength() for c in cs), 1), v=vol(ctx))
