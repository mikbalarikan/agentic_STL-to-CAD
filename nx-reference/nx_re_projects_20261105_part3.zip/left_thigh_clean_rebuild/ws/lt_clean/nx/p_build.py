"""Run feature stages on a copy of a part. argv: which(out|inn) src_prt out_dir stage1,stage2,..."""
import os, sys, time, shutil, traceback, json
for k in ("NXH_DIR", "NXCK_DIR", "NXRE_DIR"):
    sys.path.insert(0, os.environ[k])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean\nx")
import NXOpen
import nxh, nxf, nxre
import ltint as I
import stages as ST

WHICH, SRC, OUT, LIST = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4].split(",")
os.makedirs(OUT, exist_ok=True)
RJ = os.path.join(OUT, f"build_{WHICH}.json")
res = {"result": "FAIL", "stages": LIST, "steps": []}
T0 = time.time()


def step(name, **kw):
    kw["name"] = name; kw["t"] = round(time.time() - T0, 1)
    res["steps"].append(kw); nxh.write_json(RJ, res)


try:
    dst = os.path.join(OUT, os.path.basename(SRC))
    if os.path.abspath(dst) != os.path.abspath(SRC):
        shutil.copyfile(SRC, dst)
    part = nxh.open_part(dst)
    ctx = {"part": part, "D": nxh.Datums(part), "E0": I.envelope_ref(part), "out": WHICH == "out", "step": step}
    step("open", v=ST.vol(ctx))
    for s in LIST:
        m = nxh.mark("stage " + s, False)
        try:
            ST.STAGES[s](ctx)
            sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
            if len(sol) > 1:
                bodies = []
                for b in sol:
                    bb = nxh.bbox(b)
                    bodies.append([round(c, 1) for c in bb])
                step("ISLANDS after " + s, n=len(sol), bboxes=bodies)
        except Exception:
            step("STAGE_FAILED " + s, error=traceback.format_exc()[-1500:])
            raise
    E = I.main_body(part)
    step("done", v=ST.vol(ctx), ok=nxh.body_ok(part, E), census=str(nxh.face_census(E)),
         n_solids=len([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]))
    nxre.stl_export(part, E, os.path.join(OUT, f"{WHICH}.stl"), chord=0.01)
    err = nxh.feature_errors(part)
    step("errors", errors=str(err))
    nxh.save(part)
    res["result"] = "PASS" if not err else "FAIL"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(RJ, res)
