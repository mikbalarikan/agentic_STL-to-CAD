

# ====================================================================== screw tabs and clip (user-marked details of the
# earlier revisions, same positions; outer tab D / inner lug D and outer tab C / inner lug 3 are pairs across the gap)
R2_ = math.sqrt(0.5)


def _plane3(ctx, name, p0, n):
    """datum plane through p0 with normal n (three points, associative to nothing: a fixed design plane)."""
    part = ctx["part"]
    a = (p0[0], p0[1], p0[2])
    t1 = (-n[1], n[0], 0.0) if abs(n[2]) < 0.9 else (1.0, 0.0, 0.0)
    t2 = (n[1] * t1[2] - n[2] * t1[1], n[2] * t1[0] - n[0] * t1[2], n[0] * t1[1] - n[1] * t1[0])
    pts = [nxh.point(part, *map(float, a)), nxh.point(part, *map(float, [a[i] + 10 * t1[i] for i in range(3)])),
           nxh.point(part, *map(float, [a[i] + 10 * t2[i] for i in range(3)]))]
    f, pl = nxf.datum_plane(part, "three_points", pts, name=name)
    return pl


def _slab(ctx, name, plane, pts, vec, t, op=None):
    part = ctx["part"]
    sk = nxf.new_sketch(part, plane, ctx["D"].z if abs(vec[2]) < 0.9 else ctx["D"].x, ctx["D"].origin, name="SK_" + name)
    poly(part, sk, pts)
    st = I.finish(sk)
    f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), vec, start=0, end=t,
                       op=op or U, target=E(ctx))
    f.SetName(name)
    ctx["step"](name, sketch=str(st), v=vol(ctx))
    return f


def _hole(ctx, name, plane, centre, d, vec, depth):
    part = ctx["part"]
    sk = nxf.new_sketch(part, plane, ctx["D"].z if abs(vec[2]) < 0.9 else ctx["D"].x, ctx["D"].origin, name="SK_" + name)
    nxf.sketch_circle(part, sk, nxh.point(part, *map(float, centre)), d)
    I.finish(sk)
    f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), vec, start=-0.5, end=depth,
                       op=S_, target=E(ctx))
    f.SetName(name)
    ctx["step"](name, v=vol(ctx))


def tabs_out_add(ctx):
    """before the clip: clip post+head (A), 45 deg tab C beside the hip-end boss, side-wall tab D."""
    part = ctx["part"]
    ex(ctx, "tab_hole_D", 2.7, "screw hole of the outer tabs and clip ring")
    # A: post + head as one rectangle 6.9 x 12.0 (turned -4.6 deg) from the skin up to Z 4.78
    th = math.radians(-4.6); a1 = (math.cos(th), math.sin(th)); a2 = (-math.sin(th), math.cos(th)); OA = (94.42, 206.92)
    Afn = lambda x, y: (OA[0] + x * a1[0] + y * a2[0], OA[1] + x * a1[1] + y * a2[1])   # noqa: E731
    head = [Afn(-0.05 - 3.45, -6.0), Afn(-0.05 + 3.45, -6.0), Afn(-0.05 + 3.45, 6.0), Afn(-0.05 - 3.45, 6.0)]
    sk, st = plan_poly(ctx, "SK_CLIP_POST", [head])
    I.extrude_z(part, sk, BIG_LO, 4.78, op=U, target=E(ctx), name="CLIP_POST")
    ctx["step"]("CLIP_POST", sketch=str(st), v=vol(ctx))
    rails = [[Afn(-3.5, s * 6.0 - (s * 1.65 if s > 0 else -0.0)) for s in ()]]
    r1 = [Afn(-3.5, 6.0 - 1.65), Afn(3.4, 6.0 - 1.65), Afn(3.4, 6.0), Afn(-3.5, 6.0)]
    r2 = [Afn(-3.5, -6.0), Afn(3.4, -6.0), Afn(3.4, -6.0 + 1.65), Afn(-3.5, -6.0 + 1.65)]
    sk, st = plan_poly(ctx, "SK_CLIP_RAILS", [r1, r2])
    I.extrude_z(part, sk, 4.7, 7.7, op=U, target=E(ctx), name="CLIP_RAILS")
    sk = I.sketch(part, ctx["D"], "SK_CLIP_RING")
    I.circle(part, sk, OA[0], OA[1], 5.3)
    I.finish(sk)
    I.extrude_z(part, sk, 4.7, 6.2, op=U, target=E(ctx), name="CLIP_RING")
    ctx["step"]("CLIP_HEAD", v=vol(ctx))
    # C: 45 deg tab (faces u 142.92 / 145.50 along e, outline in (w, z))
    E_, D_ = (R2_, R2_, 0.0), (R2_, -R2_, 0.0)
    C3 = lambda u, w, z: (u * E_[0] + w * D_[0], u * E_[1] + w * D_[1], z)   # noqa: E731
    u0, u1 = 142.92, 145.50
    pl = _plane3(ctx, "PL_TAB_C", C3(u0, 0, 0), E_)
    _slab(ctx, "TAB_C", pl, [C3(u0, -197.0, 20.21), C3(u0, -189.78, 20.21), C3(u0, -189.78, 2.0), C3(u0, -197.0, 11.0)],
          E_, u1 - u0)
    # D: side-wall tab x -20.42..-18.03
    x0, x1 = -20.42, -18.03
    pl = _plane3(ctx, "PL_TAB_D", (x0, 0, 0), (1.0, 0.0, 0.0))
    _slab(ctx, "TAB_D", pl, [(x0, 181.5, 8.15), (x0, 191.85, 8.15), (x0, 191.85, -2.2), (x0, 181.5, 1.5)], (1.0, 0.0, 0.0), x1 - x0)


def tabs_out_cut(ctx):
    part = ctx["part"]
    sk = I.sketch(part, ctx["D"], "SK_CLIP_HOLE")
    I.circle(part, sk, 94.42, 206.92, "tab_hole_D")
    I.finish(sk)
    I.extrude_z(part, sk, 4.25, 8.0, op=S_, target=E(ctx), name="CLIP_HOLE")
    E_, D_ = (R2_, R2_, 0.0), (R2_, -R2_, 0.0)
    C3 = lambda u, w, z: (u * E_[0] + w * D_[0], u * E_[1] + w * D_[1], z)   # noqa: E731
    pl = I.feat(part, "PL_TAB_C").DatumPlane
    _hole(ctx, "TAB_C_HOLE", pl, C3(142.92, -192.66, 15.6), "tab_hole_D", E_, 3.2)
    pl = I.feat(part, "PL_TAB_D").DatumPlane
    _hole(ctx, "TAB_D_HOLE", pl, (-20.42, 188.42, 4.48), "tab_hole_D", (1.0, 0.0, 0.0), 2.9)


def tabs_inn_add(ctx):
    """before the clip: lug D under the -X wall (pair of outer tab D) and lug 3 beside P3 (pair of outer tab C)."""
    part = ctx["part"]
    ex(ctx, "lug_hole_D", 2.6, "screw hole of the inner lugs")
    xo, xi = -20.5, -17.9
    pl = _plane3(ctx, "PL_LUG_D", (xo, 0, 0), (1.0, 0.0, 0.0))
    # slanted end (Y 190.3 at xo .. 192.6 at xi) approximated by the plane outline at xo: end at 191.45 (mid)
    _slab(ctx, "LUG_D", pl, [(xo, 177.0, 62.1), (xo, 191.45, 62.1), (xo, 191.45, 80.0), (xo, 177.0, 80.0)], (1.0, 0.0, 0.0), xi - xo)
    O = (-34.0, 238.5); Uv = (0.61527086, -0.78831578); W = (0.78831578, 0.61527086, 0.0)
    stz = lambda s, t, z: (O[0] + s * Uv[0] + t * W[0], O[1] + s * Uv[1] + t * W[1], z)   # noqa: E731
    T_A, T_B = -1.65, 0.95
    pl = _plane3(ctx, "PL_LUG_3", stz(0, T_A, 0), W)
    _slab(ctx, "LUG_3", pl, [stz(-3.5, T_A, 50.08), stz(3.1, T_A, 50.08), stz(3.1, T_A, 80.0), stz(-3.5, T_A, 80.0)], W, T_B - T_A)


def tabs_inn_cut(ctx):
    part = ctx["part"]
    pl = I.feat(part, "PL_LUG_D").DatumPlane
    _hole(ctx, "LUG_D_HOLE", pl, (-20.5, 188.4, 65.6), "lug_hole_D", (1.0, 0.0, 0.0), 3.1)
    O = (-34.0, 238.5); Uv = (0.61527086, -0.78831578); W = (0.78831578, 0.61527086, 0.0)
    stz = lambda s, t, z: (O[0] + s * Uv[0] + t * W[0], O[1] + s * Uv[1] + t * W[1], z)   # noqa: E731
    pl = I.feat(part, "PL_LUG_3").DatumPlane
    _hole(ctx, "LUG_3_HOLE", pl, stz(0.05, -1.65, 54.6), "lug_hole_D", W, 3.1)
