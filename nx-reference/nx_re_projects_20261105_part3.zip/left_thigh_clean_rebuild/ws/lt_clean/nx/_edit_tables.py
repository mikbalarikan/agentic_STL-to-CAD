p = 'C:/NX_MCP_WORKSPACE/lt_clean/nx/dwg_out.py'
s = open(p, encoding='utf-8').read()
a = '''            rows.append(["H%d" % i, "%.2f" % h["x"], "%.2f" % h["y"], "FLOOR HOLE", "ON FLOOR", "%s2.6 x 6 DEEP" % DIA])'''
b = '''            rows.append(["H%d" % i, "%.2f" % h["x"], "%.2f" % h["y"], "FLOOR HOLE" + (" IN BOSS %s6" % DIA if i > 1 else ""), "0.00", "%s2.6 x 8 DEEP" % DIA])'''
assert a in s
s = s.replace(a, b)
a = '''              ["LOW HUB WALL", "7.49"], ["PADS", "33.90 / 29.55 / 28.39 / 27.67"], ["RIB TOPS", "4.97 / 4.78 / 0.00 / -5.00 / -20.29"],
              ["LONG RIB RAMP", "-13.25 (Y 166) TO -20.29 (Y 206.5)"]]'''
b = '''              ["LOW HUB WALL", "7.49"], ["RIB TOPS (FLAT)", "0.00 / -5.00"], ["RIB R1 (Y 194.42)", "22.00"],
              ["LONG RIB X 37.9", "-13.25 (Y 166) TO -20.29 (Y 206.5), THEN -20.29"],
              ["GUSSETS AT B6 / B7", "-15.50 (Y 224) TO 36.07 (Y 261.2)"]]'''
assert a in s
s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s)

p = 'C:/NX_MCP_WORKSPACE/lt_clean/nx/dwg_inn.py'
s = open(p, encoding='utf-8').read()
i0 = s.index('        for i, h in enumerate(CH, 1):\n            rows.append(["H%d"')
i1 = s.index('        rows.append(["L1", "-20.50"')
b = '''        import design as DSG
        for i, (k, (x, y)) in enumerate(DSG.CH_HOLES.items(), 1):
            rows.append(["H%d" % i, "%.2f" % x, "%.2f" % y, "CHANNEL COVER BOSS %s6" % DIA, "%.2f" % DSG.CH_RIB_BOTTOM,
                         "%s%.1f x %.0f DEEP" % (DIA, DSG.CH_HOLE_D, DSG.CH_HOLE_DEPTH)])
        for i, (k, (x, y)) in enumerate(list(DSG.KNEE_COVER_PINS.items()) + list(DSG.HIP_PINS.items()), 1):
            if k in DSG.KNEE_COVER_PINS:
                rows.append(["N%d" % i, "%.2f" % x, "%.2f" % y, "PIN %s3 x %.2f, KNEE COVER" % (DIA, DSG.N_PIN_LEN), "%.2f" % DSG.N_PIN_FACE, "-"])
            else:
                rows.append(["N%d" % i, "%.2f" % x, "%.2f" % y, "PIN %s4 x %.2f, INTO SLOT S1/S2" % (DIA, DSG.HIP_PIN_LEN), "%.2f" % DSG.HIP_PIN_FACE, "-"])
'''
s = s[:i0] + b + s[i1:]
i0 = s.index('        lv = [["FLAT LEVELS (Z IN MODEL FRAME, A = %.2f)" % ZA, ""]')
i1 = s.index('        N("table_levels", lambda: table((470.0, 300.0)')
b = '''        lv = [["FLAT LEVELS (Z IN MODEL FRAME, A = %.2f)" % ZA, ""], ["LIP FACE", "%.2f" % LIP], ["REBATE FLOOR", "%.2f" % RB],
              ["BOSS FACES (A)", "%.2f" % ZA], ["POCKET FLOORS", "%.2f" % BOSS[0]["pocket_z1"]],
              ["KNEE WINDOW LINTEL", "62.57"], ["CHANNEL RIBS / SPOKES", "75.07"], ["CHANNEL FLOOR", "76.87"],
              ["RIBS Y 166 / DIAGONAL", "75.15"], ["KNEE DISC INSIDE / OUTSIDE", "%.2f / %.2f" % (HB["cav_top"], HB["top_z"])],
              ["HIP RING PAD", "85.32"], ["UPPER RIB (X 38)", "90.57"], ["KNEE HUB TOP", "%.2f" % KB["ring_top"]]]
'''
s = s[:i0] + b + s[i1:]
s = s.replace('import gdt  # noqa: E402', 'import gdt  # noqa: E402\nsys.path.insert(0, r"C:\\NX_MCP_WORKSPACE\\lt_clean\\nx")', 1)
open(p, 'w', encoding='utf-8').write(s)
print("ok")
