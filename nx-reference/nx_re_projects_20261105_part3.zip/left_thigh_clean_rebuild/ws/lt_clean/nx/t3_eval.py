import os, sys, traceback, time
for k in ("NXH_DIR", "NXCK_DIR", "NXRE_DIR"):
    sys.path.insert(0, os.environ[k])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean\nx")
import NXOpen, nxh, ltjoint
res = {}
try:
    t0 = time.time()
    part = nxh.open_part(r"C:\NX_MCP_WORKSPACE\lt_clean\nx\base2\LT_BASE.prt")
    res["open_s"] = time.time() - t0
    b = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked][0]
    e = max(b.GetEdges(), key=lambda e: e.GetLength())
    res["mid"] = ltjoint.edge_mid(e)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(r"C:\NX_MCP_WORKSPACE\lt_clean\nx\t3\t3.json", res)
