"""Design table of the interior features (frame of both parts). Values from the drawings of the delivered
revisions and re-measured on both scans (an/c4_rib.py, joint-level overlays p2_*.png). Units mm."""

Z_A = 36.07

# screw bosses: Ø15 columns, both parts meet face to face at datum A
BOSSES = {
    "B1": (61.35, -40.01), "B2": (75.85, 29.86), "B3": (-25.10, 77.45), "B4": (-17.05, 165.91),
    "B5": (86.45, 165.96), "B6": (97.95, 264.95), "B7": (-22.00, 264.93),
}
BOSS_D = 15.0
NUB_D, NUB_TOP = 10.0, 39.04            # outer spigot
NUB_HOLE_D, NUB_HOLE_DEPTH = 5.2, 12.0  # outer, from the spigot top
POCKET_D, POCKET_FLOOR = 10.05, 39.17   # inner (Ø10 +0.10/0)
SCREW_D, CBORE_D, CBORE_FLOOR = 6.0, 10.4, 44.87   # inner: Ø6 thru, Ø10.4 counterbore from outside

# full-height arms (ribs from the bosses), width 3.0; end points per part (the scans stagger them)
ARM_W = 3.0
ARMS = {   # name: (start inside the boss, end outer, end inner)
    "ARM_B3_R": ((-25.10, 78.65), (-2.33, 78.32), (-4.17, 78.53)),
    "ARM_B3_D": ((-24.40, 75.20), (-17.00, 52.78), (-17.55, 54.51)),
    "ARM_B4_R": ((-17.05, 165.95), (-2.27, 166.08), (-4.00, 166.08)),
    "ARM_B2_D": ((73.60, 33.10), (55.16, 55.52), (56.52, 54.18)),
}
FLANGES = {  # wall-end flanges at the knee side opening, width 1.9
    "FL_KNEE_MX": ((-62.5, 29.6), (-50.33, 24.74), 1.9),
}

# locating pins (outer) in pin holes (inner): Ø4 pins on Ø9 lugs
PINS = {   # name: (x, y, outer lug top / pin base, pin top, inner lug face)
    "P1": (97.46, 131.44, 34.76, 41.98, 35.32),
    "P2": (108.97, 194.32, 34.76, 41.98, 35.32),
    "P3": (-38.09, 245.35, 36.24, 42.25, 36.36),
}
PIN_D, PIN_LUG_D, PIN_HOLE_D, PIN_HOLE_DEPTH = 4.0, 9.0, 4.0, 10.0

# hip plate (transverse wall of both parts) and the hip ring of the outer
HIP_Y0, HIP_Y1 = 266.5, 276.85

# ---- outer ribs (flat tops), centre lines, width 3.0 unless given: (p0, p1, top_z, t)
OUT_RIBS = {
    "R_TRANS_Y166": ((-2.3, 166.0), (80.0, 166.0), -5.0, 3.0),
    "R_DIAG_A": ((19.8, 75.5), (36.8, 165.0), -5.0, 3.0),
    "R_DIAG_B_UP": ((71.5, 142.0), (75.3, 165.0), -5.0, 3.0),
    "R_DIAG_B": ((53.5, 60.0), (71.5, 142.0), 0.0, 3.5),
    "R_X0": ((0.3, 79.0), (-1.9, 142.0), 0.0, 3.0),
    "R_P2_WALL": ((95.0, 194.42), (114.0, 194.42), 22.0, 2.05),
}
# sloped gussets: vertical plane through p0-p1, top line from (p0, z0) to (p1, z1)
OUT_GUSSETS = {
    "G_B7": ((-22.0, 224.0), (-22.0, 261.2), -15.5, 36.07, 3.0),
    "G_B6": ((97.95, 224.0), (97.95, 261.2), -15.5, 36.07, 3.0),
    "G_P1": ((80.0, 131.44), (97.46, 131.44), -2.3, 26.3, 3.0),
    "G_LONG_HIP": ((37.9, 166.0), (37.9, 206.5), -13.25, -20.29, 3.0),
    "G_LONG_HIP2": ((37.9, 206.5), (37.9, 266.5), -20.29, -20.29, 3.0),
}

# ---- inner ribs: free edge level (rib grows up from it to the skin)
INN_RIBS = {
    "I_TRANS_Y166": ((-4.0, 165.95), (80.0, 165.95), 75.15, 3.1),
    "I_DIAG": ((20.5, 79.0), (36.8, 165.0), 75.15, 3.1),
    "I_LONG_HIP": ((38.1, 167.0), (37.9, 266.5), 90.57, 3.1),
}
INN_GUSSETS = {   # (p0, p1, z0 at p0, z1 at p1, t)
    "IG_B7": ((-22.0, 230.0), (-22.0, 263.2), 64.9, 36.07, 4.0),
    "IG_B6": ((97.95, 230.0), (97.95, 263.2), 64.9, 36.07, 4.0),
    "IG_P1": ((80.0, 131.44), (97.46, 131.44), 75.3, 38.9, 2.2),
    "IG_P2": ((95.0, 194.32), (104.1, 194.32), 73.5, 35.3, 2.5),
    "IG_HIP_L": ((10.8, 244.4), (10.8, 266.5), 90.4, 72.6, 4.0),
    "IG_HIP_R": ((65.3, 244.4), (65.3, 266.5), 90.4, 72.6, 4.0),
}
# knee-cover locating pins of the inner (hang down from the knee window lintel), and their partner level in the outer
KNEE_COVER_PINS = {"N1": (-30.89, -51.41), "N2": (-56.68, 19.53)}
N_PIN_D, N_PIN_FACE, N_PIN_LEN = 3.0, 62.57, 6.93
# hip pins of the inner into the outer's slots S1 / S2
HIP_PINS = {"N3": (49.03, 271.72), "N4": (27.04, 271.73)}
HIP_PIN_D, HIP_PIN_FACE, HIP_PIN_LEN = 4.0, 85.32, 5.9

# ---- inner knee underside: cable channel (C around the hub + straight run up the +X side) and spokes
CH_RIB_BOTTOM, CH_FLOOR, CH_RIB_T = 75.07, 76.87, 2.5
CH_R_IN, CH_R_OUT, CH_A_TOP = 33.5, 43.5, 75.0           # ring rib centre radii, C top end angle
CH_J_IN, CH_J_OUT = (29.182, -16.452), (35.912, -24.547)  # ring -> straight rib junctions
CH_TOP_L, CH_TOP_R = (61.5, 135.0), (78.97, 135.0)        # straight ribs end (closed by a cap rib)
CH_HOLES = {"H1": (59.36, 62.33), "H2": (47.79, 70.73), "H3": (63.50, 81.86), "H4": (50.79, 84.72),
            "H5": (65.64, 91.82), "H6": (77.20, 128.43), "H7": (60.75, 131.45), "H8": (52.90, 94.40)}
CH_HOLE_D, CH_HOLE_DEPTH, CH_BOSS_D = 3.3, 6.0, 6.0
SPOKES_IN = (22.0, 108.0, 161.0, 227.0, 327.0)            # r 10.5 -> ring
SPOKES_OUT = (108.0, 161.0, 327.0)                        # ring -> drum wall
SPOKE_T, SPOKE_BOTTOM = 3.0, 75.07

# ---- small features
FLOOR_BOSSES = {"H2": (62.45, 70.06), "H3": (-6.37, 92.09), "H4": (75.27, 130.08), "H5": (-6.31, 138.10)}  # outer, top Z0
FLOOR_HOLES = {"H1": (-0.16, 58.89), **FLOOR_BOSSES}
FLOOR_BOSS_D, FLOOR_HOLE_D, FLOOR_HOLE_DEPTH = 6.0, 2.6, 8.0
OUT_COVER_PIN_BASE = 7.49     # outer knee-cover pins stand on the low drum wall
