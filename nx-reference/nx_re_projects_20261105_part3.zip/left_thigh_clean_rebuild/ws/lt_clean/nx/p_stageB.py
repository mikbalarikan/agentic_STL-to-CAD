"""Stage B: mating structure. Boss columns, arms, wall-end flange, pin lugs (overshooting tools, united), one
CLIP_TO_ENVELOPE intersect, then spigots + holes (outer) / pockets + bores + counterbores (inner), pins / pin holes.
argv: which(out|inn) stageA_prt out_dir"""
import os, sys, time, shutil, traceback
for k in ("NXH_DIR", "NXCK_DIR", "NXRE_DIR"):
    sys.path.insert(0, os.environ[k])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean\nx")
import importlib
import NXOpen
import nxh, nxf, nxre
import ltint as I
import design as DS

WHICH, SRC, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
RJ = os.path.join(OUT, f"stageB_{WHICH}.json")
res = {"result": "FAIL", "steps": []}
T0 = time.time()
BIG_LO, BIG_HI = -80, 160


def step(name, **kw):
    kw["name"] = name; kw["t"] = round(time.time() - T0, 1)
    res["steps"].append(kw); nxh.write_json(RJ, res)


def vol(part):
    return round(nxh.volume(part, I.main_body(part)), 3)


try:
    dst = os.path.join(OUT, os.path.basename(SRC))
    shutil.copyfile(SRC, dst)
    part = nxh.open_part(dst)
    D = nxh.Datums(part)
    E = I.main_body(part)
    E0 = I.envelope_ref(part)
    out = WHICH == "out"
    nxh.expr(part, "boss_D", DS.BOSS_D, "mm", "screw boss column")
    nxh.expr(part, "arm_t", DS.ARM_W, "mm", "boss arm (full-height rib) thickness")
    nxh.expr(part, "pin_lug_D", DS.PIN_LUG_D, "mm", "locating pin lug")
    v0 = vol(part)
    # ---- boss columns
    sk = I.sketch(part, D, "SK_BOSSES")
    for nm, (x, y) in DS.BOSSES.items():
        I.circle(part, sk, x, y, "boss_D")
    st = I.finish(sk)
    z0, z1 = (BIG_LO, "z_A") if out else ("z_A", BIG_HI)
    I.extrude_z(part, sk, z0, z1, op=nxf.BOOL.Unite, target=E, name="BOSS_COLUMNS")
    step("bosses", sketch=str(st), v=vol(part))
    if not out:
        # the inner's lip inside the boss seats is relieved down to datum A
        I.extrude_z(part, sk, "z_lip-1", "z_A", op=nxf.BOOL.Subtract, target=E, name="BOSS_SEAT_RELIEF")
        step("seat_relief", v=vol(part))
    # ---- arms + wall-end flange (centre lines, thin extrude)
    sk = I.sketch(part, D, "SK_ARMS")
    for nm, (a, bo, bi) in DS.ARMS.items():
        I.segment(part, sk, a, bo if out else bi)
    st = I.finish(sk)
    I.extrude_z(part, sk, z0, z1, op=nxf.BOOL.Unite, target=E, thin=("-arm_t/2", "arm_t/2"), name="BOSS_ARMS")
    step("arms", sketch=str(st), v=vol(part))
    sk = I.sketch(part, D, "SK_KNEE_FLANGE")
    for nm, (a, b, w) in DS.FLANGES.items():
        I.segment(part, sk, a, b)
        nxh.expr(part, "flange_t", w, "mm", "wall-end flange at the knee side opening")
    st = I.finish(sk)
    I.extrude_z(part, sk, z0, z1, op=nxf.BOOL.Unite, target=E, thin=("-flange_t/2", "flange_t/2"), name="KNEE_WALL_FLANGE")
    step("flange", sketch=str(st), v=vol(part))
    # ---- pin lugs (two heights)
    for grp, names in (("P12", ("P1", "P2")), ("P3", ("P3",))):
        sk = I.sketch(part, D, "SK_PIN_LUGS_" + grp)
        for n in names:
            x, y, top_o, pin_top, face_i = DS.PINS[n]
            I.circle(part, sk, x, y, "pin_lug_D")
        st = I.finish(sk)
        x, y, top_o, pin_top, face_i = DS.PINS[names[0]]
        lz0, lz1 = (BIG_LO, top_o) if out else (face_i, BIG_HI)
        I.extrude_z(part, sk, lz0, lz1, op=nxf.BOOL.Unite, target=E, name="PIN_LUGS_" + grp)
        step("pin_lugs_" + grp, sketch=str(st), v=vol(part))
    # ---- clip everything to the envelope
    vb = vol(part)
    fc = nxh.intersect(part, E, [E0], keep_tool=True)
    try:
        fc.SetName("CLIP_TO_ENVELOPE")
    except Exception:
        pass
    step("clip", v_before=vb, v=vol(part), n_solids=len([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]),
         e0_kept=len([b for b in part.Bodies if b.IsSolidBody and b.IsBlanked]))
    # ---- spigots / pockets, holes
    if out:
        nxh.expr(part, "nub_D", DS.NUB_D, "mm", "boss spigot"); nxh.expr(part, "nub_top", DS.NUB_TOP, "mm", "spigot top")
        nxh.expr(part, "nub_hole_D", DS.NUB_HOLE_D, "mm", "screw hole in the spigot")
        nxh.expr(part, "nub_hole_depth", DS.NUB_HOLE_DEPTH, "mm", "screw hole depth from the spigot top")
        sk = I.sketch(part, D, "SK_SPIGOTS")
        for nm, (x, y) in DS.BOSSES.items():
            I.circle(part, sk, x, y, "nub_D")
        I.finish(sk)
        I.extrude_z(part, sk, "z_A", "nub_top", op=nxf.BOOL.Unite, target=E, name="BOSS_SPIGOTS")
        sk = I.sketch(part, D, "SK_SPIGOT_HOLES")
        for nm, (x, y) in DS.BOSSES.items():
            I.circle(part, sk, x, y, "nub_hole_D")
        I.finish(sk)
        I.extrude_z(part, sk, "nub_top-nub_hole_depth", "nub_top+1", op=nxf.BOOL.Subtract, target=E, name="BOSS_SCREW_HOLES")
        step("spigots", v=vol(part))
        nxh.expr(part, "pin_D", DS.PIN_D, "mm", "locating pin")
        for grp, names in (("P12", ("P1", "P2")), ("P3", ("P3",))):
            sk = I.sketch(part, D, "SK_PINS_" + grp)
            for n in names:
                I.circle(part, sk, DS.PINS[n][0], DS.PINS[n][1], "pin_D")
            I.finish(sk)
            x, y, top_o, pin_top, face_i = DS.PINS[names[0]]
            I.extrude_z(part, sk, top_o, pin_top, op=nxf.BOOL.Unite, target=E, name="PINS_" + grp)
        step("pins", v=vol(part))
    else:
        for n, v, c in (("pocket_D", DS.POCKET_D, "spigot pocket"), ("pocket_floor", DS.POCKET_FLOOR, "pocket floor"),
                        ("screw_D", DS.SCREW_D, "screw clearance"), ("cbore_D", DS.CBORE_D, "counterbore from outside"),
                        ("cbore_floor", DS.CBORE_FLOOR, "counterbore floor")):
            nxh.expr(part, n, v, "mm", c)
        for nm, dexp, za, zb in (("BOSS_POCKETS", "pocket_D", "z_A-1", "pocket_floor"),
                                  ("BOSS_SCREW_BORES", "screw_D", "pocket_floor-1", "cbore_floor+1"),
                                  ("BOSS_COUNTERBORES", "cbore_D", "cbore_floor", BIG_HI)):
            sk = I.sketch(part, D, "SK_" + nm)
            for b, (x, y) in DS.BOSSES.items():
                I.circle(part, sk, x, y, dexp)
            I.finish(sk)
            I.extrude_z(part, sk, za, zb, op=nxf.BOOL.Subtract, target=E, name=nm)
        step("pockets", v=vol(part))
        nxh.expr(part, "pin_hole_D", DS.PIN_HOLE_D, "mm", "pin hole (H8)")
        nxh.expr(part, "pin_hole_depth", DS.PIN_HOLE_DEPTH, "mm", "pin hole depth")
        for grp, names in (("P12", ("P1", "P2")), ("P3", ("P3",))):
            sk = I.sketch(part, D, "SK_PIN_HOLES_" + grp)
            for n in names:
                I.circle(part, sk, DS.PINS[n][0], DS.PINS[n][1], "pin_hole_D")
            I.finish(sk)
            face_i = DS.PINS[names[0]][4]
            I.extrude_z(part, sk, face_i - 1, "%s+pin_hole_depth" % face_i, op=nxf.BOOL.Subtract, target=E,
                        name="PIN_HOLES_" + grp)
        step("pin_holes", v=vol(part))
    E = I.main_body(part)
    step("done", v=vol(part), ok=nxh.body_ok(part, E), census=str(nxh.face_census(E)),
         n_solids=len([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]))
    nxre.stl_export(part, E, os.path.join(OUT, f"{WHICH}_B.stl"), chord=0.01)
    err = nxh.feature_errors(part)
    step("errors", errors=str(err))
    nxh.save(part)
    res["result"] = "PASS" if not err else "FAIL"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(RJ, res)
