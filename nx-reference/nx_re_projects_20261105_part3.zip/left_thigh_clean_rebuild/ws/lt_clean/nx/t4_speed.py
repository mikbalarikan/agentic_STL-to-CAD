"""Speed test: envelope from sections json, shell with tolerance T, trim at the rim plane. argv: out sections tol"""
import os, sys, time, traceback
for k in ("NXH_DIR", "NXCK_DIR", "NXRE_DIR"):
    sys.path.insert(0, os.environ[k])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean\nx")
import NXOpen, nxh, nxf, ltenv
OUT, SEC, TOL = sys.argv[1], sys.argv[2], float(sys.argv[3])
res = {"steps": []}; T0 = time.time()
def step(n, **k):
    k["name"] = n; k["t"] = round(time.time() - T0, 1); res["steps"].append(k); nxh.write_json(os.path.join(OUT, "t4_%g.json" % TOL), res)
try:
    part = nxh.new_part(os.path.join(OUT, "t4_%g.prt" % TOL))
    dt, E, sf = ltenv.envelope(part, SEC)
    step("env", v=nxh.volume(part, E))
    end = [f for f in E.GetFaces() if abs(nxh.face_mid_normal(f)[0][1] - 287.4) < 0.05]
    b = part.Features.CreateShellBuilder(NXOpen.Features.Feature.Null)
    b.Tolerance = TOL; b.Body = E
    b.RemovedFacesCollector = nxh.collector(part, faces=end)
    b.DefaultThickness.RightHandSide = "wall"; b.DefaultThicknessFlip = True
    b.CommitFeature(); b.Destroy()
    step("shell", v=nxh.volume(part, E))
    pl = [f for f in part.Features.GetFeatures() if f.Name == "RIM_PLANE"][0].DatumPlane
    nxf._trim(part, [E], False, {"datum_plane": pl})
    step("trim", v=nxh.volume(part, E))
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "t4_%g.json" % TOL), res)
