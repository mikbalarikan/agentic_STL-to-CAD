param([string]$Tag = "P1", [string]$OutStages = "", [string]$InnStages = "")
$rj = "C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1"
$n = "C:\NX_MCP_WORKSPACE\lt_clean\nx"
if ($OutStages -eq "") { $OutStages = "mating_add,knee_out_add,hip_out_add,ribs_out_add,clip,b1_ear_out,mating_cut,knee_out_cut,small_out,hip_out_cut,hip_out_details,side_openings" }
if ($InnStages -eq "") { $InnStages = "mating_add,knee_inn_add,knee_inn_ribs,hip_inn_add,ribs_inn_add,clip,small_inn,hub_inn,mating_cut,knee_inn_cut,knee_inn_holes,knee_inn_window,pins_inn,joint_reliefs_inn,side_openings" }
& $rj -Script "$n\p_build.py" -WorkDir "$n\$Tag" -JArgs "out","$n\A3\LT-OUT-001_Left_Thigh_Outer.prt","$n\$Tag",$OutStages -TimeoutSec 5400 | Select-Object -Last 1
& $rj -Script "$n\p_build.py" -WorkDir "$n\$Tag" -JArgs "inn","$n\A3\LT-INN-001_Left_Thigh_Inner.prt","$n\$Tag",$InnStages -TimeoutSec 5400 | Select-Object -Last 1
