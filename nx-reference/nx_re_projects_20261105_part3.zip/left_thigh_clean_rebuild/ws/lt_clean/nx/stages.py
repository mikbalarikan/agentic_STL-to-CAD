"""Feature stages of the clean rebuild. Each stage(ctx) adds named features to the main body of one part.
ctx: dict(part, D, E, E0, out(bool), step(fn)). Additive tools overshoot the skin; CLIP_TO_ENVELOPE trims them."""
import math
import NXOpen
import nxh, nxf
import ltint as I
import design as DS

BIG_LO, BIG_HI = -80, 160
U, S_ = nxf.BOOL.Unite, nxf.BOOL.Subtract


def E(ctx):
    return I.main_body(ctx["part"])


def vol(ctx, acc=0.99):
    """fast volume (accuracy 0.99 ~ 1e-4 relative) - 0.999999 costs minutes on these bodies."""
    part = ctx["part"]
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [E(ctx)])
    try:
        return round(mb.Volume, 1)
    finally:
        mb.Dispose()


def ex(ctx, n, v, c, unit="mm"):
    try:
        ctx["part"].Expressions.FindObject(n)
    except Exception:
        nxh.expr(ctx["part"], n, v, unit, c)


def poly(part, sk, pts):
    """closed polygon of anchored segments (3D points in the sketch plane)."""
    n = len(pts)
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        pa, pb = nxh.point(part, *map(float, a)), nxh.point(part, *map(float, b))
        ln = part.Curves.CreateLine(NXOpen.Point3d(*map(float, a)), NXOpen.Point3d(*map(float, b)))
        nxf.add(sk, ln, infer=False)
        sk.CreateCoincidentConstraint(nxf.cg(ln, nxf.CP.StartVertex), nxf.cg(nxf.sketch_anchor(part, sk, pa)))
        sk.CreateCoincidentConstraint(nxf.cg(ln, nxf.CP.EndVertex), nxf.cg(nxf.sketch_anchor(part, sk, pb)))


def loop(part, sk, segs):
    """closed loop of lines / arcs, every vertex held on a smart point, every arc also through a held mid point:
    DOF 0. segs = [(p, mid_or_None), ...]: segment i runs p_i -> p_{i+1}, an arc through mid when given."""
    n = len(segs)
    for i in range(n):
        a, mid = segs[i]
        b = segs[(i + 1) % n][0]
        A, B = NXOpen.Point3d(*map(float, a)), NXOpen.Point3d(*map(float, b))
        if mid is None:
            c = part.Curves.CreateLine(A, B)
        else:
            c = part.Curves.CreateArc(A, NXOpen.Point3d(*map(float, mid)), B, False)[0]
        nxf.add(sk, c, infer=False)
        pa, pb = nxh.point(part, *map(float, a)), nxh.point(part, *map(float, b))
        sk.CreateCoincidentConstraint(nxf.cg(c, nxf.CP.StartVertex), nxf.cg(nxf.sketch_anchor(part, sk, pa)))
        sk.CreateCoincidentConstraint(nxf.cg(c, nxf.CP.EndVertex), nxf.cg(nxf.sketch_anchor(part, sk, pb)))
        if mid is not None:
            pm = nxh.point(part, *map(float, mid))
            sk.CreatePointOnCurveConstraint(nxf.cg(nxf.sketch_anchor(part, sk, pm)), nxf.cg(c), nxf.help_at(NXOpen.Point3d(*map(float, mid))))


def plan_poly(ctx, name, polys):
    part, D = ctx["part"], ctx["D"]
    sk = I.sketch(part, D, name)
    for pts in polys:
        poly(part, sk, [(x, y, 0.0) for x, y in pts])
    return sk, I.finish(sk)


def rect(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


def sector(cx, cy, r0, r1, a0, a1, n=24):
    """polygon approximation is NOT used for design faces; only for cut tools whose faces are planes"""
    raise NotImplementedError


def plane_named(ctx, name, base, value):
    """offset datum plane from a datum plane (cached by name)."""
    part = ctx["part"]
    m = [f for f in part.Features.GetFeatures() if f.Name == name]
    if m:
        return m[0].DatumPlane
    f, pl = nxf.datum_plane(part, "offset", [base], value, name=name)
    return pl


def revolve_profile(ctx, name, plane, haxis, pts, axis, op, sk_name=None, start=0, end=360):
    part = ctx["part"]
    sk = nxf.new_sketch(part, plane, haxis, ctx["D"].origin, name=sk_name or ("SK_" + name))
    poly(part, sk, pts)
    st = I.finish(sk)
    f = nxf.revolve(part, nxh.section_feature(part, [sk.Feature], curves_only=True), axis, start=start, end=end,
                    op=op, target=E(ctx))
    f.SetName(name)
    ctx["step"](name, sketch=str(st), v=vol(ctx))
    return f


# ====================================================================== mating structure (both parts)
def mating_add(ctx):
    part, D, out = ctx["part"], ctx["D"], ctx["out"]
    ex(ctx, "boss_D", DS.BOSS_D, "screw boss column")
    ex(ctx, "arm_t", DS.ARM_W, "boss arm (full-height rib) thickness")
    ex(ctx, "pin_lug_D", DS.PIN_LUG_D, "locating pin lug")
    z0, z1 = (BIG_LO, "z_A") if out else ("z_A", BIG_HI)
    sk = I.sketch(part, D, "SK_BOSSES")
    for nm, (x, y) in DS.BOSSES.items():
        I.circle(part, sk, x, y, "boss_D")
    st = I.finish(sk)
    I.extrude_z(part, sk, z0, z1, op=U, target=E(ctx), name="BOSS_COLUMNS")
    ctx["step"]("BOSS_COLUMNS", sketch=str(st), v=vol(ctx))
    if not out:
        I.extrude_z(part, sk, "z_lip-1", "z_A", op=S_, target=E(ctx), name="BOSS_SEAT_RELIEF")
        ctx["step"]("BOSS_SEAT_RELIEF", v=vol(ctx))
    sk = I.sketch(part, D, "SK_ARMS")
    for nm, (a, bo, bi) in DS.ARMS.items():
        I.segment(part, sk, a, bo if out else bi)
    st = I.finish(sk)
    I.extrude_z(part, sk, z0, z1, op=U, target=E(ctx), thin=("-arm_t/2", "arm_t/2"), name="BOSS_ARMS")
    ctx["step"]("BOSS_ARMS", sketch=str(st), v=vol(ctx))
    sk = I.sketch(part, D, "SK_KNEE_FLANGE")
    for nm, (a, b, w) in DS.FLANGES.items():
        I.segment(part, sk, a, b)
        ex(ctx, "flange_t", w, "wall-end flange at the knee side opening")
    st = I.finish(sk)
    I.extrude_z(part, sk, z0, z1, op=U, target=E(ctx), thin=("-flange_t/2", "flange_t/2"), name="KNEE_WALL_FLANGE")
    ctx["step"]("KNEE_WALL_FLANGE", sketch=str(st), v=vol(ctx))
    for grp, names in (("P12", ("P1", "P2")), ("P3", ("P3",))):
        sk = I.sketch(part, D, "SK_PIN_LUGS_" + grp)
        for n in names:
            I.circle(part, sk, DS.PINS[n][0], DS.PINS[n][1], "pin_lug_D")
        st = I.finish(sk)
        x, y, top_o, pin_top, face_i = DS.PINS[names[0]]
        lz0, lz1 = (BIG_LO, top_o) if out else (face_i, BIG_HI)
        I.extrude_z(part, sk, lz0, lz1, op=U, target=E(ctx), name="PIN_LUGS_" + grp)
        ctx["step"]("PIN_LUGS_" + grp, sketch=str(st), v=vol(ctx))


def clip(ctx):
    part = ctx["part"]
    vb = vol(ctx)
    fc = nxh.intersect(part, E(ctx), [ctx["E0"]], keep_tool=True)
    try:
        fc.SetName("CLIP_TO_ENVELOPE")
    except Exception:
        pass
    ctx["step"]("CLIP_TO_ENVELOPE", v_before=vb, v=vol(ctx),
                n_solids=len([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]))


def mating_cut(ctx):
    part, D, out = ctx["part"], ctx["D"], ctx["out"]
    if out:
        ex(ctx, "nub_D", DS.NUB_D, "boss spigot"); ex(ctx, "nub_top", DS.NUB_TOP, "spigot top")
        ex(ctx, "nub_hole_D", DS.NUB_HOLE_D, "screw hole in the spigot")
        ex(ctx, "nub_hole_depth", DS.NUB_HOLE_DEPTH, "screw hole depth from the spigot top")
        sk = I.sketch(part, D, "SK_SPIGOTS")
        for nm, (x, y) in DS.BOSSES.items():
            I.circle(part, sk, x, y, "nub_D")
        I.finish(sk)
        I.extrude_z(part, sk, "z_A", "nub_top", op=U, target=E(ctx), name="BOSS_SPIGOTS")
        sk = I.sketch(part, D, "SK_SPIGOT_HOLES")
        for nm, (x, y) in DS.BOSSES.items():
            I.circle(part, sk, x, y, "nub_hole_D")
        I.finish(sk)
        I.extrude_z(part, sk, "nub_top-nub_hole_depth", "nub_top+1", op=S_, target=E(ctx), name="BOSS_SCREW_HOLES")
        ctx["step"]("spigots", v=vol(ctx))
        ex(ctx, "pin_D", DS.PIN_D, "locating pin")
        for grp, names in (("P12", ("P1", "P2")), ("P3", ("P3",))):
            sk = I.sketch(part, D, "SK_PINS_" + grp)
            for n in names:
                I.circle(part, sk, DS.PINS[n][0], DS.PINS[n][1], "pin_D")
            I.finish(sk)
            x, y, top_o, pin_top, face_i = DS.PINS[names[0]]
            I.extrude_z(part, sk, top_o, pin_top, op=U, target=E(ctx), name="PINS_" + grp)
        ctx["step"]("pins", v=vol(ctx))
    else:
        for n, v, c in (("pocket_D", DS.POCKET_D, "spigot pocket"), ("pocket_floor", DS.POCKET_FLOOR, "pocket floor"),
                        ("screw_D", DS.SCREW_D, "screw clearance"), ("cbore_D", DS.CBORE_D, "counterbore from outside"),
                        ("cbore_floor", DS.CBORE_FLOOR, "counterbore floor")):
            ex(ctx, n, v, c)
        for nm, dexp, za, zb in (("BOSS_POCKETS", "pocket_D", "z_A-1", "pocket_floor"),
                                  ("BOSS_SCREW_BORES", "screw_D", "pocket_floor-1", "cbore_floor+1"),
                                  ("BOSS_COUNTERBORES", "cbore_D", "cbore_floor", BIG_HI)):
            sk = I.sketch(part, D, "SK_" + nm)
            for b, (x, y) in DS.BOSSES.items():
                I.circle(part, sk, x, y, dexp)
            I.finish(sk)
            I.extrude_z(part, sk, za, zb, op=S_, target=E(ctx), name=nm)
        ctx["step"]("pockets", v=vol(ctx))
        ex(ctx, "pin_hole_D", DS.PIN_HOLE_D, "pin hole (H8)")
        ex(ctx, "pin_hole_depth", DS.PIN_HOLE_DEPTH, "pin hole depth")
        for grp, names in (("P12", ("P1", "P2")), ("P3", ("P3",))):
            sk = I.sketch(part, D, "SK_PIN_HOLES_" + grp)
            for n in names:
                I.circle(part, sk, DS.PINS[n][0], DS.PINS[n][1], "pin_hole_D")
            I.finish(sk)
            face_i = DS.PINS[names[0]][4]
            I.extrude_z(part, sk, face_i - 1, "%s+pin_hole_depth" % face_i, op=S_, target=E(ctx), name="PIN_HOLES_" + grp)
        ctx["step"]("pin_holes", v=vol(ctx))


# ====================================================================== knee
KNEE_FLOOR_POLY = [(-80, -80), (100, -80), (100, 23), (73.0, 33.0), (55.2, 55.5), (52.5, 61.5), (22.5, 76.5),
                   (-3.0, 77.8), (-25.1, 78.0), (-40, 90), (-80, 90)]


def knee_out_add(ctx):
    sk, st = plan_poly(ctx, "SK_KNEE_FLOOR", [KNEE_FLOOR_POLY])
    I.extrude_z(ctx["part"], sk, BIG_LO, 0, op=U, target=E(ctx), name="KNEE_FLOOR")
    ctx["step"]("KNEE_FLOOR", sketch=str(st), v=vol(ctx))


def knee_out_cut(ctx):
    part, D = ctx["part"], ctx["D"]
    for n, v, c in (("knee_bore_D", 110.0, "knee bore H7"), ("knee_bore_depth", 4.12, "knee bore depth from the floor"),
                    ("knee_step_D", 96.0, "bore step"), ("knee_step_z", -6.1, "bore step level"),
                    ("knee_thru_D", 92.1, "through bore"), ("knee_recess_D", 125.5, "bottom recess H7"),
                    ("knee_recess_z", -8.35, "bottom recess floor")):
        ex(ctx, n, v, c)
    r = lambda d: d / 2.0
    pts = [(0, 0, -30), (r(125.5), 0, -30), (r(125.5), 0, -8.35), (r(92.1), 0, -8.35), (r(92.1), 0, -6.1),
           (r(96.0), 0, -6.1), (r(96.0), 0, -4.12), (r(110.0), 0, -4.12), (r(110.0), 0, 1.0), (0, 0, 1.0)]
    revolve_profile(ctx, "KNEE_BORE", D.xz, D.x, pts, nxf.axis_from(part, D.z), S_)
    # bolt circle: one hole + circular pattern
    ex(ctx, "knee_bolt_D", 5.7, "knee bolt holes"); ex(ctx, "knee_pcd", 102.92, "knee bolt circle")
    ex(ctx, "knee_bolt_n", 30, "knee bolt count", unit=None)
    a = math.radians(6.0)
    sk = I.sketch(part, D, "SK_KNEE_BOLT")
    I.circle(part, sk, 51.46 * math.cos(a), 51.46 * math.sin(a), "knee_bolt_D")
    I.finish(sk)
    fh = I.extrude_z(part, sk, -12, -3, op=S_, target=E(ctx), name="KNEE_BOLT_HOLE")
    fp = nxf.pattern_circular(part, [fh], (0, 0, 0), D.z, "knee_bolt_n")
    fp.SetName("KNEE_BOLT_PATTERN")
    ctx["step"]("KNEE_BOLT_PATTERN", v=vol(ctx))
    # side opening of the drum wall (-X), wall cut down to Z 7.49
    ex(ctx, "knee_open_z", 7.49, "drum wall top in the side opening")
    a0, a1 = math.radians(154.6), math.radians(245.7)
    ro = 90.0
    pts = [(0, 0)] + [(ro * math.cos(a0 + (a1 - a0) * k / 3), ro * math.sin(a0 + (a1 - a0) * k / 3)) for k in range(4)]
    sk, st = plan_poly(ctx, "SK_KNEE_SIDE_OPEN", [[(55 * math.cos(a0), 55 * math.sin(a0))] + pts[1:] +
                                                  [(55 * math.cos(a1), 55 * math.sin(a1))]])
    I.extrude_z(part, sk, "knee_open_z", "z_A+5", op=S_, target=E(ctx), name="KNEE_SIDE_OPENING")
    ctx["step"]("KNEE_SIDE_OPENING", sketch=str(st), v=vol(ctx))


# ====================================================================== hip
def hip_plane(ctx):
    return plane_named(ctx, "HIP_PLANE", ctx["D"].xy, "hip_z")


def hip_axis(ctx):
    return nxf.axis_from(ctx["part"], I.feat(ctx["part"], "HIP_AXIS").DatumAxis)


def hip_out_add(ctx):
    part = ctx["part"]
    ex(ctx, "hip_y0", DS.HIP_Y0, "hip plate inside face"); ex(ctx, "hip_y1", DS.HIP_Y1, "hip plate end face (D)")
    ex(ctx, "hip_ring_D", 105.03, "hip ring OD"); ex(ctx, "hip_ring_top", 85.2, "hip ring top flat")
    sk, st = plan_poly(ctx, "SK_HIP_PLATE", [rect(-80, DS.HIP_Y0, 160, DS.HIP_Y1)])
    I.extrude_z(part, sk, BIG_LO, "z_A", op=U, target=E(ctx), name="HIP_PLATE")
    ctx["step"]("HIP_PLATE", v=vol(ctx))
    hx, hz = 37.97, 35.18
    R = 105.03 / 2
    pts = [(hx, DS.HIP_Y0, hz), (hx + R, DS.HIP_Y0, hz), (hx + R, DS.HIP_Y1, hz), (hx, DS.HIP_Y1, hz)]
    revolve_profile(ctx, "HIP_RING", hip_plane(ctx), ctx["D"].x, pts, hip_axis(ctx), U)


def hip_out_cut(ctx):
    part, D = ctx["part"], ctx["D"]
    sk, st = plan_poly(ctx, "SK_HIP_RING_TOP", [rect(-20, DS.HIP_Y0 - 1, 100, DS.HIP_Y1 + 1)])
    I.extrude_z(part, sk, "hip_ring_top", BIG_HI, op=S_, target=E(ctx), name="HIP_RING_TOP_FLAT")
    ctx["step"]("HIP_RING_TOP_FLAT", v=vol(ctx))
    hx, hz = 37.97, 35.18
    prof = [(0, 266.0), (48.77, 266.0), (48.77, 269.45), (42.98, 269.45), (42.98, 271.4), (40.99, 271.4),
            (40.99, 275.85), (41.99, 276.85), (41.99, 295.0), (0, 295.0)]
    pts = [(hx + r, y, hz) for r, y in prof]
    revolve_profile(ctx, "HIP_BORE", hip_plane(ctx), D.x, pts, hip_axis(ctx), S_)


# ---- inner
def knee_inn_add(ctx):
    sk, st = plan_poly(ctx, "SK_KNEE_DISC_FILL", [KNEE_FLOOR_POLY])
    ex(ctx, "knee_disc_in", 80.02, "knee disc inside face")
    I.extrude_z(ctx["part"], sk, "knee_disc_in", BIG_HI, op=U, target=E(ctx), name="KNEE_DISC_FILL")
    ctx["step"]("KNEE_DISC_FILL", sketch=str(st), v=vol(ctx))


def knee_inn_cut(ctx):
    part, D = ctx["part"], ctx["D"]
    ex(ctx, "hub_bore_D", 19.9, "knee hub bore H7")
    sk = I.sketch(part, D, "SK_HUB_BORE")
    I.circle(part, sk, 0, 0, "hub_bore_D")
    I.finish(sk)
    I.extrude_z(part, sk, 70, BIG_HI, op=S_, target=E(ctx), name="HUB_BORE")
    ex(ctx, "hub_screw_D", 3.3, "M4 tap drill"); ex(ctx, "hub_pcd", 30.0, "hub screw circle")
    sk = I.sketch(part, D, "SK_HUB_SCREWS")
    for k in range(4):
        a = math.radians(45 + 90 * k)
        I.circle(part, sk, 15.0 * math.cos(a), 15.0 * math.sin(a), "hub_screw_D")
    I.finish(sk)
    I.extrude_z(part, sk, 70, BIG_HI, op=S_, target=E(ctx), name="HUB_SCREW_HOLES")
    ctx["step"]("HUB_HOLES", v=vol(ctx))


def hip_inn_add(ctx):
    part = ctx["part"]
    ex(ctx, "hip_y0", DS.HIP_Y0, "hip plate inside face"); ex(ctx, "hip_y1", DS.HIP_Y1, "hip plate end face")
    ex(ctx, "hip_clear_D", 105.25, "clearance around the outer's hip ring")
    ex(ctx, "hip_pad_z", 85.32, "pad over the hip ring flat")
    hx, rc = 37.97, 105.25 / 2
    sk, st = plan_poly(ctx, "SK_HIP_BLOCKS", [rect(-80, DS.HIP_Y0, hx - rc, DS.HIP_Y1), rect(hx + rc, DS.HIP_Y0, 160, DS.HIP_Y1)])
    I.extrude_z(part, sk, "z_A", BIG_HI, op=U, target=E(ctx), name="HIP_SIDE_BLOCKS")
    sk, st = plan_poly(ctx, "SK_HIP_WEB", [rect(hx - rc - 1, DS.HIP_Y0, hx + rc + 1, 268.2)])
    I.extrude_z(part, sk, "z_A", BIG_HI, op=U, target=E(ctx), name="HIP_WEB")
    ctx["step"]("HIP_BLOCKS", v=vol(ctx))
    hx, hz = 37.97, 35.18
    pts = [(hx, DS.HIP_Y0 - 0.5, hz), (hx + rc, DS.HIP_Y0 - 0.5, hz), (hx + rc, DS.HIP_Y1 + 0.5, hz), (hx, DS.HIP_Y1 + 0.5, hz)]
    revolve_profile(ctx, "HIP_RING_CLEARANCE", hip_plane(ctx), ctx["D"].x, pts, hip_axis(ctx), S_)
    sk, st = plan_poly(ctx, "SK_HIP_PAD", [rect(hx - 16.0, DS.HIP_Y0, hx + 16.0, DS.HIP_Y1)])
    I.extrude_z(part, sk, "hip_pad_z", BIG_HI, op=U, target=E(ctx), name="HIP_PAD")
    ctx["step"]("HIP_PAD", v=vol(ctx))


def hip_inn_cut(ctx):
    pass


# ====================================================================== ribs
def flat_ribs(ctx, table, prefix):
    """ribs grouped by (top, thickness): one centre-line sketch + one thin extrude per group."""
    part, D, out = ctx["part"], ctx["D"], ctx["out"]
    groups = {}
    for nm, (a, b, top, t) in table.items():
        groups.setdefault((top, t), []).append((nm, a, b))
    for (top, t), items in groups.items():
        tag = ("%s_Z%g_T%g" % (prefix, top, t)).replace("-", "M").replace(".", "P")
        sk = I.sketch(part, D, "SK_" + tag)
        for nm, a, b in items:
            I.segment(part, sk, a, b)
        st = I.finish(sk)
        z0, z1 = (BIG_LO, top) if out else (top, BIG_HI)
        I.extrude_z(part, sk, z0, z1, op=U, target=E(ctx), thin=(-t / 2.0, t / 2.0), name=tag)
        ctx["step"](tag, ribs=[i[0] for i in items], sketch=str(st), v=vol(ctx))


def gussets(ctx, table):
    """vertical rib in the plane through p0-p1, top edge from (p0, z0) to (p1, z1), thickness t (symmetric)."""
    part, out = ctx["part"], ctx["out"]
    zfar = BIG_LO if out else BIG_HI
    for nm, (a, b, z0, z1, t) in table.items():
        pts = [nxh.point(part, a[0], a[1], 0.0), nxh.point(part, b[0], b[1], 0.0), nxh.point(part, a[0], a[1], 10.0)]
        fpl, pl = nxf.datum_plane(part, "three_points", pts, name="PL_" + nm)
        sk = nxf.new_sketch(part, pl, ctx["D"].z, ctx["D"].origin, name="SK_" + nm)
        poly(part, sk, [(a[0], a[1], zfar), (a[0], a[1], z0), (b[0], b[1], z1), (b[0], b[1], zfar)])
        st = I.finish(sk)
        f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), pl, symmetric=True,
                           end=t, op=U, target=E(ctx))
        f.SetName(nm)
        ctx["step"](nm, sketch=str(st), v=vol(ctx))


def ribs_out_add(ctx):
    flat_ribs(ctx, DS.OUT_RIBS, "RIBS")
    gussets(ctx, DS.OUT_GUSSETS)


# ---- outer hip details
def hip_out_details(ctx):
    part, D = ctx["part"], ctx["D"]
    hx, hz = 37.97, 35.18
    ax = hip_axis(ctx)
    # 26 x D4.07 thru on PCD 91.45, counterbore D7.53 x 4.15 from the end face: one hole + one cbore, patterned
    ex(ctx, "hip_bolt_D", 4.07, "hip bolt holes"); ex(ctx, "hip_bolt_cb_D", 7.53, "hip bolt counterbore")
    ex(ctx, "hip_bolt_cb_depth", 4.15, "hip bolt counterbore depth"); ex(ctx, "hip_bolt_n", 26, "hip bolt count", unit=None)
    pl = plane_named(ctx, "HIP_END_FACE_D", D.xz, "hip_y1")
    feats = []
    for nm, dexp, depth in (("HIP_BOLT_HOLE", "hip_bolt_D", 12.0), ("HIP_BOLT_CBORE", "hip_bolt_cb_D", "hip_bolt_cb_depth")):
        sk = nxf.new_sketch(part, pl, D.x, D.origin, name="SK_" + nm)
        nxf.sketch_circle(part, sk, nxh.point(part, hx + 91.45 / 2, DS.HIP_Y1, hz), dexp)
        I.finish(sk)
        f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), (0, -1, 0),
                           start=-1, end=depth, op=S_, target=E(ctx))
        f.SetName(nm); feats.append(f)
    fp = nxf.pattern_circular(part, feats, (hx, 0, hz), I.feat(part, "HIP_AXIS").DatumAxis, "hip_bolt_n")
    fp.SetName("HIP_BOLT_PATTERN")
    ctx["step"]("HIP_BOLT_PATTERN", v=vol(ctx))
    # connector pad: sector about the hip axis, R52.4-66.2, 28 deg about 109.06 deg (+X towards -Z), 4.1 high
    ex(ctx, "conn_r0", 52.4, "connector pad inner radius"); ex(ctx, "conn_r1", 66.2, "connector pad outer radius")
    ex(ctx, "conn_h", 4.1, "connector pad height over face D")
    pts = [(hx + 52.4, DS.HIP_Y1 - 0.5, hz), (hx + 66.2, DS.HIP_Y1 - 0.5, hz), (hx + 66.2, DS.HIP_Y1 + 4.1, hz),
           (hx + 52.4, DS.HIP_Y1 + 4.1, hz)]
    sk = nxf.new_sketch(part, hip_plane(ctx), D.x, D.origin, name="SK_CONN_PAD")
    poly(part, sk, pts)
    I.finish(sk)
    f = nxf.revolve(part, nxh.section_feature(part, [sk.Feature], curves_only=True), ax, start=109.06 - 14.0,
                    end=109.06 + 14.0, op=U, target=E(ctx))
    f.SetName("CONN_PAD")
    ctx["step"]("CONN_PAD", v=vol(ctx))
    plp = plane_named(ctx, "CONN_PAD_TOP", D.xz, "hip_y1+conn_h")
    r = 59.85
    for nm, dexp, ang, depth in (("CONN_SCREW_HOLES", 3.3, (-9.08, 9.08), 15.0), ("CONN_SCREW_CBORES", 7.3, (-9.08, 9.08), 4.0),
                                 ("CONN_PIN_HOLES", 4.05, (-2.875, 2.875), 15.0)):
        sk = nxf.new_sketch(part, plp, D.x, D.origin, name="SK_" + nm)
        for da in ang:
            t = math.radians(109.06 + da)
            nxf.sketch_circle(part, sk, nxh.point(part, hx + r * math.cos(t), DS.HIP_Y1 + 4.1, hz - r * math.sin(t)), dexp)
        I.finish(sk)
        f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), (0, -1, 0),
                           start=-1, end=depth, op=S_, target=E(ctx))
        f.SetName(nm)
    ctx["step"]("CONN_HOLES", v=vol(ctx))
    # locating slots S1 / S2 for the inner's hip pins
    ex(ctx, "slot_D", 4.3, "hip locating slot"); ex(ctx, "slot_floor", 79.2, "slot floor")
    sk = I.sketch(part, D, "SK_HIP_SLOTS")
    for x in (27.03, 49.02):
        I.circle(part, sk, x, 271.7, "slot_D")
    I.finish(sk)
    I.extrude_z(part, sk, "slot_floor", "hip_ring_top+1", op=S_, target=E(ctx), name="HIP_LOCATING_SLOTS")
    ctx["step"]("HIP_LOCATING_SLOTS", v=vol(ctx))


# ---- side openings (both parts: each cuts its own wall)
O2_MX = [((0, 181.0, 13.0), None), ((0, 181.0, 57.0), None), ((0, 192.5, 72.0), (0, 213.5, 68.5)),
         ((0, 234.5, 61.0), None), ((0, 234.5, 52.0), None), ((0, 240.0, 50.0), None), ((0, 240.0, 20.0), None),
         ((0, 234.5, 18.5), None), ((0, 234.5, 9.0), (0, 213.5, 1.5)), ((0, 192.5, -1.0), None)]
O3_PX = [((0, 188.5, 6.0), None), ((0, 188.5, 64.0), None), ((0, 185.0, 67.5), None), ((0, 173.0, 66.0), None),
         ((0, 159.0, 61.5), (0, 137.0, 35.0)), ((0, 159.0, 8.5), None), ((0, 173.0, 4.5), None), ((0, 185.0, 3.0), None)]


def side_openings(ctx):
    part, D = ctx["part"], ctx["D"]
    for nm, segs, x0, x1 in (("SIDE_OPENING_MX", O2_MX, -120, -25), ("SIDE_OPENING_PX", O3_PX, 100, 200)):
        sk = nxf.new_sketch(part, D.yz, D.y, D.origin, name="SK_" + nm)
        loop(part, sk, segs)
        st = I.finish(sk)
        f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), (1, 0, 0),
                           start=x0, end=x1, op=S_, target=E(ctx))
        f.SetName(nm)
        ctx["step"](nm, sketch=str(st), v=vol(ctx))


def knee_inn_window(ctx):
    part = ctx["part"]
    ex(ctx, "knee_win_top", 62.57, "knee side window top (inner) = cover pin root")
    a0, a1 = math.radians(154.6), math.radians(245.7)
    pts = [(55 * math.cos(a0), 55 * math.sin(a0))] + [(90 * math.cos(a0 + (a1 - a0) * k / 3), 90 * math.sin(a0 + (a1 - a0) * k / 3)) for k in range(4)] + [(55 * math.cos(a1), 55 * math.sin(a1))]
    sk, st = plan_poly(ctx, "SK_KNEE_SIDE_WINDOW", [pts])
    I.extrude_z(part, sk, "z_lip-1", "knee_win_top", op=S_, target=E(ctx), name="KNEE_SIDE_WINDOW")
    ctx["step"]("KNEE_SIDE_WINDOW", sketch=str(st), v=vol(ctx))


def ribs_inn_add(ctx):
    flat_ribs(ctx, DS.INN_RIBS, "IRIBS")
    gussets(ctx, DS.INN_GUSSETS)


def pins_inn(ctx):
    """inner: knee-cover pins N1/N2 (down from the window lintel) and hip pins N3/N4 (down from the hip pad)."""
    part, D = ctx["part"], ctx["D"]
    ex(ctx, "npin_D", DS.N_PIN_D, "knee cover pin"); ex(ctx, "npin_face", DS.N_PIN_FACE, "knee cover pin root")
    ex(ctx, "npin_len", DS.N_PIN_LEN, "knee cover pin length")
    ex(ctx, "hpin_D", DS.HIP_PIN_D, "hip pin"); ex(ctx, "hpin_face", DS.HIP_PIN_FACE, "hip pin root (hip pad)")
    ex(ctx, "hpin_len", DS.HIP_PIN_LEN, "hip pin length")
    cover_pin_lugs(ctx, "npin_face", "knee_disc_in+1")
    for nm, tbl, dexp, face, ln in (("KNEE_COVER_PINS", DS.KNEE_COVER_PINS, "npin_D", "npin_face", "npin_len"),
                                    ("HIP_PINS", DS.HIP_PINS, "hpin_D", "hpin_face", "hpin_len")):
        sk = I.sketch(part, D, "SK_" + nm)
        for k, (x, y) in tbl.items():
            I.circle(part, sk, x, y, dexp)
        I.finish(sk)
        I.extrude_z(part, sk, "%s-%s" % (face, ln), "%s+0.5" % face, op=U, target=E(ctx), name=nm)
        ctx["step"](nm, v=vol(ctx))


def arc3(part, sk, a, m, b):
    """arc a -> b through m (plan points), all three held on smart points: DOF 0."""
    A, M, B = [NXOpen.Point3d(float(p[0]), float(p[1]), 0.0) for p in (a, m, b)]
    c = part.Curves.CreateArc(A, M, B, False)[0]
    nxf.add(sk, c, infer=False)
    for pt, cp in ((a, nxf.CP.StartVertex), (b, nxf.CP.EndVertex)):
        sk.CreateCoincidentConstraint(nxf.cg(c, cp), nxf.cg(nxf.sketch_anchor(part, sk, nxh.point(part, float(pt[0]), float(pt[1]), 0.0))))
    sk.CreatePointOnCurveConstraint(nxf.cg(nxf.sketch_anchor(part, sk, nxh.point(part, float(m[0]), float(m[1]), 0.0))),
                                    nxf.cg(c), nxf.help_at(M))
    return c


def _pol(r, deg):
    return (r * math.cos(math.radians(deg)), r * math.sin(math.radians(deg)))


def knee_inn_ribs(ctx):
    """cable channel of the inner knee: ring ribs + straight ribs + cap ribs (bottom 75.07), channel floor land
    (76.87 up), screw bosses + holes for the channel cover; radial spokes."""
    part, D = ctx["part"], ctx["D"]
    for n, v, c in (("ch_rib_bottom", DS.CH_RIB_BOTTOM, "cable channel rib bottom"), ("ch_floor", DS.CH_FLOOR, "cable channel floor"),
                    ("ch_rib_t", DS.CH_RIB_T, "cable channel rib thickness"), ("spoke_t", DS.SPOKE_T, "knee spoke thickness")):
        ex(ctx, n, v, c)
    ri, ro, at = DS.CH_R_IN, DS.CH_R_OUT, DS.CH_A_TOP
    ji, jo = DS.CH_J_IN, DS.CH_J_OUT
    ai = math.degrees(math.atan2(ji[1], ji[0])) % 360; ao = math.degrees(math.atan2(jo[1], jo[0])) % 360
    # ---- C channel around the hub: ONE revolve of the channel cross-section (two ribs + floor), 75 -> 330 deg
    hw = DS.CH_RIB_T / 2
    prof = [(ri - hw, 0, DS.CH_RIB_BOTTOM), (ri + hw, 0, DS.CH_RIB_BOTTOM), (ri + hw, 0, DS.CH_FLOOR),
            (ro - hw, 0, DS.CH_FLOOR), (ro - hw, 0, DS.CH_RIB_BOTTOM), (ro + hw, 0, DS.CH_RIB_BOTTOM),
            (ro + hw, 0, 90.0), (ri - hw, 0, 90.0)]
    ex(ctx, "ch_a0", DS.CH_A_TOP, "cable channel C start angle (deg from +X)", unit="deg")
    ex(ctx, "ch_a1", 330.0, "cable channel C end angle (joins the straight run)", unit="deg")
    revolve_profile(ctx, "CH_RING", D.xz, D.x, prof, nxf.axis_from(part, D.z), U, start="ch_a0", end="ch_a1")
    # ---- straight run: two ribs + caps + floor
    sets = {
        "SK_CH_RUN_RIBS": [("line", jo, DS.CH_TOP_R), ("line", ji, DS.CH_TOP_L)],
        "SK_CH_CAPS": [("line", _pol(ri - hw, at), _pol(ro + hw, at)),
                       ("line", (DS.CH_TOP_L[0] - hw, DS.CH_TOP_L[1]), (DS.CH_TOP_R[0] + hw, DS.CH_TOP_R[1]))],
    }
    for skn, items in sets.items():
        sk = I.sketch(part, D, skn)
        for it in items:
            I.segment(part, sk, it[1], it[2])
        st = I.finish(sk)
        I.extrude_z(part, sk, "ch_rib_bottom", BIG_HI, op=U, target=E(ctx), thin=("-ch_rib_t/2", "ch_rib_t/2"),
                    name=skn.replace("SK_", ""))
        ctx["step"](skn, sketch=str(st), v=vol(ctx))
    sk = I.sketch(part, D, "SK_CH_FLOOR_RUN")
    loop(part, sk, [((*ji, 0.0), None), ((*jo, 0.0), None), ((*DS.CH_TOP_R, 0.0), None), ((*DS.CH_TOP_L, 0.0), None)])
    st = I.finish(sk)
    I.extrude_z(part, sk, "ch_floor", BIG_HI, op=U, target=E(ctx), name="CH_FLOOR_RUN")
    ctx["step"]("CH_FLOOR_RUN", sketch=str(st), v=vol(ctx))
    # ---- spokes
    for nm, angs, r0, r1 in (("SPOKES_IN", DS.SPOKES_IN, 10.5, ri), ("SPOKES_OUT", DS.SPOKES_OUT, ro, 66.5)):
        sk = I.sketch(part, D, "SK_" + nm)
        for a in angs:
            I.segment(part, sk, _pol(r0, a), _pol(r1, a))
        st = I.finish(sk)
        I.extrude_z(part, sk, DS.SPOKE_BOTTOM, BIG_HI, op=U, target=E(ctx), thin=("-spoke_t/2", "spoke_t/2"), name=nm)
        ctx["step"](nm, sketch=str(st), v=vol(ctx))
    # ---- cover screw bosses on the channel ribs
    ex(ctx, "ch_boss_D", DS.CH_BOSS_D, "channel cover screw boss")
    sk = I.sketch(part, D, "SK_CH_BOSSES")
    for k, (x, y) in DS.CH_HOLES.items():
        I.circle(part, sk, x, y, "ch_boss_D")
    I.finish(sk)
    I.extrude_z(part, sk, "ch_rib_bottom", BIG_HI, op=U, target=E(ctx), name="CH_BOSSES")
    ctx["step"]("CH_BOSSES", v=vol(ctx))


def knee_inn_holes(ctx):
    part, D = ctx["part"], ctx["D"]
    ex(ctx, "ch_hole_D", DS.CH_HOLE_D, "channel cover screw (M4 tap)"); ex(ctx, "ch_hole_depth", DS.CH_HOLE_DEPTH, "depth")
    sk = I.sketch(part, D, "SK_CH_HOLES")
    for k, (x, y) in DS.CH_HOLES.items():
        I.circle(part, sk, x, y, "ch_hole_D")
    I.finish(sk)
    I.extrude_z(part, sk, "ch_rib_bottom-1", "ch_rib_bottom+ch_hole_depth", op=S_, target=E(ctx), name="CH_COVER_HOLES")
    ctx["step"]("CH_COVER_HOLES", v=vol(ctx))


def b1_ear_out(ctx):
    part, D = ctx["part"], ctx["D"]
    # B1 ear: the B1 column runs through the drum wall and stands out of it (not clipped)
    sk = I.sketch(part, D, "SK_B1_EAR")
    I.circle(part, sk, DS.BOSSES["B1"][0], DS.BOSSES["B1"][1], "boss_D")
    I.finish(sk)
    I.extrude_z(part, sk, "knee_bot", "z_A", op=U, target=E(ctx), name="B1_EAR")
    ctx["step"]("B1_EAR", v=vol(ctx))


def cover_pin_lugs(ctx, z0, z1):
    """lugs under / over the knee-cover pins: D8 circle + radial web (t 6) to the drum wall."""
    part, D = ctx["part"], ctx["D"]
    ex(ctx, "npin_lug_D", 8.0, "knee cover pin lug"); ex(ctx, "npin_web_t", 6.0, "knee cover pin lug web")
    sk = I.sketch(part, D, "SK_KNEE_COVER_PIN_LUGS")
    for k, (x, y) in DS.KNEE_COVER_PINS.items():
        I.circle(part, sk, x, y, "npin_lug_D")
    I.finish(sk)
    I.extrude_z(part, sk, z0, z1, op=U, target=E(ctx), name="KNEE_COVER_PIN_LUGS")
    sk = I.sketch(part, D, "SK_KNEE_COVER_PIN_WEBS")
    for k, (x, y) in DS.KNEE_COVER_PINS.items():
        r = math.hypot(x, y)
        I.segment(part, sk, (x, y), (x * 67.5 / r, y * 67.5 / r))
    I.finish(sk)
    I.extrude_z(part, sk, z0, z1, op=U, target=E(ctx), thin=("-npin_web_t/2", "npin_web_t/2"), name="KNEE_COVER_PIN_WEBS")
    ctx["step"]("KNEE_COVER_PIN_LUGS", v=vol(ctx))


def small_out(ctx):
    part, D = ctx["part"], ctx["D"]
    # knee-cover pins on the low drum wall
    ex(ctx, "npin_D", DS.N_PIN_D, "knee cover pin"); ex(ctx, "npin_len", DS.N_PIN_LEN, "knee cover pin length")
    ex(ctx, "npin_base", DS.OUT_COVER_PIN_BASE, "knee cover pin root (outer)")
    cover_pin_lugs(ctx, -5, "npin_base")
    sk = I.sketch(part, D, "SK_KNEE_COVER_PINS")
    for k, (x, y) in DS.KNEE_COVER_PINS.items():
        I.circle(part, sk, x, y, "npin_D")
    I.finish(sk)
    I.extrude_z(part, sk, "npin_base-0.5", "npin_base+npin_len", op=U, target=E(ctx), name="KNEE_COVER_PINS")
    ctx["step"]("KNEE_COVER_PINS", v=vol(ctx))
    # floor bosses (top Z0) and their holes
    ex(ctx, "floor_boss_D", DS.FLOOR_BOSS_D, "floor screw boss"); ex(ctx, "floor_hole_D", DS.FLOOR_HOLE_D, "floor hole")
    ex(ctx, "floor_hole_depth", DS.FLOOR_HOLE_DEPTH, "floor hole depth")
    sk = I.sketch(part, D, "SK_FLOOR_HOLES")
    for k, (x, y) in DS.FLOOR_HOLES.items():
        I.circle(part, sk, x, y, "floor_hole_D")
    I.finish(sk)
    I.extrude_z(part, sk, "-floor_hole_depth", 1, op=S_, target=E(ctx), name="FLOOR_HOLES")
    ctx["step"]("FLOOR_BOSSES_HOLES", v=vol(ctx))


def small_inn(ctx):
    part, D = ctx["part"], ctx["D"]
    sk = I.sketch(part, D, "SK_B1_EAR")
    I.circle(part, sk, DS.BOSSES["B1"][0], DS.BOSSES["B1"][1], "boss_D")
    I.finish(sk)
    I.extrude_z(part, sk, "z_A", "knee_top", op=U, target=E(ctx), name="B1_EAR")
    ctx["step"]("B1_EAR", v=vol(ctx))


# ====================================================================== root blends
INTERIOR = ("BOSS_COLUMNS", "BOSS_ARMS", "KNEE_WALL_FLANGE", "PIN_LUGS", "RIBS_", "IRIBS_", "G_", "IG_", "KNEE_FLOOR",
            "KNEE_DISC_FILL", "HIP_PLATE", "HIP_SIDE_BLOCKS", "HIP_WEB", "HIP_PAD", "CH_", "SPOKES_", "FLOOR_BOSSES",
            "B1_EAR", "SHELL", "KNEE_HUB")


def _creator_names(part, body):
    feats = {f.Tag: f for f in part.Features.GetFeatures()}
    order = {f.Tag: i for i, f in enumerate(part.Features.GetFeatures())}
    out = {}
    for fc in body.GetFaces():
        tags = [t for t in nxh.UFS.Modeling.AskFaceFeats(fc.Tag) if t in feats]
        if tags:
            first = min(tags, key=lambda t: order[t])
            out[fc.Tag] = feats[first].Name or feats[first].FeatureType
        else:
            out[fc.Tag] = "?"
    return out


def root_blends(ctx, radius=3.0):
    """concave edges where interior structure (bosses, arms, ribs, gussets, floors, plates, the shell's inside)
    meet each other: one Edge Blend per creating feature group, falling back chain by chain."""
    part = ctx["part"]
    body = E(ctx)
    names = _creator_names(part, body)
    CUTS = ("CLEARANCE", "RELIEF", "WINDOW", "OPENING", "HOLE", "BORE", "POCKET", "SLOT", "SEAM")
    isint = lambda n: any(n.startswith(k) for k in INTERIOR) and not any(c in n for c in CUTS)
    cand = {}
    for e, k in nxf.sharp_edges(part, body, convex=False, concave=True, min_length=0.3):
        fs = list(e.GetFaces())
        if len(fs) != 2:
            continue
        bbe = nxh.bbox(e)
        if bbe[4] > 258.0 and bbe[2] < 50.0 and bbe[5] > 30.0:
            continue                       # hip joint zone: the partner part sits in this corner, no root blend
        n1, n2 = names.get(fs[0].Tag, "?"), names.get(fs[1].Tag, "?")
        if not (isint(n1) and isint(n2)) or (n1 == "SHELL" and n2 == "SHELL"):
            continue
        key = n2 if n1 == "SHELL" else n1
        cand.setdefault(key.split("_Z")[0], []).append(e)
    ctx["step"]("root_blend_candidates", groups={k: len(v) for k, v in cand.items()})
    ex(ctx, "root_r", radius, "interior root blend radius")
    report = {}

    def try_blend(edges, tag, depth=0):
        """one Edge Blend for the set (dialog overflow on); if refused, split in halves (few features)."""
        m = nxh.mark("blend " + tag, False)
        try:
            f = nxf.edge_blend(part, [(edges, "root_r")], overflow=True)
            if not nxh.body_ok(part, E(ctx)) or nxh.feature_errors(part, recheck=False):
                raise RuntimeError("body / feature not ok")
            f.SetName("ROOT_BLEND_" + tag)
            return len(edges), 1
        except Exception:
            nxh.undo_to(m)
            if len(edges) == 1 or depth > 4:
                return 0, 0
            h = len(edges) // 2
            a = try_blend(edges[:h], tag + "_A", depth + 1)
            b = try_blend(edges[h:], tag + "_B", depth + 1)
            return a[0] + b[0], a[1] + b[1]
    order = sorted(cand.items(), key=lambda kv: -len(kv[1]))
    for grp, edges in order:
        # edges may have been consumed by earlier blends: keep only those still on the body
        alive = set(e.Tag for e in E(ctx).GetEdges())
        edges = [e for e in edges if e.Tag in alive]
        if not edges:
            continue
        done, nfeat = try_blend(edges, grp)
        report[grp] = {"edges": len(edges), "blended": done, "features": nfeat}
        ctx["step"]("ROOT_BLEND_" + grp, result=report[grp], v=vol(ctx))


def _ends(c):
    ev = nxh.UFS.Eval.Initialize2(c.Tag)
    lim = nxh.UFS.Eval.AskLimits(ev)
    a = nxh.UFS.Eval.EvaluateUnitVectors(ev, lim[0])[0]; b = nxh.UFS.Eval.EvaluateUnitVectors(ev, lim[1])[0]
    return a, b


def _chains(curves, tol=0.02):
    """group curves into connected chains by end points."""
    ends = [(_ends(c), c) for c in curves]
    left = list(range(len(curves))); out = []
    d = lambda p, q: sum((p[i] - q[i]) ** 2 for i in range(3)) ** 0.5
    while left:
        ch = [left.pop(0)]; grew = True
        while grew:
            grew = False
            for j in list(left):
                (a, b), _ = ends[j]
                if any(min(d(a, e), d(b, e)) < tol for i in ch for e in ends[i][0]):
                    ch.append(j); left.remove(j); grew = True
        out.append([ends[i][1] for i in ch])
    return out


# ====================================================================== exterior panel lines
def seams(ctx):
    """panel lines: plan splines (scan-measured, same plan on top and bottom) projected along Z onto the
    exterior skin of this part, a D1.25 tube along each projection subtracted (groove 1.25 wide, 0.62 deep)."""
    import json as _json
    import curvekit as ck
    part = ctx["part"]
    data = _json.load(open("C:/NX_MCP_WORKSPACE/lt_clean/work/seams.json"))
    out = ctx["out"]
    zs, vec = (-200.0, (0, 0, 1)) if out else (200.0, (0, 0, -1))
    ex(ctx, "seam_D", 1.25, "panel line groove (tube diameter)")
    body = E(ctx)
    names = _creator_names(part, body)
    skin = [fc for fc in body.GetFaces() if names.get(fc.Tag) == "BODY_LOFT"]
    ctx["step"]("seam_faces", n=len(skin))
    for nm, pts in data.items():
        f, sp = ck.studio_spline(part, [(x, y, zs) for x, y in pts], degree=3)
        f.SetName("SEAM_%s_PLAN" % nm)
        b = part.Features.CreateProjectCurveBuilder(NXOpen.Features.Feature.Null)
        try:
            PB = NXOpen.Features.ProjectCurveBuilder
            b.Tolerance = 0.01
            nxh.fill_section(part, b.SectionToProject, curves=[sp])
            b.FaceToProjectTo.Add(nxh.collector(part, faces=skin))
            b.ProjectionDirectionMethod = PB.DirectionType.AlongVector
            b.ProjectionVector = nxh.direction(part, vec)
            b.InputCurvesOption.Associative = True
            fp = b.Commit()
        finally:
            b.Destroy()
        fp.SetName("SEAM_%s_ON_SKIN" % nm)
        cs = [e for e in fp.GetEntities() if isinstance(e, NXOpen.Curve)]
        chains = _chains(cs)
        tubes = []
        for k, ch in enumerate(chains):
            if sum(c.GetLength() for c in ch) < 3.0:
                continue
            ft, tb = nxf.tube(part, "seam_D", curves=ch)
            ft.SetName("SEAM_%s_TUBE_%d" % (nm, k + 1))
            tubes.append(tb)
        fs = nxh.subtract(part, E(ctx), tubes)
        try:
            fs.SetName("SEAM_%s_GROOVE" % nm)
        except Exception:
            pass
        ctx["step"]("SEAM_" + nm, n_curves=len(cs), chains=len(chains), length=round(sum(c.GetLength() for c in cs), 1), v=vol(ctx))


def joint_reliefs_inn(ctx):
    """inner: where the outer rises to datum A over the wall (hip plate band, knee wall flange) the inner's lip is
    relieved up to datum A; over the outer's P3 lug (top 36.24) up to the P3 lug face 36.36."""
    part, D = ctx["part"], ctx["D"]
    sk, st = plan_poly(ctx, "SK_HIP_SEAT_RELIEF", [rect(-80, DS.HIP_Y0, 160, DS.HIP_Y1)])
    I.extrude_z(part, sk, "z_lip-1", "z_A", op=S_, target=E(ctx), name="HIP_SEAT_RELIEF")
    sk = I.sketch(part, D, "SK_FLANGE_SEAT_RELIEF")
    for nm, (a, b, w) in DS.FLANGES.items():
        I.segment(part, sk, a, b)
    I.finish(sk)
    I.extrude_z(part, sk, "z_lip-1", "z_A", op=S_, target=E(ctx), thin=("-flange_t/2-0.2", "flange_t/2+0.2"),
                name="FLANGE_SEAT_RELIEF")
    ex(ctx, "p3_relief_D", 9.4, "relief over the outer's P3 lug")
    sk = I.sketch(part, D, "SK_P3_LUG_RELIEF")
    I.circle(part, sk, DS.PINS["P3"][0], DS.PINS["P3"][1], "p3_relief_D")
    I.finish(sk)
    I.extrude_z(part, sk, "z_lip-1", DS.PINS["P3"][4], op=S_, target=E(ctx), name="P3_LUG_RELIEF")
    ctx["step"]("JOINT_RELIEFS", v=vol(ctx))


def hub_inn(ctx):
    """knee hub on the disc (outside the envelope, so after the clip): revolve of shoulder D43.6 x 2.58 + hub
    D40.23 up to Z 93."""
    part, D = ctx["part"], ctx["D"]
    ex(ctx, "hub_D", 40.23, "knee hub OD"); ex(ctx, "hub_top", 93.0, "knee hub top")
    ex(ctx, "hub_sh_D", 43.6, "knee hub shoulder"); ex(ctx, "hub_sh_top", 86.2, "knee hub shoulder top")
    prof = [(0, 0, 83.0), (21.8, 0, 83.0), (21.8, 0, 86.2), (20.115, 0, 86.2), (20.115, 0, 93.0), (0, 0, 93.0)]
    revolve_profile(ctx, "KNEE_HUB", D.xz, D.x, prof, nxf.axis_from(part, D.z), U)


def floor_bosses_out(ctx):
    """outer floor screw bosses (top Z0), before the envelope clip so they stop at the skin."""
    part, D = ctx["part"], ctx["D"]
    ex(ctx, "floor_boss_D", DS.FLOOR_BOSS_D, "floor screw boss")
    sk = I.sketch(part, D, "SK_FLOOR_BOSSES")
    for k, (x, y) in DS.FLOOR_BOSSES.items():
        I.circle(part, sk, x, y, "floor_boss_D")
    I.finish(sk)
    I.extrude_z(part, sk, BIG_LO, 0, op=U, target=E(ctx), name="FLOOR_BOSSES")
    ctx["step"]("FLOOR_BOSSES", v=vol(ctx))


# ====================================================================== screw tabs and clip (user-marked details of the
# earlier revisions, same positions; outer tab D / inner lug D and outer tab C / inner lug 3 are pairs across the gap)
R2_ = math.sqrt(0.5)


def _plane3(ctx, name, p0, n):
    """datum plane through p0 with normal n (three points, associative to nothing: a fixed design plane)."""
    part = ctx["part"]
    a = (p0[0], p0[1], p0[2])
    t1 = (-n[1], n[0], 0.0) if abs(n[2]) < 0.9 else (1.0, 0.0, 0.0)
    t2 = (n[1] * t1[2] - n[2] * t1[1], n[2] * t1[0] - n[0] * t1[2], n[0] * t1[1] - n[1] * t1[0])
    pts = [nxh.point(part, *map(float, a)), nxh.point(part, *map(float, [a[i] + 10 * t1[i] for i in range(3)])),
           nxh.point(part, *map(float, [a[i] + 10 * t2[i] for i in range(3)]))]
    f, pl = nxf.datum_plane(part, "three_points", pts, name=name)
    return pl


def _slab(ctx, name, plane, pts, vec, t, op=None):
    part = ctx["part"]
    sk = nxf.new_sketch(part, plane, ctx["D"].z if abs(vec[2]) < 0.9 else ctx["D"].x, ctx["D"].origin, name="SK_" + name)
    poly(part, sk, pts)
    st = I.finish(sk)
    f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), vec, start=0, end=t,
                       op=op or U, target=E(ctx))
    f.SetName(name)
    ctx["step"](name, sketch=str(st), v=vol(ctx))
    return f


def _hole(ctx, name, plane, centre, d, vec, depth):
    part = ctx["part"]
    sk = nxf.new_sketch(part, plane, ctx["D"].z if abs(vec[2]) < 0.9 else ctx["D"].x, ctx["D"].origin, name="SK_" + name)
    nxf.sketch_circle(part, sk, nxh.point(part, *map(float, centre)), d)
    I.finish(sk)
    f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), vec, start=-0.5, end=depth,
                       op=S_, target=E(ctx))
    f.SetName(name)
    ctx["step"](name, v=vol(ctx))


def tabs_out_add(ctx):
    """before the clip: clip post+head (A), 45 deg tab C beside the hip-end boss, side-wall tab D."""
    part = ctx["part"]
    ex(ctx, "tab_hole_D", 2.7, "screw hole of the outer tabs and clip ring")
    # A: post + head as one rectangle 6.9 x 12.0 (turned -4.6 deg) from the skin up to Z 4.78
    th = math.radians(-4.6); a1 = (math.cos(th), math.sin(th)); a2 = (-math.sin(th), math.cos(th)); OA = (94.42, 206.92)
    Afn = lambda x, y: (OA[0] + x * a1[0] + y * a2[0], OA[1] + x * a1[1] + y * a2[1])   # noqa: E731
    head = [Afn(-0.05 - 3.45, -6.0), Afn(-0.05 + 3.45, -6.0), Afn(-0.05 + 3.45, 6.0), Afn(-0.05 - 3.45, 6.0)]
    sk, st = plan_poly(ctx, "SK_CLIP_POST", [head])
    I.extrude_z(part, sk, BIG_LO, 4.78, op=U, target=E(ctx), name="CLIP_POST")
    ctx["step"]("CLIP_POST", sketch=str(st), v=vol(ctx))
    r1 = [Afn(-3.5, 6.0 - 1.65), Afn(3.4, 6.0 - 1.65), Afn(3.4, 6.0), Afn(-3.5, 6.0)]
    r2 = [Afn(-3.5, -6.0), Afn(3.4, -6.0), Afn(3.4, -6.0 + 1.65), Afn(-3.5, -6.0 + 1.65)]
    sk, st = plan_poly(ctx, "SK_CLIP_RAILS", [r1, r2])
    I.extrude_z(part, sk, 4.7, 7.7, op=U, target=E(ctx), name="CLIP_RAILS")
    sk = I.sketch(part, ctx["D"], "SK_CLIP_RING")
    I.circle(part, sk, OA[0], OA[1], 5.3)
    I.finish(sk)
    I.extrude_z(part, sk, 4.7, 6.2, op=U, target=E(ctx), name="CLIP_RING")
    ctx["step"]("CLIP_HEAD", v=vol(ctx))
    # C: 45 deg tab (faces u 142.92 / 145.50 along e, outline in (w, z))
    E_, D_ = (R2_, R2_, 0.0), (R2_, -R2_, 0.0)
    C3 = lambda u, w, z: (u * E_[0] + w * D_[0], u * E_[1] + w * D_[1], z)   # noqa: E731
    u0, u1 = 142.92, 145.50
    pl = _plane3(ctx, "PL_TAB_C", C3(u0, 0, 0), E_)
    _slab(ctx, "TAB_C", pl, [C3(u0, -197.0, 20.21), C3(u0, -189.78, 20.21), C3(u0, -189.78, 2.0), C3(u0, -197.0, 11.0)],
          E_, u1 - u0)
    # D: side-wall tab x -20.42..-18.03
    x0, x1 = -20.42, -18.03
    pl = _plane3(ctx, "PL_TAB_D", (x0, 0, 0), (1.0, 0.0, 0.0))
    _slab(ctx, "TAB_D", pl, [(x0, 181.5, 8.15), (x0, 191.85, 8.15), (x0, 191.85, -2.2), (x0, 181.5, 1.5)], (1.0, 0.0, 0.0), x1 - x0)


def tabs_out_cut(ctx):
    part = ctx["part"]
    sk = I.sketch(part, ctx["D"], "SK_CLIP_HOLE")
    I.circle(part, sk, 94.42, 206.92, "tab_hole_D")
    I.finish(sk)
    I.extrude_z(part, sk, 4.25, 8.0, op=S_, target=E(ctx), name="CLIP_HOLE")
    E_, D_ = (R2_, R2_, 0.0), (R2_, -R2_, 0.0)
    C3 = lambda u, w, z: (u * E_[0] + w * D_[0], u * E_[1] + w * D_[1], z)   # noqa: E731
    pl = I.feat(part, "PL_TAB_C").DatumPlane
    _hole(ctx, "TAB_C_HOLE", pl, C3(142.92, -192.66, 15.6), "tab_hole_D", E_, 3.2)
    pl = I.feat(part, "PL_TAB_D").DatumPlane
    _hole(ctx, "TAB_D_HOLE", pl, (-20.42, 188.42, 4.48), "tab_hole_D", (1.0, 0.0, 0.0), 2.9)


def tabs_inn_add(ctx):
    """before the clip: lug D under the -X wall (pair of outer tab D) and lug 3 beside P3 (pair of outer tab C)."""
    part = ctx["part"]
    ex(ctx, "lug_hole_D", 2.6, "screw hole of the inner lugs")
    xo, xi = -20.5, -17.9
    pl = _plane3(ctx, "PL_LUG_D", (xo, 0, 0), (1.0, 0.0, 0.0))
    # slanted end (Y 190.3 at xo .. 192.6 at xi) approximated by the plane outline at xo: end at 191.45 (mid)
    _slab(ctx, "LUG_D", pl, [(xo, 177.0, 62.1), (xo, 191.45, 62.1), (xo, 191.45, 80.0), (xo, 177.0, 80.0)], (1.0, 0.0, 0.0), xi - xo)
    O = (-34.0, 238.5); Uv = (0.61527086, -0.78831578); W = (0.78831578, 0.61527086, 0.0)
    stz = lambda s, t, z: (O[0] + s * Uv[0] + t * W[0], O[1] + s * Uv[1] + t * W[1], z)   # noqa: E731
    T_A, T_B = -1.65, 0.95
    pl = _plane3(ctx, "PL_LUG_3", stz(0, T_A, 0), W)
    _slab(ctx, "LUG_3", pl, [stz(-3.5, T_A, 50.08), stz(3.1, T_A, 50.08), stz(3.1, T_A, 80.0), stz(-3.5, T_A, 80.0)], W, T_B - T_A)


def tabs_inn_cut(ctx):
    part = ctx["part"]
    pl = I.feat(part, "PL_LUG_D").DatumPlane
    _hole(ctx, "LUG_D_HOLE", pl, (-20.5, 188.4, 65.6), "lug_hole_D", (1.0, 0.0, 0.0), 3.1)
    O = (-34.0, 238.5); Uv = (0.61527086, -0.78831578); W = (0.78831578, 0.61527086, 0.0)
    stz = lambda s, t, z: (O[0] + s * Uv[0] + t * W[0], O[1] + s * Uv[1] + t * W[1], z)   # noqa: E731
    pl = I.feat(part, "PL_LUG_3").DatumPlane
    _hole(ctx, "LUG_3_HOLE", pl, stz(0.05, -1.65, 54.6), "lug_hole_D", W, 3.1)


STAGES = {
    "mating_add": mating_add, "clip": clip, "mating_cut": mating_cut,
    "knee_out_add": knee_out_add, "knee_out_cut": knee_out_cut, "hip_out_add": hip_out_add, "hip_out_cut": hip_out_cut,
    "knee_inn_add": knee_inn_add, "knee_inn_cut": knee_inn_cut, "hip_inn_add": hip_inn_add, "hip_inn_cut": hip_inn_cut,
    "ribs_out_add": ribs_out_add, "hip_out_details": hip_out_details, "side_openings": side_openings,
    "knee_inn_window": knee_inn_window, "ribs_inn_add": ribs_inn_add, "pins_inn": pins_inn,
    "knee_inn_ribs": knee_inn_ribs, "knee_inn_holes": knee_inn_holes, "small_out": small_out, "small_inn": small_inn, "b1_ear_out": b1_ear_out, "floor_bosses_out": floor_bosses_out, "tabs_out_add": tabs_out_add,
    "tabs_out_cut": tabs_out_cut, "tabs_inn_add": tabs_inn_add, "tabs_inn_cut": tabs_inn_cut,
    "root_blends": root_blends, "seams": seams, "joint_reliefs_inn": joint_reliefs_inn, "hub_inn": hub_inn,
}
