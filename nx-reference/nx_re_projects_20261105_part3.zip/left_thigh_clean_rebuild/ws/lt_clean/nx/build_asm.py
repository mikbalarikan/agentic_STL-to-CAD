"""LT-ASM-001: assembly of the two clean-rebuild parts. Both parts are modelled in the same frame
(designed in place), so both components go in at the absolute origin with identity orientation, no constraints.
args: cad_dir out_json [asm_rev outer_rev inner_rev]  (default A A A)
cad_dir holds the two component prts (copies); the assembly is created there; STEP AP214 + AP242 exported there."""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf, nxa

CAD, OUT = sys.argv[1], sys.argv[2]
REV, REV_OUT, REV_INN = (sys.argv[3:6] + ["A"] * 3)[:3]
ASM = os.path.join(CAD, "LT-ASM-001_Left_Thigh_Assembly.prt")
PARTS = [("LT-OUT-001", "LT-OUT-001_Left_Thigh_Outer.prt"), ("LT-INN-001", "LT-INN-001_Left_Thigh_Inner.prt")]
res = {"result": "FAIL", "components": {}}
try:
    if os.path.exists(ASM):
        os.remove(ASM)
    assy = nxa.new_assembly(ASM)
    nxh.save(assy)
    occs = {}
    for name, fn in PARTS:
        path = os.path.join(CAD, fn)
        comp = nxa.add_component(assy, path, name, (0.0, 0.0, 0.0), None, "SOLID")
        p = comp.Prototype
        try:
            p.LoadThisPartFully()
        except Exception:  # noqa: BLE001
            pass
        rs_names = [r.Name for r in p.GetAllReferenceSets()]
        if comp.ReferenceSet != "SOLID":
            assy.ComponentAssembly.ReplaceReferenceSet(comp, "SOLID" if "SOLID" in rs_names else "MODEL")
        solids = [b for b in p.Bodies if b.IsSolidBody]
        info = {"file": fn, "refsets": rs_names, "solids_in_part": len(solids),
                "part_volume": round(sum(nxh.volume(p, b) for b in solids), 2),
                "body_names": [b.Name for b in solids]}
        pos, mat = comp.GetPosition()
        info["refset"] = comp.ReferenceSet
        info["origin"] = [round(pos.X, 6), round(pos.Y, 6), round(pos.Z, 6)]
        info["matrix"] = [round(v, 9) for v in (mat.Xx, mat.Xy, mat.Xz, mat.Yx, mat.Yy, mat.Yz, mat.Zx, mat.Zy, mat.Zz)]
        o = [comp.FindOccurrence(b) for b in solids]
        o = [x for x in o if x is not None]
        info["occurrences"] = len(o)
        info["occ_bbox"] = [round(v, 3) for v in nxh.bbox(o[0])] if o else None
        info["occ_volume"] = round(sum(nxh.volume(assy, x) for x in o), 2)
        res["components"][name] = info
        occs[name] = o
    # NX interference check between the two parts (touching boss faces are expected: edges/faces only)
    try:
        res["simple_interference"] = nxa.simple_interference(assy, occs["LT-OUT-001"][0], occs["LT-INN-001"][0])
    except Exception as e:  # noqa: BLE001
        res["simple_interference_err"] = str(e)
    try:
        res["min_dist"] = nxh.min_dist(occs["LT-OUT-001"][0], occs["LT-INN-001"][0])
    except Exception as e:  # noqa: BLE001
        res["min_dist_err"] = str(e)
    for k, val in (("DRAWING_NO", "LT-ASM-001"), ("REVISION", REV),
                   ("DESCRIPTION", f"Left thigh assembly: LT-OUT-001 Rev {REV_OUT} + LT-INN-001 Rev {REV_INN}")):
        try:
            assy.SetUserAttribute(k, -1, val, NXOpen.Update.Option.Now)
        except Exception as e:  # noqa: BLE001
            res.setdefault("attr_err", []).append(str(e))
    nxh.save(assy)
    st214 = os.path.join(CAD, "LT-ASM-001_Left_Thigh_Assembly_AP214.step")
    st242 = os.path.join(CAD, "LT-ASM-001_Left_Thigh_Assembly_AP242.step")
    nxf.step_export(assy, st214, ap242=False, save=False)
    nxf.step_export(assy, st242, ap242=True, save=False)
    res["step_sizes"] = [os.path.getsize(st214), os.path.getsize(st242)]
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
