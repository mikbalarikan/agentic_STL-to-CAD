"""Test 1: envelope = drum revolve U body loft, then Shell. Timed, measured. argv: out_dir sections.json"""
import os, sys, json, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import math
import NXOpen
import nxh, nxf
import curvekit as ck
import nxre

OUT, SEC = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
res = {"result": "FAIL", "steps": []}
T0 = time.time()


def step(name, **kw):
    kw["name"] = name; kw["t"] = round(time.time() - T0, 1)
    res["steps"].append(kw)
    nxh.write_json(os.path.join(OUT, "t1.json"), res)


try:
    data = json.load(open(SEC))
    dr = data["drum"]
    part = nxh.new_part(os.path.join(OUT, "t1_env.prt"))
    tn = math.tan(math.radians(1.7))
    R = lambda z: dr["Rp"] - abs(z - dr["zp"]) * tn
    zb, zt, zp = dr["zbot"], dr["ztop"], dr["zp"]
    prof = [(0, 0, zb), (R(zb), 0, zb), (dr["Rp"], 0, zp), (R(zt), 0, zt), (0, 0, zt)]
    cur = [nxh.line(part, prof[i], prof[(i + 1) % len(prof)]) for i in range(len(prof))]
    fD = nxf.revolve(part, nxh.section(part, curves=cur), nxh.axis(part, (0, 0, 0), (0, 0, 1)))
    D = fD.GetBodies()[0]
    step("drum", vol=nxh.volume(part, D))
    sps = []
    for s in data["sections"]:
        f, sp = ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True, periodic=True)
        sps.append(sp)
    step("splines", n=len(sps))
    secs = []
    for sp in sps:
        sec = nxh.section(part, curves=[sp])
        secs.append(sec)
    fL = nxf.through_curves(part, secs, solid=True)
    L = fL.GetBodies()[0]
    step("loft", vol=nxh.volume(part, L), ok=nxh.body_ok(part, L), census=str(nxh.face_census(L)))
    nxh.unite(part, D, [L])
    E = nxh.solids(part)[0] if len(nxh.solids(part)) == 1 else None
    step("unite", n_solids=len(nxh.solids(part)), vol=nxh.volume(part, E), ok=nxh.body_ok(part, E),
         census=str(nxh.face_census(E)), nfaces=len(E.GetFaces()))
    nxre.stl_export(part, E, os.path.join(OUT, "t1_env.stl"), chord=0.01)
    end = []
    if not end:
        end = [f for f in E.GetFaces() if abs(nxh.face_mid_normal(f)[0][1] - 287.4) < 0.05]
    step("end_face", n=len(end))
    v0 = nxh.volume(part, E)
    nxf.shell(part, E, end, 3.1)
    step("shell", vol=nxh.volume(part, E), dv=v0 - nxh.volume(part, E), ok=nxh.body_ok(part, E),
         nfaces=len(E.GetFaces()), census=str(nxh.face_census(E)))
    nxre.stl_export(part, E, os.path.join(OUT, "t1_shell.stl"), chord=0.01)
    err = nxh.feature_errors(part)
    step("errors", errors=str(err))
    nxh.save(part)
    res["result"] = "PASS" if not err else "FAIL"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "t1.json"), res)
