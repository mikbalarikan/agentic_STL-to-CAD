param([string]$P = "P15", [string]$Tag = "1")
$rj = "C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1"
$n = "C:\NX_MCP_WORKSPACE\lt_clean\nx"; $c = "C:\NX_MCP_WORKSPACE\lt_clean\deliver\CAD"
& "$n\run_finalize.ps1" -P $P
& $rj -Script "$n\build_asm.py" -WorkDir "$n\asm" -JArgs $c,"$n\asm\asm.json","C","D","C" -TimeoutSec 3000 | Select-Object -Last 1
& $rj -Script "$n\dwg_asm.py" -WorkDir "$n\dwgA$Tag" -JArgs "$c\LT-ASM-001_Left_Thigh_Assembly.prt","$n\dwgA$Tag" -TimeoutSec 3600 | Select-Object -Last 1
& $rj -Script "$n\dwg_out.py" -WorkDir "$n\dwgO$Tag" -JArgs "$c\LT-OUT-001_Left_Thigh_Outer.prt","$n\dwgO$Tag" -TimeoutSec 3600 | Select-Object -Last 1
& $rj -Script "$n\dwg_inn.py" -WorkDir "$n\dwgI$Tag" -JArgs "$c\LT-INN-001_Left_Thigh_Inner.prt","$n\dwgI$Tag" -TimeoutSec 3600 | Select-Object -Last 1
