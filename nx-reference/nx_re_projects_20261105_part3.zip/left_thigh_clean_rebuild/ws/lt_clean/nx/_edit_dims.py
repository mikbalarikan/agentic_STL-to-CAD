p = 'C:/NX_MCP_WORKSPACE/lt_clean/nx/dwg_out.py'
s = open(p, encoding='utf-8').read()
a = '''        if c_knee and c_end:
            dimc("L_overall", front, c_knee, c_end, (fx(110.0), fz(-60.0)), "horizontal", 287.4 + 68.861, etol=0.25)'''
b = '''        def _ext(view, sign):
            best = None
            for c, _ps in nxd.curves(view):
                for q in nxd.curve_points(c)[:2]:
                    if best is None or sign * q[0] > sign * best[1][0]:
                        best = (c, q)
            return best
        def _overall():
            (c0, p0), (c1, p1) = _ext(front, -1), _ext(front, +1)
            return m3d.dim_ends(front, c0, p0, c1, p1, (fx(110.0), fz(-60.0)), "horizontal", expect=abs(p1[0] - p0[0]), etol=0.02)
        D("L_overall", _overall)'''
assert a in s
s = s.replace(a, b)
a = '''        c_sk = N("c_skirt2", hor(-13.9, -64.5, -62.5))'''
b = '''        c_sk = N("c_skirt2", hor(-13.9, -66.0, -62.0))'''
assert a in s
s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s)

p = 'C:/NX_MCP_WORKSPACE/lt_clean/nx/dwg_inn.py'
s = open(p, encoding='utf-8').read()
a = '''            c_bface = N("c_bossface", dhor(bb["top_z"], yb + 5.0, yb + 7.6))'''
b = '''            c_bface = N("c_bossface", lambda: longest(straight(bdet, lambda p0, p1: abs(p0[2] - bb["top_z"]) < 0.06 and abs(p1[2] - bb["top_z"]) < 0.06
                                                               and min(p0[0], p1[0]) <= yb + 6.5 <= max(p0[0], p1[0]))))'''
assert a in s
s = s.replace(a, b)
open(p, 'w', encoding='utf-8').write(s)
print("ok")
