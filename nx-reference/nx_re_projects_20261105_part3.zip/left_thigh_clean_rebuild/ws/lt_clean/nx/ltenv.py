"""Left thigh clean rebuild - shared masters and envelope, used identically by the outer and the inner part.

Frame (both parts, = assembly frame): origin on the knee axis at the knee floor plane, +Z knee axis towards the
inner shell, +Y towards the hip. All values mm / degrees.
"""
import os, json, math
import NXOpen
import nxh, nxf
import curvekit as ck

HERE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else r"C:\NX_MCP_WORKSPACE\lt_clean\nx"

# name, value, unit, comment  (the masters: change here, both parts follow)
MASTERS = [
    ("wall", 3.1, "mm", "shell wall (scans 3.07-3.10)"),
    ("z_A", 36.07, "mm", "datum A: boss faces, outer tongue top"),
    ("z_rim", 34.76, "mm", "outer rim (joint face of LT-OUT-001)"),
    ("z_lip", 35.32, "mm", "inner lip (joint face of LT-INN-001), 0.56 shadow gap"),
    ("z_rebate", 36.19, "mm", "inner rebate floor, 0.12 over the tongue"),
    ("t_tongue", 1.65, "mm", "outer tongue width from the inside face"),
    ("w_rebate", 2.0, "mm", "inner rebate width from the inside face"),
    ("drum_D", 137.8, "mm", "knee drum diameter at datum A"),
    ("drum_draft", 1.7, "deg", "knee drum draft both ways from datum A"),
    ("knee_top", 83.62, "mm", "knee disc outside face (LT-INN-001)"),
    ("knee_bot", -13.9, "mm", "knee drum bottom face (LT-OUT-001)"),
    ("knee_top_ch", 3.3, "mm", "knee disc edge chamfer 45 deg"),
    ("knee_bot_ch_r", 3.4, "mm", "knee bottom edge chamfer, radial leg"),
    ("knee_bot_ch_z", 2.9, "mm", "knee bottom edge chamfer, axial leg"),
    ("hip_x", 37.97, "mm", "hip axis X"),
    ("hip_z", 35.18, "mm", "hip axis Z"),
    ("y_end", 287.4, "mm", "hip mouth plane"),
]

MV = {n: v for n, v, u, c in MASTERS}


def masters(part):
    for n, v, u, c in MASTERS:
        nxh.expr(part, n, v, u, c)


def datums(part):
    D = nxh.Datums(part)
    out = {"D": D}
    for nm, ex in (("DATUM_A", "z_A"), ("RIM_PLANE", "z_rim"), ("LIP_PLANE", "z_lip")):
        f, pl = nxf.datum_plane(part, "offset", [D.xy], ex, name=nm)
        out[nm] = pl
    f, ax = nxf.datum_axis(part, "point_dir", ("hip_x", "0", "hip_z"), (0, 1, 0), name="HIP_AXIS")
    out["HIP_AXIS"] = ax
    return out


def drum(part, dt):
    """Knee drum: circle on XY, extruded knee_bot..knee_top, drafted both ways from DATUM_A, edge chamfers."""
    D = dt["D"]
    sk = nxf.new_sketch(part, D.xy, D.x, D.origin, name="SK_DRUM")
    nxf.sketch_circle(part, sk, D.origin, "drum_D")
    st = nxf.finish_sketch(sk)
    f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), (0, 0, 1),
                       start="knee_bot", end="knee_top")
    f.SetName("DRUM")
    body = f.GetBodies()[0]
    cyl = [fc for fc in body.GetFaces() if fc.SolidFaceType == NXOpen.Face.FaceType.Cylindrical]
    fd = nxf.draft_parting(part, cyl, (0, 0, 1), 1.7, parting_datum=dt["DATUM_A"])
    fd.SetName("DRUM_DRAFT")
    # link the draft angle to the master
    for e in fd.GetExpressions():
        try:
            if abs(e.Value - 1.7) < 1e-9:
                e.RightHandSide = "drum_draft"
        except Exception:
            pass
    return f, body, st


def drum_chamfers(part, body):
    """top edge 45 deg (knee disc), bottom edge two legs: the OUTER edges of the knee disc / drum bottom plane
    (after the shell: only edges whose mid point is farther than 60 from the knee axis)."""
    def outer_edges(z):
        out = []
        for e in body.GetEdges():
            bb = nxh.bbox(e)
            if abs(bb[2] - z) < 1e-3 and abs(bb[5] - z) < 1e-3:
                fs = list(e.GetFaces())
                if any(f.SolidFaceType == NXOpen.Face.FaceType.Conical for f in fs):
                    out.append(e)
        return out
    top, bot = outer_edges(MV["knee_top"]), outer_edges(MV["knee_bot"])
    f1 = nxf.chamfer(part, top, "knee_top_ch"); f1.SetName("DRUM_TOP_CHAMFER")
    f2 = nxf.chamfer(part, bot, "knee_bot_ch_r", "knee_bot_ch_z"); f2.SetName("DRUM_BOT_CHAMFER")
    return f1, f2


def _edge_z(e):
    bb = nxh.bbox(e)
    return bb[2] if abs(bb[5] - bb[2]) < 1e-6 else None


def body_loft(part, sections_json):
    data = json.load(open(sections_json))
    feats, sps = [], []
    for i, s in enumerate(data["sections"]):
        f, sp = ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True, periodic=True)
        if f is not None:
            f.SetName("BODY_S%02d_Y%s" % (i + 1, ("%g" % s["y"]).replace("-", "M").replace(".", "P")))
            feats.append(f)
        sps.append(sp)
    fl = nxf.through_curves(part, [nxh.section(part, curves=[sp]) for sp in sps], solid=True)
    fl.SetName("BODY_LOFT")
    return fl, fl.GetBodies()[0], feats


def envelope(part, sections_json, log=print, chamfers=True):
    masters(part)
    dt = datums(part)
    fD, D, st = drum(part, dt)
    log("drum sketch %s" % (st,))
    if chamfers:
        drum_chamfers(part, D)
    fl, L, sfeats = body_loft(part, sections_json)
    nxh.unite(part, D, [L])
    E = D
    # the knee disc faces continue flat where the body meets them flush: anything of the loft over the disc
    # plane inside the disc (or under the bottom plane) is cut back to the plane
    sk = nxf.new_sketch(part, dt["D"].xy, dt["D"].x, dt["D"].origin, name="SK_KNEE_FLATS")
    nxf.sketch_circle(part, sk, dt["D"].origin, "drum_D-2*(knee_top-z_A)*tan(drum_draft)-1")
    nxf.finish_sketch(sk)
    for nm, z0, z1 in (("KNEE_TOP_FLAT", "knee_top", "knee_top+40"), ("KNEE_BOT_FLAT", "knee_bot-40", "knee_bot")):
        m = nxh.mark(nm, False)
        try:
            f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), (0, 0, 1),
                               start=z0, end=z1, op=nxf.BOOL.Subtract, target=E)
            f.SetName(nm)
            log("%s applied" % nm)
        except Exception as ex:
            nxh.undo_to(m)
            log("%s not needed (%s)" % (nm, str(ex)[:80]))
    return dt, E, sfeats
