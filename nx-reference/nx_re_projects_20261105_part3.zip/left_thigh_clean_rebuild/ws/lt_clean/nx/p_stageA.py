"""Stage A of one part: copy of LT_BASE.prt -> Trim at the joint plane -> tongue (outer) / rebate (inner).
argv: which(out|inn) base_prt out_dir"""
import os, sys, json, time, shutil, traceback
for k in ("NXH_DIR", "NXCK_DIR", "NXRE_DIR"):
    sys.path.insert(0, os.environ[k])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean\nx")
import NXOpen
import nxh, nxf, nxre
import ltenv, ltjoint

WHICH, BASE, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
NAME = {"out": "LT-OUT-001_Left_Thigh_Outer", "inn": "LT-INN-001_Left_Thigh_Inner"}[WHICH]
RJ = os.path.join(OUT, f"stageA_{WHICH}.json")
res = {"result": "FAIL", "steps": []}
T0 = time.time()


def step(name, **kw):
    kw["name"] = name; kw["t"] = round(time.time() - T0, 1)
    res["steps"].append(kw); nxh.write_json(RJ, res)


def feat(part, name):
    m = [f for f in part.Features.GetFeatures() if f.Name == name]
    if not m:
        raise RuntimeError("no feature %s in %s" % (name, [(f.Name, f.FeatureType) for f in part.Features.GetFeatures()]))
    return m[0]


try:
    dst = os.path.join(OUT, NAME + ".prt")
    shutil.copyfile(BASE, dst)
    part = nxh.open_part(dst)
    D = nxh.Datums(part)
    shell_f = [f for f in part.Features.GetFeatures() if f.FeatureType == "SHELL"][0]
    shell_f.SetName("SHELL")
    [f for f in part.Features.GetFeatures() if f.FeatureType == "UNITE"][0].SetName("ENVELOPE_UNITE")
    E = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked][0]
    E0 = [b for b in part.Bodies if b.IsSolidBody and b.IsBlanked][0]
    v0 = 0.0
    MV = ltenv.MV
    if WHICH == "out":
        pl = feat(part, "RIM_PLANE").DatumPlane
        ft, rev = nxf.trim_body(part, E, reverse=False, datum_plane=pl)
        zj, height, width, op = MV["z_rim"], "z_A-z_rim", "t_tongue", "unite"
    else:
        pl = feat(part, "LIP_PLANE").DatumPlane
        ft, rev = nxf.trim_body(part, E, reverse=True, datum_plane=pl)
        zj, height, width, op = MV["z_lip"], "z_rebate-z_lip", "w_rebate", "subtract"
    ft.SetName("SPLIT_AT_JOINT")
    probe = (0.0, 0.0, -12.3) if WHICH == "out" else (0.0, 0.0, 82.0)     # inside the drum bottom / top wall
    assert ltjoint.contains(E, probe) == 1, "trim kept the wrong side"
    v1 = 0.0
    step("trim", v_before=v0, v_after=v1, n_solids=len([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]))
    jf = ltjoint.joint_face(E, zj)
    edges = ltjoint.interior_edges(part, E, jf, shell_f)
    step("joint", n_faces=len(jf), n_inner_edges=len(edges), len_edges=round(sum(e.GetLength() for e in edges), 2))
    zsk, zst = ltjoint.zone_sketch(part, D, "SK_JOINT_ZONES")
    step("zones", sketch=str(zst))
    fb, fz, pieces = ltjoint.band(part, E, jf, edges, height, width, zsk, op, log=lambda m: step("log", msg=m))
    fb.SetName("TONGUE_BAND" if WHICH == "out" else "REBATE_BAND")
    fz.SetName("TONGUE_ZONES" if WHICH == "out" else "REBATE_ZONES")
    vp = [nxh.mass(part, [b])["volume"] for b in pieces]
    step("band", n_pieces=len(pieces), vols=[round(v, 2) for v in vp], total=round(sum(vp), 2))
    if op == "unite":
        fu = nxh.unite(part, E, pieces); nm = "TONGUE"
    else:
        fu = nxh.subtract(part, E, pieces); nm = "REBATE"
    try:
        fu.SetName(nm)
    except Exception:
        pass
    v2 = 0.0
    step("joint_done", v=v2, dv=v2 - v1, ok=nxh.body_ok(part, E), census=str(nxh.face_census(E)),
         n_solids=len([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]))
    nxre.stl_export(part, E, os.path.join(OUT, f"{WHICH}_A.stl"), chord=0.01)
    err = nxh.feature_errors(part)
    step("errors", errors=str(err))
    nxh.save(part)
    res["result"] = "PASS" if not err else "FAIL"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(RJ, res)
