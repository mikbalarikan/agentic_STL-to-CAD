param([string]$Tag = "3")
$rj = "C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1"
$n = "C:\NX_MCP_WORKSPACE\lt_clean\nx"; $c = "C:\NX_MCP_WORKSPACE\lt_clean\deliver\CAD"
& $rj -Script "$n\dwg_out.py" -WorkDir "$n\dwgO$Tag" -JArgs "$c\LT-OUT-001_Left_Thigh_Outer.prt","$n\dwgO$Tag" -TimeoutSec 3600 | Select-Object -Last 1
& $rj -Script "$n\dwg_inn.py" -WorkDir "$n\dwgI$Tag" -JArgs "$c\LT-INN-001_Left_Thigh_Inner.prt","$n\dwgI$Tag" -TimeoutSec 3600 | Select-Object -Last 1
