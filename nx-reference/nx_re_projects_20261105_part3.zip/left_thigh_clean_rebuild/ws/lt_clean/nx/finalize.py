"""Finalize one clean-rebuild part: keep the product solid (the blanked envelope copy goes by a Delete Body at the end
of the tree), helper geometry to layer 200, reference set SOLID, attributes, save as delivery name, exports
(STEP AP214 + AP242, Parasolid x_t, STL). args: built_prt deliver_dir which(out|inn) revision"""
import os, sys, json, traceback, shutil
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, DST, WHICH, REV = sys.argv[1:5]
META = {"out": ("LT-OUT-001_Left_Thigh_Outer", "LT-OUT-001", "LEFT_THIGH_OUTER", "Left thigh - outer shell"),
        "inn": ("LT-INN-001_Left_Thigh_Inner", "LT-INN-001", "LEFT_THIGH_INNER", "Left thigh - inner shell")}[WHICH]
NAME, DNO, BODY, DESC = META
os.makedirs(DST, exist_ok=True)
res = {"result": "FAIL", "log": []}
log = res["log"].append


def fvol(part, b):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    return part.MeasureManager.NewMassProperties(un, 0.99, [b]).Volume


try:
    work = os.path.join(DST, NAME + ".prt")
    if os.path.exists(work):
        os.remove(work)
    shutil.copyfile(SRC, work)
    part = nxh.open_part(work)
    vis = sorted([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked], key=lambda b: -fvol(part, b))
    body = vis[0]
    others = [b for b in part.Bodies if b.IsSolidBody and b.Tag != body.Tag]
    if others:
        f = nxf.delete_body(part, others)
        try:
            f.SetName("DELETE_CONSTRUCTION_BODIES")
        except Exception:  # noqa: BLE001
            pass
        log(f"deleted {len(others)} construction solids")
    n = 0
    for b in part.Bodies:
        if not b.IsSolidBody:
            b.Layer = 200; n += 1
    for c in part.Curves:
        c.Layer = 200; n += 1
    for dp in part.Datums:
        try:
            dp.Layer = 200; n += 1
        except Exception:  # noqa: BLE001
            pass
    for sk in part.Sketches:
        try:
            sk.Layer = 200; n += 1
        except Exception:  # noqa: BLE001
            pass
    body.Layer = 1
    try:
        lsc = part.Layers.GetStates(); lsc.SetState(200, NXOpen.Layer.State.Hidden); part.Layers.SetStates(lsc, True)
    except Exception as e:  # noqa: BLE001
        log(f"layer state: {e}")
    log(f"{n} helper objects to layer 200")
    rs = next((r for r in part.GetAllReferenceSets() if r.Name == "SOLID"), None)
    if rs is None:
        rs = part.CreateReferenceSet(); rs.SetName("SOLID")
    rs.AddObjectsToReferenceSet([body])
    body.SetName(BODY)
    v = nxh.volume(part, body)
    res["volume_mm3"] = v
    res["mass_kg_al6061"] = v * 2.70e-6
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    res["faces"] = len(body.GetFaces())
    res["features"] = len(nxh.top_features(part)) if hasattr(nxh, "top_features") else len(list(part.Features))
    res["errors"] = {k: [str(x) for x in v] for k, v in nxh.feature_errors(part).items()}
    for k, val in (("MATERIAL", "Aluminium 6061-T6"), ("DRAWING_NO", DNO), ("REVISION", REV),
                   ("DESCRIPTION", DESC + ", clean feature-based rebuild")):
        try:
            part.SetUserAttribute(k, -1, val, NXOpen.Update.Option.Now)
        except Exception as e:  # noqa: BLE001
            log(f"attribute {k}: {e}")
    nxh.save(part)
    st214 = os.path.join(DST, NAME + "_AP214.step"); st242 = os.path.join(DST, NAME + "_AP242.step")
    nxf.step_export(part, st214, ap242=False, save=True)
    nxf.step_export(part, st242, ap242=True, save=False)
    res["step_sizes"] = [os.path.getsize(st214), os.path.getsize(st242)]
    xt = os.path.join(DST, NAME + ".x_t")
    if os.path.exists(xt):
        os.remove(xt)
    try:
        nxh.UFS.Ps.ExportData([body.Tag], xt); res["x_t_size"] = os.path.getsize(xt)
    except Exception as e:  # noqa: BLE001
        res["x_t_error"] = str(e)
    stl = os.path.join(DST, NAME + ".stl")
    nxre.stl_export(part, body, stl, chord=0.005, max_edge=1.5)
    res["stl_size"] = os.path.getsize(stl)
    res["result"] = "PASS" if not res["errors"] and res["body_ok"] else "FAIL"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(DST, f"_finalize_{WHICH}.json"), res)
