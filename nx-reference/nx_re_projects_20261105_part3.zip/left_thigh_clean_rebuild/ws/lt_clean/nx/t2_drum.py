import os, sys, traceback, math
for k in ("NXH_DIR", "NXCK_DIR", "NXRE_DIR"):
    sys.path.insert(0, os.environ[k])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean\nx")
import NXOpen, nxh, nxf, ltenv
OUT = sys.argv[1]; res = {"result": "FAIL"}
try:
    part = nxh.new_part(os.path.join(OUT, "t2.prt"))
    ltenv.masters(part); dt = ltenv.datums(part)
    f, D, st = ltenv.drum(part, dt)
    res["sketch"] = str(st); res["v_drum"] = nxh.volume(part, D)
    res["census"] = str(nxh.face_census(D))
    # expected: double frustum about Z
    R0 = 137.8 / 2; t = math.tan(math.radians(1.7))
    def frustum(h): r1 = R0 - h * t; return math.pi * h / 3 * (R0 ** 2 + R0 * r1 + r1 ** 2)
    res["v_expect"] = frustum(83.62 - 36.07) + frustum(36.07 + 13.9)
    res["draft_exprs"] = [(e.Name, e.RightHandSide) for e in f.GetExpressions()] if False else None
    ltenv.drum_chamfers(part, D)
    res["v_cham"] = nxh.volume(part, D); res["census2"] = str(nxh.face_census(D))
    res["bbox"] = nxh.bbox(D)
    res["errors"] = str(nxh.feature_errors(part))
    nxh.save(part); res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "t2.json"), res)
