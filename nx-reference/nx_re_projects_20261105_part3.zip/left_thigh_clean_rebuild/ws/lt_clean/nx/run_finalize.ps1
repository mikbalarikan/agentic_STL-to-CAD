param([string]$P = "P14")
$rj = "C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1"
$n = "C:\NX_MCP_WORKSPACE\lt_clean\nx"; $d = "C:\NX_MCP_WORKSPACE\lt_clean\deliver\CAD"
& $rj -Script "$n\finalize.py" -WorkDir "$n\fin" -JArgs "$n\$P\LT-OUT-001_Left_Thigh_Outer.prt",$d,"out","D" -TimeoutSec 3000 | Select-Object -Last 1
& $rj -Script "$n\finalize.py" -WorkDir "$n\fin" -JArgs "$n\$P\LT-INN-001_Left_Thigh_Inner.prt",$d,"inn","C" -TimeoutSec 3000 | Select-Object -Last 1
