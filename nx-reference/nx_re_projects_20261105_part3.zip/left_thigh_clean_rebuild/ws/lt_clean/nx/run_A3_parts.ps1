$rj = "C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1"
$n = "C:\NX_MCP_WORKSPACE\lt_clean\nx"
& $rj -Script "$n\p_stageA.py" -WorkDir "$n\A3" -JArgs "out","$n\base3\LT_BASE.prt","$n\A3" -TimeoutSec 3000 | Select-Object -Last 1
& $rj -Script "$n\p_stageA.py" -WorkDir "$n\A3" -JArgs "inn","$n\base3\LT_BASE.prt","$n\A3" -TimeoutSec 3000 | Select-Object -Last 1
& "$n\run_parts.ps1" -Tag "P1"
