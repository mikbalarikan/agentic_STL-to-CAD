"""BASE part: masters, datums, envelope (drum + body loft), ENVELOPE_REF copy, Shell. argv: out_dir sections.json
Saved as LT_BASE.prt; both part journals start from a copy of it."""
import os, sys, json, time, traceback
for k in ("NXH_DIR", "NXCK_DIR", "NXRE_DIR"):
    sys.path.insert(0, os.environ[k])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\lt_clean\nx")
import NXOpen
import nxh, nxf, nxre
import ltenv

OUT, SEC = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
RJ = os.path.join(OUT, "base.json")
res = {"result": "FAIL", "steps": []}
T0 = time.time()


def step(name, **kw):
    kw["name"] = name; kw["t"] = round(time.time() - T0, 1)
    res["steps"].append(kw); nxh.write_json(RJ, res)


try:
    part = nxh.new_part(os.path.join(OUT, "LT_BASE.prt"))
    dt, E, sfeats = ltenv.envelope(part, SEC, log=lambda m: step("log", msg=m), chamfers=False)
    sols = nxh.solids(part)
    step("envelope", n_solids=len(sols), vol=nxh.volume(part, E), ok=nxh.body_ok(part, E), census=str(nxh.face_census(E)))
    assert len(sols) == 1
    nxf.feature_group(part, sfeats, "BODY_SECTIONS")
    nxre.stl_export(part, E, os.path.join(OUT, "envelope.stl"), chord=0.01)
    fx, (E0,) = nxf.extract_body(part, [E], fix_at_timestamp=True)
    fx.SetName("ENVELOPE_REF")
    E0.Blank()
    step("envelope_ref", vol=nxh.volume(part, E0))
    end = [f for f in E.GetFaces() if abs(nxh.face_mid_normal(f)[0][1] - ltenv.MV["y_end"]) < 0.05]
    assert len(end) == 1, len(end)
    v0 = nxh.volume(part, E)
    b = part.Features.CreateShellBuilder(NXOpen.Features.Feature.Null)
    try:
        b.Tolerance = 0.05          # offset accuracy; 0.01 made every later boolean 3-6x slower
        b.Body = E
        b.RemovedFacesCollector = nxh.collector(part, faces=end)
        b.DefaultThickness.RightHandSide = "wall"
        b.DefaultThicknessFlip = True
        fs = b.CommitFeature()
    finally:
        b.Destroy()
    fs.SetName("SHELL")
    [f for f in part.Features.GetFeatures() if f.FeatureType == "UNITE"][0].SetName("ENVELOPE_UNITE")
    import stages
    vs = stages.vol({"part": part}) if False else None
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    vsh = part.MeasureManager.NewMassProperties(un, 0.99, [E]).Volume
    step("shell", vol=vsh, dv=v0 - vsh, ok=nxh.body_ok(part, E), census=str(nxh.face_census(E)))
    assert vsh < 0.2 * v0, "shell did not hollow the whole envelope"
    f1, f2 = ltenv.drum_chamfers(part, E)
    step("chamfers", top=f1.GetFeatureName(), bot=f2.GetFeatureName(), ok=nxh.body_ok(part, E))
    err = nxh.feature_errors(part)
    step("errors", errors=str(err))
    nxh.save(part)
    res["result"] = "PASS" if not err else "FAIL"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(RJ, res)
