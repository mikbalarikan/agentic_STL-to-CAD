param([string]$B = "base4", [string]$A = "A4", [string]$P = "P8", [string]$OutStages = "", [string]$InnStages = "")
$rj = "C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1"
$n = "C:\NX_MCP_WORKSPACE\lt_clean\nx"
& $rj -Script "$n\p_stageA.py" -WorkDir "$n\$A" -JArgs "out","$n\$B\LT_BASE.prt","$n\$A" -TimeoutSec 3000 | Select-Object -Last 1
& $rj -Script "$n\p_stageA.py" -WorkDir "$n\$A" -JArgs "inn","$n\$B\LT_BASE.prt","$n\$A" -TimeoutSec 3000 | Select-Object -Last 1
if ($OutStages -eq "") { $OutStages = "mating_add,knee_out_add,hip_out_add,ribs_out_add,floor_bosses_out,tabs_out_add,clip,b1_ear_out,mating_cut,knee_out_cut,small_out,hip_out_cut,hip_out_details,tabs_out_cut,side_openings,root_blends,seams" }
if ($InnStages -eq "") { $InnStages = "mating_add,knee_inn_add,knee_inn_ribs,hip_inn_add,ribs_inn_add,tabs_inn_add,clip,small_inn,hub_inn,mating_cut,knee_inn_cut,knee_inn_holes,knee_inn_window,tabs_inn_cut,pins_inn,side_openings,root_blends,joint_reliefs_inn,seams" }
& $rj -Script "$n\p_build.py" -WorkDir "$n\$P" -JArgs "out","$n\$A\LT-OUT-001_Left_Thigh_Outer.prt","$n\$P",$OutStages -TimeoutSec 5400 | Select-Object -Last 1
& $rj -Script "$n\p_build.py" -WorkDir "$n\$P" -JArgs "inn","$n\$A\LT-INN-001_Left_Thigh_Inner.prt","$n\$P",$InnStages -TimeoutSec 5400 | Select-Object -Last 1
