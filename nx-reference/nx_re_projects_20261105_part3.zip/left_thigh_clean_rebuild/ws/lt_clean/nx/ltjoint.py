"""Joint helpers: split at the joint plane, tongue band (outer) / rebate band (inner) along the inside edge of the
joint face, kept only in the joint zones (the scans have the tongue / rebate only there)."""
import NXOpen
import nxh, nxf

# plan rectangles (x0, y0, x1, y1) where the tongue / rebate exists (scan-mapped, tongue_loop.png)
ZONES = {
    "TG1_MX_BODY": (-80.0, 25.0, -10.0, 181.0),     # -X wall, knee junction .. side window
    "TG2_PX_KNEE": (60.0, -22.0, 100.0, 51.0),      # +X knee fairing
    "TG3_MX_HIP": (-80.0, 241.0, 0.0, 300.0),       # -X wall at the hip mouth
    "TG4_PX_HIP": (80.0, 276.0, 140.0, 300.0),      # +X wall at the hip mouth
}


def feats_of_face(part, face):
    tags = nxh.UFS.Modeling.AskFaceFeats(face.Tag)
    out = []
    for f in part.Features.GetFeatures():
        if f.Tag in tags:
            out.append(f)
    return out


def joint_face(body, z):
    """the planar joint face at height z (normal +Z for the outer's top, -Z for the inner's bottom)."""
    out = []
    for f in body.GetFaces():
        if f.SolidFaceType != NXOpen.Face.FaceType.Planar:
            continue
        p, n = nxh.face_mid_normal(f)
        if abs(abs(n[2]) - 1) < 1e-6 and abs(p[2] - z) < 1e-4:
            out.append(f)
    return out


def interior_edges(part, body, faces, shell_feat):
    """edges of the joint faces shared with a face the SHELL made (the inside of the wall)."""
    inner = set(f.Tag for f in body.GetFaces() if shell_feat in feats_of_face(part, f))
    jf = set(f.Tag for f in faces)
    out = []
    for f in faces:
        for e in f.GetEdges():
            other = [g for g in e.GetFaces() if g.Tag not in jf]
            if other and other[0].Tag in inner:
                out.append(e)
    return out


def zone_sketch(part, D, name, zones=ZONES):
    """one fully constrained rectangle per zone on the XY plane (centre = smart point, width / height)."""
    sk = nxf.new_sketch(part, D.xy, D.x, D.origin, name=name)
    for (x0, y0, x1, y1) in zones.values():
        c = nxh.point(part, (x0 + x1) / 2, (y0 + y1) / 2, 0.0)
        nxf.sketch_rect_centered(part, sk, c, round(x1 - x0, 4), round(y1 - y0, 4))
    st = nxf.finish_sketch(sk)
    return sk, st


def contains(body, xyz):
    """1 inside, 2 outside, 3 on (UF point containment)."""
    return nxh.UFS.Modeling.AskPointContainment(list(map(float, xyz)), body.Tag)


def edge_mid(edge):
    """point and unit tangent at the middle of the edge parameter range (UF evaluator)."""
    ev = nxh.UFS.Eval.Initialize2(edge.Tag)
    lim = nxh.UFS.Eval.AskLimits(ev)
    u = 0.5 * (lim[0] + lim[1])
    r = nxh.UFS.Eval.EvaluateUnitVectors(ev, u)
    return list(r[0]), list(r[1])


def band(part, body, jfaces, edges, height, width, zones_sk, op, log=print):
    """thin extrude of the inside edges along +Z (height, width towards the wall), kept inside the zones, then
    united to / subtracted from body. Returns the features."""
    sec = nxh.section(part, edges=edges)
    longest = max(edges, key=lambda e: e.GetLength())
    p, t = edge_mid(longest)
    # direction in XY perpendicular to the edge, towards the joint face (= into the wall)
    nx_, ny_ = -t[1], t[0]
    nn = (nx_ ** 2 + ny_ ** 2) ** 0.5; nx_, ny_ = nx_ / nn, ny_ / nn
    probe_on = lambda s: min(nxh.dist_to(part, f, (p[0] + s * 0.8 * nx_, p[1] + s * 0.8 * ny_, p[2])) for f in jfaces)
    sgn = 1 if probe_on(1) < probe_on(-1) else -1
    inside = (p[0] + sgn * 0.8 * nx_, p[1] + sgn * 0.8 * ny_, p[2] + 0.3)
    fb = None
    for th in ((0, width), ("-(%s)" % width, 0)):
        m = nxh.mark("band try", False)
        fb = nxf.extrude_ex(part, sec, (0, 0, 1), start=0, end=height, thin=th)
        bb = fb.GetBodies()
        if bb and contains(bb[0], inside) == 1:
            log("band side %s" % (th,))
            break
        nxh.undo_to(m); fb = None
    if fb is None:
        raise RuntimeError("band: no side contains the probe point")
    bands = fb.GetBodies()
    fz = nxf.extrude_ex(part, nxh.section_feature(part, [zones_sk.Feature], curves_only=True), (0, 0, 1),
                        start="z_rim-3", end="z_rebate+3", op=nxf.BOOL.Intersect, target=bands[0])
    pieces = [b for b in part.Bodies if b.IsSolidBody and b.Tag != body.Tag and not b.IsBlanked]
    return fb, fz, pieces
