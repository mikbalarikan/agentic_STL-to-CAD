# LT-INN-001 Rev A: Left Thigh, Inner Shell (STL → solid CAD + manufacturing drawings)

Reverse-engineered from `share-Left Thigh - Inner.stl` (3D scan, 7.44 M triangles).
The solid was rebuilt feature by feature on top of the scan in Siemens NX 2206. It is a true
B-rep solid: freeform B-spline skins plus exact planes, cylinders, cones and tori. It is not a
faceted mesh wrapped into STEP. One valid solid, 335 389 mm³, 0.91 kg in Al 6061.

It is the mating half of LT-OUT-001 Rev A and is modelled **in the same coordinate system**: the two STEP files
assemble directly, with no moving or aligning (see "Fit with LT-OUT-001" below).

## Contents

| Folder / file | What it is |
|---|---|
| `CAD/LT-INN-001_Left_Thigh_Inner_AP214.step` | STEP AP214: opens in SolidWorks, Fusion 360, Inventor, Creo, Mastercam, etc. **Use this one for quoting.** |
| `CAD/LT-INN-001_Left_Thigh_Inner_AP242.step` | STEP AP242: the same solid in the newer schema |
| `CAD/LT-INN-001_Left_Thigh_Inner.x_t` | Parasolid: the native kernel of SolidWorks and NX. Opens in SolidWorks as a solid you can edit directly, and imports into Fusion 360 |
| `CAD/LT-INN-001_Left_Thigh_Inner.prt` | Native NX part with the full, editable feature history (reference set `SOLID`) |
| `CAD/LT-INN-001_Left_Thigh_Inner.stl` | Fine tessellation of the CAD solid (for viewing and printing) |
| `Drawings/LT-INN-001.pdf` | Drawing set, 4 sheets, third-angle projection, GD&T per ISO 1101 (datums A mating face = the 7 boss faces, B Ø19.90 knee bore = knee axis, the same axis as datum B of LT-OUT-001, C Ø4 pin hole P3 at the hip end): SH1 general arrangement + notes, SH2 knee, SH3 mating side (boss pockets, pin holes, lip, rebate, hip-ring seat), SH4 interior features (ballooned) with location tables |
| `Drawings/LT-INN-001_SH1..4.dwg`, `_SH1..4.pdf` | The same sheets, one DWG and one PDF per sheet |
| `Drawings/LT-INN-001_dwg.prt` | Native NX drawing (master-model, associative to the part) |
| `Deviation Report/REPORT_deviation.md`, `deviation_map_*.png` | Scan-to-CAD deviation report, colour maps, and the fit check against LT-OUT-001 |
| `Renders/` | Shaded views of the CAD solid, and of the inner + outer assembly |

## Coordinate system (shared with LT-OUT-001)

- Origin: on the knee axis, at the knee floor plane of LT-OUT-001.
- +Z: the knee axis, pointing away from the outer shell (the inner sits on top of the outer; its open side faces -Z).
- +Y: the direction of the hip-ring axis (knee → hip). The hip-ring axis is the line X = 37.97, Z = 35.18.
- Units: mm.

## Fit with LT-OUT-001

Checked against the delivered `LT-OUT-001_Left_Thigh_Outer_AP214.step`, both files read with OpenCascade (details in `Deviation Report/REPORT_deviation.md`):

- Interference (boolean common of the two solids): 0.0 mm³.
- Contact: the 7 boss faces (Z 36.07) sit face to face on the outer boss tops; minimum distance 0.0 mm.
- Holes concentric with their mates: 21 pairs (7 Ø10 pockets on the nubs, 3 Ø4 pin holes on the pins, 7 Ø6 screw holes on the outer Ø5.2 holes, boss columns), largest axis offset 0.0 mm.
- Parting faces parallel: lip Z 35.32 over the outer rim Z 34.76 (0.56 mm shadow gap), rebate floor Z 36.19 over the
  tongue Z 36.07, pocket floors Z 39.17 over the nub tops Z 39.04.

## How accurate it is (full numbers in `Deviation Report/REPORT_deviation.md`)

| Zone | Scan → CAD p50 | p95 | Within 0.5 mm |
|---|---|---|---|
| Outer freeform skin | 0.018 | 0.27 | 98 % |
| Whole part | 0.051 | 1.18 | 88 % |

- Functional features (knee bore Ø19.90, the knee ring and its 4 holes, the 7 bosses and pockets, the 3 pin holes,
  lip / rebate / boss planes) come from circle, cylinder and plane fits with 0.02-0.05 mm residuals, then the shared
  values of LT-OUT-001 (see below).
- Most of the remaining interior deviation is the root fillets of the original (see below).

## Simplifications and assumptions (please read)

1. **Shared features use one design value for both shells.** Where the two scans disagree, the inner takes the value
   of the delivered LT-OUT-001 so the parts fit: boss face plane Z 36.07 (the LT-OUT-001 boss tops and tongue),
   boss locating nub / pocket Ø10.00 (outer scan 10.00, inner scan 9.90), locating pins / holes Ø4.00 (inner holes
   scanned Ø3.82-3.94), boss column Ø15.00, knee hub OD Ø135.70 straight (both scans show a 1.4° draft, Ø138 at the
   joint; LT-OUT-001 is a straight Ø135.70, so the inner matches it for a flush joint), hip-ring axis X 37.97 Z 35.18.
2. **How the two shells touch.** The inner sits on the 7 boss faces only (datum A, face to face with the LT-OUT-001
   boss tops at Z 36.07). Everything else clears the outer: the visible lip faces stay 0.56 mm apart all round (the
   same shadow gap both scans show), the rebate floor 0.12 mm over the tongue, the pocket floors 0.13 mm over the
   nubs, the hip pad 0.12 mm over the flat top of the hip ring, the P3 lug 0.12 mm over the P3 pin base, the ring
   clearance arc 0.11 mm. If you want the lip faces to touch instead, it is one value (lip Z) in the model.
3. **Root fillets.** The rib-to-skin and wall fillets of the original (R2-R3) are not modelled. The CAD corners are sharp,
   and drawing note 4 sets "internal corners R3 max", as on LT-OUT-001.
4. **Styling seams** on the outer skin are modelled as Ø1.8 mm round-bottom grooves, 0.55 mm deep (the same as
   LT-OUT-001), along the scanned centre lines; the wide seam on the +X side is a shallow 0.65 mm groove. The small
   raised panel steps next to the seams (up to 0.5 mm) are blended into the smooth skin.
5. **Threads and blind depths.** The scan cannot show threads or the bottom of small deep holes. Hole sizes are as
   measured: knee ring 4X Ø3.30 (M4 tap drill), channel holes Ø3.30 x 6 deep, boss screw holes Ø6.0 with Ø10.4
   counterbores from the outside, pin holes Ø4.00 x 10 deep (about 3 mm deeper than the LT-OUT-001 pins). Tap where your
   fasteners need threads.
6. **Material.** Not stated in the brief. The drawing assumes Al 6061-T6, the same as LT-OUT-001 (mass shown for that).
7. **Fits.** H7 on the knee bore, and a slip fit on the Ø10 pockets and Ø4 pin holes, suggested from function. A scan
   cannot give design tolerances, so please confirm against your assembly.
8. **Design intent over print warp.** The scanned part is a print with slight warp. The CAD is flat, square and
   concentric; the boss faces are one plane.
9. **Small blends not modelled:** the cove round the base of the Ø40.23 knee ring (about 2.5 mm high, fading into
   the knee face at Ø55) and the sloped thickening of the two side walls next to the hip plate are left as plain
   faces; they show as the larger local values in the deviation maps.
10. **Engraved marks and printed texture** are not modelled.
11. **Projection.** The drawings are third angle (ASME), as LT-OUT-001. They can be switched to first angle on request.
