# LT-INN-001 Left Thigh - Inner shell: reverse-engineering report

Source: `share-Left Thigh - Inner.stl` (7 442 087 triangles, 3D-scan mesh, open in places).
Native CAD: Siemens NX 2206, solid body `LEFT_THIGH_INNER`, rebuilt feature by feature on the scan (not a mesh conversion).

## Part data

- Volume 335,389 mm3, mass 0.906 kg in Al 6061 (2.70 g/cm3).
- Bounding box (model frame, from the STL) [-67.85, -67.85, 35.32, 118.86, 287.4, 110.95].
- Model frame = the LT-OUT-001 frame: origin on the knee axis at the outer's knee floor; +Z = knee axis, away from the
  outer shell; +Y = direction of the hip-ring axis (knee -> hip). The two STEP files assemble as they are.

## Registration of the inner scan into the LT-OUT-001 frame

The inner scan came in its own scanner pose. It was moved by the shared functional features:
- the 7 bosses: inner boss columns + Ø10 pockets fitted onto the outer's boss columns + Ø10 nubs, RMS 0.041 mm;
- the inner boss-face plane (flat within 0.012 mm) set onto the outer boss tops, Z 36.07.
- independent checks: the 3 outer Ø4 pins sit 0.04-0.06 mm from the centres of the inner pin holes; the inner knee
  shell is centred 0.15 mm from the knee axis; joint sections of the two scans close into one tube all round.

## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)

| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |
|---|---|---|---|---|---|---|---|
| whole part | 1,500,000 | +0.168 | 0.051 | 0.646 | 1.179 | 78.9 % | 87.7 % |
| outer freeform skin | 365,214 | +0.003 | 0.018 | 0.138 | 0.270 | 93.0 % | 98.4 % |
| knee (r < 70) | 420,335 | +0.125 | 0.075 | 0.726 | 1.012 | 70.6 % | 83.9 % |
| hip end (y > 262) | 164,847 | +0.143 | 0.048 | 0.591 | 1.020 | 81.2 % | 88.6 % |
| interior (ribs, pockets, bosses) | 549,604 | +0.317 | 0.085 | 1.188 | 2.571 | 75.2 % | 83.1 % |

CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 0.059, p90 1.067, p95 2.032 mm.

Most of the remaining interior deviation is the root fillets of the original (not modelled, see the README) and
the shared features that were set to the LT-OUT-001 values (README item 1).

## Fit check against LT-OUT-001 Rev A (both STEP files read with OpenCascade)

- Interference (boolean common of the two solids): **0.0 mm3**.
- Minimum distance between the solids: 0.0 mm (0 = faces in contact).
- Inner surface points in the joint band (Z < 40) that lie inside the outer solid: 0 of 24422.
- Gap distribution of those points to the outer solid: {'-99.00--0.01': 0, '-0.01-0.01': 2957, '0.01-0.15': 3430, '0.15-0.30': 919, '0.30-0.50': 523, '0.50-1.00': 3562, '1.00-999.00': 13031}.

Mating planes in the joint (planar faces normal to Z, area in mm2):

| part | Z | area |
|---|---|---|
| outer +Z | 34.760 | 1265 |
| inner -Z | 35.320 | 1258 |
| inner -Z | 36.070 | 744 |
| outer +Z | 36.070 | 1826 |
| inner -Z | 36.190 | 1208 |
| outer +Z | 36.240 | 27 |
| inner -Z | 36.360 | 54 |
| outer +Z | 39.040 | 401 |
| inner -Z | 39.170 | 352 |

- Boss faces: inner -Z faces at Z 36.070 on the outer +Z boss tops at Z 36.070: coplanar, face to face (datum A).
  This is the only contact.
- Rebate floor Z 36.190 over the outer tongue top Z 36.070: 0.12 mm clear.
- Lip faces: inner Z 35.320 over the outer rim Z 34.760: parallel, 0.56 mm shadow gap (as both scans show).
- P3 lug face Z 36.360 over the outer P3 pin base Z 36.240: 0.12 mm clear. Pocket floors Z 39.170 over the nub
  tops Z 39.040: 0.13 mm clear. Hip pad Z 85.320 over the hip-ring top Z 85.200; ring clearance Ø105.25 on the
  Ø105.03 ring.

Concentricity of the mating holes (inner hole axis vs outer feature axis, XY offset), max 0.0 mm:

| feature | inner X, Y, Ø | outer X, Y, Ø | offset |
|---|---|---|---|
| boss pocket / nub | [-22.0, 264.93, 10.0] | [-22.0, 264.93, 10.0] | 0.0000 |
| boss pocket / nub | [97.95, 264.95, 10.0] | [97.95, 264.95, 10.0] | 0.0000 |
| boss pocket / nub | [86.45, 165.96, 10.0] | [86.45, 165.96, 10.0] | 0.0000 |
| boss pocket / nub | [-17.05, 165.91, 10.0] | [-17.05, 165.91, 10.0] | 0.0000 |
| boss pocket / nub | [-25.1, 77.45, 10.0] | [-25.1, 77.45, 10.0] | 0.0000 |
| boss pocket / nub | [75.85, 29.86, 10.0] | [75.85, 29.86, 10.0] | 0.0000 |
| boss pocket / nub | [61.35, -40.01, 10.0] | [61.35, -40.01, 10.0] | 0.0000 |
| pin hole / pin | [108.97, 194.32, 4.0] | [108.97, 194.32, 4.0] | 0.0000 |
| pin hole / pin | [97.46, 131.44, 4.0] | [97.46, 131.44, 4.0] | 0.0000 |
| pin hole / pin | [-38.09, 245.35, 4.0] | [-38.09, 245.35, 4.0] | 0.0000 |
| screw hole / outer boss hole | [-22.0, 264.93, 6.0] | [-22.0, 264.93, 5.2] | 0.0000 |
| screw hole / outer boss hole | [97.95, 264.95, 6.0] | [97.95, 264.95, 5.2] | 0.0000 |
| screw hole / outer boss hole | [86.45, 165.96, 6.0] | [86.45, 165.96, 5.2] | 0.0000 |
| screw hole / outer boss hole | [-17.05, 165.91, 6.0] | [-17.05, 165.91, 5.2] | 0.0000 |
| screw hole / outer boss hole | [-25.1, 77.45, 6.0] | [-25.1, 77.45, 5.2] | 0.0000 |
| screw hole / outer boss hole | [75.85, 29.86, 6.0] | [75.85, 29.86, 5.2] | 0.0000 |
| screw hole / outer boss hole | [61.35, -40.01, 6.0] | [61.35, -40.01, 5.2] | 0.0000 |
| boss column / outer boss | [61.35, -40.01, 15.0] | [61.35, -40.01, 15.0] | 0.0000 |
| boss column / outer boss | [75.85, 29.86, 15.0] | [75.85, 29.86, 15.0] | 0.0000 |
| boss column / outer boss | [-25.1, 77.45, 15.0] | [-25.1, 77.45, 15.0] | 0.0000 |
| boss column / outer boss | [-22.0, 264.93, 15.0] | [-22.0, 264.93, 15.0] | 0.0000 |
