﻿> SUPERSEDED 2026-10-30: this hand-off describes the fix-round package (runM13), which is now in `_fixround_2026-10-30`. The delivery is restored to runK10 (first Rev A); see STATUS.md top note and section "Restore 2026-10-30".

# LT-INN-001 review fix (2026-10-29) - hand-off

Task (from the lead session): fix the CAD errors the user found in the NX overlay (u1 knee fin, u2 knee tail, u3
channel / posts / pads / floor, screenshots in `review_user_2026-10-29\`) plus everything a systematic two-way sweep
finds; then regenerate the whole package. It stays Rev A (nothing sent). Never stop NX processes that are not yours
(the Chest session runs NX too). One output folder per NX run. Venv `C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe`,
NX via `C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1` (run in the background, 30-40 min per stage).

## Done

1. Sweep + diagnosis tools in `an/`: `i90_clusters.py` (two-way signed clusters, full-res scan, thr 0.3),
   `i91_crops.py` (overlay crops; `CROP_SPLIT=1` = CAD | scan | overlay; `views:<json>` mode), `i92_secs.py`
   (scan vs CAD sections), `i93_depth.py` / `i93top.py` (open-side / top-side height maps), `i94_zoom.py`,
   `i98_showfix.py`, `fixlib.py` (fix specs -> manifold meshes, hf_tool), `i99_autofix.py` (plane fixes),
   `i97_sim.py` (mesh simulation of a fix list on a CAD STL), `i97_nxprep.py` (-> `nx/fixes_L.json`),
   `i100_table.py` (before / after cluster table).
2. NX stage L in `nx/build_inner.py` (STAGES ...KL). Run `nx/runL11` (resumed from `nx/runK10/Left_Thigh_Inner.prt`):
   PASS, one solid INNER 341 728 mm3, body_ok, 0 failed tools; STL `nx/runL11/inner_Z.stl`.
   Whole part p50 0.048 / p95 0.78 / 91.3 % within 0.5 (Rev A 0.051 / 1.19 / 87.5 %). Exactly the mesh sim5.
3. STATUS.md section "Review fix 2026-10-29" with causes, numbers and the before/after cluster table.
4. Fresh overlay crops of the user's spots before | after: `work/verify/user_spots_before_after.png` - all fixed.

## Done in the finishing session (2026-10-29/30): steps A-H

A. Stage M = stage L re-run from runK10 with `nx/fixes_M.json` (`an/m3_fixes.py`): P3 gusset rib t 2.6 + Ø2.8 hole (M01,
   M01h), B6 / B7 buttress start Y 233 (F10 / F11), right window outline + jamb cuts (M02a, M03a/b, `an/m2_rwin.py`), cove
   F06 as a true arc (and the `revolve_profile` a0/a1 bug fixed). Final part `nx/runM13` (bumps A039 / A040 KEPT, lead
   decision 2026-10-30; `nx/runM16` with them cut back via `nx/fixes_M2.json` is dropped). All prototyped on the mesh first.
B. Finalized `nx/runM13` to `deliver/CAD` (2026-10-30 11:46): 341 376 mm3, 0.922 kg; stepcheck AP242 valid, AP214 has one
   bad 0.1 mm2 face -> AP242 is the recommended file (README).
C. Fit vs LT-OUT-001 Rev A (`work/fit_M13_revA.json`): 127.9 mm3, all at the two hip-pad bumps (2 x ~64 mm3, where Rev B
   puts its slots), nothing else; 21 concentric pairs, max offset 0.0.
D. Deviation `final3`: whole part p50 0.048 / p95 0.76 / 91.5 % within 0.5; skin 0.018 / 0.27 / 98.5 %; maps + report.
E. Overlay `Deviation_Check/LT-INN-001_Left_Thigh_Inner_vs_SCAN.prt` rebuilt from the runM13 CAD.
F. Renders regenerated.
G. Drawings (`work/dwgM` -> `deliver/Drawings`): pin-hole depths, knee-hole chamfer, cove note, note 6 "mates with LT-OUT-001
   REV B"; 15 dims read back, all 4 sheets checked by eye.
H. README (mating part LT-OUT-001 Rev B, item 12), `CLIENT_MESSAGE.txt` (outer Rev B adds the slots), zip (37 entries,
   testzip OK). Cluster table revA vs finalM13 in STATUS.md. Notes for the other sessions: side-session-notes
   `lt-inner-stageM.md` (incl. the bump geometry for the Rev B slots); outer-revb was messaged the final CAD path.

## Open (see STATUS.md "Open points")

1. DONE 2026-10-30: final fit check against LT-OUT-001 Rev B (`work/fit_revB.json` AP214, `work/fit_revB_AP242.json` AP242):
   0.0 mm3, 21 pairs at 0.0 offset; README, REPORT_deviation, CLIENT_MESSAGE and zip updated (STATUS.md).
2. AP214 sliver face: decided, AP242 is the recommended file (README, client text; AP242 fit check identical).
3. Nothing has been sent to the client; the package is still Rev A.
