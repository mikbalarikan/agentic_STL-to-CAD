"""Rebate vs the outer tongue: rasterise the outer tongue footprint (part 1 plateaus_nx level 36.07) and the inner's
rebate mask (depth 35.80..36.20 near the wall), measure boundary offsets."""
import json, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.path import Path
from scipy import ndimage
from arcfit import seg_points
from common import W
P1 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\work\plateaus_nx.json"
L = [l for l in json.load(open(P1)) if abs(l["h"] - 36.07) < 0.01][0]
d = np.load(W + r"\hmap2.npz"); H = d["H"]; X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
ny, nx = H.shape
xs = X0 + (np.arange(nx) + 0.5) * C; ys = Y0 + (np.arange(ny) + 0.5) * C
XX, YY = np.meshgrid(xs, ys); pts = np.c_[XX.ravel(), YY.ravel()]
T = np.zeros(len(pts), bool)
polys = []
def segs_of(sl):
    out = []
    for s in sl:
        out.append(("L", np.array(s[1]), np.array(s[2])) if s[0] == "L" else ("A", np.array(s[1]), np.array(s[2]), np.array(s[3]), s[4], s[5]))
    return out
for g in L["groups"]:
    P = np.vstack([seg_points(s, 12) for s in segs_of(g["outer"])]); polys.append(P)
    m = Path(P).contains_points(pts)
    for hsl in g["holes"]:
        m &= ~Path(np.vstack([seg_points(s, 12) for s in segs_of(hsl)])).contains_points(pts)
    T |= m
T = T.reshape(ny, nx)
Z = -H
R = (Z > 35.80) & (Z < 36.20)
# signed distance maps
dT = ndimage.distance_transform_edt(~T) * C   # outside distance to tongue
# rebate cells outside the tongue: how far outside?
out = R & ~T
near = out & (dT < 2.0)
print("tongue cells", T.sum(), "rebate cells", R.sum(), "rebate outside tongue within 2 mm:", near.sum())
h, e = np.histogram(dT[near], bins=np.arange(0, 2.01, 0.1)); print("dist of rebate cells outside the tongue:", list(zip(np.round(e[:-1], 1), h)))
# inside tongue: cells that are not rebate (inner material lower than 35.8 = clash)
clash = T & (Z < 35.80)
print("tongue cells where the inner reaches below 35.80 (clash in scan):", clash.sum())
fig, ax = plt.subplots(figsize=(18, 30))
ax.imshow(np.where(T, 1.0, np.nan), origin="lower", extent=[X0, X1, Y0, Y1], cmap="Blues", vmin=0, vmax=1.5)
ax.imshow(np.where(R, 1.0, np.nan), origin="lower", extent=[X0, X1, Y0, Y1], cmap="Oranges", vmin=0, vmax=1.5, alpha=0.6)
ax.imshow(np.where(clash, 1.0, np.nan), origin="lower", extent=[X0, X1, Y0, Y1], cmap="Reds", vmin=0, vmax=1)
ax.set_aspect("equal"); ax.grid(lw=0.3); fig.tight_layout(); fig.savefig(W + r"\rebate_vs_tongue.png", dpi=45)
