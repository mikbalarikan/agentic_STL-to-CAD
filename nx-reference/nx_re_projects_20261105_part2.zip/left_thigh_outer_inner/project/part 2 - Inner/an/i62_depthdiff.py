"""Depth (min z seen from the open side) of the scan vs a CAD STL, cell by cell; map of CAD - scan.
+ = the CAD surface is higher (further from the open side) than the scan = CAD MISSING material there.
usage: i62_depthdiff.py cad.stl tag"""
import sys, numpy as np, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
stl, tag = sys.argv[1], sys.argv[2]
d = np.load(W + r"\hmap2.npz"); H = d["H"]; X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
ny, nx = H.shape
import open3d as o3d
cm = o3d.io.read_triangle_mesh(stl)
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
xs = X0 + (np.arange(nx) + 0.5) * C; ys = Y0 + (np.arange(ny) + 0.5) * C
XX, YY = np.meshgrid(xs, ys)
rays = np.zeros((ny * nx, 6), np.float32); rays[:, 0] = XX.ravel(); rays[:, 1] = YY.ravel(); rays[:, 2] = 0.0; rays[:, 5] = 1.0
t = sc.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
Hc = np.where(np.isfinite(t), -t, -np.inf).reshape(ny, nx)
zs, zc = -H, -Hc
diff = np.where(np.isfinite(zs) & np.isfinite(zc), zc - zs, np.nan)
np.savez_compressed(W + rf"\depthdiff_{tag}.npz", diff=diff, zs=zs, zc=zc)
fig, ax = plt.subplots(1, 2, figsize=(34, 30))
im = ax[0].imshow(np.clip(diff, -3, 3), origin="lower", extent=[X0, X1, Y0, Y1], cmap="seismic", vmin=-3, vmax=3)
plt.colorbar(im, ax=ax[0], shrink=0.4); ax[0].set_title("CAD depth - scan depth (mm); red = CAD missing material")
im = ax[1].imshow(np.where(np.isfinite(zs), zs, np.nan), origin="lower", extent=[X0, X1, Y0, Y1], cmap="nipy_spectral", vmin=34, vmax=112)
plt.colorbar(im, ax=ax[1], shrink=0.4); ax[1].set_title("scan depth z (min z per cell)")
for a in ax:
    a.set_xticks(np.arange(-100, 126, 10)); a.set_yticks(np.arange(-70, 292, 10)); a.grid(lw=0.3)
fig.tight_layout(); fig.savefig(W + rf"\depthdiff_{tag}.png", dpi=40)
a = np.abs(diff[np.isfinite(diff)])
print("cells", a.size, "|diff| p50 %.3f p90 %.3f; > 1 mm %.1f %%; CAD missing > 1 mm %.1f %%" % (np.percentile(a, 50), np.percentile(a, 90), 100 * (a > 1).mean(), 100 * (diff[np.isfinite(diff)] > 1).mean()))
