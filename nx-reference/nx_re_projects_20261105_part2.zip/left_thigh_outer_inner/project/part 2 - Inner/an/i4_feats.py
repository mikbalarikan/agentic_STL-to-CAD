"""Inner: circle fits of the boss pockets/holes and pin lugs in the inner rim frame (z=0 on rim, +Z open side),
at several depths. Prints radius profile per feature."""
import numpy as np, json
from common import load, section, fit_circle_robust, W
v, f = load(frame=False)
pr = json.load(open(W + r"\parting_raw.json")); cc = np.array(pr["c"]); z = np.array(pr["n"])
x = np.array([1.0, 0, 0]); x -= z * (x @ z); x /= np.linalg.norm(x); y = np.cross(z, x)
vp = (v - cc) @ np.vstack([x, y, z]).T
np.save(W + r"\Rrim.npy", np.r_[np.vstack([x, y, z]), cc[None]])
F = {"B1": (-27, -142), "B2": (-42, -72), "B3": (60, -24), "B4": (-50, 64), "B5": (53, 64), "B6": (-62, 163), "B7": (57, 163),
     "P1": (-75, 92), "P2": (-40, 30), "P3": (75, 143)}
out = {}
secs = {zz: section(vp, f, 2, zz).reshape(-1, 3)[:, :2] for zz in (0.3, -0.5, -1.0, -2.0, -3.0, -4.0, -5.0, -7.0, -9.0, -12.0)}
for k, c0 in F.items():
    print(k)
    out[k] = []
    for zz, p in secs.items():
        d = np.hypot(p[:, 0] - c0[0], p[:, 1] - c0[1])
        loc = p[d < 9]
        if len(loc) < 30: continue
        # find radii clusters
        dd = np.hypot(loc[:, 0] - c0[0], loc[:, 1] - c0[1])
        h, e = np.histogram(dd, bins=np.arange(0, 9.01, 0.25))
        pk = [round(e[i] + 0.125, 2) for i in np.argsort(h)[::-1][:3]]
        res = []
        for r0 in sorted(set(round(r) for r in pk)):
            c = np.array(c0, float); r = r0; w = 1.0
            ok = True
            for _ in range(6):
                dd = np.hypot(loc[:, 0] - c[0], loc[:, 1] - c[1]); m = np.abs(dd - r) < w
                if m.sum() < 20: ok = False; break
                c, r, sd, kk = fit_circle_robust(loc[m]); w = max(0.3, min(w, 5 * sd))
            if ok: res.append((round(c[0], 3), round(c[1], 3), round(2 * r, 3), round(sd, 3), int(m.sum())))
        print(f"  z {zz:5.1f}", res)
        out[k].append((zz, res))
json.dump(out, open(W + r"\inner_feats_raw.json", "w"))
