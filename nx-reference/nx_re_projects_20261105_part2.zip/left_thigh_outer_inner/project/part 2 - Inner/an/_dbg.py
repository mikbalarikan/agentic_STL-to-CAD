import sys
exec(open("i96_reconcile.py").read().split("# exclusion: mating")[0].replace("tag = sys.argv[1]", "tag='revA'").replace("AMIN = float(sys.argv[2]) if len(sys.argv) > 2 else 3.0","AMIN=3.0"))
for nm,(x,y) in {"rail":(50,60),"rail2":(60,100),"buttress":(-28,250),"post":(-30,-50.5),"floor":(30,0),"hipfloor":(37,213),"rib20":(38,183)}.items():
    j=int((x-X0)/C); i=int((y-Y0)/C)
    w=slice(i-3,i+4), slice(j-3,j+4)
    print(nm, "zs", np.round(zs[i,j],2), "zc", np.round(zc[i,j],2), "res", np.round(np.nanmedian(res[w]),3), "g", np.round(ga[i,j],3), np.round(gb[i,j],3), "planar", planar[w].mean().round(2), "lab", lab[i,j], "cnt", cnt[lab[i,j]] if lab[i,j]>=0 else 0)
print("res pct over finite full:", np.nanpercentile(res[full], [10,25,50,75]))
for k in [lab[int((183-Y0)/C), int((38-X0)/C)], lab[int((60-Y0)/C), int((50-X0)/C)], lab[int((250-Y0)/C), int((-28-X0)/C)]]:
    if k < 0: print("no patch"); continue
    m = lab == k; X, Y, Z = XX[m], YY[m], zs[m]
    A = np.c_[X, Y, np.ones(len(X))]; co, *_ = np.linalg.lstsq(A, Z, rcond=None); r = Z - A @ co
    ev = np.sort(np.linalg.eigvalsh(np.cov(np.c_[X, Y].T)))
    dm = zc[m] - A @ co
    print(k, m.sum()*C*C, "rms", np.sqrt((r**2).mean()).round(3), "thin", (4*np.sqrt(ev[0])).round(2), co.round(4), "dm med", np.nanmedian(dm).round(2), "need frac", np.mean(dm > 0.3).round(2))
