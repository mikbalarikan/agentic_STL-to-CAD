"""Simulate the stage-L fixes on the CAD mesh with manifold3d: adds (clipped to the envelope) first, then cuts.
usage: i97_sim.py cad.stl fixes.json out.stl [only ids comma list]
Envelope = nx/envL/envelope_unlifted.stl lifted by seat_dz (stage-A body, the clip used by the build)."""
import sys, os, json, time
import numpy as np
from fixlib import mesh_to_manifold, manifold_to_stl, full_tool, DZ, ROOT

cad, fx, out = sys.argv[1], sys.argv[2], sys.argv[3]
only = set(sys.argv[4].split(",")) if len(sys.argv) > 4 else None
t0 = time.time()
body = mesh_to_manifold(cad)
env = mesh_to_manifold(os.path.join(ROOT, "nx", "envL", "envelope_unlifted.stl")).translate([0, 0, DZ])
v0 = body.volume()
fixes = [f for f in json.load(open(fx)) if (only is None or f["id"] in only) and not f.get("skip")]
log = []
for kind in ("add", "cut"):
    for f in fixes:
        if f["kind"] != kind:
            continue
        t = full_tool(f)
        if kind == "add":
            if f.get("clip", "envelope") == "envelope":
                t = t ^ env
            nb = body + t
        else:
            nb = body - t
        dv = nb.volume() - body.volume()
        body = nb
        log.append((f["id"], kind, round(dv, 1)))
print("volume", round(v0), "->", round(body.volume()), "genus", body.genus(), "status", body.status())
for l in log:
    print(*l)
manifold_to_stl(body, out)
print("written", out, round(time.time() - t0, 1), "s")
