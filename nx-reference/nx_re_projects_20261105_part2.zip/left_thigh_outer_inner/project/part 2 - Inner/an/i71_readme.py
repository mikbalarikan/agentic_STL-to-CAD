"""Fill the README placeholders (@VOL@, @MASS@, @FIT@, @DEV@) and the client text (@SKIN@) from the final results.
usage: i71_readme.py dev_tag fit_json"""
import sys, os, json
from common import W
ROOT = os.path.dirname(W)
TAG, FIT = sys.argv[1], sys.argv[2]
fin = json.load(open(os.path.join(ROOT, "deliver", "CAD", "_finalize.json")))
dev = json.load(open(os.path.join(W, f"dev2_{TAG}.json")))["scan_to_cad"]
fit = json.load(open(FIT))
vol = f"{fin['volume_mm3']:,.0f}".replace(",", " ")
mass = f"{fin['mass_g_al6061'] / 1000:.2f}"
nconc = len(fit["concentricity"])
fit_txt = "\n".join([
    f"Checked against the delivered `LT-OUT-001_Left_Thigh_Outer_AP214.step`, both files read with OpenCascade "
    f"(details in `Deviation Report/REPORT_deviation.md`):",
    "",
    f"- Interference (boolean common of the two solids): {fit['interference_mm3']} mm³.",
    f"- Contact: the 7 boss faces (Z 36.07) sit face to face on the outer boss tops; minimum distance {fit['min_distance']} mm.",
    f"- Holes concentric with their mates: {nconc} pairs (7 Ø10 pockets on the nubs, 3 Ø4 pin holes on the pins, "
    f"7 Ø6 screw holes on the outer Ø5.2 holes, boss columns), largest axis offset {fit['concentricity_max_offset']} mm.",
    "- Parting faces parallel: lip Z 35.32 over the outer rim Z 34.76 (0.56 mm shadow gap), rebate floor Z 36.19 over the",
    "  tongue Z 36.07, pocket floors Z 39.17 over the nub tops Z 39.04.",
])
row = lambda nm, s: f"| {nm} | {s['p50']:.3f} | {s['p95']:.2f} | {100 * s['within_0p5']:.0f} % |"
dev_txt = "\n".join(["| Zone | Scan → CAD p50 | p95 | Within 0.5 mm |", "|---|---|---|---|",
                     row("Outer freeform skin", dev["outer_skin"]), row("Whole part", dev["all"]), "",
                     "- Functional features (knee bore Ø19.90, the knee ring and its 4 holes, the 7 bosses and pockets, the 3 pin holes,",
                     "  lip / rebate / boss planes) come from circle, cylinder and plane fits with 0.02-0.05 mm residuals, then the shared",
                     "  values of LT-OUT-001 (see below).",
                     "- Most of the remaining interior deviation is the root fillets of the original (see below)."])
p = os.path.join(ROOT, "deliver", "README.md")
s = open(p, encoding="utf-8").read()
s = s.replace("@VOL@", vol).replace("@MASS@", mass).replace("@FIT@", fit_txt).replace("@DEV@", dev_txt)
open(p, "w", encoding="utf-8").write(s)
c = os.path.join(ROOT, "CLIENT_MESSAGE.txt")
t = open(c, encoding="utf-8").read().replace("@SKIN@", f"{dev['outer_skin']['p50']:.2f}")
open(c, "w", encoding="utf-8").write(t)
print("README and client text filled:", vol, mass, fit["interference_mm3"], dev["outer_skin"]["p50"])
