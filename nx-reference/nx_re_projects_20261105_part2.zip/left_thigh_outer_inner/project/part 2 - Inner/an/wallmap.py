"""Wall-thickness map: scan points inside the CAD envelope by 0.8..8 mm, plotted in (y, theta) polar coords."""
import sys, numpy as np, open3d as o3d, pyvista as pv, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
cad = sys.argv[1]; tag = sys.argv[2]
cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices()
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
m = pv.read(W + r"\scan_600k_framed.ply"); P = np.asarray(m.points, np.float32)
d = sc.compute_signed_distance(o3d.core.Tensor(P)).numpy()
s = np.load(W + r"\skin_fit.npz"); pc = s["pc"]; ZC = float(s["ZC"])
th = np.degrees(np.arctan2(P[:, 2] - ZC, P[:, 0] - np.polyval(pc, P[:, 1])))
sel = (d < -0.8) & (d > -8) & (P[:, 2] < 35)
fig, ax = plt.subplots(figsize=(26, 11))
o = np.argsort(-d[sel])
sca = ax.scatter(P[sel, 1][o], th[sel][o], c=-d[sel][o], s=0.4, cmap="jet", vmin=1.5, vmax=4.5)
plt.colorbar(sca); ax.set_xlabel("y"); ax.set_ylabel("theta"); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(-70, 300, 10))
ax.set_title("depth below envelope of scan points (inner walls)")
fig.tight_layout(); fig.savefig(W + rf"\wallmap_{tag}.png", dpi=70)
