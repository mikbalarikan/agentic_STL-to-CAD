"""Automatic open-side height-field fixes: every region where the CAD z differs from the scan z by > THR (root-fillet
bands masked) gets a plane fitted to the scan surface over it; if the plane fits (rms < RMS_OK), a z-prism tool is
emitted: ADD = region prism above the plane (clipped to the envelope by the build), CUT = region prism from z 30 up
to the plane. Region outline: the diff region dilated by 0.6 mm and limited to where the scan is at/nearer
(add) or at/deeper (cut) than the plane + 0.5 mm, outline fitted to lines/arcs (arcfit).
usage: i99_autofix.py tag out.json [prefix=A] [skip_box x0,x1,y0,y1;...]"""
import sys, os, json
import numpy as np
from scipy import ndimage
import contourpy
from matplotlib.path import Path as MPath
from fixlib import depth, fit_segs, W, DZ

tag, out = sys.argv[1], sys.argv[2]
PRE = sys.argv[3] if len(sys.argv) > 3 else "A"
SKIP = [[float(t) for t in b.split(",")] for b in sys.argv[4].split(";")] if len(sys.argv) > 4 and sys.argv[4] else []
THR, RMS_OK, AMIN, FR = 0.3, 0.15, 4.0, 1.8
TOP = tag.startswith("top_")
P = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))
d = depth(tag); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
zs, zc = d["zs"], d["zc"]
ny, nx = zs.shape
XX, YY = np.meshgrid(X0 + (np.arange(nx) + .5) * C, Y0 + (np.arange(ny) + .5) * C)
diff = zc - zs
gy, gx = np.gradient(np.nan_to_num(zs, nan=200.0), C); steep = np.hypot(gx, gy) > 1.5
gy, gx = np.gradient(np.nan_to_num(zc, nan=200.0), C); steepc = np.hypot(gx, gy) > 1.5
dist = ndimage.distance_transform_edt(~steep) * C
fil = (dist < FR) & (diff > 0) & (diff < 1.0)
edge = (ndimage.distance_transform_edt(~(steep | steepc)) * C) < 0.4
excl = np.zeros((ny, nx), bool)
for b in P["bosses"]:
    excl |= np.hypot(XX - b["x"], YY - b["y"]) < b["col_d"] / 2 + 0.8
for p in P["pins"]:
    excl |= np.hypot(XX - p["x"], YY - p["y"]) < p["lug_d"] / 2 + 0.5
excl |= np.hypot(XX, YY) < P["hub"]["bore_d"] / 2 + 1.0
kr = P["knee_ring_holes"]
for k in range(kr["n"]):
    a_ = np.radians(kr["clock"] + k * 360.0 / kr["n"])
    excl |= np.hypot(XX - kr["pcd"] / 2 * np.cos(a_), YY - kr["pcd"] / 2 * np.sin(a_)) < kr["d"] / 2 + 1.0
for h in P["channel_holes"]:
    excl |= np.hypot(XX - h["x"], YY - h["y"]) < h["d"] / 2 + 0.6
for x0, x1, y0, y1 in SKIP:
    excl |= (XX > x0) & (XX < x1) & (YY > y0) & (YY < y1)
fin = np.isfinite(diff)
fixes, rep = [], []
for kind, sel in (("add", fin & (diff > THR)), ("cut", fin & (diff < -THR))):
    sel = sel & ~fil & ~edge & ~excl
    sel = ndimage.binary_opening(sel, iterations=1)
    lab, n = ndimage.label(sel)
    for k, sl in enumerate(ndimage.find_objects(lab), 1):
        pad = 6
        s0 = slice(max(sl[0].start - pad, 0), min(sl[0].stop + pad, ny)); s1 = slice(max(sl[1].start - pad, 0), min(sl[1].stop + pad, nx))
        m = lab[s0, s1] == k
        if m.sum() * C * C < AMIN:
            continue
        X, Y, Z = XX[s0, s1][m], YY[s0, s1][m], zs[s0, s1][m]
        A = np.c_[X, Y, np.ones(len(X))]
        inl = np.ones(len(Z), bool)
        for _ in range(4):
            co, *_ = np.linalg.lstsq(A[inl], Z[inl], rcond=None)
            r = Z - A @ co
            inl = np.abs(r) < max(0.25, 2.5 * np.std(r[inl]))
        rms = float(np.sqrt((r[inl] ** 2).mean())); fr = float(inl.mean())
        zmean = float(np.mean(A @ co))
        info = dict(kind=kind, area=round(float(m.sum() * C * C), 1), x=round(float(X.mean()), 1), y=round(float(Y.mean()), 1),
                    z=round(zmean, 2), plane=[round(float(c_), 5) for c_ in co], rms=round(rms, 3), inl=round(fr, 2),
                    dmed=round(float(np.median(diff[s0, s1][m])), 2))
        if TOP:
            info["plane"] = [round(-float(c_), 5) for c_ in co]
        if (-zmean if TOP else zmean) < 37.6:
            info["skip"] = "joint band"; rep.append(info); continue
        if rms > RMS_OK or fr < 0.7:
            info["skip"] = "not planar"; rep.append(info); continue
        flat = np.hypot(co[0], co[1]) < 0.015
        if flat:
            co = np.array([0.0, 0.0, round((float(np.median(Z[inl])) - DZ) / 0.05) * 0.05 + DZ])
        F = co[0] * XX[s0, s1] + co[1] * YY[s0, s1] + co[2]
        Zs = zs[s0, s1]
        G = ((F + 0.5) - Zs) if kind == "add" else (Zs - (F - 0.5))
        G = np.where(np.isfinite(G), G, -1.0)
        reg = ndimage.binary_dilation(m, iterations=3) & (G > 0) & ~excl[s0, s1]
        reg = ndimage.binary_fill_holes(reg) & ~excl[s0, s1] if kind == "add" else reg
        Gm = np.where(reg, np.clip(G, 0.05, 0.5), -0.5)
        Gm = ndimage.gaussian_filter(np.pad(Gm, 2, constant_values=-0.5), 0.6)
        loops = []
        for Cn in contourpy.contour_generator(z=Gm, line_type="Separate").lines(0.0):
            if np.linalg.norm(Cn[0] - Cn[-1]) > 1e-6:
                continue
            Q = np.c_[X0 + (s1.start + Cn[:, 0] - 2 + 0.5) * C, Y0 + (s0.start + Cn[:, 1] - 2 + 0.5) * C][:-1]
            Ar = 0.5 * (np.dot(Q[:, 0], np.roll(Q[:, 1], -1)) - np.dot(Q[:, 1], np.roll(Q[:, 0], -1)))
            if abs(Ar) >= 1.0:
                loops.append((abs(Ar), Q))
        loops.sort(key=lambda t: -t[0])
        groups = []
        for Ar, Q in loops:
            host = None
            for g in groups:
                if MPath(g[0]).contains_points(Q[::4]).all():
                    host = g
            (groups.append([Q]) if host is None else host.append(Q))
        for gi, g in enumerate(groups):
            fid = f"{PRE}{len(fixes) + 1:03d}"
            if TOP:
                if kind == "add":
                    continue          # CAD top too low: left to the review (skin adds are not automatic)
                pl = [-float(c_) for c_ in co]
                fixes.append(dict(id=fid, kind="cut", type="zprism", loops=[fit_segs(Q, 0.1) for Q in g], auto=True, side="top",
                                  z0=0.0, z1=130.0, plane=pl, area=info["area"], at=[info["x"], info["y"], -info["z"]],
                                  note=f"auto top cut: CAD stands {-info['dmed']:+.2f} mm above the scan top, scan plane {[round(v, 4) for v in pl]}"))
                if flat:
                    fixes[-1].pop("plane"); fixes[-1].update(z0=-float(co[2]), z1=130.0)
                continue
            f = dict(id=fid, kind=kind, type="zprism", loops=[fit_segs(Q, 0.1) for Q in g], auto=True,
                     note=f"auto {kind}: scan {'plane' if not flat else 'level'} {('Z %.2f' % co[2]) if flat else str(info['plane'])}, CAD {info['dmed']:+.2f} mm",
                     area=info["area"], at=[info["x"], info["y"], info["z"]])
            if flat:
                f.update(z0=float(co[2]), z1=130.0) if kind == "add" else f.update(z0=30.0, z1=float(co[2]))
            else:
                f.update(z0=30.0, z1=130.0, plane=[float(c_) for c_ in co])
            fixes.append(f)
        info["fix"] = [f_["id"] for f_ in fixes[-len(groups):]] if groups else []
        rep.append(info)
json.dump(fixes, open(out, "w"), indent=0)
json.dump(rep, open(os.path.splitext(out)[0] + "_report.json", "w"), indent=0)
ok = [r for r in rep if "fix" in r]
print("regions", len(rep), "tooled", len(ok), "tools", len(fixes), "area add", round(sum(r["area"] for r in ok if r["kind"] == "add")),
      "cut", round(sum(r["area"] for r in ok if r["kind"] == "cut")))
sk = [r for r in rep if "skip" in r]
print("skipped", len(sk), "area", round(sum(r["area"] for r in sk)))
for r in sorted(sk, key=lambda r: -r["area"])[:25]:
    print(" skip", r)
