"""Plot plane sections of the framed scan.
usage: sec.py out.png AXIS v1,v2,.. [lim x0 x1 y0 y1] [grid g] [raw]
AXIS x|y|z. Plots each section in its own panel (2D coords = the other two axes in order)."""
import sys, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import load, section, W

a = sys.argv[1:]
out = a[0]; axn = "xyz".index(a[1]); vals = [float(t) for t in a[2].split(",")]
lim = None; grid = 10.0; raw = "raw" in a
if "lim" in a:
    i = a.index("lim"); lim = [float(t) for t in a[i + 1:i + 5]]
if "grid" in a:
    grid = float(a[a.index("grid") + 1])
v, f = load(frame=not raw)
other = [k for k in range(3) if k != axn]
nc = min(len(vals), 2 if len(vals) > 1 else 1)
nr = int(np.ceil(len(vals) / nc))
fig, axs = plt.subplots(nr, nc, figsize=(11 * nc, 11 * nr * (1 if lim is None else (lim[3] - lim[2]) / max(lim[1] - lim[0], 1e-9))), squeeze=False)
for k, val in enumerate(vals):
    ax = axs[k // nc][k % nc]
    s = section(v, f, axn, val)
    seg = s[:, :, other]
    if lim is not None:
        mm = ((seg[:, :, 0] > lim[0]) & (seg[:, :, 0] < lim[1]) & (seg[:, :, 1] > lim[2]) & (seg[:, :, 1] < lim[3])).any(1)
        seg = seg[mm]
    ax.add_collection(LineCollection(seg, colors="k", linewidths=0.6))
    ax.set_aspect("equal")
    if lim is not None:
        ax.set_xlim(lim[0], lim[1]); ax.set_ylim(lim[2], lim[3])
    else:
        ax.autoscale()
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
    ax.set_xticks(np.arange(np.floor(x0 / grid) * grid, x1, grid)); ax.set_yticks(np.arange(np.floor(y0 / grid) * grid, y1, grid))
    ax.tick_params(labelsize=6); plt.setp(ax.get_xticklabels(), rotation=90)
    ax.grid(True, lw=0.3, color="0.8")
    ax.set_title(f"{'xyz'[axn]} = {val}  ({'xyz'[other[0]]} horiz, {'xyz'[other[1]]} vert)", fontsize=9)
fig.tight_layout()
fig.savefig(out, dpi=110)
print("wrote", out)
