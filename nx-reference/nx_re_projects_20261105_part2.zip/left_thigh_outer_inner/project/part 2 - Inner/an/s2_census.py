"""Census of planar levels in the raw frame: z histogram for +Z/-Z facets, x/y for side facets."""
import numpy as np
from common import load, tri_data

v, f = load(frame=False)
c, n, a = tri_data(v, f)
for ax, name in ((2, "Z"), (1, "Y"), (0, "X")):
    for sgn in (1, -1):
        m = n[:, ax] * sgn > 0.995
        if m.sum() == 0:
            continue
        h, e = np.histogram(c[m, ax], bins=np.arange(v[:, ax].min() - 1, v[:, ax].max() + 1, 0.25), weights=a[m])
        idx = np.argsort(h)[::-1][:12]
        print(f"{'+' if sgn > 0 else '-'}{name}: total area {a[m].sum():.0f}")
        for i in sorted(idx):
            if h[i] > 30:
                mm = m & (np.abs(c[:, ax] - (e[i] + 0.125)) < 0.3)
                print(f"   level {e[i]+0.125:8.2f}  area {h[i]:7.0f}   mean {np.average(c[mm, ax], weights=a[mm]):8.3f}")
