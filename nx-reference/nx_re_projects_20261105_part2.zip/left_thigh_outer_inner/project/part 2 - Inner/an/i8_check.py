"""Validate the registration with features NOT used in the fit: pin holes vs outer pins, knee axis,
and joint cross-sections of both scans (inner orange, outer blue)."""
import numpy as np, json, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, tri_data, section, fit_circle_robust, W
from outer import load_outer
PO = json.load(open(r"..\nx\params_outer.json"))
vi, fi = load(); ci, ni, ai = tri_data(vi, fi)
vo, fo = load_outer()
# pins: inner holes near outer pin xy, concave facets r<4, z 36..50
for p in PO["pins"]:
    d = np.hypot(ci[:, 0] - p["x"], ci[:, 1] - p["y"])
    rad = np.c_[ci[:, 0] - p["x"], ci[:, 1] - p["y"]] / np.maximum(d, 1e-9)[:, None]
    nr = np.einsum("ij,ij->i", ni[:, :2], rad)
    for zlo, zhi in ((35.5, 40), (40, 52)):
        m = (d < 4.0) & (np.abs(ni[:, 2]) < 0.3) & (nr < -0.8) & (ci[:, 2] > zlo) & (ci[:, 2] < zhi)
        if m.sum() < 30: print("pin", p["x"], p["y"], zlo, "few", m.sum()); continue
        c, r, sd, k = fit_circle_robust(ci[m][:, :2])
        print(f"pin ({p['x']},{p['y']}) z{zlo}-{zhi}: inner hole c=({c[0]:.3f},{c[1]:.3f}) D={2*r:.3f} sd={sd:.3f} off={np.hypot(c[0]-p['x'], c[1]-p['y']):.3f}")
# knee: inner circles about origin, z sections
print("knee circles about Z (inner)")
for zz in (40, 45, 50, 60, 70, 74):
    s = section(vi, fi, 2, zz).reshape(-1, 3)[:, :2]
    d = np.hypot(*s.T)
    for r0 in (2, 5, 10, 20, 30, 40, 50, 60, 67.85):
        m = np.abs(d - r0) < (1.5 if r0 < 20 else 3)
        if m.sum() < 60: continue
        c, r, sd, k = fit_circle_robust(s[m])
        if sd < 0.15 and k.sum() > 60 and abs(r - r0) < 3: print(f"  z {zz}: D {2*r:8.3f} c ({c[0]:+.3f},{c[1]:+.3f}) sd {sd:.3f} n {k.sum()}")
# joint sections
fig, axs = plt.subplots(3, 4, figsize=(28, 18)); axs = axs.ravel()
cuts = [("y", -40), ("y", 0), ("y", 30), ("y", 80), ("y", 130), ("y", 166), ("y", 200), ("y", 240), ("x", 0), ("x", 40), ("x", -20), ("x", 90)]
for ax, (axn, val) in zip(axs, cuts):
    ia = "xyz".index(axn); h = 1 if axn == "x" else 0
    for V, F, col in ((vo, fo, "tab:blue"), (vi, fi, "tab:orange")):
        s = section(V, F, ia, val)
        for seg in s[::1]:
            ax.plot(seg[:, h], seg[:, 2], color=col, lw=0.6)
    ax.axhline(34.76, color="k", lw=0.4, ls="--"); ax.axhline(35.95, color="g", lw=0.4, ls="--")
    ax.set_title(f"{axn} = {val}"); ax.set_aspect("equal"); ax.grid(lw=0.3)
plt.tight_layout(); plt.savefig(W + r"\joint_sections.png", dpi=55)
