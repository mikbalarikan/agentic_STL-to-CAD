"""Small Z-axis through/blind holes of the inner: empty depth-map islands + top-map islands -> circle fits on the
vertical facets around them. Writes work/holes.json (x, y, D, z range)."""
import json, numpy as np
from scipy import ndimage
from common import load, tri_data, fit_circle_robust, W
v, f = load(); c, n, a = tri_data(v, f)
d = np.load(W + r"\hmap2.npz"); H = d["H"]; X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
Ht = np.load(W + r"\htop_scan.npy"); Ct = 0.25
cands = []
for M, cell, x0, y0 in ((np.isinf(H), C, X0, Y0), (np.isnan(Ht), Ct, -100.0, -72.0)):
    filled = ndimage.binary_fill_holes(~M)
    isl = filled & M
    lab, k = ndimage.label(isl)
    for j in range(1, k + 1):
        m = lab == j
        ar = m.sum() * cell * cell
        if ar < 1.0 or ar > 400: continue
        rc = np.argwhere(m)
        cands.append((x0 + (rc[:, 1].mean() + 0.5) * cell, y0 + (rc[:, 0].mean() + 0.5) * cell, 2 * np.sqrt(ar / np.pi)))
out = []
for x, y, dd in cands:
    if any(np.hypot(x - o["x"], y - o["y"]) < 1.5 for o in out): continue
    dist = np.hypot(c[:, 0] - x, c[:, 1] - y)
    m = (dist < dd / 2 + 1.5) & (np.abs(n[:, 2]) < 0.3)
    if m.sum() < 30: continue
    rad = np.c_[c[m, 0] - x, c[m, 1] - y] / np.maximum(dist[m], 1e-9)[:, None]
    nr = np.einsum("ij,ij->i", n[m, :2], rad)
    mm = nr < -0.7
    if mm.sum() < 30: continue
    cf, r, sd, kk = fit_circle_robust(c[m][mm][:, :2])
    zz = c[m][mm][kk, 2]
    out.append(dict(x=round(cf[0], 3), y=round(cf[1], 3), D=round(2 * r, 3), sd=round(sd, 3), z=[round(np.percentile(zz, 2), 2), round(np.percentile(zz, 98), 2)], n=int(kk.sum())))
out.sort(key=lambda o: (o["y"], o["x"]))
for o in out: print(o)
json.dump(out, open(W + r"\holes.json", "w"), indent=1)
