"""Skin step at the joint: outer CAD (delivered STL) x-extremes at z 34.0-34.7 vs inner scan at z 35.3-36.0, per y."""
import numpy as np, trimesh
from common import load, section
from outer import OUTER_CAD_STL, load_outer
vi, fi = load()
m = trimesh.load(OUTER_CAD_STL); vc, fc = np.asarray(m.vertices), np.asarray(m.faces)
vo, fo = load_outer()
def ext(V, F, y, z0, z1):
    s = section(V, F, 1, y).reshape(-1, 3); s = s[(s[:, 2] > z0) & (s[:, 2] < z1)]
    return (s[:, 0].min(), s[:, 0].max()) if len(s) else (np.nan, np.nan)
print("   y   | CAD L  inner L  outerscan L | CAD R  inner R outerscan R | stepL stepR (inner - CAD, + = inner proud)")
for y in np.arange(-60, 290, 10.0):
    a = ext(vc, fc, y, 34.0, 34.7); b = ext(vi, fi, y, 35.3, 36.0); c = ext(vo, fo, y, 34.0, 34.7)
    print(f"{y:6.0f} | {a[0]:7.2f} {b[0]:7.2f} {c[0]:7.2f} | {a[1]:7.2f} {b[1]:7.2f} {c[1]:7.2f} | {a[0]-b[0]:+.2f} {b[1]-a[1]:+.2f}")
