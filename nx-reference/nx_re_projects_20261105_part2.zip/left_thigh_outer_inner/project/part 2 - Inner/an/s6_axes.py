"""Fit the knee bore (axis ~Z) and hip bore (axis ~Y) from sections, iterative radial band."""
import numpy as np, sys
from common import load, section, fit_circle_robust
v, f = load()

def band_fit(p2, c0, r0, w=2.0, it=6):
    c, r = np.array(c0, float), r0
    for _ in range(it):
        d = np.hypot(p2[:, 0] - c[0], p2[:, 1] - c[1])
        m = np.abs(d - r) < w
        c, r, sd, k = fit_circle_robust(p2[m])
        w = max(0.4, min(w, 6 * sd))
    return c, r, sd, m.sum()

print("KNEE (z sections, xy)")
for zz in (-1.0, -2.0, -3.0, -5.0, -7.0, -10.0, -12.0):
    s = section(v, f, 2, zz).reshape(-1, 3)
    p = s[s[:, 1] < -60][:, :2]
    for r0 in (55, 67):
        try:
            c, r, sd, n = band_fit(p, (-30, -138), r0)
            print(f"  z {zz:6.1f} r0 {r0}: c=({c[0]:8.3f},{c[1]:8.3f}) R={r:8.3f} D={2*r:8.3f} sd={sd:.3f} n={n}")
        except Exception as e:
            print("  fail", zz, r0, e)
print("HIP (y sections, xz)")
for yy in (126.0, 131.0, 134.0, 136.0, 138.0, 142.0, 146.0):
    s = section(v, f, 1, yy).reshape(-1, 3)
    p = s[s[:, 2] > -20][:, [0, 2]]
    for r0 in (50, 47):
        try:
            c, r, sd, n = band_fit(p, (5, 36), r0, w=4)
            print(f"  y {yy:6.1f} r0 {r0}: c=({c[0]:8.3f},{c[1]:8.3f}) R={r:8.3f} D={2*r:8.3f} sd={sd:.3f} n={n}")
        except Exception as e:
            print("  fail", yy, r0, e)
