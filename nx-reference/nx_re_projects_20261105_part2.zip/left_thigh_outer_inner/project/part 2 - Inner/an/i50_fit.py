"""Fit check INNER vs the delivered OUTER, both STEP files read with OpenCascade (independent of NX).
usage: i50_fit.py inner.step outer.step out.json inner.stl
- interference: volume of the boolean common (must be ~0), min distance between the solids
- mating faces: inner planar faces facing -Z vs outer planar faces facing +Z in the joint band: levels, overlap area
- concentricity: inner pockets / pin holes vs outer nubs / pins (cylindrical faces, axis || Z)
- gap map: inner surface samples in the joint band (z < 40), signed distance to the outer (meshes)"""
import sys, json, math
import numpy as np
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE, TopAbs_REVERSED
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Plane, GeomAbs_Cylinder
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRep import BRep_Tool
from OCP.TopLoc import TopLoc_Location
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.gp import gp_Pnt
from OCP.TopAbs import TopAbs_IN


def read(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()


def vol(s):
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g); return g.Mass()


def area(f):
    g = GProp_GProps(); BRepGProp.SurfaceProperties_s(f, g); return g.Mass(), g.CentreOfMass()


def faces(s):
    e = TopExp_Explorer(s, TopAbs_FACE)
    while e.More():
        yield TopoDS.Face_s(e.Current()); e.Next()


def census(s):
    planes, cyls = [], []
    for f in faces(s):
        a = BRepAdaptor_Surface(f)
        t = a.GetType()
        if t == GeomAbs_Plane:
            pl = a.Plane(); n = pl.Axis().Direction(); o = pl.Location()
            nz = n.Z() * (-1 if f.Orientation() == TopAbs_REVERSED else 1)
            if abs(abs(n.Z()) - 1) < 1e-6:
                A, c = area(f)
                planes.append(dict(z=round(o.Z(), 4), nz=round(nz), area=A, c=(c.X(), c.Y())))
        elif t == GeomAbs_Cylinder:
            cy = a.Cylinder(); ax = cy.Axis(); d = ax.Direction(); o = ax.Location()
            if abs(abs(d.Z()) - 1) < 1e-6:
                cyls.append(dict(x=o.X(), y=o.Y(), D=2 * cy.Radius(), zr=(a.FirstVParameter(), a.LastVParameter()),
                                 rev=f.Orientation() == TopAbs_REVERSED))
    return planes, cyls


inn, out = read(sys.argv[1]), read(sys.argv[2])
res = {}
vi, vo = vol(inn), vol(out)
com = BRepAlgoAPI_Common(inn, out); com.Build()
res["volumes"] = dict(inner=round(vi, 1), outer=round(vo, 1))
res["interference_mm3"] = round(vol(com.Shape()), 4) if com.IsDone() else "common failed"
dss = BRepExtrema_DistShapeShape(inn, out); dss.Perform()
res["min_distance"] = round(dss.Value(), 4) if dss.IsDone() else None
pi, ci = census(inn); po, co = census(out)
# mating planes in the joint band
lv = {}
for p in pi:
    if 34 < p["z"] < 40 and p["nz"] < 0: lv.setdefault(("inner -Z", p["z"]), 0.0); lv[("inner -Z", p["z"])] += p["area"]
for p in po:
    if 34 < p["z"] < 40 and p["nz"] > 0: lv.setdefault(("outer +Z", p["z"]), 0.0); lv[("outer +Z", p["z"])] += p["area"]
res["joint_planes"] = [dict(side=k[0], z=k[1], area=round(v, 1)) for k, v in sorted(lv.items(), key=lambda t: (t[0][1], t[0][0]))]
# concentricity: inner Ø10 pockets vs outer Ø10 nubs; inner Ø4 pin holes vs outer Ø4 pins; Ø6 holes vs outer Ø5.2 holes
pairs = []
for Di, Do, name in ((10.0, 10.0, "boss pocket / nub"), (4.0, 4.0, "pin hole / pin"), (6.0, 5.2, "screw hole / outer boss hole"),
                     (15.0, 15.0, "boss column / outer boss")):
    I = [c for c in ci if abs(c["D"] - Di) < 0.02]
    O = [c for c in co if abs(c["D"] - Do) < 0.02]
    for c in I:
        if not O: break
        o = min(O, key=lambda q: math.hypot(q["x"] - c["x"], q["y"] - c["y"]))
        dd = math.hypot(o["x"] - c["x"], o["y"] - c["y"])
        if dd < 2.0:
            pairs.append(dict(feature=name, inner=[round(c["x"], 3), round(c["y"], 3), round(c["D"], 3)],
                              outer=[round(o["x"], 3), round(o["y"], 3), round(o["D"], 3)], offset=round(dd, 4)))
# dedupe (one per inner location)
seen, P2 = set(), []
for p in pairs:
    k = (p["feature"], p["inner"][0], p["inner"][1])
    if k not in seen: seen.add(k); P2.append(p)
res["concentricity"] = P2
res["concentricity_max_offset"] = max([p["offset"] for p in P2], default=None)
# gap map: fine STL of the inner (argv[4]) sampled in the joint band (z < 40), signed distance to the outer STL
# (open3d ray casting; - = inside the outer solid)
import open3d as o3d
from outer import OUTER_CAD_STL
mi = o3d.io.read_triangle_mesh(sys.argv[4]); mo = o3d.io.read_triangle_mesh(OUTER_CAD_STL)
mo.remove_duplicated_vertices()
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mo))
pts = np.asarray(mi.sample_points_uniformly(400000).points)
pts = pts[pts[:, 2] < 40.0].astype(np.float32)
sd = sc.compute_signed_distance(o3d.core.Tensor(pts)).numpy()
res["joint_band_samples"] = int(len(sd))
res["joint_band_inner_points_inside_outer"] = int((sd < -0.01).sum())
res["joint_band_min_signed_mm"] = round(float(sd.min()), 4)
res["joint_band_gap_hist_mm"] = {f"{a:.2f}-{b:.2f}": int(((sd >= a) & (sd < b)).sum()) for a, b in
                                 ((-99, -0.01), (-0.01, 0.01), (0.01, 0.15), (0.15, 0.3), (0.3, 0.5), (0.5, 1.0), (1.0, 999))}
json.dump(res, open(sys.argv[3], "w"), indent=1)
print(json.dumps({k: v for k, v in res.items() if k != "concentricity"}, indent=1))
print("concentricity pairs", len(P2), "max offset", res["concentricity_max_offset"])
