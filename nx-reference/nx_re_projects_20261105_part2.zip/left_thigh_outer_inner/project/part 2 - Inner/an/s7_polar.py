"""Polar map of the outer skin: per y-section, rays from (xc, ZC) at angles th in [-180, 0]
(0 = +x, -90 = straight down). Records the crossings (sorted by radius, outermost first).
Writes work/polar.npz: ys, th, xc, R (ny, nth, 4) radii of the first 4 crossings (nan if none)."""
import numpy as np
from common import load, section, W

ZC = 36.0
v, f = load()
ys = np.arange(-206.0, 152.0, 2.0)
th = np.radians(np.arange(-180.0, 0.01, 1.0))
R = np.full((len(ys), len(th), 4), np.nan)
XC = np.zeros(len(ys))
for i, y in enumerate(ys):
    s = section(v, f, 1, y)
    if len(s) == 0:
        continue
    seg = s[:, :, [0, 2]]
    below = seg[:, :, 1] < ZC + 0.5
    seg = seg[below.all(1)]
    # centre: midpoint of the x range of the section below the rim
    xs = seg[:, :, 0].ravel()
    xc = 0.5 * (xs.min() + xs.max())
    XC[i] = xc
    a = seg[:, 0] - [xc, ZC]; b = seg[:, 1] - [xc, ZC]
    for j, t in enumerate(th):
        d = np.array([np.cos(t), np.sin(t)])
        # ray p = r d ; segment a + u (b-a); solve r d - u (b-a) = a
        e = b - a
        den = d[0] * (-e[:, 1]) - d[1] * (-e[:, 0])
        ok = np.abs(den) > 1e-12
        r = (a[:, 0] * (-e[:, 1]) - a[:, 1] * (-e[:, 0])) / np.where(ok, den, 1)
        u = (d[0] * a[:, 1] - d[1] * a[:, 0]) / np.where(ok, den, 1)
        m = ok & (u >= 0) & (u <= 1) & (r > 0)
        rr = np.sort(r[m])[::-1]
        k = min(4, len(rr))
        R[i, j, :k] = rr[:k]
    if i % 20 == 0:
        print(y, "xc", round(xc, 2))
np.savez(W + r"\polar.npz", ys=ys, th=th, xc=XC, R=R, zc=ZC)
print("done")
