"""Plot fix outlines (zprism loops) over the open-side depth diff. usage: i98_showfix.py fixes.json out.png x0 x1 y0 y1 [ids]"""
import sys, json
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from fixlib import depth, segs_to_poly
fx = json.load(open(sys.argv[1])); out = sys.argv[2]; a0, a1, b0, b1 = [float(t) for t in sys.argv[3:7]]
ids = set(sys.argv[7].split(",")) if len(sys.argv) > 7 else None
d = depth(); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
i0, i1 = int((b0 - Y0) / C), int((b1 - Y0) / C); j0, j1 = int((a0 - X0) / C), int((a1 - X0) / C)
fig, ax = plt.subplots(1, 2, figsize=(20, 10 * (b1 - b0) / (a1 - a0) + 0.6))
ax[0].imshow(np.clip((d["zc"] - d["zs"])[i0:i1, j0:j1], -3, 3), origin="lower", extent=[a0, a1, b0, b1], cmap="seismic", vmin=-3, vmax=3)
ax[1].imshow(d["zs"][i0:i1, j0:j1], origin="lower", extent=[a0, a1, b0, b1], cmap="nipy_spectral", vmin=np.nanpercentile(d["zs"][i0:i1, j0:j1], 2), vmax=np.nanpercentile(d["zs"][i0:i1, j0:j1], 98))
for f in fx:
    if f["type"] != "zprism" or (ids and not any(f["id"].startswith(i) for i in ids)):
        continue
    col = "lime" if f["kind"] == "add" else "magenta"
    for lp in f["loops"]:
        P = segs_to_poly(lp) if isinstance(lp[0][0], str) else np.asarray(lp)
        P = np.vstack([P, P[:1]])
        for a in ax:
            a.plot(P[:, 0], P[:, 1], "-", color=col, lw=1.0)
    for a in ax:
        a.text(*np.asarray(segs_to_poly(f["loops"][0]) if isinstance(f["loops"][0][0][0], str) else f["loops"][0]).mean(0), f["id"], fontsize=8)
for a in ax:
    a.set_xlim(a0, a1); a.set_ylim(b0, b1); a.grid(lw=0.3, alpha=0.5); a.tick_params(labelsize=7)
ax[0].set_title("CAD z - scan z (red = CAD missing); green add, magenta cut"); ax[1].set_title("scan z")
fig.tight_layout(); fig.savefig(out, dpi=55)
print("ok")
