"""Boss-top annuli: z of +Z faces (inner rim frame) / outer frame, per boss; and P2 lug debug."""
import numpy as np, json
from common import load, tri_data, fit_plane_robust, W
from outer import load_outer
cy_i = json.load(open(W + r"\cyl_inner.json")); cy_o = json.load(open(W + r"\cyl_outer.json"))
def col(cy, k):  # boss column = convex (labelled 'hole' by nr>0) with D 14.9..15.5 largest area
    c = [o for o in cy[k] if o["side"] == "hole" and 14.8 < o["D"] < 15.5]
    return max(c, key=lambda o: o["area"])["c"]
v, f = load(frame=False); Rr = np.load(W + r"\Rrim.npy"); v = (v - Rr[3]) @ Rr[:3].T
c, n, a = tri_data(v, f)
vo, fo = load_outer(); co, no, ao = tri_data(vo, fo)
tops = {}
for k in [f"B{i}" for i in range(1, 8)]:
    ci = col(cy_i, k); cO = col(cy_o, k)
    d = np.hypot(c[:, 0] - ci[0], c[:, 1] - ci[1]); m = (d > 5.4) & (d < 7.3) & (n[:, 2] > 0.98) & (np.abs(c[:, 2]) < 2)
    d2 = np.hypot(c[:, 0] - ci[0], c[:, 1] - ci[1]); m2 = (d2 < 4.8) & (n[:, 2] > 0.98) & (c[:, 2] < -1) & (c[:, 2] > -6)
    do = np.hypot(co[:, 0] - cO[0], co[:, 1] - cO[1]); mo = (do > 5.4) & (do < 7.3) & (no[:, 2] > 0.98) & (np.abs(co[:, 2] - 36) < 2)
    mo2 = (do < 4.8) & (do > 2.8) & (no[:, 2] > 0.98) & (co[:, 2] > 37)
    tops[k] = dict(inner_top=float(np.median(c[m, 2])), inner_pocket_floor=float(np.median(c[m2, 2])) if m2.sum() else None,
                   outer_top=float(np.median(co[mo, 2])), outer_nub_top=float(np.median(co[mo2, 2])) if mo2.sum() else None,
                   ci=ci, co=cO, xy_inner_top=c[m][:, :3].mean(0).tolist())
    print(k, {kk: (round(vv, 3) if isinstance(vv, float) else vv) for kk, vv in tops[k].items() if kk != "xy_inner_top"})
json.dump(tops, open(W + r"\boss_tops.json", "w"), indent=1)
# P2 debug
for g in ((-38.5, 29.5), (-40, 30), (-36, 28)):
    d = np.hypot(c[:, 0] - g[0], c[:, 1] - g[1]); m = d < 8
    print("P2 probe", g, m.sum(), "z range", np.percentile(c[m, 2], [2, 50, 98]) if m.sum() else None)
