"""INNER side-wall windows: coverage of the fitted skin by scan points in (y, z) per side, then window loops.
args: [map]  -> only the coverage figure;  default -> loops for the y ranges in YR -> work/windows.json
Each loop is cut in NX by an extrusion in X from just inside the wall (x_inner_limit) outward."""
import sys, json, numpy as np, contourpy, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import ndimage
from scipy.spatial import cKDTree
from common import load, W
from i20lib import evalr
from arcfit import fit_loop, seg_points

LIP = 35.20
s = np.load(W + r"\skin_fit.npz"); si = np.load(W + r"\inner_fit.npz")
pc, ZC = s["pc"], float(s["ZC"])
ys = np.arange(-70, 288, 0.5); ths = np.radians(np.arange(-4, 184.01, 0.5))
Y, T = np.meshgrid(ys, ths, indexing="ij")
R = evalr(s["ty"], s["tt"], s["C"], Y.ravel(), T.ravel()).reshape(Y.shape)
X = np.polyval(pc, Y) + R * np.cos(T); Z = ZC + R * np.sin(T)
if "map" in sys.argv or not __import__("os").path.exists(W + r"\skin_cov.npz"):
    v, f = load()
    tree = cKDTree(v)
    d, _ = tree.query(np.c_[X.ravel(), Y.ravel(), Z.ravel()], distance_upper_bound=3.0)
    cov = d.reshape(X.shape) < 0.6
    np.savez(W + r"\skin_cov.npz", cov=cov)
cov = np.load(W + r"\skin_cov.npz")["cov"]
dk = np.hypot(X, Y)
SIDES = {"L": T > np.radians(120), "R": T < np.radians(60)}
if "map" in sys.argv:
    fig, ax = plt.subplots(2, 1, figsize=(30, 14))
    for k, (side, sel) in enumerate(SIDES.items()):
        ok = sel & (Z > LIP + 0.3)
        ax[k].scatter(Y[ok & cov], Z[ok & cov], s=0.3, c="0.75"); ax[k].scatter(Y[ok & ~cov], Z[ok & ~cov], s=1, c="r")
        ax[k].scatter(Y[ok & (dk < 69.5)], Z[ok & (dk < 69.5)], s=0.3, c="c", alpha=0.2)
        ax[k].set_title(side + ": red = fitted skin with no scan points; cyan = knee hub zone (skin not used)")
        ax[k].set_xticks(np.arange(-70, 290, 5)); ax[k].set_yticks(np.arange(34, 112, 2)); ax[k].grid(True, lw=0.3); ax[k].set_aspect("equal")
    fig.tight_layout(); fig.savefig(W + r"\windows_map.png", dpi=55)
    sys.exit(0)

YR = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {"L": [[170, 200]], "R": [[120, 205]]}


def x_inner(y, z, side):
    th = np.radians(np.linspace(-4, 184, 3761))
    r = evalr(si["ty"], si["tt"], si["C"], np.full(len(th), y), th)
    xx = np.polyval(pc, y) + r * np.cos(th); zz = ZC + r * np.sin(th)
    m = (th > np.radians(90)) if side == "L" else (th < np.radians(90))
    k = np.argmin(np.abs(zz[m] - z)); return xx[m][k]


gy = np.arange(-70, 288, 0.25); gz = np.arange(30, 112, 0.25)
out = []
fig, ax = plt.subplots(2, 1, figsize=(30, 14))
for k, (side, sel) in enumerate(SIDES.items()):
    Tm = sel & (dk >= 69.5)
    pts_open = np.c_[Y[Tm & ~cov], Z[Tm & ~cov]]; pts_cov = np.c_[Y[Tm & cov], Z[Tm & cov]]
    G = np.zeros((len(gz), len(gy)))
    for P_, val in ((pts_cov, -1), (pts_open, 1)):
        iy = np.clip(((P_[:, 0] + 70) / 0.25).astype(int), 0, len(gy) - 1); iz = np.clip(((P_[:, 1] - 30) / 0.25).astype(int), 0, len(gz) - 1)
        G[iz, iy] = val
    lab = G != 0
    idx = ndimage.distance_transform_edt(~lab, return_distances=False, return_indices=True)
    G = G[idx[0], idx[1]]
    G[gz < LIP + 0.2, :] = 1.0                       # open below the lip: notches reach the lip edge
    keep = np.zeros(len(gy), bool)
    for a, b in YR.get(side, []):
        keep |= (gy >= a) & (gy <= b)
    G[:, ~keep] = -1
    G[:, :4] = -1; G[:, -4:] = -1; G[-4:, :] = -1; G[:4, :] = -1
    Om = ndimage.binary_opening(G > 0, iterations=3)
    labl, n = ndimage.label(Om)
    for j in range(1, n + 1):
        m = labl == j
        if m.sum() * 0.0625 < 15: continue
        zz_ = np.where(m.any(1))[0]
        if gz[zz_].max() < LIP + 1.0: continue        # just the band below the lip
        Gs = ndimage.gaussian_filter(m.astype(float), 2.0) - 0.5
        for C in contourpy.contour_generator(z=Gs, line_type="Separate").lines(0.0):
            P = np.c_[-70 + C[:, 0] * 0.25, 30 + C[:, 1] * 0.25]
            if np.linalg.norm(P[0] - P[-1]) > 1e-6: continue
            P = P[:-1]
            if (P[:, 1] > LIP + 1).sum() < 10: continue
            segs = fit_loop(P, tol=0.15)
            yr = (P[P[:, 1] > LIP + 1, 0].min(), P[P[:, 1] > LIP + 1, 0].max())
            zr = P[:, 1].max()
            xi = [x_inner(yy, zz, side) for yy in np.linspace(yr[0], yr[1], 9) for zz in np.linspace(LIP + 1, min(zr, 100), 6)]
            xlim = (max(xi) + 1.0) if side == "L" else (min(xi) - 1.0)
            out.append(dict(side=side, y=[float(yr[0]), float(yr[1])], zmax=float(zr), x_inner_limit=float(xlim), n_seg=len(segs),
                            segs=[([s_[0], s_[1].tolist(), s_[2].tolist()] if s_[0] == "L" else [s_[0], s_[1].tolist(), s_[2].tolist(), s_[3].tolist(), float(s_[4]), bool(s_[5])]) for s_ in segs]))
            Q = np.vstack([seg_points(s_) for s_ in segs]); ax[k].plot(Q[:, 0], Q[:, 1], "-")
            print(side, "window y %.1f..%.1f zmax %.1f segs %d xlim %.1f" % (yr[0], yr[1], zr, len(segs), xlim))
    ax[k].imshow(G, origin="lower", extent=[-70, 288, 30, 112], cmap="coolwarm", alpha=0.3); ax[k].set_aspect("equal"); ax[k].grid(True)
json.dump(out, open(W + r"\windows.json", "w"))
fig.tight_layout(); fig.savefig(W + r"\windows_loops.png", dpi=55)
