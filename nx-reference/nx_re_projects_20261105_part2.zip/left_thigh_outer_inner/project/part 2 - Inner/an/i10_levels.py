"""Down-facing levels of the registered inner near the joint, vs the outer's up-facing levels."""
import numpy as np
from common import load, tri_data
from outer import load_outer
vi, fi = load(); c, n, a = tri_data(vi, fi)
vo, fo = load_outer(); co, no, ao = tri_data(vo, fo)
for lab, cc, nn, aa, sg in (("inner -Z faces", c, n, a, -1), ("outer +Z faces", co, no, ao, 1)):
    m = (nn[:, 2] * sg > 0.995) & (cc[:, 2] > 33.5) & (cc[:, 2] < 40)
    h, e = np.histogram(cc[m, 2], bins=np.arange(33.5, 40, 0.05), weights=aa[m])
    print(lab)
    for i in np.where(h > 8)[0]: print(f"   {e[i]+0.025:7.3f} {h[i]:7.1f}")
