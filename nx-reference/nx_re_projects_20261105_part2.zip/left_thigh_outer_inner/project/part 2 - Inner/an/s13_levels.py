"""Flat top levels (up-facing planar facets) in the final frame: z, area, xy extent, connected blobs."""
import numpy as np
from scipy import ndimage
from common import load, tri_data, W
v, f = load()
c, n, a = tri_data(v, f)
up = n[:, 2] > 0.995
h, e = np.histogram(c[up, 2], bins=np.arange(-45, 90, 0.1), weights=a[up])
peaks = [i for i in range(1, len(h) - 1) if h[i] >= h[i - 1] and h[i] >= h[i + 1] and h[i] > 6]
out = []
for i in peaks:
    z0 = e[i] + 0.05
    m = up & (np.abs(c[:, 2] - z0) < 0.15)
    zz = np.average(c[m, 2], weights=a[m])
    # blobs on a 1mm grid
    xy = c[m, :2]
    g = np.zeros((380, 220), bool)
    ix = np.clip(((xy[:, 0] + 100) / 1).astype(int), 0, 219); iy = np.clip(((xy[:, 1] + 75) / 1).astype(int), 0, 379)
    g[iy, ix] = True
    lab, nb = ndimage.label(ndimage.binary_closing(g, iterations=1))
    blobs = []
    for k in range(1, nb + 1):
        yy, xx = np.where(lab == k)
        if len(yy) < 4: continue
        blobs.append(f"[x {xx.min()-100}..{xx.max()-100} y {yy.min()-75}..{yy.max()-75} ~{len(yy)}mm2]")
    print(f"z {zz:8.3f} area {a[m].sum():7.0f}  blobs {len(blobs)}: " + " ".join(blobs[:8]))
