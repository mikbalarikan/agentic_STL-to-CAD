"""R(z) about the knee axis, inner + outer scans, per angle sector: outermost radius per z bin."""
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load, W
from outer import load_outer
vi, _ = load(); vo, _ = load_outer()
fig, axs = plt.subplots(1, 4, figsize=(28, 12))
for ax, (a0, a1) in zip(axs, ((-170, -130), (-130, -90), (-90, -50), (-50, -10))):
    for V, col in ((vo, "tab:blue"), (vi, "tab:orange")):
        r = np.hypot(V[:, 0], V[:, 1]); ph = np.degrees(np.arctan2(V[:, 1], V[:, 0]))
        m = (ph > a0) & (ph < a1) & (r > 55) & (r < 75) & (V[:, 2] > 0) & (V[:, 2] < 95)
        ax.plot(r[m][::7], V[m, 2][::7], ",", color=col)
        zb = np.arange(0, 95, 1.0); rmax = [np.percentile(r[m][(V[m, 2] >= z) & (V[m, 2] < z + 1)], 99.5) if ((V[m, 2] >= z) & (V[m, 2] < z + 1)).sum() > 20 else np.nan for z in zb]
        ax.plot(rmax, zb + 0.5, "-", color=col, lw=1.5)
    ax.axhline(34.76, color="k", lw=0.5); ax.axhline(35.2, color="g", lw=0.5)
    ax.set_xlim(60, 75); ax.grid(lw=0.3); ax.set_title(f"phi {a0}..{a1}"); ax.set_xticks(np.arange(60, 75.1, 1))
plt.tight_layout(); plt.savefig(W + r"\knee_rz_both.png", dpi=50)
