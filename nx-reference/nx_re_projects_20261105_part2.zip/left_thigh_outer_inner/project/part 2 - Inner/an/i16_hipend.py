"""Hip end: inner (orange) vs outer (blue) sections around the outer's hip ring."""
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load, section, W
from outer import load_outer
vi, fi = load(); vo, fo = load_outer()
fig, axs = plt.subplots(2, 3, figsize=(30, 20)); axs = axs.ravel()
cuts = [("x", 37.97), ("x", 0), ("x", 80), ("y", 271.5), ("y", 280), ("y", 262)]
for ax, (axn, val) in zip(axs, cuts):
    ia = "xyz".index(axn); h = 1 if axn == "x" else 0
    for V, F, col in ((vo, fo, "tab:blue"), (vi, fi, "tab:orange")):
        s = section(V, F, ia, val)
        if axn == "x": s = s[(s[:, 0, 1] > 230)]
        for seg in s: ax.plot(seg[:, h], seg[:, 2], color=col, lw=0.8)
    ax.set_aspect("equal"); ax.grid(lw=0.3); ax.set_title(f"{axn}={val}")
    if axn == "y":
        t = np.linspace(0, 2 * np.pi, 200); ax.plot(37.97 + 52.515 * np.cos(t), 35.18 + 52.515 * np.sin(t), "k--", lw=0.5)
plt.tight_layout(); plt.savefig(W + r"\hip_end.png", dpi=45)
