"""Inner outside (top) height map: max z per 0.25 cell + hillshade, to see knee face, flats, seams, holes."""
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.colors import LightSource
from common import load, W
v, f = load(); CELL = 0.25; X0, X1, Y0, Y1 = -100.0, 125.0, -72.0, 292.0
ix = ((v[:, 0] - X0) / CELL).astype(int); iy = ((v[:, 1] - Y0) / CELL).astype(int)
nx_, ny_ = int((X1 - X0) / CELL), int((Y1 - Y0) / CELL)
ok = (ix >= 0) & (ix < nx_) & (iy >= 0) & (iy < ny_)
H = np.full(nx_ * ny_, np.nan); Hm = np.full(nx_ * ny_, -np.inf); np.maximum.at(Hm, iy[ok] * nx_ + ix[ok], v[ok, 2])
H = np.where(np.isinf(Hm), np.nan, Hm).reshape(ny_, nx_)
np.save(W + r"\htop_scan.npy", H)
ls = LightSource(azdeg=315, altdeg=35)
rgb = ls.shade(np.nan_to_num(H, nan=30), cmap=plt.cm.terrain, vert_exag=3, blend_mode="soft", vmin=30, vmax=115)
fig, ax = plt.subplots(figsize=(18, 30)); ax.imshow(rgb, origin="lower", extent=[X0, X1, Y0, Y1])
ax.set_xticks(np.arange(-100, 126, 10)); ax.set_yticks(np.arange(-70, 292, 10)); ax.grid(lw=0.3)
fig.tight_layout(); fig.savefig(W + r"\top_map.png", dpi=45)
