"""Rebate footprint for the inner rim (z 35.20 -> 36.07):
  (delivered OUTER CAD material above z 35.10, dilated by the lateral clearance) U (inner scan rebate, depth 35.8..36.2)
Boss-pocket areas are left in (the bosses are rebuilt afterwards). Writes work/rebate_nx.json + figure."""
import json, numpy as np, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import ndimage
from common import W
from outer import OUTER_CAD_STL
from masklib import mask_loops, group_loops, loop_points
CLR = 0.10
d = np.load(W + r"\hmap2.npz"); H = d["H"]; X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
ny, nx = H.shape
m = trimesh.load(OUTER_CAD_STL)
tri = np.asarray(m.vertices)[np.asarray(m.faces)]
# outer CAD top height map (max z) from vertices + edge midpoints + centroids
P = np.concatenate([tri[:, 0], tri[:, 1], tri[:, 2], tri.mean(1), (tri[:, 0] + tri[:, 1]) / 2, (tri[:, 1] + tri[:, 2]) / 2, (tri[:, 2] + tri[:, 0]) / 2])
ix = np.floor((P[:, 0] - X0) / C).astype(int); iy = np.floor((P[:, 1] - Y0) / C).astype(int)
ok = (ix >= 0) & (ix < nx) & (iy >= 0) & (iy < ny)
O = np.full(ny * nx, -np.inf); np.maximum.at(O, iy[ok] * nx + ix[ok], P[ok, 2]); O = O.reshape(ny, nx)
T = O > 35.10
T = ndimage.binary_closing(T, iterations=2) & ~ndimage.binary_erosion(np.zeros_like(T))
dT = ndimage.distance_transform_edt(~T) * C
To = dT <= CLR + 1e-9
Z = -H
R = (Z > 35.80) & (Z < 36.20)
R = ndimage.binary_opening(R, iterations=1)
lab, n = ndimage.label(R); sz = ndimage.sum(R, lab, range(1, n + 1)) * C * C
R = np.isin(lab, 1 + np.where(sz >= 3.0)[0])
# only near the rim: within 6 mm of cells at lip level or tongue
M = To | R
M = ndimage.binary_closing(M, iterations=1)
# drop tongue cells far from the inner's own wall / rim (e.g. outer features the inner never reaches are harmless)
loops = mask_loops(M, X0, Y0, C, min_area=1.0, sigma=1.5, tol=0.06)
groups = group_loops(loops)
json.dump(dict(z0=35.20, z1=36.07, clearance=CLR, groups=groups), open(W + r"\rebate_nx.json", "w"))
print("loops", len(loops), "groups", len(groups), "areas", [round(g["area"]) for g in groups])
fig, ax = plt.subplots(figsize=(18, 30))
ax.imshow(np.where(To, 1.0, np.nan), origin="lower", extent=[X0, X1, Y0, Y1], cmap="Blues", vmin=0, vmax=1.5)
ax.imshow(np.where(R & ~To, 1.0, np.nan), origin="lower", extent=[X0, X1, Y0, Y1], cmap="Oranges", vmin=0, vmax=1.5)
for g in groups:
    for sl in [g["outer"]] + g["holes"]:
        Q = loop_points(sl); ax.plot(np.r_[Q[:, 0], Q[0, 0]], np.r_[Q[:, 1], Q[0, 1]], "k-", lw=0.6)
ax.set_aspect("equal"); ax.grid(lw=0.3); fig.tight_layout(); fig.savefig(W + r"\rebate_loops.png", dpi=45)
