"""Shared scan tools for the Left Thigh job: load cache, frame transform, plane sections, fits."""
import os, json
import numpy as np

ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
W = os.path.join(ROOT, "work")
_cache = {}


def load(frame=True):
    """Welded scan (v, f). frame=True applies work/frame.json (R, t): p_new = R @ (p - o)."""
    key = ("scan", frame)
    if key in _cache:
        return _cache[key]
    d = np.load(os.path.join(W, "scan.npz"))
    v = d["v"].astype(np.float64)
    f = d["f"]
    if frame and os.path.exists(os.path.join(W, "frame.json")):
        fr = json.load(open(os.path.join(W, "frame.json")))
        R = np.array(fr["R"]); o = np.array(fr["o"])
        v = (v - o) @ R.T
    _cache[key] = (v, f)
    return v, f


def tri_data(v, f):
    a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
    n = np.cross(b - a, c - a)
    ar = np.linalg.norm(n, axis=1)
    n = n / np.maximum(ar, 1e-12)[:, None]
    return (a + b + c) / 3, n, ar / 2


def section(v, f, axis, val, sel=None):
    """Plane section axis(0/1/2)=val. Returns segments (k,2,3)."""
    ff = f if sel is None else f[sel]
    s = v[:, axis] - val
    sa, sb, sc = s[ff[:, 0]], s[ff[:, 1]], s[ff[:, 2]]
    mn = np.minimum(np.minimum(sa, sb), sc); mx = np.maximum(np.maximum(sa, sb), sc)
    hit = (mn < 0) & (mx > 0)
    ff = ff[hit]
    segs = []
    P = v[ff]  # k,3,3
    S = s[ff]  # k,3
    pts = []
    for (i, j) in ((0, 1), (1, 2), (2, 0)):
        si, sj = S[:, i], S[:, j]
        cross = (si * sj) < 0
        t = np.where(cross, si / np.where(cross, si - sj, 1), 0)
        p = P[:, i] + t[:, None] * (P[:, j] - P[:, i])
        pts.append((cross, p))
    out = np.zeros((len(ff), 2, 3))
    cnt = np.zeros(len(ff), int)
    for cross, p in pts:
        for k in (0, 1):
            m = cross & (cnt == k)
            out[m, k] = p[m]
            cnt[m] += 1
            cross = cross & ~m
    return out[cnt == 2]


def fit_circle(p2):
    x, y = p2[:, 0], p2[:, 1]
    A = np.c_[2 * x, 2 * y, np.ones(len(x))]
    c, *_ = np.linalg.lstsq(A, x * x + y * y, rcond=None)
    r = np.sqrt(c[2] + c[0] ** 2 + c[1] ** 2)
    res = np.hypot(x - c[0], y - c[1]) - r
    return c[:2], r, res


def fit_circle_robust(p2, it=5, k=2.5):
    m = np.ones(len(p2), bool)
    for _ in range(it):
        c, r, res = fit_circle(p2[m])
        res_all = np.hypot(p2[:, 0] - c[0], p2[:, 1] - c[1]) - r
        sd = max(np.std(res_all[m]), 1e-4)
        m = np.abs(res_all) < k * sd + 0.01
    return c, r, float(np.std(res_all[m])), m


def fit_plane(p):
    c = p.mean(0)
    u, s, vt = np.linalg.svd(p - c, full_matrices=False)
    n = vt[2]
    return c, n, (p - c) @ n


def fit_plane_robust(p, it=5, k=2.5):
    m = np.ones(len(p), bool)
    for _ in range(it):
        c, n, d = fit_plane(p[m])
        d_all = (p - c) @ n
        sd = max(np.std(d_all[m]), 1e-4)
        m = np.abs(d_all) < k * sd + 0.005
    return c, n, float(np.std(d_all[m])), m


def write_stl(path, v, f):
    tri = v[f].astype(np.float32)
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    n /= np.maximum(np.linalg.norm(n, axis=1), 1e-12)[:, None]
    rec = np.zeros(len(f), np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]))
    rec["n"] = n; rec["v"] = tri
    with open(path, "wb") as fh:
        fh.write(b"left thigh".ljust(80, b" "))
        fh.write(np.uint32(len(f)).tobytes())
        rec.tofile(fh)
