"""Plateau loops -> NX input: per level, groups of (outer loop + its hole loops). Drops analytic levels."""
import json, numpy as np
from matplotlib.path import Path
from arcfit import seg_points
from common import W
d = json.load(open(W + r"\plateaus.json"))
SKIP = set()   # inner: no analytic levels in the list
out = []
for L in d["levels"]:
    if L["h"] in SKIP: continue
    polys = []
    for lp in L["loops"]:
        segs = []
        for s in lp["segs"]:
            if s[0] == "L": segs.append(("L", np.array(s[1]), np.array(s[2])))
            else: segs.append(("A", np.array(s[1]), np.array(s[2]), np.array(s[3]), s[4], s[5]))
        P = np.vstack([seg_points(s, 12) for s in segs])
        polys.append((lp, P))
    n = len(polys)
    parent = [-1] * n
    for i in range(n):
        best = None
        for j in range(n):
            if i == j: continue
            if Path(polys[j][1]).contains_points(polys[i][1][::5]).all():
                aj = abs(polys[j][0]["area"])
                if best is None or aj < abs(polys[best][0]["area"]): best = j
        parent[i] = -1 if best is None else best
    # depth parity: even depth = outer, odd = hole
    def depth(i):
        k = 0
        while parent[i] != -1: i = parent[i]; k += 1
        return k
    groups = []
    for i in range(n):
        if depth(i) % 2 == 0:
            holes = [j for j in range(n) if parent[j] == i and depth(j) % 2 == 1]
            groups.append(dict(outer=polys[i][0]["segs"], holes=[polys[j][0]["segs"] for j in holes], area=polys[i][0]["area"]))
    print(f"level {L['h']}: {n} loops -> {len(groups)} groups, holes {[len(g['holes']) for g in groups]}")
    out.append(dict(h=L["h"], groups=groups))
json.dump(out, open(W + r"\plateaus_nx.json", "w"))
