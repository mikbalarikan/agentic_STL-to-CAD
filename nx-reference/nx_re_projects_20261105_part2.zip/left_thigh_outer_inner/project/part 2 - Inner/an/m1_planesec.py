"""Vertical plane sections through the scan (lifted) and a CAD STL, plane normal n = (cos a, sin a, 0), offsets c.
usage: m1_planesec.py cad.stl out.png a_deg c1,c2,.. s0 s1 z0 z1
2D: s = p . (sin a, -cos a, 0) right, z up."""
import sys, json, os
import numpy as np, trimesh
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from fixlib import scan

cad, out, a = sys.argv[1], sys.argv[2], np.radians(float(sys.argv[3]))
cs = [float(t) for t in sys.argv[4].split(",")]
s0, s1, z0, z1 = [float(t) for t in sys.argv[5:9]]
n = np.array([np.cos(a), np.sin(a), 0.0]); d = np.array([np.sin(a), -np.cos(a), 0.0])
v, f = scan()
sm = trimesh.Trimesh(v, f, process=False); cm = trimesh.load(cad)
fig, axs = plt.subplots(1, len(cs), figsize=(7 * len(cs), 7 * (z1 - z0) / (s1 - s0) + 0.6), squeeze=False)
for k, c in enumerate(cs):
    ax = axs[0][k]
    for m, col, lw in ((sm, "#e08a00", 1.6), (cm, "k", 0.8)):
        sec = trimesh.intersections.mesh_plane(m, n, n * c)
        if len(sec) == 0:
            continue
        S = np.stack([sec @ d, sec[..., 2]], -1)
        mm = ((S[..., 0] > s0) & (S[..., 0] < s1) & (S[..., 1] > z0) & (S[..., 1] < z1)).any(1)
        ax.add_collection(LineCollection(S[mm], colors=col, lw=lw))
    ax.set_xlim(s0, s1); ax.set_ylim(z0, z1); ax.set_aspect("equal"); ax.grid(lw=0.3)
    ax.set_xticks(np.arange(np.ceil(s0), s1, 1.0)); ax.set_yticks(np.arange(np.ceil(z0), z1, 1.0)); ax.tick_params(labelsize=6)
    ax.set_title(f"n=({n[0]:.3f},{n[1]:.3f}) c={c}  s=p.({d[0]:.3f},{d[1]:.3f})", fontsize=9)
fig.tight_layout(); fig.savefig(out, dpi=70); print("ok", out)
