"""Collect the inner design values (measured -> rounded / common with the outer) into nx/params.json."""
import json, os
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
PO = json.load(open(os.path.join(ROOT, "nx", "params_outer.json")))
LIP = 35.20
P = {
    "expressions": {
        "lip_z": [LIP, "mm", "inner lip (parting) face; 0.44 shadow gap to the outer rim 34.76"],
        "boss_top_z": [35.95, "mm", "boss faces, meet the outer boss tops"],
        "rebate_z": [36.07, "mm", "rebate floor = outer tongue top"],
        "knee_od": [135.70, "mm", "knee hub OD (common with LT-OUT-001)"],
        "knee_face_z": [83.50, "mm", "knee outer face"],
        "knee_bore_d": [19.90, "mm", "knee centre bore"],
        "hip_ring_seat_z": [85.20, "mm", "pad on the outer hip-ring top"],
        "end_y": [287.40, "mm", "hip end face"],
        "seat_dz": [0.12, "mm", "final lift of the body: boss faces from Z 35.95 to the LT-OUT-001 boss tops at Z 36.07"],
    },
    "levels": {"lip": LIP, "boss_top": 35.95, "rebate": 36.07},
    "seat_dz": 0.12,          # all Z values in this file are BEFORE the final +0.12 lift (stage J)
    "skin_block": {"z0": 30.0, "z1": 125.0, "y0": -69.0, "y1": 287.40},
    "hub": {
        "r_out": 67.85, "r_in": 64.95, "chamfer": 3.3, "chamfer_a0": 110.0, "chamfer_a1": 330.0, "top_z": 83.50,
        "round_a0": 128.0, "round_a1": 320.0,
        "open_r": 68.5, "open_a0": -40.0, "open_a1": 110.0, "cav_top": 79.90,
        # outside profile (r, z), closed, revolved about the knee axis; bore cut later
        "profile_rz": [[0.0, 30.0], [67.85, 30.0], [67.85, 83.50], [27.5, 83.50], ["arc", 23.88, 84.52], [21.4, 86.0],
                       [20.115, 86.0], [20.115, 92.88], [0.0, 92.88]],
        "bore_d": 19.90,
        "knee_boss": {"ring_d": 40.23, "ring_top": 92.88,
                      "cove_rz": [[20.0, 83.50], [27.5, 83.50], ["arc", 23.88, 84.52], [21.4, 86.0], [20.0, 86.0]], "cove_vol": 1200.0},
        "low_a0": 155.5, "low_a1": 243.5, "low_z": 62.45,
    },
    "hip": {"ax_x": 37.97, "ax_z": 35.18, "ring_od": 105.03, "y0": 266.5, "y1": 276.85, "seat_z": 85.20},
    "bosses": [dict(x=b["x"], y=b["y"], col_d=15.0, top_z=35.95, pocket_d=10.0, pocket_z1=39.05,
                    hole_d=6.0, web_z1=44.75, cb_d=10.4) for b in PO["bosses"]],
    # hip plate (y 266.50 = outer plate face .. 269.55) with the clearance arc for the outer hip ring underneath
    "hip_plate": {"y0": 266.50, "y1": 269.55, "clear_d": 105.25},
    # two gussets under the skin at the hip end, symmetric about the hip axis (x 37.97 +- 27.0), 4.15 thick:
    # bottom edge 58 deg slope (1.592 mm/mm) down to a flat at z_flat, meeting the hip plate
    "gussets": [{"x0": 8.85, "t": 4.15, "z_flat": 75.45, "y_kink": 255.84, "slope": 1.592},
                {"x0": 62.90, "t": 4.15, "z_flat": 76.05, "y_kink": 255.46, "slope": 1.592}],
    "knee_ring_holes": dict(n=4, pcd=30.0, clock=45.0, d=3.3, z0=74.95, z1=92.88),
    "channel_holes": [dict(x=x, y=y, d=3.3, z0=74.95, depth=6.0) for x, y in
                      ((59.36, 62.33), (47.79, 70.73), (63.50, 81.86), (50.79, 84.72))],
    "disc_slot": dict(x=0.12, y=45.96, w=4.0, l=5.05, z0=70.0, z1=90.0),
    # lug face on the lip, except P3: the outer's P3 pin base rises to Z 36.24 (the inner scan's P3 lug face is at 36.3)
    "pins": [dict(x=p["x"], y=p["y"], lug_d=9.0, hole_d=4.0, z0=max(LIP, p["base_z"]), z1=max(LIP, p["base_z"]) + 10.0)
             for p in PO["pins"]],
}
json.dump(P, open(os.path.join(ROOT, "nx", "params.json"), "w"), indent=1)
print("wrote params.json")
