"""Bosses and pins: circle fits on z-sections; boss holes; depth of holes."""
import numpy as np, json
from common import load, section, fit_circle_robust, W
v, f = load()
guess = [(61.5, -40.5), (75.5, 29.8), (-25.8, 77.5), (-17.4, 165.8), (86.5, 165.6), (97.5, 265.0)]
def fit_at(z, c0, rmin, rmax):
    s = section(v, f, 2, z).reshape(-1, 3)[:, :2]
    d = np.hypot(s[:, 0] - c0[0], s[:, 1] - c0[1])
    p = s[(d > rmin) & (d < rmax)]
    if len(p) < 20: return None
    c, r, sd, m = fit_circle_robust(p)
    return [round(float(c[0]), 3), round(float(c[1]), 3), round(float(2 * r), 3), round(sd, 3), int(m.sum())]
res = []
for g in guess:
    row = {"guess": g}
    for z in (38.5, 37.5, 35.5, 30.0, 20.0):
        row[f"od_{z}"] = fit_at(z, g, 3.0, 5.2)
    for z in (38.5, 36.0, 30.0, 20.0, 10.0):
        row[f"id_{z}"] = fit_at(z, g, 0.8, 2.6)
    res.append(row); print(json.dumps(row))
# pins: find small circles at z = 40.5
s = section(v, f, 2, 40.5).reshape(-1, 3)[:, :2]
print("points at z=40.5:", len(s))
from scipy.cluster.vq import kmeans2
from scipy import ndimage
g = np.zeros((400, 300), bool)
ix = ((s[:, 0] + 100)).astype(int); iy = ((s[:, 1] + 75)).astype(int)
g[iy.clip(0, 399), ix.clip(0, 299)] = True
lab, n = ndimage.label(ndimage.binary_dilation(g, iterations=2))
for k in range(1, n + 1):
    yy, xx = np.where(lab == k); cx, cy = xx.mean() - 100, yy.mean() - 75
    print("cluster at z40.5", round(cx, 1), round(cy, 1), "pin od", fit_at(40.5, (cx, cy), 0.3, 3.0), "z41.5", fit_at(41.5, (cx, cy), 0.3, 3.0))
json.dump(res, open(W + r"\bosses.json", "w"), indent=1)
