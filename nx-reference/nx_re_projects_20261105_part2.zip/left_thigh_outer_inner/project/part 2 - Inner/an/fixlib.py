"""Shared helpers for the Rev A review fixes (stage L): scan sections, outer contours, fix-spec meshes.
Coordinates are the FINAL part frame (scan lifted by seat_dz)."""
import os, json
import numpy as np
from common import W, load, section

ROOT = os.path.dirname(W)
DZ = json.load(open(os.path.join(ROOT, "nx", "params.json")))["seat_dz"]
_scan = {}


def scan():
    if "v" not in _scan:
        v, f = load(); v = v.copy(); v[:, 2] += DZ
        _scan["v"], _scan["f"] = v, f
    return _scan["v"], _scan["f"]


def zsec(z, win=None):
    """Scan section at z as segment array (k,2,2) in XY, optionally limited to a window (x0,x1,y0,y1)."""
    v, f = scan()
    s = section(v, f, 2, z)[:, :, :2]
    if win is not None:
        x0, x1, y0, y1 = win
        m = ((s[..., 0] > x0) & (s[..., 0] < x1) & (s[..., 1] > y0) & (s[..., 1] < y1)).all(1)
        s = s[m]
    return s


def polar_outer(pts, c, a0, a1, da=0.5, inner=False):
    """Outermost (or innermost) point per angle bin seen from centre c, angles in degrees a0..a1."""
    d = pts - np.asarray(c)
    a = np.degrees(np.arctan2(d[:, 1], d[:, 0])); r = np.hypot(d[:, 0], d[:, 1])
    out = []
    for t in np.arange(a0, a1 + 1e-9, da):
        m = (a >= t - da / 2) & (a < t + da / 2)
        if m.sum() < 2:
            continue
        k = np.argmin(r[m]) if inner else np.argmax(r[m])
        out.append(pts[m][k])
    return np.array(out)


def segs_to_poly(segs, n=10):
    from arcfit import seg_points
    pts = []
    for s in segs:
        if s[0] == "L":
            q = seg_points(("L", np.array(s[1]), np.array(s[2])), 2)
        else:
            q = seg_points(("A", np.array(s[1]), np.array(s[2]), np.array(s[3]), s[4], s[5]), n)
        pts.append(q[:-1])
    return np.vstack(pts)


def fit_segs(P, tol=0.1, closed=True):
    from arcfit import fit_loop, fit_open
    segs = fit_loop(np.asarray(P, float), tol=tol) if closed else fit_open(np.asarray(P, float), tol)
    return [([s[0], np.asarray(s[1]).tolist(), np.asarray(s[2]).tolist()] if s[0] == "L" else
             [s[0], np.asarray(s[1]).tolist(), np.asarray(s[2]).tolist(), np.asarray(s[3]).tolist(), float(s[4]), bool(s[5])]) for s in segs]


# ------------------------------------------------------------------ tool meshes (simulation with manifold3d)
def _m():
    import manifold3d as m3
    return m3


def poly_prism(poly2d, h0, h1):
    """Manifold of a planar polygon (outer, holes...) extruded between h0 and h1 along its local +n."""
    m3 = _m()
    cs = m3.CrossSection([np.asarray(p, float) for p in poly2d], m3.FillRule.EvenOdd)
    return m3.Manifold.extrude(cs, h1 - h0).translate([0, 0, h0])


def tool_manifold(t):
    """Fix spec -> manifold3d.Manifold in the part frame."""
    m3 = _m()
    loops = [segs_to_poly(lp) if isinstance(lp[0][0], str) else np.asarray(lp, float) for lp in t.get("loops", [])]
    if t["type"] == "zprism":
        m = poly_prism(loops, t["z0"], t["z1"])
        if "plane" in t:
            a, b, c = t["plane"]; nn = np.linalg.norm([a, b, 1.0])
            if t["kind"] == "add" or t.get("side") == "top":     # keep the material ABOVE the plane
                m = m.trim_by_plane([-a / nn, -b / nn, 1 / nn], c / nn)
            else:
                m = m.trim_by_plane([a / nn, b / nn, -1 / nn], -c / nn)
        return m
    if t["type"] in ("prism_y", "prism_x"):
        # profile loops in (u, z): prism_y -> u = x, extruded along +y from s0 to s1; prism_x -> u = y, along +x
        m = poly_prism(loops, t["s0"], t["s1"])        # local (u, z, s)
        if t["type"] == "prism_y":
            # local X=u->x, Y=z->z, Z=s->y : rows map local to world
            M = np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0]], float)
        else:
            M = np.array([[0, 0, 1, 0], [1, 0, 0, 0], [0, 1, 0, 0]], float)
        return m.transform(M)
    if t["type"] == "revolve":
        cs = m3.CrossSection([np.asarray(p, float) for p in loops], m3.FillRule.EvenOdd)
        # manifold revolves the XY cross-section (x = radius, y = height) about Y; turn Y up to Z
        m = m3.Manifold.revolve(cs, 256, t.get("a1", 360.0) - t.get("a0", 0.0))
        return m.rotate([0, 0, t.get("a0", 0.0)])          # manifold revolves about Y and makes that the Z axis
    if t["type"] == "cone":
        h = t["depth"] + 0.5
        r_top = t["d_top"] / 2 + 0.5 * (t["d_top"] - t["d_bot"]) / (2 * t["depth"]) * 0  # straight 45 deg above the face
        m = m3.Manifold.cylinder(t["depth"], t["d_bot"] / 2, t["d_top"] / 2, 96).translate([t["centre"][0], t["centre"][1], t["z_top"] - t["depth"]])
        return m + m3.Manifold.cylinder(1.0, t["d_top"] / 2, t["d_top"] / 2, 96).translate([t["centre"][0], t["centre"][1], t["z_top"] - 1e-3])
    if t["type"] == "cyl":
        cx, cy, r = t["circle"]
        return m3.Manifold.cylinder(t["z1"] - t["z0"], r, r, 96).translate([cx, cy, t["z0"]])
    if t["type"] == "prism_v":
        # stage M: profile (s, z) in a vertical plane, normal n = (cos a, sin a, 0), s along d = (sin a, -cos a, 0);
        # extruded along n from c0 to c1 (c = p . n)
        a = np.radians(t["a"]); n = [np.cos(a), np.sin(a)]; d = [np.sin(a), -np.cos(a)]
        m = poly_prism(loops, t["c0"], t["c1"])             # local (s, z, c)
        M = np.array([[d[0], 0, n[0], 0], [d[1], 0, n[1], 0], [0, 1, 0, 0]], float)
        return m.transform(M)
    if t["type"] == "cyl_axis":
        o, u = np.asarray(t["origin"], float), np.asarray(t["dir"], float) / np.linalg.norm(t["dir"])
        m = m3.Manifold.cylinder(t["h"], t["d"] / 2, t["d"] / 2, 96)
        z = np.array([0, 0, 1.0]); ax = np.cross(z, u); s = np.linalg.norm(ax); c = float(z @ u)
        K = np.array([[0, -ax[2], ax[1]], [ax[2], 0, -ax[0]], [-ax[1], ax[0], 0]])
        Rm = np.eye(3) + K + K @ K * ((1 - c) / s ** 2) if s > 1e-9 else np.eye(3)
        return m.transform(np.c_[Rm, o])
    if t["type"] == "skin_deep":
        return skin_deep(t["depth"], t["box"])
    raise ValueError(t["type"])


def skin_deep(depth, box, cell=0.2):
    """Stage M: the part of the envelope (stage-A skin solid, lifted) deeper than `depth` under its surface, inside
    box (x0,x1,y0,y1,z0,z1). Mesh stand-in for NX: box AND envelope, skin faces offset inward (Offset Region)."""
    import open3d as o3d
    from skimage import measure
    m3 = _m()
    env = o3d.io.read_triangle_mesh(os.path.join(ROOT, "nx", "envL", "envelope_unlifted.stl"))
    env.translate([0, 0, DZ])
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(env))
    x0, x1, y0, y1, z0, z1 = box
    g = [np.arange(a - cell, b + 2 * cell, cell) for a, b in ((x0, x1), (y0, y1), (z0, z1))]
    G = np.stack(np.meshgrid(*g, indexing="ij"), -1).reshape(-1, 3).astype(np.float32)
    sd = sc.compute_signed_distance(o3d.core.Tensor(G)).numpy().reshape([len(a) for a in g])
    F = -sd - depth                                               # > 0: deeper than depth inside the envelope
    inb = np.ones_like(F, bool)
    for k, (a, b) in enumerate(((x0, x1), (y0, y1), (z0, z1))):
        sl = [None, None, None]; sl[k] = slice(None)
        inb &= ((g[k] >= a) & (g[k] <= b))[tuple(sl)]
    F = np.where(inb, F, -1.0)
    vv, ff, _, _ = measure.marching_cubes(F, 0.0, spacing=(cell, cell, cell))
    vv += np.array([g[0][0], g[1][0], g[2][0]])
    me = m3.Mesh(vert_properties=vv.astype(np.float32), tri_verts=ff[:, ::-1].astype(np.uint32))
    m = m3.Manifold(me)
    if m.volume() < 0:
        m = m3.Manifold(m3.Mesh(vert_properties=vv.astype(np.float32), tri_verts=ff.astype(np.uint32)))
    return m


def full_tool(t):
    m = tool_manifold(t)
    for a in t.get("and", []):
        m = m ^ tool_manifold(a)
    for a in t.get("minus", []):
        m = m - tool_manifold(a)
    return m


def mesh_to_manifold(path):
    import trimesh
    m3 = _m()
    tm = trimesh.load(path)
    tm.merge_vertices()
    return m3.Manifold(m3.Mesh(vert_properties=np.asarray(tm.vertices, np.float32), tri_verts=np.asarray(tm.faces, np.uint32)))


def manifold_to_stl(m, path):
    import trimesh
    me = m.to_mesh()
    trimesh.Trimesh(np.asarray(me.vert_properties)[:, :3], np.asarray(me.tri_verts)).export(path)


# ------------------------------------------------------------------ height-field tools from the open-side depth map
_dm = {}


def depth(tag="revA"):
    if tag not in _dm:
        _dm[tag] = dict(np.load(os.path.join(W, f"depth_{tag}.npz")))     # top_<tag> -> depth_top_<tag>.npz
    return _dm[tag]


def hf_tool(kind, plane, box, grow=1.5, drop=0.5, need_thr=0.3, tag="revA", excl_circles=(), seeds=None, tol=0.1,
            min_loop=1.0, smooth=0.6, band=None):
    """Region on the open-side depth map where the scan surface is at/nearer than the plane (add) or at/deeper (cut),
    inside box (x0,x1,y0,y1), limited to where the CAD disagrees (dilated by grow mm). plane = h or (a, b, c).
    Returns (loops as fitted segs [outer, holes...] grouped, area mm2, mask)."""
    from scipy import ndimage
    import contourpy
    from matplotlib.path import Path as MPath
    d = depth(tag); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
    x0, x1, y0, y1 = box
    i0, i1 = int((y0 - Y0) / C), int((y1 - Y0) / C); j0, j1 = int((x0 - X0) / C), int((x1 - X0) / C)
    zs, zc = d["zs"][i0:i1, j0:j1], d["zc"][i0:i1, j0:j1]
    xs = X0 + (np.arange(j0, j1) + 0.5) * C; ys = Y0 + (np.arange(i0, i1) + 0.5) * C
    XX, YY = np.meshgrid(xs, ys)
    F = plane[0] * XX + plane[1] * YY + plane[2] if isinstance(plane, (list, tuple)) else np.full(XX.shape, float(plane))
    if kind == "add":
        G = (F + drop) - zs; need = (zc > F + need_thr) | ~np.isfinite(zc)
    else:
        G = zs - (F - drop); need = np.isfinite(zc) & (zc < F - need_thr)
    if band is not None:     # only cells within band mm of the plane on the other side (keeps walls / ribs out)
        G = np.minimum(G, (zs - (F - band)) if kind == "add" else ((F + band) - zs))
    G = np.where(np.isfinite(G), G, -1.0)
    body_ = G > 0
    need &= body_
    for (cx, cy, r) in excl_circles:
        m_ = np.hypot(XX - cx, YY - cy) < r
        body_ &= ~m_; need &= ~m_
    if seeds is not None:
        lb, _ = ndimage.label(body_)
        ids = [lb[int((sy - y0) / C), int((sx - x0) / C)] for sx, sy in seeds]
        body_ &= np.isin(lb, [i for i in ids if i > 0])
        need &= body_
    reg = body_ & ndimage.binary_dilation(need, iterations=max(1, int(grow / C))) if grow else body_.copy()
    reg = ndimage.binary_opening(reg, iterations=2)
    lb, n = ndimage.label(reg)
    keep = np.unique(lb[need & reg]); keep = keep[keep > 0]
    reg = np.isin(lb, keep)
    Gm = np.where(reg, np.clip(G, -0.5, 0.5), -0.5)
    Gm[reg] = np.maximum(Gm[reg], 0.05)
    Gm = ndimage.gaussian_filter(np.pad(Gm, 2, constant_values=-0.5), smooth)
    loops = []
    for Cn in contourpy.contour_generator(z=Gm, line_type="Separate").lines(0.0):
        if np.linalg.norm(Cn[0] - Cn[-1]) > 1e-6:
            continue
        Q = np.c_[x0 + (Cn[:, 0] - 2 + 0.5) * C, y0 + (Cn[:, 1] - 2 + 0.5) * C][:-1]
        A = 0.5 * (np.dot(Q[:, 0], np.roll(Q[:, 1], -1)) - np.dot(Q[:, 1], np.roll(Q[:, 0], -1)))
        if abs(A) < min_loop:
            continue
        loops.append((abs(A), Q))
    loops.sort(key=lambda t: -t[0])
    # group: outer loops with the holes they contain
    groups = []
    for A, Q in loops:
        host = None
        for g in groups:
            if MPath(g[0]).contains_points(Q[::4]).all():
                host = g
        if host is None:
            groups.append([Q])
        else:
            host.append(Q)
    out = [[fit_segs(Q, tol) for Q in g] for g in groups]
    return out, float(reg.sum() * C * C), reg


def hf_fix(fid, kind, plane, box, note, clusters=(), zlo=30.0, zhi=130.0, **kw):
    groups, area, _ = hf_tool(kind, plane, box, **kw)
    fl = []
    for k, g in enumerate(groups):
        h = plane if not isinstance(plane, (list, tuple)) else None
        f = dict(id=f"{fid}{'abcdefghijklmnop'[k] if len(groups) > 1 else ''}", kind=kind, type="zprism", loops=g,
                 note=note, clusters=list(clusters), area=round(area, 1))
        if h is not None:
            f.update(z0=h if kind == "add" else zlo, z1=zhi if kind == "add" else h)
        else:
            f.update(z0=zlo, z1=zhi, plane=list(plane))
        fl.append(f)
    return fl
