"""INNER seam-groove centre lines: anchor polylines in (y, theta deg) refined to the residual minimum of the final
skin fit, mapped onto the fitted skin and lifted along the outward normal (tube centre). Writes work/grooves.json.
Narrow seams: tube 1.8, lift 0.35 (0.55 deep, same as the outer's seams). G3 is a wide shallow seam with one steep
wall: tube 10, 0.65 deep, centre moved 2.2 mm to the ramp side of the residual minimum."""
import json
import numpy as np
from scipy.ndimage import gaussian_filter1d
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
from i20lib import evalr

ANCH = {
    "G1": [(25, 2), (25, 8), (27, 13), (31, 18), (40, 25), (55, 34), (70, 44), (90, 56), (110, 70), (130, 84),
           (150, 97), (170, 108), (191, 119.5)],
    "G2": [(140, 180), (140, 165), (141, 155), (145, 145), (152, 138), (165, 131), (192, 120), (220, 108), (240, 99),
           (255, 91), (265, 84), (271, 76), (272, 68), (270, 57), (267, 48), (262, 43), (250, 40), (235, 37),
           (220, 34), (205, 31), (195, 28), (187, 25)],
    "G3": [(53, 2), (54, 10), (57, 17), (62, 22), (70, 26), (85, 30), (100, 33), (120, 36), (140, 37), (155, 37),
           (170, 36), (185, 35), (200, 33), (215, 31), (230, 28), (245, 24), (253, 18), (257, 10), (258, 2)],
    "G4": [(240, 144), (246, 149), (252, 154), (258, 160), (262, 167), (264, 174), (265, 180)],
}
SPEC = {"G3": dict(tube_d=10.0, lift=5.0 - 0.65, shift_mm=-2.2)}
d = np.load(W + r"\skin_data.npz"); mask = d["mask"]
y_, t_, res = d["y"], np.degrees(d["t"]), d["res"]
ok = mask & np.isfinite(res)
GY = np.round(y_ + 72).astype(int); GT = np.round((t_ + 4) / 0.5).astype(int)
R = np.full((GY.max() + 2, GT.max() + 2), np.nan); R[GY[ok], GT[ok]] = res[ok]
s = np.load(W + r"\skin_fit.npz"); pc, ZC = s["pc"], float(s["ZC"])


def P3(y, thd):
    th = np.radians(thd); r = evalr(s["ty"], s["tt"], s["C"], np.array([y]), np.array([th]))[0]
    return np.array([np.polyval(pc, y) + r * np.cos(th), y, ZC + r * np.sin(th)]), r


def normal(y, thd):
    e = 0.05
    a = P3(y + e, thd)[0] - P3(y - e, thd)[0]; b = P3(y, thd + e)[0] - P3(y, thd - e)[0]
    n = np.cross(a, b); n /= np.linalg.norm(n)
    c = np.array([np.polyval(pc, y), y, ZC])
    if n @ (P3(y, thd)[0] - c) < 0: n = -n
    return n


out = {}
fig, ax = plt.subplots(figsize=(28, 12))
ax.imshow(np.clip(R.T, -0.6, 0.3), origin="lower", extent=[-72, R.shape[0] - 72, -4, R.shape[1] * 0.5 - 4], aspect="auto", cmap="gray")
for name, an in ANCH.items():
    sp = SPEC.get(name, {})
    A = np.array(an, float)
    seg = np.r_[0, np.cumsum(np.hypot(np.diff(A[:, 0]), np.diff(A[:, 1]) * 1.05))]
    ss = np.arange(0, seg[-1], 1.0)
    Q = np.c_[np.interp(ss, seg, A[:, 0]), np.interp(ss, seg, A[:, 1])]
    T = np.gradient(Q, axis=0); T /= np.linalg.norm(T, axis=1)[:, None] + 1e-12
    Nn = np.c_[-T[:, 1], T[:, 0]]
    Qr = Q.copy(); found = np.zeros(len(Q), bool)
    for i, (q, nn) in enumerate(zip(Q, Nn)):
        if q[1] < 2.5 or q[1] > 177.5:
            continue
        best = None
        for k in np.linspace(-3, 3, 25):
            p = q + k * nn * np.array([1.0, 1 / 1.05])
            iy, it = int(round(p[0] + 72)), int(round((p[1] + 4) / 0.5))
            if 0 <= iy < R.shape[0] and 0 <= it < R.shape[1] and np.isfinite(R[iy, it]):
                if best is None or R[iy, it] < best[0]:
                    best = (R[iy, it], p)
        if best is not None and best[0] < -0.15:
            Qr[i] = best[1]; found[i] = True
    Qs = np.c_[gaussian_filter1d(Qr[:, 0], 2.0, mode="nearest"), gaussian_filter1d(Qr[:, 1], 2.0, mode="nearest")]
    if sp.get("shift_mm"):
        Qs[:, 1] += np.degrees(sp["shift_mm"] / np.array([P3(y, t)[1] for y, t in Qs]))
    lift = sp.get("lift", 0.35)
    pts = np.array([P3(y, t)[0] + lift * normal(y, t) for y, t in Qs])
    keep = np.r_[np.arange(0, len(pts), 3), len(pts) - 1]
    out[name] = dict(pts=pts[np.unique(keep)].tolist(), found=float(found.mean()), n=int(len(pts)),
                     tube_d=sp.get("tube_d", 1.8), lift=lift)
    if name == "G3":    # re-lifted centre lines for smaller tubes (same 0.65 depth) in case the 10 mm tube is refused
        nrm = np.array([normal(y, t) for y, t in Qs]); base = np.array([P3(y, t)[0] for y, t in Qs])
        out[name]["pts_lift"] = {str(td): (base + (td / 2.0 - 0.65) * nrm)[np.unique(keep)].tolist() for td in (6.0, 4.0)}
    ax.plot(Qs[:, 0], Qs[:, 1], "-", lw=1.2, label=f"{name} found {found.mean():.0%}")
    print(name, "points", len(pts), "refined share", round(found.mean(), 2))
ax.legend(); ax.set_xlim(-72, 290); ax.grid(True, lw=0.3)
fig.tight_layout(); fig.savefig(W + r"\groove_paths.png", dpi=55)
json.dump(dict(lift=0.35, tube_d=1.8, paths=out), open(W + r"\grooves.json", "w"))
