"""Cylinder census at the bosses / pin holes of the REGISTERED inner (LT-OUT frame), centred on the outer's
design positions (common xy). Prints D, z-range, convex/concave per radius peak."""
import numpy as np, json
from common import load, tri_data, fit_circle_robust, W
PO = json.load(open(r"..\nx\params_outer.json"))
v, f = load(); c, n, a = tri_data(v, f)
F = {f"B{i+1}": (b["x"], b["y"]) for i, b in enumerate(PO["bosses"])}
F.update({f"P{i+1}": (p["x"], p["y"]) for i, p in enumerate(PO["pins"])})
res = {}
for k, c0 in F.items():
    d = np.hypot(c[:, 0] - c0[0], c[:, 1] - c0[1])
    m0 = (d < 13) & (np.abs(n[:, 2]) < 0.25)
    rd = np.c_[c[m0, 0] - c0[0], c[m0, 1] - c0[1]] / d[m0, None]
    nr = np.einsum("ij,ij->i", n[m0, :2], rd)
    m1 = np.abs(nr) > 0.9
    cc, dd, aa, sg = c[m0][m1], d[m0][m1], a[m0][m1], np.sign(nr[m1])
    h, e = np.histogram(dd, bins=np.arange(0, 13, 0.2), weights=aa)
    out, used = [], np.zeros(len(h), bool)
    for i in np.argsort(h)[::-1]:
        if h[i] < 3 or used[max(0, i - 2):i + 3].any(): continue
        used[i] = True
        mm = np.abs(dd - e[i] - 0.1) < 0.45
        if mm.sum() < 40: continue
        cf, r, sd, kk = fit_circle_robust(cc[mm][:, :2])
        zz = cc[mm][kk, 2]
        out.append(dict(off=[round(cf[0] - c0[0], 3), round(cf[1] - c0[1], 3)], D=round(2 * r, 3), sd=round(sd, 3),
                        z=[round(np.percentile(zz, 2), 2), round(np.percentile(zz, 98), 2)],
                        kind="boss/shaft" if np.median(sg[mm]) > 0 else "hole", area=round(float(h[i]), 1)))
    out.sort(key=lambda o: o["D"]); res[k] = out
    print(k, c0)
    for o in out:
        if o["sd"] < 0.2: print("   ", o)
json.dump(res, open(W + r"\boss_census.json", "w"), indent=1)
