"""CAD (red) over scan (black) plane sections. usage: ovl.py cad.stl out.png AXIS v1,v2 [lim x0 x1 y0 y1]"""
import sys, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import load, section
a = sys.argv[1:]
import open3d as o3d
cm = o3d.io.read_triangle_mesh(a[0]); cv = np.asarray(cm.vertices); cf = np.asarray(cm.triangles)
axn = "xyz".index(a[2]); vals = [float(t) for t in a[3].split(",")]
lim = [float(t) for t in a[a.index("lim") + 1:a.index("lim") + 5]] if "lim" in a else None
v, f = load(); oth = [k for k in range(3) if k != axn]
fig, axs = plt.subplots(1, len(vals), figsize=(10 * len(vals), 9), squeeze=False)
for ax, val in zip(axs[0], vals):
    ax.add_collection(LineCollection(section(v, f, axn, val)[:, :, oth], colors="k", lw=0.6))
    ax.add_collection(LineCollection(section(cv, cf, axn, val)[:, :, oth], colors="r", lw=0.8))
    ax.set_aspect("equal"); ax.autoscale(); ax.grid(True, lw=0.3); ax.set_title(f"{'xyz'[axn]}={val}  black scan, red CAD")
    if lim: ax.set_xlim(lim[0], lim[1]); ax.set_ylim(lim[2], lim[3])
fig.tight_layout(); fig.savefig(a[1], dpi=70)
