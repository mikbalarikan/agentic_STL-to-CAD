"""Collect the stage-L fixes for NX: manual work/fixes.json (+ F15-F17 added here) + auto work/autofix_revA.json.
zprism point loops are fitted to line/arc chains (the NX build draws exactly these), prism / revolve profiles stay
polylines. Writes nx/fixes_L.json (final part frame, lifted) and work/fixes_L_sim.json (same geometry for i97_sim)."""
import json, os
import numpy as np
from fixlib import W, ROOT, fit_segs, depth

fx = [f for f in json.load(open(os.path.join(W, "fixes.json"))) if f["id"][:3] not in ("F15", "F16", "F17")]
fx.append(dict(id="F15", kind="cut", type="zprism", z0=36.30, z1=58.0,
               loops=[[[60.5, -28.95], [72.1, -28.95], [72.0, -29.2], [71.3, -30.7], [70.5, -32.0], [69.3, -33.0], [68.3, -33.5],
                       [65.7, -33.6], [64.5, -33.2], [63.2, -32.7], [62.0, -32.5], [60.6, -32.5]]],
               note="knee-end cavity end: Rev A cavity stopped flat at Y -29.0, scan end wall curves to Y -33.6 (z 36.3-58)", clusters=[11]))
# posts on the knee floor: centre = centroid of scan cells nearer than the floor by > 2 mm
d = depth("revA"); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"]); zs = d["zs"]
ny, nx = zs.shape
XX, YY = np.meshgrid(X0 + (np.arange(nx) + .5) * C, Y0 + (np.arange(ny) + .5) * C)
for k, (gx, gy) in enumerate(((-31.0, -51.3), (-56.8, 19.3))):
    m = (np.hypot(XX - gx, YY - gy) < 3.0) & (zs < 60.5)
    cx, cy = float(XX[m].mean()), float(YY[m].mean()); dia = 2 * np.sqrt(m.sum() * C * C / np.pi)
    top = float(np.percentile(zs[m], 50))
    fx.append(dict(id=f"F16{'ab'[k]}", kind="add", type="cyl", circle=[round(cx, 2), round(cy, 2), round(dia / 2, 2)], z0=round(top, 2), z1=64.0,
                   note=f"knee-floor post Ø{dia:.2f} to Z {top:.2f} (missing in Rev A)", clusters=[36, 39]))
P = json.load(open(os.path.join(ROOT, "nx", "params.json")))
for k, (p, zb) in enumerate(zip(P["pins"], (60.45, 60.30, 63.55))):
    fx.append(dict(id=f"F17{'abc'[k]}", kind="cut", type="cyl", circle=[p["x"], p["y"], p["hole_d"] / 2], z0=p["z1"] + P["seat_dz"] - 0.5, z1=zb,
                   note=f"pin hole Ø{p['hole_d']} continued to Z {zb} (scan: open to 0.4 mm under the outer skin; Rev A stopped 10 deep)", clusters=[57, 59, 41]))
json.dump(fx, open(os.path.join(W, "fixes.json"), "w"), indent=0)
auto = json.load(open(os.path.join(W, "autofix_revA.json")))
out = []
for f in fx + auto:
    g = dict(f)
    if g["type"] == "zprism":
        g["loops"] = [lp if isinstance(lp[0][0], str) else fit_segs(np.asarray(lp, float), 0.08) for lp in g["loops"]]
    out.append(g)
# cap the open-side zprism adds just above the CAD surface they fill against (no envelope clip needed, grooves and
# windows on the skin can not be refilled); keep the envelope clip only where the cap would reach the outer skin
from fixlib import segs_to_poly
from matplotlib.path import Path as MPath
dt = depth("top_sim2")
zc, ztc = d["zc"], -dt["zc"]
for g in out:
    if g["kind"] != "add" or g["type"] != "zprism":
        continue
    poly = segs_to_poly(g["loops"][0])
    lo, hi = poly.min(0), poly.max(0)
    i0, i1 = int((lo[1] - Y0) / C), int((hi[1] - Y0) / C) + 1; j0, j1 = int((lo[0] - X0) / C), int((hi[0] - X0) / C) + 1
    sub = np.c_[XX[i0:i1, j0:j1].ravel(), YY[i0:i1, j0:j1].ravel()]
    inside = MPath(poly).contains_points(sub).reshape(i1 - i0, j1 - j0)
    zcin, ztin = zc[i0:i1, j0:j1][inside], ztc[i0:i1, j0:j1][inside]
    if not np.isfinite(zcin).all() or not np.isfinite(ztin).any():
        g["clip"] = "envelope"; continue
    cap = float(np.nanmax(zcin)) + 0.6
    if cap < float(np.nanmin(ztin)) - 0.8:
        g["z1"] = round(cap, 2); g["clip"] = "none"
    else:
        g["clip"] = "envelope"
print("adds capped:", sum(1 for g in out if g["kind"] == "add" and g.get("clip") == "none"), "envelope-clipped:",
      [g["id"] for g in out if g["kind"] == "add" and g.get("clip", "envelope") == "envelope"])
json.dump(out, open(os.path.join(ROOT, "nx", "fixes_L.json"), "w"), indent=0)
json.dump(out, open(os.path.join(W, "fixes_L_sim.json"), "w"), indent=0)
print(len(out), "tools:", sum(1 for f in out if f["kind"] == "add"), "add,", sum(1 for f in out if f["kind"] == "cut"), "cut")
print([f["id"] + ":" + f["type"] for f in out if not f.get("auto")])
