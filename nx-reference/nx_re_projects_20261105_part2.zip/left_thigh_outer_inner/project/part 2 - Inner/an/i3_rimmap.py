"""Top-view maps of rim-level facets: inner (in its rim-plane frame, flipped so it faces down like on assembly)
and outer (LT-OUT-001 frame). Colour = height rel. rim."""
import numpy as np, json, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, tri_data, W
from outer import load_outer
v, f = load(frame=False)
pr = json.load(open(W + r"\parting_raw.json")); cc = np.array(pr["c"]); z = np.array(pr["n"])
x = np.array([1.0, 0, 0]); x -= z * (x @ z); x /= np.linalg.norm(x); y = np.cross(z, x)
vp = (v - cc) @ np.vstack([x, y, z]).T
c, n, a = tri_data(vp, f)
vo, fo = load_outer(); co, no, ao = tri_data(vo, fo)
fig, ax = plt.subplots(1, 2, figsize=(22, 20))
m = (np.abs(n[:, 2]) > 0.97) & (c[:, 2] > -4) & (c[:, 2] < 3)
s = ax[0].scatter(c[m, 0], c[m, 1], c=c[m, 2], s=0.2, cmap="jet", vmin=-4, vmax=2); plt.colorbar(s, ax=ax[0])
ax[0].set_title("INNER (scanner frame on its rim plane, viewed from +Z = open side)"); ax[0].set_aspect("equal"); ax[0].grid()
m = (np.abs(no[:, 2]) > 0.97) & (co[:, 2] > 31) & (co[:, 2] < 40)
s = ax[1].scatter(co[m, 0], co[m, 1], c=co[m, 2] - 34.76, s=0.2, cmap="jet", vmin=-2, vmax=4); plt.colorbar(s, ax=ax[1])
ax[1].set_title("OUTER (LT-OUT-001 frame, rel. rim 34.76, viewed from +Z)"); ax[1].set_aspect("equal"); ax[1].grid()
plt.savefig(W + r"\rim_maps.png", dpi=60, bbox_inches="tight")
