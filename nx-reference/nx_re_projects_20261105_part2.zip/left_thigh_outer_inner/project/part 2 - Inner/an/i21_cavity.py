"""INNER cavity surface r_in(y, th) about the same centre line as the skin (upper half, th -4..184 deg).
Data: per ray the crossing right inside the outermost one, if the wall r1 - r2 is 1.2..4.5 mm.
Hidden zones (knee hub, ribs, bosses) guided by skin - nominal wall. Robust LSQ, same B-spline set-up as the skin.
Writes work/inner_fit.npz, work/inner_res.png."""
import sys
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.interpolate import BSpline
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load, section, W
from i20lib import evalr, fit_grid

s = np.load(W + r"\skin_fit.npz")
pc, ZC, YCL = s["pc"], float(s["ZC"]), float(s["YCL"])
xcf = lambda y: np.polyval(pc, np.maximum(y, YCL))
KY, KT, LAM = 8.0, 4.0, 3e-3
if "fit" not in sys.argv:
    v, f = load()
    ys = np.arange(-72.0, 293.0, 1.0)
    th = np.radians(np.arange(-4.0, 184.01, 0.5))
    rows = []
    for y in ys:
        sg = section(v, f, 1, y)
        if len(sg) == 0: continue
        seg = sg[:, :, [0, 2]]
        seg = seg[(seg[:, :, 1] > ZC - 1.5).all(1)]
        if len(seg) == 0: continue
        c = np.array([xcf(y), ZC]); a = seg[:, 0] - c; b = seg[:, 1] - c; e = b - a
        for t in th:
            d = np.array([np.cos(t), np.sin(t)])
            den = -d[0] * e[:, 1] + d[1] * e[:, 0]
            ok = np.abs(den) > 1e-12; den = np.where(ok, den, 1)
            r = (-a[:, 0] * e[:, 1] + a[:, 1] * e[:, 0]) / den
            u = (d[0] * a[:, 1] - d[1] * a[:, 0]) / den
            m = ok & (u >= 0) & (u <= 1) & (r > 0)
            if m.sum() < 2: continue
            o = np.argsort(r[m])[::-1]
            k2 = np.where(m)[0][o[1]]
            en = np.array([-e[k2, 1], e[k2, 0]]); en /= np.linalg.norm(en)
            rows.append((y, t, r[m][o[0]], r[m][o[1]], abs(en @ d)))
    np.savez(W + r"\cav_raw.npz", D=np.array(rows))
D = np.load(W + r"\cav_raw.npz")["D"]
y_, t_, r1, r2, inc = D.T
X1 = xcf(y_) + r1 * np.cos(t_); Z2 = ZC + r2 * np.sin(t_)
dk = np.hypot(X1, y_); phk = np.degrees(np.arctan2(y_, X1))
wall = r1 - r2
r_out = evalr(s["ty"], s["tt"], s["C"], y_, t_)
mask = (wall > 1.2) & (wall < 4.5) & (inc > 0.25) & (Z2 > 37.0) & (np.abs(r1 - r_out) < 0.3)
mask &= ~(dk < 69.5)
mask &= ~((dk < 75) & ((phk > 128) | (phk < -41)))
WN = float(np.median(wall[mask]))
print("rows", len(D), "inner rows", mask.sum(), "median wall", round(WN, 3))
guide = ~mask & (inc > 0.1)
rr = np.where(mask, r2, r_out - WN)
wts = np.where(mask, inc, np.where(guide, 0.2, 0.0))
m_all = mask | guide
for it in range(3):
    ty, tt, C = fit_grid(y_[m_all], t_[m_all], rr[m_all], wts[m_all], KY, KT, LAM)
    res = (rr - evalr(ty, tt, C, y_, t_)) * inc
    bad = mask & (np.abs(res) > 0.25)
    print(f"pass {it}: |res| p50 {np.percentile(abs(res[mask]),50):.3f} p95 {np.percentile(abs(res[mask]),95):.3f} p99 {np.percentile(abs(res[mask]),99):.3f}; dropping {bad.sum()}")
    m_all &= ~bad
np.savez(W + r"\inner_fit.npz", ty=ty, tt=tt, C=C, pc=pc, ZC=ZC, YCL=YCL, wall=WN)
fig, ax = plt.subplots(figsize=(26, 10))
sc = ax.scatter(y_[mask], np.degrees(t_[mask]), c=np.clip(res[mask], -0.4, 0.4), s=0.3, cmap="seismic", vmin=-0.4, vmax=0.4)
plt.colorbar(sc); ax.grid(True, lw=0.3); ax.set_title("cavity residual (data rows)")
fig.tight_layout(); fig.savefig(W + r"\inner_res.png", dpi=60)
rin = evalr(ty, tt, C, y_, t_)
th_fit = r_out - rin
print("fitted wall: p5 %.2f p50 %.2f p95 %.2f; min over all rows %.2f" % (*np.percentile(th_fit[mask], [5, 50, 95]), th_fit.min()))
