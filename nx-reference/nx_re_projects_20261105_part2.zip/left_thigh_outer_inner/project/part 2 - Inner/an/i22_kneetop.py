"""Knee hub outside profile of the inner: top z per radius (sector phi -170..-10, away from the leg)."""
import numpy as np
from common import load
v, f = load()
r = np.hypot(v[:, 0], v[:, 1]); ph = np.degrees(np.arctan2(v[:, 1], v[:, 0]))
m = (ph > -170) & (ph < -10) & (v[:, 2] > 78)
rb = np.arange(9.0, 70.0, 0.25)
for a in rb:
    s = m & (r >= a) & (r < a + 0.25)
    if s.sum() > 30: print(f"r {a+0.125:6.2f}  zmax {np.percentile(v[s,2], 99.5):7.3f}")
# vertical faces: r of outermost per z for the hub cylinder and the boss wall
for zz in np.arange(78, 93, 0.5):
    s = (ph > -170) & (ph < -10) & (np.abs(v[:, 2] - zz) < 0.1)
    rr = r[s]
    print(f"z {zz:5.1f}: hub r max {np.percentile(rr[rr>55], 99.5) if (rr>55).sum()>10 else np.nan:7.3f}  boss wall r {np.percentile(rr[(rr>15)&(rr<25)], 99) if ((rr>15)&(rr<25)).sum()>10 else np.nan:7.3f}  bore r {np.percentile(rr[rr<12], 1) if (rr<12).sum()>10 else np.nan:7.3f}")
