"""Two-way deviation report scan <-> CAD with zones (INNER, LT-OUT-001 frame).
usage: i40_dev.py cad.stl tag [n_scan_samples]
scan->CAD: signed distance of full-res scan vertices to the CAD solid (+ = scan outside CAD = material missing in CAD).
CAD->scan: unsigned distance of CAD surface samples to the scan mesh.
Zones: knee hub (r < 70 about the knee axis), hip end (y > 262), outer skin (within 1 mm of the fitted skin model,
outside the hub), interior (the rest). Writes work/dev2_<tag>.json, work/dev2_<tag>_*.png."""
import sys, os, json
import numpy as np
import open3d as o3d
import pyvista as pv
from common import W, load
from i20lib import evalr

cad, tag = sys.argv[1], sys.argv[2]
N = int(sys.argv[3]) if len(sys.argv) > 3 else 1500000
cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices()
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
v, f = load()
DZ = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))["seat_dz"]
v = v.copy(); v[:, 2] += DZ      # the delivered CAD is lifted by seat_dz (stage J): the scan follows it
rng = np.random.default_rng(7)
idx = rng.choice(len(v), min(N, len(v)), replace=False)
P = v[idx].astype(np.float32)
d = sc.compute_signed_distance(o3d.core.Tensor(P)).numpy()
s = np.load(W + r"\skin_fit.npz"); pc, ZC = s["pc"], float(s["ZC"])
xc = np.polyval(pc, P[:, 1].astype(float))
th = np.arctan2(P[:, 2] - DZ - ZC, P[:, 0] - xc); rr = np.hypot(P[:, 0] - xc, P[:, 2] - DZ - ZC)
okth = (th > np.radians(-4)) & (th < np.radians(184))
rs = np.full(len(P), np.nan)
rs[okth] = evalr(s["ty"], s["tt"], s["C"], P[okth, 1].astype(float), th[okth])
de = np.abs(rr - rs)
knee = np.hypot(P[:, 0], P[:, 1]) < 70
hip = P[:, 1] > 262
outer = (~knee) & (~hip) & (de < 1.0)
inner = (~knee) & (~hip) & ~outer


def st(x):
    ax = np.abs(x)
    if len(x) == 0:
        return {}
    return dict(n=int(len(x)), mean=round(float(x.mean()), 4), rms=round(float(np.sqrt((x ** 2).mean())), 4),
                p50=round(float(np.percentile(ax, 50)), 4), p90=round(float(np.percentile(ax, 90)), 4),
                p95=round(float(np.percentile(ax, 95)), 4), p99=round(float(np.percentile(ax, 99)), 4),
                within_0p1=round(float((ax <= 0.1).mean()), 4), within_0p2=round(float((ax <= 0.2).mean()), 4),
                within_0p5=round(float((ax <= 0.5).mean()), 4), over_1=round(float((ax > 1).mean()), 4))


out = {"scan_to_cad": {"all": st(d), "knee_hub": st(d[knee]), "hip_end": st(d[hip]), "outer_skin": st(d[outer]), "interior": st(d[inner])}}
sm = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
ss = o3d.t.geometry.RaycastingScene(); ss.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(sm))
pcd = cm.sample_points_uniformly(600000)
Q = np.asarray(pcd.points, dtype=np.float32)
dq = ss.compute_distance(o3d.core.Tensor(Q)).numpy()
out["cad_to_scan"] = {"all": st(dq)}
print(json.dumps(out, indent=1))
json.dump(out, open(os.path.join(W, f"dev2_{tag}.json"), "w"), indent=1)
np.save(os.path.join(W, f"dev2_{tag}_cad2scan.npy"), np.c_[Q, dq])
np.save(os.path.join(W, f"dev2_{tag}_scan2cad.npy"), np.c_[P, d])
if "nomaps" in sys.argv:
    sys.exit(0)
m = pv.read(os.path.join(W, "scan_600k_framed.ply"))
m.points = np.asarray(m.points) + np.array([0.0, 0.0, DZ])
dd = sc.compute_signed_distance(o3d.core.Tensor(np.asarray(m.points, np.float32))).numpy()
m["dev"] = dd
c = np.array(m.center)
for vname, (dv, up) in {"top": ((0, 0, 1), (0, 1, 0)), "open": ((0, 0, -1), (0, 1, 0)), "iso": ((1, -1, 1), (0, 0, 1)),
                         "iso2": ((-1, 1, 1), (0, 0, 1)), "isob": ((1, -1, -1), (0, 0, -1)), "px": ((1, 0, 0.2), (0, 0, 1)),
                         "nx": ((-1, 0, 0.2), (0, 0, 1))}.items():
    p = pv.Plotter(off_screen=True, window_size=(1500, 1500))
    p.add_mesh(m, scalars="dev", cmap="coolwarm", clim=(-0.5, 0.5), show_scalar_bar=True,
               scalar_bar_args=dict(title="scan - CAD (mm), + = CAD missing material", fmt="%.2f"))
    p.camera_position = [tuple(c + np.array(dv, float) / np.linalg.norm(dv) * 720), tuple(c), up]
    p.camera.view_angle = 32
    p.screenshot(os.path.join(W, f"dev2_{tag}_{vname}.png")); p.close()
print("maps ok")
