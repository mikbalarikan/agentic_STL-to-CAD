"""Reconcile the CAD open-side height field with the scan, patch by patch (Rev A review fix, stage L).
usage: i96_reconcile.py tag [min_area=3]
Reads work/depth_<tag>.npz (i93_depth: zs scan z, zc CAD z, both lifted, 0.2 mm cells seen from -Z).
1. Planar patches of the scan: local 9x9 plane fit residual < RES, neighbours joined when their gradients agree;
   each patch gets one plane z = a x + b y + c (|grad| < 0.02 -> flat, level rounded to 0.05 in the analysis frame).
   Fillets, drafts, curved skin floors are not planar and give no patch.
2. For each patch where the CAD disagrees (|zc - f| > 0.3 on >= min_area):
   ADD  outline = cells near the patch where the scan surface is at or nearer than the plane (zs <= f + 0.5), limited to
        where the CAD is too deep (zc > f + 0.3, dilated 1 mm): material from the plane up (clipped to the envelope).
   CUT  outline = cells near the patch where the scan surface is at or deeper (zs >= f - 0.5), limited to where the CAD
        is too near (zc < f - 0.3, dilated 1 mm): material from z 30 up to the plane is removed.
   Joint band (plane below Z 37.5), boss / pin / hole areas are left alone (mating features, separate checks).
3. Simulation: zc after the tools, residual stats; outlines as line/arc loops (arcfit) -> work/reconcile_nx.json.
"""
import sys, os, json
import numpy as np
from scipy import ndimage
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
import contourpy
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
from arcfit import fit_loop, seg_points

tag = sys.argv[1]; AMIN = float(sys.argv[2]) if len(sys.argv) > 2 else 3.0
P = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))
DZ = P["seat_dz"]
d = np.load(W + rf"\depth_{tag}.npz"); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
zs, zc = d["zs"].copy(), d["zc"].copy()
ny, nx = zs.shape
xs = X0 + (np.arange(nx) + 0.5) * C; ys = Y0 + (np.arange(ny) + 0.5) * C
XX, YY = np.meshgrid(xs, ys)
RES, K, GROW, SMO = 0.05, 13, 2.0, 2.0

# ---- 1. local planes
ok = np.isfinite(zs)
_w = ndimage.gaussian_filter(ok.astype(float), SMO)
zsm = np.where(ok, ndimage.gaussian_filter(np.where(ok, zs, 0.0), SMO) / np.maximum(_w, 1e-9), np.nan)
z0 = np.where(ok, zsm, 0.0)
f = lambda a: ndimage.uniform_filter(a, K, mode="constant")      # noqa: E731
lx = (np.arange(nx) * C)[None, :] * np.ones((ny, 1)); ly = (np.arange(ny) * C)[:, None] * np.ones((1, nx))
n_ = f(ok.astype(float))
full = n_ > 0.999
mz, mx, my = f(z0), f(lx * ok), f(ly * ok)
cxz = f(lx * z0) - mx * mz; cyz = f(ly * z0) - my * mz
vx = f(lx * lx * ok) - mx * mx; vy = f(ly * ly * ok) - my * my; cxy = f(lx * ly * ok) - mx * my
vz = f(z0 * z0) - mz * mz
det = vx * vy - cxy * cxy
ga = np.where(full, (cxz * vy - cyz * cxy) / np.maximum(det, 1e-12), np.nan)
gb = np.where(full, (cyz * vx - cxz * cxy) / np.maximum(det, 1e-12), np.nan)
res = np.sqrt(np.maximum(vz - ga * cxz - gb * cyz, 0))
planar = full & (res < RES) & (np.hypot(ga, gb) < 1.2)
# joint graph
idx = np.arange(ny * nx).reshape(ny, nx)
rows, cols = [], []
for dy_, dx_ in ((0, 1), (1, 0)):
    a = planar[:ny - dy_, :nx - dx_] & planar[dy_:, dx_:]
    a &= np.abs(ga[:ny - dy_, :nx - dx_] - ga[dy_:, dx_:]) < 0.03
    a &= np.abs(gb[:ny - dy_, :nx - dx_] - gb[dy_:, dx_:]) < 0.03
    a &= np.abs(zsm[:ny - dy_, :nx - dx_] - zsm[dy_:, dx_:]) < 0.08
    rows.append(idx[:ny - dy_, :nx - dx_][a]); cols.append(idx[dy_:, dx_:][a])
rows = np.concatenate(rows); cols = np.concatenate(cols)
G = coo_matrix((np.ones(len(rows)), (rows, cols)), shape=(ny * nx, ny * nx))
ncomp, lab = connected_components(G, directed=False)
lab = lab.reshape(ny, nx); lab[~planar] = -1
cnt = np.bincount(lab[planar], minlength=ncomp)
big = np.where(cnt * C * C >= AMIN)[0]

# exclusion: mating / hole features
excl = np.zeros((ny, nx), bool)
for b in P["bosses"]:
    excl |= np.hypot(XX - b["x"], YY - b["y"]) < b["col_d"] / 2 + 1.0
for p in P["pins"]:
    excl |= np.hypot(XX - p["x"], YY - p["y"]) < p["lug_d"] / 2 + 0.6
excl |= np.hypot(XX, YY) < P["hub"]["bore_d"] / 2 + 1.5
kr = P["knee_ring_holes"]
for k in range(kr["n"]):
    a_ = np.radians(kr["clock"] + k * 360.0 / kr["n"])
    excl |= np.hypot(XX - kr["pcd"] / 2 * np.cos(a_), YY - kr["pcd"] / 2 * np.sin(a_)) < kr["d"] / 2 + 1.5
for h in P["channel_holes"]:
    excl |= np.hypot(XX - h["x"], YY - h["y"]) < h["d"] / 2 + 1.0

patches = []
zsim = zc.copy()
add_mask_all = np.zeros((ny, nx), bool); cut_mask_all = np.zeros((ny, nx), bool)
for k in big:
    m = lab == k
    yy_, xx_ = np.nonzero(m)
    X, Y, Z = XX[m], YY[m], zs[m]
    A = np.c_[X, Y, np.ones(len(X))]
    co, *_ = np.linalg.lstsq(A, Z, rcond=None)
    r = Z - A @ co
    if np.sqrt((r ** 2).mean()) > 0.07:
        continue
    ev = np.sort(np.linalg.eigvalsh(np.cov(np.c_[X, Y].T)))
    if 4 * np.sqrt(ev[0]) < 2.0:            # thin strips: fillet / draft bands, not a face
        continue
    flat = np.hypot(co[0], co[1]) < 0.02
    if flat:
        lev = round((float(np.median(Z)) - DZ) / 0.05) * 0.05 + DZ
        co = np.array([0.0, 0.0, lev])
    fz = lambda xx, yy: co[0] * xx + co[1] * yy + co[2]      # noqa: E731
    if fz(X, Y).mean() < 37.5:
        continue
    sl = ndimage.find_objects(m.astype(int))[0]
    pad = int(6.0 / C)
    s0 = slice(max(sl[0].start - pad, 0), min(sl[0].stop + pad, ny)); s1 = slice(max(sl[1].start - pad, 0), min(sl[1].stop + pad, nx))
    mm = m[s0, s1]; Zs, Zc, Ex = zs[s0, s1], zc[s0, s1], excl[s0, s1]
    Fz = fz(XX[s0, s1], YY[s0, s1])
    near = ndimage.binary_dilation(mm, iterations=int(5.0 / C))
    dm = Zc[mm] - Fz[mm]
    out_p = dict(id=int(k), flat=bool(flat), plane=[round(float(c_), 5) for c_ in co], area=round(float(m.sum() * C * C), 1),
                 ctr=[round(float(X.mean()), 1), round(float(Y.mean()), 1), round(float(fz(X.mean(), Y.mean())), 2)],
                 cad_med=round(float(np.nanmedian(dm)), 2) if np.isfinite(dm).any() else None)
    tools = {}
    for kind in ("add", "cut"):
        if kind == "add":
            need = (Zc > Fz + 0.3) | ~np.isfinite(Zc)
            body_ = np.isfinite(Zs) & (Zs <= Fz + 0.5)
        else:
            need = np.isfinite(Zc) & (Zc < Fz - 0.3)
            body_ = np.isfinite(Zs) & (Zs >= Fz - 0.5)
        need &= mm
        if need.sum() * C * C < AMIN or need.sum() < 0.4 * mm.sum():
            continue
        reg = body_ & near & ndimage.binary_dilation(need, iterations=int(GROW / C)) & ~Ex
        lb, nl = ndimage.label(reg)
        keep = np.unique(lb[need & reg]); keep = keep[keep > 0]
        reg = np.isin(lb, keep)
        reg = ndimage.binary_opening(reg, iterations=2)
        if reg.sum() * C * C < AMIN:
            continue
        tools[kind] = (s0, s1, reg)
        full_ = np.zeros((ny, nx), bool); full_[s0, s1] = reg
        if kind == "add":
            zsim[full_] = np.fmin(np.where(np.isfinite(zsim[full_]), zsim[full_], 1e9), Fz[reg]); add_mask_all |= full_
        else:
            zsim[full_] = np.fmax(zsim[full_], Fz[reg]); cut_mask_all |= full_
        out_p[kind + "_area"] = round(float(reg.sum() * C * C), 1)
    if tools:
        out_p["_tools"] = tools
        patches.append(out_p)

# ---- 3. outlines
def loops_of(s0, s1, reg):
    Gm = np.pad(np.where(reg, 0.5, -0.5), 2, constant_values=-0.5)
    Gm = ndimage.gaussian_filter(Gm, 0.7)
    out = []
    for Cn in contourpy.contour_generator(z=Gm, line_type="Separate").lines(0.0):
        if np.linalg.norm(Cn[0] - Cn[-1]) > 1e-6:
            continue
        Q = np.c_[X0 + (s1.start + Cn[:, 0] - 2 + 0.5) * C, Y0 + (s0.start + Cn[:, 1] - 2 + 0.5) * C][:-1]
        A_ = 0.5 * (np.dot(Q[:, 0], np.roll(Q[:, 1], -1)) - np.dot(Q[:, 1], np.roll(Q[:, 0], -1)))
        if abs(A_) < 1.0:
            continue
        segs = fit_loop(Q, tol=0.12)
        out.append(dict(area=float(A_), segs=[([s[0], s[1].tolist(), s[2].tolist()] if s[0] == "L" else
                                               [s[0], s[1].tolist(), s[2].tolist(), s[3].tolist(), float(s[4]), bool(s[5])]) for s in segs]))
    return out


from matplotlib.path import Path as MPath
nxout = []
for p_ in patches:
    for kind, (s0, s1, reg) in p_.pop("_tools").items():
        lps = loops_of(s0, s1, reg)
        polys = [np.vstack([seg_points((s[0], *[np.array(t) if isinstance(t, list) else t for t in s[1:]]), 8) for s in lp["segs"]]) for lp in lps]
        par = []
        for i in range(len(lps)):
            best = -1
            for j in range(len(lps)):
                if i != j and MPath(polys[j]).contains_points(polys[i][::3]).all():
                    if best < 0 or abs(lps[j]["area"]) < abs(lps[best]["area"]):
                        best = j
            par.append(best)
        groups = [dict(outer=lps[i]["segs"], holes=[lps[j]["segs"] for j in range(len(lps)) if par[j] == i], area=abs(lps[i]["area"]))
                  for i in range(len(lps)) if par[i] < 0]
        nxout.append(dict(patch=p_["id"], kind=kind, flat=p_["flat"], plane=p_["plane"], groups=groups, ctr=p_["ctr"],
                          area=p_.get(kind + "_area")))
json.dump(nxout, open(W + r"\reconcile_nx.json", "w"))
json.dump(patches, open(W + rf"\reconcile_{tag}.json", "w"), indent=0)
fin = np.isfinite(zs) & np.isfinite(zc)
for nm, zz in (("before", zc), ("after", zsim)):
    dd = (zz - zs)[fin & np.isfinite(zz)]
    print(f"{nm}: |diff|>0.3 {100 * (np.abs(dd) > 0.3).mean():.1f} %, missing>0.3 {100 * (dd > 0.3).mean():.1f} %, extra>0.3 {100 * (dd < -0.3).mean():.1f} %")
print("patches with tools", len(patches), "add", sum(1 for t in nxout if t["kind"] == "add"), "cut", sum(1 for t in nxout if t["kind"] == "cut"),
      "add area", round(sum(t["area"] for t in nxout if t["kind"] == "add")), "cut area", round(sum(t["area"] for t in nxout if t["kind"] == "cut")),
      "sloped", sum(1 for t in nxout if not t["flat"]))
for t in sorted(nxout, key=lambda t: -t["area"])[:80]:
    print(t["kind"], t["patch"], "flat" if t["flat"] else "slope", t["plane"], t["area"], t["ctr"], len(t["groups"]), [len(g["outer"]) for g in t["groups"]])
np.savez_compressed(W + rf"\reconcile_{tag}.npz", zsim=zsim, add=add_mask_all, cut=cut_mask_all)
tiles = {"knee": (-75, 125, -72, 75), "mid": (-75, 125, 65, 195), "hip": (-75, 125, 185, 292)}
for nm, (a0, a1, b0, b1) in tiles.items():
    i0, i1 = int((b0 - Y0) / C), int((b1 - Y0) / C); j0, j1 = int((a0 - X0) / C), int((a1 - X0) / C)
    fig, ax = plt.subplots(1, 2, figsize=(24, 12 * (b1 - b0) / (a1 - a0) + 1))
    for a, zz, ttl in ((ax[0], zc, "before"), (ax[1], zsim, "after (simulated)")):
        im = a.imshow(np.clip((zz - zs)[i0:i1, j0:j1], -3, 3), origin="lower", extent=[a0, a1, b0, b1], cmap="seismic", vmin=-3, vmax=3)
        a.set_title(f"{ttl}: CAD z - scan z, red = CAD missing", fontsize=10)
        a.contour(xs[j0:j1], ys[i0:i1], add_mask_all[i0:i1, j0:j1].astype(float), levels=[0.5], colors="g", linewidths=0.6)
        a.contour(xs[j0:j1], ys[i0:i1], cut_mask_all[i0:i1, j0:j1].astype(float), levels=[0.5], colors="m", linewidths=0.6)
        a.set_xticks(np.arange(a0, a1 + 1, 10)); a.set_yticks(np.arange(b0 - b0 % 10, b1 + 1, 10)); a.grid(lw=0.3, alpha=0.4); a.tick_params(labelsize=7)
    fig.tight_layout(); fig.savefig(W + rf"\diag\recon_{tag}_{nm}.png", dpi=50); plt.close(fig)
