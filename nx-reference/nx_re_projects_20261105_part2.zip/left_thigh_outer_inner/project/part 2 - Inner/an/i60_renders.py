"""Shaded renders of the inner CAD (and the inner + outer assembly), same look as the LT-OUT-001 renders.
usage: i60_renders.py inner.stl out_dir"""
import sys, os
import numpy as np
import pyvista as pv
from outer import OUTER_CAD_STL

stl, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
m = pv.read(stl)
mo = pv.read(OUTER_CAD_STL)
GREY, BLUE = "#9aa3ab", "#6f8fb0"


def shot(meshes, name, d, up, dist=1.0, size=(1800, 1400)):
    p = pv.Plotter(off_screen=True, window_size=size)
    p.set_background("white")
    for mesh, col in meshes:
        p.add_mesh(mesh, color=col, smooth_shading=True, specular=0.35, specular_power=20, ambient=0.18, diffuse=0.8)
    allp = np.vstack([np.asarray(mm.points) for mm, _ in meshes])
    c = 0.5 * (allp.min(0) + allp.max(0))
    R = np.linalg.norm(allp.max(0) - allp.min(0))
    d = np.array(d, float); d /= np.linalg.norm(d)
    p.camera_position = [tuple(c + d * R * 1.9 * dist), tuple(c), tuple(up)]
    p.camera.view_angle = 28
    p.enable_anti_aliasing("ssaa")
    p.screenshot(os.path.join(out, name)); p.close()


N = "LT-INN-001"
shot([(m, GREY)], f"{N}_iso_open_side.png", (1, -1, -1.3), (0, 0, -1))
shot([(m, GREY)], f"{N}_iso_open_side2.png", (-1, 1.2, -1.3), (0, 0, -1))
shot([(m, GREY)], f"{N}_iso_outside.png", (1, -1, 1.2), (0, 0, 1))
shot([(m, GREY)], f"{N}_side_px.png", (1, 0, 0.15), (0, 0, 1))
shot([(m, GREY)], f"{N}_hip_end.png", (0.25, 1, -0.5), (0, 0, 1))
shot([(m, GREY), (mo, BLUE)], f"{N}_assembly_with_LT-OUT-001.png", (1, -1, 0.9), (0, 0, 1))
shot([(m, GREY), (mo, BLUE)], f"{N}_assembly_with_LT-OUT-001_b.png", (-1, 0.8, 0.5), (0, 0, 1))
print("renders ok")
