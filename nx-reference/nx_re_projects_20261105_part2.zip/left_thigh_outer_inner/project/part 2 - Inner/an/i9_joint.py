"""Zoomed joint sections (inner orange, outer blue) at the rim, to read tongue/groove and the skin step."""
import numpy as np, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, section, W
from outer import load_outer
vi, fi = load(); vo, fo = load_outer()
cuts = [("y", 130, -22), ("y", 130, 101), ("y", 200, 115), ("y", 240, -45), ("y", 240, 118), ("y", -40, 70),
        ("x", 0, -67), ("y", 30, -62), ("y", 30, 84), ("y", 80, 88), ("x", 40, 286), ("x", -20, 284)]
fig, axs = plt.subplots(3, 4, figsize=(28, 21)); axs = axs.ravel()
for ax, (axn, val, h0) in zip(axs, cuts):
    ia = "xyz".index(axn); h = 1 if axn == "x" else 0
    for V, F, col in ((vo, fo, "tab:blue"), (vi, fi, "tab:orange")):
        s = section(V, F, ia, val)
        m = (np.abs(s[:, 0, h] - h0) < 9) & (np.abs(s[:, 0, 2] - 36) < 9)
        for seg in s[m]: ax.plot(seg[:, h], seg[:, 2], color=col, lw=1.0)
    for zz, cc in ((34.76, "k"), (35.95, "g"), (36.07, "r")): ax.axhline(zz, color=cc, lw=0.5, ls="--")
    ax.set_xlim(h0 - 9, h0 + 9); ax.set_ylim(27, 45); ax.set_aspect("equal"); ax.grid(lw=0.3)
    ax.set_title(f"{axn}={val} around {'yx'[axn=='y']}={h0}")
plt.tight_layout(); plt.savefig(W + r"\joint_zoom.png", dpi=50)
