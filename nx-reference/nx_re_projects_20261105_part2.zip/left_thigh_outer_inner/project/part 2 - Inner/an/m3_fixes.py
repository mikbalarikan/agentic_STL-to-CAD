"""Stage M fix list = nx/fixes_L.json with the B6 / B7 buttress start moved (F10 / F11 s0 229 -> 233) plus:
  M01  P3 pin-lug gusset rib, t 2.6, vertical plane with normal at 45.5 deg (mid c = p.n = 145.85), profile from the
       scan section in that plane (bottom edge Z 50.05, R2.8 corner, free end s -188.0 up into the wall)
  M01h Ø2.8 hole through that rib (scan: round hole, centre s -191.45, Z 54.6)
  M02* right window outline: cells (Y, Z) where the scan is open but the CAD has wall -> cut through along X
  M03* right window jambs: CAD inner face proud of the scan -> prism along X AND deeper than 2.3 under the skin
Measurements: work/stageM/p3_plane2.png (an/m1_planesec.py), s0 sweep work/stageM/s0opt.py, an/m2_rwin.py.
Writes nx/fixes_M.json (the NX build reads it with FIXES=fixes_M.json) and work/fixes_M_sim.json (same)."""
import os, json
import numpy as np
from fixlib import W, ROOT

fx = json.load(open(os.path.join(ROOT, "nx", "fixes_L.json")))
for f in fx:
    if f["id"] in ("F10", "F11"):
        f["s0"] = 233.0
        f["note"] += "; starts at Y 233 (stage M: the scan wall blends down into the buttress over Y 229-235)"
A = 45.5; a = np.radians(A); n = np.array([np.cos(a), np.sin(a)]); d = np.array([np.sin(a), -np.cos(a)])
CM, TH = 145.85, 2.6
arc = [(-190.8 + 2.8 * np.cos(t), 52.85 + 2.8 * np.sin(t)) for t in np.radians(np.arange(-90, 1, 15))]
prof = [(-196.5, 50.05)] + arc + [(-188.0, 69.0), (-196.5, 69.0)]
fx.append(dict(id="M01", kind="add", type="prism_v", a=A, c0=CM - TH / 2, c1=CM + TH / 2,
               loops=[[[round(float(s), 3), round(float(z), 3)] for s, z in prof]],
               note="P3 pin-lug gusset rib t 2.6 (plane normal 45.5 deg in XY), bottom edge Z 50.05, free end 7.4 from the lug",
               clusters=[22]))
s, z = -191.45, 54.6
o = s * d + (CM - 2.5) * n
fx.append(dict(id="M01h", kind="cut", type="cyl_axis", origin=[round(float(o[0]), 3), round(float(o[1]), 3), z],
               dir=[round(float(n[0]), 5), round(float(n[1]), 5), 0.0], d=2.8, h=5.0,
               note="Ø2.8 hole through the P3 gusset rib (scan), centre Z 54.6"))
rw = json.load(open(os.path.join(W, "stageM", "rwin_fixes.json")))
for f in rw:
    if "and_" in f:
        f["and"] = [dict(f.pop("and_"), kind="cut")]
    fx.append(f)
json.dump(fx, open(os.path.join(ROOT, "nx", "fixes_M.json"), "w"), indent=0)
json.dump(fx, open(os.path.join(W, "fixes_M_sim.json"), "w"), indent=0)
print(len(fx), "tools;", [f["id"] for f in fx if f["id"][0] == "M" or f["id"] in ("F10", "F11")])
