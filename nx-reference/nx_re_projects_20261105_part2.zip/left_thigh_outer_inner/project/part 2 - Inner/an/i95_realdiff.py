"""Open-side depth diff with root-fillet bands masked: cells within FR mm of a steep scan wall where the CAD misses
< 2 mm (a concave root fillet r <= ~4) are greyed. What stays coloured is a real height / outline error.
usage: i95_realdiff.py tag [FR=2.5]  -> work/diag/real_<tag>_{knee,mid,hip}.png, work/real_<tag>.npz (mask + labels)"""
import sys
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import ndimage
from common import W
tag = sys.argv[1]; FR = float(sys.argv[2]) if len(sys.argv) > 2 else 2.5
d = np.load(W + rf"\depth_{tag}.npz"); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
diff, zs, zc = d["diff"], d["zs"], d["zc"]
gy, gx = np.gradient(np.nan_to_num(zs, nan=200.0), C)
steep = np.hypot(gx, gy) > 1.5
gy, gx = np.gradient(np.nan_to_num(zc, nan=200.0), C)
steep |= np.hypot(gx, gy) > 1.5
dist = ndimage.distance_transform_edt(~steep) * C
fil = (dist < FR) & (diff > 0) & (diff < 2.0)
edge = dist < 0.6          # the walls themselves: the depth jumps there, a 0.2 mm cell shift is a big diff
real = np.isfinite(diff) & (np.abs(diff) > 0.3) & ~fil & ~edge
real = ndimage.binary_opening(real, iterations=2)
lab, n = ndimage.label(real)
ar = ndimage.sum(np.ones_like(diff), lab, index=np.arange(1, n + 1)) * C * C
keep = np.zeros(n + 1, bool); keep[1:] = ar >= 4.0
real = keep[lab]
lab, n = ndimage.label(real)
np.savez_compressed(W + rf"\real_{tag}.npz", real=real, lab=lab, fil=fil)
regs = []
for k, sl in enumerate(ndimage.find_objects(lab), 1):
    m = lab[sl] == k
    dd = diff[sl][m]
    yy, xx = np.nonzero(m)
    regs.append(dict(id=k, area=round(float(m.sum() * C * C), 1), mean=round(float(dd.mean()), 2),
                     x=round(float(X0 + (sl[1].start + xx.mean() + 0.5) * C), 1), y=round(float(Y0 + (sl[0].start + yy.mean() + 0.5) * C), 1),
                     zs=round(float(np.nanmedian(zs[sl][m])), 2), zc=round(float(np.nanmedian(zc[sl][m])), 2),
                     bb=[round(float(X0 + sl[1].start * C), 1), round(float(X0 + sl[1].stop * C), 1), round(float(Y0 + sl[0].start * C), 1), round(float(Y0 + sl[0].stop * C), 1)]))
regs.sort(key=lambda r: -r["area"] * abs(r["mean"]))
import json
json.dump(regs, open(W + rf"\real_{tag}.json", "w"), indent=0)
print("regions", n, "area", round(sum(r["area"] for r in regs)), "missing", round(sum(r["area"] for r in regs if r["mean"] > 0)), "extra", round(sum(r["area"] for r in regs if r["mean"] < 0)))
for r in regs[:70]:
    print(r)
show = np.where(real, np.clip(diff, -3, 3), np.nan)
tiles = {"knee": (-75, 125, -72, 75), "mid": (-75, 125, 65, 195), "hip": (-75, 125, 185, 292)}
for nm, (a0, a1, b0, b1) in tiles.items():
    i0, i1 = int((b0 - Y0) / C), int((b1 - Y0) / C); j0, j1 = int((a0 - X0) / C), int((a1 - X0) / C)
    fig, ax = plt.subplots(figsize=(16, 16 * (b1 - b0) / (a1 - a0) + 0.8))
    ax.imshow(np.where(np.isfinite(zs[i0:i1, j0:j1]), zs[i0:i1, j0:j1], np.nan), origin="lower", extent=[a0, a1, b0, b1], cmap="gray_r", vmin=30, vmax=115, alpha=0.5)
    im = ax.imshow(show[i0:i1, j0:j1], origin="lower", extent=[a0, a1, b0, b1], cmap="seismic", vmin=-3, vmax=3)
    for r in regs:
        if a0 <= r["x"] <= a1 and b0 <= r["y"] <= b1 and r["area"] >= 8:
            ax.text(r["x"], r["y"], str(r["id"]), fontsize=7, color="k", ha="center", va="center", weight="bold")
    plt.colorbar(im, ax=ax, shrink=0.6); ax.set_title(f"{tag}: real depth errors (fillet bands masked); red = CAD missing, blue = CAD extra", fontsize=10)
    ax.set_xticks(np.arange(a0, a1 + 1, 10)); ax.set_yticks(np.arange(b0 - b0 % 10, b1 + 1, 10)); ax.grid(lw=0.4, color="k", alpha=0.3); ax.tick_params(labelsize=7)
    fig.tight_layout(); fig.savefig(W + rf"\diag\real_{tag}_{nm}.png", dpi=60); plt.close(fig)
