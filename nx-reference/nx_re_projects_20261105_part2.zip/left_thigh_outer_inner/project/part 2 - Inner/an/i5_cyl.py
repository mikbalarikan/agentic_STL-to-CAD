"""Cylinder census around feature guesses: facets with horizontal normals that point radially (in or out),
histogram by radius; for each radius peak a robust circle fit (xy) + z-range. mode: inner | outer"""
import sys, numpy as np, json
from common import load, tri_data, fit_circle_robust, W
mode = sys.argv[1]
if mode == "inner":
    v, f = load(frame=False)
    Rr = np.load(W + r"\Rrim.npy"); v = (v - Rr[3]) @ Rr[:3].T
    F = {"B1": (-26.55, -142.1), "B2": (-41.6, -71.7), "B3": (60.14, -24.73), "B4": (-51.23, 63.94), "B5": (52.25, 63.74),
         "B6": (-62.55, 162.95), "B7": (57.43, 162.74), "P1": (-74.4, 92.3), "P2": (-38.5, 29.5), "P3": (74.7, 143.1)}
else:
    from outer import load_outer
    v, f = load_outer()
    P = json.load(open(r"..\nx\params_outer.json"))
    F = {f"B{i+1}": (b["x"], b["y"]) for i, b in enumerate(P["bosses"])}
    F.update({f"P{i+1}": (b["x"], b["y"]) for i, b in enumerate(P["pins"])})
c, n, a = tri_data(v, f)
res = {}
for k, c0 in F.items():
    d = np.hypot(c[:, 0] - c0[0], c[:, 1] - c0[1])
    m0 = (d < 13) & (np.abs(n[:, 2]) < 0.25)
    rd = np.c_[c[m0, 0] - c0[0], c[m0, 1] - c0[1]] / d[m0, None]
    nr = np.einsum("ij,ij->i", n[m0, :2], rd)
    m1 = np.abs(nr) > 0.9
    cc, dd, aa, sg = c[m0][m1], d[m0][m1], a[m0][m1], np.sign(nr[m1])
    h, e = np.histogram(dd, bins=np.arange(0, 13, 0.2), weights=aa)
    out = []
    used = np.zeros(len(h), bool)
    for i in np.argsort(h)[::-1]:
        if h[i] < 3 or used[max(0, i - 3):i + 4].any(): continue
        used[i] = True
        r0 = e[i] + 0.1
        mm = np.abs(dd - r0) < 0.5
        if mm.sum() < 40: continue
        cf, r, sd, kk = fit_circle_robust(cc[mm][:, :2])
        zz = cc[mm][kk, 2]
        out.append(dict(c=[round(cf[0], 3), round(cf[1], 3)], D=round(2 * r, 3), sd=round(sd, 3), n=int(kk.sum()),
                        z=[round(np.percentile(zz, 2), 2), round(np.percentile(zz, 98), 2)], side="hole" if np.median(sg[mm]) > 0 else "shaft",
                        area=round(float(h[i]), 1)))
    out.sort(key=lambda o: o["D"])
    res[k] = out
    print(k, c0)
    for o in out: print("   ", o)
json.dump(res, open(W + "\cyl_%s.json" % mode, "w"), indent=1)
