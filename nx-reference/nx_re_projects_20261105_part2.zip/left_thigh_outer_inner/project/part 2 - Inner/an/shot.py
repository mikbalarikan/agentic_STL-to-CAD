"""Close-up render of the framed decimated scan.
usage: shot.py out.png  cx cy cz  dx dy dz  [dist D] [up ux uy uz] [mesh path] [clip axis lo hi]"""
import sys, os, json
import numpy as np
import pyvista as pv
from common import W

a = sys.argv[1:]
out = a[0]
foc = np.array([float(t) for t in a[1:4]]); d = np.array([float(t) for t in a[4:7]]); d /= np.linalg.norm(d)
dist = float(a[a.index("dist") + 1]) if "dist" in a else 300.0
up = [float(t) for t in a[a.index("up") + 1:a.index("up") + 4]] if "up" in a else [0, 0, 1]
mpath = a[a.index("mesh") + 1] if "mesh" in a else os.path.join(W, "scan_600k_framed.ply")
if not os.path.exists(mpath):
    m = pv.read(os.path.join(W, "scan_600k.ply"))
    fr = json.load(open(os.path.join(W, "frame.json")))
    R = np.array(fr["R"]); o = np.array(fr["o"])
    m.points = (np.asarray(m.points) - o) @ R.T
    m.save(mpath)
mesh = pv.read(mpath)
if "clip" in a:
    i = a.index("clip"); ax = "xyz".index(a[i + 1]); lo, hi = float(a[i + 2]), float(a[i + 3])
    b = list(mesh.bounds); b[2 * ax] = lo; b[2 * ax + 1] = hi
    mesh = mesh.clip_box(b, invert=False)
p = pv.Plotter(off_screen=True, window_size=(1600, 1200))
p.add_mesh(mesh, color="#9ec9e8", smooth_shading=False, specular=0.4, ambient=0.25)
p.add_axes()
p.camera_position = [tuple(foc + d * dist), tuple(foc), tuple(up)]
p.camera.view_angle = 30
p.screenshot(out)
print("wrote", out)
