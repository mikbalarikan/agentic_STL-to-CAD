"""INNER outer-skin model r(y, th) about the OUTER centre line (xc(y), ZC=36) - upper half, th in [-4, 184] deg
(0 = +x side at the parting, 90 = straight up (+Z), 180 = -x side at the parting).
- data: outermost crossing of rays in y-sections (LT-OUT frame), masked to skin-only rows
- joint band (th < 1.5 or > 178.5): data replaced by the outer skin fit (part 1 work/skin_fit.npz) so the two skins
  meet flush at the parting (common design value: the delivered outer skin)
- pass 1 fine fit finds the styling seams (|res| > 0.12), dilated and excluded; pass 2 smooth fit; knee zone frozen.
Writes work/skin_raw.npz (ray data, reused with 'fit'), work/skin_fit.npz, work/skin_data.npz, work/skin_res.png."""
import sys
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.interpolate import BSpline
from scipy.ndimage import binary_dilation
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load, section, W

KY, KT, LAM = 8.0, 4.0, 3e-3
SEAM_T = 0.12
NEG = float(sys.argv[5]) if len(sys.argv) > 5 else -0.10   # rows with the scan this far INSIDE the fit are dropped
J0, J1 = 1.5, 178.5          # joint band limits (deg)
YF = -30.0
SO = np.load(r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\work\skin_fit.npz")
pc, ZC, YCL = SO["pc"], float(SO["ZC"]), float(SO["YCL"])
xcf = lambda y: np.polyval(pc, np.maximum(y, YCL))


def evalr(ty, tt, C, y, t):
    out = []
    for k in range(0, len(y), 4000):
        By = BSpline.design_matrix(np.clip(y[k:k + 4000], ty[3], ty[-4] - 1e-9), ty, 3)
        Bt = BSpline.design_matrix(np.clip(t[k:k + 4000], tt[3], tt[-4] - 1e-9), tt, 3).toarray()
        out.append(np.einsum("ij,ij->i", By @ C, Bt))
    return np.concatenate(out) if out else np.zeros(0)


if "fit" not in sys.argv:
    v, f = load()
    ys = np.arange(-72.0, 293.0, 1.0)
    th = np.radians(np.arange(-4.0, 184.01, 0.5))
    rows = []
    for y in ys:
        s = section(v, f, 1, y)
        if len(s) == 0: continue
        seg = s[:, :, [0, 2]]
        seg = seg[(seg[:, :, 1] > ZC - 1.5).all(1)]
        if len(seg) == 0: continue
        c = np.array([xcf(y), ZC]); a = seg[:, 0] - c; b = seg[:, 1] - c; e = b - a
        for t in th:
            d = np.array([np.cos(t), np.sin(t)])
            den = -d[0] * e[:, 1] + d[1] * e[:, 0]
            ok = np.abs(den) > 1e-12; den = np.where(ok, den, 1)
            r = (-a[:, 0] * e[:, 1] + a[:, 1] * e[:, 0]) / den
            u = (d[0] * a[:, 1] - d[1] * a[:, 0]) / den
            m = ok & (u >= 0) & (u <= 1) & (r > 0)
            if not m.any(): continue
            k = np.argmax(np.where(m, r, -1))
            en = np.array([-e[k, 1], e[k, 0]]); en /= np.linalg.norm(en)
            rows.append((y, t, r[k], abs(en @ d)))
    D = np.array(rows)
    np.savez(W + r"\skin_raw.npz", D=D)
D = np.load(W + r"\skin_raw.npz")["D"]
y_, t_, r_, inc = D.T.copy()
X = xcf(y_) + r_ * np.cos(t_); Z = ZC + r_ * np.sin(t_)
dk = np.hypot(X, y_); phk = np.degrees(np.arctan2(y_, X)); tdeg = np.degrees(t_)
mask = ~(dk < 69.5)
mask &= ~((dk < 75) & ((phk > 128) | (phk < -41)))
mask &= Z > 35.6
mask &= inc > 0.25
joint = (tdeg < J0) | (tdeg > J1)
mask &= ~joint
print("rows", len(D), "skin rows", mask.sum())
# joint rows from the outer skin model
tj = np.radians(np.r_[np.arange(-4.0, J0 + 0.01, 0.5), np.arange(J1, 184.01, 0.5)])
yj = np.arange(-72.0, 293.0, 1.0)
YJ, TJ = [a.ravel() for a in np.meshgrid(yj, tj, indexing="ij")]
TO = np.where(TJ > np.pi / 2, TJ - 2 * np.pi, TJ)
RJ = evalr(SO["ty"], SO["tt"], SO["C"], YJ, TO)
XJ = xcf(YJ) + RJ * np.cos(TJ)
dkj = np.hypot(XJ, YJ); phj = np.degrees(np.arctan2(YJ, XJ))
okj = ~(dkj < 69.5) & ~((dkj < 75) & ((phj > 128) | (phj < -41)))
YJ, TJ, RJ = YJ[okj], TJ[okj], RJ[okj]
y_ = np.r_[y_, YJ]; t_ = np.r_[t_, TJ]; r_ = np.r_[r_, RJ]; inc = np.r_[inc, np.ones(len(YJ))]
isj = np.r_[np.zeros(len(mask), bool), np.ones(len(YJ), bool)]
mask = np.r_[mask, np.zeros(len(YJ), bool)]
WJ = 2.0
print("joint rows from the outer skin", len(YJ))


def knots(lo, hi, h, k=3):
    n = max(1, int(round((hi - lo) / h)))
    return np.r_[[lo] * k, np.linspace(lo, hi, n + 1), [hi] * k]


def fit(m, wt, KY, KT, LAM):
    ty = knots(-75.0, 295.0, KY); tt = knots(np.radians(-5.0), np.radians(185.0), np.radians(KT))
    ny, nt = len(ty) - 4, len(tt) - 4
    yy, tth, rr, w = y_[m], t_[m], r_[m], (inc * wt)[m]
    By = BSpline.design_matrix(yy, ty, 3).tocsr(); Bt = BSpline.design_matrix(tth, tt, 3).tocsr()
    iy = By.indices.reshape(-1, 4); vy = By.data.reshape(-1, 4)
    it = Bt.indices.reshape(-1, 4); vt = Bt.data.reshape(-1, 4)
    cols = (iy[:, :, None] * nt + it[:, None, :]).reshape(len(yy), 16)
    vals = (vy[:, :, None] * vt[:, None, :]).reshape(len(yy), 16) * w[:, None]
    A = sp.csr_matrix((vals.ravel(), cols.ravel(), np.arange(0, 16 * len(yy) + 1, 16)), shape=(len(yy), ny * nt))
    d2 = lambda n: sp.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n))
    d1 = lambda n: sp.diags([1.0, -1.0], [0, 1], shape=(n - 1, n))
    P = sp.kron(d2(ny), sp.eye(nt)); Q = sp.kron(sp.eye(ny), d2(nt)); Xp = sp.kron(d1(ny), d1(nt))
    M = (A.T @ A + LAM * len(yy) / (ny * nt) * (P.T @ P + Q.T @ Q + 2 * Xp.T @ Xp)).tocsc()
    coef = spl.spsolve(M, A.T @ (rr * w))
    return ty, tt, coef.reshape(ny, nt)


WT = np.where(isj, WJ, 1.0)
KY = float(sys.argv[2]) if len(sys.argv) > 2 else KY
KT = float(sys.argv[3]) if len(sys.argv) > 3 else KT
LAM = float(sys.argv[4]) if len(sys.argv) > 4 else LAM
# knee zone: synthetic rows (profile at YF) only where y < YF has no data at that theta
tgrid = np.radians(np.arange(-4.0, 184.01, 1.0))
YS, TS = [a.ravel() for a in np.meshgrid(np.arange(-72.0, YF, 1.0), tgrid, indexing="ij")]
gy = np.round((y_ + 72)).astype(int); gt = np.round(np.degrees(t_) + 4).astype(int)
occ = np.zeros((400, 200), bool); occ[gy[mask], gt[mask]] = True
occ = binary_dilation(occ, structure=np.ones((5, 5), bool))
free = ~occ[np.round(YS + 72).astype(int), np.round(np.degrees(TS) + 4).astype(int)]
YS, TS = YS[free], TS[free]
# robust passes: drop rows the scan has INSIDE the fit (grooves, holes, notches), dilated +-1.5 mm / +-1 deg,
# and positive spikes; keep raised seam lips / panels in the fit
use = mask.copy()
for it in range(4):
    if it == 1:   # add the knee-zone synthetic rows once a first fit exists
        RS = evalr(ty, tt, C, np.full(len(TS), YF), TS)
        y_ = np.r_[y_, YS]; t_ = np.r_[t_, TS]; r_ = np.r_[r_, RS]; inc = np.r_[inc, np.ones(len(YS))]
        n_add = len(YS)
        mask = np.r_[mask, np.zeros(n_add, bool)]; use = np.r_[use, np.zeros(n_add, bool)]
        isj = np.r_[isj, np.zeros(n_add, bool)]; WT = np.r_[WT, np.full(n_add, 0.5)]
        syn = np.r_[np.zeros(len(y_) - n_add, bool), np.ones(n_add, bool)]
    else:
        syn = np.zeros(len(y_), bool) if it == 0 else syn
    ty, tt, C = fit(use | isj | syn, WT, KY, KT, LAM) if it > 0 else fit(use | isj, WT, KY, KT, LAM)
    res = np.full(len(y_), np.nan)
    res[mask] = (r_[mask] - evalr(ty, tt, C, y_[mask], t_[mask])) * inc[mask]
    gy = np.round(y_ + 72).astype(int); gt = np.round((np.degrees(t_) + 4) / 0.5).astype(int)
    G = np.zeros((gy.max() + 1, gt.max() + 1), bool)
    neg = mask & (res < NEG)
    G[gy[neg], gt[neg]] = True
    G = binary_dilation(G, structure=np.ones((3, 5), bool))
    seam = mask & G[gy, gt]
    use = mask & ~seam & ~(res > 0.8)
    q = np.abs(res[use])
    print(f"it {it} KY {KY} KT {KT} lam {LAM}: used {use.sum()}/{mask.sum()}  |res| used p50 {np.percentile(q,50):.3f} p95 {np.percentile(q,95):.3f} p99 {np.percentile(q,99):.3f}")
res2 = res
qa = np.abs(res2[mask])
rj = r_[isj] - evalr(ty, tt, C, y_[isj], t_[isj])
print(f"all skin rows |res| p50 {np.percentile(qa,50):.3f} p90 {np.percentile(qa,90):.3f} p95 {np.percentile(qa,95):.3f}; "
      f"joint rows vs outer skin |d| p50 {np.percentile(abs(rj),50):.3f} p95 {np.percentile(abs(rj),95):.3f} max {abs(rj).max():.3f}")
np.savez(W + r"\skin_fit.npz", YCL=YCL, ty=ty, tt=tt, C=C, pc=pc, ZC=ZC, KY=KY, KT=KT, LAM=LAM)
np.savez(W + r"\skin_data.npz", y=y_, t=t_, r=r_, inc=inc, mask=mask, seam=seam, isj=isj, res=res2)
fig, ax = plt.subplots(1, 2, figsize=(26, 10))
for k, (sel, ttl) in enumerate(((mask, "residual, all skin rows (+ = scan outside)"), (mask & ~seam, "residual, seams excluded"))):
    sc = ax[k].scatter(y_[sel], np.degrees(t_[sel]), c=np.clip(res2[sel], -0.4, 0.4), s=0.3, cmap="seismic", vmin=-0.4, vmax=0.4)
    plt.colorbar(sc, ax=ax[k]); ax[k].set_title(ttl); ax[k].grid(True, lw=0.3); ax[k].set_xlabel("y"); ax[k].set_ylabel("theta deg")
fig.tight_layout(); fig.savefig(W + r"\skin_res.png", dpi=60)
