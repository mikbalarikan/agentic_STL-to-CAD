"""Stage M: right side window (scan wall 2.3 thick round the window, CAD jambs proud, window outline short).
Rays along +X from X0 over a (y, z) grid: first scan hit xs, first CAD hit xc (both lifted / final frame).
  open  = scan has no wall on the ray but the CAD has  -> window outline cut (prism along X, everything in X0..X1)
  proud = CAD inner face nearer than the scan's by > THR -> jamb cut = prism along X  AND  deeper than T from the skin
usage: m2_rwin.py cad.stl out_prefix [T=2.3]
Writes <out>_masks.png, <out>_fixes.json (prism_x tools; the jamb tools carry and=[skin_deep]) ."""
import sys, os, json
import numpy as np
import open3d as o3d
from scipy import ndimage
import contourpy
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from fixlib import scan, fit_segs

cad, out = sys.argv[1], sys.argv[2]
T = float(sys.argv[3]) if len(sys.argv) > 3 else 2.3
X0, X1 = 95.5, 116.0
Y0, Y1, Z0, Z1 = 133.5, 192.5, 37.6, 72.0       # P1 lug gusset ends Y 132.7, P2 gusset starts Y 193.25; mating faces below Z 37.5
C, THR = 0.25, 0.3


def scene(v, f):
    s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(np.asarray(v, np.float32)), o3d.core.Tensor(np.asarray(f, np.uint32)))
    return s


ys = np.arange(Y0, Y1, C) + C / 2; zs = np.arange(Z0, Z1, C) + C / 2
YY, ZZ = np.meshgrid(ys, zs)
R = np.c_[np.full(YY.size, X0), YY.ravel(), ZZ.ravel(), np.ones(YY.size), np.zeros(YY.size), np.zeros(YY.size)].astype(np.float32)
v, f = scan()
xs = scene(v, f).cast_rays(o3d.core.Tensor(R))["t_hit"].numpy().reshape(YY.shape) + X0
cm = o3d.io.read_triangle_mesh(cad)
xc = scene(np.asarray(cm.vertices), np.asarray(cm.triangles)).cast_rays(o3d.core.Tensor(R))["t_hit"].numpy().reshape(YY.shape) + X0
sh, ch = xs < X1, xc < X1
M_open = ~sh & ch
M_proud = sh & ch & (xc < xs - THR) & ~((ZZ > 66.6) & (YY > 156) & (YY < 176))   # not the rib-top junction above the window (Y 160-172, Z 67-72)


def clean(M, it=2, amin=4.0):
    M = ndimage.binary_opening(M, iterations=it)
    lb, n = ndimage.label(M)
    for k in range(1, n + 1):
        if (lb == k).sum() * C * C < amin:
            M[lb == k] = False
    return M


M_open = clean(M_open, 2, 6.0)
M_proud = clean(M_proud, 2, 6.0)


def loops(M, grow=0.0):
    if grow:
        M = ndimage.binary_dilation(M, iterations=int(round(grow / C)))
    G = ndimage.gaussian_filter(np.pad(M.astype(float), 2), 0.7)
    res = []
    for L in contourpy.contour_generator(z=G, line_type="Separate").lines(0.5):
        if np.linalg.norm(L[0] - L[-1]) > 1e-6:
            continue
        Q = np.c_[Y0 + (L[:, 0] - 2 + 0.5) * C, Z0 + (L[:, 1] - 2 + 0.5) * C][:-1]
        A = 0.5 * abs(np.dot(Q[:, 0], np.roll(Q[:, 1], -1)) - np.dot(Q[:, 1], np.roll(Q[:, 0], -1)))
        if A > 4.0:
            res.append((A, Q))
    return res


fx = []
for k, (A, Q) in enumerate(sorted(loops(M_open, 0.5), key=lambda t: -t[0])):
    fx.append(dict(id=f"M02{'abcdefgh'[k]}", kind="cut", type="prism_x", s0=X0, s1=X1, loops=[np.round(Q[::2], 2).tolist()],
                   note=f"right window outline: scan open, CAD wall ({A:.0f} mm2 in YZ)"))
for k, (A, Q) in enumerate(sorted(loops(M_proud, 1.0), key=lambda t: -t[0])):
    fx.append(dict(id=f"M03{'abcdefgh'[k]}", kind="cut", type="prism_x", s0=X0, s1=X1, loops=[np.round(Q[::2], 2).tolist()],
                   and_=dict(type="skin_deep", depth=T, box=[X0, X1, Y0, Y1, Z0, Z1]),
                   note=f"right window jamb: CAD inner face proud of the scan, cut to {T} from the outer skin ({A:.0f} mm2 in YZ)"))
json.dump(fx, open(out + "_fixes.json", "w"), indent=0)
fig, ax = plt.subplots(1, 3, figsize=(24, 9))
for a, (M, t) in zip(ax, ((np.where(ch & sh, xs - xc, np.nan), "xs - xc (mm), +: CAD proud"), (M_open, "open (scan none, CAD wall)"), (M_proud, "proud > 0.3"))):
    im = a.imshow(M.astype(float), origin="lower", extent=[Y0, Y1, Z0, Z1], cmap="RdBu_r" if M.dtype != bool else "gray_r",
                  vmin=-3 if M.dtype != bool else 0, vmax=3 if M.dtype != bool else 1)
    a.set_title(t); a.set_xlabel("y"); a.set_ylabel("z")
    for g in fx:
        q = np.asarray(g["loops"][0]); a.plot(np.r_[q[:, 0], q[0, 0]], np.r_[q[:, 1], q[0, 1]], "g-" if g["id"][:3] == "M02" else "m-", lw=1)
fig.colorbar(im, ax=ax[0]); fig.tight_layout(); fig.savefig(out + "_masks.png", dpi=60)
print("open cells mm2", M_open.sum() * C * C, "proud mm2", M_proud.sum() * C * C)
print([(g["id"], len(g["loops"][0])) for g in fx])
