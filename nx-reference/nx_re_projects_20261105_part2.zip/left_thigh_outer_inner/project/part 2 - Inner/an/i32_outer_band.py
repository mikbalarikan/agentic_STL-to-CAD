"""Clearance footprint of the delivered OUTER in the joint band: cells where the outer CAD rises above Z 35.10
(rim excluded), dilated by 0.20 mm, as NX loops. Used by build stage K (cut up to Z 36.07 after the lift)."""
import json, numpy as np, open3d as o3d
from scipy import ndimage
from common import W
from outer import OUTER_CAD_STL
from masklib import mask_loops, group_loops
X0, X1, Y0, Y1, C = -100.0, 125.0, -72.0, 292.0, 0.1
nx_, ny_ = int((X1 - X0) / C), int((Y1 - Y0) / C)
mo = o3d.io.read_triangle_mesh(OUTER_CAD_STL)
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mo))
xs = X0 + (np.arange(nx_) + 0.5) * C; ys = Y0 + (np.arange(ny_) + 0.5) * C
XX, YY = np.meshgrid(xs, ys)
# top of the outer below Z 37 (rays from Z 37 downwards: nubs / pins / ring above are not the band)
rays = np.zeros((nx_ * ny_, 6), np.float32); rays[:, 0] = XX.ravel(); rays[:, 1] = YY.ravel(); rays[:, 2] = 37.0; rays[:, 5] = -1.0
t = sc.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
O = np.where(np.isfinite(t), 37.0 - t, -np.inf).reshape(ny_, nx_)
T = O > 35.10
D = ndimage.distance_transform_edt(~T) * C
M = D <= 0.20
loops = mask_loops(M, X0, Y0, C, min_area=0.3, sigma=1.0, tol=0.03)
groups = group_loops(loops)
json.dump(dict(dilation=0.20, z_from=35.10, groups=groups), open(W + r"\outer_band_nx.json", "w"))
print("cells", int(T.sum()), "area", round(T.sum() * C * C), "groups", len(groups), "holes", sum(len(g["holes"]) for g in groups),
      [round(g["area"]) for g in groups])
print("strip check (-40, 258):", round(float(O[int((258 - Y0) / C), int((-40 - X0) / C)]), 3), "(-23.5, 155):", round(float(O[int((155 - Y0) / C), int((-23.5 - X0) / C)]), 3))
