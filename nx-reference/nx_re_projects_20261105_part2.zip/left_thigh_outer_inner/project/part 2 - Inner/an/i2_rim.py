"""Inner: fit the rim (parting) plane = highest broad +Z-facing level; print level histogram rel. to it."""
import numpy as np, json
from common import load, tri_data, fit_plane_robust, W
v, f = load(frame=False)
c, n, a = tri_data(v, f)
m = (n[:, 2] > 0.99) & (c[:, 2] > 33) & (c[:, 2] < 38)
cc, nn, sd, k = fit_plane_robust(c[m])
if nn[2] < 0: nn = -nn
print("seed n", nn, "sd", sd, m.sum())
for it in range(4):
    d = (c - cc) @ nn
    m2 = (n @ nn > np.cos(np.radians(2))) & (np.abs(d) < 0.5)
    cc, nn, sd, keep = fit_plane_robust(c[m2])
    if nn[2] < 0: nn = -nn
    print(it, nn, "sd", sd, "n", m2.sum(), "area", a[m2].sum())
d = (c - cc) @ nn
for sgn in (1, -1):
    mm = (n @ nn) * sgn > 0.995
    h, e = np.histogram(d[mm], bins=np.arange(-90, 10, 0.2), weights=a[mm])
    print("facing", sgn)
    for i in np.where(h > 25)[0]:
        print(f"   {e[i]+0.1:8.2f} {h[i]:7.0f}")
json.dump(dict(c=cc.tolist(), n=nn.tolist(), sd=sd), open(W + r"\parting_raw.json", "w"))
