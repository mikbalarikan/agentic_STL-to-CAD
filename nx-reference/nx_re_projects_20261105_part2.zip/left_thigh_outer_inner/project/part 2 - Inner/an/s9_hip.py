"""Hip ring: radial profile about the hip axis (|| Y). Histogram of facets by (y, r) for normals perp to Y,
and by (r) for faces normal to Y. Then circle fits per radial band."""
import numpy as np
from common import load, tri_data, fit_circle_robust
v, f = load()
c, n, a = tri_data(v, f)
C0 = np.array([38.59, 35.5])
sel = (c[:, 1] > 250) & (c[:, 1] < 300)
cc, nn, aa = c[sel], n[sel], a[sel]
r = np.hypot(cc[:, 0] - C0[0], cc[:, 2] - C0[1])
# radial surfaces (normal perp to Y and radial)
rad = np.abs(nn[:, 1]) < 0.1
radial_dir = np.c_[(cc[:, 0] - C0[0]) / r, (cc[:, 2] - C0[1]) / r]
nr = nn[:, 0] * radial_dir[:, 0] + nn[:, 2] * radial_dir[:, 1]
cyl = rad & (np.abs(nr) > 0.98) & (r < 60)
h, e = np.histogram(r[cyl], bins=np.arange(30, 60, 0.25), weights=aa[cyl])
print("cylindrical faces about hip axis: r bins with area > 20")
for i in np.where(h > 20)[0]:
    m = cyl & (np.abs(r - e[i] - 0.125) < 0.125)
    print(f"  r {e[i]+0.125:6.2f} area {h[i]:6.0f}  y {cc[m,1].min():7.2f}..{cc[m,1].max():7.2f}  in/out {np.sign(np.median(nr[m])):+.0f}")
# planar faces normal to Y
pl = np.abs(nn[:, 1]) > 0.995
h, e = np.histogram(cc[pl, 1], bins=np.arange(250, 300, 0.1), weights=aa[pl])
print("faces normal to Y")
for i in np.where(h > 15)[0]:
    m = pl & (np.abs(cc[:, 1] - e[i] - 0.05) < 0.05)
    print(f"  y {e[i]+0.05:7.2f} area {h[i]:6.0f}  r {r[m].min():6.1f}..{r[m].max():6.1f}  dir {np.sign(np.median(nn[m,1])):+.0f}")
