"""Quick look at a build STL: 4 views, optional sections vs the scan.  usage: i61_look.py cad.stl tag"""
import sys, numpy as np, pyvista as pv, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load, section, W
import trimesh
stl, tag = sys.argv[1], sys.argv[2]
m = pv.read(stl)
imgs = []
for k, (d, up) in {"open": ((0.6, -0.5, -1), (0, 0, -1)), "open2": ((-0.6, 0.6, -1), (0, 0, -1)), "out": ((0.6, -0.5, 1), (0, 0, 1)), "hip": ((0.2, 1, -0.6), (0, 0, 1))}.items():
    p = pv.Plotter(off_screen=True, window_size=(1200, 900)); p.set_background("white")
    p.add_mesh(m, color="#a8b0b8", smooth_shading=True, specular=0.3)
    c = np.array(m.center); R = 420
    d = np.array(d, float); d /= np.linalg.norm(d)
    p.camera_position = [tuple(c + d * R), tuple(c), up]; p.camera.view_angle = 40
    fn = W + rf"\look_{tag}_{k}.png"; p.screenshot(fn); p.close(); imgs.append(fn)
from PIL import Image
I = [Image.open(f) for f in imgs]; G = Image.new("RGB", (2400, 1800), "white")
for i, im in enumerate(I): G.paste(im, ((i % 2) * 1200, (i // 2) * 900))
G.save(W + rf"\look_{tag}.png")
if "sec" in sys.argv:
    vi, fi = load(); tm = trimesh.load(stl); vc, fc = np.asarray(tm.vertices), np.asarray(tm.faces)
    cuts = [("y", 271.5), ("y", 262), ("y", 200), ("y", 130), ("y", 60), ("y", 0), ("x", 37.97), ("x", 0)]
    fig, axs = plt.subplots(2, 4, figsize=(36, 16)); axs = axs.ravel()
    for ax, (axn, val) in zip(axs, cuts):
        ia = "xyz".index(axn); h = 1 if axn == "x" else 0
        for V, F, col, lw in ((vi, fi, "tab:orange", 0.6), (vc, fc, "k", 0.8)):
            for seg in section(V, F, ia, val): ax.plot(seg[:, h], seg[:, 2], color=col, lw=lw)
        ax.set_aspect("equal"); ax.grid(lw=0.3); ax.set_title(f"{axn}={val}  (black CAD, orange scan)")
    plt.tight_layout(); plt.savefig(W + rf"\look_{tag}_sec.png", dpi=40)
