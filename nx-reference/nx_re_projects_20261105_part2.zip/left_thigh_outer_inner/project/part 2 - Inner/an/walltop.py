import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
d = np.load(W + r"\hmap2.npz"); H = d["H"]; X0, X1, Y0, Y1 = d["ext"]
m = np.load(W + r"\masks.npz"); wall = m["wall30"]
Hn = np.where(np.isinf(H), np.nan, H)
show = np.where(wall & ~np.isnan(Hn), Hn, np.nan)
fig, ax = plt.subplots(figsize=(16, 26))
im = ax.imshow(show, origin="lower", extent=[X0, X1, Y0, Y1], cmap="jet", vmin=-10, vmax=40, interpolation="nearest")
plt.colorbar(im, ax=ax, shrink=0.4)
ax.imshow(np.where(np.isnan(Hn), np.nan, 0.0), origin="lower", extent=[X0, X1, Y0, Y1], cmap="gray", alpha=0.08)
ax.set_xticks(np.arange(-100, 126, 10)); ax.set_yticks(np.arange(-70, 292, 10)); ax.grid(True, lw=0.3)
fig.tight_layout(); fig.savefig(W + r"\walltop.png", dpi=60)
