"""Top-down height map (max z per xy cell) and bottom (min z) of the framed scan, with grid."""
import numpy as np, matplotlib, sys
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load, W
v, f = load()
cell = 0.4
x0, x1, y0, y1 = -105, 95, -210, 155
nx_, ny_ = int((x1 - x0) / cell), int((y1 - y0) / cell)
ix = ((v[:, 0] - x0) / cell).astype(int); iy = ((v[:, 1] - y0) / cell).astype(int)
ok = (ix >= 0) & (ix < nx_) & (iy >= 0) & (iy < ny_)
zmax = np.full((ny_, nx_), np.nan); zmin = np.full((ny_, nx_), np.nan)
lin = iy[ok] * nx_ + ix[ok]
zz = v[ok, 2]
a = np.full(nx_ * ny_, -np.inf); np.maximum.at(a, lin, np.minimum(zz, 37.5)); a[np.isinf(a)] = np.nan
b = np.full(nx_ * ny_, np.inf); np.minimum.at(b, lin, zz); b[np.isinf(b)] = np.nan
zmax = a.reshape(ny_, nx_); zmin = b.reshape(ny_, nx_)
np.savez(W + r"\hmap.npz", zmax=zmax, zmin=zmin, ext=[x0, x1, y0, y1], cell=cell)
for nm, arr, lims in (("top", zmax, (-42, 37)), ("bot", zmin, (-42, 0))):
    fig, ax = plt.subplots(figsize=(14, 24))
    im = ax.imshow(arr, origin="lower", extent=[x0, x1, y0, y1], cmap="nipy_spectral", vmin=lims[0], vmax=lims[1], interpolation="nearest")
    ax.set_xticks(np.arange(-100, 96, 10)); ax.set_yticks(np.arange(-210, 156, 10)); ax.grid(True, lw=0.3, color="w")
    plt.colorbar(im, ax=ax, shrink=0.5); fig.tight_layout(); fig.savefig(W + rf"\hmap_{nm}.png", dpi=70)
