"""Circle fits in plane sections. usage: cfit.py AXIS c1 c2 VAL[,VAL..] R0[,R0..] [w W] [ang a0 a1]
2D coords = remaining axes in order (x->(y,z), y->(x,z), z->(x,y)). Band fit around R0."""
import sys, numpy as np
from common import load, section, fit_circle_robust
a = sys.argv[1:]
axn = "xyz".index(a[0]); c0 = np.array([float(a[1]), float(a[2])])
vals = [float(t) for t in a[3].split(",")]; r0s = [float(t) for t in a[4].split(",")]
w = float(a[a.index("w") + 1]) if "w" in a else 1.0
ang = [float(t) for t in a[a.index("ang") + 1:a.index("ang") + 3]] if "ang" in a else None
v, f = load()
oth = [k for k in range(3) if k != axn]
for val in vals:
    p = section(v, f, axn, val).reshape(-1, 3)[:, oth]
    for r0 in r0s:
        c = c0.copy(); r = r0; ww = w
        for it in range(8):
            d = np.hypot(p[:, 0] - c[0], p[:, 1] - c[1])
            m = np.abs(d - r) < ww
            if ang is not None:
                ph = np.degrees(np.arctan2(p[:, 1] - c[1], p[:, 0] - c[0]))
                m &= (ph > ang[0]) & (ph < ang[1])
            if m.sum() < 10: break
            c, r, sd, k = fit_circle_robust(p[m])
            ww = max(0.25, min(ww, 5 * sd + 0.1))
        ph = np.degrees(np.arctan2(p[m, 1] - c[1], p[m, 0] - c[0]))
        cov = len(np.unique(np.round(ph / 5))) * 5
        print(f"{a[0]}={val:8.3f} R0={r0:6.2f}: centre ({c[0]:9.4f},{c[1]:9.4f}) R={r:8.4f} D={2*r:8.4f} sd={sd:.4f} n={m.sum()} cover~{cov}deg")
