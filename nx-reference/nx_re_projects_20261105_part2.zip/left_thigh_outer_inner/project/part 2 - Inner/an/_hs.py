import numpy as np, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load, section, W
vi, fi = load(); tm = trimesh.load(r"..\nx\tmpF\fin\LT-INN-001_Left_Thigh_Inner.stl"); vc, fc = np.asarray(tm.vertices), np.asarray(tm.faces)
cuts = [("x", 0), ("x", 10), ("x", 64), ("x", 100), ("x", -28), ("y", 250), ("y", 258), ("y", 264), ("y", 268), ("y", 110), ("x", 60), ("x", 38)]
fig, axs = plt.subplots(3, 4, figsize=(36, 24)); axs = axs.ravel()
for ax, (axn, val) in zip(axs, cuts):
    ia = "xyz".index(axn); h = 1 if axn == "x" else 0
    for V, F, col, lw in ((vi, fi, "tab:orange", 0.7), (vc, fc, "k", 0.9)):
        s = section(V, F, ia, val)
        if axn == "x" and val not in (60, 38): s = s[s[:, 0, 1] > 215]
        if axn == "x" and val == 60: s = s[(s[:, 0, 1] > 60) & (s[:, 0, 1] < 150)]
        for seg in s: ax.plot(seg[:, h], seg[:, 2], color=col, lw=lw)
    ax.set_aspect("equal"); ax.grid(lw=0.3); ax.set_title(f"{axn}={val} (black CAD F, orange scan)")
plt.tight_layout(); plt.savefig(W + r"\hipend_secs.png", dpi=38)
