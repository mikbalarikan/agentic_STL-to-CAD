"""Signed deviation scan -> CAD (+ = scan outside the CAD solid), coloured renders + stats.
usage: dev.py cad.stl tag [lim L] [views v1,v2,..] [full N]
Uses the decimated framed scan for maps; 'full N' samples N vertices of the full-res scan for stats."""
import sys, os, json
import numpy as np
import open3d as o3d
import pyvista as pv
from common import W, load

a = sys.argv[1:]
cad, tag = a[0], a[1]
L = float(a[a.index("lim") + 1]) if "lim" in a else 0.5
views = a[a.index("views") + 1].split(",") if "views" in a else ["bot", "top", "px", "nx", "iso"]
cm = o3d.io.read_triangle_mesh(cad)
cm.remove_duplicated_vertices()
scene = o3d.t.geometry.RaycastingScene()
scene.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
print("cad watertight", cm.is_watertight(), "tris", len(cm.triangles))

mp = os.path.join(W, "scan_600k_framed.ply")
m = pv.read(mp)
P = np.asarray(m.points, dtype=np.float32)
d = scene.compute_signed_distance(o3d.core.Tensor(P)).numpy()
m["dev"] = d
stats = {}
def st(x):
    ax = np.abs(x)
    return dict(n=int(len(x)), rms=float(np.sqrt(np.mean(x ** 2))), mean=float(x.mean()), p50=float(np.percentile(ax, 50)),
                p90=float(np.percentile(ax, 90)), p95=float(np.percentile(ax, 95)), p99=float(np.percentile(ax, 99)),
                over_0p2=float((ax > 0.2).mean()), over_0p5=float((ax > 0.5).mean()), over_1=float((ax > 1).mean()))
stats["dec_all"] = st(d)
if "full" in a:
    N = int(a[a.index("full") + 1])
    v, f = load()
    idx = np.random.default_rng(1).choice(len(v), min(N, len(v)), replace=False)
    df = scene.compute_signed_distance(o3d.core.Tensor(v[idx].astype(np.float32))).numpy()
    stats["full_sample"] = st(df)
    np.save(os.path.join(W, f"devfull_{tag}.npy"), np.c_[v[idx], df])
print(json.dumps(stats, indent=1))
json.dump(stats, open(os.path.join(W, f"dev_{tag}.json"), "w"), indent=1)
cams = {"bot": ((0, 0, -1), (0, 1, 0)), "top": ((0, 0, 1), (0, 1, 0)), "px": ((1, 0, 0), (0, 0, 1)), "nx": ((-1, 0, 0), (0, 0, 1)),
        "iso": ((1, -1, -1), (0, 0, 1)), "iso2": ((-1, 1, 1), (0, 0, 1)), "py": ((0, 1, 0), (0, 0, 1)), "ny": ((0, -1, 0), (0, 0, 1)),
        "isot": ((1, -1, 1), (0, 0, 1))}
c = np.array(m.center)
for vname in views:
    dvec, up = cams[vname]
    p = pv.Plotter(off_screen=True, window_size=(1400, 1400))
    p.add_mesh(m, scalars="dev", cmap="seismic", clim=(-L, L), smooth_shading=False, show_scalar_bar=True,
               scalar_bar_args=dict(title=f"scan-CAD mm ({tag})"))
    p.camera_position = [tuple(c + np.array(dvec, float) / np.linalg.norm(dvec) * 700), tuple(c), up]
    p.camera.view_angle = 32
    p.screenshot(os.path.join(W, f"dev_{tag}_{vname}.png"))
    p.close()
print("ok")
