"""Load the big binary STL once, weld vertices, cache as npz; print a description."""
import sys, os, time, json
import numpy as np

SRC = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\share-Left Thigh - Inner.stl"
OUT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\work"

t = time.time()
with open(SRC, "rb") as f:
    f.read(80)
    n = int(np.frombuffer(f.read(4), np.uint32)[0])
    dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
    rec = np.fromfile(f, dt, n)
print("triangles", n, "read", round(time.time() - t, 1), "s")
tri = rec["v"].astype(np.float64)
V = tri.reshape(-1, 3)
# weld at 1e-4 mm
q = np.round(V / 1e-4).astype(np.int64)
uq, inv = np.unique(q, axis=0, return_inverse=True)
verts = uq * 1e-4
faces = inv.reshape(-1, 3).astype(np.int32)
print("verts", len(verts), "weld", round(time.time() - t, 1), "s")
np.savez(os.path.join(OUT, "scan.npz"), v=verts.astype(np.float32), f=faces)
lo, hi = verts.min(0), verts.max(0)
e = tri[:, 1] - tri[:, 0]; g = tri[:, 2] - tri[:, 0]
cr = np.cross(e, g)
area = 0.5 * np.linalg.norm(cr, axis=1)
vol = np.sum(np.einsum("ij,ij->i", tri[:, 0], np.cross(tri[:, 1], tri[:, 2]))) / 6
edge = np.linalg.norm(e, axis=1)
# open edges
ed = np.sort(np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]]), axis=1)
k = ed[:, 0].astype(np.int64) * (len(verts) + 1) + ed[:, 1]
_, cnt = np.unique(k, return_counts=True)
d = dict(triangles=n, verts=len(verts), bbox_lo=lo.tolist(), bbox_hi=hi.tolist(), size=(hi - lo).tolist(),
         area=float(area.sum()), volume=float(vol), edge_median=float(np.median(edge)),
         edge_p95=float(np.percentile(edge, 95)), open_edges=int((cnt == 1).sum()),
         nonmanifold_edges=int((cnt > 2).sum()), degenerate=int((area < 1e-9).sum()))
print(json.dumps(d, indent=1))
json.dump(d, open(os.path.join(OUT, "s0_describe.json"), "w"), indent=1)
