"""Polar tensor B-spline helpers shared by the inner skin / cavity fits (th domain -5..185 deg)."""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.interpolate import BSpline


def evalr(ty, tt, C, y, t):
    out = []
    for k in range(0, len(y), 4000):
        By = BSpline.design_matrix(np.clip(y[k:k + 4000], ty[3], ty[-4] - 1e-9), ty, 3)
        Bt = BSpline.design_matrix(np.clip(t[k:k + 4000], tt[3], tt[-4] - 1e-9), tt, 3).toarray()
        out.append(np.einsum("ij,ij->i", By @ C, Bt))
    return np.concatenate(out) if out else np.zeros(0)


def knots(lo, hi, h, k=3):
    n = max(1, int(round((hi - lo) / h)))
    return np.r_[[lo] * k, np.linspace(lo, hi, n + 1), [hi] * k]


def fit_grid(yy, tth, rr, w, KY, KT, LAM):
    ty = knots(-75.0, 295.0, KY); tt = knots(np.radians(-5.0), np.radians(185.0), np.radians(KT))
    ny, nt = len(ty) - 4, len(tt) - 4
    By = BSpline.design_matrix(yy, ty, 3).tocsr(); Bt = BSpline.design_matrix(tth, tt, 3).tocsr()
    iy = By.indices.reshape(-1, 4); vy = By.data.reshape(-1, 4)
    it = Bt.indices.reshape(-1, 4); vt = Bt.data.reshape(-1, 4)
    cols = (iy[:, :, None] * nt + it[:, None, :]).reshape(len(yy), 16)
    vals = (vy[:, :, None] * vt[:, None, :]).reshape(len(yy), 16) * w[:, None]
    A = sp.csr_matrix((vals.ravel(), cols.ravel(), np.arange(0, 16 * len(yy) + 1, 16)), shape=(len(yy), ny * nt))
    d2 = lambda n: sp.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n))
    d1 = lambda n: sp.diags([1.0, -1.0], [0, 1], shape=(n - 1, n))
    P = sp.kron(d2(ny), sp.eye(nt)); Q = sp.kron(sp.eye(ny), d2(nt)); Xp = sp.kron(d1(ny), d1(nt))
    M = (A.T @ A + LAM * len(yy) / (ny * nt) * (P.T @ P + Q.T @ Q + 2 * Xp.T @ Xp)).tocsc()
    coef = spl.spsolve(M, A.T @ (rr * w))
    return ty, tt, coef.reshape(ny, nt)
