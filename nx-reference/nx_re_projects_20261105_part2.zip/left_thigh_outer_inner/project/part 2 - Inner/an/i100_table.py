"""Cluster table before / after the stage-L fixes for STATUS.md.
usage: i100_table.py before_tag after_tag fixes.json out.md [min_area=20]
A before-cluster is RESOLVED when no after-cluster of the same sign with core depth (p90 > 0.5) lies within 2 mm of
its points. Cause: the fix whose footprint / spec covers it, else a rule (scan gap in a bore, shared hub value,
root fillet / edge round, noise)."""
import sys, json, os
import numpy as np
from scipy.spatial import cKDTree
from matplotlib.path import Path as MPath
from fixlib import W, segs_to_poly

bt, at, fxf, out = sys.argv[1:5]
AMIN = float(sys.argv[5]) if len(sys.argv) > 5 else 20.0
B = json.load(open(os.path.join(W, f"clusters_{bt}.json")))["clusters"]
A = json.load(open(os.path.join(W, f"clusters_{at}.json")))["clusters"]
BP = np.load(os.path.join(W, f"clusters_{bt}_pts.npz")); AP = np.load(os.path.join(W, f"clusters_{at}_pts.npz"))
FX = json.load(open(fxf))
P = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))
trees = {s: cKDTree(np.vstack([AP[c["key"]][:, :3] for c in A if c["sign"] == s and c["p90"] > 0.5] or [np.zeros((1, 3)) + 1e6])) for s in ("missing", "extra")}
after_by = {s: [c for c in A if c["sign"] == s] for s in ("missing", "extra")}


def fix_for(c, pts):
    hits = []
    for f in FX:
        if f["type"] == "zprism":
            poly = segs_to_poly(f["loops"][0]) if isinstance(f["loops"][0][0][0], str) else np.asarray(f["loops"][0])
            inside = MPath(poly).contains_points(pts[:, :2]).mean()
        elif f["type"] in ("prism_x", "prism_y"):
            ax = 0 if f["type"] == "prism_x" else 1
            other = 1 if ax == 0 else 0
            poly = np.asarray(f["loops"][0])
            m = (pts[:, ax] > f["s0"] - 1.5) & (pts[:, ax] < f["s1"] + 1.5)
            inside = (m & MPath(poly).contains_points(np.c_[pts[:, other], pts[:, 2]], radius=3.0)).mean()
        elif f["type"] == "revolve":
            r = np.hypot(pts[:, 0], pts[:, 1]); inside = ((r < 29) & (pts[:, 2] > 82)).mean()
        elif f["type"] in ("cyl", "cone"):
            cx, cy = (f["circle"][:2] if f["type"] == "cyl" else f["centre"])
            inside = (np.hypot(pts[:, 0] - cx, pts[:, 1] - cy) < 4.5).mean()
        else:
            inside = 0
        if inside > 0.25:
            hits.append((inside, f))
    hits.sort(key=lambda t: -t[0])
    return [f for _, f in hits]


def rule(c, pts):
    x, y, z = c["ctr"]
    for b in P["bosses"]:
        if np.hypot(pts[:, 0] - b["x"], pts[:, 1] - b["y"]).mean() < 8.0 and z > 44:
            return "scan gap: bore / counterbore interior not scanned (CAD hole per design)"
    r = np.hypot(pts[:, 0], pts[:, 1])
    if np.median(r) > 58 and np.median(r) < 71 and c["p90"] < 1.3 and z < 80:
        return "shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001"
    if c["p90"] <= 2.0 and c["sign"] == "missing":
        return "root fillet / edge round (not modelled, as on LT-OUT-001)"
    if c["p90"] <= 0.8:
        return "print / scan noise"
    return None


rows, open_ = [], []
for c in B:
    if c["area"] < AMIN:
        continue
    pts = BP[c["key"]][:, :3]
    d, _ = trees[c["sign"]].query(pts, distance_upper_bound=2.0)
    frac_left = float(np.isfinite(d).mean())
    fx = fix_for(c, pts)
    if fx:
        cause = "; ".join(sorted({f["note"].split(":")[0][:70] if f.get("auto") else f["id"] + " " + f["note"][:80] for f in fx[:2]}))
        status = "fixed" if frac_left < 0.35 else f"improved ({100 * frac_left:.0f} % of points still off)"
    else:
        cause = rule(c, pts) or "OPEN - not explained"
        status = "kept (by rule)" if not cause.startswith("OPEN") else ("gone" if frac_left < 0.35 else "open")
    rows.append((c, cause, status))
    if status == "open":
        open_.append(c)
L = [f"| # | sign | area mm2 | p90 mm | centre X, Y, Z | cause | after the fix |", "|---|---|---|---|---|---|---|"]
for c, cause, status in rows:
    L.append(f"| {c['id']} | {c['sign']} | {c['area']:.0f} | {c['p90']:.2f} | {c['ctr'][0]:.0f}, {c['ctr'][1]:.0f}, {c['ctr'][2]:.0f} | {cause} | {status} |")
tot = lambda cl, s: (sum(1 for c in cl if c["sign"] == s and c["area"] >= AMIN), round(sum(c["area"] for c in cl if c["sign"] == s and c["area"] >= AMIN)))  # noqa: E731
head = [f"Clusters >= {AMIN:.0f} mm2 (|signed deviation| > 0.3 mm, full-resolution scan, both directions):",
        f"before ({bt}): missing {tot(B, 'missing')}, extra {tot(B, 'extra')} (count, mm2); after ({at}): missing {tot(A, 'missing')}, extra {tot(A, 'extra')}.", ""]
open(out, "w", encoding="utf-8").write("\n".join(head + L) + "\n")
print("\n".join(head)); print("rows", len(rows), "open", len(open_))
for c in open_:
    print(" OPEN", c["id"], c["sign"], c["area"], c["p90"], c["ctr"])
