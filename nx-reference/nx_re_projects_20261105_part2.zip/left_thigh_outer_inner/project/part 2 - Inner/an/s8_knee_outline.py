"""Knee hub outline: plan sections at several z; polar r(phi) about the knee axis."""
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load, section, W
v, f = load()
KC = np.array([-29.741, -137.181])
fig, ax = plt.subplots(1, 2, figsize=(22, 10))
for zz, col in ((-6.0, "k"), (0.5, "b"), (10.0, "g"), (20.0, "r"), (30.0, "m")):
    s = section(v, f, 2, zz).reshape(-1, 3)
    p = s[:, :2] - KC
    r = np.hypot(p[:, 0], p[:, 1]); ph = np.degrees(np.arctan2(p[:, 1], p[:, 0]))
    m = r < 110
    # outermost per 1 deg
    b = np.round(ph[m]).astype(int); rr = r[m]
    out = {}
    for bi, ri in zip(b, rr):
        if ri > out.get(bi, 0): out[bi] = ri
    k = np.array(sorted(out)); ax[0].plot(k, [out[i] for i in k], col + ".-", ms=2, lw=0.5, label=f"z={zz}")
    ax[1].plot(p[m, 0], p[m, 1], col + ",")
ax[0].axhline(67.85, color="0.5"); ax[0].set_ylim(50, 110); ax[0].legend(); ax[0].grid(True); ax[0].set_xlabel("phi deg about knee axis (0=+x, 90=+y)")
ax[1].add_patch(plt.Circle((0, 0), 67.85, fill=False, color="0.5")); ax[1].set_aspect("equal"); ax[1].grid(True)
fig.tight_layout(); fig.savefig(W + r"\knee_outline.png", dpi=80)
