"""Read-only access to the OUTER (part 1) scan in the LT-OUT-001 frame, and the delivered outer CAD STL."""
import os, json
import numpy as np
P1 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1"
_c = {}
def load_outer():
    if "o" in _c: return _c["o"]
    d = np.load(os.path.join(P1, "work", "scan.npz"))
    fr = json.load(open(os.path.join(P1, "work", "frame.json")))
    R = np.array(fr["R"]); o = np.array(fr["o"])
    v = (d["v"].astype(np.float64) - o) @ R.T
    _c["o"] = (v, d["f"]); return _c["o"]
OUTER_CAD_STL = os.path.join(P1, "deliver", "CAD", "LT-OUT-001_Left_Thigh_Outer.stl")
OUTER_STEP = os.path.join(P1, "deliver", "CAD", "LT-OUT-001_Left_Thigh_Outer_AP214.step")
