"""Rim-top plane(s) in the provisional frame: fit, compare with the knee floor plane."""
import numpy as np
from common import load, tri_data, fit_plane_robust
v, f = load()
c, n, a = tri_data(v, f)
m = (n[:, 2] > 0.995) & (c[:, 2] > 33.5) & (c[:, 2] < 37.5)
print("facets", m.sum(), "area", a[m].sum())
cc, nn, sd, k = fit_plane_robust(c[m])
print("one plane: n", nn, "z0 at origin", cc @ nn / nn[2], "sd", sd, "kept", k.sum())
# per-cluster: grid by y
p = c[m]
for y0 in range(-210, 160, 20):
    mm = (p[:, 1] >= y0) & (p[:, 1] < y0 + 20)
    if mm.sum() < 200: continue
    print(f" y {y0:5d}..{y0+20:5d}: n={mm.sum():6d} z med {np.median(p[mm,2]):7.3f}  x range {p[mm,0].min():7.1f} {p[mm,0].max():7.1f}")
for x0 in range(-100, 100, 20):
    mm = (p[:, 0] >= x0) & (p[:, 0] < x0 + 20)
    if mm.sum() < 200: continue
    print(f" x {x0:5d}..{x0+20:5d}: n={mm.sum():6d} z med {np.median(p[mm,2]):7.3f}")
