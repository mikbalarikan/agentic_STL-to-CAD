"""Independent STEP check with OpenCascade (OCP): solids, validity, volume, area, bbox, face types."""
import sys, time
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.TopoDS import TopoDS
for p in sys.argv[1:]:
    t = time.time()
    r = STEPControl_Reader()
    st = r.ReadFile(p)
    assert st == IFSelect_RetDone, st
    r.TransferRoots()
    s = r.OneShape()
    ns = 0; e = TopExp_Explorer(s, TopAbs_SOLID)
    while e.More(): ns += 1; e.Next()
    ft = {}; nf = 0; e = TopExp_Explorer(s, TopAbs_FACE)
    while e.More():
        nf += 1
        k = str(BRepAdaptor_Surface(TopoDS.Face_s(e.Current())).GetType()).split(".")[-1]
        ft[k] = ft.get(k, 0) + 1; e.Next()
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g); vol = g.Mass()
    g2 = GProp_GProps(); BRepGProp.SurfaceProperties_s(s, g2); area = g2.Mass()
    b = Bnd_Box(); BRepBndLib.Add_s(s, b); bb = b.Get()
    ok = BRepCheck_Analyzer(s).IsValid()
    print(p.split("\\")[-1], f"read {time.time()-t:.1f}s solids {ns} faces {nf} valid {ok} volume {vol:.1f} area {area:.1f}")
    print("   bbox", [round(v, 2) for v in bb], "face types", ft)
