"""Inner scan census in its scanner pose: z histogram of +Z / -Z facing area, to find rim / floor planes."""
import numpy as np
from common import load, tri_data
v, f = load(frame=False)
c, n, a = tri_data(v, f)
for lab, m in (("up", n[:, 2] > 0.995), ("down", n[:, 2] < -0.995)):
    h, e = np.histogram(c[m, 2], bins=np.arange(-40, 40, 0.25), weights=a[m])
    idx = np.argsort(h)[::-1][:12]
    print(lab, [(round(e[i], 2), round(h[i])) for i in sorted(idx)])
# x/y extremes
print("bbox", v.min(0), v.max(0))
