"""Top-down height maps of scan and CAD by ray casting (first hit from above), difference map, components.
usage: hdiff.py cad.stl tag   -> work/hdiff_<tag>.npz/.png/.json"""
import sys, json
import numpy as np
import open3d as o3d
from scipy import ndimage
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, W

cad, tag = sys.argv[1], sys.argv[2]
CELL = 0.25
X0, X1, Y0, Y1 = -100.0, 125.0, -72.0, 292.0
xs = np.arange(X0, X1, CELL) + CELL / 2; ys = np.arange(Y0, Y1, CELL) + CELL / 2
XX, YY = np.meshgrid(xs, ys)


def topmap(mesh):
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mesh))
    rays = np.zeros((XX.size, 6), np.float32)
    rays[:, 0] = XX.ravel(); rays[:, 1] = YY.ravel(); rays[:, 2] = 120.0; rays[:, 5] = -1.0
    t = sc.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
    z = 120.0 - t
    z[~np.isfinite(t)] = np.nan
    return z.reshape(XX.shape)


import os
sp = W + r"\htop_scan.npy"
if os.path.exists(sp):
    Hs = np.load(sp)
else:
    v, f = load()
    Hs = topmap(o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f)))
    np.save(sp, Hs)
cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices()
Hc = topmap(cm)
D = Hs - Hc                      # + : scan higher = CAD missing material ; - : CAD extra
both = np.isfinite(Hs) & np.isfinite(Hc)
miss = both & (D > 0.6); extra = both & (D < -0.6)
miss |= np.isfinite(Hs) & ~np.isfinite(Hc)     # scan has material, CAD has nothing
extra |= np.isfinite(Hc) & ~np.isfinite(Hs)
np.savez_compressed(W + rf"\hdiff_{tag}.npz", Hs=Hs, Hc=Hc, ext=np.array([X0, X1, Y0, Y1]), cell=CELL)
rep = {}
for nm, m in (("missing", miss), ("extra", extra)):
    m2 = ndimage.binary_opening(m, iterations=2)
    lab, n = ndimage.label(m2)
    comps = []
    for k in range(1, n + 1):
        ii = lab == k
        a = ii.sum() * CELL * CELL
        if a < 8: continue
        yy, xx = np.where(ii)
        dz = np.nanmedian(np.abs(np.where(np.isfinite(D[ii]), D[ii], 0)))
        comps.append(dict(area=round(float(a), 1), x=[round(float(xs[xx.min()]), 1), round(float(xs[xx.max()]), 1)],
                          y=[round(float(ys[yy.min()]), 1), round(float(ys[yy.max()]), 1)], dz_med=round(float(dz), 2),
                          zs=round(float(np.nanmedian(Hs[ii])), 2) if np.isfinite(Hs[ii]).any() else None))
    comps.sort(key=lambda c: -c["area"])
    rep[nm] = comps
    print(nm, len(comps), "components; largest:")
    for c in comps[:25]:
        print("  ", c)
json.dump(rep, open(W + rf"\hdiff_{tag}.json", "w"), indent=1)
fig, ax = plt.subplots(figsize=(16, 26))
img = np.where(both, np.clip(D, -3, 3), np.nan)
img = np.where(np.isfinite(Hs) & ~np.isfinite(Hc), 3, img)
img = np.where(np.isfinite(Hc) & ~np.isfinite(Hs), -3, img)
im = ax.imshow(img, origin="lower", extent=[X0, X1, Y0, Y1], cmap="coolwarm", vmin=-3, vmax=3, interpolation="nearest")
plt.colorbar(im, shrink=0.4, label="scan top - CAD top (mm)")
ax.set_xticks(np.arange(-100, 126, 10)); ax.set_yticks(np.arange(-70, 292, 10)); ax.grid(True, lw=0.3)
fig.tight_layout(); fig.savefig(W + rf"\hdiff_{tag}.png", dpi=60)
