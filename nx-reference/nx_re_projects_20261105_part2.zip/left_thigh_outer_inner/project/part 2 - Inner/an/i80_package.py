"""Package LT-INN-001 Rev A exactly like the LT-OUT-001 Rev A zip:
LT-INN-001_RevA_Left_Thigh_Inner/LT-INN-001_RevA/{CAD, Drawings, Deviation Report, Renders} + README.md.
usage: i80_package.py   (reads deliver/, writes the folder + zip next to it)"""
import os, shutil, zipfile
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
D = os.path.join(ROOT, "deliver")
TOP = "LT-INN-001_RevA_Left_Thigh_Inner"
OUT = os.path.join(ROOT, TOP, "LT-INN-001_RevA")
if os.path.exists(os.path.join(ROOT, TOP)):
    shutil.rmtree(os.path.join(ROOT, TOP))
os.makedirs(OUT)
for sub, src in (("CAD", "CAD"), ("Drawings", "Drawings"), ("Deviation Report", "Deviation Report"), ("Renders", "Renders")):
    os.makedirs(os.path.join(OUT, sub))
    for f in sorted(os.listdir(os.path.join(D, src))):
        if f.startswith("_") or f.endswith(".log") or os.path.isdir(os.path.join(D, src, f)):
            continue
        shutil.copy2(os.path.join(D, src, f), os.path.join(OUT, sub, f))
shutil.copy2(os.path.join(D, "README.md"), os.path.join(OUT, "README.md"))
zp = os.path.join(ROOT, TOP + ".zip")
if os.path.exists(zp):
    os.remove(zp)
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for base, dirs, files in os.walk(os.path.join(ROOT, TOP)):
        rel = os.path.relpath(base, ROOT)
        z.write(base, rel + "/")
        for f in sorted(files):
            z.write(os.path.join(base, f), os.path.join(rel, f))
with zipfile.ZipFile(zp) as z:
    names = z.namelist()
    bad = z.testzip()
print("zip", zp, os.path.getsize(zp), "entries", len(names), "testzip", bad)
for n in names:
    print("  ", n)
