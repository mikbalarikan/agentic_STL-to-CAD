"""Close-up of the deviation map. usage: devzoom.py cad.stl out.png cx cy cz dx dy dz dist [lim]"""
import sys, numpy as np, open3d as o3d, pyvista as pv
from common import W
a = sys.argv[1:]
cm = o3d.io.read_triangle_mesh(a[0]); cm.remove_duplicated_vertices()
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
m = pv.read(W + r"\scan_600k_framed.ply")
m["dev"] = sc.compute_signed_distance(o3d.core.Tensor(np.asarray(m.points, np.float32))).numpy()
foc = np.array([float(t) for t in a[2:5]]); d = np.array([float(t) for t in a[5:8]]); d /= np.linalg.norm(d)
lim = float(a[9]) if len(a) > 9 else 1.0
p = pv.Plotter(off_screen=True, window_size=(1500, 1200))
p.add_mesh(m, scalars="dev", cmap="coolwarm", clim=(-lim, lim))
p.camera_position = [tuple(foc + d * float(a[8])), tuple(foc), (0, 0, 1) if abs(d[2]) < 0.9 else (0, 1, 0)]
p.camera.view_angle = 30
p.screenshot(a[1]); print("ok")
