"""Inner (LT-OUT frame): area histogram of -Z facing (toward the open side) and +Z facing faces over all z."""
import numpy as np
from common import load, tri_data
v, f = load(); c, n, a = tri_data(v, f)
for lab, m in (("-Z facing (seen from the open side)", n[:, 2] < -0.995), ("+Z facing", n[:, 2] > 0.995)):
    h, e = np.histogram(c[m, 2], bins=np.arange(34, 125, 0.1), weights=a[m])
    print(lab)
    pk = [(e[i] + 0.05, h[i]) for i in range(1, len(h) - 1) if h[i] > 15 and h[i] >= h[i - 1] and h[i] >= h[i + 1]]
    for z, ar in pk: print(f"   {z:7.2f} {ar:8.1f}")
print("z range", v[:, 2].min(), v[:, 2].max())
