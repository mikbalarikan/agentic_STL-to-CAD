"""STEP check for a delivery (OCP): solids, validity, faces, bbox, GProp volume (known to be off on big trimmed
B-splines), mesh volume (signed tetra sum of the OCP tessellation), and the face-on-NX-surface test (every OCP
face's mesh nodes within 0.1 mm of the NX STL). usage: stepcheck_revE.py out.json nx.stl step1 [step2 ...]"""
import sys, json, time
import numpy as np, open3d as o3d
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE, TopAbs_REVERSED
from OCP.BRep import BRep_Tool
from OCP.TopLoc import TopLoc_Location
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Surface

out_json, stl = sys.argv[1], sys.argv[2]
m = o3d.io.read_triangle_mesh(stl)
scene = o3d.t.geometry.RaycastingScene()
scene.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
V = np.asarray(m.vertices); T = np.asarray(m.triangles)
stl_vol = float(np.einsum("ij,ij->i", V[T[:, 0]], np.cross(V[T[:, 1]], V[T[:, 2]])).sum() / 6.0)
res = {"nx_stl": stl, "nx_stl_volume": stl_vol, "files": []}
for p in sys.argv[3:]:
    t = time.time()
    r = STEPControl_Reader()
    st = r.ReadFile(p)
    row = {"file": p}
    if st != IFSelect_RetDone:
        row["read"] = "FAILED %s" % st; res["files"].append(row); continue
    r.TransferRoots()
    s = r.OneShape()
    ns = 0; e = TopExp_Explorer(s, TopAbs_SOLID)
    while e.More(): ns += 1; e.Next()
    ok = BRepCheck_Analyzer(s).IsValid()
    b = Bnd_Box(); BRepBndLib.Add_s(s, b, False); bb = [round(v, 3) for v in b.Get()]
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g); vg = g.Mass()
    BRepMesh_IncrementalMesh(s, 0.01, False, 0.1, True)
    vm = 0.0; nf = 0; off = []; ft = {}; nodes = []
    ex = TopExp_Explorer(s, TopAbs_FACE)
    while ex.More():
        f = TopoDS.Face_s(ex.Current()); loc = TopLoc_Location(); tri = BRep_Tool.Triangulation_s(f, loc)
        k = str(BRepAdaptor_Surface(f).GetType()).split(".")[-1]; ft[k] = ft.get(k, 0) + 1
        if tri is None:
            off.append([nf, "no triangulation", k]); nf += 1; ex.Next(); continue
        P = np.array([[tri.Node(i).X(), tri.Node(i).Y(), tri.Node(i).Z()] for i in range(1, tri.NbNodes() + 1)])
        TT = np.array([[tri.Triangle(i).Value(j) for j in (1, 2, 3)] for i in range(1, tri.NbTriangles() + 1)]) - 1
        if f.Orientation() == TopAbs_REVERSED: TT = TT[:, ::-1]
        vm += np.einsum("ij,ij->i", P[TT[:, 0]], np.cross(P[TT[:, 1]], P[TT[:, 2]])).sum() / 6.0
        d = np.abs(scene.compute_distance(o3d.core.Tensor(P.astype(np.float32))).numpy())
        if d.max() > 0.1:
            off.append([nf, round(float(d.max()), 3), P.mean(0).round(2).tolist(), k])
        nodes.append(P)
        nf += 1; ex.Next()
    allp = np.vstack(nodes)
    row.update({"read_s": round(time.time() - t, 1), "solids": ns, "valid": bool(ok), "faces": nf, "face_types": ft,
                "bbox_ocp_optimal": bb, "bbox_mesh": allp.min(0).round(3).tolist() + allp.max(0).round(3).tolist(),
                "volume_gprop": round(vg, 2), "volume_mesh": round(vm, 2),
                "faces_off_nx_surface_gt_0p1": len(off), "off_list": off[:20]})
    res["files"].append(row)
    print(json.dumps({k: v for k, v in row.items() if k != "off_list"}))
json.dump(res, open(out_json, "w"), indent=1)
