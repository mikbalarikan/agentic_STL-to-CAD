"""Binary cell mask -> NX loop groups (line/arc chains, outer loops with their holes), as in s16/s19."""
import numpy as np
from scipy import ndimage
import contourpy
from matplotlib.path import Path
from arcfit import fit_loop, seg_points


def _area(P):
    x, y = P[:, 0], P[:, 1]
    return 0.5 * (np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))


def mask_loops(M, X0, Y0, cell, min_area=1.5, sigma=3.5, tol=0.10):
    G = np.pad(np.where(M, 0.5, -0.5), 2, constant_values=-0.5)
    G = ndimage.gaussian_filter(G, 0.7)
    loops = []
    for C in contourpy.contour_generator(z=G, line_type="Separate").lines(0.0):
        C = C[:, ::-1] - 2.0
        P = np.c_[X0 + (C[:, 1] + 0.5) * cell, Y0 + (C[:, 0] + 0.5) * cell]
        if np.linalg.norm(P[0] - P[-1]) > 1e-6:
            continue
        P = P[:-1]
        A = _area(P)
        if abs(A) < min_area:
            continue
        Pc = np.vstack([P, P[:1]])
        Lc = np.r_[0, np.cumsum(np.linalg.norm(np.diff(Pc, axis=0), axis=1))]
        s = np.arange(0, Lc[-1], 0.1)
        Pu = np.c_[np.interp(s, Lc, Pc[:, 0]), np.interp(s, Lc, Pc[:, 1])]
        Pu = np.c_[ndimage.gaussian_filter1d(Pu[:, 0], sigma, mode="wrap"), ndimage.gaussian_filter1d(Pu[:, 1], sigma, mode="wrap")]
        segs = fit_loop(Pu, tol=tol)
        loops.append(dict(area=float(A), segs=[
            ([g[0], g[1].tolist(), g[2].tolist()] if g[0] == "L" else [g[0], g[1].tolist(), g[2].tolist(), g[3].tolist(), float(g[4]), bool(g[5])])
            for g in segs]))
    return loops


def _np_segs(sl):
    return [("L", np.array(s[1]), np.array(s[2])) if s[0] == "L" else ("A", np.array(s[1]), np.array(s[2]), np.array(s[3]), s[4], s[5]) for s in sl]


def loop_points(sl, n=12):
    return np.vstack([seg_points(s, n) for s in _np_segs(sl)])


def group_loops(loops):
    polys = [loop_points(l["segs"]) for l in loops]
    n = len(polys)
    parent = [-1] * n
    for i in range(n):
        best = None
        for j in range(n):
            if i != j and Path(polys[j]).contains_points(polys[i][::5]).all():
                if best is None or abs(loops[j]["area"]) < abs(loops[best]["area"]):
                    best = j
        parent[i] = -1 if best is None else best
    def depth(i):
        k = 0
        while parent[i] != -1:
            i = parent[i]; k += 1
        return k
    groups = []
    for i in range(n):
        if depth(i) % 2 == 0:
            holes = [j for j in range(n) if parent[j] == i and depth(j) % 2 == 1]
            groups.append(dict(outer=loops[i]["segs"], holes=[loops[j]["segs"] for j in holes], area=loops[i]["area"]))
    return groups
