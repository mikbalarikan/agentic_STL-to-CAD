"""Inner: depth map seen from the open side (-Z): MIN z per 0.2 mm cell of the framed scan. Stored mirrored as
H = -min z (so 'higher' = closer to the open side, same logic as part 1's hmap2). Writes work/hmap2.npz + a picture."""
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import ndimage
from common import load, W
CELL = 0.2
X0, X1, Y0, Y1 = -100.0, 125.0, -72.0, 292.0
v, f = load()
a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
pts = np.concatenate([a, b, c, (a + b) / 2, (b + c) / 2, (c + a) / 2, (a + b + c) / 3])
nx_, ny_ = int((X1 - X0) / CELL), int((Y1 - Y0) / CELL)
ix = np.floor((pts[:, 0] - X0) / CELL).astype(np.int64); iy = np.floor((pts[:, 1] - Y0) / CELL).astype(np.int64)
ok = (ix >= 0) & (ix < nx_) & (iy >= 0) & (iy < ny_)
lin = iy[ok] * nx_ + ix[ok]
H = np.full(nx_ * ny_, -np.inf); np.maximum.at(H, lin, -pts[ok, 2])
L = np.full(nx_ * ny_, np.inf); np.minimum.at(L, lin, -pts[ok, 2])
H = H.reshape(ny_, nx_); L = L.reshape(ny_, nx_)
empty = np.isinf(H)
Hf = np.where(empty, -1e9, H); mx = ndimage.maximum_filter(Hf, size=3); fill = empty & (mx > -1e8); H[fill] = mx[fill]
print("cells", H.size, "empty", np.isinf(H).sum())
np.savez_compressed(W + r"\hmap2.npz", H=H, L=L, ext=np.array([X0, X1, Y0, Y1]), cell=CELL)
fig, ax = plt.subplots(figsize=(18, 30))
im = ax.imshow(np.where(np.isinf(H), np.nan, -H), origin="lower", extent=[X0, X1, Y0, Y1], cmap="nipy_spectral", vmin=34, vmax=112)
plt.colorbar(im, ax=ax, shrink=0.5); ax.set_xticks(np.arange(-100, 126, 10)); ax.set_yticks(np.arange(-70, 292, 10)); ax.grid(lw=0.3)
fig.tight_layout(); fig.savefig(W + r"\depth_map.png", dpi=45)
