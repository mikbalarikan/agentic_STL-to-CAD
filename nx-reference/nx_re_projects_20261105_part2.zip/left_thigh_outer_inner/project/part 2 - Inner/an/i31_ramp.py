"""Cable-channel ramp floor: footprint of the cells whose scan depth follows the ramp z = Z0 + S (y - Y0), y 86..137.
Writes work/ramp_nx.json (loop groups + ramp line)."""
import json, numpy as np
from scipy import ndimage
from common import W
from masklib import mask_loops, group_loops
Z0, Y0, S = 75.13, 90.0, 0.1045
d = np.load(W + r"\hmap2.npz"); H = d["H"]; X0, X1, Y0g, Y1 = d["ext"]; C = float(d["cell"])
ny, nx = H.shape
xs = X0 + (np.arange(nx) + 0.5) * C; ys = Y0g + (np.arange(ny) + 0.5) * C
XX, YY = np.meshgrid(xs, ys)
zs = -H
ramp = Z0 + S * (YY - Y0)
M = (YY > 86) & (YY < 137) & (XX > 38) & (XX < 78) & np.isfinite(zs) & (np.abs(zs - ramp) < 0.35)
M = ndimage.binary_opening(M, iterations=2)
lab, n = ndimage.label(M); sz = ndimage.sum(M, lab, range(1, n + 1))
M = lab == (1 + int(np.argmax(sz)))
M = ndimage.binary_fill_holes(ndimage.binary_closing(M, iterations=3))
loops = mask_loops(M, X0, Y0g, C, min_area=5.0, sigma=3.0, tol=0.10)
groups = group_loops(loops)
json.dump(dict(z0=Z0, y0=Y0, slope=S, y_from=84.0, y_to=140.0, groups=groups), open(W + r"\ramp_nx.json", "w"))
print("ramp footprint cells", int(M.sum()), "area mm2", round(M.sum() * C * C), "groups", len(groups), [round(g["area"]) for g in groups])
