"""Stage M clearance: the stage-L auto adds A039 / A040 (scan bumps Z 79.4 -> 85.3 at X 27 / 49, Y 270-273.6 on the hip pad)
sit inside LT-OUT-001 Rev A as delivered (an/i50_fit.py: 2 x 64 mm3). The outer SCAN has matching slots there, the
delivered outer CAD does not; the outer stays as delivered, so the inner bumps are cut back to the hip pad face Z 85.32
(the stage-K state). Writes nx/fixes_M2.json (cuts only; run as stage L on the stage-M part)."""
import os, json
from fixlib import ROOT

fx = {f["id"]: f for f in json.load(open(os.path.join(ROOT, "nx", "fixes_M.json")))}
out = []
for k, fid in enumerate(("A039", "A040")):
    f = fx[fid]
    out.append(dict(id=f"M04{'ab'[k]}", kind="cut", type="zprism", loops=f["loops"], z0=79.0, z1=85.32,
                    note=f"hip-pad bump of {fid} cut back to the pad face Z 85.32: inside LT-OUT-001 Rev A (its scan has a slot here, its CAD does not)"))
json.dump(out, open(os.path.join(ROOT, "nx", "fixes_M2.json"), "w"), indent=0)
print([f["id"] for f in out])
