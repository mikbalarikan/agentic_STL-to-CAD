"""Register the INNER scan into the LT-OUT-001 frame by the shared functional features.
1. inner rim frame (Rrim.npy) -> level the plane through the 7 boss-top annuli (the real contact faces)
2. flip 180 deg about Y (inner open side faces the outer's open side)
3. 2D rigid fit (rotation about Z + translation) of the 7 inner boss axes onto the 7 outer boss axes
   (column + nub/pocket centres averaged on each side)
4. boss-top plane -> z = 35.95 (outer CAD boss top, common design value)
Writes work/frame.json (p_new = R @ (p - o), same convention as part 1) and work/register.json (residuals)."""
import numpy as np, json
from common import load, tri_data, fit_plane_robust, fit_circle_robust, W
from outer import load_outer
PO = json.load(open(r"..\nx\params_outer.json"))
Z_TOP = 35.95
# inner label -> outer boss index (B4/B5 cross over in the flip)
MAP = {"B1": 0, "B2": 1, "B3": 2, "B4": 4, "B5": 3, "B6": 5, "B7": 6}
cy_i = json.load(open(W + r"\cyl_inner.json")); cy_o = json.load(open(W + r"\cyl_outer.json"))
def pick(cy, k, lo, hi, conv):
    c = [o for o in cy[k] if (o["side"] == "hole") == conv and lo < o["D"] < hi]
    return np.array(max(c, key=lambda o: o["area"])["c"]) if c else None
Rr = np.load(W + r"\Rrim.npy")
v, f = load(frame=False); vr = (v - Rr[3]) @ Rr[:3].T
c, n, a = tri_data(vr, f)
# --- inner centres (rim frame) and boss-top points
ci, top_pts = {}, []
for k in MAP:
    col = pick(cy_i, k, 14.8, 15.5, True)
    d = np.hypot(c[:, 0] - col[0], c[:, 1] - col[1])
    # pocket circle from wall facets r 4.5..5.5, z -2.8..-0.6
    m = (d > 4.4) & (d < 5.6) & (np.abs(n[:, 2]) < 0.3) & (c[:, 2] > -2.7) & (c[:, 2] < -0.7)
    pc, pr, psd, _ = fit_circle_robust(c[m][:, :2])
    ci[k] = dict(col=col.tolist(), pocket=pc.tolist(), pocket_D=2 * pr, pocket_sd=psd)
    mt = (d > 5.4) & (d < 7.3) & (n[:, 2] > 0.98) & (np.abs(c[:, 2]) < 2)
    top_pts.append(c[mt])
tp = np.vstack(top_pts)
pc_, pn, psd, keep = fit_plane_robust(tp)
if pn[2] < 0: pn = -pn
print("boss-top plane normal (rim frame)", pn, "sd", psd, "tilt deg", np.degrees(np.arccos(pn[2])))
# level rotation L: pn -> +Z
zt = pn; xt = np.array([1.0, 0, 0]) - zt * zt[0]; xt /= np.linalg.norm(xt); yt = np.cross(zt, xt)
L = np.vstack([xt, yt, zt])
lev = lambda p: (np.asarray(p) - pc_) @ L.T            # levelled, boss-top plane z = 0
FLIP = np.diag([-1.0, 1.0, -1.0])
# --- outer centres
vo, fo = load_outer(); co, no, ao = tri_data(vo, fo)
src, dst, names = [], [], []
for k, j in MAP.items():
    ok = "B%d" % (j + 1)
    ocol = pick(cy_o, ok, 14.8, 15.5, True)
    dd = np.hypot(co[:, 0] - ocol[0], co[:, 1] - ocol[1])
    m = (dd > 4.4) & (dd < 5.6) & (np.abs(no[:, 2]) < 0.3) & (co[:, 2] > 36.4) & (co[:, 2] < 38.6)
    nc, nr, nsd, _ = fit_circle_robust(co[m][:, :2])
    ci[k].update(outer=ok, outer_col=ocol.tolist(), outer_nub=nc.tolist(), outer_nub_D=2 * nr, outer_nub_sd=nsd)
    pairs = [(ci[k]["pocket"], nc)] + ([] if k == "B2" else [(ci[k]["col"], ocol)])  # inner B2 column fit is poor (sd 0.28)
    for s, d_ in pairs:
        p = (lev([s[0], s[1], 0.0]) @ FLIP.T)[:2]
        src.append(p); dst.append(d_); names.append(k)
src, dst = np.array(src), np.array(dst)
ms, md = src.mean(0), dst.mean(0)
H = (src - ms).T @ (dst - md); U, S, Vt = np.linalg.svd(H); Rz = Vt.T @ U.T
if np.linalg.det(Rz) < 0: Vt[1] *= -1; Rz = Vt.T @ U.T
t = md - Rz @ ms
res = (src @ Rz.T + t) - dst
print("2D fit: rot deg", np.degrees(np.arctan2(Rz[1, 0], Rz[0, 0])), "t", t)
for nm, r in zip(names, res): print(f"   {nm} residual {r[0]:+.3f} {r[1]:+.3f}  |{np.hypot(*r):.3f}|")
print("rms", np.sqrt((res ** 2).sum(1).mean()))
# compose: p_out = R3 @ (FLIP @ (L @ (Rrim @ (p - o_raw)) - L@pc_)) + T
R3 = np.eye(3); R3[:2, :2] = Rz
Rtot = R3 @ FLIP @ L @ Rr[:3]
T = np.r_[t, Z_TOP] - R3 @ FLIP @ (L @ pc_)
# p_new = Rtot @ p + T - Rtot@Rr3... careful: vr = Rr3 @ (p - o_raw)
o_raw = Rr[3]
Tfull = T - Rtot @ o_raw            # p_new = Rtot @ p + Tfull
o = -np.linalg.solve(Rtot, Tfull)   # p_new = Rtot @ (p - o)
json.dump(dict(R=Rtot.tolist(), o=o.tolist(), note="INNER scan -> LT-OUT-001 frame: boss-top plane at z=35.95, "
               "flipped 180 deg about Y, 7 boss axes fitted to the outer's"), open(W + r"\frame.json", "w"), indent=1)
json.dump(dict(bosses=ci, rms=float(np.sqrt((res ** 2).sum(1).mean())), residuals=res.tolist(), names=names,
               top_plane_sd=psd, rot_deg=float(np.degrees(np.arctan2(Rz[1, 0], Rz[0, 0]))), t=t.tolist()),
          open(W + r"\register.json", "w"), indent=1)
print({k: (round(vv["pocket_D"], 3), round(vv["outer_nub_D"], 3)) for k, vv in ci.items()})
