import os
D = os.path.dirname(os.path.abspath(__file__))
p = os.path.join(D, "ptdwg.py")
s = open(p, encoding="utf-8").read()
s = s.replace('CLIENT = "POOL TIME - Toth Invest Solutions AB"', 'CLIENT = "Paul Clark"')
s = s.replace('PRODUCT = "M3 Multifold set"', 'PRODUCT = "Robot leg - left thigh"')
s = s.replace('DATE = "2026-10-24"', 'DATE = "2026-10-25"')
s = s.replace('FRAME = {"A3": (20.0, 10.0, 410.0, 287.0), "A2": (20.0, 10.0, 584.0, 410.0)}',
              'FRAME = {"A3": (20.0, 10.0, 410.0, 287.0), "A2": (20.0, 10.0, 584.0, 410.0), "A1": (20.0, 10.0, 831.0, 584.0), "A0": (20.0, 10.0, 1179.0, 831.0)}')
s = s.replace('''def sheet(dwg, size="A3"):
    """Template sheet (border + zones), first angle, the Siemens example title block deleted."""
    sh = nxd.sheet(dwg, "SH", angle="first", template=nxd.template_path(size))''', '''ANGLE = "third"


def sheet(dwg, size="A3"):
    """Template sheet (border + zones), projection ANGLE, the Siemens example title block deleted."""
    sh = nxd.sheet(dwg, "SH", angle=ANGLE, template=nxd.template_path(size))''')
s = s.replace('''def title_block(dwg, size, title, dwg_no, material, mass, scale, sheet_no, n_sheets, rev="IM01", subtitle=""):''', '''def third_angle_symbol(dwg, x, y, h=7.0):
    """Third-angle symbol: end view (two circles) on the LEFT, truncated cone (small end left) on the right."""
    d1, d2, L = 0.5 * h, h, 1.0 * h
    cy = y + h / 2.0
    cx = x + d2 / 2
    for rr in (d1 / 2, d2 / 2):
        nxh.circle(dwg, (cx, cy, 0.0), rr)
    nxd2.sheet_line(dwg, (cx - d2 / 2 - 1.0, cy), (cx + d2 / 2 + 1.0, cy), font="center")
    nxd2.sheet_line(dwg, (cx, cy - d2 / 2 - 1.0), (cx, cy + d2 / 2 + 1.0), font="center")
    x0 = cx + d2 / 2 + 0.35 * h
    pts = [(x0, cy - d1 / 2), (x0 + L, cy - d2 / 2), (x0 + L, cy + d2 / 2), (x0, cy + d1 / 2)]
    for i in range(4):
        nxd2.sheet_line(dwg, pts[i], pts[(i + 1) % 4])
    nxd2.sheet_line(dwg, (x0 - 1.0, cy), (x0 + L + 1.0, cy), font="center")


def title_block(dwg, size, title, dwg_no, material, mass, scale, sheet_no, n_sheets, rev="IM01", subtitle=""):''')
s = s.replace('''["Drawn", DRAWN, "Checked", "-", "1st angle"],''', '''["Drawn", DRAWN, "Checked", "-", ("3rd" if ANGLE == "third" else "1st") + " angle"],''')
s = s.replace('''    first_angle_symbol(dwg, left + sum(cw[:4]) + 6.0, top - 12.0 + 2.5, h=7.0)''',
              '''    (third_angle_symbol if ANGLE == "third" else first_angle_symbol)(dwg, left + sum(cw[:4]) + 6.0, top - 12.0 + 2.5, h=7.0)''')
open(p, "w", encoding="utf-8").write(s)
p = os.path.join(D, "m3d.py")
s = open(p, encoding="utf-8").read()
s = s.replace(r'B = r"C:\NX_MCP_WORKSPACE\pooltime_molding\m3_dwg"', r'B = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\nx\dwg"')
s = s.replace(r'ASM = r"C:\NX_MCP_WORKSPACE\pooltime_molding\m3_asm"', 'ASM = B')
open(p, "w", encoding="utf-8").write(s)
print("patched")
