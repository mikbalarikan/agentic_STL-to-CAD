# -*- coding: utf-8 -*-
"""GD&T annotations on NX 2206 drawings (probed in nx/probe_gdt.py): feature control frames, datum feature
symbols, arrow balloons, basic dimensions. The FCF data must be appended to the builder list FIRST and then
filled through FindItem(0) (values set before Append are dropped: the frame shows 0.0 and no datums)."""
import NXOpen
import NXOpen.Annotations

import nxh
import nxd2

A = NXOpen.Annotations
P = nxh.P


def characteristic(name):
    E = A.FeatureControlFrameBuilder.FcfCharacteristic
    if not hasattr(E, name):
        raise RuntimeError("no FcfCharacteristic %s; have %s" % (name, [a for a in dir(E) if not a.startswith("_")]))
    return getattr(E, name)


def fcf(dwg, char, tol, datums=(), dia=False, pos=(0.0, 0.0), target=None, view=None, at=None, size=4.0, mmc=False):
    """Single feature control frame at sheet pos; optional leader to drafting curve `target` at MODEL point `at`."""
    b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
    try:
        b.Characteristic = characteristic(char)
        b.FrameStyle = A.FeatureControlFrameBuilder.FcfFrameStyle.SingleFrame
        b.FeatureControlFrameDataList.Append(dwg.Annotations.CreateFeatureControlFrameDataBuilder(None))
        d = b.FeatureControlFrameDataList.FindItem(0)
        if dia:
            d.ZoneShape = A.FeatureControlFrameDataBuilder.ToleranceZoneShape.Diameter
        d.ToleranceValue = str(tol)
        if mmc:
            try:
                d.MaterialModifier = A.FeatureControlFrameDataBuilder.ToleranceMaterialModifier.MaximumMaterialCondition
            except Exception:  # noqa: BLE001
                pass
        refs = (d.PrimaryDatumReference, d.SecondaryDatumReference, d.TertiaryDatumReference)
        for r, letter in zip(refs, datums):
            r.Letter = letter
        b.Style.LetteringStyle.GeneralTextSize = float(size)
        if target is not None:
            nxd2._leader(dwg, b.Leader, target, view, at)
        b.Origin.Origin.SetValue(None, None, P(pos[0], pos[1], 0.0))
        o = b.Commit()
    finally:
        b.Destroy()
    return o


def datum(dwg, letter, pos, target, view, at, size=4.0):
    """Datum feature symbol (letter in a box, triangle on the feature) with a leader to `target` at MODEL `at`."""
    b = dwg.Annotations.Datums.CreateDraftingDatumFeatureSymbolBuilder(None)
    try:
        b.Letter = letter
        try:
            b.Style.LetteringStyle.GeneralTextSize = float(size)
        except Exception:  # noqa: BLE001
            pass
        ld = dwg.Annotations.CreateLeaderData()
        ld.StubSize = 0.0
        b.Leader.Leaders.Append(ld)
        ld.Leader.SetValue(target, view, P(*at))
        b.Origin.Origin.SetValue(None, None, P(pos[0], pos[1], 0.0))
        o = b.Commit()
    finally:
        b.Destroy()
    return o


def balloon(dwg, text, pos, target, view, at, size=11.0, text_size=4.5):
    """Circle balloon at sheet pos, leader with a filled ARROW to `target` at MODEL point `at`."""
    b = dwg.Annotations.IdSymbols.CreateIdSymbolBuilder(A.IdSymbol.Null)
    try:
        b.Type = A.IdSymbolBuilder.SymbolTypes.Circle
        b.UpperText = str(text)
        b.Size = float(size)
        try:
            b.Style.LetteringStyle.GeneralTextSize = float(text_size)
        except Exception:  # noqa: BLE001
            pass
        nxd2._leader(dwg, b.Leader, target, view, at, "filled_arrow")
        b.Origin.Origin.SetValue(None, None, P(pos[0], pos[1], 0.0))
        o = b.Commit()
    finally:
        b.Destroy()
    return o


def make_basic(d):
    """Turn an existing dimension into a basic (boxed, theoretically exact) dimension."""
    b = d.OwningPart.Dimensions.CreateLinearDimensionBuilder(d) if "Linear" in type(d).__name__ or "Horizontal" in type(d).__name__ \
        else None
    if b is None:
        raise RuntimeError("make_basic: unsupported %s" % type(d).__name__)
    try:
        b.Style.DimensionStyle.ToleranceType = A.ToleranceType.Basic
        b.Commit()
    finally:
        b.Destroy()
    return d
