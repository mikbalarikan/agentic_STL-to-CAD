"""Left Thigh INNER shell (LT-INN-001) - native NX rebuild from the registered scan.  args: out_dir [stop_stage]
Frame = LT-OUT-001 frame: origin on the knee axis at the outer's knee floor, Z = knee axis (+Z = away from the outer;
the inner's open side faces -Z), Y = hip-axis direction. The inner sits on top of the outer (lip z 35.20).
Stages: A envelope (skin loft + knee hub revolve), B cavity tool, C plateaus + shell + lip trim + rebate,
D hip-ring clearance, E knee bore and holes, F bosses and pin lugs, G windows, H seam grooves.
Every number comes from nx/params.json and work/*.json (scan analysis, see an/)."""
import os, sys, json, math, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, curvekit as ck, nxre

OUT = sys.argv[1]
STOP = sys.argv[2] if len(sys.argv) > 2 else "Z"
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
WK = os.path.join(ROOT, "work")
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": [], "checks": {}}
T0 = time.time()


def log(msg):
    res["log"].append(f"[{time.time()-T0:6.0f}s] {msg}")
    nxh.write_json(os.path.join(OUT, "build.json"), res)


P = json.load(open(os.path.join(ROOT, "nx", "params.json")))


# ------------------------------------------------------------------ helpers
def loft_sheet(part, jsonfile, ymin=-1e9):
    sec = [s for s in json.load(open(os.path.join(WK, jsonfile)))["sections"] if s["y"] >= ymin]
    sps = []
    for s in sec:
        f, sp = ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True)
        sps.append(sp)
    tc = nxf.through_curves(part, [nxh.section(part, curves=[sp]) for sp in sps], solid=False)
    return tc, tc.GetBodies()[0], sps


def block_trimmed(part, sheet, name, y0, y1, z0, z1):
    """Block trimmed by the loft sheet, keeping the inside. The kept side depends on the sheet normal (the inner's
    sections run the other way round from the outer's): try one side, if the outside was kept start over."""
    for rev in (False, True):
        bf, blk = nxh.block(part, (-130.0, y0, z0), (320.0, y1 - y0, z1 - z0))
        v0 = nxh.volume(part, blk)
        nxf.trim_body(part, blk, reverse=rev, sheet=sheet)
        v1 = nxh.volume(part, blk)
        if v1 < 0.5 * v0:
            return blk, v1
        log(f"{name}: trim reverse={rev} kept the outside ({v1:.0f} of {v0:.0f}); other side")
        nxf.delete_body(part, [blk])
    raise RuntimeError(f"{name}: trim kept the outside both ways")


def seg_curves(part, segs, z):
    cs = []
    for s in segs:
        if s[0] == "L":
            cs.append(nxh.line(part, (s[1][0], s[1][1], z), (s[2][0], s[2][1], z)))
        else:
            p0, p1, c, r, ccw = s[1], s[2], s[3], s[4], s[5]
            a0 = math.atan2(p0[1] - c[1], p0[0] - c[0]); a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
            if not ccw:
                a0, a1 = a1, a0
            while a1 <= a0:
                a1 += 2 * math.pi
            cs.append(nxh.arc(part, (c[0], c[1], z), (1, 0, 0), (0, 1, 0), r, a0, a1))
    return cs


def seg_curves_yz(part, segs, x):
    cs = []
    for s_ in segs:
        if s_[0] == "L":
            cs.append(nxh.line(part, (x, s_[1][0], s_[1][1]), (x, s_[2][0], s_[2][1])))
        else:
            p0, p1, c, r, ccw = s_[1], s_[2], s_[3], s_[4], s_[5]
            a0 = math.atan2(p0[1] - c[1], p0[0] - c[0]); a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
            if not ccw:
                a0, a1 = a1, a0
            while a1 <= a0:
                a1 += 2 * math.pi
            cs.append(nxh.arc(part, (x, c[0], c[1]), (0, 1, 0), (0, 0, 1), r, a0, a1))
    return cs


def extrude_curves(part, curves, vec, start, end, hp=(0, 0, 0)):
    f = nxh.extrude(part, nxh.section(part, curves=curves, help_point=hp), vec, start, end)
    return f, f.GetBodies()


def clip_unite(part, body, tools, envx):
    pieces = []
    for t in tools:
        f = nxh.intersect(part, t, [envx], check=False, keep_tool=True)
        pieces += [b for b in f.GetBodies() if b.IsSolidBody]
    if pieces:
        nxh.unite(part, body, pieces, check=False)
    return len(pieces)


def sector_curves(part, r0, r1, a0, a1, z):
    A0, A1 = math.radians(a0), math.radians(a1)
    c = [nxh.arc(part, (0, 0, z), (1, 0, 0), (0, 1, 0), r1, A0, A1),
         nxh.line(part, (r1 * math.cos(A1), r1 * math.sin(A1), z), (r0 * math.cos(A1), r0 * math.sin(A1), z))]
    if r0 > 0:
        c.append(nxh.arc(part, (0, 0, z), (1, 0, 0), (0, 1, 0), r0, A0, A1))
        c.append(nxh.line(part, (r0 * math.cos(A0), r0 * math.sin(A0), z), (r1 * math.cos(A0), r1 * math.sin(A0), z)))
    else:
        c.append(nxh.line(part, (0, 0, z), (r1 * math.cos(A0), r1 * math.sin(A0), z)))
    return c


def circ3(p0, p1, p2):
    (x1, y1), (x2, y2), (x3, y3) = p0, p1, p2
    d = 2 * (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2))
    ux = ((x1 * x1 + y1 * y1) * (y2 - y3) + (x2 * x2 + y2 * y2) * (y3 - y1) + (x3 * x3 + y3 * y3) * (y1 - y2)) / d
    uy = ((x1 * x1 + y1 * y1) * (x3 - x2) + (x2 * x2 + y2 * y2) * (x1 - x3) + (x3 * x3 + y3 * y3) * (x2 - x1)) / d
    return (ux, uy), math.hypot(x1 - ux, y1 - uy)


def revolve_profile(part, prof, op=None, target=None, a0=0.0, a1=360.0):
    """Closed (r, z) profile in the XZ plane (r along +X) with optional ["arc", r_mid, z_mid] entries, revolved
    360 deg about the knee axis."""
    cs, pts, i = [], [], 0
    seq = []
    for p in prof:
        seq.append(p)
    n = len(seq)
    k = 0
    while k < n:
        a = seq[k]
        b = seq[(k + 1) % n]
        if b[0] == "arc":
            c_ = seq[(k + 2) % n]
            (cx, cz), r = circ3((a[0], a[1]), (b[1], b[2]), (c_[0], c_[1]))
            a0 = math.atan2(a[1] - cz, a[0] - cx); a1 = math.atan2(c_[1] - cz, c_[0] - cx)
            am = math.atan2(b[2] - cz, b[1] - cx)
            # choose the sweep that passes the mid point
            def inside(lo, hi, x):
                while hi < lo: hi += 2 * math.pi
                while x < lo: x += 2 * math.pi
                return x <= hi
            if inside(a0, a1, am):
                lo, hi = a0, a1
            else:
                lo, hi = a1, a0
            while hi <= lo: hi += 2 * math.pi
            cs.append(nxh.arc(part, (cx, 0.0, cz), (1, 0, 0), (0, 0, 1), r, lo, hi))
            k += 2
        else:
            cs.append(nxh.line(part, (a[0], 0.0, a[1]), (b[0], 0.0, b[1])))
            k += 1
    sec = nxh.section(part, curves=cs, help_point=(prof[0][0], 0.0, prof[0][1]))
    return nxf.revolve(part, sec, nxh.axis(part, (0, 0, 0), (0, 0, 1)), a0, a1, op=op, target=target)


def group_section_curves(part, g, z, holes=True):
    cs = seg_curves(part, g["outer"], z)
    if holes:
        for h in g.get("holes", []):
            cs += seg_curves(part, h, z)
    return cs


def check(name, ok, value=None):
    res["checks"][name] = {"ok": bool(ok), "value": value}
    if not ok:
        log(f"CHECK FAILED {name}: {value}")


def largest_only(part, keep_tags=()):
    nb = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and b.Tag not in keep_tags]
    nb.sort(key=lambda b_: -nxh.volume(part, b_))
    if len(nb) > 1:
        nxf.delete_body(part, nb[1:])
    return nb[0], len(nb) - 1


# ------------------------------------------------------------------ build
part = None
body = None
try:
    part = nxh.new_part(os.path.join(OUT, "Left_Thigh_Inner.prt"))
    for k, v in P["expressions"].items():
        nxh.expr(part, k, v[0], v[1], v[2] if len(v) > 2 else "")
    SB = P["skin_block"]; H = P["hub"]; LV = P["levels"]

    # ---- A: envelope
    tc, skin, _ = loft_sheet(part, "sections.json")
    body, v = block_trimmed(part, skin, "skin", SB["y0"], SB["y1"], SB["z0"], SB["z1"])
    log(f"A skin loft area {nxh.sheet_area(part, skin)[0]:.0f}; skin solid {v:.0f}")
    fs, (sect,) = extrude_curves(part, sector_curves(part, H["r_out"], 400.0, H["round_a0"], H["round_a1"], 20.0), (0, 0, 1), 0, 150)
    nxh.subtract(part, body, [sect], check=False)
    fc, cyl = nxh.cylinder(part, (0.0, 0.0, 20.0), (0, 0, 1), 2 * H["r_out"], 150.0)
    nxh.subtract(part, body, [cyl], check=False)
    body, nd = largest_only(part)
    if nd: log(f"A deleted {nd} leftover skin pieces")
    revolve_profile(part, H["profile_rz"], op=BOOL.Unite, target=body)
    log(f"A hub revolve united; body {nxh.volume(part, body):.0f}")
    # 45 deg chamfer of the knee face where the hub is exposed (scan: from 110 deg round to 330 deg); a revolved
    # cutter limited to r <= r_out, so the leg skin beyond the hub is not touched (an edge chamfer was refused)
    c_ = H["chamfer"]; ro = H["r_out"] + 0.01; zt = H["top_z"]
    cut_prof = [[ro - c_ - 0.01, zt], [ro, zt - c_ - 0.01], [ro, zt + 1.0], [ro - c_ - 0.01, zt + 1.0]]
    f, err = nxf._try_feature(lambda: revolve_profile(part, cut_prof, op=BOOL.Subtract, target=body, a0=H["chamfer_a0"], a1=H["chamfer_a1"]))
    log(f"A knee-face chamfer {c_} x 45 deg, {H['chamfer_a0']}..{H['chamfer_a1']} deg: {'ok' if f is not None else err}; body {nxh.volume(part, body):.0f}")
    venv = nxh.volume(part, body)
    check("A envelope single solid", len([b for b in part.Bodies if b.IsSolidBody]) == 1)
    ef, (envx,) = nxf.extract_body(part, [body])
    envx.Blank()
    log(f"A envelope {venv:.0f}")
    if STOP == "A": raise StopIteration

    # ---- B: cavity tool
    tci, isheet, _ = loft_sheet(part, "inner_sections.json", ymin=-30.0)
    cav, vc = block_trimmed(part, isheet, "inner", -29.0, SB["y1"] + 5.0, SB["z0"] - 5.0, SB["z1"])
    log(f"B cavity (inner skin) {vc:.0f}")
    # inside the knee circle the cavity is the hub cylinder only (the loft is not measured there)
    fcc, cc_ = nxh.cylinder(part, (0.0, 0.0, H["cav_top"]), (0, 0, 1), 2 * H["r_out"], 100.0)
    nxh.subtract(part, cav, [cc_], check=False)
    hc, hubcav = nxh.cylinder(part, (0.0, 0.0, 20.0), (0, 0, 1), 2 * H["r_in"], H["cav_top"] - 20.0)
    fs2, (sec2,) = extrude_curves(part, sector_curves(part, 0.0, H["open_r"], H["open_a0"], H["open_a1"], 20.0), (0, 0, 1), 0, H["cav_top"] - 20.0)
    nxh.unite(part, cav, [hubcav, sec2], check=False)
    log(f"B cavity tool {nxh.volume(part, cav):.0f}")
    if STOP == "B": raise StopIteration

    # ---- C: plateaus (material from level h up to the skin) taken out of the cavity tool
    plats = json.load(open(os.path.join(WK, "plateaus_nx.json")))
    tools = []
    for L in plats:
        h = L["h"]
        for g in L["groups"]:
            try:
                cs = group_section_curves(part, g, h)
                f, bodies = extrude_curves(part, cs, (0, 0, 1), 0, 200.0 - h, hp=tuple(g["outer"][0][1]) + (h,))
                tools.extend([b for b in bodies if b.IsSolidBody])
            except Exception as e:  # noqa: BLE001
                try:
                    cs = group_section_curves(part, g, h, holes=False)
                    f, bodies = extrude_curves(part, cs, (0, 0, 1), 0, 200.0 - h, hp=tuple(g["outer"][0][1]) + (h,))
                    tools.extend([b for b in bodies if b.IsSolidBody])
                    log(f"C level {h} group area {g['area']:.0f}: holes dropped ({e})")
                except Exception as e2:  # noqa: BLE001
                    log(f"C level {h} group area {g['area']:.0f}: extrude failed {e2}")
    v0 = nxh.volume(part, cav)
    try:
        nxh.subtract(part, cav, tools, check=False)
    except Exception as e:  # noqa: BLE001
        log(f"C one-shot subtract failed ({e}); per tool")
        for t in tools:
            try:
                nxh.subtract(part, cav, [t], check=False)
            except Exception as e2:  # noqa: BLE001
                log(f"C tool skipped: {e2}")
                nxf.delete_body(part, [t])
    cavs = [b for b in part.Bodies if b.IsSolidBody and b.Tag not in (body.Tag, envx.Tag)]
    log(f"C cavity {v0:.0f} -> {sum(nxh.volume(part, b) for b in cavs):.0f} in {len(cavs)} pieces")
    nxh.subtract(part, body, cavs, check=False)
    body, nd = largest_only(part, keep_tags=(envx.Tag,))
    log(f"C shell {nxh.volume(part, body):.0f} (dropped {nd} pieces)")
    lip = LV["lip"]
    nxh.block(part, (-150.0, -80.0, -100.0), (350.0, 400.0, 100.0 + lip), op=BOOL.Subtract, target=body)
    log(f"C trimmed at the lip z {lip}: {nxh.volume(part, body):.0f}")
    rb = json.load(open(os.path.join(WK, "rebate_nx.json")))
    rtools = []
    for g in rb["groups"]:
        try:
            f, bodies = extrude_curves(part, seg_curves(part, g["outer"], lip - 1.0), (0, 0, 1), 0, rb["z1"] - lip + 1.0,
                                       hp=tuple(g["outer"][0][1]) + (lip - 1.0,))
            rtools += [b for b in bodies if b.IsSolidBody]
        except Exception as e:  # noqa: BLE001
            log(f"C rebate group area {g['area']:.0f} failed: {e}")
    nxh.subtract(part, body, rtools, check=False)
    log(f"C rebate ({len(rtools)} tools) to z {rb['z1']}: {nxh.volume(part, body):.0f}")
    fl2, (lw,) = extrude_curves(part, sector_curves(part, H["r_in"] - 3.0, H["r_out"] + 10.0, H["low_a0"], H["low_a1"], 20.0), (0, 0, 1), 0, H["low_z"] - 20.0)
    nxh.subtract(part, body, [lw], check=False)
    log(f"C hub low wall (z < {H['low_z']} in {H['low_a0']}..{H['low_a1']} deg); body {nxh.volume(part, body):.0f}")
    if STOP == "C": raise StopIteration

    # ---- D: clearance for the outer's hip ring (OD, between its plate faces, below its flat top)
    hp = P["hip"]
    fh, rc = nxh.cylinder(part, (hp["ax_x"], hp["y0"], hp["ax_z"]), (0, 1, 0), hp["ring_od"], hp["y1"] - hp["y0"])
    nxh.block(part, (-100.0, hp["y0"] - 1.0, hp["seat_z"]), (300.0, hp["y1"] - hp["y0"] + 2.0, 100.0), op=BOOL.Subtract, target=rc)
    nxh.subtract(part, body, [rc], check=False)
    log(f"D hip-ring clearance; body {nxh.volume(part, body):.0f}")
    if STOP == "D": raise StopIteration

    # ---- E: knee bore and holes
    nxh.cylinder(part, (0.0, 0.0, 60.0), (0, 0, 1), H["bore_d"], 50.0, op=BOOL.Subtract, target=body)
    tools = []
    kr = P["knee_ring_holes"]
    for k in range(kr["n"]):
        a = math.radians(kr["clock"] + k * 360.0 / kr["n"])
        tools.append(nxh.cylinder(part, (kr["pcd"] / 2 * math.cos(a), kr["pcd"] / 2 * math.sin(a), kr["z0"] - 0.5), (0, 0, 1), kr["d"], kr["z1"] - kr["z0"] + 1.5)[1])
    for h in P["channel_holes"]:
        tools.append(nxh.cylinder(part, (h["x"], h["y"], h["z0"] - 0.5), (0, 0, 1), h["d"], h["depth"] + 0.5)[1])
    sl = P["disc_slot"]
    r_ = sl["w"] / 2; yc0 = sl["y"] - (sl["l"] - sl["w"]) / 2; yc1 = sl["y"] + (sl["l"] - sl["w"]) / 2; z_ = sl["z0"]
    scs = [nxh.arc(part, (sl["x"], yc1, z_), (1, 0, 0), (0, 1, 0), r_, 0.0, math.pi),
           nxh.line(part, (sl["x"] - r_, yc1, z_), (sl["x"] - r_, yc0, z_)),
           nxh.arc(part, (sl["x"], yc0, z_), (1, 0, 0), (0, 1, 0), r_, math.pi, 2 * math.pi),
           nxh.line(part, (sl["x"] + r_, yc0, z_), (sl["x"] + r_, yc1, z_))]
    f, bodies = extrude_curves(part, scs, (0, 0, 1), 0, sl["z1"] - sl["z0"], hp=(sl["x"] + r_, sl["y"], z_))
    tools += [b_ for b_ in bodies if b_.IsSolidBody]
    if tools:
        nxh.subtract(part, body, tools, check=False)
    log(f"E knee bore + {len(tools)} holes; body {nxh.volume(part, body):.0f}")
    if STOP == "E": raise StopIteration

    # ---- G: wall windows / notches (profiles in the YZ or XZ plane), cut outward
    wf = os.path.join(WK, "windows.json")
    for w in [w for w in (json.load(open(wf)) if os.path.exists(wf) else []) if w["y"][1] - w["y"][0] > 20.0]:
        x0 = w["x_inner_limit"]
        cs = seg_curves_yz(part, w["segs"], x0)
        vec = (-1, 0, 0) if w["side"] == "L" else (1, 0, 0)
        f, bodies = extrude_curves(part, cs, vec, 0, 120.0, hp=(x0, w["segs"][0][1][0], w["segs"][0][1][1]))
        nxh.subtract(part, body, bodies, check=False)
    log(f"G windows; body {nxh.volume(part, body):.0f}")
    if STOP == "G": raise StopIteration  # (windows run before the bosses, which are refilled up to the skin)

    # ---- F: boss columns (face z 35.95) and pin lugs, then pockets / holes / counterbores
    bt = []
    for b in P["bosses"]:
        f, cb = nxh.cylinder(part, (b["x"], b["y"], b["top_z"]), (0, 0, 1), b["col_d"], 130.0 - b["top_z"])
        bt.append(cb)
    for p in P["pins"]:
        f, pb = nxh.cylinder(part, (p["x"], p["y"], p["z0"]), (0, 0, 1), p["lug_d"], 130.0 - p["z0"])
        bt.append(pb)
    n = clip_unite(part, body, bt, envx)
    log(f"F {n} boss/lug columns clipped to the envelope; body {nxh.volume(part, body):.0f}")
    tools = []
    for b in P["bosses"]:
        tools.append(nxh.cylinder(part, (b["x"], b["y"], b["top_z"] - 1.0), (0, 0, 1), b["pocket_d"], b["pocket_z1"] - b["top_z"] + 1.0)[1])
        tools.append(nxh.cylinder(part, (b["x"], b["y"], b["pocket_z1"] - 0.5), (0, 0, 1), b["hole_d"], b["web_z1"] - b["pocket_z1"] + 1.0)[1])
        tools.append(nxh.cylinder(part, (b["x"], b["y"], b["web_z1"]), (0, 0, 1), b["cb_d"], 130.0 - b["web_z1"])[1])
    for p in P["pins"]:
        tools.append(nxh.cylinder(part, (p["x"], p["y"], p["z0"] - 1.0), (0, 0, 1), p["hole_d"], p["z1"] - p["z0"] + 1.0)[1])
    nxh.subtract(part, body, tools, check=False)
    log(f"F pockets / holes / counterbores; body {nxh.volume(part, body):.0f}")
    if STOP == "F": raise StopIteration

    # ---- H: seam grooves (cosmetic styling lines): tube along a spline on the skin, subtracted
    gf = os.path.join(WK, "grooves.json")
    if os.path.exists(gf):
        gr = json.load(open(gf))
        for name, gp in gr["paths"].items():
            try:
                f, sp = ck.studio_spline(part, [tuple(p) for p in gp["pts"]], degree=3)
                tf, tb = nxf.tube(part, gp.get("tube_d", gr["tube_d"]), "0", curves=[sp])
                nxh.subtract(part, body, [tb], check=False)
                log(f"H groove {name}: ok, body {nxh.volume(part, body):.0f}")
            except Exception as e:  # noqa: BLE001
                log(f"H groove {name} failed: {e}")
    raise StopIteration
except StopIteration:
    pass
except Exception:
    res["error"] = traceback.format_exc()
    log("ERROR")
try:
    sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
    res["solids"] = [round(nxh.volume(part, b), 1) for b in sol]
    res["body_ok"] = [nxh.body_ok(part, b) for b in sol]
    res["feature_errors"] = [str(e) for e in nxh.feature_errors(part)][:20]
    if sol:
        big = max(sol, key=lambda b: nxh.volume(part, b))
        try:
            res["bbox"] = [round(x, 3) for x in nxh.bbox(part, big)]
        except Exception:
            pass
        nxre.stl_export(part, big, os.path.join(OUT, f"inner_{STOP}.stl"), chord=0.01, max_edge=2.0)
    nxh.save(part)
    if "error" not in res:
        res["result"] = "PASS"
except Exception:
    res["error_final"] = traceback.format_exc()
res["t"] = round(time.time() - T0, 1)
nxh.write_json(os.path.join(OUT, "build.json"), res)
