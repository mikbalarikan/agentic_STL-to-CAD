"""Left Thigh (outer shell) - native NX rebuild from the scan.  args: out_dir [stop_stage]
Frame: origin on the knee axis at the knee-floor plane, Z = knee axis (open side up), Y = hip-axis direction.
Stages: A envelope+hub, B shell (cavity), C plateaus (ribs/bosses/pads/tongue), D hip plate+ring, E bores and
hole patterns, F bosses/pins/small holes. Every number comes from work/*.json (scan analysis, see an/)."""
import os, sys, json, math, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, curvekit as ck, nxre

OUT = sys.argv[1]
STOP = sys.argv[2] if len(sys.argv) > 2 else "Z"
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
WK = os.path.join(ROOT, "work")
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": [], "checks": {}}
T0 = time.time()


def log(msg):
    res["log"].append(f"[{time.time()-T0:6.0f}s] {msg}")
    nxh.write_json(os.path.join(OUT, "build.json"), res)


P = json.load(open(os.path.join(ROOT, "nx", "params.json")))


# ------------------------------------------------------------------ helpers
def bs_eval(knots, poles, u):
    k = 3; n = len(poles)
    i = n - 1 if u >= knots[n] else max(j for j in range(k, n) if knots[j] <= u)
    d = [list(poles[j]) for j in range(i - k, i + 1)]
    for r in range(1, k + 1):
        for j in range(k, r - 1, -1):
            a = (u - knots[j + i - k]) / (knots[j + 1 + i - r] - knots[j + i - k])
            d[j] = [(1 - a) * d[j - 1][c] + a * d[j][c] for c in range(3)]
    return d[k]


def loft_sheet(part, jsonfile, ymin=-1e9):
    sec = [s for s in json.load(open(os.path.join(WK, jsonfile)))["sections"] if s["y"] >= ymin]
    sps = []
    for s in sec:
        f, sp = ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True)
        sps.append(sp)
    tc = nxf.through_curves(part, [nxh.section(part, curves=[sp]) for sp in sps], solid=False)
    return tc, tc.GetBodies()[0], sps


def block_trimmed(part, sheet, name, y0=-69.0):
    bf, blk = nxh.block(part, (-130.0, y0, -70.0), (320.0, 287.4 - y0, 114.0))
    v0 = nxh.volume(part, blk)
    nxf.trim_body(part, blk, reverse=True, sheet=sheet)
    v1 = nxh.volume(part, blk)
    if v1 > 0.5 * v0:
        raise RuntimeError(f"{name}: trim kept the outside")
    return blk, v1


def seg_curves(part, segs, z):
    cs = []
    for s in segs:
        if s[0] == "L":
            cs.append(nxh.line(part, (s[1][0], s[1][1], z), (s[2][0], s[2][1], z)))
        else:
            p0, p1, c, r, ccw = s[1], s[2], s[3], s[4], s[5]
            a0 = math.atan2(p0[1] - c[1], p0[0] - c[0]); a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
            if not ccw:
                a0, a1 = a1, a0
            while a1 <= a0:
                a1 += 2 * math.pi
            cs.append(nxh.arc(part, (c[0], c[1], z), (1, 0, 0), (0, 1, 0), r, a0, a1))
    return cs


def seg_curves_yz(part, segs, x):
    """Segments given in (y, z) -> curves in the plane X = x."""
    cs = []
    for s_ in segs:
        if s_[0] == "L":
            cs.append(nxh.line(part, (x, s_[1][0], s_[1][1]), (x, s_[2][0], s_[2][1])))
        else:
            p0, p1, c, r, ccw = s_[1], s_[2], s_[3], s_[4], s_[5]
            a0 = math.atan2(p0[1] - c[1], p0[0] - c[0]); a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
            if not ccw:
                a0, a1 = a1, a0
            while a1 <= a0:
                a1 += 2 * math.pi
            cs.append(nxh.arc(part, (x, c[0], c[1]), (0, 1, 0), (0, 0, 1), r, a0, a1))
    return cs


def poly_curves(part, pts, z=None, plane="xy"):
    return nxh.polyline(part, pts, closed=True)


def extrude_curves(part, curves, vec, start, end, hp=(0, 0, 0)):
    f = nxh.extrude(part, nxh.section(part, curves=curves, help_point=hp), vec, start, end)
    return f, f.GetBodies()


def clip_unite(part, body, tools, envx, label):
    """Intersect each tool body with a kept copy of the envelope, unite the pieces into body."""
    pieces = []
    for t in tools:
        f = nxh.intersect(part, t, [envx], check=False, keep_tool=True)
        pieces += [b for b in f.GetBodies() if b.IsSolidBody]
    if pieces:
        nxh.unite(part, body, pieces, check=False)
    return len(pieces)


def sector_curves(part, r0, r1, a0, a1, z):
    """Closed annular sector (degrees, ccw a0->a1) at height z."""
    A0, A1 = math.radians(a0), math.radians(a1)
    c = []
    c.append(nxh.arc(part, (0, 0, z), (1, 0, 0), (0, 1, 0), r1, A0, A1))
    c.append(nxh.line(part, (r1 * math.cos(A1), r1 * math.sin(A1), z), (r0 * math.cos(A1), r0 * math.sin(A1), z)))
    if r0 > 0:
        c.append(nxh.arc(part, (0, 0, z), (1, 0, 0), (0, 1, 0), r0, A0, A1))
        c.append(nxh.line(part, (r0 * math.cos(A0), r0 * math.sin(A0), z), (r1 * math.cos(A0), r1 * math.sin(A0), z)))
    else:
        c.append(nxh.line(part, (0, 0, z), (r1 * math.cos(A0), r1 * math.sin(A0), z)))
    return c


def revolve_rz(part, pts_rz, axis_origin, axis_dir, radial_dir, op, target):
    """Closed (r, axial) polygon in the plane spanned by radial_dir and axis_dir, revolved 360 deg."""
    o = axis_origin
    P3 = [tuple(o[k] + r * radial_dir[k] + a * axis_dir[k] for k in range(3)) for r, a in pts_rz]
    cs = nxh.polyline(part, P3, closed=True)
    hp = P3[0]
    return nxf.revolve(part, nxh.section(part, curves=cs, help_point=hp), nxh.axis(part, o, axis_dir), 0, 360, op=op, target=target)


def check(name, ok, value=None):
    res["checks"][name] = {"ok": bool(ok), "value": value}
    if not ok:
        log(f"CHECK FAILED {name}: {value}")


# ------------------------------------------------------------------ build
part = None
try:
    part = nxh.new_part(os.path.join(OUT, "Left_Thigh_Outer.prt"))
    for k, v in P["expressions"].items():
        nxh.expr(part, k, v[0], v[1], v[2] if len(v) > 2 else "")

    # ---- A: envelope
    tc, skin, _ = loft_sheet(part, "sections.json")
    body, v = block_trimmed(part, skin, "skin", y0=-69.0)
    log(f"A skin loft area {nxh.sheet_area(part, skin)[0]:.0f}; skin solid {v:.0f}")
    H = P["hub"]
    # round knee end: skin removed outside the hub cylinder (sector) and inside it
    fs, (sect,) = extrude_curves(part, sector_curves(part, H["r_out"], 400.0, H["round_a0"], H["round_a1"], -90.0), (0, 0, 1), 0, 200)
    nxh.subtract(part, body, [sect])
    fc, cyl = nxh.cylinder(part, (0.0, 0.0, -90.0), (0, 0, 1), 2 * H["r_out"], 200.0)
    nxh.subtract(part, body, [cyl], check=False)
    nb = [b_ for b_ in part.Bodies if b_.IsSolidBody]
    if len(nb) > 1:
        nb.sort(key=lambda b_: -nxh.volume(part, b_))
        body = nb[0]
        nxf.delete_body(part, nb[1:])
        log(f"A deleted {len(nb)-1} leftover skin pieces")
    # knee +x corner: the loft is replaced by the revolved wrap (axisymmetric about the knee axis there)
    WR = P["wrap"]
    a0, a1 = WR["a0"], WR["a1"]
    fs, (ct,) = extrude_curves(part, sector_curves(part, H["r_out"] - 0.3, 150.0, a0, a1, -90.0), (0, 0, 1), 0, 200)
    nxh.subtract(part, body, [ct], check=False)
    prof = [tuple(p) for p in WR["profile_rz"]]
    pts3 = [(r, 0.0, z) for r, z in prof]
    f_sp, sp = ck.studio_spline(part, pts3, degree=3)
    c0 = nxh.line(part, (WR["r_in"], 0.0, prof[0][1]), pts3[0])
    c1 = nxh.line(part, pts3[-1], (pts3[-1][0], 0.0, WR["z_top"]))
    c2 = nxh.line(part, (pts3[-1][0], 0.0, WR["z_top"]), (WR["r_in"], 0.0, WR["z_top"]))
    c3 = nxh.line(part, (WR["r_in"], 0.0, WR["z_top"]), (WR["r_in"], 0.0, prof[0][1]))
    sec_w = nxh.section(part, curves=[c0, sp, c1, c2, c3], help_point=(WR["r_in"], 0.0, prof[0][1]))
    fw = nxf.revolve(part, sec_w, nxh.axis(part, (0, 0, 0), (0, 0, 1)), a0, a1)
    wrap = fw.GetBodies()[0]
    nxh.unite(part, body, [wrap], check=False)
    log(f"A knee wrap revolve {a0}..{a1} deg united; body {nxh.volume(part, body):.0f}")
    rev = revolve_rz(part, H["outer_profile_rz"], (0, 0, 0), (0, 0, 1), (1, 0, 0), BOOL.Unite, body)
    venv = nxh.volume(part, body)
    log(f"A envelope (skin + hub) {venv:.0f}")
    check("A envelope single solid", len([b for b in part.Bodies if b.IsSolidBody]) == 1)
    ef, (envx,) = nxf.extract_body(part, [body])
    envx.Blank()
    if STOP == "A": raise StopIteration

    # ---- B: cavity tool
    tci, isheet, _ = loft_sheet(part, "inner_sections.json", ymin=-30.0)
    cav, vc = block_trimmed(part, isheet, "inner", y0=-29.0)
    log(f"B cavity (inner skin) {vc:.0f}")
    hc, hubcav = nxh.cylinder(part, (0.0, 0.0, 0.0), (0, 0, 1), 2 * H["r_in"], 60.0)
    fs2, (sec2,) = extrude_curves(part, sector_curves(part, 0.0, H["open_r"], H["open_a0"], H["open_a1"], 0.0), (0, 0, 1), 0, 60)
    nxh.unite(part, cav, [hubcav, sec2], check=False)
    hp = P["hip"]
    bf, slab = nxh.block(part, (-150.0, hp["y_plate_in"], -90.0), (350.0, hp["y_plate_out"] - hp["y_plate_in"], 200.0))
    nxh.subtract(part, cav, [slab], check=False)
    log(f"B cavity tool {nxh.volume(part, cav):.0f}")
    if STOP == "B": raise StopIteration

    # ---- C: plateaus (ribs, floors, pads) are taken out of the cavity tool; tall ones added after the rim trim
    plats = json.load(open(os.path.join(WK, "plateaus_nx.json")))
    rim = P["levels"]["rim"]
    low_tools, tall_tools = [], []
    for L in plats:
        h = L["h"]
        for g in L["groups"]:
            cs = seg_curves(part, g["outer"], -80.0)
            try:
                f, bodies = extrude_curves(part, cs, (0, 0, 1), 0, h + 80.0, hp=tuple(g["outer"][0][1]) + (-80.0,))
                (tall_tools if h > rim else low_tools).extend([b for b in bodies if b.IsSolidBody])
            except Exception as e:  # noqa: BLE001
                log(f"C level {h} group area {g['area']:.0f}: extrude failed {e}")
    fcf, fl = nxh.cylinder(part, (0.0, 0.0, -30.0), (0, 0, 1), 2 * H["r_in"] + 0.2, 30.0)
    fw, (wl,) = extrude_curves(part, sector_curves(part, H["r_in"], H["r_out"] + 1.0, H["round_a0"], H["round_a1"], -30.0), (0, 0, 1), 0, 30.0 + rim + 5.0)
    low_tools += [fl, wl]
    for pr in P.get("prisms", []):
        pts = pr["pts"]; a = pr["at"]
        if pr["plane"] == "yz":
            P3 = [(a, u, w) for u, w in pts]; vec = (1, 0, 0)
        elif pr["plane"] == "xz":
            P3 = [(u, a, w) for u, w in pts]; vec = (0, 1, 0)
        else:
            P3 = [(u, w, a) for u, w in pts]; vec = (0, 0, 1)
        f = nxh.extrude(part, nxh.section(part, curves=nxh.polyline(part, P3, closed=True), help_point=P3[0]), vec, 0, pr["t"])
        bl = [b for b in f.GetBodies() if b.IsSolidBody]
        (tall_tools if pr["tall"] else low_tools).extend(bl)
        log(f"C prism {pr['name']}: {len(bl)} body")
    for rp in P.get("ramp_ribs", []):
        pts = rp["yz"]
        segs = [["L", pts[i], pts[(i + 1) % len(pts)]] for i in range(len(pts))]
        f, bodies = extrude_curves(part, seg_curves_yz(part, segs, rp["x0"]), (1, 0, 0), 0, rp["t"], hp=(rp["x0"], pts[0][0], pts[0][1]))
        low_tools += [b for b in bodies if b.IsSolidBody]
    tall_tags = {b.Tag for b in tall_tools}
    v0 = nxh.volume(part, cav)
    try:
        nxh.subtract(part, cav, low_tools, check=False)
    except Exception as e:  # noqa: BLE001
        log(f"C one-shot subtract failed ({e}); per tool")
        for t in low_tools:
            try:
                nxh.subtract(part, cav, [t], check=False)
            except Exception as e2:  # noqa: BLE001
                log(f"C tool skipped: {e2}")
                nxf.delete_body(part, [t])
    cavs = [b for b in part.Bodies if b.IsSolidBody and b.Tag not in (body.Tag, envx.Tag) and b.Tag not in tall_tags]
    log(f"C cavity {v0:.0f} -> {sum(nxh.volume(part, b) for b in cavs):.0f} in {len(cavs)} pieces")
    nxh.subtract(part, body, cavs, check=False)
    sol = [b for b in part.Bodies if b.IsSolidBody and b.Tag != envx.Tag and b.Tag not in tall_tags]
    log(f"C shell pieces {[round(nxh.volume(part, b)) for b in sol]}")
    sol.sort(key=lambda b: -nxh.volume(part, b))
    body = sol[0]
    if len(sol) > 1:
        try:
            nxh.unite(part, body, sol[1:], check=False)
        except Exception as e:  # noqa: BLE001
            log(f"C could not unite shell pieces: {e}")
    nxh.block(part, (-150.0, -80.0, rim), (350.0, 400.0, 100.0), op=BOOL.Subtract, target=body)
    log(f"C shell trimmed at rim {rim}: {nxh.volume(part, body):.0f}")
    n = clip_unite(part, body, tall_tools, envx, "tall plateaus")
    log(f"C tall plateaus {n} pieces; body {nxh.volume(part, body):.0f}")
    fl2, (lw,) = extrude_curves(part, sector_curves(part, H["r_in"] - 3.0, H["r_out"] + 10.0, H["low_a0"], H["low_a1"], H["low_z"]), (0, 0, 1), 0, 60.0)
    nxh.subtract(part, body, [lw], check=False)
    log(f"C hub low wall; body {nxh.volume(part, body):.0f}")
    if STOP == "C": raise StopIteration

    # ---- D: hip plate is kept by the slab; ring above the rim
    ax0 = (hp["ax_x"], hp["y_plate_in"], hp["ax_z"])
    nxh.cylinder(part, ax0, (0, 1, 0), hp["ring_od"], hp["y_ring_out"] - hp["y_plate_in"], op=BOOL.Unite, target=body)
    nxh.block(part, (-50.0, 250.0, hp["ring_top_z"]), (200.0, 50.0, 50.0), op=BOOL.Subtract, target=body)
    revolve_rz(part, hp["bore_rz"], (hp["ax_x"], 0.0, hp["ax_z"]), (0, 1, 0), (1, 0, 0), BOOL.Subtract, body)
    log(f"D hip ring + bores; body {nxh.volume(part, body):.0f}")
    if STOP == "D": raise StopIteration

    # ---- E: knee bores and the two bolt circles
    revolve_rz(part, H["bore_rz"], (0, 0, 0), (0, 0, 1), (1, 0, 0), BOOL.Subtract, body)
    kb = P["knee_bolts"]
    tools = []
    for k in range(kb["n"]):
        a = math.radians(kb["clock"] + k * 360.0 / kb["n"])
        f, c = nxh.cylinder(part, (kb["pcd"] / 2 * math.cos(a), kb["pcd"] / 2 * math.sin(a), kb["z0"]), (0, 0, 1), kb["d"], kb["z1"] - kb["z0"])
        tools.append(c)
    nxh.subtract(part, body, tools, check=False)
    hb = P["hip_bolts"]
    tools = []
    for k in range(hb["n"]):
        a = math.radians(hb["clock"] + k * 360.0 / hb["n"])
        x = hp["ax_x"] + hb["pcd"] / 2 * math.cos(a); z = hp["ax_z"] + hb["pcd"] / 2 * math.sin(a)
        f, c = nxh.cylinder(part, (x, hb["y0"], z), (0, 1, 0), hb["d"], hb["y1"] - hb["y0"])
        f2, c2 = nxh.cylinder(part, (x, hb["cb_y0"], z), (0, 1, 0), hb["cb_d"], hb["cb_y1"] - hb["cb_y0"])
        tools += [c, c2]
    nxh.subtract(part, body, tools, check=False)
    log(f"E bores + {kb['n']} knee holes + {hb['n']} hip holes; body {nxh.volume(part, body):.0f}")
    if STOP == "E": raise StopIteration

    # ---- F: boss spigots, pins, boss bores, small holes
    bt = []
    for b in P["bosses"]:
        f, cb = nxh.cylinder(part, (b["x"], b["y"], -40.0), (0, 0, 1), P["boss_body_d"], 40.0 + P["levels"]["tongue"])
        bt.append(cb)
    clip_unite(part, body, bt, envx, "boss bodies")
    for b in P["bosses"]:
        nxh.cylinder(part, (b["x"], b["y"], b["z0"]), (0, 0, 1), b["nub_d"], b["z1"] - b["z0"], op=BOOL.Unite, target=body)
    for p in P["pins"]:
        f, pb = nxh.cylinder(part, (p["x"], p["y"], -40.0), (0, 0, 1), p["base_d"], p["base_z"] + 40.0)
        clip_unite(part, body, [pb], envx, "pin base")
        nxh.cylinder(part, (p["x"], p["y"], p["base_z"] - 0.5), (0, 0, 1), p["d"], p["top_z"] - p["base_z"] + 0.5, op=BOOL.Unite, target=body)
    tools = []
    for b in P["bosses"]:
        f, c = nxh.cylinder(part, (b["x"], b["y"], b["z1"] - b["hole_depth"]), (0, 0, 1), b["hole_d"], b["hole_depth"] + 1.0)
        tools.append(c)
    for h in P["small_holes"]:
        f, c = nxh.cylinder(part, (h["x"], h["y"], h["z1"] - h["depth"]), (0, 0, 1), h["d"], h["depth"] + 1.0)
        tools.append(c)
    for h in P.get("axis_holes", []):
        f, c = nxh.cylinder(part, tuple(h["p"][k] - 0.5 * h["dir"][k] for k in range(3)), tuple(h["dir"]), h["d"], h["depth"] + 0.5)
        tools.append(c)
    nxh.subtract(part, body, tools, check=False)
    log(f"F bosses/pins/holes; body {nxh.volume(part, body):.0f}")
    if STOP == "F": raise StopIteration

    # ---- G: side-wall windows (profiles in the YZ plane, cut outward from just inside the wall)
    for w in json.load(open(os.path.join(WK, "windows.json"))):
        x0 = w["x_inner_limit"]
        cs = seg_curves_yz(part, w["segs"], x0)
        vec = (-1, 0, 0) if w["side"] == "L" else (1, 0, 0)
        f, bodies = extrude_curves(part, cs, vec, 0, 120.0, hp=(x0, w["segs"][0][1][0], w["segs"][0][1][1]))
        nxh.subtract(part, body, bodies, check=False)
    log(f"G windows; body {nxh.volume(part, body):.0f}")
    if STOP == "G": raise StopIteration

    # ---- H: seam grooves (cosmetic styling lines): tube along a spline on the skin, subtracted
    gr = json.load(open(os.path.join(WK, "grooves.json")))
    for name, gp in gr["paths"].items():
        try:
            f, sp = ck.studio_spline(part, [tuple(p) for p in gp["pts"]], degree=3)
            tf, tb = nxf.tube(part, gr["tube_d"], "0", curves=[sp])
            nxh.subtract(part, body, [tb], check=False)
            log(f"H groove {name}: ok, body {nxh.volume(part, body):.0f}")
        except Exception as e:  # noqa: BLE001
            log(f"H groove {name} failed: {e}")
    if STOP == "H": raise StopIteration

    nxh.save(part)
    nxre.stl_export(part, body, os.path.join(OUT, "thigh_H.stl"), chord=0.01, max_edge=2.0)
    log("H saved before fillets")
    # ---- I: root fillets - concave edges between the inner skin (B-surface faces) and walls/ribs/bosses
    FB = P["fillet"]
    def bsurf(face):
        return face.SolidFaceType == NXOpen.Face.FaceType.Parametric
    edges = []
    for e in body.GetEdges():
        fs = e.GetFaces()
        if len(fs) != 2 or e.GetLength() < 0.5:
            continue
        if bsurf(fs[0]) == bsurf(fs[1]):
            continue
        p0, p1 = e.GetVertices()
        if max(p0.Z, p1.Z) > 30.0:
            continue
        if nxf.edge_convexity(part, e) == "concave":
            edges.append(e)
    log(f"I fillet candidates: {len(edges)} concave B-surface/wall edges")
    # group the edges into connected chains (shared end points), blend chain by chain within a time budget
    def key(p):
        return (round(p.X, 3), round(p.Y, 3), round(p.Z, 3))
    parent = list(range(len(edges)))
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]; i = parent[i]
        return i
    ends = {}
    for i, e in enumerate(edges):
        for p in e.GetVertices():
            k = key(p)
            if k in ends:
                parent[find(i)] = find(ends[k])
            else:
                ends[k] = i
    groups = {}
    for i in range(len(edges)):
        groups.setdefault(find(i), []).append(edges[i])
    chains = sorted(groups.values(), key=lambda g: -sum(e.GetLength() for e in g))
    log(f"I {len(chains)} chains; trying the whole set per radius first")
    done = False
    for r in [FB["radius"], FB["radius"] * 0.667]:
        f, err = nxf._try_feature(lambda: nxf.edge_blend(part, [(edges, str(r))], overflow=True))
        if f is not None and nxh.body_ok(part, body):
            log(f"I one blend R{r:.2f} on all {len(edges)} edges"); done = True; break
        log(f"I all-edges R{r:.2f} refused: {err}")
    if not done:
        t_end = time.time() + FB.get("budget_s", 1500)
        ok = bad = 0
        for ch in chains:
            if time.time() > t_end:
                log(f"I time budget reached; {len(chains) - ok - bad} chains left unblended"); break
            built = False
            for r in (FB["radius"], FB["radius"] * 0.667, FB["radius"] * 0.333):
                f, err = nxf._try_feature(lambda: nxf.edge_blend(part, [(ch, str(r))], overflow=True))
                if f is not None:
                    built = True; break
            ok += built; bad += (not built)
        log(f"I chains blended {ok}, refused {bad}; body {nxh.volume(part, body):.0f} ok={nxh.body_ok(part, body)}")
    raise StopIteration
except StopIteration:
    pass
except Exception:
    res["error"] = traceback.format_exc()
    log("ERROR")
try:
    sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
    res["solids"] = [round(nxh.volume(part, b), 1) for b in sol]
    res["body_ok"] = [nxh.body_ok(part, b) for b in sol]
    res["feature_errors"] = [str(e) for e in nxh.feature_errors(part)][:20]
    if sol:
        big = max(sol, key=lambda b: nxh.volume(part, b))
        nxre.stl_export(part, big, os.path.join(OUT, f"thigh_{STOP}.stl"), chord=0.01, max_edge=2.0)
    nxh.save(part)
    if "error" not in res:
        res["result"] = "PASS"
except Exception:
    res["error_final"] = traceback.format_exc()
res["t"] = round(time.time() - T0, 1)
nxh.write_json(os.path.join(OUT, "build.json"), res)
