"""Examine the built body; then suppress the root-fillet blends and examine again. args: prt out_json [keep_blends]"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

PRT, OUTJ = sys.argv[1], sys.argv[2]
res = {}
try:
    part = nxh.open_part(PRT)
    sol = sorted([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked], key=lambda b: -nxh.volume(part, b))
    body = sol[0]
    res["volume"] = nxh.volume(part, body)
    res["examine"] = nxh.examine_geometry(part, body)
    feats = [f for f in part.Features.GetFeatures() if f.FeatureType == "BLEND"]
    res["n_blends"] = len(feats)
    res["blend_names"] = [f.JournalIdentifier for f in feats][:40]
    if feats:
        part.Features.SuppressFeatures(feats)
        nxh.update()
        res["volume_noblend"] = nxh.volume(part, body)
        res["examine_noblend"] = nxh.examine_geometry(part, body)
        # one by one: unsuppress each blend and test validity
        bad = []
        for f in feats:
            part.Features.UnsuppressFeatures([f]); nxh.update()
            if not nxh.body_ok(part, body):
                bad.append(f.JournalIdentifier)
                part.Features.SuppressFeatures([f]); nxh.update()
        res["bad_blends"] = bad
        res["volume_final"] = nxh.volume(part, body)
        res["examine_final"] = nxh.examine_geometry(part, body)
        res["ok_final"] = nxh.body_ok(part, body)
        if len(sys.argv) > 3:
            nxh.save(part)
            res["saved"] = True
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(OUTJ, res)
