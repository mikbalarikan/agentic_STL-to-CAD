"""Finalize the built part: keep one solid, helper geometry to layer 200, reference set SOLID, mass,
save-as the delivery name, exports (STEP AP214 + AP242, Parasolid x_t, STL) + STEP round trip.
args: built_prt deliver_dir"""
import os, sys, json, traceback, shutil
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, DST = sys.argv[1], sys.argv[2]
NAME = "LT-INN-001_Left_Thigh_Inner"
os.makedirs(DST, exist_ok=True)
res = {"result": "FAIL", "log": []}
log = res["log"].append
try:
    work = os.path.join(DST, NAME + ".prt")
    if os.path.exists(work):
        os.remove(work)
    shutil.copyfile(SRC, work)
    part = nxh.open_part(work)
    # the scan overlay (convergent bodies) does not belong in the delivered part
    conv = [f for f in part.Features if f.FeatureType == "BREP" and f.GetFeatureName().startswith("Convergent Body")]
    if conv:
        v0 = [nxh.volume(part, b) for b in part.Bodies if b.IsSolidBody]
        m = nxh.mark("del scan")
        nxh.S.UpdateManager.AddObjectsToDeleteList(conv)
        nxh.S.UpdateManager.DoUpdate(m)
        v1 = [nxh.volume(part, b) for b in part.Bodies if b.IsSolidBody]
        log(f"deleted {len(conv)} scan features; solid volumes {v0} -> {v1}")
        res["features_after"] = len(list(part.Features))
    vis = sorted([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked], key=lambda b: -nxh.volume(part, b))
    body = vis[0]
    others = [b for b in part.Bodies if b.IsSolidBody and b.Tag != body.Tag]
    if others:
        vols = [round(nxh.volume(part, b)) for b in others]
        nxf.delete_body(part, others)
        log(f"deleted {len(others)} helper solids {vols}")
    # helper geometry (section splines, sheets, groove paths) -> layer 200
    n = 0
    for b in part.Bodies:
        if not b.IsSolidBody:
            b.Layer = 200; n += 1
    for c in part.Curves:
        c.Layer = 200; n += 1
    for dp in part.Datums:
        try:
            dp.Layer = 200; n += 1
        except Exception:  # noqa: BLE001
            pass
    body.Layer = 1
    log(f"{n} helper objects moved to layer 200")
    try:
        lsc = part.Layers.GetStates()
        lsc.SetState(200, NXOpen.Layer.State.Hidden)
        part.Layers.SetStates(lsc, True)
    except Exception as e:  # noqa: BLE001
        log(f"layer state: {e}")
    rs = next((r for r in part.GetAllReferenceSets() if r.Name == "SOLID"), None)
    if rs is None:
        rs = part.CreateReferenceSet()
        rs.SetName("SOLID")
    try:
        rs.AddObjectsToReferenceSet([body])
    except Exception as e:  # noqa: BLE001
        log(f"refset: {e}")
    body.SetName("LEFT_THIGH_INNER")
    v = nxh.volume(part, body)
    res["volume_mm3"] = v
    res["mass_g_al6061"] = v * 2.70e-3
    try:
        mn, dirs, dist = nxh.UFS.ModlGeneral.AskBoundingBoxExact(body.Tag, NXOpen.Tag.Null)
        res["bbox"] = [round(mn[0], 3), round(mn[1], 3), round(mn[2], 3), round(mn[0] + dist[0], 3), round(mn[1] + dist[1], 3), round(mn[2] + dist[2], 3)]
    except Exception as e:  # noqa: BLE001
        res["bbox_exact_err"] = str(e)
        res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    for k, val in (("MATERIAL", "Aluminium 6061-T6"), ("DRAWING_NO", "LT-INN-001"), ("REVISION", "B"),
                   ("DESCRIPTION", "Left thigh - inner shell, reverse engineered from scan")):
        try:
            part.SetUserAttribute(k, -1, val, NXOpen.Update.Option.Now)
        except Exception as e:  # noqa: BLE001
            log(f"attribute {k}: {e}")
    nxh.save(part)
    # exports
    st214 = os.path.join(DST, NAME + "_AP214.step")
    st242 = os.path.join(DST, NAME + "_AP242.step")
    nxf.step_export(part, st214, ap242=False, save=True)
    nxf.step_export(part, st242, ap242=True, save=False)
    res["step_sizes"] = [os.path.getsize(st214), os.path.getsize(st242)]
    xt = os.path.join(DST, NAME + ".x_t")
    if os.path.exists(xt):
        os.remove(xt)
    try:
        nxh.UFS.Ps.ExportData([body.Tag], xt)
        res["x_t_size"] = os.path.getsize(xt)
    except Exception as e:  # noqa: BLE001
        res["x_t_error"] = str(e)
    stl = os.path.join(DST, NAME + ".stl")
    nxre.stl_export(part, body, stl, chord=0.005, max_edge=1.5)
    res["stl_size"] = os.path.getsize(stl)
    # NX's own STEP re-import imports nothing on these files (part 1 trap): the STEP is checked with OCP (an/stepcheck.py)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(DST, "_finalize.json"), res)
