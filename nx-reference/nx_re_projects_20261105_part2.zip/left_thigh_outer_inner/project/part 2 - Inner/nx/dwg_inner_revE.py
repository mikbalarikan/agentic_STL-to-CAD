# -*- coding: utf-8 -*-
"""LT-INN-001 Left Thigh - Inner shell, REV E drawing set (dwg_inner_revE.py <- nx/dwg_inner_revB.py; improvements of
part 1 nx/dwg_revF.py: model read-back, revision block, drawing part saved without its component). Third angle, A1.
Rev E (2026-11-02): scan reference gone; user design edits (groups WINDOWS_R1, ZONE1_R5, RIBS_R5, KNEE_R5, FEATURES_R6..R8:
ribs, window, rail bosses, lugs); fit fixes to LT-OUT-001 REV F (group FIT_REVE) and the B5 screw web (group B6_WEB,
X 86.45 Y 165.96). EVERY value printed on the sheets is read from the model faces in this run (class Model); nothing
is taken from params.json (Rev B numbers are only used as SEEDS to find the faces: boss / pin XY).
run_journal dwg_inner_revE.py -args <model.prt> <out_dir> [full|dump] [probe.json with the model volume]
Master-model drawing: drawing (X, Y, Z) = model (y, -x, z) (knee left -> hip right in the plan views). M(x, y, z) maps
a MODEL point to drawing-part coordinates.
Datum system (as LT-OUT-001): A = boss faces (6X Z 36.07), B = knee bore Ø19.90 H7, C = pin hole P3 (hip end)."""
import json
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\nx\dwglib")
import NXOpen  # noqa: E402
import NXOpen.Annotations  # noqa: E402
import NXOpen.Features  # noqa: E402
import nxh  # noqa: E402
import nxd  # noqa: E402
import nxd2  # noqa: E402
import ptdwg  # noqa: E402
import m3d  # noqa: E402
import gdt  # noqa: E402
from m3d import D, N, xy  # noqa: E402

MODEL, OUTD = sys.argv[1], sys.argv[2]
MODE = sys.argv[3] if len(sys.argv) > 3 else "full"
VOLJ = sys.argv[4] if len(sys.argv) > 4 else None
os.makedirs(OUTD, exist_ok=True)
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
NO, TITLE = "LT-INN-001", "LEFT THIGH - INNER SHELL"
_ol = os.path.join(os.path.dirname(OUTD), "plan_outline_E.json")      # outline of THIS model (work folder of the run)
OUTLINE = json.load(open(_ol if os.path.exists(_ol) else os.path.join(ROOT, "work", "dwgE", "plan_outline_E.json")))
# outer (LT-OUT-001 REV F, unchanged) levels under the inner's boss faces / floors: work/revE2/final_gate.txt
OUTER_BOSS_TOP = {"B7": 36.24}            # outer hip plate under B7; every other boss sits over an outer boss top Z 36.07
OUTER_BOSS_DEFAULT = 36.07
MAT = "Al 6061-T6"
RHO = 2.70e-3            # g/mm3, Al 6061
R = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]]
S = nxd.SNAP
A = NXOpen.Annotations
DT = 5.0        # dimension text
GT = 4.5        # notes, GD&T frames, datum letters
DIA = "Ø"
DEG = "°"
REV = "E"
NSH = 5
ptdwg.DATE = "2026-11-02"
res = {"result": "FAIL", "dims": {}, "errors": {}, "gdt": {}, "meas": {}}
MEAS = res["meas"]
m3d.start(res)
res["model_mtime_before"] = os.path.getmtime(MODEL)

# never write the model: save the drawing part only
nxh.save = lambda part: part.Save(NXOpen.BasePart.SaveComponents.FalseValue, NXOpen.BasePart.CloseAfterSave.FalseValue).Dispose()

# every ptdwg dimension (linear / radius) gets the larger text
_style0 = ptdwg._style
ptdwg._style = lambda b, prec=2, text_size=None: _style0(b, prec, text_size or DT)


def M(x, y, z):
    return (y, -x, z)


def straight(view, pred):
    """Lines ([start, end, mid]) and open splines ([start, end], not circles) whose end points satisfy pred."""
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 3 or (len(p) == 2 and not ptdwg._is_arc(c)):
            if pred(p[0], p[1]):
                out.append((c, p))
    return out


def longest(cands):
    if not cands:
        raise RuntimeError("no curve")
    return max(cands, key=lambda cp: sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)))[0]


def at(ax, val, tol=0.05):
    return lambda p0, p1: abs(p0[ax] - val) <= tol and abs(p1[ax] - val) <= tol


def dimc(name, view, ca, cb, origin, method, expect, etol=0.05, **kw):
    return D(name, lambda: m3d.dim_curves(view, ca, cb, origin, method, expect=expect, etol=etol, **kw))


def arc_xy(view, centre, r, skip, tol=0.08):
    """Circular drafting curve of radius r whose centre matches `centre` (drawing coords) in the two axes other
    than `skip` (the view direction). Among several (top / bottom edge) the one nearest the viewer wins."""
    best = None
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 2:
            cen, q = p[0], p[1]
        elif len(p) == 4:
            cen, q = p[2], p[0]
        else:
            continue
        rr = sum((cen[i] - q[i]) ** 2 for i in range(3)) ** 0.5
        if abs(rr - r) > tol:
            continue
        if max(abs(cen[i] - centre[i]) for i in range(3) if i != skip) > tol:
            continue
        if best is None or cen[skip] > best[1][skip]:
            best = (c, cen)
    if best is None:
        cand = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) == 2:
                rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
                cand.append((max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip), [round(v, 2) for v in p[0]], round(rr, 3)))
        cand.sort(key=lambda t: t[0])
        raise RuntimeError("arc_xy: no R%.3f at %s in %s; nearest %s" % (r, [round(v, 2) for v in centre], view.Name, cand[:6]))
    return best


def on_arc(centre, r, skip, toward):
    ax = [i for i in range(3) if i != skip]
    dx, dy = toward[ax[0]] - centre[ax[0]], toward[ax[1]] - centre[ax[1]]
    n = math.hypot(dx, dy) or 1.0
    p = list(centre)
    p[ax[0]] += r * dx / n
    p[ax[1]] += r * dy / n
    return tuple(p)


def lin(view, ca, cb, origin, method, sa, sb, before=None, after=None, basic=False, tol=None, expect=None, etol=0.05):
    """Linear dimension with explicit snaps; basic=True draws it boxed (theoretically exact)."""
    meth = {"horizontal": nxd.MM.Horizontal, "vertical": nxd.MM.Vertical, "point": nxd.MM.PointToPoint,
            "cylindrical": nxd.MM.Cylindrical}[method]
    dwg = m3d.CTX["dwg"]
    b = dwg.Dimensions.CreateLinearDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = meth
        b.FirstAssociativity.SetValue(sa, ca, view, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(sb, cb, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=tol, before=before, after=after)
        _style0(b, 2, DT)
        if basic:
            b.Style.DimensionStyle.ToleranceType = A.ToleranceType.Basic
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if expect is not None and abs(d.ComputedSize - expect) > etol:
        v = d.ComputedSize
        ptdwg._delete([d])
        raise RuntimeError("lin: %.4f instead of %.4f" % (v, expect))
    return d


def dia_dim(view, arc, origin, expect=None, etol=0.02):
    b = m3d.CTX["dwg"].Dimensions.CreateRadialDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = nxd.MM.Diametral
        b.FirstAssociativity.SetValue(nxd.SNAP.NotSet, arc, view, nxd.P0, None, None, nxd.P0)
        ptdwg._style(b, 2, DT)
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if expect is not None and abs(d.ComputedSize - expect) > etol:
        v = d.ComputedSize
        ptdwg._delete([d])
        raise RuntimeError("dia: %.4f instead of %.4f" % (v, expect))
    return d


def stack_below(ann):
    ao = A.Annotation.AssociativeOriginData()
    ao.OriginType = A.AssociativeOriginType.AttachedToStack
    ao.StackAlignmentPosition = A.StackAlignmentPosition.Below
    ao.OffsetAnnotation = ann
    return ao


def stack_fcf(name, dim, char, tol, datums=(), dia=False, pos=None):
    """FCF stacked under a dimension / note (NX 'attached to stack' origin); fallback: free FCF at `pos`."""
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
            try:
                b.Characteristic = gdt.characteristic(char)
                b.FrameStyle = A.FeatureControlFrameBuilder.FcfFrameStyle.SingleFrame
                b.FeatureControlFrameDataList.Append(dwg.Annotations.CreateFeatureControlFrameDataBuilder(None))
                d = b.FeatureControlFrameDataList.FindItem(0)
                if dia:
                    d.ZoneShape = A.FeatureControlFrameDataBuilder.ToleranceZoneShape.Diameter
                d.ToleranceValue = str(tol)
                for r_, l_ in zip((d.PrimaryDatumReference, d.SecondaryDatumReference, d.TertiaryDatumReference), datums):
                    r_.Letter = l_
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(dim))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-400:]
            if pos is None:
                raise
            o = gdt.fcf(dwg, char, tol, datums, dia, pos, size=GT)
            res["gdt"][name] = "free"
            return o
    return N(name, f)


def datum_under(name, letter, ann, fallback):
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.Datums.CreateDraftingDatumFeatureSymbolBuilder(None)
            try:
                b.Letter = letter
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(ann))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-300:]
            o = fallback()
            res["gdt"][name] = "leader"
            return o
    return N(name, f)


def callout(name, view, arc, cen, r, skip, toward, lines, side=None):
    a = on_arc(cen, r, skip, toward)
    pos = xy(view, toward)
    return N(name, lambda: nxd2.leader_note(m3d.CTX["dwg"], lines, pos, arc, view, a, size=DT, side=side))


def table(origin, cw, rows, size=3.5, rh=8.0):
    m = [(0, 0, 0, len(cw) - 1)]
    _ts, tn = nxd2.table(m3d.CTX["dwg"], origin, cw, [rh] * len(rows), rows, text_size=size, merges=m, sizes={(0, 0): size})
    return nxd2.table_text(tn)


def note_lines(lines, x, y, step=8.0, size=GT):
    for i, t in enumerate(lines):
        if not t:
            continue
        N("note_%d_%d" % (int(x), int(y - i * step)), lambda t=t, i=i: nxd.note(m3d.CTX["dwg"], [t], (x, y - i * step), size=size))


def edge_at(view, ax, val, tol=0.06):
    best = None
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 4:
            q = [p[0], p[1], p[3]]
        elif len(p) in (2, 3) and not (len(p) == 2 and ptdwg._is_arc(c)):
            q = p[:2]
        else:
            continue
        if all(abs(t[ax] - val) < tol for t in q):
            L = sum((q[0][i] - q[1][i]) ** 2 for i in range(3)) ** 0.5
            if best is None or L > best[0]:
                best = (L, c)
    if best is None:
        raise RuntimeError("edge_at: none at %s = %.3f in %s" % ("XYZ"[ax], val, view.Name))
    return best[1]


def seg_on(view, ax, val, lo_ax, lo, hi, tol=0.06):
    return lambda: longest(straight(view, lambda p0, p1: abs(p0[ax] - val) < tol and abs(p1[ax] - val) < tol
                                    and lo <= 0.5 * (p0[lo_ax] + p1[lo_ax]) <= hi))


def relabel(view, letter):
    def f():
        lab = NXOpen.TaggedObjectManager.GetTaggedObject(nxh.UFS.Draw.AskViewLabel(view.Tag))
        b = m3d.CTX["dwg"].SettingsManager.CreateDrawingEditViewLabelSettingsBuilder([lab])
        try:
            b.ViewCommonViewLabel.Letter = letter
            b.Commit()
        finally:
            b.Destroy()
        return letter
    return N("label_%s_%s" % (view.Name, letter), f)


def rev_block():
    """Revision block on top of the title block (same 180 mm width): rows only for released revisions."""
    x0, y0, x1, y1 = ptdwg.FRAME["A1"]
    rows = [["REV", "DESCRIPTION", "DATE", "BY"],
            ["A", "FIRST ISSUE", "2026-10-29", "MIA"],
            ["B", "PINS, LUGS, GUSSETS, CHANNEL HOLES ADDED; JOINT BAND CLEANED", "2026-10-31", "MIA"],
            ["E", "FIT TO LT-OUT-001 REV F, B5 BOSS WEB (X86.45 Y165.96), DESIGN EDITS (RIBS, WINDOW, RAIL BOSSES)",
             "2026-11-02", "MIA"]]
    top = y0 + 47.0 + 6.0 * len(rows) + 1.0
    _ts, tn = nxd2.table(m3d.CTX["dwg"], (x1 - 180.0, top), [10.0, 138.0, 19.0, 13.0], [6.0] * len(rows), rows, text_size=2.0)
    return nxd2.table_text(tn)


def ztxt(z):
    return "%.2f" % z


# ======================================================================== model read-back (faces of the model part)
class Model(object):
    """Cylinder and plane faces of every visible solid of the model part (model coordinates)."""

    def __init__(self, prt):
        self.cyl, self.pl = [], []
        self.solids = []
        for b in prt.Bodies:
            if not b.IsSolidBody or b.IsBlanked:
                continue
            self.solids.append(b)
            for f in b.GetFaces():
                t, pt, d, _bx, rad, _rd, nd = nxh.UFS.Modeling.AskFaceData(f.Tag)
                bb = list(nxh.UFS.ModlGeneral.AskBoundingBox(f.Tag))
                if t == 16:
                    self.cyl.append({"r": abs(rad), "pt": list(pt), "dir": list(d), "bb": bb, "nd": nd, "face": f})
                elif t == 22:
                    self.pl.append({"n": list(d), "d": sum(pt[i] * d[i] for i in range(3)), "bb": bb, "face": f})

    def vcyl(self, x, y, r, tol=0.3, rtol=0.012, concave=None):
        out = []
        for c in self.cyl:
            if abs(abs(c["dir"][2]) - 1.0) > 1e-3 or abs(c["r"] - r) > rtol:
                continue
            if math.hypot(c["pt"][0] - x, c["pt"][1] - y) > tol:
                continue
            if concave is not None and (c["nd"] < 0) != concave:
                continue
            out.append(c)
        return out

    def vc1(self, x, y, r, **kw):
        rows = self.vcyl(x, y, r, **kw)
        if not rows:
            raise RuntimeError("no vertical R%.3f at (%.2f, %.2f)" % (r, x, y))
        return (sum(q["pt"][0] for q in rows) / len(rows), sum(q["pt"][1] for q in rows) / len(rows),
                min(q["bb"][2] for q in rows), max(q["bb"][5] for q in rows), rows[0]["nd"])

    def axcyl(self, p, d, r, tol=0.05, rtol=0.012):
        out = []
        for c in self.cyl:
            if abs(abs(sum(c["dir"][i] * d[i] for i in range(3))) - 1.0) > 1e-3 or abs(c["r"] - r) > rtol:
                continue
            w = [c["pt"][i] - p[i] for i in range(3)]
            s = sum(w[i] * d[i] for i in range(3))
            if math.sqrt(max(0.0, sum(v * v for v in w) - s * s)) <= tol:
                out.append(c)
        return out

    def hplane(self, x, y, up=True, zmin=-1e9, zmax=1e9, pad=0.05):
        out = []
        for p in self.pl:
            if abs(abs(p["n"][2]) - 1.0) > 1e-4 or (p["n"][2] > 0) != up:
                continue
            z = p["d"] * p["n"][2]
            b = p["bb"]
            if b[0] - pad <= x <= b[3] + pad and b[1] - pad <= y <= b[4] + pad and zmin <= z <= zmax:
                out.append(z)
        return sorted(out)

    def zlevels(self, up):
        out = {}
        for p in self.pl:
            if abs(abs(p["n"][2]) - 1.0) < 1e-4 and (p["n"][2] > 0) == up:
                z = round(p["d"] * p["n"][2], 2)
                out[z] = out.get(z, 0) + 1
        return out

    def yplanes(self, sign):
        return sorted(set(round(p["d"] * p["n"][1], 3) for p in self.pl if abs(p["n"][1] - sign) < 1e-5))

    def thk(self, faces):
        """Thickness of a rib from ITS planar faces: nearest pair of opposite vertical planes."""
        V = [p for p in self.pl if p["face"].Tag in faces and abs(p["n"][2]) < 0.05]
        best = None
        for a in V:
            for b in V:
                if a is b or sum(a["n"][k] * b["n"][k] for k in range(3)) > -0.999:
                    continue
                t = abs(a["d"] + b["d"])
                if t < 0.3 or t > 12.0:
                    continue
                ov = [max(a["bb"][k], b["bb"][k]) for k in range(3)] + [min(a["bb"][k + 3], b["bb"][k + 3]) for k in range(3)]
                ext = max(ov[3] - ov[0], ov[4] - ov[1])
                if ov[5] - ov[2] < 0.5 or ext < 1.0:
                    continue
                if best is None or ext > best[4]:
                    best = (t, a, b, ov, ext)
        return best


# ======================================================================== feature table (SH4), every value from the model
BSEED = [(61.35, -40.01), (75.85, 29.86), (-25.10, 77.45), (-17.05, 165.91), (86.45, 165.96), (97.95, 264.95), (-22.00, 264.93)]
PSEED = [(97.46, 131.44), (108.97, 194.32), (-38.09, 245.35)]
NSEED = [(-30.90, -51.41), (-56.69, 19.53)]
ESEED = [(27.04, 271.74), (49.02, 271.75)]
BOSS = []          # measured boss rows (dicts)
PINS = []


def read_bosses():
    for i, (x, y) in enumerate(BSEED, 1):
        hx, hy, hz0, hz1, _ = MD.vc1(x, y, 3.0, concave=True)               # web core Ø6
        pk = [c for c in MD.cyl if abs(abs(c["dir"][2]) - 1) < 1e-3 and c["nd"] < 0 and 4.9 < c["r"] < 5.3
              and math.hypot(c["pt"][0] - hx, c["pt"][1] - hy) < 0.3 and c["bb"][5] <= hz0 + 0.02]
        cb = [c for c in MD.cyl if abs(abs(c["dir"][2]) - 1) < 1e-3 and c["nd"] < 0 and 5.1 < c["r"] < 5.3
              and math.hypot(c["pt"][0] - hx, c["pt"][1] - hy) < 0.3 and c["bb"][2] >= hz1 - 0.02]
        col = MD.vcyl(hx, hy, 7.5, concave=False)
        p = min(pk, key=lambda c: c["bb"][2])
        b = {"id": "B%d" % i, "x": hx, "y": hy, "face": p["bb"][2], "floor": p["bb"][5], "pocket_d": 2 * p["r"],
             "web0": hz0, "web1": hz1, "hole_d": 6.0, "cb_d": 2 * cb[0]["r"], "cb_top": max(c["bb"][5] for c in cb),
             "col_d": 2 * col[0]["r"] if col else None}
        BOSS.append(b)
    MEAS["bosses"] = [{k: (round(v, 3) if isinstance(v, float) else v) for k, v in b.items()} for b in BOSS]


def read_pins():
    for i, (x, y) in enumerate(PSEED, 1):
        hx, hy, z0, z1, _ = MD.vc1(x, y, 2.0, concave=True)
        lug = MD.vcyl(hx, hy, 4.5, tol=0.5, concave=False)
        PINS.append({"id": "P%d" % i, "x": hx, "y": hy, "z0": z0, "z1": z1, "d": 4.0, "lug_d": 2 * lug[0]["r"] if lug else None})
    MEAS["pins"] = [{k: (round(v, 3) if isinstance(v, float) else v) for k, v in p.items()} for p in PINS]


def arc_target(view, x, y, z, r):
    def f(xb, yb):
        c, cen = arc_xy(view, M(x, y, z), r, 2, 0.12)
        return c, on_arc(cen, r, 2, M(xb, yb, cen[2]))
    return f


def near_target(view, x, y, z):
    def f(xb, yb):
        return ptdwg.near(view, M(x, y, z))
    return f


def feature_rows(view):
    rows, feats = [], []
    rep = MEAS.setdefault("features", {})

    def add(fid, x, y, desc, face, hole, tgt, z):
        rows.append([fid, "%.2f" % x, "%.2f" % y, desc, face, hole])
        feats.append((fid, x, y, z, tgt))
        rep[fid] = rows[-1][1:]

    def tryf(fid, fn):
        try:
            fn()
        except Exception:  # noqa: BLE001
            res["errors"]["feat_" + fid] = traceback.format_exc()[-400:]

    for b in BOSS:
        add(b["id"], b["x"], b["y"], "BOSS %s%.0f, POCKET %s%.2f TO Z %.2f" % (DIA, b["col_d"] or 15.0, DIA, b["pocket_d"], b["floor"]),
            ztxt(b["face"]), "%s6 THRU, CB %s%.2f FROM Z %.2f" % (DIA, DIA, b["cb_d"], b["web1"]),
            arc_target(view, b["x"], b["y"], b["face"], b["pocket_d"] / 2.0), b["face"])
    for p in PINS:
        add(p["id"], p["x"], p["y"], "PIN HOLE IN LUG %s%.0f" % (DIA, p["lug_d"] or 9.0), ztxt(p["z0"]),
            "%s4 H8 x %.2f DEEP" % (DIA, p["z1"] - p["z0"]), arc_target(view, p["x"], p["y"], p["z0"], 2.0), p["z0"])
    # rail bosses / channel holes: every small vertical hole not on a boss / pin / knee axis
    ex = BSEED + PSEED
    H = [c for c in MD.cyl if abs(abs(c["dir"][2]) - 1) < 1e-3 and c["nd"] < 0 and 1.2 < c["r"] < 2.1
         and min(math.hypot(c["pt"][0] - x, c["pt"][1] - y) for x, y in ex) > 3.0
         and not (math.hypot(c["pt"][0], c["pt"][1]) < 50.0 and c["bb"][2] >= 79.9)]
    cl = []
    for c in H:
        for k in cl:
            if math.hypot(k[0]["pt"][0] - c["pt"][0], k[0]["pt"][1] - c["pt"][1]) < 0.4:
                k.append(c)
                break
        else:
            cl.append([c])
    cl.sort(key=lambda k: (k[0]["pt"][1], k[0]["pt"][0]))
    for i, k in enumerate(cl, 1):
        def fh(i=i, k=k):
            low = min(k, key=lambda c: c["bb"][2])
            z0, z1 = low["bb"][2], max(c["bb"][5] for c in k)
            hx, hy = low["pt"][0], low["pt"][1]
            boss = [c for c in MD.cyl if abs(abs(c["dir"][2]) - 1) < 1e-3 and c["nd"] > 0 and 2.0 < c["r"] < 3.0
                    and math.hypot(c["pt"][0] - hx, c["pt"][1] - hy) < 0.6]
            desc = ("RAIL BOSS %s%.0f" % (DIA, 2 * boss[0]["r"])) if boss else "CHANNEL HOLE"
            add("H%d" % i, hx, hy, desc, ztxt(z0), "%s%.2f x %.2f DEEP" % (DIA, 2 * low["r"], z1 - z0),
                arc_target(view, hx, hy, z0, low["r"]), z0)
        tryf("H%d" % i, fh)
    for i, (x, y) in enumerate(NSEED, 1):
        def fn(i=i, x=x, y=y):
            px, py, z0, z1, _ = MD.vc1(x, y, 1.5, concave=False)
            tip = MD.hplane(px, py, up=False, zmin=z0 - 2.0, zmax=z0 - 0.01)       # chamfered tip: flat below the cylinder
            ch = ""
            if tip:
                ch = ", C%.1f TIP" % (z0 - min(tip))
                z0 = min(tip)
            MEAS.setdefault("pins_N", {})["N%d" % i] = [round(px, 3), round(py, 3), round(z0, 3), round(z1, 3), ch]
            add("N%d" % i, px, py, "PIN %s3 x %.2f%s (TIP Z %.2f)" % (DIA, z1 - z0, ch, z0), ztxt(z1), "-",
                arc_target(view, px, py, z1 - 2.0, 1.5), z0)
        tryf("N%d" % i, fn)
    for i, (x, y) in enumerate(ESEED, 1):
        def fe(i=i, x=x, y=y):
            px, py, z0, z1, _ = MD.vc1(x, y, 2.0, concave=False)
            add("E%d" % i, px, py, "HIP PIN %s4 x %.2f (TIP Z %.2f)" % (DIA, z1 - z0, z0), ztxt(z1), "-",
                arc_target(view, px, py, z0, 2.0), z0)
        tryf("E%d" % i, fe)
    # tabs / lugs with horizontal Ø2.6 holes
    L = [c for c in MD.cyl if abs(c["dir"][2]) < 1e-3 and c["nd"] < 0 and abs(c["r"] - 1.3) < 0.02]
    L.sort(key=lambda c: c["pt"][1])
    for i, c in enumerate(L, 1):
        def fl(i=i, c=c):
            d = c["dir"]
            ang = math.degrees(math.atan2(d[1], d[0])) % 180.0
            zc = c["pt"][2]
            add("L%d" % i, c["pt"][0], c["pt"][1], "LUG, HOLE AXIS %.0f%s IN XY, Z %.2f" % (ang, DEG, zc), "-",
                "%s%.2f THRU" % (DIA, 2 * c["r"]), near_target(view, c["pt"][0], c["pt"][1], c["bb"][2]), c["bb"][2])
        tryf("L%d" % i, fl)
    return rows, feats


def place_balloons(view, feats, tag):
    """Arrow balloons outside the plan outline (Bottom view: sheet up = model +X), stacked per side along Y."""
    oy0, xs_min, xs_max = OUTLINE["y0"], OUTLINE["xmin"], OUTLINE["xmax"]

    def band(y, w=9.0):
        i0 = max(0, int(y - w - oy0)); i1 = min(len(xs_min) - 1, int(y + w - oy0))
        lo = [v for v in xs_min[i0:i1 + 1] if v == v]; hi = [v for v in xs_max[i0:i1 + 1] if v == v]
        return (min(lo) if lo else -70.0), (max(hi) if hi else 120.0)
    GAP, PITCH = 18.0, 16.0
    sides = {"hi": [], "lo": []}
    for f in feats:
        lo, hi = band(f[2])
        sides["hi" if (hi - f[1]) <= (f[1] - lo) else "lo"].append(list(f))
    place = []
    for side, lst in sides.items():
        lst.sort(key=lambda f: f[2])
        ys = [f[2] for f in lst]
        for _it in range(400):
            moved = False
            for k in range(len(ys) - 1):
                g = ys[k + 1] - ys[k]
                if g < PITCH - 1e-6:
                    ys[k] -= (PITCH - g) / 2.0
                    ys[k + 1] += (PITCH - g) / 2.0
                    moved = True
            if not moved:
                break
        for f, yb in zip(lst, ys):
            lo, hi = band(min(f[2], yb), 9.0 + abs(yb - f[2]))
            xb = hi + GAP if side == "hi" else lo - GAP
            place.append((f, xb, yb))
    # hip pins: balloons right of the hip end face instead (their leaders would run along the hip plate)
    for k, (f, xb, yb) in enumerate(place):
        if f[0] in ("E1", "E2"):
            place[k] = (f, f[1], MEAS["y_end"] + 20.0)
    out = []
    for f, xb, yb in place:
        name, x, y, z, tgt = f
        pos = xy(view, M(xb, yb, z))

        def mk(name=name, tgt=tgt, pos=pos, xb=xb, yb=yb):
            c, a = tgt(xb, yb)
            big = len(name) > 2
            return gdt.balloon(dwg, name, pos, c, view, a, size=13.0 if big else 11.0, text_size=4.0 if big else 4.5)
        N("%s_balloon_%s" % (tag, name), mk)
        out.append([name, round(xb, 1), round(yb, 1)])
    res["balloons_" + tag] = out
    return out


def feat_faces(name):
    """Live faces (in the solid) of the model feature with this user name."""
    live = set(f.Tag for b in MD.solids for f in b.GetFaces())
    for f in mprt.Features:
        if f.Name == name:
            return [x for x in f.GetFaces() if x.Tag in live]
    raise RuntimeError("no feature named %s" % name)


def rib_rows():
    """Every Rib feature of the model: thickness from its own opposite vertical planes, mid-plane point, direction."""
    out = []
    for f in mprt.Features:
        if f.FeatureType != "RIB" or not f.Name:
            continue
        try:
            fs = set(x.Tag for x in feat_faces(f.Name))
            best = MD.thk(fs)
            if best is None:
                MEAS.setdefault("ribs_no_pair", []).append(f.Name)
                continue
            t, a, b, ov, ext = best
            if ext < 1.5 * t:                                 # a pad / block, not a rib
                MEAS.setdefault("ribs_not_rib", []).append([f.Name, round(t, 2), round(ext, 2)])
                continue
            n = a["n"]
            cx, cy, cz = 0.5 * (ov[0] + ov[3]), 0.5 * (ov[1] + ov[4]), 0.5 * (ov[2] + ov[5])
            mid = 0.5 * (a["d"] - b["d"])                    # mid-plane: n.p = mid
            s = mid - (n[0] * cx + n[1] * cy + n[2] * cz)
            mx, my = cx + s * n[0], cy + s * n[1]
            ang = math.degrees(math.atan2(n[0], -n[1])) % 180.0
            hz = sorted(p["d"] * p["n"][2] for p in MD.pl if p["face"].Tag in fs and p["n"][2] < -0.9999)
            zlo = min(ov[2], hz[0] if hz else ov[2])
            out.append({"name": f.Name, "t": t, "x": mx, "y": my, "dir": ang, "nrm": (n[0], n[1]), "zlo": zlo, "zhi": ov[5]})
        except Exception:  # noqa: BLE001
            res["errors"]["rib_" + f.Name] = traceback.format_exc()[-300:]
    out.sort(key=lambda r: (r["y"], r["x"]))
    return out


def rib_target(view, x, y, nrm, t, zfb=0.0):
    """Balloon target on a rib in the BOTTOM view: the visible straight edge parallel to the rib within t/2 of the
    mid-plane point, the seed projected onto it (lowest Z = nearest the viewer wins)."""
    u = (-nrm[1], nrm[0])
    ud = (u[1], -u[0])
    sd = (y, -x)

    def f(xb, yb):
        best = None
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) != 3:
                continue
            dx, dy = p[1][0] - p[0][0], p[1][1] - p[0][1]
            L = math.hypot(dx, dy)
            if L < 2.0 or abs(dx / L * ud[1] - dy / L * ud[0]) > 0.03:
                continue
            s = ((sd[0] - p[0][0]) * dx + (sd[1] - p[0][1]) * dy) / (L * L)
            s = min(0.95, max(0.05, s))
            q = (p[0][0] + s * dx, p[0][1] + s * dy)
            dist = math.hypot(q[0] - sd[0], q[1] - sd[1])
            if dist > t / 2.0 + 0.3:
                continue
            z = p[0][2] + s * (p[1][2] - p[0][2])
            key = (round(dist, 1), z)
            if best is None or key < best[0]:
                best = (key, c, (q[0], q[1], z))
        if best is None:
            res.setdefault("rib_target_near", []).append([round(x, 2), round(y, 2)])
            return ptdwg.near(view, M(x, y, zfb))
        return best[1], best[2]
    return f


def window(name):
    """Extent of a window cut: its own cut faces (cylinders that the cut only trimmed, e.g. the P3 lug, left out)."""
    bbs = [list(nxh.UFS.ModlGeneral.AskBoundingBox(x.Tag)) for x in feat_faces(name) if nxh.UFS.Modeling.AskFaceData(x.Tag)[0] != 16]
    return [min(b[0] for b in bbs), min(b[1] for b in bbs), min(b[2] for b in bbs), max(b[3] for b in bbs),
            max(b[4] for b in bbs), max(b[5] for b in bbs)]


def SH5_BUILD():
    sh5, _g = ptdwg.sheet(dwg, "A1")
    rbot = nxd.base_view(dwg, dwg, "Bottom", (250.0, 405.0), scale=(1.0, 1.0))
    wfront = nxd.base_view(dwg, dwg, "Front", (250.0, 205.0), scale=(1.0, 1.0))
    wback = nxd.base_view(dwg, dwg, "Back", (250.0, 95.0), scale=(1.0, 1.0))
    res["views5"] = {v.Name: nxd.view_info(v) for v in (rbot, wfront, wback)}
    res["rev5"] = N("rev_block_5", rev_block)
    res["tb5"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 5, NSH, rev=REV, subtitle="ribs and windows")
    if MODE == "dump":
        return sh5
    ribs = rib_rows()
    MEAS["ribs"] = {}
    rrows = [["RIBS (MODEL FRAME): MID-PLANE POINT, DIRECTION FROM +X, THICKNESS", "", "", "", "", "", ""],
             ["ID", "MODEL FEATURE", "X", "Y", "DIR", "THK", "Z EDGE"]]
    rfeats = []
    for i, r in enumerate(ribs, 1):
        rid = "R%d" % i
        ang = r["dir"]
        rrows.append([rid, r["name"], "%.2f" % r["x"], "%.2f" % r["y"], ("%.1f" % ang) if 0.05 < ang < 179.95 else "180.0",
                      "%.2f" % r["t"], "%.2f" % r["zlo"]])
        rfeats.append((rid, r["x"], r["y"], r["zlo"], rib_target(rbot, r["x"], r["y"], r["nrm"], r["t"], r["zlo"])))
        MEAS["ribs"][rid] = {"feature": r["name"], "thk": round(r["t"], 3), "dir": round(ang, 2), "pt": [round(r["x"], 2), round(r["y"], 2)],
                             "z": [round(r["zlo"], 2), round(r["zhi"], 2)]}
    res["table_ribs"] = N("table_ribs", lambda: table((470.0, 570.0), [14.0, 52.0, 24.0, 24.0, 18.0, 16.0, 22.0], rrows, size=3.0, rh=6.6))
    place_balloons(rbot, rfeats, "b5")
    # ---- windows W1 (+X wall, front view) and W2 (-X wall, back view)
    W = {}
    for wid, nm in (("W1", "WIN1_CUT"), ("W2", "WIN2_CUT")):
        try:
            W[wid] = window(nm)
        except Exception:  # noqa: BLE001
            res["errors"]["window_" + wid] = traceback.format_exc()[-300:]
    MEAS["windows"] = {k: [round(v, 2) for v in b] for k, b in W.items()}
    for wid, view, side in (("W1", wfront, +1), ("W2", wback, -1)):
        if wid not in W:
            continue
        b = W[wid]
        xw = b[3] if side > 0 else b[0]
        ym, zt = 0.5 * (b[1] + b[4]), b[5]

        def mkw(view=view, xw=xw, ym=ym, zt=zt, wid=wid, b=b):
            c, p = ptdwg.near(view, M(xw, ym, zt))
            s = xy(view, p)
            return gdt.balloon(dwg, wid, (s[0] + 25.0 * (1 if wid == "W1" else -1), s[1] + 28.0), c, view, p, size=11.0, text_size=4.5)
        N("balloon_" + wid, mkw)
    wrows = [["SIDE WINDOWS (THROUGH THE WALL, PROFILE PER 3D MODEL)", ""]]
    for wid, wall in (("W1", "+X WALL"), ("W2", "-X WALL")):
        if wid in W:
            b = W[wid]
            wrows.append(["%s %s: Y FROM DATUM B (BASIC)" % (wid, wall), "%.2f - %.2f" % (b[1], b[4])])
            wrows.append(["%s %s: Z RANGE (LIP Z %.2f)" % (wid, wall, LIP), "%.2f - %.2f" % (max(b[2], LIP), b[5])])
    ywt = 570.0 - 6.6 * len(rrows) - 14.0
    res["table_win"] = N("table_win", lambda: table((470.0, ywt), [110.0, 60.0], wrows, size=3.2, rh=7.2))
    yfc = ywt - 7.2 * len(wrows) - 9.0
    N("note_win", lambda: nxd.note(dwg, ["W1, W2 EDGES:"], (470.0, yfc), size=GT))
    N("fcf_win", lambda: gdt.fcf(dwg, "ProfileOfASurface", "0.2", ("A", "B", "C"), False, (520.0, yfc + 4.0), size=GT))
    N("note_ribs", lambda: nxd.note(dwg, ["RIB THICKNESS TOLERANCE +/-0.1. RIB FREE EDGES BREAK 0.2-0.5."], (470.0, yfc - 12.0), size=GT))
    res["overlaps5"] = nxd.overlaps(sh5)
    return sh5


try:
    dwg, comp = m3d.new_drawing(os.path.join(OUTD, NO + "_dwg.prt"), MODEL, "LEFT_THIGH_INNER", R, refset="SOLID")
    mprt = comp.Prototype
    try:
        mprt.LoadThisPartFully()
    except Exception:  # noqa: BLE001
        pass
    MD = Model(mprt)
    res["model"] = {"solids": len(MD.solids), "cyl": len(MD.cyl), "planes": len(MD.pl), "file": MODEL}
    # ---- volume / mass of the model solid (probe json of the same file, or measured here)
    vol = None
    if VOLJ and os.path.exists(VOLJ):
        pj = json.load(open(VOLJ))
        vol = pj.get("volume")
        res["volume_source"] = VOLJ
    if not vol:
        vol = nxh.mass(mprt, MD.solids)["volume"]
        res["volume_source"] = "measured in this run"
    MEAS["volume_mm3"] = round(vol, 2)
    MEAS["mass_g"] = round(vol * RHO, 1)
    MASS = "%.3f kg" % (vol * RHO / 1000.0)
    # ---- levels (model frame)
    dn, up = MD.zlevels(False), MD.zlevels(True)
    MEAS["down_levels"], MEAS["up_levels"] = {str(k): v for k, v in sorted(dn.items())}, {str(k): v for k, v in sorted(up.items())}
    LIP = min(dn)                                                               # lip face (lowest)
    read_bosses()
    read_pins()
    faces = [round(b["face"], 2) for b in BOSS]
    ZA = max(set(faces), key=faces.count)                                       # datum A level (most boss faces)
    NA = faces.count(ZA)
    FLOOR = max(set(round(b["floor"], 2) for b in BOSS), key=[round(b["floor"], 2) for b in BOSS].count)
    WEB1 = max(set(round(b["web1"], 2) for b in BOSS), key=[round(b["web1"], 2) for b in BOSS].count)
    # knee hub
    KB_R = MD.vc1(0.0, 0.0, 9.95, rtol=0.05, concave=True)                      # bore
    BORE_D = 2 * MD.vcyl(0.0, 0.0, 9.95, rtol=0.05, concave=True)[0]["r"]
    RING = MD.vcyl(0.0, 0.0, 20.115, rtol=0.1, concave=False)
    RING_D = 2 * RING[0]["r"]
    RING_TOP = max(MD.hplane(0.0, 15.0, up=True, zmin=85.0, zmax=100.0))
    HUB_R = max(c["r"] for c in MD.vcyl(0.0, 0.0, 67.85, rtol=0.3, concave=False))
    HUB_TOP = max(MD.hplane(0.0, -50.0, up=True, zmin=80.5, zmax=86.0))         # knee disc outside
    CAV = min(MD.hplane(0.0, -50.0, up=False, zmin=78.0, zmax=82.0))            # knee disc inside
    KH = [c for c in MD.cyl if abs(abs(c["dir"][2]) - 1) < 1e-3 and c["nd"] < 0 and abs(c["r"] - 1.65) < 0.02
          and 10.0 < math.hypot(c["pt"][0], c["pt"][1]) < 20.0]
    KH_PCD = 2 * sum(math.hypot(c["pt"][0], c["pt"][1]) for c in KH) / len(KH)
    KH_ANG = sorted(round(math.degrees(math.atan2(c["pt"][1], c["pt"][0])) % 360.0, 2) for c in KH)
    SLOT = [c for c in MD.cyl if abs(abs(c["dir"][2]) - 1) < 1e-3 and c["nd"] < 0 and abs(c["r"] - 2.0) < 0.02
            and math.hypot(c["pt"][0], c["pt"][1]) < 50.0 and c["bb"][2] >= 79.9]
    SL_W = 2 * SLOT[0]["r"]
    SL_L = SL_W + math.hypot(SLOT[0]["pt"][0] - SLOT[-1]["pt"][0], SLOT[0]["pt"][1] - SLOT[-1]["pt"][1])
    SL_X = sum(c["pt"][0] for c in SLOT) / len(SLOT)
    SL_Y = sum(c["pt"][1] for c in SLOT) / len(SLOT)
    # hip end
    Y_END = max(MD.yplanes(+1.0))
    HSEAT = min(MD.hplane(37.97, 272.0, up=False, zmin=84.0, zmax=87.0))
    HCL = [c for c in MD.cyl if abs(abs(c["dir"][1]) - 1) < 1e-3 and c["nd"] < 0 and 50.0 < c["r"] < 55.0]
    HCL_D = 2 * HCL[0]["r"]
    HCL_AX = (HCL[0]["pt"][0], HCL[0]["pt"][2])
    HCL_Y0 = min(c["bb"][1] for c in HCL)
    HCL_Y1 = max(c["bb"][4] for c in HCL)
    YP_IN = [y for y in MD.yplanes(-1.0) if 266.0 < y < 267.0]
    YP_OUT = [y for y in MD.yplanes(+1.0) if 269.0 < y < 270.0]
    HIP_IN = max(YP_IN, key=lambda y: sum(1 for p in MD.pl if abs(p["n"][1] + 1) < 1e-5 and abs(p["d"] * p["n"][1] - y) < 1e-3))
    HIP_OUT = YP_OUT[0]
    MEAS.update({"lip": LIP, "datum_A": ZA, "n_A_faces": NA, "pocket_floor": FLOOR, "web_top": WEB1, "bore_d": BORE_D,
                 "ring_d": RING_D, "ring_top": RING_TOP, "hub_r": HUB_R, "hub_top": HUB_TOP, "disc_inside": CAV,
                 "knee_holes": len(KH), "knee_hole_pcd": KH_PCD, "knee_hole_ang": KH_ANG, "slot": [SL_W, SL_L, SL_X, SL_Y],
                 "y_end": Y_END, "L_overall": Y_END + HUB_R, "hip_seat": HSEAT, "hip_clear_d": HCL_D, "hip_clear_axis": HCL_AX,
                 "hip_clear_y": [HCL_Y0, HCL_Y1], "hip_plate_in": YP_IN, "hip_plate_out": YP_OUT})
    # joint-band levels between the lip and Z 36.5 other than boss faces, classified by the faces that carry them
    ribtags = set()
    for f_ in mprt.Features:
        if f_.FeatureType == "RIB" or (f_.Name and ("WALL" in f_.Name or "CORNER" in f_.Name)):
            try:
                ribtags.update(x.Tag for x in f_.GetFaces())
            except Exception:  # noqa: BLE001
                pass
    bfaces = set(round(b["face"], 2) for b in BOSS)
    JL = {"rebate": set(), "ring": set(), "rib": set()}
    for p_ in MD.pl:
        if abs(p_["n"][2] + 1.0) > 1e-4:
            continue
        z_ = round(-p_["d"], 2)
        if not (LIP + 0.01 < z_ < 36.5) or z_ in bfaces:
            continue
        bb_ = p_["bb"]
        cx_, cy_ = 0.5 * (bb_[0] + bb_[3]), 0.5 * (bb_[1] + bb_[4])
        if p_["face"].Tag in ribtags:
            JL["rib"].add(z_)
        elif any(math.hypot(cx_ - b["x"], cy_ - b["y"]) < 8.0 for b in BOSS):
            JL["ring"].add(z_)
        else:
            JL["rebate"].add(z_)
    MEAS["joint_levels"] = {k: sorted(v) for k, v in JL.items()}
    # Rev E final: the boss rings are gone and B2-B4 faces merged into the floors, so the classification above no
    # longer separates floors from boss faces; the table lists every flat level of the joint band (lip < Z < 36.5, not A)
    MEAS["rebate_levels"] = sorted(set(round(-p_["d"], 2) for p_ in MD.pl if abs(p_["n"][2] + 1.0) < 1e-4
                                       and LIP + 0.01 < -p_["d"] < 36.5 and abs(-p_["d"] - ZA) > 0.005))

    # ================================================================ SHEET 1 general arrangement (A1, 1:1)
    sh1, _g = ptdwg.sheet(dwg, "A1")
    front = nxd.base_view(dwg, dwg, "Front", (255.0, 140.0), scale=(1.0, 1.0))
    top = nxd.projected_view(dwg, front, (255.0, 390.0))
    right = nxd.projected_view(dwg, front, (565.0, 140.0))
    iso = nxd.base_view(dwg, dwg, "Isometric", (705.0, 470.0), scale=(1.0, 2.0))
    res["views1"] = {v.Name: nxd.view_info(v) for v in (front, top, right, iso)}
    res["rev1"] = N("rev_block_1", rev_block)
    res["tb1"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (iso 1:2)", 1, NSH, rev=REV, subtitle="general arrangement")
    if MODE == "dump":
        for tg, v in (("sh1_front", front), ("sh1_top", top), ("sh1_right", right)):
            res["dump_" + tg] = m3d.dump(v, os.path.join(OUTD, "dump_%s.json" % tg))
    else:
        fx = lambda X: xy(front, (X, 0.0, 0.0))[0]           # noqa: E731
        fz = lambda Z: xy(front, (0.0, 0.0, Z))[1]           # noqa: E731
        c_knee = N("c_knee", seg_on(front, 0, -HUB_R, 2, LIP, HUB_TOP, 0.1))
        c_end = N("c_end", seg_on(front, 0, Y_END, 2, LIP - 1.0, 120.0, 0.1))
        c_lip = N("c_lip", seg_on(front, 2, LIP, 0, -80.0, 300.0))
        c_ring = N("c_ringtop", seg_on(front, 2, RING_TOP, 0, -25.0, 25.0))
        if c_knee and c_end:
            dimc("L_overall", front, c_knee, c_end, (fx(110.0), fz(10.0)), "horizontal", Y_END + HUB_R, etol=0.05)
        if c_lip and c_ring:
            dimc("H_lip_ring", front, c_lip, c_ring, (fx(-112.0), fz(65.0)), "vertical", RING_TOP - LIP, etol=0.05)
        x0, y0 = 470.0, 330.0
        note_lines(["NOTES",
                    "1. GENERAL TOLERANCES ISO 2768-mK. GD&T PER ISO 1101.",
                    "2. GEOMETRY NOT DIMENSIONED PER 3D MODEL LT-INN-001 REV E.",
                    "3. ALL SURFACES UNLESS OTHERWISE SPECIFIED:",
                    "",
                    "4. INTERNAL CORNERS R3 MAX. BREAK SHARP EDGES 0.2-0.5.",
                    "5. Ra 3.2 UNLESS OTHERWISE SPECIFIED.",
                    "6. MATES WITH LT-OUT-001 REV F, SAME MODEL FRAME.",
                    "7. VOLUME %.0f MM3, MASS %.1f G (%s, 2.70 G/CM3)." % (vol, vol * RHO, MAT.upper()),
                    "8. REV E FINAL EDITS: FIT-CUT LEFTOVER FACES REMOVED (%s RINGS)," % ", ".join(
                        b["id"] for b in BOSS if abs(b["face"] - OUTER_BOSS_TOP.get(b["id"], OUTER_BOSS_DEFAULT)) > 0.005),
                    "    R6 ON 2 RIB EDGES, C1 ON PIN TIPS N1 / N2, RIB NOTCH FILLED."], x0, y0, step=9.0)
        N("fcf_profile_all", lambda: gdt.fcf(dwg, "ProfileOfASurface", "0.2", ("A", "B", "C"), False,
                                             (x0 + 7.0, y0 - 4 * 9.0 + 2.0), size=GT))
    res["overlaps1"] = nxd.overlaps(sh1)

    # ================================================================ SHEET 2 knee (A1, 1:1)
    sh2, _g = ptdwg.sheet(dwg, "A1")
    ktop = nxd.base_view(dwg, dwg, "Top", (330.0, 425.0), scale=(1.0, 1.0))
    ksec = nxd2.section(dwg, ktop, M(0.0, 0.0, 0.0), (330.0, 190.0), (1.0, 1.0))
    relabel(ksec, "E")
    res["views2"] = {v.Name: nxd.view_info(v) for v in (ktop, ksec)}
    res["rev2"] = N("rev_block_2", rev_block)
    res["tb2"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 2, NSH, rev=REV, subtitle="knee")
    if MODE == "dump":
        res["dump_ksec"] = m3d.dump(ksec, os.path.join(OUTD, "dump_sh2_ksec.json"))
        res["dump_ktop"] = m3d.dump(ktop, os.path.join(OUTD, "dump_sh2_ktop.json"))
    else:
        sx = lambda X: xy(ksec, (X, 0.0, 0.0))[0]            # noqa: E731
        sz = lambda Z: xy(ksec, (0.0, 0.0, Z))[1]            # noqa: E731
        vert = lambda X, z0, z1: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[0] - X) < 0.06 and abs(p1[0] - X) < 0.06
                                                           and min(p0[2], p1[2]) >= z0 - 0.3 and max(p0[2], p1[2]) <= z1 + 0.3)))  # noqa: E731
        hor = lambda Z, a_, b_: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[2] - Z) < 0.06 and abs(p1[2] - Z) < 0.06
                                                          and a_ <= 0.5 * (p0[0] + p1[0]) <= b_)))  # noqa: E731
        dims2 = {}
        for name, r, z0, z1, val, tol, zz in (("D_bore", BORE_D / 2.0, CAV, RING_TOP, BORE_D, "H7", 138.0),
                                              ("D_ring", RING_D / 2.0, HUB_TOP - 0.5, RING_TOP, RING_D, None, 106.0)):
            ca = N("c_%s_a" % name, vert(-r, z0, z1))
            cb = N("c_%s_b" % name, vert(r, z0, z1))
            if ca and cb:
                dims2[name] = dimc(name, ksec, ca, cb, (sx(0.0), sz(zz)), "cylindrical", val, etol=0.02, tol=tol)
        f19 = None
        if dims2.get("D_bore"):
            f19 = stack_fcf("fcf_perp_bore", dims2["D_bore"], "Perpendicularity", "0.03", ("A",), True, None)
        if f19 is not None:
            cbb = N("c_bore_wall", vert(BORE_D / 2.0, CAV, RING_TOP))
            datum_under("datum_B", "B", f19, lambda: gdt.datum(dwg, "B", (sx(30.0), sz(115.0)), cbb, ksec, (BORE_D / 2.0, 0.0, 88.0), size=GT))
        c_lip2 = N("c_lip2", hor(LIP, -HUB_R - 0.1, -60.0))
        c_face2 = N("c_face2", hor(HUB_TOP, -HUB_R - 0.1, -30.0))
        c_ring2 = N("c_ring2", hor(RING_TOP, -RING_D / 2.0 - 0.1, -BORE_D / 2.0 + 0.1))
        c_disc = N("c_disc", hor(CAV, -HUB_R, -40.0))
        xl = sx(-HUB_R - 12.0)
        if c_lip2 and c_face2:
            dimc("Z_lip_face", ksec, c_lip2, c_face2, (xl - 8.0, sz(60.0)), "vertical", HUB_TOP - LIP, etol=0.02)
        if c_lip2 and c_ring2:
            dimc("Z_lip_ring", ksec, c_lip2, c_ring2, (xl - 24.0, sz(64.0)), "vertical", RING_TOP - LIP, etol=0.02)
        if c_disc and c_face2:
            dimc("T_disc", ksec, c_disc, c_face2, (xl - 40.0, sz(78.0)), "vertical", HUB_TOP - CAV, etol=0.02)
        if c_face2:
            N("fcf_flat_face", lambda: gdt.fcf(dwg, "Flatness", "0.05", (), False, (sx(-58.0), sz(121.0)), c_face2, ksec,
                                               (-45.0, 0.0, HUB_TOP), size=GT))
        hub_arc = N("c_hub_arc", lambda: arc_xy(ktop, M(0.0, 0.0, HUB_TOP), HUB_R, 2, 0.15))
        if hub_arc:
            D("D_hub", lambda: dia_dim(ktop, hub_arc[0], xy(ktop, M(80.0, -110.0, 0.0)), expect=2 * HUB_R))
        rk = KH_PCD / 2.0
        a0 = KH_ANG[0]

        def kh(ang):
            a = math.radians(ang)
            return M(rk * math.cos(a), rk * math.sin(a), RING_TOP)
        hole = N("c_khole", lambda: arc_xy(ktop, kh(a0 + 90.0), 1.65, 2, 0.1))
        if hole:
            dk = callout("callout_knee_holes", ktop, hole[0], hole[1], 1.65, 2, M(-97.0, -80.0, hole[1][2]),
                         ["%dX %s3.30 THRU (M4 TAP DRILL)" % (len(KH), DIA), "EQ SP ON %s%.2f" % (DIA, KH_PCD)], side="right")
            if dk:
                stack_fcf("fcf_pos_kholes", dk, "Position", "0.1", ("A", "B"), True, None)
        m3d.lnote("ln_slot", ["SLOT %.2f x %.2f THRU" % (SL_W, SL_L)], xy(ktop, M(-105.0, 135.0, 0.0)), ktop,
                  M(SL_X - SL_W / 2.0, SL_Y, HUB_TOP), size=DT)
    res["overlaps2"] = nxd.overlaps(sh2)

    # ================================================================ SHEET 3 mating side (A1, 1:1)
    sh3, _g = ptdwg.sheet(dwg, "A1")
    bot = nxd.base_view(dwg, dwg, "Bottom", (255.0, 400.0), scale=(1.0, 1.0))
    BD = BOSS[5]                                  # B6: face on datum A, hip end
    xs_b, yb = BD["x"], BD["y"]
    csec = nxd2.section(dwg, bot, M(xs_b, yb, LIP), (255.0, 165.0), (1.0, 1.0))
    relabel(csec, "F")
    hend = nxd.base_view(dwg, dwg, "Right", (690.0, 420.0), scale=(1.0, 1.0))
    bdet = N("bdet", lambda: nxd.detail_view(dwg, csec, M(xs_b, yb, 42.0), M(xs_b, yb + 13.0, 42.0), (690.0, 190.0), scale=(4.0, 1.0)))
    if bdet is not None:
        relabel(bdet, "G")
    res["views3"] = {v.Name: nxd.view_info(v) for v in (bot, csec, hend, bdet) if v is not None}
    res["rev3"] = N("rev_block_3", rev_block)
    res["tb3"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (detail G 4:1)", 3, NSH, rev=REV, subtitle="mating side")
    if MODE == "dump":
        res["dump_csec"] = m3d.dump(csec, os.path.join(OUTD, "dump_sh3_csec.json"))
        if bdet is not None:
            res["dump_bdet"] = m3d.dump(bdet, os.path.join(OUTD, "dump_sh3_bdet.json"))
    else:
        bx = lambda X: xy(bot, (X, 0.0, 0.0))[0]             # noqa: E731
        by = lambda Yd: xy(bot, (0.0, Yd, 0.0))[1]           # noqa: E731
        # pocket callout on B6 (datum-A pockets), the others in the SH4 table
        grpA = [b for b in BOSS if abs(b["face"] - ZA) < 0.005 and abs(b["pocket_d"] - BD["pocket_d"]) < 0.01]
        pk = N("c_pocket6", lambda: arc_xy(bot, M(xs_b, yb, ZA), BD["pocket_d"] / 2.0, 2, 0.1))
        others = [b["id"] for b in BOSS if b not in grpA]
        if pk:
            dp = callout("callout_pockets", bot, pk[0], pk[1], BD["pocket_d"] / 2.0, 2, M(xs_b + 40.0, yb + 35.0, ZA),
                         ["7X POCKET TO Z %.2f: %s" % (FLOOR, ", ".join(
                             "%dX %s%.2f +0.10/0%s" % (len(g), DIA, d, (" (%s)" % ", ".join(b["id"] for b in g)) if len(g) < 4 else "")
                             for d, g in sorted(((d_, [b for b in BOSS if abs(b["pocket_d"] - d_) < 0.01])
                                                 for d_ in set(round(b["pocket_d"], 2) for b in BOSS)), key=lambda t: -len(t[1])))),
                          "7X %s6.00 THRU, %s%.2f C'BORE FROM OUTSIDE" % (DIA, DIA, BD["cb_d"])])
            if dp:
                stack_fcf("fcf_pos_pockets", dp, "Position", "0.1", ("A", "B", "C"), True, None)
        p2 = PINS[1]
        ph = N("c_pinhole2", lambda: arc_xy(bot, M(p2["x"], p2["y"], p2["z0"]), 2.0, 2, 0.1))
        depths = sorted(set(round(p["z1"] - p["z0"], 2) for p in PINS))
        if ph:
            dpn = callout("callout_pins", bot, ph[0], ph[1], 2.0, 2, M(p2["x"] + 40.0, p2["y"] - 30.0, p2["z0"]),
                          ["3X %s4.00 H8 x %s DEEP" % (DIA, " / ".join("%.2f" % v for v in depths))], side="right")
            if dpn:
                stack_fcf("fcf_pos_pins", dpn, "Position", "0.05", ("A", "B"), True, None)
        cb_bot = N("c_bore_bot", lambda: arc_xy(bot, M(0.0, 0.0, CAV), BORE_D / 2.0, 2, 0.1))
        c_h0 = N("c_hipface0", lambda: edge_at(bot, 0, HIP_IN))
        c_h1 = N("c_hipface1", lambda: edge_at(bot, 0, HIP_OUT))
        if cb_bot and c_h0:
            D("L_B_hip_in", lambda: lin(bot, cb_bot[0], c_h0, (bx(133.0), by(-37.97) + 150.0), "horizontal", S.Center, S.Mid,
                                        basic=True, expect=HIP_IN))
        if cb_bot and c_h1:
            D("L_B_hip_out", lambda: lin(bot, cb_bot[0], c_h1, (bx(140.0), by(0.0) + 166.0), "horizontal", S.Center, S.Mid,
                                         basic=True, expect=HIP_OUT))
        # --- detail G (4:1) on boss B6: pocket, web, counterbore, datum A
        if bdet is not None:
            dz = lambda Z: xy(bdet, (0.0, 0.0, Z))[1]        # noqa: E731
            dx = lambda X: xy(bdet, (X, 0.0, 0.0))[0]        # noqa: E731
            dvert = lambda X, z0, z1: (lambda: longest(straight(bdet, lambda p0, p1: abs(p0[0] - X) < 0.06 and abs(p1[0] - X) < 0.06
                                                                and min(p0[2], p1[2]) >= z0 - 0.3 and max(p0[2], p1[2]) <= z1 + 0.3)))  # noqa: E731
            dhor = lambda Z, a_, b_: (lambda: longest(straight(bdet, lambda p0, p1: abs(p0[2] - Z) < 0.06 and abs(p1[2] - Z) < 0.06
                                                               and a_ <= 0.5 * (p0[0] + p1[0]) <= b_)))  # noqa: E731
            c_bface = N("c_bossface", dhor(BD["face"], yb + 5.0, yb + 7.6))
            c_pfl = N("c_pocketfloor", dhor(BD["floor"], yb - 4.0, yb + 4.0))
            c_web = N("c_webtop", dhor(BD["web1"], yb - 5.0, yb + 5.0))
            if c_bface and c_pfl:
                dimc("Z_pocket", bdet, c_bface, c_pfl, (dx(yb - 18.5), dz(37.5)), "vertical", BD["floor"] - BD["face"], etol=0.01)
            if c_bface and c_web:
                dimc("Z_web", bdet, c_bface, c_web, (dx(yb - 22.5), dz(41.0)), "vertical", BD["web1"] - BD["face"], etol=0.01)
            for name, r, z0, z1, val, zz in (("D_pocket", BD["pocket_d"] / 2.0, BD["face"], BD["floor"], BD["pocket_d"], 30.5),
                                             ("D_cbore", BD["cb_d"] / 2.0, BD["web1"], 90.0, BD["cb_d"], 52.5)):
                ca = N("c_%s_a" % name, dvert(yb - r, z0, z1))
                cb = N("c_%s_b" % name, dvert(yb + r, z0, z1))
                if ca and cb:
                    dimc(name, bdet, ca, cb, (dx(yb), dz(zz)), "horizontal", val, etol=0.01)
            if c_bface:
                fA = N("fcf_flat_A", lambda: gdt.fcf(dwg, "Flatness", "0.05", (), False, (dx(yb + 16.0), dz(30.0)), c_bface, bdet,
                                                     M(xs_b, yb + 6.5, BD["face"]), size=GT))
                if fA is not None:
                    datum_under("datum_A", "A", fA, lambda: gdt.datum(dwg, "A", (dx(yb + 16.0), dz(27.0)), c_bface, bdet,
                                                                      M(xs_b, yb + 6.0, BD["face"]), size=GT))
        # --- hip end view
        ex = lambda X: xy(hend, (0.0, X, 0.0))[0]            # noqa: E731
        ez = lambda Z: xy(hend, (0.0, 0.0, Z))[1]            # noqa: E731
        p3 = PINS[2]
        ph3 = N("c_pinhole3", lambda: arc_xy(bot, M(p3["x"], p3["y"], p3["z0"]), 2.0, 2, 0.1))
        if ph3:
            N("datum_C", lambda: gdt.datum(dwg, "C", xy(bot, M(p3["x"] - 28.0, p3["y"] + 22.0, p3["z0"])), ph3[0], bot,
                                           on_arc(ph3[1], 2.0, 2, M(p3["x"] - 28.0, p3["y"] + 22.0, p3["z0"])), size=GT))
        c_seat = N("c_seat", lambda: longest(straight(hend, lambda p0, p1: abs(p0[2] - HSEAT) < 0.06 and abs(p1[2] - HSEAT) < 0.06)))
        c_lipe = N("c_lip_end", lambda: longest(straight(hend, lambda p0, p1: abs(p0[2] - LIP) < 0.06 and abs(p1[2] - LIP) < 0.06)))
        if c_seat and c_lipe:
            dimc("Z_lip_seat", hend, c_lipe, c_seat, (ex(-37.97) - 95.0, ez(60.0)), "vertical", HSEAT - LIP, etol=0.02)
        rb = MEAS["rebate_levels"]
        bA = [b for b in BOSS if abs(b["face"] - ZA) < 0.005]
        bC = [b for b in BOSS if b not in bA and abs(b["face"] - OUTER_BOSS_TOP.get(b["id"], OUTER_BOSS_DEFAULT)) < 0.005]
        bG = [b for b in BOSS if b not in bA and b not in bC]
        MEAS["boss_gaps"] = {b["id"]: round(b["face"] - OUTER_BOSS_TOP.get(b["id"], OUTER_BOSS_DEFAULT), 3) for b in BOSS}
        rows = [["MATING INTERFACE TO LT-OUT-001 REV F (Z IN MODEL FRAME)", ""],
                ["DATUM A: BOSS FACES %s (CONTACT)" % ", ".join(b["id"] for b in bA), "Z %.2f" % ZA]]
        if bC:
            rows.append(["BOSS FACE %s (OUTER PLATE, CONTACT)" % ", ".join(b["id"] for b in bC), " / ".join("Z %.2f" % b["face"] for b in bC)])
        if bG:
            rows.append(["BOSS FACES %s, GAP %s TO OUTER Z %.2f" % (" / ".join(b["id"] for b in bG),
                         " / ".join("%.2f" % MEAS["boss_gaps"][b["id"]] for b in bG), OUTER_BOSS_DEFAULT),
                         " / ".join("Z %.2f" % b["face"] for b in bG)])
        rows += [["LIP FACE (GAP TO OUTER RIM Z 34.76)", "Z %.2f" % LIP],
                ["JOINT BAND FLOORS (GAPS: SEE BELOW)", " / ".join("%.2f" % z for z in rb)],
                ["POCKET FLOORS (OUTER NUB TOPS 39.04 / 39.00)", "Z %.2f" % FLOOR],
                ["HIP RING SEAT (OUTER RING TOP Z 85.20)", "Z %.2f" % HSEAT],
                ["DATUM C: PIN HOLE P3", "X %.2f  Y %.2f" % (p3["x"], p3["y"])],
                ["HIP RING CLEARANCE (OUTER RING %s105.03)" % DIA, "%s%.2f ON X %.2f Z %.2f" % (DIA, HCL_D, HCL_AX[0], HCL_AX[1])]]
        N("table3", lambda: table((482.0, 330.0), [136.0, 70.0], rows))
        note_lines(["FLOOR GAPS TO LT-OUT-001 REV F:",
                    "+X FLOOR 36.19: 0.19 OVER THE TONGUE",
                    "-X FLOOR 36.23: 0.23 / 0.16",
                    "HIP FLOORS 36.30 / 36.36: 0.23 / 0.12"], 482.0, 330.0 - 8.0 * (len(rows) + 1) - 4.0, step=7.0, size=3.5)
    res["overlaps3"] = nxd.overlaps(sh3)

    # ================================================================ SHEET 4 interior features (A1, 1:1)
    sh4, _g = ptdwg.sheet(dwg, "A1")
    ibot = nxd.base_view(dwg, dwg, "Bottom", (250.0, 300.0), scale=(1.0, 1.0))
    res["views4"] = {ibot.Name: nxd.view_info(ibot)}
    res["rev4"] = N("rev_block_4", rev_block)
    res["tb4"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 4, NSH, rev=REV, subtitle="interior features")
    if MODE != "dump":
        rows, feats = feature_rows(ibot)
        hdr = [["FEATURE LOCATIONS (BASIC, MODEL FRAME: ORIGIN ON B, SAME AS LT-OUT-001)", "", "", "", "", ""],
               ["ID", "X", "Y", "FEATURE", "FACE Z", "HOLE"]]
        trows = hdr + rows
        res["table4"] = N("table4", lambda: table((470.0, 570.0), [16.0, 24.0, 24.0, 90.0, 26.0, 78.0], trows, size=3.2, rh=7.2))
        ytab = 570.0 - 7.2 * len(trows)
        N("fcf_table_note", lambda: nxd.note(dwg, ["ALL FEATURES IN THIS TABLE:"], (470.0, ytab - 5.0), size=GT))
        N("fcf_table", lambda: gdt.fcf(dwg, "Position", "0.1", ("A", "B", "C"), True, (568.0, ytab - 1.0), size=GT))
        dnl = sorted(MD.zlevels(False)); upl = sorted(MD.zlevels(True))
        lv = [["FLAT LEVELS (Z IN MODEL FRAME, A = %.2f)" % ZA, ""],
              ["LIP FACE", "%.2f" % LIP],
              ["JOINT BAND FLOORS AND BOSS FACES", " / ".join("%.2f" % z for z in MEAS["rebate_levels"])],
              ["BOSS FACES (A) / %s" % ", ".join(b["id"] for b in BOSS if abs(b["face"] - ZA) >= 0.005), "%.2f / %s" % (ZA, " / ".join("%.2f" % b["face"] for b in BOSS if abs(b["face"] - ZA) >= 0.005))],
              ["POCKET FLOORS / WEB SEATS", "%.2f / %.2f" % (FLOOR, WEB1)],
              ["KNEE DISC INSIDE / OUTSIDE", "%.2f / %.2f" % (CAV, HUB_TOP)],
              ["HIP RING SEAT", "%.2f" % HSEAT],
              ["KNEE RING TOP", "%.2f" % RING_TOP]]
        N("table_levels", lambda: table((470.0, ytab - 22.0), [100.0, 136.0], lv, size=3.2, rh=7.2))
        place_balloons(ibot, feats, "b4")
    res["overlaps4"] = nxd.overlaps(sh4)

    # ================================================================ SHEET 5 ribs + window (A1, 1:1)
    sh5 = SH5_BUILD() if "SH5_BUILD" in globals() else None
    sheets = [sh1, sh2, sh3, sh4] + ([sh5] if sh5 is not None else [])
    res["export"] = ptdwg.export(dwg, sheets, OUTD, NO)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res["model_mtime_after"] = os.path.getmtime(MODEL)
res["model_untouched"] = res["model_mtime_after"] == res["model_mtime_before"]
nxh.write_json(os.path.join(OUTD, "dwg_result.json"), res)
