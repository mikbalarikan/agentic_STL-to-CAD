# -*- coding: utf-8 -*-
"""LT-OUT-001 Left Thigh - Outer shell: manufacturing drawing set, third angle, rev 2 of the layout.
run_journal dwg_main.py -args <model.prt> <out_dir> [dump|full]
Master-model drawing: the model is placed with drawing (X, Y, Z) = model (y, -x, z), so the length runs left
(knee) to right (hip) in the plan view. M(x, y, z) maps a MODEL point to drawing-part coordinates.
Datum system: A = knee mounting face (Z -8.35), B = knee bore Ø110 H7, C = hip bore Ø82 H7, D = hip outer face.
Dimension text 5 mm, every dimension text placed outside the part outline; GD&T frames instead of note text;
SH4 features identified by arrow balloons placed outside the part."""
import json
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\nx\dwglib")
import NXOpen  # noqa: E402
import NXOpen.Annotations  # noqa: E402
import nxh  # noqa: E402
import nxd  # noqa: E402
import nxd2  # noqa: E402
import ptdwg  # noqa: E402
import m3d  # noqa: E402
import gdt  # noqa: E402
from m3d import D, N, xy  # noqa: E402

MODEL, OUTD = sys.argv[1], sys.argv[2]
MODE = sys.argv[3] if len(sys.argv) > 3 else "full"
os.makedirs(OUTD, exist_ok=True)
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
NO, TITLE = "LT-OUT-001", "LEFT THIGH - OUTER SHELL"
PJ = json.load(open(os.path.join(ROOT, "nx", "params.json")))
OUTLINE = json.load(open(os.path.join(ROOT, "work", "plan_outline.json")))
FIN = json.load(open(os.path.join(os.path.dirname(MODEL), "_finalize.json")))
MASS = "%.2f kg" % (FIN["mass_g_al6061"] / 1000.0)
MAT = "Al 6061-T6"
R = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]]
S = nxd.SNAP
A = NXOpen.Annotations
DT = 5.0        # dimension text
GT = 4.5        # notes, GD&T frames, datum letters
res = {"result": "FAIL", "dims": {}, "errors": {}, "gdt": {}}
m3d.start(res)
HX, HZ = PJ["hip"]["ax_x"], PJ["hip"]["ax_z"]
DIA = "Ø"

# every ptdwg dimension (linear / radius) gets the larger text
_style0 = ptdwg._style
ptdwg._style = lambda b, prec=2, text_size=None: _style0(b, prec, text_size or DT)


def M(x, y, z):
    return (y, -x, z)


def straight(view, pred):
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 3 and pred(p[0], p[1]):
            out.append((c, p))
    return out


def longest(cands):
    if not cands:
        raise RuntimeError("no curve")
    return max(cands, key=lambda cp: sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)))[0]


def at(ax, val, tol=0.05):
    return lambda p0, p1: abs(p0[ax] - val) <= tol and abs(p1[ax] - val) <= tol


def dimc(name, view, ca, cb, origin, method, expect, etol=0.05, **kw):
    return D(name, lambda: m3d.dim_curves(view, ca, cb, origin, method, expect=expect, etol=etol, **kw))


def arc_xy(view, centre, r, skip, tol=0.08):
    """Circular drafting curve of radius r whose centre matches `centre` (drawing coords) in the two axes other
    than `skip` (the view direction). Among several (top / bottom edge) the one nearest the viewer wins."""
    best = None
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) != 2:
            continue
        rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
        if abs(rr - r) > tol:
            continue
        if max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip) > tol:
            continue
        if best is None or p[0][skip] > best[1][skip]:
            best = (c, p[0])
    if best is None:
        near = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) != 2:
                continue
            rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
            dc = max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip)
            if dc < 1.0 and 0.4 * r < rr < 2.5 * r:
                near.append((abs(rr - r), -p[0][skip], c, p[0], round(rr, 3)))
        if near:
            near.sort(key=lambda t: (round(t[0], 2), t[1]))
            res.setdefault("arc_fallback", []).append([view.Name, [round(v, 2) for v in centre], r, near[0][4]])
            return near[0][2], near[0][3]
        cand = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) == 2:
                rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
                cand.append((max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip), [round(v, 2) for v in p[0]], round(rr, 3)))
        cand.sort(key=lambda t: t[0])
        raise RuntimeError("arc_xy: no R%.3f at %s in %s; nearest %s" % (r, [round(v, 2) for v in centre], view.Name, cand[:6]))
    return best


def on_arc(centre, r, skip, toward):
    """Point of the arc (drawing coords) in the direction of `toward` (drawing coords, same plane)."""
    ax = [i for i in range(3) if i != skip]
    dx, dy = toward[ax[0]] - centre[ax[0]], toward[ax[1]] - centre[ax[1]]
    n = math.hypot(dx, dy) or 1.0
    p = list(centre)
    p[ax[0]] += r * dx / n
    p[ax[1]] += r * dy / n
    return tuple(p)


def lin(view, ca, cb, origin, method, sa, sb, before=None, after=None, basic=False, tol=None, expect=None, etol=0.05):
    """Linear dimension with explicit snaps; basic=True draws it boxed (theoretically exact)."""
    meth = {"horizontal": nxd.MM.Horizontal, "vertical": nxd.MM.Vertical, "point": nxd.MM.PointToPoint,
            "cylindrical": nxd.MM.Cylindrical}[method]
    dwg = m3d.CTX["dwg"]
    b = dwg.Dimensions.CreateLinearDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = meth
        b.FirstAssociativity.SetValue(sa, ca, view, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(sb, cb, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=tol, before=before, after=after)
        _style0(b, 2, DT)
        if basic:
            b.Style.DimensionStyle.ToleranceType = A.ToleranceType.Basic
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if expect is not None and abs(d.ComputedSize - expect) > etol:
        v = d.ComputedSize
        ptdwg._delete([d])
        raise RuntimeError("lin: %.4f instead of %.4f" % (v, expect))
    return d


def dia_callout(view, arc, origin, before=None, after=None, tol=None):
    return nxd.dim_radial(m3d.CTX["dwg"], view, arc, origin, diameter=True, before=before, after=after, tol=tol,
                          text_size=DT)


def stack_fcf(name, dim, char, tol, datums=(), dia=False, pos=None):
    """FCF stacked under a dimension (NX 'attached to stack' origin); fallback: free FCF at `pos`."""
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
            try:
                b.Characteristic = gdt.characteristic(char)
                b.FrameStyle = A.FeatureControlFrameBuilder.FcfFrameStyle.SingleFrame
                b.FeatureControlFrameDataList.Append(dwg.Annotations.CreateFeatureControlFrameDataBuilder(None))
                d = b.FeatureControlFrameDataList.FindItem(0)
                if dia:
                    d.ZoneShape = A.FeatureControlFrameDataBuilder.ToleranceZoneShape.Diameter
                d.ToleranceValue = str(tol)
                for r_, l_ in zip((d.PrimaryDatumReference, d.SecondaryDatumReference, d.TertiaryDatumReference), datums):
                    r_.Letter = l_
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(dim))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-400:]
            if pos is None:
                raise
            o = gdt.fcf(dwg, char, tol, datums, dia, pos, size=GT)
            res["gdt"][name] = "free"
            return o
    return N(name, f)


def stack_below(ann):
    """Associative origin: stacked below `ann` (probe: only OffsetAnnotation carries the stack parent)."""
    ao = A.Annotation.AssociativeOriginData()
    ao.OriginType = A.AssociativeOriginType.AttachedToStack
    ao.StackAlignmentPosition = A.StackAlignmentPosition.Below
    ao.OffsetAnnotation = ann
    return ao


def datum_under(name, letter, ann, fallback):
    """Datum feature symbol stacked below an FCF / dimension of the datum feature (no leader); fallback()."""
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.Datums.CreateDraftingDatumFeatureSymbolBuilder(None)
            try:
                b.Letter = letter
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(ann))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-300:]
            o = fallback()
            res["gdt"][name] = "leader"
            return o
    return N(name, f)


def callout(name, view, arc, cen, r, skip, toward, lines):
    """Leader note (arrow on the hole edge) at the sheet image of drawing point `toward`."""
    a = on_arc(cen, r, skip, toward)
    pos = xy(view, toward)
    return N(name, lambda: nxd2.leader_note(m3d.CTX["dwg"], lines, pos, arc, view, a, size=DT))


def table(origin, cw, rows, size=3.5, rh=8.0):
    """Tabular note, title row merged and in the same text size as the body."""
    m = [(0, 0, 0, len(cw) - 1)]
    _ts, tn = nxd2.table(m3d.CTX["dwg"], origin, cw, [rh] * len(rows), rows, text_size=size, merges=m, sizes={(0, 0): size})
    return nxd2.table_text(tn)


def note_lines(lines, x, y, step=8.0, size=GT):
    """One note per line (fixed pitch), so a GD&T frame can sit at the end of a given line."""
    for i, t in enumerate(lines):
        if not t:
            continue
        N("note_%d_%d" % (int(x), int(y - i * step)), lambda t=t, i=i: nxd.note(m3d.CTX["dwg"], [t], (x, y - i * step), size=size))


def text_w(t, size=GT):
    return len(t) * 0.745 * size


