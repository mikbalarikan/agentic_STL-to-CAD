"""Stage M2: remove the 0.1 mm2 cylinder sliver near (65.5, 104.2, 76.85) (where the stage-L channel tools F04 / F13a /
A029 meet) that the AP214 writer turns into an unorientable face. Delete Face with heal on a copy of the stage-M part.
Also lists every face of the body under 0.5 mm2. args: src_prt out_dir"""
import os, sys, json, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
res = {"result": "FAIL", "log": []}
BOX = (64.9, 103.0, 76.5, 66.1, 105.6, 77.2)
try:
    prt = os.path.join(OUT, "Left_Thigh_Inner.prt")
    shutil.copyfile(SRC, prt)
    part = nxh.open_part(prt)
    body = [b for b in part.Bodies if b.IsSolidBody and b.Name == "INNER"][0]
    v0 = nxh.volume(part, body)
    small, hit = [], []
    for f in body.GetFaces():
        a = nxh.sheet_area(part, [f])[0]
        bb = nxh.bbox(f)
        if a < 0.5:
            small.append([round(a, 4), str(f.SolidFaceType), bb])
        if all(BOX[i] <= bb[i] and bb[i + 3] <= BOX[i + 3] for i in range(3)) and a < 1.0:
            hit.append((f, a, bb))
    res["small_faces"] = small
    res["hit"] = [[round(a, 4), str(f.SolidFaceType), bb] for f, a, bb in hit]
    if hit:
        nxf.delete_face(part, [f for f, _, _ in hit], heal=True)
    v1 = nxh.volume(part, body)
    res["volume"] = [round(v0, 2), round(v1, 2)]
    res["body_ok"] = nxh.body_ok(part, body)
    res["feature_errors"] = [str(e) for e in nxh.feature_errors(part)][:10]
    res["solids"] = [[b.Name, round(nxh.volume(part, b), 1)] for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
    nxre.stl_export(part, body, os.path.join(OUT, "inner_Z.stl"), chord=0.01, max_edge=2.0)
    nxh.save(part)
    res["result"] = "PASS" if hit and res["body_ok"] and abs(v1 - v0) < 1.0 else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
json.dump(res, open(os.path.join(OUT, "fix_sliver.json"), "w"), indent=1, default=str)
