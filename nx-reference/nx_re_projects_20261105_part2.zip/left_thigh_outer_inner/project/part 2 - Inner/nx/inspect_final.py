"""Read-only look at the user-edited overlay part: bodies, the last features, volume. args: prt out_json"""
import os, sys, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

res = {"result": "FAIL"}
try:
    part = nxh.open_part(sys.argv[1])
    bl = []
    for b in part.Bodies:
        conv = False
        try:
            conv = b.IsConvergentBody
        except Exception:  # noqa: BLE001
            pass
        r = {"name": b.Name, "tag": b.Tag, "solid": b.IsSolidBody, "conv": conv, "blanked": b.IsBlanked,
             "layer": b.Layer, "faces": len(b.GetFaces()) if not conv else None}
        if b.IsSolidBody and not conv:
            r["volume"] = nxh.volume(part, b)
            r["bbox"] = nxh.bbox(b)
            try:
                r["examine"] = nxh.examine_geometry(part, b)
            except Exception as e:  # noqa: BLE001
                r["examine_err"] = str(e)
            try:
                r["owner"] = b.GetFeatures()[-1].GetFeatureName() if b.GetFeatures() else None
            except Exception as e:  # noqa: BLE001
                r["owner_err"] = str(e)
        bl.append(r)
    res["bodies"] = bl
    feats = list(part.Features)
    res["n_features"] = len(feats)
    res["last_features"] = []
    for f in feats[-40:]:
        row = {"name": f.GetFeatureName(), "type": f.FeatureType, "ts": f.Timestamp, "supp": f.Suppressed}
        try:
            m = list(f.GetFeatureErrorMessages() or [])
            if m:
                row["err"] = m
        except Exception:  # noqa: BLE001
            pass
        res["last_features"].append(row)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(sys.argv[2], res)
