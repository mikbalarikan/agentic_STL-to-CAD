# -*- coding: utf-8 -*-
"""LT-INN-001 Left Thigh - Inner shell: manufacturing drawing set, third angle (layout of LT-OUT-001 rev 2).
run_journal dwg_main.py -args <model.prt> <out_dir> [dump|full]
Master-model drawing: the model is placed with drawing (X, Y, Z) = model (y, -x, z), so the length runs left
(knee) to right (hip) in the plan view. M(x, y, z) maps a MODEL point to drawing-part coordinates.
Datum system (same axes as LT-OUT-001): A = mating face (the 7 boss faces, Z 35.95), B = knee bore (knee axis),
C = pin hole P3 (hip end). Dimension text 5 mm outside the part outline; GD&T frames; arrow balloons outside."""
import json
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\nx\dwglib")
import NXOpen  # noqa: E402
import NXOpen.Annotations  # noqa: E402
import nxh  # noqa: E402
import nxd  # noqa: E402
import nxd2  # noqa: E402
import ptdwg  # noqa: E402
ptdwg.DATE = "2026-10-31"
import m3d  # noqa: E402
import gdt  # noqa: E402
from m3d import D, N, xy  # noqa: E402

MODEL, OUTD = sys.argv[1], sys.argv[2]
MODE = sys.argv[3] if len(sys.argv) > 3 else "full"
os.makedirs(OUTD, exist_ok=True)
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
NO, TITLE = "LT-INN-001", "LEFT THIGH - INNER SHELL"
PJ = json.load(open(os.path.join(ROOT, "nx", "params.json")))
OUTLINE = json.load(open(os.path.join(ROOT, "work", "plan_outline.json"))) if os.path.exists(os.path.join(ROOT, "work", "plan_outline.json")) else None
FIN = json.load(open(os.path.join(os.path.dirname(MODEL), "_finalize.json")))
MASS = "%.2f kg" % (FIN["mass_g_al6061"] / 1000.0)
MAT = "Al 6061-T6"
R = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]]
S = nxd.SNAP
A = NXOpen.Annotations
DT = 5.0        # dimension text
GT = 4.5        # notes, GD&T frames, datum letters
res = {"result": "FAIL", "dims": {}, "errors": {}, "gdt": {}}
m3d.start(res)
HX, HZ = PJ["hip"]["ax_x"], PJ["hip"]["ax_z"]
DIA = "Ø"

# every ptdwg dimension (linear / radius) gets the larger text
_style0 = ptdwg._style
ptdwg._style = lambda b, prec=2, text_size=None: _style0(b, prec, text_size or DT)


def M(x, y, z):
    return (y, -x, z)


def straight(view, pred):
    """Lines ([start, end, mid]) and open splines ([start, end], not circles) whose end points satisfy pred."""
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 3 or (len(p) == 2 and not ptdwg._is_arc(c)):
            if pred(p[0], p[1]):
                out.append((c, p))
    return out


def longest(cands):
    if not cands:
        raise RuntimeError("no curve")
    return max(cands, key=lambda cp: sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)))[0]


def at(ax, val, tol=0.05):
    return lambda p0, p1: abs(p0[ax] - val) <= tol and abs(p1[ax] - val) <= tol


def dimc(name, view, ca, cb, origin, method, expect, etol=0.05, **kw):
    return D(name, lambda: m3d.dim_curves(view, ca, cb, origin, method, expect=expect, etol=etol, **kw))


def arc_xy(view, centre, r, skip, tol=0.08):
    """Circular drafting curve of radius r whose centre matches `centre` (drawing coords) in the two axes other
    than `skip` (the view direction). Among several (top / bottom edge) the one nearest the viewer wins."""
    best = None
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 2:                       # full circle: [centre, point]
            cen, q = p[0], p[1]
        elif len(p) == 4:                     # arc: [start, end, centre, mid]
            cen, q = p[2], p[0]
        else:
            continue
        rr = sum((cen[i] - q[i]) ** 2 for i in range(3)) ** 0.5
        if abs(rr - r) > tol:
            continue
        if max(abs(cen[i] - centre[i]) for i in range(3) if i != skip) > tol:
            continue
        if best is None or cen[skip] > best[1][skip]:
            best = (c, cen)
    if best is None:
        near = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) != 2:
                continue
            rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
            dc = max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip)
            if dc < 1.0 and 0.4 * r < rr < 2.5 * r:
                near.append((abs(rr - r), -p[0][skip], c, p[0], round(rr, 3)))
        if near:
            near.sort(key=lambda t: (round(t[0], 2), t[1]))
            res.setdefault("arc_fallback", []).append([view.Name, [round(v, 2) for v in centre], r, near[0][4]])
            return near[0][2], near[0][3]
        cand = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) == 2:
                rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
                cand.append((max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip), [round(v, 2) for v in p[0]], round(rr, 3)))
        cand.sort(key=lambda t: t[0])
        raise RuntimeError("arc_xy: no R%.3f at %s in %s; nearest %s" % (r, [round(v, 2) for v in centre], view.Name, cand[:6]))
    return best


def on_arc(centre, r, skip, toward):
    """Point of the arc (drawing coords) in the direction of `toward` (drawing coords, same plane)."""
    ax = [i for i in range(3) if i != skip]
    dx, dy = toward[ax[0]] - centre[ax[0]], toward[ax[1]] - centre[ax[1]]
    n = math.hypot(dx, dy) or 1.0
    p = list(centre)
    p[ax[0]] += r * dx / n
    p[ax[1]] += r * dy / n
    return tuple(p)


def lin(view, ca, cb, origin, method, sa, sb, before=None, after=None, basic=False, tol=None, expect=None, etol=0.05):
    """Linear dimension with explicit snaps; basic=True draws it boxed (theoretically exact)."""
    meth = {"horizontal": nxd.MM.Horizontal, "vertical": nxd.MM.Vertical, "point": nxd.MM.PointToPoint,
            "cylindrical": nxd.MM.Cylindrical}[method]
    dwg = m3d.CTX["dwg"]
    b = dwg.Dimensions.CreateLinearDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = meth
        b.FirstAssociativity.SetValue(sa, ca, view, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(sb, cb, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=tol, before=before, after=after)
        _style0(b, 2, DT)
        if basic:
            b.Style.DimensionStyle.ToleranceType = A.ToleranceType.Basic
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if expect is not None and abs(d.ComputedSize - expect) > etol:
        v = d.ComputedSize
        ptdwg._delete([d])
        raise RuntimeError("lin: %.4f instead of %.4f" % (v, expect))
    return d


def dia_dim(view, arc, origin):
    """Diametral dimension of a circular drafting curve, 2 decimals, decimal point, 5 mm text."""
    b = m3d.CTX["dwg"].Dimensions.CreateRadialDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = nxd.MM.Diametral
        b.FirstAssociativity.SetValue(nxd.SNAP.NotSet, arc, view, nxd.P0, None, None, nxd.P0)
        ptdwg._style(b, 2, DT)
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        return b.Commit()
    finally:
        b.Destroy()


def dia_callout(view, arc, origin, before=None, after=None, tol=None):
    return nxd.dim_radial(m3d.CTX["dwg"], view, arc, origin, diameter=True, before=before, after=after, tol=tol,
                          text_size=DT)


def stack_fcf(name, dim, char, tol, datums=(), dia=False, pos=None):
    """FCF stacked under a dimension (NX 'attached to stack' origin); fallback: free FCF at `pos`."""
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
            try:
                b.Characteristic = gdt.characteristic(char)
                b.FrameStyle = A.FeatureControlFrameBuilder.FcfFrameStyle.SingleFrame
                b.FeatureControlFrameDataList.Append(dwg.Annotations.CreateFeatureControlFrameDataBuilder(None))
                d = b.FeatureControlFrameDataList.FindItem(0)
                if dia:
                    d.ZoneShape = A.FeatureControlFrameDataBuilder.ToleranceZoneShape.Diameter
                d.ToleranceValue = str(tol)
                for r_, l_ in zip((d.PrimaryDatumReference, d.SecondaryDatumReference, d.TertiaryDatumReference), datums):
                    r_.Letter = l_
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(dim))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-400:]
            if pos is None:
                raise
            o = gdt.fcf(dwg, char, tol, datums, dia, pos, size=GT)
            res["gdt"][name] = "free"
            return o
    return N(name, f)


def stack_below(ann):
    """Associative origin: stacked below `ann` (probe: only OffsetAnnotation carries the stack parent)."""
    ao = A.Annotation.AssociativeOriginData()
    ao.OriginType = A.AssociativeOriginType.AttachedToStack
    ao.StackAlignmentPosition = A.StackAlignmentPosition.Below
    ao.OffsetAnnotation = ann
    return ao


def datum_under(name, letter, ann, fallback):
    """Datum feature symbol stacked below an FCF / dimension of the datum feature (no leader); fallback()."""
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.Datums.CreateDraftingDatumFeatureSymbolBuilder(None)
            try:
                b.Letter = letter
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(ann))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-300:]
            o = fallback()
            res["gdt"][name] = "leader"
            return o
    return N(name, f)


def callout(name, view, arc, cen, r, skip, toward, lines, side=None):
    """Leader note (arrow on the hole edge) at the sheet image of drawing point `toward`."""
    a = on_arc(cen, r, skip, toward)
    pos = xy(view, toward)
    return N(name, lambda: nxd2.leader_note(m3d.CTX["dwg"], lines, pos, arc, view, a, size=DT, side=side))


def table(origin, cw, rows, size=3.5, rh=8.0):
    """Tabular note, title row merged and in the same text size as the body."""
    m = [(0, 0, 0, len(cw) - 1)]
    _ts, tn = nxd2.table(m3d.CTX["dwg"], origin, cw, [rh] * len(rows), rows, text_size=size, merges=m, sizes={(0, 0): size})
    return nxd2.table_text(tn)


def note_lines(lines, x, y, step=8.0, size=GT):
    """One note per line (fixed pitch), so a GD&T frame can sit at the end of a given line."""
    for i, t in enumerate(lines):
        if not t:
            continue
        N("note_%d_%d" % (int(x), int(y - i * step)), lambda t=t, i=i: nxd.note(m3d.CTX["dwg"], [t], (x, y - i * step), size=size))


def text_w(t, size=GT):
    return len(t) * 0.745 * size




# params.json holds Z values BEFORE the final lift (build stage J, seat_dz): the drawing shows the lifted part
DZ = PJ.get("seat_dz", 0.0)
for k in ("lip", "boss_top", "rebate"):
    PJ["levels"][k] += DZ
for k in ("top_z", "cav_top", "low_z"):
    PJ["hub"][k] += DZ
PJ["hub"]["knee_boss"]["ring_top"] += DZ
PJ["hip"]["seat_z"] += DZ
for b_ in PJ["bosses"]:
    for k in ("top_z", "pocket_z1", "web_z1"):
        b_[k] += DZ
for p_ in PJ["pins"]:
    p_["z0"] += DZ; p_["z1"] += DZ
for h_ in PJ["channel_holes"]:
    h_["z0"] += DZ
for k in ("z0", "z1"):
    PJ["knee_ring_holes"][k] += DZ; PJ["disc_slot"][k] += DZ
HP = PJ["hip"]; HB = PJ["hub"]; KB = HB["knee_boss"]
ZA = PJ["levels"]["boss_top"]         # datum A plane (boss faces)
LIP = PJ["levels"]["lip"]
RB = PJ["levels"]["rebate"]
# Rev B additions (model frame, final values; not in params.json)
NEW_H = [(65.64, 91.82, 75.07, 3.3, 4.5), (77.20, 128.43, 75.07, 3.3, 6.0), (60.75, 131.45, 75.07, 3.3, 6.0), (52.90, 94.40, 75.07, 3.3, 6.0)]
NEW_N = [(-30.89, -51.41, 62.57, 3.0, "PIN %s3 x 6.93, 30%s TIP", 57.64), (-56.68, 19.53, 62.57, 3.0, "PIN %s3 x 6.93, 30%s TIP", 57.64),
         (49.03, 271.72, 85.32, 4.0, "PIN %s4 x 5.90, R1 TOP", 85.32), (27.04, 271.73, 85.32, 4.0, "PIN %s4 x 5.90, R1 TOP", 85.32)]
BOSS = PJ["bosses"]; PINS = PJ["pins"]; CH = PJ["channel_holes"]; KR = PJ["knee_ring_holes"]; SL = PJ["disc_slot"]
ENDY = PJ["expressions"]["end_y"][0]
DEG = "°"


def edge_at(view, ax, val, tol=0.06):
    """Longest drafting curve (line, spline or arc seen edge-on) whose end points (and arc mid point) all lie on
    drawing axis `ax` = val."""
    best = None
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 4:
            q = [p[0], p[1], p[3]]
        elif len(p) in (2, 3) and not (len(p) == 2 and ptdwg._is_arc(c)):
            q = p[:2]
        else:
            continue
        if all(abs(t[ax] - val) < tol for t in q):
            L = sum((q[0][i] - q[1][i]) ** 2 for i in range(3)) ** 0.5
            if best is None or L > best[0]:
                best = (L, c)
    if best is None:
        raise RuntimeError("edge_at: none at %s = %.3f in %s" % ("XYZ"[ax], val, view.Name))
    return best[1]


SHEETS_FOR_LABEL = []


def relabel(view, letter):
    """Set the letter of a detail view (NX gave the next free letter, C, which is also datum C):
    EditViewLabelSettingsBuilder.ViewCommonViewLabel.Letter (as in a recorded NX journal)."""
    sm = m3d.CTX["dwg"].SettingsManager
    res["label_api"] = [n for n in dir(sm) if "Label" in n]
    lab = None
    try:
        tag = nxh.UFS.Draw.AskViewLabel(view.Tag)
        lab = NXOpen.TaggedObjectManager.GetTaggedObject(tag)
    except Exception as e:  # noqa: BLE001
        res["label_uf_err"] = str(e)
    if lab is None:
        cands = [o for o in nxd2.sheet_objects(SHEETS_FOR_LABEL[0]) if "Label" in type(o).__name__]
        res["label_cands"] = [type(o).__name__ for o in cands]
        lab = cands[-1]
    res["label_type"] = type(lab).__name__
    b = sm.CreateDrawingEditViewLabelSettingsBuilder([lab])
    try:
        b.ViewCommonViewLabel.Letter = letter
        b.Commit()
    finally:
        b.Destroy()
    return "ok"


def dumpv(tag, v):
    res["dump_" + tag] = m3d.dump(v, os.path.join(OUTD, "dump_%s.json" % tag))
    res["vinfo_" + tag] = nxd.view_info(v)


def seg_on(view, ax, val, lo_ax, lo, hi, tol=0.06):
    """Longest straight drafting curve lying on drawing axis `ax` = val, its mid point between lo and hi on lo_ax."""
    return lambda: longest(straight(view, lambda p0, p1: abs(p0[ax] - val) < tol and abs(p1[ax] - val) < tol
                                    and lo <= 0.5 * (p0[lo_ax] + p1[lo_ax]) <= hi))


try:
    dwg, comp = m3d.new_drawing(os.path.join(OUTD, NO + "_dwg.prt"), MODEL, "LEFT_THIGH_INNER", R, refset="SOLID")
    # ================================================================ SHEET 1 general arrangement (A1, 1:1)
    sh1, _g = ptdwg.sheet(dwg, "A1")
    front = nxd.base_view(dwg, dwg, "Front", (255.0, 140.0), scale=(1.0, 1.0))
    top = nxd.projected_view(dwg, front, (255.0, 390.0))
    right = nxd.projected_view(dwg, front, (565.0, 140.0))
    iso = nxd.base_view(dwg, dwg, "Isometric", (705.0, 470.0), scale=(1.0, 2.0))
    res["tb1"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (iso 1:2)", 1, 4, rev="B", subtitle="general arrangement")
    if MODE == "dump":
        for tg, v in (("sh1_front", front), ("sh1_top", top), ("sh1_right", right)):
            dumpv(tg, v)
    else:
        fx = lambda X: xy(front, (X, 0.0, 0.0))[0]           # noqa: E731
        fz = lambda Z: xy(front, (0.0, 0.0, Z))[1]           # noqa: E731
        c_knee = N("c_knee", seg_on(front, 0, -HB["r_out"], 2, LIP, HB["top_z"], 0.1))
        c_end = N("c_end", seg_on(front, 0, ENDY, 2, LIP - 1.0, 120.0, 0.1))
        c_lip = N("c_lip", seg_on(front, 2, LIP, 0, -80.0, 300.0))
        c_face = N("c_kface", seg_on(front, 2, HB["top_z"], 0, -70.0, 60.0))
        c_ring = N("c_ringtop", seg_on(front, 2, KB["ring_top"], 0, -25.0, 25.0))
        if c_knee and c_end:
            dimc("L_overall", front, c_knee, c_end, (fx(110.0), fz(10.0)), "horizontal", 355.25, etol=0.2)
        if c_lip and c_ring:
            dimc("H_lip_ring", front, c_lip, c_ring, (fx(-112.0), fz(65.0)), "vertical", KB["ring_top"] - LIP, etol=0.05)
        x0, y0 = 470.0, 330.0
        note_lines(["NOTES",
                    "1. GENERAL TOLERANCES ISO 2768-mK. GD&T PER ISO 1101.",
                    "2. GEOMETRY NOT DIMENSIONED PER 3D MODEL LT-INN-001 REV B.",
                    "3. ALL SURFACES UNLESS OTHERWISE SPECIFIED:",
                    "",
                    "4. INTERNAL CORNERS R3 MAX. BREAK SHARP EDGES 0.2-0.5.",
                    "5. Ra 3.2 UNLESS OTHERWISE SPECIFIED.",
                    "6. MATES WITH LT-OUT-001 REV C, SAME MODEL FRAME.",
                    "7. REV B: PINS, LUGS, GUSSETS, CHANNEL HOLES ADDED; JOINT BAND CLEANED."], x0, y0, step=9.0)
        N("fcf_profile_all", lambda: gdt.fcf(dwg, "ProfileOfASurface", "0.2", ("A", "B", "C"), False,
                                             (x0 + 7.0, y0 - 4 * 9.0 + 2.0), size=GT))
    res["overlaps1"] = nxd.overlaps(sh1)

    # ================================================================ SHEET 2 knee (A1, 1:1)
    sh2, _g = ptdwg.sheet(dwg, "A1")
    ktop = nxd.base_view(dwg, dwg, "Top", (330.0, 425.0), scale=(1.0, 1.0))
    ksec = nxd2.section(dwg, ktop, M(0.0, 0.0, 0.0), (330.0, 190.0), (1.0, 1.0))
    res["tb2"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 2, 4, rev="B", subtitle="knee")
    if MODE == "dump":
        dumpv("sh2_ktop", ktop); dumpv("sh2_ksec", ksec)
    else:
        sx = lambda X: xy(ksec, (X, 0.0, 0.0))[0]            # noqa: E731
        sz = lambda Z: xy(ksec, (0.0, 0.0, Z))[1]            # noqa: E731
        vert = lambda X, z0, z1: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[0] - X) < 0.06 and abs(p1[0] - X) < 0.06
                                                           and min(p0[2], p1[2]) >= z0 - 0.3 and max(p0[2], p1[2]) <= z1 + 0.3)))  # noqa: E731
        hor = lambda Z, a_, b_: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[2] - Z) < 0.06 and abs(p1[2] - Z) < 0.06
                                                          and a_ <= 0.5 * (p0[0] + p1[0]) <= b_)))  # noqa: E731
        rb_ = HB["bore_d"] / 2.0
        rr_ = KB["ring_d"] / 2.0
        dims2 = {}
        for name, r, z0, z1, val, tol, zz in (("D19_90", rb_, HB["cav_top"], KB["ring_top"], HB["bore_d"], "H7", 138.0),
                                              ("D40_23", rr_, HB["top_z"] - 0.5, KB["ring_top"], KB["ring_d"], None, 106.0)):
            ca = N("c_%s_a" % name, vert(-r, z0, z1))
            cb = N("c_%s_b" % name, vert(r, z0, z1))
            if ca and cb:
                dims2[name] = dimc(name, ksec, ca, cb, (sx(0.0), sz(zz)), "cylindrical", val, etol=0.1, tol=tol)
        f19 = None
        if dims2.get("D19_90"):
            f19 = stack_fcf("fcf_perp_19", dims2["D19_90"], "Perpendicularity", "0.03", ("A",), True, None)
        if f19 is not None:
            cbb = N("c_bore_wall", vert(rb_, HB["cav_top"], KB["ring_top"]))
            datum_under("datum_B", "B", f19, lambda: gdt.datum(dwg, "B", (sx(30.0), sz(115.0)), cbb, ksec, (rb_, 0.0, 88.0), size=GT))
        c_lip2 = N("c_lip2", hor(LIP, -HB["r_out"] - 0.1, -HB["r_in"] + 0.1))
        c_face2 = N("c_face2", hor(HB["top_z"], -64.6, -30.0))
        c_ring2 = N("c_ring2", hor(KB["ring_top"], -20.2, -9.8))
        c_disc = N("c_disc", hor(HB["cav_top"], -64.0, -50.0))
        xl = sx(-HB["r_out"] - 12.0)
        if c_lip2 and c_face2:
            dimc("Z_lip_face", ksec, c_lip2, c_face2, (xl - 8.0, sz(60.0)), "vertical", HB["top_z"] - LIP, etol=0.05)
        if c_lip2 and c_ring2:
            dimc("Z_lip_ring", ksec, c_lip2, c_ring2, (xl - 24.0, sz(64.0)), "vertical", KB["ring_top"] - LIP, etol=0.05)
        if c_disc and c_face2:
            dimc("T_disc", ksec, c_disc, c_face2, (xl - 40.0, sz(78.0)), "vertical", HB["top_z"] - HB["cav_top"], etol=0.05)
        m3d.lnote("ln_chamfer", ["%.1f x 45%s" % (HB["chamfer"], DEG)], (sx(-120.0), sz(101.0)), ksec,
                  (-HB["r_out"] + HB["chamfer"] / 2.0, 0.0, HB["top_z"] - HB["chamfer"] / 2.0), size=DT)
        if c_face2:
            N("fcf_flat_face", lambda: gdt.fcf(dwg, "Flatness", "0.05", (), False, (sx(-58.0), sz(121.0)), c_face2, ksec,
                                               (-45.0, 0.0, HB["top_z"]), size=GT))
        tx = lambda X: xy(ktop, (X, 0.0, 0.0))[0]            # noqa: E731
        ty = lambda Y: xy(ktop, (0.0, Y, 0.0))[1]            # noqa: E731
        hub_arc = N("c_hub_arc", lambda: arc_xy(ktop, M(0.0, 0.0, HB["top_z"] - HB["chamfer"]), HB["r_out"], 2, 0.15))
        if hub_arc:
            D("D135_70", lambda: dia_dim(ktop, hub_arc[0], xy(ktop, M(80.0, -110.0, 0.0))))
        rk = KR["pcd"] / 2.0

        def kh(ang):
            a = math.radians(ang)
            return M(rk * math.cos(a), rk * math.sin(a), KB["ring_top"])
        hole = N("c_khole", lambda: arc_xy(ktop, kh(KR["clock"] + 90.0), KR["d"] / 2.0, 2, 0.1))
        if hole:
            dk = callout("callout_knee_holes", ktop, hole[0], hole[1], KR["d"] / 2.0, 2, M(-97.0, -80.0, hole[1][2]),
                         ["4X %s%.2f THRU (M4 TAP DRILL)" % (DIA, KR["d"]), "EQ SP ON %s%.2f" % (DIA, KR["pcd"])], side="right")
            if dk:
                stack_fcf("fcf_pos_kholes", dk, "Position", "0.1", ("A", "B"), True, None)
        h1 = N("c_khole1", lambda: arc_xy(ktop, kh(KR["clock"]), KR["d"] / 2.0, 2, 0.1))
        h3 = N("c_khole3", lambda: arc_xy(ktop, kh(KR["clock"] + 180.0), KR["d"] / 2.0, 2, 0.1))
        m3d.lnote("ln_slot", ["SLOT %.2f x %.2f THRU" % (SL["w"], SL["l"])], xy(ktop, M(-105.0, 135.0, 0.0)), ktop,
                  M(SL["x"] - SL["w"] / 2.0, SL["y"], HB["top_z"]), size=DT)
    res["overlaps2"] = nxd.overlaps(sh2)

    # ================================================================ SHEET 3 mating side (A1, 1:1)
    sh3, _g = ptdwg.sheet(dwg, "A1")
    bot = nxd.base_view(dwg, dwg, "Bottom", (255.0, 400.0), scale=(1.0, 1.0))
    xs_b = BOSS[6]["x"]
    csec = nxd2.section(dwg, bot, M(xs_b, BOSS[6]["y"], LIP), (255.0, 165.0), (1.0, 1.0))
    hend = nxd.base_view(dwg, dwg, "Right", (690.0, 420.0), scale=(1.0, 1.0))
    bdet = N("bdet", lambda: nxd.detail_view(dwg, csec, M(xs_b, BOSS[6]["y"], 42.0), M(xs_b, BOSS[6]["y"] + 13.0, 42.0),
                                             (690.0, 190.0), scale=(4.0, 1.0)))
    SHEETS_FOR_LABEL[:] = [sh3]
    if bdet is not None:
        res["relabel"] = N("relabel_detail", lambda: relabel(bdet, "D"))
    res["tb3"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (detail D 4:1)", 3, 4, rev="B", subtitle="mating side")
    if MODE == "dump":
        dumpv("sh3_bot", bot); dumpv("sh3_csec", csec); dumpv("sh3_hend", hend)
        if bdet is not None:
            dumpv("sh3_bdet", bdet)
    else:
        # --- plan of the mating side: pocket and pin-hole callouts, hip-ring clearance positions from B
        bx = lambda X: xy(bot, (X, 0.0, 0.0))[0]             # noqa: E731
        by = lambda Yd: xy(bot, (0.0, Yd, 0.0))[1]           # noqa: E731
        b6 = BOSS[5]
        pk = N("c_pocket6", lambda: arc_xy(bot, M(b6["x"], b6["y"], ZA), b6["pocket_d"] / 2.0, 2, 0.1))
        if pk:
            dp = callout("callout_pockets", bot, pk[0], pk[1], b6["pocket_d"] / 2.0, 2, M(b6["x"] + 40.0, b6["y"] + 35.0, ZA),
                         ["7X %s%.2f +0.10/0 x %.2f DEEP" % (DIA, b6["pocket_d"], b6["pocket_z1"] - b6["top_z"]),
                          "%s%.2f THRU, %s%.2f C'BORE FROM OUTSIDE" % (DIA, b6["hole_d"], DIA, b6["cb_d"])])
            if dp:
                stack_fcf("fcf_pos_pockets", dp, "Position", "0.1", ("A", "B", "C"), True, None)
        p2 = PINS[1]
        ph = N("c_pinhole2", lambda: arc_xy(bot, M(p2["x"], p2["y"], LIP), p2["hole_d"] / 2.0, 2, 0.1))
        if ph:
            dpn = callout("callout_pins", bot, ph[0], ph[1], p2["hole_d"] / 2.0, 2, M(p2["x"] + 40.0, p2["y"] - 30.0, LIP),
                          ["3X %s%.2f H8 x %.2f DEEP" % (DIA, p2["hole_d"], p2["z1"] - p2["z0"])], side="right")
            if dpn:
                stack_fcf("fcf_pos_pins", dpn, "Position", "0.05", ("A", "B"), True, None)
        cb_bot = N("c_bore_bot", lambda: arc_xy(bot, M(0.0, 0.0, HB["cav_top"]), HB["bore_d"] / 2.0, 2, 0.1))
        c_h0 = N("c_hipface0", lambda: edge_at(bot, 0, HP["y0"]))
        c_h1 = N("c_hipface1", lambda: edge_at(bot, 0, PJ["hip_plate"]["y1"]))
        if cb_bot and c_h0:
            D("L_B_hip0", lambda: lin(bot, cb_bot[0], c_h0, (bx(133.0), by(-HP["ax_x"]) + 0.0 + 150.0), "horizontal", S.Center, S.Mid,
                                      basic=True, expect=HP["y0"]))
        if cb_bot and c_h1:
            D("L_B_hip1", lambda: lin(bot, cb_bot[0], c_h1, (bx(140.0), by(0.0) + 166.0), "horizontal", S.Center, S.Mid,
                                      basic=True, expect=PJ["hip_plate"]["y1"]))
        # --- section through boss B7: lip and rebate relative to A
        cz = lambda Z: xy(csec, (0.0, 0.0, Z))[1]            # noqa: E731
        cxs = lambda X: xy(csec, (X, 0.0, 0.0))[0]           # noqa: E731
        # --- detail D (4:1) on boss B7: pocket, web, counterbore, datum A
        if bdet is not None:
            dz = lambda Z: xy(bdet, (0.0, 0.0, Z))[1]        # noqa: E731
            dx = lambda X: xy(bdet, (X, 0.0, 0.0))[0]        # noqa: E731
            yb = BOSS[6]["y"]
            dvert = lambda X, z0, z1: (lambda: longest(straight(bdet, lambda p0, p1: abs(p0[0] - X) < 0.06 and abs(p1[0] - X) < 0.06
                                                                and min(p0[2], p1[2]) >= z0 - 0.3 and max(p0[2], p1[2]) <= z1 + 0.3)))  # noqa: E731
            dhor = lambda Z, a_, b_: (lambda: longest(straight(bdet, lambda p0, p1: abs(p0[2] - Z) < 0.06 and abs(p1[2] - Z) < 0.06
                                                               and a_ <= 0.5 * (p0[0] + p1[0]) <= b_)))  # noqa: E731
            bb = BOSS[6]
            c_bface = N("c_bossface", dhor(bb["top_z"], yb + 5.0, yb + 7.6))
            c_pfl = N("c_pocketfloor", dhor(bb["pocket_z1"], yb - 4.0, yb + 4.0))
            c_web = N("c_webtop", dhor(bb["web_z1"], yb - 5.0, yb + 5.0))
            if c_bface and c_pfl:
                dimc("Z_pocket", bdet, c_bface, c_pfl, (dx(yb - 18.5), dz(37.5)), "vertical", bb["pocket_z1"] - bb["top_z"], etol=0.02)
            if c_bface and c_web:
                dimc("Z_web", bdet, c_bface, c_web, (dx(yb - 22.5), dz(41.0)), "vertical", bb["web_z1"] - bb["top_z"], etol=0.02)
            for name, r, z0, z1, val, zz in (("DP10", bb["pocket_d"] / 2.0, bb["top_z"], bb["pocket_z1"], bb["pocket_d"], 30.5),
                                             ("DC10_4", bb["cb_d"] / 2.0, bb["web_z1"], 90.0, bb["cb_d"], 52.5)):
                ca = N("c_%s_a" % name, dvert(yb - r, z0, z1))
                cb = N("c_%s_b" % name, dvert(yb + r, z0, z1))
                if ca and cb:
                    dimc(name, bdet, ca, cb, (dx(yb), dz(zz)), "horizontal", val, etol=0.05)
            if c_bface:
                fA = N("fcf_flat_A", lambda: gdt.fcf(dwg, "Flatness", "0.05", (), False, (dx(yb + 16.0), dz(30.0)), c_bface, bdet,
                                                     M(bb["x"], yb + 6.5, bb["top_z"]), size=GT))
                if fA is not None:
                    datum_under("datum_A", "A", fA, lambda: gdt.datum(dwg, "A", (dx(yb + 16.0), dz(27.0)), c_bface, bdet,
                                                                      M(bb["x"], yb + 6.0, bb["top_z"]), size=GT))
        # --- hip end view: ring clearance (datum C) and the seat on the ring top
        ex = lambda X: xy(hend, (0.0, X, 0.0))[0]            # noqa: E731
        ez = lambda Z: xy(hend, (0.0, 0.0, Z))[1]            # noqa: E731
        # datum C: pin hole P3 at the hip end (clocking about B); the hip-ring clearance needs no cut (no inner material there)
        p3 = PINS[2]
        ph3 = N("c_pinhole3", lambda: arc_xy(bot, M(p3["x"], p3["y"], LIP), p3["hole_d"] / 2.0, 2, 0.1))
        if ph3:
            N("datum_C", lambda: gdt.datum(dwg, "C", xy(bot, M(p3["x"] - 28.0, p3["y"] + 22.0, LIP)), ph3[0], bot,
                                           on_arc(ph3[1], p3["hole_d"] / 2.0, 2, M(p3["x"] - 28.0, p3["y"] + 22.0, LIP)), size=GT))
        c_seat = N("c_seat", lambda: longest(straight(hend, lambda p0, p1: abs(p0[2] - HP["seat_z"]) < 0.06 and abs(p1[2] - HP["seat_z"]) < 0.06)))
        c_lipe = N("c_lip_end", lambda: longest(straight(hend, lambda p0, p1: abs(p0[2] - LIP) < 0.06 and abs(p1[2] - LIP) < 0.06)))
        if c_seat and c_lipe:
            dimc("Z_lip_seat", hend, c_lipe, c_seat, (ex(-HP["ax_x"]) - 95.0, ez(60.0)), "vertical", HP["seat_z"] - LIP, etol=0.05)
        # interface table
        rows = [["MATING INTERFACE TO LT-OUT-001 (Z IN MODEL FRAME)", ""],
                ["DATUM A: BOSS FACES (7X)", "Z %.2f" % ZA],
                ["LIP FACE (GAP TO OUTER RIM Z 34.76)", "Z %.2f" % LIP],
                ["REBATE FLOOR (OUTER TONGUE TOP Z 36.07)", "Z %.2f" % RB],
                ["POCKET FLOOR (OUTER NUB TOP 39.04)", "Z %.2f" % BOSS[0]["pocket_z1"]],
                ["HIP RING PAD (OUTER RING TOP Z 85.20)", "Z %.2f" % HP["seat_z"]],
                ["DATUM C: PIN HOLE P3", "X %.2f  Y %.2f" % (PINS[2]["x"], PINS[2]["y"])],
                ["HIP RING CLEARANCE (OUTER RING %s%.2f)" % (DIA, HP["ring_od"]), "%s%.2f ON X %.2f Z %.2f" % (DIA, PJ["hip_plate"]["clear_d"], HP["ax_x"], HP["ax_z"])]]
        N("table3", lambda: table((482.0, 330.0), [118.0, 70.0], rows))
    res["overlaps3"] = nxd.overlaps(sh3)

    # ================================================================ SHEET 4 interior features (A1, 1:1)
    sh4, _g = ptdwg.sheet(dwg, "A1")
    ibot = nxd.base_view(dwg, dwg, "Bottom", (250.0, 300.0), scale=(1.0, 1.0))
    res["tb4"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 4, 4, rev="B", subtitle="interior features")
    if MODE != "dump":
        rows = [["FEATURE LOCATIONS (BASIC, MODEL FRAME: ORIGIN ON B, SAME AS LT-OUT-001)", "", "", "", "", ""],
                ["ID", "X", "Y", "FEATURE", "FACE Z", "HOLE"]]
        for i, b in enumerate(BOSS, 1):
            rows.append(["B%d" % i, "%.2f" % b["x"], "%.2f" % b["y"], "BOSS %s15, POCKET %s10" % (DIA, DIA), "%.2f" % b["top_z"],
                         "%s6 THRU, CB %s10.4" % (DIA, DIA)])
        for i, p in enumerate(PINS, 1):
            rows.append(["P%d" % i, "%.2f" % p["x"], "%.2f" % p["y"], "PIN HOLE IN LUG %s9" % DIA, "%.2f" % p["z0"],
                         "%s4 H8 x 10 DEEP" % DIA])
        for i, h in enumerate(CH, 1):
            rows.append(["H%d" % i, "%.2f" % h["x"], "%.2f" % h["y"], "CHANNEL HOLE", "%.2f" % h["z0"], "%s%.1f x %.0f DEEP" % (DIA, h["d"], h["depth"])])
        for i, (x, y, z, d, dep) in enumerate(NEW_H, len(CH) + 1):
            rows.append(["H%d" % i, "%.2f" % x, "%.2f" % y, "CHANNEL HOLE", "%.2f" % z, "%s%.1f x %.1f DEEP" % (DIA, d, dep)])
        for i, (x, y, z, d, txt, _ze) in enumerate(NEW_N, 1):
            rows.append(["N%d" % i, "%.2f" % x, "%.2f" % y, txt % ((DIA, "°") if "TIP" in txt else (DIA,)), "%.2f" % z, "-"])
        rows.append(["L1", "-20.50", "188.40", "TAB 2.6, HOLE AXIS +X, Z 65.60", "-", "%s2.6 THRU" % DIA])
        rows.append(["L2", "-35.27", "237.45", "TAB 2.6, HOLE AXIS (0.79, 0.62), Z 54.60", "-", "%s2.6 THRU" % DIA])
        N("table4", lambda: table((470.0, 565.0), [18.0, 26.0, 26.0, 80.0, 30.0, 56.0], rows))
        N("fcf_table", lambda: gdt.fcf(dwg, "Position", "0.1", ("A", "B", "C"), True, (470.0, 565.0 - 8.0 * len(rows) - 12.0), size=GT))
        N("fcf_table_note", lambda: nxd.note(dwg, ["ALL B, P, H, N, L FEATURES:"], (470.0, 565.0 - 8.0 * len(rows) - 4.0), size=GT))
        lv = [["FLAT LEVELS (Z IN MODEL FRAME, A = %.2f)" % ZA, ""], ["LIP FACE", "%.2f" % LIP], ["REBATE FLOOR / BOSS EARS", "%.2f" % RB],
              ["BOSS FACES (A)", "%.2f" % ZA], ["POCKET FLOORS", "%.2f" % BOSS[0]["pocket_z1"]], ["RIB AND PAD FACES",
              " / ".join("%.2f" % (z + DZ) for z in (42.45, 62.45, 64.95, 69.95, 74.95, 76.75))], ["KNEE DISC INSIDE / OUTSIDE", "%.2f / %.2f" % (HB["cav_top"], HB["top_z"])],
              ["HIP RING PAD", "%.2f" % HP["seat_z"]], ["UPPER RIBS", " / ".join("%.2f" % (z + DZ) for z in (90.45, 105.75, 107.75))],
              ["KNEE RING TOP", "%.2f" % KB["ring_top"]]]
        N("table_levels", lambda: table((470.0, 300.0), [100.0, 136.0], lv))
        # balloons outside the part outline (Bottom view: sheet up = model +X)
        if OUTLINE:
            oy0, xs_min, xs_max = OUTLINE["y0"], OUTLINE["xmin"], OUTLINE["xmax"]

            def band(y, w=9.0):
                i0 = max(0, int(y - w - oy0)); i1 = min(len(xs_min) - 1, int(y + w - oy0))
                lo = [v for v in xs_min[i0:i1 + 1] if v == v]; hi = [v for v in xs_max[i0:i1 + 1] if v == v]
                return (min(lo) if lo else -70.0), (max(hi) if hi else 120.0)
            feats = []
            for i, b in enumerate(BOSS, 1):
                feats.append(("B%d" % i, b["x"], b["y"], b["top_z"], b["pocket_d"] / 2.0))
            for i, p in enumerate(PINS, 1):
                feats.append(("P%d" % i, p["x"], p["y"], p["z0"], p["hole_d"] / 2.0))
            for i, h in enumerate(CH, 1):
                feats.append(("H%d" % i, h["x"], h["y"], h["z0"], h["d"] / 2.0))
            for i, (x, y, z, d, dep) in enumerate(NEW_H, len(CH) + 1):
                feats.append(("H%d" % i, x, y, z, d / 2.0))
            for i, (x, y, z, d, txt, ze) in enumerate(NEW_N, 1):
                feats.append(("N%d" % i, x, y, ze, d / 2.0))
            GAP, PITCH = 17.0, 16.0
            sides = {"hi": [], "lo": []}
            for f in feats:
                lo, hi = band(f[2])
                sides["hi" if (hi - f[1]) <= (f[1] - lo) else "lo"].append(list(f))
            place = []
            for side, lst in sides.items():
                lst.sort(key=lambda f: f[2])
                ylast = -1e9
                for f in lst:
                    yb = max(f[2], ylast + PITCH)
                    ylast = yb
                    lo, hi = band(min(f[2], yb), 9.0 + abs(yb - f[2]))
                    xb = hi + GAP if side == "hi" else lo - GAP
                    place.append((f, xb, yb))
            res["balloons"] = []
            for f, xb, yb in place:
                name, x, y, z, r = f
                pos = xy(ibot, M(xb, yb, z))

                def mk(name=name, x=x, y=y, z=z, r=r, pos=pos, xb=xb, yb=yb):
                    try:
                        c, cen = arc_xy(ibot, M(x, y, z), r, 2, 0.12)
                        a = on_arc(cen, r, 2, M(xb, yb, cen[2]))
                    except RuntimeError:
                        c, a = ptdwg.near(ibot, on_arc(M(x, y, z), r, 2, M(xb, yb, z)))
                        res.setdefault("balloon_near", []).append(name)
                    return gdt.balloon(dwg, name, pos, c, ibot, a, size=11.0, text_size=4.5)
                N("balloon_" + name, mk)
                res["balloons"].append([name, round(xb, 1), round(yb, 1)])
    res["overlaps4"] = nxd.overlaps(sh4)

    sheets = [sh1, sh2, sh3, sh4]
    res["export"] = ptdwg.export(dwg, sheets, OUTD, NO)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUTD, "dwg_result.json"), res)
