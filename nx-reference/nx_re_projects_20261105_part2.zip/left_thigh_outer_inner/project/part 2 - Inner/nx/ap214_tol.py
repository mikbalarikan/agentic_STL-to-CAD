"""AP214 re-export test (stage M): the AP214 writer leaves one 0.1 mm2 unorientable cylinder sliver near (65.5, 104, 76.9)
that AP242 does not have. Export AP214 with other B-spline tolerances; check each with an/stepcheck.py.
args: prt out_dir"""
import os, sys, json, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf

SRC, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
res = {"result": "FAIL", "files": {}}
try:
    part = nxh.open_part(SRC)
    for tol in (0.01, 0.0001):
        dest = os.path.join(OUT, f"ap214_tol{tol}.step")
        if os.path.exists(dest):
            os.remove(dest)
        b = nxh.S.DexManager.CreateStepCreator()
        try:
            b.ExportAs = NXOpen.StepCreator.ExportAsOption.Ap214
            b.SettingsFile = os.path.join(nxf.step_dir(), "ugstep214.def")
            b.InputFile = part.FullPath
            b.OutputFile = dest
            b.LayerMask = "1-256"
            b.ObjectTypes.Solids = True
            b.FileSaveFlag = False
            b.ProcessHoldFlag = True
            b.BsplineTol = tol
            b.Commit()
        finally:
            b.Destroy()
        t0, last = time.time(), -1
        while time.time() - t0 < 300:
            size = os.path.getsize(dest) if os.path.exists(dest) else -1
            if size > 0 and size == last:
                break
            last = size
            time.sleep(2.0)
        res["files"][str(tol)] = os.path.getsize(dest) if os.path.exists(dest) else None
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
json.dump(res, open(os.path.join(OUT, "ap214_tol.json"), "w"), indent=1)
