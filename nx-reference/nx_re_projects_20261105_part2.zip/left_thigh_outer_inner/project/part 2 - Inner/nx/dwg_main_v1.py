# -*- coding: utf-8 -*-
"""LT-OUT-001 Left Thigh - Outer shell: manufacturing drawing set (third angle).
run_journal dwg_main.py -args <model.prt> <out_dir> [dump|full]
Master-model drawing: the model is placed with drawing (X, Y, Z) = model (y, -x, z), so the length runs left
(knee) to right (hip) in the plan view. M(x, y, z) maps a MODEL point to drawing-part coordinates.
SH1 general arrangement (A1 1:1), SH2 knee hub (A2 1:1), SH3 hip ring (A2 1:1), SH4 interior features (A1 1:1)."""
import json
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\nx\dwglib")
import nxh  # noqa: E402
import nxd  # noqa: E402
import nxd2  # noqa: E402
import ptdwg  # noqa: E402
import m3d  # noqa: E402
from m3d import D, N, xy, note, lnote  # noqa: E402

MODEL, OUTD = sys.argv[1], sys.argv[2]
MODE = sys.argv[3] if len(sys.argv) > 3 else "full"
os.makedirs(OUTD, exist_ok=True)
NO, TITLE = "LT-OUT-001", "LEFT THIGH - OUTER SHELL"
PJ = json.load(open(r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\nx\params.json"))
FIN = json.load(open(os.path.join(os.path.dirname(MODEL), "_finalize.json")))
MASS = "%.2f kg (Al 6061)" % (FIN["mass_g_al6061"] / 1000.0)
MAT = "Al 6061-T6 (note 1)"
R = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]]
S = nxd.SNAP
res = {"result": "FAIL", "dims": {}, "errors": {}}
m3d.start(res)
TXT = 3.5
HX, HZ = PJ["hip"]["ax_x"], PJ["hip"]["ax_z"]


def M(x, y, z):
    return (y, -x, z)


def straight(view, pred):
    """Straight drafting curves (3 characteristic points) whose end points satisfy pred(p0, p1)."""
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 3 and pred(p[0], p[1]):
            out.append((c, p))
    return out


def longest(cands):
    if not cands:
        raise RuntimeError("no curve")
    return max(cands, key=lambda cp: sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)))[0]


def at(ax, val, tol=0.05, rng=None):
    """Predicate: both end points have coordinate ax == val (and, optionally, coordinate rng[0] within rng[1:3])."""
    def f(p0, p1):
        ok = abs(p0[ax] - val) <= tol and abs(p1[ax] - val) <= tol
        if ok and rng is not None:
            k, lo, hi = rng
            ok = lo <= 0.5 * (p0[k] + p1[k]) <= hi
        return ok
    return f


def dimc(name, view, ca, cb, origin, method, expect, etol=0.05, **kw):
    return D(name, lambda: m3d.dim_curves(view, ca, cb, origin, method, expect=expect, etol=etol, **kw))


def note_block(lines, pos, size=TXT):
    return N("note_%d_%d" % (int(pos[0]), int(pos[1])), lambda: nxd.note(m3d.CTX["dwg"], lines, pos, size=size))


try:
    dwg, comp = m3d.new_drawing(os.path.join(OUTD, NO + "_dwg.prt"), MODEL, "LEFT_THIGH_OUTER", R, refset="SOLID")
    # ================================================================ SHEET 1 general arrangement (A1, 1:1)
    sh1, _g = ptdwg.sheet(dwg, "A1")
    front = nxd.base_view(dwg, dwg, "Front", (255.0, 150.0), scale=(1.0, 1.0))
    top = nxd.projected_view(dwg, front, (255.0, 400.0))
    right = nxd.projected_view(dwg, front, (565.0, 150.0))
    iso = nxd.base_view(dwg, dwg, "Isometric", (705.0, 470.0), scale=(1.0, 2.0))
    res["views1"] = {v.Name: nxd.view_info(v) for v in (front, top, right, iso)}
    res["tb1"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (iso 1:2)", 1, 4, rev="A", subtitle="general arrangement")
    if MODE == "dump":
        for v, n in ((front, "front"), (top, "top"), (right, "right")):
            res["dump_" + n] = m3d.dump(v, os.path.join(OUTD, "dump_sh1_%s.json" % n))
    else:
        # -- front view: heights and overall length
        fx = lambda X: xy(front, (X, 0.0, 0.0))[0]           # noqa: E731
        fz = lambda Z: xy(front, (0.0, 0.0, Z))[1]           # noqa: E731
        c_top = N("c_ringtop", lambda: longest(straight(front, at(2, PJ["hip"]["ring_top_z"], 0.05))))
        c_skirt = N("c_skirt", lambda: longest(straight(front, at(2, -13.9, 0.05))))
        c_knee = N("c_knee", lambda: longest(straight(front, at(0, -PJ["hub"]["r_out"], 0.1))))
        c_end = N("c_end", lambda: longest(straight(front, at(0, 287.4, 0.1))))
        rim = PJ["levels"]["rim"]
        if c_end:
            pe = nxd.curve_points(c_end)
            ptop = max(pe[:2], key=lambda q: q[2]); pbot = min(pe[:2], key=lambda q: q[2])
            res["end_line"] = [ptop, pbot]
            if c_skirt:
                ps = nxd.curve_points(c_skirt)[0]
                D("H_skirt_rim", lambda: m3d.dim_ends(front, c_skirt, ps, c_end, ptop, (fx(300.0), fz(10.0)), "vertical", expect=rim + 13.9, etol=0.1))
            if c_top:
                pt = nxd.curve_points(c_top)[0]
                D("H_rim_ringtop", lambda: m3d.dim_ends(front, c_end, ptop, c_top, pt, (fx(305.0), fz(60.0)), "vertical",
                                                       expect=PJ["hip"]["ring_top_z"] - rim, etol=0.1))
        if c_knee and c_end:
            dimc("L_overall", front, c_knee, c_end, (fx(110.0), fz(-62.0)), "horizontal", 355.25, etol=0.2)
        # -- plan view: hip faces from the knee axis
        tx = lambda X: xy(top, (X, 0.0, 0.0))[0]             # noqa: E731
        ty = lambda Y: xy(top, (0.0, Y, 0.0))[1]             # noqa: E731
        c_bore = N("c_kbore", lambda: ptdwg.arc_at(top, (0.0, 0.0, 0.0), 55.0, tol=0.05))
        c_hf1 = N("c_hipface_in", lambda: longest(straight(top, at(0, PJ["hip"]["y_plate_in"], 0.05))))
        c_hf2 = N("c_hipface_out", lambda: longest(straight(top, at(0, PJ["hip"]["y_ring_out"], 0.05))))
        if c_bore and c_hf1:
            D("L_knee_hipface_in", lambda: m3d.dim_curves(top, c_bore, c_hf1, (tx(133.0), ty(105.0)), "horizontal",
                                                          sa=S.Center, sb=S.Mid, expect=266.5, etol=0.05))
        if c_bore and c_hf2:
            D("L_knee_hipface_out", lambda: m3d.dim_curves(top, c_bore, c_hf2, (tx(140.0), ty(118.0)), "horizontal",
                                                           sa=S.Center, sb=S.Mid, expect=276.85, etol=0.05))
        if c_bore:
            D("D_knee_bore_plan", lambda: ptdwg.radius(dwg, top, (0.0, 0.0, 0.0), 55.0, (tx(-45.0), ty(80.0)), diameter=True))
        note_block(["DATUM SYSTEM / MODEL FRAME (all CAD files):",
                    "ORIGIN = KNEE BORE AXIS x KNEE FLOOR PLANE (Z = 0)",
                    "Z = KNEE AXIS (OPEN SIDE +), Y = HIP AXIS DIRECTION",
                    "HIP AXIS: X = %.2f, Z = %.2f (PARALLEL TO Y)" % (HX, HZ),
                    "RIM / PARTING PLANE Z = %.2f, TONGUE TOP Z = %.2f" % (PJ["levels"]["rim"], PJ["levels"]["tongue"]),
                    "ENVELOPE (REF): X -69.0 / +119.0, Y -67.85 / +287.40, Z -40.8 / +85.20",
                    "STOCK SUGGESTION: 195 x 362 x 132 BILLET (OR 2-SIDED SETUP ON A 5-AXIS)"],
                   (30.0, 575.0), 3.0)
        note_block(["NOTES",
                    "1. MATERIAL: ALUMINIUM 6061-T6 ASSUMED (NOT GIVEN IN THE BRIEF) - CONFIRM. MASS SHOWN FOR 6061.",
                    "2. THE 3D MODEL (STEP AP214 / PARASOLID, SAME REVISION) IS THE MASTER FOR ALL GEOMETRY NOT",
                    "    DIMENSIONED: FREEFORM OUTER SKIN, INNER CAVITY, RIBS, PADS, WINDOWS, GROOVES, FILLETS.",
                    "3. UNTOLERANCED DIMENSIONS: ISO 2768-mK. FREEFORM SURFACES: PROFILE 0.2 TO THE MODEL.",
                    "4. FIT DIAMETERS (BORES, PILOT RECESS) AS STATED ON SHEETS 2 AND 3.",
                    "5. INTERNAL CORNERS: R3 MAX UNLESS MODELLED; BREAK SHARP EDGES 0.2-0.5.",
                    "6. SURFACE FINISH Ra 3.2 GENERAL, Ra 1.6 ON BORES, PILOTS AND MATING FACES.",
                    "7. STYLING SEAMS: R0.9 BALL GROOVE 0.55 DEEP ALONG THE MODEL CURVES (COSMETIC).",
                    "8. PART MARKING '20010100285-00' ON THE HIP PLATE FACE (ENGRAVE 0.2 DEEP, H=5) - NOT MODELLED.",
                    "9. GEOMETRY REVERSE ENGINEERED FROM A 3D SCAN; SEE QA REPORT FOR SCAN-TO-CAD DEVIATION.",
                    "10. DEBURR ALL EDGES, NO SHARP EDGES ON THE OUTER SKIN. ANODISE IF SPECIFIED BY CUSTOMER."],
                   (480.0, 345.0), 3.0)
    res["overlaps1"] = nxd.overlaps(sh1)

    # ================================================================ SHEET 2 knee hub (A2, 1:1)
    sh2, _g = ptdwg.sheet(dwg, "A1")
    ktop = nxd.base_view(dwg, dwg, "Top", (300.0, 420.0), scale=(1.0, 1.0))
    ksec = nxd2.section(dwg, ktop, M(0.0, 0.0, 0.0), (300.0, 175.0), (1.0, 1.0))
    res["views2"] = {v.Name: nxd.view_info(v) for v in (ktop, ksec)}
    res["tb2"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 2, 4, rev="A", subtitle="knee hub")
    if MODE == "dump":
        res["dump_ksec"] = m3d.dump(ksec, os.path.join(OUTD, "dump_sh2_ksec.json"))
        res["dump_ktop"] = m3d.dump(ktop, os.path.join(OUTD, "dump_sh2_ktop.json"))
    else:
        sx = lambda X: xy(ksec, (X, 0.0, 0.0))[0]            # noqa: E731
        sz = lambda Z: xy(ksec, (0.0, 0.0, Z))[1]            # noqa: E731
        vert = lambda X, z0, z1: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[0] - X) < 0.06 and abs(p1[0] - X) < 0.06
                                                           and min(p0[2], p1[2]) >= z0 - 0.3 and max(p0[2], p1[2]) <= z1 + 0.3)))  # noqa: E731
        hor = lambda Z, x0, x1: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[2] - Z) < 0.06 and abs(p1[2] - Z) < 0.06
                                                          and x0 <= 0.5 * (p0[0] + p1[0]) <= x1)))  # noqa: E731
        H = PJ["hub"]
        cols = [("D110", 55.0, -4.12, 0.0, 110.0, "H7", 30.0), ("D96", 48.0, -6.1, -4.12, 96.0, None, 18.0),
                ("D92", 46.05, -8.35, -6.1, 92.1, None, 6.0), ("D125_5", 62.75, -13.9, -8.35, 125.5, "H7", -32.0)]
        for name, r, z0, z1, val, tol, oy in cols:
            ca = N("c_%s_a" % name, vert(-r, z0, z1)); cb = N("c_%s_b" % name, vert(r, z0, z1))
            if ca and cb:
                dimc(name, ksec, ca, cb, (sx(0.0), sz(0.0) + oy), "cylindrical", val, etol=0.1, tol=tol)
        # depths (left side), hole on the section at +-90 deg
        c_floor = N("c_floor", hor(0.0, -64.0, -55.5))
        c_step1 = N("c_step1", hor(-4.12, -55.0, -48.0))
        c_step2 = N("c_step2", hor(-6.1, -48.0, -46.0))
        c_bot = N("c_bot", hor(-8.35, -62.7, -46.1))
        c_sk = N("c_skirt2", hor(-13.9, -64.5, -62.5))
        x_l = sx(-75.0)
        if c_floor and c_step1:
            dimc("Z_step1", ksec, c_floor, c_step1, (x_l - 8, sz(-2.0)), "vertical", 4.12, etol=0.05)
        if c_floor and c_step2:
            dimc("Z_step2", ksec, c_floor, c_step2, (x_l - 20, sz(-3.0)), "vertical", 6.10, etol=0.05)
        if c_floor and c_bot:
            dimc("Z_bottom", ksec, c_floor, c_bot, (x_l - 32, sz(-4.0)), "vertical", 8.35, etol=0.05)
        if c_bot and c_sk:
            dimc("Z_skirt", ksec, c_bot, c_sk, (x_l - 44, sz(-11.0)), "vertical", 5.55, etol=0.05)
        note_block(["KNEE BOLT CIRCLE: 30 X %s5.7 THRU, EQ SP (12°) ON %s102.92 PCD" % ("Ø", "Ø"),
                    "FIRST HOLE AT 6° FROM THE MODEL +X AXIS (NO HOLE ON THE X AXIS) - M5 CLEARANCE (CONFIRM)",
                    "PCD POSITION %s0.1 TO KNEE BORE %s110 (DATUM B) AND MOUNTING FACE Z = -8.35 (DATUM A)" % ("Ø", "Ø"),
                    "%s110 H7 KNEE BORE, %s125.5 H7 PILOT RECESS - FITS SUGGESTED, CONFIRM WITH THE ACTUATOR" % ("Ø", "Ø"),
                    "FLATNESS 0.03 ON DATUM A; PERPENDICULARITY 0.03 OF %s110 TO A" % "Ø",
                    "LOW WALL ON THE -X SIDE OF THE HUB: TOP Z = 7.49 (155.5° - 243.5° ABOUT THE KNEE AXIS)",
                    "KNEE +X WRAP: SURFACE OF REVOLUTION ABOUT THE KNEE AXIS (R69.0 AT Z-12 TO R80.9 AT Z+20), SEE MODEL"],
                   (500.0, 300.0), 3.0)
    res["overlaps2"] = nxd.overlaps(sh2)

    # ================================================================ SHEET 3 hip ring (A2, 1:1)
    sh3, _g = ptdwg.sheet(dwg, "A1")
    hend = nxd.base_view(dwg, dwg, "Right", (130.0, 430.0), scale=(1.0, 1.0))
    hfront = nxd.base_view(dwg, dwg, "Front", (390.0, 95.0), scale=(1.0, 2.0))
    hsec = nxd2.section(dwg, hfront, M(HX, 271.0, HZ), (390.0, 280.0), (1.0, 2.0))
    hdet = N("hdet", lambda: nxd.detail_view(dwg, hsec, M(HX, 271.0, HZ), M(HX + 60.0, 271.0, HZ), (640.0, 420.0), scale=(2.0, 1.0)))
    vv = [v for v in (hend, hfront, hsec, hdet) if v is not None]
    res["views3"] = {v.Name: nxd.view_info(v) for v in vv}
    res["tb3"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (front, B-B 1:2, C 2:1)", 3, 4, rev="A", subtitle="hip ring")
    if MODE == "dump":
        res["dump_hsec"] = m3d.dump(hsec, os.path.join(OUTD, "dump_sh3_hsec.json"))
    elif hdet is not None:
        hp = PJ["hip"]
        yax = -HX
        rx = lambda X: xy(hdet, (X, yax, HZ))[0]                   # noqa: E731
        ry = lambda Yd: xy(hdet, (271.0, Yd, HZ))[1]               # noqa: E731
        axl = lambda r, x0, x1: (lambda: longest(straight(hdet, lambda p0, p1: abs(p0[1] - (yax + r)) < 0.06 and abs(p1[1] - (yax + r)) < 0.06
                                                         and min(p0[0], p1[0]) >= x0 - 0.3 and max(p0[0], p1[0]) <= x1 + 0.3)))  # noqa: E731
        for name, r, y0, y1, val, tol, ox in (("HD97_54", 48.77, 266.5, 269.45, 97.54, "H7", -36.0),
                                              ("HD85_96", 42.98, 269.45, 271.4, 85.96, None, -16.0),
                                              ("HD82", 40.99, 271.4, 275.85, 82.0, "H7", 12.0),
                                              ("HD105", 52.51, 266.5, 276.85, 105.03, None, 40.0)):
            ca = N("c_%s_a" % name, axl(-r, y0, y1)); cb = N("c_%s_b" % name, axl(r, y0, y1))
            if ca and cb:
                dimc(name, hdet, ca, cb, (rx(271.0) + ox, ry(yax)), "cylindrical", val, etol=0.1, tol=tol)
            elif ca or cb:
                c1 = ca or cb
                res["half_" + name] = True
        note_block(["HIP RING (AXIS X = %.2f, Z = %.2f IN THE MODEL FRAME, PARALLEL TO Y)" % (HX, HZ),
                    "BORES: %s97.54 H7 (Y 266.50-269.45), %s85.96 (Y 269.45-271.40), %s82.00 H7 (Y 271.40-276.85)" % ("Ø", "Ø", "Ø"),
                    "      1 X 45° CHAMFER AT THE %s82 BORE ON THE OUTER FACE (Y 276.85)" % "Ø",
                    "RING OD %s105.03, OUTER FACE Y = 276.85, INNER FACE Y = 266.50, RING TOP FLAT Z = 85.20" % "Ø",
                    "HIP BOLT CIRCLE: 26 X %s4.07 THRU, C'BORE %s7.53 X 4.15 DEEP FROM Y 276.85," % ("Ø", "Ø"),
                    "      EQ SP (13.846°) ON %s91.45 PCD, FIRST HOLE ON THE MODEL +X DIRECTION (Z = %.2f)" % ("Ø", HZ),
                    "      M4 SHCS CLEARANCE / C'BORE AS SCANNED - CONFIRM",
                    "PERPENDICULARITY 0.03 OF FACE Y 276.85 TO THE %s82 AXIS; POSITION %s0.1 OF THE PCD" % ("Ø", "Ø"),
                    "LABEL PAD ON THE OUTER FACE: 4.2 HIGH, 4 X %s3.5 X 4 DEEP (SEE MODEL)" % "Ø"],
                   (30.0, 350.0), 3.0)
    res["overlaps3"] = nxd.overlaps(sh3)

    # ================================================================ SHEET 4 interior features (A1, 1:1)
    sh4, _g = ptdwg.sheet(dwg, "A1")
    itop = nxd.base_view(dwg, dwg, "Top", (250.0, 330.0), scale=(1.0, 1.0))
    res["views4"] = {v.Name: nxd.view_info(v) for v in (itop,)}
    res["tb4"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 4, 4, rev="A", subtitle="interior features")
    if MODE != "dump":
        rows = [["INTERIOR FEATURES (MODEL FRAME, mm)", "", "", "", "", ""],
                ["ID", "X", "Y", "FEATURE", "TOP Z", "HOLE"]]
        for i, b in enumerate(PJ["bosses"], 1):
            rows.append(["B%d" % i, "%.2f" % b["x"], "%.2f" % b["y"], "BOSS %s15 + SPIGOT %s10" % ("Ø", "Ø"), "36.07 / 39.04",
                         "%s5.2 X 12 (CONFIRM THREAD)" % "Ø"])
        for i, p in enumerate(PJ["pins"], 1):
            rows.append(["P%d" % i, "%.2f" % p["x"], "%.2f" % p["y"], "PIN %s4 ON BOSS %s9" % ("Ø", "Ø"), "%.2f" % p["top_z"], "-"])
        for i, h in enumerate(PJ["small_holes"], 1):
            rows.append(["H%d" % i, "%.2f" % h["x"], "%.2f" % h["y"], "FLOOR HOLE", "0.00", "%s2.6 X 6 (M3 TAP?)" % "Ø"])
        N("table4", lambda: m3d.table((470.0, 560.0), [16.0, 22.0, 22.0, 70.0, 30.0, 62.0], rows, title_rows=(0,), size=2.5, rh=6.0))
        lv = [["FLAT LEVELS (Z, MODEL FRAME)", ""], ["RIM / PARTING PLANE", "34.76"], ["TONGUE TOP (INNER EDGE OF RIM)", "36.07"],
              ["BOSS SPIGOT TOP", "39.04"], ["HIP RING TOP FLAT", "85.20"], ["KNEE FLOOR (DATUM PLANE)", "Z 0.00"],
              ["LOW HUB WALL", "7.49"], ["PADS", "33.90 / 29.55 / 28.39 / 27.67"], ["RIB TOPS", "4.97 / 4.78 / 0.00 / -5.00 / -20.29"],
              ["LONG RIB RAMP", "-13.25 (Y 166) TO -20.29 (Y 206.5)"]]
        N("table_levels", lambda: m3d.table((470.0, 380.0), [80.0, 75.0], lv, title_rows=(0,), size=2.5, rh=6.0))
        for i, b in enumerate(PJ["bosses"], 1):
            p = M(b["x"], b["y"], 39.04)
            q = xy(itop, p)
            N("lbl_B%d" % i, lambda q=q, i=i: nxd.note(dwg, ["B%d" % i], (q[0] + 9.0, q[1] + 9.0), size=4.0))
        for i, pn in enumerate(PJ["pins"], 1):
            q = xy(itop, M(pn["x"], pn["y"], 42.0))
            N("lbl_P%d" % i, lambda q=q, i=i: nxd.note(dwg, ["P%d" % i], (q[0] + 6.0, q[1] - 4.0), size=4.0))
        for i, h in enumerate(PJ["small_holes"], 1):
            q = xy(itop, M(h["x"], h["y"], 0.0))
            N("lbl_H%d" % i, lambda q=q, i=i: nxd.note(dwg, ["H%d" % i], (q[0] + 4.0, q[1] + 4.0), size=3.5))
        note_block(["SIDE WINDOWS (2): -X WALL Y 180.8-240.6 DOWN TO Z -1.6; +X WALL Y 137.9-187.8 DOWN TO Z 2.9 (PROFILES PER MODEL)",
                    "RIBS / POCKETS / PADS: WALLS VERTICAL, FLOORS FOLLOW THE INNER SKIN (WALL 3.0 TYP., 1.9 MIN NEAR THE +X RIM)",
                    "GUSSET WEBS AT THE HIP END: 3.9 / 4.0 THICK, SLOPED TOPS 53.9° / 45.7° (SEE MODEL)"],
                   (40.0, 70.0), 3.0)
    res["overlaps4"] = nxd.overlaps(sh4)

    sheets = [sh1, sh2, sh3, sh4]
    res["export"] = ptdwg.export(dwg, sheets, OUTD, NO)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUTD, "dwg_result.json"), res)
