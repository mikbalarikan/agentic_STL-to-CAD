"""Copy of the final part with the scan as a convergent body in the same frame, for the user's own
deviation check. The original part is not touched. args: src_prt dst_prt scan_stl probe_json"""
import os, sys, json, shutil, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxre

SRC, DST, STL, PROBE = sys.argv[1:5]
res = {"result": "FAIL"}
try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)
    cad = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
    res["cad_bodies"] = [b.Name for b in cad]
    body = cad[0]
    res["cad_bbox"] = nxh.bbox(body)
    t = time.time()
    scans = nxre.stl_import(part, STL)
    res["import_sec"] = round(time.time() - t, 1)
    res["scan_bodies"] = len(scans)
    scans.sort(key=lambda b: -b.GetNumberOfFacets())
    res["scan_facets"] = [b.GetNumberOfFacets() for b in scans]
    for i, b in enumerate(scans):
        b.SetName("SCAN_STL_INNER" if i == 0 else f"SCAN_STL_INNER_FRAGMENT_{i}")
        b.Layer = 10
    res["scan_bbox"] = nxh.bbox(scans[0])
    # colours: CAD light grey, scan orange and half transparent
    for b, col, tr in [(body, 130, 0)] + [(sb, 78, 50) for sb in scans]:
        dm = nxh.S.DisplayManager.NewDisplayModification()
        dm.ApplyToAllFaces = True
        dm.NewColor = col
        dm.NewTranslucency = tr
        dm.Apply([b])
        dm.Dispose()
    # sanity: signed distance of scan vertices to the CAD solid
    pts = json.load(open(PROBE))
    d = [nxh.dist_to(part, body, p) for p in pts]
    a = sorted(abs(x) for x in d)
    res["probe"] = {"n": len(d), "p50": a[len(a) // 2], "p95": a[int(0.95 * len(a))],
                    "max": a[-1], "mean_signed": sum(d) / len(d)}
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_overlay.json", res)
