"""Export the blanked ENVELOPE body (stage A, NOT lifted) and the INNER body of a built part to STL. args: prt out_dir"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxre
SRC, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
res = {"result": "FAIL"}
try:
    part = nxh.open_part(SRC)
    res["bodies"] = [[b.Name, b.IsBlanked, round(nxh.volume(part, b), 1)] for b in part.Bodies if b.IsSolidBody]
    for b in part.Bodies:
        if b.IsSolidBody and b.Name == "ENVELOPE":
            nxre.stl_export(part, b, os.path.join(OUT, "envelope_unlifted.stl"), chord=0.02, max_edge=3.0)
            res["envelope_bbox"] = nxh.bbox(b)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "export_env.json"), res)
