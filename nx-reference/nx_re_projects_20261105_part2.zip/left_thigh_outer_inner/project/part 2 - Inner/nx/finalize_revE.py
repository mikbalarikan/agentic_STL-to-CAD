"""Finalize LT-INN-001 Rev E (and later) from the user's hand-edited overlay part (scan inside as convergent bodies,
design features built on scan Fit Surfaces). Adapted from part 1 nx/finalize_revF.py.

Differences to the outer script: on this body a mass-property volume takes ~7.5 min while booleans take < 1 s, so
every intermediate check is geometric, not a volume:
  * diff check: the main solid at the start is written to a Parasolid file; at each check it is imported, and
    (current main - start) and (start - current main) are computed with Subtract on copies (inside an undo mark);
    the volumes of those small difference bodies give dV = plus - minus and the symmetric difference.
  * probe signature: point containment of ~4000 points 0.05 mm either side of the start surface (from an STL).
  One volume of the final solid is measured at the end; the start volume comes from the inspection run (arg).

Order:
 0. copy, open, baseline (tree state, errors, inactive, solids by bbox), x_t + STL of the main solid, probe points.
 1. rolled-back tail / failing features: NOT handled here; if any exist the script stops (lead decides).
 2. points on scan Fit Surfaces -> fixed points.
 3. every scan Fit Surface with design descendants is replaced (Replace Feature) by a frozen copy (Extract Body,
    FixAtCurrentTimestamp, + Remove Parameters) made right after it; fallback when Replace Feature refuses and
    all children are Replace Face: the children are re-pointed to the copy's faces. Then the scan is deleted;
    only features inside the scan closure that fail may be deleted. Accept: dV within VTOL, symmetric diff small,
    probes unchanged, solids unchanged, no new error, no feature lost.
 4. loose solids: each listed (bbox, volume, min distance, seat test); touching ones united, floating ones left
    untouched and reported (result NEEDS_LEAD).
 5. helper geometry to layer 200, ref set SOLID, attributes, save, STEP AP214 / AP242, x_t, STL.
args: src_prt deliver_dir revision v0_main(mm3, from the inspection; 0 = unknown)"""
import os, sys, json, traceback, shutil, struct, random, time
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, DST = sys.argv[1], sys.argv[2]
REV = sys.argv[3] if len(sys.argv) > 3 else "E"
V0_IN = float(sys.argv[4]) if len(sys.argv) > 4 else 0.0
LOOSE = sys.argv[5] if len(sys.argv) > 5 else "unite"   # unite | delete (lead 2026-11-02: hidden duplicates, delete)
NAME = "LT-INN-001_Left_Thigh_Inner"
BODY_NAME = "LEFT_THIGH_INNER"
VTOL = 0.2          # mm3, user's limit for the design volume before / after scan removal
SYMTOL = 1.0        # mm3, largest accepted symmetric difference (noise slivers both ways)
os.makedirs(DST, exist_ok=True)
res = {"result": "FAIL", "log": [], "revision": REV}
T0 = time.time()
OUTJ = os.path.join(DST, "_finalize.json")
FO = NXOpen.Update.FailureOption
UFS = nxh.UFS


def log(*a):
    res["log"].append("%7.1fs " % (time.time() - T0) + " ".join(str(x) for x in a))
    dump()


def dump():
    res["elapsed_s"] = round(time.time() - T0, 1)
    nxh.write_json(OUTJ, res)


def fname(f):
    return f.GetFeatureName() + ((" [" + f.Name + "]") if f.Name else "")


def raw_errors(part, active_only=False):
    out = {}
    for f in part.Features.GetFeatures():
        try:
            msgs = list(f.GetFeatureErrorMessages() or [])
        except Exception:  # noqa: BLE001
            msgs = []
        if not msgs:
            continue
        if active_only and nxh.suppress_status(f)["code"] != 0:
            continue
        out[f.GetFeatureName()] = [str(m) for m in msgs]
    return out


def solids(part):
    return [b for b in part.Bodies if b.IsSolidBody and not getattr(b, "IsConvergentBody", False)]


def diag(b):
    bb = nxh.bbox(b)
    return sum((bb[i + 3] - bb[i]) ** 2 for i in range(3)) ** 0.5


def main_solid(part):
    return max([b for b in solids(part) if not b.IsBlanked], key=diag)


def delete(objs, label):
    m = nxh.mark(label)
    nxh.S.UpdateManager.SetDefaultUpdateFailureAction(FO.AcceptAll)
    nxh.S.UpdateManager.AddObjectsToDeleteList(list(objs))
    nxh.S.UpdateManager.DoUpdate(m)


def closure(part, roots):
    seen, stack = set(), list(roots)
    while stack:
        f = stack.pop()
        if f.Tag in seen:
            continue
        seen.add(f.Tag)
        stack.extend(f.GetChildren())
    return seen


# ---------------------------------------------------------------- geometric checks (no volume of the big body)
X0 = os.path.join(DST, "_start_main.x_t")
PROBES = []


def read_stl(path):
    with open(path, "rb") as fh:
        fh.read(80)
        n = struct.unpack("<I", fh.read(4))[0]
        data = fh.read(50 * n)
    tris = []
    for i in range(n):
        v = struct.unpack_from("<12f", data, 50 * i)
        tris.append(v)
    return tris


def make_probes(stl, n=2000, eps=0.05, seed=7):
    tris = read_stl(stl)
    rnd = random.Random(seed)
    # area-weighted sampling of triangles
    areas, acc = [], 0.0
    for t in tris:
        a = [t[6] - t[3], t[7] - t[4], t[8] - t[5]]
        b = [t[9] - t[3], t[10] - t[4], t[11] - t[5]]
        c = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
        ar = 0.5 * (c[0] ** 2 + c[1] ** 2 + c[2] ** 2) ** 0.5
        acc += ar
        areas.append((acc, c, ar))
    pts = []
    import bisect
    keys = [x[0] for x in areas]
    for _ in range(n):
        k = bisect.bisect_left(keys, rnd.random() * acc)
        k = min(k, len(tris) - 1)
        t = tris[k]
        _, c, ar = areas[k]
        if ar < 1e-6:
            continue
        nn = [x / (2 * ar) for x in c]
        u, v = rnd.random(), rnd.random()
        if u + v > 1:
            u, v = 1 - u, 1 - v
        p = [t[3 + j] + u * (t[6 + j] - t[3 + j]) + v * (t[9 + j] - t[3 + j]) for j in range(3)]
        pts.append([p[j] + eps * nn[j] for j in range(3)])
        pts.append([p[j] - eps * nn[j] for j in range(3)])
    return pts


def probe_sig(body):
    return [int(UFS.Modeling.AskPointContainment(p, body.Tag)) for p in PROBES]


def probe_cmp(part, ref, label):
    sig = probe_sig(main_solid(part))
    bad = [i for i, (a, b) in enumerate(zip(ref, sig)) if a != b]
    out = {"n": len(sig), "changed": len(bad), "first": [[round(v, 3) for v in PROBES[i]] + [ref[i], sig[i]] for i in bad[:10]]}
    res.setdefault("probe_checks", {})[label] = out
    return out


def _sub_vol(part, target, tool):
    """volume of target - tool on throw-away copies; returns (volume, n bodies, message)"""
    try:
        f = nxh.subtract(part, target, [tool], check=False, keep_tool=True)
    except Exception as e:  # noqa: BLE001
        return 0.0, 0, "subtract refused: %s" % str(e)[:200]
    bodies = [b for b in f.GetBodies() if b.IsSolidBody]
    v = sum(nxh.volume(part, b) for b in bodies) if bodies else 0.0
    return v, len(bodies), ""


TAGS0 = [set()]


def diff_check(part, label):
    """dV of the current main solid vs the start solid, by booleans on copies; everything undone afterwards."""
    t = time.time()
    nb0 = len(list(part.Bodies))
    nf0 = len(list(part.Features))
    TAGS0[0] = {b.Tag for b in part.Bodies}
    out = {}
    for side in ("plus", "minus"):
        m = nxh.mark("diff " + side)
        before = list(part.Bodies)
        UFS.Ps.ImportData(X0)
        imp = [b for b in nxh.new_bodies(part, before) if b.IsSolidBody]
        if len(imp) != 1:
            raise RuntimeError("x_t import gave %d solids" % len(imp))
        b0 = imp[0]
        cur = main_solid(part) if side == "plus" else None
        before = list(part.Bodies)
        _ef, cp = nxf.extract_body(part, [main_solid(part) if cur is None else cur], fix_at_timestamp=True)
        cp = [b for b in cp if b.IsSolidBody][0]
        if side == "plus":          # current - start
            v, n, msg = _sub_vol(part, cp, b0)
        else:                       # start - current
            v, n, msg = _sub_vol(part, b0, cp)
        out[side] = round(v, 4)
        out[side + "_bodies"] = n
        if msg:
            out[side + "_msg"] = msg
        nxh.undo_to(m)
    out["dV"] = round(out["plus"] - out["minus"], 4)
    out["sym"] = round(out["plus"] + out["minus"], 4)
    out["s"] = round(time.time() - t, 1)
    if len(list(part.Bodies)) != nb0:
        left = [b for b in part.Bodies if b.Tag not in TAGS0[0]]
        if left:
            delete(left, "diff leftovers")
        out["leftover_bodies_deleted"] = len(left)
    if len(list(part.Bodies)) != nb0 or len(list(part.Features)) != nf0:
        raise RuntimeError("diff check %s: undo left bodies/features (%d/%d -> %d/%d)" % (
            label, nb0, nf0, len(list(part.Bodies)), len(list(part.Features))))
    res.setdefault("diff_checks", {})[label] = out
    dump()
    return out


SELF_MSGS = set()


def accept(part, label, ref):
    """diff check + probe check; a subtract refusal counts as 'no difference' only when the untouched part gave the
    same refusal in the self-test (identical bodies), and then the probes must be unchanged."""
    out = diff_check(part, label)
    pc = probe_cmp(part, ref, label)
    out["probes_changed"] = pc["changed"]
    msgs = [out.get(k) for k in ("plus_msg", "minus_msg") if out.get(k)]
    odd = [m for m in msgs if m not in SELF_MSGS]
    if abs(out["dV"]) > VTOL or out["sym"] > SYMTOL or odd or pc["changed"]:
        raise RuntimeError("%s: geometry changed or check not conclusive %s" % (label, out))
    return out


try:
    work = os.path.join(DST, NAME + ".prt")
    if os.path.exists(work):
        os.remove(work)
    shutil.copyfile(SRC, work)
    part = nxh.open_part(work)
    nxh.S.UpdateManager.SetDefaultUpdateFailureAction(FO.AcceptAll)
    feats = list(part.Features.GetFeatures())
    res["features_before"] = len(feats)
    res["current_before"] = part.CurrentFeature.GetFeatureName()
    res["errors_on_open"] = raw_errors(part)
    res["inactive_on_open"] = [[f.GetFeatureName(), nxh.suppress_status(f)["code"]] for f in feats
                               if nxh.suppress_status(f)["code"] not in (0, 16, 17)]
    tail = nxh.rolled_back(part)
    res["rolled_back_tail"] = [fname(f) for f in tail]
    if tail or res["errors_on_open"]:
        raise RuntimeError("rolled-back or failing features present: lead decides (%s / %s)" % (res["rolled_back_tail"], list(res["errors_on_open"])))
    body = main_solid(part)
    res["main_start"] = {"tag": body.Tag, "name": body.Name, "faces": len(body.GetFaces()), "bbox": nxh.bbox(body)}
    n_sol0 = len(solids(part))
    res["n_solids_start"] = n_sol0
    if os.path.exists(X0):
        os.remove(X0)
    UFS.Ps.ExportData([body.Tag], X0)
    stl0 = os.path.join(DST, "_start_main.stl")
    nxre.stl_export(part, body, stl0, chord=0.01, max_edge=3.0)
    PROBES[:] = make_probes(stl0)
    REF = probe_sig(body)
    res["probes"] = {"n": len(PROBES), "inside": REF.count(1), "outside": REF.count(2), "on": REF.count(3)}
    log("start: features %d, solids %d, main faces %d, probes %s" % (len(feats), n_sol0, len(body.GetFaces()), res["probes"]))
    # self-test of the diff check on the untouched part (must be 0 / 0)
    d = diff_check(part, "selftest_unchanged")
    for k in ("plus_msg", "minus_msg"):
        if d.get(k):
            SELF_MSGS.add(d[k])
    log("diff selftest", d)
    if abs(d["dV"]) > 1e-3 or d["sym"] > 1e-3:
        raise RuntimeError("diff check self-test is not zero: %s" % d)

    conv = [f for f in part.Features.GetFeatures() if f.FeatureType == "BREP" and f.GetFeatureName().startswith("Convergent Body")]
    ct = {c.Tag for c in conv}
    direct = [f for f in part.Features.GetFeatures() if f.Tag not in ct and any(p.Tag in ct for p in f.GetParents())]
    res["scan_features"] = len(conv)
    res["scan_direct"] = [fname(f) for f in direct]

    # ---- points on fit surfaces -> fixed points
    for fit in direct:
        for ch in fit.GetChildren():
            if ch.FeatureType != "POINT":
                continue
            pt = [x for x in ch.GetEntities() if isinstance(x, NXOpen.Point)][0]
            c0 = pt.Coordinates
            pb = part.BaseFeatures.CreatePointFeatureBuilder(ch)
            try:
                pb.Point = part.Points.CreatePoint(NXOpen.Point3d(c0.X, c0.Y, c0.Z))
                pb.Commit()
            finally:
                pb.Destroy()
            res.setdefault("points_fixed", []).append([ch.GetFeatureName(), round(c0.X, 4), round(c0.Y, 4), round(c0.Z, 4)])
    if res.get("points_fixed"):
        nxh.update("fix points")
        accept(part, "after_points", REF)
    log("points fixed: %s" % res.get("points_fixed"))

    base_err = set(raw_errors(part, active_only=True))
    BASE_ERR_TAGS = {f.Tag for f in part.Features.GetFeatures() if list(f.GetFeatureErrorMessages() or [])}

    need = []
    for d_ in direct:
        desc = closure(part, [d_]) - {d_.Tag}
        kinds = {f.FeatureType for f in part.Features.GetFeatures() if f.Tag in desc}
        if kinds - {"POINT", "Delete Body"}:
            need.append(d_)
    res["replace_targets"] = [d_.GetFeatureName() for d_ in need]
    dump()
    for d_ in need:
        name = d_.GetFeatureName()
        fit_tag = d_.Tag
        tags_before = {f.Tag: f.GetFeatureName() for f in part.Features.GetFeatures()}
        bodies = list(d_.GetBodies())
        if len(bodies) != 1:
            raise RuntimeError("%s has %d bodies" % (name, len(bodies)))
        end = part.CurrentFeature
        d_.MakeCurrentFeature()
        nxh.update("current = " + name)
        ef, new = nxf.extract_body(part, bodies, fix_at_timestamp=True)
        nxf.remove_parameters(part, new)
        nb = new[0]
        bf = list(nb.GetFeatures())
        if len(bf) != 1:
            raise RuntimeError("frozen copy of %s: %d features" % (name, len(bf)))
        brep = bf[0]
        brep_name = brep.GetFeatureName()
        try:
            brep.SetName("FROZEN_" + name.replace(" ", "_").replace("(", "_").replace(")", ""))
        except Exception:  # noqa: BLE001
            pass
        log("%s -> frozen copy %s (%s), solid %s, faces %d" % (name, brep_name, brep.FeatureType, nb.IsSolidBody, len(nb.GetFaces())))
        end.MakeCurrentFeature()
        nxh.update("roll forward after copy of " + name)
        row = {"fit": name, "by": brep_name, "children": [fname(c) for c in d_.GetChildren()]}
        kids = list(d_.GetChildren())
        if kids and all(k.FeatureType == "REPLACE_FACE" for k in kids):
            # Replace Feature drops an unmatched Replace Face silently (Fit Surface(Plane), Rev B and Rev E):
            # re-point the Replace Face children to the frozen copy's face instead; the fit is left childless
            newfaces = list(nb.GetFaces())
            for c in kids:
                rb = part.Features.CreateReplaceFaceBuilder(c)
                try:
                    rb.ReplacementFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(newfaces)], False)
                    rb.CommitFeature()
                finally:
                    rb.Destroy()
                nxh.update("repoint " + c.GetFeatureName())
            row["method"] = "Replace Face children re-pointed to the frozen copy, fit left childless (deleted with the scan)"
            row["fit_children_after"] = [fname(c) for c in d_.GetChildren()]
        else:
            b = part.Features.CreateReplaceFeatureBuilder()
            try:
                b.SelectFeature.Add(d_)
                b.ReplacementFeature.Add(brep)
                b.DoAutomaticGeomMatch = True
                b.DeleteOriginalFeature = True
                b.MappingTolerance = 0.01
                b.UpdateMap()
                b.AutomatchMap()
                b.Commit()
            finally:
                b.Destroy()
            nxh.update("replace " + name)
            row["method"] = "Replace Feature"
        tags_after = {f.Tag for f in part.Features.GetFeatures()}
        lost = [v for k, v in tags_before.items() if k not in tags_after and k != fit_tag]
        new_err = sorted(f.GetFeatureName() for f in part.Features.GetFeatures()
                         if list(f.GetFeatureErrorMessages() or []) and f.Tag not in BASE_ERR_TAGS)
        row.update({"lost_features": lost, "new_errors": new_err, "n_solids": len(solids(part))})
        res.setdefault("replaced", []).append(row)
        dump()
        if lost or new_err or row["n_solids"] != n_sol0:
            raise RuntimeError("replace %s: %s" % (name, row))
        dc = accept(part, "after_replace_" + name, REF)
        row["diff"] = dc
        log("replaced", name, row["method"], dc)

    # ---- scan delete; only features of the scan closure may fail and be deleted
    conv = [f for f in part.Features.GetFeatures() if f.FeatureType == "BREP" and f.GetFeatureName().startswith("Convergent Body")]
    ct = {c.Tag for c in conv}
    still = [f for f in part.Features.GetFeatures() if f.Tag not in ct and any(p.Tag in ct for p in f.GetParents())]
    res["scan_direct_before_delete"] = [fname(f) for f in still]
    cl = closure(part, still)
    cl_kinds = sorted({f.FeatureType for f in part.Features.GetFeatures() if f.Tag in cl})
    res["scan_closure_before_delete"] = {"n": len(cl), "types": cl_kinds,
                                         "names": [fname(f) for f in part.Features.GetFeatures() if f.Tag in cl]}
    bad_dep = [fname(f) for f in part.Features.GetFeatures() if f.Tag in cl and f.FeatureType not in ("POINT", "Delete Body")
               and not f.GetFeatureName().startswith("Fit Surface")]
    if bad_dep:
        raise RuntimeError("design features still depend on the scan: %s" % bad_dep)
    if [f for f in part.Features.GetFeatures() if f.Tag in cl and f.GetFeatureName().startswith("Fit Surface") and list(f.GetChildren())
            and any(c.FeatureType not in ("POINT", "Delete Body") for c in f.GetChildren())]:
        raise RuntimeError("a scan Fit Surface still has design children")
    tags_before = {f.Tag: f.GetFeatureName() for f in part.Features.GetFeatures()}
    delete(conv + [f for f in part.Features.GetFeatures() if f.Tag in cl], "del scan")
    deleted = sorted(v for k, v in tags_before.items() if k not in {f.Tag for f in part.Features.GetFeatures()})
    res["deleted_with_scan"] = deleted
    outside = [f.GetFeatureName() for f in part.Features.GetFeatures()
               if list(f.GetFeatureErrorMessages() or []) and f.Tag not in BASE_ERR_TAGS]
    res["failing_after_scan_delete"] = outside
    expected_gone = ct | cl
    unexpected = [v for k, v in tags_before.items() if k not in {f.Tag for f in part.Features.GetFeatures()} and k not in expected_gone]
    res["deleted_unexpected"] = unexpected
    dump()
    if outside or unexpected or len(solids(part)) != n_sol0:
        raise RuntimeError("scan delete: failing %s, unexpected deletions %s, solids %d" % (outside, unexpected, len(solids(part))))
    assert not [f for f in part.Features.GetFeatures() if f.GetFeatureName().startswith("Convergent")], "scan left"
    assert not [b for b in part.Bodies if getattr(b, "IsConvergentBody", False)], "convergent body left"
    dc = accept(part, "after_scan_delete", REF)
    pc = res["probe_checks"]["after_scan_delete"]
    res["scan_removal_dV"] = dc["dV"]
    res["errors_after_scan_delete_all"] = raw_errors(part)
    res["features_after_scan_delete"] = len(list(part.Features))
    log("scan deleted:", len(deleted), "features; diff", dc, "probes", pc["changed"])

    # ---- loose solids
    body = main_solid(part)
    try:
        nxre.stl_export(part, body, os.path.join(DST, "_main_before_unite.stl"), chord=0.005, max_edge=1.5)
    except Exception as e:  # noqa: BLE001
        log("pre-unite stl: %s" % e)
    others = [b for b in solids(part) if b.Tag != body.Tag]
    rows = []
    for b in sorted(others, key=lambda x: nxh.bbox(x)):
        row = {"tag": b.Tag, "volume": round(nxh.volume(part, b), 4), "bbox": [round(v, 4) for v in nxh.bbox(b)],
               "blanked": b.IsBlanked, "name": b.Name, "faces": len(b.GetFaces()),
               "features": [fname(f) for f in b.GetFeatures()][-4:],
               "min_dist_to_main": round(nxh.min_dist(body, b), 5)}
        # overlap with the main solid (small boolean, measured on copies)
        m = nxh.mark("overlap")
        try:
            _ef, cp = nxf.extract_body(part, [body], fix_at_timestamp=True)
            cp = [x for x in cp if x.IsSolidBody][0]
            f = nxh.intersect(part, b, [cp], check=False, keep_tool=True)
            ib = [x for x in f.GetBodies() if x.IsSolidBody]
            row["overlap_volume"] = round(sum(nxh.volume(part, x) for x in ib), 4)
        except Exception as e:  # noqa: BLE001
            row["overlap_volume"] = 0.0
            row["overlap_msg"] = str(e)[:150]
        nxh.undo_to(m)
        # seat test: points just outside each planar face of the loose solid, inside the main solid?
        seat = []
        for fc in b.GetFaces():
            fd = nxh.face_data(fc)
            if fd[0] != 22:
                continue
            c, nrm = fd[1], fd[2]
            q = [c[i] + 0.02 * nrm[i] for i in range(3)]
            seat.append([[round(v, 3) for v in c], [round(v, 3) for v in nrm], int(UFS.Modeling.AskPointContainment(q, body.Tag))])
        row["planar_faces_outside_point_in_main"] = seat
        rows.append(row)
    res["loose_solids"] = rows
    dump()
    floating = [r for r in rows if r["min_dist_to_main"] > 1e-6]
    res["floating_solids"] = floating
    united_sum = 0.0
    res["loose_mode"] = LOOSE
    if LOOSE == "delete":
        # dependency check: a body's GetFeatures() lists every feature that made or changed it; nothing after its
        # last owner may use it. Features after that owner that reference the body as a parent are searched too.
        feats_all = list(part.Features.GetFeatures())
        dels = []
        for r in rows:
            if r in floating:
                r["action"] = "left untouched (floating) - lead decides"
                continue
            b = [x for x in solids(part) if x.Tag == r["tag"]][0]
            own = list(b.GetFeatures())
            last = own[-1]
            idx = feats_all.index([f for f in feats_all if f.Tag == last.Tag][0])
            users = []
            for f in feats_all[idx + 1:]:
                try:
                    if any(x.Tag == b.Tag for x in f.GetBodies()):
                        users.append(fname(f))
                except Exception:  # noqa: BLE001
                    pass
            r["last_owner"] = fname(last)
            r["later_features_using_it"] = users
            if users:
                raise RuntimeError("loose body %s is used by later features %s" % (r["tag"], users))
            dels.append(b)
        if dels:
            df = nxf.delete_body(part, dels)
            nxh.update("delete hidden duplicates")
            for r in rows:
                if r not in floating:
                    r["action"] = "deleted (Delete Body %s), hidden duplicate - lead decision" % df.GetFeatureName()
            res["loose_delete_feature"] = df.GetFeatureName()
            body = main_solid(part)
            dc = accept(part, "after_loose_delete", REF)
            res["loose_delete_diff"] = dc
        log("loose solids deleted:", [(r["volume"], r["action"]) for r in rows])
    for r in rows:
        if LOOSE == "delete":
            break
        if r in floating:
            r["action"] = "left untouched (floating) - lead decides"
            continue
        b = [x for x in solids(part) if x.Tag == r["tag"]][0]
        n0 = len(solids(part))
        u = nxh.unite(part, body, [b])
        body = main_solid(part)
        n1 = len(solids(part))
        r.update({"action": "united", "feature": u.GetFeatureName(), "n_solids": [n0, n1]})
        assert n1 == n0 - 1, r
        united_sum += r["volume"] - r["overlap_volume"]
        dump()
    new_err = sorted(set(raw_errors(part, active_only=True)) - base_err)
    assert not new_err, ("unite errors", new_err)
    log("loose solids:", [(r["volume"], r["min_dist_to_main"], r["action"]) for r in rows])

    n = 0
    for b in part.Bodies:
        if not b.IsSolidBody:
            b.Layer = 200; n += 1
    for c in part.Curves:
        c.Layer = 200; n += 1
    for dp in part.Datums:
        try:
            dp.Layer = 200; n += 1
        except Exception:  # noqa: BLE001
            pass
    body.Layer = 1
    if body.IsBlanked:
        body.Unblank()
    log(f"{n} helper objects moved to layer 200")
    try:
        lsc = part.Layers.GetStates()
        lsc.SetState(200, NXOpen.Layer.State.Hidden)
        part.Layers.SetStates(lsc, True)
    except Exception as e:  # noqa: BLE001
        log(f"layer state: {e}")
    rs = next((r for r in part.GetAllReferenceSets() if r.Name == "SOLID"), None)
    if rs is None:
        rs = part.CreateReferenceSet()
        rs.SetName("SOLID")
    try:
        rs.AddObjectsToReferenceSet([body])
    except Exception as e:  # noqa: BLE001
        log(f"refset: {e}")
    body.SetName(BODY_NAME)
    for k, val in (("MATERIAL", "Aluminium 6061-T6"), ("DRAWING_NO", "LT-INN-001"), ("REVISION", REV),
                   ("DESCRIPTION", "Left thigh - inner shell, reverse engineered from scan")):
        try:
            part.SetUserAttribute(k, -1, val, NXOpen.Update.Option.Now)
        except Exception as e:  # noqa: BLE001
            log(f"attribute {k}: {e}")
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    try:
        mn, _dirs, dist = UFS.ModlGeneral.AskBoundingBoxExact(body.Tag, 0)
        mn, dist = list(mn), list(dist)
        res["bbox_exact"] = [round(x, 4) for x in mn + [mn[i] + dist[i] for i in range(3)]]
    except Exception as e:  # noqa: BLE001
        res["bbox_exact_err"] = str(e)
    res["examine"] = nxh.examine_geometry(part, body)
    res["body_ok"] = all(v == 0 for v in res["examine"].values())
    res["n_solids_final"] = len(solids(part))
    res["main_faces_final"] = len(body.GetFaces())
    res["features_final"] = len(list(part.Features))
    res["errors_final_active"] = raw_errors(part, active_only=True)
    res["errors_final_all"] = raw_errors(part)
    try:
        res["attr_REVISION"] = part.GetStringUserAttribute("REVISION", -1)
    except Exception as e:  # noqa: BLE001
        res["attr_REVISION_err"] = str(e)[:100]
    dump()
    nxh.save(part)
    log("saved")
    st214 = os.path.join(DST, NAME + "_AP214.step")
    st242 = os.path.join(DST, NAME + "_AP242.step")
    nxf.step_export(part, st214, ap242=False, save=True)
    nxf.step_export(part, st242, ap242=True, save=False)
    res["step_sizes"] = [os.path.getsize(st214), os.path.getsize(st242)]
    xt = os.path.join(DST, NAME + ".x_t")
    if os.path.exists(xt):
        os.remove(xt)
    try:
        UFS.Ps.ExportData([body.Tag], xt)
        res["x_t_size"] = os.path.getsize(xt)
    except Exception as e:  # noqa: BLE001
        res["x_t_error"] = str(e)
    stl = os.path.join(DST, NAME + ".stl")
    nxre.stl_export(part, body, stl, chord=0.005, max_edge=1.5)
    res["stl_size"] = os.path.getsize(stl)
    log("exports done; measuring the final volume (slow)")
    t = time.time()
    v = nxh.volume(part, body)
    res["volume_s"] = round(time.time() - t, 1)
    res["volume_mm3"] = v
    res["mass_g_al6061"] = v * 2.70e-3
    res["united_net_volume"] = united_sum
    if V0_IN > 0:
        exp = V0_IN + res["scan_removal_dV"] + united_sum
        res["volume_expected"] = exp
        res["volume_vs_expected"] = v - exp
        res["design_volume_before_after_scan_removal"] = [V0_IN, V0_IN + res["scan_removal_dV"]]
    ok = res["body_ok"] and res["n_solids_final"] == 1 and not res["errors_final_active"] and not floating
    if V0_IN > 0:
        ok = ok and abs(res["volume_vs_expected"]) < VTOL
    res["result"] = "PASS" if ok else ("NEEDS_LEAD" if floating else "FAIL")
except Exception:
    res["error"] = traceback.format_exc()
dump()
