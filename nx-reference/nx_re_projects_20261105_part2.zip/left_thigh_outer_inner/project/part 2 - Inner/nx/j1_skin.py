"""Stage 1 probe: skin loft from work/sections.json, block trimmed by the skin -> outer envelope solid.
args: out_dir"""
import os, sys, json, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"])
import NXOpen
import nxh, nxf, curvekit as ck

OUT = sys.argv[1]
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
res = {"result": "FAIL", "log": []}
log = res["log"].append
t0 = time.time()
sec = json.load(open(os.path.join(ROOT, "work", "sections.json")))["sections"]


def bs_eval(knots, poles, u):
    """de Boor, cubic, clamped."""
    k = 3
    n = len(poles)
    if u >= knots[n]:
        i = n - 1
    else:
        i = max(j for j in range(k, n) if knots[j] <= u)
    d = [list(poles[j]) for j in range(i - k, i + 1)]
    for r in range(1, k + 1):
        for j in range(k, r - 1, -1):
            a = (u - knots[j + i - k]) / (knots[j + 1 + i - r] - knots[j + i - k])
            d[j] = [(1 - a) * d[j - 1][c] + a * d[j][c] for c in range(3)]
    return d[k]

try:
    part = nxh.new_part(os.path.join(OUT, "j1_skin.prt"))
    splines = []
    worst = 0.0
    for s in sec:
        f, sp = ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True)
        pts = [bs_eval(s["knots"], s["poles"], u) for u in (0.03, 0.21, 0.5, 0.77, 0.97)]
        dv = nxh.max_dev(part, sp, pts)
        worst = max(worst, dv)
        splines.append(sp)
    log(f"{len(splines)} section splines, max dev NX vs python curve {worst:.5f}")
    res["spline_dev"] = worst
    secs = [nxh.section(part, curves=[sp]) for sp in splines]
    tc = nxf.through_curves(part, secs, solid=False)
    sheet = tc.GetBodies()[0]
    log(f"through curves: {tc.JournalIdentifier} area {nxh.sheet_area(part, sheet)[0]:.1f}  t={time.time()-t0:.0f}s")
    bf, blk = nxh.block(part, (-120.0, -70.0, -60.0), (300.0, 357.4, 96.0))
    v0 = nxh.volume(part, blk)
    tf, rev = nxf.trim_body(part, blk, reverse=True, sheet=sheet)
    if nxh.volume(part, blk) > 0.5 * v0:
        raise RuntimeError('trim kept the outside')
    v1 = nxh.volume(part, blk)
    log(f"block {v0:.0f} -> trimmed {v1:.0f} (reverse={rev})  bbox {[round(b,2) for b in nxh.bbox(blk)]}")
    res["envelope_volume"] = v1
    ok = nxh.body_ok(part, blk)
    log(f"body_ok {ok}")
except Exception:
    res["error"] = traceback.format_exc()
try:
    sys.path.insert(0, os.environ["NXRE_DIR"]); import nxre
    nxre.stl_export(part, blk, os.path.join(OUT, "j1_env.stl"), chord=0.01, max_edge=3.0)
    nxh.save(part)
    if "error" not in res:
        res["result"] = "PASS"
except Exception:
    res["error2"] = traceback.format_exc()
res["t"] = time.time() - t0
nxh.write_json(os.path.join(OUT, "j1.json"), res)
