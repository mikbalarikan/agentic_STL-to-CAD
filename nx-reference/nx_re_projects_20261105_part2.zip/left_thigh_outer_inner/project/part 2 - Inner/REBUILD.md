# Left Thigh (inner, LT-INN-001): internal notes and re-run chain

Delivery: `deliver/` (CAD, Drawings, Deviation Report, Renders, README). Everything below is internal.
Part 1 (`..\part 1\`) is read-only: scripts were copied here and repointed (`an/common.py` ROOT = this folder).
`an/outer.py` reads the OUTER scan (part 1 `work/scan.npz` + `frame.json`) and the delivered outer CAD STL/STEP.

## Re-run order (venv = `C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe`, NX via `run_journal.ps1`)

1. `an/s0_load.py` -> `work/scan.npz` (welded inner scan, its own scanner pose).
2. Registration into the LT-OUT-001 frame: `an/i2_rim.py` (rim plane, rim frame `Rrim.npy`) -> `an/i4_feats.py` ->
   `an/i5_cyl.py inner` + `an/i5_cyl.py outer` (cylinder census at the 7 bosses / 3 pins) -> `an/i7_register.py`
   (writes `work/frame.json`; `an/common.load()` applies it) -> checks `an/i8_check.py`, `i9_joint.py`, `i10_levels.py`.
3. Outer skin of the inner: `an/i20_skin.py` (ray data, then `i20_skin.py fit 5 2.5 5e-4`) ->
   `an/s12_sections.py 80 5 skin_fit sections`.
4. Cavity: `an/i21_cavity.py` -> `an/s12_sections.py 50 8 inner_fit inner_sections`.
5. Depth map seen from the open side (-Z): `an/i14_hmap.py` (H = -min z) -> `an/i23_outlines.py` -> `an/s19_platnx.py`.
6. Rebate: `an/i26_rebate.py` (outer CAD material above z 35.10 + 0.10 clearance, U inner scan rebate).
7. Windows `an/i27_windows.py map` then `an/i27_windows.py '{"L": [[176, 245], [252, 280]], "R": [[133, 184], [252, 272]]}'`
   (the build uses only the two big ones, y span > 20). Grooves `an/i28_grooves.py`. Holes census `an/i29_holes.py`,
   bosses `an/i24_bosses.py`.
8. `an/i30_params.py` -> `nx/params.json` (all design values).
9. NX build: `nx/build_inner.py <out> [stop] [resume_prt start]` (stages A B C D E G F H I J; every stage saves the part,
   so a later stage can be re-run from a copy: `... <out> Z <copy of saved prt> <stage>`). Stage I (hip plate with the
   ring-clearance arc, two hip-end gussets, channel ramp `an/i31_ramp.py`, P3 lug fix, wide seam G3 with a 6 mm tube)
   and stage J (outer P3 pad clearance `outer_pad_nx.json`, then lift +seat_dz 0.12 in Z) came after the first full run.
   Stage K re-applies the clearance to LT-OUT-001 after I and J (outer footprint +0.2 `an/i32_outer_band.py` cut up to
   Z 36.07, ring clearance, B6/B7 pocket tools): stage I had refilled them (OCP showed 133 mm3 before K, 0.0 after).
   **Delivered part (restored 2026-10-30): `nx/runK10`, finalized directly; the stage-L/M review-fix parts (runL11-runM16) are NOT delivered, their package is in `_fixround_2026-10-30`.** History: A-B `nx/runA5`, C-H `nx/runC7`, I `nx/runI8`, J `nx/runJ9`, K `nx/runK10` (each resumed from the
   previous save), then the review fixes: stage L from runK10 with `nx/fixes_M.json` (`nx/runM13`) -> finalize. (`nx/fixes_M2.json`
   / `nx/runM16` cut the hip-pad bumps back for LT-OUT-001 Rev A: dropped, the bumps stay and LT-OUT-001 Rev B gets slots.) Stage L: `build_inner.py <out> Z
   <resume prt> L <fix list>`; fix lists from `an/i97_nxprep.py` (fixes_L) -> `an/m3_fixes.py` (fixes_M) / `an/m4_clear.py`
   (fixes_M2), each simulated first with `an/i97_sim.py` + `an/i90_clusters.py`. Deviation_Check: `an/s30_scan_aligned.py` (seated scan) -> `nx/overlay.py` -> `Deviation_Check/`.
10. `nx/finalize_inner.py <prt> deliver/CAD` (no NX STEP round trip: it imports nothing on these files; use `an/stepcheck.py`).
11. QA: `an/i40_dev.py <stl> <tag>` (scan lifted by seat_dz), `an/i62_depthdiff.py <stl> <tag>` (depth from the open side,
    CAD vs scan, finds missing plateaus fast), `an/i50_fit.py <inner step> <outer step> <out.json> <inner stl>` (OCP boolean
    interference + mating planes + hole concentricity, mesh gap map), `an/i70_report.py`.
12. Drawings: `an/s31_outline.py <stl>` -> `nx/dwg_inner.py <deliver prt> <out> full` (dump mode writes view curve dumps).
    Renders `an/i60_renders.py`; package `an/i80_package.py`.

## Frame and joint (see STATUS.md for the numbers)

- Inner = outer frame turned 180 deg about Y: p_LT-OUT = R (p_scan - o) in `work/frame.json`.
- The inner's own design datum is its boss-top plane (z 35.95): its interior levels sit at round offsets from it
  (+3.0 pocket floor, +29.0, +34.0, +39.0 ...), which confirms the registration plane.
- The two scans disagree on: nub/pocket Ø (10.00 / 9.90), pin/hole Ø (4.00 / 3.82-3.94), knee OD (both scans have a
  1.4 deg draft, Ø138 at the parting; the outer CAD is a straight Ø135.70), boss column Ø (outer CAD 15.0, scans 15.1-15.3),
  outer CAD nub height 3.09 vs both scans 3.01. Common values: see STATUS.md.

## Traps met

- Bash heredoc with an apostrophe in the text (`OUTER's`) broke the whole command: write .py files with the Write tool.
- `import i20_skin` from another script re-runs the whole ray extraction (no main guard): shared helpers live in `an/i20lib.py`.
- Skin fit: the outer's two-pass seam exclusion (|res| > 0.12, dilated) threw away 37 % of the inner skin, because the
  inner's seams have one raised side (0.3-0.6 mm panel step). Exclude only rows where the scan is INSIDE the fit
  (grooves, holes, windows) and keep the raised side in the fit (`i20_skin.py`, 4 robust passes).
- Window loops touching the bottom grid edge are open contours and are silently skipped: close the first rows.
- Loft density: a 74 x 80-pole skin (5 mm x 2.5 deg fit) made the loft take 400 s and each knee boolean ~8 min
  (part 1's 46 x 42 loft: 28 s / 40 s). Use the outer's density: fit 8 mm x 4 deg, sections DY 8 x 50 poles;
  with the -0.35 outlier threshold the all-row skin residual is p50 0.015 / p90 0.14 (fine fit 0.010 / 0.11).
- The inner's sections run the other way round: block trim must keep `reverse=False` (build tries both).
- NX Chamfer on the knee-face circular edges is refused ("cannot be created"): revolved 45 deg cutter in 110..330 deg.
- Registration plane: I first set the inner boss faces to Z 35.95, read from the outer's params (`bosses.z0` is the NUB
  BASE). The delivered outer's boss tops are at Z 36.07 (= tongue plane; outer scan boss tops average 36.065). Fixed by
  the final lift seat_dz = 0.12 (stage J) instead of a 3 h rebuild; the analysis frame `work/frame.json` stays at 35.95
  so the chain re-runs unchanged, and the QA scripts lift the scan by seat_dz. On a clean redo: Z_TOP = 36.07 in
  `i7_register.py`, add 0.12 to every Z in `i30_params.py`, drop stage J.
- NX speed on this body: each boolean 5-12 min, opening a saved stage 5-10 min, the associative Move Object of stage J
  45 min, finalize ~15 min. Two Chest jobs ran NX at the same time. Plan for ~1 h per 5 features.
- A single revolved profile that touches the axis and contains an arc came out as a 1 152 mm3 sub-loop (twice): the knee
  hub is built from cylinders + a separate cove revolve, each volume-checked.
- Plateaus only catch faces parallel to the parting plane: the hip plate (arc underside), the sloped hip-end gussets and
  the ramped cable channel had to be added by hand (stage I). `an/i62_depthdiff.py` shows such misses at once.
- The hip-ring clearance first looked "not needed" (tool outside the body) because the plate it cuts was missing.
- `i50_fit.py`: exact point-to-solid distances with OCP (20 000 queries) ran > 30 min; the gap map uses mesh ray casting.
- NX drawing curves: open splines come as [start, end], arcs as [start, end, centre, mid], full circles as
  [centre, point]; `straight()` / `arc_xy()` in `dwg_inner.py` accept all three.
- Order matters for clearances: anything ADDED after a clearance cut (stage I plate, gussets) can refill it. Keep the
  clearance cuts last (stage K) and re-run `an/i50_fit.py` after every change.
- The knee-ring cove revolve (stage A) added 2 mm3 only. NOT an NX sub-loop: `revolve_profile` stored the arc end angles
  in a0 / a1, its own revolve-angle parameters, so any profile with an arc revolved through a few "degrees" (fixed
  2026-10-29, t0_ / t1_). The same is the likely cause of the 1 152 mm3 hub "sub-loop" above. The cove is now stage-L
  tool F06 (true arc since runM13).
- Stage-L adds came after the stage-K clearance: two auto adds (A039 / A040, hip-pad bumps) went into LT-OUT-001 and
  nobody fit-checked runL11. Run `an/i50_fit.py` on every finalized part, and keep clearance cuts last.
- The AP214 writer turns one 0.1 mm2 planar face (channel junction, X 65.5 Y 104.8 Z 77) into an unorientable cylinder;
  AP242 is clean. Check both STEP files with `an/stepcheck.py`.

## Round R8 on the user's RIBS3 save -> `Deviation_Check/..._vs_SCAN_RIBS4.prt` (2026-11-02)

Three marks (user screenshot, view into the cavity, X left / Y back / Z down). Source = the user's 06:29:54 save of
`..._RIBS3.prt` (508 features, frozen + cmp'd as `C:\NX_MCP_WORKSPACE\lt_inner_r8\src_ribs3.prt`; an earlier copy taken
12 s before that save is `src_ribs3_0629.prt`). Work folder `C:\NX_MCP_WORKSPACE\lt_inner_r8`, run with `run.ps1`.
Chain: `j2_r8.py <src> <dst> <out>` (group FEATURES_R8, appended after the user's Replace Face(471)); env `R8_SKIP`
(step names) and `R8_GROUP` let one step run alone on a saved result. Checks: `a10_check.py <before.stl> <after.stl> <tag>`
(per-spot scan deviation + 3x3 compare render), `a4m_sec.py` (scan vs CAD slices, many per sheet, loads once),
`a1_dev.py` (signed CAD->scan colour map from the user's view + zooms), `v1_user.py` (matched user view).
- Mark 1 = M1_LUG: fin from the hip-tip screw pillar (-38.09, 245.35) R4.5; bottom Z 50.07 (= 36.07 + 14.0), front face
  tangent to the pillar (normal (-0.618, -0.786)), back face (-33.07, 238.92) n (0.750, 0.661), tip (-32.8, 235.4) - all
  scan fits (`a5_lug.py`, `a6_hole.py`); sketch on Z 50.07, extruded as its own body, Trim Body by the sloped datum
  M1_LUG_CAP z = 1.6974x + 0.2581y + 62.17 (mid-surface of the ring wall above it, >= 1.9 mm inside material over the whole
  footprint, `a9_lugcap.py`), united; M1_LUG_HOLE_D2.6 through, centre (-35.12, 237.12, 54.57) (= bottom + 4.5), axis =
  front normal (scan D 2.56). Lug zone scan->CAD p50 1.93 -> 0.12 mm, scan points > 0.5 mm 67.6 % -> 4.3 %.
- Mark 2 = M2_KNEE_NOTCH: the scan has no knee wall below Z 62.56 from the tab's lower face (155.1 deg) round through
  180 to -115 deg (radial end through the -115 pad corner (-27.45, -58.86)). Sector cut r 63.5..72 from Z 62.56 (the CAD's
  own pad level) down 40 mm (takes the inner tongue there too; the scan has none). CAD area > 1 mm off the scan in the
  sector 5 510 -> 0 mm2.
- Mark 3 NOT in RIBS4. The side-wall outer skin ends on the plane PE (-42.723, 54.682) / NE (-0.788, -0.6157) (passes
  through the knee axis, ~128 deg) with a step onto the knee cylinder R67.85: 1.8 mm at Z 55, 1.0 at Z 62, 0 at Z 66.97;
  above that a ~28 deg crease skin/cylinder runs up to Z ~72. The scan is smooth and 0.4-1.0 mm outside R67.85 there (the
  scan knee has the 1.4 deg draft, the CAD knee is straight). Trial (in `r5`, NOT delivered): cut the wall between the
  plane and 140 deg (Z 35.32..66.97) and refill with a block trimmed by inner + outer Through Curves sheets, G1 to the
  old faces at the plane edges and to the knee cylinders at 140 deg. It passed every NX check (one solid, examine 0,
  seams at 140 deg 0.0 deg) and fixed Z < 60 (zone p50 0.37 -> 0.29 mm, scan > 0.5 mm 36.6 % -> 19.2 %), but G1 to a skin
  that crosses the cylinder at 28 deg forces the surface up to 1.0 mm INSIDE R67.85 at Z 62-67 and leaves a ledge at
  Z 66.97 (`RIBS4_mark3_trial_compare.png`). A clean fix needs the transition zone widened to ~122..140 deg and up to
  Z ~75 (through the crease), or the knee taking the scan draft - a design call (the knee OD mates LT-OUT-001).
Traps: (1) the plane end after a cut is TWO coplanar faces (the user's step face + the new cut face): take the boundary
of all coplanar faces, not the tallest one, or the shared edge is read as the inner edge. (2) Extend Sheet (natural
tangent, all edges) fails on a Through Curves sheet whose section chain has tiny end pieces (1.8 / 0.2 mm): use the main
edge and a line over the same Z range. (3) A closing polygon edge through a point inside a circle can self-intersect
the next edge ("self intersecting section"): close with a chord. (4) On this inner the scan in `lt_inner_ribs\scan_cn.npz`
is already in the part frame (no seat_dz lift). (5) Plotting 12 slices in parallel ran out of memory - load once.
(6) A G1 Through Curves sheet passes every NX check while sagging inside the target: always check radius vs scan.
