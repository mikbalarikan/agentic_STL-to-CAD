# LT-INN-001 Rev B Left Thigh - Inner shell: reverse-engineering report

Source: `share-Left Thigh - Inner.stl` (7 442 087 triangles, 3D-scan mesh, open in places).
Native CAD: Siemens NX 2206, solid body `LEFT_THIGH_INNER`, rebuilt feature by feature on the scan (not a mesh conversion).

## Part data

- Volume 338,012 mm3, mass 0.913 kg in Al 6061 (2.70 g/cm3). Rev A: 335,389 mm3.
- Bounding box (model frame) [-67.85, -67.85, 28.96, 118.95, 287.41, 111.03].
- Model frame = the LT-OUT-001 frame (origin on the knee axis at the outer's knee floor, +Z = knee axis away from the
  outer, +Y = hip-ring axis direction). The two STEP files assemble as they are.
- STEP check (OpenCascade): AP242 and AP214 each one valid solid, 1028 faces. Every face lies within 0.1 mm of the NX
  surface. The closed-mesh volume of the STEP triangulation is 337,989 mm3 (AP242) and 337,877 mm3 (AP214): 0.007 % and
  0.04 % from NX. (OpenCascade's own volume integral reads higher on the large trimmed B-spline faces; that is an
  integration error of the reader, not a geometry difference.)

## What changed from Rev A

- Added from the scan: 4 locating pins (N1-N4 on drawing sheet 4: two Ø3 x 6.93 with a 30° tip at the knee end,
  two Ø4 x 5.90 with an R1 top at the hip end), 4 more Ø3.3 channel holes (H5-H8), two 2.6 mm tabs with a Ø2.6 hole
  (L1, L2), two gusset ribs at the hip-end bosses.
- Joint band cleaned: the 0.12 mm pads and notches left by the old mesh-outline clearance cut are gone (the rebate
  floor is one plane at Z 36.19); the lip inner wall is one smooth surface per stretch instead of short facets; the
  knee C-ring walls are true circles (R 32.30 / 34.95 / 42.15 / 44.65 from the scan).
- Lip at boss 1 kept 0.2 mm off the LT-OUT-001 tongue, as along the rest of the lip.
- Hip-end -X corner: where the foot of the lip / wall lay over the Rev C outer's Z 36.07 plate, it is raised to Z 36.19
  (0.12 mm gap, as the rebate floor); over the outer's 34.76 rabbet the lip stays at Z 35.32.
- Mating features (boss faces, pockets, pin holes, rebate, lip level, positions and diameters) are unchanged.

## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)

| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |
|---|---|---|---|---|---|---|---|
| whole part | 1,500,000 | +0.080 | 0.051 | 0.542 | 0.967 | 79.6 % | 89.3 % |
| outer freeform skin | 365,214 | +0.006 | 0.018 | 0.135 | 0.261 | 93.2 % | 98.6 % |
| knee (r < 70) | 420,335 | +0.115 | 0.079 | 0.724 | 1.002 | 68.5 % | 83.9 % |
| hip end (y > 262) | 164,847 | +0.116 | 0.047 | 0.541 | 0.938 | 81.9 % | 89.3 % |
| interior (ribs, pockets, bosses) | 549,604 | +0.092 | 0.079 | 0.731 | 1.351 | 78.4 % | 87.2 % |

CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 0.059, p90 0.985, p95 1.831 mm.
Rev A for comparison: whole part p95 1.179 / 87.7 % within 0.5 mm; interior p95 2.571.

Most of the remaining interior deviation is the root fillets of the original (not modelled, see the README) and the
shared features that were set to the LT-OUT-001 values.

## Fit check against LT-OUT-001 Rev C (both STEP files read with OpenCascade)

Checked with the assembly fit script against `LT-OUT-001_Left_Thigh_Outer_AP242.step` Rev C:

- Interference (boolean common of the two solids): 0.0007 mm3, numerical residue on the boss faces that sit face to
  face; no inner surface point lies inside the outer (0 of 600,000; deepest -0.004 mm).
- Minimum distance between the solids: 0.0 mm (the 7 boss faces, datum A, are the contact).
- Mating planes: lip Z 35.32 over the outer rim / rabbet Z 34.76 (0.56 mm shadow gap); rebate floor Z 36.19 over the
  outer Z 36.07 surfaces (0.12 mm); boss faces Z 36.07 on the outer boss tops Z 36.07; P3 lug face Z 36.36 over the
  P3 pin base Z 36.24; pocket floors Z 39.17 over the nub tops Z 39.04.
- Concentric pairs (XY axis offset 0.000 mm): 7 Ø10 pockets on the nubs, 3 Ø4 pin holes on the pins, 7 Ø6 screw
  holes over the outer Ø5.2 holes.
- The new hip-end pins N3 / N4 (Ø4.00) sit in the Rev C pockets Ø4.30, floor Z 79.20: radial clearance 0.12-0.13 mm,
  axis offset 0.02-0.03 mm, 0.22 mm under the pin tips. They need LT-OUT-001 Rev C; Rev A has no pockets there.
