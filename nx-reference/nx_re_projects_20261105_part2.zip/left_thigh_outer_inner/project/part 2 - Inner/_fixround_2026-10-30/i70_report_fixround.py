"""Write the delivery REPORT_deviation.md (deviation by zones + fit check vs LT-OUT-001).
usage: i70_report.py cad_dir dev_tag fit_json out_md [outer label]
fit_json may carry "note": [lines] (printed under the interference line, e.g. where an interference is and why)."""
import sys, os, json
from common import W

CAD, TAG, FIT, OUTMD = sys.argv[1:5]
OUTER = sys.argv[5] if len(sys.argv) > 5 else "LT-OUT-001 Rev A"
fin = json.load(open(os.path.join(CAD, "_finalize.json")))
dev = json.load(open(os.path.join(W, f"dev2_{TAG}.json")))
fit = json.load(open(FIT))
reg = json.load(open(os.path.join(W, "register.json")))
P = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))
import trimesh
_m = trimesh.load(os.path.join(CAD, "LT-INN-001_Left_Thigh_Inner.stl"))
bbox = [round(float(x), 2) for x in list(_m.vertices.min(0)) + list(_m.vertices.max(0))]


def row(name, s):
    return (f"| {name} | {s['n']:,} | {s['mean']:+.3f} | {s['p50']:.3f} | {s['p90']:.3f} | {s['p95']:.3f} | "
            f"{100*s['within_0p2']:.1f} % | {100*s['within_0p5']:.1f} % |")


L = ["# LT-INN-001 Left Thigh - Inner shell: reverse-engineering report", "",
     "Source: `share-Left Thigh - Inner.stl` (7 442 087 triangles, 3D-scan mesh, open in places).",
     "Native CAD: Siemens NX 2206, solid body `LEFT_THIGH_INNER`, rebuilt feature by feature on the scan (not a mesh conversion).",
     "", "## Part data", "",
     f"- Volume {fin['volume_mm3']:,.0f} mm3, mass {fin['mass_g_al6061']/1000:.3f} kg in Al 6061 (2.70 g/cm3).",
     f"- Bounding box (model frame, from the STL) {bbox}.",
     "- Model frame = the LT-OUT-001 frame: origin on the knee axis at the outer's knee floor; +Z = knee axis, away from the",
     "  outer shell; +Y = direction of the hip-ring axis (knee -> hip). The two STEP files assemble as they are.",
     "", "## Registration of the inner scan into the LT-OUT-001 frame", "",
     "The inner scan came in its own scanner pose. It was moved by the shared functional features:",
     f"- the 7 bosses: inner boss columns + Ø10 pockets fitted onto the outer's boss columns + Ø10 nubs, RMS {reg['rms']:.3f} mm;",
     f"- the inner boss-face plane (flat within {reg['top_plane_sd']:.3f} mm) set onto the outer boss tops, Z 36.07.",
     "- independent checks: the 3 outer Ø4 pins sit 0.04-0.06 mm from the centres of the inner pin holes; the inner knee",
     "  shell is centred 0.15 mm from the knee axis; joint sections of the two scans close into one tube all round.",
     "", "## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)", "",
     "| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |", "|---|---|---|---|---|---|---|---|"]
for k, nm in (("all", "whole part"), ("outer_skin", "outer freeform skin"), ("knee_hub", "knee (r < 70)"),
              ("hip_end", "hip end (y > 262)"), ("interior", "interior (ribs, pockets, bosses)")):
    L.append(row(nm, dev["scan_to_cad"][k]))
c = dev["cad_to_scan"]["all"]
L += ["", f"CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 {c['p50']:.3f}, p90 {c['p90']:.3f}, p95 {c['p95']:.3f} mm.", "",
      "Most of the remaining interior deviation is the root fillets of the original (not modelled, see the README) and",
      "the shared features that were set to the LT-OUT-001 values (README item 1).", "",
      f"## Fit check against {OUTER} (both STEP files read with OpenCascade)", ""]
L.append(f"- Interference (boolean common of the two solids): **{fit['interference_mm3']} mm3**.")
L += fit.get("note", [])
L.append(f"- Minimum distance between the solids: {fit['min_distance']} mm (0 = faces in contact).")
L.append(f"- Inner surface points in the joint band (Z < 40) that lie inside the outer solid: "
         f"{fit['joint_band_inner_points_inside_outer']} of {fit['joint_band_samples']}.")
L.append(f"- Gap distribution of those points to the outer solid: {fit['joint_band_gap_hist_mm']}.")
L += ["", "Mating planes in the joint (planar faces normal to Z, area in mm2):", "", "| part | Z | area |", "|---|---|---|"]
for p in fit["joint_planes"]:
    L.append(f"| {p['side']} | {p['z']:.3f} | {p['area']:.0f} |")
L += ["", "- Boss faces: inner -Z faces at Z 36.070 on the outer +Z boss tops at Z 36.070: coplanar, face to face (datum A).",
      "  This is the only contact" + (" (apart from the hip-pad bumps above)." if fit.get("note") else "."),
      "- Rebate floor Z 36.190 over the outer tongue top Z 36.070: 0.12 mm clear.",
      "- Lip faces: inner Z 35.320 over the outer rim Z 34.760: parallel, 0.56 mm shadow gap (as both scans show).",
      "- P3 lug face Z 36.360 over the outer P3 pin base Z 36.240: 0.12 mm clear. Pocket floors Z 39.170 over the nub",
      "  tops Z 39.040: 0.13 mm clear. Hip pad Z 85.320 over the hip-ring top Z 85.200; ring clearance Ø105.25 on the",
      "  Ø105.03 ring.", "",
      f"Concentricity of the mating holes (inner hole axis vs outer feature axis, XY offset), max {fit['concentricity_max_offset']} mm:", "",
      "| feature | inner X, Y, Ø | outer X, Y, Ø | offset |", "|---|---|---|---|"]
for p in fit["concentricity"]:
    L.append(f"| {p['feature']} | {p['inner']} | {p['outer']} | {p['offset']:.4f} |")
L.append("")
open(OUTMD, "w", encoding="utf-8").write("\n".join(L))
print("\n".join(L))
