"""Plan-view (along Z) outline of the CAD solid per 1 mm Y column: min / max X. -> work/plan_outline.json
Used to place SH4 balloons outside the part."""
import json, os, sys
import numpy as np

ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
stl = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "deliver", "CAD", "LT-OUT-001_Left_Thigh_Outer.stl")
with open(stl, "rb") as f:
    f.read(80)
    n = int(np.frombuffer(f.read(4), np.uint32)[0])
    rec = np.fromfile(f, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), n)
v = rec["v"].reshape(-1, 3).astype(float)
# densify along triangle edges so long thin triangles still fill their columns
t = rec["v"].astype(float)
pts = [v]
for a, b in ((0, 1), (1, 2), (2, 0)):
    for s in (0.25, 0.5, 0.75):
        pts.append(t[:, a] + s * (t[:, b] - t[:, a]))
v = np.vstack(pts)
y0, y1 = np.floor(v[:, 1].min()), np.ceil(v[:, 1].max())
ys = np.arange(y0, y1 + 1)
idx = np.clip(((v[:, 1] - y0)).astype(int), 0, len(ys) - 1)
xmin = np.full(len(ys), np.nan); xmax = np.full(len(ys), np.nan)
np.fmin.at(xmin, idx, v[:, 0]); np.fmax.at(xmax, idx, v[:, 0])
out = {"y0": float(y0), "dy": 1.0, "xmin": [round(float(a), 2) for a in xmin], "xmax": [round(float(a), 2) for a in xmax]}
json.dump(out, open(os.path.join(ROOT, "work", "dwgE2", "plan_outline_E.json"), "w"))
print(len(ys), np.nanmin(xmin), np.nanmax(xmax))
