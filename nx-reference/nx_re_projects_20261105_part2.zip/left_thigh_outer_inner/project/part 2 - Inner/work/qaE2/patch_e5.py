"""Rev E2 (final Rev E) text for the inner deviation report."""
p = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\work\qaE2\e5_pdf.py"
t = open(p, encoding="utf-8").read()
PAIRS = [
    ('"revE": 332367}', '"revE": 332275}'),
    ("Rebate over the outer tongue: floor Z 36.19 / 36.23, step face 0.2 mm off the tongue side.",
     "Rebate over the outer tongue: floor Z 36.23, also across bosses B3 and B4 (0.16 mm above the outer bosses); step face 0.2 mm off the tongue side."),
    ("Rebate floor Z 36.19 over the tongue; boss B2 face Z 36.07 (contact).",
     "Rebate floor Z 36.19 over the tongue, also across boss B2 (0.12 mm above the outer boss)."),
    ("Floor Z 36.19 over the outer Z 36.07, step 0.2 mm off the outer wall.",
     "Floor Z 36.30 over the outer Z 36.07, step 0.2 mm off the outer wall."),
    ('"The fit changes do not touch the outer skin, the knee hub or the interior ribs; outside these boxes the Rev E statistics "\n'
     '    "are unchanged by them."]:',
     '"The fit changes do not touch the outer skin, the knee hub or the interior ribs; outside these boxes the Rev E statistics "\n'
     '    "are unchanged by them.",\n'
     '    "Final Rev E also has R6 blends on two vertical rib edges at the knee end (axes near X -30.5 Y -50.6 and X -54.2 Y 18.8), "\n'
     '    "1 mm chamfers on the tips of the two Ø3 pins N1 / N2 and one rib notch filled (X -44 to -39, Y -52 to -48). They are "\n'
     '    "design edits; their effect on the scan comparison is included in all numbers of this report."]:'),
]
for a, b in PAIRS:
    assert a in t, a[:70]
    t = t.replace(a, b)
open(p, "w", encoding="utf-8").write(t)
print("ok", len(PAIRS))
