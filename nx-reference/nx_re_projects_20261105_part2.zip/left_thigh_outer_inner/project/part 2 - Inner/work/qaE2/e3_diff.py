"""Where Rev E departs from the scan more (or less) than Rev B: per scan sample |dE| - |dB|, grouped in 10 mm cells,
connected groups reported with location, sample count and signed medians. Same samples as e2_qa.py.
usage: e3_diff.py out.json"""
import sys, os, json
import numpy as np
import open3d as o3d
from scipy import ndimage
AN = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\an"
sys.path.insert(0, AN); os.chdir(AN)
from common import W, load
R2 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
STL = {"revB": R2 + r"\LT-INN-001_RevB_Left_Thigh_Inner\LT-INN-001_RevB\CAD\LT-INN-001_Left_Thigh_Inner.stl",
       "revE": R2 + r"\deliver_RevE2\CAD\LT-INN-001_Left_Thigh_Inner.stl"}
v, f = load()
DZ = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))["seat_dz"]
v = v.copy(); v[:, 2] += DZ
rng = np.random.default_rng(7)
P = v[rng.choice(len(v), 1500000, replace=False)].astype(np.float32)
D = {}
for t, p in STL.items():
    cm = o3d.io.read_triangle_mesh(p); cm.remove_duplicated_vertices()
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
    D[t] = sc.compute_signed_distance(o3d.core.Tensor(P)).numpy()
np.save(os.path.join(os.path.dirname(sys.argv[1]), "dBE.npy"), np.c_[P, D["revB"], D["revE"]])
out = {}
for sign, m in (("worse", (np.abs(D["revE"]) - np.abs(D["revB"]) > 0.3) & (np.abs(D["revE"]) > 0.5)),
                ("better", (np.abs(D["revB"]) - np.abs(D["revE"]) > 0.3) & (np.abs(D["revB"]) > 0.5))):
    Q = P[m]; k = np.floor((Q - np.array([-75, -75, 20])) / 4.0).astype(int)
    G = np.zeros(k.max(0) + 1, bool); G[tuple(k.T)] = True
    lab, n = ndimage.label(G, structure=np.ones((3, 3, 3)))
    L = lab[tuple(k.T)]
    cl = []
    for i in range(1, n + 1):
        s = L == i
        if s.sum() < 150:
            continue
        q = Q[s]
        cl.append(dict(n=int(s.sum()), lo=[round(float(x), 1) for x in q.min(0)], hi=[round(float(x), 1) for x in q.max(0)],
                       centre=[round(float(x), 1) for x in np.median(q, 0)],
                       dB_med=round(float(np.median(D["revB"][m][s])), 3), dE_med=round(float(np.median(D["revE"][m][s])), 3)))
    cl.sort(key=lambda c: -c["n"])
    out[sign] = dict(total=int(m.sum()), clusters=cl[:15])
    print(sign, int(m.sum()))
    for c in cl[:15]:
        print("  ", c)
json.dump(out, open(sys.argv[1], "w"), indent=1)
