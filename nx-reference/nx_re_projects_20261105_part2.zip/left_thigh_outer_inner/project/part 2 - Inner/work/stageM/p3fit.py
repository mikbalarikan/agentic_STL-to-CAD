import numpy as np, sys
sys.path.insert(0, ".")
from fixlib import zsec
P = []
for z in np.arange(53.5, 61.6, 0.25):
    s = zsec(z, (-36.2, -30.5, 234.0, 240.5))
    mid = s.mean(1)
    P.append(mid)
P = np.vstack(P)
m = (P[:, 0] > -35.0) & (P[:, 0] < -32.3) & (P[:, 1] < 239.6)
Q = P[m]
best = None
for th in np.arange(20, 80, 0.5):
    n = np.array([np.cos(np.radians(th)), np.sin(np.radians(th))])
    t = Q @ n
    h, e = np.histogram(t, bins=np.arange(t.min(), t.max() + 0.1, 0.1))
    p = h / h.sum(); ent = -(p[p > 0] * np.log(p[p > 0])).sum()
    if best is None or ent < best[0]:
        best = (ent, th, t)
ent, th, t = best
n = np.array([np.cos(np.radians(th)), np.sin(np.radians(th))]); d = np.array([n[1], -n[0]])
h, e = np.histogram(t, bins=np.arange(t.min(), t.max() + 0.1, 0.1))
print("normal angle", th, "n", n, "d", d)
top = np.argsort(h)[::-1][:6]
for k in sorted(top): print(round(e[k] + 0.05, 2), h[k])
