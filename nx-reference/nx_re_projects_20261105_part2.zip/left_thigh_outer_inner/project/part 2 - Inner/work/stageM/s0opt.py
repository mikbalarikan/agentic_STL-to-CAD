import numpy as np, sys
sys.path.insert(0, ".")
from fixlib import depth
import open3d as o3d
d = depth("revA"); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(o3d.io.read_triangle_mesh("../nx/runL11/inner_Z.stl")))
for name, xr in (("B6", (100.1, 109.2)), ("B7", (-31.5, -24.35))):
    xs = np.arange(xr[0], xr[1], 0.2); ys = np.arange(228.0, 237.0, 0.2)
    XX, YY = np.meshgrid(xs, ys)
    I = ((YY - Y0) / C).astype(int); J = ((XX - X0) / C).astype(int)
    zs, zr = d["zs"][I, J], d["zc"][I, J]
    r = np.c_[XX.ravel(), YY.ravel(), np.zeros(XX.size), np.zeros(XX.size), np.zeros(XX.size), np.ones(XX.size)].astype(np.float32)
    zl = sc.cast_rays(o3d.core.Tensor(r))["t_hit"].numpy().reshape(XX.shape)
    # L11 buttress bottom value per x (taken at y 236)
    zb = zl[np.argmin(abs(ys - 236.5))]
    for s0 in np.arange(229.0, 236.1, 0.5):
        cad = np.where(YY < s0, zr, np.minimum(zr, zb[None, :]))
        e = cad - zs
        print(name, s0, "mean|e|", round(np.nanmean(abs(e)), 3), "extra(cad<scan) mm3", round(np.nansum(np.clip(zs - cad, 0, None)) * 0.04, 1), "missing", round(np.nansum(np.clip(cad - zs, 0, None)) * 0.04, 1))
