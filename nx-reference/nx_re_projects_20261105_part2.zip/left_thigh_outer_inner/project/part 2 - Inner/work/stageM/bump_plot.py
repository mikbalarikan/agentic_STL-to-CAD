import sys, numpy as np, trimesh
sys.path.insert(0, ".")
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import outer
from fixlib import scan
vo, fo = outer.load_outer()[:2]; vi, fi = scan()
M = [("outer scan", trimesh.Trimesh(vo, fo, process=False), "tab:blue", 1.6), ("inner scan", trimesh.Trimesh(vi, fi, process=False), "tab:orange", 1.6),
     ("outer CAD", trimesh.load(outer.OUTER_CAD_STL), "k", 0.9), ("inner CAD M13", trimesh.load("../nx/runM13/inner_Z.stl"), "tab:green", 0.9)]
fig, axs = plt.subplots(1, 2, figsize=(16, 8))
for ax, cx in zip(axs, (27.0, 49.0)):
    for nm, m, c, lw in M:
        s = trimesh.intersections.mesh_plane(m, [1, 0, 0], [cx, 0, 0])[:, :, 1:]
        k = ((s[..., 0] > 262) & (s[..., 0] < 282) & (s[..., 1] > 70) & (s[..., 1] < 90)).any(1)
        ax.add_collection(LineCollection(s[k], colors=c, lw=lw, label=nm))
    ax.set_xlim(262, 282); ax.set_ylim(70, 90); ax.set_aspect("equal"); ax.grid(lw=0.3); ax.legend(fontsize=8); ax.set_title(f"x = {cx} (y right, z up)")
fig.tight_layout(); fig.savefig("../work/stageM/bumps.png", dpi=70)
