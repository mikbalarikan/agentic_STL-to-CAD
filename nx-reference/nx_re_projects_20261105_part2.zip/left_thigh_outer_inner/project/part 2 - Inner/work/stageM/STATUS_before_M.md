# LT-INN-001 Rev A (Left Thigh, Inner shell) - status

Started 2026-10-29. Work folder `part 2 - Inner\` (layout mirrors part 1). Nothing sent to the client.

## Milestones

- [x] **Scan loaded** (`an/s0_load.py`): 7 442 087 triangles, 3.73 M vertices, 25 139 open edges, no non-manifold edges.
- [x] **Registration to the LT-OUT-001 frame** (`an/i2_rim.py` -> `i4_feats.py` -> `i5_cyl.py` -> `i7_register.py`, checks `i8_check.py`)
  - `work/frame.json`: p_LT-OUT = R (p_scan - o). Inner = outer frame turned 180 deg about Y.
  - Fit on the 7 boss axes (inner Ø15 boss columns + Ø10 pockets vs outer Ø15 columns + Ø10 nubs): 13 point pairs, RMS 0.041 mm.
  - Inner boss-face plane (flatness sd 0.012 mm) first set to Z 35.95, then lifted +0.12 to Z 36.07 (stage J), the
    boss-top / tongue plane of the delivered LT-OUT-001 (35.95 was the outer's nub BASE value, my misread; the outer
    scan's boss tops average 36.065). QA scripts lift the scan by the same 0.12.
  - Independent checks (not used in the fit): the 3 outer Ø4 pins sit in the inner pin holes 0.040 / 0.056 / 0.063 mm off-centre;
    inner knee shell centred 0.15 mm from the knee axis; joint sections close into one tube all round.
- [x] **Scan analysis**: skin fit (8 mm x 4 deg B-spline, all-row residual p50 0.015, joint band = outer skin), cavity fit
  (p50 0.023, wall 3.14), 13 interior levels, rebate footprint, 2 side windows, 4 seam grooves, holes, hub profile,
  hip plate / gussets / channel ramp.
- [x] **Solid built** (`nx/build_inner.py`, stages A B C D E G F H I J K, resumed run to run: `runA5` -> `runC7` -> `runI8`
  -> `runJ9` -> `runK10`) and finalized (`nx/finalize_inner.py` -> `deliver/CAD`): ONE valid solid `LEFT_THIGH_INNER`,
  335 389 mm3, 0.906 kg Al 6061; NX examine geometry all 0; B-spline skin / cavity / grooves + planes, cylinders, cones, tori.
  STEP AP214 + AP242 re-read with OCP (`an/stepcheck.py`): 1 solid each, valid, volume 335 348 / 335 392 (the AP214 reader
  notes one unresolved reference; solid still valid). x_t 5.4 MB, STL 25 MB (min Z 35.32 = lip).
- [x] **Fit check vs the delivered LT-OUT-001** (`an/i50_fit.py`, OCP on both AP214 files, `work/fit_K.json`):
  interference **0.0 mm3**; contact only on the 7 boss faces (min distance 0.0); 0 of 24 384 joint-band inner points inside
  the outer; 21 mating pairs concentric with 0.000 mm offset (7 pockets / nubs, 3 pin holes / pins, 7 screw holes / outer
  holes, boss columns); planes: lip 35.32 vs rim 34.76 (0.56 gap), boss faces 36.07 = outer boss tops 36.07, rebate 36.19 vs
  tongue 36.07, P3 lug 36.36 vs pin base 36.24, pocket floors 39.17 vs nub tops 39.04.
- [x] **Deviation report** `deliver/Deviation Report/REPORT_deviation.md` + 7 maps (`an/i40_dev.py`, scan lifted 0.12):
  skin p50 0.018 / p95 0.27 / 98.4 % within 0.5 (outer Rev A 0.021 / 0.35 / 97.4 %); whole part p50 0.051 / p95 1.18 /
  87.7 % within 0.5 (outer 0.054 / 0.98 / 89.2 %). Remaining: root fillets (not modelled, as on the outer), the knee-hub
  draft (common Ø135.70), the knee-ring cove and the hip-side wall thickening (README item 9).
  NX overlay `Deviation_Check/LT-INN-001_Left_Thigh_Inner_vs_SCAN.prt` (scan as 14 convergent bodies; probe p50 0.049).
- [x] **Drawings** `deliver/Drawings`: 4 x A1 sheets, third angle, combined PDF + per-sheet PDF + DWG + NX `_dwg.prt`
  (`nx/dwg_inner.py`): 15 dimensions read back at their expected values, 0 errors, 0 view overlaps; GD&T: datum A (boss
  faces, flatness 0.05), B (Ø19.90 H7, perpendicularity Ø0.03 A), C (pin hole P3), position frames on pockets (Ø0.1 A B C),
  pin holes (Ø0.05 A B), knee holes (Ø0.1 A B), profile 0.2 A B C in the notes; SH4 14 arrow balloons outside the part +
  location and level tables. Rasterised and checked for text over geometry.
  Lead review fixes (2026-10-29 ~20:30, `work/dwg_K6`): SH3 detail renamed C -> D (C stays datum C only; via
  `SettingsManager.CreateDrawingEditViewLabelSettingsBuilder` on the label from `UF Draw.AskViewLabel`); SH2 4X-hole note
  and slot note moved apart; the 4X and 3X callout leaders leave from the right end of the text, so no leader crosses
  any text. Re-exported (combined + per-sheet PDF, DWG), rasterised and checked; zip rebuilt.
- [x] **Renders** `deliver/Renders` (7, incl. 2 of the inner + outer assembly).
- [x] **Zip + client text**: `LT-INN-001_RevA_Left_Thigh_Inner.zip` (43 MB, 37 entries, testzip OK, same structure as the
  LT-OUT-001 Rev A zip plus README and per-sheet PDF/DWG); `CLIENT_MESSAGE.txt`.

## Review fix 2026-10-29 (user's visual review of the Rev A overlay) - IN PROGRESS, see HANDOFF.md

Stage L added to `nx/build_inner.py` (78 tools from `nx/fixes_L.json`, written by `an/i97_nxprep.py`), run `nx/runL11`
resumed from `nx/runK10`: PASS, ONE solid INNER 341 728 mm3 (Rev A 335 389), body_ok, no feature errors, 0 failed tools.
Not yet finalized / exported: deliver/ and the zip are still Rev A as first built.

| | p50 | p95 | within 0.5 mm |
|---|---|---|---|
| whole part, Rev A as first built | 0.051 | 1.19 | 87.5 % |
| whole part, after stage L (`nx/runL11/inner_Z.stl`, `work/dev2_L11.json`) | 0.048 | 0.78 | 91.3 % |

Causes of the user's spots (u1-u3) and fixes:
- u1 knee fin / u2 tail: the stage-A skin loft ran past the leg's real end face (to Y -62; scan ends at Y -50.5); the
  flat wall was the -40 deg hub-sector cut. F01 (cut to the scanned end-face contour), F14 (wall top falls 1.91 mm/mm
  along the end face; the B1 column had stood to Z 88), F15 (cavity end curves to Y -33.6, was flat at Y -29).
- u3 red channel: a false 7 x 3 mm groove (scan strip at Z 76.69 fell between the preset plateau levels) and a 4-5 mm
  slot between the ramped bars (scan floor ramps 0.109). F04 F05 F12 F13.
- u3 left post / C-feature: 2.3 mm gusset ribs on pin lugs P1 / P2 (edge from the lug at Z 50 up the wall at 1:2). F02 F03.
- u3 pad by the boss: B6 and B7 have a 4.3 mm web under the boss (bottom edge 54 deg) and a crowned buttress. F08-F11.
- u3 floor / rib: the x 36-40 rib continues to Y 162 with a sloped bottom edge (auto fix); its large root fillets stay.
- also: knee-ring cove (README item 9) F06, knee-ring hole chamfers F07, two knee-floor posts F16, pin holes continued
  to 0.4 mm under the skin as scanned F17, 53 auto plane fixes A001-A065 (`an/i99_autofix.py`).
Fresh overlay crops of the user's spots, before | after: `work/verify/user_spots_before_after.png`
(`work/verify/revA/*.png`, `work/verify/L11/*.png`, same views).

Mating interface: untouched (all tools above Z 37.5 except pin-hole extensions inside the lug); fit check
`an/i50_fit.py` still to run on the finalized AP214.

### Cluster table, Rev A vs after stage L (`an/i100_table.py revA L11`)

Clusters >= 20 mm2 (|signed deviation| > 0.3 mm, full-resolution scan, both directions):
before (revA): missing (78, 33399), extra (66, 9483) (count, mm2); after (L11): missing (86, 29476), extra (80, 7296).

| # | sign | area mm2 | p90 mm | centre X, Y, Z | cause | after the fix |
|---|---|---|---|---|---|---|
| 0 | extra | 2540 | 9.55 | 65, -46, 57 | F01 knee-end tail/fin (u1, u2): stage-A skin loft ran past the leg's end face; cut t; F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa | fixed |
| 1 | missing | 3171 | 6.34 | 37, 214, 98 | missing rib extension x 36-40, Y 162-204 (auto fix) + R5-6 root fillets along the rib | rib fixed; fillets kept |
| 2 | missing | 3990 | 3.17 | 35, 120, 80 | u3 red: false 7 x 3 mm groove + 4-5 mm slot along the channel rail (F04 F05 F12 F13); rest = rail root fillets | fixed; fillets kept |
| 3 | missing | 1021 | 8.17 | 101, 246, 65 | F09 B6 web under the hip boss, t 4.3, bottom edge Z 43.0 at Y 249.7 rising 54 deg to | improved (46 % of points still off) |
| 4 | missing | 975 | 8.54 | -24, 246, 66 | F08 B7 web under the hip boss, t 4.3, bottom edge Z 43.0 at Y 249.7 rising 54 deg to; F10 B7 buttress beside the web, crowned top Z 70.6 (scan section mean Y 238-256) | fixed |
| 5 | missing | 3474 | 1.52 | 11, -23, 78 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 6 | missing | 2747 | 1.54 | 8, 18, 78 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 7 | missing | 891 | 3.92 | -22, 264, 67 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 8 | missing | 807 | 3.02 | 65, 49, 62 | R4-6 root fillet in the B2 side-wall corner | kept (fillet) |
| 9 | missing | 1478 | 1.57 | -29, 50, 77 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 10 | missing | 1054 | 1.92 | 1, -0, 85 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub | fixed |
| 11 | missing | 596 | 3.36 | 49, 45, 78 | F04 channel rail plateau Z 76.94 (u3 red): Rev A had a 7 mm wide, 3 mm deep false gr; auto add | improved (57 % of points still off) |
| 12 | missing | 496 | 3.81 | 99, 264, 54 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 13 | missing | 900 | 2.09 | 79, 262, 82 | root fillets at the hip-end rib junction | kept (fillet) |
| 14 | extra | 472 | 3.89 | 66, -31, 52 | F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa; F15 knee-end cavity end: Rev A cavity stopped flat at Y -29.0, scan end wall curves  | improved (55 % of points still off) |
| 15 | missing | 691 | 2.40 | 86, 166, 53 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 16 | missing | 906 | 1.81 | -3, 262, 86 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 17 | missing | 1952 | 0.84 | 15, -62, 53 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 18 | missing | 298 | 4.91 | -19, 182, 63 | root fillet, rib-to-wall junction near B4 | kept (fillet) |
| 19 | missing | 310 | 4.47 | 88, 131, 67 | F02 P1 pin-lug gusset rib t 2.3 (u3 'left post'): edge from the lug at Z 50 up the w | improved (73 % of points still off) |
| 20 | missing | 280 | 4.23 | 100, 194, 66 | F03 P2 pin-lug gusset rib t 2.3 (u3 'C-shaped feature') | improved (73 % of points still off) |
| 21 | extra | 1576 | 0.69 | 17, -58, 45 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 22 | missing | 202 | 5.02 | -34, 238, 57 | P3 lug gusset rib t ~2.3 (like F02/F03, plane ~48 deg in XY) - missing | OPEN (next step) |
| 23 | missing | 302 | 3.21 | 62, -41, 49 | F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa | improved (100 % of points still off) |
| 24 | missing | 810 | 1.16 | 32, 272, 86 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 25 | extra | 375 | 2.35 | 106, 182, 55 | right side window: scan wall 2.3 thick round the window, CAD inner face 1.4-2 mm proud (cavity loft bridged the opening) | OPEN (next step) |
| 26 | missing | 232 | 3.74 | -28, 78, 56 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 27 | missing | 237 | 3.43 | 76, 27, 54 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 28 | missing | 677 | 1.09 | 16, -62, 38 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 29 | missing | 385 | 1.86 | 92, 165, 73 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 30 | missing | 621 | 0.82 | -54, 41, 50 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 31 | missing | 291 | 1.66 | -27, 274, 67 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 32 | missing | 81 | 5.83 | 49, 272, 82 | auto add | fixed |
| 33 | missing | 78 | 5.80 | 27, 272, 82 | OPEN - not explained | gone |
| 34 | missing | 274 | 1.51 | -45, 52, 48 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 35 | extra | 133 | 2.81 | 11, 242, 101 | small extra on the hip-end roof (11, 242, 101), not diagnosed | open (small) |
| 36 | missing | 184 | 1.94 | -43, 265, 39 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 37 | missing | 107 | 3.25 | -20, 164, 54 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 38 | extra | 83 | 4.14 | -26, 268, 69 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 39 | extra | 306 | 1.12 | 101, 148, 54 | right side window, same as #25 | OPEN (next step) |
| 40 | missing | 54 | 5.96 | -31, -51, 59 | F16a knee-floor post Ø3.36 to Z 56.85 (missing in Rev A) | improved (51 % of points still off) |
| 41 | missing | 111 | 2.73 | 55, 76, 78 | F04 channel rail plateau Z 76.94 (u3 red): Rev A had a 7 mm wide, 3 mm deep false gr | improved (78 % of points still off) |
| 42 | extra | 107 | 2.83 | -28, 74, 53 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 43 | extra | 97 | 3.06 | -19, 164, 52 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 44 | extra | 102 | 2.84 | 59, -42, 48 | F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa | improved (80 % of points still off) |
| 45 | extra | 182 | 1.59 | -28, -60, 47 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 46 | missing | 50 | 5.73 | -57, 19, 59 | F16b knee-floor post Ø3.29 to Z 56.72 (missing in Rev A) | improved (52 % of points still off) |
| 47 | missing | 70 | 3.74 | -38, 245, 44 | F17c pin hole Ø4.0 continued to Z 63.55 (scan: open to 0.4 mm under the outer skin; R | improved (100 % of points still off) |
| 48 | missing | 195 | 1.29 | -17, 53, 56 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 49 | missing | 193 | 1.30 | 102, 274, 65 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 50 | extra | 59 | 4.06 | 103, 266, 65 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 51 | extra | 95 | 2.49 | 91, 165, 71 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 52 | missing | 68 | 3.29 | 97, 131, 43 | F17a pin hole Ø4.0 continued to Z 60.45 (scan: open to 0.4 mm under the outer skin; R | improved (100 % of points still off) |
| 53 | extra | 336 | 0.65 | -29, 206, 58 | print / scan noise | kept (by rule) |
| 54 | missing | 67 | 3.24 | 109, 194, 43 | F17b pin hole Ø4.0 continued to Z 60.3 (scan: open to 0.4 mm under the outer skin; Re | improved (100 % of points still off) |
| 55 | missing | 81 | 2.51 | 98, 262, 82 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 56 | missing | 149 | 1.35 | -3, 78, 51 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 57 | extra | 331 | 0.60 | -46, 45, 50 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 58 | extra | 60 | 3.22 | 96, 260, 67 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 59 | extra | 283 | 0.62 | 83, 90, 61 | print / scan noise | kept (by rule) |
| 60 | extra | 181 | 0.84 | 56, -46, 48 | F01 knee-end tail/fin (u1, u2): stage-A skin loft ran past the leg's end face; cut t; F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa | improved (56 % of points still off) |
| 61 | missing | 109 | 1.24 | -51, 25, 50 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 62 | extra | 35 | 3.76 | 94, 268, 53 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 63 | extra | 33 | 3.92 | 11, -11, 87 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07d knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 64 | extra | 174 | 0.73 | -41, 257, 55 | print / scan noise | kept (by rule) |
| 65 | extra | 42 | 3.01 | 10, 11, 86 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07a knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 66 | extra | 44 | 2.80 | -11, 11, 85 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07b knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 67 | missing | 36 | 3.27 | 86, 164, 84 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 68 | extra | 41 | 2.79 | 100, 254, 60 | edge of the new B6 web / buttress (outline simplified) | small, kept |
| 69 | missing | 99 | 1.14 | -17, 157, 56 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 70 | extra | 34 | 3.22 | -21, 263, 43 | B7 column bottom near the pocket (scan gap / pocket edge) | small, kept |
| 71 | extra | 32 | 3.36 | -19, 268, 47 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 72 | extra | 35 | 2.96 | -24, 254, 65 | F10 B7 buttress beside the web, crowned top Z 70.6 (scan section mean Y 238-256) | improved (100 % of points still off) |
| 73 | missing | 85 | 1.10 | 77, 21, 59 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 74 | extra | 41 | 2.30 | 81, 30, 51 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 75 | missing | 176 | 0.53 | 1, -4, 77 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 76 | extra | 40 | 2.24 | -38, 242, 41 | F17c pin hole Ø4.0 continued to Z 63.55 (scan: open to 0.4 mm under the outer skin; R | improved (100 % of points still off) |
| 77 | extra | 29 | 2.96 | -17, 267, 64 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 78 | extra | 24 | 3.59 | -10, -11, 88 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07c knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (88 % of points still off) |
| 79 | missing | 31 | 2.66 | -10, 11, 82 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07b knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 80 | extra | 50 | 1.60 | 65, 243, 97 | small extra on the hip-end roof | small, kept |
| 81 | extra | 37 | 2.17 | 85, 162, 59 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 82 | extra | 38 | 2.10 | 53, 94, 77 | F04 channel rail plateau Z 76.94 (u3 red): Rev A had a 7 mm wide, 3 mm deep false gr | improved (98 % of points still off) |
| 83 | missing | 32 | 2.37 | 11, 10, 81 | F07a knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 84 | missing | 147 | 0.52 | 6, -18, 77 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 85 | extra | 89 | 0.84 | -51, 41, 37 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 86 | extra | 33 | 2.22 | 75, 25, 62 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 87 | extra | 32 | 2.07 | 61, 132, 82 | small extra, channel bar end | small, kept |
| 88 | extra | 49 | 1.37 | -18, 64, 83 | small extra near B3 rib top | small, kept |
| 90 | extra | 23 | 2.71 | 98, 131, 41 | F17a pin hole Ø4.0 continued to Z 60.45 (scan: open to 0.4 mm under the outer skin; R | improved (100 % of points still off) |
| 91 | extra | 24 | 2.68 | 98, 262, 43 | B6 column bottom near the pocket (scan gap / pocket edge) | small, kept |
| 92 | extra | 26 | 2.45 | 109, 193, 40 | F17b pin hole Ø4.0 continued to Z 60.3 (scan: open to 0.4 mm under the outer skin; Re | improved (100 % of points still off) |
| 93 | extra | 20 | 3.08 | -24, 252, 58 | edge of the new B7 web / buttress (outline simplified) | small, kept |
| 94 | extra | 28 | 2.16 | -22, 81, 52 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 96 | extra | 21 | 2.76 | 97, 270, 47 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 97 | missing | 100 | 0.57 | -53, 37, 69 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 98 | extra | 112 | 0.48 | 65, 252, 83 | print / scan noise | kept (by rule) |
| 99 | extra | 52 | 1.02 | 12, 259, 76 | auto cut | fixed |
| 100 | extra | 25 | 2.05 | 82, 164, 70 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 101 | missing | 104 | 0.49 | 84, 101, 69 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 102 | extra | 24 | 2.13 | 72, 33, 51 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 104 | missing | 69 | 0.71 | 72, 59, 73 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 105 | extra | 76 | 0.64 | 109, 237, 69 | print / scan noise | kept (by rule) |
| 107 | missing | 60 | 0.79 | -44, 249, 37 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 108 | missing | 29 | 1.64 | 59, 63, 79 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 109 | extra | 64 | 0.73 | 67, -3, 83 | print / scan noise | kept (by rule) |
| 110 | extra | 24 | 1.94 | -36, 249, 57 | edge of the new B7 buttress | small, kept |
| 111 | missing | 84 | 0.54 | 116, 261, 52 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 114 | missing | 41 | 1.06 | 118, 264, 38 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 116 | extra | 77 | 0.52 | -60, 28, 50 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 118 | missing | 41 | 0.98 | -17, 257, 87 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 119 | missing | 31 | 1.27 | 76, 33, 46 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 120 | missing | 22 | 1.78 | 98, 262, 40 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 121 | extra | 64 | 0.60 | 99, 190, 75 | print / scan noise | kept (by rule) |
| 124 | extra | 51 | 0.70 | 46, 268, 107 | print / scan noise | kept (by rule) |
| 125 | extra | 83 | 0.43 | 11, 250, 85 | print / scan noise | kept (by rule) |
| 127 | missing | 51 | 0.57 | 85, 25, 38 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 129 | missing | 52 | 0.55 | 106, 217, 70 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 131 | extra | 62 | 0.44 | 113, 258, 57 | print / scan noise | kept (by rule) |
| 133 | extra | 43 | 0.60 | -32, 64, 72 | print / scan noise | kept (by rule) |
| 136 | extra | 42 | 0.57 | 104, 198, 68 | print / scan noise | kept (by rule) |
| 137 | missing | 45 | 0.52 | -18, 35, 77 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 138 | extra | 51 | 0.46 | 68, 64, 73 | auto cut | fixed |
| 139 | extra | 43 | 0.54 | 102, 174, 65 | auto cut | improved (100 % of points still off) |
| 140 | extra | 51 | 0.45 | -3, 256, 101 | print / scan noise | kept (by rule) |
| 143 | missing | 35 | 0.59 | 99, 181, 73 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 144 | extra | 45 | 0.46 | -11, 3, 93 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub | fixed |
| 145 | missing | 33 | 0.61 | -17, 166, 40 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 146 | missing | 42 | 0.48 | 92, 144, 74 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 148 | missing | 23 | 0.82 | 62, 246, 101 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 149 | missing | 24 | 0.79 | 62, 253, 101 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 153 | missing | 26 | 0.68 | 109, 189, 50 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 154 | missing | 35 | 0.50 | -41, 263, 59 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 156 | missing | 26 | 0.65 | -32, 70, 52 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 157 | missing | 21 | 0.79 | 93, 258, 82 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 158 | missing | 27 | 0.60 | 114, 251, 62 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 160 | missing | 40 | 0.39 | -6, 256, 103 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 161 | missing | 21 | 0.72 | -32, 60, 70 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 166 | extra | 21 | 0.69 | 82, 268, 94 | print / scan noise | kept (by rule) |
| 169 | missing | 23 | 0.60 | 66, 40, 74 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 170 | missing | 23 | 0.60 | -25, 89, 50 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 173 | extra | 27 | 0.48 | 113, 202, 40 | print / scan noise | kept (by rule) |
| 178 | extra | 33 | 0.35 | -46, 48, 80 | print / scan noise | kept (by rule) |
| 179 | extra | 21 | 0.54 | 78, -23, 40 | F01 knee-end tail/fin (u1, u2): stage-A skin loft ran past the leg's end face; cut t | fixed |

## Open points for the lead / user (not blocking)

- The inner touches the outer only on the boss faces; the lip keeps the scanned 0.56 mm shadow gap. If the client wants
  the lip faces in contact, change lip Z (one value) - README item 2 says so.
- Outer CAD nub height (39.04 - 36.07 = 2.97) and inner pocket depth 3.10 give 0.13 clearance; both scans show 3.01.

## Shared features: scans disagree -> one common design value (outer CAD value kept)

| feature | outer scan / CAD | inner scan | design value used |
|---|---|---|---|
| boss face plane | CAD 36.07 (scan tops avg 36.065) | coplanar with its rebate floor | Z 36.07, face to face (datum A) |
| boss locating nub / pocket | nub Ø10.00, top Z 39.04 | pocket Ø9.90 | pocket Ø10.00, floor Z 39.17 (0.13 over the nub) |
| locating pin / hole | pin Ø4.00 | hole Ø3.82-3.94 | Ø4.00 x 10 deep |
| boss column | CAD Ø15.00 | Ø15.1-15.35 | Ø15.00 |
| knee hub OD | CAD Ø135.70 straight (scan 1.4 deg draft) | 1.4 deg draft, Ø138 at the joint | Ø135.70 straight, flush |
| P3 pin base | CAD top Z 36.24 | lug face ~36.36 | lug face Z 36.36 (0.12 over) |
| hip ring | Ø105.03, axis X 37.97 Z 35.18, flat top Z 85.20 | arc Ø105.26, pad | clearance Ø105.25, pad Z 85.32 |

## Joint (final model)

- Contact only on the 7 boss faces (Z 36.07). Lip faces Z 35.32 over the outer rim Z 34.76: 0.56 mm shadow gap all round
  (as both scans show). Rebate floor Z 36.19, 0.12 over the outer tongue. Pocket floors 0.13 over the nubs.

## Deviation (final build STL, scan lifted by 0.12)

| zone | p50 | p90 | p95 | within 0.5 | outer Rev A for comparison |
|---|---|---|---|---|---|
| whole part | 0.051 | 0.66 | 1.19 | 87.5 % | 0.054 / 0.54 / 0.98 / 89.2 % |
| outer skin | 0.018 | 0.14 | 0.27 | 98.4 % | 0.021 / 0.21 / 0.35 / 97.4 % |
