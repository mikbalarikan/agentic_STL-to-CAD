import sys
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopoDS import TopoDS
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
def rd(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()
a, b = rd(sys.argv[1]), rd(sys.argv[2])
c = BRepAlgoAPI_Common(a, b).Shape()
e = TopExp_Explorer(c, TopAbs_SOLID)
while e.More():
    s = TopoDS.Solid_s(e.Current()); g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g)
    bb = Bnd_Box(); BRepBndLib.Add_s(s, bb)
    if g.Mass() > 0.01:
        cm = g.CentreOfMass()
        print(round(g.Mass(), 2), [round(v, 2) for v in (cm.X(), cm.Y(), cm.Z())], [round(v, 2) for v in bb.Get()])
    e.Next()
