import numpy as np, sys
sys.path.insert(0, ".")
from fixlib import depth
d = depth("revA"); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
for xs in (np.arange(99.5, 110.1, 1.0), np.arange(-32.5, -23.0, 1.0)):
    print("y   " + " ".join(f"{x:9.1f}" for x in xs))
    for y in np.arange(227.0, 238.1, 0.5):
        i = int((y - Y0) / C)
        print(f"{y:5.1f} " + " ".join(f"{d['zs'][i, int((x - X0) / C)]:4.1f}/{d['zc'][i, int((x - X0) / C)]:4.1f}" for x in xs))
