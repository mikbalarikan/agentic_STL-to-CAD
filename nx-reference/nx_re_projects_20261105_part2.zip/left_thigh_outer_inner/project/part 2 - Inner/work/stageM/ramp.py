import numpy as np, sys, trimesh
sys.path.insert(0, ".")
from fixlib import depth
d = depth("revA"); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
print("cell", C, d["zs"].shape, list(d.keys()))
cm = trimesh.load("../nx/runL11/inner_Z.stl")
xs = np.arange(99.5, 110.1, 1.0); ys = np.arange(227.0, 238.1, 0.5)
import open3d as o3d
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(o3d.io.read_triangle_mesh("../nx/runL11/inner_Z.stl")))
def cadz(x, y):
    r = o3d.core.Tensor(np.array([[x, y, 0, 0, 0, 1]], np.float32))
    return float(sc.cast_rays(r)["t_hit"].numpy()[0])
print("y   " + " ".join(f"{x:6.1f}" for x in xs))
for y in ys:
    i = int((y - Y0) / C); row = []
    for x in xs:
        j = int((x - X0) / C)
        row.append(f"{d['zs'][i, j]:5.1f}/{cadz(x, y):4.1f}")
    print(f"{y:5.1f} " + " ".join(row))
