import numpy as np, trimesh, sys
cm = trimesh.load(sys.argv[1])
for x in (-29, -27, 104, 106):
    s = trimesh.intersections.mesh_plane(cm, [1, 0, 0], [x, 0, 0]).reshape(-1, 3)
    m = (s[:, 1] > 226) & (s[:, 1] < 240) & (s[:, 2] > 60) & (s[:, 2] < 80)
    q = s[m]; q = q[np.argsort(q[:, 1])]
    print(x, np.round(q[::max(1, len(q)//25), 1:], 2).tolist())
