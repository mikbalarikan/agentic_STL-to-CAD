"""Final cluster table for STATUS.md: rows of i100_table revA finalM, with the manual cause notes of the L11 table
(STATUS.md) where the generator found no cause, and the stage-M notes."""
import re
st = open("STATUS.md", encoding="utf-8").read()
old = {}
for ln in st.split("\n"):
    m = re.match(r"^\| (\d+) \| (missing|extra) \|", ln)
    if m:
        old[int(m.group(1))] = [c.strip() for c in ln.strip("|").split("|")]
gen = open("work/table_revA_finalM.md", encoding="utf-8").read().split("\n")
over = {
    22: ("P3 pin-lug gusset rib t 2.6 (plane 45.5 deg in XY) with a Ø2.8 hole, missing in L11 (stage M: M01, M01h)",
         "fixed (21 mm2 p90 1.04 left at the rib-to-wall fillet)"),
    25: (None, "improved: 52 mm2 p90 0.66 left (window outline M02a + jamb cut M03b)"),
    39: (None, "improved: 268 mm2 p90 0.59 left (jamb cut M03a; scan wall 2.3 vs CAD 2.3 under the skin + print noise)"),
    32: ("locating bump on the hip pad (auto add A040); sits in a slot of the outer, which LT-OUT-001 Rev B adds", "fixed"),
    33: ("locating bump on the hip pad (auto add A039), twin of #32", "fixed"),
}
out = []
for ln in gen:
    m = re.match(r"^\| (\d+) \| (missing|extra) \|", ln)
    if not m:
        out.append(ln); continue
    k = int(m.group(1)); c = [x.strip() for x in ln.strip("|").split("|")]
    if c[5].startswith("OPEN") and k in old:
        c[5], c[6] = old[k][5], old[k][6]
    if k in over:
        if over[k][0]:
            c[5] = over[k][0]
        c[6] = over[k][1]
    out.append("| " + " | ".join(c) + " |")
open("work/table_revA_finalM_merged.md", "w", encoding="utf-8").write("\n".join(out))
print(sum("OPEN" in l for l in out), "OPEN rows left")
for l in out:
    if "OPEN" in l: print(l[:200])
