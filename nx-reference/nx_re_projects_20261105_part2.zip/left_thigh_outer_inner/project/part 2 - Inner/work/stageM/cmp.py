import json, sys
def load(t): return json.load(open(f"clusters_{t}.json"))["clusters"]
boxes = {"P3": ((-40, -28), (230, 244), (46, 68)), "B6": ((96, 112), (225, 238), (60, 80)), "B7": ((-34, -20), (225, 238), (60, 80)),
         "rwin": ((92, 115), (133, 193), (36, 75))}
for t in sys.argv[1:]:
    C = load(t)
    tot = {s: (sum(1 for c in C if c["sign"] == s and c["area"] >= 20), round(sum(c["area"] for c in C if c["sign"] == s and c["area"] >= 20))) for s in ("missing", "extra")}
    print(t, "clusters>=20mm2", tot)
    for k, (bx, by, bz) in boxes.items():
        sel = [c for c in C if bx[0] < c["ctr"][0] < bx[1] and by[0] < c["ctr"][1] < by[1] and bz[0] < c["ctr"][2] < bz[1] and c["area"] >= 10]
        print("  ", k, [(c["sign"][0], round(c["area"]), c["p90"], [round(v) for v in c["ctr"]]) for c in sorted(sel, key=lambda c: -c["area"])])
