import sys, numpy as np, trimesh
sys.path.insert(0, ".")
import outer
from fixlib import scan
vo, fo = outer.load_outer()[:2]
vi, fi = scan()
co = trimesh.load(outer.OUTER_CAD_STL)
for name, v in (("outer scan", vo), ("inner scan (lifted)", vi), ("outer CAD verts", np.asarray(co.vertices))):
    for cx in (27.0, 49.0):
        m = (abs(v[:, 0] - cx) < 2.5) & (abs(v[:, 1] - 271.7) < 2.5) & (v[:, 2] > 76) & (v[:, 2] < 90)
        z = v[m, 2]
        print(name, cx, m.sum(), np.round(np.percentile(z, [0, 5, 50, 95, 100]), 2) if m.sum() else "-")
# z-section of the outer scan through the bump at x 27 / 49 (y 266-278), list z-extent of material
for cx in (27.0, 49.0):
    so = trimesh.intersections.mesh_plane(trimesh.Trimesh(vo, fo, process=False), [1, 0, 0], [cx, 0, 0]).reshape(-1, 3)
    m = (so[:, 1] > 266) & (so[:, 1] < 278) & (so[:, 2] > 70) & (so[:, 2] < 92)
    q = so[m]; q = q[np.argsort(q[:, 1])]
    print("outer scan x=", cx, np.round(q[::max(1, len(q)//20), 1:], 2).tolist())
