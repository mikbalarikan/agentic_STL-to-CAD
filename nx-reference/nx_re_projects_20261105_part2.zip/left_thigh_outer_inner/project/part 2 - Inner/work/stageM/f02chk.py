import numpy as np, sys
sys.path.insert(0, ".")
from fixlib import zsec
P = []
for z in np.arange(56, 66, 0.25):
    s = zsec(z, (84, 93, 128.5, 134.5)); P.append(s.mean(1))
P = np.vstack(P); t = P[:, 1]
h, e = np.histogram(t, bins=np.arange(128.5, 134.5, 0.1))
for k in sorted(np.argsort(h)[::-1][:6]): print(round(e[k] + 0.05, 2), h[k])
