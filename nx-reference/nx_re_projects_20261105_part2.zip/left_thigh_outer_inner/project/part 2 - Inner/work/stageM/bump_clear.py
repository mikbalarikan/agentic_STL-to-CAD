"""Clearance of the two hip-pad bumps (A039 / A040) to the LT-OUT-001 Rev B slots, on the STLs.
Samples the inner bump surface below the pad face (Z < 85.2) and takes the distance to the outer mesh, split by the
face direction (side walls -X/+X/-Y/+Y, bottom). Usage: bump_clear.py <inner.stl> <outer.stl>"""
import sys, json
import numpy as np, trimesh, open3d as o3d

inner = trimesh.load(sys.argv[1]); outer = trimesh.load(sys.argv[2])
BUMPS = {"A039": (25.0, 29.0, 269.7, 273.8), "A040": (46.9, 51.0, 269.7, 273.7)}
sc = o3d.t.geometry.RaycastingScene()
sc.add_triangles(o3d.core.Tensor(outer.vertices, o3d.core.float32), o3d.core.Tensor(outer.faces, o3d.core.uint32))
res = {}
for k, (x0, x1, y0, y1) in BUMPS.items():
    c = inner.triangles_center
    m = (c[:, 2] < 85.2) & (c[:, 2] > 78.5) & (c[:, 0] > x0) & (c[:, 0] < x1) & (c[:, 1] > y0) & (c[:, 1] < y1)
    sub = inner.submesh([m.nonzero()[0]], append=True)
    pts, fi = trimesh.sample.sample_surface_even(sub, 4000, radius=0.05)
    n = sub.face_normals[fi]
    d = -sc.compute_signed_distance(o3d.core.Tensor(pts, o3d.core.float32)).numpy()  # positive = inside the outer
    inside = int((d > 1e-3).sum())
    dist = np.abs(d)
    groups = {"-X": n[:, 0] < -0.7, "+X": n[:, 0] > 0.7, "-Y": n[:, 1] < -0.7, "+Y": n[:, 1] > 0.7, "bottom": n[:, 2] < -0.7}
    res[k] = {"points": len(pts), "inside_outer": inside,
              **{g: round(float(dist[m].min()), 3) if m.any() else None for g, m in groups.items()}}
print(json.dumps(res, indent=1))
