import sys
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
r = STEPControl_Reader(); r.ReadFile(sys.argv[1]); r.TransferRoots(); s = r.OneShape()
e = TopExp_Explorer(s, TopAbs_FACE); n = 0; bad = 0
types = {}
while e.More():
    f = TopoDS.Face_s(e.Current()); n += 1
    t = str(BRepAdaptor_Surface(f).GetType()).split(".")[-1]
    ok = BRepCheck_Analyzer(f).IsValid()
    b = Bnd_Box(); BRepBndLib.Add_s(f, b); x0, y0, z0, x1, y1, z1 = b.Get()
    if t == "GeomAbs_SurfaceOfExtrusion" or not ok:
        g = GProp_GProps(); BRepGProp.SurfaceProperties_s(f, g)
        print(n, t, "valid" if ok else "INVALID", "area %.1f" % g.Mass(), "bbox", [round(v, 1) for v in (x0, y0, z0, x1, y1, z1)])
        bad += not ok
    e.Next()
print("faces", n, "invalid", bad)
