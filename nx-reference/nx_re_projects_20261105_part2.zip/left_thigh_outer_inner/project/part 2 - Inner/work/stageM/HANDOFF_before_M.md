# LT-INN-001 review fix (2026-10-29) - hand-off

Task (from the lead session): fix the CAD errors the user found in the NX overlay (u1 knee fin, u2 knee tail, u3
channel / posts / pads / floor, screenshots in `review_user_2026-10-29\`) plus everything a systematic two-way sweep
finds; then regenerate the whole package. It stays Rev A (nothing sent). Never stop NX processes that are not yours
(the Chest session runs NX too). One output folder per NX run. Venv `C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe`,
NX via `C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1` (run in the background, 30-40 min per stage).

## Done

1. Sweep + diagnosis tools in `an/`: `i90_clusters.py` (two-way signed clusters, full-res scan, thr 0.3),
   `i91_crops.py` (overlay crops; `CROP_SPLIT=1` = CAD | scan | overlay; `views:<json>` mode), `i92_secs.py`
   (scan vs CAD sections), `i93_depth.py` / `i93top.py` (open-side / top-side height maps), `i94_zoom.py`,
   `i98_showfix.py`, `fixlib.py` (fix specs -> manifold meshes, hf_tool), `i99_autofix.py` (plane fixes),
   `i97_sim.py` (mesh simulation of a fix list on a CAD STL), `i97_nxprep.py` (-> `nx/fixes_L.json`),
   `i100_table.py` (before / after cluster table).
2. NX stage L in `nx/build_inner.py` (STAGES ...KL). Run `nx/runL11` (resumed from `nx/runK10/Left_Thigh_Inner.prt`):
   PASS, one solid INNER 341 728 mm3, body_ok, 0 failed tools; STL `nx/runL11/inner_Z.stl`.
   Whole part p50 0.048 / p95 0.78 / 91.3 % within 0.5 (Rev A 0.051 / 1.19 / 87.5 %). Exactly the mesh sim5.
3. STATUS.md section "Review fix 2026-10-29" with causes, numbers and the before/after cluster table.
4. Fresh overlay crops of the user's spots before | after: `work/verify/user_spots_before_after.png` - all fixed.

## Next steps (in order)

A. Optional stage M for the two remaining real items (else document them in README / STATUS as known):
   - P3 lug gusset (Rev A cluster #22, (-34, 238, 57), p90 5): a ~2.3 mm rib like F02/F03 but in a vertical plane along
     (0.664, -0.747) through (-33.5, 238.75); scan z-sections at Z 56 / 62 show it (`work/diag/p3.png`). Needs a
     rotated prism (profile in the rib plane, extruded along its normal +-1.15).
   - Right side window jambs (clusters #25, #39; X 100-110, Y 140-186, Z 36-70): scan wall around the window is 2.3 mm,
     CAD inner face 1.4-2 mm proud (the cavity loft bridged the opening; `work/diag/rwin.png`). Idea: thicken the
     ENVELOPE skin face inward 2.3 mm, cut (box X>96, Y 137-188, Z 37.5-72) minus that shell.
   - Small: B6/B7 buttresses start at Y 229 but the scan buttress blends into the wall near Y 233-235 (forked end in
     the crops); F10/F11 s0 could be 233.
B. Finalize: `nx/finalize_inner.py nx/runL11/Left_Thigh_Inner.prt deliver/CAD` (or the stage-M part), then
   `an/stepcheck.py` on both STEP files.
C. Fit check: `an/i50_fit.py deliver/CAD/..._AP214.step <outer AP214> work/fit_L.json deliver/CAD/...stl`
   (must stay 0.0 mm3 interference, 21 concentric pairs). The pin holes now run to Z 60.45 / 60.30 / 63.55.
D. Deviation report + maps: `an/i40_dev.py deliver/CAD/LT-INN-001_Left_Thigh_Inner.stl final2` (with maps), copy the 7
   maps to `deliver/Deviation Report/deviation_map_*.png`, `an/i70_report.py deliver/CAD final2 work/fit_L.json
   "deliver/Deviation Report/REPORT_deviation.md"`.
E. NX overlay for the user: `nx/overlay.py deliver/CAD/LT-INN-001_Left_Thigh_Inner.prt
   Deviation_Check/LT-INN-001_Left_Thigh_Inner_vs_SCAN.prt work/overlay/scan_in_part_frame.stl work/overlay/probe_pts.json`.
F. Renders: `an/i60_renders.py deliver/CAD/LT-INN-001_Left_Thigh_Inner.stl deliver/Renders`.
G. Drawings: `an/s31_outline.py <stl>` then `nx/dwg_inner.py deliver/CAD/LT-INN-001_Left_Thigh_Inner.prt <out> full`;
   read back the 15 dimensions, check SH4 location tables (pin-hole depth note, knee-ring chamfer), rasterise every
   sheet and check text-over-geometry (drawing rules in memory note drawing-style-rules.md). Copy to deliver/Drawings.
H. README (`deliver/README.md`): volume 341 728 mm3 / mass, deviation table, item 5 (pin holes now Ø4 through the lug to
   0.4 mm under the outer skin, as scanned; knee-ring holes with 0.6 x 45 chamfer), item 9 (cove now modelled; only the
   side-wall thickening next to the hip plate remains), plus any item A not done. Then `an/i80_package.py` (zip) and
   `CLIENT_MESSAGE.txt` (skin median number). Update STATUS.md (remove IN PROGRESS) and this file.
