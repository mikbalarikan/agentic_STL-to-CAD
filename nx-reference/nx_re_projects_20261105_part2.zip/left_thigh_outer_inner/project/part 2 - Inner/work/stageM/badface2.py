import sys
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepCheck import BRepCheck_Analyzer, BRepCheck_ListOfStatus
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE, TopAbs_EDGE
from OCP.TopoDS import TopoDS
from OCP.ShapeFix import ShapeFix_Shape
from OCP.BRep import BRep_Tool
r = STEPControl_Reader(); r.ReadFile(sys.argv[1]); r.TransferRoots(); s = r.OneShape()
e = TopExp_Explorer(s, TopAbs_FACE); k = 0
while e.More():
    k += 1
    f = TopoDS.Face_s(e.Current())
    if k == int(sys.argv[2]):
        a = BRepCheck_Analyzer(f, True)
        res = a.Result(f)
        for st in res.Status(): print("face status", st)
        ee = TopExp_Explorer(f, TopAbs_EDGE)
        while ee.More():
            ed = TopoDS.Edge_s(ee.Current())
            ra = a.Result(ed)
            if ra is not None:
                res.InitContextual(f) if False else None
            print("edge tol", BRep_Tool.Tolerance_s(ed))
            ee.Next()
        print("face tol", BRep_Tool.Tolerance_s(f))
    e.Next()
fx = ShapeFix_Shape(s); fx.Perform(); s2 = fx.Shape()
print("whole valid before", BRepCheck_Analyzer(s).IsValid(), "after ShapeFix", BRepCheck_Analyzer(s2).IsValid())
