# -*- coding: utf-8 -*-
"""Faces of the named design features of LT-INN-001 Rev E (groups R1..R8, FIT_REVE, B6_WEB) that survive in the solid:
type, plane normal / offset, cylinder axis / radius, bbox. args: <model.prt> <out.json>"""
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import nxh  # noqa: E402

MODEL, OUT = sys.argv[1], sys.argv[2]
res = {"result": "FAIL", "feats": {}}
try:
    prt = nxh.open_part(MODEL)
    body = [b for b in prt.Bodies if b.IsSolidBody and not b.IsBlanked][0]
    live = set(f.Tag for f in body.GetFaces())
    for f in prt.Features:
        nm = f.Name
        if not nm or isinstance(f, NXOpen.Features.FeatureGroup):
            continue
        ft = f.FeatureType
        if ft in ("DATUM_PLANE", "DATUM_AXIS", "SKETCH", "DATUM_CSYS"):
            continue
        try:
            fs = [x for x in f.GetFaces() if x.Tag in live]
        except Exception:  # noqa: BLE001
            continue
        if not fs:
            continue
        rows = []
        for x in fs:
            t, pt, d, _bx, rad, _rd, nd = nxh.UFS.Modeling.AskFaceData(x.Tag)
            bb = [round(v, 3) for v in nxh.UFS.ModlGeneral.AskBoundingBox(x.Tag)]
            r = {"t": t, "bb": bb}
            if t == 22:
                r["n"] = [round(v, 5) for v in d]
                r["d"] = round(sum(pt[i] * d[i] for i in range(3)), 4)
            elif t == 16:
                r["pt"] = [round(v, 3) for v in pt]
                r["dir"] = [round(v, 5) for v in d]
                r["r"] = round(abs(rad), 4)
                r["nd"] = nd
            rows.append(r)
        res["feats"]["%s|%s|%s" % (nm, ft, f.GetFeatureName())] = rows
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
