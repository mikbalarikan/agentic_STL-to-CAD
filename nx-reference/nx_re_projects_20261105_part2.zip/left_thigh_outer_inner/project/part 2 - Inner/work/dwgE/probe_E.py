# -*- coding: utf-8 -*-
"""Probe the LT-INN-001 Rev E model (work copy): every cylinder / plane / cone face of the solid, feature groups and
their members, bounding box, optional volume. args: <model.prt> <out.json> [vol]"""
import json
import os
import sys
import time
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import nxh  # noqa: E402

MODEL, OUT = sys.argv[1], sys.argv[2]
VOL = len(sys.argv) > 3 and sys.argv[3] == "vol"
res = {"result": "FAIL"}
t0 = time.time()
try:
    prt = nxh.open_part(MODEL)
    sol = [b for b in prt.Bodies if b.IsSolidBody and not b.IsBlanked]
    res["solids"] = [[b.Name, len(b.GetFaces())] for b in sol]
    cyl, pl, other = [], [], {}
    for b in sol:
        for f in b.GetFaces():
            t, pt, d, _bx, rad, _rd, nd = nxh.UFS.Modeling.AskFaceData(f.Tag)
            bb = [round(v, 4) for v in nxh.UFS.ModlGeneral.AskBoundingBox(f.Tag)]
            if t == 16:
                cyl.append({"r": round(abs(rad), 4), "pt": [round(v, 4) for v in pt], "dir": [round(v, 6) for v in d], "bb": bb, "nd": nd})
            elif t == 22:
                pl.append({"n": [round(v, 6) for v in d], "d": round(sum(pt[i] * d[i] for i in range(3)), 4), "bb": bb})
            else:
                other.setdefault(str(t), []).append({"pt": [round(v, 3) for v in pt], "dir": [round(v, 4) for v in d], "r": round(rad, 3), "bb": bb})
    res["cyl"], res["pl"], res["other"] = cyl, pl, other
    groups = {}
    for f in prt.Features:
        if isinstance(f, NXOpen.Features.FeatureGroup) or "Group" in f.FeatureType:
            try:
                mem = f.GetAllMembers() if hasattr(f, "GetAllMembers") else f.GetMembers()
                groups[f.Name or f.GetFeatureName()] = [m.GetFeatureName() + ((" [" + m.Name + "]") if m.Name else "") for m in mem]
            except Exception as e:  # noqa: BLE001
                groups[f.Name or f.GetFeatureName()] = str(e)
    res["groups"] = groups
    res["n_features"] = len(list(prt.Features))
    res["bbox"] = [round(v, 4) for v in nxh.bbox(sol[0])] if sol else None
    res["attrs"] = {}
    for a in ("REVISION", "MATERIAL", "DESCRIPTION"):
        try:
            res["attrs"][a] = prt.GetUserAttributeAsString(a, NXOpen.NXObject.AttributeType.String, -1)
        except Exception:  # noqa: BLE001
            pass
    res["t_faces"] = round(time.time() - t0, 1)
    nxh.write_json(OUT, res)
    if VOL:
        m = nxh.mass(prt, sol)
        res["volume"] = m["volume"]
        res["centroid"] = m["centroid"]
        res["t_vol"] = round(time.time() - t0, 1)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
