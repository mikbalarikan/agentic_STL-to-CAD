Clusters >= 20 mm2 (|signed deviation| > 0.3 mm, full-resolution scan, both directions):
before (revA): missing (78, 33399), extra (66, 9483) (count, mm2); after (L11): missing (86, 29476), extra (80, 7296).

| # | sign | area mm2 | p90 mm | centre X, Y, Z | cause | after the fix |
|---|---|---|---|---|---|---|
| 0 | extra | 2540 | 9.55 | 65, -46, 57 | F01 knee-end tail/fin (u1, u2): stage-A skin loft ran past the leg's end face; cut t; F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa | fixed |
| 1 | missing | 3171 | 6.34 | 37, 214, 98 | missing rib extension x 36-40, Y 162-204 (auto fix) + R5-6 root fillets along the rib | rib fixed; fillets kept |
| 2 | missing | 3990 | 3.17 | 35, 120, 80 | u3 red: false 7 x 3 mm groove + 4-5 mm slot along the channel rail (F04 F05 F12 F13); rest = rail root fillets | fixed; fillets kept |
| 3 | missing | 1021 | 8.17 | 101, 246, 65 | F09 B6 web under the hip boss, t 4.3, bottom edge Z 43.0 at Y 249.7 rising 54 deg to | improved (46 % of points still off) |
| 4 | missing | 975 | 8.54 | -24, 246, 66 | F08 B7 web under the hip boss, t 4.3, bottom edge Z 43.0 at Y 249.7 rising 54 deg to; F10 B7 buttress beside the web, crowned top Z 70.6 (scan section mean Y 238-256) | fixed |
| 5 | missing | 3474 | 1.52 | 11, -23, 78 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 6 | missing | 2747 | 1.54 | 8, 18, 78 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 7 | missing | 891 | 3.92 | -22, 264, 67 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 8 | missing | 807 | 3.02 | 65, 49, 62 | R4-6 root fillet in the B2 side-wall corner | kept (fillet) |
| 9 | missing | 1478 | 1.57 | -29, 50, 77 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 10 | missing | 1054 | 1.92 | 1, -0, 85 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub | fixed |
| 11 | missing | 596 | 3.36 | 49, 45, 78 | F04 channel rail plateau Z 76.94 (u3 red): Rev A had a 7 mm wide, 3 mm deep false gr; auto add | improved (57 % of points still off) |
| 12 | missing | 496 | 3.81 | 99, 264, 54 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 13 | missing | 900 | 2.09 | 79, 262, 82 | root fillets at the hip-end rib junction | kept (fillet) |
| 14 | extra | 472 | 3.89 | 66, -31, 52 | F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa; F15 knee-end cavity end: Rev A cavity stopped flat at Y -29.0, scan end wall curves  | improved (55 % of points still off) |
| 15 | missing | 691 | 2.40 | 86, 166, 53 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 16 | missing | 906 | 1.81 | -3, 262, 86 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 17 | missing | 1952 | 0.84 | 15, -62, 53 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 18 | missing | 298 | 4.91 | -19, 182, 63 | root fillet, rib-to-wall junction near B4 | kept (fillet) |
| 19 | missing | 310 | 4.47 | 88, 131, 67 | F02 P1 pin-lug gusset rib t 2.3 (u3 'left post'): edge from the lug at Z 50 up the w | improved (73 % of points still off) |
| 20 | missing | 280 | 4.23 | 100, 194, 66 | F03 P2 pin-lug gusset rib t 2.3 (u3 'C-shaped feature') | improved (73 % of points still off) |
| 21 | extra | 1576 | 0.69 | 17, -58, 45 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 22 | missing | 202 | 5.02 | -34, 238, 57 | P3 lug gusset rib t ~2.3 (like F02/F03, plane ~48 deg in XY) - missing | OPEN (next step) |
| 23 | missing | 302 | 3.21 | 62, -41, 49 | F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa | improved (100 % of points still off) |
| 24 | missing | 810 | 1.16 | 32, 272, 86 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 25 | extra | 375 | 2.35 | 106, 182, 55 | right side window: scan wall 2.3 thick round the window, CAD inner face 1.4-2 mm proud (cavity loft bridged the opening) | OPEN (next step) |
| 26 | missing | 232 | 3.74 | -28, 78, 56 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 27 | missing | 237 | 3.43 | 76, 27, 54 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 28 | missing | 677 | 1.09 | 16, -62, 38 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 29 | missing | 385 | 1.86 | 92, 165, 73 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 30 | missing | 621 | 0.82 | -54, 41, 50 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 31 | missing | 291 | 1.66 | -27, 274, 67 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 32 | missing | 81 | 5.83 | 49, 272, 82 | auto add | fixed |
| 33 | missing | 78 | 5.80 | 27, 272, 82 | OPEN - not explained | gone |
| 34 | missing | 274 | 1.51 | -45, 52, 48 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 35 | extra | 133 | 2.81 | 11, 242, 101 | small extra on the hip-end roof (11, 242, 101), not diagnosed | open (small) |
| 36 | missing | 184 | 1.94 | -43, 265, 39 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 37 | missing | 107 | 3.25 | -20, 164, 54 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 38 | extra | 83 | 4.14 | -26, 268, 69 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 39 | extra | 306 | 1.12 | 101, 148, 54 | right side window, same as #25 | OPEN (next step) |
| 40 | missing | 54 | 5.96 | -31, -51, 59 | F16a knee-floor post Ø3.36 to Z 56.85 (missing in Rev A) | improved (51 % of points still off) |
| 41 | missing | 111 | 2.73 | 55, 76, 78 | F04 channel rail plateau Z 76.94 (u3 red): Rev A had a 7 mm wide, 3 mm deep false gr | improved (78 % of points still off) |
| 42 | extra | 107 | 2.83 | -28, 74, 53 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 43 | extra | 97 | 3.06 | -19, 164, 52 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 44 | extra | 102 | 2.84 | 59, -42, 48 | F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa | improved (80 % of points still off) |
| 45 | extra | 182 | 1.59 | -28, -60, 47 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 46 | missing | 50 | 5.73 | -57, 19, 59 | F16b knee-floor post Ø3.29 to Z 56.72 (missing in Rev A) | improved (52 % of points still off) |
| 47 | missing | 70 | 3.74 | -38, 245, 44 | F17c pin hole Ø4.0 continued to Z 63.55 (scan: open to 0.4 mm under the outer skin; R | improved (100 % of points still off) |
| 48 | missing | 195 | 1.29 | -17, 53, 56 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 49 | missing | 193 | 1.30 | 102, 274, 65 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 50 | extra | 59 | 4.06 | 103, 266, 65 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 51 | extra | 95 | 2.49 | 91, 165, 71 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 52 | missing | 68 | 3.29 | 97, 131, 43 | F17a pin hole Ø4.0 continued to Z 60.45 (scan: open to 0.4 mm under the outer skin; R | improved (100 % of points still off) |
| 53 | extra | 336 | 0.65 | -29, 206, 58 | print / scan noise | kept (by rule) |
| 54 | missing | 67 | 3.24 | 109, 194, 43 | F17b pin hole Ø4.0 continued to Z 60.3 (scan: open to 0.4 mm under the outer skin; Re | improved (100 % of points still off) |
| 55 | missing | 81 | 2.51 | 98, 262, 82 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 56 | missing | 149 | 1.35 | -3, 78, 51 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 57 | extra | 331 | 0.60 | -46, 45, 50 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 58 | extra | 60 | 3.22 | 96, 260, 67 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 59 | extra | 283 | 0.62 | 83, 90, 61 | print / scan noise | kept (by rule) |
| 60 | extra | 181 | 0.84 | 56, -46, 48 | F01 knee-end tail/fin (u1, u2): stage-A skin loft ran past the leg's end face; cut t; F14 knee-end wall top: Rev A B1 column / envelope stood up to Z 88; scan wall top fa | improved (56 % of points still off) |
| 61 | missing | 109 | 1.24 | -51, 25, 50 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 62 | extra | 35 | 3.76 | 94, 268, 53 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 63 | extra | 33 | 3.92 | 11, -11, 87 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07d knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 64 | extra | 174 | 0.73 | -41, 257, 55 | print / scan noise | kept (by rule) |
| 65 | extra | 42 | 3.01 | 10, 11, 86 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07a knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 66 | extra | 44 | 2.80 | -11, 11, 85 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07b knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 67 | missing | 36 | 3.27 | 86, 164, 84 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 68 | extra | 41 | 2.79 | 100, 254, 60 | edge of the new B6 web / buttress (outline simplified) | small, kept |
| 69 | missing | 99 | 1.14 | -17, 157, 56 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 70 | extra | 34 | 3.22 | -21, 263, 43 | B7 column bottom near the pocket (scan gap / pocket edge) | small, kept |
| 71 | extra | 32 | 3.36 | -19, 268, 47 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 72 | extra | 35 | 2.96 | -24, 254, 65 | F10 B7 buttress beside the web, crowned top Z 70.6 (scan section mean Y 238-256) | improved (100 % of points still off) |
| 73 | missing | 85 | 1.10 | 77, 21, 59 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 74 | extra | 41 | 2.30 | 81, 30, 51 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 75 | missing | 176 | 0.53 | 1, -4, 77 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 76 | extra | 40 | 2.24 | -38, 242, 41 | F17c pin hole Ø4.0 continued to Z 63.55 (scan: open to 0.4 mm under the outer skin; R | improved (100 % of points still off) |
| 77 | extra | 29 | 2.96 | -17, 267, 64 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 78 | extra | 24 | 3.59 | -10, -11, 88 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07c knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (88 % of points still off) |
| 79 | missing | 31 | 2.66 | -10, 11, 82 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub; F07b knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 80 | extra | 50 | 1.60 | 65, 243, 97 | small extra on the hip-end roof | small, kept |
| 81 | extra | 37 | 2.17 | 85, 162, 59 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 82 | extra | 38 | 2.10 | 53, 94, 77 | F04 channel rail plateau Z 76.94 (u3 red): Rev A had a 7 mm wide, 3 mm deep false gr | improved (98 % of points still off) |
| 83 | missing | 32 | 2.37 | 11, 10, 81 | F07a knee-ring hole top chamfer 0.6 x 45 deg (scan Ø4.5 at the ring face) | improved (100 % of points still off) |
| 84 | missing | 147 | 0.52 | 6, -18, 77 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 85 | extra | 89 | 0.84 | -51, 41, 37 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 86 | extra | 33 | 2.22 | 75, 25, 62 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 87 | extra | 32 | 2.07 | 61, 132, 82 | small extra, channel bar end | small, kept |
| 88 | extra | 49 | 1.37 | -18, 64, 83 | small extra near B3 rib top | small, kept |
| 90 | extra | 23 | 2.71 | 98, 131, 41 | F17a pin hole Ø4.0 continued to Z 60.45 (scan: open to 0.4 mm under the outer skin; R | improved (100 % of points still off) |
| 91 | extra | 24 | 2.68 | 98, 262, 43 | B6 column bottom near the pocket (scan gap / pocket edge) | small, kept |
| 92 | extra | 26 | 2.45 | 109, 193, 40 | F17b pin hole Ø4.0 continued to Z 60.3 (scan: open to 0.4 mm under the outer skin; Re | improved (100 % of points still off) |
| 93 | extra | 20 | 3.08 | -24, 252, 58 | edge of the new B7 web / buttress (outline simplified) | small, kept |
| 94 | extra | 28 | 2.16 | -22, 81, 52 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 96 | extra | 21 | 2.76 | 97, 270, 47 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 97 | missing | 100 | 0.57 | -53, 37, 69 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 98 | extra | 112 | 0.48 | 65, 252, 83 | print / scan noise | kept (by rule) |
| 99 | extra | 52 | 1.02 | 12, 259, 76 | auto cut | fixed |
| 100 | extra | 25 | 2.05 | 82, 164, 70 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 101 | missing | 104 | 0.49 | 84, 101, 69 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 102 | extra | 24 | 2.13 | 72, 33, 51 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 104 | missing | 69 | 0.71 | 72, 59, 73 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 105 | extra | 76 | 0.64 | 109, 237, 69 | print / scan noise | kept (by rule) |
| 107 | missing | 60 | 0.79 | -44, 249, 37 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 108 | missing | 29 | 1.64 | 59, 63, 79 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 109 | extra | 64 | 0.73 | 67, -3, 83 | print / scan noise | kept (by rule) |
| 110 | extra | 24 | 1.94 | -36, 249, 57 | edge of the new B7 buttress | small, kept |
| 111 | missing | 84 | 0.54 | 116, 261, 52 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 114 | missing | 41 | 1.06 | 118, 264, 38 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 116 | extra | 77 | 0.52 | -60, 28, 50 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 118 | missing | 41 | 0.98 | -17, 257, 87 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 119 | missing | 31 | 1.27 | 76, 33, 46 | scan gap: bore / counterbore interior not scanned (CAD hole per design) | kept (by rule) |
| 120 | missing | 22 | 1.78 | 98, 262, 40 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 121 | extra | 64 | 0.60 | 99, 190, 75 | print / scan noise | kept (by rule) |
| 124 | extra | 51 | 0.70 | 46, 268, 107 | print / scan noise | kept (by rule) |
| 125 | extra | 83 | 0.43 | 11, 250, 85 | print / scan noise | kept (by rule) |
| 127 | missing | 51 | 0.57 | 85, 25, 38 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 129 | missing | 52 | 0.55 | 106, 217, 70 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 131 | extra | 62 | 0.44 | 113, 258, 57 | print / scan noise | kept (by rule) |
| 133 | extra | 43 | 0.60 | -32, 64, 72 | print / scan noise | kept (by rule) |
| 136 | extra | 42 | 0.57 | 104, 198, 68 | print / scan noise | kept (by rule) |
| 137 | missing | 45 | 0.52 | -18, 35, 77 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 138 | extra | 51 | 0.46 | 68, 64, 73 | auto cut | fixed |
| 139 | extra | 43 | 0.54 | 102, 174, 65 | auto cut | improved (100 % of points still off) |
| 140 | extra | 51 | 0.45 | -3, 256, 101 | print / scan noise | kept (by rule) |
| 143 | missing | 35 | 0.59 | 99, 181, 73 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 144 | extra | 45 | 0.46 | -11, 3, 93 | F06 knee-ring cove (Rev A README item 9, the stage-A revolve came out as a 2 mm3 sub | fixed |
| 145 | missing | 33 | 0.61 | -17, 166, 40 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 146 | missing | 42 | 0.48 | 92, 144, 74 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 148 | missing | 23 | 0.82 | 62, 246, 101 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 149 | missing | 24 | 0.79 | 62, 253, 101 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 153 | missing | 26 | 0.68 | 109, 189, 50 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 154 | missing | 35 | 0.50 | -41, 263, 59 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 156 | missing | 26 | 0.65 | -32, 70, 52 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 157 | missing | 21 | 0.79 | 93, 258, 82 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 158 | missing | 27 | 0.60 | 114, 251, 62 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 160 | missing | 40 | 0.39 | -6, 256, 103 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 161 | missing | 21 | 0.72 | -32, 60, 70 | shared design value: knee hub straight Ø135.70 (scan 1.4 deg draft), kept for LT-OUT-001 | kept (by rule) |
| 166 | extra | 21 | 0.69 | 82, 268, 94 | print / scan noise | kept (by rule) |
| 169 | missing | 23 | 0.60 | 66, 40, 74 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 170 | missing | 23 | 0.60 | -25, 89, 50 | root fillet / edge round (not modelled, as on LT-OUT-001) | kept (by rule) |
| 173 | extra | 27 | 0.48 | 113, 202, 40 | print / scan noise | kept (by rule) |
| 178 | extra | 33 | 0.35 | -46, 48, 80 | print / scan noise | kept (by rule) |
| 179 | extra | 21 | 0.54 | 78, -23, 40 | F01 knee-end tail/fin (u1, u2): stage-A skin loft ran past the leg's end face; cut t | fixed |
