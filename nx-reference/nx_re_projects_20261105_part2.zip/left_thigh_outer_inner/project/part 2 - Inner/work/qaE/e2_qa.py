"""Rev E QA numbers for LT-INN-001: same scan, frame (+seat_dz 0.12), zones, 1.5 M samples, seed 7 as an/i40_dev.py.
Scan->CAD and CAD->scan for Rev A, Rev B, Rev E (before fit fixes) and Rev E (final), within 0.25 / 0.5 / 1.0,
per-region stats for the fit-fix regions, and the largest |d| > 1 mm clusters of Rev E outside those regions.
usage: e2_qa.py out.json"""
import sys, os, json
import numpy as np
import open3d as o3d
AN = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\an"
sys.path.insert(0, AN)
os.chdir(AN)
from common import W, load
from i20lib import evalr

R2 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
STL = {
    "revA": R2 + r"\LT-INN-001_RevA_Left_Thigh_Inner\LT-INN-001_RevA\CAD\LT-INN-001_Left_Thigh_Inner.stl",
    "revB": R2 + r"\LT-INN-001_RevB_Left_Thigh_Inner\LT-INN-001_RevB\CAD\LT-INN-001_Left_Thigh_Inner.stl",
    "revE0": R2 + r"\deliver_RevE\CAD\LT-INN-001_Left_Thigh_Inner.stl",
    "revE": R2 + r"\deliver_RevE_fit\CAD\LT-INN-001_Left_Thigh_Inner.stl",
}
OUT = sys.argv[1]
N = 1500000

# fit-fix regions (model frame boxes, lo / hi), from the assembly fit-fix zones K1-K22
REG = {
    "B6 boss: bottom face to Z 36.07 + new D10.4 / D6 web": [((78.5, 158.0, 30.0), (94.5, 174.0, 46.0))],
    "-X joint wall: rebate floor 36.19 / 36.23, step +0.2": [((-61.0, 27.5, 34.9), (-20.0, 181.0, 37.5))],
    "+X joint wall: rebate floor 36.19, B5 face 36.07": [((73.0, -30.0, 34.9), (84.0, 53.5, 37.5))],
    "B4 pad to Z 36.07 + D10.4 pocket": [((50.0, -51.0, 34.9), (73.0, -31.5, 40.0))],
    "-X hip corner: floor Z 36.36, P1 recess D9.4": [((-43.0, 240.5, 34.9), (-29.0, 287.5, 37.5))],
    "Hip seat flat to Z 85.28": [((20.5, 266.3, 83.5), (55.5, 269.7, 86.0))],
    "B2 boss face to Z 36.24": [((-30.0, 257.0, 34.9), (-14.0, 273.0, 37.0))],
    "Hip rib ends to Y 266.3": [((8.5, 265.8, 35.0), (13.5, 267.5, 112.0)), ((62.5, 265.8, 35.0), (67.5, 267.5, 112.0))],
    "+X hip corner step": [((110.0, 266.3, 34.9), (114.6, 277.0, 37.5))],
}


def inbox(P, boxes):
    m = np.zeros(len(P), bool)
    for lo, hi in boxes:
        m |= np.all((P > np.array(lo)) & (P < np.array(hi)), 1)
    return m


def st(x):
    ax = np.abs(x)
    if len(x) == 0:
        return {}
    return dict(n=int(len(x)), mean=round(float(x.mean()), 4), rms=round(float(np.sqrt((x ** 2).mean())), 4),
                p50=round(float(np.percentile(ax, 50)), 4), p90=round(float(np.percentile(ax, 90)), 4),
                p95=round(float(np.percentile(ax, 95)), 4), p99=round(float(np.percentile(ax, 99)), 4),
                w025=round(float((ax <= 0.25).mean()), 4), w05=round(float((ax <= 0.5).mean()), 4),
                w10=round(float((ax <= 1.0).mean()), 4), over_1=round(float((ax > 1).mean()), 4))


def stl_bounds(p):
    with open(p, "rb") as fh:
        fh.read(80); n = int(np.frombuffer(fh.read(4), "<u4")[0])
        rec = np.frombuffer(fh.read(50 * n), np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]))
    v = rec["v"].reshape(-1, 3).astype(np.float64)
    return [round(float(x), 2) for x in list(v.min(0)) + list(v.max(0))], int(n)


v, f = load()
DZ = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))["seat_dz"]
v = v.copy(); v[:, 2] += DZ
rng = np.random.default_rng(7)
idx = rng.choice(len(v), min(N, len(v)), replace=False)
P = v[idx].astype(np.float32)
s = np.load(W + r"\skin_fit.npz"); pc, ZC = s["pc"], float(s["ZC"])
xc = np.polyval(pc, P[:, 1].astype(float))
th = np.arctan2(P[:, 2] - DZ - ZC, P[:, 0] - xc); rr = np.hypot(P[:, 0] - xc, P[:, 2] - DZ - ZC)
okth = (th > np.radians(-4)) & (th < np.radians(184))
rs = np.full(len(P), np.nan)
rs[okth] = evalr(s["ty"], s["tt"], s["C"], P[okth, 1].astype(float), th[okth])
de = np.abs(rr - rs)
knee = np.hypot(P[:, 0], P[:, 1]) < 70
hip = P[:, 1] > 262
outer = (~knee) & (~hip) & (de < 1.0)
inner = (~knee) & (~hip) & ~outer
sm = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
ss = o3d.t.geometry.RaycastingScene(); ss.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(sm))
Vf = v.astype(np.float32)
allreg = np.zeros(len(Vf), bool)
for b in REG.values():
    allreg |= inbox(Vf, b)

out = {"scan_vertices": int(len(v)), "scan_triangles": int(len(f)), "seat_dz": DZ,
       "zones_n": {"all": int(len(P)), "outer_skin": int(outer.sum()), "knee_hub": int(knee.sum()), "hip_end": int(hip.sum()), "interior": int(inner.sum())},
       "regions": {k: {"boxes": [[list(map(float, lo)), list(map(float, hi))] for lo, hi in b]} for k, b in REG.items()}}
for tag, path in STL.items():
    cm = o3d.io.read_triangle_mesh(path); cm.remove_duplicated_vertices()
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
    d = sc.compute_signed_distance(o3d.core.Tensor(P)).numpy()
    bb, ntri = stl_bounds(path)
    out[tag] = {"stl": path, "bbox": bb, "triangles": ntri,
                "scan_to_cad": {"all": st(d), "outer_skin": st(d[outer]), "knee_hub": st(d[knee]), "hip_end": st(d[hip]), "interior": st(d[inner])}}
    o3d.utility.random.seed(7)
    Q = np.asarray(cm.sample_points_uniformly(600000).points, dtype=np.float32)
    dq = ss.compute_distance(o3d.core.Tensor(Q)).numpy()
    out[tag]["cad_to_scan"] = st(dq)
    out[tag]["mesh_volume"] = round(float(cm.get_volume()), 1) if cm.is_watertight() else None
    for k, boxes in REG.items():
        R = Vf[inbox(Vf, boxes)]
        dr = sc.compute_signed_distance(o3d.core.Tensor(R)).numpy()
        out["regions"][k]["n"] = int(len(R))
        out["regions"][k][tag] = st(dr)
    # sample stats outside all fit-fix boxes
    outside = ~inbox(P, [bx for b in REG.values() for bx in b])
    out[tag]["outside_fix_regions"] = st(d[outside])
    if tag == "revE":
        # clusters of |d| > 1 mm outside the fit-fix regions, 5 mm voxels, connected components
        big = outside & (np.abs(d) > 1.0)
        Pb = P[big]; db = d[big]
        key = np.floor(Pb / 5.0).astype(np.int64)
        uk, inv, cnt = np.unique(key, axis=0, return_inverse=True, return_counts=True)
        inv = inv.ravel()
        # connected components of occupied voxels (26-neighbour)
        lut = {tuple(k): i for i, k in enumerate(uk)}
        par = list(range(len(uk)))
        def fnd(a):
            while par[a] != a:
                par[a] = par[par[a]]; a = par[a]
            return a
        offs = [(i, j, k) for i in (-1, 0, 1) for j in (-1, 0, 1) for k in (-1, 0, 1) if (i, j, k) != (0, 0, 0)]
        for i, k in enumerate(uk):
            for o in offs:
                j = lut.get((k[0] + o[0], k[1] + o[1], k[2] + o[2]))
                if j is not None:
                    a, b = fnd(i), fnd(j)
                    if a != b:
                        par[a] = b
        lab = np.array([fnd(i) for i in range(len(uk))])[inv]
        cl = []
        for L in np.unique(lab):
            m = lab == L
            if m.sum() < 400:
                continue
            q = Pb[m]; dd = db[m]
            cl.append(dict(n=int(m.sum()), share_of_samples=round(m.sum() / len(P), 5),
                           lo=[round(float(x), 1) for x in q.min(0)], hi=[round(float(x), 1) for x in q.max(0)],
                           centre=[round(float(x), 1) for x in np.median(q, 0)],
                           median_d=round(float(np.median(dd)), 3), frac_pos=round(float((dd > 0).mean()), 3),
                           p90_abs=round(float(np.percentile(np.abs(dd), 90)), 3)))
        cl.sort(key=lambda c: -c["n"])
        out["revE"]["clusters_over_1mm"] = cl[:25]
        out["revE"]["over_1mm_outside_regions_share"] = round(float(big.sum() / len(P)), 4)
    print(tag, json.dumps(out[tag]["scan_to_cad"]["all"]), "c2s p95", out[tag]["cad_to_scan"]["p95"], "bbox", bb, flush=True)
for k, r in out["regions"].items():
    print(f"{k:55s} n={r['n']:7d} " + " | ".join(f"{t} p50 {r[t]['p50']:.3f} w0.5 {100*r[t]['w05']:.1f}" for t in STL if r.get(t)))
json.dump(out, open(OUT, "w"), indent=1)
print("wrote", OUT)
