"""Deviation colour maps scan -> CAD (signed) for LT-INN-001 Rev E on the 600 k framed scan (+seat_dz), banded scale
identical on every view (same bands as the LT-OUT-001 Rev F report).
usage: e4_maps.py cad.stl out_dir [prefix]"""
import sys, os, json
import numpy as np
import open3d as o3d
import pyvista as pv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
W = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\work"

cad, OUT = sys.argv[1], sys.argv[2]
PRE = sys.argv[3] if len(sys.argv) > 3 else "LT-INN-001_deviation_"
os.makedirs(OUT, exist_ok=True)
DZ = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))["seat_dz"]
B = [-1.0, -0.5, -0.2, -0.1, 0.1, 0.2, 0.5, 1.0]
COL = ["#08306b", "#2166ac", "#67a9cf", "#b9dcea", "#3aa357", "#f3dc6b", "#f4a259", "#d6604d", "#7f0000"]
cmap = ListedColormap(COL)
norm = BoundaryNorm([-1e9] + B + [1e9], len(COL))

cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices()
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
m = pv.read(os.path.join(W, "scan_600k_framed.ply"))
m.points = np.asarray(m.points) + np.array([0.0, 0.0, DZ])
d = sc.compute_signed_distance(o3d.core.Tensor(np.asarray(m.points, np.float32))).numpy()
m["rgb"] = (cmap(norm(d))[:, :3] * 255).astype(np.uint8)
c = np.array(m.center)
VIEWS = {  # name: (title, direction focus->camera, up, parallel?, zoom)
    "iso_outside": ("Isometric, outside skin", (0.55, -0.6, 0.75), (0, 0, 1), False, 1.25),
    "iso_open": ("Isometric, open (mating) side", (-0.5, -0.55, -0.7), (0, 0, -1), False, 1.25),
    "top": ("Top (+Z), outside skin", (0, 0, 1), (0, 1, 0), True, 1.15),
    "bottom": ("Bottom (-Z), open side with joint, bosses and ribs", (0, 0, -1), (0, 1, 0), True, 1.15),
    "side_px": ("Side +X", (1, 0, 0), (0, 0, 1), True, 1.1),
    "side_nx": ("Side -X", (-1, 0, 0), (0, 0, 1), True, 1.1),
    "hip_end": ("Hip end", (0.35, 0.75, -0.55), (0, 0, -1), False, 1.2),
}
for name, (title, dv, up, par, zm) in VIEWS.items():
    dv = np.array(dv, float); dv /= np.linalg.norm(dv)
    p = pv.Plotter(off_screen=True, window_size=(1600, 1300))
    p.set_background("white")
    p.add_mesh(m, scalars="rgb", rgb=True, smooth_shading=True, ambient=0.3, diffuse=0.75, specular=0.1)
    p.enable_parallel_projection() if par else None
    dist = 330 if name == "hip_end" else 700
    p.camera_position = [tuple(c + dv * dist), tuple(c), up]
    p.camera.view_angle = 30
    p.reset_camera()
    p.camera.zoom(zm)
    img = p.screenshot(None, return_img=True); p.close()
    nz = np.where((img < 250).any(2))
    y0, y1, x0, x1 = max(nz[0].min() - 30, 0), min(nz[0].max() + 30, img.shape[0]), max(nz[1].min() - 30, 0), min(nz[1].max() + 30, img.shape[1])
    img = img[y0:y1, x0:x1]
    h, w = img.shape[:2]
    fig = plt.figure(figsize=(10, 10 * (h / w) * 0.86 + 1.4), dpi=170)
    ax = fig.add_axes([0.0, 0.14, 0.86, 0.80]); ax.imshow(img); ax.axis("off")
    ax.set_title(f"LT-INN-001 Rev E - scan to CAD deviation - {title}", fontsize=11, loc="left")
    cax = fig.add_axes([0.88, 0.2, 0.025, 0.68])
    smp = plt.cm.ScalarMappable(cmap=cmap, norm=BoundaryNorm([-1.5] + B + [1.5], len(COL)))
    cb = fig.colorbar(smp, cax=cax, boundaries=[-1.5] + B + [1.5], ticks=B, spacing="uniform")
    cb.ax.set_yticklabels([f"{b:+.1f}" if abs(b) >= 0.5 else f"{b:+.2f}" for b in B], fontsize=8)
    cb.set_label("deviation [mm]", fontsize=9)
    fig.text(0.01, 0.06, "Signed distance of the scan surface to the CAD solid. + (warm): scan outside the CAD, CAD has less material.\n"
             "- (cool): scan inside the CAD, CAD has more material. Green band: within +/-0.10 mm. End bands: beyond +/-1.0 mm.",
             fontsize=8, color="#333333")
    fig.savefig(os.path.join(OUT, f"{PRE}{name}.png"), dpi=170, bbox_inches="tight", pad_inches=0.15); plt.close(fig)
    print("wrote", name, img.shape, flush=True)
