import sys
p = sys.argv[1]; t = open(p, encoding="utf-8-sig").read()
t = t.replace("\u00c3\u02dc", "\u00d8").replace("\u00c2\u00b0", "\u00b0").replace("Image, PageBreak)", "Image, PageBreak, KeepTogether)")
open(p, "w", encoding="utf-8").write(t)
print(t.count("\u00d8"), t.count("\u00c3"))
