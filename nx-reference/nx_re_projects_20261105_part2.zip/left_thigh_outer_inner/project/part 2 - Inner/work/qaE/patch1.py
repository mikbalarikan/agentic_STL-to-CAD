p = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\work\qaE\e5_pdf.py"
t = open(p, encoding="utf-8").read()
a = 'pages = [("iso_outside", "iso_open"), ("top", "bottom"), ("side_px", "side_nx", "hip_end")]'
assert a in t
t = t.replace(a, 'pages = [("iso_outside", "iso_open"), ("top",), ("bottom",), ("side_px", "side_nx", "hip_end")]')
b = 'E.append(Paragraph("5. Other differences'
assert b in t and "E.append(PageBreak())\n" + b not in t
t = t.replace(b, "E.append(PageBreak())\n" + b)
open(p, "w", encoding="utf-8").write(t)
print("patched")
