p = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\work\qaE\e5_pdf.py"
t = open(p, encoding="utf-8").read()
s0 = t.index('E.append(Paragraph("7. Summary", H2))')
s1 = t.index('E.append(PageBreak())\nE.append(Paragraph("8. Colour maps"')
summ = t[s0:s1]
t = t[:s0] + t[s1:]
summ = summ.replace('"7. Summary"', '"5. Summary"').replace("listed in section 5.", "listed in section 6.")
k = t.index('E.append(PageBreak())\nE.append(Paragraph("5. Other differences')
t = t[:k] + summ + t[k:]
t = t.replace('"5. Other differences', '"6. Other differences').replace('"6. Documented simplifications', '"7. Documented simplifications')
open(p, "w", encoding="utf-8").write(t)
print("ok")
