"""LT-INN-001 Rev E scan-to-CAD deviation report PDF (reportlab, system Python). Same look as part 1 work/qaF/q5_pdf.py.
usage: e5_pdf.py qa_revE.json diff_BE.json maps_dir out.pdf"""
import sys, os, json
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.lib.utils import ImageReader

QA, DIFF, MAPS, OUT = sys.argv[1:5]
q = json.load(open(QA))
TITLE = "LT-INN-001 Rev E - Scan-to-CAD Deviation Report"
ss = getSampleStyleSheet()
H1 = ParagraphStyle("h1", parent=ss["Title"], fontSize=17, leading=21, alignment=0, spaceAfter=2)
H2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12, leading=15, spaceBefore=8, spaceAfter=4)
B = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9, leading=12)
S = ParagraphStyle("s", parent=B, fontSize=7.8, leading=10, textColor=colors.HexColor("#333333"))
C = ParagraphStyle("c", parent=B, fontSize=7.4, leading=9.0)
HB = ParagraphStyle("hb", parent=C, fontName="Helvetica-Bold", fontSize=7.0, leading=8.4, alignment=1)
GRID = colors.HexColor("#9aa3ad"); HEAD = colors.HexColor("#dde3ea"); ALT = colors.HexColor("#f4f6f8")


def tstyle(nrows):
    st = [("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 7.8), ("FONT", (0, 1), (-1, -1), "Helvetica", 7.8),
          ("BACKGROUND", (0, 0), (-1, 0), HEAD), ("GRID", (0, 0), (-1, -1), 0.4, GRID),
          ("ALIGN", (1, 0), (-1, -1), "CENTER"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("TOPPADDING", (0, 0), (-1, -1), 2.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.2)]
    for r in range(2, nrows, 2):
        st.append(("BACKGROUND", (0, r), (-1, r), ALT))
    return TableStyle(st)


def pct(x):
    return f"{100 * x:.1f} %"


def footer(cv, doc):
    cv.saveState(); cv.setFont("Helvetica", 7.5); cv.setFillColor(colors.HexColor("#555555"))
    cv.drawString(18 * mm, 10 * mm, TITLE + " - 2026-11-02")
    cv.drawRightString(A4[0] - 18 * mm, 10 * mm, f"Page {doc.page}")
    cv.restoreState()


REVS = (("revA", "A"), ("revB", "B"), ("revE", "E"))
VOL = {"revA": 335389, "revB": 338012, "revE": 332367}
E = []
E.append(Paragraph(TITLE, H1))
E.append(Paragraph("Left Thigh, inner shell &nbsp;|&nbsp; Revision E &nbsp;|&nbsp; Date 2026-11-02", B))
E.append(Spacer(1, 4 * mm))

E.append(Paragraph("1. Scope and method", H2))
E.append(Paragraph(

    f"The Rev E solid is compared with the 3D-scan mesh of the original inner shell (7 442 087 triangles). Scan and CAD "
    "share the LT-OUT-001 model frame: origin on the knee axis at the outer's knee-floor plane, +Z along the knee axis away from "
    "the outer shell, +Y along the hip-ring axis (knee to hip). The scan was registered once onto the shared functional features "
    "(boss columns, pockets, boss-face plane) and is used unchanged for every revision; no best-fit alignment is applied per "
    "revision. Rev A, Rev B (the issued revisions) and Rev E are measured against the same scan on the same 1 500 000 scan "
    "samples, so the numbers compare directly with the Rev B report.", B))
E.append(Spacer(1, 2 * mm))
E.append(Paragraph(
    "<b>Scan to CAD</b>: signed distance of each scan sample to the CAD solid; + means the scan lies outside the CAD (the CAD "
    "has less material), - means the scan lies inside the CAD. Percentiles and the within-columns use the absolute distance. "
    "<b>CAD to scan</b>: unsigned distance of 600 000 uniform samples of the CAD surface to the scan mesh; it also counts CAD "
    "faces the scanner did not capture (bores, hole walls, faces in shadow).", B))
E.append(Spacer(1, 2 * mm))
E.append(Paragraph(
    "Zones: <b>knee hub</b> = scan points within r 70 of the knee axis; <b>hip end</b> = Y &gt; 262; <b>outer skin</b> = "
    "remaining points within 1 mm of the fitted outer freeform skin; <b>interior</b> = everything else (ribs, pockets, bosses, "
    "joint walls, inner wall faces).", B))

E.append(Paragraph("2. Part data", H2))
fb = lambda b: f"X {b[0]:.2f}..{b[3]:.2f}  Y {b[1]:.2f}..{b[4]:.2f}  Z {b[2]:.2f}..{b[5]:.2f}"
rows = [["", "Rev A (issued)", "Rev B (issued)", "Rev E"],
        ["Volume [mm3]"] + [f"{VOL[t]:,.0f}" for t, _ in REVS],
        ["Mass, Al 6061 (2.70 g/cm3) [kg]"] + [f"{VOL[t] * 2.7e-6:.3f}" for t, _ in REVS],
        ["Solids", "1", "1", "1"],
        ["Bounding box, model frame [mm]"] + [Paragraph(fb(q[t]["bbox"]), C) for t, _ in REVS]]
t = Table(rows, colWidths=[44 * mm, 43 * mm, 43 * mm, 44 * mm]); t.setStyle(tstyle(len(rows))); E.append(t)
E.append(Paragraph("Bounding boxes from the vertices of the delivered STL files. Volumes from NX.", S))

E.append(Paragraph("3. Deviation by zone", H2))
Z = (("all", "Whole part"), ("outer_skin", "Outer skin"), ("knee_hub", "Knee hub (r < 70)"), ("hip_end", "Hip end (Y > 262)"),
     ("interior", "Interior"))
rows = [["Zone", "Points", "Rev", "Mean", "p50", "p95", "Within 0.25", "Within 0.5", "Within 1.0"]]
for k, nm in Z:
    for i, (tag, lab) in enumerate(REVS):
        s = q[tag]["scan_to_cad"][k]
        rows.append([nm if i == 0 else "", f"{s['n']:,}" if i == 0 else "", lab, f"{s['mean']:+.3f}", f"{s['p50']:.3f}",
                     f"{s['p95']:.3f}", pct(s["w025"]), pct(s["w05"]), pct(s["w10"])])
for i, (tag, lab) in enumerate(REVS):
    s = q[tag]["cad_to_scan"]
    rows.append(["CAD to scan (unsigned)" if i == 0 else "", f"{s['n']:,}" if i == 0 else "", lab, "-", f"{s['p50']:.3f}",
                 f"{s['p95']:.3f}", pct(s["w025"]), pct(s["w05"]), pct(s["w10"])])
t = Table(rows, colWidths=[38 * mm, 17 * mm, 9 * mm, 16 * mm, 15 * mm, 15 * mm, 21 * mm, 21 * mm, 21 * mm])
st = tstyle(len(rows))
for r in range(1, len(rows), 3):
    st.add("LINEABOVE", (0, r), (-1, r), 0.9, colors.HexColor("#56606b"))
    st.add("SPAN", (0, r), (0, r + 2)); st.add("SPAN", (1, r), (1, r + 2))
    st.add("BACKGROUND", (0, r), (-1, r + 2), colors.white)
    st.add("BACKGROUND", (2, r + 2), (-1, r + 2), colors.HexColor("#eaf2ea"))
t.setStyle(st); E.append(t)
E.append(Paragraph("All values in mm except counts and percentages. Mean is signed; p50 / p95 are percentiles of |d|. "
                   "Rev E rows shaded green.", S))

# ---------------- page 2
E.append(PageBreak())
E.append(Paragraph("4. Deliberate departures: assembly fit changes in Rev E", H2))
E.append(Paragraph(
    "Rev E carries a set of changes made so that the inner assembles with LT-OUT-001 Rev F without interference. They are "
    "design changes, not scan errors: at these faces the CAD intentionally sits a set amount off the scanned surface (contact "
    "faces moved onto the outer's faces, clearance faces 0.12 mm above them, side walls 0.2 mm off the outer's tongue). The table "
    "gives the scan points inside a box around each changed region and their distance to Rev B and Rev E.", B))
E.append(Spacer(1, 2 * mm))
DESC = {
    "B6 boss: bottom face to Z 36.07 + new D10.4 / D6 web": ("Boss B5", "Boss bottom face at Z 36.07 (face contact with the outer boss). New screw web Ø10.4 / Ø6, Z 39.17-44.87, as on the other six bosses."),
    "-X joint wall: rebate floor 36.19 / 36.23, step +0.2": ("-X joint wall", "Rebate over the outer tongue: floor Z 36.19 / 36.23, step face 0.2 mm off the tongue side."),
    "+X joint wall: rebate floor 36.19, B5 face 36.07": ("+X joint wall", "Rebate floor Z 36.19 over the tongue; boss B2 face Z 36.07 (contact)."),
    "B4 pad + D10.4 pocket": ("Boss B1 pad", "Pad faces Z 36.07 (contact on the outer hub), pocket Ø10 enlarged to Ø10.4."),
    "B4 pad to Z 36.07 + D10.4 pocket": ("Boss B1 pad", "Pad faces Z 36.07 (contact on the outer hub), pocket Ø10 enlarged to Ø10.4."),
    "-X hip corner: floor Z 36.36, P1 recess D9.4": ("-X hip corner", "Floor Z 36.36 over the outer plate Z 36.24; pin P3 base recess Ø9.4."),
    "Hip seat flat to Z 85.28": ("Hip seat", "Seat flat Z 85.28 over the hip-ring top Z 85.20."),
    "B2 boss face to Z 36.24": ("Boss B7 face", "Boss face Z 36.24 onto the outer boss top (contact); 0.17 mm above the scanned face."),
    "Hip rib ends to Y 266.3": ("Hip rib ends", "Two rib ends cut back to Y 266.3 (0.2 mm off the outer flange)."),
    "+X hip corner step": ("+X hip corner", "Floor Z 36.19 over the outer Z 36.07, step 0.2 mm off the outer wall."),
}
rows = [[Paragraph(h, HB) for h in ["Region", "Change in Rev E", "Scan points", "Rev B p50", "Rev B within 0.5", "Rev E p50", "Rev E p95", "Rev E within 0.5"]]]
for k, r in q["regions"].items():
    nm, d = DESC[k]
    b_, e_ = r["revB"], r["revE"]
    rows.append([Paragraph(nm, C), Paragraph(d, C), f"{r['n']:,}", f"{b_['p50']:.3f}", pct(b_["w05"]), f"{e_['p50']:.3f}",
                 f"{e_['p95']:.2f}", pct(e_["w05"])])
t = Table(rows, colWidths=[22 * mm, 62 * mm, 15 * mm, 13 * mm, 16 * mm, 13 * mm, 13 * mm, 16 * mm], repeatRows=1)
st = tstyle(len(rows)); st.add("FONT", (2, 1), (-1, -1), "Helvetica", 7.4); t.setStyle(st); E.append(t)
E.append(Spacer(1, 2 * mm))
for n in [
    "Rev E agrees with the scan in these regions about as well as Rev B: 88 to 100 % of the scan points lie within 0.5 mm. "
    "The fit changes are small (0.1 to 0.2 mm) except at boss B5, where the boss face now ends at the boss-face plane like the other six bosses.",
    "Where Rev E moved a face off the scan on purpose, the median rises: boss B7 face (0.03 to 0.16 mm), the -X hip corner "
    "(0.13 to 0.27 mm) and the +X hip corner (0.12 to 0.23 mm). These are the clearance and contact offsets listed in the second column.",
    "The fit changes do not touch the outer skin, the knee hub or the interior ribs; outside these boxes the Rev E statistics "
    "are unchanged by them."]:
    E.append(Paragraph("&bull; " + n, B))

E.append(Paragraph("5. Summary", H2))
a, b, e = (q[t]["scan_to_cad"]["all"] for t in ("revA", "revB", "revE"))
sk = q["revE"]["scan_to_cad"]["outer_skin"]
E.append(Paragraph(
    f"Whole part, scan to CAD: {pct(e['w025'])} of the scan within 0.25 mm, {pct(e['w05'])} within 0.5 mm and {pct(e['w10'])} within "
    f"1.0 mm (Rev B {pct(b['w025'])} / {pct(b['w05'])} / {pct(b['w10'])}; Rev A {pct(a['w025'])} / {pct(a['w05'])} / {pct(a['w10'])}). "
    f"Median {e['p50']:.3f} mm, p95 {e['p95']:.2f} mm. The outer freeform skin is unchanged: {pct(sk['w05'])} within 0.5 mm, "
    f"median {sk['p50']:.3f} mm. The assembly fit changes account for the planned 0.1-0.2 mm offsets at the joint; the remaining "
    "spread is the unmodelled root fillets, the shared straight knee-hub wall and the interior areas listed in section 6.", B))

E.append(PageBreak())
E.append(Paragraph("6. Other differences between Rev E and the scan", H2))
dif = json.load(open(DIFF))
E.append(Paragraph(
    "Rev E also carries a reworked interior (rib layout and wall faces) compared with Rev B. To show where this moves the CAD "
    "toward or away from the scan, every scan sample was compared for Rev B and Rev E; areas where |d| changes by more than "
    "0.3 mm (and exceeds 0.5 mm in the worse revision) are grouped below. Median signed deviation, + = CAD has less material than the scan.", B))
E.append(Spacer(1, 2 * mm))
AREAS_W = [
    ("Knee hub outer wall, Z 70-83", 0, "Outer wall held at Ø135.70 straight (shared design value with LT-OUT-001) higher up the hub; the scan narrows with its 1.4° draft, so the CAD stands proud."),
    ("Ribs, mid section", 1, "Part of the reworked rib set sits up to about 1 mm off the scanned ribs (see the improvement in the next table for the larger part of the same rib set)."),
    ("Beside boss B3", 2, "Rib / wall face next to the B3 column about 1-2 mm inside the scanned face."),
    ("+X hip end wall near boss B6", 3, "Wall face up to about 1 mm inside the scan."),
    ("Knee top face around the bore, Z 85-86", 4, "Top face about 1.5 mm below the scanned face (Rev B already 1.1 mm)."),
    ("Gusset rib beside boss B7", 5, "The scanned gusset face at X about -15 is not matched by Rev E (Rev B followed it)."),
    ("Gusset rib beside boss B6", 8, "Rev E rib face at X about 96.5; the scanned face is at X about 90.5 (Rev B followed it)."),
    ("Hip end wall above the hip seat, Z 85-108", 9, "Wall face at Y 266.5; the scan shows a face near Y 262.5 between Z 90 and 102."),
]
rows = [[Paragraph(h, HB) for h in ["Area", "Extent X / Y / Z [mm]", "Scan points", "Rev B median", "Rev E median", "Observation"]]]
for nm, i, ob in AREAS_W:
    c = dif["worse"]["clusters"][i]
    ext = " / ".join(f"{c['lo'][j]:.0f}..{c['hi'][j]:.0f}" for j in range(3))
    rows.append([Paragraph(nm, C), Paragraph(ext, C), f"{c['n']:,}", f"{c['dB_med']:+.2f}", f"{c['dE_med']:+.2f}", Paragraph(ob, C)])
t = Table(rows, colWidths=[30 * mm, 30 * mm, 14 * mm, 14 * mm, 14 * mm, 68 * mm], repeatRows=1)
st = tstyle(len(rows)); st.add("FONT", (2, 1), (4, -1), "Helvetica", 7.4); t.setStyle(st)
E.append(KeepTogether([Paragraph(f"<b>a) Areas where Rev E is further from the scan than Rev B</b> ({dif['worse']['total']:,} of 1 500 000 samples in all)", S), Spacer(1, 1 * mm), t]))
E.append(Spacer(1, 2 * mm))
AREAS_B = [("Ribs, mid section", 0), ("Boss B1 column / wall side", 1), ("Rib top, X 35-42, Y 168-204", 2), ("+X wall, Y 176-196", 3)]
rows = [[Paragraph(h, HB) for h in ["Area", "Extent X / Y / Z [mm]", "Scan points", "Rev B median", "Rev E median"]]]
for nm, i in AREAS_B:
    c = dif["better"]["clusters"][i]
    ext = " / ".join(f"{c['lo'][j]:.0f}..{c['hi'][j]:.0f}" for j in range(3))
    rows.append([Paragraph(nm, C), Paragraph(ext, C), f"{c['n']:,}", f"{c['dB_med']:+.2f}", f"{c['dE_med']:+.2f}"])
t = Table(rows, colWidths=[40 * mm, 40 * mm, 20 * mm, 20 * mm, 20 * mm], repeatRows=1, hAlign="LEFT")
st = tstyle(len(rows)); t.setStyle(st)
E.append(KeepTogether([Paragraph(f"<b>b) Largest areas where Rev E is closer to the scan than Rev B</b> ({dif['better']['total']:,} samples in all)", S), Spacer(1, 1 * mm), t]))
E.append(Spacer(1, 1.5 * mm))
E.append(Paragraph("Net effect on the whole part: within 0.5 mm 89.3 % (Rev B) and 88.4 % (Rev E); within 1.0 mm 95.3 % and 95.4 %.", S))

E.append(Paragraph("7. Documented simplifications (unchanged from Rev B)", H2))
for n in [
    "Root fillets between ribs, walls, bosses and floor (R2-R3 on the original) are not modelled; the CAD corners are sharp. "
    "They show as a narrow + band, up to about 1 mm and more, along every rib and wall root in the colour maps and are the largest "
    "single source of interior residual. Drawing note: internal corners R3 max.",
    "Shared features use one design value for both shells where the two scans disagree (the LT-OUT-001 value): boss-face plane "
    "Z 36.07, pockets Ø10.00, pin holes Ø4.00, boss columns Ø15.00, knee hub OD Ø135.70 straight (both scans show a 1.4° draft).",
    "Design intent over print warp: the scanned part is a print with slight warp; the CAD is flat, square and concentric and the "
    "boss faces are one plane.",
    "The cove round the base of the Ø40.23 knee ring and the sloped thickening of the two side walls next to the hip plate are "
    "plain faces in the CAD.",
    "Styling seams on the outer skin are Ø1.8 round-bottom grooves 0.55 deep along the scanned centre lines; small raised panel "
    "steps next to them are blended into the skin.",
    "Engraved marks and printed texture are not modelled.",
    "The scan mesh is open in places (bores, hole walls, shadowed faces). CAD faces without scan coverage raise the CAD-to-scan "
    "percentiles without being a deviation of the part."]:
    E.append(Paragraph("&bull; " + n, B))
E.append(PageBreak())
E.append(Paragraph("8. Colour maps", H2))
E.append(Paragraph(
    "Scan surface coloured by its signed distance to the Rev E solid. One banded scale for all views: green within "
    "+/-0.10 mm; warm colours where the scan lies outside the CAD (+), cool colours where it lies inside (-); the end bands "
    "collect everything beyond +/-1.0 mm. Uncoloured gaps are areas the scan does not cover.", B))
W_AV, H_AV = A4[0] - 36 * mm, A4[1] - 40 * mm
E.append(Spacer(1, 3 * mm))
FIRST = True
pages = [("iso_outside", "iso_open"), ("top",), ("bottom",), ("side_px", "side_nx", "hip_end")]
for grp in pages:
    imgs = []
    for v in grp:
        p = os.path.join(MAPS, f"LT-INN-001_deviation_{v}.png")
        iw, ih = ImageReader(p).getSize(); imgs.append((p, iw, ih))
    if grp == ("top", "bottom"):
        w = W_AV / 2 - 2 * mm
        cells = [Image(p, width=w, height=w * ih / iw) for p, iw, ih in imgs]
        h = max(c.drawHeight for c in cells)
        if h > H_AV - 4 * mm:
            sc = (H_AV - 4 * mm) / h
            cells = [Image(p, width=w * sc, height=w * sc * ih / iw) for p, iw, ih in imgs]
        tb = Table([cells], colWidths=[W_AV / 2, W_AV / 2]); tb.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
        E.append(tb)
    else:
        tot = sum(W_AV * ih / iw for p, iw, ih in imgs) + 4 * mm * len(imgs)
        sc = min(1.0, (H_AV - 6 * mm - (25 * mm if FIRST else 0)) / tot); FIRST = False
        for p, iw, ih in imgs:
            E.append(Image(p, width=W_AV * sc, height=W_AV * sc * ih / iw)); E.append(Spacer(1, 3 * mm))
    if grp != pages[-1]:
        E.append(PageBreak())

doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=18 * mm,
                        title=TITLE, author="", subject="Scan-to-CAD deviation, LT-INN-001 Rev E")
doc.build(E, onFirstPage=footer, onLaterPages=footer)
print("wrote", OUT)

