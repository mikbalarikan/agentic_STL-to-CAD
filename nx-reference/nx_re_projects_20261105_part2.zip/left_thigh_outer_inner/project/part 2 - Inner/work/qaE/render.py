"""Render every page of a PDF to PNG. usage: render.py in.pdf out_prefix [dpi]"""
import sys, glob, os
import fitz
pdf, pre = sys.argv[1], sys.argv[2]
dpi = int(sys.argv[3]) if len(sys.argv) > 3 else 90
for f in glob.glob(pre + "*.png"):
    os.remove(f)
d = fitz.open(pdf)
for i, p in enumerate(d):
    p.get_pixmap(dpi=dpi).save(f"{pre}{i + 1}.png")
print(d.page_count, "pages")
