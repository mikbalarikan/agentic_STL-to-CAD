"""Blender headless studio renders, multi-mesh version of part 1/work/renderF/bl_render.py (same look:
Cycles, studio.exr world, camera-relative key/fill/rim, AgX, Freestyle crease lines, transparent film).
usage: blender -b --factory-startup -P bl_render2.py -- <scene.json> <views.json> <out_dir> [samples] [res_pct] [only,names]
scene.json: {"parts": {name: {"stl": path, "mat": "alu"|"blue"|"cap_alu"|"cap_blue"}}}
views.json: {name: {focus, dir (focus->camera), dist mm, up, fov, [show: [parts]], [xf: {part: 4x4 row-major, mm]}, ...}}
Writes <out_dir>/<name>_rgba.png; compose.py puts them on the studio background."""
import bpy, sys, json, math, os, bmesh
from mathutils import Vector, Matrix

argv = sys.argv[sys.argv.index("--") + 1:]
sjson, vjson, out = [os.path.abspath(a) for a in argv[:3]]
samples = int(argv[3]) if len(argv) > 3 else 128
res_pct = int(argv[4]) if len(argv) > 4 else 100
only = set(argv[5].split(",")) if len(argv) > 5 and argv[5] else None
os.makedirs(out, exist_ok=True)
views = json.load(open(vjson)); scene = json.load(open(sjson))
S = 0.001

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene


def material(kind):
    m = bpy.data.materials.get(kind)
    if m: return m
    m = bpy.data.materials.new(kind); m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    col, met, rou = {"alu": ((0.56, 0.58, 0.61), 0.92, 0.30),          # Rev F machined aluminium
                     "blue": ((0.13, 0.27, 0.48), 0.85, 0.33),         # blue anodised aluminium
                     "cap_alu": ((0.80, 0.80, 0.78), 0.0, 0.55),       # section faces, matte
                     "cap_blue": ((0.30, 0.50, 0.78), 0.0, 0.55)}[kind]
    b.inputs["Base Color"].default_value = (*col, 1)
    b.inputs["Metallic"].default_value = met
    b.inputs["Roughness"].default_value = rou
    if "Anisotropic" in b.inputs and met > 0.5: b.inputs["Anisotropic"].default_value = 0.25
    return m


objs = {}
for name, p in scene["parts"].items():
    bpy.ops.object.select_all(action="DESELECT")
    bpy.ops.wm.stl_import(filepath=os.path.abspath(p["stl"]), global_scale=S)
    ob = bpy.context.selected_objects[0]; ob.name = name; me = ob.data
    me.transform(ob.matrix_world); ob.matrix_world = Matrix.Identity(4)  # bake the import scale into the mesh
    bm = bmesh.new(); bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-6)
    bm.to_mesh(me); bm.free()
    me.shade_smooth(); me.set_sharp_from_angle(angle=math.radians(28))
    me.materials.append(material(p.get("mat", "alu")))
    objs[name] = ob

w = bpy.data.worlds.new("w"); sc.world = w; w.use_nodes = True
wn = w.node_tree.nodes; wl = w.node_tree.links
bg = wn["Background"]; env = wn.new("ShaderNodeTexEnvironment")
hdr = os.path.join(os.path.dirname(bpy.app.binary_path), "%d.%d" % bpy.app.version[:2],
                   "datafiles", "studiolights", "world", "studio.exr")
env.image = bpy.data.images.load(hdr)
wl.new(env.outputs["Color"], bg.inputs["Color"]); bg.inputs["Strength"].default_value = 0.7

sc.render.engine = "CYCLES"; cy = sc.cycles
try:
    prefs = bpy.context.preferences.addons["cycles"].preferences
    for dt in ("OPTIX", "CUDA"):
        try:
            prefs.compute_device_type = dt; prefs.get_devices()
            if any(d.type == dt for d in prefs.devices):
                for d in prefs.devices: d.use = d.type == dt
                cy.device = "GPU"; print("device", dt); break
        except Exception as e:
            print("no", dt, e)
except Exception as e:
    print("gpu setup failed", e)
cy.samples = samples; cy.use_denoising = True; cy.max_bounces = 8
sc.render.film_transparent = True
sc.render.resolution_x, sc.render.resolution_y = 2400, 1500
sc.render.image_settings.file_format = "PNG"; sc.render.image_settings.color_mode = "RGBA"
sc.render.image_settings.color_depth = "16"
sc.view_settings.view_transform = "AgX"
looks = [i.identifier for i in sc.view_settings.bl_rna.properties["look"].enum_items]
for lk in ("AgX - Medium High Contrast", "Medium High Contrast"):
    if lk in looks: sc.view_settings.look = lk; break

if os.environ.get("FS", "1") == "1":
    sc.render.use_freestyle = True; sc.render.line_thickness_mode = "ABSOLUTE"
    vl = sc.view_layers[0]; fs = vl.freestyle_settings
    fs.crease_angle = math.radians(float(os.environ.get("FSA", "135")))
    ls = fs.linesets[0] if len(fs.linesets) else fs.linesets.new("L")
    ls.select_by_visibility = True; ls.visibility = "VISIBLE"
    ls.select_silhouette = True; ls.select_border = True; ls.select_crease = True
    ls.select_contour = False; ls.select_external_contour = False
    if ls.linestyle is None: ls.linestyle = bpy.data.linestyles.new("LS")
    lsty = ls.linestyle; lsty.color = (0.10, 0.11, 0.12); lsty.alpha = 0.55; lsty.thickness = 1.0

cam_d = bpy.data.cameras.new("cam"); cam = bpy.data.objects.new("cam", cam_d)
sc.collection.objects.link(cam); sc.camera = cam
cam_d.clip_start, cam_d.clip_end = 0.001, 10.0; cam_d.sensor_fit = "HORIZONTAL"


def area(name, size, power):
    ld = bpy.data.lights.new(name, "AREA"); ld.size = size; ld.energy = power
    lo = bpy.data.objects.new(name, ld); sc.collection.objects.link(lo); lo.parent = cam
    return lo


def aim(lo, pos_cam, tgt_cam=(0, 0, 0)):
    p = Vector(pos_cam); t = Vector(tgt_cam); z = (p - t).normalized()
    x = Vector((0, 1, 0)).cross(z)
    if x.length < 1e-6: x = Vector((1, 0, 0))
    x.normalize(); y = z.cross(x)
    M = Matrix((x, y, z)).transposed().to_4x4(); M.translation = p
    lo.matrix_parent_inverse = Matrix.Identity(4); lo.matrix_basis = M


key = area("key", 0.35, 60); fill = area("fill", 0.6, 25); rim = area("rim", 0.3, 40)

for name, v in views.items():
    if only and name not in only: continue
    show = set(v.get("show", objs.keys()))
    for n, ob in objs.items():
        ob.hide_render = n not in show
        X = v.get("xf", {}).get(n)
        if X:
            M = Matrix(X); M.translation = M.translation * S
            ob.matrix_world = M
        else:
            ob.matrix_world = Matrix.Identity(4)
    f = Vector(v["focus"]) * S; d = Vector(v["dir"]).normalized(); dist = v["dist"] * S
    up = Vector(v.get("up", (0, 0, 1)))
    z = d; x = up.cross(z)
    if x.length < 1e-6: x = Vector((0, 1, 0)).cross(z)
    x.normalize(); y = z.cross(x)
    M = Matrix((x, y, z)).transposed().to_4x4(); M.translation = f + d * dist
    cam.matrix_world = M; cam_d.angle = math.radians(v.get("fov", 30))
    sc.view_settings.exposure = float(os.environ.get("EXPO", "0")) + v.get("expo", 0.0)
    for m in bpy.data.materials:  # optional per-view metallic override (down-facing faces reflect the dark floor)
        b = m.node_tree.nodes.get("Principled BSDF") if m.use_nodes else None
        if b is None: continue
        if "_met0" not in m: m["_met0"] = b.inputs["Metallic"].default_value
        b.inputs["Metallic"].default_value = m["_met0"] * v.get("metal", 1.0)
    L = dist
    fy = -1.0 if v.get("lflip") else 1.0  # lflip: lights below the camera (views looking up at down-facing faces)
    aim(key, (-0.9 * L, fy * 0.9 * L, -0.15 * L), (0, 0, -L))
    aim(fill, (1.1 * L, fy * 0.2 * L, 0.1 * L), (0, 0, -L))
    aim(rim, (0.4 * L, fy * 1.0 * L, -1.8 * L), (0, 0, -L))
    sc_ = (L / 0.66) ** 2
    key.data.energy = 60 * sc_ * v.get("key", 1.0); fill.data.energy = 22 * sc_ * v.get("fill", 1.0)
    rim.data.energy = 35 * sc_
    key.data.size, fill.data.size, rim.data.size = 0.5 * L, 0.9 * L, 0.45 * L
    sc.render.resolution_percentage = int(res_pct * v.get("res", 100) / 100)
    sc.render.line_thickness = float(os.environ.get("FSW", "1.3")) * sc.render.resolution_percentage / 100
    sc.render.filepath = os.path.join(out, name + "_rgba.png")
    bpy.ops.render.render(write_still=True)
    print("wrote", name, flush=True)
