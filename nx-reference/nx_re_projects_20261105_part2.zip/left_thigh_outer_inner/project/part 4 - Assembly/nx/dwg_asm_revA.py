# -*- coding: utf-8 -*-
"""LT-ASM-001 Left Thigh assembly drawing (LT-OUT-001 Rev A + LT-INN-001 Rev A), 2 sheets A1, third angle.
run_journal dwg_asm.py -args <assembly.prt> <out_dir> [full]
Master-model drawing: the assembly prt is the only component of LT-ASM-001_dwg.prt, placed with drawing
(X, Y, Z) = model (y, -x, z) (length knee left -> hip right, as LT-OUT-001 / LT-INN-001). M(x, y, z) maps a MODEL point
to drawing-part coordinates. The assembly and its components are never saved (SaveComponents = False).
Sheet 1: general arrangement (front / top / right / iso, overall sizes, parts list, balloons, notes).
Sheet 2: mating interface (key plan 1:2 turned 90 deg so a horizontal cut is a model-Y cut; section D-D stepped
through B5 / B4 and pin P2; section E-E through the knee axis; detail F 4:1 boss + pin; detail G 10:1 parting gap).
View letters D, E, F, G (A, B, C are the datum letters of the parts)."""
import json
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\nx\dwglib")
import NXOpen  # noqa: E402
import NXOpen.Annotations  # noqa: E402
import NXOpen.Drawings  # noqa: E402
import nxh  # noqa: E402


def _save(part):
    """Save the drawing part only - never the referenced assembly or its components."""
    part.Save(NXOpen.BasePart.SaveComponents.FalseValue, NXOpen.BasePart.CloseAfterSave.FalseValue).Dispose()


nxh.save = _save
import nxd  # noqa: E402
import nxd2  # noqa: E402
import ptdwg  # noqa: E402
import m3d  # noqa: E402
import gdt  # noqa: E402
from m3d import D, N, xy  # noqa: E402

ASM, OUTD = sys.argv[1], sys.argv[2]
MODE = sys.argv[3] if len(sys.argv) > 3 else "full"
os.makedirs(OUTD, exist_ok=True)
NO, TITLE = "LT-ASM-001", "LEFT THIGH - ASSEMBLY"
MAT, MASS = "see parts list", "1.95 kg"
R = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]]
S = nxd.SNAP
A = NXOpen.Annotations
DT = 5.0        # dimension text
GT = 4.5        # notes
DIA = "Ø"
DEG = "°"
res = {"result": "FAIL", "dims": {}, "errors": {}, "info": {}}
m3d.start(res)
_style0 = ptdwg._style
ptdwg._style = lambda b, prec=2, text_size=None: _style0(b, prec, text_size or DT)
CAD_FILES = [ASM] + [os.path.join(os.path.dirname(ASM), f) for f in ("LT-OUT-001_Left_Thigh_Outer.prt", "LT-INN-001_Left_Thigh_Inner.prt")]
res["cad_mtime_before"] = {os.path.basename(f): os.path.getmtime(f) for f in CAD_FILES}


def M(x, y, z):
    return (y, -x, z)


def pub(o):
    return [n for n in dir(o) if not n.startswith("_")]


# ---------------------------------------------------------------- curve cache with owning component
CACHE = {}


def cv(view):
    """[(curve, characteristic points, owning component name)] of a view (cached)."""
    if view.Tag not in CACHE:
        rows = []
        for body in view.DraftingBodies:
            for c in body.DraftingCurves:
                try:
                    info = c.GetDraftingCurveInfo()
                    ps = list(info.GetParents()) if info is not None else []
                except Exception:  # noqa: BLE001
                    ps = []
                own = None
                for p in ps:
                    try:
                        oc = p.OwningComponent
                        if oc is not None:
                            own = oc.Name
                            break
                    except Exception:  # noqa: BLE001
                        pass
                rows.append((c, nxd.curve_points(c), own))
        CACHE[view.Tag] = rows
    return CACHE[view.Tag]


def own_is(o, who):
    if who is None:
        return True
    return o is not None and who in o.upper()


def ends_of(c, p):
    """End points (+ mid) of a line / arc / open spline; None for full circles."""
    if len(p) == 3:
        return [p[0], p[1], p[2]]
    if len(p) == 4:
        return [p[0], p[1], p[3]]
    if len(p) == 2 and not ptdwg._is_arc(c):
        return [p[0], p[1]]
    return None


def lines(view, pred, owner=None):
    return [(c, p) for c, p, o in cv(view) if len(p) == 3 and own_is(o, owner) and pred(p[0], p[1])]


def longest(cands, what="curve"):
    if not cands:
        raise RuntimeError("no %s" % what)
    return max(cands, key=lambda cp: sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)))[0]


def vline(view, Y, z0, z1, owner=None, tol=0.05):
    """Longest line at drawing Y = const lying inside z0..z1 (section views: cut lines are vertical there)."""
    return lambda: longest(lines(view, lambda a, b: abs(a[1] - Y) < tol and abs(b[1] - Y) < tol and abs(a[2] - b[2]) > 0.05
                                 and min(a[2], b[2]) >= z0 - 0.3 and max(a[2], b[2]) <= z1 + 0.3, owner),
                           "vline Y%.3f z%.2f..%.2f in %s" % (Y, z0, z1, view.Name))


def hline(view, Z, y0, y1, owner=None, tol=0.02):
    """Longest line at Z = const whose mid point lies in drawing Y y0..y1."""
    lo, hi = min(y0, y1), max(y0, y1)
    return lambda: longest(lines(view, lambda a, b: abs(a[2] - Z) < tol and abs(b[2] - Z) < tol and abs(a[1] - b[1]) > 0.02
                                 and lo <= 0.5 * (a[1] + b[1]) <= hi, owner),
                           "hline Z%.3f Y%.2f..%.2f in %s" % (Z, y0, y1, view.Name))


def dimc(name, view, fa, fb, origin, method, expect, etol=0.02, **kw):
    def f():
        ca, cb = fa(), fb()
        return m3d.dim_curves(view, ca, cb, origin, method, expect=expect, etol=etol, **kw)
    return D(name, f)


def border(view):
    return nxh.UFS.Draw.AskViewBorders(view.Tag)


def extreme(view, ax, sign, owner=None):
    """(curve, model point) of the curve end point that is extreme along drawing axis ax (sign +1 max / -1 min)."""
    best = None
    for c, p, o in cv(view):
        if not own_is(o, owner):
            continue
        e = ends_of(c, p)
        if not e:
            continue
        for q in e[:2]:
            v = sign * q[ax]
            if best is None or v > best[0] + 1e-9:
                best = (v, c, q)
    if best is None:
        raise RuntimeError("extreme: nothing in %s" % view.Name)
    return best[1], best[2]


def sheet_extreme(view, owner, key):
    """(curve, model point, sheet point) of the owner's curve point maximising key(sheet point)."""
    best = None
    for c, p, o in cv(view):
        if not own_is(o, owner):
            continue
        e = ends_of(c, p)
        if not e:
            continue
        for q in e:
            s = xy(view, q)
            v = key(s)
            if best is None or v > best[0]:
                best = (v, c, q, s)
    if best is None:
        raise RuntimeError("sheet_extreme: no %s curve in %s" % (owner, view.Name))
    return best[1], best[2], best[3]


def overall(name, view, ax, method, origin_fn, ref):
    """Overall size between the two extreme curve end points along drawing axis ax, read back."""
    def f():
        c0, p0 = extreme(view, ax, -1)
        c1, p1 = extreme(view, ax, +1)
        res["info"][name + "_ends"] = [[round(v, 3) for v in p0], [round(v, 3) for v in p1], "bbox %.3f" % ref]
        exp = abs(p1[ax] - p0[ax])
        return m3d.dim_ends(view, c0, p0, c1, p1, origin_fn(p0, p1), method, expect=exp, etol=0.02)
    return D(name, f)


def balloon(name, text, view, owner, key, dpos):
    """Arrow balloon outside the view: leader onto the owner's curve point that is extreme by key; dpos(sheet pt,
    borders) -> balloon centre."""
    def f():
        c, q, s = sheet_extreme(view, owner, key)
        pos = dpos(s, border(view))
        res["info"]["balloon_" + name] = {"target_sheet": [round(s[0], 2), round(s[1], 2)], "pos": [round(pos[0], 2), round(pos[1], 2)]}
        dw = m3d.CTX["dwg"]
        b = dw.Annotations.IdSymbols.CreateIdSymbolBuilder(A.IdSymbol.Null)
        try:
            b.Type = A.IdSymbolBuilder.SymbolTypes.Circle
            b.UpperText = str(text)
            b.Size = 11.0
            try:
                b.Style.LetteringStyle.GeneralTextSize = GT
            except Exception:  # noqa: BLE001
                pass
            # stub on the side that faces the target, so the leader never runs back under the balloon
            nxd2._leader(dw, b.Leader, c, view, q, "filled_arrow", side="right" if s[0] > pos[0] else "left")
            b.Origin.Origin.SetValue(None, None, nxh.P(pos[0], pos[1], 0.0))
            return b.Commit()
        finally:
            b.Destroy()
    return N("balloon_" + name, f)


def note_lines(lines_, x, y, step=8.0, size=GT):
    for i, t in enumerate(lines_):
        if t:
            N("note_%d_%d" % (int(x), int(y - i * step)), lambda t=t, i=i: nxd.note(m3d.CTX["dwg"], [t], (x, y - i * step), size=size))


def table(origin, cw, rows, size=3.5, rh=8.0, merge_title=False):
    m = [(0, 0, 0, len(cw) - 1)] if merge_title else []
    _ts, tn = nxd2.table(m3d.CTX["dwg"], origin, cw, [rh] * len(rows), rows, text_size=size, merges=m)
    return nxd2.table_text(tn)


# ---------------------------------------------------------------- views
def base_rot(dwg, pos, scale, normal, xdir):
    """Base view looking along -normal with xdir to the right (Orient View Tool); fallback: Top + view angle."""
    tried = []
    for how in ("ovt", "angle90", "angle-90"):
        b = dwg.DraftingViews.CreateBaseViewBuilder(NXOpen.Drawings.BaseView.Null)
        try:
            b.SelectModelView.SelectedView = dwg.ModelingViews.FindObject("Top")
            b.Style.ViewStyleBase.Part = dwg
            b.Style.ViewStyleBase.PartName = dwg.FullPath
            b.Scale.Numerator, b.Scale.Denominator = float(scale[0]), float(scale[1])
            if how == "ovt":
                ovt = b.Style.ViewStyleOrientation.Ovt
                UO = NXOpen.SmartObject.UpdateOption.WithinModeling
                ovt.NormalDirection = dwg.Directions.CreateDirection(nxh.P(0.0, 0.0, 0.0), NXOpen.Vector3d(*normal), UO)
                ovt.XDirection = dwg.Directions.CreateDirection(nxh.P(0.0, 0.0, 0.0), NXOpen.Vector3d(*xdir), UO)
            else:
                b.Style.ViewStyleGeneral.Angle = 90.0 if how == "angle90" else -90.0
            b.Placement.Placement.SetValue(None, dwg.Views.WorkView, nxh.P(pos[0], pos[1], 0.0))
            v = b.Commit()
        except Exception as e:  # noqa: BLE001
            tried.append([how, str(e)[:200]])
            v = None
        finally:
            b.Destroy()
        if v is None:
            continue
        vi = nxd.view_info(v)
        tried.append([how, vi["right"], vi["up"]])
        if abs(abs(vi["up"][0]) - 1.0) < 1e-3:
            res["info"]["rot_view"] = tried
            return v
        ptdwg._delete([v])
    res["info"]["rot_view"] = tried
    raise RuntimeError("base_rot failed: %s" % tried)


def section(dwg, parent, through, pos, scale, letter, extra=(), background=False):
    SVB = NXOpen.Drawings.SectionViewBuilder
    b = dwg.DraftingViews.CreateSectionViewBuilder(NXOpen.Drawings.SectionView.Null)
    try:
        b.SectionViewType = SVB.SectionLineType.SimpleStepped
        b.ParentView.View.Value = parent
        seg = b.SectionLineSegments.SegmentLocation
        seg.AddCutSegment(dwg.Points.CreatePoint(nxh.P(*through)))
        for q in extra:
            seg.AddCutSegment(dwg.Points.CreatePoint(nxh.P(*q)))
        sc = b.ViewStyle.ViewStyleGeneral.Scale
        sc.Numerator, sc.Denominator = float(scale[0]), float(scale[1])
        try:
            b.ViewStyle.ViewCommonViewLabel.Letter = letter
            res["info"]["letter_" + letter] = "builder"
        except Exception as e:  # noqa: BLE001
            res["info"]["letter_" + letter] = "builder failed: %s; %s" % (str(e)[:120], pub(b.ViewStyle.ViewCommonViewLabel)[:60])
        vss = b.ViewStyle.ViewStyleSection
        res["info"]["vss_pub"] = pub(vss)
        if not background:
            try:
                vss.Background = False
                res["info"]["bg_" + letter] = "off"
            except Exception as e:  # noqa: BLE001
                res["info"]["bg_" + letter] = "failed %s" % str(e)[:120]
        b.ViewPlacement.Placement.SetValue(None, dwg.Views.WorkView, nxh.P(pos[0], pos[1], 0.0))
        v = b.Commit()
    finally:
        b.Destroy()
    return v


def detail(dwg, parent, centre, edge, pos, scale, letter, on_parent="Label"):
    DVB = NXOpen.Drawings.DetailViewBuilder
    c, e = xy(parent, centre), xy(parent, edge)
    b = dwg.DraftingViews.CreateDetailViewBuilder(NXOpen.Drawings.DetailView.Null)
    try:
        res["info"]["dvb_pub"] = pub(b)
        b.Type = DVB.Types.Circular
        b.Parent.View.Value = parent
        b.BoundaryPoint1 = dwg.Points.CreatePoint(nxh.P(c[0], c[1], 0.0))
        b.BoundaryPoint2 = dwg.Points.CreatePoint(nxh.P(e[0], e[1], 0.0))
        b.Scale.Numerator, b.Scale.Denominator = float(scale[0]), float(scale[1])
        res["info"]["label_on_parent_types"] = pub(DVB.LabelOnParentType)
        b.LabelOnParent = getattr(DVB.LabelOnParentType, on_parent)
        for path in ("Style.ViewCommonViewLabel", "ViewStyle.ViewCommonViewLabel"):
            try:
                o = b
                for a_ in path.split("."):
                    o = getattr(o, a_)
                o.Letter = letter
                res["info"]["letter_" + letter] = "builder " + path
                break
            except Exception as ex:  # noqa: BLE001
                res["info"]["letter_" + letter + "_" + path] = str(ex)[:100]
        b.Origin.Placement.SetValue(None, dwg.Views.WorkView, nxh.P(pos[0], pos[1], 0.0))
        v = b.Commit()
    finally:
        b.Destroy()
    return v


def relabel(view, letter):
    """Letter of a view label after creation (EditViewLabelSettingsBuilder), as in dwg_inner.py."""
    sm = m3d.CTX["dwg"].SettingsManager
    tag = nxh.UFS.Draw.AskViewLabel(view.Tag)
    lab = NXOpen.TaggedObjectManager.GetTaggedObject(tag)
    b = sm.CreateDrawingEditViewLabelSettingsBuilder([lab])
    try:
        b.ViewCommonViewLabel.Letter = letter
        b.Commit()
    finally:
        b.Destroy()
    return "ok"


def vis_tags(views):
    out = set()
    for v in views:
        for o in v.AskVisibleObjects():
            out.add(o.Tag)
    return out


def move_new_labels(before, views, pos, box):
    """Objects that appeared in `views` since `before`: record them; move the annotation-type ones (the label on
    the parent) to sheet pos."""
    rows = []
    for v in views:
        for o in v.AskVisibleObjects():
            if o.Tag in before:
                continue
            r_ = {"type": type(o).__name__, "view": v.Name}
            try:
                p = o.AnnotationOrigin
                r_["origin"] = [round(p.X, 2), round(p.Y, 2)]
            except Exception:  # noqa: BLE001
                rows.append(r_)
                continue
            if not (box[0] <= p.X <= box[2] and box[1] <= p.Y <= box[3]):
                rows.append(r_)
                continue
            try:
                o.AnnotationOrigin = nxh.P(pos[0], pos[1], 0.0)
                o.RedisplayObject()
                p = o.AnnotationOrigin
                r_["moved_to"] = [round(p.X, 2), round(p.Y, 2)]
            except Exception as e:  # noqa: BLE001
                r_["move_err"] = str(e)[:150]
            rows.append(r_)
    return rows


def view_letter(view):
    try:
        tag = nxh.UFS.Draw.AskViewLabel(view.Tag)
        lab = NXOpen.TaggedObjectManager.GetTaggedObject(tag)
        sm = m3d.CTX["dwg"].SettingsManager
        b = sm.CreateDrawingEditViewLabelSettingsBuilder([lab])
        try:
            return b.ViewCommonViewLabel.Letter
        finally:
            b.Destroy()
    except Exception as e:  # noqa: BLE001
        return "? %s" % str(e)[:80]


HATCH = {"OUT": (45.0, 3.5), "INN": (135.0, 2.0)}     # angle, spacing: outer / inner


def restyle_hatches(view):
    """One hatch per component per view: the inner's region lies above Z 20 (inner Z min 28.96), the outer's
    reaches far below (bosses, belly). Outer 45 deg / 3.5, inner 135 deg / 2.0."""
    out = []
    hs = [(h, nxh.bbox(h)) for h in view.AskVisibleObjects() if "Hatch" in type(h).__name__]
    mid = lambda bb: 0.5 * (bb[2] + bb[5])   # noqa: E731
    if len(hs) == 2:          # one hatch per component: the higher one is the inner (detail clipping moves zmin)
        hi = max(hs, key=lambda t: mid(t[1]))[0]
    for h, bb in hs:
        if len(hs) == 2:
            who = "INN" if h is hi else "OUT"
        else:
            who = "INN" if bb[2] > 20.0 else "OUT"
        ang, dist = HATCH[who]
        row = {"who": who, "zmin": round(bb[2], 2), "zmax": round(bb[5], 2)}
        try:
            hb = m3d.CTX["dwg"].Annotations.Hatches.CreateHatchBuilder(h)
            try:
                row["before"] = [hb.Angle, hb.Distance]
                hb.Angle = ang
                hb.Distance = dist
                hb.Commit()
            finally:
                hb.Destroy()
            hb = m3d.CTX["dwg"].Annotations.Hatches.CreateHatchBuilder(h)
            try:
                row["after"] = [hb.Angle, hb.Distance]
            finally:
                hb.Destroy()
        except Exception as e:  # noqa: BLE001
            row["err"] = str(e)[:200]
        out.append(row)
    return out


def dumpv(tag, v):
    res["info"]["vinfo_" + tag] = nxd.view_info(v)
    try:
        rows = [{"own": o, "pts": [[round(t, 3) for t in q] for q in p]} for c, p, o in cv(v)]
        json.dump(rows, open(os.path.join(OUTD, "dump_%s.json" % tag), "w"), indent=0)
    except Exception as e:  # noqa: BLE001
        res["errors"]["dump_" + tag] = str(e)


try:
    dwg, comp = m3d.new_drawing(os.path.join(OUTD, NO + "_dwg.prt"), ASM, NO, R, refset="Entire Part")
    kids = {}
    for k in comp.GetChildren():
        p = k.Prototype
        if not p.IsFullyLoaded:
            p.LoadThisPartFully().Dispose()
        kids[k.Name] = {"refset": k.ReferenceSet, "full": p.IsFullyLoaded, "part": p.Name}
    res["components"] = kids

    # ================================================================ SHEET 1 general arrangement (A1, 1:1)
    sh1, _g = ptdwg.sheet(dwg, "A1")
    front = nxd.base_view(dwg, dwg, "Front", (235.0, 165.0), scale=(1.0, 1.0))
    top = nxd.projected_view(dwg, front, (235.0, 425.0))
    right = nxd.projected_view(dwg, front, (536.0, 165.0))
    iso = nxd.base_view(dwg, dwg, "Isometric", (722.0, 432.0), scale=(1.0, 2.0))
    res["tb1"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (iso 1:2)", 1, 2, rev="A", subtitle="assembly")
    for tg, v in (("sh1_front", front), ("sh1_top", top), ("sh1_right", right), ("sh1_iso", iso)):
        dumpv(tg, v)
    fb, rb_ = border(front), border(right)
    overall("L_overall", front, 0, "horizontal", lambda p0, p1: (0.5 * (fb[0] + fb[2]), fb[1] - 16.0), 288.7078 + 67.85)
    overall("H_overall", front, 2, "vertical", lambda p0, p1: (fb[0] - 16.0, 0.5 * (fb[1] + fb[3])), 111.0248 + 40.8059)
    overall("W_overall", right, 1, "horizontal", lambda p0, p1: (0.5 * (rb_[0] + rb_[2]), rb_[1] - 16.0), 118.9467 + 68.9954)
    # balloons on the isometric: 2 (inner) above its top-most point, 1 (outer) below its bottom-most point
    balloon("2_iso", "2", iso, "INN", lambda s: s[1], lambda s, bd: (s[0] - 16.0, bd[3] + 7.0))
    balloon("1_iso", "1", iso, "OUT", lambda s: -s[1], lambda s, bd: (s[0] + 16.0, bd[1] - 7.0))
    # parts list directly above the title block (tabular note, ISO 7200 order of columns as asked)
    pl = [["ITEM", "P/N", "DESCRIPTION", "MATERIAL", "QTY", "MASS"],
          ["1", "LT-OUT-001 REV A", "LEFT THIGH - OUTER SHELL", "AL 6061-T6", "1", "1.04 kg"],
          ["2", "LT-INN-001 REV A", "LEFT THIGH - INNER SHELL", "AL 6061-T6", "1", "0.91 kg"]]
    res["parts_list"] = N("parts_list", lambda: table((641.0, 57.0 + 3 * 8.0), [14.0, 46.0, 64.0, 30.0, 12.0, 24.0], pl, size=3.0))
    note_lines(["NOTES",
                "1. LT-OUT-001 AND LT-INN-001 ARE MODELLED IN ONE FRAME; ASSEMBLE AS MODELLED.",
                "2. CONTACT ON THE 7 BOSS FACES ONLY (DATUM A, Z 36.07).",
                "3. MATING INTERFACE, KNEE AXIS AND FASTENING: SEE SHEET 2."], 452.0, 318.0, step=9.0)
    res["overlaps1"] = nxd.overlaps(sh1)

    # ================================================================ SHEET 2 mating interface
    sh2, _g = ptdwg.sheet(dwg, "A1")
    plan = base_rot(dwg, (100.0, 420.0), (1.0, 2.0), (0.0, 0.0, 1.0), (0.0, -1.0, 0.0))
    Y45 = 0.5 * (165.91 + 165.96)
    secD = section(dwg, plan, M(86.45, Y45, 40.0), (330.0, 440.0), (1.0, 1.0), "D", extra=[M(108.97, 194.32, 40.0)])
    secE = section(dwg, plan, M(0.0, 0.0, 40.0), (330.0, 185.0), (1.0, 1.0), "E")
    dumpv("sh2_plan", plan)
    dumpv("sh2_secD", secD)
    dumpv("sh2_secE", secE)
    # detail F (4:1): boss B5 (nub in pocket, screw holes) + pin P2, both on the cut of D-D
    YF = -97.7            # nub and pin symmetric about the detail centre (+-45 mm on the sheet)
    detF = N("detF", lambda: detail(dwg, secD, (Y45, YF, 40.5), (Y45, YF + 20.0, 40.5), (592.0, 446.0), (4.0, 1.0), "F",
                                    on_parent="Circle"))
    if detF is not None:
        # parent label: circle only (NX puts a leader label inside the section); letter F written next to the
        # circle, outside the part (top right of the circle, beyond the side wall)
        fc = xy(secD, (Y45, YF, 40.5))
        res["info"]["letter_F_on_D"] = [round(fc[0] + 22.0, 2), round(fc[1] + 19.0, 2)]
        N("letter_F_on_D", lambda: nxd.note(dwg, ["F"], (fc[0] + 22.0, fc[1] + 19.0), size=7.0))
    # detail G (10:1): parting line on the side wall of D-D - rim of the outer at Z 34.76, lip of the inner at 35.32
    rim = N("rim_line", lambda: max(lines(secD, lambda a, b: abs(a[2] - 34.76) < 0.02 and abs(b[2] - 34.76) < 0.02 and abs(a[1] - b[1]) > 0.1, "OUT"),
                                    key=lambda cp: 0.5 * (cp[1][0][1] + cp[1][1][1])))
    res["info"]["rim_lines_D"] = [[[round(t, 3) for t in q] for q in p[:2]] for c, p in
                                  lines(secD, lambda a, b: abs(a[2] - 34.76) < 0.02 and abs(b[2] - 34.76) < 0.02, "OUT")]
    res["info"]["lip_lines_D"] = [[[round(t, 3) for t in q] for q in p[:2]] for c, p in
                                  lines(secD, lambda a, b: abs(a[2] - 35.32) < 0.02 and abs(b[2] - 35.32) < 0.02, "INN")]
    detG = None
    YG = None
    if rim is not None:
        rp = rim[1]
        YG = 0.5 * (rp[0][1] + rp[1][1])
        XG = rp[0][0]
        res["info"]["G_centre"] = [XG, YG]
        detG = N("detG", lambda: detail(dwg, secD, (XG, YG, 35.6), (XG, YG + 3.2, 35.6), (760.0, 462.0), (10.0, 1.0), "G"))
    for v, L in ((secD, "D"), (secE, "E"), (detF, "F"), (detG, "G")):
        if v is None:
            continue
        got = view_letter(v)
        if got != L:
            res["info"]["relabel_" + L] = N("relabel_" + L, lambda v=v, L=L: relabel(v, L))
            got = view_letter(v)
        res["info"]["label_" + L] = got
    res["hatch"] = {}
    for v, L in ((secD, "D"), (secE, "E"), (detF, "F"), (detG, "G")):
        if v is not None:
            res["hatch"][L] = N("hatch_" + L, lambda v=v: restyle_hatches(v))
    res["tb2"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (plan 1:2, F 4:1, G 10:1)", 2, 2, rev="A", subtitle="assembly")

    # --- section E-E (knee axis, model y = 0): both datum B features coaxial on one centre line
    e_b = border(secE)
    ex = lambda Yd, Z: xy(secE, (0.0, Yd, Z))   # noqa: E731
    dimc("D19_90_H7_inner_B", secE, vline(secE, -9.95, 80.02, 93.0, "INN"), vline(secE, 9.95, 80.02, 93.0, "INN"),
         (ex(0.0, 0.0)[0] + 22.0, e_b[3] + 9.0), "cylindrical", 19.9, tol="H7")
    dimc("D110_H7_outer_B", secE, vline(secE, -55.0, -4.12, 0.0, "OUT"), vline(secE, 55.0, -4.12, 0.0, "OUT"),
         (ex(0.0, 0.0)[0] - 30.0, ex(0.0, 18.0)[1]), "cylindrical", 110.0, tol="H7")

    # --- detail F: nub in pocket (B5), screw holes, pin P2 in its hole
    if detF is not None:
        fb2 = border(detF)
        fcx, fcy, frr = 0.5 * (fb2[0] + fb2[2]), 0.5 * (fb2[1] + fb2[3]), 0.5 * (fb2[2] - fb2[0])
        fp = lambda Yd, Z: xy(detF, (Y45, Yd, Z))   # noqa: E731
        yb, yp = -86.45, -108.97
        nub_x, pin_x = fp(yb, 40.0)[0], fp(yp, 40.0)[0]
        nub_side = -1.0 if nub_x < pin_x else 1.0
        dimc("D10_nub_pocket", detF, vline(detF, yb - 5.0, 36.07, 39.17), vline(detF, yb + 5.0, 36.07, 39.17),
             (nub_x - 56.0, fb2[1] - 10.0), "cylindrical", 10.0)
        dimc("D5_20_outer_hole", detF, vline(detF, yb - 2.6, 27.04, 39.04, "OUT"), vline(detF, yb + 2.6, 27.04, 39.04, "OUT"),
             (nub_x - 44.0, fb2[1] - 24.0), "cylindrical", 5.2)
        dimc("D10_40_cbore", detF, vline(detF, yb - 5.2, 44.87, 88.5, "INN"), vline(detF, yb + 5.2, 44.87, 88.5, "INN"),
             (nub_x, fb2[3] + 10.0), "cylindrical", 10.4)
        dimc("D4_pin", detF, vline(detF, yp - 2.0, 34.76, 45.32), vline(detF, yp + 2.0, 34.76, 45.32),
             (pin_x, fb2[3] + 10.0), "cylindrical", 4.0)
        dimc("G_nub_pocket_0_13", detF, hline(detF, 39.04, yb - 5.0, yb - 2.6, "OUT"), hline(detF, 39.17, yb - 5.0, yb - 3.0, "INN"),
             (fcx + nub_side * (frr + 12.0), fp(yb, 39.17)[1] + 13.0), "vertical", 0.13, etol=0.01)
        dimc("G_pin_top_hole_3_34", detF, hline(detF, 41.98, yp - 2.0, yp + 2.0, "OUT"), hline(detF, 45.32, yp - 2.0, yp + 2.0, "INN"),
             (fcx - nub_side * (frr + 12.0), fp(yp, 45.32)[1] + 13.0), "vertical", 3.34, etol=0.01)

    # --- detail G: shadow gap rim / lip and tongue / rebate
    if detG is not None:
        gb = border(detG)
        gcx, grr = 0.5 * (gb[0] + gb[2]), 0.5 * (gb[2] - gb[0])
        gp = lambda Yd, Z: xy(detG, (XG, Yd, Z))   # noqa: E731
        dimc("GAP_rim_lip_0_56", detG, hline(detG, 34.76, YG - 3.3, YG + 3.3, "OUT"), hline(detG, 35.32, YG - 3.3, YG + 3.3, "INN"),
             (gb[2] + 11.0, gp(YG, 35.32)[1] - 25.0), "vertical", 0.56, etol=0.01)
        dimc("GAP_tongue_rebate_0_12", detG, hline(detG, 36.07, YG - 3.3, YG + 3.3, "OUT"), hline(detG, 36.19, YG - 3.3, YG + 3.3, "INN"),
             (gb[2] + 25.0, gp(YG, 36.19)[1] + 13.0), "vertical", 0.12, etol=0.01)

    # --- balloons on D-D: 2 above the inner's top-most point, 1 left of the outer's left-most point
    balloon("2_D", "2", secD, "INN", lambda s: s[1], lambda s, bd: (s[0] + 14.0, bd[3] + 7.0))
    balloon("1_D", "1", secD, "OUT", lambda s: -(s[0] + s[1]), lambda s, bd: (s[0] - 11.0, s[1] - 11.0))

    # --- interface table + notes
    rows = [["MATING INTERFACE, LT-INN-001 ON LT-OUT-001 (Z IN MODEL FRAME)", "", "", ""],
            ["FACE PAIR", "LT-OUT-001", "LT-INN-001", "GAP"],
            ["BOSS FACES 7X = DATUM A OF BOTH", "Z 36.07", "Z 36.07", "CONTACT"],
            ["RIM / LIP, SHADOW GAP ALL ROUND (DETAIL G)", "Z 34.76", "Z 35.32", "0.56"],
            ["TONGUE / REBATE FLOOR (DETAIL G)", "Z 36.07", "Z 36.19", "0.12"],
            ["NUB TOP / POCKET FLOOR 7X (DETAIL F)", "Z 39.04", "Z 39.17", "0.13"],
            ["PIN P3 BASE / LUG FACE", "Z 36.24", "Z 36.36", "0.12"],
            ["21 CONCENTRIC PAIRS (NUB, PIN, HOLE, BOSS): OFFSET", "", "", "0.00 mm"],
            ["INTERFERENCE (STEP AP242, OPENCASCADE)", "", "", "NONE"]]
    res["table2"] = N("table2", lambda: table((470.0, 318.0), [150.0, 34.0, 34.0, 30.0], rows, size=3.5, merge_title=True))
    note_lines(["NOTES",
                "1. 7X BOSS JOINT: LT-INN-001 %s6.0 THRU, %s10.40 C'BORE FROM OUTSIDE," % (DIA, DIA),
                "    ON LT-OUT-001 %s5.2 HOLE. NO SCREW IS DEFINED IN THE CAD:" % DIA,
                "    FASTENERS BY CUSTOMER.",
                "2. KNEE (SECTION E-E): DATUM B OF LT-OUT-001 (%s110.00 H7) AND" % DIA,
                "    DATUM B OF LT-INN-001 (%s19.90 H7) ARE ON ONE AXIS (MODEL Z AXIS)." % DIA,
                "3. HATCH: LT-OUT-001 45%s WIDE, LT-INN-001 135%s CLOSE." % (DEG, DEG),
                "4. VIEW LETTERS D-G; A, B, C ARE THE DATUM LETTERS OF THE PARTS."], 470.0, 226.0, step=8.5)
    res["overlaps2"] = nxd.overlaps(sh2)

    res["views"] = {v.Name: nxd.view_info(v) for v in list(sh1.GetDraftingViews()) + list(sh2.GetDraftingViews())}
    sheets = [sh1, sh2]
    res["export"] = ptdwg.export(dwg, sheets, OUTD, NO)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
try:
    res["cad_mtime_after"] = {os.path.basename(f): os.path.getmtime(f) for f in CAD_FILES}
    res["cad_untouched"] = res["cad_mtime_after"] == res["cad_mtime_before"]
except Exception:  # noqa: BLE001
    pass
nxh.write_json(os.path.join(OUTD, "dwg_result.json"), res)
