# -*- coding: utf-8 -*-
"""Probe for LT-ASM-001 drawing: assembly structure, knee-axis cylinders of both bodies, section-view API
(hinge / orientation of a cut placed to the right of the parent), hatch objects + style API.
args: <assembly prt> <out_dir>"""
import json
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\nx\dwglib")
import NXOpen  # noqa: E402
import NXOpen.Annotations  # noqa: E402
import NXOpen.Drawings  # noqa: E402
import nxh  # noqa: E402


def _save(part):   # never save the referenced assembly / components
    part.Save(NXOpen.BasePart.SaveComponents.FalseValue, NXOpen.BasePart.CloseAfterSave.FalseValue).Dispose()


nxh.save = _save
import nxd  # noqa: E402
import nxd2  # noqa: E402
import ptdwg  # noqa: E402
import m3d  # noqa: E402

ASM, OUTD = sys.argv[1], sys.argv[2]
os.makedirs(OUTD, exist_ok=True)
R = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]]
res = {"result": "FAIL", "errors": {}}
m3d.start(res)


def M(x, y, z):
    return (y, -x, z)


def pub(o):
    return [n for n in dir(o) if not n.startswith("_")]


try:
    dwg, comp = m3d.new_drawing(os.path.join(OUTD, "probe_dwg.prt"), ASM, "LT-ASM-001", R, refset="Entire Part")
    res["asm_refset"] = comp.ReferenceSet
    res["asm_refsets"] = [r.Name for r in comp.Prototype.GetAllReferenceSets()]
    kids = comp.GetChildren()
    res["children"] = []
    bodies = {}
    for k in kids:
        p = k.Prototype
        if not p.IsFullyLoaded:
            p.LoadThisPartFully().Dispose()
        sol = [b for b in p.Bodies if b.IsSolidBody]
        occ = [k.FindOccurrence(b) for b in sol]
        res["children"].append({"name": k.Name, "disp": k.DisplayName, "refset": k.ReferenceSet, "full": p.IsFullyLoaded,
                                "bodies": [b.Name for b in sol], "occ": [o is not None for o in occ],
                                "occ_bbox": [nxh.bbox(o) for o in occ if o is not None],
                                "proto_bbox": [nxh.bbox(b) for b in sol]})
        bodies[k.Name] = (k, sol[0])
    # cylinders on the knee axis (proto coords = model frame) and around B5 / P2
    def cyl_census(body, test):
        out = []
        for f in body.GetFaces():
            t, pt, d, rad = nxh.face_data(f)
            if t != 16:
                continue
            if test(pt, d):
                bb = nxh.bbox(f)
                try:
                    nd = nxh.UFS.Modeling.AskFaceData(f.Tag)[6]
                except Exception:  # noqa: BLE001
                    nd = None
                out.append({"r": round(abs(rad), 4), "d": round(2 * abs(rad), 3), "pt": [round(v, 3) for v in pt],
                            "dir": [round(v, 3) for v in d], "z": [bb[2], bb[5]], "nd": nd})
        return sorted(out, key=lambda r_: (r_["r"], r_["z"][0]))
    knee = lambda pt, d: abs(abs(d[2]) - 1) < 1e-4 and math.hypot(pt[0], pt[1]) < 0.05   # noqa: E731
    res["knee_cyl"] = {}
    res["b5_cyl"] = {}
    res["p2_cyl"] = {}
    res["b4_cyl"] = {}
    for n, (k, b) in bodies.items():
        res["knee_cyl"][n] = cyl_census(b, knee)
        res["b5_cyl"][n] = cyl_census(b, lambda pt, d: abs(abs(d[2]) - 1) < 1e-4 and math.hypot(pt[0] - 86.45, pt[1] - 165.96) < 0.1)
        res["b4_cyl"][n] = cyl_census(b, lambda pt, d: abs(abs(d[2]) - 1) < 1e-4 and math.hypot(pt[0] + 17.05, pt[1] - 165.91) < 0.1)
        res["p2_cyl"][n] = cyl_census(b, lambda pt, d: abs(abs(d[2]) - 1) < 1e-4 and math.hypot(pt[0] - 108.97, pt[1] - 194.32) < 0.1)
        # planar faces normal +-Z between 33 and 40
        pl = {}
        for f in b.GetFaces():
            t, pt, d, rad = nxh.face_data(f)
            if t == 22 and abs(abs(d[2]) - 1) < 1e-5:
                bb = nxh.bbox(f)
                if abs(bb[2] - bb[5]) < 1e-3 and 30.0 < bb[2] < 45.0:
                    key = "%.2f%s" % (bb[2], "+" if d[2] > 0 else "-")
                    pl[key] = pl.get(key, 0) + 1
        res.setdefault("zplanes", {})[n] = pl

    sh, _g = ptdwg.sheet(dwg, "A1")
    top = nxd.base_view(dwg, dwg, "Top", (230.0, 430.0), scale=(1.0, 1.0))
    res["top"] = nxd.view_info(top)
    SVB = NXOpen.Drawings.SectionViewBuilder
    b = dwg.DraftingViews.CreateSectionViewBuilder(NXOpen.Drawings.SectionView.Null)
    try:
        res["svb"] = pub(b)
        for n in pub(b):
            try:
                o = getattr(b, n)
                if hasattr(o, "__class__") and not callable(o) and type(o).__module__.startswith("NXOpen"):
                    res.setdefault("svb_members", {})[n] = [type(o).__name__, pub(o)[:80]]
            except Exception:  # noqa: BLE001
                pass
        try:
            res["vss"] = pub(b.Style.ViewStyleSection)
        except Exception as e:  # noqa: BLE001
            res["vss_err"] = str(e)
    finally:
        b.Destroy()
    # section placed to the RIGHT of the parent, cut through B4/B5 plane (model y 165.93)
    s1 = m3d.N("s_right", lambda: nxd2.section(dwg, top, M(0.0, 165.93, 40.0), (620.0, 430.0), (1.0, 1.0)))
    if s1 is not None:
        res["s_right"] = nxd.view_info(s1)
        res["s_right_census"] = nxd.visible_census(s1)
    s2 = m3d.N("s_below", lambda: nxd2.section(dwg, top, M(0.0, 0.0, 40.0), (230.0, 170.0), (1.0, 1.0)))
    if s2 is not None:
        res["s_below"] = nxd.view_info(s2)
        res["s_below_census"] = nxd.visible_census(s2)
        hs = [o for o in s2.AskVisibleObjects() if "Hatch" in type(o).__name__]
        res["hatch_types"] = [type(o).__name__ for o in hs]
        if hs:
            res["hatch_pub"] = pub(hs[0])
            hb = None
            for attempt in ("dwg.Annotations.Hatches.CreateHatchBuilder(h)",):
                try:
                    hb = dwg.Annotations.Hatches.CreateHatchBuilder(hs[0])
                    res["hatchbuilder_pub"] = pub(hb)
                    hb.Destroy()
                except Exception as e:  # noqa: BLE001
                    res["hatchbuilder_err"] = str(e)
            rows = []
            for h in hs:
                r_ = {"bbox": None}
                try:
                    r_["bbox"] = [round(v, 2) for v in nxh.bbox(h)]
                except Exception as e:  # noqa: BLE001
                    r_["bbox_err"] = str(e)[:100]
                for a in ("Angle", "Distance", "PatternName", "HatchAngle", "HatchDistance"):
                    try:
                        r_[a] = str(getattr(h, a))
                    except Exception:  # noqa: BLE001
                        pass
                rows.append(r_)
            res["hatches"] = rows
        res["ann_pub"] = [n for n in pub(dwg.Annotations) if "atch" in n]
    res["overlaps"] = nxd.overlaps(sh)
    _save(dwg)
    res["pdf"] = nxd.export_pdf(dwg, [sh], os.path.join(OUTD, "probe.pdf"))
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUTD, "probe_result.json"), res)
