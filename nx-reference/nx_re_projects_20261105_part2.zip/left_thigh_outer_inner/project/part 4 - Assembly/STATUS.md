# LT-ASM-001 Rev B (LT-OUT-001 Rev C + LT-INN-001 Rev B) - status

Built 2026-10-31. **Nothing sent to the client.** Rev A (below) is kept unchanged in `deliver/` and its zip.

## Inputs (frozen copies in `src_revB/`, md5-checked against the part packages)
- Outer: `part 1\deliver_RevC\CAD\` (Rev C after the rim fix REVC_RIM_RABBET + REVC_PAD_WALL_BACK_0P15, 390 272.46 mm3).
- Inner: `part 2 - Inner\deliver_RevB\CAD\` (Rev B second issue 13:42: boss-1 lip re-fit + hip-end foot raised to 36.19,
  338 011.75 mm3).

## Fit gate (`an/fit_check.py` -> `work/fit_revB2_AP242.json`, summary `an/fit_summary.py`)
- History: Rev C (first) vs inner Rev A 17.94 mm3 (rim stretch filled to 36.07). Rim rabbet fix -> 1.52 mm3. User chose
  "fix the inner" for the remaining hip-end -X stretch -> inner re-issued.
- Final: 0 of 600 000 inner samples inside the outer (min signed -0.004), boolean common 0.0007 mm3 = two hair-line
  slivers (`an/locate_common.py`, `work/common_revB.txt`): 0.0006 mm3 at X -34.9..-34.1, Y 276.8..278.7 (corner of the
  inner trim) and 0.000054 mm3 at X -42.85..-42.59, Y 240.57, Z 36.008..36.07. NX SimpleInterference reports the latter:
  InterferenceExists 5.4e-5 (Rev A: OnlyEdgesOrFacesInterfere).
- 29 coaxial pairs, all offset 0.00 except E1 / E2 pins in S1 / S2 slots 0.03 / 0.02 (radial clear 0.12 / 0.13,
  tip-floor 0.22) and the pin boss Ø9.37 vs pin 0.074 (not a fit).
- Joint planes unchanged: rim 34.76 / lip 35.32, tongue 36.07 / rebate 36.19, nub 39.04 / pocket 39.17, P3 36.24 / 36.36.

## NX assembly (`nx/build_asm.py <cad> <json> B C B`, run `nx/asmB1`): PASS
- `deliver_RevB/CAD/LT-ASM-001_Left_Thigh_Assembly.prt`, both components at origin, identity, ref set SOLID,
  occurrence volumes = part volumes. Attributes REVISION B, description with part revisions.
- STEP AP214 + AP242; AP242 root renamed from `..._AP242` (6 strings). Re-read (`an/stepasm_check.py`,
  `work/revB/*_check.json`): 1 assembly, 2 parts, 1 valid solid each, translation 0, identity.
- STL of both bodies: 962 546 triangles. Renders (`an/renders.py`) in `deliver_RevB/Renders`.

## Drawing (`nx/dwg_asm.py`, Rev A copy `nx/dwg_asm_revA.py`; final run `work/dwgB4`)
- Rev B, date 2026-10-31 (`ptdwg.DATE` set in the script), parts list LT-OUT-001 REV C / LT-INN-001 REV B, masses
  1.05 / 0.91 / 1.97 kg, overall read back 355.65 x 186.96 x 151.69 (exact OCP 355.65 x 187.01 x 151.70: silhouette).
- Interface table: + hip pins E1/E2 rows, 29 coaxial pairs max 0.07, interference 0.0007 mm3; note 5 = revision note.
- Trap: a cell text starting with "<" is dropped by NX (showed a stray symbol); long cell text wraps and the row grows
  into the notes below - the overlap check does not see it, check by eye.

## Package (`an/package.py B`)
- `LT-ASM-001_RevB_Left_Thigh_Assembly.zip`, README `deliver_RevB/README.md`, `CLIENT_MESSAGE_RevB.txt`.

---

# LT-ASM-001 Rev A (Left Thigh assembly: LT-OUT-001 Rev A + LT-INN-001 Rev A) - status

Started 2026-10-30. Nothing sent to the client. Parts 1-3 are read-only for this folder.

## Inputs (copied to `src/`, untouched)
- Outer: `part 1\deliver\CAD\` (Rev A, 2026-10-25). NOT deliver_RevB (Rev B cancelled).
- Inner: `part 2 - Inner\deliver\CAD\` (runK10, first Rev A, restored 2026-10-30). Nothing from `_fixround_2026-10-30`.

## Milestones
- [x] **Fit check on the two AP242 files** (`part 2 - Inner\an\i50_fit.py`, `work/fit_AP242.json`): interference **0.0 mm3**,
  min distance 0.0, **21 concentric pairs, max offset 0.0**, 0 of 24 621 joint-band points inside the outer; planes: outer rim
  34.76 / inner lip 35.32 (**0.56 gap**), boss faces 36.07 = 36.07, tongue 36.07 / rebate 36.19, pin base 36.24 / P3 lug 36.36,
  nub tops 39.04 / pocket floors 39.17. Volumes inner 335 391.6, outer 386 005.7 (AP242).
- [x] **NX assembly** (`nx/build_asm.py`, run `nx/asm1`): `deliver/CAD/LT-ASM-001_Left_Thigh_Assembly.prt`, components
  `LT-OUT-001` / `LT-INN-001` at origin (0,0,0), identity matrix, reference set SOLID, no constraints (designed in place);
  component prts copied next to it (unchanged). Occurrence bbox / volume = part values (outer 385 942.89, inner 335 388.90).
  NX SimpleInterference: OnlyEdgesOrFacesInterfere (boss faces touch), min distance 0.0.
- [x] **Assembly STEP** AP214 + AP242 (same journal). Re-read with OCP XCAF (`an/stepasm_check.py`, `work/*_check.json`):
  1 assembly `LT-ASM-001_Left_Thigh_Assembly`, 2 parts `LT-OUT-001_Left_Thigh_Outer` / `LT-INN-001_Left_Thigh_Inner`, 1 valid
  solid each, translation 0, identity rotation; volumes AP214 385 876.5 / 335 348.3, AP242 386 005.7 / 335 391.6 = the part
  STEP files. The NX AP242 writer names the root product after the output FILE (`..._AP242`): renamed in the file text to
  `LT-ASM-001_Left_Thigh_Assembly` (6 strings) and re-read OK.
- [x] **STL**: per part (copies) + `LT-ASM-001_Left_Thigh_Assembly.stl` (both bodies, 961 826 triangles).
- [x] **Renders** (`an/renders.py`): outside x2, hip end, side, exploded (+110 Z), open sides; outer blue, inner grey.
- [x] **Drawing** LT-ASM-001 (2 x A1, third angle; `nx/dwg_asm.py`, final run `work/dwg_run4`, notes `work/dwg_notes.md`,
  library copy `nx/dwglib`): PASS, 0 errors, 0 overlaps, 13 dims read back (L 355.25, W 186.71, H 151.69 [exact OCP bbox
  151.70: silhouette pick], Ø19.90 H7 inner B, Ø110.00 H7 outer B, Ø10.00, Ø5.20, Ø10.40, Ø4.00, gaps 0.13 / 3.34 / 0.56 / 0.12).
  SH1 plan / front / side + iso, parts list, balloons 1-2, 3 notes. SH2 key plan 1:2, stepped section D-D (B4/B5 + P2),
  section E-E (knee axis), detail F 4:1, detail G 10:1, interface table, 4 notes (fasteners by customer). Letters D-G
  (A-C are the parts' datums). Hatch outer 45 deg / 3.5, inner 135 deg / 2.0. Exploded view skipped (NX explosion API not
  verified; renders carry an exploded view). Checked by eye whole + zoom (lead): text in white space, balloons outside with
  arrows, leaders short / not crossing; D-D thick-wall look confirmed real by a mesh section (`an/sec_check.py`, `work/sec_Y165.png`).
- [x] README (`deliver/README.md`), `CLIENT_MESSAGE.txt`, package `an/package.py` -> `LT-ASM-001_RevA_Left_Thigh_Assembly.zip`
  (26 entries, 75.8 MB, testzip OK). **Package ready, NOT sent.**
