# LT-ASM-001 Rev B: Left Thigh Assembly (LT-OUT-001 Rev C + LT-INN-001 Rev B)

The outer shell LT-OUT-001 and the inner shell LT-INN-001 mounted together, as one assembly. It shows that the two
parts were modelled and drawn to fit each other. Both parts were reverse-engineered in Siemens NX 2206 in **one shared
coordinate system**, so they assemble exactly as modelled: both components sit at the origin, with no moving, aligning
or constraints.

Rev B replaces Rev A. It carries the current revisions of both parts: LT-OUT-001 Rev C and LT-INN-001 Rev B.

## Components

| Item | Part number | Revision | Description | Material | Qty | Volume | Mass |
|---|---|---|---|---|---|---|---|
| 1 | LT-OUT-001 | C | Left thigh, outer shell | Al 6061-T6 | 1 | 390 272 mm³ | 1.05 kg |
| 2 | LT-INN-001 | B | Left thigh, inner shell | Al 6061-T6 | 1 | 338 012 mm³ | 0.91 kg |
| | | | **Assembly** | | | | **1.97 kg** |

The parts themselves (part drawings, deviation reports, all formats) are in their own packages,
`LT-OUT-001_RevC_Left_Thigh_Outer.zip` and `LT-INN-001_RevB_Left_Thigh_Inner.zip`. The CAD files of both parts in this
package are the same files.

## What changed from Rev A

- **Parts:** LT-OUT-001 Rev A → Rev C, and LT-INN-001 Rev A → Rev B. The parts' own READMEs list every change.
- **New pin / slot pair at the hip end:** the two Ø4.0 pins E1 / E2 of the inner shell sit in the two Ø4.30 slots
  S1 / S2 of the outer shell, at X 27.03 / 49.02, Y 271.70.
- **Hip-end rim, -X wall:** the outer shell has a 1.3 mm wide rabbet at Z 34.76 under the inner lip. Where the inner
  lip sits over the outer's Z 36.07 surface, it is raised to Z 36.19 (0.12 mm gap).
- **Overall size (drawing SH1):** now 355.65 x 186.96 x 151.69 (Rev A 355.25 x 186.71 x 151.69). The length grows by 0.40 because the outer's knee hub is now
  Ø136.5 (Rev A Ø135.7). That band is below the parting plane (Z 10 to 34.76) and does not touch the inner shell.
- **Assembly drawing:** revision B; the parts list, overall sizes and the interface table are updated. The table has
  2 new rows for the hip pins.

## Contents

| Folder / file | What it is |
|---|---|
| `CAD/LT-ASM-001_Left_Thigh_Assembly_AP214.step` | Assembly STEP AP214 with its product structure: assembly LT-ASM-001 with the two parts LT-OUT-001 and LT-INN-001. Opens as an assembly in SolidWorks, Fusion 360, Inventor, Creo, etc. |
| `CAD/LT-ASM-001_Left_Thigh_Assembly_AP242.step` | The same assembly in STEP AP242 |
| `CAD/LT-ASM-001_Left_Thigh_Assembly.prt` | Native NX assembly. It loads the two component parts below from the same folder: keep the three .prt files together |
| `CAD/LT-OUT-001_Left_Thigh_Outer.prt`, `CAD/LT-INN-001_Left_Thigh_Inner.prt` | The NX component parts (outer Rev C, inner Rev B, full feature history, reference set `SOLID`) |
| `CAD/LT-ASM-001_Left_Thigh_Assembly.stl` | Both parts in one STL, in the assembly frame (for viewing) |
| `CAD/LT-OUT-001_Left_Thigh_Outer.stl`, `CAD/LT-INN-001_Left_Thigh_Inner.stl` | One STL per part, same frame |
| `Drawings/LT-ASM-001.pdf` | Assembly drawing, 2 x A1, third-angle projection, revision B. SH1 general arrangement: assembled top, front and side views, isometric, overall dimensions, parts list, balloons 1 and 2. SH2 mating interface: stepped section D-D through bosses B4 / B5 and pin P2, section E-E through the knee axis (datum B of both parts on one axis: LT-OUT-001 Ø110.00 H7, LT-INN-001 Ø19.90 H7), detail F 4:1 (Ø10 nub in its pocket; Ø4 pin in its hole; screw holes), detail G 10:1 (parting line gap), interface table and notes. Outer and inner have different hatching |
| `Drawings/LT-ASM-001_SH1..2.pdf`, `_SH1..2.dwg` | The same sheets, one PDF and one DWG per sheet |
| `Drawings/LT-ASM-001_dwg.prt` | Native NX drawing (master-model, associative to the assembly in `CAD/`) |
| `Renders/` | Shaded views, outer shell blue, inner shell grey: outside from both sides, hip end, side, exploded, and the two open sides |

## Coordinate system (shared by both parts)

- Origin: on the knee axis, at the knee floor plane of LT-OUT-001.
- +Z: the knee axis, pointing from the outer shell towards the inner shell.
- +Y: the direction of the hip-ring axis (knee → hip). The hip-ring axis is the line X = 37.97, Z = 35.18.
- Units: mm.

## Fit check

The two STEP AP242 files were read with OpenCascade, independently of NX:

- **No penetration:** none of 600 000 points sampled on the inner surface lies inside the outer (worst
  -0.004 mm, which is meshing noise).
- **Interference:** the boolean common of the two solids is 0.0007 mm³ in total. It is two hair-line touch zones at
  the hip-end rim, each thinner than 0.06 mm. NX's interference check on the assembly reports the same, 0.00005 mm³.
- **Contact:** bearing contact on the 7 boss faces (Z 36.07, datum A of both parts), face to face; minimum distance 0.0 mm.
- **Mating features aligned (29 coaxial pairs):**
  - 7 Ø10 locating nubs of LT-OUT-001 in the 7 Ø10 pockets of LT-INN-001, offset 0.00.
  - 3 Ø4 pins in the 3 Ø4 pin holes, offset 0.00.
  - 7 boss screw holes (inner Ø6 on outer Ø5.2), offset 0.00.
  - The boss columns Ø15, offset 0.00.
  - The knee ring Ø135.7 and the hip ring Ø105.25, offset 0.00.
  - Hip pins E1 / E2 Ø4.0 in slots S1 / S2 Ø4.30, offset 0.02 / 0.03, radial clearance 0.12 / 0.13, and 0.22
    between pin tip and slot floor.
- **Parting line:** the inner lip face (Z 35.32) stays 0.56 mm above the outer rim (Z 34.76). The rebate floor is
  0.12 mm over the tongue, and the pocket floors are 0.13 mm over the nub tops.
- **Assembly STEP re-read:** one assembly, two parts, one valid solid each, both placed at the origin without
  rotation, volumes equal to the part files.

## Notes

1. **Fasteners.** The CAD shows 7 boss joints: LT-INN-001 Ø6.0 through with a Ø10.40 counterbore from the outside, on a
   Ø5.2 hole in LT-OUT-001. No screw is defined in the CAD: fasteners by customer.
2. **Use the revisions together.** The hip pins of LT-INN-001 Rev B need the slots of LT-OUT-001 Rev C. With the
   outer Rev A, the pins collide with the hip ring.
3. **Projection.** The drawings are third angle (ASME), as the part drawings.
