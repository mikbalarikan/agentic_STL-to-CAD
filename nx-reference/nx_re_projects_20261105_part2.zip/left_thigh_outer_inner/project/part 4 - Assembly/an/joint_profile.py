"""Joint-band profile across the wall at a list of stations: for each station line (fixed Y, X range, or fixed X, Y range)
sample every 0.05 mm: inner bottom Z (first inner hit going up from Z 30) and outer top Z (first outer hit going down
from Z 40). Reports the outer tongue outside face (rim 34.76 -> top >= 35.8), the inner step face (lip 35.32 -> >= 35.8),
the required step move (+0.2 clearance) and the rebate floor vs tongue top.
usage: joint_profile.py inner.stl outer.stl stations.json out.json
stations: [{"name","fix":"y"|"x","at":v,"from":a,"to":b,"lip_side":"-"|"+"}]  lip_side = side of the wall where the lip is"""
import sys, json
import numpy as np, open3d as o3d


def scene(p):
    m = o3d.io.read_triangle_mesh(p); sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m)); return sc


def cast(sc, P, d):
    r = np.zeros((len(P), 6), np.float32); r[:, :3] = P; r[:, 3:] = d
    return sc.cast_rays(o3d.core.Tensor(r))["t_hit"].numpy()


si, so = scene(sys.argv[1]), scene(sys.argv[2])
S = json.load(open(sys.argv[3])); res = []
for s in S:
    t = np.arange(s["from"], s["to"], 0.05)
    P = np.zeros((len(t), 3), np.float32)
    if s["fix"] == "y":
        P[:, 0] = t; P[:, 1] = s["at"]
    else:
        P[:, 1] = t; P[:, 0] = s["at"]
    P[:, 2] = 30.0; ti = cast(si, P, [0, 0, 1]); zi = np.where(np.isfinite(ti) & (ti < 10), 30 + ti, np.nan)
    P[:, 2] = 40.0; to = cast(so, P, [0, 0, -1]); zo = np.where(np.isfinite(to) & (to < 10), 40 - to, np.nan)
    tongue = (zo > 35.5); lip = (np.abs(zi - 35.32) < 0.02)
    ov = np.nan_to_num(zo - zi, nan=-9)
    clash = ov > 0.005
    r = dict(name=s["name"], fix=s["fix"], at=s["at"])
    if tongue.any():
        r["tongue_span"] = [round(float(t[tongue].min()), 2), round(float(t[tongue].max()), 2)]
        r["tongue_top"] = round(float(np.nanmedian(zo[tongue])), 3)
    if clash.any():
        r["clash_span"] = [round(float(t[clash].min()), 2), round(float(t[clash].max()), 2)]
        r["clash_max"] = round(float(ov.max()), 3)
        r["clash_width"] = round(float(clash.sum() * 0.05), 2)
    zz = zi[np.isfinite(zi)]
    r["inner_levels"] = sorted(set(np.round(zz, 2).tolist()))[:12] if len(zz) else []
    # where is the inner's rebate (bottom >= 35.8) along the line
    reb = zi >= 35.8
    if reb.any():
        r["inner_high_span"] = [round(float(t[reb].min()), 2), round(float(t[reb].max()), 2)]
    res.append(r); print(r)
json.dump(res, open(sys.argv[4], "w"), indent=1)
