"""Vertical material stacks of inner and outer at given XY points (mesh ray casting), overlap per point, and an exact
B-rep classification of the overlap mid-point against both STEP solids.
usage: zstack.py inner.stl outer.stl inner.step outer.step pts.json out.json
pts.json: {"label": [[x, y], ...], ...}"""
import sys, json
import numpy as np, open3d as o3d
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.gp import gp_Pnt
from OCP.TopAbs import TopAbs_IN, TopAbs_ON


def read(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()


def hits(sc, x, y):
    zs = []; z0 = -200.0
    for _ in range(60):
        r = o3d.core.Tensor([[x, y, z0, 0, 0, 1]], dtype=o3d.core.Dtype.Float32)
        t = sc.cast_rays(r)["t_hit"].numpy()[0]
        if not np.isfinite(t):
            break
        z = z0 + float(t); zs.append(round(z, 3)); z0 = z + 1e-3
    return zs


def intervals(zs):
    return [(zs[i], zs[i + 1]) for i in range(0, len(zs) - 1, 2)]


def scene(p):
    m = o3d.io.read_triangle_mesh(p); sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m)); return sc


si, so = scene(sys.argv[1]), scene(sys.argv[2])
I, O = read(sys.argv[3]), read(sys.argv[4])
P = json.load(open(sys.argv[5])); res = {}


def cls(s, p):
    c = BRepClass3d_SolidClassifier(s, gp_Pnt(*p), 1e-5); st = c.State()
    return "IN" if st == TopAbs_IN else "ON" if st == TopAbs_ON else "OUT"


for lab, pts in P.items():
    res[lab] = []
    for x, y in pts:
        a, b = intervals(hits(si, x, y)), intervals(hits(so, x, y))
        ov = []
        for p in a:
            for q in b:
                lo, hi = max(p[0], q[0]), min(p[1], q[1])
                if hi - lo > 0.005:
                    m = (x, y, (lo + hi) / 2)
                    ov.append(dict(z=[lo, hi], t=round(hi - lo, 3), exact_inner=cls(I, m), exact_outer=cls(O, m)))
        # nearest vertical gap between inner bottom faces and outer top faces near the joint (z 25..45)
        gaps = [round(p[0] - q[1], 3) for p in a for q in b if 20 < p[0] < 50 and -0.01 < p[0] - q[1] < 3]
        r = dict(xy=[x, y], inner=a, outer=b, overlap=ov, joint_gaps=gaps)
        res[lab].append(r)
        print(lab, (x, y), "inner", [p for p in a if p[1] > 20 and p[0] < 95], "outer", [q for q in b if q[1] > 20], "OV", ov, "gap", gaps)
json.dump(res, open(sys.argv[6], "w"), indent=1)
