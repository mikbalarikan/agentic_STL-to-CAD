"""Two-way signed distance between two STL meshes: samples of A inside B and samples of B inside A,
clustered (single-linkage, 3 mm) and summarised per cluster (count, bbox, max depth).
usage: twoway_sd.py inner.stl outer.stl out.json [n=800000] [thr=0.02]"""
import sys, json
import numpy as np, open3d as o3d
from scipy.sparse.csgraph import connected_components
from scipy.spatial import cKDTree


def scene(m):
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m)); return sc


def clusters(p, d, link=3.0):
    if len(p) == 0:
        return []
    t = cKDTree(p); pairs = t.query_pairs(link, output_type="ndarray")
    from scipy.sparse import coo_matrix
    n = len(p); A = coo_matrix((np.ones(len(pairs)), (pairs[:, 0], pairs[:, 1])), shape=(n, n))
    k, lab = connected_components(A, directed=False)
    out = []
    for c in range(k):
        m = lab == c; q = p[m]
        out.append(dict(n=int(m.sum()), max_depth=round(float(-d[m].min()), 3), p50_depth=round(float(np.median(-d[m])), 3),
                        bbox=[round(float(v), 2) for v in np.r_[q.min(0), q.max(0)]],
                        deepest_at=[round(float(v), 2) for v in q[np.argmin(d[m])]]))
    return sorted(out, key=lambda c: -c["n"])


a, b, oj = sys.argv[1:4]
n = int(sys.argv[4]) if len(sys.argv) > 4 else 800000
thr = float(sys.argv[5]) if len(sys.argv) > 5 else 0.02
np.random.seed(1)
ma, mb = o3d.io.read_triangle_mesh(a), o3d.io.read_triangle_mesh(b)
res = {}
for nm, src, dst in (("inner_in_outer", ma, mb), ("outer_in_inner", mb, ma)):
    sc = scene(dst)
    pts = np.asarray(src.sample_points_uniformly(n).points).astype(np.float32)
    sd = sc.compute_signed_distance(o3d.core.Tensor(pts)).numpy()
    m = sd < -thr
    cl = clusters(pts[m].astype(float), sd[m])
    res[nm] = dict(samples=n, inside=int(m.sum()), min_sd=round(float(sd.min()), 4), clusters=cl)
    print(nm, "inside", int(m.sum()), "min", round(float(sd.min()), 3), "clusters", len(cl))
    for c in cl[:25]:
        print("   ", c)
json.dump(res, open(oj, "w"), indent=1)
