"""Mesh section of both parts at model Y = y (X horizontal, Z vertical): independent check of the drawing sections.
usage: sec_check.py y out.png"""
import sys
import trimesh
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

y = float(sys.argv[1]); out = sys.argv[2]
fig, ax = plt.subplots(figsize=(10, 9))
for f, c in (("src/outer/LT-OUT-001_Left_Thigh_Outer.stl", "tab:blue"), ("src/inner/LT-INN-001_Left_Thigh_Inner.stl", "dimgray")):
    m = trimesh.load(f)
    s = m.section(plane_origin=[0, y, 0], plane_normal=[0, 1, 0])
    n = 0
    for loop in s.discrete:
        ax.plot(loop[:, 0], loop[:, 2], color=c, lw=1.0); n += 1
    print(f, "loops", n)
ax.set_aspect("equal"); ax.grid(True); ax.set_title(f"mesh section Y={y} (X horizontal, Z vertical); blue outer, grey inner")
fig.savefig(out, dpi=80)
