"""Zoomed mesh sections of inner + outer (+ optional second outer) for a list of section specs.
usage: sec_multi.py inner.stl outer.stl spec.json outdir [third.stl [third_label]]
spec: [{"name": "S1", "axis": "y"|"x", "at": v, "lim": [h0, h1, z0, z1], "lines": [z...], "title": "..."}]
Plot axes: axis y -> (X, Z); axis x -> (Y, Z). Filled: outer blue, inner red (alpha) so overlaps show purple."""
import sys, json, os
import numpy as np, trimesh, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

inn, out, spec, od = sys.argv[1:5]
out2 = sys.argv[5] if len(sys.argv) > 5 else None
lab2 = sys.argv[6] if len(sys.argv) > 6 else "outer2"
os.makedirs(od, exist_ok=True)
M = {"inner": trimesh.load(inn), "outer": trimesh.load(out)}
if out2:
    M["outer2"] = trimesh.load(out2)
S = json.load(open(spec))
sty = {"outer": ("#1f5fd6", 0.30), "inner": ("#d62f1f", 0.30), "outer2": ("#18a050", 0.0)}
for s in S:
    ax_i = 1 if s["axis"] == "y" else 0
    n = [0, 0, 0]; n[ax_i] = 1; o = [0, 0, 0]; o[ax_i] = s["at"]
    h = 0 if s["axis"] == "y" else 1
    fig, ax = plt.subplots(figsize=(9, 6))
    for nm, m in M.items():
        sec = m.section(plane_origin=o, plane_normal=n)
        if sec is None:
            continue
        col, al = sty[nm]; first = True
        for e in sec.discrete:
            ax.plot(e[:, h], e[:, 2], color=col, lw=1.2 if nm != "outer2" else 1.0, ls="-" if nm != "outer2" else "--",
                    label=(lab2 if nm == "outer2" else nm) if first else None)
            if al > 0 and len(e) > 2:
                ax.add_patch(Polygon(np.c_[e[:, h], e[:, 2]], closed=True, fc=col, alpha=al, ec="none"))
            first = False
    for z in s.get("lines", []):
        ax.axhline(z, ls=":", lw=0.7, c="k"); ax.text(s["lim"][1], z, f" {z}", fontsize=7, va="center")
    ax.set_xlim(s["lim"][0], s["lim"][1]); ax.set_ylim(s["lim"][2], s["lim"][3]); ax.set_aspect("equal"); ax.grid(alpha=.3)
    ax.set_xlabel("X" if h == 0 else "Y"); ax.set_ylabel("Z"); ax.legend(loc="best", fontsize=8)
    ax.set_title(f'{s["name"]}: section {s["axis"].upper()} = {s["at"]}  {s.get("title", "")}', fontsize=9)
    plt.tight_layout(); plt.savefig(os.path.join(od, f'sec_{s["name"]}.png'), dpi=110); plt.close(fig)
    print("wrote", s["name"])
