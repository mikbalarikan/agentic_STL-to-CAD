"""Print the gate summary of fit_check.py results. usage: fit_summary.py fit1.json [fit2.json ...]"""
import json, sys
for f in sys.argv[1:]:
    d = json.load(open(f))
    print("=====", f, "| interf", d["interference_mm3"], "| min dist", d["min_distance"], "| inside", d["inner_points_inside_outer"],
          "| min sd", d["min_signed_mm"], "| vol", d["volumes"], "| valid", d["valid"])
    print(" hist", d["gap_hist_mm"])
    print(" planes", [(p["side"][:5], p["z"], p["area"]) for p in d["joint_planes"]])
    P = [p for p in d["coaxial_pairs"] if p["offset"] < 0.1 and p["axial_overlap"] > 0.3 and min(p["inner_D"], p["outer_D"]) >= 2]
    print(" mating pairs", len(P), "max offset", max([p["offset"] for p in P], default=None))
    for p in P:
        print("  ", p["inner_D"], "H" if p["inner_hole"] else "S", p["outer_D"], "H" if p["outer_hole"] else "S", p["axis"], p["at"],
              "off", p["offset"], "ovl", p["axial_overlap"], "rc", p["radial_clear"])
    for z in d.get("inside_zones", [])[:25]:
        print("  INSIDE", z)
