"""Per-cluster anatomy of the boolean common of inner and outer STEP solids.
For each common solid: volume, bbox, and every face with its surface type / parameters and whether it lies on the
inner boundary (I), on the outer boundary (O) or on both (IO = coincident contact face).
usage: clash_faces.py inner.step outer.step out.json [common.brep]"""
import sys, json, os
import numpy as np
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE, TopAbs_REVERSED
from OCP.TopoDS import TopoDS, TopoDS_Shape
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Plane, GeomAbs_Cylinder, GeomAbs_Cone, GeomAbs_BSplineSurface, GeomAbs_Torus
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
from OCP.BRepTools import BRepTools
from OCP.BRep import BRep_Builder
from OCP.gp import gp_Pnt


def read(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()


def vol(s):
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g); return g.Mass()


def bbox(s):
    bb = Bnd_Box(); BRepBndLib.Add_s(s, bb); return [round(v, 3) for v in bb.Get()]


def it(s, T):
    e = TopExp_Explorer(s, T)
    while e.More():
        yield e.Current(); e.Next()


def dist(p, shp):
    v = BRepBuilderAPI_MakeVertex(gp_Pnt(*p)).Vertex()
    d = BRepExtrema_DistShapeShape(v, shp); d.Perform(); return d.Value()


def desc(f):
    a = BRepAdaptor_Surface(f); t = a.GetType()
    if t == GeomAbs_Plane:
        n = a.Plane().Axis().Direction(); o = a.Plane().Location()
        return dict(t="plane", n=[round(n.X(), 3), round(n.Y(), 3), round(n.Z(), 3)], z=round(o.Z(), 3) if abs(abs(n.Z()) - 1) < 1e-6 else None)
    if t == GeomAbs_Cylinder:
        c = a.Cylinder(); ax = c.Axis(); d = ax.Direction(); o = ax.Location()
        return dict(t="cyl", D=round(2 * c.Radius(), 3), axis=[round(d.X(), 3), round(d.Y(), 3), round(d.Z(), 3)],
                    o=[round(o.X(), 2), round(o.Y(), 2), round(o.Z(), 2)])
    if t == GeomAbs_Cone:
        return dict(t="cone")
    if t == GeomAbs_Torus:
        return dict(t="torus", R=round(a.Torus().MajorRadius(), 2), r=round(a.Torus().MinorRadius(), 2))
    if t == GeomAbs_BSplineSurface:
        return dict(t="bspline")
    return dict(t=str(t))


inn_p, out_p, out_json = sys.argv[1:4]
brep = sys.argv[4] if len(sys.argv) > 4 else None
inn, out = read(inn_p), read(out_p)
if brep and os.path.exists(brep):
    s = TopoDS_Shape(); BRepTools.Read_s(s, brep, BRep_Builder())
else:
    c = BRepAlgoAPI_Common(inn, out); c.Build(); s = c.Shape()
    if brep:
        BRepTools.Write_s(s, brep)
res = dict(total=round(vol(s), 4), clusters=[])
for k, so in enumerate(it(s, TopAbs_SOLID)):
    so = TopoDS.Solid_s(so)
    cl = dict(id=k, vol=round(vol(so), 4), bbox=bbox(so), faces=[])
    for f in it(so, TopAbs_FACE):
        f = TopoDS.Face_s(f)
        g = GProp_GProps(); BRepGProp.SurfaceProperties_s(f, g); A = g.Mass()
        if A < 1e-3:
            continue
        cpt = g.CentreOfMass(); p = (cpt.X(), cpt.Y(), cpt.Z())
        # a centroid of a curved face may lie off the face: use the face's own point projection via distance to face
        di, do = dist(p, inn), dist(p, out)
        side = ("I" if di < 0.01 else "") + ("O" if do < 0.01 else "")
        fd = desc(f); fd.update(area=round(A, 3), at=[round(v, 2) for v in p], side=side or f"?({di:.3f},{do:.3f})",
                                bb=bbox(f))
        cl["faces"].append(fd)
    cl["faces"].sort(key=lambda d: -d["area"])
    res["clusters"].append(cl)
    print(k, cl["vol"], cl["bbox"])
    for fd in cl["faces"][:14]:
        print("   ", fd["side"], fd["t"], {kk: fd[kk] for kk in ("z", "D", "o", "axis", "n") if kk in fd and fd[kk] is not None}, "A", fd["area"], "bb", fd["bb"])
json.dump(res, open(out_json, "w"), indent=1)
