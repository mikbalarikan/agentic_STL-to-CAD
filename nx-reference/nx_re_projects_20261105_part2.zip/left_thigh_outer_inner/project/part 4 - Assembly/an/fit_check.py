"""Fit check INNER vs OUTER from their STEP files (OpenCascade, independent of NX). General version of
part 2 - Inner/an/i50_fit.py: any cylinder axis, any diameter pair, whole-part gap map.
usage: fit_check.py inner.step outer.step inner.stl outer.stl out.json
- interference: volume of the boolean common, min distance between the solids
- joint planes: inner planar faces facing -Z vs outer facing +Z, 34 < z < 40
- coaxial pairs: every inner / outer cylindrical face pair with parallel axes and axis-to-axis distance < 1.0 mm
  (radial clearance = (D_bigger - D_smaller)/2 - offset, for the pin-in-hole sense)
- gap map: inner surface samples, signed distance to the outer mesh (- = inside the outer solid)"""
import sys, json, math
import numpy as np
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE, TopAbs_REVERSED, TopAbs_SOLID
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Plane, GeomAbs_Cylinder
from OCP.BRepCheck import BRepCheck_Analyzer


def read(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()


def vol(s):
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g); return g.Mass()


def faces(s):
    e = TopExp_Explorer(s, TopAbs_FACE)
    while e.More():
        yield TopoDS.Face_s(e.Current()); e.Next()


def nsolids(s):
    e, n = TopExp_Explorer(s, TopAbs_SOLID), 0
    while e.More():
        n += 1; e.Next()
    return n


def census(s):
    planes, cyls = [], []
    for f in faces(s):
        a = BRepAdaptor_Surface(f)
        t = a.GetType()
        if t == GeomAbs_Plane:
            n = a.Plane().Axis().Direction(); o = a.Plane().Location()
            nz = n.Z() * (-1 if f.Orientation() == TopAbs_REVERSED else 1)
            if abs(abs(n.Z()) - 1) < 1e-6:
                g = GProp_GProps(); BRepGProp.SurfaceProperties_s(f, g)
                planes.append(dict(z=round(o.Z(), 3), nz=round(nz), area=g.Mass()))
        elif t == GeomAbs_Cylinder:
            cy = a.Cylinder(); ax = cy.Axis(); d = ax.Direction(); o = ax.Location()
            dv = np.array([d.X(), d.Y(), d.Z()]); ov = np.array([o.X(), o.Y(), o.Z()])
            v0, v1 = a.FirstVParameter(), a.LastVParameter()
            cyls.append(dict(o=ov, d=dv, D=2 * cy.Radius(), span=(ov + dv * v0, ov + dv * v1),
                             hole=f.Orientation() == TopAbs_REVERSED))
    return planes, cyls


def axis_offset(a, b):
    """distance from b's span midpoint to a's axis line"""
    m = (b["span"][0] + b["span"][1]) / 2
    w = m - a["o"]
    return float(np.linalg.norm(w - np.dot(w, a["d"]) * a["d"]))


inn_p, out_p, inn_stl, out_stl, out_json = sys.argv[1:6]
inn, out = read(inn_p), read(out_p)
res = {"inputs": dict(inner=inn_p, outer=out_p)}
res["valid"] = dict(inner=BRepCheck_Analyzer(inn).IsValid(), outer=BRepCheck_Analyzer(out).IsValid(),
                    inner_solids=nsolids(inn), outer_solids=nsolids(out))
res["volumes"] = dict(inner=round(vol(inn), 1), outer=round(vol(out), 1))
com = BRepAlgoAPI_Common(inn, out); com.Build()
res["interference_mm3"] = round(vol(com.Shape()), 4) if com.IsDone() else "common failed"
dss = BRepExtrema_DistShapeShape(inn, out); dss.Perform()
res["min_distance"] = round(dss.Value(), 4) if dss.IsDone() else None
pi, ci = census(inn); po, co = census(out)
lv = {}
for p, side, sgn in [(p, "inner -Z", -1) for p in pi] + [(p, "outer +Z", 1) for p in po]:
    if 34 < p["z"] < 40 and p["nz"] == sgn:
        lv[(side, p["z"])] = lv.get((side, p["z"]), 0.0) + p["area"]
res["joint_planes"] = [dict(side=k[0], z=k[1], area=round(v, 1)) for k, v in sorted(lv.items(), key=lambda t: (t[0][1], t[0][0]))]
pairs, seen = [], set()
for c in ci:
    for o in co:
        if abs(abs(float(np.dot(c["d"], o["d"]))) - 1) > 1e-4:
            continue
        off = axis_offset(o, c)
        if off > 1.0:
            continue
        # axial overlap of the two face spans along the shared axis
        t = lambda p: float(np.dot(p - o["o"], o["d"]))
        a0, a1 = sorted(map(t, c["span"])); b0, b1 = sorted(map(t, o["span"]))
        ov = min(a1, b1) - max(a0, b0)
        mid = (c["span"][0] + c["span"][1]) / 2
        key = (round(c["D"], 3), round(o["D"], 3), tuple(np.round(mid, 1)))
        if key in seen:
            continue
        seen.add(key)
        dax = c["d"] if c["d"][np.argmax(abs(c["d"]))] > 0 else -c["d"]
        pairs.append(dict(inner_D=round(c["D"], 3), inner_hole=c["hole"], outer_D=round(o["D"], 3), outer_hole=o["hole"],
                          axis=[round(float(v), 4) for v in dax], at=[round(float(v), 2) for v in mid],
                          offset=round(off, 4), axial_overlap=round(ov, 2),
                          radial_clear=round(abs(c["D"] - o["D"]) / 2 - off, 3)))
pairs.sort(key=lambda p: (p["axis"], p["at"]))
res["coaxial_pairs"] = pairs
res["coaxial_max_offset"] = max([p["offset"] for p in pairs], default=None)
import open3d as o3d
mi = o3d.io.read_triangle_mesh(inn_stl); mo = o3d.io.read_triangle_mesh(out_stl)
mo.remove_duplicated_vertices()
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mo))
pts = np.asarray(mi.sample_points_uniformly(600000).points).astype(np.float32)
sd = sc.compute_signed_distance(o3d.core.Tensor(pts)).numpy()
res["gap_samples"] = int(len(sd))
res["inner_points_inside_outer"] = int((sd < -0.02).sum())
res["min_signed_mm"] = round(float(sd.min()), 4)
res["gap_hist_mm"] = {f"{a:.2f}..{b:.2f}": int(((sd >= a) & (sd < b)).sum()) for a, b in
                      ((-99, -0.02), (-0.02, 0.02), (0.02, 0.15), (0.15, 0.3), (0.3, 0.5), (0.5, 1.0), (1.0, 999))}
bad = pts[sd < -0.02]
if len(bad):
    # cluster the inside points on a 5 mm grid so each clash zone is reported once
    cells = {}
    for p, d in zip(bad, sd[sd < -0.02]):
        k = tuple((p // 5).astype(int))
        if k not in cells or d < cells[k][1]:
            cells[k] = (p, float(d))
    res["inside_zones"] = sorted([dict(at=[round(float(v), 1) for v in p], depth=round(-d, 3)) for p, d in cells.values()],
                                 key=lambda z: -z["depth"])[:40]
json.dump(res, open(out_json, "w"), indent=1)
print(json.dumps({k: v for k, v in res.items() if k not in ("coaxial_pairs", "inside_zones")}, indent=1))
print("coaxial pairs", len(pairs), "max offset", res["coaxial_max_offset"])
for p in pairs:
    print(p)
for z in res.get("inside_zones", [])[:15]:
    print("INSIDE", z)
