"""Re-test the mesh 'inside' points exactly: inner STL samples with signed distance < -0.02 to the outer STL,
classified against the outer STEP solid (BRepClass3d) and their exact distance to the inner / outer B-rep.
usage: probe_clash.py inner.stl outer.stl outer.step inner.step"""
import sys, numpy as np, open3d as o3d
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
from OCP.gp import gp_Pnt
from OCP.TopAbs import TopAbs_IN, TopAbs_ON, TopAbs_OUT
def read(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()
mi = o3d.io.read_triangle_mesh(sys.argv[1]); mo = o3d.io.read_triangle_mesh(sys.argv[2])
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mo))
np.random.seed(0)
pts = np.asarray(mi.sample_points_uniformly(600000).points).astype(np.float32)
sd = sc.compute_signed_distance(o3d.core.Tensor(pts)).numpy()
bad = pts[sd < -0.02]; bsd = sd[sd < -0.02]
print("mesh-inside points", len(bad))
out = read(sys.argv[3]); inn = read(sys.argv[4])
cnt = {"IN": 0, "ON": 0, "OUT": 0}
rows = []
for p, d in zip(bad, bsd):
    q = gp_Pnt(*map(float, p))
    c = BRepClass3d_SolidClassifier(out, q, 1e-4); st = c.State()
    k = "IN" if st == TopAbs_IN else "ON" if st == TopAbs_ON else "OUT"
    cnt[k] += 1
    v = BRepBuilderAPI_MakeVertex(q).Vertex()
    dO = BRepExtrema_DistShapeShape(v, out); dO.Perform()
    dI = BRepExtrema_DistShapeShape(v, inn); dI.Perform()
    rows.append((k, round(float(d), 3), round(dO.Value(), 3), round(dI.Value(), 3), [round(float(x), 2) for x in p]))
print(cnt)
rows.sort(key=lambda r: r[1])
for r in rows[:25]:
    print(r)
