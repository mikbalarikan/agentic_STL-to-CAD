"""Rev E delivery packages (inner and assembly), same layout as part 1\an\f7_package.py:
<TOP>/<NO>_RevE/{CAD, Deviation Report | Fit Check Report, Drawings, Renders}, no README, then the zip and a testzip.
usage: e7_package.py inner|asm"""
import os, shutil, sys, zipfile

ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"
JOBS = {"inner": (os.path.join(ROOT, "part 2 - Inner"), "deliver_RevE_fit", "LT-INN-001", "Left_Thigh_Inner", "Deviation Report"),
        "asm": (os.path.join(ROOT, "part 4 - Assembly"), "deliver_RevE", "LT-ASM-001", "Left_Thigh_Assembly", "Fit Check Report")}
P, src_dir, NO, NAME, QA = JOBS[sys.argv[1]]
SRC = os.path.join(P, src_dir)
TOP = NO + "_RevE_" + NAME
PKG = os.path.join(P, TOP, NO + "_RevE")
ZIP = os.path.join(P, TOP + ".zip")
if os.path.exists(os.path.join(P, TOP)):
    shutil.rmtree(os.path.join(P, TOP))
os.makedirs(PKG)
MAP = {"CAD": ("CAD", lambda n: not n.startswith("_") and n.endswith((".prt", ".step", ".x_t", ".stl"))),
       QA: ("QA", lambda n: n.endswith((".pdf", ".png"))),
       "Drawings": ("Drawings", lambda n: n.endswith((".pdf", ".dwg", ".prt"))),
       "Renders": ("Renders", lambda n: n.endswith(".png"))}
n = 0
for dst, (src, ok) in MAP.items():
    os.makedirs(os.path.join(PKG, dst))
    files = [f for f in sorted(os.listdir(os.path.join(SRC, src))) if ok(f)]
    assert files, "nothing in " + src
    for f in files:
        shutil.copy2(os.path.join(SRC, src, f), os.path.join(PKG, dst, f)); n += 1
if os.path.exists(ZIP):
    os.remove(ZIP)
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(os.path.join(P, TOP)):
        rel = os.path.relpath(root, P)
        z.write(root, rel + "/")
        for f in sorted(files):
            z.write(os.path.join(root, f), os.path.join(rel, f))
with zipfile.ZipFile(ZIP) as z:
    bad = z.testzip()
    names = z.namelist()
assert not any(x.lower().endswith((".md", ".txt", ".json", ".log")) for x in names), "internal file in zip"
print("files", n, "zip entries", len(names), "testzip", bad or "OK", "size MB", round(os.path.getsize(ZIP) / 1e6, 1))
for x in names:
    print("  ", x)
