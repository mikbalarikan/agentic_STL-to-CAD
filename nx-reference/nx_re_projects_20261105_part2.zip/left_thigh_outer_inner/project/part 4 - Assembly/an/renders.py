"""LT-ASM-001 renders: outer (blue) + inner (grey) in the shared frame; outside, open / hip side, exploded.
Same look as the part renders (pyvista, white background). usage: renders.py outer.stl inner.stl out_dir"""
import sys, os
import numpy as np
import pyvista as pv

so, si, out = sys.argv[1:4]
os.makedirs(out, exist_ok=True)
mo, mi = pv.read(so), pv.read(si)
BLUE, GREY = "#6f8fb0", "#c9ced3"
EXPLODE = 110.0  # inner lifted along +Z (the joint direction) for the exploded view


def shot(meshes, name, d, up, dist=1.0, size=(2000, 1500)):
    p = pv.Plotter(off_screen=True, window_size=size)
    p.set_background("white")
    for mesh, col in meshes:
        p.add_mesh(mesh, color=col, smooth_shading=True, specular=0.35, specular_power=20, ambient=0.18, diffuse=0.8)
    allp = np.vstack([np.asarray(mm.points) for mm, _ in meshes])
    c = 0.5 * (allp.min(0) + allp.max(0))
    R = np.linalg.norm(allp.max(0) - allp.min(0))
    d = np.array(d, float); d /= np.linalg.norm(d)
    p.camera_position = [tuple(c + d * R * 1.75 * dist), tuple(c), tuple(up)]
    p.camera.view_angle = 28
    p.enable_anti_aliasing("ssaa")
    p.screenshot(os.path.join(out, name)); p.close()


N = "LT-ASM-001"
shot([(mo, BLUE), (mi, GREY)], f"{N}_outside_inner_side.png", (1, -1, 0.9), (0, 0, 1))
shot([(mo, BLUE), (mi, GREY)], f"{N}_outside_outer_side.png", (1, -1, -0.9), (0, 0, -1))
shot([(mo, BLUE), (mi, GREY)], f"{N}_hip_end.png", (-0.6, 1, 0.35), (0, 0, 1))
shot([(mo, BLUE), (mi, GREY)], f"{N}_side_px.png", (1, 0, 0.12), (0, 0, 1))
me = mi.translate((0.0, 0.0, EXPLODE), inplace=False)
shot([(mo, BLUE), (me, GREY)], f"{N}_exploded.png", (1, -1.1, 0.75), (0, 0, 1), dist=1.05)
# open sides facing each other: outer seen from +Z (its open side), inner seen from -Z (its open side), side by side
mi_flip = mi.rotate_y(180.0, point=(37.97, 0.0, 35.7), inplace=False).translate((210.0, 0.0, 0.0), inplace=False)
shot([(mo, BLUE), (mi_flip, GREY)], f"{N}_open_sides.png", (0.35, -0.55, 1), (0, 1, 0), dist=0.95)
print("renders ok")
