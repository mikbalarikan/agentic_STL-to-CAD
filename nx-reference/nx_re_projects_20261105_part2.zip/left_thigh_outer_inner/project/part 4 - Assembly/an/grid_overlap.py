"""Robust interference volume of two closed meshes by vertical ray stacks on an XY grid (no boolean needed).
For every grid cell the material Z-intervals of A and B are found by repeated ray casting; their overlap length times
the cell area is the interference volume. Overlap cells are clustered in 2D (8-connected) and reported with volume,
bbox, max / median thickness and Z range. Also returns the near-contact map (vertical gap 0..gap_max between a B top
and an A bottom) for the joint check.
usage: grid_overlap.py A.stl B.stl out.json [step=0.25] [png]"""
import sys, json
import numpy as np, open3d as o3d
from scipy import ndimage


def stacks(path, X, Y, zmin=-100.0, nmax=24):
    m = o3d.io.read_triangle_mesh(path)
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
    n = X.size; z0 = np.full(n, zmin, np.float32); H = np.full((n, nmax), np.nan, np.float32); alive = np.ones(n, bool)
    for k in range(nmax):
        idx = np.nonzero(alive)[0]
        if not len(idx):
            break
        r = np.zeros((len(idx), 6), np.float32); r[:, 0] = X[idx]; r[:, 1] = Y[idx]; r[:, 2] = z0[idx]; r[:, 5] = 1
        t = sc.cast_rays(o3d.core.Tensor(r))["t_hit"].numpy()
        ok = np.isfinite(t); hit = idx[ok]
        H[hit, k] = z0[hit] + t[ok]; z0[hit] = H[hit, k] + 2e-4; alive[idx[~ok]] = False
    return H


def overlap(HA, HB):
    n = HA.shape[0]; ov = np.zeros(n); lo = np.full(n, np.nan); hi = np.full(n, np.nan)
    for i in range(0, HA.shape[1] - 1, 2):
        a0, a1 = HA[:, i], HA[:, i + 1]
        for j in range(0, HB.shape[1] - 1, 2):
            b0, b1 = HB[:, j], HB[:, j + 1]
            l = np.maximum(a0, b0); h = np.minimum(a1, b1); d = np.nan_to_num(h - l, nan=0.0); d[d < 0] = 0
            upd = d > 0
            ov += d; lo = np.where(upd, np.fmin(lo, l), lo); hi = np.where(upd, np.fmax(hi, h), hi)
    return ov, lo, hi


a, b, oj = sys.argv[1:4]
st = float(sys.argv[4]) if len(sys.argv) > 4 else 0.25
png = sys.argv[5] if len(sys.argv) > 5 else None
xs = np.arange(-70, 121, st) + st / 2; ys = np.arange(-70, 290, st) + st / 2
GX, GY = np.meshgrid(xs, ys, indexing="ij"); X, Y = GX.ravel().astype(np.float32), GY.ravel().astype(np.float32)
HA, HB = stacks(a, X, Y), stacks(b, X, Y)
ov, lo, hi = overlap(HA, HB)
OV = ov.reshape(GX.shape); thr = 0.01
lab, k = ndimage.label(OV > thr, structure=np.ones((3, 3)))
cl = []
for c in range(1, k + 1):
    m = lab == c; v = float(OV[m].sum() * st * st)
    ii, jj = np.nonzero(m); L = lo.reshape(GX.shape)[m]; Hh = hi.reshape(GX.shape)[m]
    t = OV[m]; mi = np.argmax(t)
    cl.append(dict(vol=round(v, 3), cells=int(m.sum()), bbox=[round(float(xs[ii.min()] - st / 2), 2), round(float(ys[jj.min()] - st / 2), 2),
                   round(float(np.nanmin(L)), 3), round(float(xs[ii.max()] + st / 2), 2), round(float(ys[jj.max()] + st / 2), 2),
                   round(float(np.nanmax(Hh)), 3)], t_max=round(float(t.max()), 3), t_p50=round(float(np.median(t)), 3),
                   at_max=[round(float(xs[ii[mi]]), 2), round(float(ys[jj[mi]]), 2)]))
cl.sort(key=lambda c: -c["vol"])
res = dict(A=a, B=b, step=st, total_mm3=round(float(OV.sum() * st * st), 3), n_clusters=len(cl), clusters=cl)
json.dump(res, open(oj, "w"), indent=1)
print("total", res["total_mm3"], "clusters", len(cl))
for c in cl[:30]:
    print("  ", c)
if png:
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(8, 13))
    AnyA = np.isfinite(HA[:, 0]).reshape(GX.shape); AnyB = np.isfinite(HB[:, 0]).reshape(GX.shape)
    ax.imshow(np.where(AnyB, 0.85, 1.0).T, origin="lower", extent=[xs[0], xs[-1], ys[0], ys[-1]], cmap="gray", vmin=0, vmax=1)
    ax.contour(GX, GY, AnyA.astype(float), levels=[0.5], colors="#999999", linewidths=0.4)
    O = np.ma.masked_less_equal(OV, thr)
    im = ax.imshow(O.T, origin="lower", extent=[xs[0], xs[-1], ys[0], ys[-1]], cmap="autumn_r", vmin=0, vmax=max(1.0, float(OV.max())))
    for i, c in enumerate(cl[:20]):
        bb = c["bbox"]; ax.add_patch(plt.Rectangle((bb[0], bb[1]), bb[3] - bb[0], bb[4] - bb[1], fill=False, ec="k", lw=0.6))
        ax.text(bb[3] + 1, bb[4], f"K{i + 1} {c['vol']:.1f}", fontsize=7)
    plt.colorbar(im, ax=ax, shrink=0.5, label="overlap thickness mm")
    ax.set_title(f"interference map (vertical stacks), total {res['total_mm3']:.1f} mm3", fontsize=9)
    ax.set_xlabel("X"); ax.set_ylabel("Y"); plt.tight_layout(); plt.savefig(png, dpi=120)
