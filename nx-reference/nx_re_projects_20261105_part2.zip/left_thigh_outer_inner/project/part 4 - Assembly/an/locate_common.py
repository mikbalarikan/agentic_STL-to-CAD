"""Where is the boolean common of two STEP solids: each piece's volume, bbox and thickness (min bbox side).
usage: locate_common.py a.step b.step"""
import sys
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
def read(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()
def vol(s):
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g); return g.Mass()
a, b = read(sys.argv[1]), read(sys.argv[2])
c = BRepAlgoAPI_Common(a, b); c.Build(); s = c.Shape()
print("common volume", vol(s))
for T, nm in ((TopAbs_SOLID, "solid"), (TopAbs_FACE, "face")):
    e = TopExp_Explorer(s, T); n = 0
    while e.More():
        x = e.Current(); bb = Bnd_Box(); BRepBndLib.Add_s(x, bb); q = [round(v, 3) for v in bb.Get()]
        if n < 40: print(nm, n, "vol" if T == TopAbs_SOLID else "", round(vol(x), 6) if T == TopAbs_SOLID else "", q,
                         "thick", round(min(q[3] - q[0], q[4] - q[1], q[5] - q[2]), 4))
        n += 1; e.Next()
    print(nm, "count", n)
