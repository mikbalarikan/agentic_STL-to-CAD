"""Exact (optimal, no gap) bounding box of every solid in a STEP file, in the file frame.
usage: exact_bbox.py file.step"""
import sys
from OCP.STEPControl import STEPControl_Reader
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

r = STEPControl_Reader()
r.ReadFile(sys.argv[1])
r.TransferRoots()
sh = r.OneShape()
e = TopExp_Explorer(sh, TopAbs_SOLID)
allb = Bnd_Box()
i = 0
while e.More():
    b = Bnd_Box()
    BRepBndLib.AddOptimal_s(e.Current(), b, False, False)
    b.SetGap(0.0)
    print("solid", i, [round(v, 3) for v in b.Get()])
    BRepBndLib.AddOptimal_s(e.Current(), allb, False, False)
    i += 1
    e.Next()
allb.SetGap(0.0)
x0, y0, z0, x1, y1, z1 = allb.Get()
print("all", [round(v, 3) for v in (x0, y0, z0, x1, y1, z1)], "size", round(x1 - x0, 3), round(y1 - y0, 3), round(z1 - z0, 3))
