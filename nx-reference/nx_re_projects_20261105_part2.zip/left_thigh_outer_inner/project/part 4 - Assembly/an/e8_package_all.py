"""One final zip for the Left Thigh: assembly Rev E + outer Rev F + inner Rev E, each with its own CAD / report / drawings /
renders, no README. Staging folder and zip at the project root: LT-ASM-001_RevE_Left_Thigh_Assembly(.zip).
usage: e8_package_all.py"""
import os, shutil, zipfile

ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"
TOP = "LT-ASM-001_RevE_Left_Thigh_Assembly"
STAGE = os.path.join(ROOT, TOP)
ZIP = STAGE + ".zip"
CAD = lambda n: not n.startswith("_") and n.endswith((".prt", ".step", ".x_t", ".stl"))
PDFPNG = lambda n: n.endswith((".pdf", ".png"))
DWG = lambda n: n.endswith((".pdf", ".dwg", ".prt"))
PNG = lambda n: n.endswith(".png")
PARTS = [("01_LT-ASM-001_RevE_Assembly", os.path.join(ROOT, "part 4 - Assembly", "deliver_RevE2"), "Fit Check Report"),
         ("02_LT-OUT-001_RevF_Outer", os.path.join(ROOT, "part 1", "deliver_RevF"), "Deviation Report"),
         ("03_LT-INN-001_RevE_Inner", os.path.join(ROOT, "part 2 - Inner", "deliver_RevE2"), "Deviation Report")]
if os.path.exists(STAGE):
    shutil.rmtree(STAGE)
n = 0
for name, src, qa in PARTS:
    for dst, sub, ok in (("CAD", "CAD", CAD), (qa, "QA", PDFPNG), ("Drawings", "Drawings", DWG), ("Renders", "Renders", PNG)):
        files = [f for f in sorted(os.listdir(os.path.join(src, sub))) if ok(f)]
        assert files, "nothing in " + os.path.join(src, sub)
        os.makedirs(os.path.join(STAGE, name, dst))
        for f in files:
            shutil.copy2(os.path.join(src, sub, f), os.path.join(STAGE, name, dst, f)); n += 1
if os.path.exists(ZIP):
    os.remove(ZIP)
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
    for root, dirs, files in os.walk(STAGE):
        dirs.sort()
        rel = os.path.relpath(root, ROOT)
        z.write(root, rel + "/")
        for f in sorted(files):
            z.write(os.path.join(root, f), os.path.join(rel, f))
with zipfile.ZipFile(ZIP) as z:
    bad = z.testzip()
    names = z.namelist()
assert not any(x.lower().endswith((".md", ".txt", ".json", ".log")) for x in names), "internal file in zip"
print("files", n, "zip entries", len(names), "testzip", bad or "OK", "size MB", round(os.path.getsize(ZIP) / 1e6, 1))
for x in names:
    print("  ", x)
