"""Rasterise a PDF (every page) at dpi and cut each page into tiles.
python raster.py <pdf> <out_dir> [dpi=200] [cols=3] [rows=2]"""
import os
import sys

import fitz

pdf, out = sys.argv[1], sys.argv[2]
dpi = int(sys.argv[3]) if len(sys.argv) > 3 else 200
cols = int(sys.argv[4]) if len(sys.argv) > 4 else 3
rows = int(sys.argv[5]) if len(sys.argv) > 5 else 2
os.makedirs(out, exist_ok=True)
d = fitz.open(pdf)
for i, p in enumerate(d, 1):
    p.get_pixmap(dpi=70).save(os.path.join(out, "p%d_whole.png" % i))
    r = p.rect
    w, h = r.width / cols, r.height / rows
    for a in range(rows):
        for b in range(cols):
            clip = fitz.Rect(r.x0 + b * w, r.y0 + a * h, r.x0 + (b + 1) * w, r.y0 + (a + 1) * h)
            p.get_pixmap(dpi=dpi, clip=clip).save(os.path.join(out, "p%d_r%dc%d.png" % (i, a, b)))
print("ok", len(d))
