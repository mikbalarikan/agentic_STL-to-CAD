"""Re-read an assembly STEP with OCP XCAF: product tree (names), instance placements, solids per part, volume,
bbox, centre of mass and validity in the assembly frame. usage: stepasm_check.py file.step [file2.step ...] -> prints + json next to it"""
import sys, json, os
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence, TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.IFSelect import IFSelect_RetDone
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib


def name(lab):
    a = TDataStd_Name()
    return a.Get().ToExtString() if lab.FindAttribute(TDataStd_Name.GetID_s(), a) else ""


def solids(shape):
    out, e = [], TopExp_Explorer(shape, TopAbs_SOLID)
    while e.More():
        out.append(e.Current()); e.Next()
    return out


def props(shape):
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(shape, g)
    b = Bnd_Box(); BRepBndLib.Add_s(shape, b, True)
    c = g.CentreOfMass()
    PROPS_COM[0] = [round(c.X(), 3), round(c.Y(), 3), round(c.Z(), 3)]
    return round(g.Mass(), 1), [round(v, 2) for v in b.Get()], BRepCheck_Analyzer(shape).IsValid()


PROPS_COM = [None]


for path in sys.argv[1:]:
    doc = TDocStd_Document(TCollection_ExtendedString("doc"))
    r = STEPCAFControl_Reader(); r.SetNameMode(True)
    assert r.ReadFile(path) == IFSelect_RetDone, path
    r.Transfer(doc)
    st = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    free = TDF_LabelSequence(); st.GetFreeShapes(free)
    res = {"file": os.path.basename(path), "roots": []}

    def walk(lab, depth):
        node = {"name": name(lab), "assembly": st.IsAssembly_s(lab), "children": []}
        if st.IsAssembly_s(lab):
            comps = TDF_LabelSequence(); st.GetComponents_s(lab, comps)
            for i in range(1, comps.Length() + 1):
                c = comps.Value(i)
                ref = TDF_Label(); st.GetReferredShape_s(c, ref)
                loc = st.GetLocation_s(c).Transformation()
                t = loc.TranslationPart()
                child = walk(ref, depth + 1)
                child["instance"] = name(c)
                child["translation"] = [round(t.X(), 6), round(t.Y(), 6), round(t.Z(), 6)]
                child["rotation_identity"] = all(abs(loc.Value(a, b) - (1.0 if a == b else 0.0)) < 1e-9 for a in (1, 2, 3) for b in (1, 2, 3))
                sh = st.GetShape_s(c)  # placed shape (assembly frame)
                ss = solids(sh)
                child["solids"] = len(ss)
                if ss:
                    child["volume"], child["bbox"], child["valid"] = props(sh)
                    child["centre_of_mass"] = PROPS_COM[0]
                node["children"].append(child)
        return node

    for i in range(1, free.Length() + 1):
        res["roots"].append(walk(free.Value(i), 0))
    print(json.dumps(res, indent=1))
    json.dump(res, open(path[:-5] + "_check.json", "w"), indent=1)
