"""Which outer change makes the clash: (outer_new - outer_old) solids, and each one's common with the inner.
usage: diff_clash.py outer_old.step outer_new.step inner.step"""
import sys
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut, BRepAlgoAPI_Common
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
def read(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()
def vol(s):
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g); return g.Mass()
def bb(s):
    b = Bnd_Box(); BRepBndLib.Add_s(s, b); return [round(v, 2) for v in b.Get()]
old, new, inn = map(read, sys.argv[1:4])
for name, a, b in (("added (new-old)", new, old), ("removed (old-new)", old, new)):
    c = BRepAlgoAPI_Cut(a, b); c.Build(); s = c.Shape()
    e = TopExp_Explorer(s, TopAbs_SOLID)
    print("==", name)
    while e.More():
        x = e.Current(); v = vol(x)
        if v > 0.5:
            cm = BRepAlgoAPI_Common(x, inn); cm.Build()
            print(f"  vol {v:10.2f}  bbox {bb(x)}  clash_with_inner {vol(cm.Shape()):.3f}")
        e.Next()
cm = BRepAlgoAPI_Common(new, inn); cm.Build(); s = cm.Shape()
e = TopExp_Explorer(s, TopAbs_SOLID)
print("== clash solids (new outer x inner)")
while e.More():
    x = e.Current(); print(f"  vol {vol(x):8.3f} bbox {bb(x)}"); e.Next()
