"""Inner scan evidence at given XY points: all vertical-ray surface hits of the inner scan (moved into the LT-OUT-001
frame with part 2 work/frame.json, then lifted by seat_dz 0.12) inside a Z window, next to the inner Rev E CAD hits.
The scan is open (25k open edges), so hits are listed as surfaces, not paired into material intervals.
usage: scan_probe.py scan.stl frame.json cad.stl pts.json out.json [z0 z1]"""
import sys, json
import numpy as np, open3d as o3d, trimesh


def hits(sc, x, y, z0, z1):
    zs, z = [], z0
    for _ in range(40):
        r = o3d.core.Tensor([[x, y, z, 0, 0, 1]], dtype=o3d.core.Dtype.Float32)
        t = float(sc.cast_rays(r)["t_hit"].numpy()[0])
        if not np.isfinite(t) or z + t > z1:
            break
        z = z + t; zs.append(round(z, 2)); z += 1e-3
    return zs


scan_p, frame_p, cad_p, pts_p, oj = sys.argv[1:6]
z0, z1 = (float(sys.argv[6]), float(sys.argv[7])) if len(sys.argv) > 7 else (25.0, 100.0)
F = json.load(open(frame_p)); R = np.array(F["R"]); o = np.array(F["o"])
m = trimesh.load(scan_p, process=False)
V = (R @ (np.asarray(m.vertices) - o).T).T; V[:, 2] += 0.12
ms = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(V), o3d.utility.Vector3iVector(np.asarray(m.faces)))
ss = o3d.t.geometry.RaycastingScene(); ss.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(ms))
mc = o3d.io.read_triangle_mesh(cad_p); sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mc))
P = json.load(open(pts_p)); res = {}
for lab, pts in P.items():
    res[lab] = []
    for x, y in pts:
        r = dict(xy=[x, y], scan=hits(ss, x, y, z0, z1), cad=hits(sc, x, y, z0, z1)); res[lab].append(r); print(lab, r)
json.dump(res, open(oj, "w"), indent=1)
