"""Package LT-ASM-001 like the part packages:
LT-ASM-001_Rev<R>_Left_Thigh_Assembly/LT-ASM-001_Rev<R>/{CAD, Drawings, Renders} + README.md, and the zip next to it.
usage: package.py [rev=A]   (rev A reads deliver/, other revs deliver_Rev<R>/)"""
import os, sys, shutil, zipfile
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly"
REV = sys.argv[1] if len(sys.argv) > 1 else "A"
D = os.path.join(ROOT, "deliver" if REV == "A" else "deliver_Rev" + REV)
TOP = "LT-ASM-001_Rev%s_Left_Thigh_Assembly" % REV
OUT = os.path.join(ROOT, TOP, "LT-ASM-001_Rev" + REV)
if os.path.exists(os.path.join(ROOT, TOP)):
    shutil.rmtree(os.path.join(ROOT, TOP))
os.makedirs(OUT)
for sub in ("CAD", "Drawings", "Renders"):
    os.makedirs(os.path.join(OUT, sub))
    for f in sorted(os.listdir(os.path.join(D, sub))):
        if f.startswith("_") or f.endswith((".log", ".json")) or os.path.isdir(os.path.join(D, sub, f)):
            continue
        shutil.copy2(os.path.join(D, sub, f), os.path.join(OUT, sub, f))
shutil.copy2(os.path.join(D, "README.md"), os.path.join(OUT, "README.md"))
zp = os.path.join(ROOT, TOP + ".zip")
if os.path.exists(zp):
    os.remove(zp)
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for base, dirs, files in os.walk(os.path.join(ROOT, TOP)):
        rel = os.path.relpath(base, ROOT)
        z.write(base, rel + "/")
        for f in sorted(files):
            z.write(os.path.join(base, f), os.path.join(rel, f))
with zipfile.ZipFile(zp) as z:
    names = z.namelist()
    bad = z.testzip()
print("zip", zp, os.path.getsize(zp), "entries", len(names), "testzip", bad)
for n in names:
    print("  ", n)
