"""Section Y = const through inner + outer A + outer C meshes, zoomed on the hip-end rim clash.
usage: sec_clash.py inner.stl outerA.stl outerC.stl Y out.png [x0 x1 z0 z1]"""
import sys, trimesh, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
inn, oa, oc, Y, png = sys.argv[1], sys.argv[2], sys.argv[3], float(sys.argv[4]), sys.argv[5]
x0, x1, z0, z1 = map(float, sys.argv[6:10]) if len(sys.argv) > 9 else (-52, -20, 20, 50)
fig, ax = plt.subplots(1, 2, figsize=(14, 6))
for k in range(2):
    a = ax[k]
    for f, col, lw, lab in ((oa, "#999999", 1.0, "outer Rev A"), (oc, "#1f5fd6", 1.6, "outer Rev C"), (inn, "#d62f1f", 1.6, "inner")):
        m = trimesh.load(f); s = m.section(plane_origin=(0, Y, 0), plane_normal=(0, 1, 0))
        if s is None: continue
        first = True
        for e in s.discrete:
            a.plot(e[:, 0], e[:, 2], color=col, lw=lw, label=lab if first else None); first = False
    a.set_aspect("equal"); a.grid(alpha=.3)
    if k == 1:
        a.set_xlim(x0, x1); a.set_ylim(z0, z1); a.axhline(35.32, ls=":", c="#d62f1f"); a.axhline(36.07, ls=":", c="#1f5fd6")
    a.set_xlabel("X"); a.set_ylabel("Z"); a.legend(loc="lower right", fontsize=8)
    a.set_title(f"Section Y = {Y}" + ("  (zoom on clash)" if k else ""))
plt.tight_layout(); plt.savefig(png, dpi=130)
