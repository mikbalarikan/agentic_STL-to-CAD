"""Plots for the LT-ASM-001 Rev E fit report from a1_maps.py grids and the final joint / axis evidence.
usage: a3_plots.py qaE_dir out_dir"""
import sys, os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm

Q, OD = sys.argv[1], sys.argv[2]; os.makedirs(OD, exist_ok=True)
EV = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\work\revE2\final"
st = 0.25
xs = np.arange(-70, 121, st) + st / 2; ys = np.arange(-70, 290, st) + st / 2
ext = [xs[0] - st / 2, xs[-1] + st / 2, ys[0] - st / 2, ys[-1] + st / 2]
GX, GY = np.meshgrid(xs, ys, indexing="ij")
B = np.load(os.path.join(Q, "grid_before.npz")); A = np.load(os.path.join(Q, "grid_after.npz"))
LAB = {"K1": (86.45, 165.96, 8, 0), "K2": (-34, 110, 4, 0), "K3": (61.3, -40, 8, -2), "K4": (82, 10, 4, 0), "K5": (-36, 272, -2, 6),
       "K6": (38, 268, 0, 6), "K7": (-22, 265, 5, -9), "K8": (11, 267, -2, -9), "K9": (65, 267, -2, -9), "K10": (-41.5, 242.5, 3, -5),
       "K11-21": (112, 272, -14, -6), "K22": (-7, 166, 2, 5)}


def base(ax, G):
    ax.imshow(np.where(G["anyO"], 0.86, 1.0).T, origin="lower", extent=ext, cmap="gray", vmin=0, vmax=1)
    ax.contour(GX, GY, G["anyI"].astype(float), levels=[0.5], colors="#666666", linewidths=0.5)
    ax.set_xlim(-72, 122); ax.set_ylim(-72, 292); ax.set_aspect("equal")
    ax.set_xlabel("X [mm]", fontsize=8); ax.set_ylabel("Y [mm]", fontsize=8); ax.tick_params(labelsize=7)


# 1. interference before / after
cm = plt.get_cmap("autumn_r")
fig, axs = plt.subplots(1, 2, figsize=(10, 9.2))
for ax, G, t in ((axs[0], B, "Before: inner Rev E as received\nwith outer Rev F (pre-release export)"),
                 (axs[1], A, "After: inner Rev E final\nwith outer Rev F final")):
    base(ax, G)
    OV = G["OV"]
    im = ax.imshow(np.ma.masked_less_equal(OV, 0.01).T, origin="lower", extent=ext, cmap=cm, vmin=0, vmax=4.5, interpolation="nearest")
    tot = float(OV.sum() * st * st)
    ax.set_title(f"{t}\ninterference {tot:.1f} mm3" if tot > 1 else f"{t}\ninterference {tot:.2f} mm3 (2 grid cells, see text)", fontsize=8.5, loc="left")
    if G is B:
        for k, (x, y, dx, dy) in LAB.items():
            ax.annotate(k, (x, y), (x + dx * 2.2 + 3, y + dy * 2.2), fontsize=7, arrowprops=dict(arrowstyle="-", lw=0.5, color="k"),
                        bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.85))
    # make thin overlap visible: dilate markers
    ii, jj = np.nonzero(OV > 0.01)
    if 0 < len(ii) < 50:
        ax.scatter(xs[ii], ys[jj], s=60, facecolors="none", edgecolors="#8b0000", lw=1.0)
cax = fig.add_axes([0.25, 0.065, 0.5, 0.013])
cb = fig.colorbar(im, cax=cax, orientation="horizontal"); cb.set_label("overlap thickness along Z [mm]", fontsize=8); cb.ax.tick_params(labelsize=7)
fig.text(0.01, 0.015, "View from +Z onto the joint (XY plane, model frame). Grey: outer footprint; line: inner outline. Vertical ray stacks on a 0.25 mm grid.",
         fontsize=7.5, color="#333333")
fig.subplots_adjust(left=0.07, right=0.98, top=0.92, bottom=0.15, wspace=0.18)
fig.savefig(os.path.join(OD, "LT-ASM-001_interference_before_after.png"), dpi=150); plt.close(fig)

# 2. clearance map (after): vertical gap inner face above outer face, 0..1 mm
Bd = [0, 0.02, 0.15, 0.30, 0.60, 1.0]
COL = ["#1a9850", "#a6d96a", "#fee08b", "#f46d43", "#a50026"]
cmap = ListedColormap(COL); norm = BoundaryNorm(Bd, len(COL))
fig, ax = plt.subplots(figsize=(6.6, 9.6))
base(ax, A)
Gp = np.where(np.isfinite(A["G"]) & (A["G"] < 1.0), A["G"], np.nan)
im = ax.imshow(np.ma.masked_invalid(Gp).T, origin="lower", extent=ext, cmap=cmap, norm=norm, interpolation="nearest")
cb = fig.colorbar(im, ax=ax, shrink=0.45, ticks=Bd, pad=0.02); cb.ax.tick_params(labelsize=7)
cb.ax.set_yticklabels(["0", "0.02", "0.15", "0.30", "0.60", "1.00"]); cb.set_label("vertical clearance [mm]", fontsize=8)
for txt, (x, y, tx, ty) in {"boss faces: contact (0)": (92.5, 168, 95, 205), "lip shadow gap 0.56": (10, -66.5, 30, -62),
                            "-X strip rebate 0.42": (-26.5, 128, -62, 128), "+X rebate 0.12": (80.6, 0, 92, 15),
                            "hip seat 0.08": (38, 270, 30, 240), "-X hip corner 0.12": (-42.5, 252, -60, 228),
                            "pocket floors 0.13": (-25.1, 82.5, -63, 95)}.items():
    ax.annotate(txt, (x, y), (tx, ty), fontsize=6.8, ha="center", arrowprops=dict(arrowstyle="-", lw=0.6, color="k"),
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="#888888", lw=0.4, alpha=0.95))
ax.set_title("Joint clearance, Rev E final + outer Rev F final\n(inner face directly above an outer face, gaps up to 1 mm shown)", fontsize=8.5, loc="left")
fig.tight_layout(); fig.savefig(os.path.join(OD, "LT-ASM-001_clearance_map.png"), dpi=150); plt.close(fig)


# 3. joint gap profile along the wall stations: vertical clearance read from the after-grid along each station line
J = json.load(open(os.path.join(EV, "joint_profile_final.json")))
G = A["G"]
rows = []
for s in J:
    a0, a1 = s["tongue_span"]
    if s["fix"] == "y":
        j = int(round((s["at"] - ys[0]) / st)); ii = np.nonzero((xs >= a0) & (xs <= a1))[0]; g = G[ii, j]
    else:
        i = int(round((s["at"] - xs[0]) / st)); jj = np.nonzero((ys >= a0) & (ys <= a1))[0]; g = G[i, jj]
    g = g[np.isfinite(g) & (g < 2.0)]
    rows.append(dict(name=s["name"], at=s["at"], tongue_top=s["tongue_top"], n=int(len(g)),
                     gmin=round(float(g.min()), 3) if len(g) else None, gmed=round(float(np.median(g)), 3) if len(g) else None,
                     share_contact=round(float((g < 0.02).mean()), 3) if len(g) else None))
json.dump(rows, open(os.path.join(Q, "joint_rows.json"), "w"), indent=1)
groups = [("MX", "-X joint wall"), ("PX", "+X joint wall"), ("MXH", "-X hip corner"), ("PXH", "+X hip")]
fig, axs = plt.subplots(1, 4, figsize=(11, 3.3), gridspec_kw=dict(width_ratios=[16, 13, 9, 4]), sharey=True)
for ax, (g, t) in zip(axs, groups):
    R = [r for r in rows if r["name"].split("_")[0] == g and r["gmed"] is not None]
    y = [r["at"] for r in R]
    ax.plot(y, [r["gmed"] for r in R], "o-", c="#c0281a", ms=3.5, lw=1, label="median over the station")
    ax.plot(y, [r["gmin"] for r in R], "v", c="#1f5fd6", ms=3.5, label="minimum")
    ax.axhline(0, c="k", lw=0.6)
    ax.set_title(t, fontsize=8.5, loc="left"); ax.set_xlabel("station X [mm]" if g == "PXH" else "station Y [mm]", fontsize=8)
    ax.tick_params(labelsize=7); ax.grid(alpha=.3); ax.set_ylim(-0.05, 0.7)
    for r in R:
        if r["gmed"] > 0.7:
            ax.annotate(f"{r['gmed']:.2f} (1 cell, rebate corner)", (r["at"], 0.69), (6, -12), textcoords="offset points", fontsize=6.5)
axs[0].set_ylabel("vertical clearance [mm]", fontsize=8)
axs[0].legend(fontsize=7, loc="upper right")
fig.suptitle("Joint clearance profile: inner face above the outer joint face, read across the tongue at each wall station (0 = face contact)",
             fontsize=9, x=0.01, ha="left")
fig.tight_layout(rect=[0, 0, 1, 0.93]); fig.savefig(os.path.join(OD, "LT-ASM-001_joint_gap_profile.png"), dpi=150); plt.close(fig)
print("ok")


