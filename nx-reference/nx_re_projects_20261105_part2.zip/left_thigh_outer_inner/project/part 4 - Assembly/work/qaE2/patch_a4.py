"""Rev E2 text for the assembly fit report (drawing boss numbering)."""
p = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\work\qaE2\a4_pdf.py"
t = open(p, encoding="utf-8").read()
PAIRS = [
    ('"(the seven boss faces and the B1 pad); everything else stands clear by the designed gaps. The 894 mm3 of overlap "\n'
     '                "found when the Rev E inner was first checked against the Rev F outer has been removed by changes to the inner "\n'
     '                "only; the outer Rev F is unchanged."',
     '"(boss faces B1, B5, B6 and B7, with the B1 pad); everything else stands clear. Bosses B2, B3 and B4 sit 0.12, 0.16 and "\n'
     '                "0.16 mm above the outer boss tops by design. The 894 mm3 of overlap found when the Rev E inner was first checked "\n'
     '                "against the Rev F outer has been removed by changes to the inner only; the outer Rev F is unchanged."'),
    ('"One flagged sample at Z -27, 63 mm below the lowest point of the inner: a sign error of the mesh test, not a contact."',
     'f"No outer point inside the inner; deepest {oi[\'min_sd\']:+.3f} mm (numerical zero)."'),
    ('"Inner LT-INN-001 Rev E", "1 valid solid; NX volume 332 367 mm3 (0.897 kg Al 6061)"',
     '"Inner LT-INN-001 Rev E (final)", "1 valid solid; NX volume 332 275 mm3 (0.897 kg Al 6061)"'),
    ('"Before: the Rev E inner as first modelled, checked against the Rev F outer. After: the delivered Rev E inner against the "\n'
     '    "final Rev F outer.',
     '"Before: the Rev E inner as first modelled, checked against the Rev F outer. After: the final Rev E inner against the "\n'
     '    "final Rev F outer. The final Rev E also merges the small leftover faces of the fit cuts into the rebate floors, which removes "\n'
     '    "the contact rings under bosses B2, B3 and B4 (now 0.12 / 0.16 / 0.16 mm clear), adds R6 blends on two rib edges, 1 mm "\n'
     '    "chamfers on the two Ø3 pin tips and fills one rib notch; none of these meets the outer.'),
    ('"Rebate cut over the outer tongue: floor Z 36.19 / 36.23, step face 0.2 off the tongue side; contact rings at B3 and B4", "0 - gap 0.42 over the strip"',
     '"Rebate cut over the outer tongue: floor Z 36.23, step face 0.2 off the tongue side; floor also round bosses B3 and B4", "0 - gap 0.23 / 0.42; B3, B4 0.16"'),
    ('"Rebate floor Z 36.19; B2 boss face Z 36.07", "0 - gap 0.12 / contact"',
     '"Rebate floor Z 36.19, also round boss B2", "0 - gap 0.19; B2 0.12"'),
    ('"Floor Z 36.19 over the outer Z 36.07, step 0.2 off the wall", "0 - gap 0.12"',
     '"Floor Z 36.30 over the outer Z 36.07, step 0.2 off the wall", "0 - gap 0.23"'),
    ('"Face 36.06 -> 36.07", "0"', '"Face merged into the floor Z 36.23", "0 - gap 0.16"'),
    ('("B2", "75.85, 29.86", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.07")',
     '("B2", "75.85, 29.86", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.19 (0.12 gap)")'),
    ('("B3", "-25.10, 77.45", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.07")',
     '("B3", "-25.10, 77.45", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.23 (0.16 gap)")'),
    ('("B4", "-17.05, 165.91", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.07")',
     '("B4", "-17.05, 165.91", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.23 (0.16 gap)")'),
    ('"Pocket floor over nub top [mm]", "Boss face Z (contact)"', '"Pocket floor over nub top [mm]", "Inner face Z at the boss"'),
    ('"columns meet end to end at the contact face, they do not overlap."]:',
     '"columns meet end to end at the contact face, they do not overlap.",\n'
     '          "Boss faces: B1, B5, B6 (Z 36.07) and B7 (Z 36.24) sit face to face on the outer boss tops. At B2, B3 and B4 the inner "\n'
     '          "floor runs across the boss at Z 36.19 / 36.23, 0.12 / 0.16 / 0.16 mm above the outer boss tops (Z 36.07): these "\n'
     '          "three screws pull the shells together across that gap. This is the chosen design state."]:'),
    ('"green) only on the boss faces and the B1 pad; the lip keeps its 0.56 mm shadow gap all round; rebate floors stand 0.12 mm "\n'
     '    "over the tongue (+X side, hip corners) and 0.42 mm over the lowered -X strip; pocket floors 0.13 mm over the nubs; hip "\n'
     '    "seat 0.08 mm over the ring top."',
     '"green) only on boss faces B1, B5, B6, B7 and the B1 pad; bosses B2, B3, B4 0.12 / 0.16 / 0.16 mm clear; the lip keeps its "\n'
     '    "0.56 mm shadow gap all round; rebate floors stand 0.19 mm over the tongue on the +X side, 0.23 / 0.16 mm on the -X side "\n'
     '    "(0.42 mm over the lowered -X strip), 0.23 mm at the +X hip corner and 0.12 mm at the -X hip corner; pocket floors 0.13 mm "\n'
     '    "over the nubs; hip seat 0.08 mm over the ring top."'),
    ('"Left: the Rev E inner as first modelled with the Rev F outer, overlap in dark red. Right: the delivered Rev E "\n'
     '                   "inner with the final Rev F outer.',
     '"Left: the Rev E inner as first modelled with the Rev F outer, overlap in dark red. Right: the final Rev E "\n'
     '                   "inner with the final Rev F outer.'),
]
for a, b in PAIRS:
    assert a in t, a[:80]
    t = t.replace(a, b)
open(p, "w", encoding="utf-8").write(t)
print("ok", len(PAIRS))
