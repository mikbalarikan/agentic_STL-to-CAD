R = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\work\qaE2"


def patch(p, pairs):
    t = open(p, encoding="utf-8-sig").read()
    for a, b in pairs:
        assert a in t, (p, a[:70])
        t = t.replace(a, b)
    open(p, "w", encoding="utf-8").write(t)
    print("patched", p)


patch(R + r"\a4_pdf.py", [
    ('"0 - gap 0.19; B2 0.12"', '"0 - gap 0.12 / 0.19; B2 0.12"'),
    ("rebate floors stand 0.19 mm over the tongue on the +X side, 0.23 / 0.16 mm on the -X side",
     "rebate floors stand 0.12 mm over the tongue on the +X side (0.19 at Y 40-55), 0.23 / 0.16 mm on the -X side"),
])
patch(R + r"\a3_plots.py", [("Joint clearance, Rev E delivered + outer Rev F final", "Joint clearance, Rev E final + outer Rev F final"),
                           ("After: inner Rev E delivered", "After: inner Rev E final")])
