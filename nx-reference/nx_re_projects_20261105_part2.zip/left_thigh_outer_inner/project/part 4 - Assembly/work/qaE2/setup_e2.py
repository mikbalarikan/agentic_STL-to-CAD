"""Copy the Rev E QA scripts into qaE2 work folders and point them at the Rev E2 CAD / gate evidence."""
import os, shutil
R = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"
IQ, IQ2 = R + r"\part 2 - Inner\work\qaE", R + r"\part 2 - Inner\work\qaE2"
AQ, AQ2 = R + r"\part 4 - Assembly\work\qaE", R + r"\part 4 - Assembly\work\qaE2"
os.makedirs(IQ2, exist_ok=True); os.makedirs(AQ2, exist_ok=True)
NEW_IN = r"\part 2 - Inner\deliver_RevE2\CAD\LT-INN-001_Left_Thigh_Inner.stl"
OLD_IN = r"\part 2 - Inner\deliver_RevE_fit\CAD\LT-INN-001_Left_Thigh_Inner.stl"


def cp(src, dst, pairs):
    t = open(src, encoding="utf-8-sig").read()
    for a, b in pairs:
        assert a in t, (src, a)
        t = t.replace(a, b)
    open(dst, "w", encoding="utf-8").write(t)
    print("wrote", dst)


cp(IQ + r"\e2_qa.py", IQ2 + r"\e2_qa.py", [('"revE": R2 + r"\\deliver_RevE_fit\\CAD', '"revE": R2 + r"\\deliver_RevE2\\CAD')])
cp(IQ + r"\e3_diff.py", IQ2 + r"\e3_diff.py", [('"revE": R2 + r"\\deliver_RevE_fit\\CAD', '"revE": R2 + r"\\deliver_RevE2\\CAD')])
shutil.copy(IQ + r"\e4_maps.py", IQ2 + r"\e4_maps.py")
shutil.copy(IQ + r"\render.py", IQ2 + r"\render.py")
shutil.copy(IQ + r"\e5_pdf.py", IQ2 + r"\e5_pdf.py")
cp(AQ + r"\a1_maps.py", AQ2 + r"\a1_maps.py", [('IN_A = ROOT + r"\\part 2 - Inner\\deliver_RevE_fit\\CAD', 'IN_A = ROOT + r"\\part 2 - Inner\\deliver_RevE2\\CAD')])
cp(AQ + r"\a2_secs.py", AQ2 + r"\a2_secs.py", [('"in_a": ROOT + r"\\part 2 - Inner\\deliver_RevE_fit\\CAD', '"in_a": ROOT + r"\\part 2 - Inner\\deliver_RevE2\\CAD')])
cp(AQ + r"\a3_plots.py", AQ2 + r"\a3_plots.py", [(r'work\revE\final"', r'work\revE2\final"')])
cp(AQ + r"\a4_pdf.py", AQ2 + r"\a4_pdf.py", [(r'work\revE\final"', r'work\revE2\final"')])
