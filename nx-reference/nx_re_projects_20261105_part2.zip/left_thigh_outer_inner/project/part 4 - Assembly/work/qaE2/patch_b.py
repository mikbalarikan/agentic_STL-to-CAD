R = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"


def patch(p, pairs):
    t = open(p, encoding="utf-8-sig").read()
    for a, b in pairs:
        assert a in t, (p, a[:70])
        t = t.replace(a, b)
    open(p, "w", encoding="utf-8").write(t)
    print("patched", p)


patch(R + r"\part 4 - Assembly\work\qaE2\a4_pdf.py", [
    ('"are stations that cross a boss contact face (B3, B4, B1, B2, and B7 at the hip end); the single 1.04 mm reading at "',
     '"are stations that cross the B1 pad and the B7 boss face at the hip end; the stations past B2, B3 and B4 now read "\n'
     '    "0.12-0.16 mm. The single 1.04 mm reading at "'),
])
patch(R + r"\part 4 - Assembly\work\qaE2\a2_secs.py", [("After: inner Rev E delivered + outer Rev F", "After: inner Rev E final + outer Rev F")])
patch(R + r"\part 2 - Inner\work\qaE2\e5_pdf.py", [
    ("within 0.5 mm 89.3 % (Rev B) and 88.4 % (Rev E); within 1.0 mm 95.3 % and 95.4 %.",
     "within 0.5 mm 89.3 % (Rev B) and 88.3 % (Rev E); within 1.0 mm 95.3 % and 95.4 %."),
    ("and the +X hip corner (0.12 to 0.23 mm)", "and the +X hip corner (0.12 to 0.24 mm)"),
    ('"Left Thigh, inner shell &nbsp;|&nbsp; Revision E &nbsp;|&nbsp; Date 2026-11-02"', '"Left Thigh, inner shell &nbsp;|&nbsp; Revision E (final) &nbsp;|&nbsp; Date 2026-11-02"'),
])
