"""Before / after interference maps and the joint clearance map for the LT-ASM-001 Rev E fit report.
Same vertical ray-stack method as an/grid_overlap.py (0.25 mm grid). Before = inner Rev E as received vs outer Rev F
06:45 export; after = inner Rev E (fit fixes + B6 web) vs outer Rev F final.
Clearance: per cell, smallest vertical gap between the top of an outer material interval and the bottom of the inner
material interval directly above it (inner faces looking down onto outer faces), shown 0..1 mm.
usage: a1_maps.py out_dir"""
import sys, os, json
import numpy as np, open3d as o3d
from scipy import ndimage
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm

ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"
IN_B = ROOT + r"\part 2 - Inner\deliver_RevE\CAD\LT-INN-001_Left_Thigh_Inner.stl"
OUT_B = ROOT + r"\part 1\work\qaF\revF_0645.stl"
IN_A = ROOT + r"\part 2 - Inner\deliver_RevE2\CAD\LT-INN-001_Left_Thigh_Inner.stl"
OUT_A = ROOT + r"\part 1\deliver_RevF\CAD\LT-OUT-001_Left_Thigh_Outer.stl"
OD = sys.argv[1]; os.makedirs(OD, exist_ok=True)
st = 0.25
xs = np.arange(-70, 121, st) + st / 2; ys = np.arange(-70, 290, st) + st / 2
GX, GY = np.meshgrid(xs, ys, indexing="ij"); X, Y = GX.ravel().astype(np.float32), GY.ravel().astype(np.float32)


def stacks(path, zmin=-100.0, nmax=24):
    m = o3d.io.read_triangle_mesh(path)
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
    n = X.size; z0 = np.full(n, zmin, np.float32); H = np.full((n, nmax), np.nan, np.float32); alive = np.ones(n, bool)
    for k in range(nmax):
        idx = np.nonzero(alive)[0]
        if not len(idx):
            break
        r = np.zeros((len(idx), 6), np.float32); r[:, 0] = X[idx]; r[:, 1] = Y[idx]; r[:, 2] = z0[idx]; r[:, 5] = 1
        t = sc.cast_rays(o3d.core.Tensor(r))["t_hit"].numpy()
        ok = np.isfinite(t); hit = idx[ok]
        H[hit, k] = z0[hit] + t[ok]; z0[hit] = H[hit, k] + 2e-4; alive[idx[~ok]] = False
    return H


def overlap(HA, HB):
    ov = np.zeros(HA.shape[0])
    for i in range(0, HA.shape[1] - 1, 2):
        for j in range(0, HB.shape[1] - 1, 2):
            d = np.nan_to_num(np.minimum(HA[:, i + 1], HB[:, j + 1]) - np.maximum(HA[:, i], HB[:, j]), nan=0.0)
            d[d < 0] = 0; ov += d
    return ov


def gaps(HI, HO):
    g = np.full(HI.shape[0], np.inf)
    for i in range(0, HI.shape[1] - 1, 2):
        ib = HI[:, i]
        for j in range(1, HO.shape[1], 2):
            ot = HO[:, j]
            d = ib - ot
            ok = np.isfinite(d) & (d > -0.02)
            g = np.where(ok, np.minimum(g, np.maximum(d, 0)), g)
    return g


res = {}
outline = None
for tag, (ia, oa) in (("before", (IN_B, OUT_B)), ("after", (IN_A, OUT_A))):
    HI, HO = stacks(ia), stacks(oa)
    OV = overlap(HI, HO).reshape(GX.shape)
    G = gaps(HI, HO).reshape(GX.shape)
    anyI = np.isfinite(HI[:, 0]).reshape(GX.shape); anyO = np.isfinite(HO[:, 0]).reshape(GX.shape)
    np.savez_compressed(os.path.join(OD, f"grid_{tag}.npz"), OV=OV.astype(np.float32), G=G.astype(np.float32), anyI=anyI, anyO=anyO)
    lab, k = ndimage.label(OV > 0.01, structure=np.ones((3, 3)))
    res[tag] = dict(total_mm3=round(float(OV.sum() * st * st), 3), clusters=int(k), max_thick=round(float(OV.max()), 3),
                    gap_cells={b: int(((G >= lo) & (G < hi)).sum()) for b, (lo, hi) in
                               {"contact <0.02": (0, 0.02), "0.02-0.15": (0.02, 0.15), "0.15-0.30": (0.15, 0.30),
                                "0.30-0.60": (0.30, 0.60), "0.60-1.00": (0.60, 1.0)}.items()})
    print(tag, res[tag], flush=True)
json.dump(res, open(os.path.join(OD, "maps_summary.json"), "w"), indent=1)
print("ok")
