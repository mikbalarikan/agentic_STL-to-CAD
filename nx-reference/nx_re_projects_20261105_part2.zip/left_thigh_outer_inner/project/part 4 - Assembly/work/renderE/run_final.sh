#!/bin/bash
# LT-ASM-001 Rev E renders (outer alu, inner blue anodised; sec/ from make_section.py) (same look as part 1/work/renderF): Blender Cycles -> compose on studio background.
# usage: run_final.sh <out_rgba_dir> <samples> <res_pct> [only,names]
cd "$(dirname "$0")"
OUT=${1:-final}; SMP=${2:-128}; RES=${3:-100}
EXPO=-0.3 "/c/Program Files/Blender Foundation/Blender 5.1/blender.exe" -b --factory-startup -P bl_render2.py -- scene.json views.json "$OUT" $SMP $RES "$4" 2>&1 | grep -E "wrote|Error|Trace|device"
/c/Users/marya/.venvs/cadgenbench/Scripts/python.exe compose.py "$OUT" "${OUT}_c" LT-ASM-001_RevE_ "$4"
