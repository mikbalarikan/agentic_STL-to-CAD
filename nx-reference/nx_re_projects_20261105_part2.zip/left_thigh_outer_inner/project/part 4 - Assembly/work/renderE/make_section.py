"""Cut the Rev E assembly meshes at Y = Y0 (through the B5 boss pair (drawing numbering), x 86.45, and the -X boss pair near x -20),
keep the Y < Y0 side, write body and cap STLs for bl_render2.py. usage: make_section.py"""
import trimesh, numpy as np, os
D = os.path.dirname(os.path.abspath(__file__)); CAD = os.path.join(D, "..", "..", "deliver_RevE2", "CAD")
Y0 = 165.96
os.makedirs(os.path.join(D, "sec"), exist_ok=True)
for tag, fn in [("out", "LT-OUT-001_Left_Thigh_Outer.stl"), ("inn", "LT-INN-001_Left_Thigh_Inner.stl")]:
    m = trimesh.load(os.path.join(CAD, fn)); m.merge_vertices()
    print(tag, "watertight", m.is_watertight)
    box = trimesh.creation.box(bounds=[[-200, -200, -200], [300, Y0, 300]])
    c = trimesh.boolean.intersection([m, box], engine="manifold")  # closed cut solid, caps included
    cen = c.triangles_center; n = c.face_normals
    cap = (np.abs(cen[:, 1] - Y0) < 1e-3) & (n[:, 1] > 0.99)
    body = c.submesh([np.nonzero(~cap)[0]], append=True); capm = c.submesh([np.nonzero(cap)[0]], append=True)
    body.export(os.path.join(D, "sec", tag + "_body.stl")); capm.export(os.path.join(D, "sec", tag + "_cap.stl"))
    print(tag, "body", len(body.faces), "cap", len(capm.faces), "cap area", round(capm.area, 1))
