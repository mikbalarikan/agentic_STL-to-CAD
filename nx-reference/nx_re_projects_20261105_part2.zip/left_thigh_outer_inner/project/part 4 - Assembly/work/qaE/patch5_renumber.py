"""Relabel bosses / pins in the Rev E QA report scripts to the LT-INN-001 drawing (SH4) numbering.
Assembly-gate -> drawing: B1->B3, B2->B7, B3->B4, B4->B1, B5->B2, B6->B5, B7->B6; P1->P3, P2->P1, P3->P2 (E1/E2 unchanged)."""
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"


def patch(p, pairs):
    t = open(p, encoding="utf-8-sig").read()
    for a, b in pairs:
        assert a in t, (p, a)
        t = t.replace(a, b)
    open(p, "w", encoding="utf-8").write(t)
    print("patched", p, len(pairs))


patch(ROOT + r"\part 2 - Inner\work\qaE\e5_pdf.py", [
    ('("Boss B6", "Boss bottom face', '("Boss B5", "Boss bottom face'),
    ("Z 39.17-44.87, as on B1-B5 and B7.", "Z 39.17-44.87, as on the other six bosses."),
    ("boss B5 face Z 36.07 (contact).", "boss B2 face Z 36.07 (contact)."),
    ('("Boss B4 pad",', '("Boss B1 pad",'),
    ("pin P1 base recess", "pin P3 base recess"),
    ('("Boss B2 face", "Boss face Z 36.24 onto the outer B2 top (contact)', '("Boss B7 face", "Boss face Z 36.24 onto the outer boss top (contact)'),
    ("except at boss B6, where", "except at boss B5, where"),
    ("boss B2 face (0.03 to 0.16 mm)", "boss B7 face (0.03 to 0.16 mm)"),
    ('("Beside boss B1", 2, "Rib / wall face next to the B1 column', '("Beside boss B3", 2, "Rib / wall face next to the B3 column'),
    ('"+X hip end wall near boss B7"', '"+X hip end wall near boss B6"'),
    ('("Gusset rib beside boss B2", 5', '("Gusset rib beside boss B7", 5'),
    ('("Gusset rib beside boss B7", 8', '("Gusset rib beside boss B6", 8'),
    ('"Boss B4 column / wall side"', '"Boss B1 column / wall side"'),
])

patch(ROOT + r"\part 4 - Assembly\work\qaE\a2_secs.py", [
    ('("B6_boss", "y", 165.96, [74, 99, 26, 48], "Boss B6, section Y = 165.96"', '("B5_boss", "y", 165.96, [74, 99, 26, 48], "Boss B5, section Y = 165.96"'),
    ('("B4_pad", "y", -40.05, [48, 76, 31, 46], "Boss B4 on outer hub F5', '("B1_pad", "y", -40.05, [48, 76, 31, 46], "Boss B1 on outer hub F5'),
    ('("B2_boss", "x", -22.0, [255, 275, 33, 41], "Boss B2, section X = -22"', '("B7_boss", "x", -22.0, [255, 275, 33, 41], "Boss B7, section X = -22"'),
    ("onto the outer B2 top (contact)", "onto the outer boss top Z 36.24 (contact)"),
])

AX_OLD = AX_NEW = None
p = ROOT + r"\part 4 - Assembly\work\qaE\a4_pdf.py"
t = open(p, encoding="utf-8-sig").read()
i0 = t.index("AX = [("); i1 = t.index("]\n", t.index('("B7", "97.95, 264.95"')) + 2
AX_NEW = '''AX = [("B1", "61.35, -40.01", "0.064", "0.34", "33.00", "39.17-44.87", "\u00d810.4 / \u00d810, 0.14", "0.17", "36.07"),
      ("B2", "75.85, 29.86", "0.000", "0.40", "27.04", "39.17-44.87", "\u00d810 / \u00d810, 0.00", "0.13", "36.07"),
      ("B3", "-25.10, 77.45", "0.000", "0.40", "27.04", "39.17-44.87", "\u00d810 / \u00d810, 0.00", "0.13", "36.07"),
      ("B4", "-17.05, 165.91", "0.000", "0.40", "27.04", "39.17-44.87", "\u00d810 / \u00d810, 0.00", "0.13", "36.07"),
      ("B5", "86.45, 165.96", "0.000", "0.40", "27.04", "39.17-44.87 (new)", "\u00d810.4 / \u00d810, 0.20", "0.13", "36.07"),
      ("B6", "97.95, 264.95", "0.000", "0.40", "27.04", "39.17-44.87", "\u00d810 / \u00d810, 0.00", "0.13", "36.07"),
      ("B7", "-22.00, 264.93", "0.000", "0.40", "27.04", "39.17-44.87", "\u00d810 / \u00d810, 0.00", "0.13", "36.24")]
'''
t = t[:i0] + AX_NEW + t[i1:]
open(p, "w", encoding="utf-8").write(t)

patch(p, [
    ("(the seven boss faces and the B4 pad)", "(the seven boss faces and the B1 pad)"),
    ("One zero-thickness sheet on the B6 boss face", "One zero-thickness sheet on the B5 boss face"),
    ("(pin P1 in its \u00d84 hole, boss B7 \u00d810 nub in its pocket)", "(pin P3 in its \u00d84 hole, boss B6 \u00d810 nub in its pocket)"),
    ('("K1", "Boss B6 (86.45, 165.96)"', '("K1", "Boss B5 (86.45, 165.96)"'),
    ("contact rings at B1 and B3", "contact rings at B3 and B4"),
    ('("K3", "Boss B4 pad on outer hub F5"', '("K3", "Boss B1 pad on outer hub F5"'),
    ('"+X joint wall incl. boss B5, Y -30..53"', '"+X joint wall incl. boss B2, Y -30..53"'),
    ("Rebate floor Z 36.19; B5 boss face Z 36.07", "Rebate floor Z 36.19; B2 boss face Z 36.07"),
    ("-X hip corner incl. pin P1, Y 241..287", "-X hip corner incl. pin P3, Y 241..287"),
    ("P1 base recess \u00d89.4", "P3 base recess \u00d89.4"),
    ('("K7", "Boss B2 face (-22.00, 264.93)"', '("K7", "Boss B7 face (-22.00, 264.93)"'),
    ("Boss face raised 36.07 -> 36.24 onto the outer B2 top", "Boss face raised 36.07 -> 36.24 onto the outer boss top (Z 36.24)"),
    ('("K22", "Next to boss B3,', '("K22", "Next to boss B4,'),
    ("pocket sits over the outer \u00d810 locating nub", "pocket sits over the outer \u00d810 locating nub"),
    ("(B4, B6: \u00d810.4)", "(B1, B5: \u00d810.4)"),
    ("(B4 0.064 mm off, inside its 0.34 mm radial clearance)", "(B1 0.064 mm off, inside its 0.34 mm radial clearance)"),
    ("B4 sits on the outer hub F5", "B1 sits on the outer hub F5"),
    ("(B1, B2, B3, B5, B7) are size on size", "(B2, B3, B4, B6, B7) are size on size"),
    ("B4 and B6 have \u00d810.4 pockets", "B1 and B5 have \u00d810.4 pockets"),
    ("At B4 the inner \u00d815 boss column", "At B1 the inner \u00d815 boss column"),
    ("only on the boss faces and the B4 pad", "only on the boss faces and the B1 pad"),
    ("(B1, B3, B4, B5 and B2 / B7 at the hip end)", "(B3, B4, B1, B2, and B7 at the hip end)"),
    ("rebate corner next to the B4 pad", "rebate corner next to the B1 pad"),
    ('["B6_boss", "B4_pad", "mx_wall", "mx_hip_corner", "hip_seat", "B2_boss"]', '["B5_boss", "B1_pad", "mx_wall", "mx_hip_corner", "hip_seat", "B7_boss"]'),
])

# pins table: renumber and reorder to P1, P2, P3 (drawing)
t = open(p, encoding="utf-8").read()
a = t.index('        ["Locating pin P1 (outer'); b = t.index('        ["Hip ring seat')
t = t[:a] + '''        ["Locating pin P1 (outer \u00d84 in inner \u00d84 hole)", "97.46, 131.44", "\u00d84 / \u00d84", "0.000", "0.00 (size on size)", "pin top 41.98 under hole bottom 45.32"],
        ["Locating pin P2", "108.97, 194.32", "\u00d84 / \u00d84", "0.000", "0.00 (size on size)", "pin top 41.98 under hole bottom 45.32"],
        ["Locating pin P3", "-38.09, 245.35", "\u00d84 / \u00d84", "0.000", "0.00 (size on size)", "pin top 42.25 under hole bottom 46.36; base \u00d89 in \u00d89.4 recess, 0.12 above"],
''' + t[b:]
open(p, "w", encoding="utf-8").write(t)
print("pins ok")
