"""Before / after section pairs for the LT-ASM-001 Rev E fit report.
Left: inner Rev E as received + outer Rev F (06:45 export), overlap filled dark red. Right: inner Rev E delivered (fit
fixes + B6 web) + outer Rev F final. Writes LT-ASM-001_section_<name>.png.
usage: a2_secs.py out_dir"""
import sys, os
import numpy as np, trimesh, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from shapely.geometry import Polygon as SP
from shapely.ops import unary_union
from shapely.validation import make_valid

ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"
M = {"in_b": ROOT + r"\part 2 - Inner\deliver_RevE\CAD\LT-INN-001_Left_Thigh_Inner.stl",
     "out_b": ROOT + r"\part 1\work\qaF\revF_0645.stl",
     "in_a": ROOT + r"\part 2 - Inner\deliver_RevE_fit\CAD\LT-INN-001_Left_Thigh_Inner.stl",
     "out_a": ROOT + r"\part 1\deliver_RevF\CAD\LT-OUT-001_Left_Thigh_Outer.stl"}
M = {k: trimesh.load(v) for k, v in M.items()}
OD = sys.argv[1]; os.makedirs(OD, exist_ok=True)

SPEC = [
    ("B5_boss", "y", 165.96, [74, 99, 26, 48], "Boss B5, section Y = 165.96",
     "Boss bottom raised 32.08 -> 36.07 (face contact on the outer boss); new D10.4 / D6 screw web Z 39.17-44.87"),
    ("B1_pad", "y", -40.05, [48, 76, 31, 46], "Boss B1 on outer hub F5, section Y = -40.05",
     "Pad faces raised 35.32 -> 36.07 (contact), pocket D10 -> D10.4"),
    ("mx_wall", "y", 110.0, [-28, -19, 33.5, 38.5], "-X joint wall, section Y = 110",
     "Rebate cut over the outer tongue: floor 36.23, step 0.2 off the tongue side"),
    ("mx_hip_corner", "y", 267.6, [-44, -28, 33.5, 39], "-X hip corner, section Y = 267.6",
     "Floor raised to 36.36 over the outer plate 36.24"),
    ("hip_seat", "x", 38.0, [262, 280, 82.5, 87.5], "Hip seat, section X = 38",
     "Seat flat raised 84.85 -> 85.28 over the ring top 85.20"),
    ("B7_boss", "x", -22.0, [255, 275, 33, 41], "Boss B7, section X = -22",
     "Boss face raised 36.07 -> 36.24 onto the outer boss top Z 36.24 (contact)"),
]


def polys(mesh, axis, at):
    ai = 1 if axis == "y" else 0; h = 0 if axis == "y" else 1
    n = [0, 0, 0]; n[ai] = 1; o = [0, 0, 0]; o[ai] = at
    sec = mesh.section(plane_origin=o, plane_normal=n)
    if sec is None:
        return None, []
    loops = [np.c_[e[:, h], e[:, 2]] for e in sec.discrete if len(e) > 3]
    g = None
    for L in loops:  # even-odd fill
        p = make_valid(SP(L))
        g = p if g is None else g.symmetric_difference(p)
    return g, loops


def fill(ax, g, **kw):
    if g is None or g.is_empty:
        return
    geoms = getattr(g, "geoms", [g])
    for p in geoms:
        if p.geom_type == "Polygon" and p.area > 1e-6:
            x, y = p.exterior.xy
            ax.fill(x, y, **kw)
            for it in p.interiors:
                xi, yi = it.xy; ax.fill(xi, yi, fc="white", ec="none")
        elif p.geom_type in ("MultiPolygon", "GeometryCollection"):
            fill(ax, p, **kw)


for name, axis, at, lim, title, note in SPEC:
    ar = (lim[3] - lim[2]) / (lim[1] - lim[0]); fh = 4.4 * ar + 1.9
    fig, axs = plt.subplots(1, 2, figsize=(11, fh))
    for ax, (ik, ok, lab) in zip(axs, (("in_b", "out_b", "Before: inner Rev E as received"),
                                       ("in_a", "out_a", "After: inner Rev E delivered + outer Rev F"))):
        gi, li = polys(M[ik], axis, at); go, lo = polys(M[ok], axis, at)
        fill(ax, go, fc="#9fbbe8", ec="none", alpha=0.8)
        fill(ax, gi, fc="#f0b4aa", ec="none", alpha=0.8)
        ov = 0.0
        if gi is not None and go is not None:
            x = gi.intersection(go)
            ov = x.area
            fill(ax, x, fc="#8b0000", ec="none", alpha=1.0)
        for L in lo:
            ax.plot(L[:, 0], L[:, 1], c="#1f5fd6", lw=1.1)
        for L in li:
            ax.plot(L[:, 0], L[:, 1], c="#c0281a", lw=1.1)
        ax.set_xlim(lim[0], lim[1]); ax.set_ylim(lim[2], lim[3]); ax.set_aspect("equal"); ax.grid(alpha=.3)
        ax.set_xlabel("X [mm]" if axis == "y" else "Y [mm]", fontsize=8); ax.set_ylabel("Z [mm]", fontsize=8)
        ax.tick_params(labelsize=7)
        ax.set_title(f"{lab}\noverlap over the whole section plane: {ov:.2f} mm2", fontsize=8.5, loc="left")
    from matplotlib.patches import Patch
    fig.legend(handles=[Patch(fc="#f0b4aa", ec="#c0281a", label="inner LT-INN-001"), Patch(fc="#9fbbe8", ec="#1f5fd6", label="outer LT-OUT-001"),
                        Patch(fc="#8b0000", label="overlap (interference)")], loc="lower center", ncol=3, fontsize=8, frameon=False)
    fig.suptitle(f"{title}  -  {note}", fontsize=9, x=0.01, ha="left")
    fig.tight_layout(rect=[0, 0.45 / fh, 1, 1 - 0.4 / fh])
    fig.savefig(os.path.join(OD, f"LT-ASM-001_section_{name}.png"), dpi=150); plt.close(fig)
    print("wrote", name, flush=True)


