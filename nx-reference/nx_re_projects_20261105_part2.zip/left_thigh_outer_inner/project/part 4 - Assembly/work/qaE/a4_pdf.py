"""LT-ASM-001 Rev E fit and collision check report PDF (reportlab, system Python), same look as the LT-OUT-001 Rev F report.
usage: a4_pdf.py qaE_dir png_dir out.pdf"""
import sys, os, json
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.lib.utils import ImageReader

Q, PNG, OUT = sys.argv[1:4]
EV = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\work\revE\final"
fit = json.load(open(os.path.join(EV, "fit_final_AP242.json")))
tw = json.load(open(os.path.join(EV, "twoway_final.json")))
ms = json.load(open(os.path.join(Q, "maps_summary.json")))
ck = {k: json.load(open(os.path.join(EV, f"LT-ASM-001_Left_Thigh_Assembly_{k}_check.json"))) for k in ("AP214", "AP242")}

TITLE = "LT-ASM-001 Rev E - Fit and Collision Check Report"
ss = getSampleStyleSheet()
H1 = ParagraphStyle("h1", parent=ss["Title"], fontSize=17, leading=21, alignment=0, spaceAfter=2)
H2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12, leading=15, spaceBefore=8, spaceAfter=4)
B = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9, leading=12)
S = ParagraphStyle("s", parent=B, fontSize=7.8, leading=10, textColor=colors.HexColor("#333333"))
C = ParagraphStyle("c", parent=B, fontSize=7.4, leading=9.0)
HB = ParagraphStyle("hb", parent=C, fontName="Helvetica-Bold", fontSize=7.0, leading=8.4, alignment=1)
V = ParagraphStyle("v", parent=B, fontSize=10.5, leading=14, textColor=colors.HexColor("#14532d"))
GRID = colors.HexColor("#9aa3ad"); HEAD = colors.HexColor("#dde3ea"); ALT = colors.HexColor("#f4f6f8")


def tstyle(nrows, fs=7.6):
    st = [("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 7.4), ("FONT", (0, 1), (-1, -1), "Helvetica", fs),
          ("BACKGROUND", (0, 0), (-1, 0), HEAD), ("GRID", (0, 0), (-1, -1), 0.4, GRID),
          ("ALIGN", (1, 0), (-1, -1), "CENTER"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("TOPPADDING", (0, 0), (-1, -1), 2.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.2)]
    for r in range(2, nrows, 2):
        st.append(("BACKGROUND", (0, r), (-1, r), ALT))
    return TableStyle(st)


def P(x, st=C):
    return Paragraph(x, st)


def table(rows, widths, fs=7.6, left=False):
    rows = [[P(h, HB) for h in rows[0]]] + [[P(c) if isinstance(c, str) and len(c) > 14 else c for c in r] for r in rows[1:]]
    t = Table(rows, colWidths=[w * mm for w in widths], repeatRows=1, hAlign="LEFT" if left else "CENTER")
    t.setStyle(tstyle(len(rows), fs)); return t


def footer(cv, doc):
    cv.saveState(); cv.setFont("Helvetica", 7.5); cv.setFillColor(colors.HexColor("#555555"))
    cv.drawString(18 * mm, 10 * mm, TITLE + " - 2026-11-02")
    cv.drawRightString(A4[0] - 18 * mm, 10 * mm, f"Page {doc.page}")
    cv.restoreState()


W_AV = A4[0] - 36 * mm


def img(name, w=W_AV, hmax=None):
    p = os.path.join(PNG, name); iw, ih = ImageReader(p).getSize()
    h = w * ih / iw
    if hmax and h > hmax:
        w, h = w * hmax / h, hmax
    return Image(p, width=w, height=h)


E = []
E.append(Paragraph(TITLE, H1))
E.append(Paragraph("Left Thigh assembly: LT-OUT-001 Rev F (outer) + LT-INN-001 Rev E (inner) &nbsp;|&nbsp; Date 2026-11-02", B))
E.append(Spacer(1, 4 * mm))

E.append(Paragraph("1. Result", H2))
box = Table([[P("<b>PASS - no interference between the two shells.</b> The parts touch only on the designed contact faces "
                "(the seven boss faces and the B1 pad); everything else stands clear by the designed gaps. The 894 mm3 of overlap "
                "found when the Rev E inner was first checked against the Rev F outer has been removed by changes to the inner "
                "only; the outer Rev F is unchanged.", V)]], colWidths=[W_AV])
box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#3f7f4f")), ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#eef6ee")),
                         ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6), ("LEFTPADDING", (0, 0), (-1, -1), 7)]))
E.append(box)
E.append(Spacer(1, 3 * mm))
ii, oi = tw["inner_in_outer"], tw["outer_in_inner"]
rows = [["Check", "Result", "Reading"],
        ["Boolean common of the two STEP solids (AP242, read with OpenCascade)", f"{fit['interference_mm3']:.3f} mm3",
         "One zero-thickness sheet on the B5 boss face at Z 36.07: two faces in contact, no volume."],
        ["Vertical ray stacks on a 0.25 mm grid over the whole part", f"{ms['after']['total_mm3']:.2f} mm3",
         "Two single grid cells on size-on-size cylinder walls (pin P3 in its Ø4 hole, boss B6 Ø10 nub in its pocket): "
         "tessellation of coincident walls, present since Rev A. Nothing in any of the former clash zones."],
        ["Inner surface sampled against the outer solid", f"{ii['inside']} of {ii['samples']:,}",
         f"No inner point inside the outer; deepest {ii['min_sd']:+.3f} mm (numerical zero)."],
        ["Outer surface sampled against the inner solid", f"{oi['inside']} of {oi['samples']:,}",
         "One flagged sample at Z -27, 63 mm below the lowest point of the inner: a sign error of the mesh test, not a contact."],
        ["Surface samples of the inner, signed distance to the outer", f"{fit['inner_points_inside_outer']} of {fit['gap_samples']:,}",
         f"Minimum {fit['min_signed_mm']:+.4f} mm; minimum distance between the solids {fit['min_distance']:.1f} mm (contact)."],
        ["NX assembly interference check (LT-ASM-001.prt)", "faces touch only",
         "NX reports only edges or faces interfering, no interference body; minimum distance 0.0 mm."]]
E.append(table(rows, [52, 24, 98]))

E.append(Paragraph("2. Assembly and files checked", H2))
a242, a214 = ck["AP242"], ck["AP214"]
rows = [["Item", "Value"],
        ["Assembly", "LT-ASM-001 Rev E: LT-OUT-001 Rev F and LT-INN-001 Rev E, both at the origin with identity orientation (shared model frame, no mates needed)"],
        ["Outer LT-OUT-001 Rev F", "1 valid solid; NX volume 378 955 mm3 (1.023 kg Al 6061)"],
        ["Inner LT-INN-001 Rev E", "1 valid solid; NX volume 332 367 mm3 (0.897 kg Al 6061)"],
        ["Assembly STEP AP214 / AP242", "Each re-read: 1 assembly, 2 instances, 1 valid solid per instance, zero translation, identity rotation; "
                                       "volumes within 0.03 % of NX"],
        ["Model frame", "Origin on the knee axis at the outer's knee-floor plane; +Z along the knee axis toward the inner; +Y along the hip-ring axis (knee to hip)"]]
t = Table([[P(h, HB) for h in rows[0]]] + [[P(a), P(b)] for a, b in rows[1:]], colWidths=[44 * mm, 130 * mm])
t.setStyle(tstyle(len(rows))); E.append(t)

E.append(Paragraph("3. Method", H2))
E.append(Paragraph(
    "The two solids are checked as delivered, in the shared model frame. Interference is measured four independent ways: the "
    "boolean common of the STEP solids, vertical ray stacks through the meshes on a 0.25 mm XY grid (material intervals of both "
    "parts compared cell by cell), dense surface sampling in both directions, and the NX assembly interference check. "
    "Clearances are read from the same ray stacks (vertical gap between an outer face and the inner face directly above it), "
    "from axis-by-axis Z stacks through every screw, pin and nub, and from 2D sections.", B))

# ---------------- page 2
E.append(PageBreak())
E.append(Paragraph("4. Clash zones before and after the Rev E fit changes", H2))
E.append(Paragraph(
    "Before: the Rev E inner as first modelled, checked against the Rev F outer. After: the delivered Rev E inner against the "
    "final Rev F outer. Volumes from the 0.25 mm ray-stack grid; thickness = largest overlap measured along Z. All changes are on "
    "the inner; contact faces were moved onto the outer's faces, clearance faces set 0.12 mm above them, side walls 0.2 mm off "
    "the outer's tongue.", B))
E.append(Spacer(1, 2 * mm))
Z = [("K1", "Boss B5 (86.45, 165.96)", "367.0", "3.99", "Boss bottom face raised 32.08 -> 36.07; new Ø10.4 / Ø6 screw web Z 39.17-44.87 as on the other bosses", "0 - face contact"),
     ("K2", "-X joint wall, X -61..-20, Y 28..181", "193.7", "0.79", "Rebate cut over the outer tongue: floor Z 36.19 / 36.23, step face 0.2 off the tongue side; contact rings at B3 and B4", "0 - gap 0.42 over the strip"),
     ("K3", "Boss B1 pad on outer hub F5", "109.3", "3.68", "Pad faces raised 35.32 -> 36.07; pocket Ø10 -> Ø10.4", "0 - face contact"),
     ("K4", "+X joint wall incl. boss B2, Y -30..53", "95.4", "0.75", "Rebate floor Z 36.19; B2 boss face Z 36.07", "0 - gap 0.12 / contact"),
     ("K5, K10", "-X hip corner incl. pin P3, Y 241..287", "58.4", "0.92", "Floor raised to Z 36.36 over the outer plate Z 36.24; P3 base recess Ø9.4", "0 - gap 0.12"),
     ("K6", "Hip seat flat, X 21..55, Y 266.5..269.5", "34.7", "0.35", "Seat flat raised 84.85 -> 85.28", "0 - gap 0.08"),
     ("K7", "Boss B7 face (-22.00, 264.93)", "16.8", "0.17", "Boss face raised 36.07 -> 36.24 onto the outer boss top (Z 36.24)", "0 - face contact"),
     ("K8, K9", "Hip rib ends at X 11 and X 65, Y 267", "17.9", "0.50", "Rib ends cut back Y 267.0 -> 266.3", "0 - gap 0.20"),
     ("K11-21", "+X hip corner, X 110..114, Y 266..277", "1.1", "0.75", "Floor Z 36.19 over the outer Z 36.07, step 0.2 off the wall", "0 - gap 0.12"),
     ("K22", "Next to boss B4, X -11.5..-2.5", "0.045", "0.01", "Face 36.06 -> 36.07", "0"),
     ("Total", "", f"{ms['before']['total_mm3']:.1f}", "", "", f"{ms['after']['total_mm3']:.2f} (2 mesh cells)")]
rows = [["Zone", "Location", "Before [mm3]", "Max. thick. [mm]", "Change made on the inner", "After"]] + [list(z) for z in Z]
t = table(rows, [13, 38, 15, 15, 68, 25], fs=7.4)
t.setStyle(TableStyle([("FONT", (0, len(rows) - 1), (-1, len(rows) - 1), "Helvetica-Bold", 7.4), ("LINEABOVE", (0, len(rows) - 1), (-1, len(rows) - 1), 0.9, colors.HexColor("#56606b"))]))
E.append(t)
E.append(Spacer(1, 2 * mm))
E.append(Paragraph("The outer Rev F final differs from the export used for the first check only where it does not meet the inner "
                   "(the -X strip was lowered to Z 35.81, which turns the K2 floor gap from 0.12 into 0.42 mm, and three features "
                   "below the inner); all fit changes were re-checked against the final outer.", S))
E.append(PageBreak())
E.append(Paragraph("Interference map before and after", H2))
E.append(img("LT-ASM-001_interference_before_after.png", hmax=225 * mm))

# ---------------- page 3: axes
E.append(PageBreak())
E.append(Paragraph("5. Screw axes", H2))
E.append(Paragraph(
    "Each boss joins the shells with one screw: Ø6 clearance hole through the inner boss web, Ø5.2 tap hole in the outer boss "
    "(blind). The inner Ø10 (B1, B5: Ø10.4) pocket sits over the outer Ø10 locating nub. Values read on each axis from the final "
    "STEP solids.", B))
E.append(Spacer(1, 2 * mm))
AX = [("B1", "61.35, -40.01", "0.064", "0.34", "33.00", "39.17-44.87", "Ø10.4 / Ø10, 0.14", "0.17", "36.07"),
      ("B2", "75.85, 29.86", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.07"),
      ("B3", "-25.10, 77.45", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.07"),
      ("B4", "-17.05, 165.91", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.07"),
      ("B5", "86.45, 165.96", "0.000", "0.40", "27.04", "39.17-44.87 (new)", "Ø10.4 / Ø10, 0.20", "0.13", "36.07"),
      ("B6", "97.95, 264.95", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.07"),
      ("B7", "-22.00, 264.93", "0.000", "0.40", "27.04", "39.17-44.87", "Ø10 / Ø10, 0.00", "0.13", "36.24")]
rows = [["Axis", "Axis X, Y [mm]", "Ø6 / Ø5.2 axis offset [mm]", "Radial clear. Ø6 over Ø5.2 [mm]", "Outer Ø5.2 hole bottom Z",
         "Inner web Z", "Pocket / nub, radial clear. [mm]", "Pocket floor over nub top [mm]", "Boss face Z (contact)"]] + [list(a) for a in AX]
E.append(table(rows, [11, 24, 18, 19, 19, 23, 26, 18, 16], fs=7.4))
E.append(Spacer(1, 1.5 * mm))
for n in ["All seven screw paths are clear: the Ø6 holes are open through the inner and line up with the outer Ø5.2 holes "
          "(B1 0.064 mm off, inside its 0.34 mm radial clearance). The outer tap holes are blind; B1 sits on the outer hub F5, "
          "where the Ø5.2 hole is 6 mm deep (to Z 33.0).",
          "Ø10 pockets on Ø10 nubs (B2, B3, B4, B6, B7) are size on size in the CAD, as in Rev A and Rev B. The fit is set by "
          "the drawing tolerance (slip fit); B1 and B5 have Ø10.4 pockets.",
          "At B1 the inner Ø15 boss column stands on the outer F5 hub column with its axis 0.62 mm off the hub's; the two "
          "columns meet end to end at the contact face, they do not overlap."]:
    E.append(Paragraph("&bull; " + n, B))

E.append(Paragraph("6. Pins and hip ring", H2))
rows = [["Feature", "Position X, Y [mm]", "Fit", "Axis offset [mm]", "Radial clearance [mm]", "Axial"],
        ["Hip pin E1 (inner Ø4.0 in outer slot Ø4.30)", "27.04, 271.74", "Ø4.0 / Ø4.30", "0.041", "0.109", "engagement 5.8; tip Z 79.40 over slot floor 79.20 = 0.20"],
        ["Hip pin E2 (inner Ø4.0 in outer slot Ø4.30)", "49.02, 271.75", "Ø4.0 / Ø4.30", "0.050", "0.100", "engagement 5.8; tip 0.20 over slot floor"],
        ["Locating pin P1 (outer Ø4 in inner Ø4 hole)", "97.46, 131.44", "Ø4 / Ø4", "0.000", "0.00 (size on size)", "pin top 41.98 under hole bottom 45.32"],
        ["Locating pin P2", "108.97, 194.32", "Ø4 / Ø4", "0.000", "0.00 (size on size)", "pin top 41.98 under hole bottom 45.32"],
        ["Locating pin P3", "-38.09, 245.35", "Ø4 / Ø4", "0.000", "0.00 (size on size)", "pin top 42.25 under hole bottom 46.36; base Ø9 in Ø9.4 recess, 0.12 above"],
        ["Hip ring seat (inner Ø105.4 on outer ring Ø105.03)", "axis X 37.97, Z 35.18", "Ø105.4 / Ø105.03", "0.18", "0.005 min (0.185 nominal)",
         "seat flat Z 85.28 over ring top 85.20 = 0.08; rib ends Y 266.3 vs flange 266.5 = 0.20"]]
E.append(table(rows, [42, 24, 22, 15, 22, 49], fs=7.2))
E.append(Spacer(1, 1.5 * mm))
E.append(Paragraph("The hip ring seat arc is 0.18 mm off the ring axis, so its radial clearance runs from 0.005 mm on one side to "
                   "about 0.37 mm on the other; no overlap. The Ø4 pin holes are size on size with the pins, as in Rev A and B "
                   "(slip fit per drawing).", S))

# ---------------- page 4: joint
E.append(PageBreak())
E.append(Paragraph("7. Joint clearance", H2))
E.append(Paragraph(
    "Where the inner sits over the outer, the vertical gap between the outer face and the inner face above it. Contact (dark "
    "green) only on the boss faces and the B1 pad; the lip keeps its 0.56 mm shadow gap all round; rebate floors stand 0.12 mm "
    "over the tongue (+X side, hip corners) and 0.42 mm over the lowered -X strip; pocket floors 0.13 mm over the nubs; hip "
    "seat 0.08 mm over the ring top.", B))
E.append(Spacer(1, 2 * mm))
E.append(img("LT-ASM-001_clearance_map.png", hmax=190 * mm))

E.append(PageBreak())
E.append(Paragraph("8. Joint clearance profile", H2))
jr = json.load(open(os.path.join(Q, "joint_rows.json")))
E.append(Paragraph(
    f"The same gap read along {len(jr)} stations across the tongue on both joint walls and the two hip corners. Zero values "
    "are stations that cross a boss contact face (B3, B4, B1, B2, and B7 at the hip end); the single 1.04 mm reading at "
    "Y -32 is the rebate corner next to the B1 pad. No station shows overlap.", B))
E.append(Spacer(1, 2 * mm))
E.append(img("LT-ASM-001_joint_gap_profile.png"))
E.append(Spacer(1, 3 * mm))
E.append(Paragraph("Mating planes (planar faces normal to Z in the joint, area in mm2):", B))
pl = fit["joint_planes"]
rows = [["Side", "Z", "Area", "Side", "Z", "Area"]]
half = (len(pl) + 1) // 2
for i in range(half):
    a = pl[i]; b = pl[i + half] if i + half < len(pl) else None
    rows.append([a["side"], f"{a['z']:.2f}", f"{a['area']:.0f}"] + ([b["side"], f"{b['z']:.2f}", f"{b['area']:.0f}"] if b else ["", "", ""]))
E.append(table(rows, [25, 16, 16, 25, 16, 16], left=True))

# ---------------- sections
E.append(PageBreak())
E.append(Paragraph("9. Sections before and after", H2))
E.append(Paragraph("Left: the Rev E inner as first modelled with the Rev F outer, overlap in dark red. Right: the delivered Rev E "
                   "inner with the final Rev F outer. Dimensions in mm, model frame.", B))
E.append(Spacer(1, 2 * mm))
for i, n in enumerate(["B5_boss", "B1_pad", "mx_wall", "mx_hip_corner", "hip_seat", "B7_boss"]):
    if i == 3:
        E.append(PageBreak())
    E.append(img(f"LT-ASM-001_section_{n}.png", hmax=72 * mm)); E.append(Spacer(1, 3 * mm))

doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=18 * mm,
                        title=TITLE, author="", subject="Fit and collision check, LT-ASM-001 Rev E")
doc.build(E, onFirstPage=footer, onLaterPages=footer)
print("wrote", OUT)
