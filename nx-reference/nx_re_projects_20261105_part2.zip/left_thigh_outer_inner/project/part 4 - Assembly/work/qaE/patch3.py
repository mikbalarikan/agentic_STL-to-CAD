p = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\work\qaE\a3_plots.py"
t = open(p, encoding="utf-8-sig").read()
t = t.replace("cax = fig.add_axes([0.25, 0.085, 0.5, 0.015])", "cax = fig.add_axes([0.25, 0.065, 0.5, 0.013])")
t = t.replace("fig.subplots_adjust(left=0.07, right=0.98, top=0.93, bottom=0.12, wspace=0.18)", "fig.subplots_adjust(left=0.07, right=0.98, top=0.92, bottom=0.15, wspace=0.18)")
open(p, "w", encoding="utf-8").write(t)
p = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\work\qaE\a4_pdf.py"
t = open(p, encoding="utf-8").read()
a = 'E.append(Spacer(1, 3 * mm))\nE.append(img("LT-ASM-001_interference_before_after.png", hmax=125 * mm))'
assert a in t
t = t.replace(a, 'E.append(PageBreak())\nE.append(Paragraph("Interference map before and after", H2))\nE.append(img("LT-ASM-001_interference_before_after.png", hmax=225 * mm))')
open(p, "w", encoding="utf-8").write(t)
print("ok")
