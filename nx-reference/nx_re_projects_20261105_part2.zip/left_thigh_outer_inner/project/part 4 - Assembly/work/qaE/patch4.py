p = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\work\qaE\a2_secs.py"
t = open(p, encoding="utf-8-sig").read()
a = 'overlap in this section: {ov:.2f} mm2'
assert a in t
t = t.replace(a, 'overlap over the whole section plane: {ov:.2f} mm2')
open(p, "w", encoding="utf-8").write(t)
print("ok")
