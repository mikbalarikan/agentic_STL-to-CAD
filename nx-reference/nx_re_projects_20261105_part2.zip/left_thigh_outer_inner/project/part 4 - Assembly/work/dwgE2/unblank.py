# -*- coding: utf-8 -*-
"""Work copy only (part 4 - Assembly/work/dwgE2/model): show the two components the user saved blanked, save the copy.
args: <work assembly prt> <out json>"""
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen  # noqa: E402
import nxh  # noqa: E402

ASM, OUT = sys.argv[1], sys.argv[2]
res = {"result": "FAIL"}
try:
    assy = nxh.open_part(ASM)
    res["parts"] = [p.FullPath for p in nxh.S.Parts]
    bad = [p for p in res["parts"] if os.path.normcase(os.path.dirname(p)) != os.path.normcase(os.path.dirname(ASM))]
    if bad:
        raise RuntimeError("loaded from outside the work folder: %s" % bad)
    kids = list(assy.ComponentAssembly.RootComponent.GetChildren())
    res["before"] = {c.Name: [c.IsBlanked, c.ReferenceSet] for c in kids}
    nxh.S.DisplayManager.ShowObjects(kids, NXOpen.DisplayManager.LayerSetting.ChangeLayerToSelectable)
    # the inner is on "Entire Part" in the user's file, which also shows its 4 helper sheet bodies: drawing copy -> SOLID
    for c in kids:
        if c.ReferenceSet != "SOLID":
            assy.ComponentAssembly.ReplaceReferenceSet(c, "SOLID")
    res["after"] = {c.Name: [c.IsBlanked, c.ReferenceSet] for c in kids}
    assy.Save(NXOpen.BasePart.SaveComponents.FalseValue, NXOpen.BasePart.CloseAfterSave.FalseValue).Dispose()
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
