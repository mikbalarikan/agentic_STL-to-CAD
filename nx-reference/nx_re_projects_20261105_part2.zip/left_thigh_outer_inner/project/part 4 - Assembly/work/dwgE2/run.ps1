param([string]$Script, [string[]]$JArgs, [int]$TimeoutSec = 2400)
$env:NXH_DIR = "H:\My Drive\NX HARNESS VERSIONS\v2\skills\nx-journal-core\scripts"
& "H:\My Drive\NX HARNESS VERSIONS\v2\skills\nx-journal-core\scripts\run_journal.ps1" -Script $Script -JArgs $JArgs -WorkDir "C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 4 - Assembly\work\dwgE2" -TimeoutSec $TimeoutSec | Select-Object -Last 25
