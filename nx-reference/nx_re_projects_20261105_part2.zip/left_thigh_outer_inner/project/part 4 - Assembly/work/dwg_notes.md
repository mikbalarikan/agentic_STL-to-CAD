# LT-ASM-001 drawing - progress notes

- dwglib copied from part 2 to A\nx\dwglib; m3d.B -> A\nx\dwg, ptdwg.DATE -> 2026-10-30. _patch.py copied, never run.
- Journals save the drawing with SaveComponents=False (nxh.save patched) so the assembly / component prts are never written.
- dwg_probe1: probe run (assembly structure, knee-axis cylinders, section orientation when placed right of parent, hatch API).
- probe1 result: section hinge is always horizontal in the parent (placement does not rotate it) -> sheet 2 uses a key plan turned 90 deg (Orient View Tool / view angle fallback) so horizontal cuts are model-Y cuts. 2 Hatch objects per section (one per component), HatchBuilder has Angle/Distance. Outer datum B = bore D110 H7 (z -4.12..0), inner datum B = D19.90 H7 (z 80.02..93).
- dwg_run1: first full run of nx/dwg_asm.py (both sheets, dims, balloons, tables, export). an/raster.py tiles the PDF.
- dwg_run1 PASS: views/dims OK; fixes for run2: parts list overlapped title block (text wrap), balloon stub side, detail F label inside D-D (move), F below-dims vs label, small-dim text over extension lines, G hatch both inner (classification), table '0.00' rendered '-', drop D135.70 (outer hub open at y=0). Exact OCC bbox 186.709 x 355.25 x 151.70 (brief bbox was padded).
- dwg_run2 PASS: sheet 1 clean. Sheet 2 fixes for run3: F parent label -> Circle + own letter note outside wall (moving the NX label kept its leader anchor = crossing); G dims both right of G (0.56 was next to F's 3.34); F below-dims text moved left of extension lines.
- dwg_run3 PASS: sheet 2 clean except 0.56 text touching its extension line -> run4 moves it lower.
- dwg_run4 FINAL (PASS, clean visually on both sheets whole + 6 tiles each at 200 dpi). Copied PDFs/DWGs/drawing prt to deliver/Drawings.
