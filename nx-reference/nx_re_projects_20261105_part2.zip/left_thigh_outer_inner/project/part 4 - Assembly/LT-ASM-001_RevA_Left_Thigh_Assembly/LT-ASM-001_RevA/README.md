# LT-ASM-001 Rev A: Left Thigh Assembly (LT-OUT-001 + LT-INN-001)

The outer shell LT-OUT-001 and the inner shell LT-INN-001 mounted together, as one assembly. It shows that the two
parts were modelled and drawn to fit each other. Both parts were reverse-engineered in Siemens NX 2206 in **one shared
coordinate system**, so they assemble exactly as modelled: both components sit at the origin, with no moving, aligning
or constraints.

## Components

| Item | Part number | Revision | Description | Material | Qty | Volume | Mass |
|---|---|---|---|---|---|---|---|
| 1 | LT-OUT-001 | A | Left thigh, outer shell | Al 6061-T6 | 1 | 385 943 mm³ | 1.04 kg |
| 2 | LT-INN-001 | A | Left thigh, inner shell | Al 6061-T6 | 1 | 335 389 mm³ | 0.91 kg |
| | | | **Assembly** | | | | **1.95 kg** |

The parts themselves (part drawings, deviation reports, all formats) are in their own packages,
`LT-OUT-001_RevA_Left_Thigh_Outer.zip` and `LT-INN-001_RevA_Left_Thigh_Inner.zip`. The CAD files of both parts in this
package are the same Rev A files.

## Contents

| Folder / file | What it is |
|---|---|
| `CAD/LT-ASM-001_Left_Thigh_Assembly_AP214.step` | Assembly STEP AP214 with its product structure: assembly LT-ASM-001 with the two parts LT-OUT-001 and LT-INN-001. Opens as an assembly in SolidWorks, Fusion 360, Inventor, Creo, etc. |
| `CAD/LT-ASM-001_Left_Thigh_Assembly_AP242.step` | The same assembly in STEP AP242 |
| `CAD/LT-ASM-001_Left_Thigh_Assembly.prt` | Native NX assembly. It loads the two component parts below from the same folder: keep the three .prt files together |
| `CAD/LT-OUT-001_Left_Thigh_Outer.prt`, `CAD/LT-INN-001_Left_Thigh_Inner.prt` | The NX component parts (Rev A, full feature history, reference set `SOLID`) |
| `CAD/LT-ASM-001_Left_Thigh_Assembly.stl` | Both parts in one STL, in the assembly frame (for viewing) |
| `CAD/LT-OUT-001_Left_Thigh_Outer.stl`, `CAD/LT-INN-001_Left_Thigh_Inner.stl` | One STL per part, same frame |
| `Drawings/LT-ASM-001.pdf` | Assembly drawing, 2 x A1, third-angle projection. SH1 general arrangement: assembled top, front and side views, isometric, overall dimensions 355.25 x 186.71 x 151.69, parts list, balloons 1 and 2. SH2 mating interface: stepped section D-D through bosses B4 / B5 and pin P2 (inner seated on the outer boss faces), section E-E through the knee axis (datum B of both parts on one axis: LT-OUT-001 Ø110.00 H7, LT-INN-001 Ø19.90 H7), detail F 4:1 (Ø10 nub in its pocket, 0.13; Ø4 pin in its hole; screw holes), detail G 10:1 (parting line, 0.56 shadow gap, 0.12 over the tongue), interface table and the fastening note. Outer and inner have different hatching |
| `Drawings/LT-ASM-001_SH1..2.pdf`, `_SH1..2.dwg` | The same sheets, one PDF and one DWG per sheet |
| `Drawings/LT-ASM-001_dwg.prt` | Native NX drawing (master-model, associative to the assembly in `CAD/`) |
| `Renders/` | Shaded views, outer shell blue, inner shell grey: outside from both sides, hip end, side, exploded, and the two open sides |

## Coordinate system (shared by both parts)

- Origin: on the knee axis, at the knee floor plane of LT-OUT-001.
- +Z: the knee axis, pointing from the outer shell towards the inner shell.
- +Y: the direction of the hip-ring axis (knee → hip). The hip-ring axis is the line X = 37.97, Z = 35.18.
- Units: mm.

## Fit check

The two STEP AP242 files were read with OpenCascade, independently of NX:

- Interference (boolean common of the two solids): **0.0 mm³**. NX interference check on the assembly: faces in contact only, no overlapping volume.
- Contact: only on the 7 boss faces (Z 36.07, datum A of both parts), face to face; minimum distance 0.0 mm.
- **21 mating features aligned**, largest axis offset 0.0 mm: 7 Ø10 locating nubs of LT-OUT-001 in the 7 Ø10 pockets of
  LT-INN-001, 3 Ø4 locating pins in the 3 Ø4 pin holes, 7 boss screw holes (inner Ø6 on outer Ø5.2), 4 boss columns Ø15.
- Parting line: the inner lip face (Z 35.32) stays 0.56 mm above the outer rim (Z 34.76) all round, the shadow gap
  both scans show. Rebate floor 0.12 mm over the tongue, pocket floors 0.13 mm over the nub tops.
- The assembly STEP files were re-read too: one assembly, two parts, one valid solid each, both placed at the origin
  without rotation, volumes equal to the part files.

## Notes

1. **Fasteners.** The CAD shows 7 boss joints: LT-INN-001 Ø6.0 through with a Ø10.40 counterbore from the outside, on a
   Ø5.2 hole in LT-OUT-001. No screw is defined in the CAD: fasteners by customer.
2. **Contact only on the boss faces.** If the lip faces should touch instead of keeping the 0.56 mm shadow gap, it is
   one value (lip Z) in LT-INN-001 (see its README).
3. **Projection.** The drawings are third angle (ASME), as the part drawings.
