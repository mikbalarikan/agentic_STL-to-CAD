# LT-OUT-001 Left Thigh - Outer shell: reverse-engineering report

Source: `SHARE -  Left Thigh - Outer.stl` (7 266 929 triangles, 3D-scan mesh, open in places).
Native CAD: Siemens NX 2206, solid body `LEFT_THIGH_OUTER`, rebuilt feature by feature on the scan (not a mesh conversion).

## Part data

- Volume 385,943 mm3, mass 1.042 kg in Al 6061 (2.70 g/cm3).
- Bounding box (model frame) [-68.995, -67.85, -40.806, 118.934, 288.708, 85.2].
- Model frame: origin on the knee-bore axis at the knee-floor plane; +Z = knee axis toward the open side;
  +Y = direction of the hip-ring axis (knee -> hip); X completes a right-handed frame.

## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)

| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |
|---|---|---|---|---|---|---|---|
| whole part | 1,500,000 | +0.076 | 0.053 | 0.541 | 0.983 | 79.8 % | 89.2 % |
| outer freeform skin | 402,851 | +0.016 | 0.021 | 0.206 | 0.352 | 89.7 % | 97.4 % |
| knee hub (r < 70) | 310,365 | +0.053 | 0.113 | 0.670 | 0.937 | 69.3 % | 83.9 % |
| hip ring / plate (y > 262) | 245,389 | +0.154 | 0.047 | 0.485 | 1.128 | 84.9 % | 90.2 % |
| interior (ribs, pockets, bosses) | 541,395 | +0.098 | 0.082 | 0.825 | 1.459 | 76.3 % | 85.8 % |

CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 0.066, p90 1.005, p95 1.978 mm.
