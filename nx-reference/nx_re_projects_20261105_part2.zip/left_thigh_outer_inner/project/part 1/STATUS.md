# LT-OUT-001 (Left Thigh, Outer shell): current status

Current revision: **Rev C** (2026-10-31). Package: `LT-OUT-001_RevC_Left_Thigh_Outer.zip`, built from `deliver_RevC/`.
Client text: `CLIENT_MESSAGE_RevC.txt`. Not sent. Details: `STATUS_RevC.md`.

| Rev | Date | State |
|---|---|---|
| A | 2026-10-25 | Delivered (`deliver/`, `LT-OUT-001_RevA_Left_Thigh_Outer.zip`) |
| B | 2026-10-30 | Cancelled, never sent (`deliver_RevB/`); its slots are in Rev C |
| C | 2026-10-31 | Ready, not sent (`deliver_RevC/`) |

Final master prt: `deliver_RevC\CAD\LT-OUT-001_Left_Thigh_Outer.prt`. Final AP242:
`deliver_RevC\CAD\LT-OUT-001_Left_Thigh_Outer_AP242.step`. Source of both:
`Deviation_Check\LT-OUT-001_RevC_Left_Thigh_Outer_vs_SCAN.prt`. It is the user's 06:56 save of `..._vs_SCAN_CONN.prt` plus
the rim fix made after the assembly fit check (REVC_RIM_RABBET, REVC_PAD_WALL_BACK_0P15).
Open: a 1.36 mm3 overlap with LT-INN-001 Rev A remains where the scan calls for the outer's 36.07 tongue (inner side;
see the last section of `STATUS_RevC.md`).
