# LT-OUT-001 Rev C (Left Thigh, Outer shell): status

Built 2026-10-31. **Revision name: Rev C.** Rev A was delivered on 2026-10-25. Rev B (2026-10-30) was cancelled and
never sent; its two slots are included in Rev C. **Nothing has been sent to the client.**

**Package:** `LT-OUT-001_RevC_Left_Thigh_Outer.zip` (41.3 MB, 38 entries, testzip OK), built from `deliver_RevC/` by
`an/c7_package.py`. It has the same layout as Rev B. Client text: `CLIENT_MESSAGE_RevC.txt`, which describes the
changes against Rev A, the revision the client has.

## Master

- **Master (the user's final hand-edited part):** `Deviation_Check/LT-OUT-001_RevB_Left_Thigh_Outer_vs_SCAN_CONN.prt`,
  saved 2026-10-31 06:56.
  - Frozen copy: `work/revC/master_0656.prt`.
  - Backup: `Deviation_Check/_backup_2026-10-31/..._CONN_0656_final.prt`.
- **History on top of Rev B:**
  - The user's own edits.
  - Hip-end connector pad (`nx/conn_pad.py`, `CONN_*`).
  - Interior details K1 / R1 / T1 / T2 (`nx/fix_r2.py`, `FIX_*`).
  - The user's further retouches: Replace Face, Offset Region, blends, and 2 pins placed on scan Fit Surfaces.
- **Delivered NX part:** `deliver_RevC/CAD/LT-OUT-001_Left_Thigh_Outer.prt` (scan removed, 18.3 MB).

## Finalize (`nx/finalize.py <master> deliver_RevC/CAD C`): PASS

- The scan could not be deleted directly ("Update undo happened"). Two Point features (332, 339) placed the user's two
  pins on Fit Surface(Cylinder) 331 / 338, which were fitted to the scan.
  - finalize now first turns such points into fixed points at the same coordinates:
    - Point(332): (-56.7281, 19.5651, 8.0365)
    - Point(339): (-30.9759, -51.41, 9.8966)
  - It then deletes the scan plus the failed Fit Surface / Delete Body features (331, 337, 338, 342).
  - Solid volume before / after: 390 417.5868 / 390 417.5867 mm3. Feature errors: 0.
  - Without the point fix the pins were lost (-46.68 mm3). The new volume assert caught this.
- **Result (first draft, superseded by the update at the end):** 390 417.6 mm3, 1.054 kg Al 6061. One solid, body_ok, examine all 0. Attribute REVISION C.
- **Exports:**
  - AP214 9.7 MB, AP242 3.2 MB, x_t 5.2 MB, STL 23.7 MB.
  - The NX STEP round trip still imports nothing, as in Rev A / B.

## STEP check (OCP, `work/revC/bboxcheck.py` -> `work/revC/stepcheck_revC.json`)

| file | solids | valid | volume | vs prt | bbox (optimal) vs prt tessellation |
|---|---|---|---|---|---|
| AP214 | 1 | yes | 390 471.3 | +0.014 % | max 0.002 mm |
| AP242 | 1 | yes | 390 432.5 | +0.004 % | max 0.002 mm |

Exact bbox: X -68.15 .. 118.85, Y -68.25 .. 287.40, Z -40.75 .. 85.20.

## Rev C vs Rev A geometry

- **Volume:** +4 474.7 mm3 (Rev A 385 942.9).
- **Knee-hub OD:** now R68.25 between Z 10 and 34.76 (Rev A R67.85), so the overall length is 355.65 (was 355.25).
  The knee-bore Ø110 top edge is now split into arcs at Z 0.
- **Locating slots S1 / S2:** **present.**
  - Ø4.30 blind holes, top Z 85.20, floor Z 79.20.
  - Centres (X 27.03, Y 271.70) and (X 49.02, Y 271.70).
  - Probed on the delivered STL: open at r 2.05, solid at r 2.25; open at Z 79.4, solid at Z 79.0.

## Drawings (`nx/make_dwg_revC.py` -> `nx/dwg_revC.py`, final run `work/dwgC4`): PASS

- 20 dimensions read back from the Rev C part, 0 errors, 0 view overlaps. All 4 sheets rasterised and checked by eye.
- Rev C changes to the sheets:
  - Revision block with the C rows (B marked not issued).
  - SH3: connector-pad table and two hole callouts.
  - SH4: table rows and balloons for K1, R1, T1, T2.
- Changes needed by the user's model edits:
  - `c_knee` now uses R68.25. L_overall expects 355.65.
  - The knee-bore centre for the 266.50 / 276.85 basic dims comes from `arc_xy` on the bore axis. It picks the
    concentric R48 arc because the R55 top edge is split.
- Read-back values equal Rev B except L_overall:
  - D110, D125.5, D92, D96, PCD 102.92 / 91.45
  - HD82 81.98, HD85.96, HD97.54
  - Z steps, S 4.30 / 6.00

## QA

- `an/dev2.py <Rev C stl> revC` and `an/report.py`, then the Rev C sections appended to
  `deliver_RevC/QA/REPORT_deviation.md`.
- Local Rev A vs Rev C by region: `an/c5_localdev.py` -> `work/revC/localdev.json`.
- Within 0.5 mm, Rev A -> Rev C:

| zone / region | Rev A | Rev C |
|---|---|---|
| whole part | 89.2 % | 91.0 % |
| knee hub | 83.9 % | 88.7 % |
| hip ring | 90.2 % | 92.8 % |
| connector pad | 51.1 % | 86.5 % |
| K1 | 69.2 % | 85.7 % |
| R1 | 82.2 % | 94.7 % |
| T1 | 78.5 % | 92.9 % |
| T2 | 77.1 % | 97.5 % |

- Renders: `an/c8_renders.py` (Rev A views + slots + connector pad + interior details).
- **Fit with LT-INN-001 was not re-run here.** The assembly session (LT-ASM-001) re-checks it with the current inner.
  Its note: the inner pins E1 / E2 are Ø4.0, tip Z 79.42, so they clear the Rev C slot floor Z 79.20.

## Final paths

- Master prt: `C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\deliver_RevC\CAD\LT-OUT-001_Left_Thigh_Outer.prt`
- AP242: `C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\deliver_RevC\CAD\LT-OUT-001_Left_Thigh_Outer_AP242.step`

## Update 2026-10-31 afternoon: rim fix after the assembly fit check (this is the current Rev C)

The assembly session (LT-ASM-001) found that the first Rev C runs into the inner LT-INN-001 Rev A lip on the -X hip-end
wall: 17.94 mm3, 188 inner samples inside. Cause: the user's retouch had raised the whole wall top to 36.07. The user
decided "Restore the outer rim", provided the scan does not call for 36.07.

- **Scan check** (`work/revC2/ysecs.png`, `rim_y.png`, `plan_rim.png`, Y 243-287): the scan has a tongue on the inner part
  of the wall at scan Z 36.3 and a rabbet about 1.3 wide on the outer side at scan Z 35.05-35.1. With the local +0.23 scan
  offset that is 36.07 / 34.76. Rev A was flat here (36.07 for Y < 266, 34.76 for Y > 266).
- **Fix** (`nx/fix_r3_rim.py`): the new master is `Deviation_Check/LT-OUT-001_RevC_Left_Thigh_Outer_vs_SCAN.prt`, which is
  the 06:56 save plus 2 features.
  - `REVC_RIM_RABBET`: thin-wall extrude of the outer top edge chain, -1.3 / +0.3. NX's offset sign is the inverse of the
    obvious one; the probes caught it. It cuts 36.07 -> 34.76 and removes 85.57 mm3. The tongue and the Z 42.2 tab are kept.
  - `REVC_PAD_WALL_BACK_0P15`: Offset Region -0.15 on the planar outer wall of the boss lobe at (61.35, -40.01). The face
    runs Z -10.4 .. 36.07 and the scan lies about 0.2 inside it. Removes 59.56 mm3.
- **Volume** 390 272.46 mm3, one solid, examine 0. Slots S1/S2 unchanged.
- **STEP:** AP214 390 244.3 (-0.007 %), AP242 390 300.0 (+0.007 %), bbox within 0.002 mm.
- **Drawings:** `work/dwgC5`, 20 dimensions identical to dwgC4, 0 errors, 0 overlaps.
- **Deviation:** whole part 91.1 % within 0.5 mm. -X rim zone 39.9 % (Rev A) -> 80.8 % (Rev C draft) -> 81.3 %. Boss-lobe
  wall 22.2 % (Rev A) -> 20.1 % (Rev C draft) -> 36.0 %.
- **Fit with LT-INN-001 Rev A AP242** (`part 4 - Assembly/an/fit_check.py`, `work/revC2/fit_revC2.json`):
  - Interference 17.94 -> **1.36 mm3**; inner samples inside 188 -> **23**.
  - What remains is all on the inner edge of the diagonal stretch, (-35.3..-32.6, Y 276..286).
  - There the scan top is Z 36.22-36.31 (tongue, 36.07 in CAD), while the inner CAD's lip comes down to 35.32 / 36.19.
    This is the inner's side. Following the user's rule (scan calls for 36.07 -> do not change), the outer was not
    changed there. Reported to the assembly session with this evidence.
  - Kept out of the client report.
- The first Rev C draft (before the rim fix) is kept in `work/revC/v1` (CAD + zip).
- 2026-10-31: the user decided "Trim inner lip". The outer Rev C stays as it is; the inner LT-INN-001 lip comes back about
  0.75 mm locally (Y 274-287) in the inner / assembly session. The decision and the 5 contact points were passed to the
  assembly session.
