# Left Thigh (outer): internal notes and re-run chain

Delivery: `deliver/` (CAD, Drawings, QA, Renders, README). Everything below is internal.

## Re-run order (venv = `C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe`, NX via `run_journal.ps1`)

1. `an/s0_load.py` → `work/scan.npz` (welded scan). The frame is in `work/frame.json`
   (origin knee axis × knee floor, Z knee axis, Y hip axis).
2. Outer skin: `an/s10_skin.py 1.0 12 6 1e-2 data` → `an/s11_skin2.py 8 4 3e-3` (YF = -30, seam exclusion) →
   `an/s12_sections.py 42 8 skin_fit sections`.
3. Inner skin: `an/s14_inner.py` → `an/s12_sections.py 42 8 inner_fit inner_sections`.
4. Plateaus: `an/hmap2.py` → `an/s16_outlines.py` → `an/s19_platnx.py`. Windows: `an/s20_windows.py` →
   `an/s21_winloops.py`. Grooves: `an/s22_grooves.py` → `an/s23_groove_paths.py`.
5. NX build: `nx/build2.py <out> H` (stages A-H, about 13 min). Stage I (root fillets) does NOT work: NX refused
   23 of 35 chains, and the 12 it accepted made the body invalid. Keep stopping at H.
6. `nx/finalize.py <out>/Left_Thigh_Outer.prt deliver/CAD` → STEP 214/242, x_t, STL, ref set SOLID.
7. `nx/dwg_main.py deliver/CAD/LT-OUT-001_Left_Thigh_Outer.prt deliver/Drawings full` → 4 sheets PDF + DWG.
8. QA: `an/dev2.py <stl> final 1500000`, `an/hdiff.py <stl> tag`, `an/report.py`, `an/stepcheck.py <step>`.

All numbers: `nx/params.json`.

## Traps met

- The inner loft from y < -30 is inconsistent (BodyConsistency) and poisons every later boolean. Start it at -30
  (the knee hub cavity is analytic there).
- A refit of the outer skin with real data at y -56..-30 made every trim fail ("intersection gaps"). Keep the
  frozen fit and use the revolved knee wrap (`params.wrap`, R(z) measured) for the +x corner.
- NX batch runs queue on the licence: two launches run one after the other, and both write the same `build.json`.
  Use one output folder per run.
- The block top must stay below the lowest section end (sections end at z ≥ 45.7; block top 44).
- Subtracting the hip-plate slab splits the cavity tool into pieces: subtract all of them.
- In finalize, pick the non-blanked solid (the blanked one is the envelope copy).

## Scan overlay for checking deviation by eye (`Deviation_Check/`)

`an/s30_scan_aligned.py` → `work/overlay/scan_in_part_frame.stl` (the scan moved by `frame.json`), then
`nx/overlay.py <deliver prt> Deviation_Check/LT-OUT-001_Left_Thigh_Outer_vs_SCAN.prt <aligned stl> work/overlay/probe_pts.json`.
The delivered prt is copied, never edited. The scan comes in as 4 convergent bodies on layer 10 (main shell 7.26 M facets + 3 fragments), orange, 50 % translucent.

## Rev A final (2026-10-25, after the user's own NX edits)

- The user edited `Deviation_Check/LT-OUT-001_Left_Thigh_Outer_vs_SCAN.prt` (3 Replace Face, Offset Region, 2 Edge Blend).
  That file is the master. `nx/finalize.py <that prt> deliver/CAD` deletes the 4 Convergent Body features in the copy
  (volume unchanged) and exports. NX's own STEP re-import still imports nothing: check with `an/stepcheck.py`.
- Drawings: `nx/dwg_main.py` (layout v2; v1 kept as `dwg_main_v1.py`), GD&T helpers in `nx/dwglib/gdt.py`
  (FCF data: Append first, then fill FindItem(0); stacking under a dimension = AssociativeOriginData.OffsetAnnotation),
  balloon placement from `work/plan_outline.json` (`an/s31_outline.py`). Build into `work/dwg2`, then copy to deliver.
- QA: `an/dev2.py deliver/CAD/...stl revA2`, `an/report.py deliver/CAD revA2`, move the report to deliver/QA.
- Zip: `LT-OUT-001_RevA_Left_Thigh_Outer.zip` (deliver/ without _finalize.json); client text in `CLIENT_MESSAGE.txt`.

## Rev B (2026-10-30): two hip-end locating slots for LT-INN-001

`nx/revB_slots.py <Rev A master> <run dir>/...prt` (copy, never the master) -> `Deviation_Check/LT-OUT-001_RevB_Left_Thigh_Outer_vs_SCAN.prt`
-> `nx/finalize.py <that> deliver_RevB/CAD B` -> drawings `nx/make_dwg_revB.py` (writes `nx/dwg_revB.py`) into `work/dwgB*`
-> `deliver_RevB/Drawings`; QA `an/dev2.py ... revB`, `an/report.py deliver_RevB/CAD revB`, `an/b5_slotdev.py`, fit `an/b6_fit.py`,
`an/b4_protochk.py`; renders `an/b8_renders.py`; package `an/b7_package.py`. Details and numbers: `STATUS_RevB.md`.

## Connector pad on the hip-end face (2026-10-31)

The user finished their own edits on `Deviation_Check/LT-OUT-001_RevB_Left_Thigh_Outer_vs_SCAN.prt` (saved 2026-10-30 23:44)
and asked for the last missing detail only: the 4-hole pad below the hip ring. `nx/conn_pad.py <src prt> <dst prt>` (run on a
local copy; the source is never written) appends CONN_PAD (sector revolved about the hip axis, R 52.4-66.2, 28 deg, 4.1 high),
CONN_PAD_CORNERS (R3 outer / R2 inner), CONN_SCREW_HOLES_M4 (cbore 7.3 x 4.0 + D3.3 to the cavity) and CONN_PIN_HOLES (2 x D4.05
to the cavity), all on R 59.85, driven by CONN_* expressions. Result: `Deviation_Check/LT-OUT-001_RevB_Left_Thigh_Outer_vs_SCAN_CONN.prt`
(+730.09 mm3, one solid, examine all 0). Scan measurements: `C:\NX_MCP_WORKSPACE\lt_conn\fit2.py`, `fit3.py`.

## Four marked details on the _CONN part (2026-10-31, round 2)

The user retouched `Deviation_Check/..._vs_SCAN_CONN.prt` (456 features) and marked four spots. `nx/fix_r2.py <src> <dst>`
(run on a copy of their 01:21:55 save; backups of both saves in `Deviation_Check/_backup_2026-10-31`) appends at the end:
FIX_A_CLIP_HEAD / RAILS / RING / HOLE (clip head on the floor post, turned -4.6 deg), FIX_B_RIB (Y 194.42, 2.05 thick, parallel
rib), FIX_C_TAB + HOLE (45 deg tab beside the hip-end boss), FIX_D_TAB + CHAMFER + HOLE (side-wall tab). Small holes D2.7
(FIX_HOLE_D). Result saved over `..._vs_SCAN_CONN.prt`: +653.76 mm3, one solid, examine all 0. Scan check
(`C:\NX_MCP_WORKSPACE\lt_conn\verify2.py`, `..._CONN_fix_r2_scancheck.json`): scan points outside the CAD by > 0.5 mm per region
A 20.4 -> 4.1 %, B 14.7 -> 2.9 %, C 20.3 -> 6.5 %, D 21.6 -> 0.0 %. The post under the A head is still the user's wider box.
Rev B locating slots still in the solid: D4.30, floor Z 79.20 at (27.03, 271.70) and (49.02, 271.70).

## Rev C package (2026-10-31)

Master = the user's 06:56 save of `Deviation_Check/..._vs_SCAN_CONN.prt` (frozen in `work/revC/master_0656.prt`).
`nx/finalize.py work/revC/master_0656.prt deliver_RevC/CAD C` (now fixes points that sit on scan Fit Surfaces, deletes the
scan-dependent construction features and asserts the solid volume) -> `work/revC/bboxcheck.py` (OCP STEP check) ->
`nx/make_dwg_revC.py` (writes `nx/dwg_revC.py`) run into `work/dwgC4` -> copy to `deliver_RevC/Drawings` ->
`an/dev2.py <stl> revC`, `an/report.py deliver_RevC/CAD revC` (+ Rev C sections), `an/c5_localdev.py`, `an/c8_renders.py`
-> `an/c7_package.py`. Details and numbers: `STATUS_RevC.md`.
Rim fix (same day, after the assembly fit check): `nx/fix_r3_rim.py <06:56 master> <dst>` -> new master
`Deviation_Check/LT-OUT-001_RevC_Left_Thigh_Outer_vs_SCAN.prt`, then the same chain (finalize -> `work/dwgC5` -> dev2 revC2 -> c7).
Fit self-check: `part 4 - Assembly/an/fit_check.py <inner AP242> <outer AP242> <inner stl> <outer stl> work/revC2/fit_revC2.json`.

## Six marked details on `..._Copy_RIBS3.prt` (2026-11-01, RIBS4)

User marked 6 spots on their 18:25 save of `Deviation_Check/..._Copy_RIBS3.prt` (frozen as
`C:\NX_MCP_WORKSPACE\lt_ribs3\master_1825.prt`). `C:\NX_MCP_WORKSPACE\lt_ribs3\j1_add.py <src> <dst> <out_dir>` (run with
`run.ps1`) appends group FEATURES_R4 after FEATURES_R3B -> `Deviation_Check/..._Copy_RIBS4.prt` (source never written):
F1_BOSS D6.4 at (94.6, 206.6) top Z 1.0, bottom on inclined mid-wall datum F1_BOSS_BASE; F2_PAD_A / F2_PAD_B sensor rib walls
(top Z 29.3, profile follows the wall mid-surface, symmetric along the wall); F3_TOP + F3_LUG R3.3 at (75.6, 129.6) top Z 0 +
F3_LUG_HOLE D2.6 x 6; F5_LUG_CUT (box cut of the old stepped block) + F5_WALL_COPY/EXTEND (frozen extract of the wall face, end
edge extended 6) + F5_LUG_TO_WALL (Replace Face of the left block faces onto it) + F5_LUG_ROUND R7.5 (column) + F5_LUG_FILLET
R3.5 + F5_HUB D10 to Z 39 with hole D5.2 x 6 at (61.3, -40.05); F4_RIB_A / F4_RIB_B radial at 21.51 / -33.13 deg, T 3.4, top Z 5,
inner end r 56; F6_RIB radial lobe at -122 deg (top Z 7.4, tip r 56.85) + F6_PIN D3.2 to Z 14.5. Result PASS: one main solid,
examine 0, no new feature errors. Scan analysis scripts a1..a9, renders v*.py in the same folder; per-zone deviation in
`r1/dev_zones.json`. Traps: the wall face ends at the old block (Y -29.19) and NX would not extend it as an extrude limit or trim
tool; Replace Face onto an extended copy worked only with the copy frozen (FixAtCurrentTimestamp) - an associative copy gives
"Circular dependency". The small triangular pit at (58.7, -29, 0) was already in RIBS3.

## Round 2 on RIBS4 -> `..._Copy_RIBS5.prt` (2026-11-01)

Two marks. Chain (on a copy of RIBS4, `C:\NX_MCP_WORKSPACE\lt_ribs3\r2`): `j3_wall.py <RIBS4> <wall.prt> <out>` then
`j4_m1_lip.py <wall.prt> <RIBS5> <out>`.
- Mark 2, -X hip ring wall (group FEATURES_R5_WALL): ring segment r 65.4/68.05, 134..154.8 deg, Z 0..34.76; the old
  low band is cut out between the hip-wall end plane and 134 deg; the transition is a block trimmed by two Through
  Curves sheets (inner from the hip wall's inner end edge, outer from its outer end edge, to lines on the ring
  cylinders), G1 at both ends. Measured: ring side 0.0 deg, hip outer seam 0.05-0.15 deg. W_LIP end lip
  153..154.8 deg r 56 -> wall + R3 fillet (FEATURES_R5).
- Mark 1 (FEATURES_R5): M1_PAD (top Z -2.0, bottom on the inclined datum M1_PAD_BASE), M1_BOSS D6.6 round the tab
  hole (-6.3, 92.0) closing the old half-open hole, M1_HOLE D3.2 x 4 (scan hole wall to Z -4, shell outside intact).
Traps: a closed-section solid Through Curves with G1 + PreserveShape came out as an invalid body or a sheet; any loft
whose faces run tangent into the old band's identical r 65.4/68.05 faces fails to unite ("zero wall thickness") or
gives BodyConsistency 1 - cut the band away under the transition. Use the real hip end edges as section strings (an
arc approximation of the outer edge left a crease + sliver). Left: a 1.3 mm step at the inner foot (Z 0..7.5) where
the old band continues a few mm under the hip wall; the scan pin on the band at (-57, 20) not modelled.
