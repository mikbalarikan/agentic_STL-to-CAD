# LT-OUT-001 Rev C, Left Thigh - Outer shell: reverse-engineering report

Source: `SHARE -  Left Thigh - Outer.stl` (7 266 929 triangles, 3D-scan mesh, open in places).
Native CAD: Siemens NX 2206, solid body `LEFT_THIGH_OUTER`, rebuilt feature by feature on the scan (not a mesh conversion).

## Part data

- Volume 390,272 mm3, mass 1.054 kg in Al 6061 (2.70 g/cm3).
- Bounding box (model frame, exact) X -68.15 .. 118.85, Y -68.25 .. 287.40, Z -40.75 .. 85.20.
- Model frame: origin on the knee-bore axis at the knee-floor plane; +Z = knee axis toward the open side;
  +Y = direction of the hip-ring axis (knee -> hip); X completes a right-handed frame.

## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)

| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |
|---|---|---|---|---|---|---|---|
| whole part | 1,500,000 | +0.051 | 0.052 | 0.442 | 0.852 | 81.5 % | 91.1 % |
| outer freeform skin | 402,851 | +0.015 | 0.021 | 0.200 | 0.340 | 90.0 % | 97.6 % |
| knee hub (r < 70) | 310,365 | +0.012 | 0.107 | 0.535 | 0.798 | 73.2 % | 88.7 % |
| hip ring / plate (y > 262) | 245,389 | +0.083 | 0.046 | 0.285 | 0.743 | 86.9 % | 92.8 % |
| interior (ribs, pockets, bosses) | 541,395 | +0.085 | 0.080 | 0.750 | 1.365 | 77.4 % | 86.8 % |

CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 0.063, p90 0.878, p95 1.813 mm.

## Rev C against Rev A (the issued revision)

Same scan, same frame, same 1.5 M scan samples. Rev C keeps every Rev A feature and adds the features in the README;
several skin, rib and knee-hub faces were also refitted to the scan.

| zone | Rev A p50 | Rev A p95 | Rev A within 0.5 | Rev C p50 | Rev C p95 | Rev C within 0.5 |
|---|---|---|---|---|---|---|
| whole part | 0.053 | 0.983 | 89.2 % | 0.052 | 0.852 | 91.1 % |
| outer freeform skin | 0.021 | 0.352 | 97.4 % | 0.021 | 0.340 | 97.6 % |
| knee hub (r < 70) | 0.113 | 0.937 | 83.9 % | 0.107 | 0.798 | 88.7 % |
| hip ring / plate (y > 262) | 0.047 | 1.128 | 90.2 % | 0.046 | 0.743 | 92.8 % |
| interior | 0.082 | 1.459 | 85.8 % | 0.080 | 1.365 | 86.8 % |

CAD -> scan p95: Rev A 1.978 -> Rev C 1.813 mm.

### The changed regions (scan points in a box around each, unsigned distance to the CAD)

| region | scan points | Rev A p50 | Rev A p95 | Rev A within 0.5 | Rev C p50 | Rev C p95 | Rev C within 0.5 |
|---|---|---|---|---|---|---|---|
| connector pad (hip end face) | 30,138 | 0.429 | 4.220 | 51.1 % | 0.087 | 1.251 | 86.5 % |
| locating slots S1/S2 | 19,498 | 0.059 | 0.658 | 94.0 % | 0.060 | 0.247 | 97.7 % |
| clip K1 | 29,980 | 0.200 | 3.023 | 69.2 % | 0.096 | 0.995 | 85.7 % |
| rib R1 | 41,972 | 0.092 | 3.190 | 82.2 % | 0.059 | 0.515 | 94.7 % |
| tab T1 | 22,782 | 0.148 | 2.346 | 78.5 % | 0.079 | 0.703 | 92.9 % |
| tab T2 | 16,481 | 0.117 | 5.091 | 77.1 % | 0.046 | 0.417 | 97.5 % |
| -X hip-end rim (Z 34.3..36.6) | 10,729 | 0.802 | 1.758 | 39.9 % | 0.217 | 1.211 | 81.3 % |
| boss lobe wall (X 53..62, Y -52..-44) | 9,038 | 0.732 | 1.084 | 22.2 % | 0.594 | 0.950 | 36.0 % |

What is left in these regions: the root fillets of the original (not modelled, as everywhere on the part), the
post under clip K1 (kept as a rectangular column; the scanned post is a slimmer half-round), and the screw heads
that sit in the connector-pad counterbores in the scan.

## Rim at the hip end (-X wall, Y 240 .. 287)

The scan shows a tongue on the inner part of the wall top (Z 36.07) and a rabbet about 1.3 wide on the outer side at the
rim plane (Z 34.76). Rev A had the whole wall top at 36.07 for Y < 266 and at 34.76 for Y > 266. Rev C follows the scan:
tongue at 36.07, outer rabbet 1.3 wide at 34.76 along the whole stretch (feature `REVC_RIM_RABBET`).
The planar outer wall of the boss lobe at (61.35, -40.01) sits 0.15 further in than in the first Rev C draft
(`REVC_PAD_WALL_BACK_0P15`); the scan lies inside it along its height.

## STEP files (read back with OpenCascade)

| file | solids | valid | volume mm3 | vs NX part | bounding box max difference |
|---|---|---|---|---|---|
| AP214.step | 1 | True | 390,244.3 | -0.0072 % | 0.002 mm |
| AP242.step | 1 | True | 390,300.0 | +0.0071 % | 0.002 mm |

NX part volume 390,272.5 mm3. The volume differences come from the STEP B-spline approximation of the
freeform faces (the same order as in Rev A).
