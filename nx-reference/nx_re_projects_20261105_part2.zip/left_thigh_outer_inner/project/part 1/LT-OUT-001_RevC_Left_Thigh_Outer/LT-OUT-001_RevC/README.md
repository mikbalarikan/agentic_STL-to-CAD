# LT-OUT-001 Rev C: Left Thigh, Outer Shell (STL → solid CAD + manufacturing drawings)

Reverse-engineered from `SHARE -  Left Thigh - Outer.stl` (3D scan, 7.27 M triangles).
The solid was rebuilt feature by feature on top of the scan in Siemens NX 2206. It is a true
B-rep solid: freeform B-spline skins plus exact planes, cylinders, cones and tori. It is not a
faceted mesh wrapped into STEP. One valid solid, 390 272 mm³, 1.05 kg in Al 6061.

## Revision history

| Rev | Date | Change |
|---|---|---|
| A | 2026-10-25 | First issue. |
| B | 2026-10-30 | Internal, not issued. Its two locating slots are part of Rev C. |
| C | 2026-10-31 | Details that are in the scan but were missing from Rev A, plus refinements to match the scan (see "What changed in Rev C"). Volume +4 330 mm³ (+1.1 %) against Rev A. |

## What changed in Rev C (against Rev A)

1. **Connector pad on the hip end face** (drawing SH3). It is a raised sector below the hip ring, concentric with the hip
   axis: R52.40 to R66.20, 28° wide, standing 4.10 above the hip outer face D. The outer corners are R3 and the inner
   corners R2. Its four holes lie on R59.85:
   - 2 screw holes: Ø3.3 through (M4 tap drill), counterbore Ø7.30 x 4.00 deep. The scan shows M4 socket-head screws
     sitting flush in them.
   - 2 holes Ø4.05 through.
2. **Locating slots S1 / S2 at the hip-ring top** (SH4). Ø4.30 x 6.00 deep at X 27.03 / 49.02, Y 271.70. They take the
   two locating bumps of the inner shell LT-INN-001.
3. **Clip K1** on the floor post (SH4). A 6.9 x 12 head with two end rails (top Z 7.70) and a Ø5.3 ring with a Ø2.7
   hole, 1.95 deep.
4. **Rib R1** (SH4). 2.05 thick, running from the wall up to the tall post at X 108.97 / Y 194.32.
5. **Tabs T1 and T2** (SH4):
   - T1: 2.58 thick, turned 45°, beside the hip-end boss.
   - T2: 2.39 thick, on the side wall, with a C1.6 chamfer.
   Each has a Ø2.7 through hole.
6. **Rim at the hip end.** On the -X wall at the hip end (Y 240–287) the wall top is now as in the scan:
   - tongue at Z 36.07 on the inner part of the wall
   - rabbet 1.3 wide at the rim plane Z 34.76 on the outer side
   
   Rev A had this stretch flat, at 36.07 for Y < 266 and at 34.76 for Y > 266.
7. **Faces refitted to the scan.** Several outer-skin, rib and knee-hub faces were replaced or offset to follow the
   scan more closely. One example is the knee-hub OD between Z 10 and the rim, now Ø136.5. The overall length is now
   355.65 (Rev A 355.25). The outer wall of the boss lobe at (61.35, -40.01) sits 0.15 further in, following the
   scan. Every functional dimension of Rev A is unchanged:
   - knee bore Ø110 and its steps, and the knee bolt circle
   - hip bores Ø82 / Ø85.96 / Ø97.54 and the hip bolt circle
   - rim and tongue planes
   - bosses and pins B1–B7 / P1–P3
   - hip faces 266.50 / 276.85
8. **Drawings.** Every sheet now has a revision block. View letters run E–J, so A–D are used only for datums. SH3 has a
   connector-pad table and hole callouts. SH4 has table rows and balloons for S1, S2, K1, R1, T1 and T2, plus section
   H-H and detail J through slot S1.

## Contents

| Folder / file | What it is |
|---|---|
| `CAD/LT-OUT-001_Left_Thigh_Outer_AP214.step` | STEP AP214. Opens in SolidWorks, Fusion 360, Inventor, Creo, Mastercam, etc. **Use this one for quoting.** |
| `CAD/LT-OUT-001_Left_Thigh_Outer_AP242.step` | STEP AP242: the same solid in the newer schema |
| `CAD/LT-OUT-001_Left_Thigh_Outer.x_t` | Parasolid, the native kernel of SolidWorks and NX. Opens in SolidWorks as an editable solid (FeatureWorks works on it) and imports into Fusion 360 |
| `CAD/LT-OUT-001_Left_Thigh_Outer.prt` | Native NX part with the editable feature history (reference set `SOLID`). The Rev C details are the last features, driven by the `CONN_*` and `FIX_*` expressions |
| `CAD/LT-OUT-001_Left_Thigh_Outer.stl` | Fine tessellation of the CAD solid, for viewing and printing |
| `Drawings/LT-OUT-001.pdf` | Drawing set, Rev C, 4 sheets, third-angle projection, GD&T per ISO 1101. Datums: A knee mounting face, B Ø110 knee bore, C Ø82 hip bore, D hip outer face. SH1 general arrangement + notes, SH2 knee hub, SH3 hip ring + connector pad, SH4 interior features (ballooned) with location tables |
| `Drawings/LT-OUT-001_SH1..4.pdf`, `_SH1..4.dwg` | The same sheets, one PDF and one DWG per sheet |
| `Drawings/LT-OUT-001_dwg.prt` | Native NX drawing (master-model, associative to the part) |
| `Deviation Report/REPORT_deviation.md`, `deviation_map_*.png` | Scan-to-CAD deviation report and colour maps (Rev C), the Rev A → Rev C comparison per zone and per changed region, and the STEP read-back check |
| `Renders/` | Shaded views of the CAD solid, plus close-ups of the slots, the connector pad and the interior details |

## Coordinate system (all files share it, and LT-INN-001 uses the same one)

- Origin: on the knee-bore axis, at the knee floor plane (top face of the knee plate).
- +Z: the knee-bore axis, pointing to the open side (the parting/rim side).
- +Y: the direction of the hip-ring axis (knee → hip). The hip-ring axis is the line X = 37.97, Z = 35.18.
- Units: mm.

## How accurate it is (full numbers in `Deviation Report/REPORT_deviation.md`)

| Zone | Scan → CAD p50 | p95 | Within 0.5 mm (Rev A → Rev C) |
|---|---|---|---|
| Outer freeform skin | 0.021 | 0.34 | 97.4 → 97.6 % |
| Knee hub | 0.107 | 0.80 | 83.9 → 88.7 % |
| Hip ring / plate | 0.046 | 0.74 | 90.2 → 92.8 % |
| Whole part | 0.052 | 0.85 | 89.2 → 91.1 % |

- Functional features (knee bore Ø110 and its steps, the 30-hole knee bolt circle, the hip-ring bores, the 26-hole hip
  bolt circle, rim/tongue planes, bosses, pins) come from circle, cylinder and plane fits with 0.01–0.05 mm residuals.
- Most of the remaining interior deviation is the root fillets of the original (see below).

## Simplifications and assumptions (please read)

1. **Root fillets.** The rib-to-floor and wall-to-floor fillets of the original (R3–R8) are not modelled.
   The CAD corners are sharp, and drawing note 4 sets "internal corners R3 max", so the shop can use its
   cutter radius.
2. **Styling seams** on the outer skin are modelled as Ø1.8 mm round-bottom grooves, 0.55 mm deep, along
   the scanned centre lines. The small raised lips next to the seams (0.3–0.8 mm over a 3–6 mm band) are
   blended into the smooth skin.
3. **Engraved part number** "20010100285-00" and the printed surface texture are not modelled. Apply part
   marking per your own standard.
4. **Threads.** The scan cannot show threads. Hole sizes are as measured:
   - Ø5.2 boss bores and Ø2.6 floor holes
   - Ø5.7 knee bolt holes
   - Ø4.07 hip bolt holes with Ø7.53 counterbore
   - Ø3.5 label-pad holes
   - Ø3.3 connector-pad screw holes (M4 tap drill)
   - Ø2.7 holes in K1 / T1 / T2

   Tap them if your fasteners need threads.
5. **Material.** Not stated in the brief. The drawing assumes Al 6061-T6 (mass shown for that).
6. **Fits.** H7 on the knee bore, the knee pilot recess and the hip bores is suggested from function. A scan
   cannot give design tolerances, so please confirm against the mating actuators.
7. **Design intent over print warp.** The scanned part is a print with slight warp (rim plane tilted 0.06°,
   knee hub OD 0.19 mm off-centre). The CAD is flat, square and concentric.
8. **Projection.** The drawings are third angle (ASME). They can be switched to first angle (ISO) on request.
9. **Locating slots.** The scanned slots measure Ø3.95, and the scanned bumps of the inner measure Ø4.08, so as
   printed they are a press fit. The CAD slot is Ø4.30, which gives at least 0.1 mm clearance per side on the bumps.
   The scan does not show the slot floor, so the depth (6.00, floor Z 79.20) is set from the bump length. Near the
   floor each slot cuts 0.1–0.3 mm into the edge of the neighbouring Ø7.53 hip-bolt counterbores. The scanned slots
   already touch them.
10. **Connector pad holes.** The scan shows screw heads in the two counterbores, so the hole below them is taken from
    the inside of the plate (Ø3.3). The two Ø4.05 holes are seen 4.4 mm deep in the scan and are modelled through.
11. **Clip K1 post.** The post under the clip head stays a rectangular column. The scanned post is a slimmer half-round.
