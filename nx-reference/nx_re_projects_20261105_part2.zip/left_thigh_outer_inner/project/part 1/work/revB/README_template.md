# LT-OUT-001 Rev B: Left Thigh, Outer Shell (STL → solid CAD + manufacturing drawings)

Reverse-engineered from `SHARE -  Left Thigh - Outer.stl` (3D scan, 7.27 M triangles).
The solid was rebuilt feature by feature on top of the scan in Siemens NX 2206. It is a true
B-rep solid: freeform B-spline skins plus exact planes, cylinders, cones and tori. It is not a
faceted mesh wrapped into STEP. One valid solid, {VOL} mm³, {MASS} kg in Al 6061.

## Revision history

| Rev | Date | Change |
|---|---|---|
| A | 2026-10-25 | First issue. |
| B | 2026-10-30 | Added 2 locating slots at the hip end (S1, S2). While building the inner shell LT-INN-001 we found two locating bumps on its hip pad; the outer scan has two matching slots that Rev A did not model. Each slot is a Ø4.30 hole, 6.00 deep from the hip-ring top (Z 85.20), centred at X 27.03 / 49.02, Y 271.70. Below the Ø97.54 hip-bore step it opens into that step, as on the scanned part. Volume {DVOL} mm³ less than Rev A. Drawings: slot table rows and balloons S1 / S2, section H-H and detail J on SH4, revision block on every sheet. View letters are now E–J, so A–D are used only for datums. DWG files added to the package. Nothing else changed. |

## Contents

| Folder / file | What it is |
|---|---|
| `CAD/LT-OUT-001_Left_Thigh_Outer_AP214.step` | STEP AP214: opens in SolidWorks, Fusion 360, Inventor, Creo, Mastercam, etc. **Use this one for quoting.** |
| `CAD/LT-OUT-001_Left_Thigh_Outer_AP242.step` | STEP AP242: the same solid in the newer schema |
| `CAD/LT-OUT-001_Left_Thigh_Outer.x_t` | Parasolid: the native kernel of SolidWorks and NX. Opens in SolidWorks as a solid you can edit directly (and use FeatureWorks on), and imports into Fusion 360 |
| `CAD/LT-OUT-001_Left_Thigh_Outer.prt` | Native NX part with the full, editable feature history (reference set `SOLID`). The Rev B slots are the last features (`REVB_LOCATING_SLOT_HOLES`, `REVB_LOCATING_SLOT_RELIEF`), driven by the `REVB_SLOT_*` expressions |
| `CAD/LT-OUT-001_Left_Thigh_Outer.stl` | Fine tessellation of the CAD solid (for viewing and printing) |
| `Drawings/LT-OUT-001.pdf` | Drawing set, Rev B, 4 sheets, third-angle projection, GD&T per ISO 1101 (datums A knee mounting face, B Ø110 knee bore, C Ø82 hip bore, D hip outer face): SH1 general arrangement + notes, SH2 knee hub, SH3 hip ring, SH4 interior features (ballooned) with location tables and the locating slots |
| `Drawings/LT-OUT-001_SH1..4.pdf`, `_SH1..4.dwg` | The same sheets, one PDF and one DWG per sheet |
| `Drawings/LT-OUT-001_dwg.prt` | Native NX drawing (master-model, associative to the part) |
| `Deviation Report/REPORT_deviation.md`, `deviation_map_*.png` | Scan-to-CAD deviation report and colour maps (Rev B), the slot comparison with Rev A, and the fit check with LT-INN-001 |
| `Renders/` | Shaded views of the CAD solid, plus a close-up of the two slots |

## Coordinate system (all files share it, and LT-INN-001 uses the same one)

- Origin: on the knee-bore axis, at the knee floor plane (top face of the knee plate).
- +Z: the knee-bore axis, pointing to the open side (the parting/rim side).
- +Y: the direction of the hip-ring axis (knee → hip). The hip-ring axis is the line X = 37.97, Z = 35.18.
- Units: mm.

## How accurate it is (full numbers in `Deviation Report/REPORT_deviation.md`)

| Zone | Scan → CAD p50 | p95 | Within 0.5 mm |
|---|---|---|---|
| Outer freeform skin | {SKIN_P50} | {SKIN_P95} | {SKIN_W05} |
| Whole part | {ALL_P50} | {ALL_P95} | {ALL_W05} |
| The two new slots (scan points within 3 mm of a slot axis), Rev A → Rev B | {SLOT_A_P50} → {SLOT_B_P50} | {SLOT_A_P95} → {SLOT_B_P95} | {SLOT_A_W05} → {SLOT_B_W05} |

- Functional features (knee bore Ø110 and its steps, the 30-hole knee bolt circle, the hip-ring bores, the
  26-hole hip bolt circle, rim/tongue planes, bosses, pins) come from circle, cylinder and plane fits with
  0.01–0.05 mm residuals.
- Most of the remaining interior deviation is the root fillets of the original (see below).

## Fit with LT-INN-001

{FIT}

## Simplifications and assumptions (please read)

1. **Root fillets.** The rib-to-floor and wall-to-floor fillets of the original (R3–R8) are not modelled.
   The CAD corners are sharp, and drawing note 4 sets "internal corners R3 max", so the shop can use its
   cutter radius.
2. **Styling seams** on the outer skin are modelled as Ø1.8 mm round-bottom grooves, 0.55 mm deep, along
   the scanned centre lines. The small raised lips next to the seams (0.3–0.8 mm over a 3–6 mm band) are
   blended into the smooth skin.
3. **Engraved part number** "20010100285-00" and the printed surface texture are not modelled. Apply part
   marking per your own standard.
4. **Threads.** The scan cannot show threads. Hole sizes are as measured (Ø5.2 boss bores, Ø2.6 floor holes,
   Ø5.7 knee bolt holes, Ø4.07 with Ø7.53 counterbore hip bolt holes, Ø3.5 label-pad holes). Tap them
   if your fasteners need threads.
5. **Material.** Not stated in the brief. The drawing assumes Al 6061-T6 (mass shown for that).
6. **Fits.** H7 on the knee bore, the knee pilot recess and the hip bores is suggested from function. A scan
   cannot give design tolerances, so please confirm against the mating actuators.
7. **Design intent over print warp.** The scanned part is a print with slight warp (rim plane tilted 0.06°,
   knee hub OD 0.19 mm off-centre). The CAD is flat, square and concentric.
8. **Projection.** The drawings are third angle (ASME). They can be switched to first angle (ISO) on request.
9. **Locating slots (Rev B).** The scanned slots measure Ø3.95, and the scanned bumps of the inner measure Ø4.08,
   so as printed they are a press fit. The CAD slot is Ø4.30, which gives at least 0.1 mm clearance per side on
   the bumps, and 0.19 mm below their tips. The scan does not show the slot floor, so the depth (6.00) is set
   from the bump length. Below the hip-bore step the Ø4.30 slots break 0.1–0.4 mm into the neighbouring Ø7.53
   hip-bolt counterbores; the scanned slots already touch them. If you want a tighter location, reduce the slot
   to Ø4.20 and check it against the inner bumps.
