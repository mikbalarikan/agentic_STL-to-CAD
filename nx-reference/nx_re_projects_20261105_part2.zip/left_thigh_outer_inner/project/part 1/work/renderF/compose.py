"""Put the Blender RGBA renders on a neutral studio background (soft radial gradient + faint contact shadow)
and report framing: border touch (clipping) and coverage. usage: compose.py <rgba_dir> <out_dir> <prefix> [names]"""
import os, sys, json, glob
import numpy as np
from PIL import Image, ImageFilter

src, out, prefix = sys.argv[1], sys.argv[2], sys.argv[3]
only = set(sys.argv[4].split(",")) if len(sys.argv) > 4 and sys.argv[4] else None
VIEWS = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "views.json")))
OW, OH, MARGIN = 2400, 1500, 0.07
os.makedirs(out, exist_ok=True)
rep = {}
for f in sorted(glob.glob(os.path.join(src, "*_rgba.png"))):
    name = os.path.basename(f)[:-9]
    if only and name not in only: continue
    im = Image.open(f).convert("RGBA")
    W, H = im.size
    a0 = np.asarray(im)[:, :, 3] > 12
    ys, xs = np.nonzero(a0)
    if VIEWS.get(name, {}).get("frame") and len(xs) and not (a0[0].any() or a0[-1].any() or a0[:, 0].any() or a0[:, -1].any()):
        # auto-frame: crop round the part with a margin at 16:10, then scale to the output size
        cx, cy = (xs.min() + xs.max()) / 2, (ys.min() + ys.max()) / 2
        bw, bh = (xs.max() - xs.min()) / (1 - 2 * MARGIN), (ys.max() - ys.min()) / (1 - 2 * MARGIN)
        cw = max(bw, bh * OW / OH); ch = cw * OH / OW
        box = (int(round(cx - cw / 2)), int(round(cy - ch / 2)), int(round(cx + cw / 2)), int(round(cy + ch / 2)))
        print(name, "crop", box, "upscale" if cw < OW else "")
        im = im.crop(box)  # outside the render = transparent
    im = im.resize((OW, OH), Image.LANCZOS)
    W, H = im.size
    a = np.asarray(im)[:, :, 3].astype(float) / 255
    yy, xx = np.mgrid[0:H, 0:W]
    r = np.hypot((xx - W * 0.5) / W, (yy - H * 0.42) / H)
    top, edge = np.array([250, 251, 252.]), np.array([222, 226, 231.])
    t = np.clip(r / 0.75, 0, 1)[..., None] ** 1.4
    bg = top * (1 - t) + edge * t
    # soft shadow: blurred alpha, shifted down
    sh = Image.fromarray((a * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(W / 90))
    sh0 = np.asarray(sh).astype(float) / 255; k = int(H * 0.012)
    sh = np.zeros_like(sh0); sh[k:] = sh0[:-k]; sh[:k] = sh0[:1]; sh *= 0.22
    bg = bg * (1 - sh[..., None])
    fg = np.asarray(im)[:, :, :3].astype(float)
    comp = fg * a[..., None] + bg * (1 - a[..., None])
    Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8)).save(os.path.join(out, prefix + name + ".png"))
    m = a > 0.05
    border = {"top": bool(m[0].any()), "bottom": bool(m[-1].any()), "left": bool(m[:, 0].any()), "right": bool(m[:, -1].any())}
    ys, xs = np.nonzero(m)
    rep[name] = {"coverage": round(float(m.mean()), 3), "touch": [k for k, v in border.items() if v],
                 "bbox_frac": [round(xs.min() / W, 3), round(ys.min() / H, 3), round(xs.max() / W, 3), round(ys.max() / H, 3)] if len(xs) else None,
                 "dark_frac": round(float(((fg.mean(2) < 25) & m).sum() / max(m.sum(), 1)), 4)}
    print(name, rep[name])
json.dump(rep, open(os.path.join(src, "framing.json"), "w"), indent=1)
