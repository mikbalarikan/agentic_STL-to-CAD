#!/bin/bash
# Rev F final renders: Blender Cycles (OptiX) -> compose on studio background. Run from work/renderF.
cd "$(dirname "$0")"
STL="../../deliver_RevF/CAD/LT-OUT-001_Left_Thigh_Outer.stl"
EXPO=-0.3 "/c/Program Files/Blender Foundation/Blender 5.1/blender.exe" -b --factory-startup -P bl_render.py -- "$STL" views.json final 128 100 "$1" 2>&1 | grep -E "wrote|Error|Trace"
/c/Users/marya/.venvs/cadgenbench/Scripts/python.exe compose.py final final_c LT-OUT-001_RevF_ "$1"
