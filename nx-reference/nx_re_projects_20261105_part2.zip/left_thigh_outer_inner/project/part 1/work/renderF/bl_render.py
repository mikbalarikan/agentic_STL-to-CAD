"""Blender headless studio renders of the LT-OUT-001 STL (Rev F).
usage: blender -b --factory-startup -P bl_render.py -- <stl> <views.json> <out_dir> [samples] [res_pct] [only,names]
Writes transparent RGBA PNGs <out_dir>/<name>_rgba.png; compose.py puts them on the studio background.
Model units mm -> scene metres (x0.001). views.json: {name: {focus:[x,y,z] mm, dir:[dx,dy,dz] focus->camera,
dist: mm, up:[..], fov: deg}}."""
import bpy, sys, json, math, os
from mathutils import Vector, Matrix

argv = sys.argv[sys.argv.index("--") + 1:]
stl, vjson, out = [os.path.abspath(a) for a in argv[:3]]
samples = int(argv[3]) if len(argv) > 3 else 128
res_pct = int(argv[4]) if len(argv) > 4 else 100
only = set(argv[5].split(",")) if len(argv) > 5 and argv[5] else None
os.makedirs(out, exist_ok=True)
views = json.load(open(vjson))
S = 0.001

# ---- scene reset
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene

# ---- mesh
bpy.ops.wm.stl_import(filepath=stl, global_scale=S)
ob = bpy.context.selected_objects[0]
me = ob.data
import bmesh
bm = bmesh.new(); bm.from_mesh(me)
bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-6)
bm.to_mesh(me); bm.free()
me.shade_smooth()
me.set_sharp_from_angle(angle=math.radians(28))

# ---- material: machined aluminium
mat = bpy.data.materials.new("alu"); mat.use_nodes = True
nt = mat.node_tree; bsdf = nt.nodes["Principled BSDF"]
bsdf.inputs["Base Color"].default_value = (0.56, 0.58, 0.61, 1)
bsdf.inputs["Metallic"].default_value = 0.92
bsdf.inputs["Roughness"].default_value = 0.30
for k in ("Anisotropic",):
    if k in bsdf.inputs: bsdf.inputs[k].default_value = 0.25
me.materials.append(mat)

# ---- world: studio HDRI for light/reflection, camera sees transparent (composited later)
w = bpy.data.worlds.new("w"); sc.world = w; w.use_nodes = True
wn = w.node_tree.nodes; wl = w.node_tree.links
bg = wn["Background"]
env = wn.new("ShaderNodeTexEnvironment")
hdr = os.path.join(os.path.dirname(bpy.app.binary_path), "%d.%d" % bpy.app.version[:2],
                   "datafiles", "studiolights", "world", "studio.exr")
env.image = bpy.data.images.load(hdr)
wl.new(env.outputs["Color"], bg.inputs["Color"])
bg.inputs["Strength"].default_value = 0.7

# ---- render settings
sc.render.engine = "CYCLES"
cy = sc.cycles
try:
    prefs = bpy.context.preferences.addons["cycles"].preferences
    for dt in ("OPTIX", "CUDA"):
        try:
            prefs.compute_device_type = dt; prefs.get_devices()
            if any(d.type == dt for d in prefs.devices):
                for d in prefs.devices: d.use = d.type == dt
                cy.device = "GPU"; print("device", dt); break
        except Exception as e:
            print("no", dt, e)
except Exception as e:
    print("gpu setup failed", e)
cy.samples = samples
cy.use_denoising = True
cy.max_bounces = 8
sc.render.film_transparent = True
sc.render.resolution_x, sc.render.resolution_y = 2400, 1500
sc.render.resolution_percentage = res_pct
sc.render.image_settings.file_format = "PNG"
sc.render.image_settings.color_mode = "RGBA"
sc.render.image_settings.color_depth = "16"
sc.view_settings.view_transform = "AgX"
looks = [i.identifier for i in sc.view_settings.bl_rna.properties["look"].enum_items]
print("looks", looks)
for lk in ("AgX - Medium High Contrast", "Medium High Contrast"):
    if lk in looks: sc.view_settings.look = lk; break
sc.view_settings.exposure = float(os.environ.get("EXPO", "0"))

# ---- optional feature-edge lines (Freestyle)
if os.environ.get("FS", "1") == "1":
    sc.render.use_freestyle = True
    sc.render.line_thickness_mode = "ABSOLUTE"
    sc.render.line_thickness = float(os.environ.get("FSW", "1.3")) * res_pct / 100
    vl = sc.view_layers[0]; fs = vl.freestyle_settings
    fs.crease_angle = math.radians(float(os.environ.get("FSA", "135")))
    ls = fs.linesets[0] if len(fs.linesets) else fs.linesets.new("L")
    ls.select_by_visibility = True; ls.visibility = "VISIBLE"
    ls.select_silhouette = True; ls.select_border = True; ls.select_crease = True
    ls.select_contour = False; ls.select_external_contour = False
    if ls.linestyle is None: ls.linestyle = bpy.data.linestyles.new("LS")
    lsty = ls.linestyle; lsty.color = (0.10, 0.11, 0.12); lsty.alpha = 0.55; lsty.thickness = 1.0

# ---- camera + camera-relative lights
cam_d = bpy.data.cameras.new("cam"); cam = bpy.data.objects.new("cam", cam_d)
sc.collection.objects.link(cam); sc.camera = cam
cam_d.clip_start, cam_d.clip_end = 0.001, 10.0
cam_d.sensor_fit = "HORIZONTAL"


def area(name, size, power):
    ld = bpy.data.lights.new(name, "AREA"); ld.size = size; ld.energy = power
    lo = bpy.data.objects.new(name, ld); sc.collection.objects.link(lo); lo.parent = cam
    return lo


def aim(lo, pos_cam, tgt_cam=(0, 0, 0)):
    # position in camera space; light -Z points at target
    p = Vector(pos_cam); t = Vector(tgt_cam)
    z = (p - t).normalized()
    x = Vector((0, 1, 0)).cross(z)
    if x.length < 1e-6: x = Vector((1, 0, 0))
    x.normalize(); y = z.cross(x)
    M = Matrix((x, y, z)).transposed().to_4x4(); M.translation = p
    lo.matrix_parent_inverse = Matrix.Identity(4); lo.matrix_basis = M


key = area("key", 0.35, 60)
fill = area("fill", 0.6, 25)
rim = area("rim", 0.3, 40)

for name, v in views.items():
    if only and name not in only: continue
    f = Vector(v["focus"]) * S; d = Vector(v["dir"]).normalized(); dist = v["dist"] * S
    up = Vector(v.get("up", (0, 0, 1)))
    z = d; x = up.cross(z)
    if x.length < 1e-6: x = Vector((0, 1, 0)).cross(z)
    x.normalize(); y = z.cross(x)
    M = Matrix((x, y, z)).transposed().to_4x4(); M.translation = f + d * dist
    cam.matrix_world = M
    cam_d.angle = math.radians(v.get("fov", 30))
    sc.view_settings.exposure = float(os.environ.get("EXPO", "0")) + v.get("expo", 0.0)
    # lights in camera space (camera looks down -Z); target = focus at (0,0,-dist)
    L = dist
    aim(key, (-0.9 * L, 0.9 * L, -0.15 * L), (0, 0, -L))
    aim(fill, (1.1 * L, 0.2 * L, 0.1 * L), (0, 0, -L))
    aim(rim, (0.4 * L, 1.0 * L, -1.8 * L), (0, 0, -L))
    sc_ = (L / 0.66) ** 2  # keep the same illuminance at any camera distance
    key.data.energy = 60 * sc_ * v.get("key", 1.0)
    fill.data.energy = 22 * sc_
    rim.data.energy = 35 * sc_
    key.data.size, fill.data.size, rim.data.size = 0.5 * L, 0.9 * L, 0.45 * L
    sc.render.resolution_percentage = int(res_pct * v.get("res", 100) / 100)
    sc.render.line_thickness = float(os.environ.get("FSW", "1.3")) * sc.render.resolution_percentage / 100
    sc.render.filepath = os.path.join(out, name + "_rgba.png")
    bpy.ops.render.render(write_still=True)
    print("wrote", name, flush=True)
