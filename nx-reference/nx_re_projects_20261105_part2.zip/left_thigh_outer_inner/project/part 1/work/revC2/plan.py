import numpy as np, sys, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\an")
import common as C
v, f = C.load()
A = trimesh.load("deliver/CAD/LT-OUT-001_Left_Thigh_Outer.stl"); Cc = trimesh.load("deliver_RevC/CAD/LT-OUT-001_Left_Thigh_Outer.stl")
x0, x1, y0, y1 = [float(t) for t in sys.argv[2:6]]; zs = eval(sys.argv[6])
sel = (v[f[:, 0], 0] > x0 - 3) & (v[f[:, 0], 0] < x1 + 3) & (v[f[:, 0], 1] > y0 - 3) & (v[f[:, 0], 1] < y1 + 3)
fig, axs = plt.subplots(1, len(zs), figsize=(0.45 * (x1 - x0) * len(zs) + 2, 0.45 * (y1 - y0)))
for ax, z in zip(np.atleast_1d(axs), zs):
    for sg in C.section(v, f, 2, z, sel): ax.plot(sg[:, 0], sg[:, 1], color="goldenrod", lw=1.5)
    for m, col in ((A, "g"), (Cc, "b")):
        cs = m.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1])
        for q in (cs.discrete if cs is not None else []):
            ok = (q[:, 0] > x0 - 3) & (q[:, 0] < x1 + 3) & (q[:, 1] > y0 - 3) & (q[:, 1] < y1 + 3)
            ax.plot(np.where(ok, q[:, 0], np.nan), np.where(ok, q[:, 1], np.nan), col + "-", lw=1)
    ax.set_xlim(x0, x1); ax.set_ylim(y0, y1); ax.set_aspect(1); ax.grid(True, alpha=.4)
    ax.set_xticks(np.arange(x0, x1 + 1, 1)); ax.set_yticks(np.arange(y0, y1 + 1, 2)); ax.tick_params(labelsize=7)
    ax.set_title(f"Z={z}: scan gold, Rev A green, Rev C blue", fontsize=10)
plt.tight_layout(); plt.savefig(f"work/revC2/{sys.argv[1]}.png", dpi=60)
