import numpy as np, sys, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\an")
import common as C
v, f = C.load()
A = trimesh.load("deliver/CAD/LT-OUT-001_Left_Thigh_Outer.stl"); Cc = trimesh.load("deliver_RevC/CAD/LT-OUT-001_Left_Thigh_Outer.stl")
out, ys, x0, x1, z0, z1 = sys.argv[1], eval(sys.argv[2]), *[float(t) for t in sys.argv[3:7]]
sel = (v[f[:, 0], 0] > x0 - 3) & (v[f[:, 0], 0] < x1 + 3) & (v[f[:, 0], 2] > z0 - 3) & (v[f[:, 0], 2] < z1 + 3)
n = len(ys); cols = 4; rows = (n + cols - 1) // cols
fig, axs = plt.subplots(rows, cols, figsize=(cols * 0.42 * (x1 - x0) + 1, rows * 0.42 * (z1 - z0) + 1)); axs = np.atleast_1d(axs).ravel()
for ax, y in zip(axs, ys):
    for sg in C.section(v, f, 1, y, sel): ax.plot(sg[:, 0], sg[:, 2], color="goldenrod", lw=1.6)
    for m, col, ls in ((A, "g", "-"), (Cc, "b", "--")):
        cs = m.section(plane_origin=[0, y, 0], plane_normal=[0, 1, 0])
        for q in (cs.discrete if cs is not None else []):
            ok = (q[:, 0] > x0 - 3) & (q[:, 0] < x1 + 3) & (q[:, 2] > z0 - 3) & (q[:, 2] < z1 + 3)
            ax.plot(np.where(ok, q[:, 0], np.nan), np.where(ok, q[:, 2], np.nan), color=col, ls=ls, lw=1.1)
    ax.axhline(34.76, color="r", lw=0.5); ax.axhline(36.07, color="m", lw=0.5)
    ax.set_xlim(x0, x1); ax.set_ylim(z0, z1); ax.set_aspect(1); ax.grid(True, alpha=.35)
    ax.set_xticks(np.arange(x0, x1 + 1, 1)); ax.tick_params(labelsize=6); ax.set_title(f"Y={y}", fontsize=9)
plt.suptitle("scan gold, Rev A green solid, Rev C blue dashed, red 34.76, magenta 36.07")
plt.tight_layout(); plt.savefig(f"work/revC2/{out}.png", dpi=55)
