import numpy as np, sys, trimesh, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\an")
import common as C
v, f = C.load()
A = trimesh.load("deliver/CAD/LT-OUT-001_Left_Thigh_Outer.stl"); Cc = trimesh.load("deliver_RevC/CAD/LT-OUT-001_Left_Thigh_Outer.stl")
name, axis, levels, lo, hi, ia, ib = sys.argv[1], int(sys.argv[2]), eval(sys.argv[3]), np.array(eval(sys.argv[4]), float), np.array(eval(sys.argv[5]), float), *eval(sys.argv[6])
sel = np.all((v[f[:, 0]] > lo - 3) & (v[f[:, 0]] < hi + 3), 1)
fig, axs = plt.subplots(1, len(levels), figsize=(8 * len(levels), 7)); axs = np.atleast_1d(axs)
for ax, L in zip(axs, levels):
    for sg in C.section(v, f, axis, L, sel): ax.plot(sg[:, ia], sg[:, ib], color="goldenrod", lw=1.2)
    nrm = np.zeros(3); nrm[axis] = 1; org = np.zeros(3); org[axis] = L
    for m, col, lw in ((A, "g", 0.9), (Cc, "b", 0.9)):
        cs = m.section(plane_origin=org, plane_normal=nrm)
        if cs is None: continue
        for q in cs.discrete:
            ok = np.all((q > lo - 3) & (q < hi + 3), 1)
            ax.plot(np.where(ok, q[:, ia], np.nan), np.where(ok, q[:, ib], np.nan), col + "-", lw=lw)
    ax.set_xlim(lo[ia], hi[ia]); ax.set_ylim(lo[ib], hi[ib]); ax.set_aspect(1); ax.grid(True, alpha=.4)
    ax.set_xticks(np.arange(np.floor(lo[ia]), hi[ia] + 1, 1)); ax.set_yticks(np.arange(np.floor(lo[ib]), hi[ib] + 0.5, 0.5)); ax.tick_params(labelsize=5)
    ax.set_title(f"{'XYZ'[axis]}={L}: scan gold, Rev A green, Rev C blue")
plt.tight_layout(); plt.savefig(f"work/revC2/{name}.png", dpi=70)
