import sys, json, trimesh
from OCP.STEPControl import STEPControl_Reader
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
stl, fin, steps = sys.argv[1], json.load(open(sys.argv[2])), sys.argv[3:]
m = trimesh.load(stl); out = {"prt_volume": fin["volume_mm3"], "prt_stl_bbox": [round(x, 3) for x in list(m.bounds[0]) + list(m.bounds[1])]}
for p in steps:
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); s = r.OneShape()
    n = 0; e = TopExp_Explorer(s, TopAbs_SOLID)
    while e.More(): n += 1; e.Next()
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g)
    b = Bnd_Box(); BRepBndLib.AddOptimal_s(s, b, True, False)
    bb = [round(x, 3) for x in b.Get()]
    out[p.split("_")[-1]] = {"solids": n, "valid": BRepCheck_Analyzer(s).IsValid(), "volume": round(g.Mass(), 1),
                             "vol_rel_diff": round((g.Mass() - fin["volume_mm3"]) / fin["volume_mm3"], 6), "bbox_optimal": bb,
                             "bbox_max_diff_vs_prt_stl": round(max(abs(a - c) for a, c in zip(bb, out["prt_stl_bbox"])), 3)}
json.dump(out, open("work/revC/stepcheck_revC.json", "w"), indent=1); print(json.dumps(out, indent=1))
