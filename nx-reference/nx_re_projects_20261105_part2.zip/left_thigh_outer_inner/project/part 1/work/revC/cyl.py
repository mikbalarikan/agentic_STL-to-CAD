import sys
from OCP.STEPControl import STEPControl_Reader
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Cylinder
from OCP.TopoDS import TopoDS
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
r = STEPControl_Reader(); r.ReadFile(sys.argv[1]); r.TransferRoots(); s = r.OneShape()
e = TopExp_Explorer(s, TopAbs_FACE); out = []
while e.More():
    f = TopoDS.Face_s(e.Current()); a = BRepAdaptor_Surface(f)
    if a.GetType() == GeomAbs_Cylinder:
        c = a.Cylinder(); ax = c.Axis(); d = ax.Direction(); l = ax.Location()
        if abs(d.Z()) > 0.999:
            x0 = l.X() - d.X() * l.Z() / d.Z(); y0 = l.Y() - d.Y() * l.Z() / d.Z()
            if (x0**2 + y0**2) ** 0.5 < 1.0 and c.Radius() > 40:
                b = Bnd_Box(); BRepBndLib.Add_s(f, b); z = b.Get()
                out.append((round(c.Radius(), 3), round(x0, 3), round(y0, 3), round(z[2], 2), round(z[5], 2)))
    e.Next()
for o in sorted(set(out)): print(o)
b = Bnd_Box(); BRepBndLib.AddOptimal_s(s, b, True, False); print("optimal bbox", [round(v, 3) for v in b.Get()])
