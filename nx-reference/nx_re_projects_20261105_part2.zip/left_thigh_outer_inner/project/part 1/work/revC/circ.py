import sys
from OCP.STEPControl import STEPControl_Reader
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_EDGE
from OCP.BRepAdaptor import BRepAdaptor_Curve
from OCP.GeomAbs import GeomAbs_Circle
from OCP.TopoDS import TopoDS
r = STEPControl_Reader(); r.ReadFile(sys.argv[1]); r.TransferRoots(); s = r.OneShape()
e = TopExp_Explorer(s, TopAbs_EDGE); out = set()
while e.More():
    c = BRepAdaptor_Curve(TopoDS.Edge_s(e.Current()))
    if c.GetType() == GeomAbs_Circle:
        ci = c.Circle(); l = ci.Location()
        if abs(ci.Radius() - 55) < 0.3 or abs(ci.Radius() - 68.25) < 0.05:
            out.add((round(ci.Radius(), 3), round(l.X(), 3), round(l.Y(), 3), round(l.Z(), 3), round(c.LastParameter() - c.FirstParameter(), 3)))
    e.Next()
for o in sorted(out): print(o)
