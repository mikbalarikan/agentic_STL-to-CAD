"""Deviation colour maps scan -> CAD (signed) on the 600 k scan mesh, banded scale identical on every view, legend in mm.
usage: q4_maps.py cad.stl out_dir [prefix]"""
import sys, os
import numpy as np
import open3d as o3d
import pyvista as pv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\an")
from common import W

cad, OUT = sys.argv[1], sys.argv[2]
PRE = sys.argv[3] if len(sys.argv) > 3 else "LT-OUT-001_deviation_"
os.makedirs(OUT, exist_ok=True)
B = [-1.0, -0.5, -0.2, -0.1, 0.1, 0.2, 0.5, 1.0]
COL = ["#08306b", "#2166ac", "#67a9cf", "#b9dcea", "#3aa357", "#f3dc6b", "#f4a259", "#d6604d", "#7f0000"]
cmap = ListedColormap(COL)
norm = BoundaryNorm([-1e9] + B + [1e9], len(COL))

cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices()
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
m = pv.read(os.path.join(W, "scan_600k_framed.ply"))
d = sc.compute_signed_distance(o3d.core.Tensor(np.asarray(m.points, np.float32))).numpy()
m["rgb"] = (cmap(norm(d))[:, :3] * 255).astype(np.uint8)
c = np.array(m.center)
VIEWS = {  # name: (title, direction focus->camera, up, parallel?, focus, zoom)
    "iso_top": ("Isometric, top", (-0.55, -0.6, 0.75), (0, 0, 1), False, c, 1.25),
    "iso_bottom": ("Isometric, bottom", (-0.5, -0.55, -0.7), (0, 0, 1), False, c, 1.25),
    "top": ("Top (+Z)", (0, 0, 1), (0, 1, 0), True, c, 1.15),
    "bottom": ("Bottom (-Z)", (0, 0, -1), (0, 1, 0), True, c, 1.15),
    "side_px": ("Side +X", (1, 0, 0), (0, 0, 1), True, c, 1.1),
    "side_nx": ("Side -X", (-1, 0, 0), (0, 0, 1), True, c, 1.1),
    "hip_end": ("Hip end", (0.35, 0.75, 0.55), (0, 0, 1), False, c, 1.2),
}
for name, (title, dv, up, par, foc, zm) in VIEWS.items():
    dv = np.array(dv, float); dv /= np.linalg.norm(dv)
    p = pv.Plotter(off_screen=True, window_size=(1600, 1300))
    p.set_background("white")
    p.add_mesh(m, scalars="rgb", rgb=True, smooth_shading=True, ambient=0.3, diffuse=0.75, specular=0.1)
    p.enable_parallel_projection() if par else None
    dist = 330 if name == "hip_end" else 700
    p.camera_position = [tuple(foc + dv * dist), tuple(foc), up]
    p.camera.view_angle = 30
    p.reset_camera()
    p.camera.zoom(zm)
    img = p.screenshot(None, return_img=True); p.close()
    # crop white margins
    nz = np.where((img < 250).any(2))
    y0, y1, x0, x1 = max(nz[0].min() - 30, 0), min(nz[0].max() + 30, img.shape[0]), max(nz[1].min() - 30, 0), min(nz[1].max() + 30, img.shape[1])
    img = img[y0:y1, x0:x1]
    h, w = img.shape[:2]
    fig = plt.figure(figsize=(10, 10 * (h / w) * 0.86 + 1.4), dpi=170)
    ax = fig.add_axes([0.0, 0.14, 0.86, 0.80]); ax.imshow(img); ax.axis("off")
    ax.set_title(f"LT-OUT-001 Rev F - scan to CAD deviation - {title}", fontsize=11, loc="left")
    cax = fig.add_axes([0.88, 0.2, 0.025, 0.68])
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=BoundaryNorm([-1.5] + B + [1.5], len(COL)))
    cb = fig.colorbar(sm, cax=cax, boundaries=[-1.5] + B + [1.5], ticks=B, spacing="uniform")
    cb.ax.set_yticklabels([f"{b:+.1f}" if abs(b) >= 0.5 else f"{b:+.2f}" for b in B], fontsize=8)
    cb.set_label("deviation [mm]", fontsize=9)
    fig.text(0.01, 0.06, "Signed distance of the scan surface to the CAD solid. + (warm): scan outside the CAD, CAD has less material.\n"
             "- (cool): scan inside the CAD, CAD has more material. Green band: within +/-0.10 mm. End bands: beyond +/-1.0 mm.",
             fontsize=8, color="#333333")
    fig.savefig(os.path.join(OUT, f"{PRE}{name}.png"), dpi=170, bbox_inches="tight", pad_inches=0.15); plt.close(fig)
    print("wrote", name, img.shape)
