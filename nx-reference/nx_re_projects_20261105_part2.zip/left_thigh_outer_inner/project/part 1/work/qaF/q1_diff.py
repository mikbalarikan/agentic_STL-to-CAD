"""Changed regions between two CAD STLs: surface samples of each farther than TOL from the other, DBSCAN clusters, bbox.
usage: q1_diff.py a.stl b.stl out.json"""
import sys, json
import numpy as np, open3d as o3d
TOL = 0.12
def load(p):
    m = o3d.io.read_triangle_mesh(p); m.remove_duplicated_vertices(); return m
def scene(m):
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m)); return s
A, B = load(sys.argv[1]), load(sys.argv[2])
SA, SB = scene(A), scene(B)
out = {}
for name, m, s_other in (("in_b_not_a", B, SA), ("in_a_not_b", A, SB)):
    P = np.asarray(m.sample_points_uniformly(3000000).points, np.float32)
    d = s_other.compute_distance(o3d.core.Tensor(P)).numpy()
    Q = P[d > TOL]; dq = d[d > TOL]
    pc = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(Q.astype(np.float64)))
    lab = np.array(pc.cluster_dbscan(eps=1.5, min_points=10))
    rows = []
    for k in range(lab.max() + 1):
        sel = lab == k
        if sel.sum() < 150: continue
        q = Q[sel]
        rows.append(dict(n=int(sel.sum()), lo=[round(float(x), 1) for x in q.min(0)], hi=[round(float(x), 1) for x in q.max(0)],
                         dmax=round(float(dq[sel].max()), 2), dmed=round(float(np.median(dq[sel])), 2)))
    rows.sort(key=lambda r: -r["n"])
    out[name] = rows
    print(name, len(Q))
    for r in rows: print("  ", r)
json.dump(out, open(sys.argv[3], "w"), indent=1)
