import sys, numpy as np, open3d as o3d
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\an")
from common import load
v, f = load(); V = v.astype(np.float32)
def sc(p):
    m = o3d.io.read_triangle_mesh(p); m.remove_duplicated_vertices(); s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m)); return s
SA, SF = sc(sys.argv[1]), sc(sys.argv[2])
for lo, hi in (((83, 97, 27), (101, 137, 35)), ((20, 78, -29), (39, 167, 1)), ((52, 27, -11), (84, 58, 37))):
    P = V[np.all((V > lo) & (V < hi), 1)]
    dF = SF.compute_signed_distance(o3d.core.Tensor(P)).numpy(); dA = SA.compute_signed_distance(o3d.core.Tensor(P)).numpy()
    for nm, m in (("F>+0.5", dF > 0.5), ("F<-0.5", dF < -0.5)):
        Q = P[m]
        if len(Q): print(lo, nm, len(Q), "min", Q.min(0).round(1), "max", Q.max(0).round(1), "medF", np.median(dF[m]).round(2), "medA", np.median(dA[m]).round(2))
