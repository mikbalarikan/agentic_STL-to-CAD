"""Scan points that fit Rev A (|d|<=0.3) but not Rev F (|d|>0.5): clusters with bbox and sign. usage: q3_worse.py revA.stl revF.stl"""
import sys
import numpy as np, open3d as o3d
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\an")
from common import load
v, f = load()
def sc(p):
    m = o3d.io.read_triangle_mesh(p); m.remove_duplicated_vertices(); s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m)); return s
P = v[np.random.default_rng(7).choice(len(v), 1500000, replace=False)].astype(np.float32)
dA = sc(sys.argv[1]).compute_signed_distance(o3d.core.Tensor(P)).numpy()
dF = sc(sys.argv[2]).compute_signed_distance(o3d.core.Tensor(P)).numpy()
for name, m in (("worse in F", (np.abs(dA) <= 0.3) & (np.abs(dF) > 0.5)), ("better in F", (np.abs(dF) <= 0.3) & (np.abs(dA) > 0.5))):
    Q = P[m]; d = dF[m] if name.startswith("worse") else dA[m]
    print(name, m.sum())
    lab = np.array(o3d.geometry.PointCloud(o3d.utility.Vector3dVector(Q.astype(np.float64))).cluster_dbscan(eps=2.0, min_points=8))
    rows = []
    for k in range(lab.max() + 1):
        s = lab == k
        if s.sum() < 300: continue
        rows.append((s.sum(), Q[s].min(0).round(1), Q[s].max(0).round(1), round(float(np.median(d[s])), 2)))
    for r in sorted(rows, key=lambda r: -r[0])[:25]: print("  ", r[0], r[1], r[2], "median d", r[3])
