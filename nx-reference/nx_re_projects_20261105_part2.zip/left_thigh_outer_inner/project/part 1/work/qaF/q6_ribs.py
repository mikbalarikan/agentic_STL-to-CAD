import sys, numpy as np, open3d as o3d
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\an")
from common import load
v, f = load(); V = v.astype(np.float32)
def sc(p):
    m = o3d.io.read_triangle_mesh(p); m.remove_duplicated_vertices(); s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m)); return s
S = {"A": sc(sys.argv[1]), "F": sc(sys.argv[2])}
R = {"U": ((-4.0, 76, -13), (2.0, 167, 1)), "A": ((20, 78, -29), (39, 167, 1)), "B": ((54, 68, -18), (81, 167, 1)),
     "C": ((-13, 163, -7), (84, 168, -3)), "D": ((35.5, 164, -29), (40.5, 271, -11)), "H": ((-25, 233, -9), (-19, 263, 29)),
     "I": ((95, 233, -10), (101, 263, 29)), "G1": ((52, 27, -11), (84, 58, 37)), "G2": ((-20, 76.5, -10), (-1, 81, 37)),
     "F2_top": ((83, 97, 27), (101, 137, 35))}
for k, (lo, hi) in R.items():
    P = V[np.all((V > lo) & (V < hi), 1)]
    s = []
    for t in "AF":
        d = S[t].compute_signed_distance(o3d.core.Tensor(P)).numpy()
        s.append(f"{t}: w0.5 {100*(np.abs(d)<=.5).mean():5.1f} mean {d.mean():+.2f} >+0.5 {100*(d>.5).mean():4.1f} <-0.5 {100*(d<-.5).mean():4.1f}")
    print(f"{k:6s} n {len(P):6d} | " + " | ".join(s))
