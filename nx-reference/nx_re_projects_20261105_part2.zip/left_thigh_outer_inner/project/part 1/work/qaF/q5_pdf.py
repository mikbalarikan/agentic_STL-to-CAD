"""Build the Rev F deviation report PDF (reportlab, system Python).
usage: q5_pdf.py qa.json maps_dir finalize_revF.json finalize_revA.json out.pdf"""
import sys, os, json
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether)
from reportlab.lib.utils import ImageReader

QA, MAPS, FINF, FINA, OUT = sys.argv[1:6]   # argv 6 / 7: Rev A / Rev F STL for the bounding boxes
q = json.load(open(QA)); fF = json.load(open(FINF)); fA = json.load(open(FINA))
ss = getSampleStyleSheet()
H1 = ParagraphStyle("h1", parent=ss["Title"], fontSize=17, leading=21, alignment=0, spaceAfter=2)
H2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12, leading=15, spaceBefore=8, spaceAfter=4)
B = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9, leading=12)
S = ParagraphStyle("s", parent=B, fontSize=7.8, leading=10, textColor=colors.HexColor("#333333"))
C = ParagraphStyle("c", parent=B, fontSize=7.6, leading=9.2)
GRID = colors.HexColor("#9aa3ad"); HEAD = colors.HexColor("#dde3ea"); ALT = colors.HexColor("#f4f6f8")


def tstyle(nrows, bold_first_col=False):
    st = [("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 7.8), ("FONT", (0, 1), (-1, -1), "Helvetica", 7.8),
          ("BACKGROUND", (0, 0), (-1, 0), HEAD), ("GRID", (0, 0), (-1, -1), 0.4, GRID),
          ("ALIGN", (1, 0), (-1, -1), "CENTER"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("TOPPADDING", (0, 0), (-1, -1), 2.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.2)]
    for r in range(2, nrows, 2):
        st.append(("BACKGROUND", (0, r), (-1, r), ALT))
    return TableStyle(st)


def pct(x):
    return f"{100 * x:.1f} %"


def footer(cv, doc):
    cv.saveState(); cv.setFont("Helvetica", 7.5); cv.setFillColor(colors.HexColor("#555555"))
    cv.drawString(18 * mm, 10 * mm, "LT-OUT-001 Rev F - Scan-to-CAD Deviation Report - 2026-11-02")
    cv.drawRightString(A4[0] - 18 * mm, 10 * mm, f"Page {doc.page}")
    cv.restoreState()


E = []
E.append(Paragraph("LT-OUT-001 Rev F - Scan-to-CAD Deviation Report", H1))
E.append(Paragraph("Left Thigh, outer shell &nbsp;|&nbsp; Revision F &nbsp;|&nbsp; Date 2026-11-02", B))
E.append(Spacer(1, 4 * mm))

a, f = q["revA"], q["revF"]
E.append(Paragraph("1. Scope and method", H2))
E.append(Paragraph(
    "The Rev F solid is compared with the 3D-scan mesh of the original part (7 266 929 triangles). Scan and CAD share one "
    "model frame: origin on the knee-bore axis at the knee-floor plane, +Z along the knee axis toward the open side, +Y along "
    "the hip-ring axis (knee to hip). No best-fit alignment is applied between the measurements; Rev A (the issued revision) "
    "and Rev F are measured against the same scan, in the same frame, on the same 1 500 000 scan samples.", B))
E.append(Spacer(1, 2 * mm))
E.append(Paragraph(
    "<b>Scan to CAD</b>: signed distance of each scan sample to the CAD solid; + means the scan lies outside the CAD (the CAD "
    "has less material), - means the scan lies inside the CAD. Percentiles are of the absolute distance. "
    "<b>CAD to scan</b>: unsigned distance of 600 000 uniform samples of the CAD surface to the scan mesh; it also counts CAD "
    "faces the scanner did not capture (bores, hole walls, faces in shadow).", B))
E.append(Spacer(1, 2 * mm))
E.append(Paragraph(
    "Zones: <b>knee hub</b> = scan points within r 70 of the knee axis; <b>hip ring / plate</b> = Y &gt; 262; "
    "<b>outer skin</b> = remaining points within 1 mm of the fitted outer envelope; <b>interior</b> = everything else "
    "(ribs, pockets, bosses, lugs, inner wall faces).", B))

E.append(Paragraph("2. Part data", H2))
volA = fA["volume_mm3"]
rows = [["", "Rev A (issued)", "Rev F"],
        ["Volume [mm3]", f"{volA:,.0f}", f"{fF['volume_mm3']:,.0f}"],
        ["Mass, Al 6061 (2.70 g/cm3) [kg]", f"{volA * 2.7e-6:.3f}", f"{fF['volume_mm3'] * 2.7e-6:.3f}"],
        ["Solids", "1", str(fF.get("n_solids_final", "-"))]]
import numpy as np
def stl_bounds(p):
    with open(p, "rb") as fh:
        fh.read(80); n = int(np.frombuffer(fh.read(4), "<u4")[0])
        rec = np.frombuffer(fh.read(50 * n), np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]))
    v = rec["v"].reshape(-1, 3).astype(np.float64)
    return [round(float(x), 2) for x in list(v.min(0)) + list(v.max(0))]
ba, bx = stl_bounds(sys.argv[6]), stl_bounds(sys.argv[7])
fb = lambda b: f"X {b[0]:.2f}..{b[3]:.2f}  Y {b[1]:.2f}..{b[4]:.2f}  Z {b[2]:.2f}..{b[5]:.2f}" if b else "-"
if bx:
    rows.append(["Bounding box, model frame [mm]", Paragraph(fb(ba), C), Paragraph(fb(bx), C)])
if False:
    rows.append(["", "", f"X {bx[0]:.2f}..{bx[3]:.2f}  Y {bx[1]:.2f}..{bx[4]:.2f}  Z {bx[2]:.2f}..{bx[5]:.2f}"])
t = Table(rows, colWidths=[50 * mm, 62 * mm, 62 * mm]); t.setStyle(tstyle(len(rows))); E.append(t)

E.append(Paragraph("3. Deviation by zone", H2))
Z = (("all", "Whole part"), ("outer_skin", "Outer skin"), ("knee_hub", "Knee hub (r < 70)"), ("hip_ring", "Hip ring / plate (Y > 262)"),
     ("interior", "Interior"))
rows = [["Zone", "Points", "Rev", "Mean", "p50", "p90", "p95", "Within 0.2", "Within 0.5"]]
for k, nm in Z:
    for tag, lab in (("revA", "A"), ("revF", "F")):
        s = q[tag]["scan_to_cad"][k]
        rows.append([nm if tag == "revA" else "", f"{s['n']:,}" if tag == "revA" else "", lab, f"{s['mean']:+.3f}", f"{s['p50']:.3f}",
                     f"{s['p90']:.3f}", f"{s['p95']:.3f}", pct(s["within_0p2"]), pct(s["within_0p5"])])
for tag, lab in (("revA", "A"), ("revF", "F")):
    s = q[tag]["cad_to_scan"]
    rows.append(["CAD to scan (unsigned)" if tag == "revA" else "", f"{s['n']:,}" if tag == "revA" else "", lab, "-", f"{s['p50']:.3f}",
                 f"{s['p90']:.3f}", f"{s['p95']:.3f}", pct(s["within_0p2"]), pct(s["within_0p5"])])
t = Table(rows, colWidths=[44 * mm, 17 * mm, 9 * mm, 15 * mm, 14 * mm, 14 * mm, 14 * mm, 19 * mm, 19 * mm])
st = tstyle(len(rows))
for r in range(1, len(rows), 2):
    st.add("LINEABOVE", (0, r), (-1, r), 0.9, colors.HexColor("#56606b"))
    st.add("SPAN", (0, r), (0, r + 1)); st.add("SPAN", (1, r), (1, r + 1))
    st.add("BACKGROUND", (0, r), (-1, r + 1), colors.white)
    st.add("BACKGROUND", (2, r + 1), (-1, r + 1), ALT)
t.setStyle(st); E.append(t)
E.append(Paragraph("All values in mm except counts and percentages. Mean is signed; p50 / p90 / p95 are percentiles of |d|.", S))

E.append(PageBreak())
E.append(Paragraph("4. Regions changed in Rev F", H2))
E.append(Paragraph(
    "Scan points inside a box around each changed region (boxes in the model frame, set from the Rev F geometry; a region "
    "may consist of several boxes, the extent column gives their envelope). Signed scan-to-CAD distance, statistics of |d|. "
    "The last column is the CAD material inside the boxes, probed on a 0.5 mm grid.", B))
E.append(Spacer(1, 2 * mm))
HB = ParagraphStyle("hb", parent=C, fontName="Helvetica-Bold", fontSize=7.0, leading=8.4, alignment=1)
rows = [[Paragraph(h, HB) for h in ["Region", "Extent X / Y / Z [mm]", "Scan points", "Rev A p50", "Rev A p95", "Rev A within 0.5", "Rev F p50", "Rev F p95", "Rev F within 0.5", "CAD vol. in box A / F [mm3]"]]]
for k, r in q["regions"].items():
    bx = r["boxes"]
    lo = [min(b[0][i] for b in bx) for i in range(3)]; hi = [max(b[1][i] for b in bx) for i in range(3)]
    ext = " / ".join(f"{lo[i]:.0f}..{hi[i]:.0f}" for i in range(3))
    if len(bx) > 1:
        ext += f" ({len(bx)} boxes)"
    A_, F_ = r["revA"], r["revF"]
    v = r["cad_volume_in_box_mm3"]
    rows.append([Paragraph(k, C), Paragraph(ext, C), f"{r['n']:,}", f"{A_['p50']:.3f}", f"{A_['p95']:.2f}", pct(A_["within_0p5"]),
                 f"{F_['p50']:.3f}", f"{F_['p95']:.2f}", pct(F_["within_0p5"]), f"{v['revA']:,.0f} / {v['revF']:,.0f}"])
t = Table(rows, colWidths=[33 * mm, 33 * mm, 13 * mm, 11 * mm, 11 * mm, 15 * mm, 11 * mm, 11 * mm, 15 * mm, 21 * mm], repeatRows=1)
st = tstyle(len(rows)); st.add("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 7.0); st.add("FONT", (2, 1), (-1, -1), "Helvetica", 7.4)
t.setStyle(st); E.append(t)

NOTES = json.load(open(os.path.join(os.path.dirname(QA), "notes.json"))) if os.path.exists(os.path.join(os.path.dirname(QA), "notes.json")) else {}
if NOTES.get("regions"):
    E.append(Spacer(1, 2 * mm))
    for n in NOTES["regions"]:
        E.append(Paragraph("&bull; " + n, B))

E.append(Paragraph("5. Documented simplifications", H2))
for n in NOTES.get("simplifications", []):
    E.append(Paragraph("&bull; " + n, B))

E.append(PageBreak())
E.append(Paragraph("6. Colour maps", H2))
E.append(Paragraph(
    "Scan surface coloured by its signed distance to the Rev F solid. One banded scale for all views: green within "
    "+/-0.10 mm; warm colours where the scan lies outside the CAD (+), cool colours where it lies inside (-); the end bands "
    "collect everything beyond +/-1.0 mm. Uncoloured gaps are areas the scan does not cover.", B))

VIEWS = ["iso_top", "iso_bottom", "top", "bottom", "side_px", "side_nx", "hip_end"]
W_AV, H_AV = A4[0] - 36 * mm, A4[1] - 40 * mm
E.append(Spacer(1, 3 * mm))
FIRST = True
pairs = [("iso_top", "iso_bottom"), ("top",), ("bottom",), ("side_px", "side_nx", "hip_end")]
for grp in pairs:
    imgs = []
    for v in grp:
        p = os.path.join(MAPS, f"LT-OUT-001_deviation_{v}.png")
        iw, ih = ImageReader(p).getSize()
        imgs.append((p, iw, ih))
    if grp == ("top", "bottom"):  # tall images side by side
        w = W_AV / 2 - 2 * mm
        cells = [Image(p, width=w, height=w * ih / iw) for p, iw, ih in imgs]
        h = max(c.drawHeight for c in cells)
        if h > H_AV:
            sc = H_AV / h
            cells = [Image(p, width=w * sc, height=w * sc * ih / iw) for p, iw, ih in imgs]
        tb = Table([cells], colWidths=[W_AV / 2, W_AV / 2]); tb.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
        E.append(tb)
    else:
        tot = sum(W_AV * ih / iw for p, iw, ih in imgs) + 4 * mm * len(imgs)
        sc = min(1.0, (H_AV - 6 * mm - (25 * mm if FIRST else 0)) / tot); FIRST = False
        for p, iw, ih in imgs:
            E.append(Image(p, width=W_AV * sc, height=W_AV * sc * ih / iw)); E.append(Spacer(1, 3 * mm))
    if grp != pairs[-1]:
        E.append(PageBreak())

doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=18 * mm,
                        title="LT-OUT-001 Rev F - Scan-to-CAD Deviation Report", author="", subject="Scan-to-CAD deviation, LT-OUT-001 Rev F")
doc.build(E, onFirstPage=footer, onLaterPages=footer)
print("wrote", OUT)
