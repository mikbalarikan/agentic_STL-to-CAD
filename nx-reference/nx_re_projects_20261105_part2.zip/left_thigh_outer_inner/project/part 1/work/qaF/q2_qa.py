"""Rev F QA numbers: scan->CAD zones (same zones / 1.5 M samples / seed as an/dev2.py) and CAD->scan for Rev A and
Rev F, per-region table for the Rev F changes, box probes on the Rev F STL.
usage: q2_qa.py revA.stl revF.stl out.json"""
import sys, os, json, math
import numpy as np
import open3d as o3d
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\an")
from common import W, load

A_STL, F_STL, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
N = 1500000


def pol(deg, r):
    a = math.radians(deg); return r * math.cos(a), r * math.sin(a)


def polar_box(d0, d1, r0, r1, z0, z1):
    xs, ys = [], []
    for d in np.linspace(d0, d1, 25):
        for r in (r0, r1):
            x, y = pol(d, r); xs.append(x); ys.append(y)
    return [(min(xs), min(ys), z0), (max(xs), max(ys), z1)]


def rib_box(o, d, deg=None):
    return o


# region boxes in the model frame (lo, hi); a region may be a union of boxes
REG = {
    "Side window (-X wall, hip end)": [((-46, 176, -6), (-13, 244, 46))],
    "Inner ribs U, A, B, C, D, G1, G2, H, I": [
        ((-4.0, 76, -13), (2.0, 167, 1)), ((20, 78, -29), (39, 167, 1)), ((54, 68, -18), (81, 167, 1)),
        ((-13, 163, -7), (84, 168, -3)), ((35.5, 164, -29), (40.5, 271, -11)), ((-25, 233, -9), (-19, 263, 29)),
        ((95, 233, -10), (101, 263, 29)), ((52, 27, -11), (84, 58, 37)), ((-20, 76.5, -10), (-1, 81, 37))],
    "F1 boss + K1 clip head": [((89, 200, -12), (101, 214, 3.5))],
    "F2 sensor pads": [((83, 97, 5), (94, 110, 30.5)), ((89, 120, 5), (101, 137, 30.5))],
    "F3 lug + hole": [((70, 124, -13), (82, 136, 1))],
    "F4 radial ribs": [polar_box(17.5, 25.5, 54, 76, -12, 6), polar_box(-37, -29, 54, 69, -12, 6)],
    "F5 lug, column + hub": [((52, -50, -6), (80, -22, 40))],
    "F6 rib + pin": [polar_box(-127, -117, 54, 66, -9, 8), ((-34, -55, 7), (-28, -48, 15.5))],
    "Hip ring wall (-X, 134..155 deg)": [polar_box(128, 158, 54, 70, -1, 36)],
    "M1 pad + boss": [((-16, 79, -11), (-1, 96, 1))],
    "Wall offset: -X wall-top strip": [((-61.5, 23, 33), (-12, 181.5, 37.5))],
    "Wall offset: knee face R83.7 + plane": [((25, 66, -14), (54, 82, 1))],
}


def inbox(P, boxes):
    m = np.zeros(len(P), bool)
    for lo, hi in boxes:
        m |= np.all((P > np.array(lo)) & (P < np.array(hi)), 1)
    return m


def scene_of(path):
    cm = o3d.io.read_triangle_mesh(path); cm.remove_duplicated_vertices()
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm)); return cm, s


def st(x):
    ax = np.abs(x)
    if len(x) == 0:
        return {}
    return dict(n=int(len(x)), mean=round(float(x.mean()), 4), rms=round(float(np.sqrt((x ** 2).mean())), 4),
                p50=round(float(np.percentile(ax, 50)), 4), p90=round(float(np.percentile(ax, 90)), 4),
                p95=round(float(np.percentile(ax, 95)), 4), p99=round(float(np.percentile(ax, 99)), 4),
                within_0p2=round(float((ax <= 0.2).mean()), 4), within_0p5=round(float((ax <= 0.5).mean()), 4),
                over_1=round(float((ax > 1).mean()), 4))


v, f = load()
rng = np.random.default_rng(7)
idx = rng.choice(len(v), min(N, len(v)), replace=False)
P = v[idx].astype(np.float32)
env = o3d.io.read_triangle_mesh(os.path.join(os.path.dirname(W), "nx", "out1", "j1_env.stl")); env.remove_duplicated_vertices()
se = o3d.t.geometry.RaycastingScene(); se.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(env))
de = np.abs(se.compute_signed_distance(o3d.core.Tensor(P)).numpy())
knee = np.hypot(P[:, 0], P[:, 1]) < 70
hip = P[:, 1] > 262
outer = (~knee) & (~hip) & (de < 1.0)
inner = (~knee) & (~hip) & ~outer
sm = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
ss = o3d.t.geometry.RaycastingScene(); ss.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(sm))
Vf = v.astype(np.float32)

out = {"zones_n": {"all": int(len(P)), "outer_skin": int(outer.sum()), "knee_hub": int(knee.sum()), "hip_ring": int(hip.sum()), "interior": int(inner.sum())},
       "regions": {k: {"boxes": [[list(map(lambda t: round(float(t), 1), lo)), list(map(lambda t: round(float(t), 1), hi))] for lo, hi in b]} for k, b in REG.items()}}
scenes = {}
for tag, path in (("revA", A_STL), ("revF", F_STL)):
    cm, sc = scene_of(path); scenes[tag] = sc
    d = sc.compute_signed_distance(o3d.core.Tensor(P)).numpy()
    out[tag] = {"scan_to_cad": {"all": st(d), "outer_skin": st(d[outer]), "knee_hub": st(d[knee]), "hip_ring": st(d[hip]), "interior": st(d[inner])}}
    o3d.utility.random.seed(7)
    Q = np.asarray(cm.sample_points_uniformly(600000).points, dtype=np.float32)
    dq = ss.compute_distance(o3d.core.Tensor(Q)).numpy()
    out[tag]["cad_to_scan"] = st(dq)
    out[tag]["stl_mtime"] = os.path.getmtime(path)
    for k, boxes in REG.items():
        R = Vf[inbox(Vf, boxes)]
        dr = sc.compute_signed_distance(o3d.core.Tensor(R)).numpy()
        out["regions"][k]["n"] = int(len(R))
        out["regions"][k][tag] = st(dr)
    print(tag, json.dumps(out[tag]["scan_to_cad"]["all"]), out[tag]["cad_to_scan"]["p95"])
# probe: CAD material in each box (occupancy of a 0.5 mm grid inside the Rev F solid vs Rev A)
for k, boxes in REG.items():
    occ = {}
    for tag in ("revA", "revF"):
        n_in = 0; n_all = 0
        for lo, hi in boxes:
            g = np.stack(np.meshgrid(*[np.arange(lo[i], hi[i], 0.5) for i in range(3)], indexing="ij"), -1).reshape(-1, 3).astype(np.float32)
            sd = scenes[tag].compute_signed_distance(o3d.core.Tensor(g)).numpy()
            n_in += int((sd < 0).sum()); n_all += len(g)
        occ[tag] = round(n_in * 0.125, 0)
    out["regions"][k]["cad_volume_in_box_mm3"] = occ
for k, r in out["regions"].items():
    print(f"{k:42s} n={r['n']:7d}  A p50 {r['revA']['p50']:.3f} p95 {r['revA']['p95']:.3f} w0.5 {100*r['revA']['within_0p5']:.1f} | "
          f"F p50 {r['revF']['p50']:.3f} p95 {r['revF']['p95']:.3f} w0.5 {100*r['revF']['within_0p5']:.1f}  vol {r['cad_volume_in_box_mm3']}")
json.dump(out, open(OUT, "w"), indent=1)
