#!/bin/bash
F="/c/Users/marya/Desktop/Left Thight Reverse Engineer/part 1/deliver_RevF/CAD/_finalize.json"
BASE=$(date -d "2026-11-02 06:50" +%s)
while true; do
  M=$(stat -c %Y "$F" 2>/dev/null || echo 0)
  if [ "$M" -gt "$BASE" ]; then
    N=$(python -c "import json;print(json.load(open(r'''$F''')).get('n_solids_final'))" 2>/dev/null)
    echo "$(date +%T) finalize.json mtime $(date -d @$M +%T) n_solids_final=$N"
    if [ "$N" = "1" ]; then echo LANDED; exit 0; fi
  else
    echo "$(date +%T) not yet"
  fi
  sleep 600
done
