"""Rasterise every page of a drawing PDF for the eye check: overview p<n>.png (55 dpi) and 3 x 2 tiles
p<n>_t<r><c>.png (130 dpi). NX writes text as strokes, so text-over-geometry can only be judged on the images.
usage: python check_pdf.py <pdf> <out_dir> [pages e.g. 1,3]"""
import os
import sys

import fitz

pdf, out = sys.argv[1], sys.argv[2]
want = set(int(v) for v in sys.argv[3].split(",")) if len(sys.argv) > 3 else None
os.makedirs(out, exist_ok=True)
doc = fitz.open(pdf)
for i, page in enumerate(doc, 1):
    if want and i not in want:
        continue
    page.get_pixmap(dpi=55).save(os.path.join(out, "p%d.png" % i))
    R = page.rect
    for r in range(2):
        for c in range(3):
            clip = fitz.Rect(R.x0 + c * R.width / 3.0 - 20, R.y0 + r * R.height / 2.0 - 20,
                             R.x0 + (c + 1) * R.width / 3.0 + 20, R.y0 + (r + 1) * R.height / 2.0 + 20) & R
            page.get_pixmap(dpi=130, clip=clip).save(os.path.join(out, "p%d_t%d%d.png" % (i, r, c)))
print("pages", len(doc))
