"""Open a drawing part (read-only) and dump the drafting curves of every member view: class, points.
args: dwg_prt out_json"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\nx\dwglib")
import NXOpen
import nxh, nxd
import m3d  # noqa: F401  (patched curve_points)

res = {}
try:
    part = nxh.open_part(sys.argv[1], full=True)
    for sh in part.DraftingDrawingSheets:
        sh.Open()
        for v in sh.GetDraftingViews():
            rows = []
            for c, ps in nxd.curves(v):
                rows.append([type(c).__name__, [[round(x, 3) for x in p] for p in nxd.curve_points(c)]])
            res[sh.Name + "/" + v.Name] = rows
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(sys.argv[2], res)
