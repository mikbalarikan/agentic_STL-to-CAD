"""Read-only probe of the Rev F part for the drawing set (never saved).
args: prt out_json
Dumps: solids (bbox), every cylindrical / conical / planar face of every solid (axis/normal, radius, bbox),
feature groups with their members (custom names, type, expressions), user expressions."""
import os, sys, json, traceback, math
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import NXOpen.Features
import nxh

PRT, OUT = sys.argv[1], sys.argv[2]
res = {}
try:
    part = nxh.open_part(PRT)
    sol = [b for b in part.Bodies if b.IsSolidBody]
    res["solids"] = []
    for bi, b in enumerate(sol):
        mn, dirs, dist = nxh.UFS.ModlGeneral.AskBoundingBoxExact(b.Tag, 0)
        mn = list(mn); dist = list(dist)
        rows = {"cyl": [], "cone": [], "plane": [], "other": {}}
        for f in b.GetFaces():
            t, pt, d, rad = nxh.face_data(f)
            bb = [round(v, 3) for v in nxh.bbox(f)]
            if t == 16:
                rows["cyl"].append({"r": round(abs(rad), 4), "pt": [round(v, 3) for v in pt], "dir": [round(v, 4) for v in d], "bb": bb})
            elif t == 17:
                rows["cone"].append({"pt": [round(v, 3) for v in pt], "dir": [round(v, 4) for v in d], "bb": bb})
            elif t == 22:
                n = [round(v, 5) for v in d]
                off = sum(pt[i] * d[i] for i in range(3))
                rows["plane"].append({"n": n, "d": round(off, 4), "bb": bb})
            else:
                rows["other"][str(t)] = rows["other"].get(str(t), 0) + 1
        res["solids"].append({"name": b.Name, "blanked": b.IsBlanked, "layer": b.Layer,
                              "bbox": [round(v, 4) for v in mn + [mn[i] + dist[i] for i in range(3)]],
                              "nfaces": len(b.GetFaces()), "rows": rows})
    feats = list(part.Features.GetFeatures())
    res["n_features"] = len(feats)
    groups = {}
    for f in feats:
        if f.FeatureType != "FSET":
            continue
        try:
            mem = list(f.GetMembers())
        except Exception as e:  # noqa: BLE001
            mem = []
            groups.setdefault("_err", []).append(str(e))
        g = []
        for m in mem:
            try:
                nm = m.Name
            except Exception:  # noqa: BLE001
                nm = ""
            ex = []
            try:
                for e in m.GetExpressions():
                    ex.append([e.Name, e.RightHandSide, round(e.Value, 4)])
            except Exception:  # noqa: BLE001
                pass
            g.append({"feat": m.GetFeatureName(), "name": nm, "type": m.FeatureType, "expr": ex[:12]})
        groups[f.Name or f.GetFeatureName()] = g
    res["groups"] = groups
    named = []
    for f in feats:
        try:
            if f.Name:
                named.append([f.GetFeatureName(), f.Name, f.FeatureType])
        except Exception:  # noqa: BLE001
            pass
    res["named_features"] = named
    ue = []
    for e in part.Expressions:
        try:
            if not e.Name.startswith("p") or not e.Name[1:].isdigit():
                ue.append([e.Name, e.RightHandSide, round(e.Value, 4)])
        except Exception:  # noqa: BLE001
            pass
    res["user_expr"] = ue
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
