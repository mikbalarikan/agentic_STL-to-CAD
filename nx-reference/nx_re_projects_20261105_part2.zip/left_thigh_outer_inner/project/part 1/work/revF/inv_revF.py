"""Investigation on a scratch copy of the Rev F master (never saved):
 A  plain regeneration noise: LogForUpdate(child of Fit Surface 310) with nothing changed -> main volume
 B  chain of Fit Surface(310) descendants with custom names / bodies
 C  frozen extract (FixAtCurrentTimestamp, no Remove Parameters) as Replace Feature replacement -> refused?
 D  the 4 separate solids: their features (custom names, boolean types); unite test of the touching ones
 E  F1_BOSS vs the K1 head body: distance, faces
args: prt out_json"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf

SRC, OUT = sys.argv[1], sys.argv[2]
res = {}
FO = NXOpen.Update.FailureOption


def dump():
    nxh.write_json(OUT, res)


def solids(part):
    return [b for b in part.Bodies if b.IsSolidBody and not getattr(b, "IsConvergentBody", False)]


def main_solid(part):
    return max([b for b in solids(part) if not b.IsBlanked], key=lambda b: nxh.volume(part, b))


def st(part):
    return {"main_vol": nxh.volume(part, main_solid(part)), "n_solids": len(solids(part)),
            "vols": sorted(round(nxh.volume(part, b), 4) for b in solids(part))}


def errs(part):
    out = {}
    for f in part.Features.GetFeatures():
        m = list(f.GetFeatureErrorMessages() or [])
        if m and nxh.suppress_status(f)["code"] == 0:
            out[f.GetFeatureName()] = [str(x) for x in m]
    return out


def fdesc(f):
    try:
        nm = f.Name
    except Exception:  # noqa: BLE001
        nm = ""
    return [f.Timestamp, f.GetFeatureName(), nm, f.FeatureType]


try:
    part = nxh.open_part(SRC)
    nxh.S.UpdateManager.SetDefaultUpdateFailureAction(FO.AcceptAll)
    feats = list(part.Features.GetFeatures())
    byname = {f.GetFeatureName(): f for f in feats}
    res["s0"] = s0 = st(part)
    e0 = set(errs(part))
    res["errors0_active"] = sorted(e0)
    dump()
    # ---- A regeneration noise
    for nm in ("Extend Sheet(311)", "Replace Face(313)", "Replace Face(418)", "Extrude(560)"):
        f = byname.get(nm)
        if f is None:
            continue
        m = nxh.mark("regen " + nm)
        try:
            nxh.S.UpdateManager.LogForUpdate(f)
            nxh.S.UpdateManager.DoUpdate(m)
            s = st(part)
            res.setdefault("A_regen", {})[nm] = {"dvol": s["main_vol"] - s0["main_vol"], "n_solids": s["n_solids"],
                                                "new_errors": sorted(set(errs(part)) - e0)}
        except Exception as e:  # noqa: BLE001
            res.setdefault("A_regen", {})[nm] = "ERR " + str(e)
        nxh.undo_to(m)
        res.setdefault("A_after_undo", []).append(st(part)["main_vol"])
        dump()
    # ---- B chain
    fit = byname["Fit Surface(Cylinder)(310)"]
    seen, stack, chain = set(), [fit], []
    while stack:
        f = stack.pop()
        if f.Tag in seen:
            continue
        seen.add(f.Tag)
        stack.extend(f.GetChildren())
    for f in part.Features.GetFeatures():
        if f.Tag in seen:
            d = fdesc(f)
            d.append([fdesc(p)[1] for p in f.GetParents()])
            try:
                d.append([[b.IsSolidBody, round(nxh.volume(part, b), 2) if b.IsSolidBody else None] for b in f.GetBodies()])
            except Exception:  # noqa: BLE001
                pass
            chain.append(d)
    res["B_chain_310"] = chain
    for nm in ("Fit Surface(Plane)(315)", "Fit Surface(Plane)(318)"):
        f = byname[nm]
        res.setdefault("B_children", {})[nm] = [fdesc(c) for c in f.GetChildren()]
    dump()
    # ---- C frozen extract as replacement
    m = nxh.mark("C")
    try:
        end = part.CurrentFeature
        fit.MakeCurrentFeature()
        ef, new = nxf.extract_body(part, list(fit.GetBodies()), fix_at_timestamp=True)
        end.MakeCurrentFeature()
        nxh.update("C roll")
        res["C_extract"] = {"feature": ef.GetFeatureName(), "vol_after_roll": st(part)["main_vol"] - s0["main_vol"]}
        b = part.Features.CreateReplaceFeatureBuilder()
        try:
            b.SelectFeature.Add(fit)
            b.ReplacementFeature.Add(ef)
            b.DoAutomaticGeomMatch = True
            b.DeleteOriginalFeature = True
            b.MappingTolerance = 0.01
            b.UpdateMap()
            b.AutomatchMap()
            b.Commit()
        finally:
            b.Destroy()
        nxh.update("C replace")
        s = st(part)
        res["C_replace"] = {"dvol": s["main_vol"] - s0["main_vol"], "n_solids": s["n_solids"], "new_errors": sorted(set(errs(part)) - e0)}
    except Exception as e:  # noqa: BLE001
        res["C_error"] = traceback.format_exc()[-700:]
    nxh.undo_to(m)
    res["C_after_undo"] = st(part)["main_vol"]
    dump()
    # ---- D separate solids
    main = main_solid(part)
    D = []
    others = [b for b in solids(part) if b.Tag != main.Tag]
    for b in others:
        row = {"tag": b.Tag, "vol": round(nxh.volume(part, b), 3), "bbox": nxh.bbox(b), "dist": nxh.min_dist(main, b),
               "features": [fdesc(f) for f in b.GetFeatures()]}
        bo = []
        for f in b.GetFeatures():
            if f.FeatureType == "EXTRUDE":
                try:
                    eb = part.Features.CreateExtrudeBuilder(f)
                    try:
                        bo.append([f.GetFeatureName(), str(eb.BooleanOperation.Type),
                                   [t.Tag for t in (eb.BooleanOperation.GetTargetBodies() or [])]])
                    finally:
                        eb.Destroy()
                except Exception as e:  # noqa: BLE001
                    bo.append([f.GetFeatureName(), "err " + str(e)[:80]])
        row["extrude_booleans"] = bo
        D.append(row)
    res["D_bodies"] = D
    res["D_main_tag"] = main.Tag
    dump()
    m = nxh.mark("D unite")
    try:
        for b in others:
            if nxh.min_dist(main, b) > 1e-6:
                continue
            v0, vb, n0 = nxh.volume(part, main), nxh.volume(part, b), len(solids(part))
            u = nxh.unite(part, main, [b])
            main = main_solid(part)
            v1, n1 = nxh.volume(part, main), len(solids(part))
            res.setdefault("D_unite_test", []).append({"tool_vol": round(vb, 3), "main_before": v0, "main_after": v1,
                                                       "overlap": round(v0 + vb - v1, 4), "n_solids": [n0, n1],
                                                       "errors": sorted(set(errs(part)) - e0)})
            dump()
    except Exception as e:  # noqa: BLE001
        res["D_unite_error"] = traceback.format_exc()[-700:]
    nxh.undo_to(m)
    dump()
    # ---- E F1_BOSS vs the K1 head
    f1 = [f for f in part.Features.GetFeatures() if (getattr(f, "Name", "") or "") == "F1_BOSS"]
    k1 = [b for b in solids(part) if abs(nxh.volume(part, b) - 316.835) < 0.01]
    if f1 and k1:
        fb = f1[0]
        res["E_f1"] = {"feature": fdesc(fb), "bodies": [b.Tag for b in fb.GetBodies()],
                       "faces": [[nxh.face_data(x)[0], [round(v, 3) for v in nxh.bbox(x)]] for x in fb.GetFaces()][:12]}
        try:
            res["E_f1"]["dist_faces_to_k1"] = [round(nxh.min_dist(x, k1[0]), 4) for x in fb.GetFaces()]
        except Exception as e:  # noqa: BLE001
            res["E_f1"]["dist_err"] = str(e)
        res["E_k1_faces"] = [[nxh.face_data(x)[0], [round(v, 3) for v in nxh.bbox(x)]] for x in k1[0].GetFaces()]
    res["named_A_features"] = [fdesc(f) for f in part.Features.GetFeatures() if (getattr(f, "Name", "") or "").startswith(("FIX_A", "FIX_C", "FIX_D", "F1_"))]
    res["done"] = True
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
dump()
