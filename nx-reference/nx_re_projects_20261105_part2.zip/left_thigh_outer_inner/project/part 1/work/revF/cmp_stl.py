"""Distance between two STLs of the same part (saved-state reference vs regenerated): vertices of each that lie
more than TOL from the other surface, with their bbox. args: ref_stl new_stl [tol]"""
import sys, json
import numpy as np, open3d as o3d
a, b = sys.argv[1], sys.argv[2]
tol = float(sys.argv[3]) if len(sys.argv) > 3 else 0.01
out = {}
for n1, p1, p2 in (("new_vs_ref", b, a), ("ref_vs_new", a, b)):
    m1 = o3d.io.read_triangle_mesh(p1); m2 = o3d.io.read_triangle_mesh(p2)
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m2))
    v = np.asarray(m1.vertices).astype(np.float32)
    d = sc.compute_distance(o3d.core.Tensor(v)).numpy()
    k = d > tol
    r = {"n": int(len(v)), "max": float(d.max()), "n_over": int(k.sum())}
    if k.any():
        P = v[k]
        r["bbox_over"] = [round(float(x), 2) for x in list(P.min(0)) + list(P.max(0))]
        # simple clusters on a 5 mm grid
        g = np.floor(P / 5.0).astype(int); keys, cnt = np.unique(g, axis=0, return_counts=True)
        r["cells"] = [[(keys[i] * 5).tolist(), int(cnt[i]), round(float(d[k][(g == keys[i]).all(1)].max()), 3)] for i in np.argsort(-cnt)[:12]]
    out[n1] = r
print(json.dumps(out, indent=1))
