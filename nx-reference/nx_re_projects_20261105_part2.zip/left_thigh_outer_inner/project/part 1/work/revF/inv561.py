"""What were the rolled-back Offset Regions 561/562/563 of the Rev F master? (read-only, never saved)
For each: distance, reverse flag, face collector rules + their faces (alive?, type, bbox, normal, owning feature),
and the main volume when the tree is rolled forward to it. args: prt out_json"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

SRC, OUT = sys.argv[1], sys.argv[2]
res = {}


def dump():
    nxh.write_json(OUT, res)


def main_vol(part):
    sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not getattr(b, "IsConvergentBody", False)]
    m = max(sol, key=lambda b: nxh.volume(part, b))
    return nxh.volume(part, m), len(sol)


def face_info(part, f):
    d = {"tag": f.Tag, "cls": type(f).__name__}
    try:
        t, pt, dr, rad = nxh.face_data(f)
        d.update({"type": t, "pt": [round(v, 3) for v in pt], "dir": [round(v, 4) for v in dr], "r": round(rad, 4),
                  "bbox": [round(v, 3) for v in nxh.bbox(f)]})
        try:
            d["mid_normal"] = [round(v, 4) for v in nxh.face_mid_normal(f)]
        except Exception:  # noqa: BLE001
            pass
        try:
            d["body"] = f.GetBody().Tag
        except Exception:  # noqa: BLE001
            pass
        try:
            ff = nxh.UFS.Modeling.AskFaceFeats(f.Tag)
            d["feats"] = [NXOpen.TaggedObjectManager.GetTaggedObject(x).GetFeatureName() for x in ff]
        except Exception as e:  # noqa: BLE001
            d["feats_err"] = str(e)[:80]
    except Exception as e:  # noqa: BLE001
        d["dead"] = str(e)[:120]
    return d


def describe(part, f):
    r = {"name": f.GetFeatureName(), "type": f.FeatureType, "status": nxh.suppress_status(f)["code"],
         "errors": [str(x) for x in (f.GetFeatureErrorMessages() or [])],
         "parents": [p.GetFeatureName() for p in f.GetParents()]}
    try:
        b = part.Features.CreateAdmOffsetRegionBuilder(f)
        try:
            r["distance"] = b.Distance.RightHandSide
            r["distance_value"] = b.Distance.Value
            r["reverse"] = bool(b.ReverseDirection)
            fc = b.FaceToOffset.FaceCollector
            rules = []
            for ru in fc.GetRules():
                row = {"rule": type(ru).__name__}
                try:
                    data = ru.GetData()
                    objs = data if isinstance(data, (list, tuple)) else [data]
                    flat = []
                    for o in objs:
                        flat.extend(o if isinstance(o, (list, tuple)) else [o])
                    row["data"] = [face_info(part, o) if isinstance(o, NXOpen.Face) else str(o)[:80] for o in flat]
                except Exception as e:  # noqa: BLE001
                    row["data_err"] = str(e)[:120]
                rules.append(row)
            r["rules"] = rules
            r["resolved_faces"] = [face_info(part, o) for o in fc.GetObjects()]
        finally:
            b.Destroy()
    except Exception as e:  # noqa: BLE001
        r["builder_err"] = traceback.format_exc()[-400:]
    return r


try:
    part = nxh.open_part(SRC)
    nxh.S.UpdateManager.SetDefaultUpdateFailureAction(NXOpen.Update.FailureOption.AcceptAll)
    fs = {f.GetFeatureName(): f for f in part.Features.GetFeatures()}
    names = ["Offset Region(561)", "Offset Region(562)", "Offset Region(563)"]
    v, n = main_vol(part)
    res["at_560"] = {"current": part.CurrentFeature.GetFeatureName(), "vol": v, "n_solids": n}
    res["rolled_back_state"] = {nm: describe(part, fs[nm]) for nm in names}
    dump()
    prev = v
    for nm in names + ["Feature Group(564)"]:
        f = fs[nm]
        f.MakeCurrentFeature()
        nxh.update("to " + nm)
        v, n = main_vol(part)
        res.setdefault("roll", []).append({"current": nm, "vol": v, "dvol": v - prev, "n_solids": n,
                                           "errors": [str(x) for x in (f.GetFeatureErrorMessages() or [])]})
        prev = v
        if nm in names:
            res.setdefault("active_state", {})[nm] = describe(part, f)
        dump()
    res["done"] = True
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
dump()
