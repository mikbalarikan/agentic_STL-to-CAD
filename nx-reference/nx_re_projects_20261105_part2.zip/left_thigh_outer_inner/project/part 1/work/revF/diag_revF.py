"""Read-only diagnosis of the Rev F master: rolled back?, errors on open, solids, scan-dependent features.
args: prt out_json   (never saved)"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

SRC, OUT = sys.argv[1], sys.argv[2]
res = {}
try:
    part = nxh.open_part(SRC)
    feats = list(part.Features.GetFeatures())
    res["n_features"] = len(feats)
    cf = part.CurrentFeature
    res["current_feature"] = cf.GetFeatureName() if cf else None
    res["last_feature"] = feats[-1].GetFeatureName()
    res["rolled_back"] = [f.GetFeatureName() for f in nxh.rolled_back(part)][:50]
    res["suppressed"] = [[f.GetFeatureName(), nxh.suppress_status(f)["code"]] for f in feats
                         if f.Suppressed and not nxh.suppress_status(f)["rolled_back"]][:200]
    res["errors_on_open_raw"] = {k: [str(x) for x in v] for k, v in nxh._scan_errors(part)[0].items()}
    res["bodies"] = [{k: v for k, v in r.items() if k != "body"} for r in nxh.bodies_report(part) if r["solid"]]
    # groups
    grp = {}
    for f in feats:
        if f.FeatureType == "FSET":
            try:
                for m in f.GetMembers():
                    grp[m.Tag] = f.GetFeatureName()
            except Exception:  # noqa: BLE001
                pass
    tagname = {f.Tag: f for f in feats}
    conv = [f for f in feats if f.FeatureType == "BREP" and f.GetFeatureName().startswith("Convergent Body")]
    ct = {c.Tag for c in conv}
    direct = [f for f in feats if f.Tag not in ct and any(p.Tag in ct for p in f.GetParents())]
    res["conv"] = [c.GetFeatureName() for c in conv]
    rows = []
    for d in direct:
        ch = d.GetChildren()
        rows.append({"name": d.GetFeatureName(), "type": d.FeatureType, "ts": d.Timestamp, "group": grp.get(d.Tag),
                     "bodies": [[b.Tag, b.IsSolidBody, len(b.GetFaces())] for b in (d.GetBodies() or [])],
                     "parents": [p.GetFeatureName() for p in d.GetParents()],
                     "children": [[c.GetFeatureName(), c.FeatureType, grp.get(c.Tag)] for c in ch]})
    res["scan_direct"] = rows
    # full descendant closure, ordered, with groups
    seen, stack = set(), list(direct)
    while stack:
        f = stack.pop()
        if f.Tag in seen:
            continue
        seen.add(f.Tag)
        stack.extend(f.GetChildren())
    res["scan_closure"] = [[f.Timestamp, f.GetFeatureName(), f.FeatureType, grp.get(f.Tag)] for f in feats if f.Tag in seen]
    res["groups"] = sorted(set(grp.values()))
    res["errors_rechecked"] = {k: [str(x) for x in v] for k, v in nxh.feature_errors(part).items()}
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
