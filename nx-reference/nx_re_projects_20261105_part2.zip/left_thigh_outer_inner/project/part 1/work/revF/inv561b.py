"""Offset Region(561): which face was it meant to move? (read-only, never saved)
Roll to its parent Offset Region(531), read the face tag 561 stores (36982 at load) and 531's faces, then step
forward feature by feature to find the one that consumes that face, and at Extrude(560) list the faces that sit
where it was (candidates for re-pointing). args: prt out_json"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

SRC, OUT = sys.argv[1], sys.argv[2]
res = {}


def dump():
    nxh.write_json(OUT, res)


def finfo(part, f):
    d = {"tag": f.Tag}
    try:
        t, pt, dr, rad = nxh.face_data(f)
        d.update({"type": t, "pt": [round(v, 4) for v in pt], "dir": [round(v, 5) for v in dr], "r": round(rad, 4),
                  "bbox": [round(v, 3) for v in nxh.bbox(f)], "edges": len(f.GetEdges())})
        try:
            d["samples"] = [[round(v, 4) for v in p] for p in nxh.face_samples(f, n=3)][:9]
        except Exception as e:  # noqa: BLE001
            d["samples_err"] = str(e)[:80]
        try:
            d["feats"] = [NXOpen.TaggedObjectManager.GetTaggedObject(x).GetFeatureName() for x in nxh.UFS.Modeling.AskFaceFeats(f.Tag)]
        except Exception as e:  # noqa: BLE001
            d["feats_err"] = str(e)[:80]
    except Exception as e:  # noqa: BLE001
        d["dead"] = str(e)[:100]
    return d


def rules_of(part, feat):
    out = {}
    b = part.Features.CreateAdmOffsetRegionBuilder(feat)
    try:
        fc = b.FaceToOffset.FaceCollector
        out["distance"] = b.Distance.RightHandSide
        out["reverse"] = bool(b.ReverseDirection)
        out["rule_types"] = []
        for ru in fc.GetRules():
            try:
                out["rule_types"].append(str(ru.Type))
            except Exception as e:  # noqa: BLE001
                out["rule_types"].append("? " + str(e)[:60])
        out["faces"] = [finfo(part, f) for f in fc.GetObjects()]
        out["face_objs"] = list(fc.GetObjects())
    finally:
        b.Destroy()
    return out


try:
    part = nxh.open_part(SRC)
    nxh.S.UpdateManager.SetDefaultUpdateFailureAction(NXOpen.Update.FailureOption.AcceptAll)
    fl = list(part.Features.GetFeatures())
    fs = {f.GetFeatureName(): f for f in fl}
    f561, f531 = fs["Offset Region(561)"], fs["Offset Region(531)"]
    r = rules_of(part, f561)
    tgt = r.pop("face_objs")
    res["561_at_load"] = r
    r = rules_of(part, f531); r.pop("face_objs")
    res["531_at_load"] = r
    dump()
    f531.MakeCurrentFeature()
    nxh.update("to 531")
    res["at_531_face_561"] = [finfo(part, f) for f in tgt]
    r = rules_of(part, f561)
    r.pop("face_objs")
    res["561_rules_at_531"] = r
    dump()
    alive = [not finfo(part, f).get("dead") for f in tgt]
    res["alive_at_531"] = alive
    last_info = res["at_531_face_561"]
    i0 = fl.index(f531)
    killer = None
    for f in fl[i0 + 1:]:
        if f.GetFeatureName() == "Offset Region(561)":
            break
        if nxh.is_internal(f):
            continue
        f.MakeCurrentFeature()
        nxh.update("step")
        info = [finfo(part, x) for x in tgt]
        if any(i.get("dead") for i in info) and killer is None:
            killer = f.GetFeatureName()
            res["killed_by"] = {"feature": killer, "type": f.FeatureType, "name": getattr(f, "Name", ""),
                                "parents": [p.GetFeatureName() for p in f.GetParents()], "face_before": last_info}
            dump()
        if killer is None:
            last_info = info
    res["face_last_alive"] = last_info
    # at Extrude(560): faces where the target face was
    fs["Extrude(560)"].MakeCurrentFeature()
    nxh.update("to 560")
    body = max([b for b in part.Bodies if b.IsSolidBody and not getattr(b, "IsConvergentBody", False)], key=lambda b: nxh.volume(part, b))
    cands = []
    pts = [p for i in last_info for p in i.get("samples", [])]
    for fc in body.GetFaces():
        try:
            ds = [abs(nxh.dist_to(part, fc, p)) for p in pts]
        except Exception:  # noqa: BLE001
            continue
        if ds and min(ds) < 0.5:
            d = finfo(part, fc)
            d["dist_to_samples"] = [round(x, 4) for x in ds]
            cands.append(d)
    res["candidates_at_560"] = sorted(cands, key=lambda d: sum(d["dist_to_samples"]))[:10]
    res["done"] = True
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
dump()
