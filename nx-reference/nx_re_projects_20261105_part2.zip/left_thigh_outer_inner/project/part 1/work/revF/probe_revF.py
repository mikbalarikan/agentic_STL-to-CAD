"""Read-only probe of finalized parts (Rev C delivered vs Rev F): one main solid, volume, exact bbox, examine,
feature count + errors, cylinder census by radius, and the values the drawing script looks up.
args: out_json prt [prt ...]   (parts are opened, never saved)"""
import os, sys, json, traceback, math
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

OUT, PRTS = sys.argv[1], sys.argv[2:]
res = {}


def cyl_rows(body):
    rows = []
    for f in body.GetFaces():
        t, pt, d, rad = nxh.face_data(f)
        if t != 16:  # UF cylinder
            continue
        bb = nxh.bbox(f)
        rows.append({"r": round(abs(rad), 4), "pt": [round(v, 3) for v in pt], "dir": [round(v, 4) for v in d],
                     "bb": [round(v, 3) for v in bb]})
    return rows


def axis_dist(row, p, d):
    """distance of the cylinder axis from axis (p, d) (both assumed parallel)"""
    q = row["pt"]
    w = [q[i] - p[i] for i in range(3)]
    dd = sum(w[i] * d[i] for i in range(3))
    return math.sqrt(max(0.0, sum(x * x for x in w) - dd * dd))


def parallel(row, d):
    return abs(abs(sum(row["dir"][i] * d[i] for i in range(3))) - 1.0) < 1e-4


try:
    for prt in PRTS:
        r = {}
        res[os.path.basename(os.path.dirname(os.path.dirname(prt))) + "/" + os.path.basename(prt)] = r
        try:
            part = nxh.open_part(prt)
            sol = [b for b in part.Bodies if b.IsSolidBody]
            r["solids"] = len(sol)
            r["sheets"] = len([b for b in part.Bodies if not b.IsSolidBody])
            body = max(sol, key=lambda b: nxh.volume(part, b))
            r["body_name"] = body.Name
            r["volume"] = nxh.volume(part, body)
            r["mass_g_al6061"] = r["volume"] * 2.70e-3
            mn, dirs, dist = nxh.UFS.ModlGeneral.AskBoundingBoxExact(body.Tag, 0)
            mn = list(mn); dist = list(dist)
            r["bbox_exact_raw"] = {"min": mn, "dirs": [list(x) for x in dirs] if hasattr(dirs[0], "__len__") else list(dirs), "dist": dist}
            r["bbox_exact"] = [round(v, 4) for v in mn + [mn[i] + dist[i] for i in range(3)]]
            r["body_ok"] = nxh.body_ok(part, body)
            r["examine"] = nxh.examine_geometry(part, body)
            feats = list(part.Features.GetFeatures())
            r["features"] = len(feats)
            r["feature_errors"] = {k: [str(x) for x in v] for k, v in nxh.feature_errors(part, recheck=False).items()}
            try:
                r["revision_attr"] = part.GetUserAttributeAsString("REVISION", NXOpen.NXObject.AttributeType.String, -1)
            except Exception as e:  # noqa: BLE001
                r["revision_attr"] = "err " + str(e)
            r["groups"] = [f.GetFeatureName() for f in feats if f.FeatureType == "FSET"]
            r["conv_left"] = [f.GetFeatureName() for f in feats if f.GetFeatureName().startswith("Convergent")]
            r["face_census"] = nxh.face_census(body)
            cyl = cyl_rows(body)
            cen = {}
            for c in cyl:
                k = "%.3f" % c["r"]
                cen[k] = cen.get(k, 0) + 1
            r["cyl_census"] = dict(sorted(cen.items(), key=lambda kv: float(kv[0])))
            Z = (0.0, 0.0, 1.0)
            O = (0.0, 0.0, 0.0)
            probes = {}

            def knee(rad, tol=0.006):
                rows = [c for c in cyl if abs(c["r"] - rad) < tol and parallel(c, Z) and axis_dist(c, O, Z) < 0.01]
                return {"n": len(rows), "z": [min([c["bb"][2] for c in rows], default=None), max([c["bb"][5] for c in rows], default=None)],
                        "r": sorted(set(c["r"] for c in rows))}
            for nm, rad in (("knee_OD_R68.25", 68.25), ("knee_OD_R67.85", 67.85), ("bore_R55", 55.0), ("bore_R48", 48.0),
                            ("bore_R46.05", 46.05), ("recess_R62.75", 62.75)):
                probes[nm] = knee(rad)
            # slots S1 / S2: D4.30 vertical holes at (x, 271.70)
            for nm, x in (("S1", 27.03), ("S2", 49.02)):
                rows = [c for c in cyl if abs(c["r"] - 2.15) < 0.01 and parallel(c, Z) and axis_dist(c, (x, 271.70, 0.0), Z) < 0.02]
                fl = [f for f in body.GetFaces() if nxh.face_data(f)[0] == 22 and abs(abs(nxh.face_data(f)[2][2]) - 1) < 1e-6
                      and abs(nxh.dist_to(part, f, (x, 271.70, 79.20))) < 1e-3]
                probes[nm] = {"n_cyl": len(rows), "d": [round(2 * c["r"], 4) for c in rows],
                              "axis": [c["pt"][:2] for c in rows],
                              "z": [min([c["bb"][2] for c in rows], default=None), max([c["bb"][5] for c in rows], default=None)],
                              "floor_face_at_z79.20": len(fl)}
            # hip ring cylinders along Y (HD82 r40.99, HD85.96 r42.98, HD97.54 r48.77)
            Y = (0.0, 1.0, 0.0)
            hip = {}
            for nm, rad in (("HD82", 40.99), ("HD85_96", 42.98), ("HD97_54", 48.77)):
                rows = [c for c in cyl if abs(c["r"] - rad) < 0.012 and parallel(c, Y)]
                hip[nm] = {"n": len(rows), "r": sorted(set(c["r"] for c in rows)),
                           "axis_xz": sorted(set((c["pt"][0], c["pt"][2]) for c in rows))[:3],
                           "y": [min([c["bb"][1] for c in rows], default=None), max([c["bb"][4] for c in rows], default=None)]}
            probes["hip"] = hip
            probes["overall_length_Y"] = round(r["bbox_exact"][4] - r["bbox_exact"][1], 4)
            # Rev C details that are separate solids in the Rev F master: signed distance of a point inside each
            # to the main solid (negative = inside the main solid = present)
            inside = {}
            for nm, xyz in (("K1_clip_head", (94.37, 206.92, 4.85)), ("T1_tab", (-34.78, 238.72, 11.1)),
                            ("T2_tab", (-19.23, 186.7, 3.0)), ("user_pin_-56.7_19.6", (-56.73, 19.57, 11.0)),
                            ("slot_S1_air", (27.03, 271.70, 82.0)), ("slot_S1_floor_below", (27.03, 271.70, 79.0)),
                            ("slot_S2_air", (49.02, 271.70, 82.0)), ("slot_S2_floor_below", (49.02, 271.70, 79.0))):
                pt = part.Points.CreatePoint(nxh.P(*xyz))
                try:
                    inside[nm] = round(nxh.min_dist(pt, body), 4)
                finally:
                    nxh.S.UpdateManager.AddToDeleteList(pt)
            probes["point_signed_dist_to_main"] = inside
            r["probes"] = probes
            r["cyl_rows"] = cyl
            nxh.close_all()
        except Exception:  # noqa: BLE001
            r["error"] = traceback.format_exc()
            try:
                nxh.close_all()
            except Exception:  # noqa: BLE001
                pass
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
