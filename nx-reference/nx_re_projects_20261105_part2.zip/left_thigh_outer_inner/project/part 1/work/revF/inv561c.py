"""Faces of the main solid at the saved state (current Extrude(560)) that Offset Region(531) made or touched -
the faces Offset Region(561) (parent 531, 0.3 reversed) can have been picked on. read-only. args: prt out_json"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

SRC, OUT = sys.argv[1], sys.argv[2]
res = {}
try:
    part = nxh.open_part(SRC)
    body = max([b for b in part.Bodies if b.IsSolidBody and not getattr(b, "IsConvergentBody", False)], key=lambda b: nxh.volume(part, b))
    rows = []
    for fc in body.GetFaces():
        try:
            feats = [NXOpen.TaggedObjectManager.GetTaggedObject(x).GetFeatureName() for x in nxh.UFS.Modeling.AskFaceFeats(fc.Tag)]
        except Exception:  # noqa: BLE001
            continue
        if not any(n in ("Offset Region(531)", "Offset Region(532)", "Offset Region(533)") for n in feats):
            continue
        t, pt, dr, rad = nxh.face_data(fc)
        rows.append({"tag": fc.Tag, "type": t, "pt": [round(v, 3) for v in pt], "dir": [round(v, 4) for v in dr], "r": round(rad, 3),
                     "bbox": [round(v, 3) for v in nxh.bbox(fc)], "edges": len(fc.GetEdges()), "feats": feats[:8]})
    res["faces_531_533"] = rows
    for nm in ("Offset Region(531)", "Offset Region(532)", "Offset Region(533)"):
        f = [x for x in part.Features.GetFeatures() if x.GetFeatureName() == nm][0]
        b = part.Features.CreateAdmOffsetRegionBuilder(f)
        try:
            res[nm] = {"distance": b.Distance.RightHandSide, "reverse": bool(b.ReverseDirection),
                       "faces": [[o.Tag, [round(v, 3) for v in nxh.bbox(o)]] if not isinstance(o, type(None)) else None for o in b.FaceToOffset.FaceCollector.GetObjects()],
                       "parents": [p.GetFeatureName() for p in f.GetParents()], "children": [c.GetFeatureName() for c in f.GetChildren()]}
        except Exception as e:  # noqa: BLE001
            res[nm] = "err " + str(e)[:200]
        finally:
            b.Destroy()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
