# LT-OUT-001 Rev F (Left Thigh, Outer shell): status

Built 2026-11-02. Final draft frozen by the user. Nothing sent to the client.

- Master: `Deviation_Check/LT-OUT-001_RevC_Left_Thigh_Outer_vs_SCAN - Copy_RIBS5.prt` (user's 01:41 save), frozen copy `work/revF/master_RIBS5_0141.prt`.
- Finalize: `nx/finalize_revF.py` (lean mode; full-check version `nx/finalize_revF_full.py`) -> `deliver_RevF/CAD`. History kept (621 features):
  scan Fit Surfaces 310/315/318 replaced by frozen copies, scan deleted (4000 probes match); user's rolled-back Offset Regions applied
  (561 re-pointed to the 531 strip top -> Z 35.81, user: "keep offset face"; 562 -1413; 563 -703 mm3); F1_BOSS top 1.0 -> 2.5 so the K1 clip
  head unites (user choice); pin + D tabs united. 378 954.71 mm3, 1.023 kg, 1 solid, examine 0. Details: `work/revF/finalize_result.txt`.
  Do not Update All: Cylinder(218) (inactive in the user's tree) breaks most of the tree when regenerated.
- STEP: AP214 +0.013 %, AP242 +0.0085 %, bbox exact. Exact bbox X -68.05..118.85, Y -68.05..287.40, Z -40.75..85.20; L 355.45, knee OD R68.05.
- Drawings: `nx/dwg_revF.py` (work/dwgF_final), 5 sheets A1, 24 dims read back. Rev block rows A + F only.
- QA: `work/qaF` -> `deliver_RevF/QA` PDF + 7 maps. Whole part 89.0 % within 0.5 (Rev A 89.2, Rev C 91.1); ribs A/B/G1 sit ~1 mm off the scan,
  F2 pads stop at Z 29.3 (scan to ~35) - user's design, reported, not changed.
- Renders: Blender, `work/renderF/run_final.sh`, 12 views.
- Package: `an/f7_package.py` -> `LT-OUT-001_RevF_Left_Thigh_Outer.zip` (60.3 MB, 43 entries, testzip OK, no README / md / txt / json / log).
- Mates with inner LT-INN-001 Rev E fit (`part 2 - Inner/deliver_RevE_fit`) in assembly LT-ASM-001 Rev E (`part 4 - Assembly/deliver_RevE`),
  final gate 0 real interference (`part 4 - Assembly/work/revE/final_gate.txt`).
