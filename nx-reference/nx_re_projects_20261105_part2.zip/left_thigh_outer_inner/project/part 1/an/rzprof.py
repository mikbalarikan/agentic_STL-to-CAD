"""Revolve profile density image: (r, axial) of scan vertices about an axis, within an angular range.
usage: rzprof.py out.png knee|hip r0 r1 a0 a1 [phi0 phi1]"""
import sys, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load, W
a = sys.argv[1:]
out, which = a[0], a[1]; r0, r1, a0, a1 = map(float, a[2:6])
ph = [float(a[6]), float(a[7])] if len(a) > 7 else None
v, f = load()
if which == "knee":
    r = np.hypot(v[:, 0], v[:, 1]); ax_ = v[:, 2]; phi = np.degrees(np.arctan2(v[:, 1], v[:, 0]))
else:
    X, Z = 37.97, 35.18
    r = np.hypot(v[:, 0] - X, v[:, 2] - Z); ax_ = v[:, 1]; phi = np.degrees(np.arctan2(v[:, 2] - Z, v[:, 0] - X))
m = (r > r0) & (r < r1) & (ax_ > a0) & (ax_ < a1)
if ph: m &= (phi > ph[0]) & (phi < ph[1])
H, xe, ye = np.histogram2d(r[m], ax_[m], bins=[int((r1 - r0) / 0.05), int((a1 - a0) / 0.05)], range=[[r0, r1], [a0, a1]])
fig, axp = plt.subplots(figsize=(16, 16 * (a1 - a0) / (r1 - r0)))
axp.imshow(np.log1p(H.T), origin="lower", extent=[r0, r1, a0, a1], cmap="gray_r", aspect="equal")
axp.set_xticks(np.arange(np.ceil(r0), r1, 1)); axp.set_yticks(np.arange(np.ceil(a0), a1, 1)); axp.grid(True, lw=0.3, color="r", alpha=0.4)
plt.setp(axp.get_xticklabels(), rotation=90, fontsize=6); plt.setp(axp.get_yticklabels(), fontsize=6)
axp.set_xlabel("r"); axp.set_ylabel("axial"); fig.tight_layout(); fig.savefig(out, dpi=90)
