"""Inner (cavity) surface r_in(y, th) about the same centre line as the skin.
Data: for each ray the crossing right inside the outermost one, if the wall R1-R2 is 1.2..4.5 mm.
Same B-spline LSQ + penalty; hidden zones (knee hub, hip plate band) filled from neighbours / frozen.
Writes work/inner_fit.npz and work/inner_sections.json."""
import sys, json
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.interpolate import BSpline, make_lsq_spline
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, section, W

s = np.load(W + r"\skin_fit.npz")
pc, ZC = s["pc"], float(s["ZC"])
xcf = lambda y: np.polyval(pc, y)
KY, KT, LAM = 8.0, 4.0, 3e-3
v, f = load()
ys = np.arange(-72.0, 289.0, 1.0)
th = np.radians(np.arange(-182.0, 2.01, 0.5))
rows = []
for y in ys:
    sg = section(v, f, 1, y)
    if len(sg) == 0: continue
    seg = sg[:, :, [0, 2]]
    seg = seg[(seg[:, :, 1] < ZC + 1.0).all(1)]
    c = np.array([xcf(y), ZC])
    a = seg[:, 0] - c; b = seg[:, 1] - c; e = b - a
    for t in th:
        d = np.array([np.cos(t), np.sin(t)])
        den = -d[0] * e[:, 1] + d[1] * e[:, 0]
        ok = np.abs(den) > 1e-12; den = np.where(ok, den, 1)
        r = (-a[:, 0] * e[:, 1] + a[:, 1] * e[:, 0]) / den
        u = (d[0] * a[:, 1] - d[1] * a[:, 0]) / den
        m = ok & (u >= 0) & (u <= 1) & (r > 0)
        if m.sum() < 2: continue
        rr = np.sort(r[m])[::-1]
        k2 = np.where(m)[0][np.argsort(r[m])[::-1][1]]
        en = np.array([-e[k2, 1], e[k2, 0]]); en /= np.linalg.norm(en)
        rows.append((y, t, rr[0], rr[1], abs(en @ d)))
D = np.array(rows)
y_, t_, r1, r2, inc = D.T
X1 = xcf(y_) + r1 * np.cos(t_); Z1 = ZC + r1 * np.sin(t_)
X2 = xcf(y_) + r2 * np.cos(t_); Z2 = ZC + r2 * np.sin(t_)
dk = np.hypot(X1, y_); phk = np.degrees(np.arctan2(y_, X1))
wall = r1 - r2
mask = (wall > 1.2) & (wall < 4.5) & (inc > 0.25) & (Z2 < 34.0)
mask &= ~(dk < 69.5)
mask &= ~((dk < 75) & ((phk > 128) | (phk < -41)))
mask &= ~((y_ > 262) & (y_ < 279))          # hip ring plate band (plate is its own feature)
print("rows", len(D), "inner rows", mask.sum())


def knots(lo, hi, h, k=3):
    n = max(1, int(round((hi - lo) / h)))
    return np.r_[[lo] * k, np.linspace(lo, hi, n + 1), [hi] * k]


def fit(m, wts, rr):
    ty = knots(-75.0, 292.0, KY); tt = knots(np.radians(-185.0), np.radians(5.0), np.radians(KT))
    ny, nt = len(ty) - 4, len(tt) - 4
    yy, tth, w = y_[m], t_[m], wts[m]
    By = BSpline.design_matrix(yy, ty, 3).tocsr(); Bt = BSpline.design_matrix(tth, tt, 3).tocsr()
    iy = By.indices.reshape(-1, 4); vy = By.data.reshape(-1, 4)
    it = Bt.indices.reshape(-1, 4); vt = Bt.data.reshape(-1, 4)
    cols = (iy[:, :, None] * nt + it[:, None, :]).reshape(len(yy), 16)
    vals = (vy[:, :, None] * vt[:, None, :]).reshape(len(yy), 16) * w[:, None]
    A = sp.csr_matrix((vals.ravel(), cols.ravel(), np.arange(0, 16 * len(yy) + 1, 16)), shape=(len(yy), ny * nt))
    d2 = lambda n: sp.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n))
    d1 = lambda n: sp.diags([1.0, -1.0], [0, 1], shape=(n - 1, n))
    P = sp.kron(d2(ny), sp.eye(nt)); Q = sp.kron(sp.eye(ny), d2(nt)); X = sp.kron(d1(ny), d1(nt))
    M = (A.T @ A + LAM * len(yy) / (ny * nt) * (P.T @ P + Q.T @ Q + 2 * X.T @ X)).tocsc()
    coef = spl.spsolve(M, A.T @ (rr[m] * w))
    return ty, tt, coef.reshape(ny, nt)


def evalr(ty, tt, C, y, t):
    out = []
    for k in range(0, len(y), 4000):
        By = BSpline.design_matrix(np.clip(y[k:k + 4000], ty[3], ty[-4] - 1e-9), ty, 3)
        Bt = BSpline.design_matrix(np.clip(t[k:k + 4000], tt[3], tt[-4] - 1e-9), tt, 3).toarray()
        out.append(np.einsum("ij,ij->i", By @ C, Bt))
    return np.concatenate(out)


# outer skin r at every row (for hidden-zone guide: inner = outer - 3.05 along the ray)
so = np.load(W + r"\skin_fit.npz")
r_out = evalr(so["ty"], so["tt"], so["C"], y_, t_)
guide = ~mask & (inc > 0.1)
rr = np.where(mask, r2, r_out - 3.05)
wts = np.where(mask, inc, np.where(guide, 0.2, 0.0))
m_all = mask | guide
# robust: 2 passes, drop |res| > 0.25 on data rows
for it in range(2):
    ty, tt, C = fit(m_all, wts, rr)
    res = (rr - evalr(ty, tt, C, y_, t_)) * inc
    bad = mask & (np.abs(res) > 0.25)
    print(f"pass {it}: data rows {mask.sum()}, |res| p50 {np.percentile(abs(res[mask]),50):.3f} p95 {np.percentile(abs(res[mask]),95):.3f} p99 {np.percentile(abs(res[mask]),99):.3f}; dropping {bad.sum()}")
    m_all &= ~bad
np.savez(W + r"\inner_fit.npz", ty=ty, tt=tt, C=C, pc=pc, ZC=ZC, YCL=-1000.0)
fig, ax = plt.subplots(figsize=(26, 10))
mm = mask
sc = ax.scatter(y_[mm], np.degrees(t_[mm]), c=np.clip(res[mm], -0.4, 0.4), s=0.3, cmap="seismic", vmin=-0.4, vmax=0.4)
plt.colorbar(sc); ax.grid(True, lw=0.3); ax.set_title("inner surface residual (data rows)")
fig.tight_layout(); fig.savefig(W + r"\inner_res.png", dpi=70)
# thickness check on the fit
rin = evalr(ty, tt, C, y_, t_)
th_fit = r_out - rin
print("fitted wall thickness on data rows: p5 %.2f p50 %.2f p95 %.2f; min over all rows %.2f" % (
    *np.percentile(th_fit[mask], [5, 50, 95]), th_fit.min()))
