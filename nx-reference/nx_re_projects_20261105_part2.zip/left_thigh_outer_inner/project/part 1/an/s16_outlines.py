"""Plateau outlines per flat level as line/arc loops (frame coords), plus small round holes found in them.
Writes work/plateaus.json and an overlay figure."""
import json
import numpy as np
from scipy import ndimage
import contourpy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W
from arcfit import fit_loop, seg_points

d = np.load(W + r"\hmap2.npz")
H, ext, cell = d["H"], d["ext"], float(d["cell"])
X0, X1, Y0, Y1 = ext
Hn = np.where(np.isinf(H), np.nan, H)
gy, gx = np.gradient(np.nan_to_num(Hn, nan=-100.0), cell)
slope = np.hypot(gx, gy)
LEVELS = [42.25, 41.98, 39.04, 36.07, 33.90, 29.55, 28.39, 27.67, 8.15, 7.49, 4.97, 4.78, 0.0, -5.00, -20.29]
BAND = 5.0
DROP = 0.5


def to_mm(rc):
    return np.c_[X0 + (rc[:, 1] + 0.5) * cell, Y0 + (rc[:, 0] + 0.5) * cell]


def area(P):
    x, y = P[:, 0], P[:, 1]
    return 0.5 * (np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))


out = {"levels": [], "holes": []}
fig, ax = plt.subplots(figsize=(18, 30))
ax.imshow(np.where(np.isnan(Hn), np.nan, Hn), origin="lower", extent=[X0, X1, Y0, Y1], cmap="gray", vmin=-45, vmax=45, alpha=0.6)
for h in LEVELS:
    R0 = (np.abs(Hn - h) < 0.15) & (slope < 0.12)
    R0 = ndimage.binary_opening(R0, iterations=1)
    lab, n = ndimage.label(R0)
    sizes = ndimage.sum(R0, lab, range(1, n + 1)) * cell * cell
    R0 = np.isin(lab, 1 + np.where(sizes >= (0.8 if h > 41 else 3.0))[0])
    if not R0.any():
        continue
    band = ndimage.binary_dilation(R0, iterations=int(BAND / cell))
    inside = band & (np.nan_to_num(Hn, nan=-1e3) >= h - DROP)
    # small holes inside the plateau (bolt holes, boss bores): record and fill
    filled = ndimage.binary_fill_holes(inside)
    hl, hn = ndimage.label(filled & ~inside)
    for k in range(1, hn + 1):
        m = hl == k
        a_mm = m.sum() * cell * cell
        if a_mm > 60:
            continue
        rc = np.argwhere(m); P = to_mm(rc.astype(float))
        cx, cy = P.mean(0); dia = 2 * np.sqrt(a_mm / np.pi)
        out["holes"].append(dict(level=h, x=float(cx), y=float(cy), d_area=float(dia), area=float(a_mm)))
        inside |= m
    G = np.where(inside, 0.5, -0.5)
    # sub-pixel walls: inside the band, use the height field
    core = band & ~np.isnan(Hn)
    G = np.where(core & (Hn < h - DROP), np.clip(Hn - (h - DROP), -0.5, 0.5), G)
    G = np.where(core & (Hn >= h - DROP), np.maximum(G, np.clip(Hn - (h - DROP), -0.5, 0.5)), G)
    G = np.pad(G, 2, constant_values=-0.5)
    loops = []
    for C in contourpy.contour_generator(z=G, line_type='Separate').lines(0.0):
        C = C[:, ::-1]
        P = to_mm(C - 2.0)
        if np.linalg.norm(P[0] - P[-1]) > 1e-6:
            continue
        P = P[:-1]
        A = area(P)
        if abs(A) < 1.5:
            continue
        # smooth along the loop (sigma ~0.35 mm), keep it closed
        Lc = np.r_[0, np.cumsum(np.linalg.norm(np.diff(np.vstack([P, P[:1]]), axis=0), axis=1))]
        sgrid = np.arange(0, Lc[-1], 0.1)
        Pc = np.vstack([P, P[:1]])
        Pu = np.c_[np.interp(sgrid, Lc, Pc[:, 0]), np.interp(sgrid, Lc, Pc[:, 1])]
        Pu = np.c_[ndimage.gaussian_filter1d(Pu[:, 0], 3.5, mode="wrap"), ndimage.gaussian_filter1d(Pu[:, 1], 3.5, mode="wrap")]
        segs = fit_loop(Pu, tol=0.10)
        loops.append(dict(area=float(A), n_seg=len(segs), segs=[
            ([s[0], s[1].tolist(), s[2].tolist()] if s[0] == "L" else [s[0], s[1].tolist(), s[2].tolist(), s[3].tolist(), float(s[4]), bool(s[5])])
            for s in segs]))
        Q = np.vstack([seg_points(s) for s in segs])
        ax.plot(Q[:, 0], Q[:, 1], "-", lw=0.6)
    out["levels"].append(dict(h=h, loops=loops))
    print(f"level {h:7.2f}: {len(loops)} loops, segs {[l['n_seg'] for l in loops]}")
json.dump(out, open(W + r"\plateaus.json", "w"), indent=0)
print("holes found", len(out["holes"]))
ax.set_xticks(np.arange(-100, 126, 10)); ax.set_yticks(np.arange(-70, 292, 10)); ax.grid(True, lw=0.3)
ax.set_xlim(X0, X1); ax.set_ylim(Y0, Y1); ax.set_aspect("equal")
fig.tight_layout(); fig.savefig(W + r"\plateaus.png", dpi=70)
