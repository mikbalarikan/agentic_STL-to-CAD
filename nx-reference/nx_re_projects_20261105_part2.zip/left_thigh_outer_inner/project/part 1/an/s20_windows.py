"""Side-wall windows: coverage of the fitted outer skin by scan points, in (y, z) for each side."""
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from scipy.interpolate import BSpline
from common import load, W
v, f = load()
tree = cKDTree(v)
s = np.load(W + r"\skin_fit.npz"); ty, tt, C, pc, ZC = s["ty"], s["tt"], s["C"], s["pc"], float(s["ZC"])
ys = np.arange(100, 288, 0.5); ths = np.radians(np.arange(-182, 2, 0.5))
Y, T = np.meshgrid(ys, ths, indexing="ij")
Ry = BSpline(ty, C, 3)(ys)
R = np.array([BSpline(tt, Ry[i], 3)(ths) for i in range(len(ys))])
X = np.polyval(pc, Y) + R * np.cos(T); Z = ZC + R * np.sin(T)
d, _ = tree.query(np.c_[X.ravel(), Y.ravel(), Z.ravel()], distance_upper_bound=3.0)
d = d.reshape(X.shape)
cov = d < 0.6
np.savez(W + r"\skin_cov.npz", ys=ys, ths=ths, cov=cov, X=X, Z=Z)
fig, ax = plt.subplots(1, 2, figsize=(24, 9))
for k, (sel, nm) in enumerate(((T < np.radians(-120), "left (-x)"), (T > np.radians(-60), "right (+x)"))):
    m = sel & ~cov & (Z < 34.5)
    ax[k].scatter(Y[sel & cov & (Z < 34.5)], Z[sel & cov & (Z < 34.5)], s=0.3, c="0.7")
    ax[k].scatter(Y[m], Z[m], s=1, c="r")
    ax[k].set_title(nm + ": red = fitted skin with no scan points (window)"); ax[k].grid(True); ax[k].set_xticks(np.arange(100, 290, 5)); ax[k].set_yticks(np.arange(-40, 36, 2))
    ax[k].set_aspect("equal")
fig.tight_layout(); fig.savefig(W + r"\windows.png", dpi=70)
