"""Outer-skin model r(y, th) about a centre line (xc(y), ZC) in the final frame.
Step 1: polar crossings of y-sections (outermost), masked to skin-only points.
Step 2: tensor cubic B-spline least squares with 2nd-difference penalty.
Writes work/skin_fit.npz (knots, coefs, xc poly, ZC) and residual figures."""
import sys, json
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.interpolate import BSpline
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, section, W

ZC = 36.0
STEP_Y = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
KY = float(sys.argv[2]) if len(sys.argv) > 2 else 12.0     # knot spacing in y (mm)
KT = float(sys.argv[3]) if len(sys.argv) > 3 else 6.0      # knot spacing in theta (deg)
LAM = float(sys.argv[4]) if len(sys.argv) > 4 else 1e-2
v, f = load()

# ---------------- centre line
mids = []
for y in np.arange(-60, 287, 5.0):
    s = section(v, f, 1, y).reshape(-1, 3)
    s = s[s[:, 2] < 34]
    if len(s) < 20: continue
    mids.append((y, 0.5 * (s[:, 0].min() + s[:, 0].max())))
mids = np.array(mids)
pc = np.polyfit(mids[:, 0], mids[:, 1], 3)
YCL = -1000.0
xc = lambda y: np.polyval(pc, np.maximum(y, YCL))
print("centre poly", pc, "range", xc(np.array([-70, 0, 100, 200, 288])))

# ---------------- polar data
ys = np.arange(-72.0, 289.0, STEP_Y)
th = np.radians(np.arange(-182.0, 2.01, 0.5))
rows = []
for y in ys:
    s = section(v, f, 1, y)
    if len(s) == 0: continue
    seg = s[:, :, [0, 2]]
    seg = seg[(seg[:, :, 1] < ZC + 1.0).all(1)]
    c = np.array([xc(y), ZC])
    a = seg[:, 0] - c; b = seg[:, 1] - c; e = b - a
    for t in th:
        d = np.array([np.cos(t), np.sin(t)])
        den = -d[0] * e[:, 1] + d[1] * e[:, 0]
        ok = np.abs(den) > 1e-12
        den = np.where(ok, den, 1)
        r = (-a[:, 0] * e[:, 1] + a[:, 1] * e[:, 0]) / den
        u = (d[0] * a[:, 1] - d[1] * a[:, 0]) / den
        m = ok & (u >= 0) & (u <= 1) & (r > 0)
        if not m.any(): continue
        k = np.argmax(np.where(m, r, -1))
        # incidence: angle between ray and segment normal
        en = np.array([-e[k, 1], e[k, 0]]); en /= np.linalg.norm(en)
        rows.append((y, t, r[k], abs(en @ d)))
D = np.array(rows)
y_, t_, r_, inc = D.T
X = xc(y_) + r_ * np.cos(t_); Z = ZC + r_ * np.sin(t_)
# ---------------- mask
dk = np.hypot(X, y_)                          # distance to knee axis (x=0,y=0)
phk = np.degrees(np.arctan2(y_, X))
mask = np.ones(len(D), bool)
mask &= ~(dk < 69.5)                           # hub cylinder and its floor
mask &= ~((dk < 75) & ((phk > 128) | (phk < -41)))
mask &= Z < ZC + 0.2
mask &= inc > 0.25                             # grazing rays
mask &= ~(Z > 34.0)                            # rim top faces / cut edges
print("rows", len(D), "skin rows", mask.sum())
np.savez(W + r"\skin_data.npz", D=D, mask=mask, pc=pc, ZC=ZC, YCL=YCL)
if "data" in sys.argv: sys.exit(0)

# ---------------- B-spline basis
def knots(lo, hi, h, k=3):
    n = max(1, int(round((hi - lo) / h)))
    inner = np.linspace(lo, hi, n + 1)
    return np.r_[[lo] * k, inner, [hi] * k]

ty = knots(-75.0, 292.0, KY)
tt = knots(np.radians(-185.0), np.radians(5.0), np.radians(KT))
ny, nt = len(ty) - 4, len(tt) - 4

def basis(t, x):
    return BSpline.design_matrix(np.clip(x, t[3], t[-4] - 1e-9), t, 3)

yy, tth, rr = y_[mask], t_[mask], r_[mask]
w = inc[mask]  # radial residual -> normal residual ~ dr * inc
By = basis(ty, yy).tocsr(); Bt = basis(tt, tth).tocsr()
# row-wise Kronecker
rowsA = []
A = sp.csr_matrix((len(yy), ny * nt))
Byc = By.tocoo(); Btc = Bt.tocoo()
# build via dense small per-row nonzeros: each row has 4 nonzero in each
iy = By.indices.reshape(-1, 4); vy = By.data.reshape(-1, 4)
it = Bt.indices.reshape(-1, 4); vt = Bt.data.reshape(-1, 4)
cols = (iy[:, :, None] * nt + it[:, None, :]).reshape(len(yy), 16)
vals = (vy[:, :, None] * vt[:, None, :]).reshape(len(yy), 16) * w[:, None]
A = sp.csr_matrix((vals.ravel(), cols.ravel(), np.arange(0, 16 * len(yy) + 1, 16)), shape=(len(yy), ny * nt))
b = rr * w
# penalty: second differences along both directions
def d2(n):
    return sp.diags([1, -2, 1], [0, 1, 2], shape=(n - 2, n))
P1 = sp.kron(d2(ny), sp.eye(nt)); P2 = sp.kron(sp.eye(ny), d2(nt))
Pm = sp.kron(sp.diags([1, -1], [0, 1], shape=(ny - 1, ny)), sp.diags([1, -1], [0, 1], shape=(nt - 1, nt)))
M = (A.T @ A + LAM * len(yy) / (ny * nt) * (P1.T @ P1 + P2.T @ P2 + 2 * Pm.T @ Pm)).tocsc()
coef = spl.spsolve(M, A.T @ b)
C = coef.reshape(ny, nt)
fit = (A @ coef) / w
res = rr - fit
nres = res * w
print(f"KY {KY} KT {KT} lam {LAM}: coefs {ny}x{nt}; normal residual rms {np.sqrt(np.mean(nres**2)):.3f} p50 {np.percentile(abs(nres),50):.3f} p95 {np.percentile(abs(nres),95):.3f} p99 {np.percentile(abs(nres),99):.3f}")
np.savez(W + r"\skin_fit.npz", ty=ty, tt=tt, C=C, pc=pc, ZC=ZC, KY=KY, KT=KT, LAM=LAM)

# ---------------- figures: residual map
fig, ax = plt.subplots(1, 2, figsize=(26, 10))
sc = ax[0].scatter(yy, np.degrees(tth), c=np.clip(nres, -0.6, 0.6), s=0.3, cmap="seismic", vmin=-0.6, vmax=0.6)
plt.colorbar(sc, ax=ax[0]); ax[0].set_title("normal residual scan - fit (mm), + = scan outside")
ax[0].set_xlabel("y"); ax[0].set_ylabel("theta"); ax[0].grid(True, lw=0.3)
# fitted r over full domain + data coverage
Y, T = np.meshgrid(np.linspace(-72, 288, 361), np.radians(np.linspace(-182, 2, 185)), indexing="ij")
Ry = BSpline(ty, C, 3)(np.clip(Y[:, 0], ty[3], ty[-4]))  # (361, nt)
Rf = np.array([BSpline(tt, Ry[i], 3)(T[i]) for i in range(len(Ry))])
im = ax[1].imshow(Rf.T, origin="lower", aspect="auto", extent=[-72, 288, -182, 2], cmap="viridis")
plt.colorbar(im, ax=ax[1]); ax[1].plot(yy[::50], np.degrees(tth[::50]), "w,", alpha=0.3); ax[1].set_title("fitted r")
fig.tight_layout(); fig.savefig(W + rf"\skin_res_{int(KY)}_{int(KT)}.png", dpi=70)
