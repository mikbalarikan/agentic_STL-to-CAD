﻿"""Rev B prototype check: tessellate a Rev B outer STEP, plot the slot sections against the outer scan and the
inner bump build, and measure the bump clearance (inner bump surface samples -> signed distance to the outer).
usage: b4_protochk.py outer_revB.step inner_bumps.stl tag -> work/revB/chk_<tag>_*.png, chk_<tag>.json"""
import os, sys, json
import numpy as np, trimesh, open3d as o3d
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.StlAPI import StlAPI_Writer

P1 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1"
OUT = os.path.join(P1, "work", "revB")
step, inner_stl, tag = sys.argv[1], sys.argv[2], sys.argv[3]
stl = os.path.join(OUT, f"chk_{tag}_outer.stl")
if step.lower().endswith((".step", ".stp")):
    r = STEPControl_Reader(); r.ReadFile(step); r.TransferRoots(); s = r.OneShape()
    BRepMesh_IncrementalMesh(s, 0.01, False, 0.1, True)
    w = StlAPI_Writer(); w.Write(s, stl)
else:
    stl = step
cad = trimesh.load(stl)
d = np.load(os.path.join(OUT, "scan_crop.npz")); scan = trimesh.Trimesh(d["v"], d["f"], process=False)
inn = trimesh.load(inner_stl)
M = [("outer scan", scan, "tab:blue", 1.4), (f"outer {tag}", cad, "k", 0.8), ("inner", inn, "tab:green", 0.8)]


def sec(ax, normal, origin, dims, lim):
    for nm, m, c, lw in M:
        s = trimesh.intersections.mesh_plane(m, normal, origin)[:, :, dims]
        k = ((s[..., 0] > lim[0]) & (s[..., 0] < lim[1]) & (s[..., 1] > lim[2]) & (s[..., 1] < lim[3])).any(1)
        ax.add_collection(LineCollection(s[k], colors=c, lw=lw, label=nm))
    ax.set_xlim(lim[0], lim[1]); ax.set_ylim(lim[2], lim[3]); ax.set_aspect("equal"); ax.grid(lw=0.3)


fig, axs = plt.subplots(3, 4, figsize=(24, 15))
for j, cx in enumerate((27.03, 49.02)):
    for i, z in enumerate((84.5, 82.0, 80.0)):
        ax = axs[i, 2 * j]; sec(ax, [0, 0, 1], [0, 0, z], [0, 1], (cx - 6, cx + 6, 265, 278)); ax.set_title(f"z = {z} (x, y)")
    ax = axs[0, 2 * j + 1]; sec(ax, [1, 0, 0], [cx, 0, 0], [1, 2], (264, 279, 74, 87)); ax.set_title(f"x = {cx} (y, z)")
    ax = axs[1, 2 * j + 1]; sec(ax, [0, 1, 0], [0, 271.7, 0], [0, 2], (cx - 7, cx + 7, 74, 87)); ax.set_title("y = 271.7 (x, z)")
    ax = axs[2, 2 * j + 1]; sec(ax, [0, 1, 0], [0, 273.2, 0], [0, 2], (cx - 7, cx + 7, 74, 87)); ax.set_title("y = 273.2 (x, z)")
axs[0, 0].legend(fontsize=7)
fig.tight_layout(); fig.savefig(os.path.join(OUT, f"chk_{tag}_sec.png"), dpi=70)

# bump clearance: inner surface samples near the bumps, signed distance to the outer (- = inside the outer)
mo = o3d.io.read_triangle_mesh(stl); mo.remove_duplicated_vertices()
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mo))
mi = o3d.io.read_triangle_mesh(inner_stl)
pts = np.asarray(mi.sample_points_uniformly(int(os.environ.get("NSAMP", "3000000"))).points)
res = {}
for key, (cx, cy) in {"x27": (27.03, 271.70), "x49": (49.02, 271.69)}.items():
    p = pts[(np.hypot(pts[:, 0] - cx, pts[:, 1] - cy) < 3.0) & (pts[:, 2] < 85.25) & (pts[:, 2] > 78)].astype(np.float32)
    sd = sc.compute_signed_distance(o3d.core.Tensor(p)).numpy()
    side = (p[:, 2] > 79.6)
    res[key] = dict(n=int(len(p)), min_signed=round(float(sd.min()), 4), inside=int((sd < -1e-3).sum()),
                    min_side=round(float(sd[side].min()), 4), min_bottom=round(float(sd[~side].min()), 4) if (~side).any() else None)
print(res)
json.dump(res, open(os.path.join(OUT, f"chk_{tag}.json"), "w"), indent=1)
