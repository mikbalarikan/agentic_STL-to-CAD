"""Profile density (r, z) about a vertical axis at (cx, cy). usage: rzloc.py out cx cy rmax z0 z1 [phi0 phi1]"""
import sys, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import load
a = sys.argv[1:]; out = a[0]; cx, cy, rmax, z0, z1 = map(float, a[1:6])
ph = (float(a[6]), float(a[7])) if len(a) > 7 else None
v, f = load()
r = np.hypot(v[:, 0] - cx, v[:, 1] - cy); m = (r < rmax) & (v[:, 2] > z0) & (v[:, 2] < z1)
if ph:
    p = np.degrees(np.arctan2(v[:, 1] - cy, v[:, 0] - cx)); m &= (p > ph[0]) & (p < ph[1])
H, xe, ye = np.histogram2d(r[m], v[m, 2], bins=[int(rmax / 0.05), int((z1 - z0) / 0.05)], range=[[0, rmax], [z0, z1]])
fig, ax = plt.subplots(figsize=(10, 10 * (z1 - z0) / rmax))
ax.imshow(np.log1p(H.T), origin="lower", extent=[0, rmax, z0, z1], cmap="gray_r", aspect="equal")
ax.set_xticks(np.arange(0, rmax, 1)); ax.set_yticks(np.arange(np.ceil(z0), z1, 1)); ax.grid(True, lw=0.3, color="r", alpha=0.4)
plt.setp(ax.get_yticklabels(), fontsize=6); fig.tight_layout(); fig.savefig(out, dpi=80)
