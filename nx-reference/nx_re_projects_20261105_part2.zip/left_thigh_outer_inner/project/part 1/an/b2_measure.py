"""Rev B: measure the two hip-end locating holes on the OUTER scan and the matching bumps on the INNER scan
(inner scan in the LT-OUT-001 frame, lifted +0.12 as in the inner QA) and in the inner M13 build.
Circle fits in z bands -> work/revB/measure.json"""
import os, sys, json
import numpy as np, trimesh

P1 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1"
P2 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
OUT = os.path.join(P1, "work", "revB")
C0 = {"x27": (26.97, 271.76), "x49": (49.0, 271.7)}


def cfit(p):
    A = np.c_[2 * p[:, 0], 2 * p[:, 1], np.ones(len(p))]
    b = (p ** 2).sum(1)
    s = np.linalg.lstsq(A, b, rcond=None)[0]
    r = np.sqrt(s[2] + s[0] ** 2 + s[1] ** 2)
    return s[0], s[1], r


def robust(p, it=4):
    for _ in range(it):
        cx, cy, r = cfit(p)
        e = np.hypot(p[:, 0] - cx, p[:, 1] - cy) - r
        k = np.abs(e) < max(3 * np.std(e), 0.03)
        if k.all(): break
        p = p[k]
    e = np.hypot(p[:, 0] - cx, p[:, 1] - cy) - r
    return dict(cx=round(cx, 3), cy=round(cy, 3), d=round(2 * r, 3), rms=round(float(np.std(e)), 3), n=int(len(p)))


def bands(v, nrm, rmin, rmax, zlist, label, horiz=True):
    out = {}
    for key, (cx, cy) in C0.items():
        rows = []
        for z0, z1 in zlist:
            rr = np.hypot(v[:, 0] - cx, v[:, 1] - cy)
            m = (rr > rmin) & (rr < rmax) & (v[:, 2] > z0) & (v[:, 2] < z1)
            if nrm is not None and horiz:
                m &= np.abs(nrm[:, 2]) < 0.5
            if m.sum() < 30:
                rows.append(dict(z=[z0, z1], n=int(m.sum()))); continue
            f = robust(v[m][:, :2]); f["z"] = [z0, z1]
            # angular coverage
            a = np.degrees(np.arctan2(v[m][:, 1] - f["cy"], v[m][:, 0] - f["cx"]))
            f["cover_deg"] = int(len(np.unique((a // 10).astype(int))) * 10)
            rows.append(f)
        out[key] = rows
        print(label, key)
        for r in rows: print("   ", r)
    return out


res = {}
d = np.load(os.path.join(OUT, "scan_crop.npz"))
so = trimesh.Trimesh(d["v"], d["f"], process=False)
zl = [(84.6, 85.0), (84.0, 84.6), (83.4, 84.0), (82.8, 83.4), (82.2, 82.8), (81.6, 82.2), (81.0, 81.6), (80.4, 81.0), (79.8, 80.4), (79.0, 79.8)]
res["outer_scan"] = bands(so.vertices, so.vertex_normals, 1.4, 3.0, zl, "OUTER scan hole")
# deepest hole wall point and any floor (upward facing) inside the hole
for key, (cx, cy) in C0.items():
    v, n = so.vertices, so.vertex_normals
    rr = np.hypot(v[:, 0] - cx, v[:, 1] - cy)
    m = (rr < 2.6) & (v[:, 2] < 85.1) & (v[:, 2] > 70)
    zz = v[m, 2]
    up = m & (n[:, 2] > 0.7)
    res.setdefault("outer_depth", {})[key] = dict(n=int(m.sum()), zmin=round(float(zz.min()), 2) if m.sum() else None,
                                               z_pct=np.round(np.percentile(zz, [1, 5, 50]), 2).tolist() if m.sum() else None,
                                               floor_up_n=int(up.sum()), floor_up_z=np.round(np.percentile(v[up, 2], [5, 50, 95]), 2).tolist() if up.sum() > 5 else None)
    print("outer depth", key, res["outer_depth"][key])
    # top face level around the hole
    t = (rr > 3) & (rr < 6) & (n[:, 2] > 0.95) & (v[:, 2] > 84)
    res.setdefault("outer_top", {})[key] = round(float(np.median(v[t, 2])), 3)
print("outer top", res["outer_top"])

# inner scan (bumps), LT-OUT-001 frame, lifted 0.12
sys.path.insert(0, os.path.join(P2, "an"))
cwd = os.getcwd(); os.chdir(os.path.join(P2, "an"))
from fixlib import scan
vi, fi = scan()
os.chdir(cwd)
box = (vi[:, 0] > 18) & (vi[:, 0] < 58) & (vi[:, 1] > 264) & (vi[:, 1] < 280) & (vi[:, 2] > 77) & (vi[:, 2] < 88)
k = box[fi].all(1)
si = trimesh.Trimesh(vi, fi[k], process=False); si.remove_unreferenced_vertices()
zi = [(84.6, 85.2), (84.0, 84.6), (83.0, 84.0), (82.0, 83.0), (81.0, 82.0), (80.0, 81.0), (79.6, 80.0)]
res["inner_scan"] = bands(si.vertices, si.vertex_normals, 1.0, 2.8, zi, "INNER scan bump")
for key, (cx, cy) in C0.items():
    v, n = si.vertices, si.vertex_normals
    rr = np.hypot(v[:, 0] - cx, v[:, 1] - cy)
    m = (rr < 1.5) & (n[:, 2] < -0.8) & (v[:, 2] < 84)
    res.setdefault("inner_bottom", {})[key] = np.round(np.percentile(v[m, 2], [5, 50, 95]), 3).tolist() if m.sum() > 5 else None
    xy = v[(rr < 3.0) & (v[:, 2] < 85.0) & (v[:, 2] > 79.0)][:, :2]
    res.setdefault("inner_bump_xy_extent", {})[key] = dict(x=np.round([xy[:, 0].min(), xy[:, 0].max()], 3).tolist(),
                                                           y=np.round([xy[:, 1].min(), xy[:, 1].max()], 3).tolist())
print("inner bump bottom", res["inner_bottom"]); print("inner bump extent", res["inner_bump_xy_extent"])

# inner M13 build (A039 / A040 switched on)
mi = trimesh.load(os.path.join(P2, "nx", "runM13", "inner_Z.stl"))
for key, (cx, cy) in C0.items():
    v = mi.vertices
    rr = np.hypot(v[:, 0] - cx, v[:, 1] - cy)
    m = (rr < 3.0) & (v[:, 2] < 85.2) & (v[:, 2] > 78)
    res.setdefault("inner_M13_bump", {})[key] = dict(x=np.round([v[m, 0].min(), v[m, 0].max()], 3).tolist(),
                                                     y=np.round([v[m, 1].min(), v[m, 1].max()], 3).tolist(),
                                                     zmin=round(float(v[m, 2].min()), 3), rmax=round(float(rr[m].max()), 3))
print("inner M13 bump", res["inner_M13_bump"])
json.dump(res, open(os.path.join(OUT, "measure.json"), "w"), indent=1, default=float)
