"""Window outlines (y, z) per side from the skin coverage map -> line/arc loops; x limits from the inner fit."""
import json, numpy as np, contourpy, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import ndimage
from scipy.interpolate import BSpline
from common import W
from arcfit import fit_loop, seg_points
c = np.load(W + r"\skin_cov.npz"); ys, ths, cov, X, Z = c["ys"], c["ths"], c["cov"], c["X"], c["Z"]
si = np.load(W + r"\inner_fit.npz")
def x_inner(y, z, side):
    ty, tt, C, pc, ZC = si["ty"], si["tt"], si["C"], si["pc"], float(si["ZC"])
    th = np.radians(np.linspace(-182, 2, 3681)); r = BSpline(tt, BSpline(ty, C, 3)(y), 3)(th)
    xx = np.polyval(pc, y) + r * np.cos(th); zz = ZC + r * np.sin(th)
    m = (th < np.radians(-90)) if side == "L" else (th > np.radians(-90))
    k = np.argmin(np.abs(zz[m] - z)); return xx[m][k]
gy = np.arange(100, 290, 0.25); gz = np.arange(-40, 46, 0.25)
out = []
fig, ax = plt.subplots(1, 2, figsize=(24, 9))
for k, side in enumerate(("L", "R")):
    sel = (ths < np.radians(-120)) if side == "L" else (ths > np.radians(-60))
    T = np.broadcast_to(sel[None, :], cov.shape)
    pts_open = np.c_[np.broadcast_to(ys[:, None], cov.shape)[T & ~cov], Z[T & ~cov]]
    pts_cov = np.c_[np.broadcast_to(ys[:, None], cov.shape)[T & cov], Z[T & cov]]
    G = np.zeros((len(gz), len(gy)))
    for P, val in ((pts_cov, -1), (pts_open, 1)):
        iy = np.clip(((P[:, 0] - 100) / 0.25).astype(int), 0, len(gy) - 1); iz = np.clip(((P[:, 1] + 40) / 0.25).astype(int), 0, len(gz) - 1)
        G[iz, iy] = val
    # fill gaps by nearest labelled cell
    lab = G != 0
    idx = ndimage.distance_transform_edt(~lab, return_distances=False, return_indices=True)
    G = G[idx[0], idx[1]]
    G[gz > 34.0, :] = 1.0                      # open above the rim
    yr_ = (175.0, 245.0) if side == 'L' else (132.0, 192.0)
    G[:, (gy < yr_[0]) | (gy > yr_[1])] = -1
    G[:, :4] = -1; G[:, -4:] = -1; G[-4:, :] = -1
    Om = G > 0
    Om = ndimage.binary_opening(Om, iterations=3)
    labl, n = ndimage.label(Om)
    for j in range(1, n + 1):
        m = labl == j
        if m.sum() * 0.0625 < 15: continue
        zz_ = np.where(m.any(1))[0]
        if gz[zz_].min() > 33.0: continue      # just the band above the rim
        Gs = ndimage.gaussian_filter(m.astype(float), 2.0) - 0.5
        for C in contourpy.contour_generator(z=Gs, line_type="Separate").lines(0.0):
            P = np.c_[100 + C[:, 0] * 0.25, -40 + C[:, 1] * 0.25]
            if np.linalg.norm(P[0] - P[-1]) > 1e-6: continue
            P = P[:-1]
            if (P[:, 1] < 33).sum() < 10: continue
            segs = fit_loop(P, tol=0.15)
            yr = (P[P[:, 1] < 33, 0].min(), P[P[:, 1] < 33, 0].max())
            zr = P[:, 1].min()
            ymid = 0.5 * (yr[0] + yr[1])
            xi = [x_inner(yy, zz, side) for yy in np.linspace(yr[0], yr[1], 9) for zz in np.linspace(max(zr, -30), 33, 6)]
            xlim = (max(xi) + 1.0) if side == "L" else (min(xi) - 1.0)
            out.append(dict(side=side, y=[float(yr[0]), float(yr[1])], zmin=float(zr), x_inner_limit=float(xlim), n_seg=len(segs),
                            segs=[([s[0], s[1].tolist(), s[2].tolist()] if s[0] == "L" else [s[0], s[1].tolist(), s[2].tolist(), s[3].tolist(), float(s[4]), bool(s[5])]) for s in segs]))
            Q = np.vstack([seg_points(s) for s in segs]); ax[k].plot(Q[:, 0], Q[:, 1], "-")
            print(side, "window y %.1f..%.1f zmin %.1f segs %d xlim %.1f" % (yr[0], yr[1], zr, len(segs), xlim))
    ax[k].imshow(G, origin="lower", extent=[100, 290, -40, 46], cmap="coolwarm", alpha=0.3); ax[k].set_aspect("equal"); ax[k].grid(True)
json.dump(out, open(W + r"\windows.json", "w"))
fig.tight_layout(); fig.savefig(W + r"\windows_loops.png", dpi=70)
