"""Two-pass skin fit: pass 1 fine (6mm x 3deg) finds seams (|res| > SEAM_T), dilate, exclude;
pass 2 smooth fit on the rest. Writes work/skin_fit.npz + seam_pts.npz (seam groove samples)."""
import sys
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.interpolate import BSpline
from scipy.ndimage import binary_dilation
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W

KY = float(sys.argv[1]) if len(sys.argv) > 1 else 8.0
KT = float(sys.argv[2]) if len(sys.argv) > 2 else 4.0
LAM = float(sys.argv[3]) if len(sys.argv) > 3 else 3e-3
SEAM_T = 0.12
d = np.load(W + r"\skin_data.npz")
D, mask, pc, ZC, YCL = d["D"], d["mask"], d["pc"], float(d["ZC"]), float(d["YCL"])
xcf = lambda y: np.polyval(pc, np.maximum(y, YCL))
y_, t_, r_, inc = D.T
X_ = xcf(y_) + r_ * np.cos(t_); Z_ = ZC + r_ * np.sin(t_)
dk_ = np.hypot(X_, y_); ph_ = np.degrees(np.arctan2(y_, X_))
HUBW = 0.15
hub = (~mask) & (dk_ < 69.5) & (Z_ < ZC - 1) & (inc > 0.25) & ~((ph_ > -50) & (ph_ < 140) & (dk_ > 60))
WT = np.where(mask, 1.0, np.where(hub, HUBW, 0.0))
print("hub guide rows", hub.sum())


def knots(lo, hi, h, k=3):
    n = max(1, int(round((hi - lo) / h)))
    return np.r_[[lo] * k, np.linspace(lo, hi, n + 1), [hi] * k]


def fit(m, KY, KT, LAM):
    ty = knots(-75.0, 292.0, KY); tt = knots(np.radians(-185.0), np.radians(5.0), np.radians(KT))
    ny, nt = len(ty) - 4, len(tt) - 4
    yy, tth, rr, w = y_[m], t_[m], r_[m], inc[m] * WT[m]
    By = BSpline.design_matrix(yy, ty, 3).tocsr(); Bt = BSpline.design_matrix(tth, tt, 3).tocsr()
    iy = By.indices.reshape(-1, 4); vy = By.data.reshape(-1, 4)
    it = Bt.indices.reshape(-1, 4); vt = Bt.data.reshape(-1, 4)
    cols = (iy[:, :, None] * nt + it[:, None, :]).reshape(len(yy), 16)
    vals = (vy[:, :, None] * vt[:, None, :]).reshape(len(yy), 16) * w[:, None]
    A = sp.csr_matrix((vals.ravel(), cols.ravel(), np.arange(0, 16 * len(yy) + 1, 16)), shape=(len(yy), ny * nt))
    d2 = lambda n: sp.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n))
    d1 = lambda n: sp.diags([1.0, -1.0], [0, 1], shape=(n - 1, n))
    P = sp.kron(d2(ny), sp.eye(nt)); Q = sp.kron(sp.eye(ny), d2(nt)); X = sp.kron(d1(ny), d1(nt))
    M = (A.T @ A + LAM * len(yy) / (ny * nt) * (P.T @ P + Q.T @ Q + 2 * X.T @ X)).tocsc()
    coef = spl.spsolve(M, A.T @ (rr * w))
    return ty, tt, coef.reshape(ny, nt)


def evalr(ty, tt, C, y, t):
    By = BSpline.design_matrix(np.clip(y, ty[3], ty[-4] - 1e-9), ty, 3)
    Bt = BSpline.design_matrix(np.clip(t, tt[3], tt[-4] - 1e-9), tt, 3)
    return np.asarray((By @ C).__mul__(1) if False else None) if False else np.einsum("ij,ij->i", (By @ C), Bt.toarray()) if len(y) < 2000 else \
        np.concatenate([np.einsum("ij,ij->i", (BSpline.design_matrix(np.clip(y[k:k+2000], ty[3], ty[-4]-1e-9), ty, 3) @ C),
                                  BSpline.design_matrix(np.clip(t[k:k+2000], tt[3], tt[-4]-1e-9), tt, 3).toarray()) for k in range(0, len(y), 2000)])


# pass 1
ty, tt, C = fit(mask | hub, 6.0, 3.0, 1e-3)
res1 = np.full(len(D), np.nan)
res1[mask] = (r_[mask] - evalr(ty, tt, C, y_[mask], t_[mask])) * inc[mask]
# grid the seam indicator
gy = np.round((y_ + 72) / 1.0).astype(int); gt = np.round((np.degrees(t_) + 182) / 0.5).astype(int)
G = np.zeros((gy.max() + 1, gt.max() + 1), bool)
sm = mask & (np.abs(res1) > SEAM_T)
G[gy[sm], gt[sm]] = True
Gd = binary_dilation(G, structure=np.ones((7, 9), bool))      # +-3 mm, +-2 deg
seam = Gd[gy, gt]
m2 = (mask & ~seam) | hub
print("pass1 seam pts", sm.sum(), "excluded after dilation", (mask & seam).sum(), "of", mask.sum())
# pass 2
ty, tt, C = fit(m2, KY, KT, LAM)
res2 = np.full(len(D), np.nan)
res2[mask] = (r_[mask] - evalr(ty, tt, C, y_[mask], t_[mask])) * inc[mask]
q = np.abs(res2[mask & ~seam]); qa = np.abs(res2[mask])
print(f"pass2 KY {KY} KT {KT} lam {LAM}: off-seam p50 {np.percentile(q,50):.3f} p95 {np.percentile(q,95):.3f} p99 {np.percentile(q,99):.3f} max {q.max():.3f}; "
      f"all p95 {np.percentile(qa,95):.3f} p99 {np.percentile(qa,99):.3f}")
YF = -30.0
syn = (~mask) & (y_ < YF)
r_ref = evalr(ty, tt, C, np.full(syn.sum(), YF), t_[syn])
r_[syn] = r_ref; inc[syn] = 1.0; WT[syn] = 0.5; hub &= ~syn
m3 = m2 | syn
ty, tt, C = fit(m3, KY, KT, LAM)
res2[mask] = (r_[mask] - evalr(ty, tt, C, y_[mask], t_[mask])) * inc[mask]
q = np.abs(res2[mask & ~seam])
print(f"pass3 (frozen knee zone y<{YF}): off-seam p50 {np.percentile(q,50):.3f} p95 {np.percentile(q,95):.3f} p99 {np.percentile(q,99):.3f}")
np.savez(W + r"\skin_fit.npz", YCL=YCL, ty=ty, tt=tt, C=C, pc=pc, ZC=ZC, KY=KY, KT=KT, LAM=LAM)
np.savez(W + r"\seam_grid.npz", G=G, Gd=Gd, res1=res1, res2=res2, seam=seam)
fig, ax = plt.subplots(1, 2, figsize=(26, 10))
for k, (rs, ttl) in enumerate(((res2, "pass2 residual (all skin pts)"), (np.where(m2, res2, np.nan), "pass2 residual, seams excluded"))):
    mm = ~np.isnan(rs)
    sc = ax[k].scatter(y_[mm], np.degrees(t_[mm]), c=np.clip(rs[mm], -0.4, 0.4), s=0.3, cmap="seismic", vmin=-0.4, vmax=0.4)
    plt.colorbar(sc, ax=ax[k]); ax[k].set_title(ttl); ax[k].grid(True, lw=0.3)
fig.tight_layout(); fig.savefig(W + rf"\skin2_res_{int(KY)}_{int(KT)}.png", dpi=70)
