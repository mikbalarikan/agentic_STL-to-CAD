"""Missing solid features from the height-map difference (scan top above CAD top): opening removes fillet
bands, each remaining component -> footprint loop (lines/arcs) + fitted top plane z = a x + b y + c.
usage: s24_missing.py tag   -> work/missing_<tag>.json + figure"""
import sys, json
import numpy as np
from scipy import ndimage
import contourpy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W
from arcfit import fit_loop, seg_points

tag = sys.argv[1]
d = np.load(W + rf"\hdiff_{tag}.npz")
Hs, Hc, (X0, X1, Y0, Y1), cell = d["Hs"], d["Hc"], d["ext"], float(d["cell"])
xs = X0 + (np.arange(Hs.shape[1]) + 0.5) * cell; ys = Y0 + (np.arange(Hs.shape[0]) + 0.5) * cell
XX, YY = np.meshgrid(xs, ys)
D = Hs - Hc
miss = np.isfinite(Hs) & ((D > 0.8) | ~np.isfinite(Hc))
# exclusions: knee bore interior (scan sees through holes), hip collar/ring band, windows handled elsewhere
excl = (np.hypot(XX, YY) < 56) | (YY > 264) | (YY < -68)
miss &= ~excl
R = int(round(1.6 / cell))
disk = np.hypot(*np.mgrid[-R:R + 1, -R:R + 1]) <= R
core = ndimage.binary_opening(miss, structure=disk)
core = ndimage.binary_dilation(core, structure=disk) & miss
lab, n = ndimage.label(core)
out = []
fig, ax = plt.subplots(figsize=(16, 26))
ax.imshow(np.where(miss, 1.0, np.nan), origin="lower", extent=[X0, X1, Y0, Y1], cmap="Reds", vmin=0, vmax=2)
for k in range(1, n + 1):
    m = lab == k
    area = m.sum() * cell * cell
    if area < 12:
        continue
    inner = ndimage.binary_erosion(m, iterations=2)
    sel = inner if inner.sum() > 20 else m
    z = Hs[sel]; x = XX[sel]; y = YY[sel]
    A = np.c_[x, y, np.ones_like(x)]
    coef, *_ = np.linalg.lstsq(A, z, rcond=None)
    res = z - A @ coef
    keep = np.abs(res) < max(0.3, 2.5 * res.std())
    coef, *_ = np.linalg.lstsq(A[keep], z[keep], rcond=None)
    res = z - A @ coef
    rms = float(np.sqrt(np.mean(res[keep] ** 2)))
    slope = float(np.degrees(np.arctan(np.hypot(coef[0], coef[1]))))
    G = np.pad(ndimage.gaussian_filter(m.astype(float), 1.2) - 0.5, 2, constant_values=-0.5)
    loops = []
    for C in contourpy.contour_generator(z=G, line_type="Separate").lines(0.0):
        P = np.c_[X0 + (C[:, 0] - 2 + 0.5) * cell, Y0 + (C[:, 1] - 2 + 0.5) * cell]
        if np.linalg.norm(P[0] - P[-1]) > 1e-6 or len(P) < 8:
            continue
        P = P[:-1]
        a2 = 0.5 * (np.dot(P[:, 0], np.roll(P[:, 1], -1)) - np.dot(P[:, 1], np.roll(P[:, 0], -1)))
        if abs(a2) < 8:
            continue
        segs = fit_loop(P, tol=0.12)
        loops.append([([s_[0], s_[1].tolist(), s_[2].tolist()] if s_[0] == "L" else
                       [s_[0], s_[1].tolist(), s_[2].tolist(), s_[3].tolist(), float(s_[4]), bool(s_[5])]) for s_ in segs])
        Q = np.vstack([seg_points(s_) for s_ in segs]); ax.plot(Q[:, 0], Q[:, 1], "b-", lw=0.8)
    if not loops:
        continue
    loops.sort(key=lambda L: -len(L))
    zmax = float(np.nanmax(Hs[m])); zmed = float(np.nanmedian(Hs[m]))
    cx, cy = float(XX[m].mean()), float(YY[m].mean())
    out.append(dict(area=round(float(area), 1), centre=[round(cx, 2), round(cy, 2)], plane=[float(c) for c in coef], rms=round(rms, 3),
                    slope_deg=round(slope, 1), zmax=round(zmax, 2), zmed=round(zmed, 2), loop=loops[0], holes=loops[1:]))
    ax.text(cx, cy, f"{len(out)-1}", fontsize=9, color="k")
    print(f"#{len(out)-1}: area {area:7.1f} at ({cx:6.1f},{cy:6.1f}) top z~{zmed:6.2f} (max {zmax:6.2f}) slope {slope:5.1f} rms {rms:.3f} loops {len(loops)}")
json.dump(out, open(W + rf"\missing_{tag}.json", "w"))
ax.set_xticks(np.arange(-100, 126, 10)); ax.set_yticks(np.arange(-70, 292, 10)); ax.grid(True, lw=0.3); ax.set_aspect("equal")
fig.tight_layout(); fig.savefig(W + rf"\missing_{tag}.png", dpi=60)
