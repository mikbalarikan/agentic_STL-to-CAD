"""Decimate the scan for viewing and render 6 + 2 iso views (pyvista offscreen)."""
import sys, os
import numpy as np
import open3d as o3d
import pyvista as pv

W = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\work"
d = np.load(os.path.join(W, "scan.npz"))
m = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(d["v"].astype(np.float64)),
                              o3d.utility.Vector3iVector(d["f"]))
dec_path = os.path.join(W, "scan_600k.ply")
if not os.path.exists(dec_path):
    md = m.simplify_quadric_decimation(600000)
    md.compute_vertex_normals()
    o3d.io.write_triangle_mesh(dec_path, md)
mesh = pv.read(dec_path)
tag = sys.argv[1] if len(sys.argv) > 1 else "raw"
views = {"px": (1, 0, 0), "nx": (-1, 0, 0), "py": (0, 1, 0), "ny": (0, -1, 0), "pz": (0, 0, 1), "nz": (0, 0, -1),
         "iso1": (1, -1, 1), "iso2": (-1, 1, -1)}
for k, v in views.items():
    p = pv.Plotter(off_screen=True, window_size=(1400, 1400))
    p.add_mesh(mesh, color="#3aa0e0", smooth_shading=True, specular=0.3)
    p.add_axes()
    p.camera_position = [tuple(np.array(v) * 1000), (0, 0, 0), (0, 0, 1) if k not in ("pz", "nz") else (0, 1, 0)]
    p.reset_camera()
    p.screenshot(os.path.join(W, f"view_{tag}_{k}.png"))
    p.close()
print("ok")
