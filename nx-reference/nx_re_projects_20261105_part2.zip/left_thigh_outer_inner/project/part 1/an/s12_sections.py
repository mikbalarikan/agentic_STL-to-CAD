"""Loft sections for NX from the skin fit: at y = Y0..Y1 step DY, theta -185..5 deg,
each a clamped uniform cubic B-spline with NP poles (least squares on dense samples).
Writes work/sections.json: [{y, poles:[[x,y,z],..], knots}] and the max fit error per section."""
import json, sys
import numpy as np
from scipy.interpolate import BSpline, make_lsq_spline
from common import W

NP = int(sys.argv[1]) if len(sys.argv) > 1 else 40
DY = float(sys.argv[2]) if len(sys.argv) > 2 else 8.0
SRC = sys.argv[3] if len(sys.argv) > 3 else "skin_fit"
DST = sys.argv[4] if len(sys.argv) > 4 else "sections"
s = np.load(W + "\\" + SRC + ".npz")
ty, tt, C, pc, ZC, YCL = s["ty"], s["tt"], s["C"], s["pc"], float(s["ZC"]), float(s["YCL"])


def r_of(y, th):
    ry = BSpline(ty, C, 3)(np.clip(y, ty[3], ty[-4]))      # (nt,)
    sp = BSpline(tt, ry, 3)
    lo, hi = tt[3], tt[-4]
    r = sp(np.clip(th, lo, hi))
    d = sp.derivative()
    r = np.where(th > hi, sp(hi) + d(hi) * (th - hi), r)
    r = np.where(th < lo, sp(lo) + d(lo) * (th - lo), r)
    return r


def section_pts(y, th):
    r = r_of(y, th)
    xc = np.polyval(pc, max(y, YCL))
    return np.c_[xc + r * np.cos(th), np.full_like(th, y), ZC + r * np.sin(th)]


ys = list(np.arange(-70.0, 287.0, DY)) + [287.0, 292.0]
th = np.radians(np.linspace(-197.0, 17.0, 2141))
EXT = 0.0
out = []
worst = 0
for y in ys:
    P = section_pts(y, th)
    # optional straight tangent extensions at both ends (EXT > 0)
    if EXT > 0:
        t0 = P[0] - P[8]; t0 /= np.linalg.norm(t0)
        t1 = P[-1] - P[-9]; t1 /= np.linalg.norm(t1)
        e = np.linspace(0, EXT, 60)[1:]
        P = np.vstack([P[0] + e[::-1, None] * t0, P, P[-1] + e[:, None] * t1])
    # chord-length parameter normalised 0..1 (same knot vector for every section)
    L = np.r_[0, np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))]
    u = L / L[-1]
    kn = np.r_[[0.0] * 4, np.linspace(0, 1, NP - 2)[1:-1], [1.0] * 4]
    spl = make_lsq_spline(u, P, kn, k=3)
    err = np.linalg.norm(spl(u) - P, axis=1).max()
    worst = max(worst, err)
    out.append(dict(y=float(y), poles=spl.c.tolist(), knots=kn.tolist(), err=float(err), length=float(L[-1])))
json.dump(dict(NP=NP, DY=DY, sections=out), open(W + "\\" + DST + ".json", "w"))
allp = np.array([p for o in out for p in o["poles"]])
print("sections", len(out), "poles each", NP, "max lsq err", round(worst, 4), "pole bbox", allp.min(0).round(1), allp.max(0).round(1))
