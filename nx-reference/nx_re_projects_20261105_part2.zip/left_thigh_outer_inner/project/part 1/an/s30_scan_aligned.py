"""Write the scan STL moved into the part frame (work/frame.json: p_new = R @ (p - o)), full resolution."""
import sys, os, json, time
import numpy as np

ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"
SRC = os.path.join(ROOT, "SHARE -  Left Thigh - Outer.stl")
DST = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "work", "overlay", "scan_in_part_frame.stl")
t = time.time()
with open(SRC, "rb") as f:
    head = f.read(80)
    n = int(np.frombuffer(f.read(4), np.uint32)[0])
    dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
    rec = np.fromfile(f, dt, n)
fr = json.load(open(os.path.join(ROOT, "work", "frame.json")))
R = np.array(fr["R"]); o = np.array(fr["o"])
v = (rec["v"].astype(np.float64).reshape(-1, 3) - o) @ R.T
v = v.reshape(-1, 3, 3)
nr = np.cross(v[:, 1] - v[:, 0], v[:, 2] - v[:, 0])
nr /= np.maximum(np.linalg.norm(nr, axis=1, keepdims=True), 1e-30)
out = np.zeros(n, dt)
out["v"] = v.astype(np.float32); out["n"] = nr.astype(np.float32)
with open(DST, "wb") as f:
    f.write(b"scan in LT-OUT-001 part frame".ljust(80, b" "))
    f.write(np.uint32(n).tobytes())
    out.tofile(f)
lo, hi = v.reshape(-1, 3).min(0), v.reshape(-1, 3).max(0)
d = dict(triangles=n, bbox_lo=lo.round(3).tolist(), bbox_hi=hi.round(3).tolist(), file=DST,
         size=os.path.getsize(DST), sec=round(time.time() - t, 1))
print(json.dumps(d, indent=1))
