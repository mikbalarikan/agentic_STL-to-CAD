"""Masks on the fine height map: flat-top regions per level, wall band, wall-top heights.
Writes work/masks.npz and a figure."""
import numpy as np
from scipy import ndimage
from scipy.interpolate import BSpline
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W

d = np.load(W + r"\hmap2.npz")
H, ext, cell = d["H"], d["ext"], float(d["cell"])
X0, X1, Y0, Y1 = ext
ny_, nx_ = H.shape
xs = X0 + (np.arange(nx_) + 0.5) * cell
ys = Y0 + (np.arange(ny_) + 0.5) * cell
XX, YY = np.meshgrid(xs, ys)


def polar_r(fitfile, y, x, z):
    s = np.load(W + "\\" + fitfile)
    ty, tt, C, pc, ZC = s["ty"], s["tt"], s["C"], s["pc"], float(s["ZC"])
    xc = np.polyval(pc, y)
    th = np.arctan2(z - ZC, x - xc)
    r = np.hypot(x - xc, z - ZC)
    By = BSpline.design_matrix(np.clip(y, ty[3], ty[-4] - 1e-9), ty, 3)
    Bt = BSpline.design_matrix(np.clip(th, tt[3], tt[-4] - 1e-9), tt, 3)
    rf = np.asarray((By @ C * Bt.toarray()).sum(1)).ravel() if False else np.einsum("ij,ij->i", (By @ C), Bt.toarray())
    return r, rf


def outside_inner(z):
    """True where (x, y, z) is NOT in the cavity (wall, exterior) by the inner fit; knee zone analytic."""
    out = np.ones(H.shape, bool)
    yy, xx = YY.ravel(), XX.ravel()
    sel = (yy > -70) & (yy < 289)
    r, rf = [], []
    idx = np.where(sel)[0]
    res = np.ones(len(yy), bool)
    for k in range(0, len(idx), 200000):
        ii = idx[k:k + 200000]
        rr, rfit = polar_r("inner_fit.npz", yy[ii], xx[ii], np.full(len(ii), z))
        res[ii] = rr >= rfit
    out = res.reshape(H.shape)
    dk = np.hypot(XX, YY); ph = np.degrees(np.arctan2(YY, XX)) % 360
    hub = dk < 67.85
    round_side = (ph >= 128) & (ph <= 320)
    out[hub & (dk < 64.95)] = False
    out[(dk < 70) & round_side & (dk >= 64.95)] = True
    out[hub & ~round_side] = False
    return out


Hn = np.where(np.isinf(H), np.nan, H)
gy, gx = np.gradient(np.nan_to_num(Hn, nan=-100.0), cell)
slope = np.hypot(gx, gy)
levels = [39.04, 36.07, 34.76, 33.90, 29.55, 28.39, 27.67, 8.15, 7.49, 4.97, 4.78, 0.0, -5.00, -20.29]
flat = {}
for h in levels:
    m = (np.abs(Hn - h) < 0.15) & (slope < 0.12)
    m = ndimage.binary_opening(m, iterations=1)
    lab, n = ndimage.label(m)
    sizes = ndimage.sum(m, lab, range(1, n + 1)) * cell * cell
    keep = np.isin(lab, 1 + np.where(sizes >= 3.0)[0])
    flat[h] = keep
    print(f"level {h:7.2f}: {int(keep.sum()*cell*cell)} mm2 in {int((sizes>=3).sum())} regions")
# wall band at rim height and wall-top heights
wall = outside_inner(30.0)
so = np.load(W + r"\skin_fit.npz")
np.savez_compressed(W + r"\masks.npz", **{f"flat_{h:+.2f}": flat[h] for h in levels}, wall30=wall, slope=slope)
# figure: classified top map
fig, ax = plt.subplots(figsize=(16, 26))
img = np.full(H.shape + (3,), 1.0)
img[~np.isnan(Hn)] = 0.85
cmap = plt.get_cmap("tab20")
for k, h in enumerate(levels):
    img[flat[h]] = cmap(k % 20)[:3]
ax.imshow(img, origin="lower", extent=[X0, X1, Y0, Y1], interpolation="nearest")
for k, h in enumerate(levels):
    ax.plot([], [], "s", color=cmap(k % 20), label=f"{h}")
ax.legend(loc="upper left", fontsize=8)
ax.set_xticks(np.arange(-100, 126, 10)); ax.set_yticks(np.arange(-70, 292, 10)); ax.grid(True, lw=0.3)
fig.tight_layout(); fig.savefig(W + r"\levels_map.png", dpi=60)
