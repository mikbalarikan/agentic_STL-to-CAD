"""Rev F delivery package: LT-OUT-001_RevF_Left_Thigh_Outer/LT-OUT-001_RevF/{CAD, Deviation Report, Drawings, Renders}
from deliver_RevF (no README), then the zip and a testzip. usage: f7_package.py"""
import os, shutil, zipfile

P1 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1"
SRC = os.path.join(P1, "deliver_RevF")
TOP = "LT-OUT-001_RevF_Left_Thigh_Outer"
PKG = os.path.join(P1, TOP, "LT-OUT-001_RevF")
ZIP = os.path.join(P1, TOP + ".zip")
if os.path.exists(os.path.join(P1, TOP)):
    shutil.rmtree(os.path.join(P1, TOP))
os.makedirs(PKG)
MAP = {"CAD": ("CAD", lambda n: not n.startswith("_") and n.endswith((".prt", ".step", ".x_t", ".stl"))),
       "Deviation Report": ("QA", lambda n: n.endswith((".pdf", ".png"))),
       "Drawings": ("Drawings", lambda n: n.endswith((".pdf", ".dwg", ".prt"))),
       "Renders": ("Renders", lambda n: n.endswith(".png"))}
n = 0
for dst, (src, ok) in MAP.items():
    os.makedirs(os.path.join(PKG, dst))
    for f in sorted(os.listdir(os.path.join(SRC, src))):
        if ok(f):
            shutil.copy2(os.path.join(SRC, src, f), os.path.join(PKG, dst, f)); n += 1
if os.path.exists(ZIP):
    os.remove(ZIP)
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(os.path.join(P1, TOP)):
        rel = os.path.relpath(root, P1)
        z.write(root, rel + "/")
        for f in sorted(files):
            z.write(os.path.join(root, f), os.path.join(rel, f))
with zipfile.ZipFile(ZIP) as z:
    bad = z.testzip()
    names = z.namelist()
assert not any(x.lower().endswith((".md", ".txt", ".json", ".log")) for x in names), "internal file in zip"
print("files", n, "zip entries", len(names), "testzip", bad or "OK", "size MB", round(os.path.getsize(ZIP) / 1e6, 1))
for x in names:
    print("  ", x)
