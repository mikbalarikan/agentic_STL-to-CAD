"""Rev C: scan -> CAD deviation in the regions that changed vs Rev A (connector pad, slots, clip K1, rib R1, tabs T1/T2).
usage: c5_localdev.py revA.stl revC.stl out.json"""
import sys, json
import numpy as np, open3d as o3d, trimesh
from common import load
v, f = load()
R = {"connector pad (hip end face)": ((0, 274, -34), (36, 284, -8)),
     "locating slots S1/S2": ((22, 266, 78), (54, 277, 86)),
     "clip K1": ((85, 195, -14), (106, 218, 12)), "rib R1": ((88, 186, -12), (114, 202, 38)),
     "tab T1": ((-44, 228, -2), (-24, 248, 26)), "tab T2": ((-28, 176, -6), (-10, 198, 14))}
def scene(p):
    m = trimesh.load(p); s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(m.vertices.astype(np.float32)), o3d.core.Tensor(m.faces.astype(np.uint32))); return s
SA, SC = scene(sys.argv[1]), scene(sys.argv[2])
out = {}
for k, (lo, hi) in R.items():
    P = v[np.all((v > np.array(lo)) & (v < np.array(hi)), 1)].astype(np.float32)
    row = {"n": int(len(P))}
    for tag, s in (("revA", SA), ("revC", SC)):
        d = s.compute_signed_distance(o3d.core.Tensor(P)).numpy()
        row[tag] = {"p50": round(float(np.percentile(np.abs(d), 50)), 3), "p95": round(float(np.percentile(np.abs(d), 95)), 3),
                    "within_0p5_%": round(100 * float((np.abs(d) <= 0.5).mean()), 1)}
    out[k] = row
json.dump(out, open(sys.argv[3], "w"), indent=1)
for k, r in out.items(): print(k, r)
