"""Bolt-circle holes of the knee hub and hip ring: centres, diameters, PCD, count, clocking."""
import numpy as np, json
from scipy import ndimage
from common import load, section, fit_circle_robust, W
v, f = load()

def holes_in(p2, rmin, rmax, c0):
    r = np.hypot(p2[:, 0] - c0[0], p2[:, 1] - c0[1]); p = p2[(r > rmin) & (r < rmax)]
    g = np.zeros((1400, 1400), bool); s = 10.0
    ix = ((p[:, 0] - c0[0] + 70) * s).astype(int); iy = ((p[:, 1] - c0[1] + 70) * s).astype(int)
    g[iy.clip(0, 1399), ix.clip(0, 1399)] = True
    lab, n = ndimage.label(ndimage.binary_dilation(g, iterations=3))
    out = []
    for k in range(1, n + 1):
        sel = lab[iy.clip(0, 1399), ix.clip(0, 1399)] == k
        q = p[sel]
        if len(q) < 30: continue
        c, rr, sd, m = fit_circle_robust(q)
        if rr > 6: continue
        out.append((c[0], c[1], 2 * rr, sd, len(q)))
    return out

def summarize(name, hl, c0):
    hl = np.array(hl)
    R = np.hypot(hl[:, 0] - c0[0], hl[:, 1] - c0[1]); A = np.degrees(np.arctan2(hl[:, 1] - c0[1], hl[:, 0] - c0[0]))
    o = np.argsort(A); A = A[o]; R = R[o]; D = hl[o, 2]
    n = len(A); pitch = 360.0 / n
    clock = np.degrees(np.angle(np.mean(np.exp(1j * np.radians((A % pitch) * n)))) ) / n
    print(f"{name}: n={n} PCD={2*np.median(R):.3f} (r sd {R.std():.3f}) D med {np.median(D):.3f} [{D.min():.2f}..{D.max():.2f}] pitch {pitch:.3f} clock {clock % pitch:.3f}")
    print("   angles", np.round(A, 2).tolist())
    return dict(n=n, pcd=float(2 * np.median(R)), d=float(np.median(D)), clock=float(clock % pitch), angles=A.tolist(), r=R.tolist(), D=D.tolist())

res = {}
for z in (-5.2, -7.3):
    p = section(v, f, 2, z).reshape(-1, 3)[:, :2]
    res[f"knee_z{z}"] = summarize(f"knee holes z={z}", holes_in(p, 47.5, 55.5, (0, 0)), (0, 0))
HX, HZ = 37.97, 35.18
for y in (271.0, 274.5):
    p = section(v, f, 1, y).reshape(-1, 3)[:, [0, 2]]
    res[f"hip_y{y}"] = summarize(f"hip holes y={y}", holes_in(p, 42.3, 50.0, (HX, HZ)), (HX, HZ))
json.dump(res, open(W + r"\boltholes.json", "w"), indent=1)
