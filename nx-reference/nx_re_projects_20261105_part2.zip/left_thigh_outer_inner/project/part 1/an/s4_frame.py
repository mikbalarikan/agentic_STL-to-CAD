"""Part frame: Z = parting-plane normal, origin = knee bore axis on the parting plane,
Y = hip ring axis projected into the parting plane (pointing knee -> hip)."""
import numpy as np, json
from common import load, tri_data, fit_plane_robust, fit_circle_robust, section, W

v, f = load(frame=False)
pr = json.load(open(W + r"\parting_raw.json"))
c0 = np.array(pr["c"]); z = np.array(pr["n"])
# provisional frame: z, x from raw X orthogonalised
x = np.array([1.0, 0, 0]); x -= z * (x @ z); x /= np.linalg.norm(x)
y = np.cross(z, x)
R = np.vstack([x, y, z])
vp = v @ R.T
vp[:, 2] -= c0 @ z
c, n, a = tri_data(vp, f)

# --- hip ring faces: normals near +-Y, at y ~ 125..155 raw -> use vp
for lo, hi, sg in ((128, 131, -1), (138.5, 141, 1), (131, 133.5, -1)):
    m = (np.abs(n[:, 1]) > 0.99) & (c[:, 1] > lo + 0) & (c[:, 1] < hi)
    if m.sum() < 100: print("few", lo, hi, m.sum()); continue
    cc, nn, sd, k = fit_plane_robust(c[m])
    if nn[1] < 0: nn = -nn
    print(f"hip face y {lo}-{hi}: n={np.round(nn,5)} y0={cc[1]:.3f} sd={sd:.4f} n={m.sum()} area={a[m].sum():.0f}")

# --- knee bore: section at several z, keep points near a circle in the knee region (y<-100)
print("knee sections")
for zz in (-5, -10, -15, -20, -25, -30, -35):
    s = section(vp, f, 2, zz)
    p = s.reshape(-1, 3)
    p = p[p[:, 1] < -10]
    if len(p) < 50: continue
    # guess: bore points within radius band — first a rough fit on everything near centre
    ctr = np.array([np.median(p[:, 0]), np.median(p[:, 1])])
    r = np.hypot(p[:, 0] - ctr[0], p[:, 1] - ctr[1])
    hist, e = np.histogram(r, bins=np.arange(0, 120, 1))
    print(f"  z {zz}: npts {len(p)} r-hist peaks", [(int(e[i]), int(hist[i])) for i in np.argsort(hist)[::-1][:6]])
np.save(W + r"\Rprov.npy", np.r_[R, c0[None]])
