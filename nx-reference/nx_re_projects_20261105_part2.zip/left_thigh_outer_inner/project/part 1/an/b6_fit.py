"""Rev B fit check: runs the inner session's an/i50_fit.py unchanged, with its gap map pointed at the Rev B outer STL
(i50_fit reads outer.OUTER_CAD_STL, which is the Rev A STL).
usage: b6_fit.py inner.step outerB.step out.json inner.stl outerB.stl"""
import os, sys, runpy

P2AN = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner\an"
sys.path.insert(0, P2AN)
import outer  # noqa: E402

outer.OUTER_CAD_STL = sys.argv[5]
sys.argv = [os.path.join(P2AN, "i50_fit.py")] + sys.argv[1:5]
runpy.run_path(sys.argv[0], run_name="__main__")
