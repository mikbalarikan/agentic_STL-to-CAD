﻿"""Rev B prototype on the Rev A STEP (OCP): planar faces near the two hip-end holes (pocket ceiling / walls),
then subtract the planned slot tools (Ã˜ D hole from the top Z 85.2 to the floor + relief box below the pocket
ceiling, open to -Y) and report volume, validity and the wall left between hole and pocket.
usage: b3_proto.py D floor -> work/revB/proto.json, work/revB/proto_revB.step"""
import os, sys, json, math
import numpy as np
from OCP.STEPControl import STEPControl_Reader, STEPControl_Writer, STEPControl_AsIs
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut, BRepAlgoAPI_Common
from OCP.BRepPrimAPI import BRepPrimAPI_MakeCylinder, BRepPrimAPI_MakeBox
from OCP.gp import gp_Ax2, gp_Pnt, gp_Dir
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE, TopAbs_SOLID, TopAbs_REVERSED
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Plane
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

P1 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1"
OUT = os.path.join(P1, "work", "revB")
D = float(sys.argv[1]) if len(sys.argv) > 1 else 4.3
FLOOR = float(sys.argv[2]) if len(sys.argv) > 2 else 79.2
CTR = [(27.03, 271.70), (49.02, 271.69)]
TOP = 85.2
YREL = 268.95  # relief start (0.5 inside the hip-bore step void)
RB = 48.77     # hip-bore step radius (Rev A face)


def read(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()


def vol(s):
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(s, g); return g.Mass()


def nsolids(s):
    e = TopExp_Explorer(s, TopAbs_SOLID); n = 0
    while e.More(): n += 1; e.Next()
    return n


def bbox(f):
    b = Bnd_Box(); BRepBndLib.Add_s(f, b); return b.Get()


shape = read(os.path.join(P1, "deliver", "CAD", "LT-OUT-001_Left_Thigh_Outer_AP242.step"))
res = {"D": D, "floor": FLOOR, "centres": CTR}
# planar faces in the box of each hole
for cx, cy in CTR:
    rows = []
    e = TopExp_Explorer(shape, TopAbs_FACE)
    while e.More():
        f = TopoDS.Face_s(e.Current()); e.Next()
        x0, y0, z0, x1, y1, z1 = bbox(f)
        if x1 < cx - 5 or x0 > cx + 5 or y1 < cy - 5 or y0 > cy + 5 or z1 < 76 or z0 > 86:
            continue
        a = BRepAdaptor_Surface(f)
        if a.GetType() != GeomAbs_Plane:
            rows.append(dict(t=str(a.GetType()), bb=[round(v, 2) for v in (x0, y0, z0, x1, y1, z1)])); continue
        n = a.Plane().Axis().Direction(); s = -1 if f.Orientation() == TopAbs_REVERSED else 1
        rows.append(dict(t="plane", n=[round(s * n.X(), 3), round(s * n.Y(), 3), round(s * n.Z(), 3)],
                         bb=[round(v, 3) for v in (x0, y0, z0, x1, y1, z1)]))
    res[f"faces_{cx}"] = rows
    print("faces near", cx)
    for r in rows: print("   ", r)

ceil = {}
for cx, cy in CTR:
    # pocket ceiling = downward plane just under the top that spans the hole x range on the -Y side
    c = [r for r in res[f"faces_{cx}"] if r["t"] == "plane" and r["n"][2] < -0.99 and r["bb"][0] <= cx - D / 2 + 0.3
         and r["bb"][3] >= cx + D / 2 - 0.3 and r["bb"][1] < cy - D / 2 and 80 < r["bb"][2] < 85]
    ceil[cx] = c[0]["bb"][2] if c else None
res["pocket_ceiling"] = ceil
print("pocket ceiling", ceil)

v0 = vol(shape); cut = shape; tools_v = 0
for cx, cy in CTR:
    cyl = BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(cx, cy, FLOOR), gp_Dir(0, 0, 1)), D / 2, TOP + 1 - FLOOR).Shape()
    # relief below the hip-bore step (R 48.77 about the hip axis X 37.97 Z 35.18, faces Y 266.06-269.45): the hole
    # would leave a 0.1 wall to the step plane Y 269.45; open it to -Y up to the bore surface (box AND bore cylinder)
    box = BRepPrimAPI_MakeBox(gp_Pnt(cx - D / 2, YREL, FLOOR), D, cy - YREL, 86 - FLOOR).Shape()
    bore = BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(37.97, 260.0, 35.18), gp_Dir(0, 1, 0)), RB, 20.0).Shape()
    rel = BRepAlgoAPI_Common(box, bore); rel.Build(); rel = rel.Shape()
    tools_v += vol(cyl) + vol(rel)
    for t in (cyl, rel):
        c = BRepAlgoAPI_Cut(cut, t); c.Build(); cut = c.Shape()
v1 = vol(cut)
res["vol_revA"] = round(v0, 2); res["vol_revB"] = round(v1, 2); res["removed_mm3"] = round(v0 - v1, 2)
res["tools_mm3"] = round(tools_v, 2); res["already_void_mm3"] = round(tools_v - (v0 - v1), 2)
res["valid"] = BRepCheck_Analyzer(cut).IsValid(); res["solids"] = nsolids(cut)
print(json.dumps({k: res[k] for k in ("vol_revA", "vol_revB", "removed_mm3", "tools_mm3", "already_void_mm3", "valid", "solids")}))
w = STEPControl_Writer(); w.Transfer(cut, STEPControl_AsIs); w.Write(os.path.join(OUT, "proto_revB.step"))
json.dump(res, open(os.path.join(OUT, "proto.json"), "w"), indent=1)

