"""Rev B: look at the two hip-end locating slots on the OUTER scan (Rev A CAD is solid there).
Plots z-slices and x / y sections of outer scan, outer Rev A CAD and the inner M13 build (bumps on).
-> work/revB/slots_*.png"""
import os, sys, json
import numpy as np, trimesh
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection

P1 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1"
P2 = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 2 - Inner"
OUT = os.path.join(P1, "work", "revB"); os.makedirs(OUT, exist_ok=True)

d = np.load(os.path.join(P1, "work", "scan.npz"))
fr = json.load(open(os.path.join(P1, "work", "frame.json")))
v = (d["v"].astype(np.float64) - np.array(fr["o"])) @ np.array(fr["R"]).T
f = d["f"]
box = (v[:, 0] > 10) & (v[:, 0] < 66) & (v[:, 1] > 258) & (v[:, 1] < 286) & (v[:, 2] > 66) & (v[:, 2] < 92)
keep = box[f].all(1)
scan = trimesh.Trimesh(v, f[keep], process=False); scan.remove_unreferenced_vertices()
np.savez_compressed(os.path.join(OUT, "scan_crop.npz"), v=scan.vertices, f=scan.faces)
cad = trimesh.load(os.path.join(P1, "deliver", "CAD", "LT-OUT-001_Left_Thigh_Outer.stl"))
inn = trimesh.load(os.path.join(P2, "nx", "runM13", "inner_Z.stl"))
M = [("outer scan", scan, "tab:blue", 1.4), ("outer CAD Rev A", cad, "k", 0.8), ("inner CAD M13", inn, "tab:green", 0.8)]

def sec(ax, normal, origin, dims, lim):
    for nm, m, c, lw in M:
        s = trimesh.intersections.mesh_plane(m, normal, origin)[:, :, dims]
        k = ((s[..., 0] > lim[0]) & (s[..., 0] < lim[1]) & (s[..., 1] > lim[2]) & (s[..., 1] < lim[3])).any(1)
        ax.add_collection(LineCollection(s[k], colors=c, lw=lw, label=nm))
    ax.set_xlim(lim[0], lim[1]); ax.set_ylim(lim[2], lim[3]); ax.set_aspect("equal"); ax.grid(lw=0.3)

# z slices (plan)
zs = [84.8, 84.0, 83.0, 82.0, 81.0, 80.0]
fig, axs = plt.subplots(2, 3, figsize=(21, 10))
for ax, z in zip(axs.flat, zs):
    sec(ax, [0, 0, 1], [0, 0, z], [0, 1], (14, 62, 262, 282)); ax.set_title(f"z = {z} (x right, y up)")
axs[0, 0].legend(fontsize=7)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "slots_z.png"), dpi=80)

# y sections through the slots (x right, z up)
fig, axs = plt.subplots(1, 3, figsize=(21, 6))
for ax, y in zip(axs, (270.8, 271.7, 272.8)):
    sec(ax, [0, 1, 0], [0, y, 0], [0, 2], (14, 62, 70, 90)); ax.set_title(f"y = {y} (x right, z up)")
axs[0].legend(fontsize=7)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "slots_y.png"), dpi=80)

# x sections (y right, z up)
fig, axs = plt.subplots(2, 3, figsize=(21, 10))
for ax, x in zip(axs.flat, (24.0, 27.0, 30.0, 46.0, 49.0, 52.0)):
    sec(ax, [1, 0, 0], [x, 0, 0], [1, 2], (262, 282, 70, 90)); ax.set_title(f"x = {x} (y right, z up)")
axs[0, 0].legend(fontsize=7)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "slots_x.png"), dpi=80)
print("ok", len(scan.faces))
