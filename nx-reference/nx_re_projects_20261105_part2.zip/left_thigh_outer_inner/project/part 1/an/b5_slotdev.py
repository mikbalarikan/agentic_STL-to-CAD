"""Rev B: local scan -> CAD deviation at the two hip-end slots, Rev A vs Rev B (full-res scan, signed, + = scan
outside the CAD = material in the scan the CAD does not have, - = CAD material where the scan has none).
usage: b5_slotdev.py revA.stl revB.stl -> work/revB/slotdev.json"""
import sys, os, json
import numpy as np
import open3d as o3d
from common import W, load

CTR = {"S1": (27.03, 271.70), "S2": (49.02, 271.70)}
v, f = load()
out = {}
scenes = {}
for tag, p in (("revA", sys.argv[1]), ("revB", sys.argv[2])):
    m = o3d.io.read_triangle_mesh(p); m.remove_duplicated_vertices()
    s = o3d.t.geometry.RaycastingScene(); s.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m)); scenes[tag] = s
for k, (cx, cy) in CTR.items():
    r = np.hypot(v[:, 0] - cx, v[:, 1] - cy)
    sel = (r < 3.0) & (v[:, 2] > 78.5) & (v[:, 2] < 85.1)
    P = v[sel].astype(np.float32)
    row = {"n": int(len(P))}
    for tag, s in scenes.items():
        d = s.compute_signed_distance(o3d.core.Tensor(P)).numpy()
        a = np.abs(d)
        row[tag] = dict(mean=round(float(d.mean()), 3), p50=round(float(np.percentile(a, 50)), 3), p90=round(float(np.percentile(a, 90)), 3),
                        p95=round(float(np.percentile(a, 95)), 3), within_0p2=round(float((a <= 0.2).mean()), 3),
                        within_0p5=round(float((a <= 0.5).mean()), 3), max=round(float(a.max()), 3))
    out[k] = row
    print(k, json.dumps(row))
json.dump(out, open(os.path.join(W, "revB", "slotdev.json"), "w"), indent=1)
