"""Seam-groove centre lines from the fine-fit residual: points with res < -0.2 (groove bottoms) in (y, th),
clustered into polylines. Writes work/groove_pts.npz + figure."""
import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import ndimage
from common import W
d = np.load(W + r"\skin_data.npz"); D = d["D"]; mask = d["mask"]
g = np.load(W + r"\seam_grid.npz"); res1 = g["res1"]
y_, t_ = D[:, 0], np.degrees(D[:, 1])
m = mask & (res1 < -0.2)
# raster in (y, th) 1mm x 0.5deg
gy = np.round(y_[m] + 72).astype(int); gt = np.round((t_[m] + 182) / 0.5).astype(int)
G = np.zeros((int(y_.max() + 74), 370), bool); G[gy, gt] = True
G = ndimage.binary_closing(G, structure=np.ones((3, 3)), iterations=2)
lab, n = ndimage.label(G, structure=np.ones((3, 3)))
sizes = ndimage.sum(G, lab, range(1, n + 1))
fig, ax = plt.subplots(figsize=(24, 10))
keep = []
for k in np.argsort(sizes)[::-1]:
    if sizes[k] < 40: break
    yy, tt = np.where(lab == k + 1)
    keep.append(k + 1)
    ax.plot(yy - 72, tt * 0.5 - 182, ".", ms=1, label=f"{k+1}: {int(sizes[k])}")
    print("component", k + 1, "cells", int(sizes[k]), "y", yy.min() - 72, yy.max() - 72, "th", tt.min() * 0.5 - 182, tt.max() * 0.5 - 182)
ax.legend(markerscale=10); ax.grid(True); ax.set_xticks(np.arange(-70, 290, 10))
fig.tight_layout(); fig.savefig(W + r"\grooves.png", dpi=70)
np.savez(W + r"\groove_lab.npz", lab=lab, keep=np.array(keep))
