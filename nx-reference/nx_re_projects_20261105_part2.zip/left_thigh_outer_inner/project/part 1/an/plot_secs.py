import json, numpy as np, matplotlib, sys
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.interpolate import BSpline
from common import W, load, section
d = json.load(open(W + "\\" + (sys.argv[3] if len(sys.argv) > 3 else "sections") + ".json"))
v, f = load()
sel = [s for s in d["sections"] if s["y"] <= float(sys.argv[1])][: int(sys.argv[2])] if len(sys.argv) > 2 else d["sections"][:8]
fig, axs = plt.subplots(2, 4, figsize=(28, 13)); axs = axs.ravel()
for ax, s in zip(axs, sel):
    sp = BSpline(np.array(s["knots"]), np.array(s["poles"]), 3); u = np.linspace(0, 1, 800); P = sp(u)
    seg = section(v, f, 1, s["y"])[:, :, [0, 2]]
    from matplotlib.collections import LineCollection
    ax.add_collection(LineCollection(seg, colors="k", lw=0.6)); ax.plot(P[:, 0], P[:, 2], "r-", lw=0.8)
    ax.set_aspect("equal"); ax.autoscale(); ax.grid(True); ax.set_title(f"y={s['y']} err {s['err']:.3f}")
fig.tight_layout(); fig.savefig(W + r"\secs_check.png", dpi=60)
