"""Fit the parting plane (rim top) in the raw frame; report residual levels in the plane frame."""
import numpy as np, json
from common import load, tri_data, fit_plane_robust

v, f = load(frame=False)
c, n, a = tri_data(v, f)
m = (n[:, 2] > 0.99) & (c[:, 2] > -3.6) & (c[:, 2] < -0.3)
p = c[m]
cc, nn, sd, keep = fit_plane_robust(p)
if nn[2] < 0: nn = -nn
print("plane pt", cc, "normal", nn, "sd", sd, "kept", keep.sum(), "/", len(p))
# iterate: facets whose normal within 2 deg of nn and within 0.4 mm of plane
for it in range(3):
    d = (c - cc) @ nn
    m2 = (n @ nn > np.cos(np.radians(2))) & (np.abs(d) < 0.4)
    cc, nn, sd, keep = fit_plane_robust(c[m2])
    if nn[2] < 0: nn = -nn
    print(it, "normal", nn, "sd", sd, "n", m2.sum(), "area", a[m2].sum())
tilt = np.degrees(np.arccos(nn[2]))
print("tilt from Z deg", tilt, "about X", np.degrees(np.arctan2(nn[1], nn[2])), "about Y", np.degrees(np.arctan2(nn[0], nn[2])))
# level histogram of all up/down facets relative to the plane
d = (c - cc) @ nn
for sgn in (1, -1):
    mm = (n @ nn) * sgn > 0.995
    h, e = np.histogram(d[mm], bins=np.arange(-140, 140, 0.2), weights=a[mm])
    print("facing", sgn)
    for i in np.where(h > 25)[0]:
        print(f"   {e[i]+0.1:8.2f} {h[i]:7.0f}")
json.dump(dict(c=cc.tolist(), n=nn.tolist(), sd=sd), open(r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\work\parting_raw.json", "w"))
