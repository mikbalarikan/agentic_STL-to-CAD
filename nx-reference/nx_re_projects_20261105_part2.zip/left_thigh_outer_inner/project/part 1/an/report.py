﻿"""Write the delivery REPORT.md from the json results.  usage: report.py deliver_dir dev_tag"""
import sys, os, json
from common import W

DST, TAG = sys.argv[1], sys.argv[2]
fin = json.load(open(os.path.join(DST, "_finalize.json")))
dev = json.load(open(os.path.join(W, f"dev2_{TAG}.json")))
P = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))


def row(name, s):
    return f"| {name} | {s['n']:,} | {s['mean']:+.3f} | {s['p50']:.3f} | {s['p90']:.3f} | {s['p95']:.3f} | {100*s['within_0p2']:.1f} % | {100*s['within_0p5']:.1f} % |"


L = []
L += ["# LT-OUT-001 Left Thigh - Outer shell: reverse-engineering report", "",
      "Source: `SHARE -  Left Thigh - Outer.stl` (7 266 929 triangles, 3D-scan mesh, open in places).",
      "Native CAD: Siemens NX 2206, solid body `LEFT_THIGH_OUTER`, rebuilt feature by feature on the scan (not a mesh conversion).", "",
      "## Part data", "",
      f"- Volume {fin['volume_mm3']:,.0f} mm3, mass {fin['mass_g_al6061']/1000:.3f} kg in Al 6061 (2.70 g/cm3).",
      f"- Bounding box (model frame) {fin['bbox']}.",
      "- Model frame: origin on the knee-bore axis at the knee-floor plane; +Z = knee axis toward the open side;",
      "  +Y = direction of the hip-ring axis (knee -> hip); X completes a right-handed frame.",
      "", "## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)", "",
      "| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |", "|---|---|---|---|---|---|---|---|"]
for k, nm in (("all", "whole part"), ("outer_skin", "outer freeform skin"), ("knee_hub", "knee hub (r < 70)"),
              ("hip_ring", "hip ring / plate (y > 262)"), ("interior", "interior (ribs, pockets, bosses)")):
    L.append(row(nm, dev["scan_to_cad"][k]))
c = dev["cad_to_scan"]["all"]
L += ["", f"CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 {c['p50']:.3f}, p90 {c['p90']:.3f}, p95 {c['p95']:.3f} mm.", ""]
open(os.path.join(DST, "REPORT_deviation.md"), "w", encoding="utf-8").write("\n".join(L))
print("\n".join(L))
