﻿"""Rev B renders of the CAD STL (pyvista, off-screen): the five Rev A view names plus a close-up of the two hip-end
locating slots. usage: b8_renders.py cad.stl out_dir"""
import os, sys
import numpy as np
import pyvista as pv

stl, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
m = pv.read(stl)
c = np.array(m.center)
VIEWS = {  # name: (focus, direction from focus to camera, distance, up)
    "LT-OUT-001_iso_top": (c, (-0.55, -0.6, 0.75), 660, (0, 0, 1)),
    "LT-OUT-001_iso_top2": (c, (0.6, 0.55, 0.7), 660, (0, 0, 1)),
    "LT-OUT-001_iso_bottom": (c, (-0.5, -0.55, -0.7), 660, (0, 0, 1)),
    "LT-OUT-001_side_px": (c, (1, 0, 0), 600, (0, 0, 1)),
    "LT-OUT-001_hip_end": ((38.0, 262.0, 40.0), (0.35, 0.75, 0.55), 330, (0, 0, 1)),
    "LT-OUT-001_RevB_hip_slots": ((38.0, 271.7, 84.0), (-0.15, -0.55, 0.82), 75, (0, 1, 0)),
}
for name, (foc, d, dist, up) in VIEWS.items():
    d = np.array(d, float); d /= np.linalg.norm(d)
    p = pv.Plotter(off_screen=True, window_size=(1800, 1400))
    p.set_background("white")
    p.add_mesh(m, color="#b4b9bf", smooth_shading=True, specular=0.35, ambient=0.25, split_sharp_edges=True)
    p.enable_anti_aliasing("ssaa")
    p.camera_position = [tuple(np.array(foc) + d * dist), tuple(foc), tuple(up)]
    p.camera.view_angle = 30
    p.screenshot(os.path.join(out, name + ".png"))
    p.close()
    print("wrote", name)
