import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
d = np.load(W + r"\polar.npz"); ys, th, R, xc = d["ys"], np.degrees(d["th"]), d["R"], d["xc"]
fig, ax = plt.subplots(1, 3, figsize=(24, 12))
im = ax[0].imshow(R[:, :, 0].T, origin="lower", aspect="auto", extent=[ys[0], ys[-1], th[0], th[-1]], cmap="viridis"); plt.colorbar(im, ax=ax[0]); ax[0].set_title("R1 outer")
t = R[:, :, 0] - R[:, :, 1]
im = ax[1].imshow(np.clip(t, 0, 8).T, origin="lower", aspect="auto", extent=[ys[0], ys[-1], th[0], th[-1]], cmap="jet"); plt.colorbar(im, ax=ax[1]); ax[1].set_title("R1-R2 wall")
g = np.gradient(R[:, :, 0], axis=1)
im = ax[2].imshow(np.clip(np.gradient(g, axis=1), -0.5, 0.5).T, origin="lower", aspect="auto", extent=[ys[0], ys[-1], th[0], th[-1]], cmap="seismic"); plt.colorbar(im, ax=ax[2]); ax[2].set_title("d2R/dth2")
for a in ax: a.set_xlabel("y"); a.set_ylabel("theta deg"); a.grid(True, lw=0.3)
fig.tight_layout(); fig.savefig(W + r"\polar_map.png", dpi=80)
