"""Seam-groove centre lines: anchor polylines in (y, theta) refined to the residual minimum, mapped onto the
fitted skin and lifted by LIFT along the outward normal (tube centre). Writes work/grooves.json."""
import json
import numpy as np
from scipy.interpolate import BSpline
from scipy.ndimage import gaussian_filter1d
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W

LIFT = 0.35
ANCH = {
    "G1": [(25, 3), (25, -2), (27, -12), (35, -20), (60, -37), (100, -63), (150, -95), (194, -118.5)],
    "G2": [(140, -178), (141, -160), (146, -145), (160, -133), (190, -121), (230, -107), (255, -96), (268, -85),
           (272, -70), (270, -58), (262, -47), (240, -41), (215, -35), (200, -33)],
    "G3": [(58, 3), (58, -18), (62, -22), (75, -30), (100, -36), (130, -39), (168, -38.5), (190, -36), (205, -33),
           (228, -31), (245, -25), (255, -15), (258, -2), (258, 3)],
}
d = np.load(W + r"\skin_data.npz"); D = d["D"]; mask = d["mask"]
g = np.load(W + r"\seam_grid.npz"); res1 = g["res1"]
y_, t_ = D[:, 0], np.degrees(D[:, 1])
ok = mask & np.isfinite(res1)
# grid res1 (1 mm x 0.5 deg)
GY = np.round(y_ + 72).astype(int); GT = np.round((t_ + 182) / 0.5).astype(int)
R = np.full((GY.max() + 2, 372), np.nan); R[GY[ok], GT[ok]] = res1[ok]
s = np.load(W + r"\skin_fit.npz"); ty, tt, C, pc, ZC = s["ty"], s["tt"], s["C"], s["pc"], float(s["ZC"])


def r_of(y, th):
    return BSpline(tt, BSpline(ty, C, 3)(y), 3)(np.clip(th, tt[3], tt[-4]))


def P3(y, thd):
    th = np.radians(thd); r = r_of(y, th)
    return np.array([np.polyval(pc, y) + r * np.cos(th), y, ZC + r * np.sin(th)])


def normal(y, thd):
    e = 0.05
    a = P3(y + e, thd) - P3(y - e, thd); b = P3(y, thd + e) - P3(y, thd - e)
    n = np.cross(a, b); n /= np.linalg.norm(n)
    c = np.array([np.polyval(pc, y), y, ZC])
    if n @ (P3(y, thd) - c) < 0: n = -n
    return n


out = {}
fig, ax = plt.subplots(figsize=(24, 10))
ax.imshow(np.clip(R.T, -0.5, 0.3), origin="lower", extent=[-72, R.shape[0] - 72, -182, 4], aspect="auto", cmap="gray")
for name, an in ANCH.items():
    A = np.array(an, float)
    # resample every ~1 mm of arc (theta scaled by ~60 mm/rad)
    seg = np.r_[0, np.cumsum(np.hypot(np.diff(A[:, 0]), np.diff(A[:, 1]) * 1.05))]
    ss = np.arange(0, seg[-1], 1.0)
    Q = np.c_[np.interp(ss, seg, A[:, 0]), np.interp(ss, seg, A[:, 1])]
    # refine: search perpendicular (in y, th*1.05 space) for the residual minimum within +-3
    T = np.gradient(Q, axis=0); T /= np.linalg.norm(T, axis=1)[:, None] + 1e-12
    Nn = np.c_[-T[:, 1], T[:, 0]]
    Qr = Q.copy(); found = np.zeros(len(Q), bool)
    for i, (q, nn) in enumerate(zip(Q, Nn)):
        if q[1] > -2.5:
            continue
        best = None
        for k in np.linspace(-3, 3, 25):
            p = q + k * nn * np.array([1.0, 1 / 1.05])
            iy, it = int(round(p[0] + 72)), int(round((p[1] + 182) / 0.5))
            if 0 <= iy < R.shape[0] and 0 <= it < R.shape[1] and np.isfinite(R[iy, it]):
                if best is None or R[iy, it] < best[0]:
                    best = (R[iy, it], p)
        if best is not None and best[0] < -0.15:
            Qr[i] = best[1]; found[i] = True
    Qs = np.c_[gaussian_filter1d(Qr[:, 0], 2.0, mode="nearest"), gaussian_filter1d(Qr[:, 1], 2.0, mode="nearest")]
    pts = np.array([P3(y, t) + LIFT * normal(y, t) for y, t in Qs])
    keep = np.r_[np.arange(0, len(pts), 3), len(pts) - 1]
    out[name] = dict(pts=pts[np.unique(keep)].tolist(), found=float(found.mean()), n=int(len(pts)))
    ax.plot(Qs[:, 0], Qs[:, 1], "-", lw=1.2, label=f"{name} found {found.mean():.0%}")
    print(name, "points", len(pts), "refined share", round(found.mean(), 2))
ax.legend(); ax.set_xlim(-72, 290); ax.grid(True, lw=0.3)
fig.tight_layout(); fig.savefig(W + r"\groove_paths.png", dpi=70)
json.dump(dict(lift=LIFT, tube_d=1.8, paths=out), open(W + r"\grooves.json", "w"))
