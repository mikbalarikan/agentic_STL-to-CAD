# LT-OUT-001 Rev B Left Thigh - Outer shell: reverse-engineering report

Source: `SHARE -  Left Thigh - Outer.stl` (7 266 929 triangles, 3D-scan mesh, open in places).
Native CAD: Siemens NX 2206, solid body `LEFT_THIGH_OUTER`, rebuilt feature by feature on the scan (not a mesh conversion).

## Part data

- Volume 385,752 mm3, mass 1.042 kg in Al 6061 (2.70 g/cm3).
- Bounding box (model frame) [-68.995, -67.85, -40.806, 118.934, 288.708, 85.2].
- Model frame: origin on the knee-bore axis at the knee-floor plane; +Z = knee axis toward the open side;
  +Y = direction of the hip-ring axis (knee -> hip); X completes a right-handed frame.

## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)

| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |
|---|---|---|---|---|---|---|---|
| whole part | 1,500,000 | +0.076 | 0.053 | 0.540 | 0.981 | 79.8 % | 89.3 % |
| outer freeform skin | 402,851 | +0.016 | 0.021 | 0.206 | 0.352 | 89.7 % | 97.4 % |
| knee hub (r < 70) | 310,365 | +0.053 | 0.113 | 0.670 | 0.937 | 69.3 % | 83.9 % |
| hip ring / plate (y > 262) | 245,389 | +0.157 | 0.047 | 0.473 | 1.114 | 84.9 % | 90.3 % |
| interior (ribs, pockets, bosses) | 541,395 | +0.098 | 0.082 | 0.825 | 1.459 | 76.3 % | 85.8 % |

CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 0.066, p90 1.017, p95 1.996 mm.

## Rev B change: the two hip-end locating slots

Rev B differs from Rev A only by the two locating slots S1 / S2 (Ø4.30 x 6.00 deep at X 27.03 / 49.02, Y 271.70,
from the hip-ring top Z 85.20). Removed volume 190.9 mm3 (NX); the other zones above are identical to Rev A,
and the hip-ring zone is slightly closer to the scan (Rev A: p90 0.485, p95 1.128, 90.2 % within 0.5).

Scan points within 3 mm of a slot axis, Z 78.5 to 85.1 (signed, full-resolution scan):

| slot | points | Rev A p50 | Rev A p95 | Rev A within 0.5 | Rev B p50 | Rev B p95 | Rev B within 0.5 |
|---|---|---|---|---|---|---|---|
| S1 (X 27.03) | 1,254 | 0.338 | 2.073 | 55.5 % | 0.190 | 1.023 | 86.0 % |
| S2 (X 49.02) | 1,178 | 0.389 | 2.020 | 54.8 % | 0.191 | 1.019 | 83.1 % |

What is left at the slots is intended. The scanned slots measure Ø3.95, and the CAD is Ø4.30 to clear the scanned
Ø4.08 bumps of the inner shell by at least 0.1 mm per side. The scan does not reach the slot floors. The CAD -> scan
p90 / p95 rise slightly (1.005 / 1.978 -> 1.017 / 1.996) because the new slot walls and floors have no scan data under them.

## Fit with LT-INN-001 (inner with its two locating bumps, AP242, 2026-10-30)

Both STEP files were read with OpenCascade (inner `LT-INN-001_Left_Thigh_Inner_AP242.step`, this part's AP214):

- Interference (boolean common): 0.0 mm3. Minimum distance 0.0 mm (the 7 boss faces touch face to face).
- 21 mating pairs concentric (7 Ø10 pockets / nubs, 3 Ø4 pin holes / pins, 7 screw holes / boss holes, boss columns),
  largest axis offset 0.0 mm. Of 23,616 inner joint-band points, 0 are inside the outer.
- Locating bumps: both sit in slots S1 / S2. Clearance to the slot wall is 0.19 mm at S1 and 0.13 mm at S2, and
  0.19 / 0.16 mm under the bump tips. No bump point is inside the outer.
