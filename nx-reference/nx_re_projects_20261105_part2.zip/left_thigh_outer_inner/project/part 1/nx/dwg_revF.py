# -*- coding: utf-8 -*-
"""LT-OUT-001 Left Thigh - Outer shell, REV F drawing set (dwg_revF.py <- nx/dwg_revC.py; third angle).
Rev F (2026-11-02): interior ribs (RIBS_INNER + R2/R3B/R4 ribs) with measured thicknesses and the -X side-wall
window WIN_SIDE_CUT on a new SH5; SH4 feature table rebuilt from the MODEL (bosses, pins, holes, lugs, F1/F3/F5/F6,
M1, K1, T1/T2, S1/S2): every position / diameter / depth / top level is read from the model faces in this run;
knee datum face A now Z -8.25, knee OD band R68.05 (overall length 355.45 on the 06:45 part).
run_journal dwg_revF.py -args <model.prt> <out_dir> [dump|full]
The drawing part is saved WITHOUT its component (nxh.save patched): the model prt is never written.
Master-model drawing: the model is placed with drawing (X, Y, Z) = model (y, -x, z), so the length runs left
(knee) to right (hip) in the plan view. M(x, y, z) maps a MODEL point to drawing-part coordinates.
Datum system: A = knee mounting face (Z -8.35), B = knee bore Ø110 H7, C = hip bore Ø82 H7, D = hip outer face.
Dimension text 5 mm, every dimension text placed outside the part outline; GD&T frames instead of note text;
SH4 features identified by arrow balloons placed outside the part."""
import json
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1\nx\dwglib")
import NXOpen  # noqa: E402
import NXOpen.Annotations  # noqa: E402
import nxh  # noqa: E402
import nxd  # noqa: E402
import nxd2  # noqa: E402
import ptdwg  # noqa: E402
import m3d  # noqa: E402
import gdt  # noqa: E402
from m3d import D, N, xy  # noqa: E402

MODEL, OUTD = sys.argv[1], sys.argv[2]
MODE = sys.argv[3] if len(sys.argv) > 3 else "full"
os.makedirs(OUTD, exist_ok=True)
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 1"
NO, TITLE = "LT-OUT-001", "LEFT THIGH - OUTER SHELL"
PJ = json.load(open(os.path.join(ROOT, "nx", "params.json")))
OUTLINE = json.load(open(os.path.join(ROOT, "work", "plan_outline.json")))
FIN = json.load(open(os.path.join(os.path.dirname(MODEL), "_finalize.json")))
MASS = "%.2f kg" % (FIN["mass_g_al6061"] / 1000.0)
MAT = "Al 6061-T6"
R = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]]
S = nxd.SNAP
A = NXOpen.Annotations
DT = 5.0        # dimension text
GT = 4.5        # notes, GD&T frames, datum letters
res = {"result": "FAIL", "dims": {}, "errors": {}, "gdt": {}}
m3d.start(res)
HX, HZ = PJ["hip"]["ax_x"], PJ["hip"]["ax_z"]
DIA = "Ø"

# never write the model: save the drawing part only
nxh.save = lambda part: part.Save(NXOpen.BasePart.SaveComponents.FalseValue, NXOpen.BasePart.CloseAfterSave.FalseValue).Dispose()

# every ptdwg dimension (linear / radius) gets the larger text
_style0 = ptdwg._style
ptdwg._style = lambda b, prec=2, text_size=None: _style0(b, prec, text_size or DT)


def M(x, y, z):
    return (y, -x, z)


def straight(view, pred):
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 3 and pred(p[0], p[1]):
            out.append((c, p))
    return out


def longest(cands):
    if not cands:
        raise RuntimeError("no curve")
    return max(cands, key=lambda cp: sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)))[0]


def at(ax, val, tol=0.05):
    return lambda p0, p1: abs(p0[ax] - val) <= tol and abs(p1[ax] - val) <= tol


def dimc(name, view, ca, cb, origin, method, expect, etol=0.05, **kw):
    return D(name, lambda: m3d.dim_curves(view, ca, cb, origin, method, expect=expect, etol=etol, **kw))


def arc_xy(view, centre, r, skip, tol=0.08):
    """Circular drafting curve of radius r whose centre matches `centre` (drawing coords) in the two axes other
    than `skip` (the view direction). Among several (top / bottom edge) the one nearest the viewer wins."""
    best = None
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) != 2:
            continue
        rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
        if abs(rr - r) > tol:
            continue
        if max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip) > tol:
            continue
        if best is None or p[0][skip] > best[1][skip]:
            best = (c, p[0])
    if best is None:
        near = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) != 2:
                continue
            rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
            dc = max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip)
            if dc < 1.0 and 0.4 * r < rr < 2.5 * r:
                near.append((abs(rr - r), -p[0][skip], c, p[0], round(rr, 3)))
        if near:
            near.sort(key=lambda t: (round(t[0], 2), t[1]))
            res.setdefault("arc_fallback", []).append([view.Name, [round(v, 2) for v in centre], r, near[0][4]])
            return near[0][2], near[0][3]
        cand = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) == 2:
                rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
                cand.append((max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip), [round(v, 2) for v in p[0]], round(rr, 3)))
        cand.sort(key=lambda t: t[0])
        raise RuntimeError("arc_xy: no R%.3f at %s in %s; nearest %s" % (r, [round(v, 2) for v in centre], view.Name, cand[:6]))
    return best


def arc_dir(view, r, toward, tol=0.02):
    """Partial arc (start, end, centre, mid) about the drawing origin of radius r whose span contains the direction
    `toward` (drawing x, y); the highest one wins."""
    best = None
    ang = math.atan2(toward[1], toward[0])
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) != 4 or math.hypot(p[2][0], p[2][1]) > 0.05 or abs(math.dist(p[2][:2], p[0][:2]) - r) > tol:
            continue
        a0, a1, am = (math.atan2(q[1], q[0]) for q in (p[0], p[1], p[3]))

        def within(x, lo, hi):
            return (x - lo) % (2 * math.pi) <= (hi - lo) % (2 * math.pi)
        lo, hi = (a0, a1) if within(am, a0, a1) else (a1, a0)
        if within(ang, lo, hi) and (best is None or p[0][2] > best[1]):
            best = (c, p[0][2])
    if best is None:
        raise RuntimeError("arc_dir: no R%.3f arc toward %s" % (r, toward[:2]))
    return best[0]


def on_arc(centre, r, skip, toward):
    """Point of the arc (drawing coords) in the direction of `toward` (drawing coords, same plane)."""
    ax = [i for i in range(3) if i != skip]
    dx, dy = toward[ax[0]] - centre[ax[0]], toward[ax[1]] - centre[ax[1]]
    n = math.hypot(dx, dy) or 1.0
    p = list(centre)
    p[ax[0]] += r * dx / n
    p[ax[1]] += r * dy / n
    return tuple(p)


def lin(view, ca, cb, origin, method, sa, sb, before=None, after=None, basic=False, tol=None, expect=None, etol=0.05):
    """Linear dimension with explicit snaps; basic=True draws it boxed (theoretically exact)."""
    meth = {"horizontal": nxd.MM.Horizontal, "vertical": nxd.MM.Vertical, "point": nxd.MM.PointToPoint,
            "cylindrical": nxd.MM.Cylindrical}[method]
    dwg = m3d.CTX["dwg"]
    b = dwg.Dimensions.CreateLinearDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = meth
        b.FirstAssociativity.SetValue(sa, ca, view, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(sb, cb, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=tol, before=before, after=after)
        _style0(b, 2, DT)
        if basic:
            b.Style.DimensionStyle.ToleranceType = A.ToleranceType.Basic
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if expect is not None and abs(d.ComputedSize - expect) > etol:
        v = d.ComputedSize
        ptdwg._delete([d])
        raise RuntimeError("lin: %.4f instead of %.4f" % (v, expect))
    return d


def dia_callout(view, arc, origin, before=None, after=None, tol=None):
    return nxd.dim_radial(m3d.CTX["dwg"], view, arc, origin, diameter=True, before=before, after=after, tol=tol,
                          text_size=DT)


def stack_fcf(name, dim, char, tol, datums=(), dia=False, pos=None):
    """FCF stacked under a dimension (NX 'attached to stack' origin); fallback: free FCF at `pos`."""
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
            try:
                b.Characteristic = gdt.characteristic(char)
                b.FrameStyle = A.FeatureControlFrameBuilder.FcfFrameStyle.SingleFrame
                b.FeatureControlFrameDataList.Append(dwg.Annotations.CreateFeatureControlFrameDataBuilder(None))
                d = b.FeatureControlFrameDataList.FindItem(0)
                if dia:
                    d.ZoneShape = A.FeatureControlFrameDataBuilder.ToleranceZoneShape.Diameter
                d.ToleranceValue = str(tol)
                for r_, l_ in zip((d.PrimaryDatumReference, d.SecondaryDatumReference, d.TertiaryDatumReference), datums):
                    r_.Letter = l_
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(dim))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-400:]
            if pos is None:
                raise
            o = gdt.fcf(dwg, char, tol, datums, dia, pos, size=GT)
            res["gdt"][name] = "free"
            return o
    return N(name, f)


def stack_below(ann):
    """Associative origin: stacked below `ann` (probe: only OffsetAnnotation carries the stack parent)."""
    ao = A.Annotation.AssociativeOriginData()
    ao.OriginType = A.AssociativeOriginType.AttachedToStack
    ao.StackAlignmentPosition = A.StackAlignmentPosition.Below
    ao.OffsetAnnotation = ann
    return ao


def datum_under(name, letter, ann, fallback):
    """Datum feature symbol stacked below an FCF / dimension of the datum feature (no leader); fallback()."""
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.Datums.CreateDraftingDatumFeatureSymbolBuilder(None)
            try:
                b.Letter = letter
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(ann))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-300:]
            o = fallback()
            res["gdt"][name] = "leader"
            return o
    return N(name, f)


def callout(name, view, arc, cen, r, skip, toward, lines):
    """Leader note (arrow on the hole edge) at the sheet image of drawing point `toward`."""
    a = on_arc(cen, r, skip, toward)
    pos = xy(view, toward)
    return N(name, lambda: nxd2.leader_note(m3d.CTX["dwg"], lines, pos, arc, view, a, size=DT))


def table(origin, cw, rows, size=3.5, rh=8.0):
    """Tabular note, title row merged and in the same text size as the body."""
    m = [(0, 0, 0, len(cw) - 1)]
    _ts, tn = nxd2.table(m3d.CTX["dwg"], origin, cw, [rh] * len(rows), rows, text_size=size, merges=m, sizes={(0, 0): size})
    return nxd2.table_text(tn)


def note_lines(lines, x, y, step=8.0, size=GT):
    """One note per line (fixed pitch), so a GD&T frame can sit at the end of a given line."""
    for i, t in enumerate(lines):
        if not t:
            continue
        N("note_%d_%d" % (int(x), int(y - i * step)), lambda t=t, i=i: nxd.note(m3d.CTX["dwg"], [t], (x, y - i * step), size=size))


REV = "F"
ptdwg.DATE = "2026-11-02"
SLOT = dict(d=4.30, floor=79.20, top=85.20, y=271.70, xs=(27.03, 49.02), y_step=269.45)


# ======================================================================== model read-back (faces of the model part)
class Model(object):
    """Cylinder and plane faces of every visible solid of the model part (model coordinates)."""

    def __init__(self, prt):
        self.cyl, self.pl = [], []
        self.solids = []
        for b in prt.Bodies:
            if not b.IsSolidBody or b.IsBlanked:
                continue
            self.solids.append(b)
            for f in b.GetFaces():
                t, pt, d, _bx, rad, _rd, nd = nxh.UFS.Modeling.AskFaceData(f.Tag)
                bb = list(nxh.UFS.ModlGeneral.AskBoundingBox(f.Tag))
                if t == 16:
                    self.cyl.append({"r": abs(rad), "pt": list(pt), "dir": list(d), "bb": bb, "nd": nd})
                elif t == 22:
                    self.pl.append({"n": list(d), "d": sum(pt[i] * d[i] for i in range(3)), "bb": bb})

    def vcyl(self, x, y, r, tol=0.3, rtol=0.012, concave=None):
        """Vertical cylinders of radius r whose axis passes within tol of (x, y): [(cx, cy, zmin, zmax, nd)]."""
        out = []
        for c in self.cyl:
            if abs(abs(c["dir"][2]) - 1.0) > 1e-3 or abs(c["r"] - r) > rtol:
                continue
            if math.hypot(c["pt"][0] - x, c["pt"][1] - y) > tol:
                continue
            if concave is not None and (c["nd"] < 0) != concave:
                continue
            out.append((c["pt"][0], c["pt"][1], c["bb"][2], c["bb"][5], c["nd"]))
        return out

    def vc1(self, x, y, r, **kw):
        rows = self.vcyl(x, y, r, **kw)
        if not rows:
            raise RuntimeError("no vertical R%.3f at (%.2f, %.2f)" % (r, x, y))
        return (sum(q[0] for q in rows) / len(rows), sum(q[1] for q in rows) / len(rows),
                min(q[2] for q in rows), max(q[3] for q in rows), rows[0][4])

    def axcyl(self, p, d, r, tol=0.05, rtol=0.012):
        """Cylinders of radius r on the axis (p, d)."""
        out = []
        for c in self.cyl:
            if abs(abs(sum(c["dir"][i] * d[i] for i in range(3))) - 1.0) > 1e-3 or abs(c["r"] - r) > rtol:
                continue
            w = [c["pt"][i] - p[i] for i in range(3)]
            s = sum(w[i] * d[i] for i in range(3))
            if math.sqrt(max(0.0, sum(v * v for v in w) - s * s)) <= tol:
                out.append(c)
        return out

    def hplane(self, x, y, up=True, zmin=-1e9, zmax=1e9, pad=0.05):
        """Z levels of horizontal planar faces whose bbox contains (x, y), facing +Z (up) or -Z."""
        out = []
        for p in self.pl:
            if abs(abs(p["n"][2]) - 1.0) > 1e-4 or (p["n"][2] > 0) != up:
                continue
            z = p["d"] * p["n"][2]
            b = p["bb"]
            if b[0] - pad <= x <= b[3] + pad and b[1] - pad <= y <= b[4] + pad and zmin <= z <= zmax:
                out.append(z)
        return sorted(out)

    def thk(self, x, y, nrm, tol=2.5):
        """Wall / rib thickness at (x, y): nearest pair of opposite vertical planes (normal +-nrm) around the point."""
        V = [p for p in self.pl if abs(p["n"][2]) < 0.05 and abs(abs(p["n"][0] * nrm[0] + p["n"][1] * nrm[1]) - 1.0) < 3e-3
             and p["bb"][0] - tol <= x <= p["bb"][3] + tol and p["bb"][1] - tol <= y <= p["bb"][4] + tol]
        best = None
        for a in V:
            for b in V:
                if a is b or sum(a["n"][k] * b["n"][k] for k in range(3)) > -0.999:
                    continue
                sa = a["n"][0] * x + a["n"][1] * y - a["d"]
                sb = b["n"][0] * x + b["n"][1] * y - b["d"]
                t = abs(a["d"] + b["d"])
                if sa <= 0.05 and sb <= 0.05 and t < 12.0 and (best is None or t < best[0]):
                    na = a["n"]
                    off = 0.5 * (a["d"] - b["d"]) - (na[0] * x + na[1] * y)       # move the seed onto the mid-plane
                    best = (t, max(a["bb"][5], b["bb"][5]), (x + off * na[0], y + off * na[1]))
        if best is None:
            raise RuntimeError("no rib faces at (%.2f, %.2f)" % (x, y))
        return best

    def yplane(self, sign=1):
        """Extreme planar face normal to Y (sign=+1: max Y end face)."""
        ys = [p["d"] * p["n"][1] for p in self.pl if abs(abs(p["n"][1]) - 1.0) < 1e-5]
        return max(ys) if sign > 0 else min(ys)


def ztxt(z):
    """Z level text; NX tables print a lone '0.00' as '-'."""
    return "Z0 (FLOOR)" if abs(z) < 0.005 else "%.2f" % z


MEAS = {}
NSH = 5
PAD = dict(r_in=52.40, r_out=66.20, half=14.0, theta=-109.06, h=4.10, face=276.85, pcr=59.85, s_half=9.08, p_half=2.875,
           tap=3.3, cb_d=7.30, cb_depth=4.00, pin_d=4.05, rc_out=3.0, rc_in=2.0)
PAD["top"] = PAD["face"] + PAD["h"]


def pad_pt(half, r=None, y=None):
    a = math.radians(PAD["theta"] + half)
    r = PAD["pcr"] if r is None else r
    return (PJ["hip"]["ax_x"] + r * math.cos(a), PAD["top"] if y is None else y, PJ["hip"]["ax_z"] + r * math.sin(a))


# ---- Rev F rib seeds: (ID, point on the rib mid-plane, rib normal, description); thickness measured in the model
RIBS = [("U", (-1.0, 109.55), (-1.0, 0.0), "RIB U"),
        ("A", (33.1, 143.88), (-0.985, 0.173), "RIB A"),
        ("B", (64.71, 105.96), (-0.974, 0.228), "RIB B"),
        ("C", (35.5, 165.92), (-0.0104, 0.99995), "RIB C (WITH CEXT)"),
        ("D", (37.9, 238.65), (-1.0, 0.0), "RIB D (UNDER FLOOR)"),
        ("G1", (68.1, 42.44), (-0.682, -0.731), "RIB G1"),
        ("G2", (-10.5, 78.61), (0.0055, -1.0), "RIB G2"),
        ("H", (-22.04, 242.1), (-1.0, 0.0), "RIB H, R3 TOP END"),
        ("I", (97.92, 242.1), (-1.0, 0.0), "RIB I, R3 TOP END"),
        ("G1M", (-20.0, 61.5), (-0.9, -0.436), "RIB G1M"),
        ("G18", (85.0, 131.4), (0.0, -1.0), "RIB G18"),
        ("R1", (97.6, 194.41), (0.0, -1.0), "RIB R1 (B2), WALL TO POST"),
        ("F2A", (89.5, 100.2), (0.199, 0.98), "SENSOR RIB WALL F2A"),
        ("F4A", (60.92, 24.01), (-0.36666, 0.93035), "RADIAL RIB F4A"),
        ("F4B", (51.75, -33.78), (-0.54654, -0.83743), "RADIAL RIB F4B"),
        ("F6", (-33.5, -53.5), (0.84805, -0.52992), "LOBE RIB F6, R4.15 END")]


def rev_block():
    """Revision block on top of the title block (same 180 mm width): REV / DESCRIPTION / DATE / BY."""
    x0, y0, x1, y1 = ptdwg.FRAME["A1"]
    rows = [["REV", "DESCRIPTION", "DATE", "BY"],
            ["A", "FIRST ISSUE", "2026-10-25", "MIA"],
            ["F", "INTERIOR RIBS, SIDE WINDOW, BOSSES/LUGS/PINS, HIP RING WALL, WALL OFFSETS", "2026-11-02", "MIA"]]
    top = y0 + 47.0 + 6.0 * len(rows) + 1.0
    _ts, tn = nxd2.table(m3d.CTX["dwg"], (x1 - 180.0, top), [10.0, 138.0, 19.0, 13.0], [6.0] * len(rows), rows, text_size=2.0)
    return nxd2.table_text(tn)


def relabel(view, letter):
    """Letter of a section / detail view label (NX hands out the next free letter, which can be a datum letter):
    EditViewLabelSettingsBuilder.ViewCommonViewLabel.Letter on the label from UF Draw.AskViewLabel."""
    def f():
        lab = NXOpen.TaggedObjectManager.GetTaggedObject(nxh.UFS.Draw.AskViewLabel(view.Tag))
        b = m3d.CTX["dwg"].SettingsManager.CreateDrawingEditViewLabelSettingsBuilder([lab])
        try:
            b.ViewCommonViewLabel.Letter = letter
            b.Commit()
        finally:
            b.Destroy()
        return letter
    return N("label_%s_%s" % (view.Name, letter), f)


def text_w(t, size=GT):
    return len(t) * 0.745 * size


# ======================================================================== Rev F feature read-back + balloons
def arc_target(view, x, y, z, r):
    """Balloon target = the circle of radius r about the vertical axis (x, y) in a plan view."""
    def f(xb, yb):
        c, cen = arc_xy(view, M(x, y, z), r, 2, 0.12)
        return c, on_arc(cen, r, 2, M(xb, yb, cen[2]))
    return f


def near_target(view, x, y, z):
    def f(xb, yb):
        c, p = ptdwg.near(view, M(x, y, z))
        return c, p
    return f


def rib_target(view, x, y, nrm, t):
    """Balloon target on a rib: the visible straight edge parallel to the rib (drawing coords), within t/2 of the
    mid-plane point (x, y), the seed projected onto it (highest Z wins)."""
    u = (-nrm[1], nrm[0])                    # rib direction, model
    ud = (u[1], -u[0])                       # drawing (X_d = y, Y_d = -x)
    sd = (y, -x)

    def f(xb, yb):
        best = None
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) != 3:
                continue
            dx, dy = p[1][0] - p[0][0], p[1][1] - p[0][1]
            L = math.hypot(dx, dy)
            if L < 2.0 or abs(dx / L * ud[1] - dy / L * ud[0]) > 0.03:
                continue
            s = ((sd[0] - p[0][0]) * dx + (sd[1] - p[0][1]) * dy) / (L * L)
            s = min(0.95, max(0.05, s))
            q = (p[0][0] + s * dx, p[0][1] + s * dy)
            dist = math.hypot(q[0] - sd[0], q[1] - sd[1])
            if dist > t / 2.0 + 0.3:
                continue
            z = p[0][2] + s * (p[1][2] - p[0][2])
            key = (round(dist, 1), -z)
            if best is None or key < best[0]:
                best = (key, c, (q[0], q[1], z))
        if best is None:
            raise RuntimeError("rib_target: no edge for rib at (%.2f, %.2f)" % (x, y))
        return best[1], best[2]
    return f


def feature_rows(view):
    """SH4 table rows + balloon list, every value read from the model faces."""
    rows, feats = [], []
    rep = MEAS.setdefault("features", {})

    def add(fid, x, y, desc, top, hole, tgt, z=0.0):
        rows.append([fid, "%.2f" % x, "%.2f" % y, desc, top, hole])
        feats.append((fid, x, y, z, tgt))
        rep[fid] = rows[-1][1:]

    def tryf(fid, fn):
        try:
            fn()
        except Exception:  # noqa: BLE001
            res["errors"]["feat_" + fid] = traceback.format_exc()[-400:]

    for i, b in enumerate(PJ["bosses"], 1):
        if i == 1:
            continue                                        # B1 is now the F5 column + hub

        def fb(i=i, b=b):
            hx, hy, hz0, hz1, _ = MD.vc1(b["x"], b["y"], 2.6, concave=True)
            sx_, sy_, sz0, sz1, _ = MD.vc1(hx, hy, 5.0, concave=False)
            MD.vc1(hx, hy, 7.5, tol=0.8)
            add("B%d" % i, hx, hy, "BOSS %s15, SPIGOT %s10" % (DIA, DIA), "%.2f / %.2f" % (sz0, sz1),
                "%s5.20 x %.2f DEEP" % (DIA, sz1 - hz0), arc_target(view, sx_, sy_, sz1, 5.0), sz1)
        tryf("B%d" % i, fb)

    def f5():
        hx, hy, hz0, hz1, _ = MD.vc1(61.3, -40.05, 2.6, concave=True)
        ux, uy, uz0, uz1, _ = MD.vc1(hx, hy, 5.0, concave=False)
        MD.vc1(hx, hy, 7.5, tol=0.8)
        add("F5", ux, uy, "COLUMN R7.5 + HUB %s10 (WAS B1)" % DIA, "%.2f / %.2f" % (uz0, uz1), "%s5.20 x %.2f DEEP" % (DIA, uz1 - hz0),
            arc_target(view, ux, uy, uz1, 5.0), uz1)
    tryf("F5", f5)
    for i, p in enumerate(PJ["pins"], 1):
        def fp(i=i, p=p):
            px, py, pz0, pz1, _ = MD.vc1(p["x"], p["y"], 2.0, concave=False)
            MD.vc1(px, py, 4.5, tol=0.5)
            top = max(MD.hplane(px, py, up=True, zmin=pz1 - 0.01, zmax=pz1 + 3.0) or [pz1])
            add("P%d" % i, px, py, "PIN %s4 ON BOSS %s9" % (DIA, DIA), "%.2f" % top, "-", arc_target(view, px, py, pz1, 2.0), pz1)
        tryf("P%d" % i, fp)

    def fp4():
        px, py, pz0, pz1, _ = MD.vc1(-56.73, 19.57, 1.5, concave=False)
        MD.vc1(-56.5, 19.4, 3.375, tol=0.5)
        top = max(MD.hplane(px, py, up=True, zmin=pz1 - 0.01, zmax=pz1 + 3.0) or [pz1])
        add("P4", px, py, "PIN %s3 ON BOSS %s6.75" % (DIA, DIA), "%.2f" % top, "-", arc_target(view, px, py, pz1, 1.5), pz1)
    tryf("P4", fp4)

    def f6():
        px, py, pz0, pz1, _ = MD.vc1(-30.9, -51.2, 1.6, concave=False)
        top = max(MD.hplane(px, py, up=True, zmin=pz1 - 0.01, zmax=pz1 + 3.0) or [pz1])
        add("F6", px, py, "PIN %s3.2 ON LOBE RIB END" % DIA, "%.2f" % top, "-", arc_target(view, px, py, pz1, 1.6), pz1)
    tryf("F6", f6)

    def f1():
        bx, by, bz0, bz1, _ = MD.vc1(94.6, 206.6, 3.2, concave=False)
        add("F1", bx, by, "BOSS %s6.4 UNDER K1" % DIA, "%.2f" % bz1, "-", near_target(view, bx + 3.2, by, bz0), bz1)
    tryf("F1", f1)

    def k1():
        hx, hy, hz0, hz1, _ = MD.vc1(94.42, 206.92, 1.35, concave=True)
        MD.vc1(hx, hy, 2.65)
        tops = [p["d"] * p["n"][2] for p in MD.pl if p["n"][2] > 0.9999 and hz1 - 0.01 <= p["d"] <= 12.0
                and math.hypot(0.5 * (p["bb"][0] + p["bb"][3]) - hx, 0.5 * (p["bb"][1] + p["bb"][4]) - hy) < 7.0]
        top = max(tops)
        MEAS["K1_tops"] = sorted(set(round(v, 3) for v in tops))
        add("K1", hx, hy, "CLIP HEAD, RING %s5.3" % DIA, "%.2f" % top, "%s2.70 x %.2f DEEP" % (DIA, hz1 - hz0),
            arc_target(view, hx, hy, hz1, 2.65), hz1)
    tryf("K1", k1)

    def f3():
        hx, hy, hz0, hz1, _ = MD.vc1(75.6, 129.6, 1.3, concave=True)
        MD.vc1(hx, hy, 3.3, concave=False)
        add("F3", hx, hy, "LUG R3.3 ON RIB STUB", ztxt(hz1), "%s2.60 x %.2f DEEP" % (DIA, hz1 - hz0), arc_target(view, hx, hy, hz1, 1.3), hz1)
    tryf("F3", f3)

    def m1():
        hx, hy, hz0, hz1, _ = MD.vc1(-6.3, 92.0, 1.6, concave=True)
        _x, _y, bz0, bz1, _ = MD.vc1(hx, hy, 3.3, concave=False)
        add("M1", hx, hy, "PAD + BOSS %s6.6" % DIA, ztxt(bz1), "%s3.20 x %.2f DEEP" % (DIA, hz1 - hz0), arc_target(view, hx, hy, hz1, 1.6), hz1)
    tryf("M1", m1)
    # Rev A floor holes still in the model (H3 -> M1, H4 -> F3)
    for i, h in enumerate(PJ["small_holes"], 1):
        def fh(i=i, h=h):
            cand = [q for q in MD.cyl if abs(abs(q["dir"][2]) - 1) < 1e-3 and q["nd"] < 0 and q["r"] < 2.0
                    and math.hypot(q["pt"][0] - h["x"], q["pt"][1] - h["y"]) < 0.6]
            if not cand:
                rep["H%d" % i] = "not in model"
                return
            if any(abs(q["pt"][0] - xx) < 0.6 and abs(q["pt"][1] - yy) < 0.6 for q in cand for xx, yy in ((-6.3, 92.0), (75.6, 129.6))):
                rep["H%d" % i] = "replaced (M1 / F3)"
                return
            q = min(cand, key=lambda q: q["r"])
            add("H%d" % i, q["pt"][0], q["pt"][1], "FLOOR HOLE", ztxt(q["bb"][5]), "%s%.2f x %.2f DEEP" % (DIA, 2 * q["r"], q["bb"][5] - q["bb"][2]),
                arc_target(view, q["pt"][0], q["pt"][1], q["bb"][5], q["r"]), q["bb"][5])
        tryf("H%d" % i, fh)
    for i, sx_ in enumerate(SLOT["xs"], 1):
        def fs(i=i, sx_=sx_):
            hx, hy, hz0, hz1, _ = MD.vc1(sx_, SLOT["y"], SLOT["d"] / 2.0, concave=True)
            add("S%d" % i, hx, hy, "LOCATING SLOT", "%.2f" % hz1, "%s%.2f x %.2f DEEP" % (DIA, SLOT["d"], hz1 - hz0),
                arc_target(view, hx, hy, hz1, SLOT["d"] / 2.0), hz1)
        tryf("S%d" % i, fs)

    def tabs():
        for fid, seed, nrm, ztop_seed, desc in (("T1", (-34.26, 238.2), (0.70711, 0.70711), (-34.75, 238.4), "TAB %.2f THK AT 45 DEG"),
                                                  ("T2", (-19.225, 186.7), (1.0, 0.0), (-19.2, 186.7), "TAB %.2f THK, C1.6")):
            t, _zt, _mp = MD.thk(seed[0], seed[1], nrm)
            top = max(MD.hplane(ztop_seed[0], ztop_seed[1], up=True, zmin=0.0, zmax=40.0))
            hc = [c for c in MD.cyl if abs(c["r"] - 1.35) < 0.01 and abs(c["dir"][2]) < 1e-3 and c["nd"] < 0
                  and math.hypot(c["pt"][0] - seed[0], c["pt"][1] - seed[1]) < 2.5]
            if not hc:
                raise RuntimeError("no D2.7 hole in tab " + fid)
            add(fid, hc[0]["pt"][0], hc[0]["pt"][1], desc % t, "%.2f" % top, "%s2.70 THRU" % DIA,
                near_target(view, ztop_seed[0], ztop_seed[1], top), top)
    tryf("T", tabs)
    return rows, feats


def place_balloons(view, feats, tag):
    """Arrow balloons outside the plan outline (sheet up = model -X), stacked per side along Y."""
    oy0, xs_min, xs_max = OUTLINE["y0"], OUTLINE["xmin"], OUTLINE["xmax"]

    def band(y, w=9.0):
        i0 = max(0, int(y - w - oy0)); i1 = min(len(xs_min) - 1, int(y + w - oy0))
        lo = [v for v in xs_min[i0:i1 + 1] if v == v]; hi = [v for v in xs_max[i0:i1 + 1] if v == v]
        return (min(lo) if lo else -70.0), (max(hi) if hi else 120.0)
    GAP, PITCH = 18.0, 17.0
    sides = {"up": [], "down": []}
    for f in feats:
        lo, hi = band(f[2])
        sides["up" if (f[1] - lo) <= (hi - f[1]) else "down"].append(list(f))
    place = []
    for side, lst in sides.items():
        lst.sort(key=lambda f: f[2])
        ys = [f[2] for f in lst]
        for _it in range(400):                       # relax: push neighbours apart symmetrically
            moved = False
            for k in range(len(ys) - 1):
                g = ys[k + 1] - ys[k]
                if g < PITCH - 1e-6:
                    ys[k] -= (PITCH - g) / 2.0
                    ys[k + 1] += (PITCH - g) / 2.0
                    moved = True
            if not moved:
                break
        for f, yb in zip(lst, ys):
            lo, hi = band(min(f[2], yb), 9.0 + abs(yb - f[2]))
            xb = lo - GAP if side == "up" else hi + GAP
            place.append((f, xb, yb))
    out = []
    for f, xb, yb in place:
        name, x, y, z, tgt = f
        pos = xy(view, M(xb, yb, z))

        def mk(name=name, tgt=tgt, pos=pos, xb=xb, yb=yb):
            c, a = tgt(xb, yb)
            big = len(name) > 2
            return gdt.balloon(dwg, name, pos, c, view, a, size=14.0 if big else 11.0, text_size=4.0 if big else 4.5)
        N("%s_balloon_%s" % (tag, name), mk)
        out.append([name, round(xb, 1), round(yb, 1)])
    res["balloons_" + tag] = out
    return out


try:
    dwg, comp = m3d.new_drawing(os.path.join(OUTD, NO + "_dwg.prt"), MODEL, "LEFT_THIGH_OUTER", R, refset="SOLID")
    mprt = comp.Prototype
    try:
        mprt.LoadThisPartFully()
    except Exception:  # noqa: BLE001
        pass
    MD = Model(mprt)
    res["model"] = {"solids": len(MD.solids), "cyl": len(MD.cyl), "planes": len(MD.pl), "file": MODEL,
                    "mtime": os.path.getmtime(MODEL)}
    # knee hub levels and radii (axis Z through the origin)
    kc = MD.axcyl((0, 0, 0), (0, 0, 1), 68.05, rtol=0.25) + MD.axcyl((0, 0, 0), (0, 0, 1), 68.25, rtol=0.01)
    RK = max(c["r"] for c in kc if c["bb"][5] > 10.0)                      # knee OD band (Rev C 68.25)
    Y_END = MD.yplane(+1)                                                   # hip end face (287.4)
    ZA = max(MD.hplane(55.0, 0.0, up=False, zmin=-12.0, zmax=-7.0))        # datum A face (knee mounting face)
    Z_SK = max(MD.hplane(63.5, 0.0, up=False, zmin=-16.0, zmax=-12.0))     # skirt
    Z_S1 = max(MD.hplane(51.0, 0.0, up=True, zmin=-5.0, zmax=-3.0))       # bore step Ø110 / Ø96
    Z_S2 = max(MD.hplane(47.0, 0.0, up=True, zmin=-7.0, zmax=-5.0))       # bore step Ø96 / Ø92
    MEAS.update({"knee_OD_r": RK, "y_end": Y_END, "L_overall": Y_END + RK, "z_A": ZA, "z_skirt": Z_SK, "z_step1": Z_S1,
                 "z_step2": Z_S2, "knee_radii": sorted(set(round(c["r"], 3) for c in MD.cyl
                                                            if abs(abs(c["dir"][2]) - 1) < 1e-3 and math.hypot(c["pt"][0], c["pt"][1]) < 0.02))})
    for nm, rr in (("r46_05", 46.05), ("r48", 48.0), ("r55", 55.0), ("r62_75", 62.75)):
        MEAS[nm] = [[round(c["bb"][2], 3), round(c["bb"][5], 3)] for c in MD.axcyl((0, 0, 0), (0, 0, 1), rr)]
    # ================================================================ SHEET 1 general arrangement (A1, 1:1)
    sh1, _g = ptdwg.sheet(dwg, "A1")
    front = nxd.base_view(dwg, dwg, "Front", (255.0, 150.0), scale=(1.0, 1.0))
    top = nxd.projected_view(dwg, front, (255.0, 400.0))
    right = nxd.projected_view(dwg, front, (565.0, 150.0))
    iso = nxd.base_view(dwg, dwg, "Isometric", (705.0, 470.0), scale=(1.0, 2.0))
    res["views1"] = {v.Name: nxd.view_info(v) for v in (front, top, right, iso)}
    res["rev1"] = N("rev_block_1", rev_block)
    res["tb1"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (iso 1:2)", 1, NSH, rev=REV, subtitle="general arrangement")
    if MODE == "dump":
        for v, n in ((front, "front"), (top, "top"), (right, "right")):
            res["dump_" + n] = m3d.dump(v, os.path.join(OUTD, "dump_sh1_%s.json" % n))
    else:
        fx = lambda X: xy(front, (X, 0.0, 0.0))[0]           # noqa: E731
        fz = lambda Z: xy(front, (0.0, 0.0, Z))[1]           # noqa: E731
        c_top = N("c_ringtop", lambda: longest(straight(front, at(2, PJ["hip"]["ring_top_z"], 0.05))))
        def skirt_line():
            # chamfer line of the knee skirt that ends on the skirt level (the flat bottom is a circle seen edge-on)
            cs = [(c, p) for c, _ps in nxd.curves(front) for p in [nxd.curve_points(c)] if len(p) == 3
                  and min(abs(p[0][2] - Z_SK), abs(p[1][2] - Z_SK)) < 0.02 and p[0][0] < 0 and abs(p[0][0] - p[1][0]) > 1.0]
            c, p = min(cs, key=lambda cp: min(cp[1][0][0], cp[1][1][0]))
            return c, min(p[:2], key=lambda q: abs(q[2] - Z_SK))
        c_skirt = N("c_skirt", skirt_line)
        c_knee = N("c_knee", lambda: longest(straight(front, at(0, -RK, 0.1))))
        rim = PJ["levels"]["rim"]

        def end_curve():
            # hip end face seen edge-on: its boundary curves are splines; take one with both ends on Y_END at the rim
            cs = [(c, p) for c, _ps in nxd.curves(front) for p in [nxd.curve_points(c)] if len(p) >= 2
                  and abs(p[0][0] - Y_END) < 0.02 and abs(p[1][0] - Y_END) < 0.02 and min(abs(p[0][2] - rim), abs(p[1][2] - rim)) < 0.02]
            c, p = cs[0]
            return c, min(p[:2], key=lambda q: abs(q[2] - rim))
        ce = N("c_end", end_curve)
        c_end, ptop = ce if ce else (None, None)
        if c_knee and c_skirt:
            pk = max(nxd.curve_points(c_knee)[:2], key=lambda q: q[2])
            res["dbg_knee_top"] = pk
            D("H_skirt_rim", lambda: m3d.dim_ends(front, c_skirt[0], c_skirt[1], c_knee, pk, (fx(-92.0), fz(10.0)), "vertical",
                                                  expect=rim - Z_SK, etol=0.02))
        if c_end:
            if c_top:
                pt = nxd.curve_points(c_top)[0]
                D("H_rim_ringtop", lambda: m3d.dim_ends(front, c_end, ptop, c_top, pt, (fx(316.0), fz(60.0)), "vertical",
                                                       expect=PJ["hip"]["ring_top_z"] - rim, etol=0.1))
        if c_knee and c_end:
            pk2 = max(nxd.curve_points(c_knee)[:2], key=lambda q: q[2])
            D("L_overall", lambda: m3d.dim_ends(front, c_knee, pk2, c_end, ptop, (fx(110.0), fz(-60.0)), "horizontal",
                                                expect=Y_END + RK, etol=0.02))
        tx = lambda X: xy(top, (X, 0.0, 0.0))[0]             # noqa: E731
        ty = lambda Y: xy(top, (0.0, Y, 0.0))[1]             # noqa: E731
        c_bore = N("c_kbore", lambda: arc_xy(top, (0.0, 0.0, 0.0), 55.0, 2, 0.08)[0])
        c_hf1 = N("c_hipface_in", lambda: longest(straight(top, at(0, PJ["hip"]["y_plate_in"], 0.05))))
        c_hf2 = N("c_hipface_out", lambda: longest(straight(top, at(0, PJ["hip"]["y_ring_out"], 0.05))))
        if c_bore and c_hf1:
            D("L_knee_hipface_in", lambda: lin(top, c_bore, c_hf1, (tx(133.0), ty(102.0)), "horizontal", S.Center, S.Mid,
                                               basic=True, expect=266.5))
        if c_bore and c_hf2:
            D("L_knee_hipface_out", lambda: lin(top, c_bore, c_hf2, (tx(140.0), ty(118.0)), "horizontal", S.Center, S.Mid,
                                                basic=True, expect=276.85))
        x0, y0 = 470.0, 330.0
        note_lines(["NOTES",
                    "1. GENERAL TOLERANCES ISO 2768-mK. GD&T PER ISO 1101.",
                    "2. GEOMETRY NOT DIMENSIONED PER 3D MODEL LT-OUT-001 REV F.",
                    "3. ALL SURFACES UNLESS OTHERWISE SPECIFIED:",
                    "",
                    "4. INTERNAL CORNERS R3 MAX. BREAK SHARP EDGES 0.2-0.5.",
                    "5. Ra 3.2 UNLESS OTHERWISE SPECIFIED."], x0, y0, step=9.0)
        N("fcf_profile_all", lambda: gdt.fcf(dwg, "ProfileOfASurface", "0.2", ("A", "B", "C"), False,
                                             (x0 + 7.0, y0 - 4 * 9.0 + 2.0), size=GT))
    res["overlaps1"] = nxd.overlaps(sh1)

    # ================================================================ SHEET 2 knee hub (A1, 1:1)
    sh2, _g = ptdwg.sheet(dwg, "A1")
    ktop = nxd.base_view(dwg, dwg, "Top", (330.0, 425.0), scale=(1.0, 1.0))
    ksec = nxd2.section(dwg, ktop, M(0.0, 0.0, 0.0), (330.0, 205.0), (1.0, 1.0))
    relabel(ksec, "E")
    res["views2"] = {v.Name: nxd.view_info(v) for v in (ktop, ksec)}
    res["rev2"] = N("rev_block_2", rev_block)
    res["tb2"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 2, NSH, rev=REV, subtitle="knee hub")
    if MODE == "dump":
        res["dump_ksec"] = m3d.dump(ksec, os.path.join(OUTD, "dump_sh2_ksec.json"))
        res["dump_ktop"] = m3d.dump(ktop, os.path.join(OUTD, "dump_sh2_ktop.json"))
    else:
        sx = lambda X: xy(ksec, (X, 0.0, 0.0))[0]            # noqa: E731
        sz = lambda Z: xy(ksec, (0.0, 0.0, Z))[1]            # noqa: E731
        vert = lambda X, z0, z1: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[0] - X) < 0.06 and abs(p1[0] - X) < 0.06
                                                           and min(p0[2], p1[2]) >= z0 - 0.3 and max(p0[2], p1[2]) <= z1 + 0.3)))  # noqa: E731
        hor = lambda Z, x0, x1: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[2] - Z) < 0.06 and abs(p1[2] - Z) < 0.06
                                                          and x0 <= 0.5 * (p0[0] + p1[0]) <= x1)))  # noqa: E731
        # diameters stacked BELOW the section (white space under the knee), smallest nearest the part
        dims2 = {}
        cols = [("D92", 46.05, ZA, Z_S2, 92.1, None, -42.0), ("D96", 48.0, Z_S2, Z_S1, 96.0, None, -58.0),
                ("D110", 55.0, Z_S1, 0.0, 110.0, "H7", -74.0), ("D125_5", 62.75, Z_SK, ZA, 125.5, "H7", -112.0)]
        for name, r, z0, z1, val, tol, zz in cols:
            ca = N("c_%s_a" % name, vert(-r, z0, z1)); cb = N("c_%s_b" % name, vert(r, z0, z1))
            if ca and cb:
                dims2[name] = dimc(name, ksec, ca, cb, (sx(0.0), sz(zz)), "cylindrical", val, etol=0.1, tol=tol)
        f110 = None
        if dims2.get("D110"):
            f110 = stack_fcf("fcf_perp_110", dims2["D110"], "Perpendicularity", "0.03", ("A",), True, (sx(0.0) - 20.0, sz(-74.0) - 10.0))
        if dims2.get("D125_5"):
            stack_fcf("fcf_pos_125", dims2["D125_5"], "Position", "0.05", ("A", "B"), True, (sx(0.0) - 20.0, sz(-112.0) - 10.0))
        # datum B stacked under the Ø110 frame; datum A + flatness on the mounting face Z -8.35, in the recess opening
        c_b110 = N("c_D110_b2", vert(55.0, Z_S1, 0.0))
        if f110 is not None:
            datum_under("datum_B", "B", f110, lambda: gdt.datum(dwg, "B", (sx(80.0), sz(-60.0)), c_b110, ksec, (55.0, 0.0, -3.0), size=GT))
        c_fA = N("c_faceA", hor(ZA, -62.7, -46.1))
        if c_fA:
            fA = N("fcf_flat_A", lambda: gdt.fcf(dwg, "Flatness", "0.03", (), False, (sx(-36.0), sz(-20.0)), c_fA, ksec,
                                                 (-54.0, 0.0, ZA), size=GT))
            if fA is not None:
                datum_under("datum_A", "A", fA, lambda: gdt.datum(dwg, "A", (sx(-36.0), sz(-30.0)), c_fA, ksec, (-50.0, 0.0, ZA), size=GT))
        # depths, left of the section
        c_floor = N("c_floor", hor(0.0, -64.0, -55.5))
        c_step1 = N("c_step1", hor(Z_S1, -55.0, -48.0))
        c_step2 = N("c_step2", hor(Z_S2, -48.0, -46.0))
        c_bot = N("c_bot", hor(ZA, -62.7, -46.1))
        c_sk = N("c_skirt2", hor(Z_SK, -64.5, -62.5))
        x_l = sx(-75.0)
        if c_floor and c_step1:
            dimc("Z_step1", ksec, c_floor, c_step1, (x_l - 8, sz(12.0)), "vertical", -Z_S1, etol=0.01)
        if c_floor and c_step2:
            dimc("Z_step2", ksec, c_floor, c_step2, (x_l - 22, sz(12.0)), "vertical", -Z_S2, etol=0.01)
        if c_floor and c_bot:
            dimc("Z_bottom", ksec, c_floor, c_bot, (x_l - 36, sz(12.0)), "vertical", -ZA, etol=0.01)
        if c_bot and c_sk:
            dimc("Z_skirt", ksec, c_bot, c_sk, (x_l - 50, sz(-26.0)), "vertical", ZA - Z_SK, etol=0.01)
        # knee bolt circle on the plan view: callout + position frame above the view, basic PCD
        kb = PJ["knee_bolts"]
        rk = kb["pcd"] / 2.0

        def kh(ang):
            a = math.radians(ang)
            return M(rk * math.cos(a), rk * math.sin(a), 0.0)
        hole = N("c_khole", lambda: arc_xy(ktop, kh(186.0), kb["d"] / 2.0, 2))
        if hole:
            tw = M(-112.0, -62.0, hole[1][2])
            dk = callout("callout_knee_holes", ktop, hole[0], hole[1], kb["d"] / 2.0, 2, tw,
                         ["30X %s%.2f THRU EQ SP" % (DIA, kb["d"])])
            if dk:
                stack_fcf("fcf_pos_kholes", dk, "Position", "0.1", ("A", "B"), True, None)
        h90 = N("c_khole90", lambda: arc_xy(ktop, kh(90.0), kb["d"] / 2.0, 2))
        h270 = N("c_khole270", lambda: arc_xy(ktop, kh(270.0), kb["d"] / 2.0, 2))
        if h90 and h270:
            D("PCD_knee", lambda: lin(ktop, h270[0], h90[0], xy(ktop, M(-14.0, 0.0, 0.0)), "cylindrical", S.Center, S.Center,
                                      basic=True, expect=kb["pcd"]))
        MEAS["knee_holes"] = len([c for c in MD.cyl if abs(c["r"] - kb["d"] / 2.0) < 0.01 and abs(abs(c["dir"][2]) - 1) < 1e-3
                                  and abs(math.hypot(c["pt"][0], c["pt"][1]) - rk) < 0.05])
        # Rev F: rebuilt -X ring wall segment (F2W_RING about the knee axis, 134-154.8 deg): its two radii on the plan view
        for nm, rr, ang, ro in (("R_ringwall_out", RK, 150.0, 28.0), ("R_ringwall_in", 65.4, 136.0, 55.0)):
            def mkr(rr=rr, ang=ang, ro=ro):
                a = math.radians(ang)
                arc = arc_dir(ktop, rr, M(math.cos(a), math.sin(a), 0.0))
                org = xy(ktop, M((rr + ro) * math.cos(a), (rr + ro) * math.sin(a), 0.0))
                b = dwg.Dimensions.CreateRadialDimensionBuilder(A.Dimension.Null)
                try:
                    b.Measurement.Method = nxd.MM.Radial
                    b.FirstAssociativity.SetValue(S.NotSet, arc, ktop, nxd.P0, None, None, nxd.P0)
                    _style0(b, 2, DT)
                    b.Origin.Origin.SetValue(None, None, nxh.P(org[0], org[1], 0.0))
                    d = b.Commit()
                finally:
                    b.Destroy()
                if abs(d.ComputedSize - rr) > 0.01:
                    v = d.ComputedSize
                    ptdwg._delete([d])
                    raise RuntimeError("radius %.3f instead of %.3f" % (v, rr))
                return d
            D(nm, mkr)
    res["overlaps2"] = nxd.overlaps(sh2)

    # ================================================================ SHEET 3 hip ring (A1)
    sh3, _g = ptdwg.sheet(dwg, "A1")
    hend = nxd.base_view(dwg, dwg, "Right", (175.0, 400.0), scale=(1.0, 1.0))
    hfront = nxd.base_view(dwg, dwg, "Front", (175.0, 95.0), scale=(1.0, 2.0))
    hsec = nxd2.section(dwg, hfront, M(HX, 271.0, HZ), (175.0, 215.0), (1.0, 2.0))
    relabel(hsec, "F")
    hdet = N("hdet", lambda: nxd.detail_view(dwg, hsec, M(HX, 271.0, HZ), M(HX + 60.0, 271.0, HZ), (560.0, 380.0), scale=(2.0, 1.0)))
    if hdet is not None:
        relabel(hdet, "G")
    vv = [v for v in (hend, hfront, hsec, hdet) if v is not None]
    res["views3"] = {v.Name: nxd.view_info(v) for v in vv}
    res["rev3"] = N("rev_block_3", rev_block)
    res["tb3"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (front, F-F 1:2, G 2:1)", 3, NSH, rev=REV, subtitle="hip ring")
    if MODE == "dump":
        res["dump_hsec"] = m3d.dump(hsec, os.path.join(OUTD, "dump_sh3_hsec.json"))
        if hdet is not None:
            res["dump_hdet"] = m3d.dump(hdet, os.path.join(OUTD, "dump_sh3_hdet.json"))
        res["dump_hend"] = m3d.dump(hend, os.path.join(OUTD, "dump_sh3_hend.json"))
    elif hdet is not None:
        yax = -HX
        rx = lambda X: xy(hdet, (X, yax, HZ))[0]                   # noqa: E731
        ry = lambda Yd: xy(hdet, (271.0, Yd, HZ))[1]               # noqa: E731
        axl = lambda r, x0, x1, t=0.06: (lambda: longest(straight(hdet, lambda p0, p1: abs(p0[1] - (yax + r)) < t and abs(p1[1] - (yax + r)) < t
                                                               and min(p0[0], p1[0]) >= x0 - 0.6 and max(p0[0], p1[0]) <= x1 + 0.6)))  # noqa: E731
        dims3 = {}
        # dimension lines RIGHT of the outer face (white space inside the detail circle), smallest first
        for name, r, y0_, y1_, val, tol, xo in (("HD82", 40.99, 271.4, 275.85, 82.0, "H7", 16.0),
                                                ("HD85_96", 42.98, 269.45, 271.4, 85.96, None, 46.0),
                                                ("HD97_54", 48.77, 266.5, 269.45, 97.54, "H7", -10.35 - 30.0)):
            ca = N("c_%s_a" % name, axl(-r, y0_, y1_, 0.15)); cb = N("c_%s_b" % name, axl(r, y0_, y1_, 0.15))
            if ca and cb:
                dims3[name] = dimc(name, hdet, ca, cb, (rx(276.85 + xo), ry(yax)), "cylindrical", val, etol=0.1, tol=tol)
                if dims3[name] is not None and name == "HD82":
                    N("ovr_HD82", lambda: nxd2.override_text(dims3["HD82"], ["82.00"]))
            else:
                res["dbg_" + name] = [[[round(v, 2) for v in q] for q in pp[:2]] for c, pp in
                                      straight(hdet, lambda p0, p1: abs(abs(p0[1] - yax) - r) < 1.5 and abs(abs(p1[1] - yax) - r) < 1.5)][:16]
        # position frames outside the detail circle with a leader to the bore wall (a frame stacked under a vertical
        # dimension is crossed by its own dimension line)
        c82w = N("c_HD82_wall_l", axl(-40.99, 271.4, 275.85, 0.15))
        if dims3.get("HD82") and c82w:
            N("fcf_pos_82", lambda: gdt.fcf(dwg, "Position", "0.1", ("A", "B"), True, (690.0, 455.0), c82w, hdet,
                                             (272.4, yax - 40.99, HZ), size=GT))
        c97w = N("c_HD97_wall_l", axl(-48.77, 266.5, 269.45, 0.15))
        if dims3.get("HD97_54") and c97w:
            N("fcf_pos_97", lambda: gdt.fcf(dwg, "Position", "0.05", ("D", "C"), True, (690.0, 482.0), c97w, hdet,
                                             (268.0, yax - 48.77, HZ), size=GT))
        # datum C on the Ø82 bore wall, datum D + perpendicularity on the outer face (Y 276.85)
        c82 = N("c_HD82_wall", axl(-40.99, 271.4, 275.85, 0.15))
        if c82:
            N("datum_C", lambda: gdt.datum(dwg, "C", (rx(262.0), ry(yax - 40.99) - 16.0), c82, hdet, (273.6, yax - 40.99, HZ), size=GT))
        c_face = N("c_outer_face", lambda: longest(straight(hdet, at(0, 276.85, 0.06))))
        if c_face:
            pf = nxd.curve_points(c_face)
            pm = max(pf[:2], key=lambda q: q[1])
            atp = (276.85, pm[1] - 1.5, HZ)
            fD = N("fcf_perp_D", lambda: gdt.fcf(dwg, "Perpendicularity", "0.03", ("C",), False, (rx(336.0), ry(atp[1]) + 30.0),
                                                 c_face, hdet, (276.85, pm[1] - 4.0, HZ), size=GT))
            if fD is not None:
                datum_under("datum_D", "D", fD, lambda: gdt.datum(dwg, "D", (rx(336.0), ry(atp[1]) + 14.0), c_face, hdet, atp, size=GT))
        # hip bolt circle on the end view: callout above the ring, basic PCD above the ring top
        hb = PJ["hip_bolts"]
        rh_ = hb["pcd"] / 2.0

        def hh(ang, y):
            a = math.radians(ang)
            return M(HX + rh_ * math.cos(a), y, HZ + rh_ * math.sin(a))
        step_a = 360.0 / hb["n"]
        top_k = max(range(hb["n"]), key=lambda k: math.sin(math.radians(k * step_a)) - 1e-3 * math.cos(math.radians(k * step_a)))
        hole3 = N("c_hhole", lambda: arc_xy(hend, hh(top_k * step_a, 276.85), hb["cb_d"] / 2.0, 0, 0.1))
        if hole3:
            dh = callout("callout_hip_holes", hend, hole3[0], hole3[1], hb["cb_d"] / 2.0, 0, M(HX - 75.0, 276.85, 126.0),
                         ["26X %s%.2f THRU EQ SP" % (DIA, hb["d"]), "C'BORE %s%.2f x %.2f DEEP" % (DIA, hb["cb_d"], 276.85 - hb["cb_y0"])])
            if dh:
                stack_fcf("fcf_pos_hholes", dh, "Position", "0.1", ("D", "C"), True, None)
        h0 = N("c_hhole0", lambda: arc_xy(hend, hh(0.0, 276.85), hb["cb_d"] / 2.0, 0, 0.1))
        h180 = N("c_hhole180", lambda: arc_xy(hend, hh(180.0, 276.85), hb["cb_d"] / 2.0, 0, 0.1))
        if h0 and h180:
            D("PCD_hip", lambda: lin(hend, h180[0], h0[0], xy(hend, M(HX, 276.85, 108.0)), "cylindrical", S.Center, S.Center,
                                     basic=True, expect=hb["pcd"]))
        # Rev C connector pad: hole callouts below the part, pad data in a table right of the end view
        ps_ = pad_pt(-PAD["s_half"])
        cs_ = N("c_pad_cbore", lambda: arc_xy(hend, M(*ps_), PAD["cb_d"] / 2.0, 0, 0.1))
        if cs_:
            callout("callout_pad_screws", hend, cs_[0], cs_[1], PAD["cb_d"] / 2.0, 0, M(ps_[0] - 30.0, PAD["face"], -66.0),
                    ["2X %s%.1f THRU (M4 TAP)" % (DIA, PAD["tap"]), "C'BORE %s%.2f x %.2f DEEP" % (DIA, PAD["cb_d"], PAD["cb_depth"])])
        pp_ = pad_pt(PAD["p_half"])
        cp_ = N("c_pad_pin", lambda: arc_xy(hend, M(*pp_), PAD["pin_d"] / 2.0, 0, 0.1))
        if cp_:
            callout("callout_pad_pins", hend, cp_[0], cp_[1], PAD["pin_d"] / 2.0, 0, M(pp_[0] + 45.0, PAD["face"], -66.0),
                    ["2X %s%.2f THRU" % (DIA, PAD["pin_d"])])
        prow = [["CONNECTOR PAD, HIP END FACE", ""],
                ["SECTOR ABOUT HIP AXIS", "R%.2f - R%.2f, %.1f DEG" % (PAD["r_in"], PAD["r_out"], 2 * PAD["half"])],
                ["CENTRE LINE", "%.2f DEG FROM +X (TOWARD -Z)" % -PAD["theta"]],
                ["HEIGHT ABOVE D", "%.2f" % PAD["h"]],
                ["CORNERS", "R%.0f OUTER / R%.0f INNER" % (PAD["rc_out"], PAD["rc_in"])],
                ["HOLES ON R%.2f" % PAD["pcr"], "SCREWS +/-%.2f, PINS +/-%.3f DEG" % (PAD["s_half"], PAD["p_half"])]]
        N("table_pad", lambda: table((290.0, 560.0), [62.0, 86.0], prow, size=3.5, rh=8.0))
    res["overlaps3"] = nxd.overlaps(sh3)

    # ================================================================ SHEET 4 interior features (A1, 1:1)
    sh4, _g = ptdwg.sheet(dwg, "A1")
    itop = nxd.base_view(dwg, dwg, "Top", (250.0, 320.0), scale=(1.0, 1.0))
    s1x = SLOT["xs"][0]
    ssec = N("ssec", lambda: nxd2.section(dwg, itop, M(s1x, SLOT["y"], SLOT["top"]), (250.0, 135.0), (1.0, 2.0)))
    sdet = None
    if ssec is not None:
        relabel(ssec, "H")
        sdet = N("sdet", lambda: nxd.detail_view(dwg, ssec, M(s1x, SLOT["y"] + 1.0, 82.0), M(s1x, SLOT["y"] + 11.0, 82.0),
                                                  (575.0, 150.0), scale=(5.0, 1.0)))
        if sdet is not None:
            relabel(sdet, "J")
    res["views4"] = {v.Name: nxd.view_info(v) for v in (itop, ssec, sdet) if v is not None}
    res["rev4"] = N("rev_block_4", rev_block)
    res["tb4"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (H-H 1:2, J 5:1)", 4, NSH, rev=REV, subtitle="interior features")
    if MODE != "dump":
        rows, feats = feature_rows(itop)
        hdr = [["FEATURE LOCATIONS (BASIC, MODEL FRAME: ORIGIN ON B, Z0 = %.2f ABOVE A)" % -ZA, "", "", "", "", ""],
               ["ID", "X", "Y", "FEATURE", "TOP Z", "HOLE"]]
        trows = hdr + rows
        res["table4"] = N("table4", lambda: table((470.0, 570.0), [16.0, 24.0, 24.0, 84.0, 38.0, 52.0], trows, size=3.3, rh=7.4))
        ytab = 570.0 - 7.4 * len(trows)
        N("fcf_table_note", lambda: nxd.note(dwg, ["ALL FEATURES IN THIS TABLE:"], (470.0, ytab - 5.0), size=GT))
        N("fcf_table", lambda: gdt.fcf(dwg, "Position", "0.1", ("A", "B", "C"), True, (568.0, ytab - 1.0), size=GT))
        lv = [["FLAT LEVELS (Z FROM KNEE FLOOR)", ""]]
        for lab, (x_, y_, z0_, z1_, up_) in (("RIM / PARTING PLANE", (100.0, 150.0, 34.0, 35.0, True)),
                                             ("TONGUE TOP (INNER EDGE OF RIM)", (100.0, 265.0, 35.5, 36.5, True)),
                                             ("-X WALL TOP (Y 24-181)", (-40.0, 100.0, 35.0, 37.0, True)),
                                             ("-X WALL TOP AT HIP END (B7)", (-30.0, 260.0, 35.0, 37.0, True)),
                                             ("HIP RING TOP FLAT", (38.0, 271.7, 84.0, 86.0, True)),
                                             ("LOW HUB WALL (KNEE, -X SIDE)", (-62.0, -10.0, 6.0, 9.0, True))):
            try:
                zz = MD.hplane(x_, y_, up=up_, zmin=z0_, zmax=z1_)
                MEAS["level_" + lab] = zz
                lv.append([lab, " / ".join("%.2f" % v for v in sorted(set(round(q, 2) for q in zz)))])
            except Exception:  # noqa: BLE001
                res["errors"]["level_" + lab] = traceback.format_exc()[-300:]
        lv.append(["KNEE FLOOR", "Z0 (%.2f ABOVE A)" % -ZA])
        N("table_levels", lambda: table((470.0, ytab - 22.0), [100.0, 136.0], lv, size=3.3, rh=7.4))
        place_balloons(itop, feats, "b4")
        if sdet is not None:
            yl, yr = SLOT["y"] - SLOT["d"] / 2.0, SLOT["y"] + SLOT["d"] / 2.0
            jx = lambda Y: xy(sdet, (Y, -s1x, 0.0))[0]           # noqa: E731
            jz = lambda Z: xy(sdet, (SLOT["y"], -s1x, Z))[1]     # noqa: E731
            wall = lambda Y, z0, z1: (lambda: longest(straight(sdet, lambda p0, p1: abs(p0[0] - Y) < 0.03 and abs(p1[0] - Y) < 0.03
                                                               and min(p0[2], p1[2]) >= z0 - 0.3 and max(p0[2], p1[2]) <= z1 + 0.3)))  # noqa: E731
            flat = lambda Z, y0_, y1_: (lambda: longest(straight(sdet, lambda p0, p1: abs(p0[2] - Z) < 0.03 and abs(p1[2] - Z) < 0.03
                                                                  and y0_ <= 0.5 * (p0[0] + p1[0]) <= y1_)))  # noqa: E731
            cwl = N("c_slot_wall_l", wall(yl, 82.5, SLOT["top"]))
            cwr = N("c_slot_wall_r", wall(yr, SLOT["floor"], SLOT["top"]))
            if cwl and cwr:
                dw = D("S_width", lambda: lin(sdet, cwl, cwr, (jx(SLOT["y"] + 1.6), jz(SLOT["top"] + 3.2)), "horizontal", S.Start, S.Start,
                                              expect=SLOT["d"], etol=0.01))
                if dw is not None:
                    N("ovr_S_width", lambda: nxd2.override_text(dw, ["2X %s%.2f" % (DIA, SLOT["d"])]))
            ctop = N("c_slot_top", flat(SLOT["top"], yr + 0.2, yr + 4.0))
            cflo = N("c_slot_floor", flat(SLOT["floor"], yl - 0.5, yr))
            if ctop and cflo:
                D("S_depth", lambda: lin(sdet, ctop, cflo, (jx(yr + 5.3), jz(82.2)), "vertical", S.Mid, S.Mid,
                                         expect=SLOT["top"] - SLOT["floor"], etol=0.01))
            N("note_slot", lambda: nxd.note(dwg, ["S1, S2: OPEN INTO %s97.54 STEP BELOW" % DIA], (505.0, 68.0), size=GT))
    res["overlaps4"] = nxd.overlaps(sh4)

    # ================================================================ SHEET 5 ribs + side window (A1, 1:1)
    sh5, _g = ptdwg.sheet(dwg, "A1")
    rtop = nxd.base_view(dwg, dwg, "Top", (250.0, 410.0), scale=(1.0, 1.0))
    back = nxd.base_view(dwg, dwg, "Back", (250.0, 150.0), scale=(1.0, 1.0))
    res["views5"] = {v.Name: nxd.view_info(v) for v in (rtop, back)}
    res["rev5"] = N("rev_block_5", rev_block)
    res["tb5"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 5, NSH, rev=REV, subtitle="ribs and side window")
    if MODE == "dump":
        res["dump_back"] = m3d.dump(back, os.path.join(OUTD, "dump_sh5_back.json"))
    else:
        rrows = [["RIBS: POINT ON MID-PLANE (MODEL FRAME), DIRECTION FROM +X, THICKNESS", "", "", "", "", ""],
                 ["ID", "X", "Y", "DIR (DEG)", "THK", "FEATURE"]]
        rfeats = []
        MEAS["ribs"] = {}
        for rid, (x_, y_), nrm, desc in RIBS:
            try:
                t, zt, (mx, my) = MD.thk(x_, y_, nrm)
                ang = math.degrees(math.atan2(nrm[0], -nrm[1])) % 180.0      # rib direction u = (-ny, nx)
                rrows.append([rid, "%.2f" % mx, "%.2f" % my, ("%.1f" % ang) if 0.05 < ang < 179.95 else "180.0", "%.2f" % t, desc])
                rfeats.append((rid, mx, my, zt, rib_target(rtop, mx, my, nrm, t)))
                MEAS["ribs"][rid] = {"thk": round(t, 3), "dir": round(ang, 2), "pt": [round(mx, 2), round(my, 2)]}
            except Exception:  # noqa: BLE001
                res["errors"]["rib_" + rid] = traceback.format_exc()[-300:]
        res["table_ribs"] = N("table_ribs", lambda: table((470.0, 570.0), [16.0, 24.0, 24.0, 26.0, 20.0, 90.0], rrows, size=3.3, rh=7.4))
        place_balloons(rtop, rfeats, "b5")
        # ---- side window W1 (WIN_SIDE_CUT) on the -X wall, seen in the back view
        wy = sorted(set(round(p["d"] * p["n"][1], 3) for p in MD.pl if abs(abs(p["n"][1]) - 1) < 1e-5
                        and p["bb"][3] < -15.0 and p["bb"][5] > 30.0 and 170.0 < p["d"] * p["n"][1] < 250.0))
        MEAS["window_y"] = wy
        W0, W1 = wy[0], wy[-1]
        wr = sorted([c for c in MD.cyl if abs(abs(c["dir"][0]) - 1) < 1e-3 and c["bb"][1] >= W0 - 0.5 and c["bb"][4] <= W1 + 0.5
                     and c["bb"][3] < -10.0 and c["r"] > 5.0], key=lambda c: c["r"])
        wlow = min(c["bb"][2] for c in wr)
        blends = sorted(set(round(c["r"], 2) for c in MD.cyl if c["r"] < 8.0 and c["bb"][3] < -10.0
                            and c["bb"][1] > W0 - 5.0 and c["bb"][4] < W1 + 25.0 and c["bb"][5] > 10.0))
        MEAS["window"] = {"y0": W0, "y1": W1, "radii": [round(c["r"], 3) for c in wr], "lowest_z": round(wlow, 3), "blend_radii": blends}
        bx = lambda X: xy(back, (X, 0.0, 0.0))[0]           # noqa: E731
        bz = lambda Z: xy(back, (0.0, 0.0, Z))[1]           # noqa: E731
        cw0 = N("c_win0", lambda: longest(straight(back, at(0, W0, 0.05))))
        cw1 = N("c_win1", lambda: longest(straight(back, at(0, W1, 0.05))))
        cbe = N("c_back_end", lambda: longest(straight(back, at(0, Y_END, 0.1))))
        dW = None
        if cw0 and cw1:
            dW = dimc("W_width", back, cw0, cw1, (bx(0.5 * (W0 + W1)), bz(102.0)), "horizontal", W1 - W0, etol=0.01)
        if cw1 and cbe:
            dimc("W_to_end", back, cw1, cbe, (bx(0.5 * (W1 + Y_END)), bz(102.0)), "horizontal", Y_END - W1, etol=0.01)
        for k, (c, dxo) in enumerate(()):
            def mkw(c=c, dxo=dxo):
                cen = M(*c["pt"])
                arc, _cc = arc_xy(back, cen, c["r"], 1, 0.05)
                d = nxd.dim_radial(dwg, back, arc, (bx(cen[0] + dxo), bz(-62.0)), diameter=False, text_size=DT)
                if abs(d.ComputedSize - c["r"]) > 0.01:
                    raise RuntimeError("window radius %.3f instead of %.3f" % (d.ComputedSize, c["r"]))
                return d
            D("W_R%d" % (k + 1), mkw)
        if cw0:
            pw = nxd.curve_points(cw0)
            ptop = max(pw[:2], key=lambda q: q[2])
            N("balloon_W1", lambda: gdt.balloon(dwg, "W1", (bx(W0 - 30.0), bz(70.0)), cw0, back, ptop, size=11.0, text_size=4.5))
        wrows = [["SIDE WINDOW W1 (-X WALL, THROUGH)", ""],
                 ["Y FROM DATUM B (BASIC)", "%.2f - %.2f" % (W0, W1)],
                 ["LOWEST EDGE", "Z %.2f" % wlow],
                 ["BOTTOM EDGE RADII (ABOUT X)", " / ".join("R%.2f" % c["r"] for c in wr)]]
        ywt = 570.0 - 7.4 * len(rrows) - 14.0
        res["table_win"] = N("table_win", lambda: table((470.0, ywt), [80.0, 70.0], wrows, size=3.3, rh=7.4))
        N("note_win", lambda: nxd.note(dwg, ["W1 EDGES:"], (470.0, ywt - 7.4 * len(wrows) - 9.0), size=GT))
        N("fcf_win", lambda: gdt.fcf(dwg, "ProfileOfASurface", "0.2", ("A", "B", "C"), False, (512.0, ywt - 7.4 * len(wrows) - 5.0), size=GT))
    res["overlaps5"] = nxd.overlaps(sh5)

    sheets = [sh1, sh2, sh3, sh4, sh5]
    res["export"] = ptdwg.export(dwg, sheets, OUTD, NO)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUTD, "dwg_result.json"), res)
