﻿"""LT-OUT-001 Rev B: two locating slots at the hip end for the inner's (LT-INN-001) two locating bumps.
Works on a COPY of the Rev A master (the user-edited overlay prt); the master itself is never opened for write.
args: src_prt dst_prt [params_json]

Slot = Ø D blind hole from the hip-ring top Z 85.2 down to the floor, plus a relief below the hip-bore step
(R 48.77 about the hip axis X 37.97 Z 35.18; step plane Y 269.45): without it the hole would leave a 0.10 mm
wall to that plane. The relief is open to -Y up to the bore surface, as the scan shows (an/b2_measure.py)."""
import os, sys, json, math, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf

SRC, DST = sys.argv[1], sys.argv[2]
PRM = dict(D=4.30, FLOOR=79.20, TOP=85.20, X1=27.03, X2=49.02, Y=271.70, YREL=268.95,
           HIP_X=37.97, HIP_Z=35.18, R_STEP=48.77)
if len(sys.argv) > 3:
    PRM.update(json.load(open(sys.argv[3])))
BOOL = nxh.BOOL
res = {"result": "FAIL", "params": PRM, "log": []}
log = res["log"].append
try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)

    def is_conv(b):
        try:
            return bool(b.IsConvergentBody)
        except Exception:  # noqa: BLE001
            return any(f.GetFeatureName().startswith("Convergent Body") for f in b.GetFeatures())

    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: nxh.volume(part, b))
    res["body"] = body.Name
    v0 = nxh.volume(part, body)
    res["vol_revA"] = v0
    res["features_before"] = len(list(part.Features))

    # named expressions (all Rev B values in one place)
    E = {}
    for k, nm, val, cm in (("D", "REVB_SLOT_D", PRM["D"], "locating slot hole diameter (bump scan Ø4.08 + 2 x 0.11)"),
                           ("FLOOR", "REVB_SLOT_FLOOR_Z", PRM["FLOOR"], "slot floor (bump tip Z 79.39 - 0.19)"),
                           ("TOP", "REVB_SLOT_TOP_Z", PRM["TOP"], "hip-ring top face"),
                           ("X1", "REVB_SLOT1_X", PRM["X1"], "slot 1 centre X"),
                           ("X2", "REVB_SLOT2_X", PRM["X2"], "slot 2 centre X"),
                           ("Y", "REVB_SLOT_Y", PRM["Y"], "slot centres Y"),
                           ("YREL", "REVB_SLOT_RELIEF_Y0", PRM["YREL"], "relief start, inside the hip-bore step void")):
        E[k] = nxh.expr(part, nm, val, comment=cm).Name

    ax_x = nxf.datum_axis(part, "point_dir", (0, 0, 0), (1, 0, 0), name="REVB_X_AXIS")[1]

    # 1) the two holes: sketch on the top plane, extrude down to the floor
    _, pl_top = nxh.datum_plane(part, (0, 0, PRM["TOP"]), (0, 0, 1), name="REVB_SLOT_TOP_PLANE")
    sk1 = nxf.new_sketch(part, pl_top, ax_x, nxh.point(part, 0, 0, PRM["TOP"]), name="REVB_SLOT_HOLES_SKETCH")
    for xk in ("X1", "X2"):
        c = nxh.point(part, E[xk], E["Y"], E["TOP"])
        nxf.sketch_circle(part, sk1, c, E["D"])
    res["sketch_holes"] = nxf.finish_sketch(sk1)
    sec1 = nxh.section_feature(part, [sk1.Feature], curves_only=True)
    f1 = nxh.extrude(part, sec1, (0, 0, -1), 0, f"{E['TOP']}-{E['FLOOR']}", op=BOOL.Subtract, target=body)
    f1.SetName("REVB_LOCATING_SLOT_HOLES")
    v1 = nxh.volume(part, body)
    log(f"holes: {v0:.2f} -> {v1:.2f} ({v0 - v1:.2f} mm3)")

    # 2) relief below the hip-bore step: XZ profile (floor line, two sides, R 48.77 arc about the hip axis),
    #    extruded +Y from Y0 to the hole centres
    y0 = PRM["YREL"]
    _, pl_rel = nxh.datum_plane(part, (0, y0, 0), (0, 1, 0), name="REVB_SLOT_RELIEF_PLANE")
    sk2 = nxf.new_sketch(part, pl_rel, ax_x, nxh.point(part, 0, y0, 0), name="REVB_SLOT_RELIEF_SKETCH")
    R, hx, hz, D, zf = PRM["R_STEP"], PRM["HIP_X"], PRM["HIP_Z"], PRM["D"], PRM["FLOOR"]
    for xc in (PRM["X1"], PRM["X2"]):
        xa, xb = xc - D / 2, xc + D / 2
        aa, ab = math.acos((xa - hx) / R), math.acos((xb - hx) / R)          # angle from +X towards +Z
        za, zb = hz + R * math.sin(aa), hz + R * math.sin(ab)
        ln = [nxh.line(part, (xa, y0, zf), (xb, y0, zf)), nxh.line(part, (xb, y0, zf), (xb, y0, zb)),
              nxh.line(part, (xa, y0, za), (xa, y0, zf))]
        arc = part.Curves.CreateArc(nxf.P(hx, y0, hz), nxf.V(1, 0, 0), nxf.V(0, 0, 1), R, ab, aa)
        nxf.add(sk2, *ln, arc)
        log(f"relief x {xa:.3f}..{xb:.3f}: bore arc z {za:.3f} / {zb:.3f}")
    sk2.Update()
    sk2.Deactivate(nxf.SK.ViewReorient.FalseValue, nxf.SK.UpdateLevel.Model)
    sec2 = nxh.section_feature(part, [sk2.Feature], curves_only=True)
    f2 = nxh.extrude(part, sec2, (0, 1, 0), 0, f"{E['Y']}-{E['YREL']}", op=BOOL.Subtract, target=body)
    f2.SetName("REVB_LOCATING_SLOT_RELIEF")
    v2 = nxh.volume(part, body)
    log(f"relief: {v1:.2f} -> {v2:.2f} ({v1 - v2:.2f} mm3)")

    res["vol_revB"] = v2
    res["removed_mm3"] = v0 - v2
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["solids"] = len([b for b in part.Bodies if b.IsSolidBody and not is_conv(b) and not b.IsBlanked])
    res["features_after"] = len(list(part.Features))
    try:
        part.SetUserAttribute("REVISION", -1, "B", NXOpen.Update.Option.Now)
    except Exception as e:  # noqa: BLE001
        log(f"attribute: {e}")
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    res["result"] = "PASS" if res["body_ok"] and 150 < res["removed_mm3"] < 260 else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(os.path.dirname(DST), "revB_slots.json"), res)
