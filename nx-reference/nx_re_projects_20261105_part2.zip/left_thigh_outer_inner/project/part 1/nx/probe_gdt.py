"""Probe GD&T annotations on a small drawing: FCF, datum feature symbol, arrow balloon, basic dimension."""
import os, sys, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.environ["NXH_DIR"])), "nx-assemblies", "scripts"))
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\nx\dwglib")
import NXOpen, NXOpen.Annotations
import nxh, nxd, nxd2, ptdwg
A = NXOpen.Annotations
OUT = sys.argv[1]
res = {"result": "FAIL", "steps": {}}
def step(name, fn):
    try:
        res["steps"][name] = fn()
    except Exception:
        res["steps"][name] = "ERR " + traceback.format_exc()[-700:]
def pub(o):
    return [a for a in dir(o) if not a.startswith("_")]
try:
    mp = os.path.join(OUT, "blk.prt")
    for p in (mp, os.path.join(OUT, "blk_dwg.prt")):
        if os.path.exists(p): os.remove(p)
    m = nxh.new_part(mp)
    nxh.block(m, (0, 0, 0), (100, 60, 20))
    nxh.save(m)
    dwg, comp = ptdwg.new_drawing(os.path.join(OUT, "blk_dwg.prt"), mp, "BLK")
    sh = nxd.sheet(dwg, "SH1", "A3", "third")
    v = nxd.base_view(dwg, dwg, "Top", (150, 150))
    res["ann_mgr"] = [a for a in pub(dwg.Annotations) if "Fcf" in a or "Datum" in a or "FeatureControl" in a or "Create" in a]
    res["fcfs"] = pub(dwg.Annotations.Fcfs) if hasattr(dwg.Annotations, "Fcfs") else None
    res["datums"] = pub(dwg.Annotations.Datums) if hasattr(dwg.Annotations, "Datums") else None
    crvs = [c for c, _ in nxd.curves(v)]
    res["ncurves"] = len(crvs)
    c0 = crvs[0]
    p0 = nxd.curve_points(c0)[0]
    res["c0"] = p0
    def mk_fcf(variant, pos):
        b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
        b.Characteristic = A.FeatureControlFrameBuilder.FcfCharacteristic.Position
        b.FrameStyle = A.FeatureControlFrameBuilder.FcfFrameStyle.SingleFrame
        res["list_api"] = pub(b.FeatureControlFrameDataList)
        def fill(d):
            d.ZoneShape = A.FeatureControlFrameDataBuilder.ToleranceZoneShape.Diameter
            d.ToleranceValue = "0.1"
            d.PrimaryDatumReference.Letter = "A"
            d.SecondaryDatumReference.Letter = "B"
        if variant == 1:
            d = dwg.Annotations.CreateFeatureControlFrameDataBuilder(None)
            b.FeatureControlFrameDataList.Append(d)
            fill(b.FeatureControlFrameDataList.FindItem(0))
        elif variant == 2:
            d = dwg.Annotations.CreateFeatureControlFrameDataBuilder(None)
            fill(d)
            b.FeatureControlFrameDataList.SetContents([d])
        elif variant == 3:
            d = dwg.Annotations.CreateFeatureControlFrameDataBuilder(None)
            fill(d)
            b.FeatureControlFrameDataList.Append(d)
        nxd2._leader(dwg, b.Leader, c0, v, p0)
        b.Style.LetteringStyle.GeneralTextSize = 5.0
        b.Origin.Origin.SetValue(None, None, nxh.P(pos[0], pos[1], 0))
        o = b.Commit(); b.Destroy()
        return type(o).__name__
    def fcf():
        return [mk_fcf(1, (250, 200)), mk_fcf(2, (250, 180)), mk_fcf(3, (250, 160))]
    step("fcf", fcf)
    def fcf_free():
        b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
        b.Characteristic = A.FeatureControlFrameBuilder.FcfCharacteristic.ProfileOfASurface
        d = dwg.Annotations.CreateFeatureControlFrameDataBuilder(None)
        b.FeatureControlFrameDataList.Append(d)
        d = b.FeatureControlFrameDataList.FindItem(0)
        d.ToleranceValue = "0.2"
        d.PrimaryDatumReference.Letter = "A"; d.SecondaryDatumReference.Letter = "B"; d.TertiaryDatumReference.Letter = "C"
        b.Style.LetteringStyle.GeneralTextSize = 5.0
        b.Origin.Origin.SetValue(None, None, nxh.P(250, 250, 0))
        o = b.Commit(); b.Destroy()
        return type(o).__name__
    step("fcf_free", fcf_free)
    def datum():
        b = dwg.Annotations.Datums.CreateDraftingDatumFeatureSymbolBuilder(None)
        res["dfs_builder"] = pub(b)
        b.Letter = "A"
        ld = dwg.Annotations.CreateLeaderData()
        res["leaderdata"] = pub(ld)
        try:
            ld.TerminatorType = A.LeaderData.LeaderType.Datum if hasattr(A.LeaderData, "LeaderType") else ld.TerminatorType
        except Exception as e:
            res["term_err"] = str(e)
        res["leader_enums"] = [a for a in dir(A.LeaderData) if not a.startswith("_")]
        b.Leader.Leaders.Append(ld)
        ld.Leader.SetValue(c0, v, nxh.P(*p0))
        b.Origin.Origin.SetValue(None, None, nxh.P(80, 230, 0))
        o = b.Commit(); b.Destroy()
        return type(o).__name__
    step("datum", datum)
    def balloon():
        b = dwg.Annotations.IdSymbols.CreateIdSymbolBuilder(A.IdSymbol.Null)
        b.Type = A.IdSymbolBuilder.SymbolTypes.Circle
        b.UpperText = "B1"; b.Size = 10.0
        nxd2._leader(dwg, b.Leader, c0, v, p0, "filled_arrow")
        b.Origin.Origin.SetValue(None, None, nxh.P(60, 100, 0))
        o = b.Commit(); b.Destroy()
        return type(o).__name__
    step("balloon", balloon)
    def basic():
        b = dwg.Dimensions.CreateLinearDimensionBuilder(A.Dimension.Null)
        res["tol_types"] = [a for a in dir(A.ToleranceType) if not a.startswith("_")]
        b.Measurement.Method = nxd.MM.Horizontal
        cs = [c for c in crvs if len(nxd.curve_points(c)) >= 2]
        cs = [c for c in cs if len(nxd.curve_points(c)) == 3]
        res["cs"] = [nxd.curve_points(c) for c in cs[:4]]
        b.FirstAssociativity.SetValue(nxd.SNAP.Start, cs[0], v, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(nxd.SNAP.End, cs[0], v, nxd.P0, None, None, nxd.P0)
        b.Style.DimensionStyle.ToleranceType = A.ToleranceType.Basic
        b.Style.LetteringStyle.DimensionTextSize = 5.0
        b.Origin.Origin.SetValue(None, None, nxh.P(150, 240, 0))
        o = b.Commit(); b.Destroy()
        return [o.ComputedSize, list(o.GetDimensionText()[0])]
    step("basic", basic)
    def stack():
        ao = A.Annotation.AssociativeOriginData()
        res["aod"] = pub(ao)
        res["aot"] = [a for a in dir(A.AssociativeOriginType) if not a.startswith("_")]
        res["sap"] = [a for a in dir(A) if "Stack" in a or "Alignment" in a]
        b = dwg.Dimensions.CreateLinearDimensionBuilder(A.Dimension.Null)
        cs = [c for c in crvs if len(nxd.curve_points(c)) == 3]
        b.Measurement.Method = nxd.MM.Horizontal
        b.FirstAssociativity.SetValue(nxd.SNAP.Start, cs[1], v, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(nxd.SNAP.End, cs[1], v, nxd.P0, None, None, nxd.P0)
        b.Origin.Origin.SetValue(None, None, nxh.P(150, 60, 0))
        dim = b.Commit(); b.Destroy()
        f = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
        f.Characteristic = A.FeatureControlFrameBuilder.FcfCharacteristic.Position
        f.FeatureControlFrameDataList.Append(dwg.Annotations.CreateFeatureControlFrameDataBuilder(None))
        d = f.FeatureControlFrameDataList.FindItem(0); d.ToleranceValue = "0.03"; d.PrimaryDatumReference.Letter = "A"
        res["origin_api"] = pub(f.Origin)
        ao.OriginType = A.AssociativeOriginType.AttachedToStack
        for k in res["aod"]:
            if "Stack" in k or "Annotation" in k or "Alignment" in k:
                res.setdefault("aod_keys", []).append(k)
        ao.StackAlignmentPosition = A.StackAlignmentPosition.Below
        tried = []
        for key in ("AlignedAnnotation", "VertAnnotation", "HorizAnnotation", "OffsetAnnotation"):
            try:
                ao2 = A.Annotation.AssociativeOriginData()
                ao2.OriginType = A.AssociativeOriginType.AttachedToStack
                ao2.StackAlignmentPosition = A.StackAlignmentPosition.Below
                setattr(ao2, key, dim)
                f.Origin.SetAssociativeOrigin(ao2)
                o = f.Commit()
                f.Destroy()
                return [key, type(o).__name__, tried]
            except Exception as e:
                tried.append([key, str(e)[:120]])
        f.Destroy()
        return ["none", tried]
    step("stack", stack)
    nxh.save(dwg)
    step("pdf", lambda: nxd.export_pdf(dwg, [sh], os.path.join(OUT, "probe.pdf")))
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "probe.json"), res)
