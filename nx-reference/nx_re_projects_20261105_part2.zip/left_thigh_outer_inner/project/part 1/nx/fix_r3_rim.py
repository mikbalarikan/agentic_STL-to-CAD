"""LT-OUT-001 Rev C fit fix with LT-INN-001 (assembly check, 2026-10-31; user decision "Restore the outer rim").
Works on a COPY of the user's 06:56 master. args: src_prt dst_prt

1. RIM_RABBET: on the -X wall at the hip end (X < -27, Y 240..288) the user's retouch raised the whole wall top to the
   tongue level Z 36.07. The scan shows a rabbet on the outer side, about 1.3 wide, at the rim plane (scan Z 35.05-35.1
   with the tongue at 36.3, i.e. 34.76 / 36.07 after the local +0.25 scan offset). The inner's lip sits in it.
   Rebuilt as a thin-wall extrude of the outer edge chain of the 36.07 top face: 1.3 inward (+0.3 outward overshoot
   through the skin), from 36.07 down to 34.76, subtracted. The tongue (inner part of the wall) and the tall tab at
   Y 244..249 stay.
2. PAD_EDGE_OFFSET: the pad wall next to the boss at (61.35, -40.01), the face through (56.6, -47.55, 35.4), was
   straightened by the retouch and runs 0.1-0.3 outside the Rev A wall and the scan; offset 0.2 inward.
"""
import os, sys, json, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf

SRC, DST = sys.argv[1], sys.argv[2]
W_RAB, OVER, Z_TOP, Z_RIM = 1.3, 0.3, 36.07, 34.76
res = {"result": "FAIL", "log": [], "checks": {}}
log = res["log"].append
try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)

    def is_conv(b):
        try:
            return bool(b.IsConvergentBody)
        except Exception:  # noqa: BLE001
            return False

    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: nxh.volume(part, b))
    v0 = nxh.volume(part, body)
    res.update(vol_before=v0, solids_before=len(cand), features_before=len(list(part.Features)))
    chk = res["checks"]

    def solid_at(p):
        return nxh.dist_to(part, body, p) < 1e-4

    # ------------------------------------------------ 1. rabbet
    tops = []
    for fc in body.GetFaces():
        bb = nxh.bbox(fc)
        if abs(bb[2] - Z_TOP) < 0.02 and abs(bb[5] - Z_TOP) < 0.02 and bb[0] < -27 and bb[4] > 242 and bb[1] < 288:
            tops.append(fc)
    res["top_faces"] = [[round(x, 2) for x in nxh.bbox(fc)] for fc in tops]
    assert tops, "no 36.07 top face on the -X hip-end wall"
    chain = []
    for fc in tops:
        for e in fc.GetEdges():
            p1, p2 = e.GetVertices()
            if abs(p1.Z - Z_TOP) > 0.02 or abs(p2.Z - Z_TOP) > 0.02:
                continue
            if max(p1.X, p2.X) > -27 or min(p1.Y, p2.Y) < 240 or max(p1.Y, p2.Y) > 288:
                continue
            other = [g for g in e.GetFaces() if g.Tag != fc.Tag]
            if not other:
                continue
            mid = ((p1.X + p2.X) / 2, (p1.Y + p2.Y) / 2, Z_TOP - 0.3)
            try:
                n = nxh.normal_at(other[0], mid)
            except Exception:  # noqa: BLE001
                continue
            if -n[0] > 0.3:                       # outer skin of the -X wall (straight and diagonal stretch)
                # exterior only: at both END points, 3 mm out along the face normal there is nothing within 2 mm
                ext = True
                for pv in (p1, p2):
                    pp = (pv.X, pv.Y, Z_TOP - 0.3)
                    nn = nxh.normal_at(other[0], pp)
                    q = (pp[0] + 3.0 * nn[0], pp[1] + 3.0 * nn[1], pp[2])
                    ext = ext and nxh.dist_to(part, body, q) > 2.0
                if ext:
                    chain.append(e)
    res["chain"] = [[[round(v, 2) for v in (p.X, p.Y, p.Z)] for p in e.GetVertices()] for e in chain]
    assert chain, "no outer edge chain"
    # probes: outer face position at two stations, measured along X
    st = {}
    for y, xin in ((255.0, -41.0), (280.0, -35.2)):      # bisection along X: air at -50, wall at xin
        lo_, hi_ = -50.0, xin
        assert not solid_at((lo_, y, 35.5)) and solid_at((hi_, y, 35.5)), y
        for _ in range(30):
            mx = 0.5 * (lo_ + hi_)
            if solid_at((mx, y, 35.5)):
                hi_ = mx
            else:
                lo_ = mx
        st[y] = hi_
    res["outer_x"] = st
    pin = {f"Y{int(y)}_in0.6": (x + 0.6, y, 35.5) for y, x in st.items()}
    pkeep = {f"Y{int(y)}_in2.0": (x + 2.0, y, 35.5) for y, x in st.items()}
    pfloor = {f"Y{int(y)}_floor": (x + 0.6, y, Z_RIM - 0.2) for y, x in st.items()}
    chk["before"] = {k: solid_at(p) for k, p in {**pin, **pkeep, **pfloor}.items()}
    assert all(chk["before"].values()), chk["before"]

    def rabbet(thin):
        sec = nxh.section(part, edges=chain)
        return nxf.extrude_ex(part, sec, (0, 0, -1), 0, Z_TOP - Z_RIM, op=nxh.BOOL.Subtract, target=body, thin=thin)

    f1 = None
    for thin in ((-W_RAB, OVER), (OVER, -W_RAB), (-OVER, W_RAB)):
        m = nxh.mark("rabbet try")
        try:
            f1 = rabbet(thin)
        except Exception as e:  # noqa: BLE001
            log(f"rabbet {thin}: {e}")
            nxh.undo_to(m)
            continue
        ok = (not any(solid_at(p) for p in pin.values())) and all(solid_at(p) for p in pkeep.values()) \
            and all(solid_at(p) for p in pfloor.values())
        diag = {k: solid_at(p) for k, p in {**pin, **pkeep, **pfloor}.items()}
        diag["removed"] = round(v0 - nxh.volume(part, body), 3)
        for y, x in st.items():               # where the cut is: a line across the wall, Z 35.5 and 35.95
            diag[f"line_Y{int(y)}"] = [int(solid_at((x + t, y, 35.5))) for t in (-0.5, 0.2, 0.6, 1.0, 1.4, 1.8, 2.2, 2.6)]
            diag[f"line_Y{int(y)}_z36"] = [int(solid_at((x + t, y, 35.95))) for t in (-0.5, 0.2, 0.6, 1.0, 1.4, 1.8, 2.2, 2.6)]
        res.setdefault("tries", {})[str(thin)] = diag
        log(f"rabbet thin {thin}: ok={ok}")
        if ok:
            res["rabbet_thin"] = thin
            break
        nxh.undo_to(m)
        f1 = None
    assert f1 is not None, "rabbet failed both ways"
    f1.SetName("REVC_RIM_RABBET")
    v1 = nxh.volume(part, body)
    res["rabbet_removed"] = v0 - v1
    chk["after_rabbet"] = {k: solid_at(p) for k, p in {**pin, **pkeep, **pfloor}.items()}
    # tab at Y 244..249 (top 42.2) and the tongue must still be there
    chk["tab_kept"] = solid_at((-38.0, 246.5, 41.5))
    chk["tongue_kept"] = {f"Y{int(y)}": solid_at((x + 2.0, y, 35.9)) for y, x in st.items()}
    assert chk["tab_kept"] and all(chk["tongue_kept"].values()), chk

    # ------------------------------------------------ 2. pad wall next to the boss
    p_pad = (56.6, -47.55, 35.4)
    best = min(((nxh.dist_to(part, fc, p_pad), fc) for fc in body.GetFaces()), key=lambda t: t[0])
    pad = best[1]
    pbb = nxh.bbox(pad)
    res["pad_face"] = {"dist": round(best[0], 4), "bbox": [round(x, 3) for x in pbb], "normal": [round(x, 3) for x in nxh.normal_at(pad, p_pad)]}
    # the face is the whole outer wall of the boss lobe (Z -10.4 .. 36.07, planar, normal (-0.64, -0.77, 0)); the scan
    # lies about 0.2 inside it along its height, so the whole face goes back 0.15
    nrm = nxh.normal_at(pad, p_pad)
    assert best[0] < 0.3 and abs(nrm[2]) < 0.05 and nrm[0] < -0.5 and nrm[1] < -0.6 and 53 < pbb[0] and pbb[3] < 62.5, res["pad_face"]
    v_b = nxh.volume(part, body)
    f2 = nxf.offset_region(part, [pad], -0.15)
    f2.SetName("REVC_PAD_WALL_BACK_0P15")
    v2 = nxh.volume(part, body)
    res["pad_removed"] = v_b - v2
    assert 0 < res["pad_removed"] < 60, res["pad_removed"]

    res["vol_after"] = v2
    res["errors_after"] = {k: [str(x) for x in v] for k, v in nxh.feature_errors(part).items()}
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["solids_after"] = len([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)])
    res["new_features"] = [f.GetFeatureName() + " / " + f.Name for f in list(part.Features)[res["features_before"]:]]
    # Rev B slots still there
    chk["slots"] = {f"S{i}": (not solid_at((x, 271.70, 82.0))) and solid_at((x, 271.70, 79.0)) for i, x in ((1, 27.03), (2, 49.02))}
    nxh.save(part)
    ok = res["body_ok"] and not res["errors_after"] and res["solids_after"] == res["solids_before"] and all(chk["slots"].values())
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_fix_r3.json", res)
