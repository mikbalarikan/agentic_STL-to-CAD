﻿"""Writes nx/dwg_revB.py from nx/dwg_main.py (Rev A layout v2, left untouched): revision B, revision block on every
sheet, view letters E-J (datums A-D stay unique), SH4 locating slots S1 / S2 (table rows, balloons, section H-H through
S1 and detail J with the slot size)."""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
s = open(os.path.join(HERE, "dwg_main.py"), encoding="utf-8").read()


def rep(a, b, count=1):
    global s
    n = s.count(a)
    assert n == count, (n, a[:80])
    s = s.replace(a, b)


rep('"""LT-OUT-001 Left Thigh - Outer shell: manufacturing drawing set, third angle, rev 2 of the layout.',
    '"""LT-OUT-001 Left Thigh - Outer shell, REV B drawing set (made by make_dwg_revB.py from dwg_main.py; third angle).\n'
    'Rev B: 2 locating slots S1 / S2 at the hip end (SH4 table, balloons, section H-H, detail J), revision block,\n'
    'view letters E-J so no view shares a letter with datums A-D.')
rep('ROOT = r"C:\\Users\\marya\\Desktop\\Left Thight Reverse Engineer"',
    'ROOT = r"C:\\Users\\marya\\Desktop\\Left Thight Reverse Engineer\\part 1"')
rep('sys.path.insert(0, r"C:\\Users\\marya\\Desktop\\Left Thight Reverse Engineer\\nx\\dwglib")',
    'sys.path.insert(0, r"C:\\Users\\marya\\Desktop\\Left Thight Reverse Engineer\\part 1\\nx\\dwglib")')
rep('rev="A"', 'rev=REV', count=4)
rep('"2. GEOMETRY NOT DIMENSIONED PER 3D MODEL LT-OUT-001 REV A."', '"2. GEOMETRY NOT DIMENSIONED PER 3D MODEL LT-OUT-001 REV B."')

# ---- helpers: revision, revision block, relabel
rep('def text_w(t, size=GT):', '''REV = "B"
ptdwg.DATE = "2026-10-30"
SLOT = dict(d=4.30, floor=79.20, top=85.20, y=271.70, xs=(27.03, 49.02), y_step=269.45)


def rev_block():
    """Revision block on top of the title block (same 180 mm width): REV / DESCRIPTION / DATE / BY."""
    x0, y0, x1, y1 = ptdwg.FRAME["A1"]
    rows = [["REV", "DESCRIPTION", "DATE", "BY"],
            ["A", "FIRST ISSUE", "2026-10-25", "MIA"],
            ["B", "ADDED 2 LOCATING SLOTS AT HIP END (S1, S2, SH4)", "2026-10-30", "MIA"],
            ["", "VIEW LETTERS E-J (DATUMS A-D ONLY)", "", ""]]
    top = y0 + 47.0 + 6.0 * len(rows) + 1.0
    _ts, tn = nxd2.table(m3d.CTX["dwg"], (x1 - 180.0, top), [12.0, 112.0, 32.0, 24.0], [6.0] * len(rows), rows, text_size=2.5)
    return nxd2.table_text(tn)


def relabel(view, letter):
    """Letter of a section / detail view label (NX hands out the next free letter, which can be a datum letter):
    EditViewLabelSettingsBuilder.ViewCommonViewLabel.Letter on the label from UF Draw.AskViewLabel."""
    def f():
        lab = NXOpen.TaggedObjectManager.GetTaggedObject(nxh.UFS.Draw.AskViewLabel(view.Tag))
        b = m3d.CTX["dwg"].SettingsManager.CreateDrawingEditViewLabelSettingsBuilder([lab])
        try:
            b.ViewCommonViewLabel.Letter = letter
            b.Commit()
        finally:
            b.Destroy()
        return letter
    return N("label_%s_%s" % (view.Name, letter), f)


def text_w(t, size=GT):''')

# ---- SH1..SH4: revision block after each title block
for k in (1, 2, 3):
    rep('res["tb%d"] = ' % k, 'res["rev%d"] = N("rev_block_%d", rev_block)\n    res["tb%d"] = ' % (k, k, k))
# fix indentation for the inserted line (title blocks sit at 4 spaces)
# ---- view letters
rep('    ksec = nxd2.section(dwg, ktop, M(0.0, 0.0, 0.0), (330.0, 205.0), (1.0, 1.0))\n',
    '    ksec = nxd2.section(dwg, ktop, M(0.0, 0.0, 0.0), (330.0, 205.0), (1.0, 1.0))\n    relabel(ksec, "E")\n')
rep('    hsec = nxd2.section(dwg, hfront, M(HX, 271.0, HZ), (175.0, 215.0), (1.0, 2.0))\n',
    '    hsec = nxd2.section(dwg, hfront, M(HX, 271.0, HZ), (175.0, 215.0), (1.0, 2.0))\n    relabel(hsec, "F")\n')
rep('    vv = [v for v in (hend, hfront, hsec, hdet) if v is not None]\n',
    '    if hdet is not None:\n        relabel(hdet, "G")\n    vv = [v for v in (hend, hfront, hsec, hdet) if v is not None]\n')
rep('"1:1 (front, B-B 1:2, C 2:1)"', '"1:1 (front, F-F 1:2, G 2:1)"')

# ---- SH4: section H-H through slot S1 (plane X 27.03) + detail J
rep('''    itop = nxd.base_view(dwg, dwg, "Top", (250.0, 320.0), scale=(1.0, 1.0))
    res["views4"] = {v.Name: nxd.view_info(v) for v in (itop,)}
    res["tb4"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 4, 4, rev=REV, subtitle="interior features")''',
    '''    itop = nxd.base_view(dwg, dwg, "Top", (250.0, 320.0), scale=(1.0, 1.0))
    s1x = SLOT["xs"][0]
    ssec = N("ssec", lambda: nxd2.section(dwg, itop, M(s1x, SLOT["y"], SLOT["top"]), (250.0, 135.0), (1.0, 2.0)))
    sdet = None
    if ssec is not None:
        relabel(ssec, "H")
        sdet = N("sdet", lambda: nxd.detail_view(dwg, ssec, M(s1x, SLOT["y"] + 1.0, 82.0), M(s1x, SLOT["y"] + 11.0, 82.0),
                                                  (575.0, 150.0), scale=(5.0, 1.0)))
        if sdet is not None:
            relabel(sdet, "J")
    res["views4"] = {v.Name: nxd.view_info(v) for v in (itop, ssec, sdet) if v is not None}
    res["rev4"] = N("rev_block_4", rev_block)
    res["tb4"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (H-H 1:2, J 5:1)", 4, 4, rev=REV, subtitle="interior features")''')

# table rows S1 / S2 + the FCF note covers them
rep('''            rows.append(["H%d" % i, "%.2f" % h["x"], "%.2f" % h["y"], "FLOOR HOLE", "ON FLOOR", "%s2.6 x 6 DEEP" % DIA])''',
    '''            rows.append(["H%d" % i, "%.2f" % h["x"], "%.2f" % h["y"], "FLOOR HOLE", "ON FLOOR", "%s2.6 x 6 DEEP" % DIA])
        for i, sx_ in enumerate(SLOT["xs"], 1):
            rows.append(["S%d" % i, "%.2f" % sx_, "%.2f" % SLOT["y"], "LOCATING SLOT (REV B)", "%.2f" % SLOT["top"],
                         "%s%.2f x %.2f DEEP" % (DIA, SLOT["d"], SLOT["top"] - SLOT["floor"])])''')
rep('["ALL B, P, H FEATURES:"]', '["ALL B, P, H, S FEATURES:"]')
rep('''            feats.append(("H%d" % i, h["x"], h["y"], h["z1"], h["d"] / 2.0))''',
    '''            feats.append(("H%d" % i, h["x"], h["y"], h["z1"], h["d"] / 2.0))
        for i, sx_ in enumerate(SLOT["xs"], 1):
            feats.append(("S%d" % i, sx_, SLOT["y"], SLOT["top"], SLOT["d"] / 2.0))''')

# detail J dimensions: slot width (walls Y 269.55 / 273.85 above the bore step) and depth (top Z 85.2 to floor 79.2)
rep('''    res["overlaps4"] = nxd.overlaps(sh4)''', '''        if sdet is not None:
            yl, yr = SLOT["y"] - SLOT["d"] / 2.0, SLOT["y"] + SLOT["d"] / 2.0
            jx = lambda Y: xy(sdet, (Y, -s1x, 0.0))[0]           # noqa: E731
            jz = lambda Z: xy(sdet, (SLOT["y"], -s1x, Z))[1]     # noqa: E731
            wall = lambda Y, z0, z1: (lambda: longest(straight(sdet, lambda p0, p1: abs(p0[0] - Y) < 0.03 and abs(p1[0] - Y) < 0.03
                                                               and min(p0[2], p1[2]) >= z0 - 0.3 and max(p0[2], p1[2]) <= z1 + 0.3)))  # noqa: E731
            flat = lambda Z, y0_, y1_: (lambda: longest(straight(sdet, lambda p0, p1: abs(p0[2] - Z) < 0.03 and abs(p1[2] - Z) < 0.03
                                                                  and y0_ <= 0.5 * (p0[0] + p1[0]) <= y1_)))  # noqa: E731
            cwl = N("c_slot_wall_l", wall(yl, 82.5, SLOT["top"]))
            cwr = N("c_slot_wall_r", wall(yr, SLOT["floor"], SLOT["top"]))
            if cwl and cwr:
                dw = D("S_width", lambda: lin(sdet, cwl, cwr, (jx(SLOT["y"] + 1.6), jz(SLOT["top"] + 3.2)), "horizontal", S.Start, S.Start,
                                              expect=SLOT["d"], etol=0.01))
                if dw is not None:
                    N("ovr_S_width", lambda: nxd2.override_text(dw, ["2X %s%.2f" % (DIA, SLOT["d"])]))
            ctop = N("c_slot_top", flat(SLOT["top"], yr + 0.2, yr + 4.0))
            cflo = N("c_slot_floor", flat(SLOT["floor"], yl - 0.5, yr))
            if ctop and cflo:
                D("S_depth", lambda: lin(sdet, ctop, cflo, (jx(yr + 5.3), jz(82.2)), "vertical", S.Mid, S.Mid,
                                         expect=SLOT["top"] - SLOT["floor"], etol=0.01))
            N("note_slot", lambda: nxd.note(dwg, ["S1, S2: OPEN INTO %s97.54 STEP BELOW" % DIA], (505.0, 68.0), size=GT))
    res["overlaps4"] = nxd.overlaps(sh4)''')
open(os.path.join(HERE, "dwg_revB.py"), "w", encoding="utf-8").write(s)
print("ok", len(s))
