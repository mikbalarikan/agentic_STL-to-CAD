# -*- coding: utf-8 -*-
"""LT-OUT-001 Left Thigh - Outer shell: manufacturing drawing set, third angle, rev 2 of the layout.
run_journal dwg_main.py -args <model.prt> <out_dir> [dump|full]
Master-model drawing: the model is placed with drawing (X, Y, Z) = model (y, -x, z), so the length runs left
(knee) to right (hip) in the plan view. M(x, y, z) maps a MODEL point to drawing-part coordinates.
Datum system: A = knee mounting face (Z -8.35), B = knee bore Ø110 H7, C = hip bore Ø82 H7, D = hip outer face.
Dimension text 5 mm, every dimension text placed outside the part outline; GD&T frames instead of note text;
SH4 features identified by arrow balloons placed outside the part."""
import json
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\nx\dwglib")
import NXOpen  # noqa: E402
import NXOpen.Annotations  # noqa: E402
import nxh  # noqa: E402
import nxd  # noqa: E402
import nxd2  # noqa: E402
import ptdwg  # noqa: E402
import m3d  # noqa: E402
import gdt  # noqa: E402
from m3d import D, N, xy  # noqa: E402

MODEL, OUTD = sys.argv[1], sys.argv[2]
MODE = sys.argv[3] if len(sys.argv) > 3 else "full"
os.makedirs(OUTD, exist_ok=True)
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"
NO, TITLE = "LT-OUT-001", "LEFT THIGH - OUTER SHELL"
PJ = json.load(open(os.path.join(ROOT, "nx", "params.json")))
OUTLINE = json.load(open(os.path.join(ROOT, "work", "plan_outline.json")))
FIN = json.load(open(os.path.join(os.path.dirname(MODEL), "_finalize.json")))
MASS = "%.2f kg" % (FIN["mass_g_al6061"] / 1000.0)
MAT = "Al 6061-T6"
R = [[0.0, 1.0, 0.0], [-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]]
S = nxd.SNAP
A = NXOpen.Annotations
DT = 5.0        # dimension text
GT = 4.5        # notes, GD&T frames, datum letters
res = {"result": "FAIL", "dims": {}, "errors": {}, "gdt": {}}
m3d.start(res)
HX, HZ = PJ["hip"]["ax_x"], PJ["hip"]["ax_z"]
DIA = "Ø"

# every ptdwg dimension (linear / radius) gets the larger text
_style0 = ptdwg._style
ptdwg._style = lambda b, prec=2, text_size=None: _style0(b, prec, text_size or DT)


def M(x, y, z):
    return (y, -x, z)


def straight(view, pred):
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 3 and pred(p[0], p[1]):
            out.append((c, p))
    return out


def longest(cands):
    if not cands:
        raise RuntimeError("no curve")
    return max(cands, key=lambda cp: sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)))[0]


def at(ax, val, tol=0.05):
    return lambda p0, p1: abs(p0[ax] - val) <= tol and abs(p1[ax] - val) <= tol


def dimc(name, view, ca, cb, origin, method, expect, etol=0.05, **kw):
    return D(name, lambda: m3d.dim_curves(view, ca, cb, origin, method, expect=expect, etol=etol, **kw))


def arc_xy(view, centre, r, skip, tol=0.08):
    """Circular drafting curve of radius r whose centre matches `centre` (drawing coords) in the two axes other
    than `skip` (the view direction). Among several (top / bottom edge) the one nearest the viewer wins."""
    best = None
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) != 2:
            continue
        rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
        if abs(rr - r) > tol:
            continue
        if max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip) > tol:
            continue
        if best is None or p[0][skip] > best[1][skip]:
            best = (c, p[0])
    if best is None:
        near = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) != 2:
                continue
            rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
            dc = max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip)
            if dc < 1.0 and 0.4 * r < rr < 2.5 * r:
                near.append((abs(rr - r), -p[0][skip], c, p[0], round(rr, 3)))
        if near:
            near.sort(key=lambda t: (round(t[0], 2), t[1]))
            res.setdefault("arc_fallback", []).append([view.Name, [round(v, 2) for v in centre], r, near[0][4]])
            return near[0][2], near[0][3]
        cand = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) == 2:
                rr = sum((p[0][i] - p[1][i]) ** 2 for i in range(3)) ** 0.5
                cand.append((max(abs(p[0][i] - centre[i]) for i in range(3) if i != skip), [round(v, 2) for v in p[0]], round(rr, 3)))
        cand.sort(key=lambda t: t[0])
        raise RuntimeError("arc_xy: no R%.3f at %s in %s; nearest %s" % (r, [round(v, 2) for v in centre], view.Name, cand[:6]))
    return best


def on_arc(centre, r, skip, toward):
    """Point of the arc (drawing coords) in the direction of `toward` (drawing coords, same plane)."""
    ax = [i for i in range(3) if i != skip]
    dx, dy = toward[ax[0]] - centre[ax[0]], toward[ax[1]] - centre[ax[1]]
    n = math.hypot(dx, dy) or 1.0
    p = list(centre)
    p[ax[0]] += r * dx / n
    p[ax[1]] += r * dy / n
    return tuple(p)


def lin(view, ca, cb, origin, method, sa, sb, before=None, after=None, basic=False, tol=None, expect=None, etol=0.05):
    """Linear dimension with explicit snaps; basic=True draws it boxed (theoretically exact)."""
    meth = {"horizontal": nxd.MM.Horizontal, "vertical": nxd.MM.Vertical, "point": nxd.MM.PointToPoint,
            "cylindrical": nxd.MM.Cylindrical}[method]
    dwg = m3d.CTX["dwg"]
    b = dwg.Dimensions.CreateLinearDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = meth
        b.FirstAssociativity.SetValue(sa, ca, view, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(sb, cb, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=tol, before=before, after=after)
        _style0(b, 2, DT)
        if basic:
            b.Style.DimensionStyle.ToleranceType = A.ToleranceType.Basic
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if expect is not None and abs(d.ComputedSize - expect) > etol:
        v = d.ComputedSize
        ptdwg._delete([d])
        raise RuntimeError("lin: %.4f instead of %.4f" % (v, expect))
    return d


def dia_callout(view, arc, origin, before=None, after=None, tol=None):
    return nxd.dim_radial(m3d.CTX["dwg"], view, arc, origin, diameter=True, before=before, after=after, tol=tol,
                          text_size=DT)


def stack_fcf(name, dim, char, tol, datums=(), dia=False, pos=None):
    """FCF stacked under a dimension (NX 'attached to stack' origin); fallback: free FCF at `pos`."""
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
            try:
                b.Characteristic = gdt.characteristic(char)
                b.FrameStyle = A.FeatureControlFrameBuilder.FcfFrameStyle.SingleFrame
                b.FeatureControlFrameDataList.Append(dwg.Annotations.CreateFeatureControlFrameDataBuilder(None))
                d = b.FeatureControlFrameDataList.FindItem(0)
                if dia:
                    d.ZoneShape = A.FeatureControlFrameDataBuilder.ToleranceZoneShape.Diameter
                d.ToleranceValue = str(tol)
                for r_, l_ in zip((d.PrimaryDatumReference, d.SecondaryDatumReference, d.TertiaryDatumReference), datums):
                    r_.Letter = l_
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(dim))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-400:]
            if pos is None:
                raise
            o = gdt.fcf(dwg, char, tol, datums, dia, pos, size=GT)
            res["gdt"][name] = "free"
            return o
    return N(name, f)


def stack_below(ann):
    """Associative origin: stacked below `ann` (probe: only OffsetAnnotation carries the stack parent)."""
    ao = A.Annotation.AssociativeOriginData()
    ao.OriginType = A.AssociativeOriginType.AttachedToStack
    ao.StackAlignmentPosition = A.StackAlignmentPosition.Below
    ao.OffsetAnnotation = ann
    return ao


def datum_under(name, letter, ann, fallback):
    """Datum feature symbol stacked below an FCF / dimension of the datum feature (no leader); fallback()."""
    dwg = m3d.CTX["dwg"]

    def f():
        try:
            b = dwg.Annotations.Datums.CreateDraftingDatumFeatureSymbolBuilder(None)
            try:
                b.Letter = letter
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(ann))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-300:]
            o = fallback()
            res["gdt"][name] = "leader"
            return o
    return N(name, f)


def callout(name, view, arc, cen, r, skip, toward, lines):
    """Leader note (arrow on the hole edge) at the sheet image of drawing point `toward`."""
    a = on_arc(cen, r, skip, toward)
    pos = xy(view, toward)
    return N(name, lambda: nxd2.leader_note(m3d.CTX["dwg"], lines, pos, arc, view, a, size=DT))


def table(origin, cw, rows, size=3.5, rh=8.0):
    """Tabular note, title row merged and in the same text size as the body."""
    m = [(0, 0, 0, len(cw) - 1)]
    _ts, tn = nxd2.table(m3d.CTX["dwg"], origin, cw, [rh] * len(rows), rows, text_size=size, merges=m, sizes={(0, 0): size})
    return nxd2.table_text(tn)


def note_lines(lines, x, y, step=8.0, size=GT):
    """One note per line (fixed pitch), so a GD&T frame can sit at the end of a given line."""
    for i, t in enumerate(lines):
        if not t:
            continue
        N("note_%d_%d" % (int(x), int(y - i * step)), lambda t=t, i=i: nxd.note(m3d.CTX["dwg"], [t], (x, y - i * step), size=size))


def text_w(t, size=GT):
    return len(t) * 0.745 * size


try:
    dwg, comp = m3d.new_drawing(os.path.join(OUTD, NO + "_dwg.prt"), MODEL, "LEFT_THIGH_OUTER", R, refset="SOLID")
    # ================================================================ SHEET 1 general arrangement (A1, 1:1)
    sh1, _g = ptdwg.sheet(dwg, "A1")
    front = nxd.base_view(dwg, dwg, "Front", (255.0, 150.0), scale=(1.0, 1.0))
    top = nxd.projected_view(dwg, front, (255.0, 400.0))
    right = nxd.projected_view(dwg, front, (565.0, 150.0))
    iso = nxd.base_view(dwg, dwg, "Isometric", (705.0, 470.0), scale=(1.0, 2.0))
    res["views1"] = {v.Name: nxd.view_info(v) for v in (front, top, right, iso)}
    res["tb1"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (iso 1:2)", 1, 4, rev="A", subtitle="general arrangement")
    if MODE == "dump":
        for v, n in ((front, "front"), (top, "top"), (right, "right")):
            res["dump_" + n] = m3d.dump(v, os.path.join(OUTD, "dump_sh1_%s.json" % n))
    else:
        fx = lambda X: xy(front, (X, 0.0, 0.0))[0]           # noqa: E731
        fz = lambda Z: xy(front, (0.0, 0.0, Z))[1]           # noqa: E731
        c_top = N("c_ringtop", lambda: longest(straight(front, at(2, PJ["hip"]["ring_top_z"], 0.05))))
        c_skirt = N("c_skirt", lambda: longest(straight(front, at(2, -13.9, 0.05))))
        c_knee = N("c_knee", lambda: longest(straight(front, at(0, -PJ["hub"]["r_out"], 0.1))))
        c_end = N("c_end", lambda: longest(straight(front, at(0, 287.4, 0.1))))
        rim = PJ["levels"]["rim"]
        if c_end:
            pe = nxd.curve_points(c_end)
            ptop = max(pe[:2], key=lambda q: q[2])
            if c_skirt:
                ps = nxd.curve_points(c_skirt)[0]
                D("H_skirt_rim", lambda: m3d.dim_ends(front, c_skirt, ps, c_end, ptop, (fx(302.0), fz(10.0)), "vertical", expect=rim + 13.9, etol=0.1))
            if c_top:
                pt = nxd.curve_points(c_top)[0]
                D("H_rim_ringtop", lambda: m3d.dim_ends(front, c_end, ptop, c_top, pt, (fx(316.0), fz(60.0)), "vertical",
                                                       expect=PJ["hip"]["ring_top_z"] - rim, etol=0.1))
        if c_knee and c_end:
            dimc("L_overall", front, c_knee, c_end, (fx(110.0), fz(-60.0)), "horizontal", 355.25, etol=0.2)
        tx = lambda X: xy(top, (X, 0.0, 0.0))[0]             # noqa: E731
        ty = lambda Y: xy(top, (0.0, Y, 0.0))[1]             # noqa: E731
        c_bore = N("c_kbore", lambda: ptdwg.arc_at(top, (0.0, 0.0, 0.0), 55.0, tol=0.05))
        c_hf1 = N("c_hipface_in", lambda: longest(straight(top, at(0, PJ["hip"]["y_plate_in"], 0.05))))
        c_hf2 = N("c_hipface_out", lambda: longest(straight(top, at(0, PJ["hip"]["y_ring_out"], 0.05))))
        if c_bore and c_hf1:
            D("L_knee_hipface_in", lambda: lin(top, c_bore, c_hf1, (tx(133.0), ty(102.0)), "horizontal", S.Center, S.Mid,
                                               basic=True, expect=266.5))
        if c_bore and c_hf2:
            D("L_knee_hipface_out", lambda: lin(top, c_bore, c_hf2, (tx(140.0), ty(118.0)), "horizontal", S.Center, S.Mid,
                                                basic=True, expect=276.85))
        x0, y0 = 470.0, 330.0
        note_lines(["NOTES",
                    "1. GENERAL TOLERANCES ISO 2768-mK. GD&T PER ISO 1101.",
                    "2. GEOMETRY NOT DIMENSIONED PER 3D MODEL LT-OUT-001 REV A.",
                    "3. ALL SURFACES UNLESS OTHERWISE SPECIFIED:",
                    "",
                    "4. INTERNAL CORNERS R3 MAX. BREAK SHARP EDGES 0.2-0.5.",
                    "5. Ra 3.2 UNLESS OTHERWISE SPECIFIED."], x0, y0, step=9.0)
        N("fcf_profile_all", lambda: gdt.fcf(dwg, "ProfileOfASurface", "0.2", ("A", "B", "C"), False,
                                             (x0 + 7.0, y0 - 4 * 9.0 + 2.0), size=GT))
    res["overlaps1"] = nxd.overlaps(sh1)

    # ================================================================ SHEET 2 knee hub (A1, 1:1)
    sh2, _g = ptdwg.sheet(dwg, "A1")
    ktop = nxd.base_view(dwg, dwg, "Top", (330.0, 425.0), scale=(1.0, 1.0))
    ksec = nxd2.section(dwg, ktop, M(0.0, 0.0, 0.0), (330.0, 205.0), (1.0, 1.0))
    res["views2"] = {v.Name: nxd.view_info(v) for v in (ktop, ksec)}
    res["tb2"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 2, 4, rev="A", subtitle="knee hub")
    if MODE == "dump":
        res["dump_ksec"] = m3d.dump(ksec, os.path.join(OUTD, "dump_sh2_ksec.json"))
        res["dump_ktop"] = m3d.dump(ktop, os.path.join(OUTD, "dump_sh2_ktop.json"))
    else:
        sx = lambda X: xy(ksec, (X, 0.0, 0.0))[0]            # noqa: E731
        sz = lambda Z: xy(ksec, (0.0, 0.0, Z))[1]            # noqa: E731
        vert = lambda X, z0, z1: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[0] - X) < 0.06 and abs(p1[0] - X) < 0.06
                                                           and min(p0[2], p1[2]) >= z0 - 0.3 and max(p0[2], p1[2]) <= z1 + 0.3)))  # noqa: E731
        hor = lambda Z, x0, x1: (lambda: longest(straight(ksec, lambda p0, p1: abs(p0[2] - Z) < 0.06 and abs(p1[2] - Z) < 0.06
                                                          and x0 <= 0.5 * (p0[0] + p1[0]) <= x1)))  # noqa: E731
        # diameters stacked BELOW the section (white space under the knee), smallest nearest the part
        dims2 = {}
        cols = [("D92", 46.05, -8.35, -6.1, 92.1, None, -42.0), ("D96", 48.0, -6.1, -4.12, 96.0, None, -58.0),
                ("D110", 55.0, -4.12, 0.0, 110.0, "H7", -74.0), ("D125_5", 62.75, -13.9, -8.35, 125.5, "H7", -112.0)]
        for name, r, z0, z1, val, tol, zz in cols:
            ca = N("c_%s_a" % name, vert(-r, z0, z1)); cb = N("c_%s_b" % name, vert(r, z0, z1))
            if ca and cb:
                dims2[name] = dimc(name, ksec, ca, cb, (sx(0.0), sz(zz)), "cylindrical", val, etol=0.1, tol=tol)
        f110 = None
        if dims2.get("D110"):
            f110 = stack_fcf("fcf_perp_110", dims2["D110"], "Perpendicularity", "0.03", ("A",), True, (sx(0.0) - 20.0, sz(-74.0) - 10.0))
        if dims2.get("D125_5"):
            stack_fcf("fcf_pos_125", dims2["D125_5"], "Position", "0.05", ("A", "B"), True, (sx(0.0) - 20.0, sz(-112.0) - 10.0))
        # datum B stacked under the Ø110 frame; datum A + flatness on the mounting face Z -8.35, in the recess opening
        c_b110 = N("c_D110_b2", vert(55.0, -4.12, 0.0))
        if f110 is not None:
            datum_under("datum_B", "B", f110, lambda: gdt.datum(dwg, "B", (sx(80.0), sz(-60.0)), c_b110, ksec, (55.0, 0.0, -3.0), size=GT))
        c_fA = N("c_faceA", hor(-8.35, -62.7, -46.1))
        if c_fA:
            fA = N("fcf_flat_A", lambda: gdt.fcf(dwg, "Flatness", "0.03", (), False, (sx(-36.0), sz(-20.0)), c_fA, ksec,
                                                 (-54.0, 0.0, -8.35), size=GT))
            if fA is not None:
                datum_under("datum_A", "A", fA, lambda: gdt.datum(dwg, "A", (sx(-36.0), sz(-30.0)), c_fA, ksec, (-50.0, 0.0, -8.35), size=GT))
        # depths, left of the section
        c_floor = N("c_floor", hor(0.0, -64.0, -55.5))
        c_step1 = N("c_step1", hor(-4.12, -55.0, -48.0))
        c_step2 = N("c_step2", hor(-6.1, -48.0, -46.0))
        c_bot = N("c_bot", hor(-8.35, -62.7, -46.1))
        c_sk = N("c_skirt2", hor(-13.9, -64.5, -62.5))
        x_l = sx(-75.0)
        if c_floor and c_step1:
            dimc("Z_step1", ksec, c_floor, c_step1, (x_l - 8, sz(-2.0)), "vertical", 4.12, etol=0.05)
        if c_floor and c_step2:
            dimc("Z_step2", ksec, c_floor, c_step2, (x_l - 22, sz(-3.0)), "vertical", 6.10, etol=0.05)
        if c_floor and c_bot:
            dimc("Z_bottom", ksec, c_floor, c_bot, (x_l - 36, sz(-4.0)), "vertical", 8.35, etol=0.05)
        if c_bot and c_sk:
            dimc("Z_skirt", ksec, c_bot, c_sk, (x_l - 50, sz(-11.0)), "vertical", 5.55, etol=0.05)
        # knee bolt circle on the plan view: callout + position frame above the view, basic PCD
        kb = PJ["knee_bolts"]
        rk = kb["pcd"] / 2.0

        def kh(ang):
            a = math.radians(ang)
            return M(rk * math.cos(a), rk * math.sin(a), 0.0)
        hole = N("c_khole", lambda: arc_xy(ktop, kh(186.0), kb["d"] / 2.0, 2))
        if hole:
            tw = M(-112.0, -62.0, hole[1][2])
            dk = callout("callout_knee_holes", ktop, hole[0], hole[1], kb["d"] / 2.0, 2, tw,
                         ["30X %s%.2f THRU EQ SP" % (DIA, kb["d"])])
            if dk:
                stack_fcf("fcf_pos_kholes", dk, "Position", "0.1", ("A", "B"), True, None)
        h90 = N("c_khole90", lambda: arc_xy(ktop, kh(90.0), kb["d"] / 2.0, 2))
        h270 = N("c_khole270", lambda: arc_xy(ktop, kh(270.0), kb["d"] / 2.0, 2))
        if h90 and h270:
            D("PCD_knee", lambda: lin(ktop, h270[0], h90[0], xy(ktop, M(-14.0, 0.0, 0.0)), "cylindrical", S.Center, S.Center,
                                      basic=True, expect=kb["pcd"]))
    res["overlaps2"] = nxd.overlaps(sh2)

    # ================================================================ SHEET 3 hip ring (A1)
    sh3, _g = ptdwg.sheet(dwg, "A1")
    hend = nxd.base_view(dwg, dwg, "Right", (175.0, 400.0), scale=(1.0, 1.0))
    hfront = nxd.base_view(dwg, dwg, "Front", (175.0, 95.0), scale=(1.0, 2.0))
    hsec = nxd2.section(dwg, hfront, M(HX, 271.0, HZ), (175.0, 215.0), (1.0, 2.0))
    hdet = N("hdet", lambda: nxd.detail_view(dwg, hsec, M(HX, 271.0, HZ), M(HX + 60.0, 271.0, HZ), (560.0, 380.0), scale=(2.0, 1.0)))
    vv = [v for v in (hend, hfront, hsec, hdet) if v is not None]
    res["views3"] = {v.Name: nxd.view_info(v) for v in vv}
    res["tb3"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (front, B-B 1:2, C 2:1)", 3, 4, rev="A", subtitle="hip ring")
    if MODE == "dump":
        res["dump_hsec"] = m3d.dump(hsec, os.path.join(OUTD, "dump_sh3_hsec.json"))
        if hdet is not None:
            res["dump_hdet"] = m3d.dump(hdet, os.path.join(OUTD, "dump_sh3_hdet.json"))
        res["dump_hend"] = m3d.dump(hend, os.path.join(OUTD, "dump_sh3_hend.json"))
    elif hdet is not None:
        yax = -HX
        rx = lambda X: xy(hdet, (X, yax, HZ))[0]                   # noqa: E731
        ry = lambda Yd: xy(hdet, (271.0, Yd, HZ))[1]               # noqa: E731
        axl = lambda r, x0, x1, t=0.06: (lambda: longest(straight(hdet, lambda p0, p1: abs(p0[1] - (yax + r)) < t and abs(p1[1] - (yax + r)) < t
                                                               and min(p0[0], p1[0]) >= x0 - 0.6 and max(p0[0], p1[0]) <= x1 + 0.6)))  # noqa: E731
        dims3 = {}
        # dimension lines RIGHT of the outer face (white space inside the detail circle), smallest first
        for name, r, y0_, y1_, val, tol, xo in (("HD82", 40.99, 271.4, 275.85, 82.0, "H7", 16.0),
                                                ("HD85_96", 42.98, 269.45, 271.4, 85.96, None, 46.0),
                                                ("HD97_54", 48.77, 266.5, 269.45, 97.54, "H7", -10.35 - 30.0)):
            ca = N("c_%s_a" % name, axl(-r, y0_, y1_, 0.15)); cb = N("c_%s_b" % name, axl(r, y0_, y1_, 0.15))
            if ca and cb:
                dims3[name] = dimc(name, hdet, ca, cb, (rx(276.85 + xo), ry(yax)), "cylindrical", val, etol=0.1, tol=tol)
                if dims3[name] is not None and name == "HD82":
                    N("ovr_HD82", lambda: nxd2.override_text(dims3["HD82"], ["82.00"]))
            else:
                res["dbg_" + name] = [[[round(v, 2) for v in q] for q in pp[:2]] for c, pp in
                                      straight(hdet, lambda p0, p1: abs(abs(p0[1] - yax) - r) < 1.5 and abs(abs(p1[1] - yax) - r) < 1.5)][:16]
        if dims3.get("HD82"):
            stack_fcf("fcf_pos_82", dims3["HD82"], "Position", "0.1", ("A", "B"), True, None)
        if dims3.get("HD97_54"):
            stack_fcf("fcf_pos_97", dims3["HD97_54"], "Position", "0.05", ("D", "C"), True, None)
        # datum C on the Ø82 bore wall, datum D + perpendicularity on the outer face (Y 276.85)
        c82 = N("c_HD82_wall", axl(-40.99, 271.4, 275.85, 0.15))
        if c82:
            N("datum_C", lambda: gdt.datum(dwg, "C", (rx(262.0), ry(yax - 40.99) - 16.0), c82, hdet, (273.6, yax - 40.99, HZ), size=GT))
        c_face = N("c_outer_face", lambda: longest(straight(hdet, at(0, 276.85, 0.06))))
        if c_face:
            pf = nxd.curve_points(c_face)
            pm = max(pf[:2], key=lambda q: q[1])
            atp = (276.85, pm[1] - 1.5, HZ)
            fD = N("fcf_perp_D", lambda: gdt.fcf(dwg, "Perpendicularity", "0.03", ("C",), False, (rx(336.0), ry(atp[1]) + 30.0),
                                                 c_face, hdet, (276.85, pm[1] - 4.0, HZ), size=GT))
            if fD is not None:
                datum_under("datum_D", "D", fD, lambda: gdt.datum(dwg, "D", (rx(336.0), ry(atp[1]) + 14.0), c_face, hdet, atp, size=GT))
        # hip bolt circle on the end view: callout above the ring, basic PCD above the ring top
        hb = PJ["hip_bolts"]
        rh_ = hb["pcd"] / 2.0

        def hh(ang, y):
            a = math.radians(ang)
            return M(HX + rh_ * math.cos(a), y, HZ + rh_ * math.sin(a))
        step_a = 360.0 / hb["n"]
        top_k = max(range(hb["n"]), key=lambda k: math.sin(math.radians(k * step_a)) - 1e-3 * math.cos(math.radians(k * step_a)))
        hole3 = N("c_hhole", lambda: arc_xy(hend, hh(top_k * step_a, 276.85), hb["cb_d"] / 2.0, 0, 0.1))
        if hole3:
            dh = callout("callout_hip_holes", hend, hole3[0], hole3[1], hb["cb_d"] / 2.0, 0, M(HX - 75.0, 276.85, 126.0),
                         ["26X %s%.2f THRU EQ SP" % (DIA, hb["d"]), "C'BORE %s%.2f x %.2f DEEP" % (DIA, hb["cb_d"], 276.85 - hb["cb_y0"])])
            if dh:
                stack_fcf("fcf_pos_hholes", dh, "Position", "0.1", ("D", "C"), True, None)
        h0 = N("c_hhole0", lambda: arc_xy(hend, hh(0.0, 276.85), hb["cb_d"] / 2.0, 0, 0.1))
        h180 = N("c_hhole180", lambda: arc_xy(hend, hh(180.0, 276.85), hb["cb_d"] / 2.0, 0, 0.1))
        if h0 and h180:
            D("PCD_hip", lambda: lin(hend, h180[0], h0[0], xy(hend, M(HX, 276.85, 100.0)), "cylindrical", S.Center, S.Center,
                                     basic=True, expect=hb["pcd"]))
    res["overlaps3"] = nxd.overlaps(sh3)

    # ================================================================ SHEET 4 interior features (A1, 1:1)
    sh4, _g = ptdwg.sheet(dwg, "A1")
    itop = nxd.base_view(dwg, dwg, "Top", (250.0, 320.0), scale=(1.0, 1.0))
    res["views4"] = {v.Name: nxd.view_info(v) for v in (itop,)}
    res["tb4"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 4, 4, rev="A", subtitle="interior features")
    if MODE != "dump":
        rows = [["FEATURE LOCATIONS (BASIC, MODEL FRAME: ORIGIN ON B, Z0 = 8.35 ABOVE A)", "", "", "", "", ""],
                ["ID", "X", "Y", "FEATURE", "TOP Z", "HOLE"]]
        for i, b in enumerate(PJ["bosses"], 1):
            rows.append(["B%d" % i, "%.2f" % b["x"], "%.2f" % b["y"], "BOSS %s15, SPIGOT %s10" % (DIA, DIA), "36.07 / 39.04",
                         "%s5.2 x 12 DEEP" % DIA])
        for i, p in enumerate(PJ["pins"], 1):
            rows.append(["P%d" % i, "%.2f" % p["x"], "%.2f" % p["y"], "PIN %s4 ON BOSS %s9" % (DIA, DIA), "%.2f" % p["top_z"], "-"])
        for i, h in enumerate(PJ["small_holes"], 1):
            rows.append(["H%d" % i, "%.2f" % h["x"], "%.2f" % h["y"], "FLOOR HOLE", "ON FLOOR", "%s2.6 x 6 DEEP" % DIA])
        N("table4", lambda: table((470.0, 565.0), [18.0, 26.0, 26.0, 78.0, 36.0, 52.0], rows))
        N("fcf_table", lambda: gdt.fcf(dwg, "Position", "0.1", ("A", "B", "C"), True, (470.0, 565.0 - 8.0 * len(rows) - 12.0), size=GT))
        N("fcf_table_note", lambda: nxd.note(dwg, ["ALL B, P, H FEATURES:"], (470.0, 565.0 - 8.0 * len(rows) - 4.0), size=GT))
        lv = [["FLAT LEVELS (Z FROM KNEE FLOOR)", ""], ["RIM / PARTING PLANE", "34.76"], ["TONGUE TOP (INNER EDGE OF RIM)", "36.07"],
              ["BOSS SPIGOT TOP", "39.04"], ["HIP RING TOP FLAT", "85.20"], ["KNEE FLOOR", "Z0 (8.35 ABOVE A)"],
              ["LOW HUB WALL", "7.49"], ["PADS", "33.90 / 29.55 / 28.39 / 27.67"], ["RIB TOPS", "4.97 / 4.78 / 0.00 / -5.00 / -20.29"],
              ["LONG RIB RAMP", "-13.25 (Y 166) TO -20.29 (Y 206.5)"]]
        N("table_levels", lambda: table((470.0, 330.0), [100.0, 136.0], lv))

        # ---- balloons outside the part outline (plan view: sheet up = model -X)
        oy0, xs_min, xs_max = OUTLINE["y0"], OUTLINE["xmin"], OUTLINE["xmax"]

        def band(y, w=9.0):
            i0 = max(0, int(y - w - oy0)); i1 = min(len(xs_min) - 1, int(y + w - oy0))
            lo = [v for v in xs_min[i0:i1 + 1] if v == v]; hi = [v for v in xs_max[i0:i1 + 1] if v == v]
            return (min(lo) if lo else -70.0), (max(hi) if hi else 120.0)
        feats = []
        for i, b in enumerate(PJ["bosses"], 1):
            feats.append(("B%d" % i, b["x"], b["y"], b["z1"], b["nub_d"] / 2.0))
        for i, p in enumerate(PJ["pins"], 1):
            feats.append(("P%d" % i, p["x"], p["y"], p["top_z"], p["d"] / 2.0))
        for i, h in enumerate(PJ["small_holes"], 1):
            feats.append(("H%d" % i, h["x"], h["y"], h["z1"], h["d"] / 2.0))
        GAP, PITCH = 17.0, 16.0
        sides = {"up": [], "down": []}
        for f in feats:
            lo, hi = band(f[2])
            sides["up" if (f[1] - lo) <= (hi - f[1]) else "down"].append(list(f))
        place = []
        for side, lst in sides.items():
            lst.sort(key=lambda f: f[2])
            ylast = -1e9
            for f in lst:
                yb = max(f[2], ylast + PITCH)
                ylast = yb
                lo, hi = band(min(f[2], yb), 9.0 + abs(yb - f[2]))
                xb = lo - GAP if side == "up" else hi + GAP
                place.append((f, xb, yb))
        res["balloons"] = []
        for f, xb, yb in place:
            name, x, y, z, r = f
            pos = xy(itop, M(xb, yb, z))

            def mk(name=name, x=x, y=y, z=z, r=r, pos=pos, xb=xb, yb=yb):
                try:
                    c, cen = arc_xy(itop, M(x, y, z), r, 2, 0.12)
                    a = on_arc(cen, r, 2, M(xb, yb, cen[2]))
                except RuntimeError:
                    c, a = ptdwg.near(itop, on_arc(M(x, y, z), r, 2, M(xb, yb, z)))
                    res.setdefault("balloon_near", []).append(name)
                return gdt.balloon(dwg, name, pos, c, itop, a, size=11.0, text_size=4.5)
            N("balloon_" + name, mk)
            res["balloons"].append([name, round(xb, 1), round(yb, 1)])
    res["overlaps4"] = nxd.overlaps(sh4)

    sheets = [sh1, sh2, sh3, sh4]
    res["export"] = ptdwg.export(dwg, sheets, OUTD, NO)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUTD, "dwg_result.json"), res)
