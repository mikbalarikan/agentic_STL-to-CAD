"""Probe: why does the inner loft not trim a block? Examine the sheet, then trim blocks over y sub-ranges."""
import os, sys, json, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"])
import NXOpen
import nxh, nxf, curvekit as ck
OUT = sys.argv[1]
WK = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\work"
res = {"log": []}
try:
    part = nxh.new_part(os.path.join(OUT, "probe.prt"))
    sec = [s for s in json.load(open(os.path.join(WK, sys.argv[3] + ".json")))["sections"] if s["y"] >= float(sys.argv[2])]
    sps = [ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True)[1] for s in sec]
    tc = nxf.through_curves(part, [nxh.section(part, curves=[sp]) for sp in sps], solid=False)
    sh = tc.GetBodies()[0]
    try:
        res["examine"] = nxh.examine_geometry(part, sh)
    except Exception as e:
        res["examine_err"] = str(e)
    Y0 = float(sys.argv[2]) + 1.0
    for (y0, y1, ztop) in ((Y0, 287.4, 40), (Y0, 0, 40), (0, 100, 40), (100, 200, 40), (200, 287.4, 40), (Y0, 287.4, 38)):
        m = nxh.mark("t", False)
        try:
            bf, blk = nxh.block(part, (-130.0, float(y0), -70.0), (320.0, float(y1 - y0), float(ztop + 70)))
            nxf.trim_body(part, blk, reverse=True, sheet=sh)
            res["log"].append(f"y {y0}..{y1} z<{ztop}: OK vol {nxh.volume(part, blk):.0f}")
        except Exception as e:
            res["log"].append(f"y {y0}..{y1} z<{ztop}: FAIL {str(e)[:80]}")
        nxh.undo_to(m)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "probe.json"), res)
