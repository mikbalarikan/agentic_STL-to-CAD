# -*- coding: utf-8 -*-
"""Shared helpers of the M3 IM01 drawing journals (on top of ptdwg / nxd2 / nxd): result bookkeeping, sheet-point
mapping, notes, leader notes, thread-crest pick, parting line, gate and pull symbols, standard moulding notes,
thread / fit data tables, view-curve dump."""
import json
import math
import os
import traceback

import nxh
import nxd
import nxd2
import ptdwg

B = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\nx\dwg"
ASM = B
OUT = os.path.join(B, "out")
WORK = os.path.join(B, "work")
DWG = os.path.join(B, "dwg")
for _d in (OUT, WORK, DWG):
    os.makedirs(_d, exist_ok=True)
TXT = 2.5
CTX = {"dwg": None, "res": None}


def _curve_points(c):
    """nxd.curve_points without the crash on a drafting curve that reports an empty location (seen on the manifold)."""
    out = []
    for loc in c.GetLocations() or []:
        if loc is not None and loc.Location is not None:
            out.append((loc.Location.X, loc.Location.Y, loc.Location.Z))
    return out


nxd.curve_points = _curve_points


def start(res):
    CTX["res"] = res


def D(name, fn):
    """Dimension: run fn, record the read-back (or the error)."""
    res = CTX["res"]
    try:
        d = fn()
        res["dims"][name] = ptdwg.info(d)
        return d
    except Exception:  # noqa: BLE001
        res["errors"][name] = traceback.format_exc()[-900:]
        return None


def N(name, fn):
    res = CTX["res"]
    try:
        return fn()
    except Exception:  # noqa: BLE001
        res["errors"][name] = traceback.format_exc()[-900:]
        return None


def xy(view, p):
    return nxd.to_sheet(view, p)


def note(lines, pos, size=TXT):
    return nxd.note(CTX["dwg"], lines if isinstance(lines, list) else [lines], pos, size=size)


def text_width(lines, size=TXT):
    """Approximate width (mm) of a note block (ISO lettering, measured 1.86 mm per character at 2.5)."""
    return max(len(t) for t in lines) * 0.745 * size


def lnote(name, lines, pos, view, at, size=TXT, kind="on", side=None):
    """Leader note to the drafting curve through MODEL point `at` (or the curve closest to it). The leader leaves
    the side of the text facing the target (side='left' / 'right' forces it)."""
    lines = lines if isinstance(lines, list) else [lines]

    def f():
        try:
            c, _s = ptdwg.pick(view, at, 0.05, kind)
            p = at
        except RuntimeError:
            c, p = ptdwg.near(view, at)
        sd = side
        if sd is None:
            tx = xy(view, p)[0]
            sd = "right" if tx > pos[0] + text_width(lines, size) else "left"
        return nxd2.leader_note(CTX["dwg"], lines, pos, c, view, p, size=size, side=sd)
    return N(name, f)


def dim_curves(view, ca, cb, origin, method, sa=None, sb=None, text=None, tol=None, before=None, after=None, expect=None,
               etol=0.01, prec=2):
    """Linear dimension between two drafting curves (snaps tried until the value matches `expect`)."""
    S = nxd.SNAP
    if sa or sb:
        combos = [(sa or S.Mid, sb or S.Mid)]
    else:
        combos = [(S.Start, S.Start), (S.Start, S.End), (S.End, S.Start), (S.End, S.End), (S.Mid, S.Mid)]
    d = None
    for a, b in combos:
        d = ptdwg.dim_linear(CTX["dwg"], view, ca, cb, origin, method, a, b, tol=tol, before=before, after=after, prec=prec)
        if expect is None or abs(d.ComputedSize - expect) <= etol:
            break
        ptdwg._delete([d])
        d = None
    if d is None:
        raise RuntimeError("dim_curves: no snap gives %.4f" % expect)
    if text:
        nxd2.override_text(d, text if isinstance(text, list) else [text])
    return d


def straight_curves(view, pred):
    """Drafting curves with 2 or 3 characteristic points whose first two satisfy pred(p0, p1)."""
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) in (2, 3) and pred(p[0], p[1]):
            out.append((c, p))
    return out


def dump(view, path):
    rows = []
    for c, ps in nxd.curves(view):
        rows.append({"cls": type(c).__name__, "owner": type(ps[0]).__name__ if ps else None,
                     "pts": [[round(v, 4) for v in p] for p in nxd.curve_points(c)]})
    json.dump(rows, open(path, "w"), indent=0)
    return len(rows)


# ---------------------------------------------------------------- symbols
def pl_line(view, a, b, label_pos=None, label="PL"):
    """Parting line: phantom line between the sheet images of MODEL points a, b + label."""
    nxd2.view_line(CTX["dwg"], view, a, b, font="phantom")
    if label_pos:
        note([label], label_pos, 3.5)


def gate(x, y, direction="right", label=("GATE G", "(suggested)"), label_pos=None):
    """Gate symbol: hatched triangle whose tip touches (x, y) on the sheet, pointing in `direction`."""
    dw = CTX["dwg"]
    ax, ay = {"right": (-1, 0), "left": (1, 0), "up": (0, -1), "down": (0, 1)}[direction]
    bx, by = x + ax * 8.0, y + ay * 8.0
    px, py = -ay * 3.5, ax * 3.5
    pts = [(x, y), (bx + px, by + py), (bx - px, by - py)]
    for i in range(3):
        nxd2.sheet_line(dw, pts[i], pts[(i + 1) % 3])
    for k in (0.33, 0.66):
        nxd2.sheet_line(dw, (x + (bx + px - x) * k, y + (by + py - y) * k), (x + (bx - px - x) * k, y + (by - py - y) * k))
    if label_pos:
        note(list(label), label_pos, 2.5)


def arrow(x0, y0, x1, y1, text=None, text_pos=None):
    """Pull-direction arrow on the sheet from (x0, y0) to (x1, y1)."""
    dw = CTX["dwg"]
    nxd2.sheet_line(dw, (x0, y0), (x1, y1))
    a = math.atan2(y1 - y0, x1 - x0)
    for s in (1, -1):
        nxd2.sheet_line(dw, (x1, y1), (x1 - 3.0 * math.cos(a + s * 0.35), y1 - 3.0 * math.sin(a + s * 0.35)))
    if text:
        note(text if isinstance(text, list) else [text], text_pos, 2.5)


# ---------------------------------------------------------------- tables
def table(origin, cw, rows, title_rows=(0,), size=2.2, rh=5.0, merges=None):
    """Data table (tabular note), top-left corner at origin; title rows merged over all columns.
    Returns (cell texts, total height)."""
    m = list(merges or []) + [(r, 0, r, len(cw) - 1) for r in title_rows]
    sizes = {(r, 0): 2.5 for r in title_rows}
    _ts, tn = nxd2.table(CTX["dwg"], origin, cw, [rh] * len(rows), rows, text_size=size, merges=m, sizes=sizes)
    return nxd2.table_text(tn), rh * len(rows)


NPT_MALE = [["THREAD 1/2\"-14 NPT EXTERNAL (ASME B1.20.1), MOULDED", ""],
            ["Threads per inch / pitch P", "14 / 1.8143"],
            ["Taper on Ø / flank angle", "1:16 (half angle 1.79°) / 60°"],
            ["E0 pitch Ø at the small end", "19.264 (CAD 19.260)"],
            ["E1 pitch Ø at hand-tight plane", "19.772"],
            ["L1 hand-tight engagement", "8.128"],
            ["L2 eff. length / L3 make-up", "13.556 / 5.443 (3 turns)"],
            ["Thread height h", "1.309 (B1.20.1: 1.288 - 1.451)"],
            ["Crest flat / root", "0.142 / land 0.120, R0.09"],
            ["Thread ends", "blunt (Higbee), in slide PL"],
            ["Gauge / tolerance", "L1 ring gauge, ±1 turn"]]

NPT_FEMALE = [["THREAD 1/2\"-14 NPT INTERNAL (ASME B1.20.1), MOULDED", ""],
              ["Threads per inch / pitch P", "14 / 1.8143"],
              ["Taper on Ø / flank angle", "1:16 (half angle 1.79°) / 60°"],
              ["E1 pitch Ø at the face", "19.772 (CAD 19.772 - 19.773)"],
              ["L1 hand-tight engagement", "8.128"],
              ["Full thread depth", "18.5 (>= L1 + L3 + 1 turn = 15.38)"],
              ["Thread height h", "1.339 (B1.20.1: 1.288 - 1.451)"],
              ["Crest flat / root", "0.142 / full root R0.09"],
              ["Entry", "90° countersink to Ø22.16 at the face"],
              ["Thread end", "blunt void end, 18.5 deep"],
              ["Gauge / tolerance", "L1 plug gauge, ±1 turn"]]

MAKEUP = ["NPT joints: PTFE tape (3 wraps) or PP / PVC compatible sealant;",
          "    hand-tight + 1 to 1.5 turns, never more than 2 turns (plastic female thread)."]


def std_notes(material, shrink, extra=()):
    """Numbered moulding notes common to every moulded part of the set, then `extra` (a string starting with
    four spaces continues the previous note)."""
    n = ["NOTES",
         "1. Material: %s." % material,
         "2. Dimensions are final part dimensions; the toolmaker compensates shrinkage (%s)." % shrink,
         "    The 3D model (STEP, same revision) is the master for every geometry not dimensioned.",
         "3. General tolerances ISO 20457 TG6 (moulded); fit and thread dimensions as stated (TG5).",
         "4. Draft 1° unless noted, 0.5° on fit faces; no draft on thread flanks. Drafted sizes",
         "    are given at the stated end (tight end of a fit).",
         "5. Internal corners R0.3 min unless noted; no sharp internal corners, no feather edges.",
         "6. No sink marks, weld lines, flash or ejector marks on sealing faces and thread flanks.",
         "    Flash on the parting line / slide seams max 0.05."]
    k = 7
    for e in extra:
        if e.startswith("    "):
            n.append(e)
        else:
            n.append("%d. %s" % (k, e))
            k += 1
    return n


def arcs(view, circles_at=None):
    """[(curve, centre, radius)] of the circular drafting curves of a view: arcs report (start, end, centre, mid);
    full circles report (centre, point) - pass circles_at=(axis point, axis index) to accept 2-point curves whose
    first point lies on that axis (splines report start / end and would match otherwise)."""
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 4:
            out.append((c, p[2], math.dist(p[2], p[0])))
        elif len(p) == 2 and circles_at is not None:
            ctr, ax = circles_at
            k = [i for i in range(3) if i != ax]
            if math.hypot(p[0][k[0]] - ctr[k[0]], p[0][k[1]] - ctr[k[1]]) < 1e-3 and math.dist(p[0], p[1]) > 1e-3:
                out.append((c, p[0], math.dist(p[0], p[1])))
    return out


def arc_near(view, centre, radius, tol=0.03, axis=2):
    """Circular curve of radius `radius` whose centre matches `centre` in the two coordinates other than `axis`
    (the viewing axis of an end view); the closest wins."""
    best = None
    k = [i for i in range(3) if i != axis]
    for c, ce, r in arcs(view, (centre, axis)):
        d = math.hypot(ce[k[0]] - centre[k[0]], ce[k[1]] - centre[k[1]]) + abs(r - radius)
        if d <= tol and (best is None or d < best[1]):
            best = (c, d)
    if best is None:
        raise RuntimeError("arc_near: no R%.3f at %s in %s" % (radius, centre, view.Name))
    return best[0]


def dim_radial(view, arc, origin, diameter=True, text=None, tol=None, before=None, after=None, prec=2):
    import NXOpen
    b = CTX["dwg"].Dimensions.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    try:
        b.Measurement.Method = nxd.MM.Diametral if diameter else nxd.MM.Radial
        b.FirstAssociativity.SetValue(nxd.SNAP.NotSet, arc, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=tol, before=before, after=after)
        ptdwg._style(b, prec)
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if text:
        nxd2.override_text(d, [text])
    return d


def lands(view, rmin, rmax, side=-1, zmin=-1e9, zmax=1e9, maxlen=0.3):
    """Short straight curves in the section plane (thread root lands / crest flats) with |x| in [rmin, rmax] on
    the given side; sorted by drawing z. Returns [(curve, mid point)]."""
    out = []
    for c, p in straight_curves(view, lambda a, b: abs(a[1]) < 1e-3 and abs(b[1]) < 1e-3):
        if len(p) != 3:
            continue
        a, b = p[0], p[1]
        if side * a[0] < 0 or side * b[0] < 0:
            continue
        if not (rmin <= abs(a[0]) <= rmax and rmin <= abs(b[0]) <= rmax):
            continue
        if math.dist(a, b) > maxlen:
            continue
        m = [(a[i] + b[i]) / 2 for i in range(3)]
        if zmin <= m[2] <= zmax:
            out.append((c, m))
    return sorted(out, key=lambda t: t[1][2])


def lands_h(view, rmin, rmax, side=1, xmin=-1e9, xmax=1e9, maxlen=0.3):
    """lands() for a section whose axis runs along drawing X: |z| in [rmin, rmax], side = sign of z; sorted by x."""
    out = []
    for c, p in straight_curves(view, lambda a, b: abs(a[1]) < 1e-3 and abs(b[1]) < 1e-3):
        if len(p) != 3:
            continue
        a, b = p[0], p[1]
        if side * a[2] < 0 or side * b[2] < 0:
            continue
        if not (rmin <= abs(a[2]) <= rmax and rmin <= abs(b[2]) <= rmax):
            continue
        if math.dist(a, b) > maxlen:
            continue
        m = [(a[i] + b[i]) / 2 for i in range(3)]
        if xmin <= m[0] <= xmax:
            out.append((c, m))
    return sorted(out, key=lambda t: t[1][0])


def curve_end(view, pt, other, tol=0.02):
    """Straight drafting curve with one end at MODEL point pt whose other end satisfies other(p); returns the curve."""
    for c, p in straight_curves(view, lambda a, b: True):
        for k in (0, 1):
            if math.dist(p[k], pt) <= tol and other(p[1 - k]):
                return c
    raise RuntimeError("curve_end: none at %s in %s" % ([round(v, 3) for v in pt], view.Name))


def new_drawing(path, model_prt, comp_name, r=None, refset="IM01"):
    """ptdwg.new_drawing with an explicit reference set (the product body only: IM01 / VALVE / CAP)."""
    import nxa
    dwg = nxa.new_assembly(path)
    comp = nxa.add_component(dwg, model_prt, comp_name, (0.0, 0.0, 0.0), r, refset=refset)
    nxh.save(dwg)
    nxd.enter(dwg)
    nxd.load_standard(dwg, "ISO")
    CTX["dwg"] = dwg
    return dwg, comp


def matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def apply(r, p):
    return tuple(sum(r[i][k] * p[k] for k in range(3)) for i in range(3))


NPT_STRAIGHT_VALVE = [["CAP THREAD 1/2\"-14 STRAIGHT, EXTERNAL, MOULDED", ""],
                      ["Form / pitch P", "60°, 14 TPI / 1.8143 (straight)"],
                      ["Pitch Ø (male)", "19.75 ±0.08 (CAD 19.749)"],
                      ["Major Ø / root Ø", "21.04 / 18.42 (crest flat, root R0.09)"],
                      ["Mating part", "PT-M3-06 cap, pitch Ø 19.95 ±0.08"],
                      ["Allowance on pitch Ø", "0.20 (worst case 0.04)"],
                      ["Length", "2 full turns, blunt starts; R0.6 at the collar"]]
NPT_STRAIGHT_CAP = [["CAP THREAD 1/2\"-14 STRAIGHT, INTERNAL, MOULDED", ""],
                    ["Form / pitch P", "60°, 14 TPI / 1.8143 (straight)"],
                    ["Pitch Ø (female)", "19.95 ±0.08 (CAD 19.949)"],
                    ["Minor Ø / root Ø", "18.66 / 21.34 (crest flat, root R0.09)"],
                    ["Mating part", "PT-M3-05 valve, pitch Ø 19.75 ±0.08"],
                    ["Allowance on pitch Ø", "0.20 (worst case 0.04), axial play 0.11"],
                    ["Thread depth", "to 12.3 below the top face, blunt void end"],
                    ["Mould", "unscrewing core from the top (+Z)"]]


def dim_ends(view, ca, pa, cb, pb, origin, method="horizontal", text=None, tol=None, before=None, after=None, expect=None,
             etol=0.01, prec=2):
    """Linear dimension between the END points pa / pb (MODEL coordinates) of drafting curves ca / cb. The End snap
    is resolved by the pick point, so the sheet image of each end point is passed (a zero pick point makes NX take
    the same end whatever the snap). Falls back to model-coordinate pick points."""
    import NXOpen
    meth = {"horizontal": nxd.MM.Horizontal, "vertical": nxd.MM.Vertical, "point": nxd.MM.PointToPoint,
            "perpendicular": nxd.MM.Perpendicular, "cylindrical": nxd.MM.Cylindrical}[method]
    dw = CTX["dwg"]
    tries = []
    for mode in ("sheet", "model"):
        qa = xy(view, pa) + (0.0,) if mode == "sheet" else tuple(pa)
        qb = xy(view, pb) + (0.0,) if mode == "sheet" else tuple(pb)
        b = dw.Dimensions.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
        try:
            b.Measurement.Method = meth
            b.FirstAssociativity.SetValue(nxd.SNAP.End, ca, view, nxh.P(*qa), None, None, nxd.P0)
            b.SecondAssociativity.SetValue(nxd.SNAP.End, cb, view, nxh.P(*qb), None, None, nxd.P0)
            nxd._style(b, tol=tol, before=before, after=after)
            ptdwg._style(b, prec)
            b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
            d = b.Commit()
        finally:
            b.Destroy()
        tries.append(round(d.ComputedSize, 4))
        if expect is None or abs(d.ComputedSize - expect) <= etol:
            if text:
                nxd2.override_text(d, text if isinstance(text, list) else [text])
            return d
        ptdwg._delete([d])
    raise RuntimeError("dim_ends: expected %.4f, got %s" % (expect, tries))


GLAND_MALE = [["O-RING GLAND (static radial, male groove)", ""],
              ["O-ring (ISO 3601-1 116)", "AS568-116, 18.72 x 2.62, EPDM 70"],
              ["Groove bottom Ø", "18.95 ±0.05 (fit; ID stretch 1.2 %)"],
              ["Groove width", "3.60 ±0.05 (fill 74 % nominal)"],
              ["Lands either side", "Ø22.60 x 1.5 (extrusion gap 0.20)"],
              ["Radii / draft", "R0.3 bottom, R0.1 edges / none"],
              ["Mating counterbore", "Ø23.00 ±0.05 (PT-M3-01 / -02)"],
              ["Squeeze nom. / worst case", "22.2 % / 15.5 - 28.5 %"]]
CBORE_FEMALE = [["O-RING COUNTERBORE (plain, ahead of the NPT)", ""],
                ["Counterbore Ø / plain length", "23.00 ±0.05 (fit) / 17.65"],
                ["Lead-in", "20° x 0.8 radial (mouth Ø24.60)"],
                ["Depth above thread face F", "19.85 (lead-in included)"],
                ["Root radius", "R0.3 (bore / thread-face step)"],
                ["Surface / draft", "polished / none (max 0.25°)"],
                ["O-ring (on the male part)", "AS568-116, 18.72 x 2.62, EPDM 70"],
                ["Squeeze nom. / worst case", "22.2 % / 15.5 - 28.5 %"]]
GLAND_NOTES_MALE = ["O-ring groove formed in the thread slides (split through the axis, the PL crosses the",
                    "    groove): slide mismatch max 0.02, NO flash on the groove bottom and lands; gland faces",
                    "    undrafted. Groove Ø18.95 and width 3.60 are fit sizes ±0.05 (not TG5)."]
CBORE_NOTES_FEMALE = ["O-ring counterbore and 20° lead-in formed by a NON-ROTATING sleeve on the unscrewing core",
                      "    (the part strips off the sleeve after the core has unscrewed): no draft, polished; if the",
                      "    toolmaker needs draft: max 0.25° with Ø23.00 at mid-length. Ø23.00 is a fit size ±0.05."]
MAKEUP_ORING = ["Assembly: fit the o-ring (AS568-116, silicone grease, no mineral oil) BEFORE the PTFE tape;",
                "    then hand-tight + 1 to 1.5 turns, never more than 2 turns (plastic female thread)."]
