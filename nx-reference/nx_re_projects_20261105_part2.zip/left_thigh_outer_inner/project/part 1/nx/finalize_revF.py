"""Finalize for Rev F (and later): like finalize.py, but the user's history now builds DESIGN geometry on scan Fit
Surfaces (Fit Surface -> Extend Sheet -> Thicken / Replace Face / Trim Body, FEATURES_R4/R5 children), and the part
may be saved rolled back. Deleting the scan therefore must not change the solid.

Order:
 0. copy, open, baseline: solids, main solid (largest non-blanked), raw feature errors, inactive features.
 1. rolled-back tail: features after the current feature are deleted (they are not part of the shown geometry),
    except Feature Groups; then the last feature is made current. Volume must not change.
 2. points on scan Fit Surfaces -> fixed points (as finalize.py, Rev C).
 3. strategy "replace": every scan Fit Surface whose descendants are more than Points / Delete Body is replaced
    (Replace Feature) by a frozen, parameter-less copy of its sheet made right after it (Extract Body at the
    insert point + Remove Parameters). Then the scan is deleted, and only features of the scan closure that fail
    are deleted. Accepted when the main volume is unchanged within VTOL, the solid count is unchanged and no
    feature outside the scan closure has a new error. Otherwise everything is undone and
    strategy "dumb": Remove Parameters on the main solid (exact saved geometry, history of the solid dropped),
    then the scan + all its dependents are deleted.
 4. as finalize.py: other solids deleted (reported with distance to the main solid), helper geometry to layer 200,
    ref set SOLID, attributes, save, STEP AP214 / AP242, x_t, STL.
args: built_prt deliver_dir [revision] [strategy: auto|dumb]"""
import os, sys, json, traceback, shutil
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, DST = sys.argv[1], sys.argv[2]
REV = sys.argv[3] if len(sys.argv) > 3 else "A"
STRAT = sys.argv[4] if len(sys.argv) > 4 else "replace"   # replace | auto (replace, else dumb) | dumb
OPT = json.load(open(sys.argv[5])) if len(sys.argv) > 5 else {}
# OPT: {"tail": "keep" | "delete",            rolled-back features after the current one (default keep -> rolled forward
#                                               after the scan removal, each one's volume change reported)
#       "tail_repair": {"<index in tail>": {"point": [x,y,z], "normal": [nx,ny,nz]}}   re-point an Offset Region of the
#                                               tail whose face is gone to the face through point with that normal
#       "f1_top": 2.5}                          F1_BOSS top Z (user decision Rev F), then the touching K1 head is united
TAIL = OPT.get("tail", "keep")
# lean (Rev F final, after the full run proved every step): no accurate volumes between steps - volumes at accuracy
# 0.99 only as a gross check, step checks by solid count / feature errors / point containment probes, ONE accurate
# volume at the very end after the exports are written. OPT: "lean": true, "vref": regenerated reference volume,
# "probes": json {"in": [[x,y,z]..], "out": [..]} of the saved solid, checked after the scan removal.
LEAN = bool(OPT.get("lean"))
NOISE_MAX = 0.5   # mm3, largest accepted regeneration noise of the saved tree
NAME = "LT-OUT-001_Left_Thigh_Outer"
VTOL = 0.01
BASE_ERR_TAGS = set()
if LEAN:
    VTOL = 1e9   # 0.99-accuracy volumes scatter by 10-200 mm3: logged only; probes + the final accurate volume decide
os.makedirs(DST, exist_ok=True)
res = {"result": "FAIL", "log": [], "strategy_asked": STRAT}
log = res["log"].append
OUTJ = os.path.join(DST, "_finalize.json")
FO = NXOpen.Update.FailureOption


def dump():
    nxh.write_json(OUTJ, res)


def raw_errors(part, active_only=False):
    out = {}
    for f in part.Features.GetFeatures():
        try:
            msgs = list(f.GetFeatureErrorMessages() or [])
        except Exception:  # noqa: BLE001
            msgs = []
        if not msgs:
            continue
        if active_only and nxh.suppress_status(f)["code"] != 0:
            continue
        out[f.GetFeatureName()] = [str(m) for m in msgs]
    return out


def vol(part, b):
    if not LEAN:
        return nxh.volume(part, b)
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, 0.99, [b])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


def solids(part):
    return [b for b in part.Bodies if b.IsSolidBody and not getattr(b, "IsConvergentBody", False)]


def main_solid(part):
    if LEAN:
        return max([b for b in solids(part) if not b.IsBlanked], key=lambda b: len(b.GetFaces()))
    return max([b for b in solids(part) if not b.IsBlanked], key=lambda b: nxh.volume(part, b))


def state(part):
    m = main_solid(part)
    if LEAN:
        return {"main_tag": m.Tag, "main_vol": vol(part, m), "n_solids": len(solids(part))}
    return {"main_tag": m.Tag, "main_vol": nxh.volume(part, m), "n_solids": len(solids(part)),
            "solid_vols": sorted(round(nxh.volume(part, b), 4) for b in solids(part))}


def delete(objs, label):
    m = nxh.mark(label)
    nxh.S.UpdateManager.SetDefaultUpdateFailureAction(FO.AcceptAll)
    nxh.S.UpdateManager.AddObjectsToDeleteList(list(objs))
    nxh.S.UpdateManager.DoUpdate(m)


def closure(part, roots):
    seen, stack = set(), list(roots)
    while stack:
        f = stack.pop()
        if f.Tag in seen:
            continue
        seen.add(f.Tag)
        stack.extend(f.GetChildren())
    return seen


def delete_failed_in(part, allowed, label):
    """delete features that carry an error, only inside `allowed` (tags); returns the names of failing
    features OUTSIDE it (those are never deleted)."""
    outside = []
    for _ in range(4):
        bad = [f for f in part.Features.GetFeatures() if list(f.GetFeatureErrorMessages() or []) and f.Tag in allowed]
        if not bad:
            break
        res.setdefault("deleted_" + label, []).extend(f.GetFeatureName() for f in bad)
        delete(bad, "del " + label)
    for f in part.Features.GetFeatures():
        if list(f.GetFeatureErrorMessages() or []) and f.Tag not in allowed and f.Tag not in BASE_ERR_TAGS:
            outside.append(f.GetFeatureName())
    return outside


try:
    work = os.path.join(DST, NAME + ".prt")
    if os.path.exists(work):
        os.remove(work)
    shutil.copyfile(SRC, work)
    part = nxh.open_part(work)
    nxh.S.UpdateManager.SetDefaultUpdateFailureAction(FO.AcceptAll)
    feats = list(part.Features.GetFeatures())
    res["features_before"] = len(feats)
    res["current_before"] = part.CurrentFeature.GetFeatureName()
    res["errors_on_open"] = raw_errors(part)
    res["inactive_on_open"] = [[f.GetFeatureName(), nxh.suppress_status(f)["code"]] for f in feats
                               if nxh.suppress_status(f)["code"] not in (0, 16, 17)]
    st0 = state(part)
    res["state0"] = st0
    vm0 = st0["main_vol"]
    dump()

    # ---- 1. rolled-back tail
    tail = nxh.rolled_back(part)
    if tail:
        res["rolled_back_tail"] = [f.GetFeatureName() for f in tail]
        TAIL_FEATS = list(tail)
        kill = [f for f in tail if f.FeatureType != "FSET"] if TAIL == "delete" else []
        if kill:
            delete(kill, "del rolled-back tail")
        if kill:
            fl = list(part.Features.GetFeatures())
            fl[-1].MakeCurrentFeature()
            nxh.update("current = last")
        st = state(part)
        res["after_tail"] = {"deleted": [n for n in res["rolled_back_tail"] if "Feature Group" not in n],
                             "current": part.CurrentFeature.GetFeatureName(), "rolled_back_left": [f.GetFeatureName() for f in nxh.rolled_back(part)],
                             "main_vol": st["main_vol"]}
        assert abs(st["main_vol"] - vm0) < VTOL, ("tail", vm0, st["main_vol"])
        log("rolled-back tail (%s): %s" % (TAIL, res["after_tail"]))
    dump()

    conv = [f for f in part.Features.GetFeatures() if f.FeatureType == "BREP" and f.GetFeatureName().startswith("Convergent Body")]
    ct = {c.Tag for c in conv}
    direct = [f for f in part.Features.GetFeatures() if f.Tag not in ct and any(p.Tag in ct for p in f.GetParents())]
    res["scan_direct"] = [f.GetFeatureName() for f in direct]

    # ---- 2. points on fit surfaces -> fixed points
    for fit in direct:
        for ch in fit.GetChildren():
            if ch.FeatureType != "POINT":
                continue
            pt = [x for x in ch.GetEntities() if isinstance(x, NXOpen.Point)][0]
            c0 = pt.Coordinates
            pb = part.BaseFeatures.CreatePointFeatureBuilder(ch)
            try:
                pb.Point = part.Points.CreatePoint(NXOpen.Point3d(c0.X, c0.Y, c0.Z))
                pb.Commit()
            finally:
                pb.Destroy()
            res.setdefault("points_fixed", []).append([ch.GetFeatureName(), round(c0.X, 4), round(c0.Y, 4), round(c0.Z, 4)])
    if res.get("points_fixed"):
        nxh.update("fix points")
    st = state(part)
    res["after_points"] = st["main_vol"]
    assert abs(st["main_vol"] - vm0) < VTOL, ("points", vm0, st["main_vol"])
    log("points fixed: %s" % res.get("points_fixed"))
    dump()

    base_err = set(raw_errors(part, active_only=True))
    # features that already carry a message in the saved part (inactive failed / suppressed ones too), by TAG
    # (names are renumbered by the replacements)
    BASE_ERR_TAGS = {f.Tag for f in part.Features.GetFeatures() if list(f.GetFeatureErrorMessages() or [])}
    res["pre_existing_error_features"] = [[f.GetFeatureName(), nxh.suppress_status(f)["code"]] for f in part.Features.GetFeatures()
                                          if f.Tag in BASE_ERR_TAGS]
    # regeneration noise of the saved tree: regenerate from the first child of the first scan Fit Surface that
    # carries design geometry, change nothing, measure, undo. A user's GUI-built tree need not regenerate to
    # exactly its saved volume (Rev F: -0.108 mm3); the scan removal is judged against this regenerated value.
    noise = 0.0
    for d in ([] if LEAN else direct):
        kids = [c for c in d.GetChildren() if c.FeatureType not in ("POINT", "Delete Body")]
        if kids:
            mn_ = nxh.mark("regen noise")
            nxh.S.UpdateManager.LogForUpdate(kids[0])
            nxh.S.UpdateManager.DoUpdate(mn_)
            noise = state(part)["main_vol"] - vm0
            res["regen_noise"] = {"from": kids[0].GetFeatureName(), "dvol": noise,
                                  "new_errors": sorted(set(raw_errors(part, active_only=True)) - base_err)}
            nxh.undo_to(mn_)
            assert abs(state(part)["main_vol"] - vm0) < 1e-6, "undo after noise test"  # full mode only
            break
    if abs(noise) > NOISE_MAX:
        raise RuntimeError("regeneration noise %.4f mm3 > %.3f" % (noise, NOISE_MAX))
    vref = float(OPT["vref"]) if LEAN else vm0 + noise
    res["volume_reference_regenerated"] = vref
    dump()
    m_start = nxh.mark("before scan removal")
    used = None

    def try_replace():
        cl0 = closure(part, direct)
        need = []
        for d in direct:
            desc = closure(part, [d]) - {d.Tag}
            kinds = {f.FeatureType for f in part.Features.GetFeatures() if f.Tag in desc}
            if kinds - {"POINT", "Delete Body"}:
                need.append(d)
        res["replace_targets"] = [d.GetFeatureName() for d in need]
        dump()
        for d in need:
            name = d.GetFeatureName()
            sheet = [b for b in d.GetBodies()]
            if len(sheet) != 1:
                raise RuntimeError("%s has %d bodies" % (name, len(sheet)))
            end = part.CurrentFeature
            d.MakeCurrentFeature()
            ef, new = nxf.extract_body(part, sheet, fix_at_timestamp=True)
            nxf.remove_parameters(part, new)
            nb = new[0]
            bf = list(nb.GetFeatures())
            if len(bf) != 1:
                raise RuntimeError("frozen copy of %s: %d features" % (name, len(bf)))
            brep = bf[0]
            log("%s -> frozen copy %s (%s), faces %d" % (name, brep.GetFeatureName(), brep.FeatureType, len(nb.GetFaces())))
            end.MakeCurrentFeature()
            nxh.update("roll forward after copy of " + name)
            st = state(part)
            if abs(st["main_vol"] - vref) > VTOL and abs(st["main_vol"] - vm0) > VTOL:
                raise RuntimeError("roll forward after copy of %s changed the solid: %s" % (name, st["main_vol"]))
            b = part.Features.CreateReplaceFeatureBuilder()
            try:
                b.SelectFeature.Add(d)
                b.ReplacementFeature.Add(brep)
                b.DoAutomaticGeomMatch = True
                b.DeleteOriginalFeature = True
                b.MappingTolerance = 0.01
                b.UpdateMap()
                b.AutomatchMap()
                b.Commit()
            finally:
                b.Destroy()
            nxh.update("replace " + name)
            st = state(part)
            new_err = sorted(set(raw_errors(part, active_only=True)) - base_err)
            res.setdefault("replaced", []).append({"fit": name, "by": brep.GetFeatureName(), "main_vol": st["main_vol"],
                                                   "n_solids": st["n_solids"], "new_errors": new_err})
            dump()
            if abs(st["main_vol"] - vref) > VTOL or st["n_solids"] != st0["n_solids"] or new_err:
                raise RuntimeError("replace %s: volume %s (was %s), solids %d, new errors %s" % (name, st["main_vol"], vm0, st["n_solids"], new_err))
        # scan delete; only features depending on the scan may fail and be deleted
        cl = closure(part, [f for f in part.Features.GetFeatures() if f.Tag not in ct and any(p.Tag in ct for p in f.GetParents())])
        delete(conv, "del scan")
        outside = delete_failed_in(part, cl, "scan_construction")
        st = state(part)
        res["replace_result"] = {"main_vol": st["main_vol"], "n_solids": st["n_solids"], "failing_outside_closure": outside}
        dump()
        if abs(st["main_vol"] - vref) > VTOL or st["n_solids"] != st0["n_solids"] or outside:
            raise RuntimeError("scan delete after replace: %s" % res["replace_result"])
        return "replace"

    def do_dumb():
        body = main_solid(part)
        tag = body.Tag
        nxf.remove_parameters(part, [body])
        nxh.update("remove parameters")
        body = [b for b in solids(part) if b.Tag == tag]
        res["dumb_body_same_tag"] = bool(body)
        cl = closure(part, [f for f in part.Features.GetFeatures() if f.Tag not in ct and any(p.Tag in ct for p in f.GetParents())])
        delete(conv, "del scan")
        outside = delete_failed_in(part, cl, "scan_dependents")
        st = state(part)
        res["dumb_result"] = {"main_vol": st["main_vol"], "n_solids": st["n_solids"], "failing_outside_closure": outside}
        dump()
        return "dumb"

    if STRAT in ("auto", "replace"):
        try:
            used = try_replace()
        except Exception as e:  # noqa: BLE001
            res["replace_failed"] = traceback.format_exc()[-1500:]
            log("strategy replace failed, undo: %s" % str(e)[:300])
            dump()
            nxh.undo_to(m_start)
            st = state(part)
            res["after_undo"] = st
            assert abs(st["main_vol"] - vm0) < VTOL, ("undo", vm0, st["main_vol"])
    if used is None:
        if STRAT == "replace":
            raise RuntimeError("strategy replace failed (see replace_failed); dumb not allowed")
        used = do_dumb()
        vref = vm0
    res["strategy_used"] = used
    st = state(part)
    vm1 = st["main_vol"]
    res["main_volume_before_after_scan_delete"] = [vm0, vm1]
    res["main_volume_vs_regenerated_reference"] = vm1 - vref
    assert abs(vm1 - vref) < VTOL, (vm0, vref, vm1)
    assert not [f for f in part.Features.GetFeatures() if f.GetFeatureName().startswith("Convergent")], "scan left"
    res["errors_after_scan_delete_active"] = raw_errors(part, active_only=True)
    res["errors_after_scan_delete_all"] = raw_errors(part)
    res["features_after"] = len(list(part.Features))
    if OPT.get("probes"):
        pr = json.load(open(OPT["probes"]))
        mb_ = main_solid(part)
        bad, perr = [], None
        def contain(q):
            try:
                return int(nxh.UFS.Modeling.AskPointContainment(list(q), mb_.Tag))
            except Exception:  # noqa: BLE001
                d = nxh.min_dist(part.Points.CreatePoint(nxh.P(*q)), mb_)   # signed: < 0 inside
                return 1 if d < -1e-6 else (2 if d > 1e-6 else 3)
        try:
            for kind, want in (("in", 1), ("out", 2)):
                for q in pr[kind]:
                    c = contain(q)
                    if c != want:
                        bad.append([kind, [round(v, 3) for v in q], c])
        except Exception:  # noqa: BLE001
            perr = traceback.format_exc()[-400:]
        res["probes_after_scan_delete"] = {"n_in": len(pr["in"]), "n_out": len(pr["out"]), "mismatch": len(bad), "bad": bad[:20], "error": perr}
        dump()
        assert not bad, res["probes_after_scan_delete"]
    dump()

    # ---- tail: roll forward one by one (user: "i did them by intent"); repair a lost face reference first
    if tail and TAIL == "keep":
        rep_ = OPT.get("tail_repair", {})
        prev = state(part)["main_vol"]
        for i, f in enumerate(TAIL_FEATS):
            row = {"feature": f.GetFeatureName(), "type": f.FeatureType}
            if str(i) in OPT.get("tail_suppress", []):
                part.Features.SuppressFeatures([f])
                nxh.update("suppress " + f.GetFeatureName())
                row["action"] = "suppressed (face reference lost; kept in the tree, not deleted)"
                st = state(part)
                row.update({"main_vol": st["main_vol"], "dvol": st["main_vol"] - prev, "n_solids": st["n_solids"]})
                prev = st["main_vol"]
                res.setdefault("tail_rolled_forward", []).append(row)
                dump()
                continue
            f.MakeCurrentFeature()
            nxh.update("roll forward " + f.GetFeatureName())
            msgs = [str(x) for x in (f.GetFeatureErrorMessages() or [])]
            row["errors_on_roll"] = msgs
            spec = rep_.get(str(i))
            if spec and f.FeatureType == "OFFSET_REGION":
                body_ = main_solid(part)
                def owned(fc, names):
                    try:
                        fn = [NXOpen.TaggedObjectManager.GetTaggedObject(x).GetFeatureName() for x in nxh.UFS.Modeling.AskFaceFeats(fc.Tag)]
                    except Exception:  # noqa: BLE001
                        return False
                    return any(n in fn for n in names)
                if "parent_plane_z" in spec:
                    # a planar face of the feature's parent (the face it was picked on), flat at that Z, normal as given
                    pn = [p_.GetFeatureName() for p_ in f.GetParents()]
                    zz = float(spec["parent_plane_z"])
                    cand = [fc for fc in body_.GetFaces() if nxh.face_data(fc)[0] == 22 and abs(nxh.bbox(fc)[2] - zz) < 0.07
                            and abs(nxh.bbox(fc)[5] - zz) < 0.07 and nxh.angle_deg(nxh.face_data(fc)[2], spec["normal"]) < 0.5 and owned(fc, pn)]
                    row["repair_parent"] = pn
                else:
                    cand = [fc for fc in body_.GetFaces() if abs(nxh.dist_to(part, fc, spec["point"])) < 1e-3]
                if "normal" in spec and "parent_plane_z" not in spec:
                    cand = [fc for fc in cand if nxh.angle_deg(nxh.normal_at(fc, spec["point"]), spec["normal"]) < 2.0]
                row["repair_candidates"] = [[fc.Tag, [round(v, 3) for v in nxh.bbox(fc)]] for fc in cand]
                if len(cand) != 1:
                    raise RuntimeError("tail repair %s: %d candidate faces" % (f.GetFeatureName(), len(cand)))
                b = part.Features.CreateAdmOffsetRegionBuilder(f)
                try:
                    b.FaceToOffset.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb([cand[0]])], False)
                    row["distance"] = b.Distance.RightHandSide
                    row["reverse"] = bool(b.ReverseDirection)
                    b.CommitFeature()
                finally:
                    b.Destroy()
                nxh.update("repair " + f.GetFeatureName())
                msgs = [str(x) for x in (f.GetFeatureErrorMessages() or [])]
                row["errors_after_repair"] = msgs
                if "expect_z" in spec:
                    body_ = main_solid(part)
                    hit = [fc for fc in body_.GetFaces() if nxh.face_data(fc)[0] == 22 and abs(nxh.bbox(fc)[2] - spec["expect_z"]) < 0.07
                           and abs(nxh.bbox(fc)[5] - spec["expect_z"]) < 0.07 and nxh.angle_deg(nxh.face_data(fc)[2], (0, 0, 1)) < 0.5
                           and nxh.bbox(fc)[3] - nxh.bbox(fc)[0] > 20.0]
                    row["expect_faces"] = [[fc.Tag, [round(v, 4) for v in nxh.face_data(fc)[1]], [round(v, 3) for v in nxh.bbox(fc)]] for fc in hit]
                    try:
                        row["expect_face_exact_z"] = [round(nxh.UFS.ModlGeneral.AskBoundingBoxExact(fc.Tag, 0)[0][2], 4) for fc in hit]
                    except Exception as e:  # noqa: BLE001
                        row["expect_face_exact_z_err"] = str(e)[:80]
                    if not hit:
                        raise RuntimeError("tail repair %s: no face at Z %s" % (f.GetFeatureName(), spec["expect_z"]))
                if "expect_point" in spec:
                    body_ = main_solid(part)
                    hit = [fc for fc in body_.GetFaces() if abs(nxh.dist_to(part, fc, spec["expect_point"])) < 1e-3]
                    row["expect_point_faces"] = [[fc.Tag, nxh.face_data(fc)[0], [round(v, 4) for v in nxh.face_data(fc)[2]],
                                                  [round(v, 3) for v in nxh.bbox(fc)]] for fc in hit]
                    gone = [fc for fc in body_.GetFaces() if abs(nxh.dist_to(part, fc, spec["point"])) < 1e-3]
                    row["old_point_faces"] = len(gone)
                    if not hit or gone:
                        raise RuntimeError("tail repair %s: expected face at %s not found (old faces %d)" % (f.GetFeatureName(), spec["expect_point"], len(gone)))
            st = state(part)
            row.update({"main_vol": st["main_vol"], "dvol": st["main_vol"] - prev, "n_solids": st["n_solids"]})
            prev = st["main_vol"]
            res.setdefault("tail_rolled_forward", []).append(row)
            dump()
            if msgs and f.FeatureType != "FSET":
                raise RuntimeError("tail feature %s fails: %s" % (row["feature"], msgs))
        last = list(part.Features.GetFeatures())[-1]
        last.MakeCurrentFeature()
        nxh.update("current = last")
        res["rolled_back_after_tail"] = [f.GetFeatureName() for f in nxh.rolled_back(part)]
        assert not res["rolled_back_after_tail"], res["rolled_back_after_tail"]
        new_err = sorted(set(raw_errors(part, active_only=True)) - base_err)
        assert not new_err, ("tail errors", new_err)

    # ---- F1_BOSS top raised (user decision 2026-11-02: "Raise boss to Z 2.5"), so the K1 head sits on it
    if OPT.get("f1_top") is not None:
        f1 = [f for f in part.Features.GetFeatures() if (f.Name or "") == "F1_BOSS"]
        assert len(f1) == 1, "F1_BOSS feature"
        f1 = f1[0]
        def f1_cyl():
            cy = [x for x in f1.GetFaces() if nxh.face_data(x)[0] == 16]
            return [[round(v, 4) for v in nxh.face_data(x)[1][:2]] + [round(abs(nxh.face_data(x)[3]) * 2, 4)] + [round(v, 4) for v in (nxh.bbox(x)[2], nxh.bbox(x)[5])] for x in cy]
        st1 = state(part)
        info = {"before": f1_cyl(), "main_before": st1["main_vol"]}
        ztop0 = max(c[4] for c in info["before"])
        rise = float(OPT["f1_top"]) - ztop0
        done = False
        for sign in (-1.0, 1.0):
            mk = nxh.mark("f1 raise")
            eb = part.Features.CreateExtrudeBuilder(f1)
            try:
                info["start_before"] = eb.Limits.StartExtend.Value.RightHandSide
                s0 = float(eb.Limits.StartExtend.Value.Value)
                eb.Limits.StartExtend.Value.RightHandSide = "%.4f" % (s0 + sign * rise)
                eb.CommitFeature()
            finally:
                eb.Destroy()
            nxh.update("f1 raise")
            cy = f1_cyl()
            if cy and abs(max(c[4] for c in cy) - float(OPT["f1_top"])) < 1e-4:
                info["start_after"] = "%.4f" % (s0 + sign * rise)
                done = True
                break
            info.setdefault("tried", []).append([sign, cy])
            nxh.undo_to(mk)
        assert done, ("f1 raise", info)
        st2 = state(part)
        info.update({"after": f1_cyl(), "main_after": st2["main_vol"], "dvol": st2["main_vol"] - st1["main_vol"],
                     "expected_dvol": 3.141592653589793 * 3.2 ** 2 * rise, "n_solids": st2["n_solids"],
                     "new_errors": sorted(set(raw_errors(part, active_only=True)) - base_err)})
        res["f1_raise"] = info
        dump()
        assert not info["new_errors"], info["new_errors"]
    dump()

    body = main_solid(part)
    others = [b for b in solids(part) if b.Tag != body.Tag]
    try:
        nxre.stl_export(part, body, os.path.join(DST, "_main_before_unite.stl"), chord=0.005, max_edge=1.5)
    except Exception as e:  # noqa: BLE001
        log("pre-unite stl: %s" % e)
    res["main_volume_before_unite"] = vol(part, body)
    kept = []
    for b in sorted(others, key=lambda x: nxh.bbox(x)):
        row = {"volume": round(vol(part, b), 3), "bbox": nxh.bbox(b), "name": b.Name,
               "features": [f.GetFeatureName() + ((" " + f.Name) if f.Name else "") for f in b.GetFeatures()][-4:],
               "min_dist_to_main": round(nxh.min_dist(body, b), 4)}
        if row["min_dist_to_main"] > 1e-6:
            row["action"] = "kept separate (gap)"
            kept.append(b)
        else:
            v0, vb, n0 = vol(part, body), vol(part, b), len(solids(part))
            u = nxh.unite(part, body, [b], check=not LEAN)
            body = main_solid(part)
            v1, n1 = vol(part, body), len(solids(part))
            row.update({"action": "united", "feature": u.GetFeatureName() if hasattr(u, "GetFeatureName") else str(u),
                        "main_before": v0, "main_after": v1, "overlap": round(v0 + vb - v1, 4), "n_solids": [n0, n1]})
            assert n1 == n0 - 1 and (LEAN or v0 < v1 <= v0 + vb + 1e-6), row
        res.setdefault("other_solids", []).append(row)
        dump()
    new_err = sorted(set(raw_errors(part, active_only=True)) - base_err)
    assert not new_err, ("unite errors", new_err)
    log("other solids: %s" % [(r["volume"], r["action"]) for r in res.get("other_solids", [])])
    n = 0
    for b in part.Bodies:
        if not b.IsSolidBody:
            b.Layer = 200; n += 1
    for c in part.Curves:
        c.Layer = 200; n += 1
    for dp in part.Datums:
        try:
            dp.Layer = 200; n += 1
        except Exception:  # noqa: BLE001
            pass
    body.Layer = 1
    log(f"{n} helper objects moved to layer 200")
    try:
        lsc = part.Layers.GetStates()
        lsc.SetState(200, NXOpen.Layer.State.Hidden)
        part.Layers.SetStates(lsc, True)
    except Exception as e:  # noqa: BLE001
        log(f"layer state: {e}")
    rs = next((r for r in part.GetAllReferenceSets() if r.Name == "SOLID"), None)
    if rs is None:
        rs = part.CreateReferenceSet()
        rs.SetName("SOLID")
    try:
        rs.AddObjectsToReferenceSet([body] + kept)
    except Exception as e:  # noqa: BLE001
        log(f"refset: {e}")
    body.SetName("LEFT_THIGH_OUTER")
    if not LEAN:
        v = nxh.volume(part, body)
        res["volume_mm3"] = v
        res["mass_g_al6061"] = v * 2.70e-3
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    try:
        mn, _dirs, dist = nxh.UFS.ModlGeneral.AskBoundingBoxExact(body.Tag, 0)
        mn, dist = list(mn), list(dist)
        res["bbox_exact"] = [round(x, 4) for x in mn + [mn[i] + dist[i] for i in range(3)]]
    except Exception as e:  # noqa: BLE001
        res["bbox_exact_err"] = str(e)
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["n_solids_final"] = len(solids(part))
    res["kept_separate"] = [{"volume": round(vol(part, b), 3), "bbox": nxh.bbox(b)} for b in kept]
    for b in kept:
        b.Layer = 1
    for k, val in (("MATERIAL", "Aluminium 6061-T6"), ("DRAWING_NO", "LT-OUT-001"), ("REVISION", REV),
                   ("DESCRIPTION", "Left thigh - outer shell, reverse engineered from scan")):
        try:
            part.SetUserAttribute(k, -1, val, NXOpen.Update.Option.Now)
        except Exception as e:  # noqa: BLE001
            log(f"attribute {k}: {e}")
    res["features_final"] = len(list(part.Features))
    res["errors_final_active"] = raw_errors(part, active_only=True)
    res["errors_final_all"] = raw_errors(part)
    dump()
    nxh.save(part)
    st214 = os.path.join(DST, NAME + "_AP214.step")
    st242 = os.path.join(DST, NAME + "_AP242.step")
    nxf.step_export(part, st214, ap242=False, save=True)
    nxf.step_export(part, st242, ap242=True, save=False)
    res["step_sizes"] = [os.path.getsize(st214), os.path.getsize(st242)]
    xt = os.path.join(DST, NAME + ".x_t")
    if os.path.exists(xt):
        os.remove(xt)
    try:
        nxh.UFS.Ps.ExportData([body.Tag], xt)
        res["x_t_size"] = os.path.getsize(xt)
    except Exception as e:  # noqa: BLE001
        res["x_t_error"] = str(e)
    stl = os.path.join(DST, NAME + ".stl")
    nxre.stl_export(part, body, stl, chord=0.005, max_edge=1.5)
    res["stl_size"] = os.path.getsize(stl)
    dump()
    if LEAN:
        # the one accurate volume, after every file is written
        v = nxh.volume(part, body)
        res["volume_mm3"] = v
        res["mass_g_al6061"] = v * 2.70e-3
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
dump()
