"""Writes nx/dwg_revC.py from nx/dwg_revB.py (left untouched): revision C (2026-10-31), revision block with the C row
(Rev B marked not issued), SH3 connector pad on the hip end face (two hole callouts + a pad table), SH4 rows and
balloons K1 (clip head), R1 (rib), T1 / T2 (tabs)."""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
s = open(os.path.join(HERE, "dwg_revB.py"), encoding="utf-8").read()


def rep(a, b, count=1):
    global s
    n = s.count(a)
    assert n == count, (n, a[:80])
    s = s.replace(a, b)


rep('"""LT-OUT-001 Left Thigh - Outer shell, REV B drawing set (made by make_dwg_revB.py from dwg_main.py; third angle).',
    '"""LT-OUT-001 Left Thigh - Outer shell, REV C drawing set (make_dwg_revC.py <- dwg_revB.py <- dwg_main.py; third angle).\n'
    'Rev C: connector pad on the hip end face (SH3), clip K1, rib R1, tabs T1 / T2 (SH4), on top of the Rev B slots.')
rep('REV = "B"\nptdwg.DATE = "2026-10-30"', 'REV = "C"\nptdwg.DATE = "2026-10-31"')
rep('"2. GEOMETRY NOT DIMENSIONED PER 3D MODEL LT-OUT-001 REV B."', '"2. GEOMETRY NOT DIMENSIONED PER 3D MODEL LT-OUT-001 REV C."')
rep('''            ["B", "ADDED 2 LOCATING SLOTS AT HIP END (S1, S2, SH4)", "2026-10-30", "MIA"],
            ["", "VIEW LETTERS E-J (DATUMS A-D ONLY)", "", ""]]''',
    '''            ["B", "2 LOCATING SLOTS AT HIP END (S1, S2) - NOT ISSUED", "2026-10-30", "MIA"],
            ["C", "CONNECTOR PAD ON HIP END FACE (SH3)", "2026-10-31", "MIA"],
            ["", "CLIP K1, RIB R1, TABS T1/T2 (SH4); S1, S2 INCLUDED", "", ""],
            ["", "SKIN AND RIB FACES REFINED TO SCAN", "", ""]]''')

# ---- connector pad data (model frame, polar about the hip axis)
rep('SLOT = dict(d=4.30, floor=79.20, top=85.20, y=271.70, xs=(27.03, 49.02), y_step=269.45)',
    '''SLOT = dict(d=4.30, floor=79.20, top=85.20, y=271.70, xs=(27.03, 49.02), y_step=269.45)
PAD = dict(r_in=52.40, r_out=66.20, half=14.0, theta=-109.06, h=4.10, face=276.85, pcr=59.85, s_half=9.08, p_half=2.875,
           tap=3.3, cb_d=7.30, cb_depth=4.00, pin_d=4.05, rc_out=3.0, rc_in=2.0)
PAD["top"] = PAD["face"] + PAD["h"]


def pad_pt(half, r=None, y=None):
    a = math.radians(PAD["theta"] + half)
    r = PAD["pcr"] if r is None else r
    return (PJ["hip"]["ax_x"] + r * math.cos(a), PAD["top"] if y is None else y, PJ["hip"]["ax_z"] + r * math.sin(a))


R2_ = math.sqrt(0.5)
NEW = [("K1", 94.42, 206.92, 7.70, "CLIP HEAD 6.9x12, 2 RAILS, RING %s5.3" % "\\u00d8", "%s2.7 x 1.95 DEEP" % "\\u00d8", (94.42, 206.92, 6.2), 2.65),
       ("R1", 99.0, 194.42, 22.0, "RIB 2.05 THK, WALL TO POST", "-", (99.0, 194.42 + 1.025, 10.0), 0.3),
       ("T1", (144.21 - 192.66) * R2_, (144.21 + 192.66) * R2_, 20.21, "TAB 2.58 THK AT 45 DEG", "%s2.7 THRU" % "\\u00d8",
        (((144.21 - 191.0) * R2_), ((144.21 + 191.0) * R2_), 20.21), 1.29),
       ("T2", -19.23, 188.42, 8.15, "TAB 2.39 THK, C1.6", "%s2.7 THRU" % "\\u00d8", (-19.23, 189.5, 8.15), 1.2)]''')

# ---- SH3: callouts on the pad holes + pad table (after the hip PCD)
rep('''            D("PCD_hip", lambda: lin(hend, h180[0], h0[0], xy(hend, M(HX, 276.85, 100.0)), "cylindrical", S.Center, S.Center,
                                     basic=True, expect=hb["pcd"]))''',
    '''            D("PCD_hip", lambda: lin(hend, h180[0], h0[0], xy(hend, M(HX, 276.85, 100.0)), "cylindrical", S.Center, S.Center,
                                     basic=True, expect=hb["pcd"]))
        # Rev C connector pad: hole callouts below the part, pad data in a table right of the end view
        ps_ = pad_pt(-PAD["s_half"])
        cs_ = N("c_pad_cbore", lambda: arc_xy(hend, M(*ps_), PAD["cb_d"] / 2.0, 0, 0.1))
        if cs_:
            callout("callout_pad_screws", hend, cs_[0], cs_[1], PAD["cb_d"] / 2.0, 0, M(ps_[0] - 30.0, PAD["face"], -66.0),
                    ["2X %s%.1f THRU (M4 TAP)" % (DIA, PAD["tap"]), "C'BORE %s%.2f x %.2f DEEP" % (DIA, PAD["cb_d"], PAD["cb_depth"])])
        pp_ = pad_pt(PAD["p_half"])
        cp_ = N("c_pad_pin", lambda: arc_xy(hend, M(*pp_), PAD["pin_d"] / 2.0, 0, 0.1))
        if cp_:
            callout("callout_pad_pins", hend, cp_[0], cp_[1], PAD["pin_d"] / 2.0, 0, M(pp_[0] + 45.0, PAD["face"], -66.0),
                    ["2X %s%.2f THRU" % (DIA, PAD["pin_d"])])
        prow = [["CONNECTOR PAD (REV C), HIP END FACE", ""],
                ["SECTOR ABOUT HIP AXIS", "R%.2f - R%.2f, %.1f DEG" % (PAD["r_in"], PAD["r_out"], 2 * PAD["half"])],
                ["CENTRE LINE", "%.2f DEG FROM +X (TOWARD -Z)" % -PAD["theta"]],
                ["HEIGHT ABOVE D", "%.2f" % PAD["h"]],
                ["CORNERS", "R%.0f OUTER / R%.0f INNER" % (PAD["rc_out"], PAD["rc_in"])],
                ["HOLES ON R%.2f" % PAD["pcr"], "SCREWS +/-%.2f, PINS +/-%.3f DEG" % (PAD["s_half"], PAD["p_half"])]]
        N("table_pad", lambda: table((290.0, 560.0), [62.0, 86.0], prow, size=3.5, rh=8.0))''')

# ---- SH4 table rows + balloons
rep('''        for i, sx_ in enumerate(SLOT["xs"], 1):
            rows.append(["S%d" % i, "%.2f" % sx_, "%.2f" % SLOT["y"], "LOCATING SLOT (REV B)", "%.2f" % SLOT["top"],
                         "%s%.2f x %.2f DEEP" % (DIA, SLOT["d"], SLOT["top"] - SLOT["floor"])])''',
    '''        for i, sx_ in enumerate(SLOT["xs"], 1):
            rows.append(["S%d" % i, "%.2f" % sx_, "%.2f" % SLOT["y"], "LOCATING SLOT", "%.2f" % SLOT["top"],
                         "%s%.2f x %.2f DEEP" % (DIA, SLOT["d"], SLOT["top"] - SLOT["floor"])])
        for nid, nx_, ny_, nz_, ntxt, nhole, _bp, _br in NEW:
            rows.append([nid, "%.2f" % nx_, "%.2f" % ny_, ntxt, "%.2f" % nz_, nhole])''')
rep('["ALL B, P, H, S FEATURES:"]', '["ALL B, P, H, S, K, R, T FEATURES:"]')
rep('''        for i, sx_ in enumerate(SLOT["xs"], 1):
            feats.append(("S%d" % i, sx_, SLOT["y"], SLOT["top"], SLOT["d"] / 2.0))''',
    '''        for i, sx_ in enumerate(SLOT["xs"], 1):
            feats.append(("S%d" % i, sx_, SLOT["y"], SLOT["top"], SLOT["d"] / 2.0))
        for nid, _x, _y, _z, _t, _h, bp, br in NEW:
            feats.append((nid, bp[0], bp[1], bp[2], br))''')
s = s.replace('"\\u00d8"', '"Ø"')
# Rev C model: the user's knee-hub edits moved the hub OD to R68.25 (Z 10..34.76) and the knee-bore top edge to Z 0.15
rep('c_knee = N("c_knee", lambda: longest(straight(front, at(0, -PJ["hub"]["r_out"], 0.1))))',
    'c_knee = N("c_knee", lambda: longest(straight(front, at(0, -68.25, 0.1))))')
rep('dimc("L_overall", front, c_knee, c_end, (fx(110.0), fz(-60.0)), "horizontal", 355.25, etol=0.2)',
    'dimc("L_overall", front, c_knee, c_end, (fx(110.0), fz(-60.0)), "horizontal", 287.4 + 68.25, etol=0.2)')
rep('ptdwg.arc_at(top, (0.0, 0.0, 0.0), 55.0, tol=0.05)', 'arc_xy(top, (0.0, 0.0, 0.0), 55.0, 2, 0.08)[0]')
open(os.path.join(HERE, "dwg_revC.py"), "w", encoding="utf-8").write(s)
print("ok", len(s))
