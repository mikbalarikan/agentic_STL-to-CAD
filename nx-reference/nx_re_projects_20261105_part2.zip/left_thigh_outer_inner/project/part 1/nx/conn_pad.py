"""LT-OUT-001: connector pad on the hip-end face (the 4-hole pad below the hip ring, 2026-10-31).
Works on a COPY of the user's master; the master is never opened for write.
args: src_prt dst_prt

Measured on the scan (C:\\NX_MCP_WORKSPACE\\lt_conn\\fit2.py / fit3.py, part frame):
- pad = annular sector about the hip axis (X 37.97, Z 35.18, along Y): R 52.40 (fit 52.46) .. R 66.17,
  radial sides at theta -123.05 / -95.07 deg (side lines pass 0.2 mm from the axis), so centre -109.06, 28.0 deg
- top Y 281.06 on a face at 276.94 (scan) -> height 4.1 on the CAD face Y 276.85
- vertical corners: outer R3, inner R2
- 4 holes on R 59.85 about the hip axis, symmetric about the pad centre:
  screws +-9.08 deg: counterbore wall D7.3 (heads of M4 socket screws flush with the top, 3 mm hex),
  inside the plate the hole ends as D3.3 (= M4 tap drill) -> counterbore D7.3 x 4.0 + D3.3 to the cavity
  pins +-2.875 deg (6.0 mm apart): D4.05, seen 4.4 mm deep, modelled through to the cavity
"""
import os, sys, json, math, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf

SRC, DST = sys.argv[1], sys.argv[2]
HX, HZ, FACE_Y = 37.97, 35.18, 276.85
PRM = dict(R_IN=52.40, R_OUT=66.20, H=4.10, THETA=-109.06, HALF=14.0, PCR=59.85, SCREW_HALF=9.08, PIN_HALF=2.875,
           PIN_D=4.05, CB_D=7.30, CB_DEPTH=4.0, TAP_D=3.3, HOLE_DEPTH=15.0, RC_OUT=3.0, RC_IN=2.0, OVERLAP=0.3)
BOOL = nxh.BOOL
res = {"result": "FAIL", "params": PRM, "log": []}
log = res["log"].append


def polar(r, th_deg, y):
    t = math.radians(th_deg)
    return (HX + r * math.cos(t), y, HZ + r * math.sin(t))


try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)

    def is_conv(b):
        try:
            return bool(b.IsConvergentBody)
        except Exception:  # noqa: BLE001
            return False

    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: nxh.volume(part, b))
    res["body"] = body.Name
    v0 = nxh.volume(part, body)
    res["vol_before"] = v0
    res["features_before"] = len(list(part.Features))
    res["errors_before"] = [str(e) for e in nxh.feature_errors(part)]
    res["solids_before"] = len(cand)
    top_y = FACE_Y + PRM["H"]

    # the face under the pad must be the plane Y 276.85, and the plate under each hole solid down to its inner face
    for th in (PRM["THETA"] - PRM["HALF"] + 1, PRM["THETA"], PRM["THETA"] + PRM["HALF"] - 1):
        for r in (PRM["R_IN"] + 0.5, PRM["R_OUT"] - 0.5):
            d = nxh.dist_to(part, body, polar(r, th, FACE_Y + 0.5))
            assert abs(d - 0.5) < 0.02, f"face under the pad not at Y {FACE_Y}: theta {th} r {r} dist {d}"
    inner_y = {}
    for k, half in (("S1", -PRM["SCREW_HALF"]), ("P1", -PRM["PIN_HALF"]), ("P2", PRM["PIN_HALF"]), ("S2", PRM["SCREW_HALF"])):
        x, _, z = polar(PRM["PCR"], PRM["THETA"] + half, 0)
        d = nxh.dist_to(part, body, (x, 262.0, z))            # in the cavity, below the plate
        inner_y[k] = 262.0 + d
    res["plate_inner_y"] = inner_y
    assert all(265.95 + 0.2 < y < 267.5 for y in inner_y.values()), f"plate inner face: {inner_y}"

    E = {}
    for k, nm, cm in (("R_IN", "CONN_PAD_R_IN", "connector pad inner radius about the hip axis"),
                      ("R_OUT", "CONN_PAD_R_OUT", "connector pad outer radius about the hip axis"),
                      ("H", "CONN_PAD_H", "connector pad height above the hip-end face"),
                      ("HALF", "CONN_PAD_HALF_ANG", "connector pad half angle (deg) about its centre line"),
                      ("PCR", "CONN_HOLE_R", "radius of the 4 pad holes about the hip axis"),
                      ("PIN_D", "CONN_PIN_D", "middle holes diameter"),
                      ("CB_D", "CONN_SCREW_CB_D", "screw counterbore diameter (M4 socket head)"),
                      ("CB_DEPTH", "CONN_SCREW_CB_DEPTH", "screw counterbore depth from the pad top"),
                      ("TAP_D", "CONN_SCREW_TAP_D", "M4 tap drill"),
                      ("HOLE_DEPTH", "CONN_HOLE_DEPTH", "hole depth from the pad top (past the plate inner face)"),
                      ("RC_OUT", "CONN_PAD_RC_OUT", "outer corner radius"),
                      ("RC_IN", "CONN_PAD_RC_IN", "inner corner radius")):
        unit = "deg" if k == "HALF" else "mm"
        E[k] = nxh.expr(part, nm, PRM[k], unit=unit, comment=cm).Name

    # 1) pad = rectangle (radial x Y) in the radial plane through the hip axis at the pad centre, revolved +-HALF
    t = math.radians(PRM["THETA"])
    u = (math.cos(t), 0.0, math.sin(t))                          # radial direction
    nrm = (-math.sin(t), 0.0, math.cos(t))                       # plane normal (tangential)
    a_on = (HX, FACE_Y, HZ)
    _, pl = nxh.datum_plane(part, a_on, nrm, name="CONN_PAD_PLANE")
    ax_r = nxf.datum_axis(part, "point_dir", a_on, u, name="CONN_PAD_RADIAL_AXIS")[1]
    ax_hip = nxf.datum_axis(part, "point_dir", a_on, (0, 1, 0), name="CONN_HIP_AXIS")
    sk = nxf.new_sketch(part, pl, ax_r, nxh.point(part, *a_on), name="CONN_PAD_SKETCH")
    rm = (PRM["R_IN"] + PRM["R_OUT"]) / 2
    ym = FACE_Y - PRM["OVERLAP"] + (PRM["H"] + PRM["OVERLAP"]) / 2
    c = polar(rm, PRM["THETA"], ym)
    lines = nxf.sketch_rect_centered(part, sk, nxh.point(part, *c), f"{E['R_OUT']}-{E['R_IN']}",
                                     f"{E['H']}+{PRM['OVERLAP']}")
    res["sketch"] = nxf.finish_sketch(sk)
    assert res["sketch"]["dof"] == 0, res["sketch"]
    sec = nxh.section(part, curves=lines)
    f1 = nxf.revolve(part, sec, nxh.axis(part, a_on, (0, 1, 0)), f"-{E['HALF']}", E["HALF"], op=BOOL.Unite, target=body)
    f1.SetName("CONN_PAD")
    v1 = nxh.volume(part, body)
    alpha = math.radians(2 * PRM["HALF"])
    exp1 = 0.5 * (PRM["R_OUT"] ** 2 - PRM["R_IN"] ** 2) * alpha * PRM["H"]
    res["pad"] = dict(added=v1 - v0, expected=exp1)
    log(f"pad: +{v1 - v0:.3f} mm3 (sector {exp1:.3f})")
    assert abs((v1 - v0) - exp1) < 0.5, res["pad"]

    # 2) vertical corner blends: outer R3, inner R2
    def corner_edge(r, th):
        x, _, z = polar(r, th, 0)
        hits = []
        for e in body.GetEdges():
            p1, p2 = e.GetVertices()
            if all(abs(p.X - x) < 0.02 and abs(p.Z - z) < 0.02 for p in (p1, p2)) and abs(abs(p1.Y - p2.Y) - PRM["H"]) < 0.02:
                hits.append(e)
        return nxh.one(hits, f"corner r {r} th {th}")

    lo, hi = PRM["THETA"] - PRM["HALF"], PRM["THETA"] + PRM["HALF"]
    eo = [corner_edge(PRM["R_OUT"], lo), corner_edge(PRM["R_OUT"], hi)]
    ei = [corner_edge(PRM["R_IN"], lo), corner_edge(PRM["R_IN"], hi)]
    f2 = nxf.edge_blend(part, [(eo, E["RC_OUT"]), (ei, E["RC_IN"])])
    f2.SetName("CONN_PAD_CORNERS")
    v2 = nxh.volume(part, body)
    # each blend removes (1 - pi/4) r^2 h at a 90 deg corner; the sector corners are 90 deg to the arcs
    exp2 = 2 * (1 - math.pi / 4) * (PRM["RC_OUT"] ** 2 + PRM["RC_IN"] ** 2) * PRM["H"]
    res["corners"] = dict(removed=v1 - v2, expected_approx=exp2)
    log(f"corners: -{v1 - v2:.3f} mm3 (about {exp2:.3f})")
    assert abs((v1 - v2) - exp2) < 0.05 * exp2 + 0.3, res["corners"]

    # 3) screw holes: counterbore D7.3 x 4.0, M4 tap drill D3.3 to the cavity
    th_s = [PRM["THETA"] - PRM["SCREW_HALF"], PRM["THETA"] + PRM["SCREW_HALF"]]
    th_p = [PRM["THETA"] - PRM["PIN_HALF"], PRM["THETA"] + PRM["PIN_HALF"]]
    pts_s = [polar(PRM["PCR"], th, top_y) for th in th_s]
    pts_p = [polar(PRM["PCR"], th, top_y) for th in th_p]
    f3 = nxf.hole(part, body, pts_s, E["TAP_D"], depth=E["HOLE_DEPTH"], tip=0, vector=(0, -1, 0),
                  cbore=(E["CB_D"], E["CB_DEPTH"]))
    f3.SetName("CONN_SCREW_HOLES_M4")
    v3 = nxh.volume(part, body)
    exp3 = sum(math.pi / 4 * (PRM["CB_D"] ** 2 * PRM["CB_DEPTH"] + PRM["TAP_D"] ** 2 * (top_y - PRM["CB_DEPTH"] - inner_y[k]))
               for k in ("S1", "S2"))
    res["screw_holes"] = dict(removed=v2 - v3, expected=exp3)
    log(f"screw holes: -{v2 - v3:.3f} mm3 (expected {exp3:.3f})")
    assert abs((v2 - v3) - exp3) < 0.01 * exp3, res["screw_holes"]

    # 4) middle holes D4.05 to the cavity
    f4 = nxf.hole(part, body, pts_p, E["PIN_D"], depth=E["HOLE_DEPTH"], tip=0, vector=(0, -1, 0))
    f4.SetName("CONN_PIN_HOLES")
    v4 = nxh.volume(part, body)
    exp4 = sum(math.pi / 4 * PRM["PIN_D"] ** 2 * (top_y - inner_y[k]) for k in ("P1", "P2"))
    res["pin_holes"] = dict(removed=v3 - v4, expected=exp4)
    log(f"pin holes: -{v3 - v4:.3f} mm3 (expected {exp4:.3f})")
    assert abs((v3 - v4) - exp4) < 0.01 * exp4, res["pin_holes"]

    # probes: pad top, hole axes open, nothing below the plate cut
    pr = {}
    pr["top"] = nxh.dist_to(part, body, polar(PRM["R_OUT"] - 1.0, PRM["THETA"], top_y + 1.0))   # clear of all holes
    for k, th in (("S1", th_s[0]), ("P1", th_p[0]), ("P2", th_p[1]), ("S2", th_s[1])):
        pr[k + "_axis_mid"] = nxh.dist_to(part, body, polar(PRM["PCR"], th, 272.0))   # inside the hole: > 0
    res["probes"] = pr
    assert abs(pr["top"] - 1.0) < 1e-3, pr
    assert all(pr[k] > 1.5 for k in pr if k.endswith("axis_mid")), pr

    res["vol_after"] = v4
    res["delta_total"] = v4 - v0
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["solids_after"] = len([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)])
    res["features_after"] = len(list(part.Features))
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part)]
    res["new_features"] = [f.GetFeatureName() + " / " + f.Name for f in list(part.Features)[res["features_before"]:]]
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    ok = res["body_ok"] and res["solids_after"] == res["solids_before"] and len(res["errors_after"]) <= len(res["errors_before"])
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_conn_pad.json", res)
