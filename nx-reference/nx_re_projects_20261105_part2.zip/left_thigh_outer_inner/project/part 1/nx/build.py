"""Left Thigh (outer shell) - native NX rebuild from the scan.  args: out_dir [stop_stage]
Frame: origin on the knee axis at the knee-floor plane, Z = knee axis (open side up), Y = hip-axis direction.
Stages: A envelope+hub, B shell (cavity), C plateaus (ribs/bosses/pads/tongue), D hip plate+ring, E bores and
hole patterns, F bosses/pins/small holes. Every number comes from work/*.json (scan analysis, see an/)."""
import os, sys, json, math, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, curvekit as ck, nxre

OUT = sys.argv[1]
STOP = sys.argv[2] if len(sys.argv) > 2 else "Z"
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer"
WK = os.path.join(ROOT, "work")
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": [], "checks": {}}
T0 = time.time()


def log(msg):
    res["log"].append(f"[{time.time()-T0:6.0f}s] {msg}")
    nxh.write_json(os.path.join(OUT, "build.json"), res)


P = json.load(open(os.path.join(ROOT, "nx", "params.json")))


# ------------------------------------------------------------------ helpers
def bs_eval(knots, poles, u):
    k = 3; n = len(poles)
    i = n - 1 if u >= knots[n] else max(j for j in range(k, n) if knots[j] <= u)
    d = [list(poles[j]) for j in range(i - k, i + 1)]
    for r in range(1, k + 1):
        for j in range(k, r - 1, -1):
            a = (u - knots[j + i - k]) / (knots[j + 1 + i - r] - knots[j + i - k])
            d[j] = [(1 - a) * d[j - 1][c] + a * d[j][c] for c in range(3)]
    return d[k]


def loft_sheet(part, jsonfile, ymin=-1e9):
    sec = [s for s in json.load(open(os.path.join(WK, jsonfile)))["sections"] if s["y"] >= ymin]
    sps = []
    for s in sec:
        f, sp = ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True)
        sps.append(sp)
    tc = nxf.through_curves(part, [nxh.section(part, curves=[sp]) for sp in sps], solid=False)
    return tc, tc.GetBodies()[0], sps


def block_trimmed(part, sheet, name, y0=-69.0):
    bf, blk = nxh.block(part, (-130.0, y0, -70.0), (320.0, 287.4 - y0, 114.0))
    v0 = nxh.volume(part, blk)
    nxf.trim_body(part, blk, reverse=True, sheet=sheet)
    v1 = nxh.volume(part, blk)
    if v1 > 0.5 * v0:
        raise RuntimeError(f"{name}: trim kept the outside")
    return blk, v1


def seg_curves(part, segs, z):
    cs = []
    for s in segs:
        if s[0] == "L":
            cs.append(nxh.line(part, (s[1][0], s[1][1], z), (s[2][0], s[2][1], z)))
        else:
            p0, p1, c, r, ccw = s[1], s[2], s[3], s[4], s[5]
            a0 = math.atan2(p0[1] - c[1], p0[0] - c[0]); a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
            if not ccw:
                a0, a1 = a1, a0
            while a1 <= a0:
                a1 += 2 * math.pi
            cs.append(nxh.arc(part, (c[0], c[1], z), (1, 0, 0), (0, 1, 0), r, a0, a1))
    return cs


def poly_curves(part, pts, z=None, plane="xy"):
    return nxh.polyline(part, pts, closed=True)


def extrude_curves(part, curves, vec, start, end, hp=(0, 0, 0)):
    f = nxh.extrude(part, nxh.section(part, curves=curves, help_point=hp), vec, start, end)
    return f, f.GetBodies()


def clip_unite(part, body, tools, envx, label):
    """Intersect each tool body with a kept copy of the envelope, unite the pieces into body."""
    pieces = []
    for t in tools:
        f = nxh.intersect(part, t, [envx], check=False, keep_tool=True)
        pieces += [b for b in f.GetBodies() if b.IsSolidBody]
    if pieces:
        nxh.unite(part, body, pieces, check=False)
    return len(pieces)


def sector_curves(part, r0, r1, a0, a1, z):
    """Closed annular sector (degrees, ccw a0->a1) at height z."""
    A0, A1 = math.radians(a0), math.radians(a1)
    c = []
    c.append(nxh.arc(part, (0, 0, z), (1, 0, 0), (0, 1, 0), r1, A0, A1))
    c.append(nxh.line(part, (r1 * math.cos(A1), r1 * math.sin(A1), z), (r0 * math.cos(A1), r0 * math.sin(A1), z)))
    if r0 > 0:
        c.append(nxh.arc(part, (0, 0, z), (1, 0, 0), (0, 1, 0), r0, A0, A1))
        c.append(nxh.line(part, (r0 * math.cos(A0), r0 * math.sin(A0), z), (r1 * math.cos(A0), r1 * math.sin(A0), z)))
    else:
        c.append(nxh.line(part, (0, 0, z), (r1 * math.cos(A0), r1 * math.sin(A0), z)))
    return c


def revolve_rz(part, pts_rz, axis_origin, axis_dir, radial_dir, op, target):
    """Closed (r, axial) polygon in the plane spanned by radial_dir and axis_dir, revolved 360 deg."""
    o = axis_origin
    P3 = [tuple(o[k] + r * radial_dir[k] + a * axis_dir[k] for k in range(3)) for r, a in pts_rz]
    cs = nxh.polyline(part, P3, closed=True)
    hp = P3[0]
    return nxf.revolve(part, nxh.section(part, curves=cs, help_point=hp), nxh.axis(part, o, axis_dir), 0, 360, op=op, target=target)


def check(name, ok, value=None):
    res["checks"][name] = {"ok": bool(ok), "value": value}
    if not ok:
        log(f"CHECK FAILED {name}: {value}")


# ------------------------------------------------------------------ build
part = None
try:
    part = nxh.new_part(os.path.join(OUT, "Left_Thigh_Outer.prt"))
    for k, v in P["expressions"].items():
        nxh.expr(part, k, v[0], v[1], v[2] if len(v) > 2 else "")

    # ---- A: envelope
    tc, skin, _ = loft_sheet(part, "sections.json")
    log(f"A skin loft area {nxh.sheet_area(part, skin)[0]:.0f}")
    body, v = block_trimmed(part, skin, "skin")
    log(f"A skin solid {v:.0f}")
    H = P["hub"]
    # sector of the round knee end where the hub cylinder is the outside (skin removed there)
    fs, (sect,) = extrude_curves(part, sector_curves(part, H["r_out"], 400.0, H["round_a0"], H["round_a1"], -90.0), (0, 0, 1), 0, 200)
    nxh.subtract(part, body, [sect])
    fc, cyl = nxh.cylinder(part, (0.0, 0.0, -90.0), (0, 0, 1), 2 * H["r_out"], 200.0)
    nxh.subtract(part, body, [cyl], check=False)
    nb = [b for b in part.Bodies if b.IsSolidBody]
    log(f"A skin minus hub zone: solids {len(nb)}")
    if len(nb) > 1:  # keep the shank piece, delete tiny leftovers
        nb.sort(key=lambda b: -nxh.volume(part, b))
        body = nb[0]
        nxf.delete_body(part, nb[1:])
        log(f"A deleted {len(nb)-1} leftover pieces")
    rev = revolve_rz(part, H["outer_profile_rz"], (0, 0, 0), (0, 0, 1), (1, 0, 0), BOOL.Unite, body)
    venv = nxh.volume(part, body)
    log(f"A envelope (skin + hub) {venv:.0f}")
    check("A envelope single solid", len([b for b in part.Bodies if b.IsSolidBody]) == 1)
    ef, (envx,) = nxf.extract_body(part, [body])
    envx.Blank()
    if STOP == "A": raise StopIteration

    # ---- B: shell = envelope - cavity
    tci, isheet, _ = loft_sheet(part, "inner_sections.json", ymin=-54.0)
    cav, vc = block_trimmed(part, isheet, "inner", y0=-53.0)
    log(f"B cavity (inner skin) {vc:.0f}")
    hc, hubcav = nxh.cylinder(part, (0.0, 0.0, 0.0), (0, 0, 1), 2 * H["r_in"], 60.0)
    fs2, (sec2,) = extrude_curves(part, sector_curves(part, 0.0, H["open_r"], H["open_a0"], H["open_a1"], 0.0), (0, 0, 1), 0, 60)
    nxh.unite(part, cav, [hubcav, sec2], check=False)
    hp = P["hip"]
    bf, slab = nxh.block(part, (-150.0, hp["y_plate_in"], -90.0), (350.0, hp["y_plate_out"] - hp["y_plate_in"], 200.0))
    nxh.subtract(part, cav, [slab], check=False)
    nxh.subtract(part, body, [cav], check=False)
    sol = [b for b in part.Bodies if b.IsSolidBody and b.Tag != envx.Tag]
    sol.sort(key=lambda b: -nxh.volume(part, b))
    if len(sol) > 1:
        log(f"B shell pieces {[round(nxh.volume(part, b)) for b in sol]}")
        body = sol[0]
        nxf.delete_body(part, sol[1:])
    nxh.block(part, (-150.0, -80.0, P["levels"]["rim"]), (350.0, 400.0, 100.0), op=BOOL.Subtract, target=body)
    log(f"B shell trimmed at rim {P['levels']['rim']}: {nxh.volume(part, body):.0f}")
    if STOP == "B": raise StopIteration

    # ---- C: plateaus
    plats = json.load(open(os.path.join(WK, "plateaus_nx.json")))
    for L in plats:
        h = L["h"]
        tools = []
        for g in L["groups"]:
            cs = seg_curves(part, g["outer"], -80.0)
            for hl in g["holes"]:
                if not P["plateau_hole_keep"]:
                    continue
                cs += seg_curves(part, hl, -80.0)
            try:
                f, bodies = extrude_curves(part, cs, (0, 0, 1), 0, h + 80.0, hp=tuple(g["outer"][0][1]) + (-80.0,))
                tools += [b for b in bodies if b.IsSolidBody]
            except Exception as e:  # noqa: BLE001
                log(f"C level {h} group area {g['area']:.0f}: extrude failed {e}")
        n = clip_unite(part, body, tools, envx, f"level {h}")
        log(f"C level {h}: {len(tools)} tools -> {n} pieces; body {nxh.volume(part, body):.0f}")
    # hub floor + round-side hub wall (analytic)
    fcf, fl = nxh.cylinder(part, (0.0, 0.0, -30.0), (0, 0, 1), 2 * H["r_in"] + 0.2, 30.0)
    fw, (wl,) = extrude_curves(part, sector_curves(part, H["r_in"], H["r_out"] + 1.0, H["round_a0"], H["round_a1"], -30.0), (0, 0, 1), 0, 30.0 + P["levels"]["rim"])
    clip_unite(part, body, [fl, wl], envx, "hub floor/wall")
    # low wall on the -x side of the hub
    fl2, (lw,) = extrude_curves(part, sector_curves(part, H["r_in"] - 3.0, H["r_out"] + 10.0, H["low_a0"], H["low_a1"], H["low_z"]), (0, 0, 1), 0, 60.0)
    nxh.subtract(part, body, [lw], check=False)
    log(f"C hub floor/wall/low wall; body {nxh.volume(part, body):.0f}")
    if STOP == "C": raise StopIteration

    # ---- D: hip plate is kept by the slab; ring above the rim
    ax0 = (hp["ax_x"], hp["y_plate_in"], hp["ax_z"])
    nxh.cylinder(part, ax0, (0, 1, 0), hp["ring_od"], hp["y_ring_out"] - hp["y_plate_in"], op=BOOL.Unite, target=body)
    nxh.block(part, (-50.0, 250.0, hp["ring_top_z"]), (200.0, 50.0, 50.0), op=BOOL.Subtract, target=body)
    revolve_rz(part, hp["bore_rz"], (hp["ax_x"], 0.0, hp["ax_z"]), (0, 1, 0), (1, 0, 0), BOOL.Subtract, body)
    log(f"D hip ring + bores; body {nxh.volume(part, body):.0f}")
    if STOP == "D": raise StopIteration

    # ---- E: knee bores and the two bolt circles
    revolve_rz(part, H["bore_rz"], (0, 0, 0), (0, 0, 1), (1, 0, 0), BOOL.Subtract, body)
    kb = P["knee_bolts"]
    tools = []
    for k in range(kb["n"]):
        a = math.radians(kb["clock"] + k * 360.0 / kb["n"])
        f, c = nxh.cylinder(part, (kb["pcd"] / 2 * math.cos(a), kb["pcd"] / 2 * math.sin(a), kb["z0"]), (0, 0, 1), kb["d"], kb["z1"] - kb["z0"])
        tools.append(c)
    nxh.subtract(part, body, tools, check=False)
    hb = P["hip_bolts"]
    tools = []
    for k in range(hb["n"]):
        a = math.radians(hb["clock"] + k * 360.0 / hb["n"])
        x = hp["ax_x"] + hb["pcd"] / 2 * math.cos(a); z = hp["ax_z"] + hb["pcd"] / 2 * math.sin(a)
        f, c = nxh.cylinder(part, (x, hb["y0"], z), (0, 1, 0), hb["d"], hb["y1"] - hb["y0"])
        f2, c2 = nxh.cylinder(part, (x, hb["cb_y0"], z), (0, 1, 0), hb["cb_d"], hb["cb_y1"] - hb["cb_y0"])
        tools += [c, c2]
    nxh.subtract(part, body, tools, check=False)
    log(f"E bores + {kb['n']} knee holes + {hb['n']} hip holes; body {nxh.volume(part, body):.0f}")
    if STOP == "E": raise StopIteration

    # ---- F: boss spigots, pins, boss bores, small holes
    for b in P["bosses"]:
        nxh.cylinder(part, (b["x"], b["y"], b["z0"]), (0, 0, 1), b["nub_d"], b["z1"] - b["z0"], op=BOOL.Unite, target=body)
    for p in P["pins"]:
        f, pb = nxh.cylinder(part, (p["x"], p["y"], -40.0), (0, 0, 1), p["base_d"], p["base_z"] + 40.0)
        clip_unite(part, body, [pb], envx, "pin base")
        nxh.cylinder(part, (p["x"], p["y"], p["base_z"] - 0.5), (0, 0, 1), p["d"], p["top_z"] - p["base_z"] + 0.5, op=BOOL.Unite, target=body)
    tools = []
    for b in P["bosses"]:
        f, c = nxh.cylinder(part, (b["x"], b["y"], b["z1"] - b["hole_depth"]), (0, 0, 1), b["hole_d"], b["hole_depth"] + 1.0)
        tools.append(c)
    for h in P["small_holes"]:
        f, c = nxh.cylinder(part, (h["x"], h["y"], h["z1"] - h["depth"]), (0, 0, 1), h["d"], h["depth"] + 1.0)
        tools.append(c)
    nxh.subtract(part, body, tools, check=False)
    log(f"F bosses/pins/holes; body {nxh.volume(part, body):.0f}")
    raise StopIteration
except StopIteration:
    pass
except Exception:
    res["error"] = traceback.format_exc()
    log("ERROR")
try:
    sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
    res["solids"] = [round(nxh.volume(part, b), 1) for b in sol]
    res["body_ok"] = [nxh.body_ok(part, b) for b in sol]
    res["feature_errors"] = [str(e) for e in nxh.feature_errors(part)][:20]
    if sol:
        big = max(sol, key=lambda b: nxh.volume(part, b))
        nxre.stl_export(part, big, os.path.join(OUT, f"thigh_{STOP}.stl"), chord=0.01, max_edge=2.0)
    nxh.save(part)
    if "error" not in res:
        res["result"] = "PASS"
except Exception:
    res["error_final"] = traceback.format_exc()
res["t"] = round(time.time() - T0, 1)
nxh.write_json(os.path.join(OUT, "build.json"), res)
