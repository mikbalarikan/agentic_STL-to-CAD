"""Examine loft sheets built from sub-ranges of the section set, to find the inconsistent region.
args: out_json sections_name"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"])
import NXOpen
import nxh, nxf, curvekit as ck
OUTJ, NAME = sys.argv[1], sys.argv[2]
WK = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\work"
res = {}
try:
    part = nxh.new_part(os.path.join(os.path.dirname(OUTJ), "loftcheck.prt"))
    sec = json.load(open(os.path.join(WK, NAME + ".json")))["sections"]
    sps = {s["y"]: ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True)[1] for s in sec}
    ys = sorted(sps)
    for (lo, hi) in ((-70, 292), (-70, -20), (-30, 60), (50, 150), (140, 230), (220, 292), (-70, -50), (-54, -30)):
        sel = [y for y in ys if lo <= y <= hi]
        m = nxh.mark("t", False)
        try:
            tc = nxf.through_curves(part, [nxh.section(part, curves=[sps[y]]) for y in sel], solid=False)
            sh = tc.GetBodies()[0]
            ex = nxh.examine_geometry(part, sh)
            res[f"{lo}..{hi}"] = {k: v for k, v in ex.items() if v}
            res[f"{lo}..{hi} faces"] = len(sh.GetFaces())
        except Exception as e:  # noqa: BLE001
            res[f"{lo}..{hi}"] = "ERR " + str(e)[:100]
        nxh.undo_to(m)
    # single section curve checks
    q = {}
    for y in ys:
        try:
            q[y] = nxh.curve_quality(sps[y])
        except Exception as e:  # noqa: BLE001
            q[y] = str(e)[:60]
    res["curve_quality"] = {str(k): (v if isinstance(v, str) else {kk: v[kk] for kk in ("k_max", "inflections", "peaks") if kk in v}) for k, v in q.items()}
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(OUTJ, res)
