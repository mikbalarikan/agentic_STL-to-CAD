"""LT-OUT-001: four details the user marked on the _CONN overlay part (2026-10-31), appended at the END of the
user's history on a COPY. args: src_prt dst_prt

Measured on the scan (C:\\NX_MCP_WORKSPACE\\lt_conn: dev.py clusters, secs.py / cplot*.py / hfit.py sections and fits):
A  clip head on the post in the middle of the floor (centre X 94.42 Y 206.92, turned -4.6 deg about Z): head plate
   Z 2.0..4.78 (= top of the existing post), 6.9 x 12.0; two rails at the ends Z 4.78..7.7, 1.65 wide;
   ring D5.3 to Z 6.2 with a D2.7 hole down to Z 4.25. The existing post below the head stays as the user made it.
B  rib Y 194.42, 2.05 thick, free edge X = 95.49 + 0.463 Z, from the wall up to the tall post.
C  tab beside the hip-end boss, turned 45 deg: faces u = p.e 142.92 / 145.50 (e = (+x+y)/r2), tip w = p.d -189.78
   (d = (+x-y)/r2), top Z 20.21, D2.7 hole along e at (w -192.66, Z 15.6).
D  tab on the lower side wall: X -20.42..-18.03 (flush with the wall face), top Z 8.15 (= wall top), end Y 191.85
   with a 1.6 chamfer on the -X corner, D2.7 hole along X at (Y 188.42, Z 4.48).
"""
import os, sys, json, math, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf

SRC, DST = sys.argv[1], sys.argv[2]
BOOL = nxh.BOOL
SK = NXOpen.Sketch
R2 = math.sqrt(0.5)
E_ = (R2, R2, 0.0)          # C thickness direction
D_ = (R2, -R2, 0.0)         # C length direction
HOLE_D = 2.7
res = {"result": "FAIL", "log": [], "checks": {}}
log = res["log"].append


def lin(*terms):
    out = [0.0, 0.0, 0.0]
    for s, v in terms:
        for i in range(3):
            out[i] += s * v[i]
    return tuple(out)


def C3(u, w, z):
    return lin((u, E_), (w, D_), (z, (0, 0, 1)))


try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)

    def is_conv(b):
        try:
            return bool(b.IsConvergentBody)
        except Exception:  # noqa: BLE001
            return False

    def main_body():
        cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
        return max(cand, key=lambda b: nxh.volume(part, b)), len(cand)

    body, n0 = main_body()
    v0 = nxh.volume(part, body)
    res.update(body=body.Name, vol_before=v0, solids_before=n0, features_before=len(list(part.Features)),
               errors_before=[str(e) for e in nxh.feature_errors(part)])
    chk = res["checks"]

    def inside(p):
        return nxh.dist_to(part, body, p) < 1e-4

    # tool corners that must sit inside the existing material (so no tool pokes through a skin)
    pre = {"C_tab_root_low": C3(144.2, -196.9, 11.0), "C_tab_bottom_tip": C3(144.2, -189.9, 2.2),
           "C_tab_bottom_mid": C3(143.0, -193.5, 6.8), "D_tab_bottom_root": (-19.2, 181.6, 1.6),
           "D_tab_bottom_end": (-19.2, 191.7, -2.1), "D_tab_bottom_end_xm": (-20.3, 191.7, -2.1),
           "B_rib_low_end": (89.95, 194.42, -11.9), "B_rib_top_end": (105.6, 194.42, 21.9),
           "A_head_on_post": (94.42, 210.0, 3.0)}
    chk["tool_points_in_material"] = {k: inside(p) for k, p in pre.items()}
    assert all(chk["tool_points_in_material"].values()), chk["tool_points_in_material"]
    # and the places to fill must be empty now
    empty = {"A_rail_-y": (94.42 - 5.17 * math.sin(math.radians(4.6)), 206.92 - 5.17 * math.cos(math.radians(4.6)), 6.5),
             "A_head_ext": (94.4, 201.5, 3.5), "B_rib_mid": (100.0, 194.42, 6.0), "C_tab_mid": C3(144.2, -191.0, 17.0),
             "D_tab_mid": (-19.2, 189.5, 6.5)}
    chk["fill_points_empty_before"] = {k: not inside(p) for k, p in empty.items()}
    assert all(chk["fill_points_empty_before"].values()), chk["fill_points_empty_before"]

    def vol():
        return nxh.volume(part, body)

    feats = {}
    vol_log = {}

    def step(name, fn):
        va = vol()
        f = fn()
        f.SetName(name)
        vb = vol()
        vol_log[name] = round(vb - va, 3)
        log(f"{name}: {vb - va:+.3f} mm3")
        feats[name] = f
        return f

    def poly_sketch(name, plane, haxis, origin, pts):
        sk = nxf.new_sketch(part, plane, haxis, nxh.point(part, *origin), name=name)
        lines = nxh.polyline(part, pts)
        nxf.add(sk, *lines)
        st = nxf.finish_sketch(sk)
        res.setdefault("sketches", {})[name] = st
        return sk, lines

    # ---------------------------------------------------------------- A: clip head
    th = math.radians(-4.6)
    a1 = (math.cos(th), math.sin(th), 0.0)
    a2 = (-math.sin(th), math.cos(th), 0.0)
    OA = (94.42, 206.92)

    def A(x, y, z):
        return (OA[0] + x * a1[0] + y * a2[0], OA[1] + x * a1[1] + y * a2[1], z)

    ax_a = nxf.datum_axis(part, "point_dir", (OA[0], OA[1], 0.0), a1, name="FIX_A_AXIS")[1]
    _, pl_a0 = nxh.datum_plane(part, (0, 0, 2.0), (0, 0, 1), name="FIX_A_HEAD_BOTTOM")
    _, pl_a1 = nxh.datum_plane(part, (0, 0, 4.78), (0, 0, 1), name="FIX_A_HEAD_TOP")
    for nm in ("A_HEAD_W", "A_HEAD_L", "A_RAIL_W"):
        pass
    nxh.expr(part, "FIX_A_HEAD_W", 6.9, comment="clip head width")
    nxh.expr(part, "FIX_A_HEAD_L", 12.0, comment="clip head length (over the rails)")
    nxh.expr(part, "FIX_A_RAIL_W", 1.65, comment="clip head rail width")
    nxh.expr(part, "FIX_A_RAIL_H", 2.92, comment="rail height above the head (top Z 7.7)")
    nxh.expr(part, "FIX_A_RING_D", 5.3, comment="ring boss diameter")
    nxh.expr(part, "FIX_A_RING_H", 1.42, comment="ring height above the head (top Z 6.2)")
    nxh.expr(part, "FIX_HOLE_D", HOLE_D, comment="small holes of the A ring, C tab and D tab")

    def head():
        sk = nxf.new_sketch(part, pl_a0, ax_a, nxh.point(part, OA[0], OA[1], 2.0), name="FIX_A_HEAD_SKETCH")
        ls = nxf.sketch_rect_centered(part, sk, nxh.point(part, *A(-0.05, 0.0, 2.0)), "FIX_A_HEAD_W", "FIX_A_HEAD_L")
        res.setdefault("sketches", {})["FIX_A_HEAD_SKETCH"] = nxf.finish_sketch(sk)
        return nxh.extrude(part, nxh.section(part, curves=ls), (0, 0, 1), 0, "4.78-2.0", op=BOOL.Unite, target=body)
    step("FIX_A_CLIP_HEAD", head)

    def rails():
        sk = nxf.new_sketch(part, pl_a1, ax_a, nxh.point(part, OA[0], OA[1], 4.78), name="FIX_A_RAILS_SKETCH")
        ls = []
        for s in (1, -1):
            ls += nxf.sketch_rect_centered(part, sk, nxh.point(part, *A(-0.05, s * (6.0 - 1.65 / 2), 4.78)),
                                           "FIX_A_HEAD_W", "FIX_A_RAIL_W")
        res.setdefault("sketches", {})["FIX_A_RAILS_SKETCH"] = nxf.finish_sketch(sk)
        return nxh.extrude(part, nxh.section(part, curves=ls), (0, 0, 1), 0, "FIX_A_RAIL_H", op=BOOL.Unite, target=body)
    step("FIX_A_CLIP_RAILS", rails)

    def ring():
        sk = nxf.new_sketch(part, pl_a1, ax_a, nxh.point(part, OA[0], OA[1], 4.78), name="FIX_A_RING_SKETCH")
        nxf.sketch_circle(part, sk, nxh.point(part, OA[0], OA[1], 4.78), "FIX_A_RING_D")
        res.setdefault("sketches", {})["FIX_A_RING_SKETCH"] = nxf.finish_sketch(sk)
        sec = nxh.section_feature(part, [sk.Feature], curves_only=True)
        return nxh.extrude(part, sec, (0, 0, 1), 0, "FIX_A_RING_H", op=BOOL.Unite, target=body)
    step("FIX_A_CLIP_RING", ring)
    step("FIX_A_CLIP_HOLE", lambda: nxf.hole(part, body, [(OA[0], OA[1], 6.2)], "FIX_HOLE_D", depth="6.2-4.25", tip=0,
                                             vector=(0, 0, -1)))

    # ---------------------------------------------------------------- B: rib under the tall post
    _, pl_b = nxh.datum_plane(part, (0, 194.42, 0), (0, 1, 0), name="FIX_B_RIB_PLANE")
    ax_bx = nxf.datum_axis(part, "point_dir", (0, 194.42, 0), (1, 0, 0), name="FIX_B_X_AXIS")[1]

    def rib():
        sk = nxf.new_sketch(part, pl_b, ax_bx, nxh.point(part, 0, 194.42, 0), name="FIX_B_RIB_SKETCH")
        za, zb = -12.0, 22.0
        pa, pb = (95.49 + 0.463 * za, 194.42, za), (95.49 + 0.463 * zb, 194.42, zb)
        toward = (103.0, 194.42, 4.0)
        m = sk.Orientation.Element
        nz = (m.Zx, m.Zy, m.Zz)
        d = [q - p for p, q in zip(pa, pb)]
        side = (d[1] * nz[2] - d[2] * nz[1], d[2] * nz[0] - d[0] * nz[2], d[0] * nz[1] - d[1] * nz[0])
        if sum(s_ * (t - p) for s_, t, p in zip(side, toward, pa)) < 0:
            pa, pb = pb, pa
        sk.AddGeometry(nxh.line(part, pa, pb), SK.InferConstraintsOption.InferNoConstraints)
        res.setdefault("sketches", {})["FIX_B_RIB_SKETCH"] = nxf.finish_sketch(sk)
        return nxf._rib(part, body, sk, pa, False, 2.05, False, None)
    step("FIX_B_RIB", rib)

    # ---------------------------------------------------------------- C: 45 deg tab beside the hip-end boss
    u0, u1 = 142.92, 145.50
    _, pl_c = nxh.datum_plane(part, C3(u0, 0, 0), E_, name="FIX_C_TAB_PLANE")
    ax_c = nxf.datum_axis(part, "point_dir", C3(u0, 0, 0), D_, name="FIX_C_TAB_AXIS")[1]

    def tab_c():
        pts = [C3(u0, -197.0, 20.21), C3(u0, -189.78, 20.21), C3(u0, -189.78, 2.0), C3(u0, -197.0, 11.0)]
        sk, ls = poly_sketch("FIX_C_TAB_SKETCH", pl_c, ax_c, C3(u0, 0, 0), pts)
        return nxh.extrude(part, nxh.section(part, curves=ls), E_, 0, u1 - u0, op=BOOL.Unite, target=body)
    step("FIX_C_TAB", tab_c)
    step("FIX_C_TAB_HOLE", lambda: nxf.hole(part, body, [C3(u0, -192.66, 15.6)], "FIX_HOLE_D", depth=u1 - u0 + 0.5,
                                            tip=0, vector=E_))

    # ---------------------------------------------------------------- D: tab on the lower side wall
    x0, x1 = -20.42, -18.03
    _, pl_d = nxh.datum_plane(part, (x0, 0, 0), (1, 0, 0), name="FIX_D_TAB_PLANE")
    ax_dy = nxf.datum_axis(part, "point_dir", (x0, 0, 0), (0, 1, 0), name="FIX_D_Y_AXIS")[1]

    def tab_d():
        pts = [(x0, 181.5, 8.15), (x0, 191.85, 8.15), (x0, 191.85, -2.2), (x0, 181.5, 1.5)]
        sk, ls = poly_sketch("FIX_D_TAB_SKETCH", pl_d, ax_dy, (x0, 0, 0), pts)
        return nxh.extrude(part, nxh.section(part, curves=ls), (1, 0, 0), 0, x1 - x0, op=BOOL.Unite, target=body)
    step("FIX_D_TAB", tab_d)

    def cham_d():
        hits = []
        for e in body.GetEdges():
            p1, p2 = e.GetVertices()
            if all(abs(p.X - x0) < 0.02 and abs(p.Y - 191.85) < 0.02 for p in (p1, p2)) and abs(p1.Z - p2.Z) > 3:
                hits.append(e)
        return nxf.chamfer(part, [nxh.one(hits, "D tab end edge")], 1.6)
    step("FIX_D_TAB_CHAMFER", cham_d)
    step("FIX_D_TAB_HOLE", lambda: nxf.hole(part, body, [(x0, 188.42, 4.48)], "FIX_HOLE_D", depth=x1 - x0 + 0.5, tip=0,
                                            vector=(1, 0, 0)))

    # ---------------------------------------------------------------- checks
    filled = {"A_rail_-y": empty["A_rail_-y"], "A_head_ext": empty["A_head_ext"], "A_ring": A(0, 2.4, 5.5),
              "B_rib_mid": empty["B_rib_mid"], "C_tab_mid": empty["C_tab_mid"], "D_tab_mid": empty["D_tab_mid"]}
    chk["filled_after"] = {k: inside(p) for k, p in filled.items()}
    holes = {"A_hole": (OA[0], OA[1], 5.0), "C_hole": C3(144.2, -192.66, 15.6), "D_hole": (-19.2, 188.42, 4.48)}
    chk["holes_open"] = {k: round(nxh.dist_to(part, body, p), 3) for k, p in holes.items()}
    tops = {"A_rail_top": (A(0, 5.17, 7.7 + 0.5), 0.5), "A_ring_top": (A(0, 2.3, 6.2 + 0.5), 0.5),
            "C_top": (C3(144.2, -191.0, 20.21 + 0.5), 0.5), "D_top": ((-19.2, 189.5, 8.15 + 0.5), 0.5),
            "D_end": ((-18.3, 191.85 + 0.5, 6.0), 0.5), "C_tip": (C3(144.2, -189.78 + 0.5, 15.0), 0.5)}
    chk["faces_at"] = {k: round(nxh.dist_to(part, body, p), 4) for k, (p, d) in tops.items()}
    res["vol_steps"] = vol_log
    body2, n1 = main_body()
    res["vol_after"] = vol()
    res["delta_total"] = res["vol_after"] - v0
    res["solids_after"] = n1
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part)]
    res["features_after"] = len(list(part.Features))
    res["new_features"] = [f.GetFeatureName() + " / " + f.Name for f in list(part.Features)[res["features_before"]:]]
    ok = (res["body_ok"] and n1 == n0 and not res["errors_after"] and all(chk["filled_after"].values())
          and all(v > 0.5 for v in chk["holes_open"].values())
          and all(abs(v - 0.5) < 0.02 for v in chk["faces_at"].values())
          and all(v > 0 for k, v in vol_log.items() if "HOLE" not in k and "CHAMFER" not in k))
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    try:
        sys.path.insert(0, os.environ["NXRE_DIR"])
        import nxre
        nxre.stl_export(part, body, os.path.splitext(DST)[0] + ".stl", chord=0.005, max_edge=1.5)
    except Exception as e:  # noqa: BLE001
        res["stl_err"] = str(e)
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_fix_r2.json", res)
