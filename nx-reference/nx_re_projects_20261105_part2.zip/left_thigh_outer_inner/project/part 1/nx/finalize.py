"""Finalize the built part: keep one solid, helper geometry to layer 200, reference set SOLID, mass,
save-as the delivery name, exports (STEP AP214 + AP242, Parasolid x_t, STL) + STEP round trip.
args: built_prt deliver_dir [revision, default A]"""
import os, sys, json, traceback, shutil
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, DST = sys.argv[1], sys.argv[2]
REV = sys.argv[3] if len(sys.argv) > 3 else "A"
NAME = "LT-OUT-001_Left_Thigh_Outer"
os.makedirs(DST, exist_ok=True)
res = {"result": "FAIL", "log": []}
log = res["log"].append
try:
    work = os.path.join(DST, NAME + ".prt")
    if os.path.exists(work):
        os.remove(work)
    shutil.copyfile(SRC, work)
    part = nxh.open_part(work)
    # the scan overlay (convergent bodies) does not belong in the delivered part
    conv = [f for f in part.Features if f.FeatureType == "BREP" and f.GetFeatureName().startswith("Convergent Body")]
    if conv:
        v0 = [nxh.volume(part, b) for b in part.Bodies if b.IsSolidBody]
        main0 = max([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not getattr(b, "IsConvergentBody", False)],
                    key=lambda b: nxh.volume(part, b))
        vm0 = nxh.volume(part, main0)
        m = nxh.mark("del scan")
        nxh.S.UpdateManager.AddObjectsToDeleteList(conv)
        try:
            nxh.S.UpdateManager.DoUpdate(m)
        except NXOpen.NXException as e:
            # Rev C: construction features made on the scan (Fit Surface + its points / curves / Delete Body) fail
            # without it. Delete the scan with failures accepted, then delete every feature that failed because
            # of it; the solid must keep its volume exactly.
            log(f"scan delete refused ({e}); retry with the scan-based construction features")
            # points placed on a Fit Surface of the scan (the user's Rev C pins) -> fixed points at the same place,
            # so the geometry built from them survives the scan
            conv_tags = {c.Tag for c in conv}
            fits = [f for f in part.Features.GetFeatures() if any(p.Tag in conv_tags for p in f.GetParents())]
            for fit in fits:
                for ch in fit.GetChildren():
                    if ch.FeatureType != "POINT":
                        continue
                    pt = [x for x in ch.GetEntities() if isinstance(x, NXOpen.Point)][0]
                    c0 = pt.Coordinates
                    pb = part.BaseFeatures.CreatePointFeatureBuilder(ch)
                    try:
                        pb.Point = part.Points.CreatePoint(NXOpen.Point3d(c0.X, c0.Y, c0.Z))
                        pb.Commit()
                    finally:
                        pb.Destroy()
                    res.setdefault("points_fixed", []).append([ch.GetFeatureName(), round(c0.X, 4), round(c0.Y, 4), round(c0.Z, 4)])
            nxh.update("fix points")
            res["main_volume_after_point_fix"] = nxh.volume(part, main0)
            log(f"points fixed: {res.get('points_fixed')}")
            m = nxh.mark("del scan 2")
            nxh.S.UpdateManager.SetDefaultUpdateFailureAction(NXOpen.Update.FailureOption.AcceptAll)
            nxh.S.UpdateManager.AddObjectsToDeleteList(conv)
            nxh.S.UpdateManager.DoUpdate(m)
            for _ in range(3):
                bad = [f for f in part.Features.GetFeatures() if list(f.GetFeatureErrorMessages() or [])]
                if not bad:
                    break
                res.setdefault("deleted_scan_construction", []).extend(f.GetFeatureName() for f in bad)
                m = nxh.mark("del scan construction")
                nxh.S.UpdateManager.AddObjectsToDeleteList(bad)
                nxh.S.UpdateManager.DoUpdate(m)
            log(f"deleted scan construction features: {res.get('deleted_scan_construction')}")
        v1 = [nxh.volume(part, b) for b in part.Bodies if b.IsSolidBody]
        log(f"deleted {len(conv)} scan features; solid volumes {v0} -> {v1}")
        res["errors_after_scan_delete"] = {k: [str(x) for x in v] for k, v in nxh.feature_errors(part).items()}
        assert not res["errors_after_scan_delete"], res["errors_after_scan_delete"]
        vm1 = nxh.volume(part, main0)
        res["main_volume_before_after_scan_delete"] = [vm0, vm1]
        assert abs(vm1 - vm0) < 1e-6 * vm0, (vm0, vm1)
        res["features_after"] = len(list(part.Features))
    vis = sorted([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked], key=lambda b: -nxh.volume(part, b))
    body = vis[0]
    others = [b for b in part.Bodies if b.IsSolidBody and b.Tag != body.Tag]
    if others:
        vols = [round(nxh.volume(part, b)) for b in others]
        nxf.delete_body(part, others)
        log(f"deleted {len(others)} helper solids {vols}")
    # helper geometry (section splines, sheets, groove paths) -> layer 200
    n = 0
    for b in part.Bodies:
        if not b.IsSolidBody:
            b.Layer = 200; n += 1
    for c in part.Curves:
        c.Layer = 200; n += 1
    for dp in part.Datums:
        try:
            dp.Layer = 200; n += 1
        except Exception:  # noqa: BLE001
            pass
    body.Layer = 1
    log(f"{n} helper objects moved to layer 200")
    try:
        lsc = part.Layers.GetStates()
        lsc.SetState(200, NXOpen.Layer.State.Hidden)
        part.Layers.SetStates(lsc, True)
    except Exception as e:  # noqa: BLE001
        log(f"layer state: {e}")
    rs = next((r for r in part.GetAllReferenceSets() if r.Name == "SOLID"), None)
    if rs is None:
        rs = part.CreateReferenceSet()
        rs.SetName("SOLID")
    try:
        rs.AddObjectsToReferenceSet([body])
    except Exception as e:  # noqa: BLE001
        log(f"refset: {e}")
    body.SetName("LEFT_THIGH_OUTER")
    v = nxh.volume(part, body)
    res["volume_mm3"] = v
    res["mass_g_al6061"] = v * 2.70e-3
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    for k, val in (("MATERIAL", "Aluminium 6061-T6"), ("DRAWING_NO", "LT-OUT-001"), ("REVISION", REV),
                   ("DESCRIPTION", "Left thigh - outer shell, reverse engineered from scan")):
        try:
            part.SetUserAttribute(k, -1, val, NXOpen.Update.Option.Now)
        except Exception as e:  # noqa: BLE001
            log(f"attribute {k}: {e}")
    nxh.save(part)
    # exports
    st214 = os.path.join(DST, NAME + "_AP214.step")
    st242 = os.path.join(DST, NAME + "_AP242.step")
    nxf.step_export(part, st214, ap242=False, save=True)
    nxf.step_export(part, st242, ap242=True, save=False)
    res["step_sizes"] = [os.path.getsize(st214), os.path.getsize(st242)]
    xt = os.path.join(DST, NAME + ".x_t")
    if os.path.exists(xt):
        os.remove(xt)
    try:
        nxh.UFS.Ps.ExportData([body.Tag], xt)
        res["x_t_size"] = os.path.getsize(xt)
    except Exception as e:  # noqa: BLE001
        res["x_t_error"] = str(e)
    stl = os.path.join(DST, NAME + ".stl")
    nxre.stl_export(part, body, stl, chord=0.005, max_edge=1.5)
    res["stl_size"] = os.path.getsize(stl)
    try:
        rt = nxf.step_roundtrip_check(st214, os.path.join(DST, "_rt"), name="rt214", restore=part, part=part, bodies=[body])
        res["roundtrip_214"] = rt
    except Exception as e:  # noqa: BLE001
        res["roundtrip_214_error"] = traceback.format_exc()[-600:]
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(DST, "_finalize.json"), res)
