"""One-off: flap outline numbers after the look at the seated flaps (f9), exact end check."""
import os
WS = os.path.dirname(os.path.abspath(__file__))
path = os.path.join(WS, "build2.py")
s = open(path, encoding="utf-8").read()


def sub(a, b):
    global s
    if s.count(a) != 1:
        raise SystemExit("expected 1 x %r, found %d" % (a[:70], s.count(a)))
    s = s.replace(a, b)


sub('''    e("flap_z0", 6.8, "flap: lower end (just above the drive blades)")
    e("flap_end_gap", 1.75, "flap: upper end stays this far below the idler end face")
    e("flap_taper_len", 21.7, "flap: axial length of the end taper")
    e("flap_foot_r0", 14.5, "flap outline: radius at the lower end (plain part, no bead)")
    e("flap_foot_r1", 15.35, "flap outline: radius where the step to the full height starts")
    e("flap_step_z0", 12.8, "flap outline: the step starts at this height")
    e("flap_step_z1", 14.4, "flap outline: the step ends, full height reached")
''', '''    e("flap_seat_gap", 0.1, "flap: gap between its lower end and the tops of the drive blades it rests on (scan: seated flaps start at z 6.5)")
    nxh.expr(p, "flap_z0", "z_core0+flap_seat_gap", "mm", "flap: height of the lower end")
    M["flap_z0"] = M["z_core0"] + M["flap_seat_gap"]
    e("flap_end_gap", 1.95, "flap: upper end stays this far below the idler end face")
    e("flap_taper_len", 21.8, "flap: axial length of the end taper")
    e("flap_foot_r0", 14.8, "flap outline: radius at the lower end (plain part, no bead)")
    e("flap_foot_r1", 15.4, "flap outline: radius where the step to the full height starts")
    e("flap_step_z0", 12.6, "flap outline: the step starts at this height")
    e("flap_step_z1", 14.3, "flap outline: the step ends, full height reached")
''')
sub('''    bb = nxh.bbox(flap)
    c.chk("flap runs from flap_z0 to h_total - flap_end_gap (z min)", bb[2], M["flap_z0"], 0.05)
    c.chk("flap runs from flap_z0 to h_total - flap_end_gap (z max)", bb[5], z1, 0.05)
''', '''    zc = flap_end_planes(flap)
    c.chk("flap: lower end face at flap_z0", zc[0], M["flap_z0"], 1e-4)
    c.chk("flap: upper end face at h_total - flap_end_gap", zc[1], z1, 1e-4)
''')
sub('''def interp(line, z):''', '''def flap_end_planes(body):
    """z of the lowest and the highest planar end face (normal along Z) - the bounding box of a twisted body is padded"""
    zs = [nxh.face_data(f)[1][2] for f in body.GetFaces() if nxh.face_data(f)[0] == PLANE and abs(abs(nxh.face_data(f)[2][2]) - 1.0) < 1e-6]
    return (min(zs), max(zs)) if zs else (None, None)


def interp(line, z):''')
sub('''    run("h_total", 160, lambda: both(near(nxh.bbox(c.core)[5], 160.0, 0.2), near(max(nxh.bbox(b)[5] for b in c.flaps), 160.0 - M["flap_end_gap"], 0.1)))''',
    '''    run("h_total", 160, lambda: both(near(nxh.bbox(c.core)[5], 160.0, 0.2), near(max(flap_end_planes(b)[1] for b in c.flaps), 160.0 - M["flap_end_gap"], 1e-4)))''')
open(path, "w", encoding="utf-8", newline="\n").write(s)
print("patched")
