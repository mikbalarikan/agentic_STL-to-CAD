# Dreame ana fırça (kıllı) — çekirdek + 4 silikon kanat + ince kıllar, NX 2206 (2026-10-10)

8 Ekim teslimi (yalnız çekirdek + 54 "çubuk" demet) Ilia'dan döndü: *"has both bristles and flaps … many fine bristles
instead of sticks"*. Bu sürümde aynı çekirdeğe **4 silikon kanat** ve **ince filamentlerden oluşan kıl demetleri** eklendi.
Kanatlar, montajlı kıllı fırçanın kendi taramasından (`dreame_brush_with_bristles.stl`) ölçüldü.

![önce / şimdi / tarama](figures/v2_01_once_simdi_tarama.png)

## Önce okunması gerekenler

1. **"Kılsız fırçayla aynı" yapı olarak doğru, ölçü olarak değil.** İki fırça da "çekirdek + T-kanallara geçen silikon
   kanatlar" kurgusunda; ama kılsız fırçada **5 kanat**, kıllı fırçada **4 kanat + 2 kıl sırası** var (kanıt:
   `figures/v2_08_iki_firca_kesit_4_kanat_ve_5_kanat.png`), çekirdekleri de farklı (1. tur raporu). Model kıllı fırçanın
   kendi taramalarına göre kuruldu; kılsız fırçanın CAD'i (`brush_no_bristles … .prt`, 5 kanat) geometri olarak
   kullanılmadı, yalnız kurgu örneği oldu (ayrı kanat gövdeleri).
2. **Kanatlar ve kıllar yumuşak parçalar; tarama bandına (p95 ≤ 0,30 / max ≤ 0,80 mm) dahil değil.** Taramada kanat uçları
   yana −1 … +2,4 mm esnemiş, kanatlar kanalda ±1 mm kaymış. Model nominal durumu verir: kanat radyal ve düz. Sert
   yüzeylerde (çekirdek) tarama→CAD p95 = 0,16 mm; `max ≤ 0,8` çekirdekte 1. turdaki gibi **karşılanmıyor**.
3. **Varsayımlar:** kanadın T-kanal içindeki ayağı (görünmüyor), filament sayısı ve çapı (61 × Ø0,15; tarama tek tek
   kılları çözmüyor), kıl deliği derinliği (3,0). Kumpas ölçüsü yok; ölçek yalnız taramadan.
4. **Boncuk omzundaki küçük pah modelde yok.** Taramada boncuk gövdeye ≈ 0,25 × 0,45 mm'lik bir rampayla bağlanıyor;
   modelde bu geçiş 0,25 mm'lik basamak. Pah üç koşuda denendi, kararlı kurulamadığı için bırakıldı ("Doğrulama").
5. **Journal son koşuda tek kontrolde kaldı** (o pah). Teslim edilen parça o koşunun çıktısıdır; pah adımı sonradan
   journal'dan çıkarıldı ve kullanılmayan iki ifadesi parçadan silindi (geometri değişmedi, ölçüldü).

## Teslim edilenler

| Dosya | İçerik |
|---|---|
| `dreame_brush_with_bristles.prt` | NX 2206 parametrik parça: `CORE` (1) + `SILICONE_FLAP` (4) + `BRISTLE_TUFT` (54) = 59 katı; gövdeler renkli (çekirdek koyu gri, kanat gri, kıl siyah) |
| `dreame_brush_with_bristles.step` | AP242, 59 katı, 9,1 MB |
| `dreame_brush_with_bristles_with_scans.prt` | Aynı parça + taramalar CAD datum çerçevesinde: katman 12 montajlı fırça (görünür), katman 10 çekirdek, katman 11 taban (gizli). 42 MB. Montajlı tarama kapalı bir facet gövdesi olduğu için NX bu dosyada 60 "katı" sayar |
| `dreame_brush_with_bristles_core.stl`, `_flaps.stl` | Sapma ölçümünde kullanılan CAD mozaikleri (kıl mozaiği 57 MB olduğu için konmadı) |
| `figures/v2_*.png` | Render'lar (model / tarama aynı kameradan), ölçüm grafikleri, kesit bindirmeleri |
| `journal/build2.py`, `run2.ps1`, `review2.py`, `asfound2.py`, `fixup_expr.py`, `test_pure.py` | Parçayı baştan kuran journal, taramalı inceleme parçası, geri okuma, ifade temizliği, NX'siz matematik testi |
| `analysis/f*.py`, `r*.py`, `s*.py`, `common2.py` | Montajlı taramanın hizalanması, kanat / kıl ölçümleri, sapma, STEP kontrolü |
| `qa/build2_checks.json`, `build2_stage_e_cleaned_journal.json`, `masters_v2.json`, `T_asm.json`, `f*.json`, `s*.json`, `asfound2.json`, `fixup_expr.json`, `review2.json` | Kontroller (teslim edilen koşu + temizlenmiş journal'ın kanat aşaması), ifadeler, hizalama matrisi, ölçüm ve sapma sayıları |
| `_onceki_surum_2026-10-08_cekirdek_cubuk_kil/` | 8 Ekim dosyaları (prt, step, stl, with_scans, eski rapor) **taşındı**, silinmedi |

1. turun `figures/01…15`, `journal/build.py`, `analysis/`, `qa/` dosyaları yerinde: çekirdek değişmedi, o kanıtlar geçerli.

## Çekirdek

Değişmedi: `build2.py`'nin a–d aşamaları `build.py` ile aynı kod (taban, kanatçıklar, 4 T-kanal, oluklar, rulman ucu,
54 kıl deliği). Hacim 26 991,42 mm³ (8 Ekim ile aynı), 41/41 kontrol. Ayrıntı: `_onceki_surum…/REPORT_v1_2026-10-08.md`.

## Montajlı taramanın hizalanması

`dreame_brush_with_bristles.stl` (6,5 M üçgen) çekirdek CAD'ine noktadan-düzleme ICP ile oturtuldu (36 başlangıç açısı;
yalnız eksene yakın noktalar ve tahrik ucu). Sonuç `qa/T_asm.json`: çekirdek yüzeyine 0,3 mm'den yakın pay %82, bu payda
rms 0,074 mm; bölge bölge p50 0,03–0,10, p95 0,16–0,38 mm (en büyüğü flanş yan yüzünde). Çekirdek 2 katlı simetrik olduğu için
180° belirsizliği var; kanatlar ve kıl sıraları da 2 katlı olduğundan sonucu değiştirmez.

## Silikon kanatlar

**Kurgu.** Her T-kanalda bir kanat; ayrı katı gövde, çekirdeğe değmiyor (en küçük boşluk 0,050 mm, ayak ile kanal yanağı
arasında). Kanat çekirdekle aynı burulmayı izler (aynı `twist_lead`, aynı kılavuz eskiz).

| Ölçü | Taramada ölçülen (4 kanat) | Modelde |
|---|---|---|
| Sayı / açı | 4; T-kanallarda | `n_slot` 4, `slot_ang0` 1,1° (çekirdekle ortak) |
| Gövde kalınlığı | 0,91–0,95 (medyan 0,94) | `flap_t` 0,94 |
| Uç boncuğu kalınlığı | 1,43–1,45 (en az esnemiş bantta) | `bead_t` 1,44 |
| Boncuk boyu | geçiş r 14,75'te başlıyor (rampa ≈ 0,45 boyunda), uç 16,5 | `bead_len` 1,5; omuz **basamak** (rampa modellenmedi) |
| Boncuk uç köşesi | uçtan 0,1 / 0,2 / 0,3 / 0,4 mm'de genişlik 0,94 / 1,17 / 1,29 / 1,37 → R ≈ 0,6 | `bead_tip_R` 0,6 (modelde 0,88 / 1,12 / 1,27 / 1,36) |
| Uç yarıçapı, uzun kenar | 17,15 (z 15–20) → 16,25 (z 140), doğrusala yakın | `flap_r_a` 17,1 (z 14,3) → `flap_r_b` 16,25 (z 146,0) |
| Uç pahı (rulman ucu) | eğim −0,3285 mm/mm (doğru fit kalıntısı 0,02), köşe R ≈ 25 | `flap_taper_len` 21,8, `flap_r_end` 9,1, `flap_end_R` 25; boncuk pah boyunca sürer |
| Alt uç | oturmuş kanatlarda z 6,5 (tahrik kanatçıklarının üstü); iki kanat 0,5–2 mm yukarı kaymış | `flap_seat_gap` 0,1 → z 6,6 |
| Alt düz kısım (boncuksuz) | r 14,8 (z 6,5) → 15,4 (z 12,3) | `flap_foot_r0` 14,8, `flap_foot_r1` 15,4 |
| Basamak (boncuğun başladığı yer) | alt uçtan 6,0 → 7,7 mm yukarıda | `flap_step_z0` 12,6, `flap_step_z1` 14,3, `flap_step_R` 1,0 |
| Üst uç | z 166,6 … 169,1 (kanat boyu ≈ 161,2 ± 0,6) | `flap_end_gap` 1,95 → z 167,8 |
| Kanal içindeki ayak | **görünmüyor** | kırlangıç ayak: `flap_foot_w` 2,0, `flap_foot_gap` 0,1 — **varsayım** |
| Yana esneme | uçta −1 … +2,4 mm, kanada ve yüksekliğe göre değişiyor | modellenmedi (kanat radyal, düz) |

Ölçüm grafikleri: `figures/v2_09 … v2_17`. Model kesiti taramanın üstünde: `figures/v2_17_kanat_kesiti_model_tarama.png`.

**Feature'lar (bir kanat, sonra desen).**

| Adım | Feature | Not |
|---|---|---|
| 1 | `SK_FLAP` → `FLAP_BLANK` (Swept, açısal yasa) | Gövde + kırlangıç ayak kesiti `DP_CORE0` üstünde; T-kanal takımıyla aynı kurulum |
| 2 | `SK_FLAP_WEB_OUTLINE` → `FLAP_WEB_ENVELOPE` (Revolve) → `FLAP_WEB` (Intersect) | Kanadın (r, z) dış hattı XZ eskizinde; burulmuş ham gövde bu zarfa kesilir |
| 3 | `SK_BEAD` → `BEAD_BLANK` (Swept) | 1,44 kalınlığında ikinci ham gövde |
| 4 | `SK_BEAD_OUTLINE` → `BEAD_ENVELOPE` (Revolve) → `BEAD_ENVELOPE_ROUNDS` (Edge Blend R25 / R1) → `FLAP_BEAD` (Intersect) | Serbest kenar boyunca `bead_len` genişliğinde bant |
| 5 | `BEAD_TIP_ROUND` (Edge Blend, 10 helis kenar) | Boncuğun iki dış köşesi, `bead_tip_R` |
| 6 | `FLAP` (Unite) → `DP_FLAP_END` → `FLAP_END` (Trim Body) | Üst uç düzlemi `h_total − flap_end_gap` |
| 7 | `FLAPS` (Pattern Geometry, dairesel, `n_slot`) | 4 gövde, `SILICONE_FLAP` |

4 eskiz de tam kısıtlı (DOF 0, otomatik ölçü 0). Bir kanat 37 yüz, 1 862,53 mm³.

## Kıllar: ince filamentler

- **Demet = kök tıkacı + 61 filament.** Tıkaç deliği doldurur ve lamadan 1,0 mm çıkar (`tuft_root_h`); filamentler
  Ø0,15 (`d_fil`), tıkaçta altıgen dizilimde (adım 0,2 mm), her biri ayrı bir silindir feature'ı, tıkaçla birleşik:
  demet tek katı. 54 demet × 61 = **3 294 filament**.
- **Doğal görünüm için:** yelpaze (kökteki konuma göre sıra boyunca ±15°, enine ±6°) + her filamente rastgele yön
  (σ 2,5° / 1,5°) + uç yarıçapında saçılma (18,5 −0,55 / +0,2 mm; modelde uçlar r 17,95 … 18,70). Tek demet tekrar
  etmesin diye **3 farklı demet** (A, B, C; ayrı rastgele tohum) sıra boyunca dönüşümlü dizildi.
- **Ölçüden gelenler:** sıra / demet sayısı, adım, açı, eksenel yatma 40° ve uç çapı 1. turdaki ifadelerle aynı
  (`n_tuft`, `tuft_pitch`, `tuft_z0`, `tuft_ang0`, `tuft_lean`, `d_brush`). Montajlı taramada uç yarıçapı p98 = 18,4 / 18,6
  (çekirdek taramasında 18,3 / 18,6) → `d_brush` 37,0 kaldı. Teğetsel yatma artık modelde: −7° (çekirdek taramasında
  −7 … −10°, montajlıda −5 … −8°).
- **Varsayım:** filament çapı ve sayısı (gerçek kıl ≈ Ø0,1–0,15 ve daha sık olabilir), yelpazenin enine açısı.
- **Filamentler birbirini kesmez:** üretici, her çifti kök dışında en az 0,02 mm aralıklı tutar (yalın yelpaze zaten
  ayrışır; rastgele yön yalnız aralık korunuyorsa kabul edilir). Komşu **demetlerin** uçları ise birbirinin içinden
  geçer (gerçekte de kıllar iç içe); demetler arası girişim kontrolü bu yüzden yapılmadı.
- **İfadeyle sürülen:** `d_fil`, `tuft_root_h`, `d_tuft_hole` (kök konumları onunla ölçeklenir), `d_brush` ve `tuft_lean`
  (boylar `fil_len` üzerinden), `n_tuft`, `tuft_pitch`, `tuft_z0`, `tuft_ang0`, `twist_lead`. **Sabit sayı olan:** her
  filamentin yönü ve boy çarpanı (journal'daki `FAN_U`, `FAN_V`, `JIT_*`, `LEAN_T`, `VARIANTS` ile üretilir; değiştirmek
  için journal yeniden koşulur). `n_tuft` her değeri alır (desen sayıları `ceiling((n_tuft−k)/3)`).

| Adım (her demet türü için) | Feature |
|---|---|
| 1 | `TUFT_x_ROOT` (Cylinder) + `TUFT_x_FILAMENT_01…61` (Cylinder, Unite) — orijinde, demet ekseni +X; feature grubu `TUFT_x` |
| 2 | `TUFT_x_LEAN` (Move Object, Y çevresinde −`tuft_lean`) → `TUFT_x_PLACE` (Move Object, `d_core/2`, `tuft_z0 + k·tuft_pitch`) → `TUFT_x_CLOCK` (Move Object, Z çevresinde) |
| 3 | `TUFT_x_ROW_2` (Pattern Geometry, 2) → `TUFTS_x_ROW_1/2` (Pattern Geometry [Helix], her 3. konum) |

## Doğrulama (kurucu tarafından yapıldı — bağımsız QA değildir)

| Kontrol | Sonuç |
|---|---|
| Journal kontrolleri | 107 kontrolün 106'sı geçti. Geçmeyen tek kontrol boncuk omzundaki pah: kuruldu, kendi ölçüm kontrolünden geçemedi, geri alındı (aşağıda). Bu adım journal'dan çıkarıldıktan sonra kanat aşaması ayrıca yeniden koşuldu: 21 / 21 kontrol, bir kanat 1 862,53 mm³ (teslim edilen parçayla aynı) |
| Eskizler | 16 / 16 DOF 0, otomatik ölçü 0 |
| Kanat: ham gövde hacmi = kesit × boy · zarfla kesilmiş hacim = sayısal integral | 2 196,05 / 2 196,01 · gövde 1 666,403 / 1 666,397 · boncuk 338,065 / 338,048 mm³ |
| Kanat: gövde duvarı helis üstünde (z 30 / 90 / 150), uç yüzü dış hat üstünde (z 40 / 120) | 0,001 / 0,002 / 0,000 mm · 0,000 / 0,000 mm |
| Kanat–çekirdek en küçük boşluk (4 kanat) | 0,050 mm |
| Demet: hacim = tıkaç + 61 silindir (A / B / C) | 27,095 / 27,166 / 27,163 mm³, beklenenle fark < 1·10⁻⁶ |
| Demet yerleşimi: tıkaç dibi delik dibinde, orta filamentin ucu hesaplanan noktada | 3 / 3 demet türü, 0,000 mm |
| Kıl demetleri–kanatlar en küçük boşluk | çekirdeğin dışında kökte ≥ 2,5 mm, uçlarda ≥ 7,8 mm (mozaikten); gövdeler arası mutlak en küçük mesafe 0,87 mm ve çekirdeğin içinde: demet tıkacının dibi ile kanat ayağı arası (54 demetin hepsi, NX ölçümü) |
| Examine Geometry (çekirdek + 4 kanat + 54 demet) | Tüm sayaçlar 0 |
| Regenerasyon: 11 ana ifade tek tek değiştirildi → güncelle → kontrol → geri al | 11 / 11 hatasız; her seferinde çekirdek, kanat ve kıl hacimleri nominale döndü (bağıl 10⁻⁶ içinde) |
| STEP AP242 → NX'e geri okuma | 59 katı, Examine Geometry bulgusu 0; en büyük bağıl hacim farkı 3,0·10⁻⁵ (çekirdek 3,0·10⁻⁵, kanatlar 2,5·10⁻⁵, kıllar 4·10⁻¹²) |
| STEP'in OpenCascade ile bağımsız okunması | 59 katı, hepsi geçerli; hacim farkı çekirdek −4,6·10⁻⁵, kanatlar −1,6·10⁻⁵, kıllar −7·10⁻⁹; kanat gövde kalınlığı 15 noktada 0,9398–0,9404 (tasarım 0,94); kanat yüzeyi NX mozaiğine ≤ 0,005 mm (mozaiğin kendi kiriş toleransı) |
| Teslim edilen `.prt` kopyasının yeniden açılıp okunması (as-found) | 278 üst düzey feature (423 satır), bastırılmış 0, hatalı 0; 59 katı: CORE 1 (26991,42 mm³), SILICONE_FLAP 4 (7450,13), BRISTLE_TUFT 54 (1465,63); 16 eskiz, tam kısıtlı olmayan 0; 97 adlandırılmış ifade; 3 feature grubu (TUFT_A/B/C); kanat–çekirdek en küçük boşluk 0,050 mm |

Regenerasyonda değiştirilenler: `twist_lead` 250 (kanal duvarı ve kanat gövdesi yeni helisin üstünde: 0,002 / 0,003 mm; kanat–çekirdek boşluğu 0,054) · `slot_w` 1,5 · `h_total` 160 (kanat üst ucu 158,05 = beklenen) · `flap_t` 1,1 (bir kanatta ΔV 234,66; beklenen 234,54) · `bead_t` 1,8 (ΔV 84,69; beklenen 84,07) · `flap_r_a` 18 (uç yüzü yeni dış hattın üstünde) · `n_tuft` 20 (45 katı; 14 delik kapandı) · `tuft_pitch` 5,5 · `tuft_lean` 30 (tıkaç dibi yeni delik dibinde) · `d_brush` 40 (kıl hacmi × 1,074; beklenen 1,073) · `d_fil` 0,14 (demet başına filament hacmi 12,696 = beklenen). Kanat dış hattının diğer ifadeleri (`flap_step_*`, `flap_taper_len`, `flap_r_b`, `flap_r_end`, `bead_len`, `bead_tip_R`), `n_slot` ve `d_tuft_hole` **denenmedi**.

**Koşu geçmişi ve boncuk omzundaki pah.** Kanat aşaması üç kez koşuldu: bir deneme, iki tam koşu (a–z). İki tam koşu
arasındaki fark omuz pahı ve kontrollerdir; çekirdek ve kıl hacimleri ikisinde aynı çıktı (10⁻⁹ içinde).

| Koşu | Omuz pahı (iki ölçülü Chamfer, 10 helis kenar) | Sonuç |
|---|---|---|
| Deneme (yalnız kanat aşaması) | kuruldu; bir yanda neredeyse yok, öbür yanda 0,12 × 0,40 (kesitten ölçüldü), çıkan hacim 8,9 mm³ | kontrol eşiği gevşekti, geçti sayıldı |
| 1. tam koşu | kuruldu; ana kenarlarda iki yanda 0,22 × 0,45, basamaktaki kısa kenarda farklı; 19,7 mm³ | 106 kontrolün 2'si kaldı: (a) `flap_t` regenerasyon beklentisini yanlış yazmışım (model hatasız güncellendi), (b) STEP NX'e geri okununca kanat hacmi %0,67 düşük |
| 2. tam koşu (teslim edilen) | kuruldu; 12,6 mm³, ölçüm kontrolünden geçemedi → **geri alındı** | 107 kontrolün 1'i kaldı (pah); STEP geri okuması tüm gövdelerde 3·10⁻⁵ içinde |

NX, iki ölçülü pahta hangi ölçünün hangi yüze gideceğini kenardan kenara ve oturumdan oturuma farklı seçti; pah adımı
üç koşuda üç farklı sonuç verdi (deneme koşusunda kanat dış hattının sayıları sonrakilerden biraz farklıydı). Pahlı sürümün STEP'inde de geri okuma farkı çıktı (pahsız sürümde yok; farkın pah
yüzeylerinden geldiğini bu karşılaştırmadan çıkarıyorum, ayrıca kanıtlamadım). Bu yüzden pah modelden çıkarıldı.
1. koşudaki (a) hatası kontrolün kendisindeydi ve düzeltildi; (b) için kanatlara ayrı bir STEP ölçütü yazdım (hacim
farkının yüzey kayması karşılığı ≤ 0,01 mm) — pahsız sürümde gerek kalmadı, kanatlar eski 1·10⁻⁴ eşiğini de geçiyor.

Teslim edilen `.prt` 2. tam koşunun çıktısıdır. Sonradan yapılan iki şey: (1) `fixup_expr.py` kullanılmayan `bead_step`
ve `bead_ramp` ifadelerini parçadan sildi (59 katı, toplam hacim önce / sonra 35 907,1829 mm³, hata yok); STEP bu
adımdan önce aynı geometriden yazıldı. (2) Pah adımı `build2.py`'den çıkarıldı; kanat aşaması bu haliyle yeniden
koşuldu (tablodaki sonuç). Temizlenmiş journal'ın **tamamı** (regenerasyon + STEP dahil) yeniden koşulmadı.

Doğrulanmayanlar: parça NX arayüzünde açılıp gözle incelenmedi (yalnız headless + mozaik render'ları); kumpas yok.

## Sapma (montajlı tarama, tam çözünürlüğün her 2. üçgeni, 1,39 M örnek; her nokta en yakın olduğu parçaya yazıldı)

| Tarama → model | pay | p50 | p90 | p95 | p99 | max |
|---|---|---|---|---|---|---|
| Çekirdek (sert) | %31 | 0,033 | 0,105 | **0,165** | 1,14 | 5,63 |
| Kanatlar, tümü (yumuşak) | %45 | 0,200 | 0,664 | 0,967 | 1,54 | 2,27 |
| — kök r 7,4–10 | | 0,134 | 0,322 | 0,417 | 0,62 | 1,62 |
| — r 10–13 | | 0,213 | 0,500 | 0,806 | 1,31 | 1,96 |
| — r 13–15 | | 0,272 | 0,865 | 1,136 | 1,80 | 2,27 |
| — uç r 15–18,5 | | 0,300 | 1,054 | 1,322 | 1,72 | 2,26 |
| Kıllar (yumuşak) | %24 | 0,190 | 0,521 | 0,661 | 1,11 | 3,81 |

Çekirdek satırındaki p99 / max büyük: çekirdeğe "en yakın" sayılan noktaların bir kısmı kanat kökü, kıl kökü ve tabla
kalıntısı (bu ölçümde 1. turdaki bölge maskeleri kullanılmadı). Çekirdeğin kendi sapma tablosu 1. tur raporunda.
Kanat sapması kökten uca büyüyor: bu, taramadaki esnemenin (uçta ölçülen −1 … +2,4 mm) görüntüsü; kanat **biçimi**
(kalınlık, boncuk, dış hat) yukarıdaki ölçü tablosuyla ve kesit bindirmeleriyle (`figures/v2_17`, `v2_18`, `v2_19`)
karşılaştırılmalı.

Model → tarama (modelin taramada görülen payı): kanat yüzeyinin %51'i 0,3 mm, %78'i 1 mm içinde tarama görüyor
(kanal içindeki ayak hiç görünmüyor); kıl yüzeyinin %30'u 0,3 mm, %80'i 1 mm içinde.

## Bilinen sapmalar, varsayımlar ve sadeleştirmeler

1. Kanat ayağı (T-kanal içi) varsayım; boşluklar 0,05–0,155 mm seçildi.
2. Kanat nominal: yana esneme, kanal boyunca kayma ve dış kısmın eksenel kayması (taramada bir kanadın alt dış köşesi
   z ≈ 5,3'e kadar iniyor görünüyor; `figures/v2_16`) modellenmedi; dört kanat özdeş.
3. Uç yarıçapı z boyunca doğrusal alındı; ölçülen profil z ≈ 100'de 0,13 mm daha küçük.
4. Boncuk omzu basamak (yan başına 0,25 mm); ölçülen ≈ 0,25 × 0,45'lik rampa modellenmedi (neden: "Doğrulama").
5. Boncuk başlangıcı düz bir yüzle başlıyor (z 12,35); taramada yumuşak geçiş.
6. Filamentler düz silindir (eğrilik yok), uçları düz kesik; çap / sayı varsayım; komşu demetlerin uçları iç içe.
7. Çekirdeğe ait 1. tur maddeleri (altıgen yuva, delik derinliği, modellenmeyen yerel girinti vb.) aynen geçerli. Varsayılan
   delik derinliğiyle (3,0) kıl deliğinin dibi ile T-kanal ayağı arasında ≈ 0,8 mm çekirdek duvarı kalıyor.
8. Kanat ve kıl gövdelerine malzeme atanmadı; yalnız renk.

## Yeniden kurma

```
powershell -File journal\run2.ps1 -Stages abcdefz      (yollar C:\NX_MCP_WORKSPACE\dreame_brush'a göredir; ≈ a–f 4,5 dk; z (regenerasyon + STEP) 18 dk, bilgisayar başka işle yüklüyken 40 dk)
```
Aşamalar: `a b c d` çekirdek + kıl delikleri · `e` kanatlar · `f` kıllar · `z` kontroller, regenerasyon, renk, STEP.
`a` verilmezse journal `out2\dreame_brush_with_bristles_stage_d.prt` kopyası üzerinde devam eder (ör. `-Stages ef`).
