"""One-off: replace make_filaments and the filament constants in build2.py."""
import os
WS = os.path.dirname(os.path.abspath(__file__))
path = os.path.join(WS, "build2.py")
s = open(path, encoding="utf-8").read()
a = s.index("N_RING = 4 ")
b = s.index("def seg_dist(p1, q1, p2, q2):")
s = s[:a] + '''N_RING = 4                          # hexagonal packing with 4 rings = 61 filaments per tuft
FIL_PITCH = 0.2                     # filament spacing in the root as a share of the hole radius (0.2 mm in a d 2 hole)
FAN_U, FAN_V = 15.0, 6.0            # half fan angle of the outermost filaments along the row / across it, deg
JIT_U, JIT_V = 2.5, 1.5             # random part of each filament direction (sigma), deg
MAX_U = 17.0                        # limit of the angle along the row (fan + random), deg
LEAN_T = -7.0                       # common sideways lean of the tufts (clockwise seen from +Z), deg
TIP_JIT = (-0.55, 0.2)              # scatter of the tip radius about d_brush / 2, mm
SINK = 0.25                         # filaments start this far inside the root plug
FIL_GAP = 0.02                      # smallest gap kept between two filaments of a tuft outside the root, mm
VARIANTS = (("A", 11), ("B", 23), ("C", 37))      # three different tufts take turns along a row (name, random seed)


''' + s[b:]
a = s.index("def make_filaments(M, seed):")
b = s.index("def stage_f(c):")
s = s[:a] + '''def make_filaments(M, seed):
    """61 straight filaments of one tuft in the canonical frame: start point, unit direction, length.
    Start: the plain fan (direction angle proportional to the position in the root) - its filaments move apart all
    the way, so they cannot touch. Then every filament gets a random change of direction and of tip radius, kept only
    when it still clears all the others by FIL_GAP outside the root; so no two filaments of a tuft ever cut each other
    and the root plug is the only thing each one is united with. Lengths put every tip near the brush diameter."""
    import random
    rng = random.Random(seed)
    rh = M["d_tuft_hole"] / 2
    pitch = FIL_PITCH * rh
    ph = rng.uniform(0.0, 60.0)
    pts = [(0.0, 0.0)]
    for k in range(1, N_RING + 1):
        for s in range(6):
            a0, a1 = math.radians(60.0 * s + ph), math.radians(60.0 * (s + 2) + ph)
            for j in range(k):
                pts.append((k * pitch * math.cos(a0) + j * pitch * math.cos(a1), k * pitch * math.sin(a0) + j * pitch * math.sin(a1)))
    rmax = N_RING * pitch
    x0 = M["tuft_root_h"] - SINK
    Ln = math.radians(M["tuft_lean"])
    Rc, rt = M["d_core"] / 2, M["d_brush"] / 2
    clear = M["d_fil"] + FIL_GAP

    def radius(q):
        return math.hypot(q[0] * math.cos(Ln) - q[2] * math.sin(Ln) + Rc, q[1])

    def make(i, au, av, target):
        u, v = pts[i]
        d = (1.0, math.tan(math.radians(av)), math.tan(math.radians(au)))
        n = math.sqrt(sum(t * t for t in d))
        d = tuple(t / n for t in d)
        st = (x0, v, u)
        lo, hi = 1.0, 60.0
        for _ in range(50):
            mid = (lo + hi) / 2
            if radius(tuple(st[j] + d[j] * mid for j in range(3))) < target:
                lo = mid
            else:
                hi = mid
        h = (lo + hi) / 2
        seg = (tuple(st[j] + d[j] * (SINK / d[0]) for j in range(3)), tuple(st[j] + d[j] * h for j in range(3)))
        return dict(i=i, start=st, dir=d, h=h, au=au, av=av, seg=seg, jittered=False)

    def free(cand, fils):
        return all(o["i"] == cand["i"] or seg_dist(cand["seg"][0], cand["seg"][1], o["seg"][0], o["seg"][1]) >= clear for o in fils)

    fils = [make(i, FAN_U * pts[i][0] / rmax, LEAN_T + FAN_V * pts[i][1] / rmax, rt) for i in range(len(pts))]
    worst = min(seg_dist(a["seg"][0], a["seg"][1], b["seg"][0], b["seg"][1]) for a in fils for b in fils if a["i"] < b["i"])
    if worst < clear:
        raise RuntimeError("plain fan too tight: smallest axis distance %.4f < %.4f" % (worst, clear))
    for sc in (1.0, 1.0, 1.0, 0.7, 0.7, 0.5, 0.5, 0.35):
        idx = [i for i in range(len(fils)) if not fils[i]["jittered"]]
        rng.shuffle(idx)
        for i in idx:
            u, v = pts[i]
            for attempt in range(25):
                au = max(-MAX_U, min(MAX_U, FAN_U * u / rmax + rng.gauss(0.0, JIT_U * sc)))
                av = LEAN_T + FAN_V * v / rmax + rng.gauss(0.0, JIT_V * sc)
                cand = make(i, au, av, rt + rng.uniform(*TIP_JIT))
                if free(cand, fils):
                    cand["jittered"] = True
                    fils[i] = cand
                    break
    return fils


''' + s[b:]
s = s.replace('    e("d_fil", 0.16, "bristle filament diameter")', '    e("d_fil", 0.15, "bristle filament diameter")')
s = s.replace('"random_sigma_deg": [JIT_U, JIT_V], "sideways_lean_deg": LEAN_T, "tip_radius_scatter": list(TIP_JIT), "variants": {}}',
              '"random_sigma_deg": [JIT_U, JIT_V], "sideways_lean_deg": LEAN_T, "tip_radius_scatter": list(TIP_JIT), "smallest_gap": FIL_GAP, "variants": {}}')
open(path, "w", encoding="utf-8", newline="\n").write(s)
print("patched")
