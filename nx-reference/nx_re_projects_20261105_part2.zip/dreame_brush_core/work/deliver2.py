"""Round 2 delivery into the existing project folder.
Superseded model files and the old report are MOVED into a dated subfolder (nothing is deleted); figures / qa /
analysis / journal get the new files added.   usage: deliver2.py [check]"""
import os, sys, json, shutil

WS = r"C:\NX_MCP_WORKSPACE\dreame_brush"
DST = r"C:\Users\marya\Downloads\Projects\CAD_Projects\dreame_brush_core_with_bristles_nx"
OLD = os.path.join(DST, "_onceki_surum_2026-10-08_cekirdek_cubuk_kil")
NAME, OLDNAME = "dreame_brush_with_bristles", "dreame_brush_core_with_bristles"
dry = "check" in sys.argv
if not os.path.isdir(DST):
    raise SystemExit("project folder not found: " + DST)


def cp(src, dst):
    if dry:
        print("copy", src, "->", os.path.relpath(dst, DST)); return
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(src, dst)


moves = [(OLDNAME + ext, OLDNAME + ext) for ext in (".prt", ".step", "_core.stl", "_tufts.stl", "_with_scans.prt")] + [("REPORT.md", "REPORT_v1_2026-10-08.md")]
for a, b in moves:
    s, d = os.path.join(DST, a), os.path.join(OLD, b)
    if os.path.exists(s) and not (a == "REPORT.md" and os.path.exists(d)):
        if dry:
            print("move", a, "->", os.path.relpath(d, DST)); continue
        os.makedirs(OLD, exist_ok=True)
        if os.path.exists(d):
            raise SystemExit("already there, not overwritten: " + d)
        shutil.move(s, d)
O2 = os.path.join(WS, "out2")
for f in (NAME + ".prt", NAME + ".step", NAME + "_with_scans.prt", NAME + "_core.stl", NAME + "_flaps.stl"):
    cp(os.path.join(O2, f), os.path.join(DST, f))
figs = json.load(open(os.path.join(WS, "fig2", "delivery_figures.json"), encoding="utf-8"))
for a, b in figs.items():
    cp(os.path.join(WS, "fig2", a), os.path.join(DST, "figures", b))
for f in ("build2.py", "review2.py", "asfound2.py", "fixup_expr.py", "run2.ps1", "show.py", "show2.py", "test_pure.py"):
    if os.path.exists(os.path.join(WS, f)):
        cp(os.path.join(WS, f), os.path.join(DST, "journal", f))
for f in sorted(os.listdir(os.path.join(WS, "an"))):
    if f.endswith(".py") and (f[0] in "frs" and f[1].isdigit() or f == "common2.py"):
        cp(os.path.join(WS, "an", f), os.path.join(DST, "analysis", f))
b = json.load(open(os.path.join(O2, "build2_abcdefz.json")))
if not dry:
    json.dump(b, open(os.path.join(DST, "qa", "build2_checks.json"), "w"), indent=1)
    # bead_step / bead_ramp belonged to the shoulder chamfer that was undone; they were deleted from the part (fixup_expr.py)
    json.dump({k: v for k, v in b["masters"].items() if k not in ("bead_step", "bead_ramp")}, open(os.path.join(DST, "qa", "masters_v2.json"), "w"), indent=1, ensure_ascii=False)
for f in sorted(os.listdir(os.path.join(WS, "qa2"))):
    if f.endswith(".json") and "_trial" not in f:
        cp(os.path.join(WS, "qa2", f), os.path.join(DST, "qa", f))
cp(os.path.join(WS, "out2e", "build2_e.json"), os.path.join(DST, "qa", "build2_stage_e_cleaned_journal.json"))
for f in ("review2.json", "asfound2.json", "fixup_expr.json"):
    if os.path.exists(os.path.join(O2, f)):
        cp(os.path.join(O2, f), os.path.join(DST, "qa", f))
cp(os.path.join(WS, "REPORT2.md"), os.path.join(DST, "REPORT.md"))
tot = 0
for r, d, fs in os.walk(DST):
    for f in fs:
        tot += os.path.getsize(os.path.join(r, f))
print("delivered to", DST, "- %.1f MB" % (tot / 1e6))
print(json.dumps({k: v for k, v in b.items() if k in ("result", "n_features_top", "volume_core", "volume_flaps", "volume_tufts")}))
print("checks", len(b["checks"]), "failed", sum(1 for c in b["checks"] if not c["ok"]))
