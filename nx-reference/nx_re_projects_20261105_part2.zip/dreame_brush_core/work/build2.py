"""Dreame main brush WITH bristles: core + 4 silicone flaps + 2 rows of fine-filament bristle tufts.
Native parametric build (NX 2206 journal, headless).

    run_journal build2.py -args <out dir> [stages, default abcdefz]

Stages: a b c d = the core with the tuft holes (unchanged from build.py, 2026-10-08), e = silicone flaps,
f = bristle tufts as fine filaments, z = checks, regeneration test, colours, STEP, STL.
Without "a" the journal continues on a copy of <name>_stage_d.prt (written after stage d).

Datum CSYS (= datum frame of the core scan, qa/T_bristles.json; the assembled scan is aligned to it, qa2/T_asm.json):
    Z  = brush axis, +Z towards the idler end;  z0 = underside of the drive-end flange;  X = straight edge of blade 0
Angles are unitless numbers in degrees, counter-clockwise about +Z seen from +Z; angles of twisted features are
given at z = z_core0. The core twists LEFT-hand: a feature at angle a at z_core0 sits at
a - 360 * (z - z_core0) / twist_lead at height z.
"""
import os, sys, math, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, os.environ["NXBLADE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\dreame_brush\nxlib")
import NXOpen, NXOpen.UF, NXOpen.Features, NXOpen.GeometricUtilities as GU
import nxh, nxf, nxre
import nxblade as nb
import ps

BOOL = nxh.BOOL
F = ps.FREE
OUT = sys.argv[1]
STAGES = sys.argv[2] if len(sys.argv) > 2 else "abcdefz"
NAME = "dreame_brush_with_bristles"
UFS = NXOpen.UF.UFSession.GetUFSession()
X, Y, Z = (1, 0, 0), (0, 1, 0), (0, 0, 1)
CYL, PLANE = 16, 22


class Ctx:
    def __init__(self, part):
        self.part, self.dat = part, nxh.Datums(part)
        self.M, self.C, self.chk, self.log, self.sk, self.notes = {}, {}, nxh.Check(), [], {}, {}
        self.t0 = time.time()

    def e(self, name, value, comment="", unit="mm"):
        """master expression (a number); unit None = unitless (counts, angles in degrees)"""
        nxh.expr(self.part, name, value, unit, comment)
        self.M[name] = float(value)
        self.C[name] = (comment, unit or "-")
        return float(value)

    def d(self, name, formula, value, comment=""):
        """derived unitless expression (a formula of masters); value = its number for the journal's own maths"""
        nxh.expr(self.part, name, formula, None, comment)
        self.M[name] = float(value)
        return float(value)

    def say(self, msg):
        self.log.append("%6.1fs  %s" % (time.time() - self.t0, msg))

    def sketch(self, plane, name, **kw):
        return ps.Sketch(self.part, self.dat, plane, name, **kw)

    def done(self, S):
        st = S.finish()
        self.sk[S.name] = {"status": st["status"], "dof": st["dof"], "auto_dims": st["auto_dims"], "dims": len(st["dims"])}
        return S

    def vol(self, body):
        return nxh.volume(self.part, body)


# ------------------------------------------------------------------------------------------ small maths
def revolve_volume(verts):
    """Volume of a closed (r, z) polygon turned 360 deg about r = 0."""
    v = 0.0
    n = len(verts)
    for i in range(n):
        r0, z0 = verts[i][0], verts[i][1]
        r1, z1 = verts[(i + 1) % n][0], verts[(i + 1) % n][1]
        v += (r0 * r0 + r0 * r1 + r1 * r1) * (z1 - z0)
    return abs(v) * math.pi / 3.0


def poly_area(pts):
    a = 0.0
    for i in range(len(pts)):
        x0, y0 = pts[i]
        x1, y1 = pts[(i + 1) % len(pts)]
        a += x0 * y1 - x1 * y0
    return abs(a) / 2


def in_poly(x, y, pts):
    c = False
    n = len(pts)
    for i in range(n):
        x0, y0 = pts[i]
        x1, y1 = pts[(i + 1) % n]
        if (y0 > y) != (y1 > y) and x < x0 + (y - y0) * (x1 - x0) / (y1 - y0):
            c = not c
    return c


def area_in_disc(inside, box, R, r_min=0.0, h=0.004):
    """Area of {inside(x, y)} within r_min <= r <= R, midpoint grid over box = (x0, x1, y0, y1)."""
    x0, x1, y0, y1 = box
    nx_, ny_ = int((x1 - x0) / h) + 1, int((y1 - y0) / h) + 1
    n = 0
    for i in range(nx_):
        x = x0 + (i + 0.5) * h
        for j in range(ny_):
            y = y0 + (j + 0.5) * h
            rr = x * x + y * y
            if rr <= R * R and rr >= r_min * r_min and inside(x, y):
                n += 1
    return n * h * h


def rotz(p, deg):
    a = math.radians(deg)
    return (p[0] * math.cos(a) - p[1] * math.sin(a), p[0] * math.sin(a) + p[1] * math.cos(a))


def tw(c, z):
    """rotation (deg) of the twisted core at height z relative to z_core0"""
    return -360.0 * (z - c.M["z_core0"]) / c.M["twist_lead"]


def on_body(c, body, xyz):
    return abs(nxh.dist_to(c.part, body, xyz))


def land_faces(c):
    r = c.M["d_core"] / 2
    out = []
    for f in c.core.GetFaces():
        t, pt, d, rad = nxh.face_data(f)
        if t == CYL and abs(abs(rad) - r) < 1e-4 and abs(pt[0]) < 1e-6 and abs(pt[1]) < 1e-6:
            out.append(f)
    return out


def long_land_edges(c, centre_deg, half_window_deg, min_len=60.0):
    """Helical edges of the land faces whose untwisted angle lies within the window of one of the centres."""
    out, seen = [], set()
    for f in land_faces(c):
        for ed in f.GetEdges():
            if ed.Tag in seen or ed.GetLength() < min_len:
                continue
            seen.add(ed.Tag)
            pts = nxh.edge_points(ed, n=5, ends=False)
            p = pts[len(pts) // 2]
            a = math.degrees(math.atan2(p[1], p[0])) - tw(c, p[2])
            if any(abs((a - c0 + 180.0) % 360.0 - 180.0) < half_window_deg for c0 in centre_deg):
                out.append(ed)
    return out


def stl_many(bodies, path, chord=0.01, max_edge=1.0):
    if os.path.exists(path):
        os.remove(path)
    h = UFS.Std.OpenBinaryStlFile(path, False, "dreame brush")
    try:
        for b in bodies:
            UFS.Std.PutSolidInStlFile(h, 0, b.Tag, 0.0, float(max_edge), float(chord))
    finally:
        UFS.Std.CloseStlFile(h)
    return os.path.getsize(path)


# =========================================================================================== stage A
def stage_a(c):
    """Drive end: flange + hub disc + hub (one revolve with the underside recess), hex socket, pits, pinwheel blades."""
    p, e, M = c.part, c.e, c.M
    e("h_total", 169.75, "overall length: underside of the flange to the idler end face")
    e("twist_lead", 225.75, "lead of the core twist, mm per turn, left-hand")
    e("d_rim", 32.9, "flange (rim) diameter")
    e("h_rim", 3.35, "flange height")
    e("rim_cham_r", 0.8, "flange bottom edge chamfer, radial")
    e("rim_cham_z", 1.3, "flange bottom edge chamfer, axial")
    e("d_hub", 30.4, "hub disc diameter")
    e("z_floor", 4.65, "top of the hub disc = floor between the drive blades")
    e("z_core0", 6.5, "top of the drive blades = start of the twisted core")
    e("d_hub_in", 9.9, "hub cylinder between the blades")
    e("d_recess", 23.0, "underside recess diameter")
    e("z_recess", 3.7, "underside recess floor height")
    e("d_boss", 10.0, "raised ring round the hex socket, diameter")
    e("z_boss", 3.47, "face of the raised ring")
    rr, rh, rhi, rrec, rbo = M["d_rim"] / 2, M["d_hub"] / 2, M["d_hub_in"] / 2, M["d_recess"] / 2, M["d_boss"] / 2
    base = [(0.0, M["z_boss"], None, "z_boss"), (rbo, M["z_boss"], "d_boss/2", None), (rbo, M["z_recess"], None, "z_recess"),
            (rrec, M["z_recess"], "d_recess/2", None), (rrec, 0.0), (rr - M["rim_cham_r"], 0.0, "d_rim/2-rim_cham_r", None),
            (rr, M["rim_cham_z"], "d_rim/2", "rim_cham_z"), (rr, M["h_rim"], None, "h_rim"), (rh, M["h_rim"], "d_hub/2", None),
            (rh, M["z_floor"], None, "z_floor"), (rhi, M["z_floor"], "d_hub_in/2", None), (rhi, M["z_core0"], None, "z_core0"),
            (0.0, M["z_core0"])]
    S = c.sketch("xz", "SK_BASE")
    S.profile(base)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (rr, 1.0)), nxf.axis_from(p, c.dat.z))
    f.SetName("BASE")
    c.core = f.GetBodies()[0]
    c.chk("BASE volume = revolve of the profile", c.vol(c.core), revolve_volume(base), 0.02)
    c.base_profile = base

    # ---- pits and ejector marks on the recess floor (pairs, 180 deg apart)
    e("pit_r", 7.93, "pits in the recess floor: radial position")
    e("pit_ang", 139.5, "pits: angle of the first one, deg", None)
    e("pit_d", 1.5, "pit diameter")
    e("pit_depth", 0.65, "pit depth from the recess floor")
    e("ej_r", 8.35, "ejector marks: radial position")
    e("ej_ang", 46.0, "ejector marks: angle of the first one, deg", None)
    e("ej_d", 2.2, "ejector mark diameter")
    e("ej_depth", 0.3, "ejector mark depth")
    e("dish_d", 3.6, "shallow dish round each pit: diameter")
    e("dish_depth", 0.25, "shallow dish round each pit: depth")
    nxh.expr(p, "n_pair", 2, None, "pits / marks per circle")
    for nm, pre, pos in (("PIT_DISH", "dish", "pit"), ("PIT", "pit", "pit"), ("EJECTOR_MARK", "ej", "ej")):
        v0 = c.vol(c.core)
        f, _ = nxh.cylinder(p, ("%s_r*cos(%s_ang)" % (pos, pos), "%s_r*sin(%s_ang)" % (pos, pos), "z_recess"), Z, "%s_d" % pre, "%s_depth" % pre,
                            op=BOOL.Subtract, target=c.core)
        f.SetName(nm)
        pf = nxf.pattern_circular(p, [f], (0, 0, 0), c.dat.z, "n_pair")
        pf.SetName(nm + "_PATTERN")
        exp_ = 2 * math.pi * (M[pre + "_d"] / 2) ** 2 * M[pre + "_depth"]
        if nm == "PIT":                                             # the dish already took the top of the pit
            exp_ -= 2 * math.pi * (M["pit_d"] / 2) ** 2 * M["dish_depth"]
        c.chk(nm + " x 2 removes two cylinders", v0 - c.vol(c.core), exp_, 0.01)

    # ---- pinwheel drive blades
    e("blade_edge", 1.14, "blade: offset of the straight (driving) edge from the axis plane")
    e("d_blade", 30.3, "blade: diameter of the outer wall")
    e("blade_corner_R", 0.5, "blade: round between the straight edge and the outer wall")
    e("blade_crown_R", 4.95, "blade: crown radius (tangent to the outer wall and to the back wall)")
    e("blade_wall", 0.45, "blade: offset of the back wall from the axis plane")
    nxh.expr(p, "n_blade", 4, None, "number of drive blades")
    rb, ed, r1, Rc, xw = M["d_blade"] / 2, M["blade_edge"], M["blade_corner_R"], M["blade_crown_R"], M["blade_wall"]

    def blade_pts(rin):
        c1 = (math.sqrt((rb - r1) ** 2 - (ed + r1) ** 2), ed + r1)
        cc = (xw + Rc, math.sqrt((rb - Rc) ** 2 - (xw + Rc) ** 2))
        v0_ = (math.sqrt(rin ** 2 - ed ** 2), ed)
        v1_ = (c1[0], ed)
        v2_ = (c1[0] * rb / (rb - r1), c1[1] * rb / (rb - r1))
        v3_ = (cc[0] * rb / (rb - Rc), cc[1] * rb / (rb - Rc))
        v4_ = (xw, cc[1])
        v5_ = (xw, math.sqrt(rin ** 2 - xw ** 2))
        return [v0_, v1_, v2_, v3_, v4_, v5_], c1, cc

    rin = rhi - 0.6                                           # the profile closes INSIDE the hub cylinder (clean unite)
    bv, c1, cc = blade_pts(rin)
    verts = [(bv[0][0], bv[0][1], F, "blade_edge"), (bv[1][0], bv[1][1], F, None), (bv[2][0], bv[2][1], F, F), (bv[3][0], bv[3][1], F, F),
             (bv[4][0], bv[4][1], "blade_wall", F), (bv[5][0], bv[5][1], None, F)]
    arcs = {1: (c1[0], c1[1], "blade_corner_R"), 2: (0.0, 0.0, "d_blade/2"), 3: (cc[0], cc[1], "blade_crown_R"), 5: (0.0, 0.0, "d_hub_in/2-0.6")}
    S = c.sketch("xy", "SK_BLADE")
    cs = S.profile(verts, arcs)
    for a_, b_ in ((0, 1), (1, 2), (2, 3), (3, 4)):
        S.tangent(cs[a_], cs[b_], at=bv[b_])
    for k in (2, 5):
        S.centre_on(cs[k], "h")
        S.centre_on(cs[k], "v")
    c.done(S)
    v0 = c.vol(c.core)
    f = nxh.extrude(p, S.section(None, (bv[0][0], bv[0][1])), Z, "z_floor", "z_core0", op=BOOL.Unite, target=c.core)
    f.SetName("BLADE")
    # expected: blade area outside the hub cylinder (numeric), times the blade height
    def arc_pts(ctr, a, b, n=60):
        r = math.hypot(a[0] - ctr[0], a[1] - ctr[1])
        t0, t1 = math.atan2(a[1] - ctr[1], a[0] - ctr[0]), math.atan2(b[1] - ctr[1], b[0] - ctr[0])
        dt = (t1 - t0 + math.pi) % (2 * math.pi) - math.pi
        return [(ctr[0] + r * math.cos(t0 + dt * i / n), ctr[1] + r * math.sin(t0 + dt * i / n)) for i in range(n)]
    poly = [bv[0]] + arc_pts(c1, bv[1], bv[2]) + arc_pts((0, 0), bv[2], bv[3], 400) + arc_pts(cc, bv[3], bv[4], 400) + [bv[4]] + arc_pts((0, 0), bv[5], bv[0], 200)
    # less the strip of the profile that lies inside the hub cylinder: rin <= r <= rhi between the two straight walls
    n_i, strip = 2000, 0.0
    for i in range(n_i):
        r_ = rin + (rhi - rin) * (i + 0.5) / n_i
        strip += r_ * (math.acos(xw / r_) - math.asin(ed / r_)) * (rhi - rin) / n_i
    a_out = poly_area(poly) - strip
    c.blade_area = a_out
    c.chk("BLADE adds area outside the hub x height", c.vol(c.core) - v0, a_out * (M["z_core0"] - M["z_floor"]), 0.35)
    v1 = c.vol(c.core)
    pf = nxf.pattern_circular(p, [f], (0, 0, 0), c.dat.z, "n_blade")
    pf.SetName("BLADE_PATTERN")
    c.chk("BLADE_PATTERN: four equal blades", c.vol(c.core) - v0, 4 * (v1 - v0), 0.01)
    # ---- core cylinder (the hex socket reaches into it)
    e("d_core", 14.95, "core diameter over the lands")
    v0 = c.vol(c.core)
    f, _ = nxh.cylinder(p, (0, 0, "z_core0"), Z, "d_core", "h_total-z_core0", op=BOOL.Unite, target=c.core)
    f.SetName("CORE_CYLINDER")
    c.chk("CORE_CYLINDER volume", c.vol(c.core) - v0, math.pi * (M["d_core"] / 2) ** 2 * (M["h_total"] - M["z_core0"]), 0.01)

    # ---- hex socket
    e("hex_af", 5.8, "hex socket across flats (scan: 5.7 at the mouth .. 5.9 deeper; not caliper-checked)")
    e("hex_ang", 3.5, "direction of a hex flat normal, deg", None)
    e("hex_depth", 6.6, "hex socket depth from the ring face (deepest wall seen; bottom not scanned)")
    rc = M["hex_af"] / math.sqrt(3.0)
    hexv = []
    for i in range(6):
        a = M["hex_ang"] + 30.0 + 60.0 * i
        x, y = rc * math.cos(math.radians(a)), rc * math.sin(math.radians(a))
        fx = "%shex_af/sqrt(3)*cos(hex_ang+%d)" % ("-" if x < 0 else "", 30 + 60 * i)
        fy = "%shex_af/sqrt(3)*sin(hex_ang+%d)" % ("-" if y < 0 else "", 30 + 60 * i)
        hexv.append((x, y, fx, fy))
    S = c.sketch("xy", "SK_HEX")
    S.profile(hexv)
    c.done(S)
    v0 = c.vol(c.core)
    f = nxh.extrude(p, S.section(None, (hexv[0][0], hexv[0][1])), Z, "z_boss", "z_boss+hex_depth", op=BOOL.Subtract, target=c.core)
    f.SetName("HEX_SOCKET")
    c.chk("HEX_SOCKET removes the hexagonal prism", v0 - c.vol(c.core), math.sqrt(3) / 2 * M["hex_af"] ** 2 * M["hex_depth"], 0.02)

    c.chk.true("one solid after stage A", len(nxh.solids(p)) == 1, len(nxh.solids(p)))


# =========================================================================================== stage B
def stage_b(c):
    """Core cylinder and the twisted cuts."""
    p, e, M = c.part, c.e, c.M
    R = M["d_core"] / 2
    L = M["h_total"] - M["z_core0"]
    c.d("twist_sweep", "360*(h_total+1-z_core0)/twist_lead", 360.0 * (M["h_total"] + 1 - M["z_core0"]) / M["twist_lead"],
        "twist angle over the tool length (tools run 1 mm past the idler end), deg")
    # reference geometry at the start of the core
    fp, c.dp0 = nxf.datum_plane(p, "offset", [c.dat.xy], "z_core0", "DP_CORE0")
    fx, c.dax0 = nxf.datum_axis(p, "point_dir", (0, 0, "z_core0"), X, "DA_CORE0_X")
    fy, c.day0 = nxf.datum_axis(p, "point_dir", (0, 0, "z_core0"), Y, "DA_CORE0_Y")
    c.o0 = nxh.point(p, 0, 0, "z_core0")
    G = c.sketch("xz", "SK_AXIS")
    G.profile([(0.0, M["z_core0"], None, "z_core0"), (0.0, M["h_total"] + 1.0, None, "h_total+1")], closed=False)
    c.done(G)
    c.guide = G
    c.guide_feature = G.feature

    def core_sketch(name):
        return ps.Sketch(p, c.dat, "xy", name, on=c.dp0, origin=c.o0, hax=c.dax0, vax=c.day0, shift=(0.0, 0.0, M["z_core0"]))

    def guide_sec():
        return nxh.section_feature(p, [c.guide.feature], (0, 0, M["z_core0"]), curves_only=True)

    def twisted_cut(S, help_uv, ang, count, name, a_in, trim_plane=None, keep_xy=None, z_from=None, trim_plane2=None, z_to=None):
        """Swept tool (angular law) -> [Trim Body] -> Pattern Geometry -> Subtract. a_in = tool area inside the core."""
        f = nb.swept(p, [S.section(None, help_uv)], [guide_sec()], orientation="angular",
                     angles=("-%s" % ang, "-%s+twist_sweep" % ang), solid=True)
        f.SetName(name + "_TOOL")
        tool = f.GetBodies()[0]
        if not tool.IsSolidBody:
            raise RuntimeError(name + ": swept tool is not a solid")
        ex = {k: v for k, v in nxh.examine_geometry(p, tool).items() if v}
        c.chk.true(name + " tool: Examine Geometry clean", not ex, ex)
        if trim_plane is not None:
            zz = 100.0
            kp = rotz(keep_xy, M[ang] + tw(c, zz))
            tf, _rev = nxf.trim_body(p, tool, keep_point=(kp[0], kp[1], zz), datum_plane=trim_plane)
            tf.SetName(name + "_TOOL_START")
            if trim_plane2 is not None:
                tf2, _rev2 = nxf.trim_body(p, tool, keep_point=(kp[0], kp[1], zz), datum_plane=trim_plane2)
                tf2.SetName(name + "_TOOL_END")
        pf, copies = nxf.pattern_geometry(p, [tool], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count=count))
        pf.SetName(name + "_TOOLS")
        n = len(copies) + 1
        v0_ = c.vol(c.core)
        sf = nxh.subtract(p, c.core, tool_features=[f, pf])
        sf.SetName(name)
        length = ((z_to if z_to is not None else M["h_total"]) - (z_from if z_from is not None else M["z_core0"]))
        c.chk("%s: %d cuts remove area-in-core x length" % (name, n), v0_ - c.vol(c.core), n * a_in * length, max(0.012 * n * a_in * length, 0.6))
        c.chk.true(name + ": one solid left, tools consumed", len(nxh.solids(p)) == 1, len(nxh.solids(p)))
        return f

    # ---- T-slots
    e("slot_ang0", 1.1, "T-slot: angle of the first slot at z_core0, deg", None)
    e("slot_w", 1.25, "T-slot: neck width")
    e("slot_neck_r", 6.05, "T-slot: radius where the neck ends and the foot starts")
    e("slot_foot_w", 2.2, "T-slot: foot width at the floor")
    e("slot_floor_r", 4.88, "T-slot: floor radius")
    nxh.expr(p, "n_slot", 4, None, "number of T-slots")
    ro = R + 1.0
    w2, fw2 = M["slot_w"] / 2, M["slot_foot_w"] / 2
    sv = [(ro, -w2, "d_core/2+1", "slot_w/2"), (ro, w2, None, "slot_w/2"), (M["slot_neck_r"], w2, "slot_neck_r", None),
          (M["slot_floor_r"], fw2, "slot_floor_r", "slot_foot_w/2"), (M["slot_floor_r"], -fw2, None, "slot_foot_w/2"), (M["slot_neck_r"], -w2, "slot_neck_r", None)]
    S = core_sketch("SK_SLOT")
    S.profile(sv)
    c.done(S)
    spoly = [(v[0], v[1]) for v in sv]
    a_slot = area_in_disc(lambda x, y: in_poly(x, y, spoly), (4.8, R + 0.05, -1.2, 1.2), R)
    c.a_slot = a_slot
    twisted_cut(S, (ro, 0.0), "slot_ang0", "n_slot", "SLOTS", a_slot)
    # the slot follows the twist: probe a neck wall point at three heights
    for zz in (20.0, 90.0, 160.0):
        q = rotz((6.6, w2), M["slot_ang0"] + tw(c, zz))
        c.chk("slot wall on the helix at z = %g" % zz, on_body(c, c.core, (q[0], q[1], zz)), 0.0, 0.006)

    # ---- small grooves
    e("sg_ang0", 59.9, "small groove: angle of the first one at z_core0, deg", None)
    e("sg_R", 0.92, "small groove: radius")
    e("sg_floor_r", 6.935, "small groove: floor radius")
    nxh.expr(p, "n_sg", 2, None, "number of small grooves")
    S = core_sketch("SK_SMALL_GROOVE")
    cu = M["sg_floor_r"] + M["sg_R"]
    S.circle(cu, 0.0, 2 * M["sg_R"], cuf="sg_floor_r+sg_R", df="2*sg_R")
    c.done(S)
    a_sg = area_in_disc(lambda x, y: (x - cu) ** 2 + y * y <= M["sg_R"] ** 2, (cu - 1.0, R + 0.05, -1.0, 1.0), R)
    twisted_cut(S, (M["sg_floor_r"], 0.0), "sg_ang0", "n_sg", "SMALL_GROOVES", a_sg)

    # ---- wide V grooves (flat floor) and their centre groove
    e("vg_ang0", 135.65, "wide groove: angle of the first one at z_core0, deg", None)
    e("vg_floor_r", 6.59, "wide groove: radius of the flat floor")
    e("vg_floor_w", 2.6, "wide groove: width of the flat floor")
    e("vg_flank_ang", 13.7, "wide groove: flank slope against the floor, deg", None)
    nxh.expr(p, "n_vg", 2, None, "number of wide grooves")
    rt = R + 0.6
    vt = M["vg_floor_w"] / 2 + (rt - M["vg_floor_r"]) / math.tan(math.radians(M["vg_flank_ang"]))
    ft = "vg_floor_w/2+(d_core/2+0.6-vg_floor_r)/tan(vg_flank_ang)"
    vv = [(M["vg_floor_r"], -M["vg_floor_w"] / 2, "vg_floor_r", "vg_floor_w/2"), (M["vg_floor_r"], M["vg_floor_w"] / 2, None, "vg_floor_w/2"),
          (rt, vt, "d_core/2+0.6", ft), (rt, -vt, None, ft)]
    S = core_sketch("SK_WIDE_GROOVE")
    S.profile(vv)
    c.done(S)
    vpoly = [(v[0], v[1]) for v in vv]
    a_vg = area_in_disc(lambda x, y: in_poly(x, y, vpoly), (M["vg_floor_r"] - 0.01, R + 0.05, -3.2, 3.2), R)
    twisted_cut(S, (M["vg_floor_r"], 0.0), "vg_ang0", "n_vg", "WIDE_GROOVES", a_vg)

    e("ag_R", 1.65, "centre groove in the wide groove: radius")
    e("ag_floor_r", 6.25, "centre groove: floor radius (scan: 6.06 .. 6.47 along the length)")
    e("z_ag0", 33.0, "centre groove starts at this height (scan: runs in between z 24 and 36)")
    e("ag_end_gap", 6.25, "centre groove ends this far before the idler end face (scan: runs out before the end)")
    fz, dpa = nxf.datum_plane(p, "offset", [c.dat.xy], "z_ag0", "DP_CENTRE_GROOVE_START")
    fz1, dpb = nxf.datum_plane(p, "offset", [c.dat.xy], "h_total-ag_end_gap", "DP_CENTRE_GROOVE_END")
    S = core_sketch("SK_CENTRE_GROOVE")
    ca = M["ag_floor_r"] + M["ag_R"]
    S.circle(ca, 0.0, 2 * M["ag_R"], cuf="ag_floor_r+ag_R", df="2*ag_R")
    c.done(S)
    # what the centre groove still removes below the wide groove's floor / flanks
    a_ag = area_in_disc(lambda x, y: (x - ca) ** 2 + y * y <= M["ag_R"] ** 2 and not in_poly(x, y, vpoly), (M["ag_floor_r"] - 0.01, R + 0.05, -1.7, 1.7), R)
    twisted_cut(S, (M["ag_floor_r"], 0.0), "vg_ang0", "n_vg", "CENTRE_GROOVES", a_ag, trim_plane=dpa, keep_xy=(ca, 0.0), z_from=M["z_ag0"], trim_plane2=dpb, z_to=M["h_total"] - M["ag_end_gap"])

    # ---- edge blends along the helical edges of the lands
    e("slot_mouth_R", 0.25, "round on the T-slot mouths")
    e("sg_edge_R", 0.3, "round on the small-groove shoulders")
    e("vg_edge_R", 1.0, "round where the wide-groove flanks meet the lands")
    half_slot = math.degrees(math.asin(w2 / R))
    half_sg = math.degrees(math.asin(min(1.0, 0.82 / R)))
    half_vg = math.degrees(math.atan2(2.75, 6.95))
    jobs = (("SLOT_MOUTH_BLEND", [M["slot_ang0"] + 90.0 * i for i in range(4)], half_slot + 1.5, "slot_mouth_R", 8),
            ("SMALL_GROOVE_BLEND", [M["sg_ang0"] + 180.0 * i for i in range(2)], half_sg + 2.5, "sg_edge_R", 4),
            ("WIDE_GROOVE_BLEND", [M["vg_ang0"] + 180.0 * i for i in range(2)], half_vg + 3.0, "vg_edge_R", 4))
    c.notes["blends"] = {}
    for name, centres, win, rad, n_exp in jobs:
        eds = long_land_edges(c, centres, win)
        v0_ = c.vol(c.core)
        info = {"edges": len(eds)}
        if len(eds) != n_exp:
            info["result"] = "SKIPPED: expected %d edges" % n_exp
        else:
            m = nxh.mark(name, False)
            try:
                bf = nxh.blend(p, eds, rad)
                bf.SetName(name)
                ex = {k: v for k, v in nxh.examine_geometry(p, c.core).items() if v}
                if ex or len(nxh.solids(p)) != 1:
                    raise RuntimeError("body not clean after the blend: %s" % ex)
                info["result"] = "built"
                info["dV"] = c.vol(c.core) - v0_
            except Exception as ex_:                                   # noqa: BLE001
                nxh.undo_to(m)
                info["result"] = "NOT BUILT: " + str(ex_)[:200]
        c.notes["blends"][name] = info
        c.chk.true(name + " built on %d helical edges" % n_exp, info["result"] == "built", info)
    c.chk.true("no feature errors after stage B", not nxh.feature_errors(p), nxh.feature_errors(p))


# =========================================================================================== stage C
def stage_c(c):
    """Idler end."""
    p, e, M = c.part, c.e, c.M
    e("d_cbore", 11.75, "idler end: counterbore diameter")
    e("cbore_depth", 1.2, "idler end: counterbore depth")
    e("d_bore", 8.6, "idler end: bore diameter")
    e("bore_depth", 4.95, "idler end: bore depth from the end face (deepest shoulder seen in the scan)")
    e("end_cham", 1.05, "idler end: 45 deg chamfer on the outer edge")
    ht, rcb, rbo = M["h_total"], M["d_cbore"] / 2, M["d_bore"] / 2
    ev = [(0.0, ht + 1.0, None, "h_total+1"), (rcb, ht + 1.0, "d_cbore/2", None), (rcb, ht - M["cbore_depth"], None, "h_total-cbore_depth"),
          (rbo, ht - M["cbore_depth"], "d_bore/2", None), (rbo, ht - M["bore_depth"], None, "h_total-bore_depth"), (0.0, ht - M["bore_depth"])]
    S = c.sketch("xz", "SK_IDLER_BORE")
    S.profile(ev)
    c.done(S)
    v0 = c.vol(c.core)
    f = nxf.revolve(p, S.section(None, (rcb, ht)), nxf.axis_from(p, c.dat.z), op=BOOL.Subtract, target=c.core)
    f.SetName("IDLER_BORE")
    c.notes["solids_after_IDLER_BORE"] = [round(c.vol(b), 3) for b in nxh.solids(p)]
    # the slots already removed part of the counterbore ring (their feet reach inside the counterbore radius)
    spoly = [(M["slot_floor_r"], -M["slot_foot_w"] / 2), (M["slot_floor_r"], M["slot_foot_w"] / 2), (M["slot_neck_r"], M["slot_w"] / 2), (9.0, M["slot_w"] / 2),
             (9.0, -M["slot_w"] / 2), (M["slot_neck_r"], -M["slot_w"] / 2)]
    a_sl = area_in_disc(lambda x, y: in_poly(x, y, spoly), (4.8, rcb + 0.02, -1.2, 1.2), rcb)
    exp = math.pi * (rcb ** 2 * M["cbore_depth"] + rbo ** 2 * (M["bore_depth"] - M["cbore_depth"])) - 4 * a_sl * M["cbore_depth"]
    c.chk("IDLER_BORE removes counterbore + bore (less the slot feet)", v0 - c.vol(c.core), exp, 0.6)

    R = M["d_core"] / 2
    ch = M["end_cham"]
    rv = [(R - ch, ht, "d_core/2-end_cham", "h_total"), (R, ht - ch, "d_core/2", "h_total-end_cham"), (R + 1.0, ht - ch, "d_core/2+1", None),
          (R + 1.0, ht + 1.0, None, "h_total+1"), (R - ch, ht + 1.0, None, None)]
    S = c.sketch("xz", "SK_END_CHAMFER")
    S.profile(rv)
    c.done(S)
    v0 = c.vol(c.core)
    f = nxf.revolve(p, S.section(None, (R + 1.0, ht)), nxf.axis_from(p, c.dat.z), op=BOOL.Subtract, target=c.core)
    f.SetName("END_CHAMFER")
    c.notes["solids_after_END_CHAMFER"] = [round(c.vol(b), 3) for b in nxh.solids(p)]
    full = revolve_volume([(R - ch, ht), (R, ht - ch), (R, ht)])                      # uncut ring
    dv = v0 - c.vol(c.core)
    c.chk.true("END_CHAMFER removes material (full ring %.2f less slots and grooves)" % full, 0.6 * full < dv < full + 0.01, dv)
    q = rotz((R - ch / 2, 0.0), 30.0 + tw(c, ht))
    c.chk("END_CHAMFER: point on the chamfer", on_body(c, c.core, (q[0], q[1], ht - ch / 2)), 0.0, 2e-3)

    # ---- key notch beside one slot at the idler end
    e("notch_ang", 201.3, "idler-end key notch: direction of its centre line, deg (it overlaps the neck of the slot it widens)", None)
    e("notch_w", 2.25, "key notch width, measured from inside the slot neck to the far wall")
    e("notch_h", 1.5, "key notch depth from the end face")
    a, w2 = M["notch_ang"], M["notch_w"] / 2
    ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
    nv = []
    for rr_, sg in ((5.0, -1), (5.0, 1), (9.0, 1), (9.0, -1)):
        x, y = rr_ * ca - sg * w2 * sa, rr_ * sa + sg * w2 * ca
        sx = "%g*cos(notch_ang)%snotch_w/2*sin(notch_ang)" % (rr_, "-" if sg > 0 else "+")
        sy = "%g*sin(notch_ang)%snotch_w/2*cos(notch_ang)" % (rr_, "+" if sg > 0 else "-")
        nv.append((x, y, ("-(%s)" % sx) if x < 0 else sx, ("-(%s)" % sy) if y < 0 else sy))
    S = c.sketch("xy", "SK_KEY_NOTCH")
    S.profile(nv)
    c.done(S)
    v0 = c.vol(c.core)
    f = nxh.extrude(p, S.section(None, (nv[0][0], nv[0][1])), Z, "h_total-notch_h", "h_total+1", op=BOOL.Subtract, target=c.core)
    f.SetName("KEY_NOTCH")
    c.notes["solids_after_KEY_NOTCH"] = [(round(c.vol(b), 4), nxh.bbox(b)) for b in nxh.solids(p)]
    dv = v0 - c.vol(c.core)
    ring = (R - rcb) * M["notch_w"] * M["notch_h"]
    c.chk.true("KEY_NOTCH cuts the end ring (at most width x wall x depth = %.2f)" % ring, 0.3 * ring < dv < 1.15 * ring, dv)
    c.chk.true("one solid after stage C, no feature errors", len(nxh.solids(p)) == 1 and not nxh.feature_errors(p), nxh.feature_errors(p))


# =========================================================================================== stage D
def stage_d(c):
    """Bristles, part 1: 2 helical rows of tuft holes in the core (the tufts themselves: stage F)."""
    p, e, M = c.part, c.e, c.M
    nxh.expr(p, "n_tuft", 27, None, "tufts per row")
    M["n_tuft"] = 27
    e("tuft_pitch", 4.9, "tuft spacing along the axis")
    e("tuft_z0", 10.55, "height of the first tuft (centre of its hole mouth on the land)")
    e("tuft_ang0", 36.1, "row angle referred to z_core0 (the rows follow the core twist), deg", None)
    e("d_tuft_hole", 2.0, "tuft hole diameter")
    e("tuft_hole_depth", 3.0, "tuft hole depth along its axis (ASSUMED: the holes are filled with bristles)")
    e("tuft_lean", 40.0, "lean of the tufts from the radial direction towards the idler end, deg", None)
    e("d_brush", 37.0, "diameter over the bristle tips")
    seed_ang = M["tuft_ang0"] - 360.0 * (M["tuft_z0"] - M["z_core0"]) / M["twist_lead"]
    c.d("tuft_ang_seed", "tuft_ang0-360*(tuft_z0-z_core0)/twist_lead", seed_ang, "angle of the first tuft at its own height, deg")
    R, ln = M["d_core"] / 2, M["tuft_lean"]
    cs_, sn_ = math.cos(math.radians(ln)), math.sin(math.radians(ln))
    rh, dep, z0 = M["d_tuft_hole"] / 2, M["tuft_hole_depth"], M["tuft_z0"]
    CL, SL = "cos(tuft_lean)", "sin(tuft_lean)"
    # hole tool: half section turned about its own axis line B -> E (E = 2 mm outside the land)
    B = (R - dep * cs_, z0 - dep * sn_)
    E = (R + 2.0 * cs_, z0 + 2.0 * sn_)
    hv = [(B[0], B[1], "d_core/2-tuft_hole_depth*%s" % CL, "tuft_z0-tuft_hole_depth*%s" % SL),
          (E[0], E[1], "d_core/2+2*%s" % CL, "tuft_z0+2*%s" % SL),
          (E[0] - rh * sn_, E[1] + rh * cs_, "d_core/2+2*%s-d_tuft_hole/2*%s" % (CL, SL), "tuft_z0+2*%s+d_tuft_hole/2*%s" % (SL, CL)),
          (B[0] - rh * sn_, B[1] + rh * cs_, "d_core/2-tuft_hole_depth*%s-d_tuft_hole/2*%s" % (CL, SL), "tuft_z0-tuft_hole_depth*%s+d_tuft_hole/2*%s" % (SL, CL))]
    S = c.sketch("xz", "SK_TUFT_HOLE")
    cs = S.profile(hv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (hv[2][0], hv[2][1])), nxf.axis_from(p, cs[0]))
    f.SetName("TUFT_HOLE_TOOL")
    tool = f.GetBodies()[0]
    c.chk("TUFT_HOLE_TOOL = cylinder d x (depth + 2)", c.vol(tool), math.pi * rh * rh * (dep + 2.0), 1e-3)
    mf = nxf.move_object(p, [tool], "angle", "tuft_ang_seed", vec=Z, origin=(0, 0, 0))
    mf.SetName("TUFT_HOLE_TOOL_CLOCK")
    pf1, cp1 = nxf.pattern_geometry(p, [tool], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="2"))
    pf1.SetName("TUFT_HOLE_TOOL_ROW_2")
    pf2, cp2 = helix_copies(c, tool)
    pf2.SetName("TUFT_HOLE_TOOLS_ROW_1")
    pf3, cp3 = helix_copies(c, cp1[0])
    pf3.SetName("TUFT_HOLE_TOOLS_ROW_2")
    n = 1 + len(cp1) + len(cp2) + len(cp3)
    c.chk.true("54 hole tools", n == 54, n)
    v0 = c.vol(c.core)
    sf = nxh.subtract(p, c.core, tool_features=[f, pf1, pf2, pf3])
    sf.SetName("TUFT_HOLES")
    dv = v0 - c.vol(c.core)
    c.notes["tuft_hole_volume_each"] = dv / 54
    c.chk("TUFT_HOLES: 54 holes of about d^2 pi/4 x depth each", dv, 54 * math.pi * rh * rh * dep, 54 * math.pi * rh * rh * dep * 0.06)
    c.chk.true("one core solid after the tuft holes", len(nxh.solids(p)) == 1, len(nxh.solids(p)))
    # position of the first and the last hole axis of row 1: the hole bottom centre lies on the core body
    for k in (0, 13, 26):
        zz = B[1] + k * M["tuft_pitch"]
        q = rotz((B[0], 0.0), seed_ang - 360.0 * k * M["tuft_pitch"] / M["twist_lead"])
        c.chk("tuft hole %d: bottom centre on the body" % k, on_body(c, c.core, (q[0], q[1], zz)), 0.0, 2e-3)

    c.core.SetName("CORE")
    c.chk.true("no feature errors after stage D", not nxh.feature_errors(p), nxh.feature_errors(p))


def helix_copies(c, body, count="n_tuft", every=1):
    """Pattern Geometry, helix layout along the core twist; every = 3 takes each third tuft position."""
    p = c.part
    before = list(p.Bodies)
    b = p.Features.CreatePatternGeometryBuilder(NXOpen.Features.PatternGeometry.Null)
    try:
        psv = b.PatternService
        psv.PatternType = GU.PatternDefinition.PatternEnum.Helix
        hd = psv.HelixDefinition
        hd.RotationAxis = nxh.axis(p, (0, 0, 0), Z)
        hd.DirectionType = GU.HelixPatternDirectionTypes.Lefthand
        hd.SizeOption = type(hd).SizeOptions.CountAngleDistance
        hd.CountOfInstances.RightHandSide = count
        hd.AnglePitch.RightHandSide = "%d*360*tuft_pitch/twist_lead" % every
        hd.DistancePitch.RightHandSide = "%d*tuft_pitch" % every
        b.GeometryToPattern.Add(body)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(p, before)


# =========================================================================================== stage E
def core_sketch(c, name):
    """Sketch on DP_CORE0 in the frame of the twisted cuts (u radial at angle 0, v tangential)."""
    return ps.Sketch(c.part, c.dat, "xy", name, on=c.dp0, origin=c.o0, hax=c.dax0, vax=c.day0, shift=(0.0, 0.0, c.M["z_core0"]))


def guide_sec(c):
    return nxh.section_feature(c.part, [c.guide_feature], (0, 0, c.M["z_core0"]), curves_only=True)


def flap_lines(M):
    """Flap outline in (z, r) without the corner rounds: outer edge of the bead, edge of the web under it."""
    z1 = M["h_total"] - M["flap_end_gap"]
    zt = z1 - M["flap_taper_len"]
    ze = z1 + 1.0
    re = M["flap_r_end"] + (M["flap_r_end"] - M["flap_r_b"]) / M["flap_taper_len"]
    bl = M["bead_len"]
    outer = [(M["flap_step_z0"] - 0.25, M["flap_foot_r1"] + 0.2), (M["flap_step_z1"], M["flap_r_a"]), (zt, M["flap_r_b"]), (ze, re)]
    web = [(M["flap_z0"], M["flap_foot_r0"]), (M["flap_step_z0"], M["flap_foot_r1"]), (M["flap_step_z1"], M["flap_r_a"] - bl / 2),
           (zt, M["flap_r_b"] - bl / 2), (ze, re - bl / 2)]
    return outer, web, z1, zt, ze, re


def flap_end_planes(body):
    """z of the lowest and the highest planar end face (normal along Z) - the bounding box of a twisted body is padded"""
    zs = [nxh.face_data(f)[1][2] for f in body.GetFaces() if nxh.face_data(f)[0] == PLANE and abs(abs(nxh.face_data(f)[2][2]) - 1.0) < 1e-6]
    return (min(zs), max(zs)) if zs else (None, None)


def interp(line, z):
    for (za, ra), (zb, rb) in zip(line[:-1], line[1:]):
        if za <= z <= zb:
            return ra + (rb - ra) * (z - za) / (zb - za)
    return None


def strip_seg(t2, r):
    """integral of sqrt(r^2 - y^2) over |y| <= t2"""
    return t2 * math.sqrt(r * r - t2 * t2) + r * r * math.asin(t2 / r)


def flap_volumes(M, z_hi=None):
    """(web, bead) volumes by integration over z of the section area inside the envelopes (corner rounds of the
    outline and of the bead left out). z_hi: upper end (default: the envelopes' own end, 1 mm past)."""
    outer, web, z1, zt, ze, re = flap_lines(M)
    z_hi = ze if z_hi is None else z_hi
    t2, b2 = M["flap_t"] / 2, M["bead_t"] / 2
    nr, rf = M["slot_neck_r"], M["slot_floor_r"] + M["flap_foot_gap"]
    a_foot = (M["flap_t"] + M["flap_foot_w"]) / 2 * (nr - rf)
    n = 6000
    vw = vb = 0.0
    za = M["flap_z0"]
    for i in range(n):
        z = za + (z_hi - za) * (i + 0.5) / n
        dz = (z_hi - za) / n
        vw += (a_foot + strip_seg(t2, interp(web, z)) - 2 * t2 * nr) * dz
        ro = interp(outer, z)
        if ro is not None:
            vb += (strip_seg(b2, ro) - strip_seg(b2, ro - M["bead_len"])) * dz
    return vw, vb


def stage_e(c):
    """Silicone flaps, one in every T-slot. A twisted blank (web + dovetail foot) and a twisted bead blank are each cut
    to the measured (r, z) outline by a revolved envelope, the outer bead corners are rounded, the flap is patterned."""
    p, e, M = c.part, c.e, c.M
    R = M["d_core"] / 2
    e("flap_t", 0.94, "silicone flap: web thickness")
    e("flap_foot_w", 2.0, "flap: width of the dovetail foot at the slot floor (ASSUMED: hidden in the slot)")
    e("flap_foot_gap", 0.1, "flap: gap between the foot and the slot floor (ASSUMED)")
    e("bead_t", 1.44, "flap: thickness of the bead along the free edge")
    e("bead_len", 1.5, "flap: radial length of the bead")
    e("bead_tip_R", 0.6, "flap: round on the two outer corners of the bead")
    e("flap_seat_gap", 0.1, "flap: gap between its lower end and the tops of the drive blades it rests on (scan: seated flaps start at z 6.5)")
    nxh.expr(p, "flap_z0", "z_core0+flap_seat_gap", "mm", "flap: height of the lower end")
    M["flap_z0"] = M["z_core0"] + M["flap_seat_gap"]
    e("flap_end_gap", 1.95, "flap: upper end stays this far below the idler end face")
    e("flap_taper_len", 21.8, "flap: axial length of the end taper")
    e("flap_foot_r0", 14.8, "flap outline: radius at the lower end (plain part, no bead)")
    e("flap_foot_r1", 15.4, "flap outline: radius where the step to the full height starts")
    e("flap_step_z0", 12.6, "flap outline: the step starts at this height")
    e("flap_step_z1", 14.3, "flap outline: the step ends, full height reached")
    e("flap_r_a", 17.1, "flap outline: tip radius at the top of the step (largest radius)")
    e("flap_r_b", 16.25, "flap outline: tip radius where the end taper starts")
    e("flap_r_end", 9.1, "flap outline: tip radius at the upper end")
    e("flap_step_R", 1.0, "flap outline: round at the top of the step")
    e("flap_end_R", 25.0, "flap outline: round between the long edge and the end taper")
    t2, b2, bl = M["flap_t"] / 2, M["bead_t"] / 2, M["bead_len"]
    rblank = M["flap_r_a"] + 1.5
    L = M["h_total"] + 1 - M["z_core0"]
    outer, web, z1, zt, ze, re = flap_lines(M)
    Z1, ZT, ZE = "h_total-flap_end_gap", "h_total-flap_end_gap-flap_taper_len", "h_total-flap_end_gap+1"
    RE = "flap_r_end+(flap_r_end-flap_r_b)/flap_taper_len"
    c.notes["flap"] = {}

    def twisted(S, help_uv, name):
        f = nb.swept(p, [S.section(None, help_uv)], [guide_sec(c)], orientation="angular",
                     angles=("-slot_ang0", "-slot_ang0+twist_sweep"), solid=True)
        f.SetName(name)
        b = f.GetBodies()[0]
        if not b.IsSolidBody:
            raise RuntimeError(name + ": swept body is not a solid")
        return f, b

    # ---- web blank: strip + dovetail foot, twisted with the slots
    nr, rf, fw2 = M["slot_neck_r"], M["slot_floor_r"] + M["flap_foot_gap"], M["flap_foot_w"] / 2
    fv = [(rblank, -t2, "flap_r_a+1.5", "flap_t/2"), (rblank, t2, None, "flap_t/2"), (nr, t2, "slot_neck_r", None),
          (rf, fw2, "slot_floor_r+flap_foot_gap", "flap_foot_w/2"), (rf, -fw2, None, "flap_foot_w/2"), (nr, -t2, "slot_neck_r", None)]
    S = core_sketch(c, "SK_FLAP")
    S.profile(fv)
    c.done(S)
    f, blank = twisted(S, (rblank, 0.0), "FLAP_BLANK")
    a_sec = M["flap_t"] * (rblank - nr) + (M["flap_t"] + M["flap_foot_w"]) / 2 * (nr - rf)
    c.chk("FLAP_BLANK volume = section area x length", c.vol(blank), a_sec * L, 0.004 * a_sec * L)

    # ---- envelope of the web: revolved (r, z) outline
    wv = [(3.0, M["flap_z0"], "3", "flap_z0"), (M["flap_foot_r0"], M["flap_z0"], "flap_foot_r0", None),
          (M["flap_foot_r1"], M["flap_step_z0"], "flap_foot_r1", "flap_step_z0"),
          (M["flap_r_a"] - bl / 2, M["flap_step_z1"], "flap_r_a-bead_len/2", "flap_step_z1"),
          (M["flap_r_b"] - bl / 2, zt, "flap_r_b-bead_len/2", ZT), (re - bl / 2, ze, RE + "-bead_len/2", ZE), (3.0, ze, None, None)]
    S = c.sketch("xz", "SK_FLAP_WEB_OUTLINE")
    S.profile(wv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (3.0, 80.0)), nxf.axis_from(p, c.dat.z))
    f.SetName("FLAP_WEB_ENVELOPE")
    env = f.GetBodies()[0]
    c.chk("FLAP_WEB_ENVELOPE volume = revolve of the outline", c.vol(env), revolve_volume([(v[0], v[1]) for v in wv]), 0.05)
    f = nxh.intersect(p, blank, [env])
    f.SetName("FLAP_WEB")
    vw, vb = flap_volumes(M)
    c.chk("FLAP_WEB = blank inside the envelope (numeric integral)", c.vol(blank), vw, 0.006 * vw)

    # ---- bead blank and its envelope (a band along the free edge)
    ri = R - 0.5
    bv = [(rblank, -b2, "flap_r_a+1.5", "bead_t/2"), (rblank, b2, None, "bead_t/2"), (ri, b2, "d_core/2-0.5", None), (ri, -b2, None, None)]
    S = core_sketch(c, "SK_BEAD")
    S.profile(bv)
    c.done(S)
    f, bead = twisted(S, (rblank, 0.0), "BEAD_BLANK")
    c.chk("BEAD_BLANK volume = section area x length", c.vol(bead), M["bead_t"] * (rblank - ri) * L, 0.004 * M["bead_t"] * (rblank - ri) * L)
    zs, r1s = M["flap_step_z0"] - 0.25, M["flap_foot_r1"] + 0.2
    ov = [(r1s, zs, "flap_foot_r1+0.2", "flap_step_z0-0.25"), (M["flap_r_a"], M["flap_step_z1"], "flap_r_a", "flap_step_z1"),
          (M["flap_r_b"], zt, "flap_r_b", ZT), (re, ze, RE, ZE), (re - bl, ze, RE + "-bead_len", None),
          (M["flap_r_b"] - bl, zt, "flap_r_b-bead_len", ZT), (M["flap_r_a"] - bl, M["flap_step_z1"], "flap_r_a-bead_len", "flap_step_z1"),
          (r1s - bl, zs, "flap_foot_r1+0.2-bead_len", None)]
    S = c.sketch("xz", "SK_BEAD_OUTLINE")
    S.profile(ov)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (r1s - bl / 2, zs)), nxf.axis_from(p, c.dat.z))
    f.SetName("BEAD_ENVELOPE")
    band = f.GetBodies()[0]
    c.chk("BEAD_ENVELOPE volume = revolve of the band", c.vol(band), revolve_volume([(v[0], v[1]) for v in ov]), 0.05)

    def ring_edges(body, r, z, tol=0.02):
        out = []
        for ed in body.GetEdges():
            bb = nxh.bbox(ed)
            if abs(bb[2] - z) < tol and abs(bb[5] - z) < tol and abs(bb[3] - r) < tol:
                out.append(ed)
        return out

    sets = [(ring_edges(band, M["flap_r_b"], zt) + ring_edges(band, M["flap_r_b"] - bl, zt), "flap_end_R"),
            (ring_edges(band, M["flap_r_a"], M["flap_step_z1"]) + ring_edges(band, M["flap_r_a"] - bl, M["flap_step_z1"]), "flap_step_R")]
    c.chk.true("BEAD_ENVELOPE: two corner rings found per radius", [len(s[0]) for s in sets] == [2, 2], [len(s[0]) for s in sets])
    v0 = c.vol(band)
    f = nxf.edge_blend(p, sets)
    f.SetName("BEAD_ENVELOPE_ROUNDS")
    c.notes["flap"]["band_round_dV"] = c.vol(band) - v0
    f = nxh.intersect(p, bead, [band])
    f.SetName("FLAP_BEAD")
    c.chk("FLAP_BEAD = bead blank inside the band (numeric integral, corner rounds left out)", c.vol(bead), vb, 0.02 * vb)

    def bead_edges(body):
        """helical edges of the bead: (outer corners, shoulder corners)"""
        cls = {}
        for fc in body.GetFaces():
            pt, n = nxh.face_mid_normal(fc)
            rr = math.hypot(pt[0], pt[1]) or 1e-9
            nrad = (n[0] * pt[0] + n[1] * pt[1]) / rr
            cls[fc.Tag] = "end" if abs(n[2]) > 0.95 else ("outer" if nrad > 0.6 else ("inner" if nrad < -0.6 else "side"))
        tip, sh = [], []
        for ed in body.GetEdges():
            ks = sorted(cls[fc.Tag] for fc in ed.GetFaces())
            if ks == ["outer", "side"]:
                tip.append(ed)
            elif ks == ["inner", "side"]:
                sh.append(ed)
        return tip, sh, cls

    def guarded(name, fn):
        """run one detail feature; undo it when it fails or leaves a body Examine Geometry complains about"""
        m = nxh.mark(name, False)
        v0_ = c.vol(bead)
        try:
            ft = fn()
            ft.SetName(name)
            ex = {k: v for k, v in nxh.examine_geometry(p, bead).items() if v}
            if ex or not bead.IsSolidBody:
                raise RuntimeError("body not clean: %s" % ex)
            return {"result": "built", "dV": c.vol(bead) - v0_}
        except Exception as ex_:                                       # noqa: BLE001
            nxh.undo_to(m)
            return {"result": "NOT BUILT: " + str(ex_)[:200]}

    tip, _sh, cls = bead_edges(bead)
    c.notes["flap"]["bead_faces"] = {k: sum(1 for v in cls.values() if v == k) for k in ("outer", "inner", "side", "end")}
    info = {"edges": len(tip)}
    info.update(guarded("BEAD_TIP_ROUND", lambda: nxh.blend(p, tip, "bead_tip_R")))
    if info["result"] != "built":
        info["first_try"] = info["result"]
        tip, _sh, cls = bead_edges(bead)
        info.update(guarded("BEAD_TIP_ROUND", lambda: nxh.blend(p, tip, "bead_tip_R", overflow=True)))
    c.notes["flap"]["BEAD_TIP_ROUND"] = info
    c.chk.true("BEAD_TIP_ROUND built on the %d outer corner edges" % info["edges"], info["result"] == "built", info)
    # The shoulder where the bead meets the web stays a square step of (bead_t - flap_t) / 2. The scan shows a ramp
    # of about 0.25 x 0.45 there; a two-offset Chamfer on these 10 helical edges was tried in three runs and NX gave
    # the two offsets to different faces from edge to edge and from run to run (removed volume 8.9 / 19.7 / 12.6 mm3),
    # and the STEP of the chamfered flap re-imported 0.67 % short in volume. Left out on purpose.

    # ---- one flap: web + bead, cut to length
    v_parts = c.vol(blank) + c.vol(bead)
    f = nxh.unite(p, blank, [bead])
    f.SetName("FLAP")
    flap = blank
    c.notes["flap"]["web_and_bead_overlap"] = v_parts - c.vol(flap)
    fz, dpe = nxf.datum_plane(p, "offset", [c.dat.xy], Z1, "DP_FLAP_END")
    tf, _rev = nxf.trim_body(p, flap, keep_point=(0.0, 0.0, 90.0), datum_plane=dpe)
    tf.SetName("FLAP_END")
    zc = flap_end_planes(flap)
    c.chk("flap: lower end face at flap_z0", zc[0], M["flap_z0"], 1e-4)
    c.chk("flap: upper end face at h_total - flap_end_gap", zc[1], z1, 1e-4)
    ex = {k: v for k, v in nxh.examine_geometry(p, flap).items() if v}
    c.chk.true("FLAP: one solid, Examine Geometry clean", flap.IsSolidBody and not ex, ex)
    c.notes["flap"]["volume_one"] = c.vol(flap)
    c.notes["flap"]["faces"] = nxh.face_census(flap)
    # probes: web wall on the helix, tip flat on the outline, clearance to the core
    for zz in (30.0, 90.0, 150.0):
        qw = rotz((11.0, t2), M["slot_ang0"] + tw(c, zz))
        c.chk("flap web wall on the helix at z = %g" % zz, on_body(c, flap, (qw[0], qw[1], zz)), 0.0, 0.006)
    for zz in (40.0, 120.0):
        qt = rotz((interp(outer, zz), 0.0), M["slot_ang0"] + tw(c, zz))
        c.chk("flap tip on the outline at z = %g (r = %.3f)" % (zz, interp(outer, zz)), on_body(c, flap, (qt[0], qt[1], zz)), 0.0, 0.006)
    gap = nxh.min_dist(flap, c.core)
    c.notes["flap"]["clearance_to_core"] = gap
    c.chk.true("flap clears the core everywhere (smallest gap %.3f mm)" % gap, gap > 0.02, gap)
    pf, copies = nxf.pattern_geometry(p, [flap], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="n_slot"))
    pf.SetName("FLAPS")
    c.flaps = [flap] + list(copies)
    for b in c.flaps:
        b.SetName("SILICONE_FLAP")
    c.chk.true("4 flap bodies", len(c.flaps) == 4, len(c.flaps))
    c.chk("the four flaps have the same volume", sum(c.vol(b) for b in c.flaps), 4 * c.notes["flap"]["volume_one"], 0.01)
    gaps = [nxh.min_dist(b, c.core) for b in c.flaps]
    c.notes["flap"]["clearance_all"] = gaps
    c.chk.true("all flaps clear the core", min(gaps) > 0.02, gaps)
    c.chk.true("no feature errors after stage E", not nxh.feature_errors(p), nxh.feature_errors(p))


# =========================================================================================== stage F
N_RING = 4                          # hexagonal packing with 4 rings = 61 filaments per tuft
FIL_PITCH = 0.2                     # filament spacing in the root as a share of the hole radius (0.2 mm in a d 2 hole)
FAN_U, FAN_V = 15.0, 6.0            # half fan angle of the outermost filaments along the row / across it, deg
JIT_U, JIT_V = 2.5, 1.5             # random part of each filament direction (sigma), deg
MAX_U = 17.0                        # limit of the angle along the row (fan + random), deg
LEAN_T = -7.0                       # common sideways lean of the tufts (clockwise seen from +Z), deg
TIP_JIT = (-0.55, 0.2)              # scatter of the tip radius about d_brush / 2, mm
SINK = 0.25                         # filaments start this far inside the root plug
FIL_GAP = 0.02                      # smallest gap kept between two filaments of a tuft outside the root, mm
VARIANTS = (("A", 11), ("B", 23), ("C", 37))      # three different tufts take turns along a row (name, random seed)


def seg_dist(p1, q1, p2, q2):
    """smallest distance between the segments p1-q1 and p2-q2"""
    d1 = [q1[i] - p1[i] for i in range(3)]
    d2 = [q2[i] - p2[i] for i in range(3)]
    r = [p1[i] - p2[i] for i in range(3)]
    a = sum(v * v for v in d1)
    e_ = sum(v * v for v in d2)
    f = sum(d2[i] * r[i] for i in range(3))
    cc = sum(d1[i] * r[i] for i in range(3))
    b = sum(d1[i] * d2[i] for i in range(3))
    den = a * e_ - b * b
    s = min(1.0, max(0.0, (b * f - cc * e_) / den)) if den > 1e-12 else 0.0
    t = (b * s + f) / e_
    if t < 0.0:
        t, s = 0.0, min(1.0, max(0.0, -cc / a))
    elif t > 1.0:
        t, s = 1.0, min(1.0, max(0.0, (b - cc) / a))
    return math.sqrt(sum((p1[i] + d1[i] * s - p2[i] - d2[i] * t) ** 2 for i in range(3)))


def tuft_place(M, q, k=0):
    """canonical tuft frame (X' = tuft axis, Z' = along the row, origin = hole mouth centre) -> part frame, tuft k of row 1"""
    Ln = math.radians(M["tuft_lean"])
    x = q[0] * math.cos(Ln) - q[2] * math.sin(Ln) + M["d_core"] / 2
    z = q[0] * math.sin(Ln) + q[2] * math.cos(Ln) + M["tuft_z0"] + k * M["tuft_pitch"]
    xx, yy = rotz((x, q[1]), M["tuft_ang_seed"] - 360.0 * k * M["tuft_pitch"] / M["twist_lead"])
    return (xx, yy, z)


def make_filaments(M, seed):
    """61 straight filaments of one tuft in the canonical frame: start point, unit direction, length.
    Start: the plain fan (direction angle proportional to the position in the root) - its filaments move apart all
    the way, so they cannot touch. Then every filament gets a random change of direction and of tip radius, kept only
    when it still clears all the others by FIL_GAP outside the root; so no two filaments of a tuft ever cut each other
    and the root plug is the only thing each one is united with. Lengths put every tip near the brush diameter."""
    import random
    rng = random.Random(seed)
    rh = M["d_tuft_hole"] / 2
    pitch = FIL_PITCH * rh
    ph = rng.uniform(0.0, 60.0)
    pts = [(0.0, 0.0)]
    for k in range(1, N_RING + 1):
        for s in range(6):
            a0, a1 = math.radians(60.0 * s + ph), math.radians(60.0 * (s + 2) + ph)
            for j in range(k):
                pts.append((k * pitch * math.cos(a0) + j * pitch * math.cos(a1), k * pitch * math.sin(a0) + j * pitch * math.sin(a1)))
    rmax = N_RING * pitch
    x0 = M["tuft_root_h"] - SINK
    Ln = math.radians(M["tuft_lean"])
    Rc, rt = M["d_core"] / 2, M["d_brush"] / 2
    clear = M["d_fil"] + FIL_GAP

    def radius(q):
        return math.hypot(q[0] * math.cos(Ln) - q[2] * math.sin(Ln) + Rc, q[1])

    def make(i, au, av, target):
        u, v = pts[i]
        d = (1.0, math.tan(math.radians(av)), math.tan(math.radians(au)))
        n = math.sqrt(sum(t * t for t in d))
        d = tuple(t / n for t in d)
        st = (x0, v, u)
        lo, hi = 1.0, 60.0
        for _ in range(50):
            mid = (lo + hi) / 2
            if radius(tuple(st[j] + d[j] * mid for j in range(3))) < target:
                lo = mid
            else:
                hi = mid
        h = (lo + hi) / 2
        seg = (tuple(st[j] + d[j] * (SINK / d[0]) for j in range(3)), tuple(st[j] + d[j] * h for j in range(3)))
        return dict(i=i, start=st, dir=d, h=h, au=au, av=av, seg=seg, jittered=False)

    def free(cand, fils):
        return all(o["i"] == cand["i"] or seg_dist(cand["seg"][0], cand["seg"][1], o["seg"][0], o["seg"][1]) >= clear for o in fils)

    fils = [make(i, FAN_U * pts[i][0] / rmax, LEAN_T + FAN_V * pts[i][1] / rmax, rt) for i in range(len(pts))]
    worst = min(seg_dist(a["seg"][0], a["seg"][1], b["seg"][0], b["seg"][1]) for a in fils for b in fils if a["i"] < b["i"])
    if worst < clear:
        raise RuntimeError("plain fan too tight: smallest axis distance %.4f < %.4f" % (worst, clear))
    for sc in (1.0, 1.0, 1.0, 0.7, 0.7, 0.5, 0.5, 0.35):
        idx = [i for i in range(len(fils)) if not fils[i]["jittered"]]
        rng.shuffle(idx)
        for i in idx:
            u, v = pts[i]
            for attempt in range(25):
                au = max(-MAX_U, min(MAX_U, FAN_U * u / rmax + rng.gauss(0.0, JIT_U * sc)))
                av = LEAN_T + FAN_V * v / rmax + rng.gauss(0.0, JIT_V * sc)
                cand = make(i, au, av, rt + rng.uniform(*TIP_JIT))
                if free(cand, fils):
                    cand["jittered"] = True
                    fils[i] = cand
                    break
    return fils


def stage_f(c):
    """Bristles as fine filaments: three tuft variants (root plug + 61 thin cylinders each, built upright at the
    origin), leaned / placed / clocked by Move Object, then patterned along the helix (every third position each)."""
    p, e, M = c.part, c.e, c.M
    e("d_fil", 0.15, "bristle filament diameter")
    e("tuft_root_h", 1.0, "packed root of a tuft: height above the land, along the tuft axis")
    nxh.expr(p, "fil_len", "(d_brush/2-d_core/2)/cos(tuft_lean)", "mm", "length of the tuft axis from the land to the brush diameter")
    L0 = (M["d_brush"] / 2 - M["d_core"] / 2) / math.cos(math.radians(M["tuft_lean"]))
    M["fil_len"] = L0
    rh, dep, dh = M["d_tuft_hole"] / 2, M["tuft_hole_depth"], M["d_tuft_hole"]
    c.notes["tufts"] = {"filaments_per_tuft": 1 + 3 * N_RING * (N_RING + 1), "fan_along_row_deg": FAN_U, "fan_across_deg": FAN_V,
                        "random_sigma_deg": [JIT_U, JIT_V], "sideways_lean_deg": LEAN_T, "tip_radius_scatter": list(TIP_JIT), "smallest_gap": FIL_GAP, "variants": {}}
    c.tufts, groups = [], []
    for vi, (vn, seed) in enumerate(VARIANTS):
        fils = make_filaments(M, seed)
        f, tuft = nxh.cylinder(p, ("-tuft_hole_depth", 0, 0), X, "d_tuft_hole", "tuft_hole_depth+tuft_root_h")
        f.SetName("TUFT_%s_ROOT" % vn)
        feats = [f]
        v_exp = math.pi * rh * rh * (dep + M["tuft_root_h"])
        for k, fl in enumerate(fils):
            st, d = fl["start"], fl["dir"]
            ff, _ = nxh.cylinder(p, ("tuft_root_h-%g" % SINK, "%.6f*d_tuft_hole" % (st[1] / dh), "%.6f*d_tuft_hole" % (st[2] / dh)), d,
                                 "d_fil", "fil_len*%.6f" % (fl["h"] / L0), op=BOOL.Unite, target=tuft)
            ff.SetName("TUFT_%s_FILAMENT_%02d" % (vn, k + 1))
            feats.append(ff)
            v_exp += math.pi * M["d_fil"] ** 2 / 4 * (fl["h"] - SINK / d[0])
        v_t = c.vol(tuft)
        c.chk("TUFT_%s: root + 61 filaments, volume" % vn, v_t, v_exp, 0.01 * v_exp)
        ex = {k_: v for k_, v in nxh.examine_geometry(p, tuft).items() if v}
        c.chk.true("TUFT_%s: one solid, Examine Geometry clean" % vn, tuft.IsSolidBody and not ex, ex)
        m1 = nxf.move_object(p, [tuft], "angle", "-tuft_lean", vec=Y, origin=(0, 0, 0))
        m1.SetName("TUFT_%s_LEAN" % vn)
        m2 = nxf.move_object(p, [tuft], "delta", ("d_core/2", "0", "tuft_z0+%d*tuft_pitch" % vi))
        m2.SetName("TUFT_%s_PLACE" % vn)
        m3 = nxf.move_object(p, [tuft], "angle", "tuft_ang_seed-%d*360*tuft_pitch/twist_lead" % vi, vec=Z, origin=(0, 0, 0))
        m3.SetName("TUFT_%s_CLOCK" % vn)
        # placement probes: centre of the root's bottom face, tip centre of the middle filament
        qb = tuft_place(M, (-dep, 0.0, 0.0), vi)
        c.chk("TUFT_%s: root bottom centre where the hole bottom is" % vn, on_body(c, tuft, qb), 0.0, 2e-3)
        c.chk("TUFT_%s: root bottom centre on the core (hole %d of row 1)" % (vn, vi + 1), on_body(c, c.core, qb), 0.0, 2e-3)
        f0 = fils[0]
        qt = tuft_place(M, tuple(f0["start"][j] + f0["dir"][j] * f0["h"] for j in range(3)), vi)
        c.chk("TUFT_%s: tip centre of the middle filament" % vn, on_body(c, tuft, qt), 0.0, 2e-3)
        tips = [math.hypot(*tuft_place(M, tuple(fl["start"][j] + fl["dir"][j] * fl["h"] for j in range(3)), vi)[:2]) for fl in fils]
        cnt = "ceiling((n_tuft-%d)/3)" % vi
        pf1, cp1 = nxf.pattern_geometry(p, [tuft], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="2"))
        pf1.SetName("TUFT_%s_ROW_2" % vn)
        pf2, cp2 = helix_copies(c, tuft, cnt, 3)
        pf2.SetName("TUFTS_%s_ROW_1" % vn)
        pf3, cp3 = helix_copies(c, cp1[0], cnt, 3)
        pf3.SetName("TUFTS_%s_ROW_2" % vn)
        mine = [tuft] + list(cp1) + list(cp2) + list(cp3)
        c.chk.true("TUFT_%s: 18 bodies (9 per row)" % vn, len(mine) == 18, len(mine))
        c.chk("TUFT_%s: all copies have the seed volume" % vn, sum(c.vol(b) for b in mine), 18 * v_t, 0.02)
        c.tufts += mine
        groups.append((vn, feats))
        c.notes["tufts"]["variants"][vn] = {"seed": seed, "volume": v_t, "length_min_max": [min(fl["h"] for fl in fils), max(fl["h"] for fl in fils)],
                                            "tip_radius_min_max": [min(tips), max(tips)],
                                            "angle_along_row_min_max": [min(fl["au"] for fl in fils), max(fl["au"] for fl in fils)],
                                            "angle_across_min_max": [min(fl["av"] for fl in fils), max(fl["av"] for fl in fils)]}
    for b in c.tufts:
        b.SetName("BRISTLE_TUFT")
    n_s = len(nxh.solids(p))
    c.chk.true("54 tufts + flaps + core", len(c.tufts) == 54 and n_s == 55 + len(getattr(c, "flaps", [])), (len(c.tufts), n_s))
    if getattr(c, "flaps", None):
        seeds = c.tufts[0:1] + c.tufts[18:19] + c.tufts[36:37]
        g = min(nxh.min_dist(t, fb) for t in seeds for fb in c.flaps)
        c.notes["tufts"]["clearance_seed_tufts_to_flaps"] = g
        c.chk.true("seed tufts clear the flaps (smallest gap %.2f mm)" % g, g > 0.5, g)
    for vn, feats in groups:
        try:
            nxf.feature_group(p, feats, "TUFT_%s" % vn)
        except Exception as ex_:                                       # noqa: BLE001
            c.notes["tufts"]["group_" + vn] = "not grouped: " + str(ex_)[:120]
    c.chk.true("no feature errors after stage F", not nxh.feature_errors(p), nxh.feature_errors(p))


# =========================================================================================== stage Z
def sort_bodies(c):
    """core / flaps / tufts by volume (tags of pattern copies change when a count is edited)"""
    p = c.part
    c.flaps, c.tufts = [], []
    for b in nxh.solids(p):
        if b.Tag == c.core.Tag:
            continue
        (c.flaps if c.vol(b) > 300.0 else c.tufts).append(b)


def colour(bodies, rgb):
    K = NXOpen.UF.UFConstants
    cid = UFS.Disp.AskClosestColor(K.UF_DISP_rgb_model, [float(v) for v in rgb], K.UF_DISP_CCM_EUCLIDEAN_DISTANCE)
    dm = nxh.S.DisplayManager.NewDisplayModification()
    try:
        dm.ApplyToAllFaces = True
        dm.NewColor = cid
        dm.Apply(list(bodies))
    finally:
        dm.Dispose()
    return cid


def stage_z(c):
    p, M = c.part, c.M
    res = c.res
    sort_bodies(c)
    ex = nxh.examine_geometry(p, c.core)
    res["examine_core"] = ex
    c.chk.true("Examine Geometry: core clean", not any(ex.values()), {k: v for k, v in ex.items() if v})
    bad = sum(1 for b in c.flaps + c.tufts if any(nxh.examine_geometry(p, b).values()))
    c.chk.true("Examine Geometry: %d flaps and %d tufts clean" % (len(c.flaps), len(c.tufts)), bad == 0, bad)
    res["volume_core"] = c.vol(c.core)
    res["volume_flaps"] = sum(c.vol(b) for b in c.flaps)
    res["volume_tufts"] = sum(c.vol(b) for b in c.tufts)
    res["bbox_core"] = nxh.bbox(c.core)
    res["face_census_core"] = nxh.face_census(c.core)
    res["faces_total"] = sum(len(b.GetFaces()) for b in nxh.solids(p))
    nxh.save(p)

    # ---- regeneration test: one master at a time, update, check, back
    v_nom, vf_nom, vt_nom = res["volume_core"], res["volume_flaps"], res["volume_tufts"]
    reg = []

    def run(name, new, check):
        old = p.Expressions.FindObject(name).RightHandSide
        row = {"name": name, "from": old, "to": new}
        t = time.time()
        try:
            nxh.set_expr(p, name, new)
            nxh.update()
            errs = nxh.feature_errors(p)
            row["errors"] = {k: str(v)[:160] for k, v in errs.items()} if errs else {}
            row["solids"] = len(nxh.solids(p))
            sort_bodies(c)
            try:
                row["check"] = check()
            except Exception as ex_:                                   # noqa: BLE001
                row["check"] = "EXC " + str(ex_)[:200]
        except Exception as ex_:                                       # noqa: BLE001
            row["exception"] = str(ex_)[:300]
        finally:
            nxh.set_expr(p, name, old)
            nxh.update()
            sort_bodies(c)
        row["v_back"] = [c.vol(c.core), sum(c.vol(b) for b in c.flaps), sum(c.vol(b) for b in c.tufts)]
        back = all(abs(a - b) <= 1e-6 * b for a, b in zip(row["v_back"], (v_nom, vf_nom, vt_nom)))
        row["seconds"] = round(time.time() - t, 1)
        row["ok"] = (not row.get("errors")) and "exception" not in row and back and not str(row.get("check", "")).startswith(("EXC", "FAIL"))
        reg.append(row)
        c.chk.true("regen %s %s -> %s: no errors, check ok, volumes return" % (name, old, new), row["ok"], {k: v for k, v in row.items() if k != "name"})

    def near(val, exp, tol):
        return ("ok " if abs(val - exp) <= tol else "FAIL ") + "%.4f (expected %.4f +- %g)" % (val, exp, tol)

    def both(*parts):
        return ("FAIL " if any(s.startswith("FAIL") for s in parts) else "ok ") + " ; ".join(parts)

    def with_m(**kw):
        m2 = dict(M)
        m2.update(kw)
        return m2

    R = M["d_core"] / 2
    w2 = M["slot_w"] / 2
    n_solid = 1 + len(c.flaps) + len(c.tufts)
    vfl = vf_nom / 4
    a250 = M["slot_ang0"] - 360.0 * (120.0 - M["z_core0"]) / 250.0
    run("twist_lead", 250, lambda: both(near(on_body(c, c.core, rotz((6.6, w2), a250) + (120.0,)), 0.0, 0.01),
                                        near(min(on_body(c, b, rotz((11.0, M["flap_t"] / 2), a250) + (120.0,)) for b in c.flaps), 0.0, 0.01),
                                        near(min(nxh.min_dist(b, c.core) for b in c.flaps), c.notes["flap"]["clearance_to_core"], 0.02)))
    run("slot_w", 1.5, lambda: near(v_nom - c.vol(c.core), 4 * (0.25 * (R - M["slot_neck_r"]) + 0.125 * (M["slot_neck_r"] - M["slot_floor_r"])) * (M["h_total"] - M["z_core0"]), 20.0))
    run("h_total", 160, lambda: both(near(nxh.bbox(c.core)[5], 160.0, 0.2), near(max(flap_end_planes(b)[1] for b in c.flaps), 160.0 - M["flap_end_gap"], 1e-4)))
    # a thicker web adds its own volume, less the part of it that lies inside the bead (already bead material)
    ov = c.notes["flap"]["web_and_bead_overlap"]
    run("flap_t", 1.1, lambda: near(sum(c.vol(b) for b in c.flaps) / 4 - vfl, flap_volumes(with_m(flap_t=1.1), M["h_total"] - M["flap_end_gap"])[0] - flap_volumes(M, M["h_total"] - M["flap_end_gap"])[0]
                                    - ov * (1.1 / M["flap_t"] - 1.0), 6.0))
    run("bead_t", 1.8, lambda: near(sum(c.vol(b) for b in c.flaps) / 4 - vfl, flap_volumes(with_m(bead_t=1.8), M["h_total"] - M["flap_end_gap"])[1] - flap_volumes(M, M["h_total"] - M["flap_end_gap"])[1], 12.0))
    o18 = flap_lines(with_m(flap_r_a=18.0))[0]
    run("flap_r_a", 18, lambda: near(min(on_body(c, b, rotz((interp(o18, 40.0), 0.0), M["slot_ang0"] + tw(c, 40.0)) + (40.0,)) for b in c.flaps), 0.0, 0.006))
    run("n_tuft", 20, lambda: both(near(float(len(nxh.solids(p))), n_solid - 14.0, 0.0), near(c.vol(c.core) - v_nom, 14 * c.notes["tuft_hole_volume_each"], 0.05)))
    run("tuft_pitch", 5.5, lambda: near(max(nxh.bbox(b)[5] for b in c.tufts) - M["tuft_z0"], 26 * 5.5 + 12.0, 9.0))
    run("tuft_lean", 30, lambda: both(near(on_body(c, c.core, tuft_place(with_m(tuft_lean=30.0), (-M["tuft_hole_depth"], 0.0, 0.0), 0)), 0.0, 3e-3),
                                      near(min(on_body(c, b, tuft_place(with_m(tuft_lean=30.0), (-M["tuft_hole_depth"], 0.0, 0.0), 0)) for b in c.tufts), 0.0, 3e-3)))
    run("d_brush", 40, lambda: near(sum(c.vol(b) for b in c.tufts) / vt_nom, 1.0 + (vt_nom / 54 - math.pi * (M["d_tuft_hole"] / 2) ** 2 * (M["tuft_hole_depth"] + M["tuft_root_h"])) / (vt_nom / 54)
                                    * ((20.0 - R) / (M["d_brush"] / 2 - R) - 1.0), 0.02))
    run("d_fil", 0.14, lambda: near(sum(c.vol(b) for b in c.tufts) / 54 - math.pi * (M["d_tuft_hole"] / 2) ** 2 * (M["tuft_hole_depth"] + M["tuft_root_h"]),
                                    (vt_nom / 54 - math.pi * (M["d_tuft_hole"] / 2) ** 2 * (M["tuft_hole_depth"] + M["tuft_root_h"])) * (0.14 / M["d_fil"]) ** 2, 0.5))
    res["regeneration"] = reg
    res["volumes_after_regen"] = [c.vol(c.core), sum(c.vol(b) for b in c.flaps), sum(c.vol(b) for b in c.tufts)]
    c.chk("core volume back at nominal after the regeneration test (relative)", res["volumes_after_regen"][0] / v_nom, 1.0, 1e-6)
    c.chk("flap volume back at nominal after the regeneration test (relative)", res["volumes_after_regen"][1] / vf_nom, 1.0, 1e-6)
    c.chk("tuft volume back at nominal after the regeneration test (relative)", res["volumes_after_regen"][2] / vt_nom, 1.0, 1e-6)
    c.chk.true("1 core + 4 flaps + 54 tufts, no feature errors at the end", (len(c.flaps), len(c.tufts)) == (4, 54) and not nxh.feature_errors(p),
               (len(c.flaps), len(c.tufts), nxh.feature_errors(p)))
    ex = nxh.examine_geometry(p, c.core)
    c.chk.true("Examine Geometry: core clean after the regeneration test", not any(ex.values()), {k: v for k, v in ex.items() if v})
    finish(c)


def finish(c):
    """names, colours, save, STL for the figures, STEP AP242 + re-import"""
    p, res = c.part, c.res
    sort_bodies(c)
    c.core.SetName("CORE")
    for b in c.flaps:
        b.SetName("SILICONE_FLAP")
    for b in c.tufts:
        b.SetName("BRISTLE_TUFT")
    try:
        res["colours"] = {"core": colour([c.core], (0.16, 0.16, 0.17)), "flaps": colour(c.flaps, (0.42, 0.42, 0.44)), "tufts": colour(c.tufts, (0.03, 0.03, 0.03))}
    except Exception:                                                  # noqa: BLE001
        res["colours"] = "not set: " + traceback.format_exc()[-300:]
    nxh.save(p)
    res["stl_core"] = stl_many([c.core], os.path.join(OUT, NAME + "_core.stl"), chord=0.005)
    if c.flaps:
        res["stl_flaps"] = stl_many(c.flaps, os.path.join(OUT, NAME + "_flaps.stl"), chord=0.005)
    if c.tufts:
        res["stl_tufts"] = stl_many(c.tufts, os.path.join(OUT, NAME + "_tufts.stl"), chord=0.004, max_edge=3.0)
    if "z" not in STAGES:
        return
    stp = os.path.join(OUT, NAME + ".step")
    nxf.step_export(p, stp, timeout=600)
    res["step_size"] = os.path.getsize(stp)
    n = len(nxh.solids(p))
    rt = nxf.step_roundtrip_check(stp, OUT, name="step_roundtrip", restore=p, part=p)
    res["step_roundtrip"] = {k: rt.get(k) for k in ("schema", "solids", "volume", "max_rel", "match", "healthy", "manifold_solid_brep")}
    res["step_roundtrip"]["examine_findings"] = sum(sum(e.values()) for e in rt.get("examine") or [])
    kinds = {"core": [], "flaps": [], "tufts": []}
    for r_ in rt.get("per_body") or []:
        kinds["core" if r_["expected"] > 10000 else ("flaps" if r_["expected"] > 300 else "tufts")].append(r_)
    res["step_roundtrip"]["max_rel_by_kind"] = {k: max((r_["rel"] for r_ in v), default=None) for k, v in kinds.items()}
    ok = all(r_["rel"] <= 1e-4 for r_ in kinds["core"] + kinds["tufts"])
    c.chk.true("STEP AP242 re-import: %d solids, Examine Geometry clean, core and tuft volumes match (1e-4)" % n,
               bool(rt.get("healthy")) and rt.get("solids") == n and ok and len(kinds["core"]) == 1 and len(kinds["tufts"]) == len(c.tufts), res["step_roundtrip"])
    # the flaps are 0.94 mm thick twisted sheets: a relative volume says little (2 x offset / thickness), so the volume
    # change of the re-imported flaps is turned into the uniform face offset it corresponds to and held against the
    # modelling tolerance; the raw relative number is kept in the result
    if kinds["flaps"]:
        area = sum(nxh.mass(p, [b]).get("area", 0.0) for b in c.flaps)
        dv = sum(r_["got"] - r_["expected"] for r_ in kinds["flaps"])
        res["step_roundtrip"]["flaps"] = {"n": len(kinds["flaps"]), "dV": dv, "rel": dv / sum(r_["expected"] for r_ in kinds["flaps"]), "area": area,
                                          "equivalent_face_offset": dv / area if area else None}
        c.chk("STEP re-import, %d flaps: volume change as a uniform face offset (mm) within the 0.01 modelling tolerance" % len(kinds["flaps"]),
              dv / area if area else 1.0, 0.0, 0.01)


def resume(c):
    """rebuild the journal's context on a part that already holds the core (stages A-D)"""
    p = c.part
    for ex in p.Expressions:
        try:
            c.M[ex.Name] = float(ex.Value)
        except Exception:                                              # noqa: BLE001
            pass
    feats = {}
    for f in p.Features.GetFeatures():
        if f.Name:
            feats[f.Name] = f
    c.dp0 = feats["DP_CORE0"].DatumPlane
    c.dax0 = feats["DA_CORE0_X"].DatumAxis
    c.day0 = feats["DA_CORE0_Y"].DatumAxis
    c.o0 = nxh.point(p, 0, 0, "z_core0")
    gs = [s for s in p.Sketches if s.Name == "SK_AXIS"]
    c.guide_feature = gs[0].Feature if gs else feats["SK_AXIS"]
    c.core = [b for b in nxh.solids(p) if b.Name == "CORE"][0]
    c.notes["tuft_hole_volume_each"] = math.pi * (c.M["d_tuft_hole"] / 2) ** 2 * c.M["tuft_hole_depth"]
    c.notes["resumed"] = True


# =========================================================================================== main
res = {"result": "FAIL", "stages": STAGES}
c = None
ALL = (("a", stage_a), ("b", stage_b), ("c", stage_c), ("d", stage_d), ("e", stage_e), ("f", stage_f), ("z", stage_z))
try:
    dst = os.path.join(OUT, NAME + ".prt")
    core_file = os.path.join(OUT, NAME + "_stage_d.prt")
    if "a" in STAGES:
        part = nxh.new_part(dst)
        c = Ctx(part)
    else:
        import shutil
        if os.path.exists(dst):
            os.remove(dst)
        shutil.copyfile(core_file, dst)
        part = nxh.open_part(dst)
        c = Ctx(part)
        resume(c)
    c.res = res
    for key, fn in ALL:
        if key not in STAGES:
            continue
        t = time.time()
        fn(c)
        c.say("stage %s done in %.1f s" % (key, time.time() - t))
        if key == "d":
            nxh.save(part)
            import shutil
            shutil.copyfile(dst, core_file)
    if "z" not in STAGES:
        res["volume_core"] = c.vol(c.core)
        res["examine_core"] = {k: v for k, v in nxh.examine_geometry(part, c.core).items() if v}
        if "e" in STAGES or "f" in STAGES:
            finish(c)
        else:
            nxh.save(part)
except Exception:
    res["error"] = traceback.format_exc()
if c is not None:
    rep = c.chk.report()
    res.update(rep)
    res["sketches"] = c.sk
    res["masters"] = {k: {"value": v, "comment": c.C.get(k, ("derived", "-"))[0], "unit": c.C.get(k, ("derived", "-"))[1]} for k, v in c.M.items()}
    res["notes"] = c.notes
    res["log"] = c.log
    try:
        res["features"] = [(x["name"], x["type"]) for x in nxh.feature_table(c.part) if not x["type"] == "EXTRACT_BODY"]
        res["n_features_top"] = len(nxh.top_features(c.part)[0])
        res["feature_errors"] = {k: str(v)[:200] for k, v in (nxh.feature_errors(c.part) or {}).items()}
    except Exception:
        res["features_exc"] = traceback.format_exc()[-400:]
    if "error" in res:
        res["result"] = "FAIL"
nxh.write_json(os.path.join(OUT, "build2_%s.json" % STAGES), res)
