p = r"C:\NX_MCP_WORKSPACE\dreame_brush\REPORT.md"
t = open(p, encoding="utf-8").read()
old = "13. Feature adları `SetName` ile verildi; parça arayüzde açılmadığı için gezginde nasıl göründüğü kontrol edilmedi."
new = ("13. Feature adları dosyada saklı (61 adımın 60'ı adlı, gövdeler `CORE` / `BRISTLE_TUFT`; teslim dosyasının kopyasından geri okundu); "
       "parça arayüzde açılmadığı için gezginde nasıl göründüğü kontrol edilmedi.")
assert old in t
t = t.replace(old, new)
old = "| STEP AP242 → NX'e geri okuma | 55 katı, en büyük bağıl hacim farkı 3,0·10⁻⁵, geri okunan 55 gövdede Examine Geometry bulgusu 0 |"
new = old + "\n| Teslim edilen `.prt` kopyasının yeniden açılıp okunması (as-found) | 61 feature, bastırılmış 0, hatalı 0; 55 katı (çekirdek 26 991,42 mm³, demet başına 84,93 mm³); 76 adlandırılmış ifade |"
assert old in t
t = t.replace(old, new)
open(p, "w", encoding="utf-8", newline="\n").write(t)
print("report patched")
