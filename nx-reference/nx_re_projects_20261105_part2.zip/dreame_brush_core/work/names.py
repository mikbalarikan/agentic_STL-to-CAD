"""Read back the custom feature names of the delivered part copy. -> out/asfound/names.json"""
import os, sys, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

SRC, OUT = sys.argv[1:3]
res = {"result": "FAIL"}
try:
    part = nxh.open_part(SRC)
    top, _n = nxh.top_features(part)
    rows = [(f.GetFeatureName(), f.Name) for f in top]
    res["named"] = sum(1 for a, b in rows if b)
    res["top"] = len(rows)
    res["rows"] = rows
    res["bodies"] = sorted({b.Name for b in part.Bodies})
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "names.json"), res)
