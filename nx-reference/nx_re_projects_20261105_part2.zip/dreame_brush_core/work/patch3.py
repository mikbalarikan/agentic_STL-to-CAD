import ast
p = r"C:\NX_MCP_WORKSPACE\dreame_brush\build.py"
b = open(p, "rb").read()
if b[:3] == b"\xef\xbb\xbf":
    b = b[3:]
t = b.replace(b"\r\n", b"\n").decode("utf-8")


def rep(old, new, count=1):
    global t
    assert t.count(old) == count, (t.count(old), old[:70])
    t = t.replace(old, new)


# key notch: defined so that it overlaps the neck of the slot it widens (no sliver between the two cuts)
rep('''    e("notch_ang", 203.75, "idler-end key notch: direction of its centre line, deg", None)
    e("notch_w", 1.75, "key notch width")''',
    '''    e("notch_ang", 201.3, "idler-end key notch: direction of its centre line, deg (it overlaps the neck of the slot it widens)", None)
    e("notch_w", 2.25, "key notch width, measured from inside the slot neck to the far wall")''')
# helix pattern: ONE body per Pattern Geometry [Helix] (two bodies are refused: 'total number of instances must be greater than 1')
rep('''    nxh.expr(p, "n_row", 2, None, "tuft rows (equally spaced round the axis)")
    M["n_tuft"], M["n_row"] = 27, 2
''', '''    M["n_tuft"] = 27
''')
rep('''    pf1, cp1 = nxf.pattern_geometry(p, [tool], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="n_row"))
    pf1.SetName("TUFT_HOLE_TOOL_ROWS")
    pf2, cp2 = helix_copies(c, [tool] + list(cp1))
    pf2.SetName("TUFT_HOLE_TOOLS")
    n = 1 + len(cp1) + len(cp2)
    c.chk.true("54 hole tools", n == 54, n)
    v0 = c.vol(c.core)
    sf = nxh.subtract(p, c.core, tool_features=[f, pf1, pf2])''',
    '''    pf1, cp1 = nxf.pattern_geometry(p, [tool], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="2"))
    pf1.SetName("TUFT_HOLE_TOOL_ROW_2")
    pf2, cp2 = helix_copies(c, tool)
    pf2.SetName("TUFT_HOLE_TOOLS_ROW_1")
    pf3, cp3 = helix_copies(c, cp1[0])
    pf3.SetName("TUFT_HOLE_TOOLS_ROW_2")
    n = 1 + len(cp1) + len(cp2) + len(cp3)
    c.chk.true("54 hole tools", n == 54, n)
    v0 = c.vol(c.core)
    sf = nxh.subtract(p, c.core, tool_features=[f, pf1, pf2, pf3])''')
rep('''    pf1, cp1 = nxf.pattern_geometry(p, [tuft], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="n_row"))
    pf1.SetName("TUFT_ROWS")
    pf2, cp2 = helix_copies(c, [tuft] + list(cp1))
    pf2.SetName("TUFTS")
    c.tufts = [tuft] + list(cp1) + list(cp2)''',
    '''    pf1, cp1 = nxf.pattern_geometry(p, [tuft], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="2"))
    pf1.SetName("TUFT_ROW_2")
    pf2, cp2 = helix_copies(c, tuft)
    pf2.SetName("TUFTS_ROW_1")
    pf3, cp3 = helix_copies(c, cp1[0])
    pf3.SetName("TUFTS_ROW_2")
    c.tufts = [tuft] + list(cp1) + list(cp2) + list(cp3)''')
rep('''def helix_copies(c, bodies):''', '''def helix_copies(c, body):''')
rep('''        for body in bodies:
            b.GeometryToPattern.Add(body)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(p, before)''', '''        b.GeometryToPattern.Add(body)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(p, before)''')
ast.parse(t)
open(p, "w", encoding="utf-8", newline="\n").write(t)
print("patched ok")
