"""One-off: build2.py = stages A-D of build.py (core + tuft holes) + the round-2 tail (flaps, fine bristles).
After this, build2.py is edited by hand; do not run again."""
import os

WS = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(WS, "build.py"), encoding="utf-8").read()
tail = open(os.path.join(WS, "build2_tail.py"), encoding="utf-8").read()
cut = src.index("    # tufts: cylinder in the hole (to 1 mm above the land)")
head = src[:cut]


def sub(a, b, count=1):
    global head
    if head.count(a) != count:
        raise SystemExit("expected %d x %r, found %d" % (count, a[:60], head.count(a)))
    head = head.replace(a, b)


sub(head[:head.index('import os, sys, math, time, traceback')], '''"""Dreame main brush WITH bristles: core + 4 silicone flaps + 2 rows of fine-filament bristle tufts.
Native parametric build (NX 2206 journal, headless).

    run_journal build2.py -args <out dir> [stages, default abcdefz]

Stages: a b c d = the core with the tuft holes (unchanged from build.py, 2026-10-08), e = silicone flaps,
f = bristle tufts as fine filaments, z = checks, regeneration test, colours, STEP, STL.
Without "a" the journal continues on a copy of <name>_stage_d.prt (written after stage d).

Datum CSYS (= datum frame of the core scan, qa/T_bristles.json; the assembled scan is aligned to it, qa2/T_asm.json):
    Z  = brush axis, +Z towards the idler end;  z0 = underside of the drive-end flange;  X = straight edge of blade 0
Angles are unitless numbers in degrees, counter-clockwise about +Z seen from +Z; angles of twisted features are
given at z = z_core0. The core twists LEFT-hand: a feature at angle a at z_core0 sits at
a - 360 * (z - z_core0) / twist_lead at height z.
"""
''')
sub('LAST = sys.argv[2] if len(sys.argv) > 2 else "z"', 'STAGES = sys.argv[2] if len(sys.argv) > 2 else "abcdefz"')
sub('NAME = "dreame_brush_core_with_bristles"', 'NAME = "dreame_brush_with_bristles"')
sub("    c.guide = G\n", "    c.guide = G\n    c.guide_feature = G.feature\n")
sub('    """Bristles: 2 helical rows of tuft holes in the core, and the tufts as separate solids."""',
    '    """Bristles, part 1: 2 helical rows of tuft holes in the core (the tufts themselves: stage F)."""')
sub('    e("d_tuft_tip", 3.2, "tuft diameter at the tip (ASSUMED flare; the scanned tufts splay and merge)")\n', "")
sub('    rh, rt, dep, z0 = M["d_tuft_hole"] / 2, M["d_tuft_tip"] / 2, M["tuft_hole_depth"], M["tuft_z0"]',
    '    rh, dep, z0 = M["d_tuft_hole"] / 2, M["tuft_hole_depth"], M["tuft_z0"]')
open(os.path.join(WS, "build2.py"), "w", encoding="utf-8", newline="\n").write(head + tail)
print("build2.py written:", len((head + tail).splitlines()), "lines")
