    c.core.SetName("CORE")
    c.chk.true("no feature errors after stage D", not nxh.feature_errors(p), nxh.feature_errors(p))


def helix_copies(c, body, count="n_tuft", every=1):
    """Pattern Geometry, helix layout along the core twist; every = 3 takes each third tuft position."""
    p = c.part
    before = list(p.Bodies)
    b = p.Features.CreatePatternGeometryBuilder(NXOpen.Features.PatternGeometry.Null)
    try:
        psv = b.PatternService
        psv.PatternType = GU.PatternDefinition.PatternEnum.Helix
        hd = psv.HelixDefinition
        hd.RotationAxis = nxh.axis(p, (0, 0, 0), Z)
        hd.DirectionType = GU.HelixPatternDirectionTypes.Lefthand
        hd.SizeOption = type(hd).SizeOptions.CountAngleDistance
        hd.CountOfInstances.RightHandSide = count
        hd.AnglePitch.RightHandSide = "%d*360*tuft_pitch/twist_lead" % every
        hd.DistancePitch.RightHandSide = "%d*tuft_pitch" % every
        b.GeometryToPattern.Add(body)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(p, before)


# =========================================================================================== stage E
def core_sketch(c, name):
    """Sketch on DP_CORE0 in the frame of the twisted cuts (u radial at angle 0, v tangential)."""
    return ps.Sketch(c.part, c.dat, "xy", name, on=c.dp0, origin=c.o0, hax=c.dax0, vax=c.day0, shift=(0.0, 0.0, c.M["z_core0"]))


def guide_sec(c):
    return nxh.section_feature(c.part, [c.guide_feature], (0, 0, c.M["z_core0"]), curves_only=True)


def flap_lines(M):
    """Flap outline in (z, r) without the corner rounds: outer edge of the bead, edge of the web under it."""
    z1 = M["h_total"] - M["flap_end_gap"]
    zt = z1 - M["flap_taper_len"]
    ze = z1 + 1.0
    re = M["flap_r_end"] + (M["flap_r_end"] - M["flap_r_b"]) / M["flap_taper_len"]
    bl = M["bead_len"]
    outer = [(M["flap_step_z0"] - 0.25, M["flap_foot_r1"] + 0.2), (M["flap_step_z1"], M["flap_r_a"]), (zt, M["flap_r_b"]), (ze, re)]
    web = [(M["flap_z0"], M["flap_foot_r0"]), (M["flap_step_z0"], M["flap_foot_r1"]), (M["flap_step_z1"], M["flap_r_a"] - bl / 2),
           (zt, M["flap_r_b"] - bl / 2), (ze, re - bl / 2)]
    return outer, web, z1, zt, ze, re


def interp(line, z):
    for (za, ra), (zb, rb) in zip(line[:-1], line[1:]):
        if za <= z <= zb:
            return ra + (rb - ra) * (z - za) / (zb - za)
    return None


def strip_seg(t2, r):
    """integral of sqrt(r^2 - y^2) over |y| <= t2"""
    return t2 * math.sqrt(r * r - t2 * t2) + r * r * math.asin(t2 / r)


def flap_volumes(M, z_hi=None):
    """(web, bead) volumes by integration over z of the section area inside the envelopes (corner rounds, bead
    corner rounds and shoulder chamfers left out). z_hi: upper end (default: the envelopes' own end, 1 mm past)."""
    outer, web, z1, zt, ze, re = flap_lines(M)
    z_hi = ze if z_hi is None else z_hi
    t2, b2 = M["flap_t"] / 2, M["bead_t"] / 2
    nr, rf = M["slot_neck_r"], M["slot_floor_r"] + M["flap_foot_gap"]
    a_foot = (M["flap_t"] + M["flap_foot_w"]) / 2 * (nr - rf)
    n = 6000
    vw = vb = 0.0
    za = M["flap_z0"]
    for i in range(n):
        z = za + (z_hi - za) * (i + 0.5) / n
        dz = (z_hi - za) / n
        vw += (a_foot + strip_seg(t2, interp(web, z)) - 2 * t2 * nr) * dz
        ro = interp(outer, z)
        if ro is not None:
            vb += (strip_seg(b2, ro) - strip_seg(b2, ro - M["bead_len"])) * dz
    return vw, vb


def stage_e(c):
    """Silicone flaps, one in every T-slot. A twisted blank (web + dovetail foot) and a twisted bead blank are each cut
    to the measured (r, z) outline by a revolved envelope, the bead corners are rounded, the flap is patterned."""
    p, e, M = c.part, c.e, c.M
    R = M["d_core"] / 2
    e("flap_t", 0.94, "silicone flap: web thickness")
    e("flap_foot_w", 2.0, "flap: width of the dovetail foot at the slot floor (ASSUMED: hidden in the slot)")
    e("flap_foot_gap", 0.1, "flap: gap between the foot and the slot floor (ASSUMED)")
    e("bead_t", 1.44, "flap: thickness of the bead along the free edge")
    e("bead_len", 1.5, "flap: radial length of the bead")
    e("bead_tip_R", 0.6, "flap: round on the two outer corners of the bead")
    e("bead_step", 0.22, "flap: shoulder chamfer where the bead meets the web, across the thickness")
    e("bead_ramp", 0.45, "flap: shoulder chamfer where the bead meets the web, along the flap")
    e("flap_z0", 6.8, "flap: lower end (just above the drive blades)")
    e("flap_end_gap", 1.75, "flap: upper end stays this far below the idler end face")
    e("flap_taper_len", 21.7, "flap: axial length of the end taper")
    e("flap_foot_r0", 14.5, "flap outline: radius at the lower end (plain part, no bead)")
    e("flap_foot_r1", 15.35, "flap outline: radius where the step to the full height starts")
    e("flap_step_z0", 12.8, "flap outline: the step starts at this height")
    e("flap_step_z1", 14.4, "flap outline: the step ends, full height reached")
    e("flap_r_a", 17.1, "flap outline: tip radius at the top of the step (largest radius)")
    e("flap_r_b", 16.25, "flap outline: tip radius where the end taper starts")
    e("flap_r_end", 9.1, "flap outline: tip radius at the upper end")
    e("flap_step_R", 1.0, "flap outline: round at the top of the step")
    e("flap_end_R", 25.0, "flap outline: round between the long edge and the end taper")
    t2, b2, bl = M["flap_t"] / 2, M["bead_t"] / 2, M["bead_len"]
    rblank = M["flap_r_a"] + 1.5
    L = M["h_total"] + 1 - M["z_core0"]
    outer, web, z1, zt, ze, re = flap_lines(M)
    Z1, ZT, ZE = "h_total-flap_end_gap", "h_total-flap_end_gap-flap_taper_len", "h_total-flap_end_gap+1"
    RE = "flap_r_end+(flap_r_end-flap_r_b)/flap_taper_len"
    c.notes["flap"] = {}

    def twisted(S, help_uv, name):
        f = nb.swept(p, [S.section(None, help_uv)], [guide_sec(c)], orientation="angular",
                     angles=("-slot_ang0", "-slot_ang0+twist_sweep"), solid=True)
        f.SetName(name)
        b = f.GetBodies()[0]
        if not b.IsSolidBody:
            raise RuntimeError(name + ": swept body is not a solid")
        return f, b

    # ---- web blank: strip + dovetail foot, twisted with the slots
    nr, rf, fw2 = M["slot_neck_r"], M["slot_floor_r"] + M["flap_foot_gap"], M["flap_foot_w"] / 2
    fv = [(rblank, -t2, "flap_r_a+1.5", "flap_t/2"), (rblank, t2, None, "flap_t/2"), (nr, t2, "slot_neck_r", None),
          (rf, fw2, "slot_floor_r+flap_foot_gap", "flap_foot_w/2"), (rf, -fw2, None, "flap_foot_w/2"), (nr, -t2, "slot_neck_r", None)]
    S = core_sketch(c, "SK_FLAP")
    S.profile(fv)
    c.done(S)
    f, blank = twisted(S, (rblank, 0.0), "FLAP_BLANK")
    a_sec = M["flap_t"] * (rblank - nr) + (M["flap_t"] + M["flap_foot_w"]) / 2 * (nr - rf)
    c.chk("FLAP_BLANK volume = section area x length", c.vol(blank), a_sec * L, 0.004 * a_sec * L)

    # ---- envelope of the web: revolved (r, z) outline
    wv = [(3.0, M["flap_z0"], "3", "flap_z0"), (M["flap_foot_r0"], M["flap_z0"], "flap_foot_r0", None),
          (M["flap_foot_r1"], M["flap_step_z0"], "flap_foot_r1", "flap_step_z0"),
          (M["flap_r_a"] - bl / 2, M["flap_step_z1"], "flap_r_a-bead_len/2", "flap_step_z1"),
          (M["flap_r_b"] - bl / 2, zt, "flap_r_b-bead_len/2", ZT), (re - bl / 2, ze, RE + "-bead_len/2", ZE), (3.0, ze, None, None)]
    S = c.sketch("xz", "SK_FLAP_WEB_OUTLINE")
    S.profile(wv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (3.0, 80.0)), nxf.axis_from(p, c.dat.z))
    f.SetName("FLAP_WEB_ENVELOPE")
    env = f.GetBodies()[0]
    c.chk("FLAP_WEB_ENVELOPE volume = revolve of the outline", c.vol(env), revolve_volume([(v[0], v[1]) for v in wv]), 0.05)
    f = nxh.intersect(p, blank, [env])
    f.SetName("FLAP_WEB")
    vw, vb = flap_volumes(M)
    c.chk("FLAP_WEB = blank inside the envelope (numeric integral)", c.vol(blank), vw, 0.006 * vw)

    # ---- bead blank and its envelope (a band along the free edge)
    ri = R - 0.5
    bv = [(rblank, -b2, "flap_r_a+1.5", "bead_t/2"), (rblank, b2, None, "bead_t/2"), (ri, b2, "d_core/2-0.5", None), (ri, -b2, None, None)]
    S = core_sketch(c, "SK_BEAD")
    S.profile(bv)
    c.done(S)
    f, bead = twisted(S, (rblank, 0.0), "BEAD_BLANK")
    c.chk("BEAD_BLANK volume = section area x length", c.vol(bead), M["bead_t"] * (rblank - ri) * L, 0.004 * M["bead_t"] * (rblank - ri) * L)
    zs, r1s = M["flap_step_z0"] - 0.25, M["flap_foot_r1"] + 0.2
    ov = [(r1s, zs, "flap_foot_r1+0.2", "flap_step_z0-0.25"), (M["flap_r_a"], M["flap_step_z1"], "flap_r_a", "flap_step_z1"),
          (M["flap_r_b"], zt, "flap_r_b", ZT), (re, ze, RE, ZE), (re - bl, ze, RE + "-bead_len", None),
          (M["flap_r_b"] - bl, zt, "flap_r_b-bead_len", ZT), (M["flap_r_a"] - bl, M["flap_step_z1"], "flap_r_a-bead_len", "flap_step_z1"),
          (r1s - bl, zs, "flap_foot_r1+0.2-bead_len", None)]
    S = c.sketch("xz", "SK_BEAD_OUTLINE")
    S.profile(ov)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (r1s - bl / 2, zs)), nxf.axis_from(p, c.dat.z))
    f.SetName("BEAD_ENVELOPE")
    band = f.GetBodies()[0]
    c.chk("BEAD_ENVELOPE volume = revolve of the band", c.vol(band), revolve_volume([(v[0], v[1]) for v in ov]), 0.05)

    def ring_edges(body, r, z, tol=0.02):
        out = []
        for ed in body.GetEdges():
            bb = nxh.bbox(ed)
            if abs(bb[2] - z) < tol and abs(bb[5] - z) < tol and abs(bb[3] - r) < tol:
                out.append(ed)
        return out

    sets = [(ring_edges(band, M["flap_r_b"], zt) + ring_edges(band, M["flap_r_b"] - bl, zt), "flap_end_R"),
            (ring_edges(band, M["flap_r_a"], M["flap_step_z1"]) + ring_edges(band, M["flap_r_a"] - bl, M["flap_step_z1"]), "flap_step_R")]
    c.chk.true("BEAD_ENVELOPE: two corner rings found per radius", [len(s[0]) for s in sets] == [2, 2], [len(s[0]) for s in sets])
    v0 = c.vol(band)
    f = nxf.edge_blend(p, sets)
    f.SetName("BEAD_ENVELOPE_ROUNDS")
    c.notes["flap"]["band_round_dV"] = c.vol(band) - v0
    f = nxh.intersect(p, bead, [band])
    f.SetName("FLAP_BEAD")
    c.chk("FLAP_BEAD = bead blank inside the band (numeric integral, corner rounds left out)", c.vol(bead), vb, 0.02 * vb)

    def bead_edges(body):
        """helical edges of the bead: (outer corners, shoulder corners)"""
        cls = {}
        for fc in body.GetFaces():
            pt, n = nxh.face_mid_normal(fc)
            rr = math.hypot(pt[0], pt[1]) or 1e-9
            nrad = (n[0] * pt[0] + n[1] * pt[1]) / rr
            cls[fc.Tag] = "end" if abs(n[2]) > 0.95 else ("outer" if nrad > 0.6 else ("inner" if nrad < -0.6 else "side"))
        tip, sh = [], []
        for ed in body.GetEdges():
            ks = sorted(cls[fc.Tag] for fc in ed.GetFaces())
            if ks == ["outer", "side"]:
                tip.append(ed)
            elif ks == ["inner", "side"]:
                sh.append(ed)
        return tip, sh, cls

    def guarded(name, fn):
        """run one detail feature; undo it when it fails or leaves a body Examine Geometry complains about"""
        m = nxh.mark(name, False)
        v0_ = c.vol(bead)
        try:
            ft = fn()
            ft.SetName(name)
            ex = {k: v for k, v in nxh.examine_geometry(p, bead).items() if v}
            if ex or not bead.IsSolidBody:
                raise RuntimeError("body not clean: %s" % ex)
            return {"result": "built", "dV": c.vol(bead) - v0_}
        except Exception as ex_:                                       # noqa: BLE001
            nxh.undo_to(m)
            return {"result": "NOT BUILT: " + str(ex_)[:200]}

    tip, sh, cls = bead_edges(bead)
    c.notes["flap"]["bead_faces"] = {k: sum(1 for v in cls.values() if v == k) for k in ("outer", "inner", "side", "end")}
    info = {"edges": len(tip)}
    info.update(guarded("BEAD_TIP_ROUND", lambda: nxh.blend(p, tip, "bead_tip_R")))
    if info["result"] != "built":
        info["first_try"] = info["result"]
        tip, sh, cls = bead_edges(bead)
        info.update(guarded("BEAD_TIP_ROUND", lambda: nxh.blend(p, tip, "bead_tip_R", overflow=True)))
    c.notes["flap"]["BEAD_TIP_ROUND"] = info
    c.chk.true("BEAD_TIP_ROUND built on the %d outer corner edges" % info["edges"], info["result"] == "built", info)
    # shoulder chamfer: bead_step across the thickness, bead_ramp along the flap; NX chooses which face gets the
    # first offset, so the result is probed and the other order is taken when needed
    zq = 80.0
    q = rotz((interp(outer, zq) - bl + 0.3, b2), M["slot_ang0"] + tw(c, zq))
    info = {}
    for order in (("bead_step", "bead_ramp"), ("bead_ramp", "bead_step")):
        tip_, sh, cls = bead_edges(bead)
        m = nxh.mark("shoulder", False)
        r_ = guarded("BEAD_SHOULDER_CHAMFER", lambda: nxf.chamfer(p, sh, order[0], second=order[1]))
        r_["edges"], r_["order"] = len(sh), order
        if r_["result"] == "built":
            r_["probe"] = on_body(c, bead, (q[0], q[1], zq))
            if r_["probe"] > 0.02:                                     # the side face starts bead_ramp above the shoulder
                info = r_
                break
            nxh.undo_to(m)
            r_["result"] = "wrong leg order, undone"
        info = r_
    c.notes["flap"]["BEAD_SHOULDER_CHAMFER"] = info
    c.chk.true("BEAD_SHOULDER_CHAMFER built (%s edges)" % info.get("edges"), info.get("result") == "built", info)

    # ---- one flap: web + bead, cut to length
    v_parts = c.vol(blank) + c.vol(bead)
    f = nxh.unite(p, blank, [bead])
    f.SetName("FLAP")
    flap = blank
    c.notes["flap"]["web_and_bead_overlap"] = v_parts - c.vol(flap)
    fz, dpe = nxf.datum_plane(p, "offset", [c.dat.xy], Z1, "DP_FLAP_END")
    tf, _rev = nxf.trim_body(p, flap, keep_point=(0.0, 0.0, 90.0), datum_plane=dpe)
    tf.SetName("FLAP_END")
    bb = nxh.bbox(flap)
    c.chk("flap runs from flap_z0 to h_total - flap_end_gap (z min)", bb[2], M["flap_z0"], 0.05)
    c.chk("flap runs from flap_z0 to h_total - flap_end_gap (z max)", bb[5], z1, 0.05)
    ex = {k: v for k, v in nxh.examine_geometry(p, flap).items() if v}
    c.chk.true("FLAP: one solid, Examine Geometry clean", flap.IsSolidBody and not ex, ex)
    c.notes["flap"]["volume_one"] = c.vol(flap)
    c.notes["flap"]["faces"] = nxh.face_census(flap)
    # probes: web wall on the helix, tip flat on the outline, clearance to the core
    for zz in (30.0, 90.0, 150.0):
        qw = rotz((11.0, t2), M["slot_ang0"] + tw(c, zz))
        c.chk("flap web wall on the helix at z = %g" % zz, on_body(c, flap, (qw[0], qw[1], zz)), 0.0, 0.006)
    for zz in (40.0, 120.0):
        qt = rotz((interp(outer, zz), 0.0), M["slot_ang0"] + tw(c, zz))
        c.chk("flap tip on the outline at z = %g (r = %.3f)" % (zz, interp(outer, zz)), on_body(c, flap, (qt[0], qt[1], zz)), 0.0, 0.006)
    gap = nxh.min_dist(flap, c.core)
    c.notes["flap"]["clearance_to_core"] = gap
    c.chk.true("flap clears the core everywhere (smallest gap %.3f mm)" % gap, gap > 0.02, gap)
    pf, copies = nxf.pattern_geometry(p, [flap], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="n_slot"))
    pf.SetName("FLAPS")
    c.flaps = [flap] + list(copies)
    for b in c.flaps:
        b.SetName("SILICONE_FLAP")
    c.chk.true("4 flap bodies", len(c.flaps) == 4, len(c.flaps))
    c.chk("the four flaps have the same volume", sum(c.vol(b) for b in c.flaps), 4 * c.notes["flap"]["volume_one"], 0.01)
    gaps = [nxh.min_dist(b, c.core) for b in c.flaps]
    c.notes["flap"]["clearance_all"] = gaps
    c.chk.true("all flaps clear the core", min(gaps) > 0.02, gaps)
    c.chk.true("no feature errors after stage E", not nxh.feature_errors(p), nxh.feature_errors(p))


# =========================================================================================== stage F
N_RING = 4                          # hexagonal packing with 4 rings = 61 filaments per tuft
FIL_PITCH = 0.2                     # filament spacing in the root, as a share of d_tuft_hole / 2 it is 0.2
FAN_U, FAN_V = 15.0, 6.0            # half fan angle of the outermost filaments along the row / across it, deg
JIT_U, JIT_V = 2.5, 1.5             # random part of each filament direction (sigma), deg
LEAN_T = -7.0                       # common sideways lean of the tufts (clockwise seen from +Z), deg
TIP_JIT = (-0.55, 0.2)              # scatter of the tip radius about d_brush / 2, mm
SINK = 0.4                          # filaments start this far inside the root plug
VARIANTS = (("A", 11), ("B", 23), ("C", 37))      # three different tufts take turns along a row (name, random seed)


def seg_dist(p1, q1, p2, q2):
    """smallest distance between the segments p1-q1 and p2-q2"""
    d1 = [q1[i] - p1[i] for i in range(3)]
    d2 = [q2[i] - p2[i] for i in range(3)]
    r = [p1[i] - p2[i] for i in range(3)]
    a = sum(v * v for v in d1)
    e_ = sum(v * v for v in d2)
    f = sum(d2[i] * r[i] for i in range(3))
    cc = sum(d1[i] * r[i] for i in range(3))
    b = sum(d1[i] * d2[i] for i in range(3))
    den = a * e_ - b * b
    s = min(1.0, max(0.0, (b * f - cc * e_) / den)) if den > 1e-12 else 0.0
    t = (b * s + f) / e_
    if t < 0.0:
        t, s = 0.0, min(1.0, max(0.0, -cc / a))
    elif t > 1.0:
        t, s = 1.0, min(1.0, max(0.0, (b - cc) / a))
    return math.sqrt(sum((p1[i] + d1[i] * s - p2[i] - d2[i] * t) ** 2 for i in range(3)))


def tuft_place(M, q, k=0):
    """canonical tuft frame (X' = tuft axis, Z' = along the row, origin = hole mouth centre) -> part frame, tuft k of row 1"""
    Ln = math.radians(M["tuft_lean"])
    x = q[0] * math.cos(Ln) - q[2] * math.sin(Ln) + M["d_core"] / 2
    z = q[0] * math.sin(Ln) + q[2] * math.cos(Ln) + M["tuft_z0"] + k * M["tuft_pitch"]
    xx, yy = rotz((x, q[1]), M["tuft_ang_seed"] - 360.0 * k * M["tuft_pitch"] / M["twist_lead"])
    return (xx, yy, z)


def make_filaments(M, seed):
    """61 straight filaments of one tuft in the canonical frame: start point, unit direction, length. Directions fan
    out with the position in the root, plus a random part; lengths put every tip near the brush diameter; no two
    filaments come closer than d_fil + 0.03 outside the root (rejection sampling), so they never cut each other."""
    import random
    rng = random.Random(seed)
    rh = M["d_tuft_hole"] / 2
    pitch = FIL_PITCH * rh
    ph = rng.uniform(0.0, 60.0)
    pts = [(0.0, 0.0)]
    for k in range(1, N_RING + 1):
        for s in range(6):
            a0, a1 = math.radians(60.0 * s + ph), math.radians(60.0 * (s + 2) + ph)
            for j in range(k):
                pts.append((k * pitch * math.cos(a0) + j * pitch * math.cos(a1), k * pitch * math.sin(a0) + j * pitch * math.sin(a1)))
    rmax = N_RING * pitch
    x0 = M["tuft_root_h"] - SINK
    Ln = math.radians(M["tuft_lean"])
    Rc, rt = M["d_core"] / 2, M["d_brush"] / 2

    def radius(q):
        return math.hypot(q[0] * math.cos(Ln) - q[2] * math.sin(Ln) + Rc, q[1])

    out, segs = [], []
    order = sorted(range(len(pts)), key=lambda i: -math.hypot(*pts[i]))        # outside first: they have the most room
    for i in order:
        u, v = pts[i]
        best = None
        for attempt in range(400):
            sc = 1.0 if attempt < 200 else 0.5                                  # fall back to less scatter
            au = max(-19.0, min(19.0, FAN_U * u / rmax + rng.gauss(0.0, JIT_U * sc)))
            av = LEAN_T + FAN_V * v / rmax + rng.gauss(0.0, JIT_V * sc)
            d = (1.0, math.tan(math.radians(av)), math.tan(math.radians(au)))
            n = math.sqrt(sum(t * t for t in d))
            d = tuple(t / n for t in d)
            st = (x0, v, u)
            target = rt + rng.uniform(*TIP_JIT)
            lo, hi = 1.0, 60.0
            for _ in range(60):
                mid = (lo + hi) / 2
                if radius(tuple(st[j] + d[j] * mid for j in range(3))) < target:
                    lo = mid
                else:
                    hi = mid
            h = (lo + hi) / 2
            a = tuple(st[j] + d[j] * (SINK / d[0]) for j in range(3))         # where it leaves the root plug
            b = tuple(st[j] + d[j] * h for j in range(3))
            if all(seg_dist(a, b, a2, b2) >= M["d_fil"] + 0.03 for a2, b2 in segs):
                best = (st, d, h, au, av)
                segs.append((a, b))
                break
        if best is None:
            raise RuntimeError("no free direction for filament %d of seed %d" % (i, seed))
        out.append(dict(i=i, start=best[0], dir=best[1], h=best[2], au=best[3], av=best[4]))
    out.sort(key=lambda f: f["i"])
    return out


def stage_f(c):
    """Bristles as fine filaments: three tuft variants (root plug + 61 thin cylinders each, built upright at the
    origin), leaned / placed / clocked by Move Object, then patterned along the helix (every third position each)."""
    p, e, M = c.part, c.e, c.M
    e("d_fil", 0.16, "bristle filament diameter")
    e("tuft_root_h", 1.0, "packed root of a tuft: height above the land, along the tuft axis")
    nxh.expr(p, "fil_len", "(d_brush/2-d_core/2)/cos(tuft_lean)", "mm", "length of the tuft axis from the land to the brush diameter")
    L0 = (M["d_brush"] / 2 - M["d_core"] / 2) / math.cos(math.radians(M["tuft_lean"]))
    M["fil_len"] = L0
    rh, dep, dh = M["d_tuft_hole"] / 2, M["tuft_hole_depth"], M["d_tuft_hole"]
    c.notes["tufts"] = {"filaments_per_tuft": 1 + 3 * N_RING * (N_RING + 1), "fan_along_row_deg": FAN_U, "fan_across_deg": FAN_V,
                        "random_sigma_deg": [JIT_U, JIT_V], "sideways_lean_deg": LEAN_T, "tip_radius_scatter": list(TIP_JIT), "variants": {}}
    c.tufts, groups = [], []
    for vi, (vn, seed) in enumerate(VARIANTS):
        fils = make_filaments(M, seed)
        f, tuft = nxh.cylinder(p, ("-tuft_hole_depth", 0, 0), X, "d_tuft_hole", "tuft_hole_depth+tuft_root_h")
        f.SetName("TUFT_%s_ROOT" % vn)
        feats = [f]
        v_exp = math.pi * rh * rh * (dep + M["tuft_root_h"])
        for k, fl in enumerate(fils):
            st, d = fl["start"], fl["dir"]
            ff, _ = nxh.cylinder(p, ("tuft_root_h-%g" % SINK, "%.6f*d_tuft_hole" % (st[1] / dh), "%.6f*d_tuft_hole" % (st[2] / dh)), d,
                                 "d_fil", "fil_len*%.6f" % (fl["h"] / L0), op=BOOL.Unite, target=tuft)
            ff.SetName("TUFT_%s_FILAMENT_%02d" % (vn, k + 1))
            feats.append(ff)
            v_exp += math.pi * M["d_fil"] ** 2 / 4 * (fl["h"] - SINK / d[0])
        v_t = c.vol(tuft)
        c.chk("TUFT_%s: root + 61 filaments, volume" % vn, v_t, v_exp, 0.01 * v_exp)
        ex = {k_: v for k_, v in nxh.examine_geometry(p, tuft).items() if v}
        c.chk.true("TUFT_%s: one solid, Examine Geometry clean" % vn, tuft.IsSolidBody and not ex, ex)
        m1 = nxf.move_object(p, [tuft], "angle", "-tuft_lean", vec=Y, origin=(0, 0, 0))
        m1.SetName("TUFT_%s_LEAN" % vn)
        m2 = nxf.move_object(p, [tuft], "delta", ("d_core/2", "0", "tuft_z0+%d*tuft_pitch" % vi))
        m2.SetName("TUFT_%s_PLACE" % vn)
        m3 = nxf.move_object(p, [tuft], "angle", "tuft_ang_seed-%d*360*tuft_pitch/twist_lead" % vi, vec=Z, origin=(0, 0, 0))
        m3.SetName("TUFT_%s_CLOCK" % vn)
        # placement probes: centre of the root's bottom face, tip centre of the middle filament
        qb = tuft_place(M, (-dep, 0.0, 0.0), vi)
        c.chk("TUFT_%s: root bottom centre where the hole bottom is" % vn, on_body(c, tuft, qb), 0.0, 2e-3)
        c.chk("TUFT_%s: root bottom centre on the core (hole %d of row 1)" % (vn, vi + 1), on_body(c, c.core, qb), 0.0, 2e-3)
        f0 = fils[0]
        qt = tuft_place(M, tuple(f0["start"][j] + f0["dir"][j] * f0["h"] for j in range(3)), vi)
        c.chk("TUFT_%s: tip centre of the middle filament" % vn, on_body(c, tuft, qt), 0.0, 2e-3)
        tips = [math.hypot(*tuft_place(M, tuple(fl["start"][j] + fl["dir"][j] * fl["h"] for j in range(3)), vi)[:2]) for fl in fils]
        cnt = "ceiling((n_tuft-%d)/3)" % vi
        pf1, cp1 = nxf.pattern_geometry(p, [tuft], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="2"))
        pf1.SetName("TUFT_%s_ROW_2" % vn)
        pf2, cp2 = helix_copies(c, tuft, cnt, 3)
        pf2.SetName("TUFTS_%s_ROW_1" % vn)
        pf3, cp3 = helix_copies(c, cp1[0], cnt, 3)
        pf3.SetName("TUFTS_%s_ROW_2" % vn)
        mine = [tuft] + list(cp1) + list(cp2) + list(cp3)
        c.chk.true("TUFT_%s: 18 bodies (9 per row)" % vn, len(mine) == 18, len(mine))
        c.chk("TUFT_%s: all copies have the seed volume" % vn, sum(c.vol(b) for b in mine), 18 * v_t, 0.02)
        c.tufts += mine
        groups.append((vn, feats))
        c.notes["tufts"]["variants"][vn] = {"seed": seed, "volume": v_t, "length_min_max": [min(fl["h"] for fl in fils), max(fl["h"] for fl in fils)],
                                            "tip_radius_min_max": [min(tips), max(tips)],
                                            "angle_along_row_min_max": [min(fl["au"] for fl in fils), max(fl["au"] for fl in fils)],
                                            "angle_across_min_max": [min(fl["av"] for fl in fils), max(fl["av"] for fl in fils)]}
    for b in c.tufts:
        b.SetName("BRISTLE_TUFT")
    n_s = len(nxh.solids(p))
    c.chk.true("54 tufts + flaps + core", len(c.tufts) == 54 and n_s == 55 + len(getattr(c, "flaps", [])), (len(c.tufts), n_s))
    if getattr(c, "flaps", None):
        seeds = c.tufts[0:1] + c.tufts[18:19] + c.tufts[36:37]
        g = min(nxh.min_dist(t, fb) for t in seeds for fb in c.flaps)
        c.notes["tufts"]["clearance_seed_tufts_to_flaps"] = g
        c.chk.true("seed tufts clear the flaps (smallest gap %.2f mm)" % g, g > 0.5, g)
    for vn, feats in groups:
        try:
            nxf.feature_group(p, feats, "TUFT_%s" % vn)
        except Exception as ex_:                                       # noqa: BLE001
            c.notes["tufts"]["group_" + vn] = "not grouped: " + str(ex_)[:120]
    c.chk.true("no feature errors after stage F", not nxh.feature_errors(p), nxh.feature_errors(p))


# =========================================================================================== stage Z
def sort_bodies(c):
    """core / flaps / tufts by volume (tags of pattern copies change when a count is edited)"""
    p = c.part
    c.flaps, c.tufts = [], []
    for b in nxh.solids(p):
        if b.Tag == c.core.Tag:
            continue
        (c.flaps if c.vol(b) > 300.0 else c.tufts).append(b)


def colour(bodies, rgb):
    K = NXOpen.UF.UFConstants
    cid = UFS.Disp.AskClosestColor(K.UF_DISP_rgb_model, [float(v) for v in rgb], K.UF_DISP_CCM_EUCLIDEAN_DISTANCE)
    dm = nxh.S.DisplayManager.NewDisplayModification()
    try:
        dm.ApplyToAllFaces = True
        dm.NewColor = cid
        dm.Apply(list(bodies))
    finally:
        dm.Dispose()
    return cid


def stage_z(c):
    p, M = c.part, c.M
    res = c.res
    sort_bodies(c)
    ex = nxh.examine_geometry(p, c.core)
    res["examine_core"] = ex
    c.chk.true("Examine Geometry: core clean", not any(ex.values()), {k: v for k, v in ex.items() if v})
    bad = sum(1 for b in c.flaps + c.tufts if any(nxh.examine_geometry(p, b).values()))
    c.chk.true("Examine Geometry: %d flaps and %d tufts clean" % (len(c.flaps), len(c.tufts)), bad == 0, bad)
    res["volume_core"] = c.vol(c.core)
    res["volume_flaps"] = sum(c.vol(b) for b in c.flaps)
    res["volume_tufts"] = sum(c.vol(b) for b in c.tufts)
    res["bbox_core"] = nxh.bbox(c.core)
    res["face_census_core"] = nxh.face_census(c.core)
    res["faces_total"] = sum(len(b.GetFaces()) for b in nxh.solids(p))
    nxh.save(p)

    # ---- regeneration test: one master at a time, update, check, back
    v_nom, vf_nom, vt_nom = res["volume_core"], res["volume_flaps"], res["volume_tufts"]
    reg = []

    def run(name, new, check):
        old = p.Expressions.FindObject(name).RightHandSide
        row = {"name": name, "from": old, "to": new}
        t = time.time()
        try:
            nxh.set_expr(p, name, new)
            nxh.update()
            errs = nxh.feature_errors(p)
            row["errors"] = {k: str(v)[:160] for k, v in errs.items()} if errs else {}
            row["solids"] = len(nxh.solids(p))
            sort_bodies(c)
            try:
                row["check"] = check()
            except Exception as ex_:                                   # noqa: BLE001
                row["check"] = "EXC " + str(ex_)[:200]
        except Exception as ex_:                                       # noqa: BLE001
            row["exception"] = str(ex_)[:300]
        finally:
            nxh.set_expr(p, name, old)
            nxh.update()
            sort_bodies(c)
        row["v_back"] = [c.vol(c.core), sum(c.vol(b) for b in c.flaps), sum(c.vol(b) for b in c.tufts)]
        back = all(abs(a - b) <= 1e-6 * b for a, b in zip(row["v_back"], (v_nom, vf_nom, vt_nom)))
        row["seconds"] = round(time.time() - t, 1)
        row["ok"] = (not row.get("errors")) and "exception" not in row and back and not str(row.get("check", "")).startswith(("EXC", "FAIL"))
        reg.append(row)
        c.chk.true("regen %s %s -> %s: no errors, check ok, volumes return" % (name, old, new), row["ok"], {k: v for k, v in row.items() if k != "name"})

    def near(val, exp, tol):
        return ("ok " if abs(val - exp) <= tol else "FAIL ") + "%.4f (expected %.4f +- %g)" % (val, exp, tol)

    def both(*parts):
        return ("FAIL " if any(s.startswith("FAIL") for s in parts) else "ok ") + " ; ".join(parts)

    def with_m(**kw):
        m2 = dict(M)
        m2.update(kw)
        return m2

    R = M["d_core"] / 2
    w2 = M["slot_w"] / 2
    n_solid = 1 + len(c.flaps) + len(c.tufts)
    vfl = vf_nom / 4
    a250 = M["slot_ang0"] - 360.0 * (120.0 - M["z_core0"]) / 250.0
    run("twist_lead", 250, lambda: both(near(on_body(c, c.core, rotz((6.6, w2), a250) + (120.0,)), 0.0, 0.01),
                                        near(min(on_body(c, b, rotz((11.0, M["flap_t"] / 2), a250) + (120.0,)) for b in c.flaps), 0.0, 0.01),
                                        near(min(nxh.min_dist(b, c.core) for b in c.flaps), c.notes["flap"]["clearance_to_core"], 0.02)))
    run("slot_w", 1.5, lambda: near(v_nom - c.vol(c.core), 4 * (0.25 * (R - M["slot_neck_r"]) + 0.125 * (M["slot_neck_r"] - M["slot_floor_r"])) * (M["h_total"] - M["z_core0"]), 20.0))
    run("h_total", 160, lambda: both(near(nxh.bbox(c.core)[5], 160.0, 0.2), near(max(nxh.bbox(b)[5] for b in c.flaps), 160.0 - M["flap_end_gap"], 0.1)))
    run("flap_t", 1.1, lambda: near(sum(c.vol(b) for b in c.flaps) / 4 - vfl, flap_volumes(with_m(flap_t=1.1), M["h_total"] - M["flap_end_gap"])[0] - flap_volumes(M, M["h_total"] - M["flap_end_gap"])[0], 6.0))
    run("bead_t", 1.8, lambda: near(sum(c.vol(b) for b in c.flaps) / 4 - vfl, flap_volumes(with_m(bead_t=1.8), M["h_total"] - M["flap_end_gap"])[1] - flap_volumes(M, M["h_total"] - M["flap_end_gap"])[1], 12.0))
    o18 = flap_lines(with_m(flap_r_a=18.0))[0]
    run("flap_r_a", 18, lambda: near(min(on_body(c, b, rotz((interp(o18, 40.0), 0.0), M["slot_ang0"] + tw(c, 40.0)) + (40.0,)) for b in c.flaps), 0.0, 0.006))
    run("n_tuft", 20, lambda: both(near(float(len(nxh.solids(p))), n_solid - 14.0, 0.0), near(c.vol(c.core) - v_nom, 14 * c.notes["tuft_hole_volume_each"], 0.05)))
    run("tuft_pitch", 5.5, lambda: near(max(nxh.bbox(b)[5] for b in c.tufts) - M["tuft_z0"], 26 * 5.5 + 12.0, 9.0))
    run("tuft_lean", 30, lambda: both(near(on_body(c, c.core, tuft_place(with_m(tuft_lean=30.0), (-M["tuft_hole_depth"], 0.0, 0.0), 0)), 0.0, 3e-3),
                                      near(min(on_body(c, b, tuft_place(with_m(tuft_lean=30.0), (-M["tuft_hole_depth"], 0.0, 0.0), 0)) for b in c.tufts), 0.0, 3e-3)))
    run("d_brush", 40, lambda: near(sum(c.vol(b) for b in c.tufts) / vt_nom, 1.0 + (vt_nom / 54 - math.pi * (M["d_tuft_hole"] / 2) ** 2 * (M["tuft_hole_depth"] + M["tuft_root_h"])) / (vt_nom / 54)
                                    * ((20.0 - R) / (M["d_brush"] / 2 - R) - 1.0), 0.02))
    run("d_fil", 0.14, lambda: near(sum(c.vol(b) for b in c.tufts) / 54 - math.pi * (M["d_tuft_hole"] / 2) ** 2 * (M["tuft_hole_depth"] + M["tuft_root_h"]),
                                    (vt_nom / 54 - math.pi * (M["d_tuft_hole"] / 2) ** 2 * (M["tuft_hole_depth"] + M["tuft_root_h"])) * (0.14 / M["d_fil"]) ** 2, 0.5))
    res["regeneration"] = reg
    res["volumes_after_regen"] = [c.vol(c.core), sum(c.vol(b) for b in c.flaps), sum(c.vol(b) for b in c.tufts)]
    c.chk("core volume back at nominal after the regeneration test (relative)", res["volumes_after_regen"][0] / v_nom, 1.0, 1e-6)
    c.chk("flap volume back at nominal after the regeneration test (relative)", res["volumes_after_regen"][1] / vf_nom, 1.0, 1e-6)
    c.chk("tuft volume back at nominal after the regeneration test (relative)", res["volumes_after_regen"][2] / vt_nom, 1.0, 1e-6)
    c.chk.true("1 core + 4 flaps + 54 tufts, no feature errors at the end", (len(c.flaps), len(c.tufts)) == (4, 54) and not nxh.feature_errors(p),
               (len(c.flaps), len(c.tufts), nxh.feature_errors(p)))
    ex = nxh.examine_geometry(p, c.core)
    c.chk.true("Examine Geometry: core clean after the regeneration test", not any(ex.values()), {k: v for k, v in ex.items() if v})
    finish(c)


def finish(c):
    """names, colours, save, STL for the figures, STEP AP242 + re-import"""
    p, res = c.part, c.res
    sort_bodies(c)
    c.core.SetName("CORE")
    for b in c.flaps:
        b.SetName("SILICONE_FLAP")
    for b in c.tufts:
        b.SetName("BRISTLE_TUFT")
    try:
        res["colours"] = {"core": colour([c.core], (0.16, 0.16, 0.17)), "flaps": colour(c.flaps, (0.42, 0.42, 0.44)), "tufts": colour(c.tufts, (0.03, 0.03, 0.03))}
    except Exception:                                                  # noqa: BLE001
        res["colours"] = "not set: " + traceback.format_exc()[-300:]
    nxh.save(p)
    res["stl_core"] = stl_many([c.core], os.path.join(OUT, NAME + "_core.stl"), chord=0.005)
    if c.flaps:
        res["stl_flaps"] = stl_many(c.flaps, os.path.join(OUT, NAME + "_flaps.stl"), chord=0.005)
    if c.tufts:
        res["stl_tufts"] = stl_many(c.tufts, os.path.join(OUT, NAME + "_tufts.stl"), chord=0.004, max_edge=3.0)
    if "z" not in STAGES:
        return
    stp = os.path.join(OUT, NAME + ".step")
    nxf.step_export(p, stp, timeout=600)
    res["step_size"] = os.path.getsize(stp)
    n = len(nxh.solids(p))
    rt = nxf.step_roundtrip_check(stp, OUT, name="step_roundtrip", restore=p, part=p)
    res["step_roundtrip"] = {k: rt.get(k) for k in ("schema", "solids", "volume", "max_rel", "match", "healthy", "manifold_solid_brep", "examine")}
    c.chk.true("STEP AP242 re-import: %d solids, volumes match, healthy" % n, bool(rt.get("match")) and bool(rt.get("healthy")) and rt.get("solids") == n, res["step_roundtrip"])


def resume(c):
    """rebuild the journal's context on a part that already holds the core (stages A-D)"""
    p = c.part
    for ex in p.Expressions:
        try:
            c.M[ex.Name] = float(ex.Value)
        except Exception:                                              # noqa: BLE001
            pass
    feats = {}
    for f in p.Features.GetFeatures():
        if f.Name:
            feats[f.Name] = f
    c.dp0 = feats["DP_CORE0"].DatumPlane
    c.dax0 = feats["DA_CORE0_X"].DatumAxis
    c.day0 = feats["DA_CORE0_Y"].DatumAxis
    c.o0 = nxh.point(p, 0, 0, "z_core0")
    gs = [s for s in p.Sketches if s.Name == "SK_AXIS"]
    c.guide_feature = gs[0].Feature if gs else feats["SK_AXIS"]
    c.core = [b for b in nxh.solids(p) if b.Name == "CORE"][0]
    c.notes["tuft_hole_volume_each"] = math.pi * (c.M["d_tuft_hole"] / 2) ** 2 * c.M["tuft_hole_depth"]
    c.notes["resumed"] = True


# =========================================================================================== main
res = {"result": "FAIL", "stages": STAGES}
c = None
ALL = (("a", stage_a), ("b", stage_b), ("c", stage_c), ("d", stage_d), ("e", stage_e), ("f", stage_f), ("z", stage_z))
try:
    dst = os.path.join(OUT, NAME + ".prt")
    core_file = os.path.join(OUT, NAME + "_stage_d.prt")
    if "a" in STAGES:
        part = nxh.new_part(dst)
        c = Ctx(part)
    else:
        import shutil
        if os.path.exists(dst):
            os.remove(dst)
        shutil.copyfile(core_file, dst)
        part = nxh.open_part(dst)
        c = Ctx(part)
        resume(c)
    c.res = res
    for key, fn in ALL:
        if key not in STAGES:
            continue
        t = time.time()
        fn(c)
        c.say("stage %s done in %.1f s" % (key, time.time() - t))
        if key == "d":
            nxh.save(part)
            import shutil
            shutil.copyfile(dst, core_file)
    if "z" not in STAGES:
        res["volume_core"] = c.vol(c.core)
        res["examine_core"] = {k: v for k, v in nxh.examine_geometry(part, c.core).items() if v}
        if "e" in STAGES or "f" in STAGES:
            finish(c)
        else:
            nxh.save(part)
except Exception:
    res["error"] = traceback.format_exc()
if c is not None:
    rep = c.chk.report()
    res.update(rep)
    res["sketches"] = c.sk
    res["masters"] = {k: {"value": v, "comment": c.C.get(k, ("derived", "-"))[0], "unit": c.C.get(k, ("derived", "-"))[1]} for k, v in c.M.items()}
    res["notes"] = c.notes
    res["log"] = c.log
    try:
        res["features"] = [(x["name"], x["type"]) for x in nxh.feature_table(c.part) if not x["type"] == "EXTRACT_BODY"]
        res["n_features_top"] = len(nxh.top_features(c.part)[0])
        res["feature_errors"] = {k: str(v)[:200] for k, v in (nxh.feature_errors(c.part) or {}).items()}
    except Exception:
        res["features_exc"] = traceback.format_exc()[-400:]
    if "error" in res:
        res["result"] = "FAIL"
nxh.write_json(os.path.join(OUT, "build2_%s.json" % STAGES), res)
