import ast
p = r"C:\NX_MCP_WORKSPACE\dreame_brush\build.py"
b = open(p, "rb").read()
if b[:3] == b"\xef\xbb\xbf":
    b = b[3:]
t = b.replace(b"\r\n", b"\n").decode("utf-8")


def rep(old, new, count=1):
    global t
    assert t.count(old) == count, (t.count(old), old[:80])
    t = t.replace(old, new)


# ---- underside numbers after the base scan was centred on its own recess wall
rep('e("d_recess", 22.85, "underside recess diameter")', 'e("d_recess", 23.0, "underside recess diameter")')
rep('e("d_boss", 10.05, "raised ring round the hex socket, diameter")', 'e("d_boss", 10.0, "raised ring round the hex socket, diameter")')
rep('e("hex_af", 5.7, "hex socket across flats")', 'e("hex_af", 5.8, "hex socket across flats (scan: 5.7 at the mouth .. 5.9 deeper; not caliper-checked)")')
rep('e("pit_r", 7.94, "pits in the recess floor: radial position")', 'e("pit_r", 7.93, "pits in the recess floor: radial position")')
rep('e("ej_r", 8.33, "ejector marks: radial position")', 'e("ej_r", 8.35, "ejector marks: radial position")')
rep('    nxh.expr(p, "n_pair", 2, None, "pits / marks per circle")\n    for nm, pre in (("PIT", "pit"), ("EJECTOR_MARK", "ej")):',
    '    e("dish_d", 3.6, "shallow dish round each pit: diameter")\n    e("dish_depth", 0.25, "shallow dish round each pit: depth")\n'
    '    nxh.expr(p, "n_pair", 2, None, "pits / marks per circle")\n    for nm, pre, pos in (("PIT_DISH", "dish", "pit"), ("PIT", "pit", "pit"), ("EJECTOR_MARK", "ej", "ej")):')
rep('''        f, _ = nxh.cylinder(p, ("%s_r*cos(%s_ang)" % (pre, pre), "%s_r*sin(%s_ang)" % (pre, pre), "z_recess"), Z, "%s_d" % pre, "%s_depth" % pre,
                            op=BOOL.Subtract, target=c.core)''',
    '''        f, _ = nxh.cylinder(p, ("%s_r*cos(%s_ang)" % (pos, pos), "%s_r*sin(%s_ang)" % (pos, pos), "z_recess"), Z, "%s_d" % pre, "%s_depth" % pre,
                            op=BOOL.Subtract, target=c.core)''')
rep('''        c.chk(nm + " x 2 removes two cylinders", v0 - c.vol(c.core), 2 * math.pi * (M[pre + "_d"] / 2) ** 2 * M[pre + "_depth"], 0.01)''',
    '''        exp_ = 2 * math.pi * (M[pre + "_d"] / 2) ** 2 * M[pre + "_depth"]
        if nm == "PIT":                                             # the dish already took the top of the pit
            exp_ -= 2 * math.pi * (M["pit_d"] / 2) ** 2 * M["dish_depth"]
        c.chk(nm + " x 2 removes two cylinders", v0 - c.vol(c.core), exp_, 0.01)''')

# ---- centre groove: also ends before the idler end
rep('''    def twisted_cut(S, help_uv, ang, count, name, a_in, trim_plane=None, keep_xy=None, z_from=None):''',
    '''    def twisted_cut(S, help_uv, ang, count, name, a_in, trim_plane=None, keep_xy=None, z_from=None, trim_plane2=None, z_to=None):''')
rep('''            tf.SetName(name + "_TOOL_START")
''', '''            tf.SetName(name + "_TOOL_START")
            if trim_plane2 is not None:
                tf2, _rev2 = nxf.trim_body(p, tool, keep_point=(kp[0], kp[1], zz), datum_plane=trim_plane2)
                tf2.SetName(name + "_TOOL_END")
''')
rep('''        length = (M["h_total"] - (z_from if z_from is not None else M["z_core0"]))''',
    '''        length = ((z_to if z_to is not None else M["h_total"]) - (z_from if z_from is not None else M["z_core0"]))''')
rep('''    fz, dpa = nxf.datum_plane(p, "offset", [c.dat.xy], "z_ag0", "DP_CENTRE_GROOVE_START")''',
    '''    e("z_ag1", 163.5, "centre groove ends at this height (scan: runs out before the idler end)")
    fz, dpa = nxf.datum_plane(p, "offset", [c.dat.xy], "z_ag0", "DP_CENTRE_GROOVE_START")
    fz1, dpb = nxf.datum_plane(p, "offset", [c.dat.xy], "z_ag1", "DP_CENTRE_GROOVE_END")''')
rep('''"CENTRE_GROOVES", a_ag, trim_plane=dpa, keep_xy=(ca, 0.0), z_from=M["z_ag0"])''',
    '''"CENTRE_GROOVES", a_ag, trim_plane=dpa, keep_xy=(ca, 0.0), z_from=M["z_ag0"], trim_plane2=dpb, z_to=M["z_ag1"])''')

# ---- idler end: the outer edge is a 45 degree chamfer, not a round
i0 = t.index('    R = M["d_core"] / 2\n    rv = [(R - M["end_R"], ht')
i1 = t.index("    # ---- key notch beside one slot at the idler end")
new_block = '''    R = M["d_core"] / 2
    ch = M["end_cham"]
    rv = [(R - ch, ht, "d_core/2-end_cham", "h_total"), (R, ht - ch, "d_core/2", "h_total-end_cham"), (R + 1.0, ht - ch, "d_core/2+1", None),
          (R + 1.0, ht + 1.0, None, "h_total+1"), (R - ch, ht + 1.0, None, None)]
    S = c.sketch("xz", "SK_END_CHAMFER")
    S.profile(rv)
    c.done(S)
    v0 = c.vol(c.core)
    f = nxf.revolve(p, S.section(None, (R + 1.0, ht)), nxf.axis_from(p, c.dat.z), op=BOOL.Subtract, target=c.core)
    f.SetName("END_CHAMFER")
    c.notes["solids_after_END_CHAMFER"] = [round(c.vol(b), 3) for b in nxh.solids(p)]
    full = revolve_volume([(R - ch, ht), (R, ht - ch), (R, ht)])                      # uncut ring
    dv = v0 - c.vol(c.core)
    c.chk.true("END_CHAMFER removes material (full ring %.2f less slots and grooves)" % full, 0.6 * full < dv < full + 0.01, dv)
    q = rotz((R - ch / 2, 0.0), 30.0 + tw(c, ht))
    c.chk("END_CHAMFER: point on the chamfer", on_body(c, c.core, (q[0], q[1], ht - ch / 2)), 0.0, 2e-3)

'''
t = t[:i0] + new_block + t[i1:]
rep('e("end_R", 1.05, "idler end: round on the outer edge")', 'e("end_cham", 1.05, "idler end: 45 deg chamfer on the outer edge")')
ast.parse(t)
open(p, "w", encoding="utf-8", newline="\n").write(t)

q = r"C:\NX_MCP_WORKSPACE\dreame_brush\an\dev.py"
s = open(q, encoding="utf-8").read()
old = 'table = ((z < 0.3) & (r > 15.3)) | (z < -0.3) | (r > 22.5)'
new = 'table = ((z < 0.3) & (r > 15.3)) | (z < -0.3) | (r > 22.5) | ((z < 7.0) & (r > 17.0))      # table plane, its fringe, debris beside the flange'
assert old in s
open(q, "w", encoding="utf-8", newline="\n").write(s.replace(old, new))
print("patched ok")
