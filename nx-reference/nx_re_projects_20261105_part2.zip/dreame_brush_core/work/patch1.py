import ast
p = r"C:\NX_MCP_WORKSPACE\dreame_brush\build.py"
b = open(p, "rb").read()
if b[:3] == b"\xef\xbb\xbf":
    b = b[3:]
t = b.replace(b"\r\n", b"\n").decode("utf-8")
old = """    for a_, b_ in ((0, 1), (1, 2), (2, 3), (3, 4)):
        S.tangent(cs[a_], cs[b_])"""
new = """    for a_, b_ in ((0, 1), (1, 2), (2, 3), (3, 4)):
        S.tangent(cs[a_], cs[b_], at=bv[b_])"""
assert old in t
t = t.replace(old, new)
i0 = t.index("    # ---- hex socket")
i1 = t.index("    # ---- pits and ejector marks")
hexblock = t[i0:i1]
t = t[:i0] + t[i1:]
old_end = """    c.chk.true("one solid after stage A", len(nxh.solids(p)) == 1, len(nxh.solids(p)))"""
assert old_end in t
cyl = """    # ---- core cylinder (the hex socket reaches into it)
    e("d_core", 14.95, "core diameter over the lands")
    v0 = c.vol(c.core)
    f, _ = nxh.cylinder(p, (0, 0, "z_core0"), Z, "d_core", "h_total-z_core0", op=BOOL.Unite, target=c.core)
    f.SetName("CORE_CYLINDER")
    c.chk("CORE_CYLINDER volume", c.vol(c.core) - v0, math.pi * (M["d_core"] / 2) ** 2 * (M["h_total"] - M["z_core0"]), 0.01)

"""
t = t.replace(old_end, cyl + hexblock + old_end)
old_b = """    e("d_core", 14.95, "core diameter over the lands")
    v0 = c.vol(c.core)
    f, _ = nxh.cylinder(p, (0, 0, "z_core0"), Z, "d_core", "h_total-z_core0", op=BOOL.Unite, target=c.core)
    f.SetName("CORE_CYLINDER")
    R = M["d_core"] / 2
    L = M["h_total"] - M["z_core0"]
    c.chk("CORE_CYLINDER volume", c.vol(c.core) - v0, math.pi * R * R * L, 0.01)
"""
assert t.count(old_b) == 1, t.count(old_b)
t = t.replace(old_b, """    R = M["d_core"] / 2
    L = M["h_total"] - M["z_core0"]
""")
ast.parse(t)
open(p, "w", encoding="utf-8", newline="\n").write(t)
q = r"C:\NX_MCP_WORKSPACE\dreame_brush\nxlib\ps.py"
s = open(q, encoding="utf-8").read()
old = """    def tangent(self, c1, c2):
        self.sk.CreateTangentConstraint(nxf.cg(c1), nxf.cg(c2))"""
new = """    def tangent(self, c1, c2, at=None):
        \"\"\"Tangent constraint; at = (u, v) of the point where the two curves touch (help point).\"\"\"
        hp = self.p3(*at) if at is not None else self.p3(0.0, 0.0)
        self.sk.CreateTangentConstraint(nxf.cg(c1), nxf.help_at(hp), nxf.cg(c2), nxf.help_at(hp))"""
assert old in s
open(q, "w", encoding="utf-8", newline="\n").write(s.replace(old, new))
print("patched ok")
