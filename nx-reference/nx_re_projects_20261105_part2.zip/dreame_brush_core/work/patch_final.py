"""One-off: take the bead shoulder chamfer out of build2.py (it was undone in the delivered part: a two-offset Chamfer
on the 10 helical shoulder edges came out with different leg assignments from run to run)."""
import os
WS = os.path.dirname(os.path.abspath(__file__))
path = os.path.join(WS, "build2.py")
s = open(path, encoding="utf-8").read()


def sub(a, b):
    global s
    if s.count(a) != 1:
        raise SystemExit("expected 1 x %r, found %d" % (a[:70], s.count(a)))
    s = s.replace(a, b)


sub('''    e("bead_step", 0.22, "flap: shoulder chamfer where the bead meets the web, across the thickness")
    e("bead_ramp", 0.45, "flap: shoulder chamfer where the bead meets the web, along the flap")
''', "")
a = s.index("    # shoulder chamfer: bead_step across the thickness, bead_ramp along the flap; NX chooses which face gets the")
b = s.index("    # ---- one flap: web + bead, cut to length")
s = s[:a] + '''    # The shoulder where the bead meets the web stays a square step of (bead_t - flap_t) / 2. The scan shows a ramp
    # of about 0.25 x 0.45 there; a two-offset Chamfer on these 10 helical edges was tried in three runs and NX gave
    # the two offsets to different faces from edge to edge and from run to run (removed volume 8.9 / 19.7 / 12.6 mm3),
    # and the STEP of the chamfered flap re-imported 0.67 % short in volume. Left out on purpose.

''' + s[b:]
sub('''    tip, sh, cls = bead_edges(bead)
    c.notes["flap"]["bead_faces"]''', '''    tip, _sh, cls = bead_edges(bead)
    c.notes["flap"]["bead_faces"]''')
sub('''        tip, sh, cls = bead_edges(bead)
        info.update(guarded("BEAD_TIP_ROUND", lambda: nxh.blend(p, tip, "bead_tip_R", overflow=True)))''',
    '''        tip, _sh, cls = bead_edges(bead)
        info.update(guarded("BEAD_TIP_ROUND", lambda: nxh.blend(p, tip, "bead_tip_R", overflow=True)))''')
sub('''    """(web, bead) volumes by integration over z of the section area inside the envelopes (corner rounds, bead
    corner rounds and shoulder chamfers left out).''', '''    """(web, bead) volumes by integration over z of the section area inside the envelopes (corner rounds of the
    outline and of the bead left out).''')
sub('''    to the measured (r, z) outline by a revolved envelope, the bead corners are rounded, the flap is patterned."""''',
    '''    to the measured (r, z) outline by a revolved envelope, the outer bead corners are rounded, the flap is patterned."""''')
open(path, "w", encoding="utf-8", newline="\n").write(s)
import ast
ast.parse(s)
print("patched, syntax ok; 'chamfer' left in file:", s.count("chamfer"), "| bead_step:", s.count("bead_step"), "| bead_ramp:", s.count("bead_ramp"))
