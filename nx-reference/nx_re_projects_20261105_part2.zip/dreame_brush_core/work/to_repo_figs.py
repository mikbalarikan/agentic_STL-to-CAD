"""Rewrite the figures of the repo example: a curated set, true colours (no palette), large ones only resized.
usage: to_repo_figs.py <target dir>"""
import os, sys, shutil
from PIL import Image

DLV = r"C:\Users\marya\Downloads\dreame_brush_core_with_bristles_nx\figures"
DST = os.path.join(sys.argv[1], "figures")
KEEP = ["01_referans_ve_killi_tarama_farkli_cekirdek.png", "02_render_yan_cad.png", "02_render_yan_bindirme.png", "03_render_iso_cad.png",
        "04_render_tahrik_ucu_cad.png", "05_render_alt_yuz_cad.png", "06_render_rulman_ucu_cad.png", "07_sapma_haritasi_cekirdek.png",
        "08_sapma_haritasi_uclar_ve_alt_yuz.png", "09_kesit_bindirme_z.png", "10_kesit_bindirme_yari_kesit.png",
        "11_olcum_acilmis_cekirdek_kesiti.png", "12_olcum_kil_demetleri_acilim.png", "13_olcum_alt_yuz.png"]
assert os.path.basename(os.path.dirname(DST)) == "dreame_brush_core_with_bristles" and os.path.isdir(DST)
shutil.rmtree(DST)
os.makedirs(DST)
tot = 0
for f in KEEP:
    src, dst = os.path.join(DLV, f), os.path.join(DST, f)
    if os.path.getsize(src) > 450_000:
        im = Image.open(src).convert("RGB")
        w, h = im.size
        if w > 1600:
            im = im.resize((1600, int(h * 1600 / w)), Image.LANCZOS)
        im.save(dst, optimize=True)
    else:
        shutil.copyfile(src, dst)
    s = os.path.getsize(dst)
    tot += s
    print("%-52s %5d KB" % (f, s / 1e3))
print("figures: %d files, %.2f MB" % (len(KEEP), tot / 1e6))
