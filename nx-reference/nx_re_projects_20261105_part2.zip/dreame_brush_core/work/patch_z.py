"""One-off: corrections to checks of build2.py after the first full run (the geometry is not touched):
flap_t regeneration expectation, chamfer probe threshold, STEP re-import reported per kind of body."""
import os
WS = os.path.dirname(os.path.abspath(__file__))
path = os.path.join(WS, "build2.py")
s = open(path, encoding="utf-8").read()


def sub(a, b):
    global s
    if s.count(a) != 1:
        raise SystemExit("expected 1 x %r, found %d" % (a[:70], s.count(a)))
    s = s.replace(a, b)


sub('''            if r_["probe"] > 0.02:                                     # the side face starts bead_ramp above the shoulder''',
    '''            if r_["probe"] > 0.045:                                    # right order: 0.07 (the side face starts bead_ramp above the shoulder); wrong order: 0.03 or less''')
sub('''    run("flap_t", 1.1, lambda: near(sum(c.vol(b) for b in c.flaps) / 4 - vfl, flap_volumes(with_m(flap_t=1.1), M["h_total"] - M["flap_end_gap"])[0] - flap_volumes(M, M["h_total"] - M["flap_end_gap"])[0], 6.0))''',
    '''    # a thicker web adds its own volume, less the part of it that lies inside the bead (already bead material)
    ov = c.notes["flap"]["web_and_bead_overlap"]
    run("flap_t", 1.1, lambda: near(sum(c.vol(b) for b in c.flaps) / 4 - vfl, flap_volumes(with_m(flap_t=1.1), M["h_total"] - M["flap_end_gap"])[0] - flap_volumes(M, M["h_total"] - M["flap_end_gap"])[0]
                                    - ov * (1.1 / M["flap_t"] - 1.0), 6.0))''')
sub('''    res["step_roundtrip"] = {k: rt.get(k) for k in ("schema", "solids", "volume", "max_rel", "match", "healthy", "manifold_solid_brep", "examine")}
    c.chk.true("STEP AP242 re-import: %d solids, volumes match, healthy" % n, bool(rt.get("match")) and bool(rt.get("healthy")) and rt.get("solids") == n, res["step_roundtrip"])''',
    '''    res["step_roundtrip"] = {k: rt.get(k) for k in ("schema", "solids", "volume", "max_rel", "match", "healthy", "manifold_solid_brep")}
    res["step_roundtrip"]["examine_findings"] = sum(sum(e.values()) for e in rt.get("examine") or [])
    kinds = {"core": [], "flaps": [], "tufts": []}
    for r_ in rt.get("per_body") or []:
        kinds["core" if r_["expected"] > 10000 else ("flaps" if r_["expected"] > 300 else "tufts")].append(r_)
    res["step_roundtrip"]["max_rel_by_kind"] = {k: max((r_["rel"] for r_ in v), default=None) for k, v in kinds.items()}
    ok = all(r_["rel"] <= 1e-4 for r_ in kinds["core"] + kinds["tufts"])
    c.chk.true("STEP AP242 re-import: %d solids, Examine Geometry clean, core and tuft volumes match (1e-4)" % n,
               bool(rt.get("healthy")) and rt.get("solids") == n and ok and len(kinds["core"]) == 1 and len(kinds["tufts"]) == len(c.tufts), res["step_roundtrip"])
    # the flaps are 0.94 mm thick twisted sheets: a relative volume says little (2 x offset / thickness), so the volume
    # change of the re-imported flaps is turned into the uniform face offset it corresponds to and held against the
    # modelling tolerance; the raw relative number is kept in the result
    if kinds["flaps"]:
        area = sum(nxh.mass(p, [b]).get("area", 0.0) for b in c.flaps)
        dv = sum(r_["got"] - r_["expected"] for r_ in kinds["flaps"])
        res["step_roundtrip"]["flaps"] = {"n": len(kinds["flaps"]), "dV": dv, "rel": dv / sum(r_["expected"] for r_ in kinds["flaps"]), "area": area,
                                          "equivalent_face_offset": dv / area if area else None}
        c.chk("STEP re-import, %d flaps: volume change as a uniform face offset (mm) within the 0.01 modelling tolerance" % len(kinds["flaps"]),
              dv / area if area else 1.0, 0.0, 0.01)''')
open(path, "w", encoding="utf-8", newline="\n").write(s)
print("patched")
