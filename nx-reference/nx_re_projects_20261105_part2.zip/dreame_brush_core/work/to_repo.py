"""Copy the result and the sources of this job into the skill repo as a worked example.
usage: to_repo.py <target dir>      (refuses to write into an existing folder)
Large figures are re-encoded at a reduced size; scans, the review part and the CAD tessellations are NOT copied."""
import os, sys, json, shutil
from PIL import Image

WS = r"C:\NX_MCP_WORKSPACE\dreame_brush"
DLV = r"C:\Users\marya\Downloads\dreame_brush_core_with_bristles_nx"
DST = sys.argv[1]
NAME = "dreame_brush_core_with_bristles"
if os.path.exists(DST):
    raise SystemExit("target exists: " + DST)
for sub in ("", "result", "journal", "journal/nxlib", "analysis", "qa", "figures"):
    os.makedirs(os.path.join(DST, sub))
n = 0


def cp(src, dst):
    global n
    shutil.copyfile(src, os.path.join(DST, dst))
    n += 1


cp(os.path.join(DLV, "REPORT.md"), "REPORT.md")
for f in (NAME + ".prt", NAME + ".step"):
    cp(os.path.join(DLV, f), os.path.join("result", f))
for f in sorted(os.listdir(os.path.join(DLV, "journal"))):
    p = os.path.join(DLV, "journal", f)
    if os.path.isfile(p):
        cp(p, os.path.join("journal", f))
for f in sorted(os.listdir(os.path.join(DLV, "journal", "nxlib"))):
    cp(os.path.join(DLV, "journal", "nxlib", f), os.path.join("journal", "nxlib", f))
for f in sorted(os.listdir(os.path.join(DLV, "analysis"))):
    cp(os.path.join(DLV, "analysis", f), os.path.join("analysis", f))
for f in sorted(os.listdir(os.path.join(DLV, "qa"))):
    cp(os.path.join(DLV, "qa", f), os.path.join("qa", f))
for f in sorted(os.listdir(os.path.join(DLV, "figures"))):
    src = os.path.join(DLV, "figures", f)
    dst = os.path.join(DST, "figures", f)
    if os.path.getsize(src) > 450_000:
        im = Image.open(src).convert("RGB")
        w, h = im.size
        if w > 1800:
            im = im.resize((1800, int(h * 1800 / w)), Image.LANCZOS)
        im = im.quantize(colors=128, method=Image.MEDIANCUT, dither=Image.FLOYDSTEINBERG)
        im.save(dst, optimize=True)
    else:
        shutil.copyfile(src, dst)
    n += 1
tot = 0
rows = []
for r, d, fs in os.walk(DST):
    for f in fs:
        s = os.path.getsize(os.path.join(r, f))
        tot += s
        rows.append((os.path.relpath(os.path.join(r, f), DST), s))
print("copied", n, "files,", round(tot / 1e6, 2), "MB ->", DST)
for sub in ("result", "journal", "analysis", "qa", "figures"):
    ss = [s for p, s in rows if p.startswith(sub)]
    print("  %-9s %3d files %7.0f KB" % (sub, len(ss), sum(ss) / 1e3))
