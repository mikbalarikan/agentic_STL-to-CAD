"""Volume of one flap of the STEP by fine tessellation (divergence theorem), against the NX number and the NX STL.
usage: s2_flap_volume.py <file.step> <nx volume of one flap>"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from OCP.STEPControl import STEPControl_Reader
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE, TopAbs_REVERSED
from OCP.TopoDS import TopoDS
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRep import BRep_Tool
from OCP.TopLoc import TopLoc_Location
from common2 import *

src, v_nx = sys.argv[1], float(sys.argv[2])
rd = STEPControl_Reader()
rd.ReadFile(src)
rd.TransferRoots()
ex = TopExp_Explorer(rd.OneShape(), TopAbs_SOLID)
flap = None
while ex.More():
    s = TopoDS.Solid_s(ex.Current())
    g = GProp_GProps()
    BRepGProp.VolumeProperties_s(s, g)
    if 300 < g.Mass() < 10000:
        flap = s
        v_default = g.Mass()
        break
    ex.Next()
g = GProp_GProps()
try:
    BRepGProp.VolumePropertiesGK_s(flap, g, 1e-7, False, False, False, False, False)
    v_gk = g.Mass()
except Exception as e:  # noqa: BLE001
    v_gk = "n/a: " + str(e)[:80]
res = {"nx": v_nx, "occ_default": v_default, "occ_gauss_kronrod_1e-7": v_gk}
for defl in (0.002, 0.0005, 0.0002):
    BRepMesh_IncrementalMesh(flap, defl, False, 0.02, True)
    vol, ntri = 0.0, 0
    fe = TopExp_Explorer(flap, TopAbs_FACE)
    while fe.More():
        f = TopoDS.Face_s(fe.Current())
        loc = TopLoc_Location()
        tr = BRep_Tool.Triangulation_s(f, loc)
        t = loc.Transformation()
        P = np.array([[tr.Node(i).Transformed(t).X(), tr.Node(i).Transformed(t).Y(), tr.Node(i).Transformed(t).Z()] for i in range(1, tr.NbNodes() + 1)])
        T = np.array([tr.Triangle(i).Get() for i in range(1, tr.NbTriangles() + 1)]) - 1
        a, b, c = P[T[:, 0]], P[T[:, 1]], P[T[:, 2]]
        v = np.einsum("ij,ij->i", a, np.cross(b, c)).sum() / 6.0
        vol += -v if f.Orientation() == TopAbs_REVERSED else v
        ntri += len(T)
        fe.Next()
    res["mesh_deflection_%g" % defl] = {"volume": float(vol), "triangles": ntri, "rel_to_nx": float(vol / v_nx - 1.0)}
tri = read_stl(os.path.join(WS, "out2", "dreame_brush_with_bristles_flaps.stl"))
v_stl = float(np.einsum("ij,ij->i", tri[:, 0], np.cross(tri[:, 1], tri[:, 2])).sum() / 6.0)
res["nx_stl_chord_0.005_four_flaps_div_4"] = {"volume": v_stl / 4, "rel_to_nx": v_stl / 4 / v_nx - 1.0}
print(json.dumps(res, indent=1))
json.dump(res, open(os.path.join(QA2, "s2_flap_volume.json"), "w"), indent=1)
