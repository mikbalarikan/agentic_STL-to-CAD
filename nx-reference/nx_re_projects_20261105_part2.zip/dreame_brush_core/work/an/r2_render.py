﻿"""Renders of the round-2 model (core + flaps + bristles) and of the assembled scan, same cameras.
usage: r2_render.py [tag]      reads out2/<name>_core.stl, _flaps.stl, _tufts.stl (whichever exist)"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import pyvista as pv
from common2 import *

TAG = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] != "-" else ""
NAME = "dreame_brush_with_bristles"
O2 = os.path.join(WS, "out2")
COL = {"core": "#3f4349", "flaps": "#8d9299", "tufts": "#16171a"}
parts = {}
for k in ("core", "flaps", "tufts"):
    f = os.path.join(O2, "%s_%s.stl" % (NAME, k))
    if os.path.exists(f):
        parts[k] = pv.read(f)
scan_f = os.path.join(O2, "scan_brush_with_bristles_datum.stl")
scan = pv.read(scan_f) if os.path.exists(scan_f) else None
print({k: v.n_cells for k, v in parts.items()}, "scan", None if scan is None else scan.n_cells)


def cam(pl, d, up, focus, dist=420.0, zoom=1.0, scale=None):
    d = np.asarray(d, float); d /= np.linalg.norm(d)
    pl.camera.focal_point = focus
    pl.camera.position = np.asarray(focus) + d * dist
    pl.camera.up = up
    pl.camera.parallel_projection = True
    if scale is not None:
        pl.camera.parallel_scale = scale
    else:
        pl.reset_camera(); pl.camera.zoom(zoom)


def add_cad(pl):
    for k, m in parts.items():
        pl.add_mesh(m, color=COL[k], smooth_shading=True, split_sharp_edges=True, feature_angle=35, specular=0.25, specular_power=18, ambient=0.28, diffuse=0.75)


def add_scan(pl):
    pl.add_mesh(scan, color="#9aa7ad", smooth_shading=False, specular=0.15, ambient=0.25)


def shot(fn, what, d, up, focus, scale, size=(1500, 1700)):
    pl = pv.Plotter(off_screen=True, window_size=size)
    (add_cad if what == "cad" else add_scan)(pl)
    pl.set_background("white")
    pl.enable_anti_aliasing("ssaa")
    cam(pl, d, up, focus, scale=scale)
    pl.screenshot(os.path.join(FIG2, fn))
    pl.close()


views = {"iso": ((1.0, 0.75, 0.55), (0, 0, 1), (0, 0, 86.0), 98.0, (1500, 1900)),
         "side": ((1.0, 0.0, 0.0), (0, 0, 1), (0, 0, 85.0), 92.0, (1100, 1900)),
         "side2": ((0.0, 1.0, 0.0), (0, 0, 1), (0, 0, 85.0), 92.0, (1100, 1900)),
         "drive_end": ((0.55, 0.45, 0.35), (0, 0, 1), (0, 0, 16.0), 26.0, (1700, 1500)),
         "idler_end": ((0.5, 0.4, 0.75), (0, 0, 1), (0, 0, 152.0), 27.0, (1700, 1500)),
         "bristles": ((0.75, 0.55, 0.12), (0, 0, 1), (5.0, 8.0, 62.0), 15.0, (1900, 1500)),
         "top": ((0.0, 0.0, 1.0), (0, 1, 0), (0, 0, 85.0), 23.0, (1500, 1500))}
only = [a for a in sys.argv[2:]]
for nm, (d, up, focus, scale, size) in views.items():
    if only and nm not in only:
        continue
    if parts:
        shot("r2_%s_cad%s.png" % (nm, TAG), "cad", d, up, focus, scale, size)
    if scan is not None and not TAG:
        shot("r2_%s_scan.png" % nm, "scan", d, up, focus, scale, size)
    print("view", nm)

