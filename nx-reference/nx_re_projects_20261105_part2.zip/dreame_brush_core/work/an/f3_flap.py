"""Silicone flaps of the assembled scan, measured in the untwisted frame of the core (flap i along local +x at
slot_ang0 + 90 i).  Per flap and z band: centre line y(x), thickness t(x), tip radius; tip radius along z (end tapers);
bead fit at the tip.  Writes qa2/f3_flap.json, fig2/f3_*.png.   usage: f3_flap.py"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common2 import *

SLOT0 = 1.1
T = load_T(os.path.join("..", "qa2", "T_asm.json"))
m = Mesh(apply(T, read_stl(SCAN_ASM_FULL)))
print("full scan triangles", len(m.tri))
P, N, A = m.c, m.n, m.a
tu, r, z = untwist(P)
# normals in the untwisted frame: rotate by -k (z - z0) about Z
rot = np.radians(-K_TWIST * (z - Z0))
nx_u = N[:, 0] * np.cos(rot) - N[:, 1] * np.sin(rot)
ny_u = N[:, 0] * np.sin(rot) + N[:, 1] * np.cos(rot)
res = {"flaps": {}}

fig, axs = plt.subplots(4, 6, figsize=(60, 28))
bands = [(22, 30), (40, 50), (60, 70), (85, 95), (110, 120), (135, 145)]
xb = np.arange(7.0, 19.01, 0.2)
allprof = []
for i in range(4):
    a = np.radians(tu - (SLOT0 + 90.0 * i))
    xl, yl = r * np.cos(a), r * np.sin(a)
    ca, sa = np.cos(np.radians(SLOT0 + 90.0 * i)), np.sin(np.radians(SLOT0 + 90.0 * i))
    nyl = -nx_u * sa + ny_u * ca
    nxl = nx_u * ca + ny_u * sa
    sel = (xl > 6.0) & (xl < 21) & (np.abs(yl) < 4.5) & (z > 6.6)
    fl = {"bands": {}}
    for j, (z0_, z1_) in enumerate(bands):
        s = sel & (z > z0_) & (z < z1_)
        up, lo = s & (nyl > 0.5), s & (nyl < -0.5)
        prof = []
        for k in range(len(xb) - 1):
            u = up & (xl >= xb[k]) & (xl < xb[k + 1]); l = lo & (xl >= xb[k]) & (xl < xb[k + 1])
            if u.sum() > 15 and l.sum() > 15:
                yu_, yl_ = np.median(yl[u]), np.median(yl[l])
                prof.append((0.5 * (xb[k] + xb[k + 1]), 0.5 * (yu_ + yl_), yu_ - yl_))
        prof = np.array(prof)
        tipx = float(np.percentile(xl[s], 99.8)) if s.sum() else None
        fl["bands"]["%d-%d" % (z0_, z1_)] = {"tip_x_p99.8": tipx, "x": prof[:, 0].round(2).tolist(), "centre_y": prof[:, 1].round(3).tolist(), "thickness": prof[:, 2].round(3).tolist()}
        allprof.append((i, j, prof, tipx))
        ax = axs[i, j]
        q = np.random.default_rng(0).choice(np.flatnonzero(s), min(int(s.sum()), 60000), replace=False)
        ax.scatter(xl[q], yl[q], s=0.3, c="k")
        if len(prof):
            ax.plot(prof[:, 0], prof[:, 1], "r-", lw=1)
        ax.set_aspect("equal"); ax.set_xlim(6, 19); ax.set_ylim(-3.5, 3.5); ax.grid(True, lw=0.3)
        ax.set_xticks(np.arange(6, 19.1, 1)); ax.set_yticks(np.arange(-3.5, 3.6, 0.5))
        ax.set_title(f"flap {i} (slot at {SLOT0 + 90 * i:.1f} deg), z {z0_}..{z1_}, tip x {tipx:.2f}")
    # tip radius along z (2 mm steps): p99.5 of r within the flap strip
    tz = []
    for zc in np.arange(7.0, 170.0, 1.0):
        s = sel & (np.abs(z - zc) < 0.5)
        if s.sum() > 30:
            tz.append((float(zc), float(np.percentile(r[s], 99.5)), float(np.average(yl[s & (xl > np.percentile(xl[s], 90))])) if s.sum() else 0.0))
    fl["tip_r_by_z"] = [(a_, round(b_, 2), round(c_, 2)) for a_, b_, c_ in tz]
    res["flaps"][str(i)] = fl
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f3_flap_sections.png"), dpi=45); plt.close(fig)

# pooled summary: thickness by x, centre-line by x (all flaps, all bands)
tx = {}
for i, j, prof, tipx in allprof:
    for x_, cy, t_ in prof:
        tx.setdefault(round(float(x_), 2), []).append((cy, t_))
summ = []
for x_ in sorted(tx):
    v = np.array(tx[x_])
    summ.append((x_, len(v), float(np.median(v[:, 1])), float(v[:, 1].min()), float(v[:, 1].max()), float(np.median(v[:, 0])), float(v[:, 0].min()), float(v[:, 0].max())))
res["pooled_by_x"] = {"columns": ["x", "n", "t_median", "t_min", "t_max", "centre_y_median", "centre_y_min", "centre_y_max"], "rows": [[round(q, 3) for q in row] for row in summ]}
print("x      n   t_med  t_min  t_max   cy_med  cy_min  cy_max")
for row in summ:
    print("%5.2f %3d  %5.3f  %5.3f  %5.3f   %+5.2f  %+5.2f  %+5.2f" % row)
tips = [t for _, _, _, t in allprof]
print("tip x per flap/band:", np.round(np.array(tips).reshape(4, -1), 2))
res["tip_x_mid"] = np.round(np.array(tips).reshape(4, -1), 3).tolist()

fig, axs = plt.subplots(2, 1, figsize=(26, 14))
for i in range(4):
    tzv = np.array(res["flaps"][str(i)]["tip_r_by_z"])
    axs[0].plot(tzv[:, 0], tzv[:, 1], label=f"flap {i}")
    axs[1].plot(tzv[:, 0], tzv[:, 2], label=f"flap {i}")
axs[0].set_ylabel("tip radius p99.5 (mm)"); axs[0].grid(True); axs[0].legend(); axs[0].set_xticks(np.arange(0, 171, 5)); axs[0].set_yticks(np.arange(7, 19, 0.5))
axs[1].set_ylabel("sideways offset of the tip (mm, + = counter-clockwise)"); axs[1].grid(True); axs[1].set_xticks(np.arange(0, 171, 5)); axs[1].set_xlabel("z")
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f3_flap_tip_by_z.png"), dpi=60); plt.close(fig)
json.dump(res, open(os.path.join(QA2, "f3_flap.json"), "w"), indent=1)
