﻿"""Shoulder chamfer of the CAD flap bead, both sides, read from the section z = const of the flaps STL.
usage: f8b_shoulder.py <flaps.stl> [z]"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common2 import *

cad = Mesh(read_stl(sys.argv[1]))
zc = float(sys.argv[2]) if len(sys.argv) > 2 else 115.0
SLOT0 = 1.1
a = np.radians(-SLOT0 - K_TWIST * (zc - Z0))
R = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
seg = cad.section(2, zc)[:, :, :2] @ R.T
seg = seg[(seg[:, :, 0].min(axis=1) > 7.6) & (np.abs(seg[:, :, 1]).max(axis=1) < 2.0)]
# dense resampling of the outline
pts = np.concatenate([s[0] + (s[1] - s[0]) * t for s in seg for t in np.linspace(0, 1, 40)[:, None, None]]).reshape(-1, 2)
print(os.path.basename(os.path.dirname(sys.argv[1])), "z =", zc, "tip x %.3f" % pts[:, 0].max())
for side, sel in (("+y", pts[:, 1] > 0), ("-y", pts[:, 1] < 0)):
    p = pts[sel]
    rows = []
    for xc in np.arange(pts[:, 0].max() - 1.75, pts[:, 0].max() - 0.9, 0.05):
        q = p[np.abs(p[:, 0] - xc) < 0.012]
        if len(q):
            rows.append("%.2f:%.3f" % (xc, np.abs(q[:, 1]).max()))
    print(side, " ".join(rows))

