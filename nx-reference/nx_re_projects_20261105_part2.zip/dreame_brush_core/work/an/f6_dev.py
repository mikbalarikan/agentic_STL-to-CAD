"""Round 2 deviation: assembled scan against the model (core + flaps + bristle tufts).
Each scan sample goes to the model part it is nearest to; flap numbers are split by radius (the flaps are soft and
bend sideways at the tip) and by region; section overlays at fixed heights.
Writes qa2/f6_dev.json, fig2/f6_sections.png, fig2/f6_untwisted_overlay.png.   usage: f6_dev.py"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common2 import *

NAME = "dreame_brush_with_bristles"
O2 = os.path.join(WS, "out2")
T = load_T(os.path.join("..", "qa2", "T_asm.json"))
scan = Mesh(apply(T, read_stl(SCAN_ASM_FULL, every=2)))
cad = {k: Mesh(read_stl(os.path.join(O2, "%s_%s.stl" % (NAME, k)))) for k in ("core", "flaps", "tufts")}
sc = {k: scene_of(m) for k, m in cad.items()}
P, idx = scan.sample(1_500_000, seed=11)
r, th, z = cyl(P)
tu = (th - K_TWIST * (z - Z0)) % 360.0
keep = (z > 0.35) & (r < 22.0)
P, r, z, tu = P[keep], r[keep], z[keep], tu[keep]
D = {}
for k in cad:
    d, sg, tid, q = closest(sc[k], cad[k], P)
    D[k] = d * sg
A = np.abs(np.stack([D["core"], D["flaps"], D["tufts"]]))
near = A.argmin(axis=0)
dev = np.choose(near, [D["core"], D["flaps"], D["tufts"]])
res = {"samples": int(len(P)), "share_by_part": {k: float((near == i).mean()) for i, k in enumerate(("core", "flaps", "tufts"))}}
res["core"] = stats(dev[near == 0])
fl = near == 1
res["flaps_all"] = stats(dev[fl])
res["flaps_by_radius"] = {"%g-%g" % (a, b): stats(dev[fl & (r >= a) & (r < b)]) for a, b in ((7.4, 10), (10, 13), (13, 15), (15, 18.5))}
res["flaps_by_region"] = {"foot z < 14.4": stats(dev[fl & (z < 14.4)]), "main z 14.4-146": stats(dev[fl & (z >= 14.4) & (z < 146.3)]), "end taper z > 146": stats(dev[fl & (z >= 146.3)])}
res["tufts"] = stats(dev[near == 2])
res["all"] = stats(dev)
# model -> scan: how much of each part has scan within 0.3 / 1.0 mm
scs = scene_of(scan)
res["cad_to_scan"] = {}
for k, m in cad.items():
    Q, _ = m.sample(300_000, seed=3)
    d, sg, tid, q = closest(scs, scan, Q)
    res["cad_to_scan"][k] = {"p50": float(np.percentile(d, 50)), "p95": float(np.percentile(d, 95)), "within_0.3": float((d < 0.3).mean()), "within_1.0": float((d < 1.0).mean())}
for k in ("share_by_part", "core", "flaps_all", "flaps_by_radius", "flaps_by_region", "tufts", "cad_to_scan"):
    print(k, json.dumps(res[k]))
json.dump(res, open(os.path.join(QA2, "f6_dev.json"), "w"), indent=1)

# ---- section overlays
zs = (9.0, 13.6, 25.0, 60.0, 100.0, 140.0, 156.0, 165.0)
fig, axs = plt.subplots(2, 4, figsize=(44, 22))
for ax, zc in zip(axs.ravel(), zs):
    plot_segs(ax, scan.section(2, zc)[:, :, :2], colors="k", linewidths=0.7)
    for k, col in (("core", "tab:red"), ("flaps", "tab:blue"), ("tufts", "tab:green")):
        plot_segs(ax, cad[k].section(2, zc)[:, :, :2], colors=col, linewidths=0.8)
    ax.set_xlim(-21, 21); ax.set_ylim(-21, 21); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(-20, 21, 2)); ax.set_yticks(np.arange(-20, 21, 2))
    ax.set_title("z = %g   black: scan, red: core, blue: flaps, green: bristle filaments" % zc, fontsize=15)
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f6_sections.png"), dpi=50); plt.close(fig)

# ---- pooled untwisted section z 60..110: scan density + model flap / core outlines at z0
s = (z > 60) & (z < 110)
x, y = r[s] * np.cos(np.radians(tu[s])), r[s] * np.sin(np.radians(tu[s]))
fig, ax = plt.subplots(figsize=(18, 18))
ax.hist2d(x, y, bins=[np.arange(-21, 21.01, 0.04)] * 2, cmap="Greys", norm=matplotlib.colors.LogNorm())
zc = 85.0
a = np.radians(-K_TWIST * (zc - Z0))
R2 = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
for k, col in (("core", "tab:red"), ("flaps", "tab:blue")):
    sg2 = cad[k].section(2, zc)[:, :, :2] @ R2.T
    plot_segs(ax, sg2, colors=col, linewidths=0.9)
ax.set_xlim(-21, 21); ax.set_ylim(-21, 21); ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(-20, 21, 2)); ax.set_yticks(np.arange(-20, 21, 2))
ax.set_title("scan z 60..110 untwisted and pooled (grey); model section at z = 85 untwisted (red core, blue flaps)", fontsize=14)
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f6_untwisted_overlay.png"), dpi=60); plt.close(fig)
print("done")
