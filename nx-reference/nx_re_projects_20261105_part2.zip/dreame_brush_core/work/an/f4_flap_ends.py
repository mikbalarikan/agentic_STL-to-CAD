"""Flap outline in (z, r) at both ends, bead along the tapered edges, bead shape in the least-flexed bands,
bristle envelope of the assembled scan.  Writes qa2/f4_flap_ends.json, fig2/f4_*.png.   usage: f4_flap_ends.py"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common2 import *

SLOT0 = 1.1
T = load_T(os.path.join("..", "qa2", "T_asm.json"))
m = Mesh(apply(T, read_stl(SCAN_ASM_FULL)))
P, N = m.c, m.n
tu, r, z = untwist(P)
rot = np.radians(-K_TWIST * (z - Z0))
nx_u = N[:, 0] * np.cos(rot) - N[:, 1] * np.sin(rot)
ny_u = N[:, 0] * np.sin(rot) + N[:, 1] * np.cos(rot)
res = {}

# ---- (z, r) outline of each flap: side faces only (normal mostly tangential) so that core and flange do not show
fig, axs = plt.subplots(4, 2, figsize=(40, 36))
out = {}
for i in range(4):
    a = np.radians(tu - (SLOT0 + 90.0 * i))
    xl, yl = r * np.cos(a), r * np.sin(a)
    ca, sa = np.cos(np.radians(SLOT0 + 90.0 * i)), np.sin(np.radians(SLOT0 + 90.0 * i))
    nyl = -nx_u * sa + ny_u * ca
    sel = (xl > 7.6) & (np.abs(yl) < 4.5) & (np.abs(nyl) > 0.6)
    rr = np.hypot(xl, yl)
    rows = []
    for zc in np.arange(6.0, 170.01, 0.25):
        s = sel & (np.abs(z - zc) < 0.125)
        rows.append((float(zc), float(np.percentile(rr[s], 99.0)) if s.sum() > 12 else float("nan"), int(s.sum())))
    out[str(i)] = rows
    rw = np.array(rows)
    for j, (za, zb_) in enumerate(((5.5, 24.0), (142.0, 170.5))):
        ax = axs[i, j]
        s = sel & (z > za) & (z < zb_)
        ax.scatter(z[s], rr[s], s=0.2, c="k")
        k = (rw[:, 0] > za) & (rw[:, 0] < zb_)
        ax.plot(rw[k, 0], rw[k, 1], "r-", lw=1)
        ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xlim(za, zb_); ax.set_ylim(7, 18.5)
        ax.set_xticks(np.arange(np.ceil(za), zb_, 1.0)); ax.set_yticks(np.arange(7, 18.6, 0.5))
        ax.set_title(f"flap {i}: side-face points in (z, r); red = p99 radius")
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f4_flap_ends.png"), dpi=40); plt.close(fig)
res["tip_r_by_z_quarter_mm"] = out
med = np.nanmedian(np.array([[q[1] for q in out[str(i)]] for i in range(4)]), axis=0)
zz = np.array([q[0] for q in out["0"]])
res["tip_r_median_of_4"] = [(float(a), None if np.isnan(b) else round(float(b), 3)) for a, b in zip(zz, med)]
print("median tip radius of the four flaps:")
for a, b in zip(zz, med):
    if a < 22 or a > 140 or abs(a % 10) < 0.01:
        print("  z %6.2f  r %6.3f" % (a, b))
# linear fits of the three straight parts
def fit(z0_, z1_):
    k = (zz >= z0_) & (zz <= z1_) & ~np.isnan(med)
    c = np.polyfit(zz[k], med[k], 1)
    return {"z": [z0_, z1_], "slope": float(c[0]), "r_at_z0": float(np.polyval(c, z0_)), "r_at_z1": float(np.polyval(c, z1_)), "rms": float(np.std(med[k] - np.polyval(c, zz[k])))}
res["fit_main"] = fit(20.0, 138.0); res["fit_main_a"] = fit(20.0, 60.0); res["fit_main_b"] = fit(100.0, 138.0)
res["fit_end_taper"] = fit(150.0, 166.0); res["fit_foot"] = fit(7.5, 12.5)
for k in ("fit_main", "fit_main_a", "fit_main_b", "fit_end_taper", "fit_foot"):
    print(k, res[k])

# ---- bead on the tapered edges: thickness of the flap at its edge, in sections z = const
fig, axs = plt.subplots(4, 8, figsize=(80, 28))
zcs = (8.0, 10.0, 12.0, 14.0, 152.0, 157.0, 162.0, 166.0)
for i in range(4):
    a = np.radians(tu - (SLOT0 + 90.0 * i))
    xl, yl = r * np.cos(a), r * np.sin(a)
    for j, zc in enumerate(zcs):
        s = (np.abs(z - zc) < 0.4) & (xl > 6.5) & (np.abs(yl) < 4.5)
        ax = axs[i, j]
        ax.scatter(xl[s], yl[s], s=0.5, c="k"); ax.set_aspect("equal"); ax.set_xlim(6.5, 18.5); ax.set_ylim(-3.5, 3.5); ax.grid(True, lw=0.3)
        ax.set_xticks(np.arange(7, 18.6, 1)); ax.set_yticks(np.arange(-3.5, 3.6, 0.5)); ax.set_title(f"flap {i}, z = {zc} +- 0.4")
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f4_flap_end_sections.png"), dpi=35); plt.close(fig)

# ---- bead shape: least-flexed bands, flap straightened by its own centre line (local frame at the bead)
fig, axs = plt.subplots(1, 4, figsize=(48, 12))
beads = []
for ax, (i, z0_, z1_) in zip(axs, ((1, 108, 122), (3, 84, 96), (0, 108, 122), (2, 108, 122))):
    a = np.radians(tu - (SLOT0 + 90.0 * i))
    xl, yl = r * np.cos(a), r * np.sin(a)
    s = (z > z0_) & (z < z1_) & (xl > 12.0) & (np.abs(yl) < 4.5)
    # centre line direction from the strip between x 12 and 14.5
    k = s & (xl < 14.5)
    c1 = np.polyfit(xl[k], yl[k], 1)
    ang = np.arctan(c1[0])
    x0, y0 = 13.0, np.polyval(c1, 13.0)
    xs = (xl[s] - x0) * np.cos(ang) + (yl[s] - y0) * np.sin(ang) + x0
    ys = -(xl[s] - x0) * np.sin(ang) + (yl[s] - y0) * np.cos(ang)
    ax.scatter(xs, ys, s=0.4, c="k"); ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xlim(12, 17.5); ax.set_ylim(-1.5, 1.5)
    ax.set_xticks(np.arange(12, 17.6, 0.25)); ax.set_yticks(np.arange(-1.5, 1.51, 0.125))
    ax.set_title(f"flap {i}, z {z0_}..{z1_}: straightened along its own strip (tilt {np.degrees(ang):.1f} deg)")
    # numbers: strip thickness, bead thickness, bead start, tip
    def width(xa, xb_):
        q = (xs > xa) & (xs < xb_)
        return float(np.percentile(ys[q], 97) - np.percentile(ys[q], 3))
    prof = [(round(float(xc), 2), round(width(xc - 0.05, xc + 0.05), 3)) for xc in np.arange(12.5, 17.0, 0.1) if ((xs > xc - 0.05) & (xs < xc + 0.05)).sum() > 30]
    beads.append({"flap": i, "z": [z0_, z1_], "tilt_deg": float(np.degrees(ang)), "tip_x_p99.9": float(np.percentile(xs, 99.9)), "width_by_x": prof})
    print("bead flap", i, "tip", round(float(np.percentile(xs, 99.9)), 3), "width by x:", prof)
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f4_bead.png"), dpi=45); plt.close(fig)
res["beads"] = beads

# ---- bristles in the assembled scan: radius percentiles per row and z, lean, width
br = {}
for name, a0 in (("row_A", 36.1), ("row_B", 216.1)):
    d = (tu - a0 + 180.0) % 360.0 - 180.0
    s = (np.abs(d) < 32.0) & (r > 8.3) & (z > 7.5)
    rows = []
    for zc in np.arange(10, 160, 10.0):
        q = s & (np.abs(z - zc) < 5)
        if q.sum() > 200:
            rows.append((float(zc), int(q.sum()), *[round(float(v), 2) for v in np.percentile(r[q], [50, 90, 98, 99.8])]))
    q = s & (z > 20) & (z < 140)
    br[name] = {"r_p50_p90_p98_p998_by_z": rows, "r_p98_all": float(np.percentile(r[q], 98)), "r_p99.5_all": float(np.percentile(r[q], 99.5)),
                "z_extent_r_gt_12": [float(z[s & (r > 12)].min()), float(z[s & (r > 12)].max())],
                "angle_by_r": [(float(rc), round(float(np.median(d[q & (np.abs(r - rc) < 0.5)])), 2), round(float(np.percentile(d[q & (np.abs(r - rc) < 0.5)], 5)), 2),
                                round(float(np.percentile(d[q & (np.abs(r - rc) < 0.5)], 95)), 2)) for rc in np.arange(9, 19.1, 1.0) if (q & (np.abs(r - rc) < 0.5)).sum() > 100]}
    print(name, json.dumps(br[name]))
res["bristles"] = br
json.dump(res, open(os.path.join(QA2, "f4_flap_ends.json"), "w"), indent=1)
