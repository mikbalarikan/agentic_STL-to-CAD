"""Reference CAD of the brush WITHOUT bristles (user's part with the silicone flaps): renders + flap section facts.
usage: f0_view_ref.py"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import pyvista as pv
from common2 import *

D = os.path.join(OUT, "nb")
core = pv.read(os.path.join(D, "nb_body8.stl"))
flaps = [pv.read(os.path.join(D, f"nb_body{i}.stl")) for i in (2, 4, 5, 6, 7)]
pl = pv.Plotter(off_screen=True, shape=(1, 4), window_size=(3200, 1500))
cen = np.array([0, 0, 85.0])
for i, (d, up) in enumerate([((1, 0, 0), (0, 0, 1)), ((0.6, 0.6, 0.5), (0, 0, 1)), ((0.2, 0.2, 1), (0, 1, 0)), ((0.2, 0.2, -1), (0, 1, 0))]):
    pl.subplot(0, i)
    pl.add_mesh(core, color="#8f9aa0", smooth_shading=True, split_sharp_edges=True)
    for f in flaps:
        pl.add_mesh(f, color="#e58a2b", smooth_shading=True, split_sharp_edges=True)
    d = np.array(d, float); d /= np.linalg.norm(d)
    pl.camera.focal_point = cen; pl.camera.position = cen + d * 400; pl.camera.up = up
    pl.camera.parallel_projection = True; pl.reset_camera(); pl.camera.zoom(1.3)
pl.set_background("white")
pl.screenshot(os.path.join(FIG2, "f0_reference_no_bristles_cad.png"))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, axs = plt.subplots(1, 4, figsize=(40, 10))
mc = Mesh(read_stl(os.path.join(D, "nb_body8.stl")))
mf = [Mesh(read_stl(os.path.join(D, f"nb_body{i}.stl"))) for i in (2, 4, 5, 6, 7)]
for ax, zc in zip(axs, (8.0, 40.0, 85.0, 160.0)):
    plot_segs(ax, mc.section(2, zc)[:, :, :2], colors="k")
    for f in mf:
        plot_segs(ax, f.section(2, zc)[:, :, :2], colors="tab:orange", linewidths=1.0)
    ax.set_title(f"reference (no bristles) CAD, section z = {zc}"); ax.grid(True, lw=0.3)
    ax.set_xlim(-20, 20); ax.set_ylim(-20, 20)
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f0_reference_sections.png"), dpi=60); plt.close(fig)
# flap envelope r(z) of one flap
f = mf[0]
r, th, z = cyl(f.c)
rows = []
for zc in np.arange(6, 170, 8.0):
    s = np.abs(z - zc) < 1.0
    if s.sum() > 5:
        rows.append((float(zc), float(r[s].min()), float(r[s].max())))
print("flap 0 r_min / r_max by z:", [(a, round(b, 2), round(c, 2)) for a, b, c in rows])
print("flap bbox z", f.lo[:, 2].min(), f.hi[:, 2].max())
