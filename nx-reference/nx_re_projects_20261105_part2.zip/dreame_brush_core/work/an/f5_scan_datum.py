"""Assembled scan in the CAD datum frame, table removed -> out2/scan_brush_with_bristles_datum.stl (decimated source).
usage: f5_scan_datum.py"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common2 import *

T = load_T(os.path.join("..", "qa2", "T_asm.json"))
tri = apply(T, read_stl(SCAN_ASM_20))
c = tri.mean(axis=1)
r = np.hypot(c[:, 0], c[:, 1])
keep = ~((c[:, 2] < 0.6) & (r > 16.9)) & (r < 23.0)
os.makedirs(os.path.join(WS, "out2"), exist_ok=True)
dst = os.path.join(WS, "out2", "scan_brush_with_bristles_datum.stl")
write_stl(dst, tri[keep])
print("triangles", len(tri), "->", int(keep.sum()), "written", dst, "z", tri[keep][:, :, 2].min().round(2), tri[keep][:, :, 2].max().round(2))
