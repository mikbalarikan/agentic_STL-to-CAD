"""Composite figures for the round-2 report: before / after / scan, and model / scan pairs.   usage: r3_compose.py"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image, ImageDraw, ImageFont
from common2 import *


def font(sz):
    for f in ("arial.ttf", "segoeui.ttf"):
        try:
            return ImageFont.truetype(f, sz)
        except Exception:
            pass
    return ImageFont.load_default()


def row(items, out, height=1500, pad=30, title_h=90):
    """items: [(path, caption)] -> one image, equal heights"""
    ims = []
    for p, cap in items:
        im = Image.open(p).convert("RGB")
        w = int(im.width * height / im.height)
        ims.append((im.resize((w, height), Image.LANCZOS), cap))
    W = sum(i.width for i, _ in ims) + pad * (len(ims) + 1)
    canvas = Image.new("RGB", (W, height + title_h + pad), "white")
    d = ImageDraw.Draw(canvas)
    x = pad
    f = font(44)
    for im, cap in ims:
        canvas.paste(im, (x, title_h))
        tw = d.textlength(cap, font=f)
        d.text((x + (im.width - tw) / 2, 22), cap, fill="black", font=f)
        x += im.width + pad
    canvas.save(os.path.join(FIG2, out))
    print("wrote", out, canvas.size)


F1 = os.path.join(WS, "fig")
row([(os.path.join(F1, "render_iso_cad.png"), "ÖNCE (8 Ekim): çekirdek + çubuk kıllar"),
     (os.path.join(FIG2, "r2_iso_cad.png"), "ŞİMDİ: çekirdek + 4 silikon kanat + ince kıllar"),
     (os.path.join(FIG2, "r2_iso_scan.png"), "TARAMA (montajlı kıllı fırça)")], "c1_once_simdi_tarama.png")
for nm, cap in (("side", "yan"), ("drive_end", "tahrik ucu"), ("idler_end", "rulman ucu"), ("bristles", "kıl sırası, yakın"), ("top", "üstten")):
    a, b = os.path.join(FIG2, "r2_%s_cad.png" % nm), os.path.join(FIG2, "r2_%s_scan.png" % nm)
    if os.path.exists(a) and os.path.exists(b):
        row([(a, "MODEL - " + cap), (b, "TARAMA - " + cap)], "c2_%s_model_tarama.png" % nm, height=1300)
