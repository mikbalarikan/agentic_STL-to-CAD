"""The two assembled brushes side by side: sections of the scans at two heights (flaps are counted by eye:
the brush with bristles has 4 flaps + 2 bristle rows, the brush without bristles has 5 flaps).
Axis of the no-bristles scan: PCA of the scan without its table.  Writes fig2/f7_flap_count.png."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common2 import *

fig, axs = plt.subplots(2, 2, figsize=(24, 20))
for row, (name, path, T) in enumerate((("brush WITH bristles (assembled scan, CAD datum frame)", SCAN_ASM_20, load_T(os.path.join("..", "qa2", "T_asm.json"))),
                                       ("brush WITHOUT bristles (assembled scan, PCA axis)", SCAN_NB_20, None))):
    tri = read_stl(path)
    if T is not None:
        m = Mesh(apply(T, tri))
    else:
        m0 = Mesh(tri)
        keep = np.ones(len(m0.c), bool)
        for it in range(5):
            c0 = np.average(m0.c[keep], axis=0, weights=m0.a[keep])
            w, e = np.linalg.eigh(np.cov((m0.c[keep] - c0).T, aweights=m0.a[keep]))
            ax_ = e[:, 2]
            t = (m0.c - c0) @ ax_
            keep = np.linalg.norm((m0.c - c0) - np.outer(t, ax_), axis=1) < 20.0
        ex = np.cross([0.0, 0.0, 1.0], ax_); ex /= np.linalg.norm(ex)
        R = np.stack([ex, np.cross(ax_, ex), ax_])
        m = Mesh((tri - c0) @ R.T + np.array([0, 0, 85.0]))
    for col, zc in enumerate((60.0, 100.0)):
        ax = axs[row, col]
        plot_segs(ax, m.section(2, zc)[:, :, :2], colors="k", linewidths=0.8)
        ax.set_xlim(-22, 22); ax.set_ylim(-22, 22); ax.grid(True, lw=0.3)
        ax.set_title("%s\nsection %s" % (name, "z = %g" % zc if T is not None else "%g mm from the middle" % (zc - 85.0)), fontsize=15)
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f7_flap_count.png"), dpi=45); plt.close(fig)
print("done")
