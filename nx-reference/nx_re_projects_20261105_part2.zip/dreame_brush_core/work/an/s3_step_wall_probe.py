﻿"""Where are the web walls of the STEP flaps?  Design points on the exact helicoid walls (y = +-flap_t/2 in the slot
frame) -> distance to the nearest STEP flap and inside / outside.  Thickness of the STEP web from opposite points.
usage: s3_step_wall_probe.py <file.step>"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from OCP.STEPControl import STEPControl_Reader
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_IN, TopAbs_OUT
from OCP.TopoDS import TopoDS
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
from OCP.BRepClass3d import BRepClass3d_SolidClassifier
from OCP.gp import gp_Pnt
from common2 import *

rd = STEPControl_Reader()
rd.ReadFile(sys.argv[1])
rd.TransferRoots()
ex = TopExp_Explorer(rd.OneShape(), TopAbs_SOLID)
flaps = []
while ex.More():
    s = TopoDS.Solid_s(ex.Current())
    g = GProp_GProps()
    BRepGProp.VolumeProperties_s(s, g)
    if 300 < g.Mass() < 10000:
        flaps.append(s)
    ex.Next()
SLOT0, T2 = 1.1, 0.47
rows = []
for zc in (30.0, 60.0, 90.0, 120.0, 140.0):
    for rr in (8.5, 11.0, 13.0):       # all inside the plain web (the bead starts at r 14.8 or more up to z 146)
        row = {"z": zc, "r": rr}
        for side in (+1, -1):
            a = np.radians(SLOT0 + K_TWIST * (zc - Z0))
            x, y = rr, side * T2
            p = gp_Pnt(float(x * np.cos(a) - y * np.sin(a)), float(x * np.sin(a) + y * np.cos(a)), float(zc))
            v = BRepBuilderAPI_MakeVertex(p).Vertex()
            best = None
            for f in flaps:
                d = BRepExtrema_DistShapeShape(v, f)
                dist = d.Value()
                if dist > 1e-9:                                   # 0 = the point is inside the solid: use the shell distance
                    pass
                cl = BRepClass3d_SolidClassifier(f, p, 1e-7)
                st = cl.State()
                if best is None or dist < best[0]:
                    best = (dist, "in" if st == TopAbs_IN else ("out" if st == TopAbs_OUT else "on"), f)
            # distance to the boundary also when the point is inside
            from OCP.TopAbs import TopAbs_SHELL
            se = TopExp_Explorer(best[2], TopAbs_SHELL)
            dsh = BRepExtrema_DistShapeShape(v, se.Current()).Value()
            row["+y" if side > 0 else "-y"] = {"dist_to_surface": round(float(dsh), 5), "state": best[1]}
        # signed: + = STEP wall lies outside the design wall (point inside the solid)
        sg = [(d["dist_to_surface"] if d["state"] == "in" else -d["dist_to_surface"]) for d in (row["+y"], row["-y"])]
        row["web_thickness_step"] = round(2 * T2 + sg[0] + sg[1], 5)
        rows.append(row)
        print(row)
th = np.array([r["web_thickness_step"] for r in rows])
res = {"design_thickness": 2 * T2, "step_thickness_mean": float(th.mean()), "min": float(th.min()), "max": float(th.max()), "probes": rows}
print("web thickness of the STEP flap: mean %.5f min %.5f max %.5f (design %.2f)" % (th.mean(), th.min(), th.max(), 2 * T2))
json.dump(res, open(os.path.join(QA2, "s3_step_wall_probe.json"), "w"), indent=1)

