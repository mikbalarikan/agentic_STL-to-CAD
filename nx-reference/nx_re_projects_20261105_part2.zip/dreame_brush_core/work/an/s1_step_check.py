"""Independent look at the delivered STEP with OpenCascade: solids, volumes, validity, colours of the root shapes,
and the distance of the STEP flap surface from the NX flap surface (NX STL as reference).
usage: s1_step_check.py <file.step> <build2 json>"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopoDS import TopoDS
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRep import BRep_Tool
from OCP.TopLoc import TopLoc_Location
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from common2 import *

src, bj = sys.argv[1], sys.argv[2]
rd = STEPControl_Reader()
if rd.ReadFile(src) != IFSelect_RetDone:
    raise SystemExit("cannot read " + src)
rd.TransferRoots()
shape = rd.OneShape()
solids = []
ex = TopExp_Explorer(shape, TopAbs_SOLID)
while ex.More():
    solids.append(TopoDS.Solid_s(ex.Current()))
    ex.Next()
rows = []
for s in solids:
    g = GProp_GProps()
    BRepGProp.VolumeProperties_s(s, g)
    nf = 0
    fe = TopExp_Explorer(s, TopAbs_FACE)
    while fe.More():
        nf += 1
        fe.Next()
    bb = Bnd_Box()
    BRepBndLib.Add_s(s, bb)
    rows.append({"volume": g.Mass(), "faces": nf, "valid": bool(BRepCheck_Analyzer(s).IsValid()), "bbox": [round(v, 3) for v in bb.Get()]})
vols = np.array([r["volume"] for r in rows])
core = [r for r in rows if r["volume"] > 10000]
flaps = [r for r in rows if 300 < r["volume"] < 10000]
tufts = [r for r in rows if r["volume"] < 300]
b = json.load(open(bj))
res = {"file": os.path.basename(src), "size": os.path.getsize(src), "solids": len(rows), "all_valid": all(r["valid"] for r in rows),
       "core": {"n": len(core), "volume": sum(r["volume"] for r in core), "nx": b["volume_core"], "faces": [r["faces"] for r in core]},
       "flaps": {"n": len(flaps), "volume": sum(r["volume"] for r in flaps), "nx": b["volume_flaps"], "each": [round(r["volume"], 3) for r in flaps], "faces": [r["faces"] for r in flaps]},
       "tufts": {"n": len(tufts), "volume": sum(r["volume"] for r in tufts), "nx": b["volume_tufts"], "faces_min_max": [min(r["faces"] for r in tufts), max(r["faces"] for r in tufts)]}}
for k in ("core", "flaps", "tufts"):
    res[k]["rel_diff"] = res[k]["volume"] / res[k]["nx"] - 1.0
allbb = np.array([r["bbox"] for r in rows])
res["bbox_all"] = [float(allbb[:, 0].min()), float(allbb[:, 1].min()), float(allbb[:, 2].min()), float(allbb[:, 3].max()), float(allbb[:, 4].max()), float(allbb[:, 5].max())]

# STEP flap surface against the NX flap surface
fl_solids = [s for s, r in zip(solids, rows) if 300 < r["volume"] < 10000]
pts = []
for s in fl_solids[:1]:
    BRepMesh_IncrementalMesh(s, 0.002, False, 0.1, True)
    fe = TopExp_Explorer(s, TopAbs_FACE)
    while fe.More():
        f = TopoDS.Face_s(fe.Current())
        loc = TopLoc_Location()
        tr = BRep_Tool.Triangulation_s(f, loc)
        if tr is not None:
            t = loc.Transformation()
            for i in range(1, tr.NbNodes() + 1):
                p = tr.Node(i).Transformed(t)
                pts.append((p.X(), p.Y(), p.Z()))
        fe.Next()
pts = np.array(pts)
nxm = Mesh(read_stl(os.path.join(WS, "out2", "dreame_brush_with_bristles_flaps.stl")))
d, sg, tid, q = closest(scene_of(nxm), nxm, pts)
res["flap_step_vs_nx_surface"] = {"points": int(len(pts)), "p50": float(np.percentile(d, 50)), "p95": float(np.percentile(d, 95)), "p99.9": float(np.percentile(d, 99.9)), "max": float(d.max()),
                                  "mean_signed": float(np.mean(d * sg)), "note": "NX reference = STL at chord 0.005"}
print(json.dumps(res, indent=1))
json.dump(res, open(os.path.join(QA2, "s1_step_check.json"), "w"), indent=1)
