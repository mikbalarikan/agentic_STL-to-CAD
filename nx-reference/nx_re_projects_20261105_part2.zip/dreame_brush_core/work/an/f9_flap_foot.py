"""Lower end of the flaps: do they stop on top of the drive blades or reach down between them to the hub disc?
Scan points in the strip of each flap (slot frame, |y| < 1.3) as (r, z), coloured by the direction of the normal;
the channel between two drive blades is drawn from the CAD core.   usage: f9_flap_foot.py"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common2 import *

SLOT0 = 1.1
T = load_T(os.path.join("..", "qa2", "T_asm.json"))
m = Mesh(apply(T, read_stl(SCAN_ASM_FULL)))
core = Mesh(read_stl(CAD_CORE))
P, N = m.c, m.n
tu, r, z = untwist(P)
rot = np.radians(-K_TWIST * (z - Z0))
nx_u = N[:, 0] * np.cos(rot) - N[:, 1] * np.sin(rot)
ny_u = N[:, 0] * np.sin(rot) + N[:, 1] * np.cos(rot)
fig, axs = plt.subplots(2, 4, figsize=(56, 26))
res = {}
for i in range(4):
    a = np.radians(tu - (SLOT0 + 90.0 * i))
    xl, yl = r * np.cos(a), r * np.sin(a)
    ca, sa = np.cos(np.radians(SLOT0 + 90.0 * i)), np.sin(np.radians(SLOT0 + 90.0 * i))
    nyl = -nx_u * sa + ny_u * ca
    nxl = nx_u * ca + ny_u * sa
    s = (np.abs(yl) < 1.3) & (xl > 6.5) & (xl < 18.5) & (z > 2.5) & (z < 17.0)
    ax = axs[0, i]
    for sel, col, lab in ((s & (nyl > 0.6), "tab:blue", "normal +y (flap face / blade back wall)"), (s & (nyl < -0.6), "tab:red", "normal -y (flap face / blade edge)"),
                          (s & (nxl > 0.6), "tab:green", "normal outwards (end faces)"), (s & (N[:, 2] > 0.8), "0.6", "normal up"), (s & (N[:, 2] < -0.8), "k", "normal down")):
        ax.scatter(xl[sel], z[sel], s=0.6, c=col, label=lab)
    ax.set_aspect("equal"); ax.set_xlim(6.5, 18.5); ax.set_ylim(2.5, 17.0); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(7, 18.6, 0.5)); ax.set_yticks(np.arange(2.5, 17.1, 0.5))
    ax.legend(markerscale=12, fontsize=11, loc="upper left")
    ax.set_title("flap %d: scan points within |y| < 1.3 of the slot plane, (r, z)" % i, fontsize=15)
    for zz, nm in ((3.35, "flange top"), (4.65, "hub disc top"), (6.5, "blade top")):
        ax.axhline(zz, color="tab:orange", lw=0.8)
        ax.text(17.2, zz + 0.05, nm, color="tab:orange", fontsize=11)
    # section z = 5.6 (between hub disc top and blade top): flap inside the channel?
    ax = axs[1, i]
    zc = 5.6
    arot = np.radians(-(SLOT0 + 90.0 * i) - K_TWIST * (zc - Z0))
    R2 = np.array([[np.cos(arot), -np.sin(arot)], [np.sin(arot), np.cos(arot)]])
    plot_segs(ax, core.section(2, zc)[:, :, :2] @ R2.T, colors="tab:red", linewidths=0.9)
    plot_segs(ax, m.section(2, zc)[:, :, :2] @ R2.T, colors="k", linewidths=0.9)
    ax.set_xlim(4.0, 17.5); ax.set_ylim(-3.0, 3.0); ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(4, 17.6, 0.5)); ax.set_yticks(np.arange(-3, 3.1, 0.25))
    ax.set_title("flap %d: section z = %g in the slot frame (black scan, red CAD core)" % (i, zc), fontsize=15)
    # numbers: lowest z of outward-facing end-face points of the flap between r 13.8 and 15.6, and of side-face points
    e = s & (nxl > 0.6) & (xl > 13.6) & (xl < 15.8) & (np.abs(yl) < 0.6) & (z > 4.7)
    sd = s & (np.abs(nyl) > 0.6) & (xl > 8.0) & (xl < 14.0) & (np.abs(yl) < 0.9)
    res[str(i)] = {"end_face_points": int(e.sum()), "end_face_z_p1_p50": [float(v) for v in np.percentile(z[e], [1, 50])] if e.sum() > 20 else None,
                   "side_face_z_p0.5_between_r8_r14": float(np.percentile(z[sd], 0.5)) if sd.sum() > 50 else None,
                   "end_face_r_by_z": [(float(zc_), round(float(np.median(xl[e & (np.abs(z - zc_) < 0.25)])), 2)) for zc_ in np.arange(5.0, 12.6, 0.5) if (e & (np.abs(z - zc_) < 0.25)).sum() > 8]}
    print(i, res[str(i)])
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f9_flap_foot.png"), dpi=40); plt.close(fig)
json.dump(res, open(os.path.join(QA2, "f9_flap_foot.json"), "w"), indent=1)
