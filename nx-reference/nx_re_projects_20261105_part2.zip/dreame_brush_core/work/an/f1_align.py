"""Assembled brush scan (core + flaps + bristles) -> datum frame of the core CAD.
Rough frame: PCA axis of the scan without its table, drive end found from the table. Fine pose: point-to-plane ICP of
the scan points near the axis onto the round-1 CAD core (hard surfaces only), from 36 clockings x coarse-to-fine
thresholds. Writes qa2/T_asm.json, qa2/f1_align.json.   usage: f1_align.py [full]"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import open3d as o3d
from common2 import *

full = "full" in sys.argv
raw = read_stl(SCAN_ASM_FULL if full else SCAN_ASM_20, every=4 if full else 1)
m = Mesh(raw)
print("triangles", len(raw), "area", round(float(m.a.sum()), 1))

# ---- rough frame ---------------------------------------------------------------------------------------------------
c0 = np.average(m.c, axis=0, weights=m.a)
w, e = np.linalg.eigh(np.cov((m.c - c0).T, aweights=m.a))
ax = e[:, 2]
for it in range(4):                                   # drop the table (far from the axis) and redo
    t = (m.c - c0) @ ax
    rr = np.linalg.norm((m.c - c0) - np.outer(t, ax), axis=1)
    keep = rr < 21.0
    c0 = np.average(m.c[keep], axis=0, weights=m.a[keep])
    w, e = np.linalg.eigh(np.cov((m.c[keep] - c0).T, aweights=m.a[keep]))
    ax = e[:, 2]
t = (m.c - c0) @ ax
rr = np.linalg.norm((m.c - c0) - np.outer(t, ax), axis=1)
far = rr > 22.0                                        # table points
if np.average(t[far], weights=m.a[far]) > 0:           # table must be at the low-z end
    ax = -ax
    t = -t
ex = np.cross([0.0, 0.0, 1.0], ax); ex /= np.linalg.norm(ex)
ey = np.cross(ax, ex)
R = np.stack([ex, ey, ax])
z_table = np.average(t[far], weights=m.a[far])
T0 = np.eye(4); T0[:3, :3] = R; T0[:3, 3] = -R @ c0 - np.array([0, 0, z_table])
src = Mesh(apply(T0, raw))
r, th, z = cyl(src.c)
print("rough frame: z range", round(float(z.min()), 2), round(float(z.max()), 2), "table points", int(far.sum()))

# ---- ICP target: CAD core ------------------------------------------------------------------------------------------
tgt = Mesh(read_stl(CAD_CORE))
Pt, it_ = tgt.sample(600_000, seed=1)
pt = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(Pt)); pt.normals = o3d.utility.Vector3dVector(tgt.n[it_])
# source: everything that can be core: near the axis along the length, the whole drive end, the bearing end
sk = ((r < 8.6) & (z > 4.0)) | ((r < 17.2) & (z > 0.6) & (z < 7.5))
ssub = src.sub(sk)
Ps, _ = ssub.sample(250_000, seed=2)
ps = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(Ps))
est = o3d.pipelines.registration.TransformationEstimationPointToPlane()
crit = o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=60)
sc = scene_of(tgt)


def score(T):
    d, sg, tid, q = closest(sc, tgt, apply(T, Ps))
    return float((d < 0.3).mean()), float(np.sqrt((d[d < 0.3] ** 2).mean()))


cands = []
for a in range(0, 360, 10):
    T = rotz(a)
    for thr in (3.0, 1.5, 0.8, 0.4):
        rg = o3d.pipelines.registration.registration_icp(ps, pt, thr, T, est, crit)
        T = np.array(rg.transformation)
    f, rm = score(T)
    cands.append({"start": a, "share_lt_0.3": f, "rms_lt_0.3": rm, "T": T.tolist(), "clock": float(np.degrees(np.arctan2(T[1, 0], T[0, 0]))) % 360,
                  "dz": float(T[2, 3]), "tilt": float(np.degrees(np.arccos(min(1.0, T[2, 2]))))})
cands.sort(key=lambda c: -c["share_lt_0.3"])
for c in cands[:12]:
    print(f"start {c['start']:3d}  clock {c['clock']:7.2f}  dz {c['dz']:+.3f}  tilt {c['tilt']:.3f}  share<0.3 {c['share_lt_0.3']:.4f}  rms {c['rms_lt_0.3']:.4f}")
T = np.array(cands[0]["T"])
for thr in (0.25, 0.15):
    rg = o3d.pipelines.registration.registration_icp(ps, pt, thr, T, est, o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=100))
    T = np.array(rg.transformation)
f, rm = score(T)
print("refined: share<0.3", f, "rms", rm, "clock", np.degrees(np.arctan2(T[1, 0], T[0, 0])) % 360)
Tfull = T @ T0

# ---- residual by zone (signed, + = scan outside the CAD core) ---------------------------------------------------------
al = Mesh(apply(Tfull, raw))
P, idx = al.sample(800_000, seed=3)
d, sg, tid, q = closest(sc, tgt, P)
rr2, th2, z2 = cyl(P)
zones = {"flange side r16.45 (z 0.3-3.2)": (z2 > 0.3) & (z2 < 3.2) & (rr2 > 15.9) & (rr2 < 17.0),
         "hub disc and blades (z 3.3-6.6)": (z2 > 3.3) & (z2 < 6.6) & (rr2 < 15.7),
         "core z 7-40": (z2 > 7) & (z2 < 40) & (rr2 < 7.9), "core z 40-100": (z2 > 40) & (z2 < 100) & (rr2 < 7.9),
         "core z 100-160": (z2 > 100) & (z2 < 160) & (rr2 < 7.9), "bearing end z > 160": (z2 > 160) & (rr2 < 7.9)}
res = {"source": os.path.basename(SCAN_ASM_FULL if full else SCAN_ASM_20), "candidates": [{k: v for k, v in c.items() if k != "T"} for c in cands[:12]],
       "share_lt_0.3": f, "rms_lt_0.3": rm, "zones": {}}
for k, s in zones.items():
    near = s & (d < 0.5)
    res["zones"][k] = {"n": int(s.sum()), "share_within_0.5": float(near.sum() / max(1, s.sum())), **{a: b for a, b in stats((d * sg)[near]).items() if a in ("mean_signed", "p50", "p95", "rms")}}
    print(k, res["zones"][k])
res["z_range_aligned"] = [float(al.lo[:, 2].min()), float(al.hi[:, 2].max())]
rr3 = np.hypot(al.c[:, 0], al.c[:, 1])
res["r_max_part (z 8-165)"] = float(np.percentile(rr3[(al.c[:, 2] > 8) & (al.c[:, 2] < 165)], 99.9))
print("z range", res["z_range_aligned"], "r p99.9", res["r_max_part (z 8-165)"])
json.dump({"T": Tfull.tolist(), "note": "raw assembled with-bristles scan -> datum frame of the core CAD (ICP on the CAD core)", "source": res["source"]},
          open(os.path.join(QA2, "T_asm_full.json" if full else "T_asm.json"), "w"), indent=1)
json.dump(res, open(os.path.join(QA2, "f1_align_full.json" if full else "f1_align.json"), "w"), indent=1)
