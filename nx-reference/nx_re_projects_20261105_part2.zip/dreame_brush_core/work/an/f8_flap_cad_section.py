﻿"""Section of the CAD flap (STL) in the slot frame: bead shape, shoulder chamfer legs, tip round - against the scan.
usage: f8_flap_cad_section.py <flaps.stl> [tag]"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common2 import *

src = sys.argv[1]
tag = sys.argv[2] if len(sys.argv) > 2 else ""
SLOT0 = 1.1
cad = Mesh(read_stl(src))
T = load_T(os.path.join("..", "qa2", "T_asm.json"))
scan = Mesh(apply(T, read_stl(SCAN_ASM_FULL, every=1)))


def local(seg, zc, i=0):
    a = np.radians(-(SLOT0 + 90.0 * i) - K_TWIST * (zc - Z0))
    R = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    return seg[:, :, :2] @ R.T


zs = [(90.0, 3), (115.0, 1), (40.0, 0), (160.0, 0), (10.0, 2), (13.6, 2)]
fig, axs = plt.subplots(2, 3, figsize=(48, 24))
out = {}
for ax, (zc, i) in zip(axs.ravel(), zs):
    sc = local(scan.section(2, zc), zc, i)
    cd = local(cad.section(2, zc), zc, i)
    keep = lambda s: s[(s[:, :, 0].min(axis=1) > 4.0) & (np.abs(s[:, :, 1]).max(axis=1) < 4.0)]
    sc, cd = keep(sc), keep(cd)
    plot_segs(ax, sc, colors="k", linewidths=0.9)
    plot_segs(ax, cd, colors="tab:red", linewidths=1.1)
    ax.set_xlim(4.5, 18.0); ax.set_ylim(-3.2, 3.2); ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(5, 18.1, 0.5)); ax.set_yticks(np.arange(-3, 3.1, 0.25))
    ax.set_title("z = %g, flap in slot %d (slot frame): black scan, red CAD flap" % (zc, i), fontsize=16)
    p = cd.reshape(-1, 2)
    if len(p):
        up = p[p[:, 1] > 0]
        # thickness profile of the CAD flap: half width at x stations
        prof = []
        for xc in np.arange(5.0, 17.6, 0.05):
            q = up[np.abs(up[:, 0] - xc) < 0.03]
            if len(q):
                prof.append((round(float(xc), 2), round(float(q[:, 1].max()), 3)))
        out["z%g" % zc] = {"x_max": float(p[:, 0].max()), "x_min": float(p[:, 0].min()), "half_width_by_x": prof}
fig.tight_layout(); fig.savefig(os.path.join(FIG2, "f8_flap_cad_sections%s.png" % tag), dpi=45); plt.close(fig)
json.dump(out, open(os.path.join(QA2, "f8_flap_cad_section%s.json" % tag), "w"), indent=1)
for k, v in out.items():
    hw = v["half_width_by_x"]
    print(k, "x %.3f .. %.3f" % (v["x_min"], v["x_max"]), "half width near the bead:", [h for h in hw if h[0] > v["x_max"] - 2.6][::2])

