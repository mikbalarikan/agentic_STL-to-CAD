"""Where do the bristle tufts come closest to the flaps (and to the core outside their own hole)?
Vertices of the tuft mesh against the flap mesh.   usage: f10_tuft_flap_gap.py"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common2 import *

O2 = os.path.join(WS, "out2")
NAME = "dreame_brush_with_bristles"
tu_ = read_stl(os.path.join(O2, NAME + "_tufts.stl"))
fl = Mesh(read_stl(os.path.join(O2, NAME + "_flaps.stl")))
V = np.unique(tu_.reshape(-1, 3).round(4), axis=0)
d, sg, tid, q = closest(scene_of(fl), fl, V)
i = int(np.argmin(d))
r, th, z = cyl(V)
ang_u, _, _ = untwist(V)
print("tuft vertices", len(V), "smallest distance to a flap %.4f mm" % d[i])
print("  at tuft point", V[i].round(3), "r %.3f z %.3f untwisted angle %.2f" % (r[i], z[i], ang_u[i]))
qr, qth, qz = cyl(q[i][None])
print("  nearest flap point", q[i].round(3), "r %.3f z %.3f untwisted angle %.2f" % (qr[0], qz[0], untwist(q[i][None])[0][0]))
rows = []
for a, b in ((7.0, 8.0), (8.0, 9.0), (9.0, 11.0), (11.0, 14.0), (14.0, 17.0), (17.0, 19.5)):
    s = (r >= a) & (r < b)
    if s.any():
        rows.append({"r": [a, b], "min_gap": float(d[s].min()), "p1": float(np.percentile(d[s], 1)), "p50": float(np.percentile(d[s], 50))})
        print("  tuft points r %g-%g: min gap %.3f  p1 %.3f  p50 %.3f" % (a, b, d[s].min(), np.percentile(d[s], 1), np.percentile(d[s], 50)))
json.dump({"min_gap": float(d[i]), "tuft_point": V[i].tolist(), "flap_point": q[i].tolist(), "by_radius": rows}, open(os.path.join(QA2, "f10_tuft_flap_gap.json"), "w"), indent=1)
