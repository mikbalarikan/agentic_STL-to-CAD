"""First look at the aligned assembled scan: renders, z sections over the CAD core, untwisted pooled sections per z band,
unrolled r_max(theta_u, z) map.   usage: f2_look.py [full]"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common2 import *

full = "full" in sys.argv
T = load_T(os.path.join("..", "qa2", "T_asm.json"))
m = Mesh(apply(T, read_stl(SCAN_ASM_FULL if full else SCAN_ASM_20, every=2 if full else 1)))
core = Mesh(read_stl(CAD_CORE))
tag = "_full" if full else ""

# z sections
zs = (8.0, 12.0, 20.0, 40.0, 85.0, 130.0, 150.0, 160.0, 166.0)
fig, axs = plt.subplots(1, len(zs), figsize=(10 * len(zs), 10))
for ax, zc in zip(axs, zs):
    plot_segs(ax, core.section(2, zc)[:, :, :2], colors="tab:red", linewidths=0.8)
    plot_segs(ax, m.section(2, zc)[:, :, :2], colors="k", linewidths=0.7)
    ax.set_xlim(-21, 21); ax.set_ylim(-21, 21); ax.grid(True, lw=0.3); ax.set_title(f"z = {zc}  (black scan, red CAD core)")
fig.tight_layout(); fig.savefig(os.path.join(FIG2, f"f2_sections{tag}.png"), dpi=50); plt.close(fig)

# untwisted pooled sections
P, idx = m.sample(4_000_000, seed=5)
tu, r, z = untwist(P)
x, y = r * np.cos(np.radians(tu)), r * np.sin(np.radians(tu))
bands = [(8, 14), (14, 30), (30, 60), (60, 100), (100, 140), (140, 156), (156, 168)]
fig, axs = plt.subplots(1, len(bands), figsize=(12 * len(bands), 12))
for ax, (a, b) in zip(axs, bands):
    s = (z > a) & (z < b) & (r < 21)
    ax.hist2d(x[s], y[s], bins=[np.arange(-21, 21.01, 0.05)] * 2, cmap="Greys", norm=matplotlib.colors.LogNorm())
    cs = core.section(2, Z0)[:, :, :2]
    plot_segs(ax, cs, colors="tab:red", linewidths=0.5)
    ax.set_xlim(-21, 21); ax.set_ylim(-21, 21); ax.set_aspect("equal"); ax.grid(True, lw=0.3)
    ax.set_xticks(np.arange(-20, 21, 2)); ax.set_yticks(np.arange(-20, 21, 2))
    ax.set_title(f"untwisted to z0 = {Z0}, pooled z {a}..{b}  (red: CAD core section at z0)")
fig.tight_layout(); fig.savefig(os.path.join(FIG2, f"f2_untwisted{tag}.png"), dpi=50); plt.close(fig)

# unrolled outer envelope
tb = np.arange(0, 361, 1.0); zb = np.arange(0, 171, 1.0)
ti = np.clip((tu / 1.0).astype(int), 0, 359); zi = np.clip(z.astype(int), 0, 169)
ok = (z > 0.2) & (r < 22)
env = np.zeros((170, 360))
np.maximum.at(env, (zi[ok], ti[ok]), r[ok])
fig, ax = plt.subplots(figsize=(30, 14))
im = ax.imshow(env, origin="lower", extent=(0, 360, 0, 170), aspect="auto", cmap="turbo", vmin=7, vmax=20)
plt.colorbar(im, ax=ax, label="outer radius (mm)")
ax.set_xlabel("untwisted angle at z0 (deg)"); ax.set_ylabel("z (mm)"); ax.set_xticks(np.arange(0, 361, 15)); ax.set_yticks(np.arange(0, 171, 10)); ax.grid(True, lw=0.3)
ax.set_title("assembled scan: outer radius per (untwisted angle, z)")
fig.tight_layout(); fig.savefig(os.path.join(FIG2, f"f2_envelope{tag}.png"), dpi=60); plt.close(fig)
np.save(os.path.join(QA2, "f2_env.npy"), env)

# renders
import pyvista as pv
v = m.tri.reshape(-1, 3); f = np.c_[np.full(len(m.tri), 3), np.arange(len(v)).reshape(-1, 3)]
pm = pv.PolyData(v, f.ravel()).clean()
pl = pv.Plotter(off_screen=True, shape=(1, 5), window_size=(4000, 1700))
cen = np.array([0, 0, 85.0])
for i, (d, up) in enumerate([((1, 0, 0), (0, 0, 1)), ((0, 1, 0), (0, 0, 1)), ((0.6, 0.6, 0.5), (0, 0, 1)), ((0.25, 0.2, 1), (0, 1, 0)), ((0.25, 0.2, -1), (0, 1, 0))]):
    pl.subplot(0, i)
    pl.add_mesh(pm, color="#9aa7ad", smooth_shading=False)
    d = np.array(d, float); d /= np.linalg.norm(d)
    pl.camera.focal_point = cen; pl.camera.position = cen + d * 400; pl.camera.up = up
    pl.camera.parallel_projection = True; pl.reset_camera(); pl.camera.zoom(1.35)
pl.set_background("white")
pl.screenshot(os.path.join(FIG2, f"f2_render_scan{tag}.png"))
print("done")
