"""Round 2 (2026-10-09): the assembled brush with bristles = core + silicone flaps + bristles.
Same datum frame as round 1 (Datum CSYS of dreame_brush_core_with_bristles.prt)."""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from common import *

PRJ = r"C:\Users\marya\Downloads\Projects\CAD_Projects"
SCAN_ASM_20 = os.path.join(PRJ, r"dreame_brush_no_bristles (1)\dreame_brush_with_bristles_decimated_20MB.stl")
SCAN_ASM_FULL = os.path.join(PRJ, r"dreame_brush_no_bristles (1)\dreame_brush_with_bristles.stl")
SCAN_NB_20 = os.path.join(PRJ, r"dreame_brush_no_bristles (1)\dreame_brush_no_bristles_decimated_20MB.stl")
SCAN_CORE_FULL = os.path.join(PRJ, r"dreame_brush_core_with_bristles (1)\dreame_brush_core_with_bristles.stl")
SCAN_CORE_DATUM = os.path.join(OUT, "scan_core_with_bristles_datum.stl")          # round 1, datum frame, 376 k triangles
CAD_CORE = os.path.join(OUT, "dreame_brush_core_with_bristles_core.stl")          # round 1 CAD core, datum frame
K_TWIST = -360.0 / 225.75                                                        # deg per mm (left hand), model value
Z0 = 6.5                                                                         # z_core0: height at which twisted angles are quoted
FIG2 = os.path.join(WS, "fig2")
QA2 = os.path.join(WS, "qa2")
for d in (FIG2, QA2):
    os.makedirs(d, exist_ok=True)


def rotz(a):
    c, s = np.cos(np.radians(a)), np.sin(np.radians(a))
    R = np.eye(4); R[0, 0], R[0, 1], R[1, 0], R[1, 1] = c, -s, s, c
    return R


def untwist(p, k=K_TWIST, z0=Z0):
    """angle (deg) of points reduced to z0 along the helix, radius, z."""
    r, th, z = cyl(p)
    return (th - k * (z - z0)) % 360.0, r, z
