"""Compare the files copied into the repo example with their sources (sha256); figures are re-encoded, so only listed.
usage: verify_repo.py <target dir>"""
import os, sys, hashlib

DLV = r"C:\Users\marya\Downloads\dreame_brush_core_with_bristles_nx"
DST = sys.argv[1]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


same = diff = extra = 0
tot = 0
for r, d, fs in os.walk(DST):
    for f in fs:
        p = os.path.join(r, f)
        rel = os.path.relpath(p, DST)
        tot += os.path.getsize(p)
        if rel.startswith("figures") or rel == "README.md":
            extra += 1
            continue
        src = os.path.join(DLV, rel[len("result") + 1:] if rel.startswith("result") else rel)
        if os.path.exists(src) and sha(src) == sha(p):
            same += 1
        else:
            diff += 1
            print("DIFFERENT or no source:", rel)
print("identical to the delivery: %d, different: %d, own files (README, figures): %d, total %.2f MB" % (same, diff, extra, tot / 1e6))
empty = [os.path.join(r, f) for r, d, fs in os.walk(DST) for f in fs if os.path.getsize(os.path.join(r, f)) == 0]
print("zero-length files:", empty)
