param([string]$Stages = "abcdefz", [int]$Timeout = 3000)
# Runs the round-2 build journal for the given stages and prints the check table.   powershell -File run2.ps1 -Stages abcdefz
# Without "a" the journal continues on a copy of out2\dreame_brush_with_bristles_stage_d.prt.
$s = 'C:\Users\marya\.claude\skills\nx-journal-core\scripts'
$w = 'C:\NX_MCP_WORKSPACE\dreame_brush'
New-Item -ItemType Directory -Force "$w\out2" | Out-Null
$t0 = Get-Date
& "$s\run_journal.ps1" -Script "$w\build2.py" -WorkDir $w -JArgs "$w\out2", $Stages -TimeoutSec $Timeout 2>&1 | Select-Object -Last 3
"elapsed " + [int]((Get-Date) - $t0).TotalSeconds + " s"
python "$w\show.py" "$w\out2\build2_$Stages.json"
