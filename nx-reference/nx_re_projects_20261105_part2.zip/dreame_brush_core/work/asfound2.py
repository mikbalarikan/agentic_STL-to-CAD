"""As-found read-back of the delivered part: opens a COPY, reports features, bodies, names, colours, expressions,
sketch status, clearances between the parts.   usage: run_journal asfound2.py -args <part.prt> <out dir>"""
import os, sys, shutil, traceback, math
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf

SRC, OUT = sys.argv[1], sys.argv[2]
res = {"result": "FAIL", "source": SRC}
try:
    tmp = os.path.join(OUT, "asfound_copy.prt")
    if os.path.exists(tmp):
        os.remove(tmp)
    shutil.copyfile(SRC, tmp)
    part = nxh.open_part(tmp)
    top, internal = nxh.top_features(part)
    res["features_top"] = len(top)
    res["features_all_rows"] = len(top) + internal
    res["suppressed"] = [f.GetFeatureName() for f in top if f.Suppressed]
    res["errors"] = {k: str(v)[:200] for k, v in (nxh.feature_errors(part) or {}).items()}
    kinds = {}
    for f in top:
        kinds[f.FeatureType] = kinds.get(f.FeatureType, 0) + 1
    res["feature_types_top"] = kinds
    res["unnamed_top"] = [f.GetFeatureName() for f in top if not f.Name]
    res["groups"] = [f.Name for f in part.Features.GetFeatures() if f.FeatureType == "FSET"]
    sol = nxh.solids(part)
    by = {}
    for b in sol:
        r = by.setdefault(b.Name or "(unnamed)", {"n": 0, "volume": 0.0, "faces": 0, "colours": set(), "layers": set()})
        r["n"] += 1
        r["volume"] += nxh.volume(part, b)
        r["faces"] += len(b.GetFaces())
        r["colours"].add(int(b.Color))
        r["layers"].add(int(b.Layer))
    res["solids"] = len(sol)
    res["sheets"] = len(nxh.sheets(part))
    res["bodies_by_name"] = {k: {"n": v["n"], "volume": round(v["volume"], 3), "faces": v["faces"], "colours": sorted(v["colours"]), "layers": sorted(v["layers"])} for k, v in by.items()}
    core = [b for b in sol if b.Name == "CORE"]
    flaps = [b for b in sol if b.Name == "SILICONE_FLAP"]
    tufts = [b for b in sol if b.Name == "BRISTLE_TUFT"]
    if core and flaps:
        res["gap_flap_core_min"] = min(nxh.min_dist(b, core[0]) for b in flaps)
    if flaps and tufts:
        g = []
        for t in tufts:
            g.append(min(nxh.min_dist(t, fb) for fb in flaps))
        res["gap_tuft_flap_min"] = min(g)          # inside the core: bottom of the root plug against the flap foot
        res["gap_tuft_flap_max_of_the_54"] = max(g)
    bb = [nxh.bbox(b) for b in sol]
    res["bbox_all"] = [round(min(b[i] for b in bb), 3) for i in range(3)] + [round(max(b[i] for b in bb), 3) for i in range(3, 6)]
    sk = []
    for s in part.Sketches:
        st = nxf.sketch_status(s)
        ad = nxf.auto_dimensions(s)
        sk.append((s.Name, st[0], st[1], ad if isinstance(ad, int) else len(ad)))
    res["sketches"] = len(sk)
    res["sketches_not_fully_constrained"] = [x for x in sk if x[1] != "WellConstrained" or x[2] or x[3]]
    named = nxh.user_expressions(part)
    res["named_expressions"] = len(named)
    res["named_expression_list"] = sorted(e.Name for e in named)
    res["expressions_total"] = len(list(part.Expressions))
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "asfound2.json"), res)
