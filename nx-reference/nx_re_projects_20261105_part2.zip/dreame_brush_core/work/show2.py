"""Details of a build2 result for the report.   usage: show2.py <build2_*.json>"""
import json, sys
d = json.load(open(sys.argv[1]))
ch = d.get("checks", [])
print("RESULT", d["result"], "| checks", len(ch), "failed", sum(1 for r in ch if not r["ok"]), "| top features", d.get("n_features_top"), "| sketches", len(d.get("sketches", {})))
print("volumes core / flaps / tufts:", d.get("volume_core"), d.get("volume_flaps"), d.get("volume_tufts"), "| faces total", d.get("faces_total"))
print("named masters:", len(d.get("masters", {})))
for r in ch:
    n = r["name"]
    if any(k in n for k in ("FLAP_BLANK", "FLAP_WEB =", "FLAP_BEAD", "flap web wall", "flap tip", "flap:", "clear", "seed tufts", "STEP", "Examine", "volume back", "54 tufts", "4 flap")):
        print(("ok   " if r["ok"] else "FAIL ") + n, "| got", r.get("got", ""), "| want", r.get("want", ""), "|", str(r.get("note", ""))[:260])
print("--- regeneration")
for r in d.get("regeneration", []):
    print(("ok   " if r["ok"] else "FAIL ") + r["name"], r["from"].split("//")[0].strip(), "->", r["to"], "|", r.get("seconds"), "s |", str(r.get("check"))[:330], "| errors", r.get("errors"))
print("--- step", json.dumps(d.get("step_roundtrip")))
print("--- colours", d.get("colours"), "| step size", d.get("step_size"))
print("--- notes flap", json.dumps(d["notes"].get("flap"))[:900])
print("--- notes tufts", json.dumps({k: v for k, v in d["notes"].get("tufts", {}).items() if k != "variants"}))
print("--- log", d.get("log"))
types = {}
for n, t in d.get("features", []):
    types[t] = types.get(t, 0) + 1
print("--- feature rows by type", types)
