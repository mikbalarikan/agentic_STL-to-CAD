﻿"""Off-line test of the pure-Python parts of build2.py (no NX): filament generation, flap volume integrals."""
import ast, math, os, sys, time

WS = os.path.dirname(os.path.abspath(__file__))
tree = ast.parse(open(os.path.join(WS, "build2.py"), encoding="utf-8").read())
want_fn = {"rotz", "seg_dist", "tuft_place", "make_filaments", "flap_lines", "interp", "strip_seg", "flap_volumes", "revolve_volume"}
want_const = {"N_RING", "FIL_PITCH", "FAN_U", "FAN_V", "JIT_U", "JIT_V", "LEAN_T", "TIP_JIT", "SINK", "VARIANTS", "MAX_U", "FIL_GAP"}
ns = {"math": math}
body = []
for n in tree.body:
    if isinstance(n, ast.FunctionDef) and n.name in want_fn:
        body.append(n)
    elif isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in want_const for t in n.targets):
        body.append(n)
    elif isinstance(n, ast.Assign) and any(isinstance(t, ast.Tuple) and any(getattr(e, "id", "") in want_const for e in t.elts) for t in n.targets):
        body.append(n)
exec(compile(ast.Module(body=body, type_ignores=[]), "build2_pure", "exec"), ns)

M = dict(d_core=14.95, d_brush=37.0, tuft_lean=40.0, d_tuft_hole=2.0, tuft_hole_depth=3.0, tuft_root_h=1.0, d_fil=0.15, tuft_z0=10.55, tuft_pitch=4.9,
         twist_lead=225.75, z_core0=6.5, tuft_ang0=36.1, h_total=169.75, slot_neck_r=6.05, slot_floor_r=4.88, flap_t=0.94, flap_foot_w=2.0, flap_foot_gap=0.1,
         bead_t=1.44, bead_len=1.5, flap_z0=6.6, flap_end_gap=1.95, flap_taper_len=21.8, flap_foot_r0=14.8, flap_foot_r1=15.4, flap_step_z0=12.6,
         flap_step_z1=14.3, flap_r_a=17.1, flap_r_b=16.25, flap_r_end=9.1)
M["tuft_ang_seed"] = M["tuft_ang0"] - 360.0 * (M["tuft_z0"] - M["z_core0"]) / M["twist_lead"]
for vn, seed in ns["VARIANTS"]:
    t = time.time()
    f = ns["make_filaments"](M, seed)
    hs = [x["h"] for x in f]
    tips = [math.hypot(*ns["tuft_place"](M, tuple(x["start"][j] + x["dir"][j] * x["h"] for j in range(3)))[:2]) for x in f]
    zt = [ns["tuft_place"](M, tuple(x["start"][j] + x["dir"][j] * x["h"] for j in range(3)))[2] - M["tuft_z0"] for x in f]
    print(vn, len(f), "filaments in %.2f s" % (time.time() - t), "length %.2f..%.2f" % (min(hs), max(hs)), "tip r %.2f..%.2f" % (min(tips), max(tips)),
          "tip z above root %.1f..%.1f" % (min(zt), max(zt)), "au %.1f..%.1f av %.1f..%.1f" % (min(x["au"] for x in f), max(x["au"] for x in f), min(x["av"] for x in f), max(x["av"] for x in f)),
          "start rho max %.3f" % max(math.hypot(x["start"][1], x["start"][2]) for x in f))
    # every filament must leave the plug through its top face: radius at the plug top < plug radius
    worst = max(math.hypot(x["start"][1] + x["dir"][1] * ns["SINK"] / x["dir"][0], x["start"][2] + x["dir"][2] * ns["SINK"] / x["dir"][0]) + M["d_fil"] / 2 for x in f)
    print("   largest radius at the plug top incl. filament radius: %.3f (plug %.3f)" % (worst, M["d_tuft_hole"] / 2))
vw, vb = ns["flap_volumes"](M)
vw2, vb2 = ns["flap_volumes"](M, M["h_total"] - M["flap_end_gap"])
print("flap web volume %.2f (to z1: %.2f), bead volume %.2f (to z1: %.2f)" % (vw, vw2, vb, vb2))
outer, web, z1, zt_, ze, re = ns["flap_lines"](M)
print("outline", outer, "web", web, "z1", z1, "zt", zt_, "re", re)
print("taper slope", (M["flap_r_end"] - M["flap_r_b"]) / M["flap_taper_len"], "inner radius at z1", M["flap_r_end"] - M["bead_len"])


