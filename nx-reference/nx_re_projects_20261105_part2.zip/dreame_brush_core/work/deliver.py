﻿"""Assemble the delivery folder (never overwrites an existing folder).  usage: deliver.py"""
import os, sys, json, shutil

WS = r"C:\NX_MCP_WORKSPACE\dreame_brush"
DST = r"C:\Users\marya\Downloads\dreame_brush_core_with_bristles_nx"
NAME = "dreame_brush_core_with_bristles"
if os.path.exists(DST) and "update" not in sys.argv:
    raise SystemExit("delivery folder exists: " + DST)
for sub in ("", "figures", "journal", "journal/nxlib", "analysis", "qa"):
    os.makedirs(os.path.join(DST, sub), exist_ok=True)


def cp(src, dst):
    shutil.copyfile(os.path.join(WS, src), os.path.join(DST, dst))


for f in (NAME + ".prt", NAME + ".step", NAME + "_with_scans.prt", NAME + "_core.stl", NAME + "_tufts.stl"):
    cp(os.path.join("out", f), f)
figs = {"iki_farkli_cekirdek.png": "01_referans_ve_killi_tarama_farkli_cekirdek.png",
        "render_side_cad.png": "02_render_yan_cad.png", "render_side_scan.png": "02_render_yan_tarama.png", "render_overlay_side.png": "02_render_yan_bindirme.png",
        "render_iso_cad.png": "03_render_iso_cad.png", "render_iso_scan.png": "03_render_iso_tarama.png",
        "render_drive_end_cad.png": "04_render_tahrik_ucu_cad.png", "render_drive_end_scan.png": "04_render_tahrik_ucu_tarama.png",
        "render_underside_cad.png": "05_render_alt_yuz_cad.png", "render_underside_scan.png": "05_render_alt_yuz_taban_taramasi.png",
        "render_idler_end_cad.png": "06_render_rulman_ucu_cad.png", "render_idler_end_scan.png": "06_render_rulman_ucu_tarama.png",
        "dev_final_map.png": "07_sapma_haritasi_cekirdek.png", "dev_final_ends.png": "08_sapma_haritasi_uclar_ve_alt_yuz.png",
        "ovl_final_z.png": "09_kesit_bindirme_z.png", "ovl_final_rz.png": "10_kesit_bindirme_yari_kesit.png",
        "m2_untwisted.png": "11_olcum_acilmis_cekirdek_kesiti.png", "m6_shells.png": "12_olcum_kil_demetleri_acilim.png",
        "m7_underside.png": "13_olcum_alt_yuz.png", "v_ref_a_cad.png": "14_referans_cad_gorunum.png", "b0_sections.png": "15_referans_cad_kendi_taramasina_gore.png"}
for a, b in figs.items():
    cp(os.path.join("fig", a), os.path.join("figures", b))
for f in ("build.py", "review.py", "run.ps1", "show.py", "probe_ref.py", "export_ref.py", "probe1.py", "probe2.py", "probe3.py"):
    cp(f, os.path.join("journal", f))
for f in ("ps.py", "geo.py"):
    cp(os.path.join("nxlib", f), os.path.join("journal", "nxlib", f))
for f in sorted(os.listdir(os.path.join(WS, "an"))):
    if f.endswith(".py"):
        cp(os.path.join("an", f), os.path.join("analysis", f))
b = json.load(open(os.path.join(WS, "out", "build_z.json")))
json.dump(b, open(os.path.join(DST, "qa", "build_checks.json"), "w"), indent=1)
json.dump(b["masters"], open(os.path.join(DST, "qa", "masters.json"), "w"), indent=1, ensure_ascii=False)
for f in ("T_bristles.json", "T_base.json", "T_base_icp.json", "m1_align.json", "m2_twist.json", "m3_profile.json", "m4_base.json", "m5_top.json", "m6_tufts.json",
          "m7_base_align.json", "m7_recentre.json", "m7_underside.json", "m7_hex.json", "m8_misc.json", "b0_baseline.json", "dev_final.json", "dev_final_outliers.json", "dev_final_cad_to_scan.json", "dev_final_underside_icp.json",
          "ref_a_asfound.txt", "ref_a_asfound.json", "prt_text_ref_a.json", "prt_text_ref_b.json"):
    if os.path.exists(os.path.join(WS, "qa", f)):
        cp(os.path.join("qa", f), os.path.join("qa", f))
for f in ("review.json", "probe_a.json", "export_a.json", "export_b.json", "probe1.json", "probe2.json", "probe3.json"):
    if os.path.exists(os.path.join(WS, "out", f)):
        cp(os.path.join("out", f), os.path.join("qa", f))
if os.path.exists(os.path.join(WS, "REPORT.md")):
    cp("REPORT.md", "REPORT.md")
tot = 0
for r, d, fs in os.walk(DST):
    for f in fs:
        tot += os.path.getsize(os.path.join(r, f))
print("delivered to", DST, "- %.1f MB" % (tot / 1e6))
print(json.dumps({k: v for k, v in b.items() if k in ("result", "n_features_top", "volume_core", "volume_tufts")}))
print("checks", len(b["checks"]), "failed", sum(1 for c in b["checks"] if not c["ok"]))
