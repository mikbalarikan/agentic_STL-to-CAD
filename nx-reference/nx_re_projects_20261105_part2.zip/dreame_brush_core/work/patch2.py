import ast
p = r"C:\NX_MCP_WORKSPACE\dreame_brush\build.py"
b = open(p, "rb").read()
if b[:3] == b"\xef\xbb\xbf":
    b = b[3:]
t = b.replace(b"\r\n", b"\n").decode("utf-8")


def rep(old, new, count=1):
    global t
    assert t.count(old) == count, (t.count(old), old[:60])
    t = t.replace(old, new)


rep("        hd.RotationAxis = nxf.axis_from(p, c.dat.z)\n", "        hd.RotationAxis = nxh.axis(p, (0, 0, 0), Z)\n")
# solids census after each idler-end feature
rep("""    f.SetName("IDLER_BORE")
""", """    f.SetName("IDLER_BORE")
    c.notes["solids_after_IDLER_BORE"] = [round(c.vol(b), 3) for b in nxh.solids(p)]
""")
rep("""    f.SetName("END_ROUND")
""", """    f.SetName("END_ROUND")
    c.notes["solids_after_END_ROUND"] = [round(c.vol(b), 3) for b in nxh.solids(p)]
""")
rep("""    f.SetName("KEY_NOTCH")
""", """    f.SetName("KEY_NOTCH")
    c.notes["solids_after_KEY_NOTCH"] = [(round(c.vol(b), 4), nxh.bbox(b)) for b in nxh.solids(p)]
""")
ast.parse(t)
open(p, "w", encoding="utf-8", newline="\n").write(t)
print("patched ok")
