import ast
p = r"C:\NX_MCP_WORKSPACE\dreame_brush\build.py"
b = open(p, "rb").read()
if b[:3] == b"\xef\xbb\xbf":
    b = b[3:]
t = b.replace(b"\r\n", b"\n").decode("utf-8")


def rep(old, new, count=1):
    global t
    assert t.count(old) == count, (t.count(old), old[:80])
    t = t.replace(old, new)


# the end of the centre groove is tied to the idler end face, not to an absolute height (h_total may change)
rep('''    e("z_ag1", 163.5, "centre groove ends at this height (scan: runs out before the idler end)")''',
    '''    e("ag_end_gap", 6.25, "centre groove ends this far before the idler end face (scan: runs out before the end)")''')
rep('''    fz1, dpb = nxf.datum_plane(p, "offset", [c.dat.xy], "z_ag1", "DP_CENTRE_GROOVE_END")''',
    '''    fz1, dpb = nxf.datum_plane(p, "offset", [c.dat.xy], "h_total-ag_end_gap", "DP_CENTRE_GROOVE_END")''')
rep('''trim_plane2=dpb, z_to=M["z_ag1"])''', '''trim_plane2=dpb, z_to=M["h_total"] - M["ag_end_gap"])''')
ast.parse(t)
open(p, "w", encoding="utf-8", newline="\n").write(t)
q = r"C:\NX_MCP_WORKSPACE\dreame_brush\show.py"
s = open(q, encoding="utf-8").read()
old = '''    if k in d:
        print(k, ":", d[k])'''
new = '''    if k in d:
        v = d[k]
        if k == "step_roundtrip":
            v = dict(v)
            ex = v.pop("examine", None) or []
            v["examine_bodies"] = len(ex)
            v["examine_findings"] = sum(sum(x.values()) for x in ex if isinstance(x, dict))
        print(k, ":", v)'''
assert old in s
open(q, "w", encoding="utf-8", newline="\n").write(s.replace(old, new))
print("patched ok")
