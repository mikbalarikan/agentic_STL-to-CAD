"""Fill the tokens of REPORT2.md from the final results.   usage: fill_report.py"""
import json, os
WS = os.path.dirname(os.path.abspath(__file__))
O2 = os.path.join(WS, "out2")
b = json.load(open(os.path.join(O2, "build2_abcdefz.json")))
af = json.load(open(os.path.join(O2, "asfound2.json")))
er = json.load(open(os.path.join(WS, "out2e", "build2_e.json")))
s = open(os.path.join(WS, "REPORT2.md"), encoding="utf-8").read()


def tr(x, nd=3):
    return ("%.*f" % (nd, x)).replace(".", ",")


ch = b["checks"]
nfail = sum(1 for c in ch if not c["ok"])
ech = er["checks"]
st = b["step_roundtrip"]
reg = b["regeneration"]
bn = af["bodies_by_name"]
rep = {
    "⟦STEPMB⟧": tr(b["step_size"] / 1e6, 1),
    "⟦CHECKS⟧": "%d kontrolün %d'sı geçti. Geçmeyen tek kontrol boncuk omzundaki pah: kuruldu, kendi ölçüm kontrolünden geçemedi, geri alındı (aşağıda). "
                "Bu adım journal'dan çıkarıldıktan sonra kanat aşaması ayrıca yeniden koşuldu: %d / %d kontrol, bir kanat %s mm³ (teslim edilen parçayla aynı)"
                % (len(ch), len(ch) - nfail, sum(1 for c in ech if c["ok"]), len(ech), tr(er["notes"]["flap"]["volume_one"], 2)),
    "⟦SKETCHES⟧": "%d / %d DOF 0, otomatik ölçü 0" % (sum(1 for v in b["sketches"].values() if v["dof"] == 0 and v["auto_dims"] == 0 and v["status"] == "WellConstrained"), len(b["sketches"])),
    "⟦WEBVOL⟧": "gövde 1 666,403 / 1 666,397 · boncuk 338,065 / 338,048 mm³",
    "⟦PROBES⟧": "0,001 / 0,002 / 0,000 mm · 0,000 / 0,000 mm",
    "⟦TUFTGAP⟧": "çekirdeğin dışında kökte ≥ 2,5 mm, uçlarda ≥ 7,8 mm (mozaikten); gövdeler arası mutlak en küçük mesafe %s mm ve çekirdeğin içinde: demet tıkacının dibi ile kanat ayağı arası (54 demetin hepsi, NX ölçümü)"
                 % tr(af["gap_tuft_flap_min"], 2),
    "⟦NREGEN⟧": str(len(reg)),
    "⟦REGEN⟧": "%d / %d hatasız; her seferinde çekirdek, kanat ve kıl hacimleri nominale döndü (bağıl 10⁻⁶ içinde)" % (sum(1 for r in reg if r["ok"]), len(reg)),
    "⟦STEP⟧": "%d katı, Examine Geometry bulgusu %d; en büyük bağıl hacim farkı %.1e (çekirdek %.1e, kanatlar %.1e, kıllar %.0e)"
              % (st["solids"], st["examine_findings"], st["max_rel"], st["max_rel_by_kind"]["core"], st["max_rel_by_kind"]["flaps"], st["max_rel_by_kind"]["tufts"]),
    "⟦ASFOUND⟧": "%d üst düzey feature (%d satır), bastırılmış %d, hatalı %d; %d katı: CORE %d (%s mm³), SILICONE_FLAP %d (%s), BRISTLE_TUFT %d (%s); "
                 "%d eskiz, tam kısıtlı olmayan %d; %d adlandırılmış ifade; 3 feature grubu (TUFT_A/B/C); kanat–çekirdek en küçük boşluk %s mm"
                 % (af["features_top"], af["features_all_rows"], len(af["suppressed"]), len(af["errors"]), af["solids"], bn["CORE"]["n"], tr(bn["CORE"]["volume"], 2),
                    bn["SILICONE_FLAP"]["n"], tr(bn["SILICONE_FLAP"]["volume"], 2), bn["BRISTLE_TUFT"]["n"], tr(bn["BRISTLE_TUFT"]["volume"], 2),
                    af["sketches"], len(af["sketches_not_fully_constrained"]), af["named_expressions"], tr(af["gap_flap_core_min"], 3)),
    "⟦REGENLIST⟧": "`twist_lead` 250 (kanal duvarı ve kanat gövdesi yeni helisin üstünde: 0,002 / 0,003 mm; kanat–çekirdek boşluğu 0,054) · `slot_w` 1,5 · "
                   "`h_total` 160 (kanat üst ucu 158,05 = beklenen) · `flap_t` 1,1 (bir kanatta ΔV 234,66; beklenen 234,54) · `bead_t` 1,8 (ΔV 84,69; beklenen 84,07) · "
                   "`flap_r_a` 18 (uç yüzü yeni dış hattın üstünde) · `n_tuft` 20 (45 katı; 14 delik kapandı) · `tuft_pitch` 5,5 · `tuft_lean` 30 (tıkaç dibi yeni delik dibinde) · "
                   "`d_brush` 40 (kıl hacmi × 1,074; beklenen 1,073) · `d_fil` 0,14 (demet başına filament hacmi 12,696 = beklenen). "
                   "Kanat dış hattının diğer ifadeleri (`flap_step_*`, `flap_taper_len`, `flap_r_b`, `flap_r_end`, `bead_len`, `bead_tip_R`), `n_slot` ve `d_tuft_hole` **denenmedi**",
    "⟦MINUTES⟧": "a–f 4,5 dk; z (regenerasyon + STEP) 18 dk, bilgisayar başka işle yüklüyken 40",
}
for k, v in rep.items():
    if k not in s:
        raise SystemExit("token not in report: " + k)
    s = s.replace(k, v)
left = [t for t in ("⟦", "⟧") if t in s]
if left:
    i = s.index("⟦")
    raise SystemExit("unfilled token near: " + s[i:i + 40])
open(os.path.join(WS, "REPORT2.md"), "w", encoding="utf-8", newline="\n").write(s)
print("report filled:", len(s), "chars")
