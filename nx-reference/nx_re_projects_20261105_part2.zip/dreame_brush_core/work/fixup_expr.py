"""Delivered part: delete the two named expressions of the shoulder chamfer that was undone (bead_step, bead_ramp) -
nothing uses them, and a named expression that drives nothing is a dead dimension.  Geometry is not touched.
usage: run_journal fixup_expr.py -args <part.prt> <out dir>"""
import os, sys, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

SRC, OUT = sys.argv[1], sys.argv[2]
res = {"result": "FAIL", "part": SRC}
try:
    part = nxh.open_part(SRC)
    sol = nxh.solids(part)
    v0 = sum(nxh.volume(part, b) for b in sol)
    res["solids"], res["volume_before"] = len(sol), v0
    res["deleted"], res["kept"] = [], {}
    for name in ("bead_step", "bead_ramp"):
        try:
            ex = part.Expressions.FindObject(name)
        except Exception:                                              # noqa: BLE001
            res["kept"][name] = "not in the part"
            continue
        try:
            users = [f.GetFeatureName() for f in ex.GetUsingFeatures()]
        except Exception as e_:                                        # noqa: BLE001
            users = ["? " + str(e_)[:80]]
        refs = [e2.Name for e2 in part.Expressions if e2.Name != name and name in (e2.RightHandSide or "")]
        if users or refs:
            res["kept"][name] = {"features": users, "expressions": refs}
            continue
        part.Expressions.Delete(ex)
        res["deleted"].append(name)
    nxh.update()
    res["errors"] = {k: str(v)[:200] for k, v in (nxh.feature_errors(part) or {}).items()}
    sol = nxh.solids(part)
    res["solids_after"], res["volume_after"] = len(sol), sum(nxh.volume(part, b) for b in sol)
    res["named_after"] = len(nxh.user_expressions(part))
    if res["errors"] or res["solids_after"] != res["solids"] or abs(res["volume_after"] - v0) > 1e-6 * v0:
        raise RuntimeError("part changed: not saved")
    nxh.save(part)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "fixup_expr.json"), res)
