﻿import sys, importlib, importlib.util
print(sys.version)
for m in ['numpy','scipy','trimesh','matplotlib','sklearn','open3d','pyvista','vtk','rtree','shapely','OCP','build123d','PIL','networkx','pymeshlab','fast_simplification','embreex']:
    if importlib.util.find_spec(m):
        try:
            print(' ', m, getattr(importlib.import_module(m),'__version__','?'))
        except Exception as e:
            print(' ', m, 'IMPORT FAIL', e)
