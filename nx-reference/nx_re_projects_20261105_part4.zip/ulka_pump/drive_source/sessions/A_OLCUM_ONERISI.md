# A_OLCUM_ONERISI - taramanın göremediği, hesap için kritik değerler (en çok 6 kalem)

Tarih: 2026-10-17 (değerler Rev H'ye göre; Usta yay tellerini ölçtü - CR-D-01; CR-E-01 ile #4 ve #5 öncelikli). Yazar: ULKA-A. Orkestratör Usta'ya tek seferde götürür; A Usta'ya doğrudan sormaz.
Beklerken her kalem türetildi ve `ULKA_INTERFACES.md` / kontrol parçasında "türetildi" diye işaretli. Usta ölçerse
yalnız `ctrl_params.json` değişir (yeni revizyon), modeller yeniden kurulur.

**Öncelik (E'nin teori modeline göre, CR-E-01): 4 ve 5 en etkili** - türetilmiş VL02 ve oda dibiyle emme valfi çalışmıyor
(0 bar debisi 405 cm³/dk, E5 650). Sonra 1, 2, 3, 6.

| # | Ne | Nasıl (öneri) | Şimdiki değer (türetildi / tarama) | Neden kritik |
|---|---|---|---|---|
| 1 | DR01 piston dış çapı d_p | mikrometre, pistonun ortasından 2 açıda | 4,97 (tarama 4,964-4,978; 5,00 olabilir) | Debi ve basınç kuvveti d_p²'ye bağlı (%1,4) |
| 2 | HS01 tüpünün iç derinliği: soket ağzından tüp iç dibine (DR03'ün oturduğu yüz) | derinlik kumpası / çubuk + cetvel, soket ağzından | 57,3 (flanş üstünden 52,0; Rev H) | Armatürün dinlenme konumu, manyetik strok (7,63), hava aralığı |
| 3 | DR02 ve DR03 yay sabitleri (ya da belli bir boya sıkıştırma kuvveti) | mutfak terazisi üstünde yayı cetvelle 5 mm sıkıştırıp ağırlığı okumak | 1,17 / 2,82 N/mm (Rev H: Usta'nın tel ölçüsü 1,0 / 1,3 + taramadan sarım çapı ve sayısı, ±%15) | Strok, kapalı uç basıncı (15,7 bar hesap / 15 bar datasheet). Tarama teli 1,2 / 1,4 görüyor: k ölçümü bu çelişkiyi de çözer |
| 4 | HS02 iç profili: basınç odası çapı ve dibinin derinliği (VL02 omzu), çıkış oturma ağzı Ø | pim mastarı / matkap ucu sapıyla iki uçtan derinlik | oda Ø6,0, oda dibi HS02 flanş yüzünden 24,0, oturma Ø4,0 (D, CR-D-02) | Emme valfi ön yükü (CR-E-01), ölü hacim, çıkış valfi açılma alanı; G1/8 diş boyu (türetmede 4,8, datasheet min 7) |
| 5 | VL02 ve VL04 küçük yaylar: serbest boy, tel Ø, sarım sayısı | cetvel + kumpas (ya da büyüteçli fotoğraf, yanında cetvel) | VL02 15,0 / tel 0,5; VL04 6,8 / tel 0,45 | Emme ve basma valfi açılma basınçları. E: tel 0,5 ile emme valfi ~4,2 bar'da açılır (çalışmaz); E5'e uyan tel ~0,35 |
| 6 | EM01 bobin DC direnci (ve mümkünse diyot yönü) | multimetre, iki fast-on arası (ters yönde de) | yok | E'nin manyetik kuvvet / akım modeli; BOM Doğrulanacak #10 |

Önemsiz ama yazılı: FS01 vida boyu (M4x8 türetildi; M4x10 ise EM01 makara alnında 1,2 mm boşluk aranır) - ölçüm
istenmiyor, montaj kontrolünde not edilir.
