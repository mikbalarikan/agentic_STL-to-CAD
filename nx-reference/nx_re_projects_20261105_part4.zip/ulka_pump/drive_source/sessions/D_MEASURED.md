# ULKA-D Hidrolik - Aşama 1 ölçüm (2026-10-16)

Yazar: ULKA-D. Ölçü kaynağı yalnız taramalar (+ fotoğraf F01-F21, C'nin `EP5-HS01_aligned` / `EP5-DR01_aligned`
taramasından okunan komşu değerleri, yalnız bağlam için). Bütün değerler mm. "ölçüldü" = taramadan fit;
"türetildi" = taramada görünmüyor, kaynağı yazılı. Rev A çıkana kadar hiçbiri dondurulmuş değildir.

Araçlar ve ham çıktılar: `C:\NX_MCP_WORKSPACE\ulka\parts\D_an\` (`split.py`, `al_hs02b.py`, `al_hs03.py`,
`fin_hs02.py`, `fin_hs03*.py`, `m_rings*.py`, `m_vl03.py`, `m_vl05.py`; `HS02_meas.json`, `HS03_meas.json`,
`fig\`). Hizalı / ayrılmış kopyalar `C:\NX_MCP_WORKSPACE\ulka\scan\EP5-<kod>_aligned.stl`, dönüşümler
`scan\D_scan_index.json`, `parts\D_an\HS02_T.json`, `HS03_T.json` (ham STL -> parça çerçevesi, 4x4).

## 0. Birleşik taramaların ayrılması

İki birleşik tarama ve VL05 taraması parçaların bir altlık plakası üstünde **tek yüzden** taranmış hali. Altlık
düzlemi RANSAC + en küçük kareler ile uyduruldu (rms 0,039 / 0,048 / 0,026), düzlemin 0,25 mm üstü tutuldu,
bağlı bileşenlere ayrıldı, kümeler fotoğrafla eşleştirildi. Sonuç: parçaların altlığa değen alt yüzü ve alttaki
0,25 mm yoktur; elastomerlerde yalnız üst yarı vardır.

| Ham tarama | Bileşen (konum, plaka çerçevesi) | Eşleşme | Gerekçe |
|---|---|---|---|
| HS05+VL02+VL03+VL04 | pul Ø15,7 x 2,4, ortası delik | **HS05** | F14/F15 biçimi, çap HS02 flanşıyla aynı |
| 〃 | dik duran 15 mm yay, üst ucu daralan | **VL02** | F06: konik uçlu küçük yay; tek başına |
| 〃 | Ø5 kubbe baş + boyun, altında yay | **VL03 + VL04** (takılı) | BOM: söküm sırasında birbirine takılı çıktı |
| SL04+VL01+SL01-03 | Ø8,6 halka + içinde Ø3,6 küre | **SL04 + VL01** | F07/F08; bilya halkanın iç kenarına yaslanmış |
| 〃 | OD 20,60, kesit ~2,1 | **SL01** | ID daha büyük (16,26) = "büyük"; F02'de SL01 SL02'den ince |
| 〃 | OD 20,70, kesit ~2,7-2,9 | **SL02** | F02'de en kalın kesit SL02 |
| 〃 | OD 15,8, kesit ~1,0 | **SL03** | "ince kesitli" |
| VL05 | Ø8,4 halka + artı göbek, dik duruyor | **VL05** | F18 yıldız/haç |

Not: SL01 / SL02 ayrımı kesit kalınlığına ve fotoğrafa dayanır; BOM metni ikisine de "kalın" diyor. Ölçü
farkı açık (kesit 2,04-2,2 / 2,64-2,9), etiket ters ise yalnız ad değişir.

## 1. HS02 piston silindiri (ölçüldü, iki uçtan; orta iç kısım görünmüyor)

Parça çerçevesi: z = pompa ekseni, **z0 = flanş uç yüzü (giriş / HS05 tarafı), +z çıkışa**. Orijin gövde dış
çapının ekseninde. +x = dış düzlük (flat) yönü. Uç yüzleri ile silindir ekseni arası açı 0,2-0,3°.
Gürültü: silindir fit sd 0,03-0,06; düzlem sd 0,03-0,06.

| Özellik | Değer | Not |
|---|---|---|
| Toplam boy | **41,22** | uç yüzleri arası |
| Flanş Ø / kalınlık | **15,77** (15,81 -> 15,73 çekme açılı) / **2,88** | uçta ~0,3 pah |
| Giriş havşası (SL04 yuvası) Ø / derinlik | **8,63 / 2,15** | taban düzlemi sd 0,05 |
| Piston deliği (girişten görünen) | Ø6,40 (z 2,2) -> Ø5,92 (z 7,2) | 2,7° koniklik; z>7,5 görünmüyor |
| Gövde dış Ø | 13,47 (z 3,6-9,6), **bant Ø13,13 (z 10,8-14,4)**, 13,40 (z 15,6-22), 13,25 (z 22-28), 13,40 -> 13,29 (z 29-37) | bant 0,17 derin, 3,6 boy: kalıp izi mi oturma bandı mı belirsiz |
| Dış düzlük | z **22,18-28,55**, eksene uzaklık ≈ **5,8**, ~60° kiriş | dönme kilidi / yolluk izi? |
| Çıkış ucu dış pahı | Ø13,2 (z 40,0) -> Ø12,6 (z 41,2) | |
| Çıkış havşası (valf odası) Ø / taban | **8,52** / taban z **29,22** (12,0 derin) | ağızda pah: Ø9,8 (z 40,0) -> Ø11,2 (z 41,2) |
| Çıkış tabanındaki delik | Ø ≈ **6,0-6,1** (z 29,2-30 arası görünür) | daha derini görünmüyor |

Türetilen (taramada yok):
- Basınç odası z 2,15 -> ~28: piston deliği Ø6,2 civarı; ucu VL02 yayına omuz verecek kadar daralmalı (aşağıda).
- Çıkış valf yuvası: VL03 başı Ø5,0 kubbe (küre R 2,76); Ø6,0 deliğe düşer, yani delik tabanda **konik / keskin
  kenarlı bir daralmayla** bitmeli. Türetilen oturma kenarı Ø ≈ **4,0** (kubbe R 2,76 ile 1-1,5 mm dalma).
  Hesap için kritik -> A_OLCUM_ONERISI adayı.
- Oda / çıkış arası duvar: z ~28 -> 29,22.

## 2. HS03 çıkış flanşı (ölçüldü, iki yüz iyi)

Parça çerçevesi: **z0 = flanş plakasının alt yüzü (pimli, EM02'ye oturan yüz)**, +z boğaz ucuna; z ekseni 4 düzlem
yüzün normali (silindir fit ekseniyle 0,85° fark vardı, düzlem esas alındı); orijin 5 dairesel özelliğin ortak
merkezi (birbirinden sapma ≤0,2); +x = kulak deliği 1. Gürültü: duvar fit sd 0,04-0,13, düzlem sd 0,06-0,10.

| Özellik | Değer |
|---|---|
| Plaka alt / üst yüz | z **0 / 5,82** (plaka 5,82) |
| Kulak delikleri | Ø **4,57 / 4,50**, merkezler (±18,97; 0,02), **aralık 37,95** |
| Kulak dış yayı | R ≈ 4,75, merkez ±18,45 (delikle eş merkezliye yakın); plaka boyu 46,7 |
| Plaka yanları | göbek Ø24'e teğet düz kenarlar; y=±12'de küçük çentikler (F13) |
| Konum pimleri (4 adet, alt yüzde) | Ø **3,15** (3,13-3,19), merkezler (±13,93; ±5,00), r 14,8 (±19,7°), boy **3,02** (uç z -3,02) |
| Plaka alt cepleri | pimlerle delik arasında 2 cep (her kulakta), derinlik ölçülmedi |
| Göbek dış Ø (alt) | **23,94** (z 5,82-11,1), sonra ~33° konik -> |
| Göbek dış Ø (üst) | **20,45** (z 13,4-19,9) |
| Üst uç yüzü | z **19,90** |
| İç: alt boğaz (plaka tarafı) | Ø **20,93** (21,02 -> 20,79), z 0-8,16 |
| İç: kademe | z **8,16** (aşağı bakan omuz), radyüslü geçiş |
| İç: orta | Ø **16,50** (16,63 -> 16,42), z 8,2-16,1 |
| İç: üst | Ø **14,26**, z 16,2-19,9 |

Taramada G1/8 diş, CH12 altıgen ve iç valf yuvası **yok**: HS03 iki ucu açık, kademeli bir kovandır. Datasheet'teki
"G1/8, CH12, Ø14" bu varyantta HS03 üzerinde değil (makine tarafı rakor olabilir). Valf yuvası HS02'nin çıkış
havşasında (bölüm 1).

## 3. Elastomerler (üst yarı taranmış; kesit = altlıktan tepe yüksekliği, en güvenilir)

| Kod | ID | OD | kesit (yükseklik / genişlik / torus) | Standart eşleme (öneri) |
|---|---|---|---|---|
| SL04 | 4,48-4,63 | 8,59-8,60 | 1,94 / 2,01 / 2,06 | **4,5 x 2,0** metrik (OD 8,5); ISO 3601 4,47x1,78 kesit tutmuyor |
| SL01 | 16,20-16,26 | 20,60-20,67 | 2,04 / 2,16 / 2,24 | **16,5 x 2,0** metrik (en yakın); alternatif 16 x 2 (OD 0,6 eksik kalır) |
| SL02 | 15,32-15,38 | 20,70 | 2,89 / 2,64 / 2,69 | **AS568-115 = ISO 3601-1 15,47 x 2,62** (OD 20,71) - çok iyi tutuyor |
| SL03 | 12,93-13,04 | 15,71-15,85 | 0,91 / 1,34 / 1,39 | **13 x 1,0** (öneri, belirsiz); genişlik tarama bulanıklığı içeriyor |

## 4. Valf elemanları

| Kod | Ölçüldü | Not |
|---|---|---|
| VL01 bilya | küre fit **Ø3,606** (sd 0,031, 923 nokta) | standart öneri **9/64" = 3,572** (fark 0,034 ≈ 1 sd); 3,5 tutmuyor |
| VL02 bilya yayı | serbest boy **≈15,0**; gövde dış Ø ≈ 5,6-5,9 (ortalama sarım Ø ≈ 5,2); bir ucu daralıyor (son 2-3 sarım dış Ø ≈ 4,0-4,4); tel Ø ≈ 0,5 (tarama zayıf); hatve ≈ 1,4; toplam ≈ 10 sarım | tel ve sarım sayısı fotoğraf F06 ile tutarlı, kesin değil |
| VL03 tapa | baş: kubbe küre **R 2,76**, en büyük Ø **5,0** (z 10,5-11), tepe; boyun Ø ≈ 3,3-3,5 (görünen 3 mm); gövde yay içinde görünmüyor | baş siyah elastomer (BOM). Görünen boy (tepe -> boyun ucu) 6,0 |
| VL04 valf yayı | serbest boy **≈6,8** (VL03 başının altına kadar); konik: alt uç dış Ø ≈ 6,2-6,4, üst uç ≈ 4,4; tel Ø ≈ 0,45; ≈ 4-5 sarım, hatve ≈ 1,7 | tarama parçalı |
| VL05 kafes | halka dış Ø ≈ **8,0-8,4** (+ çıkıntılar ~Ø8,6-9,0), kalınlık ≈ **4,3-4,7**, ortada artı biçimli kollar | tarama zayıf; F18 profili ile modellenecek |
| HS05 pul | OD **15,70** (sd 0,085), delik Ø **5,60-5,72**, kalınlık **≈2,35-2,45** (üst yüz hafif çanak) | alt yüz taranmamış; F15'te bir yüzde delik çevresi kademe görünüyor |

## 5. Geometriden çıkan diziliş (öneri; A eksenel yığında karar verir)

Sayısal eşleşmeler:
- **HS05 OD 15,70 = HS02 flanş Ø15,77** -> HS05 HS02 flanşının giriş yüzüne oturur.
- **SL04 OD 8,59 = HS02 giriş havşası Ø8,63**, havşa derinliği 2,15 ≥ SL04 kesiti 2,0 -> SL04 havşada, HS05 ile
  tutulur, piston üzerinde radyal sızdırmaz. Piston Ø **5,08** (C'nin DR01 taraması, okundu) ile radyal yuva
  (8,63-5,08)/2 = 1,78 -> kesit 2,0 için **%11 sıkışma**. HS05 deliği 5,6-5,7 piston çevresinde 0,3 boşluk.
- **VL05 Ø8,0-8,4 (+çıkıntı) ≈ HS02 çıkış havşası Ø8,52** -> kafes çıkış havşasının ağzında (sıkı / tırnaklı).
- VL03 + VL04 çıkış havşasında: kubbe tabana (z 29,22, Ø6 delik ve türetilen Ø4 oturma), VL04 küçük ucu VL03 başının
  arkasında, büyük ucu VL05'e dayanır. Boy kontrolü: VL03 kubbe tepe ~z 28,5-29 -> baş arkası ~z 31,2; VL05 iç
  yüzü 41,2-4,5 ≈ 36,7 -> VL04 montaj boyu ≈ 5,5, serbest 6,8 -> **ön yük ≈ 1,3 mm**. Tutarlı.
  **Sıra (girişten çıkışa): HS02 oda -> VL03 -> VL04 -> VL05 -> HS02 çıkış ağzı.**
- VL01 bilya piston ucunda; VL02 bilya ile oda sonu omzu arasında (serbest 15,0, oda ~z 10-28 -> hafif ön yük).
- HS03 Ø14,26 üst boğazı HS02 gövdesine (Ø13,3-13,4) 0,4-0,5 çap boşlukla geçer; plaka alt yüzü (pimli) EM02'ye
  oturur (pim Ø3,15, 4 adet, aralık 27,86 x 10,0; kulak delikleri aralığı 37,95 -> FS01).
- SL02 (OD 20,70, kesit 2,6-2,9) HS03 alt boğazına Ø20,93 tam oturuyor; ID 15,4 ile Ø16 civarı bir milin
  (C'nin HS01 tüp dışı Ø16,1-16,3 veya HS01 soket ucu Ø16,0) üzerinde: (20,93-16,2)/2 = 2,37 -> **%12 sıkışma**.
  SL01 (kesit 2,04) aynı yerde sıkışmaz (2,37 > 2,04) -> SL01 başka bir Ø21 / Ø16,5 yuvada olmalı (HS01 flanşı
  Ø21,2 ile EM02 / HS03 arası adayı). **SL01 yeri açık.**
- SL03 (ID 13, kesit ~1,0) HS02'nin Ø13,13 bandına (z 10,8-14,4) uyar; karşı yüz C'nin HS01 soket iç Ø ≈ 14,7 ise
  (14,7-13,13)/2 = 0,78 -> %22 sıkışma. **Öneri, doğrulanmadı.**

## 6. Görünmeyen / kritik kalemler (A_OLCUM_ONERISI için aday, öncelik sırasıyla)

1. HS02 iç profili: basınç odası Ø ve boyu, çıkış oturma kenarı Ø (türetilen 4,0) - pim mastarı ile derinlik.
   Oda hacmi ve açılma basıncı hesabının ana girdisi.
2. VL04 ve VL02 serbest boy / tel Ø / sarım (yay sabiti -> açılma basıncı; tarama tel çapını ±0,1 veremiyor).
3. SL01'in montaj yeri (sökümde hangi parçanın üstündeydi).
Bu arada değerler yukarıdaki gibi türetilip "türetildi" işaretlenir.

## 7. Videolar
`ref\video\*.mp4` (12 adet) tarama düzeneği ve uzaktan söküm görüntüsü; valf içi / HS02 içi için kullanılabilir kare
yok (1 kare/6 sn tarandı).

## 8. Düzeltmeler (Aşama 2 sırasında)
- **HS02 çıkış odası**: "Ø8,52" kısmi kapsamalı (150-170°) serbest daire uydurmasıydı, merkez 0,43 kaymış. Gövde dış
  çapının yerel eksenine göre radyal medyan Ø9,15 (z 30,5-39,5) = **G1/8 iç diş** bölüm dairesi (9,147); Usta da içeride
  dişli kısım olduğunu bildirdi. Model diş dibinde (8,52, Rev A) + kozmetik diş (`cr\CR-D-01`, `CR-D-02`).
- HS02 giriş havşası: serbest uydurma 8,59, yerel eksen 8,73; Rev A 8,63 kaldı. HS02 taramasında iç uydurmaların
  merkezi gövdeye göre 0,15-0,25 y'de kaymış (kapsama 160-230°; birleştirme ofseti).
- HS02 düzlükleri: iki düzlük de görülüyor (normaller 9,41° / 188,68°, eksene 5,846 + 5,881 = 11,73); hizalı tarama
  -9,05° döndürüldü (+X düzlük normali).
- HS03 plaka hattı: kulak yayı kulak deliğiyle eş merkezli R 4,25 (ilk yay uydurması 18,45 / 4,75 kenar noktalarıyla
  karışmıştı); düz kenarlar eksenden 12,13, normal açısı 65,45°. Üst cepler (taban z 3,6, kenarda 1,6 et, göbek
  çevresi r 12,2, kulak deliği çevresi R 4,4) ve dar yanlarda küçük pencereler bulundu.
