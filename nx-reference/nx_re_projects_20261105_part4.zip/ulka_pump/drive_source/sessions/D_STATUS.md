# ULKA-D Hidrolik - durum

Son güncelleme: 2026-10-16

## Biten
- Aşama 1 ölçüm: `sessions\D_MEASURED.md` (§8 düzeltmeler). Hizalı / ayrılmış taramalar
  `C:\NX_MCP_WORKSPACE\ulka\scan\EP5-<kod>_aligned.stl`, dizin `scan\D_scan_index.json`.
- CR'ler: `cr\CR-D-01.md` (Usta'nın yay teli ölçüsü, HS02 G1/8 dişli, valf yığını; Rev B'de kabul),
  `cr\CR-D-02.md` (Rev C dinlenme konumuyla HS02 iç yığını; Rev D'de kabul: `hs02_vl05_z` 31,92).
- Aşama 2 modelleme: 12 parçanın hepsi kontrol parçasına (Rev C) bağlı, journal PASS, sketch'ler DOF 0, STEP gidiş-dönüş
  sağlam. Teslim `cad\<ad>.prt/.stp` + `cad\<ad>_REPORT.md`:
  HS02_CYLINDER, HS03_OUTLET-FLANGE, HS05_WASHER, VL01_BALL, VL02_SPRING-BALL, VL03_VALVE-PLUG,
  VL04_SPRING-VALVE, VL05_VALVE-CAGE, SL01_ORING-L, SL02_ORING-M, SL03_ORING-S, SL04_ORING-PISTON.
  Çalışma: `C:\NX_MCP_WORKSPACE\ulka\parts\<kod>\build.py`; ortak `parts\D_common\` (`nxlib\dsmall.py`, `run.ps1`,
  `run_many.ps1`, `dev_d.py`, `report.py`, `notes_write.py`).

## D'nin ön kontrolü (A'nın QA'sı değil; tarama ±0,15 / HS02 ±0,18 içindeki pay)
| Parça | Pay | Not |
|---|---|---|
| HS02 | %94,5 (diş bölgesi dışarıda) | kozmetik G1/8 ve orta iç QA'dan önce listelendi |
| HS03 | %85 (A: %85,8) | **kapı altında**; L pencereler eklendi (A notu); kalan fark gürültü sınırında (silindir artıkları sd 0,07-0,12) |
| HS05 | %93,8 (kendi oturması) | |
| VL01 | %100 | |
| VL03 | %95,6 (kendi oturması) | |
| VL05 | %30 | tarama çok zayıf, **tutmadı** |
| SL01 / SL02 / SL04 | %91 / %87 / %89 | elastomer bandı ±0,10 |
| SL03 | %60 | kesit yuvarlak değil (0,91 x 1,34), **tutmadı** - A'ya seçenek raporda |
| VL02, VL04 | - | tarama parçalı, karşılaştırma yok |

## A_QA sonuçları (2026-10-16)
- PASS: HS02 (K2 %95,4; K1 6/7, çıkış odası kozmetik diş - beklenen), HS05 %93,9, VL01 %100, VL03 %95,6, SL04 %91,4.
- Tutmadı: HS03 K2 %86,1 (K1 9/9; gürültü sınırı notu raporda), SL01 OD +0,18, SL02 K2 %88,4 (K1 PASS), SL03 K2 %61,3,
  VL02 %40, VL04 %37, VL05 %49 (taramalar zayıf; raporlarda yazılı).
- Montaj kuru koşusu: beklenmeyen girişim yok.

## Sıradaki
- `cr\CR-D-03.md` Rev F'de kabul; kartuş zinciri -0,079 kaydı. HS02, HS05, SL01-SL04, VL05 Rev F ile yeniden kuruldu (PASS),
  teslim edildi; ön kontrol SL01 %97,7, SL03 %84,8.
- A_QA Rev F: HS02 %95,4, HS05 %93,8, SL01 %97,5, SL04 %91,3 PASS; SL03 K1 PASS (ID -0,015, OD -0,011) ama K2 %85,4
  tutmadı (halka taramada yassı); SL02 K2 %88,4 tutmadı (K1 PASS).
- **Montaj PASS (A, Rev H)**: valf grubu yerinde (VL02 9,33, VL04 3,90 sıkışmış), yalnız O-ring sıkışmaları ve VL03 oturma
  teması, strok boyunca çarpışma yok (`cadssembly\`). Rev G/H yalnız B'yi etkiledi; D teslimleri günceldir. **D'nin işi tamam.**
- A'nın son montaj koşusu (B ve C bekleniyor). D tarafında açık iş yok.

## Açık soru / engel
- G1/8 diş boyu: Rev C kinematiğiyle 4,8 (datasheet "min 7" tutmuyor) - CR-D-02.
- HS02 iç yığını tamamen türetildi (Usta ölçemiyor); `z_dr01` değişirse oda dibi yeniden hesaplanır.
