# ULKA-B Stator - durum

Son güncelleme: 2026-10-16 (B BİTTİ: A montaj PASS (Rev H), girişim yok; HS04, EM03 QA PASS; EM01 / EM02 K1 PASS, K2 %89,4 / %89,9 tutmadı - raporda ölçüsüyle; bekleyen iş yok)

## Biten
- Aşama 1 ölçüm -> `sessions\B_MEASURED.md`; hizalı taramalar `C:\NX_MCP_WORKSPACE\ulka\scan\EP5-EM0x/HS04_aligned.stl`.
- Rev A'ya bağlı modelleme (journal'lar `C:\NX_MCP_WORKSPACE\ulka\parts\<kod>\build.py`, hepsi PASS, sketch'ler
  DOF 0, STEP geri okuma eşleşiyor). Teslim `cad\`:

| Parça | Journal | Kendi K2 (rijit oturtma sonrası, T 0,15) | Not |
|---|---|---|---|
| EP5-HS04_SPACER-RING | PASS 14/14 | %91,1 tuttu | **A_QA PASS** (K2 %95,1; K1 OD +0,003, ID -0,045, üst -0,004); pah yönü bilinmiyor (+Z) |
| EP5-EM03_FLUX-SLEEVE | PASS 19/19 | burç 1 %95,1, burç 2 %95,2 tuttu | **A_QA PASS** (burç 2 K2 %94,4; burç 1 taranmamış uç dışarıda %93,7) |
| EP5-EM01_COIL | PASS 32/32 (Rev H: z_em01_term -3,30, terminal kenarı R1) | %82,7 **tutmadı** | A_QA Rev E: K1 4/4 PASS (boy 43,52 doğrulandı), K2 %89,4 tutmadı |
| EP5-EM02_FRAME (sac metal) | PASS 30/30 (Rev G: em02_ri_out 1,9) | %89,6 **tutmadı** | A_QA Rev G: K1 10/10 PASS, K2 %89,9 tutmadı (çıkış duvarı çöküntüsü) |

- CR'ler: `cr\CR-B-01.md` (em01_len 43,52) **kabul edildi, Rev E**, `cr\CR-B-02.md` (EM02 dört bükümde
  tek iç R 1,9). A'ya haber verildi.

## Sıradaki
- A'nın QA sonuçları (`sessions\A_QA.md`) ve CR kararları. Rev B gelirse:
  `powershell -File C:\NX_MCP_WORKSPACE\ulka\parts\_B_common\rebuild_all.ps1` (journal + kendi sapma + rapor, ~2 dk).
- A isterse EM01 kalıp ayrıntısı (Klixon yuvası duvar eğimleri, bıçak kökleri, flanş kenarları) artırılabilir.

## Açık soru
- EM01 ve EM02'de K2 tutmadı; A kabul bandını değiştirmez (kural). Ek ayrıntı mı, "tutmadı" kaydıyla kabul mü:
  A / orkestratör karar verir.

## Engel
- Yok.

## Araçlar
`C:\NX_MCP_WORKSPACE\ulka\parts\_B_common\`: `rb.py`, `bm.py` (tarama), `m_*.py` (ölçüm), `s2_aligned.py`,
`nxlib\rj.py` (kontrol parçası bağlantılı journal bağlamı; sac metal şablonu için `template=`), `run.ps1`
(NX kilidi + RAM kuralı), `dev.py` (sapma), `report.py` (rapor + teslim), `rebuild_all.ps1`.
