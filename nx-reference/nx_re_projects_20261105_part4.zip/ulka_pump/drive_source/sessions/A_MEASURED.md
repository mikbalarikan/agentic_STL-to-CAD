# ULKA-A Master - Aşama 1: eksenel yığın, eksen takımı, tarama gürültüsü

Tarih: 2026-10-16. Yazar: ULKA-A. Kaynak: 13 tarama (A'nın kendi kaba hizalaması), datasheet `E_high_pressure.pdf`,
etiketli fotoğraflar F01-F21, söküm videoları (`ref\video\`, kareler `ref\video\sheets\`, `fr\`), ve B/C/D'nin
`*_MEASURED.md` değerleri (karşılaştırma için okundu; A'nın kendi sayıları ayrıca yazılı).
Araçlar: `C:\NX_MCP_WORKSPACE\ulka\an\` (`ulkalib.py` = R385 `r385lib.py` uyarlaması, `a01..a12_*.py`); kaba hizalı
taramalar `scan\A_rough\A_<kod>_rough.stl` (z = dönel eksen, z0 = taramanın en alt noktası).

## 1. Eksen takımı (öneri, Rev A'da donduruldu)

- **Z** = EM02'nin iki büyük deliğinin ortak ekseni = kartuş ekseni; **+Z girişten (HS01 nipeli) çıkışa (HS02 ucu)**.
- **Orijin** = EM02 çıkış duvarının **dış yüzü** ile eksenin kesişimi (HS03'ün oturduğu, FS01'lerin sıktığı yüz).
  Gerekçe: montajın tek rijit referans yüzü; B'nin EM02 parça çerçevesiyle aynı (z=0 bu yüz).
- **+Y** = EM02 şerit genişliği yönü (çerçevenin açık yanları), **EM01 fast-on terminallerinin olduğu taraf**.
- **+X = Y × Z** (sağ el): EM02 düz duvarlarının normali; FS01 vidaları X = ±fs_pitch/2, Y = 0'da.

## 2. Eksenel yığın (geometri, datasheet ve videodan)

Kanıt zinciri (her biri ölçülü):
- EM02 iç eksenel açıklık 44,12 + t 3,0 (B). Giriş duvarı deliği Ø16,74 < EM03 OD 21,0 -> alt burç giriş duvarının
  iç yüzüne dayanır. Çıkış duvarı deliği Ø21,24 > burç OD 21,0 ve HS04 OD 20,78 -> burçlar ve halka çıkış duvarı
  deliğinden takılır (videoda da önce bunlar çıkıyor, t ≈ 60-90 s).
- EM03 (18,9) + HS04 (9,1) + EM03 (18,9) = 46,9 ≈ giriş duvarı iç yüzü -> çıkış duvarı dış yüzü 47,12: üst burç
  çıkış deliğinden geçip dış yüzün 0,22 altında biter. **HS04 = iki kutup arasındaki manyetik olmayan ara halka
  (bobin ortası).** EM01 makarası (43,45) çerçevenin içinde, bu üç parçanın dışında.
- HS01 flanşı Ø20,23 < Ø21,24 -> flanş çıkış duvarı deliğine girer, üst burcun üstüne (araya SL01) oturur; flanşın
  üstündeki soket dudağı (Ø15,82) HS03'ün orta deliğine (Ø16,50) girer.
- HS03 pimleri (Ø3,15, 4 adet, (±14,0; ±5,0)) EM02'nin Ø3,72 deliklerine, kulak delikleri (Ø4,55, aralık 37,9)
  EM02'nin Ø3,5 deliklerine (FS01, M4) denk gelir. A'nın HS03 ölçüsü: pim deseni açıları ±19,7° (EM02 ile aynı),
  kulak delikleri r 18,93.
- HS05 (OD 15,70) HS01 soket ağzına (r 7,28-7,97) ve HS02 flanşına (Ø15,77) eş çaplı; HS03 orta deliğinde (16,50).
  SL04 (OD 8,6) HS02'nin giriş havşasına (Ø8,63 x 2,15) oturur, HS05 kapatır; piston HS05 deliğinden (5,65) geçer.
- HS02 tek parça "silindir + çıkış rakoru": CH12 anahtar düzlükleri (iki karşılıklı düzlük, aralık 11,8 - A'nın
  r(θ) haritası: θ ≈ -75° ve +105°'de r = 5,9; arada yuvarlak 6,7-6,8), çıkış havşası Ø8,52 (G1/8 iç diş delik çapı).
  Datasheet'teki Ø13,5 / CH12 / Ø14 / 1/8" Gas min 7 bu parçadır.
- Kapalı zincir: EM03-B üstü -> SL01 -> HS01 flanşı (3,23) -> soket (5,31) -> HS05 (2,4) -> HS02 flanşı (2,88) ->
  SL03 -> HS03 üst kademesi (16,15). Rijit boylar 13,82; boşluk 16,37 -> SL01 + SL03 (2,1 + 0,91) %15 sıkışır.
  SL02 (15,47 x 2,62) HS01 flanşının üstünde, HS03 alt deliğinde (Ø20,93), dudak (15,82) üstünde radyal conta.

Sonuç tablosu (Z, mm; Rev A `ctrl_params.json` değerleriyle aynı):

| Konum | Z | Kaynak |
|---|---|---|
| EM02 çıkış duvarı dış / iç | 0 / -3,00 | B |
| EM02 giriş duvarı iç / dış | -47,12 / -50,12 | B |
| EM03-A | -47,12 .. -28,22 | B boyları, A yığını |
| HS04 | -28,22 .. -19,12 | B, A |
| EM03-B | -19,12 .. -0,22 | B, A |
| EM01 makara (terminal ucu çıkışta) | -3,00 .. -46,45 | B, datasheet yan görünüş (türetildi) |
| SL01 (HS01 flanşı altı) | -0,22 .. 1,56 | **türetildi** (zincir + 15 bar kontrolü, §4) |
| HS01 flanş alt / üst (C z0) | 1,56 / 4,79 | C, A |
| SL02 (flanş üstü, HS03 Ø20,93) | 4,79 .. 7,41 | D, A (türetildi) |
| HS01 soket ağzı | 10,10 | C |
| HS01 tüp iç dibi (DR03 dayanma) | -50,51 | **türetildi** (flanş üstünden 55,3) |
| HS01 nipel ucu | -67,90 | C (toplam boy 78,0) |
| HS05 | 10,10 .. 12,50 | D |
| HS02 flanş yüzü (D z0) / ucu | 12,50 / 53,72 | D |
| SL03 (HS02 flanşı üstü) | 15,38 .. 16,15 | D, A (türetildi) |
| HS03 alt yüz / üst uç | 0 / 19,90 | D, A |
| DR01 ön alın (dinlenme, akım yok) | -3,70 | C boyları + yay dengesi (türetildi) |
| DR01 arka alın / piston ucu | -23,74 / 21,63 | 〃 |

Datasheet kontrolü: toplam boy 121,62 (datasheet 122); nipel ucu çerçeve altından 17,8 (datasheet 18); HS02 ucu
çerçeve üstünden 53,7 (datasheet 55). Datasheet'in 55 + 50 + 18 = 123'ü aile çizimi; 122 toplamı tutuyor.

## 3. BOM "Doğrulanacaklar" - geometriyle kapananlar

| # | Konu | Sonuç |
|---|---|---|
| 1 | Montajlı fotoğraf / tarama yok | Açık kalır; yığın parçalardan ve datasheet'ten kuruldu (§2), toplam boy datasheet'le 0,4 içinde. |
| 2 | SL01-03 yerleri | SL02: HS01 flanşı üstü, HS03 Ø20,93 deliği, HS01 dudağında radyal conta (çap eşleşmesi). SL03: HS02 flanşı üstü, HS03 üst kademesine yüz contası. SL01: HS01 flanşı altı, EM03-B üstü (türetildi; zincirin ve 15 bar kontrolünün tek tutarlı yeri). SL01/SL02 etiketleri D'nin kesit ölçüsüne göre (SL01 kesit 2,1, SL02 2,62). |
| 3 | DR02/DR03 tarafı | C kapattı: DR03 (uzun) armatür arkasında (iç Ø9,78 yalnız arka pilota Ø9,5 oturur), DR02 önde; video da doğruluyor. A kabul etti. |
| 4 | HS04 / HS05 görevi | HS04: bobin ortasında iki akı burcu arasındaki manyetik olmayan ara halka (hava aralığı yeri). HS05: SL04'ü HS02 havşasında tutan pul + DR02'nin ön dayanağı; HS01 soket ağzı ile HS02 flanşı arasında. |
| 5 | VL05 / VL03-VL04 sırası | D: HS02 çıkış havşasında oda -> VL03 -> VL04 -> VL05 (kafes havşa ağzında). A kabul etti. |
| 6 | G1/8 / CH12 nerede | HS02 üzerinde: CH12 iki düzlük (11,8), çıkış havşası Ø8,52 = G1/8 iç diş delik çapı (diş taramada görünmez, kozmetik). Ayrı rakor yok. HS03 yalnız flanş. |
| 7 | FS01 HS03'ü EM02'ye bağlar mı; diş | Evet: HS03 kulak delikleri Ø4,55 @ 37,9 = EM02 Ø3,5 delikleri @ 37,8. Fotoğraf F09: silindir (pan) başlı yıldız, ince adımlı makine vidası, ~13 diş görünür -> M4. Boy: M4x10 ucu çerçeve içine 1,2 girip EM01 makara alnına değerdi -> **M4x8 (ISO 7045)** türetildi. |
| 8 | 55+50+18 = 123 / 122 | Yığından toplam 121,6; 122 tutuyor. Bölünüm bu varyantta 53,7 + 50,1 + 17,8. |
| 9 | F01'deki kırmızı döküntü | Geometriyle kapanmaz; taramalarda karşılığı yok. Parça listesinde yok sayıldı. |
| 10 | EM01 Klixon / diyot / direnç | Geometriyle kapanmaz; E için ölçüm önerisine (direnç) yazıldı. |

## 4. Mekanizma kontrolü (E için başlangıç, türetildi)

- Armatür dinlenmede üst burcun içinde (16,7 mm bindirme), alt burcun 4,48 üstünde: manyetik çekim armatürü
  **girişe doğru** çeker (DR03'ü sıkıştırır, piston geri çekilir = emme); basmayı iki yay yapar.
- Yay dengesi (C'nin k değerleri 2,9 / 4,4 N/mm): toplam ön sıkışma 8,52; DR03 26,78, DR02 13,80 montaj boyu.
- Tam manyetik strokta (4,48) yay kuvveti 32,7 N -> piston alanı (d_p 4,97) ile **16,9 bar** (datasheet: Q = 0 @
  15 bar). Bu, HS01 iç dibi ve SL01 yeri türetmelerini destekliyor; SL01 flanş üstünde olsaydı 10 bar çıkardı.
- Debi: Vs = 19,4 mm² x 4,48 = 87 mm³/darbe; datasheet 0 bar'da 217 mm³/darbe (2,5 kat). 7-8 bar'da 100-110 mm³
  (1,2 kat). Fark E'nin konusu (akışkan ataleti / rezonans); A yalnız not eder.
- Yukarı sert dayanma: yaka ön yüzü -> HS05 5,81; DR02 blok boyuna (6,5) 7,3'te gelir. Aşağıda sert dayanma yok
  (DR03 blok boyu 16 mm sonra).

## 5. Tarama gürültüsü (A'nın kendi uydurmaları; koni uydurma, eksen serbest)

| Parça / yüzey | sd | sd_robust | |res|95 | Ø (A) |
|---|---|---|---|---|
| HS01 tüp dışı | 0,041 | 0,037 | 0,079 | 16,069 |
| HS02 gövde dışı (z 6-20) | 0,073 | 0,051 | 0,154 | 13,369 |
| HS02 uç dışı (z 30-39) | 0,036 | 0,022 | 0,061 | 13,614 |
| HS03 boyun dışı | 0,050 | 0,058 | 0,091 | 23,908 |
| HS03 orta delik | 0,049 | 0,048 | 0,091 | 16,525 |
| HS03 alt yüz (düzlem) | 0,062 | 0,068 | 0,117 | - |
| DR01 armatür dışı | 0,022 | 0,011 | 0,033 | 14,340 |
| DR01 piston dışı | 0,028 | 0,014 | 0,053 | 4,964 |
| EM03 dışı / içi | 0,034 / 0,050 | 0,026 / 0,017 | 0,068 / 0,096 | 20,998 / 16,708 |
| HS04 dışı / içi | 0,039 / 0,037 | 0,024 / 0,028 | 0,072 / 0,062 | 20,455 / 17,034 |
| EM01 makara dışı | 0,018 | 0,017 | 0,035 | 47,17 |
| Tarayıcı masası düzlemleri | 0,013-0,044 | | | (DR02 0,037, DR03 0,044, HS04 0,036, HS05 0,034, SL04 0,035, VL05 0,013) |

B/C/D'nin raporladığı rms'ler aynı aralıkta (0,01-0,08; tek yüzlü / kısmi yüzeylerde 0,1-0,15).
Farklar: HS04 OD A 20,455 / B 20,78 (tek yüzden kısmi yay; B'nin ortak merkezli uydurması esas), EM02 sac kalınlığı
A'nın tek-yüz okuması yanlıştı (1,45); B'nin iki yüzlü 3,00'ı esas.

## 6. A'nın bu aşamadaki hataları (düzeltildi)
- EM02 t'yi tek yüzden 1,45 okudum (B: 3,00, iki yüz). İç açıklığı 47,1 sandım; doğrusu 44,12, 47,12 iç-dış.
- HS02'yi önce HS01 tüpünün içine yerleştirdim; yay boyları sığmadığı için reddedildi, HS02 HS01'in üstünde.
