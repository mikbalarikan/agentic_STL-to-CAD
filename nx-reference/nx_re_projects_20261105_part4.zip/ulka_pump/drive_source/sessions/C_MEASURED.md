# ULKA-C Tahrik - Aşama 1 ölçümleri (HS01, DR01, DR02, DR03)

Tarih: 2026-10-16. Yazar: ULKA-C. Kaynak: bu klasördeki ham STL'ler (salt okunur). Çalışma kopyaları:
`C:\NX_MCP_WORKSPACE\ulka\scan\EP5-<kod>_clean.stl` (tarayıcı çerçevesi, masa ve küçük kabuklar atıldı) ve
`EP5-<kod>_aligned.stl` (parça çerçevesi). Ham -> parça dönüşümü: `parts\<kod>\qa\align.json` (`T_raw_to_part`).
Araçlar: `C:\NX_MCP_WORKSPACE\ulka\parts\C_common\` (R385 `B_common`'dan kopyalanıp uyarlandı: `rb.py`, `s1_census.py`,
`align_ax.py`, `prof.py`, `spring1-3.py`). Şekiller: `parts\<kod>\fig\` (`prof_*.png` r-z profilleri, `collar_z.png`,
`wire_sections.png`, `helix_u_z.png`).

Ölçü dili: Ø = çap, z = parça ekseni boyunca mm. "ölçüldü" = taramadan uydurma; "türetildi" = taramada yok, kaynağıyla.
Gürültü: uydurmanın rms'i (yüzey normaline göre değil, yarıçap artığı). Tasarım niyetine yuvarlama önerileri
**öneri**dir; kabul bandını ve yuvarlamayı A Rev A'da verir.

## Parça çerçeveleri (A'nın montaj çerçevesine eşlemesi için)
Hepsinde +Z = pompa +Z yönü (girişten çıkışa) olacak şekilde seçildi; X ekseni keyfi (açısal anahtar yok, aşağıya bak).

| Parça | Z ekseni | z = 0 | +Z ucu |
|---|---|---|---|
| HS01 | tüp dış silindiri (Ø16,09) ekseni, rms 0,036 | flanşın soket tarafındaki düz yüzü (çıkışa bakan yüz) | soket ağzı (HS02 tarafı); nipel -Z'de |
| DR01 | armatür dış silindiri (Ø14,34) ekseni, rms 0,010 | armatürün ön (piston tarafı) alın yüzü = DR02 oturma yüzü | piston ucu |
| DR02, DR03 | sarım ekseni (silindir uydurma) | yayın bir uç düzlemi | diğer uç (yay simetrik, yön önemsiz) |

## EP5-HS01 giriş gövdesi + armatür tüpü (rijit plastik, beyaz/bej)
Tek parça: hortum nipeli - boyun - ince cidarlı armatür tüpü - flanş - soket ağzı. Tarama dik duruşta, nipel ucu
masada; masa düzlemi silindi. Tüp içi yalnız soket ağzından ~10 mm içeri görülüyor.

| Özellik | Değer | Durum / not |
|---|---|---|
| Tüp dış Ø (bobin deliğine giren) | **16,093** (z -49..-5), rms 0,039, koniklik 0,08° | ölçüldü, 360° kapsama. **B-C sınırı** |
| Tüp iç Ø = soket deliği | **14,92** (z +5,0 .. -5,2 görülen), rms 0,045-0,057 | ölçüldü (yalnız ağızdan ~10 mm). Tüp boyunca aynı kabul edildi -> **türetildi** |
| Tüp cidarı | (16,093 - 14,92)/2 = 0,59 | türetildi |
| Soket dudağı dış Ø | 15,82 (z 0,5..5,0), rms 0,065, ~1,7° koniklik | ölçüldü |
| Soket dudağı cidarı | ~0,45 | türetildi |
| Soket ağzı alın yüzü | z = **+5,31** (r 7,28..7,97) | ölçüldü |
| Flanş dış Ø | **20,23**, rms 0,045 | ölçüldü |
| Flanş üst yüzü (z=0) | düzlemsellik rms 0,036, eksene dikliği 0,27° | ölçüldü |
| Flanş alt yüzü | z ≈ -3,23 (alt köşede ~0,5 pah/radyus) | zayıf tarama (alt yüz görülmedi), ±0,2 |
| Tüp sonu -> boyun geçişi | Ø16,09 -> Ø12,9, z -54,0 .. -56,8 (konik/radyus) | ölçüldü, ±0,2 |
| Boyun Ø | **12,92** (z -56,7 .. -59,5), rms 0,053 | ölçüldü, 260° |
| Boyun alt yüzü | z ≈ -60,8 .. -61,3 | ölçüldü, ±0,3 |
| z -61,3 .. -63,3 | taranmamış (gölge); nipel kökü | türetilecek |
| Nipel tırnak tepe Ø | **6,9** (iki tırnak, tepeler z -65,8 ve -68,8) | ölçüldü, 200-230° kapsama, rms 0,15. Datasheet Ø7,2 ile 0,3 fark |
| Nipel tırnak dip Ø | 6,15 (z -64,8 ve -67,8) | ölçüldü |
| Nipel uç Ø / uç z | Ø5,3 / z ≈ **-72,7** (masaya değiyordu) | ölçüldü, ±0,2 |
| Toplam boy | 5,31 - (-72,7) = **78,0** | ölçüldü, ±0,2 |
| Nipel iç delik Ø | taranmadı | türetilecek (öneri Ø3,5-4; fotoğraf) |
| Tüp iç dibi (DR03'ün dayandığı yüz) z | taranmadı | **türetilecek**: dış geçiş z -54..-56,8; dip cidarı ~1,5 kabul -> iç dip ≈ z -53 (A'nın eksenel yığınıyla kesinleşir) |
| Açısal özellik (kanal, kaburga, anahtar) | yok | ölçüldü: profil 360° dönel |

Arayüzler: tüp dış Ø16,09 / EM01 bobin deliği ve EM03 akı burçları (B). Tüp iç Ø14,92 / armatür Ø14,34
(radyal boşluk 0,29). Soket deliği Ø14,92 / HS02 dış Ø (D) -> HS01-HS02 birleşimi: HS02 bu sokete girer
(bindirme boyu D'nin HS02 ölçüsü ve A'nın yığınıyla). Flanş üst yüzü (z=0) eksenel dayanma yüzü adayı.

## EP5-DR01 armatür + içi boş piston (çelik, yekpare görünen tarama)
Tarama ~265° kapsıyor (θ ≈ +40..+140 arası tüm boyda boş: tarayıcı gölgesi). Parça dönel; tek açısal özellik
yaka penceresi.

| Özellik | Değer | Durum / not |
|---|---|---|
| Armatür dış Ø | **14,341**, rms 0,012, koniklik 0,015° | ölçüldü. **C-B hava aralığı tarafı** |
| Armatür ön alın yüzü (z=0) | r 5,23..6,59 düz, rms 0,021, diklik 0,03° | ölçüldü. DR02 oturma yüzü |
| Armatür arka alın yüzü | z = **-20,036**, rms 0,010 | ölçüldü. DR03 oturma yüzü. Armatür boyu **20,04** |
| Dış köşe radyusu (ön ve arka) | ~R0,5-0,6 | ölçüldü (profilden), ±0,1 |
| Arka pilot (DR03 merkezleme) | Ø ≈ 9,5 (köşeleri ~R0,4 yuvarlak), z -20,04 .. -21,02 | ölçüldü, ±0,15 (kısa yüzey) |
| Arka uç yüzü | z = **-21,022**, r 3,24..4,36, rms 0,018 | ölçüldü |
| Arka eksenel delik Ø | **6,09**, rms 0,008 (z -20,5 .. -16,2 görülen) | ölçüldü; armatür boyunca pencereye kadar -> türetildi |
| Ön pilot / kademe (DR02 merkezleme) | Ø **10,02** (z 0 .. 1,24), rms 0,025 | ölçüldü |
| Kademe omzu | z = 1,24 | ölçüldü |
| Yaka Ø | **8,50** (z 6,5..7,8), alt kısım 8,59 (z 1,5..1,9) | ölçüldü, rms 0,015-0,023 |
| Yaka ön (piston tarafı) yüzü | z = **7,99** | ölçüldü |
| Yan pencere | yakayı enine delen **çapraz delik Ø5,15** (silindir uydurma rms 0,030, 3877 nokta), ekseni z = **3,91**'de, armatür eksenini kesiyor (0,04 kaçık); iki ağız ±X. Parça +X ekseni bu delik eksenine döndürüldü (`align.json`) | ölçüldü (ilk okumadaki 'yarık' yorumu düzeltildi). Akış: armatür deliği Ø6,09 -> çapraz delik -> tüp içi / piston deliği |
| **Piston dış Ø d_p** | **4,966** (eksen uzaklığı medyanı, z 9..24,6, 6 dilimde 4,959..4,971); çember uydurma 4,978, rms 0,016 | ölçüldü, 265°. **Tasarım niyeti adayı Ø5,00** (fark 0,03-0,04; gürültüyle sınırda). Debi için en kritik değer: A karar verir |
| Piston ucu | z = **25,33**, dış köşe ~R0,2 | ölçüldü |
| Piston iç Ø | **2,72** (z 22,6..24,4) | ölçüldü, ~95° kapsama, ±0,05 |
| Bilya oturma ağzı (VL01) | uçta iç havşa: Ø2,72 (z 24,6) -> Ø~4,0 (z 25,33); yarım açı ~40° (90° havşa + radyus olabilir) | ölçüldü, ±0,1. **C-D sınırı** (VL01 bilya Ø D'den) |
| Piston çıkıntısı (yaka önünden) | 25,33 - 7,99 = **17,34** | ölçüldü |
| Eksenel delik sonu / piston deliği başı | z ≈ 6,36 (delik duvarı pencereden z 5,5'e kadar görülüyor, 6,36'da düz yüz) | **türetildi** |
| Toplam boy | -21,02 .. 25,33 = **46,35** | ölçüldü |

Not: piston + armatür taramada tek kabuk; ayrı parça sınırı görünmüyor. Kodlama belgesindeki "pres geçme" ile
uyumlu olarak NX'te tek parça (iki gövde birleşik değil, tek gövde) modellenecek; istenirse iki gövde.

## EP5-DR02 ön yay (kısa, paslanmaz, parlak) ve EP5-DR03 arka yay (uzun, koyu)
İki yay da masada yan yatarak taranmış; alt yarıları masa düzlemine yakın (masa silindi). Tel kesiti, ekseni
içeren yarım düzlem kesitlerinde (her 15°) ≥180° kapsayan yaylara çember uydurularak ölçüldü.

| Özellik | DR02 ön | DR03 arka | Durum |
|---|---|---|---|
| Tel Ø d | **1,23** (48 kesit, sd 0,12) -> öneri **1,2** | **1,43** (99 kesit, sd 0,06) -> öneri **1,4** | ölçüldü (sprey ile ~+0,03 şişme olası) |
| Ortalama sarım Ø D | 11,42 | 11,20 | ölçüldü |
| Dış Ø | **12,65** | **12,63** | ölçüldü (2R+d) |
| İç Ø | **10,19** | **9,78** | ölçüldü (2R-d) |
| Serbest boy L0 | **18,93** | **30,16** | ölçüldü |
| Aktif adım p | 3,89 | 4,37 | ölçüldü (helis izi) |
| Toplam sarım n_t | ≈ **5,4** | ≈ **7,6** | ölçüldü (uç uçlarının açısı ±30°) |
| Uç kapalı bölge (sarım başına) | alt ~0,55 tur düz (z_merkez ≈0,6) + kısa geçiş; üst ~0,5 tur | alt ~0,5 tur düz (z_merkez ≈0,85) + ~0,25 geçiş; üst ~0,55 tur | ölçüldü (helis izi, `parts\<kod>\qa\helix_u_z.txt`) |
| Aktif sarım n_a | ≈ **4,1** (helis izinden; klasik n_t-2 = 3,4) | ≈ **6,1** (helis izinden; klasik n_t-2 = 5,6) | ölçüldü / türetildi |
| Uç tipi | kapalı + **taşlanmış** (her iki uçta ~270° düz yüzey, 17-23 mm²) | kapalı + taşlanmış (16-24 mm²) | ölçüldü |
| Helis yönü | sağ | sağ | ölçüldü |
| Yay sabiti k = G·d⁴/(8·D³·n_a) | ≈ **2,9 N/mm** (G 69 GPa paslanmaz, d 1,2, n_a 4,1; n_a 3,4 ile 3,5) | ≈ **4,4 N/mm** (G 79 GPa çelik, d 1,4, n_a 6,1; n_a 5,6 ile 4,9) | **türetildi**, ±%20 (d⁴ ve n_a'ya duyarlı) |
| Blok boyu ≈ n_t·d | ≈ 6,5 | ≈ 10,6 | türetildi |

### Hangi yay hangi tarafta (görev: geometriden)
**Sonuç: DR03 (uzun, koyu) armatürün arkasında (HS01 / giriş tarafı), DR02 (kısa, parlak) önünde (piston / HS02 tarafı).**
Kodlama belgesindeki sıra doğrulandı. Kanıtlar:
1. Merkezleme pilotları: DR03 iç Ø9,78 armatürün arka pilotuna (Ø≈9,5) oturuyor (çap boşluğu ~0,3); DR02 iç
   Ø10,19 ön kademeye (Ø10,02) oturuyor (çap boşluğu 0,17). Ters takılırsa DR03 ön kademeye (Ø10,02) girmez
   (iç Ø9,78 < 10,02), DR02 arka pilotta ~0,7 boşlukla boşta kalır. Bu tek başına belirleyici.
2. Söküm videosu (`WhatsApp Video ... 15.25.23.mp4`, t ≈ 126-130 s): HS01 tüpü çekilince içinden koyu uzun yay
   düşüyor; kısa yay armatür-piston ile HS02 tarafında kalıyor ve sonra pistondan çıkarılıyor.
3. İki yayın dış Ø'ı (12,6) tüp iç Ø'ından (14,92) küçük; ikisi de tüp içinde, armatürün iki alnına dayanıyor.

Yayların diğer uçları: DR03 HS01 tüp iç dibine (z türetilecek); DR02 HS05 / HS02 alnına (D).

## Arayüz özeti (A için, `ULKA_INTERFACES.md` adayı)
| Arayüz | C tarafı değeri | Karşı taraf |
|---|---|---|
| Tüp dış Ø / bobin deliği, akı burcu iç Ø | HS01 Ø16,093 | B: EM01, EM03 |
| Tüp iç Ø / armatür (radyal boşluk) | HS01 Ø14,92 (türetildi boyunca) / DR01 Ø14,341 -> boşluk 0,29 | - |
| Armatür - akı burcu hava aralığı | armatür Ø14,341, boy 20,04, alınlar z 0 / -20,04 | B: EM03 konumları (eksenel) |
| DR02 oturma | DR01 ön alın z=0, pilot Ø10,02 | DR02 iç Ø10,19, dış Ø12,65 |
| DR03 oturma | DR01 arka alın z=-20,04, pilot Ø≈9,5 | DR03 iç Ø9,78, dış Ø12,63 |
| Piston / SL04 / HS02 yatağı | d_p = 4,966 (aday 5,00) | D: SL04 iç Ø, HS02 delik Ø |
| Bilya oturma | piston ucu z 25,33, iç Ø2,72, havşa -> Ø~4,0 | D: VL01 Ø |
| HS01-HS02 birleşimi | soket deliği Ø14,92, ağız z +5,31, flanş yüzü z 0 | D: HS02 dış Ø, omuz |
| Giriş | nipel tırnak Ø6,9 (datasheet 7,2), uç z -72,7 | - |

## Açık noktalar / türetilecekler (A'ya)
1. **d_p**: ölçülen 4,966-4,978; Ø5,00 yuvarlaması 0,03 ile kabul bandının sınırında. Debi Q ∝ d_p², 0,03 -> %1,3.
   A_OLCUM_ONERISI adayı (mikrometre). Öneri: A'nın kendi hizalamasıyla bağımsız ölçüsü belirlesin.
2. HS01 tüp iç dibi z'si ve nipel iç deliği taranmadı. Eksenel yığın (DR03 L0 30,16, armatür 46,35, DR02 L0 18,93,
   HS02 konumu) ile türetilecek.
3. Strok: dayanma noktaları armatür arka alnı / ön alnı ile karşı yüzler; taramada montaj yok -> A'nın yığını.
4. Nipel Ø6,9 vs datasheet 7,2: tarama tırnak tepelerini 200-230° görüyor, rms 0,15. Datasheet'e (7,2) yuvarlamak
   gürültü dışı (0,3). Öneri: taramaya sadık 6,9; A karar verir.
5. Yay tel Ø'ları (1,2 / 1,4) ve k değerleri E için türetilmiş; kesinleşmesi gerekirse A_OLCUM_ONERISI adayı.

## Kontrol parçası için önerilen expression adları (A seçer; C journal'ları bunlara `link()` ile bağlanacak)
`hs01_tube_od` 16,09 · `hs01_bore_d` 14,92 · `hs01_flange_z` (montajda flanş yüzü z) · `hs01_socket_z` (ağız z,
flanştan +5,31) · `hs01_inner_bottom_z` (türetilecek) · `dr01_arm_d` 14,34 · `dr01_arm_len` 20,04 ·
`dr01_front_pilot_d` 10,02 · `dr01_rear_pilot_d` 9,5 · `dp` (piston dış Ø) · `dr01_tip_z` (ön alından 25,33) ·
`dr01_seat_d` (havşa ağzı ~4,0) · `dr02_*` / `dr03_*`: `d_wire`, `od`, `l0`, `n_t`, `l_inst` (montaj boyu, A).
Boşluk expression'ı: `c_arm_tube = (hs01_bore_d - dr01_arm_d)/2` = 0,29.

## Çapraz kontrol (B_MEASURED ile, yalnız okuma)
EM03 burç iç Ø16,71, EM02 giriş duvarı deliği Ø16,74, HS04 iç Ø17,1 > HS01 tüp Ø16,09 -> radyal 0,31-0,5 boşluk,
B'nin "kartuş tüpü Ø<=16,6" çıkarımıyla uyumlu. HS01 flanşı Ø20,23 < bobin deliği Ø21,45 (en dar) ve < EM02 çıkış
duvarı deliği Ø21,24.

## Düzeltme 1 (2026-10-16, Rev A'dan sonra) - yay ekseni ve sarım sayısı -> CR-C-01
Yukarıdaki yay tablosunun D / dış Ø / iç Ø / n_t / k satırları **geçersiz**: yay ekseni ~0,29 mm kaçık bulunmuştu
(alt yarı taranmamış). Tel kesiti merkezlerine yeniden uydurulan eksen ve bütün yüzeye oturtulan parçalı adımlı helis
modeliyle güncel değerler: DR02 D 11,75 / d 1,2 / **dış Ø 12,94** / iç Ø 10,55 / L0 18,97 / **n_t 6,06** / k ≈ 2,4;
DR03 D 11,54 / d 1,4 / **dış Ø 12,95** / iç Ø 10,13 / L0 30,14 / **n_t 8,15** / k ≈ 3,8. Ayrıntı `cr\CR-C-01.md`.
"Hangi yay hangi tarafta" bölümündeki 1. kanıt (pilot çapları) bu iç çaplarla belirleyici değil; sonuç videoya
(2. kanıt) dayanıyor ve değişmedi.
