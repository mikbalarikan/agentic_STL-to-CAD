# A_QA - bağımsız parça ölçümleri ve montaj kontrolleri (ULKA-A)

Yöntem (Rev A kapıları, `ULKA_INTERFACES.md` §6): `C:\NX_MCP_WORKSPACE\ulka\an\qa_dev.py <KOD> <stp> <tarama>`.
A'nın kendi hizalaması: tarama temizlenir (masa düzlemi, küçük kabuklar), CAD'e çok başlangıçlı rijit oturtma
(asal eksen başlangıçları x 4 işaret; dönel parçalarda + 12 dönüş), her başlangıçtan nokta-düzlem ICP, en iyi
kırpılmış medyan; çizenin çerçevesi ve sayıları kullanılmaz. K1 özellik listeleri `an\qa\specs\<KOD>.json`
(CAD çerçevesinde bant + yarıçap penceresi; aynı primitif taramaya ve CAD'e uydurulur). Çıktılar
`an\qa\<KOD>_qa.json/.png`.

Not: kapsaması < 180° olan silindirlerde serbest daire merkezi kayar (HS04 OD serbest 20,44); bu özelliklerde çap, bütün yüzeylerle oturtulmuş CAD eksenine göre radyal medyandır (`D_axis`).

Araç denemesi (resmi değil): C'nin Rev A öncesi kuru DR01 modeli ile 9 özelliğin 8'i 0,01 içinde, genel yüzey
%98,9 ±0,15 içinde; arka delik (taramada zayıf, %50 kapsama) -0,061.

## Parça sonuçları

| Parça | K2 (±T içinde, kapı %90) | K1 (işlevsel) | Not |
|---|---|---|---|
| FS01 | - (satın alınan, tarama yok) | - | A modelledi, `cad\EP5-FS01_REPORT.md` |
| HS04 (B) | **%95,1** ±0,15 (PASS); oturtma medyanı 0,034 | OD 20,777 / 20,773 (+0,003, zayıf: 160°, eksen-sabit) PASS; ID 17,058 / 17,103 (-0,045; eksen-sabit 17,127, +0,024) PASS; üst yüz -19,124 / -19,120 PASS; alt yüz masada, ölçülemez | 2026-10-16, `qa\HS04_qa.json`. B'nin kendi K2'si %91,1 |
| EM03 (B), burç 2 | **%94,4** (PASS); medyan 0,026 | OD 20,986 / 20,993 (-0,008) PASS; ID 16,651 / 16,703 (-0,052, zayıf, bant 0,105) PASS; alt -47,127 / -47,120 PASS; üst -28,210 / -28,220 PASS (uç yüzler zayıf) | `qa\EM03_s2_qa.json` |
| EM03 (B), burç 1 | ham %87,8 (tutmadı); raporda QA'dan önce listelenen taranmamış uç (1,1 mm bant) dışarıda: **%93,7** (PASS) | OD 20,998 / 20,993 (+0,005) PASS; ID 16,707 / 16,703 (+0,004) PASS; üst -28,204 / -28,220 PASS; alt uç taranmamış (o uçtaki kırıntılar +0,31 -> ölçülemez sayıldı) | `qa\EM03_s1_qa.json` (ham), `EM03_s1x_qa.json`; geometri B'nin ayırdığı `EP5-EM03_sleeve1/2_aligned.stl`, hizalama A'nın |
| DR01 (C) | **%98,9** (PASS); medyan 0,011 | 9/9 PASS: armatür Ø 14,341/14,335 (+0,006); d_p 4,962/4,967 (-0,004); yaka 8,492/8,495; ön pilot 10,019/10,014; arka delik 6,082/6,086 (zayıf); ön alın, arka alın, yaka ön yüzü, piston ucu 0,007 içinde | `qa\DR01_qa.json`. Not (CR-C-02): tarama ince metalde şişebilir; d_p için A_OLCUM #1 |
| HS01 (C) | **%96,2** (PASS); medyan 0,032 | 7/7 PASS: tüp dışı 16,062/16,083 (-0,021); soket deliği 14,897/14,913; dudak 15,835/15,813 (+0,021); flanş Ø 20,226/20,222 (zayıf); boyun 12,957/12,913 (+0,043); flanş üstü 4,772/4,789; soket ağzı 10,082/10,099 (zayıf) | `qa\HS01_qa.json`. Geometri C'nin temizlediği `EP5-HS01_clean.stl` (masa/kırıntı), hizalama A'nın. A'nın aracı ilk denemede uzun tüpü eksen boyunca 3,5 kaydırmıştı (%88); eksenel arama (`--zsearch`, 144 başlangıç) eklendi |
| HS02 (D) | **%95,4** ±0,18 (PASS); raporda QA'dan önce listelenen çıkış odası iç yüzü (G1/8 diş) dışarıda; medyan 0,037 | flanş Ø +0,012; SL04 havşası +0,020; gövde (boğaz) +0,041; flanş yüzü, havşa tabanı, uç 0,012 içinde: PASS. Çıkış havşası 9,094 / 8,513 (+0,58) **tutmadı** - beklenen: taramadaki G1/8 diş ortalaması (bölüm dairesi 9,147), CAD diş dibinde (kozmetik diş) | `qa\HS02_qa.json`. A'nın aracına açısal arama eklendi (düzlükler küçük alan; ilk çalıştırmada 90° dönük oturmuştu, %83) |
| HS03 (D) | %85,8 ±0,15 - **tutmadı** (medyan 0,061) | 9/9 PASS: delikler 20,930/20,923, 16,490/16,493, 14,300/14,253 (zayıf); göbek 23,938/23,935, 20,426/20,443; alt yüz, kulak üstü, kademe, uç 0,014 içinde | `qa\HS03_qa.json`. Taşan bölgeler plaka dar yanlarında (x≈0, y=±11, z 1-5; -0,4..-0,5): D'nin raporunda "modellenmedi" diye yazılı küçük pencereler ve göbek-plaka dolgusu. D'nin kendi ön kontrolü %84,9 |
| HS05 (D) | **%93,9** (PASS) | OD 15,681/15,693 (zayıf) PASS; delik 5,677/5,645 (zayıf) PASS; alt yüz +0,018 PASS; üst yüz taranmamış | geometri D'nin ayırdığı tarama, hizalama A'nın (bu ve aşağıdaki D parçaları; Rev C teslimleri) |
| SL01 (D) | **%91,4** (PASS) | elastomer bandı ±0,10: ID +0,063 PASS; OD 20,540/20,358 (+0,18) **tutmadı** | CAD 16,2 x 2,1 nötr; tarama dış yayı daha geniş (üst yarı tarama, kesit 2,2 gibi) |
| SL02 (D) | %88,4 - **tutmadı** (kapı %90) | ID -0,029, OD +0,025 (zayıf) PASS | ISO 3601 15,47 x 2,62 |
| SL03 (D) | %61,3 - **tutmadı** | ID 13,178/13,009 (+0,17), OD 15,307/14,799 (+0,51) **tutmadı** | ince halka (kesit ~1) taramanın çözünürlüğünde; tarama kesiti 1,0'dan kalın görüyor (OD 15,3). CAD 13 x 0,91 |
| SL04 (D) | **%91,4** (PASS) | ID +0,20 (zayıf, bant 0,21) PASS; OD 8,531/8,471 (+0,06) PASS (±0,10) | 4,5 x 2,0 |
| VL01 (D) | **%100** (PASS); medyan 0,018 | - (küre; K2 yeterli) | 9/64" 3,572 |
| VL03 (D) | **%95,6** (PASS) | baş Ø 4,992/4,996 PASS | tarama yalnız baş + boyun |
| VL02 (D) | %40,3 - **tutmadı** | - | tarama parçalı/zayıf (tel 0,5); D'nin raporunda ölçü kaynağı fotoğraf + dış çap |
| VL04 (D) | %37,0 - **tutmadı** | - | 〃 (tel 0,45) |
| VL05 (D) | %48,9 - **tutmadı** | - | tarama çok zayıf (D ön kontrolü %30-34); şekil F18'den |
| EM01 (B) | %89,0 - **tutmadı** (kapı %90; far %23: plaka/Klixon kalıp ayrıntıları) | 4/4 PASS: gövde Ø 47,213/47,209; delik 21,576/21,492 (zayıf); terminal ucu -3,008/-3,000; düz uç -46,483/-46,450 (zayıf) | Rev A modeli (43,45); Rev E 43,52 ile yeniden kurulacak. B'nin kendi K2'si %82,7 |
| HS02 (D, Rev D) | %95,4 (PASS) | Rev C ile aynı (çıkış havşası diş farkı +0,58 beklenen) | A'nın aracı ilk Rev D koşusunda parçayı ters oturttu (%75); eksenel arama ±7,5'e genişletildi, aynı sonuç geldi |
| HS03 (D, Rev D) | %86,1 - **tutmadı** (pencereler eklendi; Rev C %85,8) | K1 Rev C'deki gibi 9/9 | D'nin notu: gürültü sınırı; taşan bölgeler alt yüz ve göbek geçişlerinde dağınık |

### Rev F yeniden ölçüm (D'nin kartuş parçaları, 2026-10-16)

| Parça | K2 | K1 | Not |
|---|---|---|---|
| HS02 | **%95,4** ±0,18 (PASS) | 6/7 PASS (çıkış havşası +0,58: kozmetik diş, beklenen) | z_hs02 12,420 |
| HS05 | **%93,8** (PASS) | OD, delik, üst yüz PASS | |
| SL01 | **%97,5** (PASS) | ID +0,066 (zayıf), OD -0,020 PASS | Rev F kesit 2,20 ile OD tuttu |
| SL02 | %88,4 - **tutmadı** | ID -0,010, OD +0,027 PASS | değişmedi (ISO 15,47 x 2,62) |
| SL03 | %85,4 - **tutmadı** (Rev E %61,3) | ID -0,015, OD -0,011 PASS | Rev F 13,15 x 1,10 ile ölçüler tuttu; yüzeyde ince halkanın tarama gürültüsü |
| SL04 | **%91,3** (PASS) | ID +0,18 (zayıf, bant 0,20) PASS; OD +0,055 PASS (elastomer ±0,10) | |
| HS01 (C, Rev F) | **%96,2** (PASS) | 7/7 PASS (boyun +0,043; ilk koşuda pencere Rev B konumunda kaldığı için geçişe taşıp +0,055 vermişti, pencere parça ile -0,08 kaydırıldı) | z_hs01_flange 4,710 |
| EM02 (B, Rev F, iç R 1,1/1,9) | %87,6 - **tutmadı** | 4 ölçülebilir PASS: çıkış deliği 21,230/21,233; giriş deliği 16,740/16,733; çıkış dış yüzü +0,060 (zayıf); giriş iç yüzü +0,002 | sapma bükümlerde ve çıkış duvarı çöküntüsünde (B'nin ölçtüğü 0,2-0,45); Rev G (tek R 1,9) ile yeniden ölçülecek |
| EM01 (B, Rev E) | %89,4 - **tutmadı** (far %23: plaka, Klixon gözleri, bıçaklar) | 4/4 PASS: gövde +0,005; delik +0,084 (zayıf); terminal ucu -0,034; düz uç -46,522/-46,520 | Rev E boyu 43,52 düz uçta doğrulandı |
| EM02 (B, Rev G, tek iç R 1,9) | %89,9 - **tutmadı** (kapının 0,1 altında; Rev F modeli %87,6) | 10/10 PASS: büyük delikler -0,004 / +0,007; çıkış dış yüzü +0,057 (zayıf), giriş iç yüzü -0,002; eksen dışı delikler (`qa_holes.py`): FS01 delikleri +0,006 / +0,011, pim delikleri -0,010..-0,058 (bant 0,08-0,10), merkezler 0,07-0,15 | kalan sapma çıkış duvarı dış yüzünün çöküntüsünde (B: 0,2-0,45, sac metalde modellenmedi) |
| HS03 eksen dışı (D, Rev D) | - | 6/6 PASS: kulak delikleri -0,057 / +0,017 (bant 0,15-0,18), pimler -0,041..+0,006, merkezler 0,04-0,09 | pim deseni EM02 deliklerine oturuyor (iki tarafta aynı (±14,0; ±5,0)) |

## Montaj kontrolleri

### Koşu 2 (Rev G, yaylar DR02/DR03 hariç bütün parçalar; `asm\asm_build.json`)
- Hard (beklenen): DR01/SL04 3,11 mm³ (O-ring pistonda %8,5), HS01/SL01 33,2 (eksenel %22,7 + ID), HS01/SL02 7,6 (dudakta),
  HS02/SL03 3,6 ve HS03/SL03 3,7 (yüz contası), EM02/FS01_P ve _N 5,31 (M4 dişi Ø3,5 delikte), HS02/VL03 0 (oturma çizgi teması).
- Hard (**beklenmeyen**): EM01/EM02 4,34 mm³ - bobin terminal ucu flanş kenarı çıkış duvarı iç büküm radyüsüne giriyor
  (OCP ortak hacim: X ±22,1..23,5, Z -3,0..-3,6). Taramada flanş uç kenarı yuvarlatılmış (uç yüzde r 22,2-22,9, 1 mm
  içeride 23,8); modelde keskin. Çözüm: Rev H (bobin ortalı, `z_em01_term` -3,30) + B'den kenar yuvarlatması.
- Touch: EM02/EM03, EM02/HS03, EM03/HS04, EM03_B/HS04, EM03_B/SL01, FS01/HS03, HS01/HS05, HS02/HS05, HS02/SL04.
- Strok taraması dz -8,13 .. +2,58 (13 adım): DR01 yalnız SL04 ile (sabit 3,11, O-ring); +2,58'de yaka HS05'e dokunuyor
  (yukarı sert dayanma, tasarlanan). VL01 hiçbir sabit parçaya değmiyor.
- STEP `asm\EP5-AS00_ASSY.stp` 555 kB yazıldı.
| DR02 (C, Rev F) | %71,0 - **tutmadı** | OD tepeleri 12,823/12,649 (+0,17, zayıf, bant 0,23) PASS; ID 10,766/10,837 (-0,07) PASS; uç z0 +0,143 **tutmadı**, uç L -0,117 (zayıf) PASS | ortalama +0,078: CAD teli Usta'nın 1,0'ı, tarama teli 1,2 (CR-C-02'de yazılı şişme). Hizalama: eksen normallerden (`--axisfit`; yarı taranmış yayda ağırlık merkezi kayıyordu) |
| DR03 (C, Rev F) | %83,9 - **tutmadı** | OD 12,762/12,714 (+0,048) PASS; ID -0,044 PASS; uçlar +0,191 / -0,089 **tutmadı** (taramada uçlar 0,28 kısa görünüyor; yarı taranmış taşlanmış uç yüzleri) | C'nin kendi tahmini %84,3 |
| EM01 (B, Rev H, flanş kenarı R1) | %89,4 - **tutmadı** | 4/4 PASS: gövde +0,006; delik +0,102 (zayıf); terminal ucu -3,334/-3,300; düz uç -46,823/-46,820 | Rev H konumu taramayla doğrulandı |
| EM02 (B, çentik R 0,8) | %89,8 - **tutmadı** | K1 Rev G ile aynı (10/10) | |

### Koşu 4 - SON (Rev H, 23 bileşen, bütün parçalar; `cad\assembly\asm_build.json`)
- 21 benzersiz parça, 23 adet (EM03 x2, FS01 x2), 23 katı. Yaylar sıkışmış kopyalarla (`*_ASM.prt`): DR03 26,70, DR02 10,57,
  VL02 9,33, VL04 3,90 (hepsi blok boyunun üstünde: DR03 blok 10,6, DR02 6,1, VL02 ~6,25, VL04 ~2,9).
- **Sert girişim: yalnız beklenenler.** O-ringler: DR01/SL04 3,11 mm³, HS01/SL01 33,15, HS01/SL02 7,62, HS02/SL03 3,58,
  HS03/SL03 3,67. Vidalar: EM02/FS01_P ve _N 5,31 (M4 dişi Ø3,5 delikte). Sıfır hacimli temaslar: HS02/VL03 (valf oturması),
  DR01/DR03 (yay ucu armatür alnında).
- EM01/EM02 girişimi (koşu 2'de 4,34 mm³) Rev H + B'nin flanş kenar yuvarlatmasıyla kalktı.
- Touch: DR01/DR02, DR03/HS01, EM02/EM03, EM02/HS03, EM03/HS04, EM03_B/HS04, EM03_B/SL01, FS01/HS03 (x2), HS01/HS05,
  HS02/HS05, HS02/SL04.
- **Strok taraması** dz -8,13 .. +2,58 (dinlenmeden; manyetik strok 7,63 + 0,5 pay; yukarı sert dayanma 2,58), 13 adım:
  DR01 yalnız SL04 ile (sabit 3,11 mm³ O-ring sıkışması, her adımda aynı); +2,58'de yaka HS05'e kenar/yüz teması
  (tasarlanan dayanma). VL01 hiçbir sabit parçaya değmiyor. **Çarpışma yok.**
- STEP `cad\assembly\EP5-AS00_ASSY.stp` (721 kB): OCP ile geri okundu - 23 katı, geçersiz 0, toplam hacim 103 118,0 mm³
  (NX 103 118,2; fark 0,23), en büyük katı farkı 0,46 mm³; sınır kutusu X ±26,98, Y -25,55..31,67, Z -67,98..53,64
  (boy 121,62; datasheet 122).
- **MONTAJ PASS** (K3: sert girişim yok, yalnız beklenen temaslar; strok boyunca çarpışma yok).
