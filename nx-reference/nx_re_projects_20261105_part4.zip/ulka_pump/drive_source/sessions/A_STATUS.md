# A_STATUS - ULKA-A Master

**MONTAJ PASS** (2026-10-16, Rev H): `cad\assembly\` - AS00, AS01, AS02, AS03, 21 parça + 4 sıkışmış yay kopyası, `EP5-AS00_ASSY.stp`, `asm_build.json`. Ayrıntı `sessions\A_QA.md` "Koşu 4".

Güncelleme: 2026-10-16 (Rev H; Aşama 4 bitti - MONTAJ PASS)

## Biten
- Aşama 1: eksenel yığın, eksen takımı, gürültü, Doğrulanacaklar 1-10 -> `sessions\A_MEASURED.md`.
- Ölçüm önerisi (6 kalem) -> `sessions\A_OLCUM_ONERISI.md` (orkestratör Usta'ya götürür; hepsi türetildi).
- **Rev A**: `ULKA_INTERFACES.md` + kontrol parçası `C:\NX_MCP_WORKSPACE\ulka\ctrl\EP5-AS00_CTRL.prt`
  (`ctrl_params.json` <- `mk_params.py`; `ctrl_build.py` -> `ctrl_build.json` PASS, 152 expression, 14 datum düzlemi,
  `PUMP_AXIS`). Kabul kapıları K1-K3 modellemeden önce sabitlendi (INTERFACES §6).
- B/C/D'ye "Rev A yayınlandı" mesajı gönderildi.
- **Rev B** (CR-D-01 + CR-C-01 kabul): Usta'nın yay teli ölçüsü 1,0 / 1,3; yay OD / sarım; k formül; `hs01_inner_bot` 52,0; `z_vl05`. ctrl PASS, 155 expression. Rev A yedekleri `ctrl\*_revA.*`.
- **Rev C** (CR-C-02): `dr02_od` 12,75, `dr03_od` 12,84 (tel merkez çapı + Usta teli). ctrl PASS.
- **Rev D** (CR-D-02): `hs02_vl05_z` 31,92, `z_vl05` buna bağlı. ctrl PASS.
- **Rev E** (CR-B-01): em01_len 43,52. ctrl PASS.
- **Rev F** (CR-D-03): sl01_cs 2,20, sl03 13,15 x 1,10; sl_sq %22,7, kartuş zinciri -0,079. ctrl PASS. C (HS01) ve D yeniden koştu, QA PASS.
- **Rev G** (CR-B-02): em02_ri_out 1,9. ctrl PASS.
- **Rev H** (A montaj bulgusu): z_em01_term -3,30 (bobin ortalı; flanş kenarı EM02 büküm radyüsüne giriyordu). B kenar yuvarlatmasını ekleyip yeniden koşacak.
- QA (A_QA.md): PASS - HS04, EM03, DR01, HS01, HS02, HS05, VL01, VL03, SL04; tutmadı - HS03 K2 %86, EM01 K2 %89 (K1 PASS), SL01 OD, SL02 K2, SL03, VL02/VL04/VL05 (tarama zayıf).
- Montaj betiği `asm\asm_build.py` kuru koşu PASS (eksik: EM01, EM02, DR02, DR03): beklenmeyen girişim yok; strok taramasında yalnız SL04 sıkışması ve +2,58'de yaka-HS05 dayanması; STEP yazıldı.

- FS01 (ISO 7045 M4x8) modellendi: `cad\EP5-FS01_SCR-FLANGE.prt/.stp`, rapor `cad\EP5-FS01_REPORT.md` (journal PASS).
- QA aracı hazır ve denendi: `an\qa_dev.py` (kendi çok başlangıçlı hizalama, K1/K2), özellik listeleri `an\qa\specs\`
  (DR01, EM01, EM02, EM03, HS01-HS05).

## Sıradaki
1. Montaj bitti. Sıradaki: orkestratör E (Teori) oturumunu başlatır. A_OLCUM_ONERISI cevapları gelirse yalnız `ctrl\mk_params.py` -> yeni revizyon -> parça journal'ları + `asm\asm_build.py` yeniden.
2. Aşama 4: AS01, AS02, AS03, AS00; girişim / boşluk; strok taraması; STEP.

## Açık soru
- **Çalışma alanı taşındı** (2026-10-17 ~01:02, `butun dosyalar D diskine tasindi.txt`): `C:\NX_MCP_WORKSPACE\ulka\` ->
  `D:\C_Yedek_2026-10-15\02_Tam_Yedek\C_NX_MCP Workspace\ulka\`. `cad\` parçalarının interpart linkleri kontrol parçasını
  eski yolda arar: NX'te açmak / yeniden kurmak için geri taşıma ya da relink gerekir (Usta kararı). A bu sırada
  `ULKA_INTERFACES.md`'yi yanlışlıkla boşalttı ve D'deki kopyadan (Rev H) geri kurdu.
- CR-E-01: türetilmiş VL02 ile emme valfi çalışmıyor (E); Rev H değişmedi, A_OLCUM #4 ve #5 öncelikli.
- A_OLCUM_ONERISI'nin 6 kalemi (d_p, HS01 iç derinlik, yay sabitleri, HS02 iç profili, VL02/VL04, bobin direnci).
- SL01 yeri (flanş altı) türetildi; 15 bar kontrolü destekliyor.
- Yay teli çelişkisi: Usta 1,0 / 1,3, tarama 1,19 / 1,41 -> k ~2 kat; A_OLCUM #3 (k ölçümü) çözer.

## Engel
- Yok.

## Araçlar
- `C:\NX_MCP_WORKSPACE\ulka\an\`: `ulkalib.py`, `a01..a12_*.py`, `nxrun_a.sh` (kilit + RAM kontrollü journal çalıştırıcı).
- Kontrol parçası revizyonu: `ctrl\mk_params.py` düzenle -> `python mk_params.py` -> `an\nxrun_a.sh ctrl\ctrl_build.py 600 ctrl`
  -> `mk_table.py` ile INTERFACES §9 tablosu.
