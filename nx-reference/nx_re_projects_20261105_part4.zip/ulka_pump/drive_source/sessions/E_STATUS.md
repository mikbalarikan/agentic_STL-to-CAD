TEORİ BİTTİ

# E_STATUS - ULKA-E Teori

Güncelleme: 2026-10-17 - Aşama 5 ilk tur bitti (türetilmiş girdilerle). CFD: plan hazır, koşu yok (Usta onayı bekler).

## Biten
- `theory\ULKA_THEORY_REPORT.md` + `.pdf` (şablondan üretiliyor), `theory\ULKA_DESIGN_PROCESS.md`, `cfd\SIMULATION_PLAN.md`.
- Hesap zinciri `theory\calc\` (tek girdi `inputs.json`; `run_all.py`): c1 STEP geometri, c2 eksenel simetrik doğrusal
  olmayan manyetik alan tablosu, c3 dinamik model (yarım dalga + diyot, armatür, yaylar, tüp/oda düğümleri, buhar,
  iki çek valf, sızıntı), c4 48 W kalibrasyonu + Q-p, c5 kayıplar/kavitasyon, c6 duyarlılık (6 kalem + varsayımlar),
  c7 ayar varyantı.
- `cr\CR-E-01.md` (A'ya haber verildi): türetilmiş VL02 + oda dibi emme valfini açtırmıyor; ctrl dinlenmesinde VL02 yok.
  A'nın kararı (Rev H): kontrol parçası değişmiyor (INTERFACES §7.5); A_OLCUM #4 ve #5 öncelikli; Rev I seçeneği
  `vl02_d` 0,35 + `z_dr01`'e VL02 kuvveti - orkestratör / Usta kararı.

## Sonuç (kısa)
- Bobin türetildi: N ≈ 4205, R ≈ 132 Ω (20 °C), tel ≈ 0,275 mm.
- Taban model: 0 bar 405 cm³/dk (E5 650), kapalı uç ~20 bar (E5 15); 10 noktanın 3'ünde kapı tuttu, RMS 105.
- Ayar varyantı (FIT_vl02_d 0,35, FIT_k_scale 1,2): RMS 59; düşük basınç tutuyor, kapalı uç tutmuyor (>18 bar).
- En etkili ölçümler: #5 VL02 + #4 oda dibi, sonra #3 k, #6 R, #2 HS01 derinliği; #1 d_p gürültü altında.
  Test düzeneğinin giriş hortumu da 0 bar debisini ±100 oynatıyor.

## Sıradaki
- Usta'nın 6 ölçümü gelince: `theory\calc\inputs.json` -> `usta_olcum.*.value`, `python run_all.py` (~2-3 saat).
- Ardından CFD aşama 0 (valf Cd, armatür delik kaybı).

## Kararlar
- 2026-10-17, Usta (orkestratör aracılığıyla): CFD aşama 0 ölçümlerden sonra başlar. Sıra: Usta 6 ölçümü verir ->
  orkestratör iletir -> inputs.json + run_all.py -> CFD aşama 0. O zamana kadar CFD koşusu yok.

## Açık soru (orkestratöre)
- E5 eğrisinin test düzeneği (giriş hortumu / depo) biliniyor mu?

## Engel
- Yok.
