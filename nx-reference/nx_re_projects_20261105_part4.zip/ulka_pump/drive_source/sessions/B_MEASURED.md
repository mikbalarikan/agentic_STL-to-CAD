# ULKA-B Stator - Aşama 1 ölçümleri (EM01, EM02, EM03 x2, HS04)

Tarih: 2026-10-16. Yazar: ULKA-B. Kaynak: yalnız taramalar (STL), fotoğraflar F03/F04/F05/F10/F11/F21.
Araçlar: `C:\NX_MCP_WORKSPACE\ulka\parts\_B_common\` (R385 B araçlarından uyarlandı: `rb.py`, `bm.py`, `m_*.py`,
`s2_aligned.py`). Hizalı kopyalar: `C:\NX_MCP_WORKSPACE\ulka\scan\EP5-<kod>_aligned.stl`; ham -> hizalı 4x4
dönüşümler `parts\_B_common\qa\aligned_transforms.json`.

Gürültü sütunu: o yüzeyde robust uydurmanın artık std'si (mm). "tek yüz" = taramada yalnız bir yüz görünüyor.

## 0. Özet: arayüz değerleri (A için)

| Ad (öneri) | Değer mm | Kaynak / güven |
|---|---|---|
| `em01_bore_d` (bobin deliği, uçlarda) | 21,75-21,9 (uç), 21,45 (orta, en dar) | tarama, iki uçtan koniklik (kalıp eğimi); sd 0,02-0,05 |
| `em01_body_d` (makara dışı) | 47,21 | silindir uydurma, rms 0,025 |
| `em01_len` (makara uç yüzleri arası) | 43,45 | uç yüzler z=0 / 43,45 (bkz. §1) |
| `em02_t` (sac kalınlığı) | 3,00 (2,94 / 3,03 iki duvar) | düz duvarlarda iki yüz; iyi |
| `em02_in_axial` (delikli duvarların iç yüzleri arası) | 44,12 | -y iç yüz + (+y dış yüz - t); bkz. §2 |
| `em02_in_x` (düz duvarlar iç arası) | 47,99 | iki yüz, sd 0,03 |
| `em02_hole_out_d` (çıkış tarafı duvar deliği, 6 delikli duvar) | 21,24 | sd 0,036, tam çevre |
| `em02_hole_in_d` (giriş tarafı duvar deliği) | 16,74 | sd 0,031, tam çevre |
| iki deliğin eş eksenliliği | 0,04 | merkezler (0,104,-0,029) / (0,111,0,005) |
| FS01 / HS03 deliği adayları (çıkış duvarı) | 4 x Ø3,72 @ (±14,0 , ±5,0); 2 x Ø3,5 @ (±18,9 , 0) | sd 0,02-0,07 |
| `em03_od` | 21,00 / 20,97 (burç 1 / 2) | sd 0,02-0,03, 17 dilimde sabit |
| `em03_id` | 16,71 / 16,72 | sd 0,02-0,05 |
| `em03_len` | burç 1 >= 18,7 (bir ucu taranmamış), burç 2 = 18,92 | uç yüzler |
| `em03_slit_w` (yarık) | ~0,5 (0,45-0,65) | tarama yarığı kısmen köprülemiş; türetildi |
| `hs04_od` | 20,78 (20,68 alt - 20,98 üst) | ortak merkezli uydurma, sd 0,03 |
| `hs04_id` | 17,11 (17,05-17,26) | ortak merkezli uydurma, sd 0,036 |
| `hs04_h` | 9,1 (9,0-9,15) | üst yüz eğik 0,65°, sd 0,04 |

Tutarlılık (eksenel yığın, giriş duvarından çıkışa):
giriş duvarı iç yüzü -> burç (18,9) -> HS04 (9,1) -> burç (18,9) = 46,9; çerçevede giriş duvarı iç yüzünden çıkış
duvarı **dış** yüzüne 47,12. Yani burçlar Ø16,74 delikli duvarın iç yüzüne dayanır, HS04 bobin ortasında manyetik
ara (hava aralığı yeri) olur, ikinci burç Ø21,24 deliğinden geçip çıkış duvarının dış yüzüyle yaklaşık aynı düzleme
gelir (0,2 içeride). Çaplar da bunu destekliyor: burç OD 21,0 -> çerçeve deliği 21,24 (0,12 radyal boşluk) ve
bobin deliği 21,45-21,9; burç ID 16,71 = giriş duvarı deliği 16,74 = HS04 ID'den küçük (17,1) -> kartuş tüpü
(HS01) Ø<=16,6 olmalı. Bobin boyu 43,45, çerçeve iç eksenel 44,12 -> 0,67 eksenel boşluk.
Bu yığın bir **öneri**dir (taramadan çıkarım, montajlı tarama yok); A doğrular.

## 1. EP5-EM01 bobin

Tarama: 500 391 üçgen, tek kabuk, 3941 açık kenar (delik içi ve bir uç kısmen eksik).
Parça çerçevesi (`EP5-EM01_aligned.stl`): Z = delik ekseni (delik silindiri uydurması), z=0 terminal plakası
tarafındaki makara uç yüzü, +Z düz uca; +X uç tırnaklarının yönü (bkz. aşağı).

| Ölçü | Değer | Not |
|---|---|---|
| Makara gövde dış Ø | 47,21 (silindir rms 0,025) | dilimlerde 47,3-47,6 hafif fıçı; gövde ekseni delik eksenine 0,40° eğik |
| Delik Ø | uç z≈0-2: 21,96-21,78; orta z≈10-20: 21,40-21,46 (en dar); uç z≈42: 21,93 | iki uçtan çekirdek pimi koniklik; ortalama 21,69 |
| Makara uç yüzleri | z=0 (terminal tarafı) ve z=43,45 | iç halka (r 11,2-16,8) +uçta 0,59 çökük (z=42,86) |
| Uç tırnakları (her iki uçta 1'er) | +X yönünde, r 12,3-16,4, genişlik ~4,1 (açısal 77-93°); +uç: z 43,45->45,8 (2,35); terminal ucu: z 0->-3,0 (3,0) | EM02 duvar çentiklerine/yarıklarına oturuyor (bkz. §2), bobinin dönüş konumunu verir |
| Terminal plakası | +X yönünde, x 23,6->31,67, y -22,43..22,04 (44,5 genişlik), z -0,86..5,63 (6,5 kalınlık) | plaka çerçeve şeridinin dışında kalıyor |
| Fast-on bıçakları (2 adet, 6,3x0,8) | dış yüz x≈31,0; y merkezleri -15,65 ve -2,76 (aralık 12,9); z 6,6..14,5 (plaka üstünden 8,9) | bıçak iç yüzü taranmamış, kalınlık 0,8 datasheet |
| Delikte anahtar çıkıntıları | uçlarda delik kenarında küçük kulakçıklar (görüntü `fig\v1_frame.png`) | işlevsel değil, modelde basit |

Gürültü: gövde 0,025; delik 0,02-0,07 (delik içi yarı yarıya taranmış, kapsama 100-160°).

## 2. EP5-EM02 manyetik çerçeve

Tarama: 500 010 üçgen, tek kabuk. Parça çerçevesi (`EP5-EM02_aligned.stl`): Z = büyük deliklerin ortak ekseni,
+Z 6 delikli duvara (çıkış / HS03 tarafı, öneri), z=0 bu duvarın dış yüzü; X = düz duvarların normali; Y = şerit
genişliği yönü. (Ara çerçeve "box": `EP5-EM02_box-frame.stl`, x=düz duvar normali, y=delik ekseni, z=şerit.)

Yapı: tek şerit sacdan bükülmüş kapalı dikdörtgen; iki ucu çıkış duvarının ortasında (X=0) birleşiyor - birleşme
çizgisi büyük delikten geçen dar yarık olarak görünüyor. Giriş duvarının iki şerit kenarında (Y=±16) yarım
yuvarlak uçlu çentik var (bobin tırnağı yuvası).

| Ölçü | Değer | Not |
|---|---|---|
| Sac kalınlığı t | 3,00 | düz duvarlar: 2,93 ve 3,02 (iki yüz ölçülü) |
| Dış X | 53,96 (x -26,80 / +27,16) | datasheet 54,3 ile uyumlu (etiket + bombe) |
| İç X | 48,01 | |
| Delikli duvarlar | giriş duvarı iç yüz z=-47,12; çıkış duvarı dış yüz z=0 | her ikisi tek yüz taranmış; t=3,0 ile dış eksenel 50,12, iç 44,12 |
| Şerit genişliği (Y) | 32,06 (kenar yüzleri ±16,03) | düz bölgede yüz kenarı 31,7 (kenar yuvarlatması) |
| Büküm dış R | 4,1 (çıkış duvarı köşeleri, sd 0,03-0,07) | giriş duvarı köşelerinde iç R 1,8-1,9 (sd 0,26), dış yüz taranmamış |
| Büküm iç R | 1,1 (= 4,1 - t) / 1,9 (giriş köşeleri) | **tutarsız**: tek büküm radyüsü bekleniyor; türetme R_i = 1,5 öneri, A karar versin |
| Çıkış duvarı deliği | Ø21,24, merkez (X 0,10, Y -0,03) | + iki şerit kenarına açılan birleşme yarığı, genişlik ~2,5 (modelde ölçülecek) |
| Giriş duvarı deliği | Ø16,74, merkez (0,11, 0,01) | |
| Çıkış duvarı küçük delikleri | Ø3,72 x4 @ (X -13,95/-13,91/14,10/14,07 ; Y∓5,0) ; Ø3,54/3,49 x2 @ (X -18,85 / +18,97 ; Y≈+0,16) | Y işaretleri aligned çerçevede ters (Y = -box z); 4'lü desen 28,0 x 10,0; 2'li aralık 37,8 |
| Giriş duvarı çentikleri | X -2,3..+2,3 (genişlik ~4,6), şerit kenarından derinlik 4,25, yarım yuvarlak dip | iki kenarda (Y=±) |
| Düz duvar pencereleri | her iki düz duvarda, çıkış duvarı bükümü bölgesinde: z(box y) 19,3 -> büküme, Y ±3,1 (6,2 genişlik) | işlevi açık (bobin plakası? kilit?) |

Gürültü: düzlemler 0,027-0,05 (düz duvar), 0,07-0,08 (delikli duvarlar, tek yüz); delikler 0,02-0,04 (büyük),
0,02-0,07 (küçük).

FS01 notu: HS03'ün iki kulağı 2'li deliklere (aralık 37,8, Ø3,5) ya da 4'lü desenden ikisine bağlanıyor olabilir;
eşleşme D'nin HS03 kulak aralığıyla kesinleşir. Delikler diş açılmamış görünüyor (Ø3,5-3,7: M4 vida için
diş açma çapı ~3,3 / M3 geçiş 3,4) - taramadan diş görülemez. **A/D karar verir.**

## 3. EP5-EM03 akı burcu (x2)

Tarama iki kabuk (her biri bir burç). Çerçeve (`EP5-EM03_sleeve1_aligned.stl`, `..._sleeve2_aligned.stl`):
Z = dış silindir ekseni, z=0 alt uç yüzü.

| Ölçü | Burç 1 | Burç 2 |
|---|---|---|
| OD | 21,002 (sd 0,028) | 20,972 (sd 0,023) |
| ID | 16,714 (sd 0,022) | 16,716 (sd 0,053) |
| Et | 2,14 | 2,13 |
| Boy | >= 18,70 (üst uç yüzü taranmamış; en uç noktalar 18,7-18,8) | 18,92 (iki uç yüz) |
| Yarık | açı -69° (tarama çerçevesinde), genişlik 0,5-0,66 | açı 93°, yarık yan yüzleri 0,98 aralıklı ama dış deri köprülenmiş |

Değerlendirme: iki burcun boyu ölçü belirsizliği içinde aynı (18,8 ± 0,1); farklı boy kanıtı yok. Öneri: tek
nominal `em03_len` = 18,9 (burç 2 tam ölçülü), iki kopya. Yarık genişliği türetildi: 0,5 (fotoğraf F04 kıl
kadar ince yarık gösteriyor). Uç pahları ~0,4 (dış silindir uç yüzden 0,45 önce bitiyor) - kenar kırma.

## 4. EP5-HS04 plastik ara halka

Tarama tarayıcı masasında dik duruyor, tek yönden: dış duvar bir yarıda, iç duvar öbür yarıda görünüyor
(her biri ~140°). Masa düzlemi çıkarıldı. Çerçeve (`EP5-HS04_aligned.stl`): Z = eksen, z=0 masa (alt yüz).

| Ölçü | Değer | Not |
|---|---|---|
| OD | 20,78 (alt 20,68 -> üst 20,98; 0,3 koniklik ya da tarama eğimi) | ortak merkezli uydurma; ayrı uydurmalar 20,48 / 16,93 veriyordu - kısmi yay belirsizliği, üst yüz halkası ortak merkezliyi doğruluyor (r 8,6-10,4) |
| ID | 17,11 | |
| Boy | 9,1 (üst yüz 9,15, masa 0-0,15) | üst yüz 0,65° eğik |
| Üst iç kenar | ~0,35 pah/yuvarlatma | üst yüz iç kenarı r 8,91 |

Görev (çıkarım): bobin deliğinde iki akı burcu arasında manyetik olmayan ara parça; OD 20,78 bobin deliğine
(21,45-21,9) boşluklu, ID 17,1 kartuş tüpünün üstünde. Konumu §0 yığınında.

## 5. Açık sorular (A'ya)

1. Bobin hangi ucuyla (terminal plakası ucu) giriş duvarına bakıyor? Taramalar söylemiyor; video / fotoğraftan A.
   Tırnaklar iki uçta aynı açıda olduğundan iki yön de çerçeveye geçiyor.
2. Giriş/çıkış ataması: Ø16,74 duvar = giriş (HS01 tüpü geçer), 6 delikli Ø21,24 duvar = çıkış (HS03 bağlanır).
   HS01 tüp dış Ø'ı ve HS03 kulak aralığı (C, D) ile doğrulanmalı.
3. Büküm iç radyüsü tek değere iner mi (1,1 / 1,9)? Öneri 1,5; dış köşe 4,1 ölçülü olduğundan çıkış köşeleri
   R_i=1,1 ile daha iyi tutar. A'nın kabul bandına göre karar.
4. FS01 hangi deliklere gider (2'li Ø3,5 @ 37,8 mi, 4'lü Ø3,72 mü)? Diğer delikler (4'lü) ne için? (HS03'ün
   konum pimleri olabilir.)

## 6. Ölçüm önerisi adayı (A'nın `A_OLCUM_ONERISI.md` listesi için, en çok 1 kalem)

- EM02 sac kalınlığı ve büküm iç radyüsü kumpasla tek ölçüm (t=3,0 iyi ölçülü; R_i belirsiz). Kritik değil
  (manyetik devre hesabında kesit alanı t ile, R_i önemsiz). Önceliği düşük.
