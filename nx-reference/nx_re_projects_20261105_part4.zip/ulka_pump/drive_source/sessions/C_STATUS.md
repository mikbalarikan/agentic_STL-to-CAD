# ULKA-C Tahrik - durum

Son güncelleme: 2026-10-16, C'nin dört parçası teslim edildi ve A QA'sından geçirildi (yaylarda K2 tutmadı, raporlu). İş tamam. **Montaj PASS (A, Rev H)**: yaylar sıkışmış kopyalarla (DR03 26,70, DR02 10,57, blok üstünde), strok -8,13..+2,58 çarpışmasız, `cad\assembly\`.

## Biten
- Aşama 1 ölçüm -> `sessions\C_MEASURED.md` (+ Düzeltme 1). Yay tarafı: DR03 arka, DR02 ön (video).
- **DR01 teslim** (Rev A=B değerleri): `cad\EP5-DR01_ARMATURE-PISTON.prt/.stp/_REPORT.md`; journal PASS 18 kontrol,
  taramaya ±0,15 içinde %98,8 (işlevsel yüzeyler %96-100). **A_QA PASS** (K2 %98,9, K1 9/9).
- **HS01 teslim (Rev B)**: `cad\EP5-HS01_INLET-BODY.*`; journal PASS, taramaya %96,1; **A_QA PASS** (K2 %96,2, K1 7/7).
- CR-C-01 (yay OD / n_t) Rev B'ye girdi. CR-C-02 yazıldı (yay od = D_merkez + Usta teli: 12,75 / 12,84; tarama
  şişmesi ve d_p ölçüm önerisi); Rev C'ye girdi.
- **DR02, DR03 teslim (Rev F)**: `cad\EP5-DR02_SPRING-FRONT.*`, `cad\EP5-DR03_SPRING-REAR.*`; journal PASS (13 kontrol).
  Kendi K2 tahmini **tutmadı**: DR03 %84,3, DR02 %63,4 (tel şişmesi +0,065 / +0,104; uç sarımları). **A_QA: K2 tutmadı** (DR03 %83,9, DR02 %71,0 - tel şişmesi), K1 OD/ID PASS, uç düzlemleri tutmadı (yarı taranmış uçlar). A: C'nin işi tamam, ölçüsüyle raporda.
- HS01 Rev F ile yeniden teslim, A_QA PASS.

## Sıradaki
- Yok. A'nın montaj koşusundan gelen CR / revizyonda ilgili parçayı yeniden koştur (linkli; `C_common\nxrun.sh`).

## Modelleme planı (Rev A'ya bağlı)
Ortak: R385 `nxlib\rj.py` + `ps.py` (kopyası `parts\C_common\nxlib\`). Her parça kendi klasöründe
`parts\<kod>\<kod>.py` journal; arayüz ölçüleri kontrol parçasından interpart expression (`link(name)`), parça içi
ölçüler adlı expression; sketch'ler DOF 0. Teslim `cad\<kod>_<ETİKET>.prt/.stp` + `cad\<kod>_REPORT.md`.
Sabit parça (HS01) montaj koordinatında yerinde; hareketli parçalar (DR01, DR02, DR03) kendi ekseninde (z=0 tanımı
C_MEASURED'da), A konumlandırır.

1. **EP5-DR01_ARMATURE-PISTON** - tek revolve profili (dış: arka pilot Ø9,5 / armatür Ø14,34 / ön kademe Ø10,02 /
   yaka Ø8,5 / piston d_p; iç: delik Ø6,09 ve piston iç Ø2,72) -> pencere yarığı (blok, simetrik Subtract,
   genişlik ~5,1, z 1,41..6,36) -> uç iç havşası (Chamfer/Revolve kesimi) -> köşe radyusları. Arayüzler linkli:
   armatür Ø, boy, d_p, piston uç z, havşa.
2. **EP5-HS01_INLET-BODY** - yerinde (montaj koordinatı)
   revolve: nipel (2 tırnak) / boyun Ø12,9 / tüp Ø16,09 / flanş Ø20,23 / soket dudağı; iç: nipel deliği / tüp
   deliği Ø14,92 / dip. Linkli: tüp dış Ø, tüp iç Ø, flanş yüzü z, soket ağzı z, iç dip z.
3. **EP5-DR02_SPRING-FRONT**, **EP5-DR03_SPRING-REAR** - serbest boyda: değişken adımlı merkez eğrisi (uç kapalı
   sarımlar + aktif sarımlar; Law/Helix), tel çemberi Sweep, uçlar düzlemle taşlama (Trim). Expression: d, D, L0,
   n_t, n_a, p. Montaj boyu A'nın expression'ı ile ikinci (sıkışmış) kopya.
Her parça bitince: kendi dev.py sapma kontrolü (işlevsel / genel bölgeler, Rev A kapısıyla), rapor, A'ya haber.

## Açık soru / engel
- Engel yok. CR-C-02 kararı yay OD'sini değiştirir (linkli, yeniden koşum yeter).
- A'ya açık noktalar C_MEASURED sonunda (d_p 4,97 / 5,00 yuvarlaması; HS01 iç dip z; strok; nipel 6,9 / 7,2).
