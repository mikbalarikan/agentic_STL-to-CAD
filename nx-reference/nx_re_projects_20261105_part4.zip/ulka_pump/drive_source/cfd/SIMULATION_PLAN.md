# Ulka EP5 titreşimli pompa: CFD simülasyon planı

**Yazar:** ULKA-E Teori · **Tarih:** 2026-10-16 · **Durum:** PLAN - hiçbir koşu başlatılmadı; **Usta onayı beklenir.**
**Çözücü ortamı (öneri):** OpenFOAM v2606 (ESI). R385 projesinde bu makinede WSL2 Ubuntu 22.04 altında kurulu
bulunmuştu (`/usr/lib/openfoam/openfoam2606`); Ulka için yeniden doğrulanacak. **Akışkan:** su, 20 °C
(ρ = 998,2 kg/m³, ν = 1,004·10⁻⁶ m²/s, p_v = 2,34 kPa).

Sayıların kaynağı `theory\ULKA_THEORY_REPORT.md` (bölüm numaraları aşağıda) ve `theory\calc\out\*.json`. Rapor
yeniden üretildiğinde (Usta'nın ölçümleriyle) bu plandaki sayısal hedefler de o dosyalardan okunmalıdır.

## 0. CFD neyi çözebilir, neyi çözemez

Teori raporunun 0-B modeli üç yerde katsayıyı varsayımla taşıyor ve sonucu en çok bunlar belirliyor:

1. **Valf geçişleri**: VL01 bilyası (Ø3,572, Ø2,72 keskin kenarlı yuvada) ve VL03 kubbe tapası (R2,76, Ø4,0 kenarda,
   Ø5,0 baş / Ø6,0 delik halkası) için boşaltma katsayısı $C_d(h)$ ve akış kuvveti (model: $C_d$ = 0,65 sabit,
   kuvvet = Δp × oturma alanı).
2. **Armatürün içinden geçen akış**: arka tüp hacmi -> Ø6,09 eksenel delik -> Ø5,15 çapraz delik -> ön tüp hacmi
   (model: iki keskin kenarlı orifis, K = 1,5 + 1,5) ve 0,29 mm halka aralık. Armatür hızında bu yol armatürü
   frenleyen basınç farkını ve **ön / arka tüpte kavitasyonu** belirliyor (rapor bölüm 6).
3. **Oda içi akış ve kavitasyon çöküşü**: basma strokunun başında buhar boşluğunun çöküşü, oda basıncında tepeler
   (rapor bölüm 3.3, şekil l1).

CFD bu katsayıları **verilen bir hareket için** hesaplar. Çözemedikleri: yay sabitleri, bobin direnci, d_p, oda dibi
derinliği (bunlar ölçüm ister: `sessions\A_OLCUM_ONERISI.md`). Bu yüzden önerilen sıra: **önce Usta'nın 6 ölçümü ve
teori raporunun yeniden üretimi, sonra CFD.** Aşama 0 ölçüm beklemeden yapılabilir (valf geometrisi taramadan).

## 1. Kademeli yaklaşım

| Aşama | Geometri | Hareket | Çıktı -> 0-B modele dönüş | Kaynak | Yer |
|---|---|---|---|---|---|
| 0a | VL01 bilyalı valf, eksenel simetrik (5° kama) | yok; bilya 8 sabit kalkışta (0,02 .. 1,0 mm) | $C_d(h)$, akış kuvveti katsayısı $C_F(h)$ (`Cd_ball`, kuvvet) | 30-80 bin hücre, kalkış başına 1-3 dk, `simpleFoam` k-ω SST + laminer karşılaştırma | yerel |
| 0b | VL03 tapa + VL04 bölgesi + VL05 kafes + G1/8 ağız, eksenel simetrik (VL05 kolları için 3B kontrol) | yok; tapa 8 kalkışta (0,02 .. 0,975) | $C_d(h)$, $C_F(h)$, kafes kaybı (`Cd_plug`, `A_o_ann`) | 2B: 50-100 bin; 3B kontrol 1-2 milyon | yerel (2B), 3B yerel sınırda |
| 0c | DR01 armatürü (eksenel delik + çapraz delik + halka aralık) tüp içinde, 3B (çapraz delik eksenel simetrik değil; 1/4 simetri) | göreli akış: armatür sabit, iki uçtan debi verilir (armatür hızı 0,5 .. 2 m/s eşdeğeri) | $K_\mathrm{bore}$, $K_\mathrm{xhole}$, halka akışı payı | 0,5-1 milyon, `simpleFoam` | yerel |
| 1 | piston ucu + oda + iki valf, eksenel simetrik, bilya ve tapa **sabit açık / kapalı diyot** (gözenekli bölge, R385 aşama 1 yöntemi) | piston: 0-B modelin $z_f(t)$ izi (rapor şekil l1, 0 / 7 / 14 bar) | oda basıncı izi, hacim korunumu, valf diyotlarıyla 0-B karşılaştırması | 50-150 bin, katman ekleme / çıkarma ya da afin sıkıştırma; çevrim başına 20-40 bin adım | yerel |
| 2 | aynı + **hareketli bilya ve tapa** (overset, 6 serbestlik derecesi yerine tek eksen, yay bağı) | piston izi 0-B'den; valf gövdeleri serbest | valf gecikmesi, geri kaçak (rapor bölüm 6.4 ile), oda basınç tepeleri | 2B: 0,2-0,5 milyon; 3B: 2-4 milyon | 2B yerel; 3B **bulut** |
| 3 (seçmeli) | aşama 2 + kavitasyon (`interPhaseChangeDyMFoam`, Schnerr-Sauer) | aynı | buhar hacmi, çöküş basıncı; 0-B'nin buhar düğümü (`p_v` + boşluk) karşılaştırması | aşama 2'nin 1,5-2 katı | bulut |
| 4 (seçmeli) | tam kartuş: giriş nipeli + tüp + armatür + piston + oda + valfler | armatür **iki yönlü bağlı**: kuvvet = manyetik tablo (`mag_tables.npz`) + yaylar + akışkan (codedFunctionObject / sixDoF dış kuvvet) | Q-p noktaları doğrudan | 3-6 milyon | bulut |

Her aşama bir öncekinin doğrulama ölçütünü (bölüm 5) geçmeden başlamaz; her aşamanın sonucu 0-B modele (`theory\calc\
inputs.json`'daki adlandırılmış katsayılar) geri döner ve rapor yeniden üretilir.

## 2. Akış hacimleri

Montaj STEP'i (`cad\assembly\EP5-AS00_ASSY.stp`, dinlenme konumu) negatif hacim çıkarmaya hazır: kartuş eksenel
simetrik, akış yolu tamamen HS01 + HS02 içinde. R385'in `cfd\tools\extract_fluid.py` aracı **kopyalanıp
uyarlanır** (R385 klasörüne yazılmaz):

| Hacim | Sınırlar | STEP'ten | Not |
|---|---|---|---|
| Oda | SL04 contası -> piston ucu / bilya -> Ø6,0 oda -> Ø4,0 oturma -> VL03 başı | dinlenmede 458 mm³ (model dinlenmesi), en ileride 397 mm³ (rapor bölüm 1.3) | Ø6,0 oda ve 0,8 duvar **türetildi**; A_OLCUM #4 gelmeden aşama 1-2 sonuçları geçici |
| Valf odası + çıkış | Ø6,0 valf deliği, Ø8,52 havşa, VL05 kafesi (açık alan 23,5 mm²), G1/8 ağız (Ø8,52; diş yok) | VL03, VL04, VL05 gövdeleri çıkarılır | çıkışa 10 mm düz uzatma (sınır koşulu uzağa) |
| Tüp | nipel Ø3,0 (türetildi) -> tüp Ø14,92 -> armatür (delik, çapraz delik, halka aralık) -> HS05 deliği | dinlenmede arka 4239 mm³, ön 1410 mm³ (yaylar dahil değil) | DR02 / DR03 yayları aşama 0c'de gözenekli bölge ya da yok sayılır (tel kesiti küçük) |

Yaylar: VL02 (tel 0,5) ve VL04 (tel 0,45) akışkan hacminden çıkarılmaz (sarımlar arası açıklık büyük); aşama 2'de
yay kuvveti overset gövdeye doğrusal yay bağı (`sixDoFRigidBodyMotion` `linearSpring`) olarak verilir.

## 3. Hareketli sınırlar

| Sınır | Hareket | Yöntem | Not |
|---|---|---|---|
| Piston ucu (Ø4,97) | 0-B izinden $z_f(t)$, strok 7-11 mm (oda boyunun %40'ı) | aşama 1: `layerAdditionRemoval` (piston yüzünde katman ekle / çıkar) ya da `dynamicMotionSolverFvMesh` + afin sıkıştırma (R385 aşama 1'de çalıştı); aşama 2-4: overset arka plan + piston gövdesi | piston ile oda duvarı arasında 0,51 mm halka: piston duvara sürtmüyor, overset uygun |
| VL01 bilya | pistonla birlikte + kendi kalkışı | overset alt ağ (küre), tek eksen serbestliği, yay bağı (VL02) | oturmuşken boşluk 0'a gidemez: en küçük kalkış 0,01-0,02 mm (sızıntı alanı olarak 0-B'deki `leak_area` ile eşleştirilir) |
| VL03 tapa | kalkış 0 .. 0,975 | overset alt ağ, yay bağı (VL04) + VL05'e dayanma | elastomer kubbe rijit kabul |
| Armatür (aşama 4) | 0-B'nin çözdüğü $z_f(t)$, ya da iki yönlü bağlı | overset; tüp - armatür halka aralığı 0,29 mm: aralıkta en az 6 hücre | manyetik kuvvet tablodan, akım ODE'si coded kaynakta |

`activePressureForceBaffleVelocity` kullanılmaz (R385 notu: kendiliğinden kapanan çek valfi temsil etmez).

## 4. Ağ, çözücü, zaman

| Öğe | Seçim |
|---|---|
| Ağ | `snappyHexMesh` (STL'den), aşama 0a/0b/1 için `blockMesh` kama; oturma aralıklarında genişlik boyunca ≥ 8 hücre (0,02 mm kalkışta 2,5 µm: bu yüzden en küçük kalkış 0,02, altı 0-B'deki sızıntı yasasıyla) |
| Çözücü | daimi: `simpleFoam`; geçici: `pimpleFoam` / `overPimpleDyMFoam`; kavitasyon: `interPhaseChangeDyMFoam` |
| Türbülans | oturma jetleri Re ≈ 10³ - 10⁴ (aralık 0,05-0,3 mm, hız 5-25 m/s): k-ω SST, laminer ile karşılaştırma |
| Sınır koşulları | giriş `totalPressure` (depo, 0-B'nin `h_tank`); çıkış `totalPressure` = Q-p noktasının basıncı (0 / 7 / 14 bar) |
| Zaman adımı | maxCo 0,5; oturma aralıklarında Δt ≈ 10⁻⁷ - 10⁻⁶ s: 20 ms çevrimde 2·10⁴ - 2·10⁵ adım |
| Çevrim | en az 4 (0-B modelde 6 çevrimde oturuyor; yüksek basınçta hareket düzensiz - aşama 1-2'de piston izi 0-B'den verildiği için bu sorun yok) |

## 5. Doğrulama ölçütleri (modellemeden önce sabitlendi)

| Ölçüt | Hedef | Karşılaştırılan |
|---|---|---|
| Ağ hacmi yasası (aşama 1) | bağıl fark < 10⁻⁴ | $V(t) = V_\mathrm{dinlenme} - A_p\,(z_f(t) - z_\mathrm{dinlenme})$ |
| Küresel süreklilik | çevrim başına giren - çıkan - ΔV < %0,1 süpürme hacmi | - |
| Valf $C_d(h)$ (aşama 0) | sonuç raporlanır; 0-B'nin 0,65'inden farkı katsayı olarak `inputs.json`'a döner | rapor bölüm 3 |
| Armatür delik kaybı (aşama 0c) | sonuç raporlanır; 0-B'nin K 1,5 + 1,5'inden farkı döner | rapor bölüm 6 |
| Oda basıncı izi (aşama 1) | aynı valf yasasıyla 0-B izinden tepe basınç ve zamanlamada ±%10 / ±0,5 ms | rapor şekil l1 |
| Ağ ve zaman adımı bağımsızlığı | iki ardışık inceltmede < %2 | - |

Tutmayan ölçüt "tutmadı" diye, ölçüsüyle yazılır; hedef sonuç görüldükten sonra gevşetilmez.

## 6. Kaynak ihtiyacı: yerel mi bulut mu

Makine: 15,6 GB RAM, boş bellek çoğu zaman 2,5 - 5 GB; 24 mantıksal çekirdek. Proje kuralı: aynı anda tek ağır iş,
boş bellek 2,5 GB'ın altına inmez. OpenFOAM için kaba bellek: ~1-1,5 GB / milyon hücre (overset 2 kat).

| Aşama | Hücre | Bellek | Tahmini süre | Öneri |
|---|---|---|---|---|
| 0a, 0b (2B) | 30-100 bin | < 0,5 GB | kalkış başına dakikalar; 16 kalkış < 1 saat | **yerel** |
| 0b (3B kontrol), 0c | 0,5-2 milyon | 1-3 GB | daimi, birkaç saat | yerel (NX ve tarama işleri yokken) |
| 1 (2B, hareketli piston) | 50-150 bin | < 0,5 GB | 4 çevrim × 3 basınç: 3-10 saat | **yerel** |
| 2 (2B overset) | 0,2-0,5 milyon | 1-2 GB | çevrim başına 2-6 saat | yerel sınırda / bulut |
| 2 (3B), 3, 4 | 2-6 milyon (overset) | 6-15 GB | çevrim başına 10-40 saat (16 çekirdek) | **bulut** (≥ 32 GB, ≥ 16 çekirdek) |

Bulut için R385'teki düzen (`r385\cfd\CLOUD_HANDOFF.md`: önce kurulum ve hız ölçümü, sonra aşama aşama Usta kararı)
örnek alınır. Yerel koşularda WSL'in bellek sınırı (`.wslconfig`) en çok 9 GB tutulur ve NX journal kilidiyle
(`C:\NX_MCP_WORKSPACE\ulka\nx.lock`) aynı anda koşulmaz.

## 7. Bilinen riskler

- **Geometrinin iç kısmı türetildi**: oda Ø6,0 ve dibi, oturma Ø4,0, nipel Ø3,0. Ölçüler gelmeden yapılan aşama
  1-4 sonuçları geçicidir; aşama 0a (bilya / piston ucu, taramadan) ve 0c (armatür, taramadan) bundan etkilenmez.
- **Valf oturma teması**: sıfır aralık CFD'de yok; en küçük kalkış altında 0-B'nin sızıntı yasası kullanılır.
- **Kavitasyon tek fazlı çözücüde yok**: 0-B model hem tüpte hem odada buhar basıncına iniyor (rapor bölüm 6.3).
  Aşama 1-2 tek fazlı koşulursa negatif mutlak basınçlar görülür; bu bölgeler raporlanır, sonuç olarak alınmaz.
- **Armatür hareketi düzensiz** (yüksek basınçta çevrimden çevrime değişiyor): CFD'ye 0-B'den tek bir çevrim izi
  verilirken çevrim seçimi yazılır.
- **Elastomerler**: VL03 kubbesi ve SL04 rijit; SL04 sürtünmesi ve kubbe sızdırmazlığı CFD dışı.

## 8. Dosyalar (onaydan sonra kurulacak)

`cfd\geometry\` (akışkan hacimleri STEP / STL), `cfd\cases\stage0a_ball\`, `stage0b_plug\`, `stage0c_armature\`,
`stage1_chamber\`, `cfd\tools\` (R385 araçlarının uyarlanmış kopyaları), `cfd\STAGE<n>_RESULTS.md`.
