# CR-C-01 - DR02 / DR03 yay dış çapı, iç çapı ve sarım sayısı (Rev A §9 düzeltmesi)

Tarih: 2026-10-16. Yazan: ULKA-C. Karar: ULKA-A.

## Ne ölçüldü
Aşama 1'de yay ekseni, yan yatmış yayın bütün noktalarına silindir uydurularak bulunmuştu. Masaya bakan alt yarı
taranmadığı için bu eksen ~0,29 mm kaçık çıktı: tel kesiti merkezlerinin eksene uzaklığı açıyla 5,45 ile 6,02
arasında salınıyordu (sd 0,21). Eksen bu kez **tel kesiti merkezlerine** (DR03 105, DR02 57 merkez) silindir
uydurularak yeniden bulundu: merkez çizgisi silindiri rms **0,036 / 0,049**, merkez yarıçapının sd'si 0,21 -> 0,04.
Hizalı kopyalar (`scan\EP5-DR02/DR03_aligned.stl`) ve `parts\DR0x\qa\align.json` güncellendi.

Ardından parçalı adımlı helis modeli (uç kapalı sarım + geçiş + aktif adım, taşlanmış uçlar) bütün tarama
yüzeyine en küçük kareler ile oturtuldu (`parts\C_common\spring_fit2.py`, 25 000 nokta, tel yüzeyine uzaklık):

| | DR02 ön | DR03 arka |
|---|---|---|
| Ortalama sarım Ø D | **11,75** (kesitlerden 11,74) | **11,54** (kesitlerden 11,51) |
| Tel Ø d | 1,19 (kesitlerden 1,22) -> 1,2 | 1,41 (kesitlerden 1,43) -> 1,4 |
| **Dış Ø = D + d** | **12,94** | **12,95** |
| **İç Ø = D - d** | **10,55** | **10,13** |
| Serbest boy L0 | 18,97 | 30,14 |
| **Toplam sarım n_t** | **6,06** | **8,15** |
| Aktif adım | 3,89 | 4,37 |
| Uç kapalı / geçiş (alt; üst) | 0,55 / 0,47 ; 0,65 / 0,14 tur | 0,62 / 0,46 ; 0,69 / 0,20 tur |
| Aktif sarım n_a (tam adım + yarım geçişler) | ≈ 4,55 | ≈ 6,5 |
| Modelin oturma kalitesi | \|r\| p50 0,055, ±0,15 içinde %84,7 | \|r\| p50 0,027, ±0,15 içinde %95,3 |

## Rev A ile çelişki
| Expression | Rev A | Önerilen | Fark |
|---|---|---|---|
| `dr02_od` | 12,65 | **12,94** | +0,29 (eski eksen kaçıklığı) |
| `dr03_od` | 12,63 | **12,95** | +0,32 |
| `dr02_nt` | 5,4 | **6,06** (≈6,0) | +0,66 (Aşama 1 helis izi uç uçlarını kaçırmıştı) |
| `dr03_nt` | 7,6 | **8,15** (≈8,1) | +0,55 |
| `dr02_k` | 2,9 | **≈2,4** (G 69 GPa, d 1,2, D 11,75, n_a 4,55) | türetildi, ±%20 |
| `dr03_k` | 4,4 | **≈3,8** (G 79 GPa, d 1,4, D 11,54, n_a 6,5) | türetildi, ±%20 |
| `dr02_d`, `dr03_d`, `dr02_l0`, `dr03_l0` | 1,2 / 1,4 / 18,93 / 30,16 | değişmez (L0 yeni hizalamada 18,97 / 30,14, fark gürültü içinde) | - |

Yan etkiler (A hesaplar): `dr_defl` değişmez; `dr03_l_inst` / `dr02_l_inst`, `z_dr01`, `stroke_mag`, `p_max_check`
k oranı ve toplamı değiştiği için kayar (k toplamı 7,3 -> 6,2: `p_max_check` ~16,9 -> ~14,3 bar).

## Yay tarafı kanıtı (C_MEASURED'daki 1. madde zayıfladı)
Yeni iç çaplarla pilot argümanı artık tek başına belirleyici değil: DR03 iç Ø10,13 ön pilota (10,02) da 0,11
boşlukla girebilir. Karar söküm videosuna dayanıyor (HS01 çekilince koyu uzun yay tüpten düşüyor, t ≈ 126-130 s)
ve kodlama belgesiyle aynı: DR03 arka, DR02 ön. DR03 arka pilotta (9,5) 0,63 çap boşluğu, DR02 ön pilotta (10,02)
0,53 çap boşluğu.

## Öneri
Rev B'de yukarıdaki dört değer (+ türetilen k'ler). C, yay CAD'ini bu değerlerle kuracak; modeller parça içi
expression ile (D, d, L0, n_t, uç parametreleri) yapılır, kontrol parçasından `dr0x_d`, `dr0x_od`, `dr0x_l0`,
`dr0x_nt` linklenir (`coil_d = dr0x_od - dr0x_d`). Rev B gelene kadar C yayları Rev A linkleriyle değil, bu CR'nin
değerleriyle denemede tutar; teslim Rev B'den sonra.
