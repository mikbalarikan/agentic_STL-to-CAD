# CR-B-02 - EM02 büküm radyüsü: dört bükümde tek iç R 1,9 (`em02_ri_out` 1,1 -> 1,9)

Yazan: ULKA-B, 2026-10-16. İlgili: `em02_ri_out` (Rev A 1,1), `em02_ri_in` (Rev A 1,9).

## Ne ölçtüm
Aşama 1'de çıkış köşelerinin dış R'sini 4,1 ölçüp (iç 1,1) giriş köşelerinden (iç 1,9) ayrı yazmıştım. EM02
modelini taramayla karşılaştırınca çıkış köşelerinde düzenli bir eksi sapma çıktı. Kesitlerde gördüğüm:

- Çıkış duvarı dış yüzü düz değil: ortada Z 0..+0,2, |X| 17'den sonra iniyor: |X| 20'de -0,13..-0,20,
  22'de -0,18..-0,28, 24'te -0,40..-0,50 (6 Y kesitinde aynı). Yani büküm bölgesi Rev A'daki R4,1'in
  başladığı |X| 22,9'dan çok önce başlıyor; ilk ölçümüm bu çöküntünün içindeydi.
- Çıkış köşesi dış yayına serbest çember uydurması: R 3,66 ama merkezi (23,14; -3,99), yani yay nominal yüzlere
  teğet değil (0,2 / 0,33 içeride). Giriş köşesi: dış yay R 4,39 (nominal yüzlere yakın teğet), iç köşe neredeyse
  keskin (R 0,2) - sabit kalınlıklı sacla birebir tutmuyor.

Bükümü teğet yay olarak modelleyip bütün parçayı rijit oturttuğumda (K2 yöntemiyle, `qa\dev*.json`):

| iç R giriş / çıkış | bükümler ±0,15 içinde | bütün parça ±0,15 içinde |
|---|---|---|
| 1,9 / 1,1 (Rev A) | %43,9 | %87,2 |
| 1,39 / 0,66 (serbest yay uydurması) | %33 | %85,9 |
| **1,9 / 1,9 (öneri)** | **%59,8** | **%89,6** |
| 1,9 / 1,7 · 2,3 / 1,7 · 2,3 / 2,0 | - | %89,7 · %89,8 · %89,4 |
| 2,1 / 2,1 · 1,9 / 2,2 · 1,5 / 2,0 | - | %89,1 · %88,9 · %88,7 |

## Öneri
Tek şerit, tek kalıpla bükülüyor: dört bükümde aynı iç R. `em02_ri_out` = 1,9 (= `em02_ri_in`). En iyi ayar
(2,3 / 1,7) ile fark %0,2; kapıya göre ayar yapmak yerine tasarım niyeti olan tek radyüsü öneriyorum. Kalan sapma
çıkış duvarının düz olmamasından (0,2-0,45 çöküntü); sac metalde modellenmiyor, raporda yazılı.

Etkisi: yalnız EM02'nin çıkış köşeleri (dış R 4,1 -> 4,9). EM01 gövdesinin köşeye yakınlığını A montajda
denetler (gövde Ø47,21, düz duvar iç yüzü ±23,98, bobin terminal ucu z = -3,0; köşe iç yayı merkezi |X| 22,08,
Z -4,9).

Model şu an Rev A değerleriyle kurulu; Rev B gelirse yalnız journal yeniden koşar (deneme: `ULKA_B_TRY_R`).
