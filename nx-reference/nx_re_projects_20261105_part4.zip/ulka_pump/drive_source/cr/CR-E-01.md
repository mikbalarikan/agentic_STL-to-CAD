# CR-E-01 - Türetilmiş VL02 + oda dibi emme valfini açtırmıyor; dinlenme dengesinde VL02 kuvveti yok

Yazan: ULKA-E, 2026-10-17. Rev H'ye karşı. Karar: ULKA-A. Kontrol parçasına dokunulmadı.
Ayrıntı ve sayılar: `theory\ULKA_THEORY_REPORT.md` bölüm 1.2, 4, 7, 8 (hesap `theory\calc\`).

## Ne buldum
1. **Emme valfi açılamıyor.** VL02 (tel `vl02_d` 0,5, serbest `vl02_l0` 15,0; D modeli: 2 konik + 7 aktif sarım)
   için k ≈ 0,49 N/mm. Oda dibi (`ch_bot` 24,0, D, CR-D-02) ile dinlenmede montaj boyu 10,0 mm -> ön yük ≈ 2,4 N.
   Bilyanın oturduğu Ø2,72 kenarda bu, valfin açılması için ≈ 4,2 bar fark demek; emme strokunda erişilebilen en
   büyük fark ≈ 1 bar (depo - buhar basıncı). Valf ancak piston dinlenmeden ≈ 5 mm geri gidince (yay boşa çıkınca)
   açılıyor. Dinamik modelde bu, 0 bar debisini 405 cm³/dk'ya düşürüyor (E5: 650).
2. **Dinlenme dengesinde VL02 yok.** `dr_defl`, `dr03_l_inst`, `z_dr01` yalnız DR02 + DR03 ile kurulmuş. VL02'nin
   2,4 N'u eklenince ön alın -0,55 yerine -1,16 (0,61 mm geride).

## Çelişki
Türetilmiş VL02 telinin / oda dibi derinliğinin pompanın çalışmasıyla tutarsız olması. Geometrik kontrol (girişim
yok, blok boyu) geçiyor; işlev kontrolü geçmiyor.

## Öneri
- Kontrol parçasında şimdi değişiklik **önermiyorum**: iki değer de A_OLCUM #4 (oda dibi) ve #5 (VL02) ile ölçülecek;
  teori modeli bunları en etkili kalemler olarak gösteriyor (sıralamada 1.). Orkestratörün Usta'ya götüreceği
  listede #4 ve #5'in önceliği yükseltilebilir.
- E5'e uydurulan ayar varyantı (ölçüm değil) VL02 telini ≈ 0,35 mm veriyor (k × 0,24; dinlenmede açılma farkı
  ≈ 1 bar). Ölçüm gelmezse ve A isterse, Rev I'da `vl02_d` 0,35 "türetildi (E teorisi, CR-E-01)" olarak alınabilir.
- Ölçüler gelince `z_dr01` formülüne VL02 kuvvetinin eklenmesi (ya da bilinçli olarak dışarıda bırakıldığının
  INTERFACES §4'e yazılması). Montaj görüntüsünü etkiler, girişim kontrolünü etkilemez.
