# CR-D-01 - HS02 çıkış odası (G1/8 diş) ve çıkış valfi yığını; Usta'nın yay teli ölçüsü

Yazar: ULKA-D, 2026-10-16. Rev A'ya karşı.

## 1. Usta'nın ölçümü (Usta'dan D'ye, aynen iletilir; C'nin parçaları)
"kısa yay 1 mm, uzun yay 1.3 mm tel çapı" -> **DR02 tel 1,0**, **DR03 tel 1,3**. Rev A: `dr02_d` 1,2, `dr03_d` 1,4.
`dr02_k`, `dr03_k` (tel^4 ile) ve `p_max_check` buna göre değişir. Öneri: Rev B'de 1,0 / 1,3.

## 2. HS02 çıkış odası = G1/8 iç diş (Usta: "hs02 içinde dişli kısım var, kumpasla da taramada da ölçülemiyor")
- D_MEASURED'daki "çıkış havşası Ø8,52" kısmi kapsamalı (150-170°) serbest daire uydurmasıydı; merkez 0,43 kaymış.
  Gövde dış çapının yerel eksenine göre radyal medyan: **Ø9,15** (z 30,5-39,5; sd 0,09), ağza doğru Ø9,7'ye çıkıyor.
  Bu G1/8 (BSPP 28 tpi) iç dişin dibi (8,566) ile tepesi (9,728) arasında: dişin bulanık taranmış hali. Rev A'daki
  `hs02_out_d` 8,52 (= diş dibi / matkap) **değişmeden kalabilir**; diş kozmetik.
- Aynı nedenle giriş havşası serbest uydurmada Ø8,59, yerel eksende Ø8,73 çıkıyor (sd 0,08); Rev A 8,63 ikisinin
  arasında, değişiklik önermiyorum (SL04 eşleşmesi tutuyor).

## 3. Çıkış valfi yığını (parçaların ilişkisinden türetildi; taramada yok)
Kısıtlar: diş derinliği ≥ 7 (datasheet "1/8 Gas min 7") -> diş z 33,72-41,22 (HS02 çerçevesi). Rakor ucu dişte durur,
valf dişin altında olmalı. VL05 (Ø8,4, 4,5 kalın) odanın tabanında (z 29,22-33,72). Kalan 7,4 mm'ye VL03 + VL04
sığmaz; demek ki tapa ve yay odanın altındaki Ø6,0 delikte (taramada z 29,2-30 arası görülen Ø6,0-6,1 delik) çalışır:

| HS02 çerçevesi z | Eleman |
|---|---|
| 2,15 -> **21,0** | basınç odası Ø6,0 (girişte Ø6,4 -> 6,0 koni, z 2,15-5,0) - VL01, VL02 |
| 21,0 -> 22,0 | oda dibi duvarı, ortasında **oturma deliği Ø4,0** (`hs02_seat_d`), oturma kenarı z 22,0 |
| 22,0 -> 29,22 | valf deliği **Ø6,0** - VL03 başı (Ø5,0, 0,5 radyal akış boşluğu) ve VL04 |
| 29,22 -> 33,72 | VL05 kafes, oda tabanına dayalı |
| 33,72 -> 41,22 | G1/8 iç diş (kozmetik, 7,5 boy) + ağız pahı |

Kontroller (modellenen yaylarla, 2026-10-16 güncellendi): VL03 kubbesi (R 2,76) Ø4,0 kenara oturur, tepe deliğe 0,86
dalar (tepe z 21,14). VL04 küçük ucu (iç Ø3,5) VL03 başının alt konisine tepeden 4,08'de dayanır -> VL04 montaj boyu
**4,0** (serbest 6,8, blok ≈2,9) -> valf kalkışı ≈1,1; Ø4 kenarda perde alanı ≈13,8 mm² ≥ delik 12,6 mm². VL03 sapı VL05
göbek deliğinden (Ø2,4) geçer. VL02: dinlenmede bilya tepesi z 11,45 (z_dr01_tip, DR01 Ø4,0 havşası, 90° varsayımı)
-> montaj boyu **9,55** (serbest 15,0, blok ≈6,25); manyetik strokta 14,03 (bilyayı hâlâ bastırır); yukarı yönde blok
boya 3,3 mm sonra oturur (`stroke_up` 5,81'e gidilmez kabulü; A'nın strok taramasında kontrol).
Not: ilk yazımda oda dibi 22,0 idi; VL04'ün modellenen blok boyu 2,9 ile valf kalkışı 0,35'e düşüyordu, 21,0'a alındı.

Öneri A'ya: §2'de VL05 yerleşimi "HS02 çıkış havşası ağzında" -> **"oda tabanında, z_hs02 + hs02_out_floor"**.
Yeni parça içi değerler (D'nin HS02 dosyasında adlı expression, türetildi): `ch_bot` 21,0, `wall_t` 1,0,
`vbore_d` 6,0, `thr_len` 7,5. Bunların A_OLCUM #4 kapsamında olduğu yazıldı; Usta ölçemiyor, bu yüzden
türetilmiş kalır.
