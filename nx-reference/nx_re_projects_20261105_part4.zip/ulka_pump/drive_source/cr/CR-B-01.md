# CR-B-01 - EM01 bobin boyu: uç yüzler iki kademeli, `em01_len` dış halkadan ölçülmeli

Yazan: ULKA-B, 2026-10-16. İlgili: `em01_len` (Rev A 43,45), `z_em01_far`.

## Ne ölçtüm
Modelleme sırasında bobinin iki uç yüzünü ayrı halkalarda düzlem uydurmasıyla ölçtüm (`EP5-EM01_aligned.stl`,
plaka bölgesi dışında, tam çevre):

| Uç | iç halka r 11,5-16,5 | dış halka r 18-22 | sd |
|---|---|---|---|
| terminal ucu (z_s=0 tarafı) | +0,21 (çökük) | -0,08 | 0,10 / 0,085 |
| düz uç | 42,87 (çökük) | 43,44 | 0,063 / 0,042 |

İki uçta da delik çevresindeki iç halka dış halkadan çökük: terminal ucunda 0,29, düz uçta 0,57. Aşama 1'deki
terminal ucu değeri (`em01_len` = 43,45 içindeki z=0) histogram tepesiydi ve plaka ile iç halkanın karışımıydı.

**Dış halkadan dış halkaya boy = 43,52** (43,44 + 0,08). Rev A 43,45 ile fark 0,07.

## Hangi değerle çelişiyor
`em01_len` = 43,45 (Rev A). Çerçeveye dayanan yüzler dış halkalardır (terminal ucu dış halkası çıkış duvarı iç
yüzüne, `z_em01_term`).

## Öneri
- `em01_len` = 43,52 -> `z_em01_far` = -46,52 (giriş duvarına boşluk 0,67 -> 0,60). Başka zincir değişmez.
- İç halka çöküntüleri parça içi (`rec_dt` 0,29, `rec_d` 0,6), kontrol parçasına gerekmez.
- Kabul edilmezse model 43,45 ile kalır; K1 bandında (EM01 uç yüzleri zayıf: sd 0,085 -> bant 0,17) içinde.

Model şu an Rev A değeriyle (43,45) kurulu; Rev B gelirse yalnız journal yeniden koşar.
