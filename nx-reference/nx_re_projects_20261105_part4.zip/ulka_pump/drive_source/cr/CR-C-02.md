# CR-C-02 - Yay dış çapı Usta'nın tel ölçüsüyle tutarlı olmalı; taramanın ince metalde şişmesi (d_p notu)

Tarih: 2026-10-16. Yazan: ULKA-C. Karar: ULKA-A. Rev B'ye (ctrl_params_revB.json) karşı.

## Ne var
Rev B tel çaplarını Usta'nın ölçüsüyle aldı (`dr02_d` 1,0, `dr03_d` 1,3 - CR-D-01) ama dış çapları CR-C-01'deki
taramadan gelen değerlerle bıraktı (`dr02_od` 12,94, `dr03_od` 12,95). O dış çaplar **taramadaki** tel çapıyla
(1,19 / 1,41) kurulmuştu: dış Ø = D_merkez + d_tarama. Rev B'de `coil_d = od - d` olunca sarım merkez çapı
taramanın ölçtüğünden büyük çıkıyor (DR02 11,94 / DR03 11,65; ölçülen 11,75 / 11,54).

Tel merkezi çizgisinin çapı (D_merkez) tel kesitlerinin **merkezlerinden** ölçüldü: yüzeydeki düzgün şişme
(sprey, tarayıcının ince özelliği yuvarlaması) merkezi kaydırmaz, yalnız tel çapını büyütür. Bu yüzden doğru
dış çap D_merkez + d_Usta'dır.

| | D_merkez (tarama, rms 0,04-0,05) | d (Usta) | **önerilen `od`** | Rev B `od` | iç Ø |
|---|---|---|---|---|---|
| DR02 | 11,75 | 1,0 | **12,75** | 12,94 | 10,75 |
| DR03 | 11,54 | 1,3 | **12,84** | 12,95 | 10,24 |

k formülü (Rev B: `(od-d)^3`) bu dış çaplarla ölçülen D'yi kullanır: DR02 k = 69000·1⁴/(8·11,75³·4,55) ≈ **1,17 N/mm**,
DR03 k = 79000·1,3⁴/(8·11,54³·6,5) ≈ **2,64 N/mm** (Rev B formülü 12,94/12,95 ile 1,11 / 2,57 verir).

## Taramanın şişmesi (bilgi; karar A'nın)
Usta'nın ölçüsü ile tarama farkı: DR02 tel 1,22 -> 1,0 (yan başına **+0,11**), DR03 1,43 -> 1,3 (yan başına +0,065).
Aynı tarama düzeneğiyle taranan, mat sprey sıkılmış metal yüzeylerin dış ölçüleri de şişmiş olabilir. En kritik
etkilenen değer **`dp`** (4,97): yan başına 0,03-0,10 şişme varsa gerçek d_p 4,77-4,91 olur; Q ∝ d_p² olduğu için
%2-8. Taramada bunu ayıracak iç referans yok (piston deliği Ø2,72 de aynı şekilde küçülmüş olur). Öneri: d_p için
Usta'dan tek kumpas / mikrometre ölçüsü (A_OLCUM_ONERISI'nde yoksa ekle); armatür Ø14,34 ikinci aday.

## Kapı notu (gevşetme önerisi değildir)
CAD teli Usta'nın çapında olunca tarama tel yüzeyi CAD'in yan başına ~0,11 (DR02) / ~0,065 (DR03) dışında kalır. K2
(T 0,15) DR02'de bu sistematik farkla sınırda olabilir; K1 "yaylar d, OD, L0" taramadan uydurulursa d ve OD
şişmiş çıkar. C raporunda bu farkı ölçüsüyle yazacak; ne yapılacağına A karar verir.

## Öneri
Rev C (ya da Rev B düzeltmesi): `dr02_od` 12,75, `dr03_od` 12,84. C yayları bu CR'ye bakmadan Rev B linkleriyle
kurabilir (od linkli; değer değişince model güncellenir).
