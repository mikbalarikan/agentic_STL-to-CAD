# CR-D-02 - Rev C kinematiğiyle HS02 iç yığını: oda uzar, VL05 yükselir, G1/8 dişi 4,8'e iner

Yazar: ULKA-D, 2026-10-16. Rev C'ye karşı (`z_dr01_tip` 24,859, `stroke_up` 2,58, `stroke_mag` 7,71).

## Ne değişti
CR-D-01'deki yığın Rev A dinlenme konumuyla (`z_dr01_tip` 21,63) kurulmuştu. Rev C'de piston ucu HS02 çerçevesinde
z 12,36'da (Rev A: 9,13). Bilya (Ø3,572, DR01 Ø4,0 havşasında, 90° varsayımı) tepesi uçtan +2,31 -> z 14,67.
Oda dibi 21,0 kalırsa VL02 dinlenmede 6,33 boyda olur, modellenen blok boyu ≈6,25 -> **neredeyse blokta**; yukarı
dayanmada (+2,58) çakışır.

## Kısıt zinciri (HS02 çerçevesi, flanş yüzünden z)
yukarı dayanmada bilya tepesi 14,67 + 2,58 = 17,25 -> + VL02 blok 6,25 + pay 0,5 -> oda dibi ≥ 24,0 -> duvar 0,8 ->
oturma kenarı (Ø4,0) 24,8 -> VL03 tepesi 23,94 (0,86 dalar), VL04 dayanması tepeden 4,08 -> 28,02 -> VL04 montaj
boyu 3,9 (blok 2,9 + 1,0 kalkış) -> VL05 alt yüzü 31,92 -> VL05 4,5 -> üst yüzü 36,42 -> **G1/8 dişi 36,42-41,22 = 4,8**.
Datasheet "1/8 Gas min 7" bununla tutmuyor; HS02 41,22 boyunda Rev C kinematiği, VL02 blok boyu ve VL04 kalkışıyla
7 mm diş sığmıyor. Rakor ucu VL05'e dayanır (VL05'i tutan rakor olabilir).

## Öneri (Rev D)
1. `z_vl05` = `z_hs02` + 31,92 (oda tabanı 29,22 değil; VL05 Ø8,52 deliğe tırnaklarıyla sıkı). Öneri: kontrol
   parçasında `hs02_vl05_z` = 31,92 adlı değer, `z_vl05` = `z_hs02+hs02_vl05_z`.
2. HS02 parça içi (türetildi): `ch_bot` 24,0, `wall_t` 0,8, `thr_len` 4,8 (kozmetik diş 36,42-41,22).
3. Kontroller (A'nın strok taramasında): VL02 montaj boyları dinlenmede 9,33, yukarı dayanmada 6,75 (> blok 6,25),
   manyetik strokta 17,04 (> serbest 15: bilya ucunda serbest kalır, emme stroğunda zaten açılır). VL04 3,9 -> kalkış
   ≈1,0, perde alanı π·4·1,0 = 12,6 mm² = delik alanı.
4. `z_dr01` yeniden değişirse oda dibi bu zincirle yeniden hesaplanır (D bildirir).
Not: VL05 parçası `z_vl05`'e bağlı (A'nın değeri); HS02 Rev C değeriyle (29,22) VL05 VL04 ile çakışır, Rev D'ye kadar
montajda bu beklenen bir çakışmadır.
