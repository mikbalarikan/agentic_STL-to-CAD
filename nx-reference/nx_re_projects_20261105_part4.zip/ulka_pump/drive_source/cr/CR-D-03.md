# CR-D-03 - SL01 ve SL03 kesit / ID değerleri (A_QA sonucuna göre)

Yazar: ULKA-D, 2026-10-16. Rev D'ye karşı. Parçaların journal'ı değişmez; değerler kontrol parçasından gelir.

## Bulgular
| | Rev D | A_QA (A'nın hizalaması) | D_MEASURED (D) |
|---|---|---|---|
| SL01 | ID 16,20, kesit 2,10 (OD 20,40) | OD +0,18 -> ≈20,58 (±0,10 bandı tutmadı), K2 %91,4 | ID 16,20-16,26, OD 20,60-20,67, torus kesiti 2,24, yükseklik 2,04 |
| SL03 | ID 13,00, kesit 0,91 (OD 14,82) | ID +0,17 -> ≈13,17, OD +0,51 -> ≈15,33, kesit ≈1,1; K2 %61,3 | ID 12,93-13,04, OD 15,71-15,85, yükseklik 0,91, genişlik 1,34 |

SL03'te 0,91 tepe yüksekliğiydi; ince halka altlıkta hafif yassılmış ya da tarama kesiti bulanık görmüş. Genişlik ve
A'nın ID / OD uydurması kesiti 1,1 civarında veriyor. SL01'de kesit 2,10 iki ölçünün ortasıydı; OD'yi tutturmak için
2,2 gerekiyor.

## Öneri (Rev E)
- `sl01_cs` 2,10 -> **2,20** (`sl01_id` 16,20 kalır, OD 20,60). Standart eşleme raporda: metrik 16,5 x 2,0 en yakın
  ölçü, tarama değeri modellenir.
- `sl03_id` 13,00 -> **13,15**, `sl03_cs` 0,91 -> **1,10** (OD 15,35). Standart eşleme önerisi 13 x 1,0 yerine
  "13,2 x 1,1 civarı, standart dışı (tarama değeri)".
- Etki: `sl_sq` formülünde `sl03_cs` var. SL01 + SL03 eksenel sıkışması 2,10+0,91 -> 2,20+1,10 olunca HS01 flanşı
  (`z_hs01_flange_bot`) ve onu izleyen zincir kayar. A'nın yığın hesabı bunu yeniden dağıtır. D'nin parçalarında yalnız
  SL01 / SL03 yeniden kurulur (journal'lar `sl0x_cs` / `sl0x_id`'ye bağlı, ~1 dk).
