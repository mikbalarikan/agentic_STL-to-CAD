# ULKA_INTERFACES - Ulka EP5 arayüz belgesi

**Rev H** - 2026-10-16 - yazar ULKA-A (tek yazar). Kontrol parçası `C:\NX_MCP_WORKSPACE\ulka\ctrl\EP5-AS00_CTRL.prt`
(`ctrl_params.json` -> `ctrl_build.py`; sonuç `ctrl_build.json`). Değerlerin dökümü bu belgenin sonunda (§9) ve
`ctrl_values_py.json`'da. Çelişki bulan oturum `cr\CR-<harf>-nn.md` yazar ve A'ya haber verir; kontrol parçasına
dokunmaz. Ölçüm gerekçeleri: `sessions\A_MEASURED.md`, `B_/C_/D_MEASURED.md`.

## 1. Eksen takımı (donduruldu)
- Z = EM02'nin iki büyük deliğinin ortak ekseni = kartuş ekseni, **+Z girişten (HS01 nipeli) çıkışa (HS02 ucu)**.
- Orijin = EM02 çıkış duvarı **dış yüzü** ∩ eksen (`z_em02_out` = 0).
- +Y = EM02 şerit genişliği yönü, **EM01 fast-on terminallerinin tarafı**. +X = Y × Z (EM02 düz duvar normali);
  FS01 vidaları (±`fs_pitch`/2, 0).
- Kontrol parçasında datum düzlemleri (adları expression adının büyük harfi: `Z_HS01_FLANGE` ...) ve `PUMP_AXIS`.

## 2. Parça yerleşimi (kim, hangi çerçevede)
Sabit parçalar montaj koordinatında **yerinde** modellenir; bileşenler montaja orijinde kısıtsız eklenir.
Hareketli parçalar kendi ekseninde modellenir, A konumlar.

| Parça | Sahip | Çerçeve | Yerleşim / açısal konum |
|---|---|---|---|
| EM02 | B | yerinde | düz duvarlar ±X, açık yanlar ±Y; birleşme yarığı çıkış duvarında X=0 |
| EM01 | B | yerinde | terminal ucu `z_em01_term` (Rev H: iki duvar arasında ortalı, -3,30), plaka ve fast-on'lar +Y, bıçaklar -Z yönünde (datasheet yan görünüş, türetildi) |
| EM03 | B | yerinde, EM03-A konumu (`z_em03a_bot`..) | ikinci kopya A'da +(em03_len+hs04_h) ötelenir; yarık +X'te |
| HS04 | B | yerinde | `z_hs04_bot`..`z_hs04_top` |
| HS01 | C | yerinde | flanş üst yüzü `z_hs01_flange` (C'nin z0'ı) |
| DR01 | C | kendi: z0 = armatür ön alnı, +z piston ucuna | A: `z_dr01` (dinlenme), strok taraması |
| DR02, DR03 | C | kendi: z0 = bir uç düzlemi, +z öbür uç | serbest boyda; uzunluk parça içinde adlı expression (`dr02_len` / `dr03_len`, varsayılan l0) olsun, A sıkışmış kopyayı `dr0x_l_inst` ile yapar |
| HS05 | D | yerinde | alt yüz `z_hs05` |
| HS02 | D | yerinde | flanş yüzü `z_hs02` (D'nin z0'ı); CH12 düzlüklerinin normali ±X |
| HS03 | D | yerinde | alt yüz `z_hs03`; kulaklar ±X, pimler (±pin_x, ±pin_y) |
| SL01..SL04 | D | yerinde, nötr (kalıp) halinde torus | SL01 alt yüzü `z_em03b_top`; SL02 alt yüzü `z_sl02`; SL03 alt yüzü `z_sl03`; SL04 HS02 havşasında (havşa tabanına dayalı) |
| VL01 | D | kendi: merkez orijinde | A: piston ucu havşasına oturur |
| VL02, VL03, VL04 | D | kendi: z0 = alt (giriş tarafı) uç, +z çıkışa | serbest boyda; uzunluk adlı expression; A konumlar |
| VL05 | D | yerinde | HS02 çıkış havşasında tırnaklarıyla sıkı, alt yüzü `z_vl05` = `z_hs02`+`hs02_vl05_z` (31,92; Rev D, CR-D-02); üstünde G1/8 iç diş 4,8 boy (kozmetik; datasheet min 7 tutmuyor, türetme) |
| FS01 | A | yerinde (+X vidası) | ikinci kopya A'da X'te -fs_pitch |

## 3. Eksenel yığın (özet; değerler §9)
Giriş duvarı iç yüzü -> EM03-A (18,9) -> HS04 (9,1) -> EM03-B (18,9, çıkış duvarı deliğinden geçer, dış yüzün 0,22
altında) -> SL01 -> HS01 flanşı -> soket ağzı -> HS05 -> HS02 flanşı -> SL03 -> HS03 üst kademesi. Bu zincir
kapalıdır; SL01 ve SL03 birlikte `sl_sq` (%22,7, Rev F) sıkışır. SL02 HS01 flanşı üstünde, HS03 alt deliğinde, dudakta
radyal conta (`sq_sl02` %2,5 - zayıf, türetildi). Armatürün dinlenme konumu yay dengesinden (`dr_defl`, `dr02_k`,
`dr03_k`); manyetik strok `stroke_mag` 4,48 (armatür girişe çekilir), yukarı sert dayanma `stroke_up` 5,81.
Toplam boy `total_len` 121,62 (datasheet 122). Rev C: manyetik strok 7,71, yukarı dayanma 2,58.

## 4. Türetilen (taramada yok) değerler - kaynağıyla
| Değer | Rev A | Kaynak / gerekçe | Ölçüm önerisi |
|---|---|---|---|
| `hs01_inner_bot` | 52,0 (Rev A 55,3) | HS01 dış geçişinin (z -54..-56,8) üstünde ~2 cidar, C'nin tahmini 53; Usta'nın tel ölçüleri + CR-C-01 sarımlarıyla 15 bar kontrolü (`p_max_check` 15,9) | A_OLCUM #2 |
| `hs01_bore_d` tüp boyunca | 14,92 | ağızdan 10 mm görülen, tüp boyunca sabit kabul (C) | - |
| SL01 yeri (flanş altı) | - | kapalı zincirin tek tutarlı yeri; flanş üstünde olsa 10 bar çıkar | - |
| `z_em01_term` (terminal ucu çıkışta) | -3,0 | datasheet yan görünüşte terminal kutusu çerçevenin üst (çıkış) yarısında | - |
| `dr02_k`, `dr03_k` | 1,17 / 2,82 (formül) | Usta'nın tel ölçüsü 1,0 / 1,3 (CR-D-01) + tarama sarım merkez çapı 11,75/11,54 (CR-C-02) ve n_a 4,55/6,5; G 69 / 79 GPa. **Çelişki:** tarama teli 1,19 / 1,41 (C, iki yöntem); k tel^4 ile ~2 kat değişir | A_OLCUM #3 (k ölçümü çelişkiyi çözer) |
| `hs02_seat_d` | 4,0 | VL03 kubbe R2,76 (D) | A_OLCUM #4 |
| HS02 basınç odası | Ø6,2, dibi D'de | D türetir; VL02 montaj boyu 12-13 olacak şekilde | A_OLCUM #4 |
| VL02 / VL04 tel, sarım | 0,5 / 0,45 | tarama zayıf (D) | A_OLCUM #5 |
| `em03_slit_w` | 0,5 | F04 (B) | - |
| `fs01_len` | 8 | M4x10 makara alnına girerdi | - |
| G1/8 iç diş | kozmetik | datasheet "1/8 Gas min 7"; HS02 çıkış havşası Ø8,52 = delik çapı | - |
| `z_dr01` ve stroklar | -3,70 | yay dengesi | E doğrular |

## 5. Yuvarlama ve standart eşlemeler
- Değerler taramaya sadık tutuldu (0,01 mm). Tasarım niyetine yuvarlama yalnız fark uydurma kesinliğinin içindeyse:
  yay telleri 1,23 -> 1,2 ve 1,43 -> 1,4 (sd 0,12 / 0,06), VL01 3,606 -> 3,572 (9/64", 1 sd), SL02 ISO 3601 15,47 x 2,62,
  SL04 4,5 x 2,0. **d_p 4,97 kaldı** (5,00'a 0,03-0,04: piston yüzeyinde sd 0,014-0,028, ortalama çok daha kesin;
  yuvarlama gürültü dışı). SL01 / SL03 standart eşlemesini D raporda yazar (değerler şimdilik tarama).
- FS01: ISO 7045 M4 x 8 H (yıldız, silindir/pan baş), EM02'de M4 diş (kozmetik, delik taramadaki Ø3,5).

## 6. Kabul kapıları (modellemeden ÖNCE sabitlendi; sonuç görüldükten sonra gevşetilmez)
A her parçayı kendi hizalamasıyla ölçer (`an\qa_dev.py`, çizenin sayılarına bakmadan); sonuç `sessions\A_QA.md`.

**K1 - İşlevsel yüzeyler** (aşağıdaki liste): aynı primitif (silindir / düzlem / küre / torus) taramaya ve CAD'e
A tarafından uydurulur; |ΔØ| ≤ **0,05**, parça içi düzlem konumu |Δz| ≤ **0,05**. Tarama özelliği zayıfsa
(kapsama < 180° ya da uydurma sd > 0,06): bant = max(0,05; 2·sd_uydurma), raporda "zayıf" yazılır.
İşlevsel liste: EM02 delikleri (büyük 2, pim 4, vida 2), iç eksenel açıklık, t; EM01 delik, gövde Ø, boy; EM03 OD/ID/boy;
HS04 OD/ID/boy; HS01 tüp dışı, soket deliği, dudak dışı, flanş Ø ve üst yüz, nipel; DR01 armatür Ø, alınlar, piston
d_p, pilotlar, uç havşası; yaylar d, OD, L0; HS02 flanş Ø/kalınlık, SL04 havşası, gövde Ø (HS03 boğazında), çıkış
havşası, boy; HS03 alt yüz, üç delik ve iki kademe, pimler, kulak delikleri; HS05 OD/delik/kalınlık; elastomerler
ID/kesit (bant ±0,10: yalnız üst yarı taranmış); VL01 Ø; VL03 baş.

**K2 - Genel yüzey**: A'nın rijit en iyi oturtmasından (nokta-düzlem ICP, %2 kırpma) sonra tarama örneklerinin
±T içinde kalan payı **≥ %90**; T = max(0,15; 2,5·sd_parça). sd_parça A'nın gürültü tablosundan
(`A_MEASURED` §5): HS02 0,073 -> T = 0,18; diğer bütün parçalar T = 0,15. Ayrıca "yerinde" (oturtmasız) pay ve
oturtma hareketi raporlanır; hareket > 0,3 mm ya da > 1° ise not düşülür. Taramanın göstermediği bölgeler
(masa izleri, tüp içi, HS02 orta iç) yalnız parça raporunda **QA'dan önce** listelenmişse dışarıda tutulur.

**K3 - Montaj**: sert girişim yok. Beklenen temaslar / girişimler: O-ring sıkışmaları (SL01-SL04, nötr torus ile),
VL05'in HS02 havşasına geçmesi, yay uç temasları, FS01 dişinin EM02 deliğinde (Ø3,5 / M4), HS01 flanşı - SL01 - EM03.
Strok taraması: DR01 `z_dr01` - (`stroke_mag` + 0,5) .. `z_dr01` + `stroke_up`, 0,25 adım; DR01 ile sabit parçalar
arası çarpışma yok (yaylar uç konumlarda ayrıca: blok boyu kontrolü).

Tutmayan kapı raporda "tutmadı" diye, ölçüsüyle yazılır.

## 7. Açık konular (Rev A'da)
1. SL01 / SL02 etiketi D'nin kesit ölçüsüne göre (BOM metniyle ters olabilir; yalnız ad).
2. EM01 makara alnında FS01 ucu için boşluk (M4x8 ile 0,8 mm kısa kalır, girişim yok).
3. EM02 büküm iç R: Rev G'den beri dört bükümde 1,9 (CR-B-02). Çıkış duvarı dış yüzünün 0,2-0,45 çöküntüsü modellenmez.
4. HS02 orta iç profili D türetir; A_OLCUM #4 gelirse Rev B.
5. **CR-E-01 (2026-10-17, A kararı: Rev H'de değişiklik yok).** Türetilmiş VL02 (tel 0,5) ve oda dibi (24,0) ile emme valfi
   ön yükü ~2,4 N, açılma farkı ~4,2 bar: E'nin modelinde valf ancak piston ~5 mm geri gidince açılıyor (0 bar debisi 405,
   E5 650). Geometrik kontroller (girişim, blok boyu) geçiyor, işlev kontrolü geçmiyor. Dinlenme dengesi (`dr_defl`, `z_dr01`)
   **bilerek yalnız DR02 + DR03 ile**; VL02'nin 2,4 N'u eklenirse ön alın -0,55 yerine ~-1,16 olur. Çözüm A_OLCUM #4 ve #5
   (öncelik yükseltildi); ölçüm gelmezse `vl02_d` 0,35 "türetildi (E teorisi)" ve `z_dr01`'e VL02 kuvveti Rev I'da alınabilir.
6. **Çalışma alanı taşındı (2026-10-17):** `C:\NX_MCP_WORKSPACE\ulka\` şu an `D:\C_Yedek_2026-10-15\02_Tam_Yedek\C_NX_MCP Workspace\ulka\`
   altında. `cad\` parçalarındaki interpart linkler kontrol parçasını eski yolda arar; NX'te açmak / yeniden kurmak için
   klasör C:'ye geri gelmeli ya da linkler yeni yola çevrilmeli (Usta kararı).

## 8. Revizyon geçmişi
- Rev H (2026-10-16): A'nın montaj kontrolü. EM01 flanş kenarları EM02'nin iç büküm radyüslerine (R1,9) giriyordu (2,4 + 1,9 mm³, X ±22-23,5, Z -3,0..-3,6). `z_em01_term` = çıkış duvarı iç yüzü - (44,12-43,52)/2 = -3,30 (bobin ortalı; türetildi). B'den: flanş uç kenar yuvarlatması taramadaki gibi (uç yüzde r 22,2-22,9, 1 mm içeride 23,8). Etkilenen yalnız B (EM01).
- Rev G (2026-10-16): CR-B-02 kabul. `em02_ri_out` 1,1 -> 1,9 (tek şerit, tek kalıp: dört bükümde aynı iç R; tasarım niyeti, kapıya ayar değil). Etkilenen yalnız B (EM02).
- Rev F (2026-10-16): CR-D-03 kabul. `sl01_cs` 2,10 -> 2,20; `sl03_id` 13,00 -> 13,15, `sl03_cs` 0,91 -> 1,10. Kapalı zincirde `sl_sq` %15,3 -> %22,7; HS01 flanşı ve ona bağlı kartuş zinciri (HS01, HS05, HS02, SL02, SL03, SL04, VL05, DR01 dinlenme) -0,079 kayar: `z_hs01_flange` 4,710, `z_hs02` 12,420, `z_dr01` -0,550; `stroke_mag` 7,63, `p_max_check` 15,7. Etkilenen: C (HS01 yeniden koşu), D (SL01, SL03 ve yerinde kartuş parçaları yeniden koşu).
- Rev E (2026-10-16): CR-B-01 kabul. `em01_len` 43,45 -> 43,52 (uç yüzlerin çerçeveye dayanan dış halkaları); `z_em01_far` -46,52, giriş duvarına boşluk 0,60. Etkilenen yalnız B (EM01).
- Rev D (2026-10-16): CR-D-02 kabul. `hs02_vl05_z` 31,92 yeni, `z_vl05` buna bağlı (HS02 iç yığını Rev C dinlenme konumuyla: oda dibi 24,0, duvar 0,8, VL04 montaj 3,9). G1/8 diş boyu 4,8 < datasheet min 7: türetmenin bilinen çelişkisi (A_OLCUM #4 ölçülürse çözülür). Etkilenen yalnız D.
- Rev C (2026-10-16): CR-C-02 kabul. `dr02_od` 12,94 -> 12,75, `dr03_od` 12,95 -> 12,84 (tel merkez çapı taramadan + Usta teli). k 1,17 / 2,82; `z_dr01` -0,47, `stroke_mag` 7,71, `stroke_up` 2,58, `p_max_check` 15,9. Taramanın ince metalde yan başına 0,07-0,11 şişmesi notu: d_p için A_OLCUM #1 zaten var. Etkilenen yalnız C (yaylar).
- Rev B (2026-10-16): CR-D-01 ve CR-C-01 kabul. CR-C-01: `dr02_od` 12,94, `dr03_od` 12,95, `dr02_nt` 6,06, `dr03_nt` 8,15, `dr02_na` 4,55, `dr03_na` 6,5. CR-D-01: Usta'nın tel ölçüsü `dr02_d` 1,0 / `dr03_d` 1,3 (Rev A 1,2 / 1,4; tarama 1,23 / 1,43 - sprey ve kesit bulanıklığı); `dr02_k`, `dr03_k` artık formül (`dr02_na`, `dr03_na` yeni); `hs01_inner_bot` 55,3 -> 52,0 (15 bar kontrolü); `z_vl05` yeni (VL05 oda tabanında). Değişen konumlar: `z_dr01` -3,70 -> -0,42, `stroke_mag` 4,48 -> 7,76, `stroke_up` 5,81 -> 2,53. Etkilenen: C (DR02, DR03; HS01 iç dip), D (VL05 yeri). B etkilenmez.
- Rev A (2026-10-16): ilk yayın. B/C/D Aşama 1 ölçümleri + A'nın eksenel yığını.

## 9. Kontrol parçası expression'ları (Rev H, değerlendirilmiş)
| Expression | Değer | Formül | Açıklama / kaynak |
|---|---|---|---|
| `z_em02_out` | 0.000 |  | pump origin: EM02 outlet-wall outer face (HS03 seat); Z = EM02 big-hole axis, +Z inlet->outlet |
| `em02_t` | 3.000 |  | EM02 sheet thickness [B 2.93/3.02 two-face] |
| `em02_in_axial` | 44.120 |  | EM02 inner faces of the holed walls [B] |
| `z_em02_out_in` | -3.000 | `z_em02_out-em02_t` | EM02 outlet wall inner face |
| `z_em02_in_in` | -47.120 | `z_em02_out_in-em02_in_axial` | EM02 inlet wall inner face |
| `z_em02_in_out` | -50.120 | `z_em02_in_in-em02_t` | EM02 inlet wall outer face (outer axial 50.12, datasheet 50) |
| `em02_out_x` | 53.960 |  | EM02 outer size along X (flat walls) [B; datasheet 54.3 incl. label] |
| `em02_w` | 32.060 |  | EM02 strip width along Y [B] |
| `em02_ri_out` | 1.900 |  | EM02 inner bend radius, outlet-wall corners = inlet corners: one strip, one tool [CR-B-02; Rev A-F 1.1] |
| `em02_ri_in` | 1.900 |  | EM02 inner bend radius, inlet-wall corners [B 1.8-1.9, sd 0.26] |
| `em02_hole_out_d` | 21.240 |  | EM02 outlet-wall hole [B, sd 0.036] |
| `em02_hole_in_d` | 16.740 |  | EM02 inlet-wall hole [B, sd 0.031] |
| `fs_pitch` | 37.900 |  | FS01 / HS03 ear-hole pitch along X [B 37.82, D 37.95, A 37.86] |
| `em02_fs_hole_d` | 3.500 |  | EM02 FS01 hole as scanned; thread M4 cosmetic (minor 3.24-3.42) [B 3.49/3.54] |
| `pin_x` | 14.000 |  | HS03 pin / EM02 pin-hole centre /X/ [B 13.91..14.10, D 13.93] |
| `pin_y` | 5.000 |  | HS03 pin / EM02 pin-hole centre /Y/ [B, D 5.00] |
| `em02_pin_hole_d` | 3.720 |  | EM02 pin holes (4) [B] |
| `em03_od` | 21.000 |  | EM03 OD [B 21.00/20.97] |
| `em03_id` | 16.710 |  | EM03 ID [B 16.71/16.72] |
| `em03_len` | 18.900 |  | EM03 length, both sleeves [B 18.92 full, other >=18.7] |
| `em03_slit_w` | 0.500 |  | EM03 slit width (derived, F04) [B] |
| `hs04_od` | 20.780 |  | HS04 OD [B] |
| `hs04_id` | 17.110 |  | HS04 ID [B] |
| `hs04_h` | 9.100 |  | HS04 height [B] |
| `z_em03a_bot` | -47.120 | `z_em02_in_in` | EM03-A (inlet sleeve) seats on the EM02 inlet wall inner face (hole 16.74 < OD 21.0) |
| `z_hs04_bot` | -28.220 | `z_em03a_bot+em03_len` | HS04 bottom = EM03-A top |
| `z_hs04_top` | -19.120 | `z_hs04_bot+hs04_h` | HS04 top = EM03-B bottom |
| `z_em03b_top` | -0.220 | `z_hs04_top+em03_len` | EM03-B top; passes the 21.24 outlet hole, ends 0.22 below the outer face |
| `em01_body_d` | 47.210 |  | EM01 bobbin body OD [B rms 0.025] |
| `em01_len` | 43.520 |  | EM01 bobbin end faces, outer rings (frame-bearing) [CR-B-01; Rev A-D 43.45] |
| `em01_bore_min_d` | 21.450 |  | EM01 bore, narrowest (middle) [B] |
| `em01_bore_end_d` | 21.900 |  | EM01 bore at the ends (core-pin draft) [B 21.78-21.96] |
| `z_em01_term` | -3.300 | `z_em02_out_in-(em02_in_axial-em01_len)/2` | EM01 terminal-end face, coil centred between the holed walls: the bend radii (1.9) carry the flange edges (DERIVED, A montage check Rev H; terminals at the outlet end from the datasheet side view) |
| `z_em01_far` | -46.820 | `z_em01_term-em01_len` | EM01 plain-end face (0.67 to the inlet wall) |
| `hs01_tube_od` | 16.090 |  | HS01 tube OD [C 16.093 rms 0.039; A 16.07] |
| `hs01_bore_d` | 14.920 |  | HS01 tube / socket bore [C, seen 10 mm from the mouth; along the tube derived] |
| `hs01_flange_d` | 20.230 |  | HS01 flange OD [C] |
| `hs01_flange_t` | 3.230 |  | HS01 flange thickness [C, lower face weak +-0.2] |
| `hs01_lip_od` | 15.820 |  | HS01 socket lip OD [C] |
| `hs01_lip_h` | 5.310 |  | HS01 flange top face -> socket mouth [C] |
| `hs01_neck_d` | 12.920 |  | HS01 neck OD [C] |
| `hs01_len` | 78.000 |  | HS01 socket mouth -> nipple tip [C +-0.2] |
| `hs01_nip_d` | 6.900 |  | HS01 nipple barb crest [C 6.9; datasheet 7.2] |
| `hs01_inner_bot` | 52.000 |  | HS01 flange top face -> tube inner bottom (DR03 seat), DERIVED: inside the outer step z -54..-56.8 (C est. 53); 15-bar check with the Usta wire sizes and CR-C-01 coils (Rev B, was 55.3) |
| `sl01_id` | 16.200 |  | SL01 ID [D 16.20-16.26]; standard mapping by D |
| `sl01_cs` | 2.200 |  | SL01 cross-section [CR-D-03, OD 20.60; Rev A-E 2.1] |
| `sl02_id` | 15.470 |  | SL02 ID, ISO 3601 15.47x2.62 (AS568-115) [D] |
| `sl02_cs` | 2.620 |  | SL02 cross-section [D] |
| `sl03_id` | 13.150 |  | SL03 ID [CR-D-03, A_QA fit; Rev A-E 13.0] |
| `sl03_cs` | 1.100 |  | SL03 cross-section [CR-D-03; Rev A-E 0.91 = flattened height] |
| `sl04_id` | 4.500 |  | SL04 ID, 4.5x2.0 [D] |
| `sl04_cs` | 2.000 |  | SL04 cross-section [D] |
| `hs05_t` | 2.400 |  | HS05 thickness [D 2.35-2.45] |
| `hs05_od` | 15.700 |  | HS05 OD [D] |
| `hs05_hole_d` | 5.650 |  | HS05 hole [D 5.60-5.72] |
| `hs02_len` | 41.220 |  | HS02 length [D; A 41.23] |
| `hs02_flange_d` | 15.770 |  | HS02 flange OD [D] |
| `hs02_flange_t` | 2.880 |  | HS02 flange thickness [D; A 2.81] |
| `hs02_body_d` | 13.400 |  | HS02 body OD at the HS03 throat [D 13.40-13.47; A 13.37] |
| `hs02_sl04_d` | 8.630 |  | HS02 inlet recess (SL04 seat) diameter [D] |
| `hs02_sl04_depth` | 2.150 |  | HS02 inlet recess depth [D; A 2.18] |
| `hs02_out_d` | 8.520 |  | HS02 outlet counterbore (valve room; G1/8 tapping size) [D] |
| `hs02_out_floor` | 29.220 |  | HS02 outlet counterbore floor from the HS02 inlet face [D] |
| `hs02_seat_d` | 4.000 |  | HS02 outlet valve seat edge, DERIVED (VL03 dome R2.76) [D] |
| `hs02_ch_s` | 11.800 |  | HS02 wrench flats across (two flats 180 deg apart; datasheet CH12) [A 11.8, D 2x5.8] |
| `hs02_ch_z0` | 22.180 |  | HS02 flats start from the HS02 inlet face [D] |
| `hs02_ch_z1` | 28.550 |  | HS02 flats end [D] |
| `hs03_plate_t` | 5.820 |  | HS03 plate thickness [D; A 5.80] |
| `hs03_bore1_d` | 20.930 |  | HS03 lower bore (SL02, HS01 flange) [D] |
| `hs03_step1` | 8.160 |  | HS03 lower step from the plate underside [D; A 8.166] |
| `hs03_bore2_d` | 16.500 |  | HS03 middle bore (HS01 lip, HS05, HS02 flange) [D 16.42-16.63; A 16.53] |
| `hs03_step2` | 16.150 |  | HS03 upper step (SL03 face seal) from the underside [D 16.1-16.2; A 16.06] |
| `hs03_bore3_d` | 14.260 |  | HS03 upper throat [D; A 14.29] |
| `hs03_len` | 19.900 |  | HS03 underside -> top face [D; A 19.91] |
| `hs03_ear_hole_d` | 4.550 |  | HS03 ear holes (M4 clearance) [D 4.50/4.57] |
| `hs03_pin_d` | 3.150 |  | HS03 locating pins (4) [D; A 3.12-3.15] |
| `hs03_pin_len` | 3.020 |  | HS03 pin length below the underside [D] |
| `z_hs03` | 0.000 | `z_em02_out` | HS03 underside on the EM02 outlet wall |
| `sl_sq` | 0.227 | `(sl01_cs+sl03_cs-(z_hs03+hs03_step2-z_em03b_top-hs01_flange_t-hs01_lip_h-hs05_t-hs02_flange_t))/(sl01_cs+sl03_cs)` | axial squeeze of SL01 (under the HS01 flange) and SL03 (on the HS02 flange), DERIVED from the closed chain |
| `z_hs01_flange_bot` | 1.480 | `z_em03b_top+sl01_cs*(1-sl_sq)` | HS01 flange lower face (SL01 between it and EM03-B) |
| `z_hs01_flange` | 4.710 | `z_hs01_flange_bot+hs01_flange_t` | HS01 flange top face = C part z0 |
| `z_hs01_mouth` | 10.020 | `z_hs01_flange+hs01_lip_h` | HS01 socket mouth |
| `z_hs01_tip` | -67.980 | `z_hs01_mouth-hs01_len` | HS01 nipple tip |
| `z_hs01_bot` | -47.290 | `z_hs01_flange-hs01_inner_bot` | HS01 tube inner bottom = DR03 seat (derived) |
| `z_hs05` | 10.020 | `z_hs01_mouth` | HS05 lower face on the HS01 socket mouth |
| `z_hs02` | 12.420 | `z_hs05+hs05_t` | HS02 inlet (flange) face = D part z0 |
| `z_hs02_tip` | 53.640 | `z_hs02+hs02_len` | HS02 outlet tip |
| `z_sl03` | 15.300 | `z_hs02+hs02_flange_t` | SL03 lower face (on the HS02 flange) |
| `z_sl02` | 4.710 | `z_hs01_flange` | SL02 lower face (on the HS01 flange, in HS03 bore1; radial seal on the HS01 lip) |
| `total_len` | 121.620 | `z_hs02_tip-z_hs01_tip` | pump length nipple tip -> HS02 tip (datasheet 122) |
| `dr01_arm_d` | 14.340 |  | DR01 armature OD [C 14.341 rms 0.012; A 14.34] |
| `dr01_arm_len` | 20.040 |  | DR01 armature front face -> rear face [C; A 20.03] |
| `dp` | 4.970 |  | DR01 piston OD d_p [C 4.966/4.978, A 4.964]; kept to the scan (5.00 is 0.03-0.04 off) |
| `dr01_tip` | 25.330 |  | DR01 front face -> piston tip [C] |
| `dr01_collar_d` | 8.500 |  | DR01 collar OD [C] |
| `dr01_collar_front` | 7.990 |  | DR01 front face -> collar front face [C] |
| `dr01_fpilot_d` | 10.020 |  | DR01 front pilot (DR02 centring) [C] |
| `dr01_rpilot_d` | 9.500 |  | DR01 rear pilot (DR03 centring) [C +-0.15] |
| `dr01_rear_len` | 0.980 |  | DR01 rear face -> rear pilot end [C 21.02-20.04] |
| `dr01_bore_d` | 6.090 |  | DR01 rear axial bore [C] |
| `dr01_pin_id` | 2.720 |  | DR01 piston bore [C] |
| `dr01_seat_d` | 4.000 |  | DR01 tip countersink mouth (VL01 seat) [C] |
| `dr02_d` | 1.000 |  | DR02 wire: Usta measured 1.0 (CR-D-01) [scan C 1.23] |
| `dr02_od` | 12.750 |  | DR02 OD = coil centre dia 11.75 (scan, wire centres) + Usta wire 1.0 [CR-C-02; Rev B 12.94, Rev A 12.65] |
| `dr02_l0` | 18.930 |  | DR02 free length [C] |
| `dr02_nt` | 6.060 |  | DR02 total coils [CR-C-01 helix fit; Rev A 5.4] |
| `dr02_na` | 4.550 |  | DR02 active coils [CR-C-01] |
| `dr02_k` | 1.169 | `69000*dr02_d^4/(8*(dr02_od-dr02_d)^3*dr02_na)` | DR02 rate N/mm, DERIVED G 69 GPa stainless (+-15%) |
| `dr03_d` | 1.300 |  | DR03 wire: Usta measured 1.3 (CR-D-01) [scan C 1.43] |
| `dr03_od` | 12.840 |  | DR03 OD = coil centre dia 11.54 + Usta wire 1.3 [CR-C-02; Rev B 12.95, Rev A 12.63] |
| `dr03_l0` | 30.160 |  | DR03 free length [C] |
| `dr03_nt` | 8.150 |  | DR03 total coils [CR-C-01; Rev A 7.6] |
| `dr03_na` | 6.500 |  | DR03 active coils [CR-C-01] |
| `dr03_k` | 2.823 | `79000*dr03_d^4/(8*(dr03_od-dr03_d)^3*dr03_na)` | DR03 rate N/mm, DERIVED G 79 GPa steel (+-15%) |
| `dr_defl` | 11.820 | `dr02_l0+dr03_l0-(z_hs05-z_hs01_bot-dr01_arm_len)` | total spring deflection at rest (both springs preloaded) |
| `dr03_l_inst` | 26.700 | `dr03_l0-dr_defl*dr02_k/(dr02_k+dr03_k)` | DR03 installed length at rest (force balance) |
| `dr02_l_inst` | 10.570 | `dr02_l0-dr_defl*dr03_k/(dr02_k+dr03_k)` | DR02 installed length at rest |
| `z_dr01_rear` | -20.590 | `z_hs01_bot+dr03_l_inst` | DR01 rear face at rest (power off) |
| `z_dr01` | -0.550 | `z_dr01_rear+dr01_arm_len` | DR01 front face at rest = C part z0 |
| `z_dr01_tip` | 24.780 | `z_dr01+dr01_tip` | piston tip at rest |
| `stroke_mag` | 7.630 | `z_dr01_rear-z_hs04_bot` | magnetic stroke to the EM03-A pole (armature pulled toward the inlet), DERIVED |
| `stroke_up` | 2.580 | `z_hs05-(z_dr01+dr01_collar_front)` | upward hard stop: collar front face -> HS05 lower face |
| `p_max_check` | 15.700 | `(dr02_k+dr03_k)*stroke_mag/(pi()*dp*dp/4)*10` | spring-delivered pressure at full magnetic stroke, bar (datasheet Q=0 at 15 bar) |
| `vl01_d` | 3.572 |  | VL01 ball 9/64 in [D 3.606 sd 0.031] |
| `vl02_l0` | 15.000 |  | VL02 free length [D] |
| `vl02_d` | 0.500 |  | VL02 wire [D, weak] |
| `vl03_head_d` | 5.000 |  | VL03 head max diameter [D] |
| `vl03_head_r` | 2.760 |  | VL03 dome radius [D] |
| `vl04_l0` | 6.800 |  | VL04 free length [D] |
| `vl04_d` | 0.450 |  | VL04 wire [D, weak] |
| `vl05_od` | 8.400 |  | VL05 ring OD [D 8.0-8.4] |
| `vl05_t` | 4.500 |  | VL05 thickness [D 4.3-4.7] |
| `hs02_vl05_z` | 31.920 |  | VL05 lower face from the HS02 inlet face, DERIVED by D from the Rev C kinematics (VL02 solid + VL04 lift chain), press-fit tabs [CR-D-02] |
| `z_vl05` | 44.340 | `z_hs02+hs02_vl05_z` | VL05 lower face (Rev D; Rev B/C on the counterbore floor 29.22) |
| `fs01_d` | 4.000 |  | FS01 ISO 7045 M4 pan head cross recess |
| `fs01_len` | 8.000 |  | FS01 length M4x8 (M4x10 would enter the EM01 flange zone by 1.2), DERIVED |
| `fs01_dk` | 8.000 |  | ISO 7045 M4 head diameter |
| `fs01_k` | 3.100 |  | ISO 7045 M4 head height |
| `z_fs01_head` | 5.820 | `z_hs03+hs03_plate_t` | FS01 head bearing face = HS03 ear top |
| `c_arm_tube` | 0.290 | `(hs01_bore_d-dr01_arm_d)/2` | radial: armature / HS01 bore |
| `c_tube_em03` | 0.310 | `(em03_id-hs01_tube_od)/2` | radial: HS01 tube / EM03 bore |
| `c_tube_hs04` | 0.510 | `(hs04_id-hs01_tube_od)/2` | radial: HS01 tube / HS04 |
| `c_tube_em02` | 0.325 | `(em02_hole_in_d-hs01_tube_od)/2` | radial: HS01 tube / EM02 inlet hole |
| `c_em03_em02` | 0.120 | `(em02_hole_out_d-em03_od)/2` | radial: EM03-B / EM02 outlet hole |
| `c_em03_em01` | 0.225 | `(em01_bore_min_d-em03_od)/2` | radial: EM03 / EM01 bore (narrowest) |
| `c_hs04_em01` | 0.335 | `(em01_bore_min_d-hs04_od)/2` | radial: HS04 / EM01 bore |
| `c_flange_hs03` | 0.350 | `(hs03_bore1_d-hs01_flange_d)/2` | radial: HS01 flange / HS03 bore1 |
| `c_lip_hs03` | 0.340 | `(hs03_bore2_d-hs01_lip_od)/2` | radial: HS01 lip / HS03 bore2 |
| `c_hs05_hs03` | 0.400 | `(hs03_bore2_d-hs05_od)/2` | radial: HS05 / HS03 bore2 |
| `c_hs02fl_hs03` | 0.365 | `(hs03_bore2_d-hs02_flange_d)/2` | radial: HS02 flange / HS03 bore2 |
| `c_hs02_hs03` | 0.430 | `(hs03_bore3_d-hs02_body_d)/2` | radial: HS02 body / HS03 throat |
| `c_pin` | 0.285 | `(em02_pin_hole_d-hs03_pin_d)/2` | radial: HS03 pin / EM02 pin hole |
| `c_piston_hs05` | 0.340 | `(hs05_hole_d-dp)/2` | radial: piston / HS05 hole |
| `c_collar_hs01` | 3.210 | `(hs01_bore_d-dr01_collar_d)/2` | radial: collar / HS01 bore |
| `sq_sl04` | 0.085 | `1-(hs02_sl04_d-dp)/2/sl04_cs` | SL04 radial squeeze on the piston |
| `sq_sl02` | 0.025 | `1-(hs03_bore1_d-hs01_lip_od)/2/sl02_cs` | SL02 radial squeeze HS01 lip / HS03 bore1 |
