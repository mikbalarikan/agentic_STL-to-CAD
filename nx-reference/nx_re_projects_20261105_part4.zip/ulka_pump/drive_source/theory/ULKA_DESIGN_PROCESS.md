# Ulka EP5 titreşimli pompa: tasarım süreci kaydı (tersine mühendislik)

**Yazar:** ULKA-E Teori oturumu · **Tarih:** 2026-10-16 · **Kapsam:** taramadan NX montajına ve oradan matematiksel
modele giden sürecin kaydı; alınan kararlar, erişilen doğruluk, açık kalanlar ve bu altyapının yeni bir titreşimli
pompa tasarımında nasıl kullanılacağı.

Bu belge bir özet ve yol haritasıdır. Sayıların asıl kaynağı aşağıdaki dosyalardır; çelişki olursa onlar geçerlidir:
`CLAUDE.md` (kurallar), `ULKA_INTERFACES.md` Rev H (eksen takımı, arayüz değerleri, kararlar), `sessions\A_MEASURED.md`,
`B_/C_/D_MEASURED.md` (ölçümler), `sessions\A_QA.md` (bağımsız karşılaştırmalar ve montaj kontrolü),
`cad\*_REPORT.md` (parça raporları), `cr\*.md` (değişiklik istekleri), `theory\ULKA_THEORY_REPORT.md` (hesap).

## 1. Amaç ve başlangıç kararları

Ulka EP5 (CEME Type E, 230 V 50 Hz 48 W, E5 eğrisi, 15 bar kapalı uç) titreşimli pistonlu pompanın 21 benzersiz
parçası (23 adet) taramalardan Siemens NX 2206'da parametrik ve birbirine tutarlı bir montaj olarak yeniden kuruldu;
ardından tasarımın matematiksel modeli çıkarıldı. Usta'nın kararları (2026-10-16):

| Karar | Sonucu |
|---|---|
| Bütün STL'ler CAD'e, sonra alt montajlar ve komple montaj | 21 parça + 4 sıkışmış yay kopyası; AS01 stator, AS02 kartuş, AS03 çıkış, AS00 komple; STEP |
| İş alt gruplara bölünür, oturumlar tek havuzda çalışır, orkestratör takip eder | A Master, B Stator, C Tahrik, D Hidrolik, E Teori (bölüm 3.3) |
| R385'ten devralınan varsayılanlar: asıl parçaya çok yakın, tasarım niyeti taşıyan model; ölçü kaynağı taramalar | Taramanın göremediği her şey türetildi ve işaretlendi; en kritik 6 kalem `A_OLCUM_ONERISI.md`'ye yazıldı |
| Montaj bitince bir oturum matematiksel modeli çıkarır, ölçüler gelmeden türetilmiş değerlerle başlar | Bu belge ve `ULKA_THEORY_REPORT.md`; girdiler tek dosyada (`theory\calc\inputs.json`) |
| CFD sonraki aşama, Usta onayıyla | `cfd\SIMULATION_PLAN.md` (plan; koşu yok) |

## 2. Girdiler

| Girdi | Durum |
|---|---|
| 13 tarama (12 tek parça + 2 birleşik: HS05+VL02+VL03+VL04, SL04+VL01+SL01-03) | D birleşik taramaları parçalarına ayırdı; montajlı tarama yok |
| Etiketli fotoğraflar F01-F21, söküm videoları | parça kimlikleri, montaj sırası, akış yolu, EM03 yarığı, VL05 biçimi |
| Datasheet `E_high_pressure.pdf` | toplam boy 122 (55 + 50 + 18), CH12, Ø13,5, G1/8, E5 Q-p eğrisi, 48 W, diyot entegre |
| BOM, parça kodlama belgesi | parça kodları, CAD dosya adları, "Doğrulanacaklar" listesi |
| Usta'nın tek ölçümü (CR-D-01) | DR02 teli 1,0, DR03 teli 1,3 mm |

Taramaların sınırları: tek yüzden taranmış küçük parçalar (yaylar, VL05) parçalı; ince metal taramada yan başına
0,07 - 0,11 mm şişiyor (yay telleri: Usta 1,0 / 1,3, tarama 1,19 - 1,23 / 1,41 - 1,43); tüp içleri ve HS02'nin orta
iç profili hiç görünmüyor.

## 3. Yöntem

### 3.1 Ortak eksen takımı
Z = EM02'nin iki büyük deliğinin ortak ekseni = kartuş ekseni, +Z girişten (HS01 nipeli) çıkışa (HS02 ucu); orijin
EM02 çıkış duvarının dış yüzü; +Y fast-on terminallerinin tarafı. Rev A'da donduruldu, bir daha değişmedi.

### 3.2 Kontrol parçası
`C:\NX_MCP_WORKSPACE\ulka\ctrl\EP5-AS00_CTRL.prt`: 155 adlı expression, 14 datum düzlemi ve `PUMP_AXIS`.
Arayüz ölçüleri parça dosyalarına elle yazılmadı; interpart expression ile kontrol parçasından geldi. Eksenel yığın
kapalı bir zincir olarak formülle kuruldu (SL01 + SL03 sıkışması `sl_sq`, armatürün yay dengesiyle dinlenme konumu
`z_dr01`, manyetik strok, yukarı dayanma, yay basınç kontrolü `p_max_check`). Revizyon döngüsü: `mk_params.py` ->
`ctrl_build.py` (headless journal) -> parça journal'ları -> `asm_build.py`.

### 3.3 İş bölümü ve haberleşme
| Oturum | İş |
|---|---|
| A Master | eksen takımı, kontrol parçası, `ULKA_INTERFACES.md`, eksenel yığın, gürültü tablosu, bağımsız QA, alt montajlar, FS01 |
| B Stator | EM01 bobin, EM02 çerçeve, EM03 akı burcu (x2), HS04 ara halka |
| C Tahrik | HS01 giriş gövdesi / tüp, DR01 armatür + piston, DR02, DR03 yayları |
| D Hidrolik | HS02, HS05, SL01-SL04, VL01-VL05, HS03 |
| E Teori | matematiksel model, akışkan doğrulaması, CFD planı (CAD'in tüketicisi) |

Çelişki bulan oturum `cr\CR-<harf>-nn.md` yazdı, A karar verip yeni revizyonu yayınladı. Kabul kapıları (K1 işlevsel
±0,05 / zayıfsa 2·sd; K2 genel yüzey ±max(0,15; 2,5·sd) içinde ≥ %90; K3 montaj) **modellemeden önce** Rev A'da
sabitlendi ve sonuç görüldükten sonra gevşetilmedi.

## 4. Kararlar ve gerekçeleri (revizyon geçmişi)

| Rev | Kaynak | Karar | Neden önemli |
|---|---|---|---|
| A | A + B/C/D Aşama 1 | ilk yayın; SL01 HS01 flanşının altında (zincirin tek tutarlı yeri) | yer değişse kapalı uç basıncı 10 bar'a düşerdi |
| B | CR-D-01, CR-C-01 | Usta'nın tel ölçüsü 1,0 / 1,3; k artık formül; `hs01_inner_bot` 55,3 -> 52,0 (15 bar kontrolü) | armatürün dinlenmesi ve strok tamamen değişti (-3,70 -> -0,42) |
| C | CR-C-02 | yay dış çapı = tarama tel merkez çapı + Usta teli | tarama şişmesi ilk kez sayısal olarak görüldü; d_p için de uyarı |
| D | CR-D-02 | VL05 yeri 31,92 (HS02 iç yığını Rev C kinematiğinden) | G1/8 dişi 4,8 < datasheet min 7: türetmenin bilinen çelişkisi |
| E | CR-B-01 | `em01_len` 43,52 (dış halkalar) | bobin - çerçeve teması |
| F | CR-D-03 | SL01 2,20; SL03 13,15 x 1,10; `sl_sq` %22,7; kartuş zinciri -0,079 | O-ring kesitleri QA'ya göre |
| G | CR-B-02 | EM02 dört bükümde tek iç R 1,9 | tek şerit, tek kalıp |
| H | A montaj kontrolü | `z_em01_term` -3,30 (bobin iki duvar arasında ortalı) | flanş kenarı büküm radyüsüne giriyordu |

## 5. Erişilen doğruluk

### 5.1 Parça - tarama (A'nın bağımsız ölçümü, `sessions\A_QA.md`)
- K2 geçen: HS01 %96,2, HS02 %95,4, HS04 %95,1, EM03 %93,7 - 94,4, DR01 %98,9, HS05 %93,8, SL01 %97,5, SL04 %91,3,
  VL01 %100, VL03 %95,6.
- K2 tutmayan (ölçüsüyle): HS03 %86,1, EM01 %89,4, EM02 %89,9, SL02 %88,4, SL03 %85,4; yaylar ve VL05 (tarama parçalı:
  %37 - 63). K1 işlevsel ölçüler bu parçaların hepsinde (SL03 dahil, Rev F'te) tuttu.
- Hesap için kritik işlevsel ölçülerin tarama kesinliği: d_p 4,962 / 4,967 (A / CAD), armatür Ø 14,341, tüp deliği
  14,897 / 14,913, EM03 ID 16,70, büyük delikler ±0,01. Bunlar teori modelinde "CAD-K" kaynağıdır.

### 5.2 Montaj
AS00 PASS (Rev H): 23 bileşen; yalnız beklenen girişimler (O-ring sıkışmaları, M4 dişi, valf / yay temasları);
strok taraması -8,13 .. +2,58 boyunca çarpışma yok; STEP 23 katı, geçersiz 0.

### 5.3 Teori aşamasında yakalananlar (E)
- **VL02 kuvveti kontrol parçasının yay dengesinde yok.** Türetilmiş VL02 (tel 0,5, serbest 15,0, montaj boyu 10,0)
  pistonu 2,4 N ile geri itiyor; dinlenme konumu ctrl'deki -0,55 yerine -1,16 çıkıyor (0,61 mm). Hesap kendi
  dengesini kullanır; CAD dinlenme konumu yalnız montaj görüntüsünü etkiler (CR yazılmadı, bilgi: rapor bölüm 1).
- **Türetilmiş VL02 ile emme valfi dinlenmede yaklaşık 4,2 bar fark ister**; emme stroku bunu üretemez (en çok
  p_atm - p_v ≈ 1 bar). Valf yalnız piston yay serbest kalacak kadar geri gidince açılır. Bu, VL02'nin gerçekte çok
  daha yumuşak olduğunu ya da oda dibinin (VL02 omzu) daha derinde olduğunu gösterir: A_OLCUM #4 ve #5 en etkili
  kalemlerdir (rapor bölüm 4, 7).
- **Model kapalı uçta durmuyor** (taban ~20 bar, E5 15): türetilmiş bobin ve B-H ile manyetik kuvvet armatürü
  8-10 mm geri çekiyor. E5'e uydurulan ayar varyantı (VL02 teli 0,35) düşük basıncı tutturuyor, kapalı ucu tutturmuyor.
  Bildirim: `cr\CR-E-01.md`.
- Bilya merkezinin STEP'teki yeri formülden 0,09 mm yukarıda (havşa temas varsayımı farkı; etkisi önemsiz).

## 6. Açık kalanlar

1. A_OLCUM_ONERISI'nin 6 kalemi (d_p, HS01 iç derinlik, DR02/DR03 k, HS02 iç profili, VL02/VL04, bobin direnci).
   Ölçüler gelince yalnız `theory\calc\inputs.json` doldurulur, `python run_all.py` koşulur; rapor yeniden üretilir.
   CAD tarafında aynı değerler A'nın `mk_params.py`'sine girer (yeni revizyon) - bu iki zincir birbirinden bağımsız
   çalışır, sayılar aynı kaynaktan gelir.
2. G1/8 iç diş boyu (4,8 < 7): HS02 iç profili ölçülünce çözülür.
3. EM01 sargı penceresi (makara cidarı, kaplama) varsayımdır; bobin direnci ölçülünce sarım sayısı 48 W'tan,
   direnç ölçümden gelir ve pencere varsayımı devreden çıkar.
4. Malzemeler (armatür ferritik paslanmaz, çerçeve düşük karbonlu çelik, tüp PA66) fotoğraf ve sınıftan; B-H eğrisi
   ölçülmedi.

## 7. Bu altyapı yeni bir titreşimli pompa tasarımında nasıl kullanılır

### 7.1 Zincir
1. Kontrol parçası (`mk_params.py`): eksenel yığın, armatür / burç / ara halka boyları, piston çapı, yaylar.
2. Parça journal'ları kontrol parçasından okur; `asm_build.py` montajı, girişimi ve strok taramasını yapar.
3. Teori zinciri (`theory\calc\run_all.py`): `c1` STEP'ten hacimler ve kütleler -> `c2` manyetik alan tablosu
   (N'den bağımsız; yalnız stator / armatür geometrisi değişince yeniden) -> `c3` dinamik model -> `c4` 48 W
   kalibrasyonu ve Q-p -> `c5` kayıplar -> `c6` duyarlılık -> `c7` ayar varyantı -> rapor.

### 7.2 Tasarım parametreleri ve etkileri (rapor bölüm 8)
- **Piston çapı d_p**: debi ∝ d_p², kapalı uç basıncı ∝ 1/d_p² (yay kuvveti sabitken).
- **Yay sabitleri ve ön yük**: kapalı uç basıncı ve eğrinin eğimi; bobin gücüyle birlikte strok.
- **Armatür - burç yerleşimi (HS04 boyu, dinlenmede EM03-A'ya mesafe)**: kuvvet - konum eğrisinin tepesinin yeri.
- **Bobin (N, tel)**: 48 W'ta akım ve amper-sarım; armatür doyması tavanı belirler.
- **Emme valfi yayı (VL02) ve oda dibi**: emme tarafının açılabilirliği; düşük basınçta debinin çoğu buraya bağlı.
- **Basma valfi yayı (VL04)**: çok düşük basınçta debi ve geri kaçak.

### 7.3 Süreçten çıkarılan dersler
- Taramada görünmeyen ama işlevi taşıyan iç ölçüleri (oda dibi, küçük yaylar) türetirken, türetmenin pompanın
  çalışmasıyla tutarlılığı (ör. emme valfi açılabilir mi) CAD aşamasında bir hesapla sınanmalı; geometrik uyum
  (girişim yok) yeterli değil.
- Yay dengesi kontrolünde bütün yaylar (küçük valf yayları dahil) toplanmalı.
- Manyetik kuvvet için tek bir "manyetik strok" sayısı yanıltıcıdır: bu tasarımda kuvvet, armatür arka yüzü alt
  burca ulaştığında değil, ancak armatür iki burcu eşit kapladığında (yaklaşık -12,5 mm) sıfırlanır.
