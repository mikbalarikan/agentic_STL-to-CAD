# Ulka EP5 titreşimli pompa: teori ve hesap raporu

**Yazar:** ULKA-E Teori oturumu · **Tarih:** 2026-10-16 · **CAD:** Rev H (`ULKA_INTERFACES.md`,
`cad\assembly\EP5-AS00_ASSY.stp`) · **Hesaplar:** `theory\calc\*.py`; bu belgedeki bütün hesap sayıları, tablolar ve
şekiller betiklerin çıktısıdır (`python run_all.py` ile yeniden üretilir). **Tek girdi dosyası:** `theory\calc\inputs.json`.

> **Önce bunu okuyun.** Bu rapordaki hiçbir sonuç pompa üzerinde ölçülmüş bir debi, basınç ya da akımla
> doğrulanmadı; tek karşılaştırma datasheet'in E5 eğrisidir. Usta'nın 6 ölçümü (`sessions\A_OLCUM_ONERISI.md`)
> henüz yok: hiçbiri ölçülmedi. Piston çapı,
> HS01 iç derinliği, ana yay sabitleri, HS02 iç profili, küçük valf yayları ve bobin direnci **türetilmiş** değerlerdir.
> Her sayının yanında kaynağı yazar: **CAD-K** (CAD, taramadan ölçülmüş), **CAD-T** (CAD, türetildi), **STEP** (bu
> çalışmada montaj STEP'inden), **DS** (datasheet), **LIT** (literatür), **VAR** (varsayım), **FIT** (E5 eğrisine
> uydurulmuş ayar parametresi), **USTA** (Usta'nın ölçümü).

## 0. Özet

| Büyüklük | Değer | Dayanağı |
|---|---|---|
| Piston çapı / alanı | 4,97 mm / 19,40 mm² | CAD-K (A_OLCUM #1) |
| Armatür dinlenme konumu (ön alın) | z = -1,16 mm (ctrl: -0,55; VL02 kuvveti dahil edilince -0,61) | DR02 + DR03 + VL02 dengesi |
| Hareketli kütle | 26,6 g (DR01 24,3 g + yay payları + delikteki su) | STEP hacmi × VAR yoğunluk |
| Basınç odası hacmi, dinlenme / en ileri | 458 / 397 mm³ | STEP (türetilmiş oda Ø6,0 × dip 24,0) |
| Manyetik çekme, dinlenmede / en büyük (4800 A-sarım) | 29,0 N / 37,4 N (x = -3,8 mm) | 2B eksenel simetrik doğrusal olmayan alan çözümü |
| Bobin (türetildi) | N = 4205 sarım, R = 132,0 Ω (20 °C), tel ≈ Ø0,275 mm | 48 W kalibrasyonu + sargı penceresi (VAR doluluk 0,55) |
| Model debisi 0 bar | 405 cm³/dk (E5: 650) | taban model (yalnız türetilmiş girdiler) |
| Model kapalı uç basıncı | 20,0 bar (E5: 15) | taban model |
| E5 ile kapı (|ΔQ| ≤ max(30; %10)) | 3 / 10 noktada tuttu; RMS sapma 105 cm³/dk | bölüm 5 |
| Ayar varyantı (FIT) | VL02 teli 0,35 mm, ana yay k × 1,20: RMS 59 cm³/dk, 3 / 10 nokta, durma > 18 bar | bölüm 8; ölçüm değildir |
| Emme valfi (VL01) açılma farkı dinlenmede | 4,2 bar (emmede erişilebilen en çok ≈ 1 bar) | türetilmiş VL02 + oda dibi |
| Basma valfi (VL03) açılma farkı | 2,62 bar | türetilmiş VL04 |

Ana bulgular:

1. **Pompanın debisi emme valfinin açılabilirliğiyle sınırlı.** Türetilmiş VL02 bilya yayı (tel 0,50,
   k 0,49 N/mm, montajda 10,0 / serbest 15,0 mm) bilyayı dinlenmede
   2,44 N ile oturtuyor; bu 4,2 bar'lık bir fark ister, emme stroku ise en çok
   ≈ 1 bar (atmosfer - buhar basıncı) üretebilir. Valf ancak piston x ≈ -5,0 mm'nin gerisine
   çekilince (yay boşa çıkınca) açılıyor; oda strokun ilk kısmında buhar boşluğuyla doluyor. Bu, taban modelin E5'in
   altında kalmasının ana nedeni (bölüm 4, 6) ve A_OLCUM #4 (oda dibi) ile #5'i (VL02) en değerli ölçüm yapıyor
   (bölüm 7).
2. **Manyetik kuvvet tek bir "manyetik strok" değil, armatürün iki burcu kaplamasıyla belirlenir.** Kuvvet,
   armatürün arka yüzü EM03-A'ya yaklaştıkça artıp x ≈ -3,8 mm'de en büyük olur, armatür iki
   burcu eşit kapladığında (x ≈ -12,7 mm) sıfırlanır. Armatür 1,68 T'ya kadar doyuyor;
   48 W'ta tepe akım 1,12 A, tepe amper-sarım ≈ 4709 A.
3. **Model kapalı uçta durmuyor**: taban modelde debi 20,0 bar'a kadar sıfıra inmiyor (E5: 15 bar'da 0).
   Manyetik kuvvet armatürü dinlenmeden 8 - 10 mm geri çekebiliyor; bu yolda yayların biriktirdiği kuvvet piston
   alanına bölününce 15 bar'ı aşıyor. Bu, türetilmiş bobinin (R, N) ve demir B-H varsayımının kuvveti fazla verdiğini
   ya da yay sabitlerinin / HS01 derinliğinin farklı olduğunu gösterir (bölüm 5, 7, 9).
4. **Hem tüpte hem odada kavitasyon var.** Armatürün içinden geçen akış yolu (Ø6,09 delik + Ø5,15 çapraz delik)
   armatürün tepe hızında 0,4 bar fark istiyor; giriş hattının ataleti basma strokunda
   6,0 bar'a kadar fark istiyor; ön ve arka tüp hacmi çevrimin bir bölümünde buhar basıncına iniyor
   (bölüm 6.3). Basma strokunun başında oda içindeki boşluğun çöküşü oda basıncında kısa tepeler üretiyor (şekil l1).
5. **Yüksek basınçta hareket düzenli değil**: 10 bar'ın üstünde ardışık çevrimlerin hacmi değişiyor (alt-harmonik /
   düzensiz salınım); tablo değerleri 10 çevrimin ortalamasıdır ve saçılım (std) ayrıca verilmiştir.

**Tutmayanlar** (ayrıntı bölüm 5, 9): 0 bar (model 405, E5 650); 2 bar (model 375, E5 520); 7 bar (model 262, E5 330); 8 bar (model 206, E5 300); 10 bar (model 179, E5 210); 14 bar (model 125, E5 60); 15 bar (model 97, E5 0); kapalı uç basıncı 20,0 bar (kapı ±1 bar: **tutmadı**).

## 1. Çalışma prensibi ve geometri

### 1.1 Mekanizma ve akış yolu

Seri bir diyot bobini şebekenin yalnız pozitif yarı dalgasında besler: saniyede 50 darbe. Akım geçerken manyetik
devre (EM02 çerçeve -> EM03-A burcu -> radyal aralık -> DR01 armatür -> radyal aralık -> EM03-B burcu -> çerçeve;
iki burcun arasında manyetik olmayan HS04 halkası) armatürü **girişe doğru** çeker (-z): DR03 arka yay sıkışır, DR02
ön yay uzar, piston HS02 odasından geri çekilir (emme). Akım bitince iki yay armatürü ve pistonu ileri iter (basma).
Basma kuvvetini yaylar verir; bobin yalnız yayları kurar.

Akış yolu (+z): giriş hortumu -> HS01 nipeli (Ø3,0, CAD-T) -> HS01 tüpü (Ø14,92) -> armatürün arka
hacmi -> armatürün eksenel deliği (Ø6,09) ve 0,29 mm halka aralık -> çapraz delik (Ø5,15) -> ön hacim ->
piston deliği (Ø2,72, 18,2 mm) -> **VL01 bilyası** (Ø3,572, Ø2,72 keskin kenarda; VL02
yayı bilyayı pistona bastırır, yayın öbür ucu oda dibinde) -> HS02 basınç odası (Ø6,0, CAD-T) -> Ø4,0
oturma -> **VL03 kubbe tapası** (R2,76, VL04 yayıyla) -> VL05 kafesi -> G1/8 çıkış.

Emme valfi pistonun içindedir: emme strokunda tüp hacmi küçülür ve sıvı pistonun içinden odaya geçer; giriş
hattından su **basma strokunda** çekilir (piston odaya girerken tüpteki hacmi açar). Ortalama debi her iki hatta aynıdır,
ama giriş hattının ataleti basma strokuna biner (bölüm 6.3).

### 1.2 Eksenel zincir ve dinlenme konumu

Zincir kontrol parçasının formülleriyle kuruldu; Usta'nın ölçümü gelirse burada kendiliğinden değişir
(`common.derive()`):

| Büyüklük | Değer | Kaynak |
|---|---|---|
| HS01 tüp iç dibi (DR03 yüzü) | z = -47,29 (soket ağzından 57,31 mm) | CAD-T (A_OLCUM #2) |
| DR02 / DR03 yay sabiti | 1,169 / 2,823 N/mm | CAD-T: G d⁴/(8 D³ n_a), Usta teli 1,0 / 1,3 (tarama teliyle 2,34 / 3,91) |
| VL02 / VL04 yay sabiti | 0,490 / 1,135 N/mm | CAD-T, konik yay, ortalama Dm³ |
| Dinlenmede yay kuvvetleri DR03 / DR02 / VL02 | 11,49 / 9,06 / 2,44 N | denge |
| Dinlenme (ön alın) | -1,160 (VL02'siz: -0,550 = ctrl -0,550) | |
| İleri sert dayanma (yaka - HS05) | z = 2,03, dinlenmeden 3,19 mm | CAD-K |
| Arka yüz - EM03-A üst kenarı | 7,02 mm (ctrl `stroke_mag` 7,63) | geri tarafta sert dayanma yok (DR03 blok boyu 10,6 mm) |
| VL02 montaj boyu dinlenmede | 10,03 mm (serbest 15,0, blok 6,25) | oda dibi z = 36,42 (CAD-T) |

Kontrol parçası VL02'nin kuvvetini dengeye katmıyor; türetilmiş VL02 ile armatür -0,61 mm daha
geride duruyor. Bu yalnız montajdaki görüntüyü etkiler; hesap kendi dengesini kullanır (CR yazılmadı: VL02 değerleri
A_OLCUM #5 ile zaten değişecek; bilgi olarak `ULKA_DESIGN_PROCESS.md` bölüm 5.3).

### 1.3 Kütleler ve hacimler (STEP)

Montaj STEP'inde 23 katı hacimden tanındı (`c1_geometry.py`).

| Büyüklük | Değer | Kaynak |
|---|---|---|
| DR01 hacmi / kütlesi | 3152,5 mm³ / 24,27 g | STEP × VAR 7,70 g/cm³ |
| Yaylar DR02 / DR03 | 1,37 / 3,07 g (hareketli kütleye 1/3) | STEP × LIT |
| Delikteki su (armatürle taşınır) | 0,87 g | eksenel delik + piston deliği |
| Toplam hareketli kütle m_a | 26,62 g | |
| Bilya + VL02 payı / tapa + VL04 payı | 0,277 / 0,153 g | |
| Oda sıvı hacmi, STEP'teki konumda (ctrl dinlenmesi) | 446,6 mm³ | STEP: Ø9,8 silindir - HS02 - DR01 - VL01 - VL02 - SL04 - VL03 |
| Oda hacmi, model dinlenmesi / en ileri (yaka dayanmada) | 458,5 / 396,6 mm³ | STEP + A_p × konum farkı |
| Tüp sıvısı, arka / ön (STEP'teki konumda) | 4239 / 1410 mm³ | STEP |
| Geometrik süpürme (EM03-A kenarından ileri dayanmaya, A_p × 10,21) | 198,1 mm³ = 594 cm³/dk @ 50 Hz | referans |
| Sıkıştırma oranı (0 bar strokuyla) | ε = 1,58 | |

Not: bilya merkezi STEP'te z = 25,304, modelin oturma geometrisiyle (Ø2,72 kenar)
25,218; 0,09 mm fark havşa teması varsayımından, etkisi önemsiz.

### 1.4 Akış yolu kesitleri

| Kesit | Alan [mm²] | Boy [mm] | 0 bar ortalama hız [m/s] | 0 bar tepe hız [m/s] | tepede ½ρv² [bar] | Kaynak |
|---|---|---|---|---|---|---|
| giriş hortumu Ø4,0 (VAR) | 12,57 | 300,0 | 0,54 | 2,9 | 0,04 | VAR |
| HS01 nipel deliği Ø3,0 | 7,07 | 20,7 | 0,96 | 5,2 | 0,13 | CAD-T |
| HS01 tüpü Ø14,92 (armatürsüz) | 174,83 | - | 0,04 | 1,9 | 0,02 | CAD-K |
| armatür / tüp halka aralığı 0,29 | 13,06 | 20,0 | 0,52 | 13,1 | 0,86 | CAD-K |
| DR01 eksenel delik Ø6,09 | 29,13 | 26,4 | 0,23 | 11,7 | 0,68 | CAD-K |
| DR01 çapraz delik Ø5,15 (iki ağız) | 41,66 | - | 0,16 | 8,2 | 0,33 | CAD-K |
| piston deliği Ø2,72 | 5,81 | 18,2 | 1,16 | 14,8 | 1,10 | CAD-K |
| VL01 oturma kenarı Ø2,72 | 5,81 | - | 1,16 | 14,8 | 1,10 | CAD-K |
| oda Ø6,0 - piston Ø4,97 halkası | 8,87 | - | 0,76 | 4,5 | 0,10 | CAD-T |
| çıkış oturması Ø4,0 | 12,57 | 0,8 | 0,54 | 7,2 | 0,26 | CAD-T |
| VL03 başı Ø5,0 / valf deliği Ø6,0 halkası | 8,64 | - | 0,78 | 10,5 | 0,55 | CAD-T |
| VL05 kafesi açık alanı | 23,51 | 4,5 | 0,29 | 3,8 | 0,07 | CAD-T |
| G1/8 çıkış (Ø8,52 delik) | 57,01 | - | 0,12 | 1,6 | 0,01 | CAD-K |

Ortalama hız 0 bar'daki ortalama debiden (405 cm³/dk), tepe hız o kesitten geçen akışın çevrim izindeki
en büyük değerinden. Akış darbelidir: tepe / ortalama oranı 10 - 40; kayıplar tepe hızlarda oluşur.

## 2. Manyetik devre

### 2.1 Model

Eşdeğer manyetik devre elle bir direnç ağı olarak kurulmadı; aynı devre r-z düzleminde sonlu hacimlerle, doğrusal
olmayan demirle çözüldü (`c2_magnetics.py`). Böylece radyal aralıklar, saçak akıları ve doyma ayrı ayrı varsayılmak
yerine geometriden çıkıyor. Bilinmeyen akı fonksiyonu $\psi = r A_\varphi$:

$$\frac{\partial}{\partial r}\left(\frac{\nu}{r}\frac{\partial \psi}{\partial r}\right) + \frac{\partial}{\partial z}\left(\frac{\nu}{r}\frac{\partial \psi}{\partial z}\right) = -J, \qquad B_z = \frac{1}{r}\frac{\partial\psi}{\partial r},\quad B_r = -\frac{1}{r}\frac{\partial\psi}{\partial z}$$

$\nu(B)$ demirlerde atan doyma eğrisinden: $B = \mu_0 H + \frac{2J_s}{\pi}\arctan\frac{\pi(\mu_r-1)\mu_0 H}{2J_s}$; armatür
$J_s$ = 1,45 T, $\mu_r$ = 1500 (VAR, ferritik paslanmaz); burçlar ve çerçeve $J_s$ = 1,90 T,
$\mu_r$ = 2500 (VAR). Newton-Raphson, en büyük artık 0,00000009 (bağıl). Ağ 86 × 354
düğüm; armatür kenarı hücreleri kısmi doluluklu (konum değişince kuvvet sürekli).

| Öğe | Geometri | Kaynak |
|---|---|---|
| Armatür | Ø6,09 / Ø14,34 × 20,04; arka pilot Ø9,5, ön pilot Ø10,02 | CAD-K |
| Radyal aralık armatür - burç | 1,185 mm (0,29 su + 0,585 PA66 tüp + 0,310 hava) | CAD-K |
| EM03-A / EM03-B | Ø16,71 / Ø21,00 × 18,9; z -47,12 .. -28,22 ve -19,12 .. -0,22; yarık 0,5 | CAD-K / CAD-T |
| HS04 (manyetik değil) | 9,1 mm | CAD-K |
| EM03-B - çerçeve deliği | radyal 0,12 mm, 2,78 mm boy | CAD-K |
| EM02 çerçeve | 3 mm duvarlar; r > 16,03'te iki şerit kesitine eşdeğer kalınlık, dış kabuk 1,16 mm (eşdeğer) | CAD-K + VAR (eksenel simetri) |
| Sargı penceresi | r 11,72 .. 22,80, z -45,62 .. -4,50: 455,6 mm², ortalama sarım 108,5 mm | EM01 zarfı (CAD-K) - makara cidarı, kaplama, alın (VAR) |

Tablo çıktıları $\varphi(z, NI)$ (sarım başına akı) ve $F(z, NI) = \partial W'/\partial z$, $W' = \int_0^{NI}\varphi\,d(NI)$;
**sarım sayısından bağımsızdır** (N ve R sonradan seçilir). Doğrusal kontrol: dinlenmede küçük akımda sarım² başına
endüktans 0,094 µH; yalnız EM03-B radyal aralığının analitik değeri 0,927 µH (seri ikinci aralık ve
saçaklarla tutarlı mertebe).

### 2.2 Sonuçlar

![Kuvvet ve akı](fig/m2_kuvvet_aki.png)

![Alan](fig/m1_alan.png)

| NI [A] | Dinlenmede çekme [N] | En büyük çekme [N] | Yeri x [mm] | Sıfır kuvvet x [mm] | Dinlenmede φ [µWb] |
|---|---|---|---|---|---|
| 1200 | 3,3 | 13,5 | -6,8 | -12,6 | 112 |
| 2400 | 12,2 | 27,2 | -6,3 | -12,6 | 213 |
| 4800 | 29,0 | 37,4 | -3,8 | -12,7 | 311 |

Okuma: armatürün arka yüzü EM03-A'nın üst kenarına (x = -7,02) gelmeden kuvvet artmaya başlar
(saçak), kenarı geçince en büyük olur, armatür iki burcu eşit kapladığında sıfıra iner ve tersine döner. Geri tarafta
sert dayanma olmadığı için armatürü geride durduran yaylar ve bu doğal denge noktasıdır. Akı 2400 A-sarımın üstünde
armatür doymasıyla yatıyor; kuvvet NI ile doğrusal artmıyor. Kuvvet eğrisindeki küçük basamaklar ağın 0,2 mm'lik
eksenel adımından (kısmi doluluk) gelir, büyüklükleri ±0,5 N mertebesindedir.

### 2.3 Bobin: sarım sayısı ve direnç (türetildi)

Bobin direnci ölçülmedi (A_OLCUM #6). İki bilinmeyen (N, R) iki koşulla bağlandı:
(1) sargı penceresi: $R = \rho_{Cu} N^2 \ell_m / (k_f A_w)$ (VAR $k_f$ = 0,55);
(2) etiket gücü: kalibrasyon basınçlarında (0.0 / 7.5 / 15.0 bar) ortalama giriş gücü 48 W.
Sonuç **N = 4205, R = 132,0 Ω, tel ≈ Ø0,275 mm** (kalibrasyonda 47,9 W).
Usta direnci ölçünce (1) devreden çıkar: R ölçülen, N yine 48 W'tan bulunur. Bobinin ısınması (sınıf F) direnci
%30-40 artırır; etiket gücünün soğuk ya da sıcak bobinde mi ölçüldüğü bilinmiyor (VAR: 20 °C).

## 3. Dinamik model

### 3.1 Denklemler

Durum vektörü: armatür konumu $z_f$ ve hızı $v$, sarım başına akı $\varphi$, üç sıvı düğümü (arka tüp, ön tüp, oda),
giriş hattı debisi $Q_{in}$, piston deliği debisi $Q_{pb}$, bilyanın konumu ve hızı, tapanın kalkışı ve hızı
(`c3_model.py`).

Elektrik (seri diyot): iletimde $N\dot\varphi = \sqrt{2}\,U\sin\omega t - V_d - R i$, $i = NI(z,\varphi)/N$ (tablonun tersi);
$\varphi = 0$ iken gerilim $V_d$'nin altındaysa kesim.

Armatür:

$$m_a \dot v = F_m(z,NI) + F_{03} - F_{02} + (p_r - p_f)(A_t - A_{bore}) + (p_f - p_c)(A_p - A_{pb}) - N_b - F_{sür} - c\,v + F_{day}$$

Sıvı düğümleri ($e$ = sıvı hacmi fazlası; $e<0$ buhar boşluğu, basınç $p_v$'ye iner):

$$\dot e_r = Q_{in} - Q_{rf} - A_t v,\qquad \dot e_f = Q_{rf} - Q_{pb} + (A_t - A_p)v,\qquad \dot e_c = Q_{pb} - Q_{out} + A_p v$$

$$p = p_v + \frac{e}{C}\ (e \gg 0),\qquad C_c = \frac{V_c}{K} + V_{oda}\frac{2}{E}\left(\frac{r_o^2+r_i^2}{r_o^2-r_i^2}+\nu\right)$$

Hatlar: $I_{in}\dot Q_{in} = p_{depo} - p_r - \Delta p_{kayıp}$, $I_{pb}\dot Q_{pb} = p_f - p_c - \Delta p_{valf} - \Delta p_{pb} - \rho L_{pb}\dot v$.
Valfler: küre - keskin kenar geçiş alanı $A = \pi (r_s + r_b) g$, $g = \sqrt{r_s^2 + (c+y)^2} - R$; $\Delta p = \frac{\rho}{2}\frac{Q|Q|}{(C_d A + A_{sız})^2}$;
valf kuvveti $\Delta p \cdot A_{yuva}$, yay, oturma ve dayanma teması (ceza yöntemi, geri sekme katsayısıyla sönüm).
Armatür içi akış: $\Delta p_{rf} = R_l Q + \frac{\rho}{2}\left(\frac{K_{bore}}{A_{bore}^2} + \frac{K_x}{A_x^2}\right)Q|Q|$, paralel laminer halka aralık.

### 3.2 Model parametreleri (kalibrasyondan sonra)

| Parametre | Değer | Kaynak |
|---|---|---|
| m_a / m_b / m_o | 26,62 / 0,277 / 0,153 g | STEP |
| Giriş hattı ataleti $I_{in}$ | 26,8·10⁶ kg/m⁴ (hortum 0,30 m × Ø4,0 + nipel) | VAR + CAD-T |
| Piston deliği ataleti $I_{pb}$ | 3,1·10⁶ kg/m⁴ | CAD-K |
| Tüp esnekliği arka / ön | 40,7 / 17,4·10⁻¹⁵ m³/Pa (PA66 tüp cidarı baskın) | LIT E 3000 MPa |
| Oda: su + PA66 duvar | $K_{eff}$ = 0,46 GPa | LIT |
| Armatür içi kayıp | $K_{bore}$ = 1,5, $K_x$ = 1,5 | LIT (keskin kenar) |
| Valf $C_d$ | bilya 0,65, tapa 0,65; sızıntı alanı 0.0001 mm² | LIT / VAR |
| Sürtünme | 1,0 N + SL04: μ 0,10 × p × π d_p × 0,5 mm | VAR |
| Depo seviyesi | 0,10 m | VAR (test düzeneği bilinmiyor) |
| Çıkış | sabit basınç (test düzeneğinde akümülatör / manometre kabulü) | VAR |
| Sayısal | Radau, rtol 1e-05, 16 çevrim, son 10'u ortalanır | |

### 3.3 Bir çevrim

![Çevrim](fig/l1_cevrim.png)

| Basınç | Strok [mm] | Konum aralığı x [mm] | Tepe hız [m/s] | Tepe akım [A] | Oda basıncı en düşük / en yüksek [bar mutlak] | Odanın buharda kaldığı pay |
|---|---|---|---|---|---|---|
| 0 bar | 11,88 | -9,84 .. 2,66 | 2,06 / -1,61 | 1,12 | 0,023 / 24,3 | %18 |
| 7 bar | 7,63 | -9,19 .. -0,84 | 2,22 / -1,82 | 1,15 | 0,023 / 34,3 | %31 |
| 14 bar | 7,48 | -9,37 .. -0,96 | 1,04 / -1,86 | 1,14 | 0,023 / 28,0 | %42 |

Akım gerilimin tepesinden yaklaşık 3 ms sonra en büyük olur ve diyot ancak gerilim negatife geçtikten sonra (indüktif
akım sıfıra inince) keser. Armatür emme strokunu akım varken yapar, basma strokunu akım bittikten sonra yaylarla
yapar. Oda basıncındaki keskin tepeler buhar boşluğunun çöküşü ve tapanın titreşmesidir (VL03 0,15 g,
VL04 1,14 N/mm: doğal frekans ≈ 433 Hz); tepe değerleri modelin sönüm varsayımına duyarlıdır.

## 4. Valfler

![Valf açılma](fig/v1_valf.png)

| Valf | Yay | Ön yük | Açılma basınç farkı | Not |
|---|---|---|---|---|
| VL01 bilya (emme) | VL02 k = 0,490 N/mm (tel 0,50, n_a 9,0) | dinlenmede 4,97 mm = 2,44 N | dinlenmede 4,19 bar; en ileride 6,88 bar; x < -4,97 mm'de 0 | piston geri gittikçe yay boşalır |
| VL03 tapa (basma) | VL04 k = 1,135 N/mm (tel 0,45) | 2,90 mm = 3,29 N | 2,62 bar; tam açık (0,975 mm) 3,50 bar | |

Emme tarafında kullanılabilir en büyük basınç farkı depo basıncı ile buhar basıncı arasındadır:
(1,023 - 0,023) ≈ 1,00 bar. Türetilmiş VL02 dinlenmede bunun 4,2 katını istiyor:
**türetilmiş VL02 ile oda dibi derinliği birlikte pompanın çalışmasıyla tutarsız** (strokun ilk kısmında emme valfi
açılamıyor). Gerçek pompada ya VL02 çok daha yumuşak (ince tel / çok sarım) ya da oda dibi daha derin (montaj boyu
serbest boya yakın). Bu iki değer A_OLCUM #4 ve #5'tir; ayar varyantı (bölüm 8) birincisini sınar.

## 5. Doğrulama: Q-p eğrisi, kapalı uç basıncı, güç

Kabul kapısı (datasheet'in "ortalama debi" toleransı bilinmediği için; ilk taban koşusundan sonra, ayar varyantından
ve duyarlılıktan önce sabitlendi, sonra gevşetilmedi):
**|Q_model - Q_E5| ≤ max(30 cm³/dk; %10·Q_E5)** her noktada, **kapalı uç basıncı 15 ± 1 bar**.

![Q-p](fig/q1_qp.png)

| p [bar] | E5 [cm³/dk] | Model [cm³/dk] | Çevrim saçılımı (std) | Fark | Kapı (±) | Sonuç | Strok [mm] | η_v (strok) | P [W] | I_rms [A] |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 650 | 405 | 39 | -245 | 65 | **tutmadı** | 11,88 | 0,59 | 48,9 | 0,529 |
| 2 | 520 | 375 | 79 | -145 | 52 | **tutmadı** | 10,76 | 0,60 | 49,1 | 0,528 |
| 4 | 420 | 403 | 52 | -17 | 42 | tuttu | 9,19 | 0,75 | 50,3 | 0,536 |
| 6 | 350 | 325 | 44 | -25 | 35 | tuttu | 7,50 | 0,75 | 48,8 | 0,537 |
| 7 | 330 | 262 | 64 | -68 | 33 | **tutmadı** | 7,63 | 0,59 | 48,5 | 0,538 |
| 8 | 300 | 206 | 66 | -94 | 30 | **tutmadı** | 7,88 | 0,45 | 48,3 | 0,537 |
| 10 | 210 | 179 | 59 | -31 | 30 | **tutmadı** | 7,92 | 0,39 | 48,0 | 0,538 |
| 12 | 140 | 127 | 72 | -13 | 30 | tuttu | 8,68 | 0,25 | 48,4 | 0,537 |
| 14 | 60 | 125 | 59 | +65 | 30 | **tutmadı** | 7,48 | 0,29 | 47,8 | 0,538 |
| 15 | 0 | 97 | 49 | +97 | 30 | **tutmadı** | 6,31 | 0,26 | 46,5 | 0,541 |

15 bar'ın üstü: 16 bar 97 (std 33); 17 bar 66 (std 25); 18 bar 62 (std 15); 20 bar 0 (std 0) cm³/dk.
Kapalı uç (Q = 0'a ilk iniş, doğrusal ara değer): **20,0 bar** (E5: 15).

![Güç ve strok](fig/q2_guc_strok.png)

Değerlendirme:
- **Düşük basınç (0 - 4 bar)**: model E5'in altında. Strok 0 bar'da 11,88 mm, strokla süpürülen hacim
  230 mm³ = 691 cm³/dk; yani **strok E5 debisine yetecek kadar** (650 için
  11,17 mm gerekir), kayıp hacimsel verimde (η_v 0,59): emme valfi geç açılıyor ve oda tam dolmuyor.
- **Orta basınç**: debi basınçla E5'ten daha yavaş düşüyor ya da yakın; eğim yay sabiti ve manyetik kuvvetin
  geri çekme yolu tarafından belirleniyor.
- **Yüksek basınç ve kapalı uç**: kapalı uç 20,0 bar; 15 bar üstünde de düzensiz küçük debi var
  (bkz. saçılım). Kapalı uçta durma basıncı ana yay sabitleriyle doğrudan ölçeklenir (bölüm 7).
- **Güç**: giriş gücü basınçla az değişiyor (40,7 .. 50,3 W); bu,
  bobinin ağırlıkla indüktif / dirençli bir yük olduğunu, mekanik işin girişin küçük bir kısmı olduğunu gösterir:
  7 bar'da hidrolik güç 3,06 W.

## 6. Hacimsel verim, kayıplar ve kavitasyon

### 6.1 Darbe başına hacim dökümü

![Hacim dökümü](fig/d1_hacim_dokumu.png)

| p [bar] | Geometrik [mm³] | Strok × A_p | Basılan | VL01 geri kaçak | VL03 geri kaçak | Sıkıştırma | η (geometrik) | η (strok) |
|---|---|---|---|---|---|---|---|---|
| 0 | 198 | 230 | 135,1 | 16,2 | 0,02 | 0,00 | 0,68 | 0,59 |
| 2 | 198 | 209 | 124,9 | 21,4 | 1,85 | 0,17 | 0,63 | 0,60 |
| 4 | 198 | 178 | 134,4 | 5,9 | 2,54 | 0,34 | 0,68 | 0,75 |
| 6 | 198 | 145 | 108,5 | 18,9 | 15,09 | 0,51 | 0,55 | 0,75 |
| 7 | 198 | 148 | 87,4 | 37,3 | 9,56 | 0,60 | 0,44 | 0,59 |
| 8 | 198 | 153 | 68,5 | 49,5 | 14,19 | 0,69 | 0,35 | 0,45 |
| 10 | 198 | 154 | 59,8 | 36,6 | 8,27 | 0,86 | 0,30 | 0,39 |
| 12 | 198 | 168 | 42,5 | 37,1 | 13,56 | 1,03 | 0,21 | 0,25 |
| 14 | 198 | 145 | 41,5 | 24,1 | 7,69 | 1,20 | 0,21 | 0,29 |
| 15 | 198 | 122 | 32,2 | 32,1 | 9,11 | 1,28 | 0,16 | 0,26 |
| 16 | 198 | 109 | 32,4 | 16,7 | 2,14 | 1,37 | 0,16 | 0,30 |

Debi kaybının nedenleri, büyükten küçüğe: (1) strokun ilk kısmında emme valfinin açılamaması ve odanın buharla
dolması (basılan hacmin strok hacminden farkının büyük kısmı; geri kaçakla açıklanmayan kısım), (2) VL01'in geç
kapanmasıyla geri kaçak (bilya 0,28 g, yay basma strokunda tekrar yüklenir), (3) basınç arttıkça strokun kısalması
(yay kuvvetine karşı basınç kuvveti), (4) sıkıştırma: oda 397 mm³, $K_{eff}$ 0,46 GPa ile 15 bar'da
yalnız 1,3 mm³ (önemsiz), (5) VL03 geri kaçağı (küçük).

### 6.2 Akış yolu basınç kayıpları

Bölüm 1.4'teki tabloda tepe dinamik basınçlar verildi. Ortalama debide kayıplar küçüktür (nipel Ø3'te
ortalama hız 0,96 m/s); darbeli akışta tepe hızlar belirleyicidir: piston deliği ve bilya
geçişi en büyük emme debisinde 2,60 bar valf farkı görüyor (0 bar; bilya çevrimin %43'inde açık); armatür içi yol
(delik + çapraz delik) armatürün tepe hızında (2,06 m/s) arka ile ön tüp arasında
0,38 bar fark istiyor (bu fark armatürü frenler: 5,5 N).
Halka aralık (0,29 mm, laminer) bu yolun yanında küçük bir paydır.

### 6.3 Kavitasyon

| Basınç | Arka tüp en düşük | Ön tüp en düşük | Oda en düşük [bar mutlak] | 0,2 bar altında kalınan çevrim payı: arka / ön / oda |
|---|---|---|---|---|
| 0 bar | 0,023 | 0,023 | 0,023 | %62 / %53 / %66 |
| 7 bar | 0,023 | 0,023 | 0,023 | %71 / %63 / %45 |
| 14 bar | 0,023 | 0,023 | 0,023 | %44 / %53 / %53 |

Depo basıncı 1,023 bar mutlak (NPSH statik 10,2 m). Giriş hattının ataleti (hortum 0,30 m)
basma strokunda 6,00 bar'a kadar fark istiyor: bu bir atmosferi aşınca arka tüp buhar basıncına iner. Hortum boyu
duyarlılığı bölüm 7'de. **Kavitasyon riski yüksek**: model hem tüpte (armatür içi yol + giriş ataleti) hem odada
(emme valfinin geç açılması) buhar basıncına iniyor. Gerçek pompada çözünmüş havanın ayrışması da buna eklenir;
model yalnız buharı temsil eder. Bu bölgeler CFD planında aşama 3'ün konusu (`cfd\SIMULATION_PLAN.md`).

## 7. Duyarlılık

Her satırda yalnız o girdi değiştirildi; zincir (dinlenme, oda hacmi, yay ön yükleri) yeniden kuruldu; bobin N ve R
tabanda sabit tutuldu (R satırları hariç).

![Duyarlılık](fig/s1_duyarlilik.png)

| Kalem | Değişiklik | Q(0) | Q(6) | Q(10) | Q(14) | Durma [bar] | P [W] | Dinlenme z |
|---|---|---|---|---|---|---|---|---|
| taban | türetilmiş girdiler (taban) | 405 | 334 | 158 | 111 | > 18 | 47,6 | -1,16 |
| #1 | d_p 5,00 (tasarım niyeti olabilir) | 405 | 301 | 174 | 89 | > 18 | 47,7 | -1,16 |
| #1 | d_p 4,94 | 406 | 337 | 184 | 100 | > 18 | 47,8 | -1,16 |
| #2 | HS01 derinlik +1,0 mm | 410 | 309 | 150 | 84 | > 18 | 46,0 | -1,79 |
| #2 | HS01 derinlik -1,0 mm | 362 | 339 | 191 | 107 | 16,0 | 48,8 | -0,53 |
| #3 | k_DR02, k_DR03 +%15 | 402 | 279 | 189 | 103 | > 18 | 48,0 | -1,09 |
| #3 | k_DR02, k_DR03 -%15 | 335 | 309 | 184 | 50 | > 18 | 47,4 | -1,25 |
| #3 | k tarama teliyle (1,19 / 1,41) | 381 | 251 | 164 | 123 | > 18 | 47,3 | -1,86 |
| #4 | oda dibi +1,0 (ölü hacim +, VL02 ön yük -) | 400 | 353 | 173 | 103 | > 18 | 48,4 | -1,05 |
| #4 | oda dibi -1,0 | 360 | 291 | 180 | 37 | 16,0 | 46,5 | -1,27 |
| #4 | oda Ø6,4 | 405 | 290 | 174 | 97 | > 18 | 47,7 | -1,16 |
| #4 | çıkış oturma Ø3,5 | 404 | 335 | 173 | 74 | 18,0 | 47,1 | -1,16 |
| #4 | çıkış oturma Ø4,5 | 415 | 323 | 167 | 106 | > 18 | 47,3 | -1,16 |
| #5 | VL02 tel 0,40 (k x0,41) | 510 | 328 | 194 | 103 | > 18 | 47,9 | -0,82 |
| #5 | VL02 tel 0,30 (k x0,13) | 307 | 318 | 141 | 113 | > 18 | 48,7 | -0,64 |
| #5 | VL04 tel 0,40 (k x0,62) | 395 | 323 | 209 | 100 | > 18 | 47,5 | -1,16 |
| #5 | VL04 tel 0,50 (k x1,52) | 406 | 331 | 138 | 105 | 16,0 | 46,4 | -1,16 |
| #6 | R +%20 (N sabit) | 418 | 283 | 167 | 128 | > 18 | 45,8 | -1,16 |
| #6 | R -%20 (N sabit) | 377 | 338 | 172 | 100 | 18,0 | 50,2 | -1,16 |
| VAR | giriş hortumu 0 m | 287 | 228 | 191 | 166 | > 18 | 49,6 | -1,16 |
| VAR | giriş hortumu 1,0 m | 461 | 230 | 179 | 52 | > 18 | 47,4 | -1,16 |
| VAR | sürtünme F0 x2 | 410 | 302 | 170 | 101 | 18,0 | 47,8 | -1,16 |
| VAR | Cd valfler 0,5 | 355 | 315 | 172 | 100 | 18,0 | 47,4 | -1,16 |
| VAR | K_bore, K_xhole x2 (armatür sönümü) | 383 | 300 | 169 | 84 | 18,0 | 47,4 | -1,16 |
| VAR | depo seviyesi 0,5 m | 435 | 339 | 184 | 93 | > 18 | 47,5 | -1,16 |

Okuma (taban bu koşuda: Q(0) 405, Q(10) 158, durma > 18 bar; durma yalnız 0/6/10/14/16/18 bar noktalarından, "> 18" = 18 bar'da hâlâ debi var):
- **#1**: d_p 5,00 (tasarım niyeti olabilir): ΔQ(0) -0, ΔQ(10) +16, durma > 18 bar; d_p 4,94: ΔQ(0) +1, ΔQ(10) +25, durma > 18 bar.
- **#2**: HS01 derinlik +1,0 mm: ΔQ(0) +5, ΔQ(10) -9, durma > 18 bar; HS01 derinlik -1,0 mm: ΔQ(0) -43, ΔQ(10) +33, durma 16,0 bar.
- **#3**: k_DR02, k_DR03 +%15: ΔQ(0) -4, ΔQ(10) +31, durma > 18 bar; k_DR02, k_DR03 -%15: ΔQ(0) -70, ΔQ(10) +25, durma > 18 bar; k tarama teliyle (1,19 / 1,41): ΔQ(0) -24, ΔQ(10) +6, durma > 18 bar.
- **#4**: oda dibi +1,0 (ölü hacim +, VL02 ön yük -): ΔQ(0) -5, ΔQ(10) +14, durma > 18 bar; oda dibi -1,0: ΔQ(0) -46, ΔQ(10) +21, durma 16,0 bar; oda Ø6,4: ΔQ(0) -1, ΔQ(10) +16, durma > 18 bar; çıkış oturma Ø3,5: ΔQ(0) -1, ΔQ(10) +15, durma 18,0 bar; çıkış oturma Ø4,5: ΔQ(0) +10, ΔQ(10) +8, durma > 18 bar.
- **#5**: VL02 tel 0,40 (k x0,41): ΔQ(0) +105, ΔQ(10) +36, durma > 18 bar; VL02 tel 0,30 (k x0,13): ΔQ(0) -98, ΔQ(10) -17, durma > 18 bar; VL04 tel 0,40 (k x0,62): ΔQ(0) -10, ΔQ(10) +51, durma > 18 bar; VL04 tel 0,50 (k x1,52): ΔQ(0) +1, ΔQ(10) -20, durma 16,0 bar.
- **#6**: R +%20 (N sabit): ΔQ(0) +13, ΔQ(10) +9, durma > 18 bar; R -%20 (N sabit): ΔQ(0) -28, ΔQ(10) +14, durma 18,0 bar.
- **VAR**: giriş hortumu 0 m: ΔQ(0) -118, ΔQ(10) +33, durma > 18 bar; giriş hortumu 1,0 m: ΔQ(0) +56, ΔQ(10) +21, durma > 18 bar; sürtünme F0 x2: ΔQ(0) +5, ΔQ(10) +11, durma 18,0 bar; Cd valfler 0,5: ΔQ(0) -50, ΔQ(10) +14, durma 18,0 bar; K_bore, K_xhole x2 (armatür sönümü): ΔQ(0) -22, ΔQ(10) +10, durma 18,0 bar; depo seviyesi 0,5 m: ΔQ(0) +30, ΔQ(10) +26, durma > 18 bar.

Öne çıkanlar: **VL02** (#5) 0 bar debisini ±100 cm³/dk oynatan tek ölçüm kalemi; **giriş hortumu** (test düzeneği,
VAR) da aynı mertebede: hortum ataleti basma strokunda gelen suyu "itme" etkisiyle (akışkan ataleti) düşük basınçta
debiyi artırıyor (0 m: 287, 1 m: 461 cm³/dk). Bu yüzden E5'in 0 bar değeri
test düzeneğinin hattına bağlıdır ve tek başına bir model kapısı olarak zayıftır. Kapalı uca en çok HS01 derinliği
(#2), oda dibi (#4), VL04 ve bobin direnci (#6) dokunuyor (16 - 18 bar'a iniyor); hiçbiri tek başına 15 bar'a indirmiyor.

Düzensiz hareket yüzünden tek noktadaki farklar ±(çevrim saçılımı / √10) mertebesinde gürültü taşır (tabanda
Q(10)'da std 59 cm³/dk); bu gürültüden küçük farklar anlamlı sayılmamalıdır.

## 8. Ayar varyantı (FIT) - modelin E5'e uydurulması

Taban model yalnız türetilmiş girdilerle koşar ve bölüm 5'teki farkları "tutmadı" olarak taşır. Hangi girdinin
farkı kapatabileceğini görmek için iki ölçülmemiş girdi E5 eğrisine en küçük kareler anlamında uyduruldu
(`c7_fit.py`, 4 × 4 ızgara, 0 - 14 bar'da 8 nokta, N tabanda sabit, seçilen noktada N yeniden 48 W'a kalibre edildi):

| Ayar parametresi | Değer | Türetilmiş (taban) | Anlamı |
|---|---|---|---|
| `FIT_vl02_d` | **0,35 mm** | 0,50 mm | VL02 teli: emme valfi yay sabiti × 0,24 |
| `FIT_k_scale` | **× 1,20** | 1 | DR02 / DR03: 1,40 / 3,39 N/mm |
| (kalibre) N, R | 4213, 132,4 Ω | 4205, 132,0 Ω | 48 W |

![Ayar](fig/f1_ayar.png)

| p [bar] | E5 | Ayar varyantı | std | Fark | Sonuç |
|---|---|---|---|---|---|
| 0 | 650 | 555 | 3 | -95 | **tutmadı** |
| 2 | 520 | 535 | 0 | +15 | tuttu |
| 4 | 420 | 443 | 4 | +23 | tuttu |
| 6 | 350 | 283 | 23 | -67 | **tutmadı** |
| 7 | 330 | 269 | 66 | -61 | **tutmadı** |
| 8 | 300 | 221 | 76 | -79 | **tutmadı** |
| 10 | 210 | 189 | 44 | -21 | tuttu |
| 12 | 140 | 108 | 97 | -32 | **tutmadı** |
| 14 | 60 | 96 | 62 | +36 | **tutmadı** |
| 15 | 0 | 87 | 76 | +87 | **tutmadı** |

Ayar varyantı: RMS 59 cm³/dk (taban 105), kapalı uç > 18 bar, 3 / 10 nokta kapıda.
**Bu bir ölçüm değildir.** Okuma: (1) RMS yüzeyi düzensiz hareketin gürültüsünü taşıyor (şekil f1, sağ); ayırt
edilebilen tek eğilim VL02 telinin **0,35 - 0,40 mm** bandında olması (0,25'te bilya geç kapanıp geri kaçak büyüyor,
0,50'de valf açılamıyor: emme valfi yayının bir **en iyi değeri** var). (2) k çarpanının etkisi gürültü mertebesinde;
seçilen × 1,20 ızgaranın kenarında ve anlamlı bir ayar sayılmamalı. (3) Ayar varyantı da kapalı uçta
**durmuyor**: kapalı uç farkını bu iki girdi kapatamıyor; bobin / manyetik kuvvet (R, B-H) ve HS01 derinliği gibi
geri çekme yolunu belirleyen girdiler gerekiyor (bölüm 9.3). Usta'nın ölçümleri gelince ayar varyantı devreden çıkar.

## 9. Dürüst özet

### 9.1 Hangi sonuç neye dayanıyor
- **Sağlam (CAD-K)**: piston, armatür, tüp, burç, çerçeve ölçüleri; manyetik devrenin geometrisi; strok sınırlarının
  ileri tarafı (yaka - HS05); oda hacminin STEP'ten ölçümü (ama odanın kendisi türetildi).
- **Türetilmiş ve sonucu güçlü etkileyen**: VL02 (yay + oda dibi) -> düşük basınç debisi; DR02/DR03 k -> kapalı uç;
  bobin R ve sargı penceresi -> akım ve kuvvet; HS01 iç derinliği -> dinlenme ve geri çekme yolu.
- **Varsayım**: malzeme B-H eğrileri, valf $C_d$, armatür içi kayıp katsayıları, giriş hortumu, sürtünme, 48 W'ın
  hangi koşulda ölçüldüğü.

### 9.2 Datasheet ile nerede tutuyor, nerede tutmuyor
- Tuttu: 4 bar, 6 bar, 12 bar.
- **Tutmadı**: 0 bar (-245), 2 bar (-145), 7 bar (-68), 8 bar (-94), 10 bar (-31), 14 bar (+65), 15 bar (+97); kapalı uç 20,0 bar.
- Strok uzunluğu E5'in 0 bar debisiyle uyumlu (strokla süpürülen 691 cm³/dk); fark hacimsel verimde.

### 9.3 En değerli ölçümler (bu modele göre sırayla)
1. **A_OLCUM #5 (VL02) ve #4 (oda dibi derinliği)**: düşük basınç debisini doğrudan belirliyor; türetilmiş değerler
   emme valfinin açılmasını engelliyor.
2. **A_OLCUM #3 (DR02/DR03 k)**: kapalı uç basıncı ve eğrinin eğimi.
3. **A_OLCUM #6 (bobin direnci)**: akımı ve kuvveti sargı penceresi varsayımından kurtarır.
4. #2 (HS01 derinliği): dinlenme konumunu ve kapalı uç basıncını etkiliyor. #1 (d_p 4,97 / 5,00): etkisi bu
   modelin gürültüsünün altında (debide beklenen %1,2).
5. Test düzeneği (ölçüm listesinde yok, ama E5 karşılaştırması için önemli): giriş hortumu boyu / çapı ve depo
   seviyesi; mümkünse CEME'nin E5 eğrisini hangi düzenekte ölçtüğü.

## Ek A. Parametre kaydı

| Ad | Değer | Birim | Kaynak | Not |
|---|---|---|---|---|
| `dp` | 4,970 | mm | CAD-K | piston dis capi d_p (A_OLCUM #1) |
| `hs01_depth_mouth` | 57,310 | mm | CAD-T | HS01 soket agzi -> tup ic dibi (A_OLCUM #2) |
| `hs01_inner_bot` | 52,000 | mm | CAD-T | HS01 flans ustu -> tup ic dibi |
| `hs02_ch_d` | 6,000 | mm | CAD-T | HS02 basinc odasi capi (taramada yalniz agizda 6,0-6,06 goruldu; derini turetildi) |
| `hs02_ch_bot` | 24,000 | mm | CAD-T | HS02 flans yuzunden oda dibine (VL02 omzu) derinlik (D, CR-D-02) |
| `hs02_seat_d` | 4,000 | mm | CAD-T | cikis valfi oturma kenari capi (VL03 kubbe R2,76 ile) |
| `vl02_d` | 0,500 | mm | CAD-T | VL02 bilya yayi tel capi (tarama zayif) |
| `vl02_l0` | 15,000 | mm | CAD-K | VL02 serbest boy |
| `vl02_na` | 9,000 | - | CAD-T | VL02 aktif sarim (D modeli: 2 konik + 7 silindirik) |
| `vl04_d` | 0,450 | mm | CAD-T | VL04 valf yayi tel capi (tarama zayif) |
| `vl04_l0` | 6,800 | mm | CAD-K | VL04 serbest boy |
| `vl04_na` | 3,000 | - | CAD-T | VL04 aktif sarim |
| `z_hs01_flange` | 4,710 | mm | CAD-T | kontrol parcasi Rev H |
| `z_hs05` | 10,020 | mm | CAD-T | kontrol parcasi Rev H |
| `z_hs02` | 12,420 | mm | CAD-T | kontrol parcasi Rev H |
| `hs01_bore_d` | 14,920 | mm | CAD-K | kontrol parcasi Rev H |
| `hs01_lip_h` | 5,310 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_arm_d` | 14,340 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_arm_len` | 20,040 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_tip` | 25,330 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_collar_d` | 8,500 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_collar_front` | 7,990 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_fpilot_d` | 10,020 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_rpilot_d` | 9,500 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_rear_len` | 0,980 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_bore_d` | 6,090 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_pin_id` | 2,720 | mm | CAD-K | kontrol parcasi Rev H |
| `dr01_seat_d` | 4,000 | mm | CAD-K | kontrol parcasi Rev H |
| `dr02_d` | 1,000 | mm | USTA | kontrol parcasi Rev H |
| `dr02_od` | 12,750 | mm | CAD-K | kontrol parcasi Rev H |
| `dr02_l0` | 18,930 | mm | CAD-K | kontrol parcasi Rev H |
| `dr02_na` | 4,550 | mm | CAD-T | kontrol parcasi Rev H |
| `dr02_nt` | 6,060 | mm | CAD-K | kontrol parcasi Rev H |
| `dr03_d` | 1,300 | mm | USTA | kontrol parcasi Rev H |
| `dr03_od` | 12,840 | mm | CAD-K | kontrol parcasi Rev H |
| `dr03_l0` | 30,160 | mm | CAD-K | kontrol parcasi Rev H |
| `dr03_na` | 6,500 | mm | CAD-T | kontrol parcasi Rev H |
| `dr03_nt` | 8,150 | mm | CAD-K | kontrol parcasi Rev H |
| `vl01_d` | 3,572 | mm | CAD-K | kontrol parcasi Rev H |
| `vl03_head_d` | 5,000 | mm | CAD-K | kontrol parcasi Rev H |
| `vl03_head_r` | 2,760 | mm | CAD-K | kontrol parcasi Rev H |
| `hs02_sl04_d` | 8,630 | mm | CAD-K | kontrol parcasi Rev H |
| `hs02_sl04_depth` | 2,150 | mm | CAD-K | kontrol parcasi Rev H |
| `hs02_out_d` | 8,520 | mm | CAD-K | kontrol parcasi Rev H |
| `hs02_out_floor` | 29,220 | mm | CAD-K | kontrol parcasi Rev H |
| `hs02_vl05_z` | 31,920 | mm | CAD-T | kontrol parcasi Rev H |
| `vl05_t` | 4,500 | mm | CAD-K | kontrol parcasi Rev H |
| `hs05_hole_d` | 5,650 | mm | CAD-K | kontrol parcasi Rev H |
| `hs01_tube_od` | 16,090 | mm | CAD-K | kontrol parcasi Rev H |
| `em03_od` | 21,000 | mm | CAD-K | kontrol parcasi Rev H |
| `em03_id` | 16,710 | mm | CAD-K | kontrol parcasi Rev H |
| `em03_len` | 18,900 | mm | CAD-K | kontrol parcasi Rev H |
| `em03_slit_w` | 0,500 | mm | CAD-T | kontrol parcasi Rev H |
| `hs04_h` | 9,100 | mm | CAD-K | kontrol parcasi Rev H |
| `z_em03a_bot` | -47,120 | mm | CAD-K | kontrol parcasi Rev H |
| `z_hs04_bot` | -28,220 | mm | CAD-K | kontrol parcasi Rev H |
| `z_hs04_top` | -19,120 | mm | CAD-K | kontrol parcasi Rev H |
| `z_em03b_top` | -0,220 | mm | CAD-K | kontrol parcasi Rev H |
| `z_em02_out` | 0,000 | mm | CAD-K | kontrol parcasi Rev H |
| `z_em02_out_in` | -3,000 | mm | CAD-K | kontrol parcasi Rev H |
| `z_em02_in_in` | -47,120 | mm | CAD-K | kontrol parcasi Rev H |
| `z_em02_in_out` | -50,120 | mm | CAD-K | kontrol parcasi Rev H |
| `em02_hole_out_d` | 21,240 | mm | CAD-K | kontrol parcasi Rev H |
| `em02_hole_in_d` | 16,740 | mm | CAD-K | kontrol parcasi Rev H |
| `em02_out_x` | 53,960 | mm | CAD-K | kontrol parcasi Rev H |
| `em02_w` | 32,060 | mm | CAD-K | kontrol parcasi Rev H |
| `em02_t` | 3,000 | mm | CAD-K | kontrol parcasi Rev H |
| `em01_body_d` | 47,210 | mm | CAD-K | kontrol parcasi Rev H |
| `em01_len` | 43,520 | mm | CAD-K | kontrol parcasi Rev H |
| `em01_bore_min_d` | 21,450 | mm | CAD-K | kontrol parcasi Rev H |
| `z_em01_term` | -3,300 | mm | CAD-T | kontrol parcasi Rev H |
| `z_em01_far` | -46,820 | mm | CAD-T | kontrol parcasi Rev H |
| `z_hs01_tip` | -67,980 | mm | CAD-T | kontrol parcasi Rev H |
| `z_hs01_mouth` | 10,020 | mm | CAD-T | kontrol parcasi Rev H |
| `hs01_len` | 78,000 | mm | CAD-K | kontrol parcasi Rev H |
| `z_dr01_ctrl` | -0,550 | mm | CAD-T | ctrl dinlenme (VL02 kuvveti yok sayilmis) |
| `stroke_mag_ctrl` | 7,630 | mm | CAD-T | ctrl manyetik strok (arka yuz -> EM03-A ust) |
| `p_max_check_ctrl` | 15,700 | bar | CAD-T | ctrl yay basinc kontrolu |
| `k02` | 1,169 | N/mm | CAD-T | DR02 yay sabiti (A_OLCUM #3); formul G d^4/(8 D^3 n_a) |
| `k03` | 2,823 | N/mm | CAD-T | DR03 yay sabiti (A_OLCUM #3) |
| `k_vl02` | 0,490 | N/mm | CAD-T | VL02 bilya yayi, konik; Dm_eff = (ortalama Dm^3)^(1/3) = 4.96 |
| `k_vl04` | 1,135 | N/mm | CAD-T | VL04 valf yayi, konik; Dm_eff = 4.70 |
| `vl02_block` | 6,250 | mm | CAD-T | VL02 blok boyu (D raporu) |
| `vl04_inst` | 3,900 | mm | CAD-T | VL04 montaj boyu (VL03 oturmus; asm_build) |
| `vl04_lift_max` | 0,975 | mm | CAD-T | VL03 en buyuk kalkis |
| `wall_t` | 0,800 | mm | CAD-T | oda dibi duvari (D, CR-D-02) |
| `z_rest` | -1,160 | mm | CALC | DR01 on alin dinlenme (DR02 + DR03 + VL02 dengesi) |

Varsayımların tamamı (değer, birim, kaynak, not): `theory\calc\inputs.json` (`malzeme`, `bobin`, `hidrolik`,
`mekanik`, `sayisal`).

## Ek B. Betikler ve yeniden üretim

| Betik | Ne yapar | Çıktı |
|---|---|---|
| `inputs.json` | tek girdi dosyası; Usta'nın 6 ölçümü `usta_olcum` altında | - |
| `common.py` | ctrl Rev H değerlerini okur, ölçümleri uygular, zinciri kurar (dinlenme, yaylar, alanlar) | - |
| `c1_geometry.py` | STEP'ten katı kimlikleri, kütleler, oda ve tüp hacimleri, kesitler | `out\geometry.json` |
| `c2_magnetics.py` | eksenel simetrik doğrusal olmayan alan çözümü, φ(z, NI) ve F(z, NI) tabloları | `out\mag_tables.npz`, `magnetics.json`, şekil m1, m2 |
| `c3_model.py` | dinamik model (kütüphane), paralel koşu yardımcısı | - |
| `c4_qp.py` | 48 W kalibrasyonu (N, R), Q-p, çevrim izleri | `out\qp.json`, `traces.npz`, şekil q1, q2, l1 |
| `c5_losses.py` | valf açılma basınçları, kesit hızları, kavitasyon, hacim dökümü | `out\losses.json`, şekil v1, d1 |
| `c6_sensitivity.py` | 6 ölçüm kalemi + varsayımlar | `out\sensitivity.json`, şekil s1 |
| `c7_fit.py` | ayar varyantı (FIT) | `out\fit.json`, şekil f1 |
| `build_report.py`, `report_template.md.j2` | bu rapor (md + pdf) | `ULKA_THEORY_REPORT.md/.pdf` |
| `run_all.py` | hepsini sırayla | |

Usta'nın ölçümleri gelince: `inputs.json` -> `usta_olcum` -> ilgili `value` alanını doldur (null = ölçülmedi), sonra
`C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe run_all.py`. Manyetik tablo (c2) stator / armatür geometrisi
değişmedikçe yeniden kurulmaz. Toplam süre 24 çekirdekte yaklaşık 2-3 saat (duyarlılık ve ayar varyantı en uzunu).