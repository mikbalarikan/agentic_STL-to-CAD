r"""Butun hesaplari sirayla calistirir ve raporu uretir.

    python run_all.py              # hepsi + rapor (md + pdf); manyetik tablo varsa yeniden kurulmaz
    python run_all.py --mag        # manyetik tabloyu (c2, ~6 dk) da yeniden kur (stator / armatur geometrisi degistiyse)
    python run_all.py --report     # yalniz raporu out\*.json'dan yeniden uret
    python run_all.py --no-pdf     # PDF'siz

Usta'nin olcumleri gelince: inputs.json -> usta_olcum -> 'value' doldur, sonra 'python run_all.py'.
(d_p, HS01 derinligi, yaylar, HS02 ic profili, VL02/VL04, R manyetik tabloyu etkilemez; --mag gerekmez.)
Bagimlilik: c1 geometri (STEP) -> c2 manyetik tablo -> c4 kalibrasyon + Q-p (c3 modeli) -> c5 kayiplar
-> c6 duyarlilik -> c7 ayar varyanti -> build_report.  Toplam sure (24 cekirdek, 14 is parcacigi): ~2-3 saat.
"""
from __future__ import annotations

import os
import sys
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import time

from common import OUT


def main():
    import build_report
    if "--report" not in sys.argv:
        import c1_geometry, c2_magnetics, c4_qp, c5_losses, c6_sensitivity, c7_fit
        steps = [("c1 geometri (STEP)", c1_geometry.main), ("c4 kalibrasyon + Q-p", c4_qp.main),
                 ("c5 kayiplar", c5_losses.main), ("c6 duyarlilik", c6_sensitivity.main), ("c7 ayar varyanti", c7_fit.main)]
        if "--mag" in sys.argv or not (OUT / "mag_tables.npz").exists():
            steps.insert(1, ("c2 manyetik tablo", c2_magnetics.main))
        for name, fn in steps:
            t0 = time.time()
            fn()
            print(f"{name:28s} {time.time() - t0:7.1f} s", flush=True)
    p, text = build_report.render_md()
    print("rapor:", p)
    if "--no-pdf" not in sys.argv:
        print("pdf  :", build_report.build(p, text))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
