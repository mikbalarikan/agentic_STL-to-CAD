"""c3 - Pompanin toplu parametreli (0-B) dinamik modeli.

Durumlar (SI):
  zf, v       DR01 on alin konumu (pompa z'si) ve hizi
  phi         bobin sarim basina akisi [Wb] (c2 tablosundan NI(z, phi) ve F(z, NI))
  er, ef, ec  arka tup / on tup / basinc odasi "sivi fazlasi" [m3]: p = p_v + max(e,0)/C (e<0 -> buhar bosluğu)
  Qin         giris hatti (hortum + nipel) debisi
  Qpb         piston deligi + VL01 bilyali valf debisi (on tup -> oda, armature gore)
  zb, vb      VL01 bilya merkezi (mutlak) ve hizi
  yo, vo      VL03 tapa kalkisi ve hizi
  integraller: Vout, Ein, Vb_back, Vo_back, i2

Elektrik: u = sqrt(2) U sin(2 pi f t), seri diyot: iletimde dphi/dt = (u - V_d - R i)/N, i = NI(z, phi)/N;
phi <= 0 iken u < V_d ise kesimde (i = 0).
Kuvvetler (+z, cikisa): manyetik (c2), DR02 + DR03, basinc (arka-on tup farki, on tup-oda farki), bilya temas
tepkisi, surtunme (Coulomb + SL04 basinc), viskoz, on dayanma (yaka - HS05).
"""
from __future__ import annotations

import math
import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")       # cok surecli koşuda bellek (OpenBLAS is parcacigi tamponlari)

import numpy as np
from scipy.integrate import solve_ivp

from common import E, G0, K_W, MU, OUT, P_ATM, P_VAP, RHO, derive, iv, spring_mass

SQ2 = math.sqrt(2.0)


class MagTables:
    def __init__(self, path=OUT / "mag_tables.npz"):
        d = np.load(path)
        self.zr = d["z_rear"] * 1e-3
        self.NI = d["NI"]
        self.phi = d["phi"]
        self.F = d["F"]
        self.z0, self.dzr, self.nz = float(self.zr[0]), float(self.zr[1] - self.zr[0]), len(self.zr)
        self.dNI, self.nNI = float(self.NI[1] - self.NI[0]), len(self.NI)
        # ters tablo NI(z, phi) duzgun phi izgarasinda
        pmax = float(self.phi.max()) * 1.6
        self.nphi = 200
        self.dphi = pmax / (self.nphi - 1)
        ph = np.arange(self.nphi) * self.dphi
        inv = np.zeros((self.nz, self.nphi))
        for i in range(self.nz):
            p = self.phi[i]
            q = np.interp(ph, p, self.NI)
            # tablo ustu: son egimle dogrusal uzat
            s = (self.NI[-1] - self.NI[-2]) / max(p[-1] - p[-2], 1e-12)
            hi = ph > p[-1]
            q[hi] = self.NI[-1] + s * (ph[hi] - p[-1])
            inv[i] = q
        self.inv = inv.tolist()
        self.Ft = self.F.tolist()
        self.phit = self.phi.tolist()

    def _ix(self, z):
        u = (z - self.z0) / self.dzr
        if u < 0:
            u = 0.0
        if u > self.nz - 1.000001:
            u = self.nz - 1.000001
        i = int(u)
        return i, u - i

    def NI_of(self, z, phi):
        i, a = self._ix(z)
        u = phi / self.dphi
        if u < 0:
            return 0.0
        if u > self.nphi - 1.000001:
            u = self.nphi - 1.000001
        j = int(u); b = u - j
        t = self.inv
        return ((1 - a) * ((1 - b) * t[i][j] + b * t[i][j + 1]) + a * ((1 - b) * t[i + 1][j] + b * t[i + 1][j + 1]))

    def F_of(self, z, NI):
        i, a = self._ix(z)
        u = NI / self.dNI
        if u > self.nNI - 1.000001:
            u = self.nNI - 1.000001
        if u < 0:
            u = 0.0
        j = int(u); b = u - j
        t = self.Ft
        return ((1 - a) * ((1 - b) * t[i][j] + b * t[i][j + 1]) + a * ((1 - b) * t[i + 1][j] + b * t[i + 1][j + 1]))


def seat_area(r_s, R, c, y):
    """Kure (R) keskin kenarli yuva (r_s) uzerinde, merkez kalkisi y: en kisa bosluk ve kesik koni gecis alani."""
    if y <= 0:
        return 0.0, 0.0
    gap = math.sqrt(r_s * r_s + (c + y) ** 2) - R
    rb = r_s * R / (R + gap)
    return gap, math.pi * (r_s + rb) * gap


def build(g=None, over=None):
    """Model parametreleri (SI). over: {'ad': deger} - duyarlilik / ayar icin dogrudan ustune yazar."""
    if g is None:
        g = derive()
    over = over or {}
    m, vol = spring_mass(g)
    mm = 1e-3
    mm2 = 1e-6
    P = {}
    P["g"] = g
    P["U"] = iv("bobin", "U_rms"); P["f"] = iv("bobin", "f_line"); P["Vd"] = iv("bobin", "V_d")
    sm = iv("mekanik", "spring_mass_frac")
    # hareketli kutle: DR01 + yay paylari + bilya + delik icindeki su
    m_fluid = RHO * (g["A_bore"] * g["L_bore"] + g["A_pb"] * g["L_pb"]) * 1e-9
    P["m_a"] = (m["DR01"] + sm * (m["DR02"] + m["DR03"])) * 1e-3 + m_fluid
    P["m_fluid"] = m_fluid
    P["m_b"] = (m["VL01"] + sm * m["VL02"]) * 1e-3
    P["m_o"] = (m["VL03"] + sm * m["VL04"]) * 1e-3
    # geometri
    for k in ("A_p", "A_t", "A_bore", "A_x", "A_pb", "A_nip", "A_seat_b", "A_seat_o", "A_ch"):
        P[k] = g[k] * mm2
    P["arm_len"] = g["dr01_arm_len"] * mm
    P["tip"] = g["dr01_tip"] * mm
    P["z_hs05"] = g["z_hs05"] * mm
    P["z_hs01_bot"] = g["z_hs01_bot"] * mm
    P["z_stop"] = g["z_stop_fwd"] * mm
    P["z_rest"] = g["z_rest"] * mm
    P["k02"] = g["k02"] * 1e3; P["k03"] = g["k03"] * 1e3
    P["l02"] = g["dr02_l0"] * mm; P["l03"] = g["dr03_l0"] * mm
    P["kb"] = g["k_vl02"] * 1e3; P["lb0"] = g["vl02_l0"] * mm; P["lb_block"] = g["vl02_block"] * mm
    P["ko"] = g["k_vl04"] * 1e3; P["o_pre"] = g["vl04_pre"] * mm; P["yo_max"] = g["vl04_lift_max"] * mm
    P["Rb"] = g["vl01_d"] / 2 * mm; P["rsb"] = g["ball_seat_r"] * mm; P["cb"] = g["ball_c_above_edge"] * mm
    P["ball_seat_off"] = (g["dr01_tip"] - 0.72 + g["ball_c_above_edge"]) * mm      # bilya merkezi - on alin (oturmus)
    P["z_ch_bot"] = g["z_ch_bot"] * mm
    P["Ro"] = g["vl03_head_r"] * mm; P["rso"] = g["hs02_seat_d"] / 2 * mm
    P["co"] = math.sqrt(max(P["Ro"] ** 2 - P["rso"] ** 2, 0.0))
    P["A_o_ann"] = math.pi / 4 * (6.0 ** 2 - g["vl03_head_d"] ** 2) * mm2        # Ø6 valf deligi - Ø5 bas halkasi
    P["Cd_b"] = iv("hidrolik", "Cd_ball"); P["Cd_o"] = iv("hidrolik", "Cd_plug")
    P["A_leak"] = iv("hidrolik", "leak_area") * mm2
    # hatlar
    A_h = math.pi / 4 * (iv("hidrolik", "d_hose") * mm) ** 2
    L_h = iv("hidrolik", "L_hose")
    L_n = g["L_nip"] * mm
    P["L_hose"], P["A_hose"], P["d_hose"] = L_h, A_h, iv("hidrolik", "d_hose") * mm
    P["I_in"] = RHO * (L_h / A_h + L_n / P["A_nip"])
    P["L_nip"] = L_n
    P["d_nip"] = iv("hidrolik", "nip_bore_d") * mm
    P["K_nip"] = iv("hidrolik", "K_nip")
    P["p_tank"] = P_ATM + RHO * G0 * iv("hidrolik", "h_tank")
    P["Kc_rf"] = iv("hidrolik", "K_bore") / P["A_bore"] ** 2 + iv("hidrolik", "K_xhole") / P["A_x"] ** 2
    P["Rl_rf"] = 128 * MU * P["arm_len"] / (math.pi * (g["dr01_bore_d"] * mm) ** 4)
    h = g["gap_arm"] * mm
    P["G_ann"] = math.pi * g["dr01_arm_d"] * mm * h ** 3 / (12 * MU * P["arm_len"])
    P["I_pb"] = RHO * g["L_pb"] * mm / P["A_pb"]
    P["L_pb"] = g["L_pb"] * mm
    P["d_pb"] = g["dr01_pin_id"] * mm
    P["K_pb"] = iv("hidrolik", "K_pb")
    # esneklikler
    E_hs = iv("malzeme", "E_hs") * 1e6
    nu_hs = iv("malzeme", "nu_hs")
    r_t = g["hs01_bore_d"] / 2 * mm
    t_t = (g["hs01_tube_od"] - g["hs01_bore_d"]) / 2 * mm
    dAdp = 2 * math.pi * r_t ** 3 / (E_hs * t_t)                                 # ince cidarli tup, m2/Pa
    Lr = (g["z_rear_rest"] - g["z_hs01_bot"]) * mm
    Lf = (g["z_hs05"] - g["z_rest"]) * mm
    Vr = P["A_t"] * Lr - vol["DR03"] * 1e-9
    Vf = P["A_t"] * Lf - vol["DR02"] * 1e-9
    P["C_r"] = Vr / K_W + dAdp * Lr
    P["C_f"] = Vf / K_W + dAdp * Lf
    ri, ro = g["hs02_ch_d"] / 2, E["hs02_body_d"] / 2
    wall = 2 / E_hs * ((ro ** 2 + ri ** 2) / (ro ** 2 - ri ** 2) + nu_hs)          # kalin cidar, dV/V/dp
    P["wall_ch"] = wall
    P["C_air"] = iv("hidrolik", "C_air")
    # oda hacmi (c1 STEP olcumu varsa onu, yoksa analitik)
    try:
        geo = __import__("json").loads((OUT / "geometry.json").read_text(encoding="utf-8"))
        Va, Vb_ = analytic_chamber(g)
        Vc_rest = geo["V_ch_rest_mm3"] * 1e-9 + (Va - geo["V_ch_analytic_base_mm3"] * 1e-9)   # STEP + olcum farki
        Vbore_rest = Vb_
    except Exception:
        Vc_rest, Vbore_rest = analytic_chamber(g)
    P["Vc_rest"], P["Vbore_ch"] = Vc_rest, Vbore_rest
    # mekanik
    P["F0"] = iv("mekanik", "F_fric0"); P["mu_or"] = iv("mekanik", "mu_oring"); P["w_or"] = iv("mekanik", "w_oring") * mm
    P["c_visc"] = iv("mekanik", "c_visc")
    P["pi_dp_w"] = math.pi * g["dp"] * mm * P["w_or"]
    e = iv("mekanik", "e_stop"); z = -math.log(e) / math.sqrt(math.pi ** 2 + math.log(e) ** 2)
    P["k_stop"] = iv("mekanik", "k_stop"); P["c_stop"] = 2 * z * math.sqrt(P["k_stop"] * P["m_a"])
    e = iv("mekanik", "e_seat"); z = -math.log(e) / math.sqrt(math.pi ** 2 + math.log(e) ** 2)
    P["k_seat"] = iv("mekanik", "k_seat")
    P["c_seat_b"] = 2 * z * math.sqrt(P["k_seat"] * P["m_b"])
    P["c_seat_o"] = 2 * z * math.sqrt(P["k_seat"] * P["m_o"])
    P["c_ball"] = 0.02; P["c_plug"] = 0.02                                          # N s/m, sivi icinde sonum (VAR)
    # elektrik
    P["N"] = None; P["R"] = None
    P.update(over)
    P["C_c_fixed"] = None
    return P


def analytic_chamber(g):
    """Oda hacmi (dinlenme): HS02 ic profili (D) - piston - bilya - VL02 teli. mm3 -> m3."""
    pi4 = math.pi / 4
    u_seal = g["hs02_sl04_depth"]
    V = pi4 * g["hs02_sl04_d"] ** 2 * u_seal                                    # SL04 havsasi (O-ring dahil)
    V -= 64.15                                                                  # SL04 hacmi (asm_build)
    V += math.pi / 12 * (6.4 ** 2 + 6.4 * 6.0 + 6.0 ** 2) * (5.0 - u_seal)       # giris konisi
    V_bore = pi4 * g["hs02_ch_d"] ** 2 * (g["hs02_ch_bot"] - 5.0)
    V += V_bore
    V += pi4 * g["hs02_seat_d"] ** 2 * 0.8                                       # oturma deligi
    z_tip = g["z_rest"] + g["dr01_tip"] - g["z_hs02"]
    V -= pi4 * g["dp"] ** 2 * z_tip                                             # piston (SL04 duzleminden ice)
    V += pi4 * g["dr01_seat_d"] ** 2 * 0.72 / 3 * 1.6                            # uc havsasi (yaklasik)
    V -= math.pi / 6 * g["vl01_d"] ** 3
    V -= 34.6                                                                   # VL02 teli
    return V * 1e-9, (V_bore + pi4 * 6.2 ** 2 * 2.85) * 1e-9


DP_SMOOTH = 3000.0          # Pa: buhar gecisinin yumusatma genisligi (sayisal)


def _vap(e, C):
    """p = p_v + softplus(e/C): e >> 0 sikisan sivi, e < 0 buhar boslugu (p -> p_v)."""
    x = e / (C * DP_SMOOTH)
    if x > 30:
        return P_VAP + min(e / C, 2e8)          # Newton deneme durumlarinda tasmayi onler
    return P_VAP + DP_SMOOTH * math.log1p(math.exp(x))


def pressures(P, er, ef, ec, zf):
    pr = _vap(er, P["C_r"])
    pf = _vap(ef, P["C_f"])
    Vc = P["Vc_rest"] - P["A_p"] * (zf - P["z_rest"])
    Cc = Vc / K_W + P["Vbore_ch"] * P["wall_ch"]
    pc = _vap(ec, Cc)
    return pr, pf, pc, Vc, Cc


def make_rhs(P, M, p_out):
    N, R = P["N"], P["R"]
    w = 2 * math.pi * P["f"]
    Upk = SQ2 * P["U"]
    Vd = P["Vd"]
    A_p, A_t, A_bore, A_pb = P["A_p"], P["A_t"], P["A_bore"], P["A_pb"]
    arm_len = P["arm_len"]
    rho = RHO
    Cd_b, Cd_o, A_leak = P["Cd_b"], P["Cd_o"], P["A_leak"]
    A_o_ann = P["A_o_ann"]

    def rhs(t, s, out=None):
        zf, v, phi, er, ef, Qin, Qpb, ec, zb, vb, yo, vo = s[:12]
        pr, pf, pc, Vc, Cc = pressures(P, er, ef, ec, zf)
        z_rear = zf - arm_len
        # --- elektrik
        u = Upk * math.sin(w * t)
        if phi > 0.0:
            NI = M.NI_of(z_rear, phi)
            i = NI / N
            dphi = (u - Vd - R * i) / N
        else:
            NI = 0.0
            i = 0.0
            dphi = (u - Vd) / N if u > Vd else 0.0
        Fm = M.F_of(z_rear, NI) if NI > 0 else 0.0
        # --- yaylar
        Fs = P["k03"] * (P["l03"] - (z_rear - P["z_hs01_bot"])) - P["k02"] * (P["l02"] - (P["z_hs05"] - zf))
        # --- tup ici akislar (arka -> on, delik + capraz delik + halka aralik)
        dp_rf = pr - pf
        Kc, Rl = P["Kc_rf"], P["Rl_rf"]
        q = (-Rl + math.sqrt(Rl * Rl + 2 * rho * Kc * abs(dp_rf))) / (rho * Kc)
        Qrf = math.copysign(q, dp_rf) + P["G_ann"] * dp_rf
        # --- giris hatti
        Vh = Qin / P["A_hose"]
        Re = abs(Vh) * P["d_hose"] * rho / MU + 1e-9
        f_h = 64 / Re if Re < 2300 else 0.316 / Re ** 0.25
        Vn = Qin / P["A_nip"]
        Ren = abs(Vn) * P["d_nip"] * rho / MU + 1e-9
        f_n = 64 / Ren if Ren < 2300 else 0.316 / Ren ** 0.25
        dp_in_loss = (0.5 * rho * Vh * abs(Vh) * f_h * P["L_hose"] / P["d_hose"]
                      + 0.5 * rho * Vn * abs(Vn) * (f_n * P["L_nip"] / P["d_nip"] + P["K_nip"]))
        dQin = (P["p_tank"] - pr - dp_in_loss) / P["I_in"]
        # --- bilya valf (VL01)
        zb_seat = zf + P["ball_seat_off"]
        yb = zb - zb_seat
        gb, Ab = seat_area(P["rsb"], P["Rb"], P["cb"], yb)
        Ab = min(Ab, A_pb) * Cd_b + A_leak
        dp_b = 0.5 * rho * Qpb * abs(Qpb) / (Ab * Ab)
        Vp = Qpb / A_pb
        Rep = abs(Vp) * P["d_pb"] * rho / MU + 1e-9
        f_p = 64 / Rep if Rep < 2300 else 0.316 / Rep ** 0.25
        dp_pb = 0.5 * rho * Vp * abs(Vp) * (f_p * P["L_pb"] / P["d_pb"] + P["K_pb"])
        # --- cikis valfi (VL03)
        go, Ao = seat_area(P["rso"], P["Ro"], P["co"], yo)
        if Ao > 0:
            Ao = 1.0 / math.sqrt(1.0 / (Ao * Ao) + 1.0 / (A_o_ann * A_o_ann))
        Ao = Ao * Cd_o + A_leak
        dpo = pc - p_out
        Qout = math.copysign(Ao * math.sqrt(2 * abs(dpo) / rho), dpo)
        # --- bilya kuvvetleri
        L2 = P["z_ch_bot"] - (zb + P["Rb"])
        Fb_spring = -P["kb"] * (P["lb0"] - L2) if L2 < P["lb0"] else 0.0
        if L2 < P["lb_block"]:
            Fb_spring -= P["k_seat"] * (P["lb_block"] - L2)
        Fb_p = dp_b * P["A_seat_b"]
        Nb = 0.0
        if yb < 0:
            Nb = P["k_seat"] * (-yb) - P["c_seat_b"] * (vb - v)
            if Nb < 0:
                Nb = 0.0
        dvb = (Fb_p + Fb_spring + Nb - P["c_ball"] * (vb - v)) / P["m_b"]
        # --- tapa kuvvetleri
        Fo = (pc - p_out) * P["A_seat_o"] if yo <= 0 else (0.5 * rho * Qout * abs(Qout) / (Ao * Ao)) * P["A_seat_o"]
        Fo -= P["ko"] * (P["o_pre"] + max(yo, 0.0))
        if yo < 0:
            No = P["k_seat"] * (-yo) - P["c_seat_o"] * vo
            Fo += max(No, 0.0)
        if yo > P["yo_max"]:
            No = P["k_seat"] * (yo - P["yo_max"]) + P["c_seat_o"] * vo
            Fo -= max(No, 0.0)
        dvo = (Fo - P["c_plug"] * vo) / P["m_o"]
        # --- armatur
        Fp = dp_rf * (A_t - A_bore) + (pf - pc) * (A_p - A_pb)
        Ffr = (P["F0"] + P["mu_or"] * max(pc - P_ATM, 0.0) * P["pi_dp_w"]) * math.tanh(v / 0.005)
        Fst = 0.0
        if zf > P["z_stop"]:
            Fst = -P["k_stop"] * (zf - P["z_stop"]) - P["c_stop"] * v
            if Fst > 0:
                Fst = 0.0
        acc = (Fm + Fs + Fp - Nb - Ffr - P["c_visc"] * v + Fst) / P["m_a"]
        dQpb = (pf - pc - dp_b - dp_pb - rho * P["L_pb"] * acc) / P["I_pb"]
        der = Qin - Qrf - A_t * v
        def_ = Qrf - Qpb + (A_t - A_p) * v
        dec = Qpb - Qout + A_p * v
        if out is not None:
            out.update(u=u, i=i, NI=NI, Fm=Fm, Fs=Fs, Fp=Fp, pr=pr, pf=pf, pc=pc, Qout=Qout, Qrf=Qrf, yb=yb, Ab=Ab,
                       Ao=Ao, Vc=Vc, dp_b=dp_b, dp_pb=dp_pb, dp_in=dp_in_loss, acc=acc, Nb=Nb, Ffr=Ffr)
        return [v, acc, dphi, der, def_, dQin, dQpb, dec, vb, dvb, vo, dvo,
                Qout, u * i, min(Qpb, 0.0), min(Qout, 0.0), i * i]
    return rhs


def initial(P, p_out):
    pr = P["p_tank"]
    Vc = P["Vc_rest"]
    Cc = Vc / K_W + P["Vbore_ch"] * P["wall_ch"]
    s = [P["z_rest"], 0.0, 0.0, (pr - P_VAP) * P["C_r"], (pr - P_VAP) * P["C_f"], 0.0, 0.0, (pr - P_VAP) * Cc,
         P["z_rest"] + P["ball_seat_off"] - 1e-7, 0.0, -1e-7, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    return s


def simulate(P, M, p_out_bar, n_cycles=None, trace=False, rtol=None):
    n_cycles = n_cycles or int(iv("sayisal", "n_cycles"))
    rtol = rtol or iv("sayisal", "rtol")
    p_out = P_ATM + p_out_bar * 1e5
    rhs = make_rhs(P, M, p_out)
    T = 1.0 / P["f"]
    s0 = initial(P, p_out)
    atol = [1e-9, 1e-6, 1e-11, 1e-16, 1e-16, 1e-11, 1e-11, 1e-17, 1e-10, 1e-6, 1e-10, 1e-6,
            1e-12, 1e-6, 1e-12, 1e-12, 1e-6]
    sol = solve_ivp(rhs, (0, n_cycles * T), s0, method="Radau", rtol=rtol, atol=atol, max_step=T / 80,
                    dense_output=False, t_eval=None)
    if not sol.success:
        raise RuntimeError(sol.message)
    t, Y = sol.t, sol.y
    nav = int(iv("sayisal", "n_avg"))
    tA = (n_cycles - nav) * T

    def at(k, tt):
        return np.interp(tt, t, Y[k])
    Q = (at(12, t[-1]) - at(12, tA)) / (t[-1] - tA)
    Vcyc = np.diff([at(12, tA + k * T) for k in range(nav + 1)])          # cevrim basina basilan hacim
    Qprev = float(np.std(Vcyc) / T)                                         # cevrimden cevrime saciim (std)
    Pin = (at(13, t[-1]) - at(13, tA)) / (t[-1] - tA)
    Vb_back = (at(14, t[-1]) - at(14, tA)) / nav
    Vo_back = (at(15, t[-1]) - at(15, tA)) / nav
    irms = math.sqrt(max((at(16, t[-1]) - at(16, tA)) / (t[-1] - tA), 0))
    m = t >= (n_cycles - 1) * T
    zf = Y[0][t >= tA]
    strokes = []
    for k in range(nav):
        mk = (t >= tA + k * T) & (t <= tA + (k + 1) * T)
        strokes.append(float((Y[0][mk].max() - Y[0][mk].min()) * 1e3))
    stk = float(np.mean(strokes))
    res = dict(p_bar=p_out_bar, Q_m3s=Q, Q_ccmin=Q * 6e7, Q_std_ccmin=Qprev * 6e7, V_cycles_mm3=(Vcyc * 1e9).tolist(), P_in=Pin, i_rms=irms,
               z_min=float(zf.min() * 1e3), z_max=float(zf.max() * 1e3), stroke=stk,
               stroke_cycles=strokes, V_disp_mm3=stk * P["A_p"] * 1e6,
               Vb_back_mm3=-Vb_back * 1e9, Vo_back_mm3=-Vo_back * 1e9, nfev=int(sol.nfev), nsteps=len(t))
    res["eta_v"] = res["Q_m3s"] / (P["f"] * res["V_disp_mm3"] * 1e-9) if res["V_disp_mm3"] > 0 else 0.0
    if trace:
        tt = t[m]
        recs = []
        for k in range(len(tt)):
            o = {}
            rhs(tt[k], Y[:, m][:, k], o)
            o["t"] = tt[k] - (n_cycles - 1) * T
            o["zf"] = Y[0][m][k]; o["v"] = Y[1][m][k]; o["yo"] = Y[10][m][k]; o["Qin"] = Y[5][m][k]
            o["Qpb"] = Y[6][m][k]; o["phi"] = Y[2][m][k]; o["ec"] = Y[7][m][k]
            recs.append(o)
        res["trace"] = {k: [r[k] for r in recs] for k in recs[0]}
        # cevrimin min basinclari
        res["pc_min"] = min(res["trace"]["pc"]); res["pr_min"] = min(res["trace"]["pr"]); res["pf_min"] = min(res["trace"]["pf"])
        res["pc_max"] = max(res["trace"]["pc"])
        res["i_peak"] = max(res["trace"]["i"])
        res["v_max"] = max(res["trace"]["v"]); res["v_min"] = min(res["trace"]["v"])
        res["Fm_max"] = -min(res["trace"]["Fm"])
        res["cav_frac_ch"] = float(np.mean(np.array(res["trace"]["ec"]) < 0))
    return res


def coil_R_from_N(N, P_extra=None):
    """Sargi penceresi + doluluk oranindan R(N) (ohm), 20 C ya da T_cu."""
    mg = __import__("json").loads((OUT / "magnetics.json").read_text(encoding="utf-8"))
    A_w = mg["A_coil_mm2"] * 1e-6
    l_mt = mg["l_mt_mm"] * 1e-3
    kf = iv("bobin", "k_fill")
    rho = iv("malzeme", "rho_cu20") * (1 + iv("malzeme", "alpha_cu") * (iv("bobin", "T_cu") - 20.0))
    return rho * N * N * l_mt / (kf * A_w)


def wire_d_from_N(N):
    mg = __import__("json").loads((OUT / "magnetics.json").read_text(encoding="utf-8"))
    A_w = mg["A_coil_mm2"]
    return math.sqrt(4 * iv("bobin", "k_fill") * A_w / (math.pi * N))


# --------------------------------------------------------------------------- paralel kosu yardimcisi
_MT = None


def run_point(job):
    """job = dict(usta={}, var={(grup, ad): deger}, over={ad: deger}, N, R, p, trace, R_scale).
    Ayri surecte calisir: girdileri bellekte degistirir, zinciri kurar, tek basinc noktasini kosar."""
    global _MT, _INP0
    import copy
    import common
    if "_INP0" not in globals():
        _INP0 = copy.deepcopy(common.INP)
    common.INP.clear(); common.INP.update(copy.deepcopy(_INP0))
    for k, v in job.get("usta", {}).items():
        common.INP["usta_olcum"][k]["value"] = v
    for (grp, k), v in job.get("var", {}).items():
        common.INP[grp][k]["value"] = v
    if _MT is None:
        _MT = MagTables()
    P = build(derive())
    P["N"] = job["N"]
    P["R"] = job["R"] * job.get("R_scale", 1.0)
    P.update(job.get("over", {}))
    r = simulate(P, _MT, job["p"], trace=job.get("trace", False))
    r["job_tag"] = job.get("tag")
    return r


def run_many(jobs, workers=None):
    import multiprocessing as mp
    import os
    workers = workers or max(1, min(int(os.environ.get("ULKA_WORKERS", "12")), (os.cpu_count() or 2) - 2, len(jobs)))
    ctx = mp.get_context("spawn")
    with ctx.Pool(workers, maxtasksperchild=40) as pool:
        return pool.map(run_point, jobs, chunksize=1)
