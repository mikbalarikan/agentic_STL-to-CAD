r"""Raporu uretir: report_template.md.j2 + out\*.json  ->  ..\ULKA_THEORY_REPORT.md  ->  .pdf

Metindeki her hesap sayisi sablona out\*.json'dan girer (elle yazilmaz). Matematik: Markdown'da $...$ (LaTeX);
PDF icin matplotlib mathtext ile SVG'ye cevrilir. PDF: Edge, basliksiz yazdirma. (R385 build_report.py'den uyarlandi.)

Kullanim:  python build_report.py [--no-pdf]
"""
from __future__ import annotations

import base64
import io
import math
import os
import re
import subprocess
import sys
from pathlib import Path

import jinja2
import numpy as np

from common import (CTRL_REV, CURVE_P, CURVE_Q, HERE, INP, MEASURED, OUT, PARAMS, P_ATM, P_VAP, RHO, THEORY, derive,
                    iv, load, tr)

EDGE = Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")


def gate(p, q_model, q_e5):
    """Rev'den once sabitlenen kapi: |dQ| <= max(30 cm3/dk, %10 Q_E5)."""
    band = max(30.0, 0.10 * q_e5)
    return abs(q_model - q_e5) <= band, band


def context():
    g = derive()
    c = dict(g=g, geo=load("geometry"), mg=load("magnetics"), qp=load("qp"), L=load("losses"), S=load("sensitivity"),
             F=load("fit"), PARAMS=PARAMS, INP=INP, MEASURED=MEASURED, CTRL_REV=CTRL_REV, math=math, P_ATM=P_ATM,
             P_VAP=P_VAP, RHO=RHO, iv=iv)
    qp, F = c["qp"], c["F"]
    for key, rows in (("cmp", qp["rows"]), ("cmpF", F["rows"])):
        out = []
        for r in rows:
            if r["p_bar"] <= 15:
                q = float(np.interp(r["p_bar"], CURVE_P, CURVE_Q))
                ok, band = gate(r["p_bar"], r["Q_ccmin"], q)
                out.append(dict(r=r, q=q, ok=ok, band=band))
        c[key] = out
    c["n_ok"] = sum(x["ok"] for x in c["cmp"]); c["n_okF"] = sum(x["ok"] for x in c["cmpF"])
    # manyetik tablo ozetleri
    d = np.load(OUT / "mag_tables.npz")
    zr, NI, phi, Fm = d["z_rear"], d["NI"], d["phi"], d["F"]
    x = zr - g["z_rear_rest"]
    mag = {}
    for ni in (1200.0, 2400.0, 4800.0):
        j = int(np.argmin(abs(NI - ni)))
        f = -Fm[:, j]
        k = int(np.argmax(f))
        # sifir gecisi (x < tepe)
        z0 = None
        for i in range(k, 0, -1):
            if f[i] > 0 >= f[i - 1]:
                z0 = x[i - 1] + (x[i] - x[i - 1]) * (0 - f[i - 1]) / (f[i] - f[i - 1])
                break
        i0 = int(np.argmin(abs(x)))
        mag[int(ni)] = dict(Fmax=float(f[k]), x_at=float(x[k]), F_rest=float(f[i0]), x_zero=z0,
                            phi_rest=float(phi[i0, j] * 1e6), L_rest_mH=None)
    c["mag"] = mag
    i0 = int(np.argmin(abs(x)))
    c["L_rest_small"] = float(phi[i0, 1] / NI[1])            # Wb/A (sarim^2 basina), N^2 ile carpilir
    c["Bmax_tab"] = float(d["Bmax_arm"].max())
    c["sens"] = c["S"]["cases"]
    c["sbase"] = c["sens"][0]
    return c


def render_md():
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(str(HERE)), variable_start_string="<<", variable_end_string=">>",
                             block_start_string="<%", block_end_string="%>", comment_start_string="<#", comment_end_string="#>",
                             trim_blocks=True, lstrip_blocks=True, undefined=jinja2.StrictUndefined)
    env.filters["tr"] = tr
    env.filters["sg"] = lambda x, nd=1: f"{x:+.{nd}f}".replace(".", ",")
    env.filters["pct"] = lambda x, nd=0: tr(100 * x, nd)
    md = env.get_template("report_template.md.j2").render(**context())
    out = THEORY / "ULKA_THEORY_REPORT.md"
    out.write_text(md, encoding="utf-8", newline="\n")
    return out, md


# ----------------------------------------------------------------------------- md -> html
def math_svg(tex: str, display: bool, cache: dict):
    key = (tex, display)
    if key in cache:
        return cache[key]
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.font_manager import FontProperties
    from matplotlib.mathtext import MathTextParser
    matplotlib.rcParams["mathtext.fontset"] = "stix"
    matplotlib.rcParams["svg.fonttype"] = "path"
    fs = 11.5 if display else 10.5
    s = f"${tex}$"
    w, h, depth, *_ = MathTextParser("path").parse(s, dpi=72, prop=FontProperties(size=fs))
    fig = plt.figure(figsize=(max(w, 1) / 72, max(h, 1) / 72))
    fig.text(0, depth / max(h, 1e-6), s, fontsize=fs)
    buf = io.BytesIO()
    fig.savefig(buf, format="svg", transparent=True)
    plt.close(fig)
    b64 = base64.b64encode(buf.getvalue()).decode()
    if display:
        html = f'<div class="eq"><img src="data:image/svg+xml;base64,{b64}" style="height:{h:.1f}pt"></div>'
    else:
        html = f'<img class="im" src="data:image/svg+xml;base64,{b64}" style="height:{h:.1f}pt;vertical-align:{-depth:.1f}pt">'
    cache[key] = html
    return html


def md_to_html(md: str) -> str:
    from markdown_it import MarkdownIt
    store: list[str] = []
    cache: dict = {}
    bad: list[str] = []

    def stash(tex, display):
        try:
            html = math_svg(tex.strip(), display, cache)
        except Exception as e:                         # mathtext'in tanimadigi komut: duz metin olarak birak
            bad.append(f"{tex}  ->  {e}")
            html = f"<code>{tex}</code>"
        store.append(html)
        return f"@@M{len(store) - 1}@@"

    md = re.sub(r"\$\$(.+?)\$\$", lambda m: stash(m.group(1), True), md, flags=re.S)
    md = re.sub(r"(?<![\\$\w])\$([^$\n]+?)\$(?![\w$])", lambda m: stash(m.group(1), False), md)
    body = MarkdownIt("commonmark").enable("table").render(md)
    body = re.sub(r"@@M(\d+)@@", lambda m: store[int(m.group(1))], body)
    if bad:
        print("UYARI: cevrilemeyen formuller:")
        for b in bad:
            print("  ", b)
    css = """
    @page { size: A4; margin: 17mm 15mm 17mm 15mm; }
    body { font-family: 'Segoe UI', Calibri, Arial, sans-serif; font-size: 9.6pt; line-height: 1.38; color: #111; }
    h1 { font-size: 18pt; margin: 0 0 4pt 0; }
    h2 { font-size: 13.5pt; margin: 16pt 0 5pt 0; border-bottom: 1px solid #999; padding-bottom: 2pt; page-break-after: avoid; }
    h3 { font-size: 11pt; margin: 11pt 0 3pt 0; page-break-after: avoid; }
    p { margin: 4pt 0; text-align: justify; }
    table { border-collapse: collapse; margin: 6pt 0 8pt 0; font-size: 8.6pt; page-break-inside: avoid; }
    th, td { border: 0.6pt solid #888; padding: 2pt 5pt; vertical-align: top; }
    th { background: #e9edf2; }
    img { max-width: 100%; }
    p > img:not(.im) { display: block; margin: 5pt auto; page-break-inside: avoid; }
    img[src$="m1_alan.png"] { width: 55%; }
    img[src$="v1_valf.png"], img[src$="q2_guc_strok.png"], img[src$="d1_hacim_dokumu.png"] { width: 78%; }
    .eq { text-align: center; margin: 5pt 0; }
    code { font-family: Consolas, monospace; font-size: 8.6pt; background: #f2f2f2; padding: 0 2pt; }
    blockquote { border-left: 3pt solid #c33; margin: 6pt 0; padding: 1pt 8pt; background: #fbf3f3; }
    ul, ol { margin: 3pt 0 3pt 16pt; padding: 0; }
    li { margin: 1.5pt 0; }
    """
    return f'<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Ulka EP5 teori ve hesap raporu</title><style>{css}</style></head><body>{body}</body></html>'


def browser() -> str:
    """PDF yazdirma icin tarayici: Windows'ta Edge; Linux'ta Edge / Chromium / Chrome (yoksa hata)."""
    if EDGE.exists():
        return str(EDGE)
    import shutil
    for name in ("microsoft-edge", "chromium", "chromium-browser", "google-chrome", "google-chrome-stable"):
        p = shutil.which(name)
        if p:
            return p
    raise RuntimeError("PDF icin tarayici bulunamadi (Edge / Chromium)")


def to_pdf(html_path: Path, pdf_path: Path):
    import tempfile
    import time
    # Ayri profil klasoru: acik bir Edge varsa baslik-siz surec isi ona devredip hemen donuyor ve PDF yazilmiyor.
    # msedge.exe bazen isi arka plan surecine birakip hemen doner; PDF saniyeler sonra yazilir. Bu yuzden dosyanin
    # yazilmasi ve boyutunun durulmasi beklenir; yazilmadiysa hata verilir (sessizce gecilmez).
    prof = tempfile.mkdtemp(prefix="ulka_edge_")
    t0 = time.time()
    cmd = [browser(), "--headless=new", "--disable-gpu", "--no-pdf-header-footer", f"--user-data-dir={prof}",
           f"--print-to-pdf={pdf_path}", html_path.as_uri()]
    if os.name != "nt":
        cmd.insert(1, "--no-sandbox")
    subprocess.run(cmd, check=True, capture_output=True, timeout=300)
    size = -1
    while time.time() - t0 < 180:
        if pdf_path.exists() and pdf_path.stat().st_mtime >= t0 - 1:
            now = pdf_path.stat().st_size
            if now > 0 and now == size:
                return
            size = now
        time.sleep(1.0)
    raise RuntimeError(f"PDF yazilmadi: {pdf_path}")


def build(md_path: Path, md: str, pdf: bool = True):
    html = md_to_html(md)
    html_path = md_path.with_suffix(".html")
    html_path.write_text(html, encoding="utf-8")
    if pdf:
        to_pdf(html_path, md_path.with_suffix(".pdf"))
        html_path.unlink()
    return md_path.with_suffix(".pdf")


if __name__ == "__main__":
    p, text = render_md()
    print("md :", p, len(text.splitlines()), "satir")
    if "--no-pdf" not in sys.argv:
        print("pdf:", build(p, text))
