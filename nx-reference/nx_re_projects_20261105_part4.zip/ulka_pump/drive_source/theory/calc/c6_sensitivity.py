"""c6 - Duyarlilik: A_OLCUM_ONERISI'nin 6 kalemi + baslica varsayimlar.

Her kalem icin girdi inputs.json'daki gibi degistirilir (bellekte; dosya degismez), zincir yeniden kurulur
(dinlenme konumu, oda hacmi, yay on yukleri) ve Q-p noktalari yeniden hesaplanir. Bobin N ve R taban
kalibrasyonunda sabit tutulur (R kalemi haric: orada R degisir, N sabit).
Cikti: Q(0), Q(6), Q(10), Q(14) bar, durma basinci, giris gucu; tabana gore fark.
"""
from __future__ import annotations

import copy
import sys
import time

import numpy as np

import common
from c3_model import run_many
from c4_qp import stall_pressure
from common import FIG, curve_Q, derive, load, save

PTS = [0.0, 6.0, 10.0, 14.0, 16.0, 18.0]


CASES = []


def case(item, label, usta=None, var=None, R_scale=1.0):
    CASES.append(dict(item=item, label=label, usta=usta or {}, var=var or {}, R_scale=R_scale))


def define(g0):
    CASES.clear()
    case("taban", "türetilmiş girdiler (taban)")
    case("#1", "d_p 5,00 (tasarım niyeti olabilir)", usta={"dp": 5.00})
    case("#1", "d_p 4,94", usta={"dp": 4.94})
    d0 = g0["hs01_depth_mouth"]
    case("#2", "HS01 derinlik +1,0 mm", usta={"hs01_depth_mouth": d0 + 1.0})
    case("#2", "HS01 derinlik -1,0 mm", usta={"hs01_depth_mouth": d0 - 1.0})
    case("#3", "k_DR02, k_DR03 +%15", usta={"k_dr02": g0["k02"] * 1.15, "k_dr03": g0["k03"] * 1.15})
    case("#3", "k_DR02, k_DR03 -%15", usta={"k_dr02": g0["k02"] * 0.85, "k_dr03": g0["k03"] * 0.85})
    case("#3", "k tarama teliyle (1,19 / 1,41)", usta={"k_dr02": g0["k02_scanwire"], "k_dr03": g0["k03_scanwire"]})
    case("#4", "oda dibi +1,0 (ölü hacim +, VL02 ön yük -)", usta={"hs02_ch_bot": g0["hs02_ch_bot"] + 1.0})
    case("#4", "oda dibi -1,0", usta={"hs02_ch_bot": g0["hs02_ch_bot"] - 1.0})
    case("#4", "oda Ø6,4", usta={"hs02_ch_d": 6.4})
    case("#4", "çıkış oturma Ø3,5", usta={"hs02_seat_d": 3.5})
    case("#4", "çıkış oturma Ø4,5", usta={"hs02_seat_d": 4.5})
    case("#5", "VL02 tel 0,40 (k x0,41)", usta={"vl02_d": 0.40})
    case("#5", "VL02 tel 0,30 (k x0,13)", usta={"vl02_d": 0.30})
    case("#5", "VL04 tel 0,40 (k x0,62)", usta={"vl04_d": 0.40})
    case("#5", "VL04 tel 0,50 (k x1,52)", usta={"vl04_d": 0.50})
    case("#6", "R +%20 (N sabit)", R_scale=1.2)
    case("#6", "R -%20 (N sabit)", R_scale=0.8)
    case("VAR", "giriş hortumu 0 m", var={("hidrolik", "L_hose"): 0.0})
    case("VAR", "giriş hortumu 1,0 m", var={("hidrolik", "L_hose"): 1.0})
    case("VAR", "sürtünme F0 x2", var={("mekanik", "F_fric0"): 2.0})
    case("VAR", "Cd valfler 0,5", var={("hidrolik", "Cd_ball"): 0.5, ("hidrolik", "Cd_plug"): 0.5})
    case("VAR", "K_bore, K_xhole x2 (armatür sönümü)", var={("hidrolik", "K_bore"): 3.0, ("hidrolik", "K_xhole"): 3.0})
    case("VAR", "depo seviyesi 0,5 m", var={("hidrolik", "h_tank"): 0.5})


def main():
    qp = load("qp")
    g0 = derive()
    define(g0)
    t0 = time.time()
    jobs = []
    for ci, c in enumerate(CASES):
        for p in PTS:
            jobs.append(dict(usta=c["usta"], var=c["var"], R_scale=c["R_scale"], N=qp["N"], R=qp["R"], p=p, tag=ci))
    cache = common.OUT / "sensitivity_raw.pkl"
    import pickle
    if cache.exists() and "--reuse" in sys.argv:
        res = pickle.loads(cache.read_bytes())
    else:
        res = run_many(jobs)
        cache.write_bytes(pickle.dumps(res))
    cases = []
    for ci, c in enumerate(CASES):
        rows = sorted([r for r in res if r["job_tag"] == ci], key=lambda r: r["p_bar"])
        r = {f"Q{int(p)}": rows[i]["Q_ccmin"] for i, p in enumerate(PTS)}
        r.update({f"sd{int(p)}": rows[i]["Q_std_ccmin"] for i, p in enumerate(PTS)})
        r["p_stall"] = stall_pressure(rows)
        r["P_in"] = float(np.mean([x["P_in"] for x in rows[:4]]))
        r["stroke0"] = rows[0]["stroke"]
        saved = copy.deepcopy(common.INP)
        for k, v in c["usta"].items():
            common.INP["usta_olcum"][k]["value"] = v
        for (grp, k), v in c["var"].items():
            common.INP[grp][k]["value"] = v
        r["z_rest"] = derive()["z_rest"]
        common.INP.clear(); common.INP.update(saved)
        r["label"], r["item"] = c["label"], c["item"]
        cases.append(r)
        print(f"{c['item']:5s} {c['label']:44s} Q0 {r['Q0']:6.0f} Q6 {r['Q6']:6.0f} Q10 {r['Q10']:6.0f} Q14 {r['Q14']:6.0f} "
              f"p_st {r['p_stall']:5.1f} P {r['P_in']:5.1f}", flush=True)
    derive()
    save("sensitivity", dict(cases=cases, PTS=PTS, base=dict(N=qp["N"], R=qp["R"])))
    plot(cases)
    print(f"{time.time() - t0:.0f} s")


def plot(cases):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    b = cases[0]
    rest = cases[1:]
    labels = [f"{c['item']} {c['label']}" for c in rest]
    y = np.arange(len(rest))
    fig, ax = plt.subplots(1, 3, figsize=(13, 0.32 * len(rest) + 1.6), sharey=True)
    for a, key, nm in ((ax[0], "Q0", "ΔQ(0 bar) [cm³/dk]"), (ax[1], "Q10", "ΔQ(10 bar) [cm³/dk]"),
                       (ax[2], "p_stall", "Δ durma basıncı [bar]")):
        d = [c[key] - b[key] for c in rest]
        a.barh(y, d, color=["#d62728" if v < 0 else "#2ca02c" for v in d])
        a.axvline(0, color="k", lw=0.6)
        a.set_xlabel(nm); a.grid(alpha=0.3, axis="x")
    ax[0].set_yticks(y); ax[0].set_yticklabels(labels, fontsize=7.5)
    ax[0].invert_yaxis()
    fig.tight_layout(); fig.savefig(FIG / "s1_duyarlilik.png", dpi=140); plt.close(fig)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
