"""c1 - Geometri: montaj STEP'inden (EP5-AS00_ASSY.stp, Rev H, dinlenme = ctrl z_dr01) olcumler.

  * kati kimlikleri: hacimden (asm_build.json part_volumes)
  * hareketli kutleler: DR01, yaylar, bilya, tapa hacmi x yogunluk
  * basinc odasi sivi hacmi (SL04 -> cikis oturma kenari), STEP'teki dinlenme konumunda; modelin kendi dinlenme
    konumuna (VL02 dahil denge) piston alaniyla tasinir
  * tup ici sivi hacimleri (arka / on), bilya merkezi (oturma geometrisi kontrolu)
Akis yolu kesitleri parametrelerden (common.derive) hesaplanir ve burada tabloya yazilir.
"""
from __future__ import annotations

import sys

import math

import numpy as np
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common, BRepAlgoAPI_Cut
from OCP.BRepGProp import BRepGProp
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox, BRepPrimAPI_MakeCylinder
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt
from OCP.GProp import GProp_GProps
from OCP.STEPControl import STEPControl_Reader
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS

from common import ASM, ASSY_STEP, E, derive, iv, save, spring_mass


def load_step(path):
    r = STEPControl_Reader()
    if r.ReadFile(str(path)) != 1:
        raise IOError(path)
    r.TransferRoots()
    return r.OneShape()


def solids(shape):
    ex = TopExp_Explorer(shape, TopAbs_SOLID)
    out = []
    while ex.More():
        out.append(TopoDS.Solid_s(ex.Current()))
        ex.Next()
    return out


def vprops(s):
    g = GProp_GProps()
    BRepGProp.VolumeProperties_s(s, g)
    c = g.CentreOfMass()
    return g.Mass(), np.array([c.X(), c.Y(), c.Z()])


def cyl(r, z0, z1):
    return BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(0, 0, z0), gp_Dir(0, 0, 1)), r, z1 - z0).Shape()


def box(z0, z1, h=40):
    return BRepPrimAPI_MakeBox(gp_Pnt(-h, -h, z0), gp_Pnt(h, h, z1)).Shape()


def cut(a, b):
    op = BRepAlgoAPI_Cut(a, b)
    op.Build()
    return op.Shape()


def common(a, b):
    op = BRepAlgoAPI_Common(a, b)
    op.Build()
    return op.Shape()


def identify(sols):
    pv = {k: v for k, v in ASM["part_volumes"].items()}
    ids = {}
    used = set()
    for k, vs in pv.items():
        for vv in vs:
            best, bi = 1e9, None
            for i, s in enumerate(sols):
                if i in used:
                    continue
                v, c = vprops(s)
                if abs(v - vv) < best:
                    best, bi = abs(v - vv), i
            if bi is not None and best < max(0.5, 2e-3 * vv):
                key = k if k not in ids else k + "_2"
                ids[key] = bi
                used.add(bi)
    return ids


def main():
    g = derive()
    shape = load_step(ASSY_STEP)
    sols = solids(shape)
    ids = identify(sols)
    S = {k: sols[i] for k, i in ids.items()}
    out = {"n_solids": len(sols), "identified": sorted(ids)}
    vols = {k: vprops(s)[0] for k, s in S.items()}
    cents = {k: vprops(s)[1].tolist() for k, s in S.items()}
    out["volumes_mm3"] = vols
    out["centroids"] = {k: cents[k] for k in ("DR01", "VL01", "VL03", "VL02", "VL04") if k in cents}
    m, _ = spring_mass(g)
    out["mass_g"] = m
    # bilya merkezi: STEP (ctrl dinlenmesi) - model formulu
    z_ball_formula = E["z_dr01"] + g["dr01_tip"] - 0.72 + g["ball_c_above_edge"]
    out["ball_z_step"] = cents.get("VL01", [0, 0, float("nan")])[2]
    out["ball_z_formula_ctrl_rest"] = z_ball_formula
    # --- basinc odasi
    z0 = g["z_hs02"]
    z1 = g["z_seat_o"]
    fl = cyl(g["hs02_sl04_d"] / 2 + 0.6, z0, z1)
    for k in ("HS02", "DR01", "VL01", "VL02", "SL04", "VL03"):
        if k in S:
            fl = cut(fl, S[k])
    parts = sorted([vprops(s)[0] for s in solids(fl)], reverse=True)
    out["chamber_pieces_mm3"] = parts
    V_step = parts[0]
    out["V_ch_step_mm3"] = V_step
    dz = g["z_rest"] - E["z_dr01"]                                   # model dinlenmesi - STEP (ctrl) dinlenmesi
    out["V_ch_rest_mm3"] = V_step - g["A_p"] * dz
    out["V_ch_bore_mm3"] = math.pi / 4 * g["hs02_ch_d"] ** 2 * (g["hs02_ch_bot"] - 5.0) + math.pi / 4 * 6.2 ** 2 * 2.85
    out["dz_rest_model_minus_ctrl"] = dz
    from c3_model import analytic_chamber
    out["V_ch_analytic_base_mm3"] = analytic_chamber(g)[0] * 1e9
    zmax = g["z_stop_fwd"]
    out["V_ch_min_mm3"] = out["V_ch_rest_mm3"] - g["A_p"] * (zmax - g["z_rest"])
    # --- tup ici
    tube = cyl(g["hs01_bore_d"] / 2, g["z_hs01_bot"], g["z_hs05"])
    for k in ("DR01", "DR02", "DR03"):
        tube = cut(tube, S[k])
    zr = E["z_dr01"] - g["dr01_arm_len"]
    out["V_tube_total_step_mm3"] = sum(vprops(s)[0] for s in solids(tube))
    out["V_rear_step_mm3"] = sum(vprops(s)[0] for s in solids(common(tube, box(g["z_hs01_bot"] - 1, zr))))
    out["V_front_step_mm3"] = sum(vprops(s)[0] for s in solids(common(tube, box(E["z_dr01"], g["z_hs05"] + 1))))
    # --- akis yolu kesitleri (mm2) ve boylar
    pi4 = math.pi / 4
    t = lambda x, nd=2: f"{x:.{nd}f}".replace(".", ",")
    sec = [
        ("giriş hortumu Ø" + t(iv("hidrolik", "d_hose"), 1) + " (VAR)", pi4 * iv("hidrolik", "d_hose") ** 2, iv("hidrolik", "L_hose") * 1e3, "VAR"),
        ("HS01 nipel deliği Ø" + t(iv("hidrolik", "nip_bore_d"), 1), g["A_nip"], g["L_nip"], "CAD-T"),
        ("HS01 tüpü Ø" + t(g["hs01_bore_d"]) + " (armatürsüz)", g["A_t"], None, "CAD-K"),
        ("armatür / tüp halka aralığı " + t(g["gap_arm"]), math.pi * g["dr01_arm_d"] * g["gap_arm"], g["dr01_arm_len"], "CAD-K"),
        ("DR01 eksenel delik Ø" + t(g["dr01_bore_d"]), g["A_bore"], g["L_bore"], "CAD-K"),
        ("DR01 çapraz delik Ø5,15 (iki ağız)", g["A_x"], None, "CAD-K"),
        ("piston deliği Ø" + t(g["dr01_pin_id"]), g["A_pb"], g["L_pb"], "CAD-K"),
        ("VL01 oturma kenarı Ø" + t(2 * g["ball_seat_r"]), g["A_seat_b"], None, "CAD-K"),
        ("oda Ø" + t(g["hs02_ch_d"], 1) + " - piston Ø" + t(g["dp"]) + " halkası", g["A_ch"] - g["A_p"], None, "CAD-T"),
        ("çıkış oturması Ø" + t(g["hs02_seat_d"], 1), g["A_seat_o"], 0.8, "CAD-T"),
        ("VL03 başı Ø" + t(g["vl03_head_d"], 1) + " / valf deliği Ø6,0 halkası", pi4 * (36 - g["vl03_head_d"] ** 2), None, "CAD-T"),
        ("VL05 kafesi açık alanı", 23.514, g["vl05_t"], "CAD-T"),
        ("G1/8 çıkış (Ø8,52 delik)", pi4 * 8.52 ** 2, None, "CAD-K"),
    ]
    out["sections"] = [dict(name=n, A_mm2=a, L_mm=l, src=s) for n, a, l, s in sec]
    out["A_p_mm2"] = g["A_p"]
    out["V_disp_geom_mm3"] = g["A_p"] * (g["z_stop_fwd"] - (g["z_rest"] - g["stroke_mag_ref"]))
    save("geometry", out)
    for k, v in out.items():
        if k not in ("sections", "centroids", "volumes_mm3"):
            print(k, v)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
