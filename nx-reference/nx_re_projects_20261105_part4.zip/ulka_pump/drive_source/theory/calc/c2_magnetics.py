"""c2 - Manyetik devre: eksenel simetrik, dogrusal olmayan (doyan demir) magnetostatik cozum.

Esdeger manyetik devre burada elle kurulan bir direnc agi yerine, ayni devrenin (EM02 cerceve -> EM03-A burcu ->
radyal aralik -> DR01 armatur -> radyal aralik -> EM03-B burcu -> cerceve) r-z duzleminde sonlu hacimlerle
cozulmesidir: hava araliklari, sacak akilari ve armatur / burc doymasi dogrudan cikar.

Denklem: psi = r * A_phi (akı fonksiyonu; r yaricapli daireden gecen aki = 2 pi psi)
    div( nu/r grad psi ) = -J        (r-z duzleminde Kartezyen diverjans)
    B_z = (1/r) dpsi/dr ,  B_r = -(1/r) dpsi/dz
Sinir: psi = 0 eksende ve uzak sinirlarda.

Cikti tablolari (armatur arka yuzu z_rear ve amper-sarim NI uzerinde; N'den BAGIMSIZ):
    phi(z_rear, NI)   sarim basina aki baglantisi [Wb]  (bobin kesitinde 2 pi psi ortalamasi)
    F(z_rear, NI)     armature etkiyen eksenel kuvvet [N] (+z), ko-enerji turevinden: F = d/dz  int_0^NI phi dNI'
EM02 cercevesi eksenel simetrik degildir (iki serit): duvarlar r > em02_w/2'de serit kesitine esdeger kalinlikla,
dis kabuk ayni kesitle modellendi (VAR). Burcun yarigi (0,5) kesitten dusuldu (%0,8). Girdap akimlari yok.

Kullanim: python c2_magnetics.py [--quick]
"""
from __future__ import annotations

import math
import sys
import time

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from common import FIG, MU0, OUT, derive, iv, reg, save

AIR, ARM, STEEL = 0, 1, 2


def bh_nu_table(Js, mur):
    """Atan doyma modeli B = mu0 H + (2 Js/pi) atan(pi (mur-1) mu0 H / (2 Js)); nu(B) tablosu."""
    H = np.concatenate([[0.0], np.logspace(-1, 7, 3000)])
    B = MU0 * H + (2 * Js / math.pi) * np.arctan(math.pi * (mur - 1) * MU0 * H / (2 * Js))
    nu = np.empty_like(H)
    nu[1:] = H[1:] / B[1:]
    nu[0] = 1.0 / (mur * MU0)
    return B, nu


def lines(breaks, hfun):
    breaks = sorted(set(round(b, 6) for b in breaks))
    out = [breaks[0]]
    for a, b in zip(breaks[:-1], breaks[1:]):
        h = hfun(0.5 * (a + b))
        n = max(1, int(math.ceil((b - a) / h - 1e-9)))
        out += list(np.linspace(a, b, n + 1)[1:])
    return np.array(out)


class Model:
    def __init__(self, g, dz=0.2):
        self.g = g
        em02_rf = g["em02_out_x"] / 2                         # cerceve dis yari genisligi (X)
        t = g["em02_t"]
        w = g["em02_w"]
        A_strip = 2 * w * t                                   # iki serit kesiti (mm2)
        self.t_shell = A_strip / (2 * math.pi * (em02_rf - 0.6))
        self.r_shell0 = em02_rf - self.t_shell
        self.r_c1 = g["em01_bore_min_d"] / 2 + iv("bobin", "t_bobbin")
        self.r_c2 = g["em01_body_d"] / 2 - iv("bobin", "t_over")
        self.z_c1 = g["z_em01_far"] + iv("bobin", "t_end")
        self.z_c2 = g["z_em01_term"] - iv("bobin", "t_end")
        self.A_coil = (self.r_c2 - self.r_c1) * (self.z_c2 - self.z_c1)           # mm2
        self.l_mt = math.pi * (self.r_c1 + self.r_c2)                              # ortalama sarim boyu mm
        rarm_i, rarm_o = g["dr01_bore_d"] / 2, g["dr01_arm_d"] / 2
        self.rarm_i, self.rarm_o = rarm_i, rarm_o
        rs_i, rs_o = g["em03_id"] / 2, g["em03_od"] / 2
        self.rs_i, self.rs_o = rs_i, rs_o
        rh_out, rh_in = g["em02_hole_out_d"] / 2, g["em02_hole_in_d"] / 2
        rbreaks = [0, rarm_i, g["dr01_rpilot_d"] / 2, g["dr01_fpilot_d"] / 2, rarm_o, rs_i, rh_in, rs_o, rh_out,
                   self.r_c1, w / 2, self.r_c2, self.r_shell0, em02_rf, em02_rf + 6, em02_rf + 18]

        def hr(r):
            if rs_o - 0.1 < r < rh_out + 0.1:
                return 0.04
            if r < rs_o:
                return 0.25
            if r < em02_rf + 0.5:
                return 0.6
            return 3.0
        self.r = lines(rbreaks, hr)
        zb = [g["z_em02_in_out"], g["z_em02_in_in"], g["z_em03a_bot"], g["z_hs04_bot"], g["z_hs04_top"],
              g["z_em03b_top"], g["z_em02_out_in"], g["z_em02_out"], self.z_c1, self.z_c2,
              -57.0, 9.0, -80.0, 30.0]

        def hz(z):
            return dz if -57.0 <= z <= 9.0 else 2.5
        self.z = lines(zb, hz)
        self.nr, self.nz = len(self.r), len(self.z)
        self.dr = np.diff(self.r)
        self.dzc = np.diff(self.z)
        self.rc = 0.5 * (self.r[:-1] + self.r[1:])
        self.zc = 0.5 * (self.z[:-1] + self.z[1:])
        RC, ZC = np.meshgrid(self.rc, self.zc, indexing="ij")
        self.RC, self.ZC = RC, ZC
        # sabit malzeme (burclar, cerceve)
        mat = np.zeros(RC.shape, dtype=np.int8)
        slit = 1.0 - g["em03_slit_w"] / (math.pi * (rs_i + rs_o))
        self.steel_frac = np.zeros(RC.shape)
        for zb0, zb1 in ((g["z_em03a_bot"], g["z_hs04_bot"]), (g["z_hs04_top"], g["z_em03b_top"])):
            m = (RC > rs_i) & (RC < rs_o) & (ZC > zb0) & (ZC < zb1)
            mat[m] = STEEL
            self.steel_frac[m] = slit
        # cerceve duvarlari: r < w/2 tam levha, r > w/2 serit kesitine esdeger kalinlik (dis yuzden iceri)
        teq = np.where(RC < w / 2, t, np.minimum(t, A_strip / (2 * math.pi * np.maximum(RC, 1e-6))))
        mo = (RC > rh_out) & (RC < em02_rf) & (ZC > g["z_em02_out"] - teq) & (ZC < g["z_em02_out"])
        mi = (RC > rh_in) & (RC < em02_rf) & (ZC > g["z_em02_in_out"]) & (ZC < g["z_em02_in_out"] + teq)
        ms = (RC > self.r_shell0) & (RC < em02_rf) & (ZC > g["z_em02_in_out"]) & (ZC < g["z_em02_out"])
        for m in (mo, mi, ms):
            mat[m] = STEEL
            self.steel_frac[m] = 1.0
        self.mat0 = mat
        # bobin
        self.coil = (RC > self.r_c1) & (RC < self.r_c2) & (ZC > self.z_c1) & (ZC < self.z_c2)
        self.cellA = np.outer(self.dr, self.dzc)
        self.Bs_arm, self.nu_arm = bh_nu_table(iv("malzeme", "arm_Js"), iv("malzeme", "arm_mur"))
        self.Bs_st, self.nu_st = bh_nu_table(iv("malzeme", "steel_Js"), iv("malzeme", "steel_mur"))
        self._index()

    def _index(self):
        nr, nz = self.nr, self.nz
        idx = -np.ones((nr, nz), dtype=np.int64)
        inner = np.zeros((nr, nz), bool)
        inner[1:-1, 1:-1] = True
        idx[inner] = np.arange(inner.sum())
        self.idx, self.n = idx, int(inner.sum())

    def arm_fraction(self, z_rear):
        """Armaturun hucre doluluk orani (z'de kismi), arka ve on pilotlar dahil."""
        g = self.g
        zlo, zhi = self.z[:-1], self.z[1:]

        def zfrac(a, b):
            return np.clip((np.minimum(zhi, b) - np.maximum(zlo, a)) / (zhi - zlo), 0, 1)
        f = np.zeros((self.nr - 1, self.nz - 1))
        rlo, rhi = self.r[:-1], self.r[1:]

        def rmask(a, b):
            return ((self.rc > a) & (self.rc < b))[:, None]
        L = g["dr01_arm_len"]
        f += rmask(self.rarm_i, self.rarm_o) * zfrac(z_rear, z_rear + L)[None, :]
        f += rmask(self.rarm_i, g["dr01_rpilot_d"] / 2) * zfrac(z_rear - g["dr01_rear_len"], z_rear)[None, :]
        f += rmask(self.rarm_i, g["dr01_fpilot_d"] / 2) * zfrac(z_rear + L, z_rear + L + 1.24)[None, :]
        return np.clip(f, 0, 1)

    def _cells(self):
        """Hucre -> 4 kose dugumu (bilinmeyen indeksi, sinirda -1) ve yerel enerji matrisi katsayilari."""
        if hasattr(self, "_cn"):
            return
        nr, nz = self.nr, self.nz
        I, J = np.meshgrid(np.arange(nr - 1), np.arange(nz - 1), indexing="ij")
        self._cn = np.stack([self.idx[I, J], self.idx[I + 1, J], self.idx[I, J + 1], self.idx[I + 1, J + 1]], -1)
        dr = np.diff(self.r * 1e-3)[:, None] * np.ones((1, nz - 1))
        dz = np.diff(self.z * 1e-3)[None, :] * np.ones((nr - 1, 1))
        cx, cy = dz / (2 * dr), dr / (2 * dz)
        S = np.zeros((nr - 1, nz - 1, 4, 4))
        for (p, q) in ((0, 1), (2, 3)):
            S[..., p, p] += cx; S[..., q, q] += cx; S[..., p, q] -= cx; S[..., q, p] -= cx
        for (p, q) in ((0, 2), (1, 3)):
            S[..., p, p] += cy; S[..., q, q] += cy; S[..., p, q] -= cy; S[..., q, p] -= cy
        self._S0 = S
        self._area = dr * dz
        self._rc = self.RC * 1e-3
        cn = self._cn
        rr = np.repeat(cn[..., :, None], 4, -1)
        cc = np.repeat(cn[..., None, :], 4, -2)
        m = (rr >= 0) & (cc >= 0)
        self._rr, self._cc, self._m = rr[m], cc[m], m

    def rhs(self, NI):
        self._cells()
        J = np.where(self.coil, NI / (self.A_coil * 1e-6), 0.0)
        load = J * self._area / 4.0
        b = np.zeros(self.n)
        for k in range(4):
            n = self._cn[..., k]
            m = n >= 0
            np.add.at(b, n[m], load[m])
        return b

    def _local_psi(self, x):
        xe = np.concatenate([x, [0.0]])
        return xe[self._cn]                        # -1 -> son eleman 0

    def _mat(self, farm):
        """Hucre gecirgenligi ve d(nu)/d(B^2), B^2 hucre enerji formundan."""
        st = self.mat0 == STEEL
        sf = np.where(st, self.steel_frac, 1.0)

        def f(B2):
            B = np.sqrt(B2)
            nu_a = np.interp(B, self.Bs_arm, self.nu_arm)
            Bs = B / sf
            nu_s = np.interp(Bs, self.Bs_st, self.nu_st)
            eps = 1e-4
            dnu_a = (np.interp(B + eps, self.Bs_arm, self.nu_arm) - np.interp(np.maximum(B - eps, 0), self.Bs_arm, self.nu_arm)) / (
                (B + eps) - np.maximum(B - eps, 0))
            dnu_s = (np.interp(Bs + eps, self.Bs_st, self.nu_st) - np.interp(np.maximum(Bs - eps, 0), self.Bs_st, self.nu_st)) / (
                (Bs + eps) - np.maximum(Bs - eps, 0)) / sf
            mu_a, mu_s = 1 / nu_a, 1 / nu_s
            mu = (1 - farm) * MU0 + farm * mu_a
            dmu = farm * (-mu_a ** 2) * dnu_a                          # d mu / dB
            mu = np.where(st, sf * mu_s + (1 - sf) * MU0, mu)
            dmu = np.where(st, sf * (-mu_s ** 2) * dnu_s, dmu)
            nu = 1 / mu
            dnu_dB = -dmu / mu ** 2
            dnu_dB2 = np.where(B > 1e-9, dnu_dB / (2 * np.maximum(B, 1e-9)), 0.0)
            return nu, dnu_dB2
        return f

    def solve(self, z_rear, NI, x0=None, tol=1e-7, itmax=60):
        self._cells()
        farm = self.arm_fraction(z_rear)
        matf = self._mat(farm)
        b = self.rhs(NI)
        x = np.zeros(self.n) if x0 is None else x0.copy()
        S0, area, rc = self._S0, self._area, self._rc

        def residual(x):
            pl = self._local_psi(x)
            Sp = np.einsum("...ij,...j->...i", S0, pl)
            B2 = np.einsum("...i,...i->...", pl, Sp) / (area * rc ** 2)
            nu, dnu = matf(B2)
            Rl = (nu / rc)[..., None] * Sp
            R = np.zeros(self.n)
            for k in range(4):
                n = self._cn[..., k]
                m = n >= 0
                np.add.at(R, n[m], Rl[..., k][m])
            return R - b, pl, Sp, nu, dnu
        R, pl, Sp, nu, dnu = residual(x)
        r0 = np.linalg.norm(b) + 1e-30
        it = 0
        for it in range(1, itmax + 1):
            Kl = (nu / rc)[..., None, None] * S0 + (2 * dnu / (area * rc ** 3))[..., None, None] * Sp[..., :, None] * Sp[..., None, :]
            K = sp.csc_matrix((Kl[self._m], (self._rr, self._cc)), shape=(self.n, self.n))
            dx = spla.spsolve(K, -R)
            nR = np.linalg.norm(R)
            lam = 1.0
            while True:
                Rn, pln, Spn, nun, dnun = residual(x + lam * dx)
                if np.linalg.norm(Rn) < nR or lam < 1 / 64:
                    break
                lam *= 0.5
            x = x + lam * dx
            R, pl, Sp, nu, dnu = Rn, pln, Spn, nun, dnun
            if np.linalg.norm(R) / r0 < tol or np.linalg.norm(lam * dx) < 1e-9 * (np.linalg.norm(x) + 1e-30):
                break
        psi = np.zeros((self.nr, self.nz))
        psi[1:-1, 1:-1] = x.reshape(self.nr - 2, self.nz - 2)
        res = np.linalg.norm(R) / r0
        return self.coil_flux(psi), psi, x, it, res

    def bmag(self, psi):
        r = self.r * 1e-3
        z = self.z * 1e-3
        dr = np.diff(r)[:, None]
        dz = np.diff(z)[None, :]
        dpdr = ((psi[1:, :-1] + psi[1:, 1:]) - (psi[:-1, :-1] + psi[:-1, 1:])) / (2 * dr)
        dpdz = ((psi[:-1, 1:] + psi[1:, 1:]) - (psi[:-1, :-1] + psi[1:, :-1])) / (2 * dz)
        rc = self.RC * 1e-3
        return np.hypot(dpdr, dpdz) / rc

    def bfield(self, psi):
        r = self.r * 1e-3
        z = self.z * 1e-3
        dr = np.diff(r)[:, None]
        dz = np.diff(z)[None, :]
        dpdr = ((psi[1:, :-1] + psi[1:, 1:]) - (psi[:-1, :-1] + psi[:-1, 1:])) / (2 * dr)
        dpdz = ((psi[:-1, 1:] + psi[1:, 1:]) - (psi[:-1, :-1] + psi[1:, :-1])) / (2 * dz)
        rc = self.RC * 1e-3
        return -dpdz / rc, dpdr / rc

    def coil_flux(self, psi):
        pc = 0.25 * (psi[:-1, :-1] + psi[1:, :-1] + psi[:-1, 1:] + psi[1:, 1:])
        A = self.cellA * self.coil
        return float(2 * math.pi * (pc * A).sum() / A.sum())


def main(quick=False):
    g = derive()
    t0 = time.time()
    M = Model(g, dz=iv("sayisal", "fem_dz"))
    print(f"ag: {M.nr} x {M.nz} = {M.n} bilinmeyen; bobin penceresi {M.A_coil:.1f} mm2, l_mt {M.l_mt:.1f} mm")
    xs = iv("sayisal", "fem_x_step")
    z_lo = math.floor((g["z_rear_rest"] - 15.0) / xs) * xs
    z_hi = math.ceil((g["z_stop_fwd"] - g["dr01_arm_len"] + 1.0) / xs) * xs
    zr = np.arange(z_lo, z_hi + 1e-9, xs)
    NIs = np.linspace(0, iv("sayisal", "fem_NI_max"), int(iv("sayisal", "fem_NI_n")))
    if quick:
        zr = zr[::6]
        NIs = NIs[::3]
    phi = np.zeros((len(zr), len(NIs)))
    iters = np.zeros_like(phi)
    resid = np.zeros_like(phi)
    Bmax_arm = np.zeros_like(phi)
    keep = {}
    for i, zz in enumerate(zr):
        x0 = None
        for j, NI in enumerate(NIs):
            if NI == 0:
                continue
            ph, psi, xs_, it, ch = M.solve(zz, NI, x0=None if x0 is None else x0 * NI / NIs[j - 1])
            x0 = xs_
            resid[i, j] = ch
            phi[i, j] = ph
            iters[i, j] = it
            farm = M.arm_fraction(zz)
            Bm = M.bmag(psi)
            Bmax_arm[i, j] = float(np.percentile(Bm[farm > 0.9], 99)) if (farm > 0.9).any() else 0
            if j == len(NIs) - 1 or abs(NI - 1800) < 1:
                keep[(round(zz, 3), NI)] = psi.copy()
        print(f"  z_rear {zz:7.2f}: phi(NImax) {phi[i, -1] * 1e6:8.2f} uWb  iter {iters[i].max():.0f}  "
              f"Bmax {Bmax_arm[i, -1]:.2f} T  res {resid[i].max():.1e}  ({time.time() - t0:.0f} s)", flush=True)
    # ko-enerji ve kuvvet
    Wc = np.zeros_like(phi)
    Wc[:, 1:] = np.cumsum(0.5 * (phi[:, 1:] + phi[:, :-1]) * np.diff(NIs)[None, :], axis=1)
    F = np.gradient(Wc, zr * 1e-3, axis=0)                     # N, +z
    np.savez(OUT / "mag_tables.npz", z_rear=zr, NI=NIs, phi=phi, F=F, Wc=Wc, Bmax_arm=Bmax_arm, iters=iters)
    # dogrusal kontrol: demir sonsuz gecirgen, yalniz iki radyal aralik (analitik, karsilastirma icin)
    gap = (M.rs_i - M.rarm_o) * 1e-3
    Dm = (M.rs_i + M.rarm_o) * 1e-3
    out = dict(grid=[M.nr, M.nz, M.n], A_coil_mm2=M.A_coil, l_mt_mm=M.l_mt, r_c=[M.r_c1, M.r_c2], z_c=[M.z_c1, M.z_c2],
               t_shell=M.t_shell, radial_gap_mm=gap * 1e3, z_rear=list(zr), NI=list(NIs), quick=quick,
               runtime_s=time.time() - t0, iter_max=float(iters.max()), resid_max=float(resid.max()))
    # linear permeance at rest (small NI) and analytic
    i_rest = int(np.argmin(abs(zr - g["z_rear_rest"])))
    out["P_lin_rest_uH"] = phi[i_rest, 1] / NIs[1] * 1e6
    ov_b = min(g["z_em03b_top"], g["z_rear_rest"] + g["dr01_arm_len"]) - max(g["z_hs04_top"], g["z_rear_rest"])
    out["overlap_B_rest"] = ov_b
    out["P_gapB_analytic_uH"] = MU0 * 2 * math.pi * ov_b * 1e-3 / math.log(M.rs_i / M.rarm_o) * 1e6
    save("magnetics", out)
    # sekiller
    plot(M, g, zr, NIs, phi, F, Bmax_arm, keep)
    print(f"bitti {time.time() - t0:.0f} s")


def plot(M, g, zr, NIs, phi, F, Bmax, keep):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    x = zr - g["z_rear_rest"]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
    for j in range(1, len(NIs), max(1, len(NIs) // 6)):
        ax[0].plot(x, -F[:, j], label=f"NI = {NIs[j]:.0f} A")
        ax[1].plot(x, phi[:, j] * 1e6, label=f"NI = {NIs[j]:.0f} A")
    ax[0].axvline(0, color="k", lw=0.6, ls=":")
    ax[0].axvline(-g["stroke_mag_ref"], color="r", lw=0.6, ls=":")
    ax[0].set_xlabel("armatür konumu x (dinlenmeden, + çıkışa) [mm]")
    ax[0].set_ylabel("manyetik çekme kuvveti -F_z (girişe doğru) [N]")
    ax[0].grid(alpha=0.3); ax[0].legend(fontsize=7)
    ax[0].set_title("Kuvvet (ko-enerji türevi)")
    ax[1].set_xlabel("x [mm]"); ax[1].set_ylabel("sarım başına akı φ [µWb]")
    ax[1].grid(alpha=0.3); ax[1].set_title("Akı (doyma dahil)")
    fig.tight_layout(); fig.savefig(FIG / "m2_kuvvet_aki.png", dpi=140); plt.close(fig)
    # alan resmi: dinlenmede, NImax
    if keep:
        key = min(keep, key=lambda k: (abs(k[0] - g["z_rear_rest"]), -k[1]))
        psi = keep[key]
        Br, Bz = M.bfield(psi)
        Bm = np.hypot(Br, Bz)
        fig, ax = plt.subplots(figsize=(6.2, 8))
        RR, ZZ = np.meshgrid(M.r, M.z, indexing="ij")
        pc = ax.pcolormesh(M.r, M.z, Bm.T, cmap="magma", vmin=0, vmax=2.0, shading="flat")
        ax.contour(RR, ZZ, psi, 25, colors="w", linewidths=0.4)
        fig.colorbar(pc, ax=ax, label="|B| [T]")
        ax.set_xlim(0, 32); ax.set_ylim(-55, 6); ax.set_aspect("equal")
        ax.set_xlabel("r [mm]"); ax.set_ylabel("z [mm]")
        ax.set_title(f"|B| ve akı çizgileri, z_arka = {key[0]:.2f}, NI = {key[1]:.0f} A")
        fig.tight_layout(); fig.savefig(FIG / "m1_alan.png", dpi=140); plt.close(fig)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main(quick="--quick" in sys.argv)
