"""c4 - Bobin kalibrasyonu (N, R) ve Q-p egrisi; E5 egrisiyle karsilastirma; cevrim izleri.

R olculmediyse: R(N) = rho_cu N^2 l_mt / (k_fill A_w) (sargi penceresi c2'den) ve N, kalibrasyon basinclarindaki
ortalama giris gucu 48 W olacak sekilde bulunur (TURETILDI). R olculduyse N yine 48 W'tan bulunur, R olculen.
"""
from __future__ import annotations

import math
import sys
import time

import numpy as np

from c3_model import MagTables, build, coil_R_from_N, run_many, simulate, wire_d_from_N
from common import CURVE_P, CURVE_Q, FIG, INP, curve_Q, derive, iv, load, save


def set_coil(P, N):
    P["N"] = N
    Rm = INP["usta_olcum"]["R_coil"]["value"]
    if Rm is not None:
        T = iv("bobin", "T_cu")
        P["R"] = Rm * (1 + iv("malzeme", "alpha_cu") * (T - 20.0))
    else:
        P["R"] = coil_R_from_N(N)
    return P


def calibrate(P, M, verbose=True, base_job=None):
    pts = iv("bobin", "P_cal_points")
    target = iv("bobin", "P_rated")
    base_job = base_job or {}

    def Pmean(N):
        set_coil(P, N)
        jobs = [dict(base_job, N=N, R=P["R"], p=p) for p in pts]
        r = [x["P_in"] for x in run_many(jobs)]
        if verbose:
            print(f"   N {N:7.0f}  R {P['R']:6.1f}  P_in {['%.1f' % x for x in r]}", flush=True)
        return float(np.mean(r))
    # log N uzerinde sekant
    if INP["usta_olcum"]["R_coil"]["value"] is not None:
        N0 = 4000.0
    else:
        N0 = math.sqrt(250.0 / coil_R_from_N(1.0))
    x0, x1 = math.log(N0), math.log(N0 * 0.85)
    f0, f1 = Pmean(math.exp(x0)) - target, Pmean(math.exp(x1)) - target
    for _ in range(12):
        if abs(f1) < 0.6 or f1 == f0:
            break
        x2 = x1 - f1 * (x1 - x0) / (f1 - f0)
        x2 = max(min(x2, x1 + 0.4), x1 - 0.4)
        x0, f0 = x1, f1
        x1 = x2
        f1 = Pmean(math.exp(x1)) - target
    N = math.exp(x1)
    set_coil(P, N)
    return N, P["R"], f1 + target


def qp_curve(P, ps, verbose=True, base_job=None):
    jobs = [dict(base_job or {}, N=P["N"], R=P["R"], p=p) for p in ps]
    rows = run_many(jobs)
    if verbose:
        for r in rows:
            p = r["p_bar"]
            print(f"   p {p:5.1f} bar  Q {r['Q_ccmin']:7.1f} (sd {r['Q_std_ccmin']:6.1f})  E5 {curve_Q(p) if p <= 15 else 0:5.0f}  "
                  f"strok {r['stroke']:5.2f} [{r['z_min']:6.2f},{r['z_max']:5.2f}]  P {r['P_in']:5.1f} W  "
                  f"eta_v {r['eta_v']:.2f}  ({r['nfev']} fev)", flush=True)
    return rows


def stall_pressure(rows):
    ps = [r["p_bar"] for r in rows]
    qs = [r["Q_ccmin"] for r in rows]
    for k in range(len(ps) - 1):
        if qs[k] > 0 >= qs[k + 1]:
            return ps[k] + (ps[k + 1] - ps[k]) * qs[k] / (qs[k] - qs[k + 1])
    return float("nan") if qs[-1] <= 0 else float("inf")


def main(fast=False):
    g = derive()
    P = build(g)
    M = MagTables()
    t0 = time.time()
    print("kalibrasyon (48 W):")
    N, R, Pc = calibrate(P, M)
    print(f"N = {N:.0f}, R = {R:.1f} ohm, P = {Pc:.2f} W, tel ~ {wire_d_from_N(N):.3f} mm  ({time.time() - t0:.0f} s)")
    ps = [float(x) for x in CURVE_P] + [16.0, 17.0, 18.0, 20.0]
    print("Q-p:")
    rows = qp_curve(P, ps)
    p_stall = stall_pressure(rows)
    print("traces:")
    trs = run_many([dict(N=P["N"], R=P["R"], p=p, trace=True) for p in (0.0, 7.0, 14.0)])
    tr = {str(r["p_bar"]): r for r in trs}
    out = dict(N=N, R=R, P_cal=Pc, wire_d=wire_d_from_N(N), R_measured=INP["usta_olcum"]["R_coil"]["value"] is not None,
               rows=rows, p_stall=p_stall,
               traces={k: {kk: vv for kk, vv in v.items() if kk != "trace"} for k, v in tr.items()},
               m_a=P["m_a"], m_b=P["m_b"], m_o=P["m_o"], m_fluid=P["m_fluid"], I_in=P["I_in"], I_pb=P["I_pb"],
               C_r=P["C_r"], C_f=P["C_f"], Vc_rest=P["Vc_rest"], wall_ch=P["wall_ch"], Kc_rf=P["Kc_rf"])
    # karsilastirma
    cmp = []
    for r in rows:
        if r["p_bar"] <= 15:
            q = curve_Q(r["p_bar"])
            cmp.append(dict(p=r["p_bar"], Q_model=r["Q_ccmin"], Q_E5=q, dQ=r["Q_ccmin"] - q,
                            rel=(r["Q_ccmin"] - q) / q if q > 0 else None))
    out["cmp"] = cmp
    dev = [abs(c["dQ"]) for c in cmp]
    out["rms_dev"] = float(np.sqrt(np.mean(np.square([c["dQ"] for c in cmp]))))
    out["max_dev"] = float(max(dev))
    save("qp", out)
    np.savez_compressed(__import__("common").OUT / "traces.npz",
                        **{f"{k}__{kk}": np.array(vv) for k, v in tr.items() for kk, vv in v["trace"].items()})
    plot(out, tr, g)
    print(f"p_stall {p_stall:.2f} bar, rms sapma {out['rms_dev']:.0f} cm3/dk  ({time.time() - t0:.0f} s)")


def plot(out, tr, g):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rows = out["rows"]
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.plot(CURVE_Q, CURVE_P, "o-", color="#1f77b4", label="E5 datasheet")
    ax.errorbar([r["Q_ccmin"] for r in rows], [r["p_bar"] for r in rows], xerr=[r["Q_std_ccmin"] / 10 ** 0.5 for r in rows],
                fmt="s-", color="#d62728", capsize=2, label="model, taban (türetilmiş girdiler); çubuk: ortalamanın std hatası")
    Vg = load("geometry")["V_disp_geom_mm3"] * 50 * 60 / 1000
    ax.axvline(Vg, color="gray", ls=":", lw=1)
    ax.text(Vg, 18.6, " referans: A_p × (EM03-A kenarı -> ileri dayanma) × 50 Hz\n (geride sert dayanma yok; strok bunu aşabilir)",
            fontsize=7, color="gray", va="top", ha="right")
    ax.set_xlabel("debi [cm³/dk]"); ax.set_ylabel("basınç [bar]")
    ax.set_xlim(0, 760); ax.set_ylim(0, 20.5); ax.grid(alpha=0.3); ax.legend()
    ax.set_title("Q-p: model / E5")
    fig.tight_layout(); fig.savefig(FIG / "q1_qp.png", dpi=150); plt.close(fig)
    # cevrim izleri
    fig, ax = plt.subplots(4, 1, figsize=(8, 9.5), sharex=True)
    for k, v in tr.items():
        t = np.array(v["trace"]["t"]) * 1e3
        ax[0].plot(t, (np.array(v["trace"]["zf"]) * 1e3 - g["z_rest"]), label=f"{float(k):.0f} bar")
        ax[1].plot(t, np.array(v["trace"]["i"]), label=f"{float(k):.0f} bar")
        ax[2].plot(t, (np.array(v["trace"]["pc"]) - 101325) / 1e5, label=f"oda {float(k):.0f} bar")
        ax[3].plot(t, np.array(v["trace"]["Qout"]) * 6e7 / 1000, label=f"Q_çıkış {float(k):.0f} bar")
    u = np.array(tr["0.0"]["trace"]["u"])
    ax1 = ax[1].twinx(); ax1.plot(np.array(tr["0.0"]["trace"]["t"]) * 1e3, u, color="gray", lw=0.6); ax1.set_ylabel("u [V]", color="gray")
    ax[0].set_ylabel("x = z_f - z_dinlenme [mm]"); ax[1].set_ylabel("akım i [A]")
    ax[2].set_ylabel("oda basıncı [bar g]"); ax[3].set_ylabel("Q_çıkış [L/dk anlık]")
    ax[3].set_xlabel("t [ms] (bir şebeke periyodu)")
    for a in ax:
        a.grid(alpha=0.3); a.legend(fontsize=7, loc="upper right")
    fig.tight_layout(); fig.savefig(FIG / "l1_cevrim.png", dpi=140); plt.close(fig)
    fig, ax = plt.subplots(figsize=(7, 3.8))
    ps = [r["p_bar"] for r in rows]
    ax.plot(ps, [r["P_in"] for r in rows], "o-", label="giriş gücü P [W]")
    ax.plot(ps, [r["stroke"] * 4 for r in rows], "s-", label="strok × 4 [mm]")
    ax.plot(ps, [r["eta_v"] * 50 for r in rows], "^-", label="hacimsel verim × 50")
    ax.axhline(48, color="gray", ls=":")
    ax.set_xlabel("basınç [bar]"); ax.grid(alpha=0.3); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(FIG / "q2_guc_strok.png", dpi=140); plt.close(fig)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
