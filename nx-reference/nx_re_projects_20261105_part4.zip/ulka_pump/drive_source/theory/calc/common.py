"""ULKA EP5 teori hesaplari - ortak girdiler, parametre kaydi ve turetilen geometri.

Tek girdi dosyasi: inputs.json (Usta'nin 6 olcumu + varsayimlar). Kontrol parcasi (Rev H) degerleri canli
dosyadan okunur. Bu modul kontrol parcasini DEGISTIRMEZ; yalniz okur ve Usta'nin olcumleriyle (varsa) kendi
icinde zinciri yeniden kurar (armatur dinlenme konumu, yay boylari, oda hacmi).

Birimler: geometri mm (girdi), model SI (m, kg, s, Pa). Basinclar raporda bar.
Kaynak kodlari: CAD-K / CAD-T / STEP / DS / LIT / VAR / USTA / FIT (inputs.json _doc).
"""
from __future__ import annotations

import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
THEORY = HERE.parent
ROOT = HERE.parents[1]                       # ...\ulka re
INPUTS = HERE / "inputs"
OUT = HERE / "out"
FIG = THEORY / "fig"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

NX_CTRL = Path(r"C:\NX_MCP_WORKSPACE\ulka\ctrl")
ASSY_STEP = ROOT / "cad" / "assembly" / "EP5-AS00_ASSY.stp"


def _load(name: str, live: Path) -> dict:
    p = live if live.exists() else INPUTS / name
    return json.loads(p.read_text(encoding="utf-8"))


E = _load("ctrl_values_py.json", NX_CTRL / "ctrl_values_py.json")          # Rev H expression degerleri
CTRL_REV = _load("ctrl_build.json", NX_CTRL / "ctrl_build.json").get("rev", "?")
ASM = _load("asm_build.json", ROOT / "cad" / "assembly" / "asm_build.json")
INP = json.loads((HERE / "inputs.json").read_text(encoding="utf-8"))


def load(name):
    return json.loads((OUT / f"{name}.json").read_text(encoding="utf-8"))


def save(name, data):
    (OUT / f"{name}.json").write_text(json.dumps(data, indent=1, ensure_ascii=False, default=float), encoding="utf-8")


def tr(x, nd=2):
    """Turkce ondalik virgul."""
    if x is None:
        return "-"
    if isinstance(x, str):
        return x
    s = f"{x:.{nd}f}"
    if s.startswith("-") and float(s) == 0:
        s = s[1:]
    return s.replace(".", ",")


# --------------------------------------------------------------------------- girdi okuma
def iv(group, name):
    return INP[group][name]["value"]


def usta(name):
    """Usta'nin olcumu varsa onu, yoksa turetilen degeri dondurur; ikinci deger kaynak kodu."""
    it = INP["usta_olcum"][name]
    if it["value"] is not None:
        return it["value"], "USTA"
    return it["derived"], it["src"]


MEASURED = {k: v["value"] is not None for k, v in INP["usta_olcum"].items()}

# --------------------------------------------------------------------------- sabitler (SI)
RHO = iv("hidrolik", "rho")
MU = iv("hidrolik", "mu")
P_ATM = iv("hidrolik", "p_atm")
P_VAP = iv("hidrolik", "p_vap")
K_W = iv("hidrolik", "K_water")
G0 = 9.80665
MU0 = 4e-7 * math.pi
F_LINE = iv("bobin", "f_line")


def k_helical(G_mpa, d, Dm, na):
    """Helisel bası yayı sabiti N/mm (G MPa, d, Dm mm)."""
    return G_mpa * d ** 4 / (8.0 * Dm ** 3 * na)


def _smooth_dm3(dm1, dm2, n=400):
    """D modellerindeki smoothstep konik gecisin ortalama Dm^3'u (aktif sarim basina)."""
    s = 0.0
    for k in range(n):
        t = (k + 0.5) / n
        u = t * t * (3 - 2 * t)
        s += (dm1 + (dm2 - dm1) * u) ** 3
    return s / n


# --------------------------------------------------------------------------- parametre kaydi
PARAMS: dict[str, tuple] = {}


def reg(name, value, unit, src, note):
    PARAMS[name] = (value, unit, src, note)
    return value


def derive():
    """Butun model geometrisini ve zinciri kurar; dict (mm, N/mm, mm3, g) dondurur ve PARAMS'i doldurur."""
    PARAMS.clear()
    g = {}
    # --- Usta olcumleri (ya da turetilenler)
    v, s = usta("dp"); g["dp"] = reg("dp", v, "mm", s, "piston dis capi d_p (A_OLCUM #1)")
    v, s = usta("hs01_depth_mouth")
    g["hs01_depth_mouth"] = reg("hs01_depth_mouth", v, "mm", s, "HS01 soket agzi -> tup ic dibi (A_OLCUM #2)")
    g["hs01_inner_bot"] = reg("hs01_inner_bot", v - E["hs01_lip_h"], "mm", s, "HS01 flans ustu -> tup ic dibi")
    for nm in ("hs02_ch_d", "hs02_ch_bot", "hs02_seat_d", "vl02_d", "vl02_l0", "vl02_na", "vl04_d", "vl04_l0", "vl04_na"):
        v, s = usta(nm)
        g[nm] = reg(nm, v, INP["usta_olcum"][nm]["unit"], s, INP["usta_olcum"][nm]["note"])

    # --- kontrol parcasindan dogrudan (CAD-K / CAD-T)
    for nm, src in [("z_hs01_flange", "CAD-T"), ("z_hs05", "CAD-T"), ("z_hs02", "CAD-T"), ("hs01_bore_d", "CAD-K"),
                    ("hs01_lip_h", "CAD-K"), ("dr01_arm_d", "CAD-K"), ("dr01_arm_len", "CAD-K"), ("dr01_tip", "CAD-K"),
                    ("dr01_collar_d", "CAD-K"), ("dr01_collar_front", "CAD-K"), ("dr01_fpilot_d", "CAD-K"),
                    ("dr01_rpilot_d", "CAD-K"), ("dr01_rear_len", "CAD-K"), ("dr01_bore_d", "CAD-K"),
                    ("dr01_pin_id", "CAD-K"), ("dr01_seat_d", "CAD-K"), ("dr02_d", "USTA"), ("dr02_od", "CAD-K"),
                    ("dr02_l0", "CAD-K"), ("dr02_na", "CAD-T"), ("dr02_nt", "CAD-K"), ("dr03_d", "USTA"),
                    ("dr03_od", "CAD-K"), ("dr03_l0", "CAD-K"), ("dr03_na", "CAD-T"), ("dr03_nt", "CAD-K"),
                    ("vl01_d", "CAD-K"), ("vl03_head_d", "CAD-K"), ("vl03_head_r", "CAD-K"),
                    ("hs02_sl04_d", "CAD-K"), ("hs02_sl04_depth", "CAD-K"), ("hs02_out_d", "CAD-K"),
                    ("hs02_out_floor", "CAD-K"), ("hs02_vl05_z", "CAD-T"), ("vl05_t", "CAD-K"), ("hs05_hole_d", "CAD-K"),
                    ("hs01_tube_od", "CAD-K"), ("em03_od", "CAD-K"), ("em03_id", "CAD-K"), ("em03_len", "CAD-K"),
                    ("em03_slit_w", "CAD-T"), ("hs04_h", "CAD-K"), ("z_em03a_bot", "CAD-K"), ("z_hs04_bot", "CAD-K"),
                    ("z_hs04_top", "CAD-K"), ("z_em03b_top", "CAD-K"), ("z_em02_out", "CAD-K"), ("z_em02_out_in", "CAD-K"),
                    ("z_em02_in_in", "CAD-K"), ("z_em02_in_out", "CAD-K"), ("em02_hole_out_d", "CAD-K"),
                    ("em02_hole_in_d", "CAD-K"), ("em02_out_x", "CAD-K"), ("em02_w", "CAD-K"), ("em02_t", "CAD-K"),
                    ("em01_body_d", "CAD-K"), ("em01_len", "CAD-K"), ("em01_bore_min_d", "CAD-K"),
                    ("z_em01_term", "CAD-T"), ("z_em01_far", "CAD-T"), ("z_hs01_tip", "CAD-T"), ("z_hs01_mouth", "CAD-T"),
                    ("hs01_len", "CAD-K"), ("vl02_l0", "CAD-K")]:
        if nm not in g:
            g[nm] = reg(nm, E[nm], "mm", src, "kontrol parcasi Rev " + CTRL_REV)
    g["z_dr01_ctrl"] = reg("z_dr01_ctrl", E["z_dr01"], "mm", "CAD-T", "ctrl dinlenme (VL02 kuvveti yok sayilmis)")
    g["stroke_mag_ctrl"] = reg("stroke_mag_ctrl", E["stroke_mag"], "mm", "CAD-T", "ctrl manyetik strok (arka yuz -> EM03-A ust)")
    g["p_max_check_ctrl"] = reg("p_max_check_ctrl", E["p_max_check"], "bar", "CAD-T", "ctrl yay basinc kontrolu")

    G_ss, G_st = iv("malzeme", "G_ss"), iv("malzeme", "G_st")
    # --- yaylar
    kf02 = k_helical(G_ss, g["dr02_d"], g["dr02_od"] - g["dr02_d"], g["dr02_na"])
    kf03 = k_helical(G_st, g["dr03_d"], g["dr03_od"] - g["dr03_d"], g["dr03_na"])
    v = INP["usta_olcum"]["k_dr02"]["value"]
    g["k02"] = reg("k02", v if v is not None else kf02, "N/mm", "USTA" if v is not None else "CAD-T",
                   "DR02 yay sabiti (A_OLCUM #3); formul G d^4/(8 D^3 n_a)")
    v = INP["usta_olcum"]["k_dr03"]["value"]
    g["k03"] = reg("k03", v if v is not None else kf03, "N/mm", "USTA" if v is not None else "CAD-T",
                   "DR03 yay sabiti (A_OLCUM #3)")
    g["k02_formula"], g["k03_formula"] = kf02, kf03
    # tarama teli ile (celiski): 1,19 / 1,41 (C, iki yontem)
    g["k02_scanwire"] = k_helical(G_ss, 1.19, 11.75, g["dr02_na"])
    g["k03_scanwire"] = k_helical(G_st, 1.41, 11.54, g["dr03_na"])
    dm3_02 = (2 * _smooth_dm3(3.6, 5.1) + 7 * 5.1 ** 3) / 9.0          # D: 2 konik + 7 silindirik aktif sarim
    dm3_04 = _smooth_dm3(3.95, 5.35)                                    # D: 3 konik aktif sarim
    g["k_vl02"] = reg("k_vl02", G_ss * g["vl02_d"] ** 4 / (8 * dm3_02 * g["vl02_na"]), "N/mm", "CAD-T",
                      "VL02 bilya yayi, konik; Dm_eff = (ortalama Dm^3)^(1/3) = %.2f" % dm3_02 ** (1 / 3))
    g["k_vl04"] = reg("k_vl04", G_ss * g["vl04_d"] ** 4 / (8 * dm3_04 * g["vl04_na"]), "N/mm", "CAD-T",
                      "VL04 valf yayi, konik; Dm_eff = %.2f" % dm3_04 ** (1 / 3))
    g["vl02_block"] = reg("vl02_block", 6.25, "mm", "CAD-T", "VL02 blok boyu (D raporu)")
    g["vl04_inst"] = reg("vl04_inst", ASM["springs"]["EP5-VL04_SPRING-VALVE"]["length_set"], "mm", "CAD-T",
                         "VL04 montaj boyu (VL03 oturmus; asm_build)")
    g["vl04_pre"] = g["vl04_l0"] - g["vl04_inst"]
    g["vl04_lift_max"] = reg("vl04_lift_max", iv("mekanik", "vl04_lift_max"), "mm", "CAD-T", "VL03 en buyuk kalkis")

    # --- zincir (pompa z'si, mm)
    g["z_hs01_bot"] = g["z_hs01_flange"] - g["hs01_inner_bot"]
    g["z_stop_fwd"] = g["z_hs05"] - g["dr01_collar_front"]                   # on alin en ileri (yaka HS05'e dayanir)
    # bilya: DR01 ucunda Ø2,72 delik kenarina oturur (havsa yari acisi > bilya temas acisi)
    R_b = g["vl01_d"] / 2
    r_s = g["dr01_pin_id"] / 2
    seat_depth = 0.72                                                       # DR01 parca ici seat_depth (CAD-K)
    g["ball_seat_r"] = r_s
    g["ball_c_above_edge"] = math.sqrt(R_b ** 2 - r_s ** 2)
    g["ball_top_from_tip"] = -seat_depth + g["ball_c_above_edge"] + R_b     # bilya tepesi, piston ucu duzlemine gore
    g["z_ch_bot"] = g["z_hs02"] + g["hs02_ch_bot"]                          # VL02 omzu
    g["wall_t"] = reg("wall_t", 0.8, "mm", "CAD-T", "oda dibi duvari (D, CR-D-02)")
    g["z_seat_o"] = g["z_ch_bot"] + g["wall_t"]                              # cikis oturma kenari (Ø4) duzlemi

    def L_vl02(zf):
        return g["z_ch_bot"] - (zf + g["dr01_tip"] + g["ball_top_from_tip"])
    g["_L_vl02"] = L_vl02

    def f_springs(zf):
        """DR01'e etkiyen yay kuvveti +z (N); bilya oturmus kabul (VL02 kuvveti piston ucuna)."""
        z_rear = zf - g["dr01_arm_len"]
        F03 = g["k03"] * (g["dr03_l0"] - (z_rear - g["z_hs01_bot"]))
        F02 = -g["k02"] * (g["dr02_l0"] - (g["z_hs05"] - zf))
        F2b = -g["k_vl02"] * max(0.0, g["vl02_l0"] - L_vl02(zf))
        return F03 + F02 + F2b

    g["_f_springs"] = f_springs
    a, b = -15.0, g["z_stop_fwd"]
    for _ in range(80):
        m = 0.5 * (a + b)
        if f_springs(m) > 0:
            a = m
        else:
            b = m
    g["z_rest"] = reg("z_rest", 0.5 * (a + b), "mm", "CALC", "DR01 on alin dinlenme (DR02 + DR03 + VL02 dengesi)")
    k_tot = g["k02"] + g["k03"]
    # VL02'siz denge (ctrl ile karsilastirma)
    dr_defl = g["dr02_l0"] + g["dr03_l0"] - (g["z_hs05"] - g["z_hs01_bot"] - g["dr01_arm_len"])
    l03 = g["dr03_l0"] - dr_defl * g["k02"] / k_tot
    g["z_rest_noVL02"] = g["z_hs01_bot"] + l03 + g["dr01_arm_len"]
    g["dr_defl"] = dr_defl
    g["stroke_up"] = g["z_stop_fwd"] - g["z_rest"]
    g["z_rear_rest"] = g["z_rest"] - g["dr01_arm_len"]
    g["stroke_mag_ref"] = g["z_rear_rest"] - g["z_hs04_bot"]                 # arka yuz -> EM03-A ust kenari
    g["L_vl02_rest"] = L_vl02(g["z_rest"])
    g["F02_rest"] = g["k02"] * (g["dr02_l0"] - (g["z_hs05"] - g["z_rest"]))
    g["F03_rest"] = g["k03"] * (g["dr03_l0"] - (g["z_rear_rest"] - g["z_hs01_bot"]))
    g["Fvl02_rest"] = g["k_vl02"] * max(0.0, g["vl02_l0"] - g["L_vl02_rest"])
    g["dr03_block"] = g["dr03_nt"] * g["dr03_d"]
    g["dr02_block"] = g["dr02_nt"] * g["dr02_d"]
    g["z_stop_back"] = g["z_hs01_bot"] + g["dr03_block"] + g["dr01_arm_len"]  # DR03 blok (pratikte erisilmez)

    # --- alanlar (mm2)
    pi4 = math.pi / 4
    g["A_p"] = pi4 * g["dp"] ** 2
    g["A_t"] = pi4 * g["hs01_bore_d"] ** 2
    g["A_bore"] = pi4 * g["dr01_bore_d"] ** 2
    g["A_x"] = 2 * pi4 * 5.15 ** 2                                        # capraz delik Ø5,15 iki agiz (DR01 parca ici)
    g["A_pb"] = pi4 * g["dr01_pin_id"] ** 2
    g["A_nip"] = pi4 * iv("hidrolik", "nip_bore_d") ** 2
    g["A_seat_b"] = pi4 * (2 * r_s) ** 2
    g["A_seat_o"] = pi4 * g["hs02_seat_d"] ** 2
    g["A_ch"] = pi4 * g["hs02_ch_d"] ** 2
    g["gap_arm"] = (g["hs01_bore_d"] - g["dr01_arm_d"]) / 2
    g["L_pb"] = g["dr01_tip"] - seat_depth - 6.36                          # piston deligi boyu (bore_end_z 6,36 -> havsa)
    g["L_bore"] = g["dr01_arm_len"] + 6.36
    g["L_nip"] = (g["z_hs01_bot"] - g["z_hs01_tip"])
    return g


def spring_mass(g):
    vol = {k: v[0] for k, v in ASM["part_volumes"].items()}
    m = {}
    m["DR01"] = vol["DR01"] * iv("malzeme", "rho_armature") * 1e-3
    m["DR02"] = vol["DR02"] * iv("malzeme", "rho_spring_ss") * 1e-3
    m["DR03"] = vol["DR03"] * iv("malzeme", "rho_spring_st") * 1e-3
    m["VL01"] = vol["VL01"] * iv("malzeme", "rho_ball") * 1e-3
    m["VL02"] = vol["VL02"] * iv("malzeme", "rho_spring_ss") * 1e-3
    m["VL03"] = vol["VL03"] * iv("malzeme", "rho_plug") * 1e-3
    m["VL04"] = vol["VL04"] * iv("malzeme", "rho_spring_ss") * 1e-3
    return m, vol


CURVE_P = INP["datasheet"]["E5_curve_bar"]
CURVE_Q = INP["datasheet"]["E5_curve_ccmin"]


def curve_Q(p_bar):
    """E5 egrisi (dogrusal ara deger), cm3/dk."""
    import numpy as np
    return float(np.interp(p_bar, CURVE_P, CURVE_Q))
