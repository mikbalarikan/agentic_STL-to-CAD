"""c7 - AYAR (FIT) varyanti: modeli E5 egrisine uydurmak icin acikca adlandirilmis iki parametre.

Taban model (c4) yalniz turetilmis girdilerle kosar; E5 ile farki raporda "tutmadi" diye yazilir. Bu betik,
olculmemis ve sonucu en cok etkileyen iki girdiyi E5 egrisine en kucuk kareler anlaminda uydurur:
  FIT_vl02_d   VL02 bilya yayi tel capi (emme valfi on yuku; A_OLCUM #5)
  FIT_k_scale  DR02 ve DR03 yay sabitlerinin ortak carpani (A_OLCUM #3)
Bobin N her aday icin tabandaki degerde sabit; secilen adayda 48 W'a yeniden kalibre edilip egri yeniden kosulur.
Bu varyant bir OLCUM DEGILDIR; Usta'nin olcumleri geldiginde taban model bu varyantin yerini alir.
"""
from __future__ import annotations

import sys

import itertools
import time

import numpy as np

from c3_model import build, run_many
from c4_qp import calibrate, qp_curve, set_coil, stall_pressure
from common import CURVE_P, CURVE_Q, curve_Q, derive, load, save

PTS = [0.0, 2.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0]
D_GRID = [0.25, 0.30, 0.35, 0.40]
K_GRID = [0.70, 0.85, 1.00, 1.20]


def main():
    qp = load("qp")
    g0 = derive()
    t0 = time.time()
    jobs = []
    for d, ks in itertools.product(D_GRID, K_GRID):
        for p in PTS:
            jobs.append(dict(usta={"vl02_d": d, "k_dr02": g0["k02"] * ks, "k_dr03": g0["k03"] * ks},
                             N=qp["N"], R=qp["R"], p=p, tag=(d, ks)))
    res = run_many(jobs)
    grid = {}
    for r in res:
        grid.setdefault(tuple(r["job_tag"]), []).append(r)
    table = []
    for (d, ks), rows in grid.items():
        rows.sort(key=lambda r: r["p_bar"])
        err = [r["Q_ccmin"] - curve_Q(r["p_bar"]) for r in rows]
        table.append(dict(vl02_d=d, k_scale=ks, rms=float(np.sqrt(np.mean(np.square(err)))),
                          Q=[r["Q_ccmin"] for r in rows], P_in=float(np.mean([r["P_in"] for r in rows]))))
    table.sort(key=lambda x: x["rms"])
    best = table[0]
    print(f"en iyi: vl02_d {best['vl02_d']}, k_scale {best['k_scale']}, rms {best['rms']:.0f}  ({time.time() - t0:.0f} s)")
    # secilen adayda N'yi 48 W'a yeniden kalibre et ve tam egriyi kos
    job = dict(usta={"vl02_d": best["vl02_d"], "k_dr02": g0["k02"] * best["k_scale"], "k_dr03": g0["k03"] * best["k_scale"]})
    import common
    saved = {k: common.INP["usta_olcum"][k]["value"] for k in job["usta"]}
    for k, v in job["usta"].items():
        common.INP["usta_olcum"][k]["value"] = v
    P = build(derive())
    N, R, Pc = calibrate(P, None, base_job=job)
    ps = [float(x) for x in CURVE_P] + [16.0, 17.0, 18.0]
    rows = qp_curve(P, ps, base_job=job)
    trs = run_many([dict(job, N=N, R=R, p=p, trace=True) for p in (0.0, 7.0, 14.0)])
    for k, v in saved.items():
        common.INP["usta_olcum"][k]["value"] = v
    err = [r["Q_ccmin"] - curve_Q(r["p_bar"]) for r in rows if r["p_bar"] <= 15]
    out = dict(params=dict(FIT_vl02_d=best["vl02_d"], FIT_k_scale=best["k_scale"],
                           k02=g0["k02"] * best["k_scale"], k03=g0["k03"] * best["k_scale"]),
               N=N, R=R, P_cal=Pc, rows=rows, p_stall=stall_pressure(rows), table=table,
               rms_dev=float(np.sqrt(np.mean(np.square(err)))), max_dev=float(np.max(np.abs(err))),
               traces={str(r["p_bar"]): {k: v for k, v in r.items() if k != "trace"} for r in trs})
    save("fit", out)
    np.savez_compressed(common.OUT / "traces_fit.npz",
                        **{f"{r['p_bar']}__{kk}": np.array(vv) for r in trs for kk, vv in r["trace"].items()})
    plot(out, table)
    print(f"FIT: N {N:.0f} R {R:.1f} rms {out['rms_dev']:.0f} p_stall {out['p_stall']:.2f}  ({time.time() - t0:.0f} s)")


def plot(out, table):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from common import FIG
    qp = load("qp")
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))
    a = ax[0]
    a.plot(CURVE_Q, CURVE_P, "o-", color="#1f77b4", label="E5 datasheet")
    a.plot([r["Q_ccmin"] for r in qp["rows"]], [r["p_bar"] for r in qp["rows"]], "s--", color="#d62728", label="taban (türetilmiş)")
    a.plot([r["Q_ccmin"] for r in out["rows"]], [r["p_bar"] for r in out["rows"]], "^-", color="#2ca02c",
           label=f"AYAR: VL02 tel {out['params']['FIT_vl02_d']:.2f}, k × {out['params']['FIT_k_scale']:.2f}")
    a.set_xlabel("debi [cm³/dk]"); a.set_ylabel("basınç [bar]"); a.set_xlim(0, 760); a.set_ylim(0, 19)
    a.grid(alpha=0.3); a.legend(fontsize=8); a.set_title("Q-p: taban, ayar varyantı, E5")
    a = ax[1]
    D = sorted({t["vl02_d"] for t in table}); K = sorted({t["k_scale"] for t in table})
    Z = np.array([[next(t["rms"] for t in table if t["vl02_d"] == d and t["k_scale"] == k) for d in D] for k in K])
    im = a.imshow(Z, origin="lower", cmap="viridis_r", aspect="auto")
    a.set_xticks(range(len(D))); a.set_xticklabels([f"{d:.2f}" for d in D])
    a.set_yticks(range(len(K))); a.set_yticklabels([f"{k:.2f}" for k in K])
    for i in range(len(K)):
        for j in range(len(D)):
            a.text(j, i, f"{Z[i, j]:.0f}", ha="center", va="center", color="w", fontsize=8)
    a.set_xlabel("VL02 tel çapı [mm]"); a.set_ylabel("DR02/DR03 k çarpanı"); a.set_title("RMS sapma [cm³/dk] (N sabit)")
    fig.colorbar(im, ax=a)
    fig.tight_layout(); fig.savefig(FIG / "f1_ayar.png", dpi=140); plt.close(fig)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
