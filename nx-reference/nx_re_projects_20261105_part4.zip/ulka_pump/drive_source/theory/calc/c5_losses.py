"""c5 - Valf acilma basinclari, akis yolu hiz / basinc kayiplari, kavitasyon, hacimsel verim dokumu.

Girdi: common.derive (geometri), out/qp.json (Q-p satirlari), out/traces.npz (0 / 7 / 14 bar cevrim izleri).
"""
from __future__ import annotations

import sys

import math

import numpy as np

from c3_model import build
from common import FIG, K_W, OUT, P_ATM, P_VAP, RHO, G0, derive, iv, load, save


def main():
    g = derive()
    P = build(g)
    qp = load("qp")
    geo = load("geometry")
    out = {}
    # ---------------------------------------------------------------- valf acilma basinclari
    zs = np.linspace(g["z_rest"] - 9.0, g["z_stop_fwd"], 200)
    crack_b = []
    for zf in zs:
        L = g["_L_vl02"](zf)
        F = g["k_vl02"] * max(0.0, g["vl02_l0"] - L)
        crack_b.append(F / g["A_seat_b"] * 10)                     # N/mm2 -> bar
    out["vl01_crack_rest_bar"] = g["Fvl02_rest"] / g["A_seat_b"] * 10
    out["vl01_crack_fwd_bar"] = g["k_vl02"] * max(0, g["vl02_l0"] - g["_L_vl02"](g["z_stop_fwd"])) / g["A_seat_b"] * 10
    out["vl01_free_x"] = None
    for zf, c in zip(zs, crack_b):
        if c <= 0:
            out["vl01_free_x"] = zf - g["z_rest"]
    # VL02 serbest kaldigi en ileri konum (bilyayi tutmuyor)
    out["vl02_free_from_x"] = (g["z_ch_bot"] - g["vl02_l0"] - g["dr01_tip"] - g["ball_top_from_tip"]) - g["z_rest"]
    out["vl03_crack_bar"] = g["k_vl04"] * g["vl04_pre"] / g["A_seat_o"] * 10
    out["vl03_full_bar"] = g["k_vl04"] * (g["vl04_pre"] + g["vl04_lift_max"]) / g["A_seat_o"] * 10
    out["k_vl02"], out["k_vl04"] = g["k_vl02"], g["k_vl04"]
    out["Fvl02_rest"] = g["Fvl02_rest"]
    out["L_vl02_rest"] = g["L_vl02_rest"]
    # ---------------------------------------------------------------- izler
    T = np.load(OUT / "traces.npz")
    keys = sorted({k.split("__")[0] for k in T.files}, key=float)
    tr = {}
    for p in keys:
        d = {k.split("__")[1]: T[k] for k in T.files if k.startswith(p + "__")}
        t = d["t"]
        res = dict(p=float(p))
        res["pr_min_bar"] = float(d["pr"].min() / 1e5); res["pf_min_bar"] = float(d["pf"].min() / 1e5)
        res["pc_min_bar"] = float(d["pc"].min() / 1e5); res["pc_max_bar"] = float(d["pc"].max() / 1e5)
        dt = np.gradient(t)
        Tt = t[-1] - t[0]
        for nm in ("pr", "pf", "pc"):
            res[f"{nm}_vapfrac"] = float(np.sum(dt[d[nm] < 0.2e5]) / Tt)      # 0,2 bar mutlak altinda kalinan pay
        res["Qin_peak"] = float(np.abs(d["Qin"]).max())
        res["Qpb_peak"] = float(np.abs(d["Qpb"]).max())
        res["Qout_peak"] = float(np.abs(d["Qout"]).max())
        res["Qrf_peak"] = float(np.abs(d["Qrf"]).max())
        res["dprf_max"] = float(np.abs(d["pr"] - d["pf"]).max())
        res["dprf_max_bar"] = res["dprf_max"] / 1e5
        res["v_peak"] = float(np.abs(d["v"]).max())
        res["i_peak"] = float(d["i"].max())
        op = d["yb"] > 1e-5                                         # bilya acik (kalkis > 0,01 mm)
        k = int(np.argmax(d["Qpb"]))
        res["dp_b_max_bar"] = float(abs(d["dp_b"][k]) / 1e5)          # en buyuk emme debisinde valf farki
        res["ball_open_frac"] = float(np.sum(dt[op]) / Tt)
        res["dp_in_max_bar"] = float(np.abs(d["dp_in"]).max() / 1e5)
        tr[p] = res
    out["traces"] = tr
    # ---------------------------------------------------------------- kesit hizlari (0 bar ortalama ve tepe)
    r0 = [r for r in qp["rows"] if r["p_bar"] == 0.0][0]
    Qm = r0["Q_m3s"]
    t0 = tr[keys[0]]
    secs = []
    for s in geo["sections"]:
        A = s["A_mm2"] * 1e-6
        nm = s["name"]
        if "nipel" in nm or "hortum" in nm:
            Qp = t0["Qin_peak"]
        elif "halka aralığı" in nm:
            Qp = P["G_ann"] * t0["dprf_max"]                      # laminer halka: yalniz kendi payi
        elif "eksenel delik" in nm or "çapraz" in nm or "tüpü" in nm:
            Qp = t0["Qrf_peak"]
        elif "piston deliği" in nm or "VL01" in nm:
            Qp = t0["Qpb_peak"]
        elif "oda" in nm:
            Qp = P["A_p"] * t0["v_peak"]
        else:
            Qp = t0["Qout_peak"]
        vm, vp = Qm / A, Qp / A
        secs.append(dict(name=nm, A_mm2=s["A_mm2"], v_mean=vm, v_peak=vp, q_peak_bar=0.5 * RHO * vp ** 2 / 1e5, src=s["src"]))
    out["sections"] = secs
    # ---------------------------------------------------------------- NPSH / emme
    out["p_tank_bar"] = P["p_tank"] / 1e5
    out["npsh_static_m"] = (P["p_tank"] - P_VAP) / (RHO * G0)
    out["I_in"] = P["I_in"]
    # hortum ataletiyle tepe ivmede basinc dususu (izden): I_in * max dQin/dt
    d = {k.split("__")[1]: T[k] for k in T.files if k.startswith(keys[0] + "__")}
    dQ = np.gradient(d["Qin"], d["t"])
    out["dp_inertia_in_max_bar"] = float(P["I_in"] * np.abs(dQ).max() / 1e5)
    # ---------------------------------------------------------------- hacimsel verim dokumu
    Vg = geo["V_disp_geom_mm3"]
    Kc = 1.0 / (1.0 / K_W + P["wall_ch"] * P["Vbore_ch"] / P["Vc_rest"])
    brk = []
    for r in qp["rows"]:
        Vcyc = r["Q_m3s"] / P["f"] * 1e9
        comp = geo["V_ch_min_mm3"] * r["p_bar"] * 1e5 / Kc
        brk.append(dict(p=r["p_bar"], V_geom=Vg, V_stroke=r["V_disp_mm3"], V_out=Vcyc, Vb_back=r["Vb_back_mm3"],
                        Vo_back=r["Vo_back_mm3"], V_comp=comp, eta_geom=Vcyc / Vg, eta_stroke=r["eta_v"]))
    out["breakdown"] = brk
    out["K_eff_ch"] = Kc
    out["eps_compression"] = (geo["V_ch_min_mm3"] + r0["V_disp_mm3"]) / geo["V_ch_min_mm3"]
    save("losses", out)
    plot(g, zs, crack_b, out, tr)
    print({k: v for k, v in out.items() if not isinstance(v, (list, dict))})


def plot(g, zs, crack_b, out, tr):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 3.8))
    ax.plot(zs - g["z_rest"], crack_b, label="VL01 (emme, VL02 yaylı) açılma Δp")
    ax.axhline(out["vl03_crack_bar"], color="C1", label="VL03 (basma, VL04) açılma Δp")
    ax.axhline(1.0, color="gray", ls=":", lw=1)
    ax.text(-8.8, 1.05, "emmede erişilebilen en büyük Δp ≈ 1 bar (p_atm - p_v)", fontsize=7, color="gray")
    ax.axvline(0, color="k", lw=0.5, ls=":")
    ax.set_xlabel("piston konumu x (dinlenmeden) [mm]"); ax.set_ylabel("açılma basınç farkı [bar]")
    ax.grid(alpha=0.3); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(FIG / "v1_valf.png", dpi=140); plt.close(fig)
    brk = out["breakdown"]
    ps = [b["p"] for b in brk if b["p"] <= 16]
    fig, ax = plt.subplots(figsize=(7.5, 4))
    ax.plot(ps, [b["V_geom"] for b in brk if b["p"] <= 16], "k--", label="geometrik (A_p × 10,2 mm)")
    ax.plot(ps, [b["V_stroke"] for b in brk if b["p"] <= 16], "o-", label="gerçekleşen strok × A_p")
    ax.plot(ps, [b["V_out"] for b in brk if b["p"] <= 16], "s-", label="basılan (net)")
    ax.plot(ps, [b["Vb_back"] for b in brk if b["p"] <= 16], "^-", label="VL01 geri kaçak")
    ax.plot(ps, [b["Vo_back"] for b in brk if b["p"] <= 16], "v-", label="VL03 geri kaçak")
    ax.plot(ps, [b["V_comp"] for b in brk if b["p"] <= 16], "x-", label="sıkıştırma (ölü hacim)")
    ax.set_xlabel("basınç [bar]"); ax.set_ylabel("darbe başına hacim [mm³]"); ax.grid(alpha=0.3); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(FIG / "d1_hacim_dokumu.png", dpi=140); plt.close(fig)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    main()
