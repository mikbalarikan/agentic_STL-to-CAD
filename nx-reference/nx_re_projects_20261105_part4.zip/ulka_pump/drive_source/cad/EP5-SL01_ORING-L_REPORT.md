# EP5-SL01_ORING-L - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: F. Journal sonucu: **PASS** (10 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-SL01_ORING-L.prt`, `cad\EP5-SL01_ORING-L.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\SL01\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_sl01.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Yerinde, nötr (kalıp) halinde torus: alt yüz `z_em03b_top` (EM03-B üstü, HS01 flanşı altı). ID / kesit kontrol parçasından.

Standart eşleme: tarama ID 16,20-16,26, kesit 2,04-2,24, OD 20,6 -> **metrik 16,5 x 2,0** en yakın (alternatif 16 x 2). Rev F değeri (16,2 x 2,2, tarama; CR-D-03) modellendi. Ön kontrol: kendi oturmasıyla %97,7 ±0,15.

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_SL01 -> DATUM_AXIS AX_PL_SL01 -> SKETCH SK_SECTION -> SWP104 TORUS

Sketch'ler: SK_SECTION WellConstrained, DOF 0, otomatik ölçü 0, 3 ölçü.
Gövdeler: body 219,74 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 1.2e-15, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `sl01_id` = 16,2, `sl01_cs` = 2,2, `z_em03b_top` = -0,22.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `z_sl01_ref` | -0,22 (= `z_em03b_top`) | reference face of the ring (lower face) |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | -0,039 | 0,096 | 0,062 | 0,207 | 42,9 | 84,2 |
| all: kendi en iyi oturmasından sonra | 200000 | +0,006 | 0,072 | 0,050 | 0,127 | 49,7 | 97,7 |

- all: taramayı CAD'e oturtan küçük hareket: dönme 0,473°, öteleme (-0,004; 0,013; 0,108).
- CAD yüzeyinin % 34,7'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `ring`: {"ID": 16.2, "cs": 2.2, "OD": 20.6, "z_ref": -0.21999999999999886, "ref_face": "lower"}
