# EP5-HS05_WASHER - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: F. Journal sonucu: **PASS** (11 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-HS05_WASHER.prt`, `cad\EP5-HS05_WASHER.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\HS05\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_hs05.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Yerinde: alt yüz `z_hs05` (HS01 soket ağzında), +Z. Tarama tek yüzden (alt yüz masada, 0,25 mm alt kesik): üst yüz,
dış çap ve delik karşılaştırılabilir. F15'teki bir yüzdeki delik çevresi kademe taramada görülmediği için modellenmedi;
dış kenarlarda 0,2 pah. Ön kontrol: kendi oturmasından sonra %93,8 ±0,15 içinde (eğim 0,8°: masa düzlemi kesiği).

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_HS05 -> DATUM_AXIS AX_PL_HS05 -> SKETCH SK_PROFILE -> SWP104 WASHER

Sketch'ler: SK_PROFILE WellConstrained, DOF 0, otomatik ölçü 0, 7 ölçü.
Gövdeler: body 402,49 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 1.4e-16, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `z_hs05` = 10,02, `hs05_od` = 15,7, `hs05_hole_d` = 5,65, `hs05_t` = 2,4.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `hs05_ch` | 0,2 | edge breaks (outer edges, both faces) [scan rounded rim] |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | -0,032 | 0,184 | 0,076 | 0,218 | 34,1 | 78,0 |
| all: kendi en iyi oturmasından sonra | 200000 | +0,026 | 0,161 | 0,043 | 0,168 | 57,0 | 93,8 |

- all: taramayı CAD'e oturtan küçük hareket: dönme 1,241°, öteleme (-0,116; 0,028; 0,089).
- CAD yüzeyinin % 40,8'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).
