# EP5-VL02_SPRING-BALL - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: D. Journal sonucu: **PASS** (9 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-VL02_SPRING-BALL.prt`, `cad\EP5-VL02_SPRING-BALL.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\VL02\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_vl02.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve ve tasarım
Kendi çerçevesinde: z0 = giriş tarafı ucu (bilya tarafı, küçük uç), +Z çıkışa; boy `vl02_len` (= `vl02_l0` 15,0; A
sıkışmış kopyayı buradan verir), aktif hatve boydan türetilir. Tel merkez eğrisi tek Law Curve (C1; ULKA-C'nin yöntemi):
0,75 kapalı sarım (hatve tel + 0,05), 0,5 sarım hatve geçişi, aktif sarımlar, uçta aynısı; çap küçük uçta Dm 3,6
(OD 4,1), 2 sarımda smoothstep ile Dm 5,1'e (OD 5,6). Toplam 11,5 sarım, aktif hatve 1,41 (tarama ≈1,4), blok ≈6,25.
Uçlar kapalı, taşlanmamış. Tel Ø 0,5 (`vl02_d`, tarama zayıf).

## Tarama
Tarama parçalı (tel parçaları); bağımsız ölçüm için zayıf, karşılaştırma yapılmadı; ölçüler D_MEASURED §4.
Montaj (CR-D-02): HS02 odasında bilya tepesi ile oda dibi (z 24,0) arası; dinlenmede 9,33, yukarı dayanmada 6,75.

## Unsur ağacı

DATUM_CSYS  -> SPLINE_LAW CENTRE_LINE -> SWP104 WIRE_TUBE

Sketch'ler: .
Gövdeler: body 34,68 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 0.0e+00, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `vl02_l0` = 15, `vl02_d` = 0,5.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `vl02_dm1` | 3,6 | mean coil diameter at the small (inlet-side) end [scan: small end OD 4.0-4.4, body OD 5.6-5.9] |
| `vl02_dm2` | 5,1 | mean coil diameter at the big end [scan: small end OD 4.0-4.4, body OD 5.6-5.9] |
| `vl02_ntap` | 2 | active turns over which the diameter grows (smoothstep) |
| `vl02_ncyl` | 7 | active turns at the big diameter |
| `vl02_a` | 0,75 | closed turns at each end (coils touch: pitch pe) |
| `vl02_b` | 0,5 | pitch ramp between the closed and the active turns |
| `vl02_gap` | 0,05 | gap between touching closed coils (keeps the wire body valid) |
| `vl02_nt` | 11,5 (= `2*vl02_a+2*vl02_b+vl02_ntap+vl02_ncyl`) | total turns |
| `vl02_pe` | 0,55 (= `vl02_d+vl02_gap`) | closed-end pitch |
| `vl02_len` | 15 (= `vl02_l0`) | spring length: free length by default; A sets the installed length on a copy |
| `vl02_n_act` | 9 (= `vl02_nt-2*vl02_a-2*vl02_b`) | turns at the active pitch |
| `vl02_p` | 1,4105 (= `(vl02_len-vl02_d-2*vl02_pe*vl02_a-vl02_pe*vl02_b)/(vl02_b+vl02_n_act)`) | active pitch, DERIVED from the length |
| `vl02_z0` | 0,25 (= `vl02_d/2`) | wire centre at the start (end coil on z = 0) |
| `vl02_zA` | 0,6625 (= `vl02_z0+vl02_pe*vl02_a`) |  |
| `vl02_zB` | 1,1526 (= `vl02_zA+(vl02_pe+vl02_p)/2*vl02_b`) |  |
| `vl02_zC` | 13,8474 (= `vl02_zB+vl02_p*((vl02_nt-vl02_a-vl02_b)-(vl02_a+vl02_b))`) |  |
| `vl02_zD` | 14,3375 (= `vl02_zC+(vl02_p+vl02_pe)/2*vl02_b`) |  |

## Tarama karşılaştırması

Yapılmadı: taraması parçalı / zayıf. Ölçüler `sessions/D_MEASURED.md` tablosundan.

## Journal notları

- `spring`: {"d": 0.5, "OD_small": 4.1, "OD_big": 5.6, "L0": 15.0, "pitch": 1.4105, "turns_total": 11.5, "turns_active_pitch": 9.0, "solid_length_approx": 6.25, "wire_length": 176.64}
