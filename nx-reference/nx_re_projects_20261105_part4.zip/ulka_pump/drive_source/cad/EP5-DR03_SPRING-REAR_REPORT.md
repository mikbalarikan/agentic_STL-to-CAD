# EP5-DR03_SPRING-REAR - parça raporu

Yazar: ULKA-C Tahrik. Tarih: 2026-10-16. Kontrol parçası revizyonu: H. Journal sonucu: **PASS** (13 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-DR03_SPRING-REAR.prt`, `cad\EP5-DR03_SPRING-REAR.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\DR03\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_dr03.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Hareketli parça, kendi ekseninde: Z = sarım ekseni, z = 0 ve z = `dr03_len` taşlanmış uç düzlemleri, tel başı +X'te,
sağ helis. `dr03_len` = `dr03_l0` (serbest boy); A montaj kopyasında bu expression'a `dr03_l_inst` verir, aktif adım
boydan türetilir (uç sarımları sabit kalır).
Unsur ağacı: law curve merkez çizgisi (`CENTRE_LINE`: x, y = coil_d/2·cos/sin(360·n_t·t), z = parçalı adım:
kapalı uç adımı = d + 0,02 [sarımlar değer] -> geçiş -> aktif adım -> geçiş -> kapalı uç) -> Tube (tel Ø) -> iki Trim Body
(z = 0 ve z = len düzlemleri = taşlanmış uçlar). Sketch yok (eğri denklemle).
Kontrol parçasından: d (Usta ölçüsü), od, l0, nt (Rev F). Uç sarımı parametreleri taramaya oturtuldu
(`parts\C_common\spring_fit3.py`, kapalı uç adımı = d kısıtıyla).

## Bilinen sapma - taramanın tel şişmesi (K2'den önce bildirilir)
Tel CAD'de Usta'nın ölçtüğü Ø1,3; taramada aynı tel Ø1,43 görünüyor (yan başına ~+0,065). Sarım merkez çizgisi ve
adım taramadan (merkez çizgisi silindiri rms 0,04-0,05), bu yüzden tarama yüzeyi CAD tel yüzeyinin sistematik olarak
~0,065 dışında kalır: aşağıdaki tabloda "ortalama" sütunu bu kaymadır, "sd" sütunu kaymadan arındırılmış uyumdur.
Bu sistematik fark modelleme hatası değildir; K2 sonucunu A değerlendirir (CR-C-02 kapı notu).
Tarama yayın yan yatmış halidir; masaya bakan alt yarı yoktu (masa silindi).
**K2 dışında tutulması istenen tarama bölgeleri:** yok.

## C'nin kendi K2 tahmini
Fazı / uç yönü en iyi oturtmadan sonra ±0,15 içinde %84,3: **tutmadı** (kapı %90). Ortalama +0,065 = tel şişmesi
(Usta 1,3 / tarama 1,43). Aktif sarımlarda %93,8 (kaymadan arındırılmış sd 0,083); kayıp uç sarımlarında (%63,3,
sd 0,163): uç sarımlarının gerçek şekli parçalı adım modelinden sapıyor. Tel Usta ölçüsünde bırakıldı.

## Unsur ağacı

DATUM_CSYS  -> SPLINE_LAW CENTRE_LINE -> SWP104 WIRE_TUBE -> DATUM_PLANE PL_END_0 -> DATUM_PLANE PL_END_LEN -> TRIM BODY  -> TRIM BODY 

Sketch'ler: .
Gövdeler: body 391,23 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 1.8e-05, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `dr03_d` = 1,3, `dr03_od` = 12,84, `dr03_l0` = 30,16, `dr03_nt` = 8,15.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `dr03_pe_gap` | 0,02 | gap between touching end coils (closed ends) |
| `dr03_a1` | 0,927 | closed turns at the z = 0 end [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr03_b1` | 0,167 | pitch ramp turns at the z = 0 end [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr03_a2` | 0,884 | closed turns at the far end [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr03_b2` | 0,1 | pitch ramp turns at the far end [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr03_grind` | 0,4 | grind depth at the ends [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr03_pe` | 1,32 (= `dr03_d+dr03_pe_gap`) | pitch of the closed end turns = wire + gap (coils touch) |
| `dr03_len` | 30,16 (= `dr03_l0`) | spring length: free length by default; A sets the installed length on a copy |
| `dr03_coil_d` | 11,54 (= `dr03_od-dr03_d`) | mean coil diameter |
| `dr03_z0` | 0,25 (= `dr03_d/2-dr03_grind`) | wire centre height at the start (ground end) |
| `dr03_n_act` | 6,072 (= `dr03_nt-dr03_a1-dr03_a2-dr03_b1-dr03_b2`) | turns at the active pitch |
| `dr03_p` | 4,366 (= `(dr03_len-2*dr03_z0-dr03_pe*(dr03_a1+dr03_a2)-dr03_pe*(dr03_b1+dr03_b2)/2)/((dr03_b1+dr03_b2)/2+dr03_n_act)`) | active pitch, DERIVED from the length |
| `dr03_zA` | 1,4736 (= `dr03_z0+dr03_pe*dr03_a1`) |  |
| `dr03_zB` | 1,9484 (= `dr03_zA+(dr03_pe+dr03_p)/2*dr03_b1`) |  |
| `dr03_zC` | 28,4588 (= `dr03_zB+dr03_p*((dr03_nt-dr03_a2-dr03_b2)-(dr03_a1+dr03_b1))`) |  |
| `dr03_zD` | 28,7431 (= `dr03_zC+(dr03_p+dr03_pe)/2*dr03_b2`) |  |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | +0,065 | 0,115 | 0,067 | 0,288 | 34,3 | 84,3 |
| outer (r > R) | 128291 | +0,063 | 0,105 | 0,066 | 0,280 | 33,3 | 86,0 |
| inner (r < R) | 71709 | +0,069 | 0,131 | 0,070 | 0,309 | 36,1 | 81,4 |
| end coils (z<2.5 or z>L0-2.5) | 62233 | +0,081 | 0,163 | 0,106 | 0,362 | 21,1 | 63,3 |
| active coils | 137767 | +0,058 | 0,083 | 0,059 | 0,164 | 40,2 | 93,8 |
| all | 200000 | +0,065 | 0,115 | 0,067 | 0,288 | 34,3 | 84,3 |

- CAD yüzeyinin % 31,9'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `v_tube`: 394.3495677970225
- `v_trimmed`: 391.2287076611973
- `active_pitch`: 4.366007573926355
- `min_rise_per_turn`: 1.3685993244354897
- `bbox_xy_padded`: [13.1415, 12.840499999999999]
