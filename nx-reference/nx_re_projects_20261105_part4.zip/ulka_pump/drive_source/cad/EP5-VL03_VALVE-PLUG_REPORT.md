# EP5-VL03_VALVE-PLUG - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: D. Journal sonucu: **PASS** (10 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-VL03_VALVE-PLUG.prt`, `cad\EP5-VL03_VALVE-PLUG.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\VL03\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_vl03.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Kendi çerçevesinde: z0 = kubbe tepesi (giriş tarafı, HS02 Ø4,0 oturma kenarına), +Z sapa doğru. Kubbe R 2,76
(`vl03_head_r`), baş Ø5,0 (`vl03_head_d`) z 1,59-2,4, alt koni boyun Ø3,3'e (z 4,3), boyun z 6,0'a kadar.
**Türetilen**: sap Ø2,0 ve toplam boy 12,7 (taramada yay içinde görünmüyor; tarayıcı masasında sapı üzerinde
durduğu için tepe 12,97'de). Siyah elastomer baş + gövde tek gövde olarak modellendi.
Ön kontrol (yalnız baş+boyun taraması): kendi oturmasından sonra %95,6 ±0,15 (tarama baş merkezi 0,4 yanda).

## Unsur ağacı

DATUM_CSYS  -> SKETCH SK_PROFILE -> SWP104 POPPET

Sketch'ler: SK_PROFILE WellConstrained, DOF 0, otomatik ölçü 0, 10 ölçü.
Gövdeler: body 95,15 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 6.0e-16, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `vl03_head_d` = 5, `vl03_head_r` = 2,76.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `cyl_z` | 2,4 | end of the head cylinder from the tip [scan max dia 5.0 at 2.0-2.5 from the tip] |
| `neck_d` | 3,3 | neck diameter [scan 3.21-3.36] |
| `taper_z` | 4,3 | head underside taper ends on the neck [scan dia 3.65 at 4.0, 3.36 at 4.5] |
| `neck_z` | 6 | neck end / stem start from the tip [scan neck visible to 6.0] |
| `stem_d` | 2 | stem diameter, DERIVED (inside VL04, through the VL05 hub) |
| `vl03_len` | 12,7 | overall length, DERIVED (stood on its stem on the scanner table: tip 12.97 above it) |
| `stem_ch` | 0,2 | stem end chamfer |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | +0,058 | 0,197 | 0,172 | 0,356 | 13,5 | 43,1 |
| all: kendi en iyi oturmasından sonra | 200000 | -0,011 | 0,072 | 0,027 | 0,144 | 71,3 | 95,6 |

- all: taramayı CAD'e oturtan küçük hareket: dönme 2,497°, öteleme (-0,400; -0,203; 0,056).
- CAD yüzeyinin % 53,6'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `seat_contact`: "on a 4.00 edge the dome centre is 1.902 above the edge; tip dips 0.858"
