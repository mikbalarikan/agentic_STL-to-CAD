# EP5-HS01_INLET-BODY - parça raporu

Yazar: ULKA-C Tahrik. Tarih: 2026-10-16. Kontrol parçası revizyonu: F. Journal sonucu: **PASS** (14 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-HS01_INLET-BODY.prt`, `cad\EP5-HS01_INLET-BODY.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\HS01\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_hs01.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve ve yerleşim
Sabit parça, montaj koordinatında yerinde: Z pompa ekseni, +Z nipelden soket ağzına. Flanş üst yüzü
`PL_HS01_FLANGE` datum düzleminde, z = `z_hs01_flange` (Rev F 4,710). Parça dönel; açısal özellik yok.
Tek unsur: profil sketch'i (`SK_PROFILE`, flanş yüzü ekseninden ölçülü, DOF 0) -> Revolve.
Taramaya karşılaştırma: tarama parça çerçevesinde (flanş yüzü z=0) -> z_hs01_flange kadar ötelenerek (`dev_hs01.py ... <z_hs01_flange>`).

## Türetilen (taramada yok) bölgeler - K2'den önce bildirilir
- Tüp iç Ø14,92 boyunca (taramada yalnız ağızdan ~10 mm, z_flanş +5,3..-5,2 görülüyor): Rev A `hs01_bore_d`.
- Tüp iç dibi: flanştan `hs01_inner_bot` = 52,0 (Rev B, türetildi; Rev A 55,3). Düz dip, delik Ø14,92 dibe kadar;
  dış geçişe (54,8) 2,8 mm et. DR03 düz dibe oturur.
- Nipel iç deliği Ø3,0 (`nip_bore_d`), uçtan tüp dibine kadar: taranmadı, türetildi.
- Nipel kökü z_flanş -61,3 .. -63,3 bölgesi taranmadı (gölge); tırnak dibi Ø6,1 ile köke kadar uzatıldı.
**K2 dışında tutulması istenen tarama bölgeleri:** yok (bu bölgelerde tarama noktası da yok; yalnız CAD yüzeyi var).

## Bilinen sapmalar
- Boyun geçişi (dış koni z_flanş -54,8 -> -56,9, r-z bindirmesinden) ve boyun alt ağzı (-60,5..-61, taramada küçük
  bir genişleme ~Ø14, modellenmedi): genel yüzey bölgesi, oranı aşağıdaki tabloda ("neck").
- Nipel tırnakları Ø6,9 (Rev A `hs01_nip_d`; datasheet 7,2): tarama 200-230° kapsıyor, tırnak arka yüzü bulanık;
  ±0,15 içinde %85,6.
- Flanş dış çevresinde birkaç tarama kümesi r ≈ 11'de (+0,4..0,55): kalıp çapağı / tarama artığı, modellenmedi.

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_HS01_FLANGE -> DATUM_AXIS AX_FLANGE_X -> SKETCH SK_PROFILE -> SWP104 BODY_REVOLVE

Sketch'ler: SK_PROFILE WellConstrained, DOF 0, otomatik ölçü 0, 24 ölçü.
Gövdeler: body 3635,70 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 8.8e-16, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `z_hs01_flange` = 4,71, `hs01_tube_od` = 16,09, `hs01_bore_d` = 14,92, `hs01_flange_d` = 20,23, `hs01_flange_t` = 3,23, `hs01_lip_od` = 15,82, `hs01_lip_h` = 5,31, `hs01_neck_d` = 12,92, `hs01_len` = 78, `hs01_nip_d` = 6,9, `hs01_inner_bot` = 52.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `fl_ch` | 0,5 | chamfer at the flange underside rim [scan ~0.5] |
| `tube_end_z` | 54,8 | end of the tube cylinder below the flange face [scan r-z overlay: cone 54.8 -> 56.9] |
| `neck_top_z` | 56,9 | top of the neck cylinder (cone tube -> neck above it) [scan r 7.5 at -55.5, 6.75 at -56.5] |
| `neck_z` | 61 | neck lower face below the flange face [scan -60.8 .. -61.3] |
| `barb_root_d` | 6,1 | nipple barb root / shank diameter [scan 6.15] |
| `barb1_z` | 68,6 | crest of the barb nearer the tip [scan -68.8] |
| `barb2_z` | 65,6 | crest of the second barb [scan -65.8] |
| `barb_back` | 0,4 | axial length of the barb back face [scan ~0.5, blurred] |
| `nip_tip_d` | 5,3 | nipple tip diameter [scan 5.3] |
| `hs01_len_nip` | 72,69 (= `hs01_len-hs01_lip_h`) | nipple tip below the flange face [scan -72.7] |
| `nip_bore_d` | 3 | nipple / inlet bore, DERIVED (not scanned; tip wall ~1.15) |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | -0,002 | 0,071 | 0,032 | 0,133 | 67,3 | 96,1 |
| F tube OD | 129010 | -0,001 | 0,048 | 0,027 | 0,095 | 76,1 | 99,1 |
| F socket bore | 12991 | -0,010 | 0,073 | 0,046 | 0,147 | 54,1 | 95,3 |
| F flange face | 5091 | -0,002 | 0,044 | 0,031 | 0,085 | 71,3 | 100,0 |
| F lip OD | 9185 | -0,001 | 0,072 | 0,051 | 0,141 | 49,3 | 96,0 |
| flange OD | 10166 | +0,014 | 0,100 | 0,032 | 0,174 | 68,5 | 93,9 |
| neck | 10098 | +0,009 | 0,158 | 0,083 | 0,351 | 31,3 | 74,2 |
| nipple | 5142 | -0,027 | 0,105 | 0,073 | 0,228 | 36,1 | 85,6 |
| all | 200000 | -0,002 | 0,071 | 0,032 | 0,133 | 67,3 | 96,1 |

- CAD yüzeyinin % 53,6'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `tube_wall`: 0.585
- `bottom_wall_to_neck_face`: 9.0
