# EP5-HS03_OUTLET-FLANGE - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: D. Journal sonucu: **PASS** (34 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-HS03_OUTLET-FLANGE.prt`, `cad\EP5-HS03_OUTLET-FLANGE.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\HS03\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_hs03.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve ve yerleşim
Yerinde (Rev A): plaka alt yüzü (pimli, EM02 çıkış duvarına oturan) `z_hs03` = 0'da, +Z göbek ucuna; kulaklar ±X,
pimler (±`pin_x`, ±`pin_y`). Tarama `scan\EP5-HS03_aligned.stl` aynı çerçevede (z ekseni 4 düzlem yüzün normali,
orijin 5 dairesel özelliğin ortak merkezi, +x kulak deliği), dönüşümsüz karşılaştırıldı.

## Modelleme kararları (ölçüden)
- Plaka hattı: kulak yayları kulak deliğiyle eş merkezli (`ear_cx` = `fs_pitch`/2), R 4,25; düz kenarlar eksenden 12,13
  (dört kenar 12,08-12,18), uç r 23,20 (tarama 23,18-23,30).
- Alt cepler 2 x (2,3 x 5,0 x 2,1), pimler arasında. Üst cepler: plaka hattı 1,6 içeri ofset, göbek çevresinde r 12,2 ve
  kulak deliği çevresinde R 4,4 dışarıda kalır, taban z 3,6 (tarama 3,56-3,64).
- Göbek: Ø23,94 -> ~33° konik -> Ø20,45, üst dış kenar 0,4 pah; iç Ø20,93 / Ø16,50 / Ø14,26 (kontrol parçası).

## Modellenmeyen / tutmayan
- Dar yan pencereleri (A_QA ilk tur notu üzerine eklendi): ince duvarda (Ø20,93 delik / kenar 12,13) L biçimli açıklık:
  geniş kısım 5,3 x 2,2 (z 2,3-4,5), altında 1,9 genişlikte yarık z 0,8'e iner; +y yanında x = +1,1, -y yanında x = -1,1
  merkezli, yarık sırasıyla -X / +X ucunda (eksene göre 180° simetrik; tarama +0,98 / -1,33).
- Göbek-plaka birleşiminde ~R1 dolgu modellenmedi (dolgu dar yanda plaka kenarını aşıyor: kenar r 12,13, göbek r 11,97).
- Ön kontrol (D, pencerelerden sonra): yerinde %84,8, kendi oturmasıyla %85,1 ±0,15 içinde (**%90 kapısının altında**).
  Gürültü sınırı: taramaya uydurulan silindirlerin (Ø20,93 / Ø16,50 / Ø14,26 / göbek) artıkları sd 0,065-0,124; sd 0,11
  ile kusursuz model de ±0,15 içinde ancak ≈%82'de kalır. Pencere bölgesi toplam farkın %3'ü. Fark bölgelere yayılı (plaka yanları %4,3,
  delikler %3,3, birleşim %1,8, göbek %3,6, pimler %1,3, üst %1,0 katkı); tarama gürültüsü HS03'te duvarlarda sd 0,10-0,12.
  A'nın kendi ICP'si ve %2 kırpması ile sonuç A_QA'da kesinleşir.

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_HS03 -> DATUM_AXIS AX_HS03_X -> SKETCH SK_PLATE -> EXTRUDE PLATE -> SKETCH SK_BOSS -> SWP104 BOSS -> SKETCH SK_BORE -> SWP104 BORES -> SKETCH SK_EARS -> EXTRUDE EAR_HOLES -> SKETCH SK_PINS -> EXTRUDE PINS -> SKETCH SK_POCKETS -> EXTRUDE POCKETS -> DATUM_PLANE PL_TOP_POCKET -> EXTRUDE  -> SKETCH SK_TOP_POCKET_KEEP -> EXTRUDE  -> SUBTRACT  -> SUBTRACT  -> SKETCH SK_WINDOW_PY -> EXTRUDE WINDOW_PY -> SKETCH SK_WINDOW_MY -> EXTRUDE WINDOW_MY

Sketch'ler: SK_PLATE WellConstrained, DOF 0, otomatik ölçü 0, 6 ölçü; SK_BOSS WellConstrained, DOF 0, otomatik ölçü 0, 7 ölçü; SK_BORE WellConstrained, DOF 0, otomatik ölçü 0, 9 ölçü; SK_EARS WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_PINS WellConstrained, DOF 0, otomatik ölçü 0, 12 ölçü; SK_POCKETS WellConstrained, DOF 0, otomatik ölçü 0, 8 ölçü; SK_TOP_POCKET_KEEP WellConstrained, DOF 0, otomatik ölçü 0, 5 ölçü; SK_WINDOW_PY WellConstrained, DOF 0, otomatik ölçü 0, 6 ölçü; SK_WINDOW_MY WellConstrained, DOF 0, otomatik ölçü 0, 6 ölçü.
Gövdeler: body 4177,72 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 1.1e-15, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `z_hs03` = 0, `hs03_plate_t` = 5,82, `hs03_bore1_d` = 20,93, `hs03_step1` = 8,16, `hs03_bore2_d` = 16,5, `hs03_step2` = 16,15, `hs03_bore3_d` = 14,26, `hs03_len` = 19,9, `hs03_ear_hole_d` = 4,55, `hs03_pin_d` = 3,15, `hs03_pin_len` = 3,02, `fs_pitch` = 37,9, `pin_x` = 14, `pin_y` = 5.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `ear_cx` | 18,95 (= `fs_pitch/2`) | ear end arc concentric with the ear hole [scan: tip r 23.18-23.30 = 18.95 + 4.25] |
| `ear_r` | 4,25 | ear end arc radius [scan: edge lines 12.13 from the axis, normal 65.45 deg, tangent to it] |
| `side_r` | 12,13 | plate side arc about the axis = distance of the straight edges [scan 12.08-12.18, four edges] |
| `boss_d` | 23,94 | boss lower outer diameter [scan 23.94 sd 0.075] |
| `boss_z1` | 11,1 | end of the lower boss cylinder from the underside [scan r 11.89 at 11.0, 11.66 at 11.5] |
| `top_d` | 20,45 | boss upper outer diameter [scan 20.45 sd 0.046] |
| `cone_z1` | 13,4 | end of the boss cone (start of the upper cylinder) [scan r 10.29 at 13.5] |
| `st1_ch` | 0,5 | chamfer at the lower step (bore1 -> bore2) [scan r 10.09 at 8.0, 8.55 at 8.5] |
| `pk_x` | 13,45 | underside pocket centre /X/ [scan 12.3 .. 14.6] |
| `pk_w` | 2,3 | underside pocket size along X [scan] |
| `pk_l` | 5 | underside pocket size along Y [scan -2.4 .. 2.7] |
| `pk_d` | 2,1 | underside pocket depth [scan floor z 2.13] |
| `tp_floor` | 3,6 | top pocket floor above the underside [scan 3.56-3.64] |
| `tp_rim` | 1,6 | top pocket rim along the plate edges [scan wall 10.55 from the axis vs edge 12.13] |
| `tp_ri` | 12,2 | top pocket inner wall radius about the axis [scan 12.21-12.25] |
| `tp_rh` | 4,4 | top pocket outer wall radius about the ear hole [scan 4.39-4.43] |
| `top_ch` | 0,4 | boss top outer edge chamfer [scan rounded] |
| `win_c` | 1,1 | side window centre offset along X (+y window at +win_c, -y window at -win_c) [scan +0.98 / -1.33] |
| `win_w` | 5,3 | side window width along X [scan 5.65 / 4.95] |
| `win_z0` | 0,8 | side window lower edge above the underside [scan 0.8-0.9] |
| `win_z1` | 4,5 | side window upper edge [scan 4.4-4.5] |
| `win_zs` | 2,3 | side window: the wide part starts here; below it only the slot [scan 2.3] |
| `win_ls` | 1,9 | side window lower slot width (at the -X end of the +y window, point symmetric) [scan] |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | -0,002 | 0,149 | 0,062 | 0,286 | 41,9 | 84,8 |
| underside | 12769 | +0,012 | 0,103 | 0,049 | 0,122 | 51,4 | 98,8 |
| plate top | 8319 | +0,051 | 0,205 | 0,059 | 0,309 | 44,3 | 86,4 |
| bore1 | 22357 | +0,011 | 0,108 | 0,059 | 0,212 | 42,9 | 86,5 |
| bore2 | 13755 | +0,009 | 0,104 | 0,065 | 0,193 | 39,9 | 90,9 |
| bore3 | 4796 | -0,057 | 0,084 | 0,086 | 0,166 | 21,5 | 91,9 |
| boss OD | 42971 | +0,012 | 0,075 | 0,045 | 0,153 | 54,6 | 94,6 |
| ear holes | 5439 | +0,013 | 0,105 | 0,050 | 0,220 | 50,0 | 89,2 |
| pins | 7652 | +0,042 | 0,231 | 0,059 | 0,615 | 42,4 | 76,6 |
| plate outline | 24366 | -0,025 | 0,142 | 0,074 | 0,278 | 31,0 | 84,9 |
| all: kendi en iyi oturmasından sonra | 200000 | -0,003 | 0,149 | 0,061 | 0,287 | 42,4 | 85,1 |

- all: taramayı CAD'e oturtan küçük hareket: dönme 0,071°, öteleme (0,011; 0,011; 0,012).
- CAD yüzeyinin % 12,6'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `plate_area_mm2`: 732.037125688325
- `top_pockets_removed_mm3`: 181.911
- `plate_length`: 46.4
