# EP5-EM01_COIL - parça raporu

Yazar: ULKA-B Stator. Tarih: 2026-10-16. Kontrol parçası revizyonu: H. Journal sonucu: **PASS** (32 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-EM01_COIL.prt`, `cad\EP5-EM01_COIL.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\EM01\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_em01.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve ve tasarım niyeti

Satın alınan parça, dış zarf modeli. Pompa çerçevesinde yerinde (Rev A §2): terminal ucu dış halkası
`z_em01_term` = -3,30 (Rev H: bobin iki duvar arasında ortalı), düz uç -46,82; terminal flanşı, fast-on'lar, Klixon yuvası ve
uç tırnakları +Y'de, bıçaklar -Z yönünde. Kontrol parçasından: gövde Ø47,21, boy 43,45, delik (iki çekirdek konisi:
uçlarda Ø21,90, ortada Ø21,45). Taramadan parça içi: uç yüz çöküntüleri (terminal 0,29 / düz 0,6, r < 17,25),
uç tırnakları (3,9 x 3,75, terminal ucunda +2,9, düz uçta 2,15), D biçimli terminal flanşı (gövdeye teğet kenarlar,
dış yüz 31,67, alt kenar ayağı 0,86, alt cep 0,56, bıçak tarafında üst basamak 0,43), iki fast-on 6,3 x 0,8
(X -15,12 / -2,35, dış yüz Y 31,0, uç Z -17,7) flanş ceplerinden geçerek, üçgen nervür (X -8,97, 1,82),
Klixon yuvası (duvarları taramaya uydurulmuş açık kutu, iki göz).
Modellenmeyen: sargı, Klixon, diyot, yazılar, delik ağzı çentikleri, bıçak delikleri, Klixon yuvası dış duvarındaki tel yarığı.

CR-B-01 kabul edildi (Rev E): `em01_len` 43,52. Rev H (A'nın montaj bulgusu): terminal ucu -3,30 ve terminal ucu dış
kenarına R1 yuvarlatma (gövde yayı + iki eğik flanş kenarı + flanş dış kenarı, uç yüzün kapalı dış sınırı;
taramada uç yüzde r 22,2-22,9 / 0,4 içeride 23,3-23,6 / 1,0 içeride 23,8). B'nin kendi girişim denetimi:
EM01 yüzeyinden 600 000 nokta EM02 içinde değil, en yakın 0,05 mm.

## Taramanın göstermediği / dışarıda tutulan bölgeler (QA'dan önce)

- Bobin uçlarının 1,2 mm ötesindeki tarayıcı kenar saçakları (tırnaklar hariç); delik ağzı çentikleri
  (r < 12,2, uçlardan 1,5 mm içinde).
- Delik içi yarım taranmış (kapsama 100-160°); Klixon gözlerinin tabanı taranmamış (flanş üstüne kadar
  türetildi); bıçakların iç yüzü taranmamış (kalınlık 0,8 standart).

## Kabul (B'nin kendi ölçümü; bağımsız QA A'da)

- K1 (işlevsel): gövde Ø, delik, boy Rev A expression'larıyla CAD'de tam. Tarama karşılaştırması (bütün parça
  rijit oturtmasından sonra, `qa\dev_fit.json`): gövde dışı ±0,15 içinde %100 (sd 0,039), delik %92, düz uç
  yüzü %97,2, terminal ucu yüzü %89,2 (Rev E).
- **K2 (T = 0,15): tutmadı** - bütün parça rijit en iyi oturtmadan sonra %82,7 ±0,15 içinde (kapı ≥ %90).
  Sapmanın büyük kısmı kalıp ayrıntısı olan flanş / Klixon yuvası / bıçak bölgesinde (Y > 23,7 bölgesinde
  noktaların yaklaşık yarısı bant dışı: Klixon yuvası duvar eğimleri ve iç bölmeler, bıçak kökleri, flanş
  kenar yuvarlatmaları). Gövde, delik ve uç yüzler bant içinde. Satın alınan parçada bu bölge zarf olarak
  modellendi; daha ileri ayrıntı Usta / A isterse eklenir.

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_TERM -> DATUM_AXIS AX_TERM_Y -> SKETCH SK_BODY -> SWP104 BOBBIN -> BLEND END_ROUND -> SKETCH SK_TAB -> EXTRUDE TAB_TERM -> EXTRUDE TAB_FAR -> SKETCH SK_PLATE -> EXTRUDE PLATE -> BLEND TERM_EDGE_ROUND -> SKETCH SK_FOOT -> EXTRUDE FLANGE_FOOT -> SKETCH SK_UPOCKET -> EXTRUDE FLANGE_UNDER_POCKET -> SKETCH SK_STEP -> EXTRUDE FLANGE_TOP_STEP -> SKETCH SK_NOTCH1 -> EXTRUDE BLADE_POCKET1 -> SKETCH SK_NOTCH2 -> EXTRUDE BLADE_POCKET2 -> SKETCH SK_BLADE1 -> EXTRUDE BLADE1 -> SKETCH SK_BLADE2 -> EXTRUDE BLADE2 -> DATUM_PLANE PL_RIB -> SKETCH SK_RIB -> EXTRUDE RIB -> SKETCH SK_HOUSING -> EXTRUDE KLIXON_HOUSING -> SKETCH SK_CAVITY_1 -> EXTRUDE KLIXON_CAVITY_1 -> SKETCH SK_CAVITY_2 -> EXTRUDE KLIXON_CAVITY_2

Sketch'ler: SK_BODY WellConstrained, DOF 0, otomatik ölçü 0, 10 ölçü; SK_TAB WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_PLATE WellConstrained, DOF 0, otomatik ölçü 0, 8 ölçü; SK_FOOT WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_UPOCKET WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_STEP WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_NOTCH1 WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_NOTCH2 WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_BLADE1 WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_BLADE2 WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_RIB WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_HOUSING WellConstrained, DOF 0, otomatik ölçü 0, 8 ölçü; SK_CAVITY_1 WellConstrained, DOF 0, otomatik ölçü 0, 8 ölçü; SK_CAVITY_2 WellConstrained, DOF 0, otomatik ölçü 0, 8 ölçü.
Gövdeler: body 63769,02 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 3.3e-08, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `z_em01_term` = -3,3, `em01_len` = 43,52, `em01_body_d` = 47,21, `em01_bore_min_d` = 21,45, `em01_bore_end_d` = 21,9, `em03_od` = 21, `hs04_od` = 20,78, `em02_w` = 32,06, `em02_out_x` = 53,96, `em02_t` = 3.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `rec_r` | 17,25 | plain-end face recess, outer radius [scan: floor to r 16.5, step 17.0..17.75] |
| `rec_dt` | 0,29 | terminal-end face recess depth below the outer ring [scan planes r 11.5-16.5: +0.21, r 18-22: -0.08] |
| `rec_d` | 0,6 | plain-end face recess depth [scan floor 42.85 vs face 43.45..43.50] |
| `end_r_t` | 1 | terminal-end outer edge round, on the half without the flange [scan r-z corner] |
| `end_r` | 1,5 | plain-end outer edge round [scan: face drops from r 22] |
| `tab_w` | 3,9 | end tab width (X) [scan -1.90..+1.97 / -1.90..+1.72] |
| `tab_r0` | 12,3 | end tab inner radius [scan r 12.3..12.4] |
| `tab_r1` | 16,05 | end tab outer face [scan 16.10 / 15.96] |
| `tab_h_term` | 2,9 | terminal-end tab height past the end face [scan 2.80..3.03] |
| `tab_h_far` | 2,15 | plain-end tab height past the end face [scan 45.60 - 43.45] |
| `plate_y1` | 31,67 | terminal plate outer face [scan 31.666] |
| `plate_y0` | 17,5 | half size of the square notch that keeps the flange sketch out of the bore and the end recess (construction, > rec_r) |
| `plate_xn` | 22,43 | terminal plate outer corner on -X [scan -22.43] |
| `plate_xp` | 22,04 | terminal plate outer corner on +X [scan 22.04] |
| `plate_t` | 5,63 | flange top from the end face [scan 5.56..5.73] |
| `foot_d` | 0,86 | flange underside rim below the end face plane [scan -0.77..-0.99] |
| `foot_y0` | 21,5 | flange underside rim starts at Y [scan row Y 22 at -0.9, Y 20 at 0] |
| `upk_d` | 0,56 | underside pocket depth inside the rim [scan pocket -0.27..-0.42 vs rim -0.86] |
| `upk_x0` | 21,2 | flange underside pocket -X edge [scan height map] |
| `upk_x1` | 17 | flange underside pocket +X edge [scan height map] |
| `upk_y0` | 23,3 | flange underside pocket Y from [scan height map] |
| `upk_y1` | 27,3 | flange underside pocket Y to [scan height map] |
| `step_d` | 0,43 | flange top step on the blade side [scan 5.15..5.29 vs 5.6] |
| `step_x1` | 1,5 | flange top step +X edge [scan between X 0 and 3] |
| `step_y0` | 25 | flange top step Y from [scan between Y 24 and 26] |
| `blade_w` | 6,3 | fast-on blade width (6.3 x 0.8 standard) [scan 6.25 / 6.20] |
| `blade_t` | 0,8 | fast-on blade thickness (standard; scan sees one face only) |
| `blade_y` | 31 | fast-on blade outer face [scan 31.06 / 30.95] |
| `blade_x1` | -15,12 | fast-on blade 1 centre X [scan] |
| `blade_x2` | -2,35 | fast-on blade 2 centre X [scan] |
| `notch_w` | 6,46 | pocket in the flange outer face under each blade, width [scan blade side faces -18.36/-11.90, -5.59/0.92] |
| `notch_y0` | 30,45 | pocket bottom (flange outer face there) [scan sections 30.4..30.6] |
| `blade_top` | 14,7 | fast-on blade tip from the end face [scan 14.72 / 14.67] |
| `rib_x` | -8,97 | triangular rib mid plane X [scan faces -9.88 / -8.06] |
| `rib_t` | 1,82 | triangular rib thickness [scan] |
| `rib_y0` | 21 | rib inner edge (inside the body, construction) |
| `rib_h0` | 21,54 | rib height at rib_y0 from the end face [scan line z = 18.26 - 1.64 (y - 24)] |
| `hs_ax` | 5,248 | Klixon housing corner (outer, from the fitted walls) |
| `hs_ay` | 20,015 | Klixon housing corner (outer, from the fitted walls) |
| `hs_bx` | 9,988 | Klixon housing corner (outer, from the fitted walls) |
| `hs_by` | 27,935 | Klixon housing corner (outer, from the fitted walls) |
| `hs_cx` | 19,839 | Klixon housing corner (outer, from the fitted walls) |
| `hs_cy` | 22,338 | Klixon housing corner (outer, from the fitted walls) |
| `hs_dx` | 15,099 | Klixon housing corner (outer, from the fitted walls) |
| `hs_dy` | 14,418 | Klixon housing corner (outer, from the fitted walls) |
| `hk_ax` | 8,228 | Klixon housing corner (cavity, from the fitted walls) |
| `hk_ay` | 22,898 | Klixon housing corner (cavity, from the fitted walls) |
| `hk_bx` | 10,395 | Klixon housing corner (cavity, from the fitted walls) |
| `hk_by` | 26,519 | Klixon housing corner (cavity, from the fitted walls) |
| `hk_cx` | 13,746 | Klixon housing corner (cavity, from the fitted walls) |
| `hk_cy` | 24,615 | Klixon housing corner (cavity, from the fitted walls) |
| `hk_dx` | 11,579 | Klixon housing corner (cavity, from the fitted walls) |
| `hk_dy` | 20,994 | Klixon housing corner (cavity, from the fitted walls) |
| `hm_ax` | 12,449 | Klixon housing corner (cavity, from the fitted walls) |
| `hm_ay` | 20,5 | Klixon housing corner (cavity, from the fitted walls) |
| `hm_bx` | 14,616 | Klixon housing corner (cavity, from the fitted walls) |
| `hm_by` | 24,121 | Klixon housing corner (cavity, from the fitted walls) |
| `hm_cx` | 18,377 | Klixon housing corner (cavity, from the fitted walls) |
| `hm_cy` | 21,985 | Klixon housing corner (cavity, from the fitted walls) |
| `hm_dx` | 16,21 | Klixon housing corner (cavity, from the fitted walls) |
| `hm_dy` | 18,364 | Klixon housing corner (cavity, from the fitted walls) |
| `hs_top` | 22,49 | Klixon housing top from the end face [scan 22.49] |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 194534 | +0,024 | 0,169 | 0,093 | 0,358 | 28,3 | 74,5 |
| (toplam dışı bırakılan) | 5466 | +0,067 | 0,111 | 0,068 | 0,277 | 41,9 | 76,2 |
| body OD (away from plate / housing) | 40586 | +0,024 | 0,106 | 0,093 | 0,187 | 20,9 | 83,9 |
| bore | 12483 | +0,053 | 0,069 | 0,045 | 0,198 | 54,9 | 90,2 |
| terminal end face | 24798 | +0,059 | 0,103 | 0,088 | 0,211 | 28,0 | 79,5 |
| plain end face + recess | 20217 | -0,063 | 0,063 | 0,062 | 0,174 | 41,0 | 91,8 |
| end tabs | 1244 | -0,030 | 0,111 | 0,056 | 0,253 | 46,1 | 82,3 |
| plate outer + top | 11530 | -0,003 | 0,261 | 0,083 | 0,626 | 35,7 | 66,8 |
| fast-on blades | 3064 | +0,011 | 0,129 | 0,085 | 0,265 | 29,4 | 76,8 |
| Klixon housing | 4756 | +0,158 | 0,313 | 0,183 | 0,626 | 11,9 | 40,5 |
| whole part (rigid best fit, K2): kendi en iyi oturmasından sonra | 194534 | -0,007 | 0,145 | 0,049 | 0,320 | 50,5 | 83,0 |
| body OD + bore (pose of the bobbin): kendi en iyi oturmasından sonra | 53069 | +0,004 | 0,054 | 0,028 | 0,106 | 74,0 | 98,2 |

- whole part (rigid best fit, K2): taramayı CAD'e oturtan küçük hareket: dönme 0,502°, öteleme (-0,044; -0,163; -0,058).
- body OD + bore (pose of the bobbin): taramayı CAD'e oturtan küçük hareket: dönme 0,232°, öteleme (-0,053; -0,155; 0,987).
- CAD yüzeyinin % 38,6'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `flange notch corner loss mm2`: 2.660156449830731
- `terminal edge round edges`: 4
- `z_planes`: {"terminal end face": -3.299999999999997, "plain end face": -46.82, "terminal tab top": -0.39999999999999725, "plain tab end": -48.97, "plate top": -8.929999999999996, "blade tips": -17.999999999999996}
- `tabs vs EM02`: "tabs (width 3.90, r 12.30..16.05) sit in the EM02 outlet-wall seam slot (terminal end) and the inlet-wall notch (plain end); EM02 openings must clear them"
- `not_modelled`: "winding, Klixon, diode, lettering, bore-mouth notches, plate feet (plate underside 0.3..0.86 below the end face at r > 23), blade dimple holes"
