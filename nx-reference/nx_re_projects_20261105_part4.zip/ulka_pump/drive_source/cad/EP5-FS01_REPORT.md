# EP5-FS01_SCR-FLANGE - rapor (ULKA-A)

2026-10-16, Rev A kontrol parçasına bağlı. Journal `C:\NX_MCP_WORKSPACE\ulka\parts\FS01\fs_build.py` -> `fs_build.json` PASS.

- Standart eşleme: **ISO 7045 M4 x 8 H** (silindir/pan baş, yıldız). Kaynak: F09 (pan baş, makine dişi, ~13 diş
  görünür -> M4); EM02 delikleri Ø3,5 (M4 diş, B), HS03 kulak delikleri Ø4,55 (D). Boy 8 türetildi: M4x10'un ucu
  çerçeve içine 1,2 girip EM01 makara alnına değerdi; M4x8 EM02'de 2,18 diş boyu tutar.
- Yerinde modellendi: +X vidası, eksen (fs_pitch/2, 0) = (18,95; 0), baş oturma yüzü z_fs01_head = 5,82 (HS03 kulak
  üstü), uç z = -2,18. İkinci kopya montajda X'te -37,9.
- Interpart expression: fs_pitch, z_fs01_head, fs01_d, fs01_len, fs01_dk, fs01_k. Parça içi: tip_leg 0,5, crown_r 1,2,
  rec_m 4,4, rec_w 1,0, rec_t 1,9 (yıldız yuva ISO 4757 H2 yaklaşımı, türetildi).
- Basitleştirme: diş modellenmedi (gövde Ø4 = diş dış çapı); baş tepesi küre yerine R1,2 kenar yuvarlatması.
- Kontroller: hacimler analitik (gövde+baş 256,354; yuvarlatma+pah sonrası 247,668; yuva 14,82 mm³), uç ve baş z,
  eksen x. Hacim 232,85 mm³. STEP `EP5-FS01_SCR-FLANGE.stp`.
- Tarama yok (satın alınan parça): K1/K2 uygulanmaz.
