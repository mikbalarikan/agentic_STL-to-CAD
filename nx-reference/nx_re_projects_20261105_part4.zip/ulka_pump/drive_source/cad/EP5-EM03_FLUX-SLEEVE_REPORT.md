# EP5-EM03_FLUX-SLEEVE - parça raporu

Yazar: ULKA-B Stator. Tarih: 2026-10-16. Kontrol parçası revizyonu: B. Journal sonucu: **PASS** (19 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-EM03_FLUX-SLEEVE.prt`, `cad\EP5-EM03_FLUX-SLEEVE.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\EM03\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_em03.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve ve tasarım niyeti

Pompa çerçevesinde yerinde, EM03-A (giriş) konumunda (Rev A §2): alt yüz `z_em03a_bot` = -47,12 (EM02 giriş
duvarı iç yüzü), üst yüz -28,22; yarık +X. EM03-B aynı dosyanın ikinci kopyasıdır: A +(em03_len + hs04_h) = 28,0
öteler (alt -19,12, üst -0,22). OD / ID / boy / yarık kontrol parçasından. Parça içi tek ölçü `em03_edge_r` 0,3:
dört uç kenarda rulo sac kenar kırması (taramada yuvarlak).

## Taramanın göstermediği / dışarıda tutulan bölgeler (QA'dan önce)

- Burç 1'in bir uç yüzü taranmamış (uçta 18,7-18,8'e kadar nokta var); boy burç 2'den (18,92) -> 18,9.
- Yarık taramada kısmen köprülenmiş (dış deri yarığın üstünü kapatıyor); genişlik 0,5 türetildi (F04).
- Dışarıda: r < 7,9 ve r > 11,0 ile uçların 0,3 ötesi (tarama uç kırıntıları / masa). Tarama yarığı +X'e döndürüldü
  (burç 1: +69°, burç 2: -93°).

## Kabul (B'nin kendi ölçümü; bağımsız QA A'da)

- K1: OD 21,00 / ID 16,71 / boy 18,9 = Rev A (CAD tam). Tarama: OD 21,002 / 20,972, ID 16,714 / 16,716, boy 18,92
  (burç 2).
- K2 (T = 0,15): burç 2 (aşağıdaki tablo) %95,2; burç 1 (`qa\dev_sleeve1.json`) %95,1 - ikisi de tuttu.

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_EM03_BOT -> DATUM_AXIS AX_BOT_X -> SKETCH SK_PROFILE -> SWP104 SLEEVE -> BLEND EDGE_BREAKS -> SKETCH SK_SLIT -> EXTRUDE SLIT

Sketch'ler: SK_PROFILE WellConstrained, DOF 0, otomatik ölçü 0, 3 ölçü; SK_SLIT WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü.
Gövdeler: body 2376,60 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 3.2e-07, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `z_em03a_bot` = -47,12, `em03_od` = 21, `em03_id` = 16,71, `em03_len` = 18,9, `em03_slit_w` = 0,5, `hs01_tube_od` = 16,09, `em01_bore_min_d` = 21,45, `em02_hole_out_d` = 21,24.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `em03_edge_r` | 0,3 | rolled-sheet edge break on the four end edges [scan r-z: rounded ~0.3] |
| `slit_over` | 0,5 | slit sketch overlap past ID / OD (construction) |
| `c_em03_tube` | 0,31 (= `(em03_id-hs01_tube_od)/2`) | radial clearance sleeve / HS01 tube |
| `c_em03_bore` | 0,225 (= `(em01_bore_min_d-em03_od)/2`) | radial clearance sleeve / EM01 bore (narrowest) |
| `c_em03_hole` | 0,12 (= `(em02_hole_out_d-em03_od)/2`) | radial clearance EM03-B / EM02 outlet hole |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 197791 | -0,007 | 0,068 | 0,026 | 0,148 | 72,2 | 95,2 |
| (toplam dışı bırakılan) | 2209 | +0,665 | 0,292 | 0,608 | 1,299 | 0,0 | 0,0 |
| outer wall (OD) | 122934 | -0,006 | 0,033 | 0,017 | 0,061 | 90,8 | 99,5 |
| inner wall (ID) | 30245 | +0,006 | 0,058 | 0,046 | 0,108 | 55,0 | 98,7 |
| end faces | 26571 | +0,024 | 0,111 | 0,059 | 0,211 | 43,2 | 88,3 |
| walls: kendi en iyi oturmasından sonra | 153272 | -0,004 | 0,041 | 0,021 | 0,075 | 83,8 | 99,0 |

- walls: taramayı CAD'e oturtan küçük hareket: dönme 0,422°, öteleme (-0,024; 0,024; -0,000).
- CAD yüzeyinin % 48,9'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `z_planes`: {"EM03-A bottom": -47.12, "EM03-A top": -28.22}
- `clearances`: {"sleeve/HS01 tube": 0.3100000000000005, "sleeve/EM01 bore": 0.22499999999999964, "EM03-B/EM02 outlet hole": 0.11999999999999922}
