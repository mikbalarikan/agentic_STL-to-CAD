# EP5-SL03_ORING-S - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: F. Journal sonucu: **PASS** (10 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-SL03_ORING-S.prt`, `cad\EP5-SL03_ORING-S.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\SL03\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_sl03.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Yerinde, nötr (kalıp) halinde torus: alt yüz `z_sl03` (HS02 flanşı üstü, HS03 üst kademesine yüz contası). ID / kesit kontrol parçasından.

Rev F (CR-D-03): 13,15 x 1,10 (OD 15,35), A'nın ID / OD uydurmasından; standart dışı, tarama değeri (en yakın metrik 13 x 1,0). Tarama tepe yüksekliği 0,91 (halka altlıkta yassı), genişlik 1,34. Ön kontrol: kendi oturmasıyla %84,8 ±0,15 (Rev A kesitiyle %60) - elastomer bandında yassılık nedeniyle **tutmayabilir**.

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_SL03 -> DATUM_AXIS AX_PL_SL03 -> SKETCH SK_SECTION -> SWP104 TORUS

Sketch'ler: SK_SECTION WellConstrained, DOF 0, otomatik ölçü 0, 3 ölçü.
Gövdeler: body 42,54 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 8.4e-16, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `sl03_id` = 13,15, `sl03_cs` = 1,1, `z_sl03` = 15,3.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `z_sl03_ref` | 15,3 (= `z_sl03`) | reference face of the ring (lower face) |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | -0,054 | 0,156 | 0,128 | 0,303 | 21,7 | 58,5 |
| all: kendi en iyi oturmasından sonra | 200000 | +0,033 | 0,110 | 0,063 | 0,260 | 40,1 | 84,8 |

- all: taramayı CAD'e oturtan küçük hareket: dönme 2,153°, öteleme (0,014; 0,160; 0,184).
- CAD yüzeyinin % 28,5'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `ring`: {"ID": 13.15, "cs": 1.1, "OD": 15.350000000000001, "z_ref": 15.3, "ref_face": "lower"}
