# EP5-VL05_VALVE-CAGE - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: F. Journal sonucu: **PASS** (12 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-VL05_VALVE-CAGE.prt`, `cad\EP5-VL05_VALVE-CAGE.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\VL05\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_vl05.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Yerinde: alt yüz `z_vl05` = `z_hs02` + `hs02_vl05_z` (31,92; Rev D, CR-D-02), HS02 Ø8,52 deliğinde, üstünde G1/8 diş. Halka Ø8,4
(`vl05_od`) x 4,5 (`vl05_t`), et 0,8, iki kol 1,2 genişlikte (artı), göbek Ø3,4, göbek deliği Ø2,4 (VL03 sap kılavuzu,
**türetildi**). Dış tırnaklar (~Ø8,6-9,0) modellenmedi.

## Tarama
Tarama çok zayıf (delikli, parçalı); ön kontrol %30-34 ±0,15 - **tutmadı**; şekil F18 fotoğrafından, ölçü kaynağı dış
çap ve kalınlık (D_MEASURED §4).

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_VL05 -> DATUM_AXIS AX_PL_VL05 -> SKETCH SK_RING -> EXTRUDE RING -> SKETCH SK_ARMS -> EXTRUDE  -> SKETCH SK_ARMS2 -> EXTRUDE  -> SKETCH SK_HUB -> EXTRUDE  -> SKETCH SK_HOLE -> EXTRUDE 

Sketch'ler: SK_RING WellConstrained, DOF 0, otomatik ölçü 0, 2 ölçü; SK_ARMS WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_ARMS2 WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_HUB WellConstrained, DOF 0, otomatik ölçü 0, 1 ölçü; SK_HOLE WellConstrained, DOF 0, otomatik ölçü 0, 1 ölçü.
Gövdeler: body 143,57 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 9.9e-16, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `z_vl05` = 44,34, `vl05_od` = 8,4, `vl05_t` = 4,5.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `ring_w` | 0,8 | ring wall [scan ring 8.0-8.4 outer, cross arms inside; F18] |
| `arm_w` | 1,2 | cross arm width [scan] |
| `hub_d` | 3,4 | hub diameter at the cross centre [scan] |
| `hub_hole_d` | 2,4 | hub hole (VL03 stem guide), DERIVED |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | -0,079 | 0,295 | 0,249 | 0,555 | 8,9 | 29,5 |
| all: kendi en iyi oturmasından sonra | 200000 | -0,060 | 0,290 | 0,220 | 0,555 | 10,7 | 33,7 |

- all: taramayı CAD'e oturtan küçük hareket: dönme 2,621°, öteleme (0,593; -2,009; 0,133).
- CAD yüzeyinin % 66,7'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `open_area_mm2`: 23.514
