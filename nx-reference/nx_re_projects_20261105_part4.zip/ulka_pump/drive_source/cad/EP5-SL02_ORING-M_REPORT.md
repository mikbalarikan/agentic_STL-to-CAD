# EP5-SL02_ORING-M - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: F. Journal sonucu: **PASS** (10 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-SL02_ORING-M.prt`, `cad\EP5-SL02_ORING-M.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\SL02\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_sl02.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Yerinde, nötr (kalıp) halinde torus: alt yüz `z_sl02` (HS01 flanşı üstü, HS03 Ø20,93 içinde). ID / kesit kontrol parçasından.

Standart eşleme: **ISO 3601-1 / AS568-115, 15,47 x 2,62** (tarama OD 20,70). Taramada yükseklik 2,89 (yatarken hafif ovallik). Ön kontrol: kendi oturmasından sonra %87,3 ±0,15 (elastomer bandı ±0,10; yalnız üst yarı taranmış).

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_SL02 -> DATUM_AXIS AX_PL_SL02 -> SKETCH SK_SECTION -> SWP104 TORUS

Sketch'ler: SK_SECTION WellConstrained, DOF 0, otomatik ölçü 0, 3 ölçü.
Gövdeler: body 306,39 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 1.7e-15, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `sl02_id` = 15,47, `sl02_cs` = 2,62, `z_sl02` = 4,71.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `z_sl02_ref` | 4,71 (= `z_sl02`) | reference face of the ring (lower face) |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | +0,105 | 0,180 | 0,165 | 0,351 | 15,4 | 45,2 |
| all: kendi en iyi oturmasından sonra | 200000 | +0,025 | 0,134 | 0,054 | 0,220 | 47,2 | 87,3 |

- all: taramayı CAD'e oturtan küçük hareket: dönme 0,643°, öteleme (0,027; 0,034; -0,231).
- CAD yüzeyinin % 37,1'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `ring`: {"ID": 15.47, "cs": 2.62, "OD": 20.71, "z_ref": 4.71, "ref_face": "lower"}
