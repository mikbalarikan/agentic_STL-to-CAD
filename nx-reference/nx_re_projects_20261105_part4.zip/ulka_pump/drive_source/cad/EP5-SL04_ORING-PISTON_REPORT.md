# EP5-SL04_ORING-PISTON - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: F. Journal sonucu: **PASS** (10 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-SL04_ORING-PISTON.prt`, `cad\EP5-SL04_ORING-PISTON.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\SL04\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_sl04.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Yerinde, nötr (kalıp) halinde torus: üst yüz HS02 havşa tabanında (`z_hs02` + `hs02_sl04_depth`). ID / kesit kontrol parçasından.

Standart eşleme: **metrik 4,5 x 2,0** (OD 8,5). Piston d_p 4,97 ile radyal sıkışma `sq_sl04` %8,5. Ön kontrol: %89,1 ±0,15.

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_SL04 -> DATUM_AXIS AX_PL_SL04 -> SKETCH SK_SECTION -> SWP104 TORUS

Sketch'ler: SK_SECTION WellConstrained, DOF 0, otomatik ölçü 0, 3 ölçü.
Gövdeler: body 64,15 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 0.0e+00, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `sl04_id` = 4,5, `sl04_cs` = 2, `z_hs02` = 12,42, `hs02_sl04_depth` = 2,15.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `z_sl04_ref` | 14,57 (= `z_hs02+hs02_sl04_depth`) | reference face of the ring (upper face) |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | +0,047 | 0,244 | 0,057 | 0,669 | 45,2 | 86,6 |
| all: kendi en iyi oturmasından sonra | 200000 | +0,070 | 0,243 | 0,038 | 0,682 | 58,9 | 89,1 |

- all: taramayı CAD'e oturtan küçük hareket: dönme 0,982°, öteleme (-0,057; -0,039; 0,055).
- CAD yüzeyinin % 38,0'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `ring`: {"ID": 4.5, "cs": 2.0, "OD": 8.5, "z_ref": 14.57, "ref_face": "upper"}
