# EP5-VL04_SPRING-VALVE - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: D. Journal sonucu: **PASS** (9 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-VL04_SPRING-VALVE.prt`, `cad\EP5-VL04_SPRING-VALVE.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\VL04\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_vl04.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve ve tasarım
Kendi çerçevesinde: z0 = giriş tarafı ucu (VL03 başına dayanan küçük uç), +Z çıkışa (VL05'e). Boy `vl04_len` (=
`vl04_l0` 6,8). Konik: Dm 3,95 (OD 4,4) -> 3 sarımda smoothstep -> Dm 5,35 (OD 5,8); toplam 5,5 sarım, aktif hatve 1,53,
blok ≈2,9. Büyük uç OD 5,8 alındı (tarama ~6,2 zayıf/bulanık; Ø6,0 valf deliğinde çalışır). Tel Ø 0,45 (`vl04_d`).

## Tarama
Parçalı; karşılaştırma yapılmadı. Montaj (CR-D-02): VL03 başı ile VL05 arası montaj boyu 3,9, valf kalkışı ≈1,0.

## Unsur ağacı

DATUM_CSYS  -> SPLINE_LAW CENTRE_LINE -> SWP104 WIRE_TUBE

Sketch'ler: .
Gövdeler: body 13,17 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 5.4e-16, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `vl04_l0` = 6,8, `vl04_d` = 0,45.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `vl04_dm1` | 3,95 | mean coil diameter at the small (inlet-side) end [scan: OD 4.4 -> 6.2 (weak); big end kept 5.8 OD for the 6.0 valve bore] |
| `vl04_dm2` | 5,35 | mean coil diameter at the big end [scan: OD 4.4 -> 6.2 (weak); big end kept 5.8 OD for the 6.0 valve bore] |
| `vl04_ntap` | 3 | active turns over which the diameter grows (smoothstep) |
| `vl04_ncyl` | 0 | active turns at the big diameter |
| `vl04_a` | 0,75 | closed turns at each end (coils touch: pitch pe) |
| `vl04_b` | 0,5 | pitch ramp between the closed and the active turns |
| `vl04_gap` | 0,05 | gap between touching closed coils (keeps the wire body valid) |
| `vl04_nt` | 5,5 (= `2*vl04_a+2*vl04_b+vl04_ntap+vl04_ncyl`) | total turns |
| `vl04_pe` | 0,5 (= `vl04_d+vl04_gap`) | closed-end pitch |
| `vl04_len` | 6,8 (= `vl04_l0`) | spring length: free length by default; A sets the installed length on a copy |
| `vl04_n_act` | 3 (= `vl04_nt-2*vl04_a-2*vl04_b`) | turns at the active pitch |
| `vl04_p` | 1,5286 (= `(vl04_len-vl04_d-2*vl04_pe*vl04_a-vl04_pe*vl04_b)/(vl04_b+vl04_n_act)`) | active pitch, DERIVED from the length |
| `vl04_z0` | 0,225 (= `vl04_d/2`) | wire centre at the start (end coil on z = 0) |
| `vl04_zA` | 0,6 (= `vl04_z0+vl04_pe*vl04_a`) |  |
| `vl04_zB` | 1,1071 (= `vl04_zA+(vl04_pe+vl04_p)/2*vl04_b`) |  |
| `vl04_zC` | 5,6929 (= `vl04_zB+vl04_p*((vl04_nt-vl04_a-vl04_b)-(vl04_a+vl04_b))`) |  |
| `vl04_zD` | 6,2 (= `vl04_zC+(vl04_p+vl04_pe)/2*vl04_b`) |  |

## Tarama karşılaştırması

Yapılmadı: taraması parçalı / zayıf. Ölçüler `sessions/D_MEASURED.md` tablosundan.

## Journal notları

- `spring`: {"d": 0.45, "OD_small": 4.4, "OD_big": 5.8, "L0": 6.8, "pitch": 1.5286, "turns_total": 5.5, "turns_active_pitch": 3.0, "solid_length_approx": 2.925, "wire_length": 82.83}
