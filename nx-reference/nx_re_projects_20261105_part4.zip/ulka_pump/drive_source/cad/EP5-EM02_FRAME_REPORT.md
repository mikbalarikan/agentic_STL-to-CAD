# EP5-EM02_FRAME - parça raporu

Yazar: ULKA-B Stator. Tarih: 2026-10-16. Kontrol parçası revizyonu: H. Journal sonucu: **PASS** (30 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-EM02_FRAME.prt`, `cad\EP5-EM02_FRAME.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\EM02\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_em02.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve ve tasarım niyeti

NX Sheet Metal parçası (Tab + 4 Flange + Normal Cutout'lar), pompa çerçevesinde yerinde (Rev A §1-2): Z = iki
büyük deliğin ekseni, orijin çıkış duvarı dış yüzü, düz duvarlar ±X, açık yanlar ±Y. Tek şerit: giriş duvarı Tab,
düz duvarlar 90° flanş (iç R `em02_ri_in`), çıkış duvarının iki yarısı içe dönen flanşlar (iç R `em02_ri_out`,
yerel radyüs); iki uç X = 0'da 1,03 mm birleşme yarığıyla buluşur. Delik / pim / vida konumları ve çapları
kontrol parçasından. Parça içi (taramadan): `seam_w` 1,03, çentikler 4,15 x (kenardan |Y| 11,82'ye) R0,8 köşeli (türetildi; R1 EM01 tırnak köşesine 0,02 değiyordu) (iki
delikli duvarda da, ±Y; EM01 tırnağı 3,9 bunlara oturur, yan boşluk 0,125), düz duvar pencereleri (çıkış
bükümünde, Y ±3,1, çıkış yarısı |X| 22,3'te biter, düz duvar Z -5,75'e kadar açık - bükümün tamamı kesik;
pencereler extrude çıkarma, Normal Cutout değil). K faktörü 0,44 türetildi (yalnız açınımı etkiler).
Modellenmeyen: etiket, şerit kenarlarının bükümlerdeki şişmesi (Y 16,2'ye), çıkış duvarının düzlemsizliği
(ortada +0,2, köşelere doğru -0,2..-0,45), M4 diş (Rev A §5 kozmetik).

CR-B-02 kabul edildi (Rev G): dört bükümde tek iç R 1,9 (`em02_ri_out` 1,9). Model Rev G ile yeniden koşuldu.

## Taramanın göstermediği / dışarıda tutulan bölgeler (QA'dan önce)

- Delikli duvarların her biri tek yüzden taranmış (çıkış: dış, giriş: iç yüz); diğer yüz t = 3,0 ile.
- Giriş köşelerinin dış yüzü kısmen taranmamış. Dışarıda: |Y| > 16,3 (şerit kenarı ötesindeki tarama saçağı).

## Kabul (B'nin kendi ölçümü; bağımsız QA A'da)

- K1: delikler (Ø21,24 / Ø16,74 / Ø3,5 x2 / Ø3,72 x4), t, iç eksenel açıklık Rev A expression'larıyla CAD'de tam.
  Tarama karşılaştırması (rijit oturtma sonrası, `qa\dev_fit.json`): büyük delikler ±0,15 içinde %97-99, küçük
  delikler %91, düz duvarlar %96, giriş duvarı %93.
- **K2 (T = 0,15): tutmadı** - Rev G modelinde bütün parça rijit en iyi oturtmadan sonra %89,6 (kapı ≥ %90; Rev A
  radyüsleriyle %87,2). Bant dışı noktalar bükümlerde (%60 içinde) ve çıkış duvarının köşelere doğru çöken
  bölgesinde (%81): sac düzlemsizliği, sabit kalınlıklı sac metalde modellenmiyor.

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_IN_OUT -> SKETCH SK_TAB -> Base Tab TAB_INLET_WALL -> SB_FLANGE FLANGE_PX -> SB_FLANGE FLANGE_NX -> SB_FLANGE FLANGE_OUT_PX -> SB_FLANGE FLANGE_OUT_NX -> DATUM_PLANE PL_OUT -> SKETCH SK_OUT_HOLES -> Normal Cutout CUT_OUT_HOLES -> SKETCH SK_OUT_NOTCHES -> Normal Cutout CUT_OUT_NOTCHES -> SKETCH SK_IN_NOTCHES -> Normal Cutout CUT_IN_NOTCHES -> SKETCH SK_WINDOWS -> EXTRUDE WINDOW_PX -> EXTRUDE WINDOW_NX

Sketch'ler: SK_TAB WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü; SK_OUT_HOLES WellConstrained, DOF 0, otomatik ölçü 0, 17 ölçü; SK_OUT_NOTCHES WellConstrained, DOF 0, otomatik ölçü 0, 20 ölçü; SK_IN_NOTCHES WellConstrained, DOF 0, otomatik ölçü 0, 21 ölçü; SK_WINDOWS WellConstrained, DOF 0, otomatik ölçü 0, 4 ölçü.
Gövdeler: body 15957,95 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 1.1e-15, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `z_em02_out` = 0, `em02_t` = 3, `em02_in_axial` = 44,12, `z_em02_in_out` = -50,12, `em02_out_x` = 53,96, `em02_w` = 32,06, `em02_ri_out` = 1,9, `em02_ri_in` = 1,9, `em02_hole_out_d` = 21,24, `em02_hole_in_d` = 16,74, `fs_pitch` = 37,9, `em02_fs_hole_d` = 3,5, `pin_x` = 14, `pin_y` = 5, `em02_pin_hole_d` = 3,72, `em03_od` = 21, `hs01_tube_od` = 16,09, `em01_body_d` = 47,21, `em01_len` = 43,52.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `k_factor` | 0,44 | neutral factor (DERIVED: shop default for t/r about 1-2; only the flat blank depends on it) |
| `seam_w` | 1,03 | seam between the two strip ends in the outlet wall [scan end faces X -0.55 / +0.48] |
| `notch_w` | 4,15 | notch width, both holed walls [scan X +-2.04 outlet, +-2.10 inlet] |
| `notch_bot` | 11,82 | notch bottom from the axis [scan inlet +11.80 / -11.84] |
| `notch_r` | 0,8 | notch bottom corner radius [scan: gap 3.0..3.6 at 0.2 above the bottom], DERIVED; 0.8 clears the EM01 tab corner (3.9 wide, r 12.3) |
| `win_w` | 6,2 | window in the flat walls at the outlet bends, width along Y [scan Y -3.3..+2.9] |
| `win_z0` | 5,75 | window far edge from the outlet outer face [scan section Y=0: flat-wall top at -5.7..-5.8] |
| `win_z1` | -1 | window runs out through the outlet face: the whole bend is cut away there (construction) |
| `win_x0` | 22,3 | window: the outlet-wall half ends at |X| [scan section Y=0: end face 22.2..22.3] |
| `c_tab_notch` | 0,125 (= `(notch_w-3.9)/2`) | side clearance EM01 end tab (3.9) / notch |
| `c_em01_axial` | 0,6 (= `em02_in_axial-em01_len`) | axial room of the EM01 bobbin between the holed walls |
| `c_em01_x` | 0,375 (= `(em02_out_x-2*em02_t-em01_body_d)/2`) | radial room EM01 body / flat walls |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 199758 | -0,027 | 0,110 | 0,059 | 0,206 | 42,4 | 89,1 |
| (toplam dışı bırakılan) | 242 | +0,839 | 0,186 | 0,842 | 1,136 | 0,0 | 0,0 |
| outlet wall faces | 20453 | -0,033 | 0,108 | 0,065 | 0,228 | 40,5 | 79,8 |
| inlet wall faces | 24437 | -0,006 | 0,081 | 0,069 | 0,149 | 38,9 | 95,1 |
| flat walls | 101729 | -0,025 | 0,072 | 0,057 | 0,142 | 43,0 | 95,6 |
| outlet big hole | 3701 | -0,004 | 0,056 | 0,030 | 0,112 | 73,2 | 97,2 |
| inlet big hole | 2824 | -0,007 | 0,039 | 0,021 | 0,088 | 83,8 | 99,8 |
| small holes (screw + pin) | 1794 | -0,005 | 0,089 | 0,053 | 0,197 | 47,5 | 90,0 |
| bends | 26268 | -0,056 | 0,173 | 0,126 | 0,358 | 21,2 | 58,9 |
| whole part (rigid best fit, K2): kendi en iyi oturmasından sonra | 199758 | -0,021 | 0,106 | 0,043 | 0,207 | 56,1 | 89,6 |

- whole part (rigid best fit, K2): taramayı CAD'e oturtan küçük hareket: dönme 0,078°, öteleme (-0,004; 0,007; 0,027).
- CAD yüzeyinin % 24,3'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `bends (angle, inner radius)`: [[90.0, 1.9], [90.0, 1.9], [90.0, 1.9], [90.0, 1.9]]
- `clearances`: {"EM01 axial room": 0.5999999999999943, "EM01 body / flat walls": 0.375, "EM01 tab / notch side": 0.12500000000000022}
