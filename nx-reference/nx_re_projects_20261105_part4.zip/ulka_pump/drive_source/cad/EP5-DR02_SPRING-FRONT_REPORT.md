# EP5-DR02_SPRING-FRONT - parça raporu

Yazar: ULKA-C Tahrik. Tarih: 2026-10-16. Kontrol parçası revizyonu: H. Journal sonucu: **PASS** (13 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-DR02_SPRING-FRONT.prt`, `cad\EP5-DR02_SPRING-FRONT.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\DR02\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_dr02.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Hareketli parça, kendi ekseninde: Z = sarım ekseni, z = 0 ve z = `dr02_len` taşlanmış uç düzlemleri, tel başı +X'te,
sağ helis. `dr02_len` = `dr02_l0` (serbest boy); A montaj kopyasında bu expression'a `dr02_l_inst` verir, aktif adım
boydan türetilir (uç sarımları sabit kalır).
Unsur ağacı: law curve merkez çizgisi (`CENTRE_LINE`: x, y = coil_d/2·cos/sin(360·n_t·t), z = parçalı adım:
kapalı uç adımı = d + 0,02 [sarımlar değer] -> geçiş -> aktif adım -> geçiş -> kapalı uç) -> Tube (tel Ø) -> iki Trim Body
(z = 0 ve z = len düzlemleri = taşlanmış uçlar). Sketch yok (eğri denklemle).
Kontrol parçasından: d (Usta ölçüsü), od, l0, nt (Rev F). Uç sarımı parametreleri taramaya oturtuldu
(`parts\C_common\spring_fit3.py`, kapalı uç adımı = d kısıtıyla).

## Bilinen sapma - taramanın tel şişmesi (K2'den önce bildirilir)
Tel CAD'de Usta'nın ölçtüğü Ø1,0; taramada aynı tel Ø1,22 görünüyor (yan başına ~+0,11). Sarım merkez çizgisi ve
adım taramadan (merkez çizgisi silindiri rms 0,04-0,05), bu yüzden tarama yüzeyi CAD tel yüzeyinin sistematik olarak
~0,11 dışında kalır: aşağıdaki tabloda "ortalama" sütunu bu kaymadır, "sd" sütunu kaymadan arındırılmış uyumdur.
Bu sistematik fark modelleme hatası değildir; K2 sonucunu A değerlendirir (CR-C-02 kapı notu).
Tarama yayın yan yatmış halidir; masaya bakan alt yarı yoktu (masa silindi).
**K2 dışında tutulması istenen tarama bölgeleri:** yok.

## C'nin kendi K2 tahmini
Fazı / uç yönü en iyi oturtmadan sonra ±0,15 içinde %63,4: **tutmadı** (kapı %90). Ortalama +0,104 = tel şişmesi
(Usta 1,0 / tarama 1,22); aktif sarımlarda kaymadan arındırılmış sd 0,113, uç sarımlarında 0,21 (uç sarımlarının
gerçek şekli parçalı adım modelinden sapıyor; taramanın en zayıf bölgesi). Tel Usta ölçüsünde bırakıldı (tasarım
niyeti ve hesap için doğru değer); kapıyı geçirmek için teli taramaya şişirmek doğru olmaz.

## Unsur ağacı

DATUM_CSYS  -> SPLINE_LAW CENTRE_LINE -> SWP104 WIRE_TUBE -> DATUM_PLANE PL_END_0 -> DATUM_PLANE PL_END_LEN -> TRIM BODY  -> TRIM BODY 

Sketch'ler: .
Gövdeler: body 173,65 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 3.2e-05, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `dr02_d` = 1, `dr02_od` = 12,75, `dr02_l0` = 18,93, `dr02_nt` = 6,06.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `dr02_pe_gap` | 0,02 | gap between touching end coils (closed ends) |
| `dr02_a1` | 0,835 | closed turns at the z = 0 end [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr02_b1` | 0,1 | pitch ramp turns at the z = 0 end [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr02_a2` | 0,75 | closed turns at the far end [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr02_b2` | 0,1 | pitch ramp turns at the far end [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr02_grind` | 0,36 | grind depth at the ends [fit with closed-end pitch = d + gap, spring_fit3.py] |
| `dr02_pe` | 1,02 (= `dr02_d+dr02_pe_gap`) | pitch of the closed end turns = wire + gap (coils touch) |
| `dr02_len` | 18,93 (= `dr02_l0`) | spring length: free length by default; A sets the installed length on a copy |
| `dr02_coil_d` | 11,75 (= `dr02_od-dr02_d`) | mean coil diameter |
| `dr02_z0` | 0,14 (= `dr02_d/2-dr02_grind`) | wire centre height at the start (ground end) |
| `dr02_n_act` | 4,275 (= `dr02_nt-dr02_a1-dr02_a2-dr02_b1-dr02_b2`) | turns at the active pitch |
| `dr02_p` | 3,87 (= `(dr02_len-2*dr02_z0-dr02_pe*(dr02_a1+dr02_a2)-dr02_pe*(dr02_b1+dr02_b2)/2)/((dr02_b1+dr02_b2)/2+dr02_n_act)`) | active pitch, DERIVED from the length |
| `dr02_zA` | 0,9917 (= `dr02_z0+dr02_pe*dr02_a1`) |  |
| `dr02_zB` | 1,2362 (= `dr02_zA+(dr02_pe+dr02_p)/2*dr02_b1`) |  |
| `dr02_zC` | 17,7805 (= `dr02_zB+dr02_p*((dr02_nt-dr02_a2-dr02_b2)-(dr02_a1+dr02_b1))`) |  |
| `dr02_zD` | 18,025 (= `dr02_zC+(dr02_p+dr02_pe)/2*dr02_b2`) |  |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | +0,104 | 0,163 | 0,124 | 0,352 | 16,8 | 63,4 |
| outer (r > R) | 136230 | +0,096 | 0,173 | 0,122 | 0,339 | 18,6 | 64,4 |
| inner (r < R) | 63770 | +0,120 | 0,136 | 0,126 | 0,367 | 13,0 | 61,3 |
| end coils (z<2.5 or z>L0-2.5) | 86551 | +0,105 | 0,210 | 0,137 | 0,433 | 17,6 | 55,2 |
| active coils | 113449 | +0,103 | 0,113 | 0,118 | 0,268 | 16,2 | 69,6 |
| all | 200000 | +0,104 | 0,163 | 0,124 | 0,352 | 16,8 | 63,4 |

- CAD yüzeyinin % 25,4'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `v_tube`: 176.38882304880804
- `v_trimmed`: 173.65023661877927
- `active_pitch`: 3.870011428571428
- `min_rise_per_turn`: 1.3477513142857145
- `bbox_xy_padded`: [13.057500000000001, 12.941]
