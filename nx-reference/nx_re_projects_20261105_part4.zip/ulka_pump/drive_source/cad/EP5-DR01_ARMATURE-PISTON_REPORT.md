# EP5-DR01_ARMATURE-PISTON - parça raporu

Yazar: ULKA-C Tahrik. Tarih: 2026-10-16. Kontrol parçası revizyonu: B. Journal sonucu: **PASS** (18 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-DR01_ARMATURE-PISTON.prt`, `cad\EP5-DR01_ARMATURE-PISTON.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\DR01\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_dr01.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Hareketli parça, kendi ekseninde: Z = armatür ekseni, +Z piston ucuna (= pompa +Z), z = 0 armatür ön alnı (DR02
oturma yüzü), **+X = yan pencere (çapraz delik) ekseni**. A montajda `z_dr01` ile konumlar. Tek gövde (armatür +
pres geçmiş piston birleşik).
Unsur ağacı: `SK_BODY` (tüm dönel profil: arka pilot, armatür, ön pilot, yaka, piston, eksenel delik, piston deliği,
VL01 oturma havşası; DOF 0) -> Revolve -> `SK_WINDOW` (Ø5,15 daire) -> Extrude (±X, Subtract) -> köşe radyusları.

## Türetilen (taramada yok) bölgeler - K2'den önce bildirilir
- Eksenel delik Ø6,09'un sonu = piston deliğinin başı z = 6,36 (`bore_end_z`): delik duvarı pencereden z 5,5'e kadar
  görülüyor; aradaki geçiş ve armatür içindeki delik boyu (z -16,2 .. 1,4 arası görülmedi) türetildi.
- Piston borusu ile armatür arasındaki pres sınırı modellenmedi (tek gövde; taramada da sınır yok).
**K2 dışında tutulması istenen tarama bölgeleri:** yok.

## Bilinen sapmalar / notlar
- Pencere Aşama 1'de "enine yarık" diye okunmuştu; çevrimdışı karşılaştırmada çapraz delik olduğu görüldü: Ø5,154
  silindir uydurması (rms 0,030), ekseni z 3,91, armatür eksenini 0,04 kaçıkla kesiyor. C_MEASURED düzeltildi.
- Bilya oturma havşası + piston deliği: ±0,15 içinde %96,2 (kapsama ~95°, ince delik içi).
- Tarama kapsaması ~265° (tüm boyda +Y tarafı, θ ≈ +45..+145, gölge).
- `d_p` = 4,97 (Rev A/B). Not: Usta'nın tel ölçüsü (DR02 1,0 / DR03 1,3) taramanın ince tellerde 0,07-0,11/yan
  şiştiğini gösterdi; piston için bunun etkisi CR-C-02'de A'ya yazıldı (pistonda ölçülmeden bilinemez).

## Unsur ağacı

DATUM_CSYS  -> SKETCH SK_BODY -> SWP104 BODY_REVOLVE -> SKETCH SK_WINDOW -> EXTRUDE WINDOW_CROSS_HOLE -> BLEND ARM_RIM_R -> BLEND PILOT_RIM_R -> BLEND TIP_R

Sketch'ler: SK_BODY WellConstrained, DOF 0, otomatik ölçü 0, 15 ölçü; SK_WINDOW WellConstrained, DOF 0, otomatik ölçü 0, 2 ölçü.
Gövdeler: body 3152,54 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 8.6e-07, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `dr01_arm_d` = 14,34, `dr01_arm_len` = 20,04, `dp` = 4,97, `dr01_tip` = 25,33, `dr01_collar_d` = 8,5, `dr01_collar_front` = 7,99, `dr01_fpilot_d` = 10,02, `dr01_rpilot_d` = 9,5, `dr01_rear_len` = 0,98, `dr01_bore_d` = 6,09, `dr01_pin_id` = 2,72, `dr01_seat_d` = 4.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `step_h` | 1,24 | front pilot step height above the front face [scan 1.242] |
| `seat_depth` | 0,72 | axial depth of the ball seat cone at the tip [scan cone 24.61 .. 25.33] |
| `xh_d` | 5,15 | transverse cross hole (side window) through the collar, axis = +X [scan cylinder fit 5.154, rms 0.030] |
| `xh_z` | 3,91 | cross-hole axis height [scan 3.906 (axis 0.04 off the armature axis)] |
| `bore_end_z` | 6,36 | end of the axial bore = start of the piston bore, DERIVED: bore wall seen through the window up to z 5.5, flat at 6.36 |
| `r_arm` | 0,5 | armature outer edge rounds [scan R0.5-0.6] |
| `r_pilot` | 0,4 | rear pilot outer edge round [scan ~R0.4] |
| `r_tip` | 0,15 | piston tip outer edge round [scan ~R0.2] |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | -0,001 | 0,042 | 0,010 | 0,094 | 87,9 | 98,8 |
| F armature OD | 97408 | +0,002 | 0,023 | 0,008 | 0,034 | 97,6 | 99,5 |
| F piston OD (d_p) | 27386 | -0,004 | 0,032 | 0,010 | 0,060 | 93,2 | 99,1 |
| F front face | 7501 | +0,004 | 0,025 | 0,014 | 0,055 | 94,0 | 100,0 |
| F rear face | 8466 | -0,004 | 0,011 | 0,007 | 0,023 | 99,7 | 100,0 |
| F front pilot | 3416 | +0,003 | 0,037 | 0,021 | 0,078 | 84,5 | 99,9 |
| F collar OD | 3200 | -0,006 | 0,026 | 0,008 | 0,054 | 93,7 | 99,6 |
| F ball seat + piston bore | 2156 | +0,029 | 0,060 | 0,032 | 0,133 | 68,6 | 96,2 |
| F rear bore | 3810 | +0,011 | 0,035 | 0,007 | 0,045 | 95,6 | 98,4 |
| window region | 15966 | +0,030 | 0,065 | 0,018 | 0,145 | 74,5 | 95,3 |
| all | 200000 | -0,001 | 0,042 | 0,010 | 0,094 | 87,9 | 98,8 |

- CAD yüzeyinin % 47,9'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).
