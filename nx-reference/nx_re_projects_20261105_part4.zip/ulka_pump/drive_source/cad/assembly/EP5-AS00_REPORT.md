# EP5-AS00 komple montaj - rapor (ULKA-A)

2026-10-16, kontrol parçası Rev H (`C:\NX_MCP_WORKSPACE\ulka\ctrl\EP5-AS00_CTRL.prt`). Kurulum
`asm_build.py` (headless NX), sonuç `asm_build.json` PASS. Ölçüler ve kararlar `ULKA_INTERFACES.md`, QA `sessions\A_QA.md`.

- `EP5-AS00_ASSY.prt` = AS01 (`EP5-AS01_STATOR-SUB`: EM02, EM01, EM03 x2, HS04) + AS02 (`EP5-AS02_CARTRIDGE-SUB`: HS01,
  HS05, HS02, SL01-SL04, DR01, VL01, DR02, DR03, VL02) + AS03 (`EP5-AS03_OUTLET-SUB`: HS03, VL05, VL03, VL04) + FS01 x2.
  21 benzersiz parça, 23 adet. Sabit parçalar yerinde (orijinde kısıtsız), hareketliler kontrol parçasının dinlenme
  konumunda (akım yok). Yaylar `*_ASM.prt` sıkışmış kopyalar (montaj boyu = kontrol parçası `*_l_inst`).
- Girişim: yalnız beklenenler (O-ring sıkışmaları, M4 vida dişi, valf / yay temasları). Strok taraması -8,13 .. +2,58:
  çarpışma yok. STEP 23 katı, geçersiz 0, hacim farkı 0,23 mm³.
- Not: alt montajlar BOM'a göre (AS03'te VL03-VL05 fiziksel olarak HS02'nin içinde). Montaj dosyası bileşenlerle aynı
  klasörde açılmalı.
