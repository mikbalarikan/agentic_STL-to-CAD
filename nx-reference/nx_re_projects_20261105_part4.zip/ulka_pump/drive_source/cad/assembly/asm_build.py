"""ULKA EP5 assemblies: AS01 stator, AS02 cartridge, AS03 outlet valve, AS00 complete; clearance analysis on a flat
analysis assembly, armature stroke sweep, STEP of AS00.

  run_journal asm_build.py -args <asm folder> <control part path>

Part files are read from <asm folder>\\parts_in (copies of the delivered cad\\ parts; owners' files are never saved
from here). Fixed parts are modelled in place -> added at the origin. Moving parts are placed from the control part
(Rev D): DR01 at z_dr01, VL01 at the piston tip seat, VL03 on the HS02 seat; springs get compressed copies
(<name>_ASM.prt, length expression set to the installed length). Missing parts are skipped and listed.
Writes asm_build.json ("result": PASS | FAIL).
"""
import math
import os
import shutil
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR", r"C:\Users\marya\.claude\skills\nx-journal-core\scripts"))
import nxh  # noqa: E402
import nxa  # noqa: E402
import NXOpen  # noqa: E402

OUT, CTRL = sys.argv[1], sys.argv[2]
IN = os.path.join(OUT, "parts_in")
res = {"result": "FAIL", "missing": [], "components": {}, "clearance": {}, "hard_volumes": {}, "sweep": [], "springs": {}}
chk = nxh.Check()

FIXED = {  # BOM subassembly -> in-place parts
    "AS01": ["EP5-EM02_FRAME", "EP5-EM01_COIL", "EP5-EM03_FLUX-SLEEVE", "EP5-HS04_SPACER-RING"],
    "AS02": ["EP5-HS01_INLET-BODY", "EP5-HS05_WASHER", "EP5-HS02_CYLINDER", "EP5-SL01_ORING-L", "EP5-SL02_ORING-M",
             "EP5-SL03_ORING-S", "EP5-SL04_ORING-PISTON"],
    "AS03": ["EP5-HS03_OUTLET-FLANGE", "EP5-VL05_VALVE-CAGE"],
}
BALL_TOP_ABOVE_TIP = 2.31     # VL01 top above the piston tip: 9/64" ball in the 90 deg / 4.0 countersink (D, CR-D-02)


def path(name):
    return os.path.join(IN, name + ".prt")


def have(name):
    return os.path.exists(path(name))


def spring_copy(name, len_expr, length):
    """Compressed copy of a spring part: <name>_ASM.prt with its length expression set to length."""
    src, dst = path(name), path(name + "_ASM")
    shutil.copyfile(src, dst)
    p = nxh.open_part(dst)
    nxh.set_expr(p, len_expr, "%.4f" % length)
    nxh.update()
    errs = nxh.feature_errors(p)
    b = nxh.solids(p)
    bb = nxh.bbox(b[0]) if b else None
    nxh.save(p)
    res["springs"][name] = {"length_set": round(length, 4), "bodies": len(b), "bbox_z": [round(bb[2], 4), round(bb[5], 4)] if bb else None,
                            "feature_errors": [str(e) for e in errs]}
    chk.true(name + " compressed copy builds", bool(b) and not errs, res["springs"][name])
    return name + "_ASM"


def add(assy, name, inst, origin=(0.0, 0.0, 0.0), r=None):
    c = nxa.add_component(assy, path(name), inst, tuple(float(v) for v in origin), r)
    res["components"].setdefault(assy.Leaf, {})[inst] = {"part": name, "origin": [round(float(v), 4) for v in origin]}
    return c


def bodies(comp):
    nxa.load_fully([comp], update=False)
    return [nxa.occ(comp, b) for b in nxh.solids(comp.Prototype)]


def hs02_internal():
    """D's HS02 part-internal chamber values (CR-D-02); defaults if the expressions are absent."""
    out = {"ch_bot": 24.0, "wall_t": 0.8}
    if have("EP5-HS02_CYLINDER"):
        p = nxh.open_part(path("EP5-HS02_CYLINDER"))
        for k in out:
            try:
                out[k] = p.Expressions.FindObject(k).Value
            except Exception:  # noqa: BLE001
                res.setdefault("notes", []).append("HS02 expression %s not found, default %.2f" % (k, out[k]))
    return out


def place_list(E, H, dz=0.0):
    """Moving parts and their origins for an armature offset dz from rest (+ = toward the outlet)."""
    tip = E["z_dr01_tip"] + dz
    seat = E["z_hs02"] + H["ch_bot"] + H["wall_t"]
    apex = seat - 0.86
    rows = [("EP5-DR01_ARMATURE-PISTON", "DR01", (0, 0, E["z_dr01"] + dz)),
            ("EP5-VL01_BALL", "VL01", (0, 0, tip + BALL_TOP_ABOVE_TIP - E["vl01_d"] / 2)),
            ("EP5-VL03_VALVE-PLUG", "VL03", (0, 0, apex))]
    return [r for r in rows if have(r[0])]


try:
    ctrl = nxh.open_part(CTRL)
    E = {e.Name: e.Value for e in nxh.user_expressions(ctrl)}
    res["ctrl_rev"] = str(ctrl.GetUserAttribute("ULKA_CTRL_REV", NXOpen.NXObject.AttributeType.String, -1).StringValue)
    H = hs02_internal()
    res["hs02_internal"] = H
    seat = E["z_hs02"] + H["ch_bot"] + H["wall_t"]
    # ---- spring copies (installed lengths at rest) ----
    springs = []   # (copy name, inst, origin, subassembly)
    if have("EP5-DR03_SPRING-REAR"):
        springs.append((spring_copy("EP5-DR03_SPRING-REAR", "dr03_len", E["dr03_l_inst"]), "DR03", (0, 0, E["z_hs01_bot"]), "AS02"))
    else:
        res["missing"].append("EP5-DR03_SPRING-REAR")
    if have("EP5-DR02_SPRING-FRONT"):
        springs.append((spring_copy("EP5-DR02_SPRING-FRONT", "dr02_len", E["dr02_l_inst"]), "DR02", (0, 0, E["z_dr01"]), "AS02"))
    else:
        res["missing"].append("EP5-DR02_SPRING-FRONT")
    z_vl02 = E["z_dr01_tip"] + BALL_TOP_ABOVE_TIP
    if have("EP5-VL02_SPRING-BALL"):
        springs.append((spring_copy("EP5-VL02_SPRING-BALL", "vl02_len", E["z_hs02"] + H["ch_bot"] - z_vl02), "VL02", (0, 0, z_vl02), "AS02"))
    else:
        res["missing"].append("EP5-VL02_SPRING-BALL")
    z_vl04 = seat - 0.86 + 4.08
    if have("EP5-VL04_SPRING-VALVE"):
        springs.append((spring_copy("EP5-VL04_SPRING-VALVE", "vl04_len", E["z_vl05"] - z_vl04), "VL04", (0, 0, z_vl04), "AS03"))
    else:
        res["missing"].append("EP5-VL04_SPRING-VALVE")
    nxh.close_all()
    ctrl = nxh.open_part(CTRL)
    moving_rows = place_list(E, H)
    sub_of_moving = {"DR01": "AS02", "VL01": "AS02", "VL03": "AS03"}
    for n in ("EP5-DR01_ARMATURE-PISTON", "EP5-VL01_BALL", "EP5-VL03_VALVE-PLUG"):
        if not have(n):
            res["missing"].append(n)

    # ---- BOM subassemblies (deliverable) ----
    subs = {}
    for sa, names in FIXED.items():
        fname = {"AS01": "EP5-AS01_STATOR-SUB", "AS02": "EP5-AS02_CARTRIDGE-SUB", "AS03": "EP5-AS03_OUTLET-SUB"}[sa]
        a = nxa.new_assembly(os.path.join(IN, fname + ".prt"))
        nxh.save(a)
        for n in names:
            if have(n):
                add(a, n, n.split("_")[0].replace("EP5-", ""))
                if n == "EP5-EM03_FLUX-SLEEVE":
                    add(a, n, "EM03_B", (0, 0, E["em03_len"] + E["hs04_h"]))
            else:
                res["missing"].append(n)
        for n, inst, o in moving_rows:
            if sub_of_moving[inst] == sa:
                add(a, n, inst, o)
        for n, inst, o, s in springs:
            if s == sa:
                add(a, n, inst, o)
        nxh.update()
        nxh.save(a)
        subs[sa] = fname
    top = nxa.new_assembly(os.path.join(IN, "EP5-AS00_ASSY.prt"))
    nxh.save(top)
    for sa, fname in subs.items():
        add(top, fname, sa)
    if have("EP5-FS01_SCR-FLANGE"):
        add(top, "EP5-FS01_SCR-FLANGE", "FS01_P")
        add(top, "EP5-FS01_SCR-FLANGE", "FS01_N", (-E["fs_pitch"], 0, 0))
    else:
        res["missing"].append("EP5-FS01_SCR-FLANGE")
    nxh.update()
    nxh.save(top)

    # ---- flat analysis assembly (all leaf parts at top level) ----
    flat = nxa.new_assembly(os.path.join(IN, "EP5-AS00_FLAT.prt"))
    nxh.save(flat)
    fixed_comps = {}
    for sa, names in FIXED.items():
        for n in names:
            if have(n):
                inst = n.split("_")[0].replace("EP5-", "")
                fixed_comps[inst] = add(flat, n, inst)
                if n == "EP5-EM03_FLUX-SLEEVE":
                    fixed_comps["EM03_B"] = add(flat, n, "EM03_B", (0, 0, E["em03_len"] + E["hs04_h"]))
    if have("EP5-FS01_SCR-FLANGE"):
        fixed_comps["FS01_P"] = add(flat, "EP5-FS01_SCR-FLANGE", "FS01_P")
        fixed_comps["FS01_N"] = add(flat, "EP5-FS01_SCR-FLANGE", "FS01_N", (-E["fs_pitch"], 0, 0))
    spring_comps = {inst: add(flat, n, inst, o) for n, inst, o, s in springs}
    mov = {inst: add(flat, n, inst, o) for n, inst, o in moving_rows}
    nxh.update()
    cs = nxa.clearance_set(flat, "CS_REST", zone=0.0)
    res["clearance"]["rest"] = nxa.run_clearance(cs)
    allc = {c.Name: c for c in flat.ComponentAssembly.RootComponent.GetChildren()}
    for row in res["clearance"]["rest"]:
        if row["type"] != "Hard":
            continue
        a, b = row["pair"]
        vol = 0.0
        for ba in bodies(allc[a]):
            for bb in bodies(allc[b]):
                st, vols = nxa.simple_interference(flat, ba, bb)
                vol += sum(vols)
        res["hard_volumes"]["%s / %s" % (a, b)] = round(vol, 4)

    # ---- stroke sweep: DR01 (+ VL01) against the fixed parts ----
    targets = [k for k in ("HS01", "HS05", "HS02", "SL04", "EM03", "HS04", "EM03_B") if k in fixed_comps]
    fixed_b = {k: bodies(fixed_comps[k]) for k in targets}
    lo, hi = -(E["stroke_mag"] + 0.5), E["stroke_up"]
    n = 12
    steps = [lo + (hi - lo) * i / n for i in range(n + 1)]
    for dz in steps:
        for c in mov.values():
            flat.ComponentAssembly.RemoveComponent(c)
        mov = {inst: add(flat, nm, inst, o) for nm, inst, o in place_list(E, H, dz)}
        nxh.update()
        row = {"dz": round(dz, 3), "pairs": {}}
        for mn in ("DR01", "VL01"):
            if mn not in mov:
                continue
            mb = bodies(mov[mn])
            for fn in targets:
                worst, vol = "NoInterference", 0.0
                for a in mb:
                    for b in fixed_b[fn]:
                        st, vols = nxa.simple_interference(flat, a, b)
                        if st == "InterferenceExists":
                            worst, vol = st, vol + sum(vols)
                        elif st != "NoInterference" and worst == "NoInterference":
                            worst = st
                if worst != "NoInterference":
                    row["pairs"]["%s-%s" % (mn, fn)] = {"state": worst, "overlap_mm3": round(vol, 4)}
        res["sweep"].append(row)
    for c in mov.values():
        flat.ComponentAssembly.RemoveComponent(c)
    mov = {inst: add(flat, nm, inst, o) for nm, inst, o in place_list(E, H, 0.0)}
    nxh.update()
    nxh.save(flat)
    res["part_volumes"] = {}
    for c in flat.ComponentAssembly.RootComponent.GetChildren():
        nxa.load_fully([c], update=False)
        res["part_volumes"][c.Name] = [round(nxh.volume(c.Prototype, b), 4) for b in nxh.solids(c.Prototype)]
    # ---- STEP of the nested AS00 ----
    import nxf
    nxa.set_work(None)
    nxh.close_all()
    top = nxh.open_part(os.path.join(IN, "EP5-AS00_ASSY.prt"))
    nxa.load_fully(list(top.ComponentAssembly.RootComponent.GetChildren()), update=True)
    stp = os.path.join(OUT, "EP5-AS00_ASSY.stp")
    nxf.step_export(top, stp, timeout=900)
    res["step"] = {"file": stp, "size": os.path.getsize(stp) if os.path.exists(stp) else 0}
    chk.true("assembly STEP written", res["step"]["size"] > 100000, res["step"])
    res.update(chk.report())
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "asm_build.json"), res)
