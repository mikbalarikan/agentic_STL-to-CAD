# EP5-VL01_BALL - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: D. Journal sonucu: **PASS** (8 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-VL01_BALL.prt`, `cad\EP5-VL01_BALL.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\VL01\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_vl01.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve
Kendi çerçevesinde, merkez orijinde (A konumlar). Ø `vl01_d` = 3,572 (9/64"), tarama küre uydurması 3,606 (sd 0,031).
Ön kontrol: %100 ±0,15, %92,4 ±0,05 içinde.

## Unsur ağacı

DATUM_CSYS  -> SKETCH SK_PROFILE -> SWP104 BALL

Sketch'ler: SK_PROFILE WellConstrained, DOF 0, otomatik ölçü 0, 1 ölçü.
Gövdeler: body 23,86 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 0.0e+00, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `vl01_d` = 3,572.

| Parça içi | Değer | Açıklama |
|---|---|---|

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | +0,014 | 0,028 | 0,021 | 0,060 | 89,2 | 100,0 |
| all: kendi en iyi oturmasından sonra | 200000 | +0,003 | 0,029 | 0,018 | 0,058 | 92,4 | 100,0 |

- all: taramayı CAD'e oturtan küçük hareket: dönme 1,066°, öteleme (-0,001; -0,000; -0,022).
- CAD yüzeyinin % 48,8'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).
