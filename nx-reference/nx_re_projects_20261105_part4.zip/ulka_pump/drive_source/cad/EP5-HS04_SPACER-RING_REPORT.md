# EP5-HS04_SPACER-RING - parça raporu

Yazar: ULKA-B Stator. Tarih: 2026-10-16. Kontrol parçası revizyonu: A. Journal sonucu: **PASS** (14 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-HS04_SPACER-RING.prt`, `cad\EP5-HS04_SPACER-RING.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\HS04\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_hs04.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve ve tasarım niyeti

Pompa çerçevesinde yerinde (Rev A §1-2): Z pompa ekseni, alt yüz `z_hs04_bot` = -28,22, üst yüz -19,12. OD / ID /
boy kontrol parçasından. Tek parça içi ölçü `hs04_ch` 0,35 x 45° iç kenar pahı: taramada bir uçta (üst yüz iç
kenarı r 8,91, delik r 8,56) görülen kenar kırma. Halkanın pompadaki yönü bilinmiyor; pah +Z (çıkış) ucuna
konuldu. Başka simetri kırıcı özellik yok.

## Taramanın göstermediği / dışarıda tutulan bölgeler (QA'dan önce)

- Tarama masada dik, tek yönden: dış duvar yalnız bir yarıda, iç duvar öbür yarıda (~140° her biri). Alt yüz
  masaya oturuyordu, taranmadı: taramada alt yüz bölgesi (z < 0,35 parça içi) ve masa kalıntısı (r < 8,0) dışarıda.
- OD tarama boyunca 20,68 (alt) -> 20,98 (üst) değişiyor; ortak merkezli uydurma 20,78 = Rev A. Duvarlarda
  kalan sapmanın büyük kısmı bu koniklik / eğik tarama (kendi oturmasında 0,89° eğim).

## Kabul (B'nin kendi ölçümü; bağımsız QA A'da)

- K1: OD 20,78, ID 17,11, boy 9,1 = Rev A expression'ları (CAD tam). Tarama özelliği zayıf (kapsama < 180°) ->
  bant max(0,05; 2·sd).
- K2 (T = 0,15): toplamın %91,1'i ±0,15 içinde (≥ %90 tuttu).

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_HS04_BOT -> DATUM_AXIS AX_BOT_X -> SKETCH SK_PROFILE -> SWP104 RING

Sketch'ler: SK_PROFILE WellConstrained, DOF 0, otomatik ölçü 0, 5 ölçü.
Gövdeler: body 990,52 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 4.6e-16, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `z_hs04_bot` = -28,22, `hs04_od` = 20,78, `hs04_id` = 17,11, `hs04_h` = 9,1, `em01_bore_min_d` = 21,45, `hs01_tube_od` = 16,09.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `hs04_ch` | 0,35 | inner edge chamfer at the +Z end [scan: top face inner edge r 8.91 vs bore r 8.56] |
| `c_hs04_bore` | 0,335 (= `(em01_bore_min_d-hs04_od)/2`) | radial clearance ring / EM01 bore (narrowest) |
| `c_hs04_tube` | 0,51 (= `(hs04_id-hs01_tube_od)/2`) | radial clearance ring / HS01 tube |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 192582 | +0,000 | 0,093 | 0,039 | 0,200 | 58,9 | 91,1 |
| (toplam dışı bırakılan) | 7418 | +0,060 | 0,276 | 0,083 | 0,596 | 33,9 | 67,5 |
| outer wall (OD) | 77910 | -0,015 | 0,092 | 0,030 | 0,195 | 65,4 | 93,4 |
| inner wall (ID) | 62452 | -0,010 | 0,061 | 0,029 | 0,120 | 75,0 | 96,7 |
| top face | 35088 | +0,048 | 0,093 | 0,077 | 0,207 | 32,0 | 85,1 |
| walls (pose of the ring): kendi en iyi oturmasından sonra | 139519 | -0,009 | 0,071 | 0,024 | 0,142 | 78,5 | 95,3 |

- walls (pose of the ring): taramayı CAD'e oturtan küçük hareket: dönme 0,894°, öteleme (0,364; -0,028; -0,550).
- CAD yüzeyinin % 57,4'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `z_planes`: {"bottom": -28.22, "top": -19.119999999999997}
- `clearances`: {"ring/EM01 bore": 0.3349999999999991, "ring/HS01 tube": 0.5099999999999998}
