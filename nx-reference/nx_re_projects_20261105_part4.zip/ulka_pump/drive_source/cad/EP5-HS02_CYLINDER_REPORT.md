# EP5-HS02_CYLINDER - parça raporu

Yazar: ULKA-D Hidrolik. Tarih: 2026-10-16. Kontrol parçası revizyonu: F. Journal sonucu: **PASS** (22 kontrol, 0 başarısız).
Dosyalar: `cad\EP5-HS02_CYLINDER.prt`, `cad\EP5-HS02_CYLINDER.stp`; journal `C:\NX_MCP_WORKSPACE\ulka\parts\HS02\build.py`, sonuç `out\build.json`,
tarama karşılaştırması `dev_hs02.py` -> `qa\dev.json`, `fig\dev.png`.

## Çerçeve ve yerleşim
Yerinde, pompa çerçevesinde (Rev A): Z pompa ekseni, +Z girişten çıkışa; flanş (giriş) yüzü `z_hs02` = 12,499'da
(`PL_HS02`). CH12 düzlüklerinin normali ±X. Tarama karşılaştırması için hizalı tarama
`scan\EP5-HS02_aligned.stl` (z0 = flanş yüzü, düzlük normalleri ±X; iki düzlük 9,41° / 188,68° -> -9,05° döndürüldü,
5,846 + 5,881 = 11,73 aralık) z_hs02 kadar ötelenip kullanıldı.

## Ölçülen / türetilen
- Ölçülen (taramadan): flanş Ø/kalınlık, SL04 havşası, giriş konisi (Ø6,40 -> Ø6,0, z 2,15-5,0), gövde Ø ve bant,
  CH12 düzlükleri, uç pahları, ağız pahı, oda tabanı z 29,22, valf deliği Ø6,0 (görülen kısa boy).
- **Türetilen** (taramada yok, Usta ölçemiyor; `cr\CR-D-01.md`): `cr\CR-D-02.md` (Rev C kinematiği): basınç odası dibi `ch_bot` 24,0 (VL02 dinlenmede 9,33,
  yukarı dayanmada 6,75 > blok 6,25); duvar `wall_t` 0,8 ve oturma deliği `hs02_seat_d` Ø4,0 (kenar z 24,8); valf deliği
  Ø6,0 (24,8-29,22); VL05 yeri `hs02_vl05_z` 31,92-36,42 (kontrol parçası, Rev D); G1/8 iç diş: diş dibi / matkap çapında `hs02_out_d` 8,52 delik,
  **diş kozmetik** (z 36,42-41,22, `thr_len` = boy - `hs02_vl05_z` - `vl05_t` = 4,8; datasheet "min 7" **tutmuyor**, CR-D-02).

## QA'dan önce dışarıda tutulacak bölgeler (K2)
1. Çıkış odası z 29,2-41,2 iç yüzeyi: G1/8 iç diş taranmış (tarama ortalaması Ø9,15 = G1/8 bölüm dairesi 9,147),
   CAD diş dibinde (8,52). Fark 0,47 radyal, kasıtlı (kozmetik diş).
2. Orta iç (z 7,5-29,2): taramada yok.
K1 notu: SL04 havşası Ø serbest daire uydurmasında 8,59, gövde eksenine göre 8,73 (kapsama 220°); Rev A 8,63.
Flanş çevresinde ~0,1 y-kayması (taramanın iki geçişinin birleşme ofseti; flanş ucu altkümesi kendi oturmasından
sonra %91,2 ±0,15 içinde).

Ön kontrol (D, A'nın QA'sı değil): 1. bölge dışarıda tutulunca yerinde (oturtmasız) %94,5 tarama ±0,18 içinde (%91,6 ±0,15).

## Unsur ağacı

DATUM_CSYS  -> DATUM_PLANE PL_HS02 -> DATUM_AXIS AX_HS02_X -> SKETCH SK_PROFILE -> SWP104 BODY_REVOLVE -> DATUM_PLANE PL_FLATS -> SKETCH SK_FLATS -> EXTRUDE CH12_FLATS

Sketch'ler: SK_PROFILE WellConstrained, DOF 0, otomatik ölçü 0, 26 ölçü; SK_FLATS WellConstrained, DOF 0, otomatik ölçü 0, 8 ölçü.
Gövdeler: body 4306,39 mm3.
STEP (AP242) geri okuma: 1 katı, hacim farkı en çok 2.1e-16, sağlıklı: evet.

## Expression'lar

Kontrol parçasından (interpart): `z_hs02` = 12,42, `hs02_len` = 41,22, `hs02_flange_d` = 15,77, `hs02_flange_t` = 2,88, `hs02_body_d` = 13,4, `hs02_sl04_d` = 8,63, `hs02_sl04_depth` = 2,15, `hs02_out_d` = 8,52, `hs02_out_floor` = 29,22, `hs02_seat_d` = 4, `hs02_ch_s` = 11,8, `hs02_ch_z0` = 22,18, `hs02_ch_z1` = 28,55, `hs02_vl05_z` = 31,92, `vl05_t` = 4,5.

| Parça içi | Değer | Açıklama |
|---|---|---|
| `fl_ch` | 0,3 | flange face outer chamfer [scan OD 15.50 at z 0 vs 15.60 at 0.4] |
| `body1_d` | 13,47 | body OD between flange and band [scan 13.46-13.50, z 3.6-9.6] |
| `band_d` | 13,13 | shallow band OD [scan 13.13-13.15, z 10.8-14.4] |
| `band_z0` | 10,6 | band start from the flange face [scan transition 10.4-10.8] |
| `band_z1` | 14,8 | band end [scan transition 14.4-15.2] |
| `tip_ch_z` | 1,2 | outer tip chamfer axial length [scan 13.22 at 40.0 -> 12.66 at 40.8] |
| `tip_ch_r` | 0,39 | outer tip chamfer radial depth -> tip OD 12.62 [scan] |
| `tip_cyl` | 0,42 | outer tip cylinder length after the chamfer [scan 40.8-41.22] |
| `mouth_d` | 11,2 | outlet mouth lead-in outer diameter [scan 11.2 at the tip face] |
| `mouth_z` | 1,2 | outlet lead-in depth [scan 40.0 -> 41.22] |
| `entry_d` | 6,4 | piston bore entry diameter at the SL04 recess floor [scan 6.40 at z 2.2] |
| `entry_z` | 5 | end of the entry cone from the flange face [scan 6.0 from z ~5] |
| `bore_d` | 6 | pressure chamber / piston bore [scan 6.0-6.06 at z 5-7.5 local axis; deeper DERIVED] |
| `ch_bot` | 24 | chamber bottom from the flange face, DERIVED from the Rev C stroke (cr/CR-D-02) |
| `wall_t` | 0,8 | seat wall thickness, DERIVED (cr/CR-D-02) |
| `vbore_d` | 6 | outlet valve bore (VL03 head) [scan 6.0-6.1 at the room floor; length DERIVED] |
| `thr_len` | 4,8 (= `hs02_len-hs02_vl05_z-vl05_t`) | G1/8 thread length from the tip down to the VL05 top (cosmetic; datasheet min 7 not met, cr/CR-D-02) |
| `thr_start` | 36,42 (= `hs02_len-thr_len`) | G1/8 thread start from the flange face |

## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)

| Bölge | n | ortalama | sd | \|d\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |
|---|---|---|---|---|---|---|---|
| **tümü** | 200000 | -0,029 | 0,144 | 0,040 | 0,400 | 57,1 | 85,3 |
| flange OD | 9109 | -0,077 | 0,090 | 0,083 | 0,202 | 36,0 | 74,5 |
| flange face | 20047 | +0,017 | 0,058 | 0,019 | 0,126 | 87,3 | 96,1 |
| SL04 recess bore | 2805 | -0,120 | 0,117 | 0,136 | 0,274 | 18,3 | 53,0 |
| body OD (z 15-22, 29-39) | 57631 | +0,006 | 0,072 | 0,037 | 0,156 | 63,4 | 94,4 |
| flats | 8269 | -0,038 | 0,065 | 0,049 | 0,148 | 51,5 | 95,2 |
| tip face | 6514 | +0,075 | 0,124 | 0,056 | 0,328 | 46,1 | 78,9 |
| outlet bore (G1/8 thread, cosmetic) | 10820 | -0,468 | 0,118 | 0,488 | 0,613 | 0,4 | 1,5 |
| flange end (z<4): kendi en iyi oturmasından sonra | 45334 | +0,016 | 0,086 | 0,032 | 0,198 | 65,0 | 91,2 |
| outlet end (z>29): kendi en iyi oturmasından sonra | 65166 | +0,025 | 0,177 | 0,115 | 0,348 | 14,5 | 65,0 |
| all: kendi en iyi oturmasından sonra | 200000 | +0,014 | 0,123 | 0,056 | 0,303 | 45,8 | 85,5 |

- flange end (z<4): taramayı CAD'e oturtan küçük hareket: dönme 0,571°, öteleme (-0,048; -0,122; 0,006).
- outlet end (z>29): taramayı CAD'e oturtan küçük hareket: dönme 5,093°, öteleme (-0,009; 0,687; -0,030).
- all: taramayı CAD'e oturtan küçük hareket: dönme 0,311°, öteleme (-0,002; 0,081; 0,006).
- CAD yüzeyinin % 54,5'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge).

## Journal notları

- `chamber_volume_mm3`: 623.29
- `thread`: "G1/8 (BSPP 28 tpi) internal, z 36.42 .. 41.22 local (cosmetic; bore at tapping size 8.52)"
