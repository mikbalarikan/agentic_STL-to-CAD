r"""Scan noise per part: residual of a cone (axis refit) on clean cylindrical bands and of planes, in the rough frame.
Writes a11_noise.json."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
from scipy.optimize import least_squares

def cone_res(P):
    def f(p):
        x0, y0, a, b, r0, k = p
        x = P[:, 0] - x0 - a * P[:, 2]; y = P[:, 1] - y0 - b * P[:, 2]
        return np.hypot(x, y) - (r0 + k * P[:, 2])
    r = np.hypot(P[:, 0], P[:, 1])
    s = least_squares(f, [0, 0, 0, 0, np.median(r), 0], loss="soft_l1", f_scale=0.05)
    return s.fun, s.x

def plane_res(P):
    c = P.mean(0); w, v = np.linalg.eigh(np.cov((P - c).T)); return (P - c) @ v[:, 0]

def stats(res):
    res = res - np.median(res)
    mad = 1.4826 * np.median(np.abs(res))
    return dict(sd=round(float(np.std(res)), 4), sd_robust=round(float(mad), 4), p95=round(float(np.percentile(np.abs(res), 95)), 4), n=int(len(res)))

bands = {  # code: list of (name, kind, zmin, zmax, rmin, rmax, normal sign)
 "HS01": [("tube OD", "cyl", 12, 50, 7.5, 8.6, +1)],
 "HS02": [("body OD", "cyl", 6, 20, 6.3, 7.2, +1), ("tip OD", "cyl", 30, 39, 6.4, 7.3, +1)],
 "HS03": [("neck OD", "cyl", 10.2, 14, 11.5, 12.5, +1), ("bore 16.6", "cyl", 12, 18, 7.9, 8.7, -1), ("underside", "zplane", 3.0, 3.5, 11, 21.5, 0)],
 "DR01": [("armature OD", "cyl", 28, 44, 6.8, 7.6, +1), ("piston OD", "cyl", 2, 15, 2.2, 2.8, +1)],
 "EM03": [("OD", "cyl", 2, 15, 10.2, 10.8, +1), ("ID", "cyl", 2, 15, 8.0, 8.7, -1)],
 "HS04": [("OD", "cyl", 1, 8, 10.0, 10.6, +1), ("ID", "cyl", 1, 8, 8.3, 8.9, -1)],
 "EM01": [("coil OD", "cyl", 6, 22, 21.5, 25.5, +1)],
}
out = {}
for code, bl in bands.items():
    m = Mesh(read_stl(os.path.join(WS, "scan", "A_rough", f"A_{code}_rough.stl")))
    P, idx = m.sample(400000); N = m.n[idx]
    r = np.hypot(P[:, 0], P[:, 1]); nr = (N[:, 0] * P[:, 0] + N[:, 1] * P[:, 1]) / np.maximum(r, 1e-9)
    for name, kind, z0, z1, r0, r1, sg in bl:
        s = (P[:, 2] > z0) & (P[:, 2] < z1) & (r > r0) & (r < r1)
        if kind == "cyl":
            s &= nr * sg > 0.85
            res, x = cone_res(P[s]); st = stats(res); st["D"] = round(2 * float(x[4] + x[5] * (z0 + z1) / 2), 3)
        else:
            s &= np.abs(N[:, 2]) > 0.9
            st = stats(plane_res(P[s]))
        out[f"{code} {name}"] = st
        print(f"{code:5s} {name:12s} {st}", flush=True)
# scanner table planes (from a03)
ax = json.load(open(os.path.join(AN, "a03_axes.json")))
for c, v in ax.items():
    out[f"{c} table"] = dict(sd=v["table_rms"], area_frac=v["table_area_frac"])
jdump(out, os.path.join(AN, "a11_noise.json"))
