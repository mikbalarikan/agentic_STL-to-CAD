import os, sys, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
p = glob.glob(os.path.join(SRC, "EP5-EM02*.stl"))[0]
m = Mesh(read_stl(p))
n2 = np.array([-0.4385, 0.2815, 0.8535]); n1 = np.array([-0.8179, 0.2707, -0.5077])
n2 -= (n2 @ n1) * n1; n2 /= np.linalg.norm(n2); n3 = np.cross(n2, n1)
R = np.stack([n1, n3, n2])          # x = side-wall normal, y = depth, z = hole-face normal (pump axis)
t = m.tri @ R.T
mm = Mesh(t)
for z0 in (-224.27, -177.22):
    s = np.abs(mm.c[:, 2] - z0) < 3
    print("face", z0, "z range of faces with |nz|>.9 :", np.percentile(mm.c[s & (np.abs(mm.n[:, 2]) > .9), 2], [1, 50, 99]).round(3))
    # boundary edges of the hole face: section at a plane just inside
    zz = z0 + (0.7 if z0 < -200 else -0.7)
    segs = mm.section(2, zz)[:, :, :2]
    for sg, closed, L in chain_loops(segs):
        if L < 4: continue
        mid = sg.mean(1); w = np.linalg.norm(sg[:, 1] - sg[:, 0], axis=1)
        cx, cy, r, rms = fit_circle(mid[:, 0], mid[:, 1], w)
        if r < 20: print(f"   loop L={L:6.1f} closed={closed} c=({cx:8.2f},{cy:8.2f}) D={2*r:6.2f} rms={rms:.3f}")
print("--- hole-face occupancy")
for z0 in (-224.37, -177.30):
    s = (np.abs(mm.c[:, 2] - z0) < 1.0) & (np.abs(mm.n[:, 2]) > 0.8)
    P, _ = mm.sample(200000, mask=s)
    c = np.array([99.0, -16.2])
    for it in range(5):
        d = P[:, :2] - c; r = np.hypot(*d.T); ang = np.arctan2(d[:, 1], d[:, 0])
        # inner boundary per angular bin
        bins = np.linspace(-np.pi, np.pi, 73); rb = []; ab = []
        for a0, a1 in zip(bins[:-1], bins[1:]):
            q = (ang >= a0) & (ang < a1) & (r < 14)
            if q.sum() > 5: rb.append(np.percentile(r[q], 0.5)); ab.append((a0 + a1) / 2)
        rb = np.array(rb); ab = np.array(ab)
        xb, yb = c[0] + rb * np.cos(ab), c[1] + rb * np.sin(ab)
        cx, cy, R0, rms = fit_circle(xb, yb); c = np.array([cx, cy])
    print(f"face {z0}: hole centre ({cx:.2f},{cy:.2f}) D={2*R0:.2f} rms {rms:.3f}  outer x [{P[:,0].min():.2f},{P[:,0].max():.2f}] y [{P[:,1].min():.2f},{P[:,1].max():.2f}]")
    # small holes: grid occupancy
    H, xe, ye = np.histogram2d(P[:, 0], P[:, 1], bins=[np.arange(70, 128, 0.25), np.arange(-34, 2, 0.25)])
    from scipy import ndimage
    empty = H == 0
    lab, nl = ndimage.label(empty)
    for k in range(1, nl + 1):
        ii, jj = np.nonzero(lab == k)
        if 20 < len(ii) < 2000 and ii.min() > 0 and jj.min() > 0 and ii.max() < H.shape[0] - 1 and jj.max() < H.shape[1] - 1:
            xc, yc = xe[ii].mean() + 0.125, ye[jj].mean() + 0.125
            print(f"    gap at ({xc:.2f},{yc:.2f}) eqD={2*np.sqrt(len(ii)*0.0625/np.pi):.2f}  rel ({xc-cx:.2f},{yc-cy:.2f}) r={np.hypot(xc-cx,yc-cy):.2f}")
