"""Re-read the assembly STEP outside NX: solids, volumes, bounding box; compare with the volumes NX reported."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from OCP.STEPControl import STEPControl_Reader
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepCheck import BRepCheck_Analyzer

stp, js = sys.argv[1], sys.argv[2]
r = STEPControl_Reader(); r.ReadFile(stp); r.TransferRoots(); s = r.OneShape()
vols, bad = [], 0
ex = TopExp_Explorer(s, TopAbs_SOLID)
while ex.More():
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(ex.Current(), g); vols.append(g.Mass())
    bad += 0 if BRepCheck_Analyzer(ex.Current()).IsValid() else 1
    ex.Next()
b = Bnd_Box(); BRepBndLib.Add_s(s, b)
nx = json.load(open(js))["part_volumes"]
want = sorted(v for vs in nx.values() for v in vs)
got = sorted(vols)
print("solids in STEP", len(got), "| solids NX reported", len(want), "| invalid solids", bad)
print("total volume STEP %.3f | NX %.3f | diff %.4f" % (sum(got), sum(want), sum(got) - sum(want)))
if len(got) == len(want):
    print("largest per-solid volume difference %.5f mm3" % max(abs(a - c) for a, c in zip(got, want)))
print("bounding box", [round(v, 2) for v in b.Get()])
