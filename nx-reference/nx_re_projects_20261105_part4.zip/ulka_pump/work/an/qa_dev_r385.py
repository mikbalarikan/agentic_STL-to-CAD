"""Independent scan-vs-CAD check (session A).

  python -I qa_dev.py <part.stp> <scan_aligned.stl> <out prefix> [--dz v] [--rotz deg] [--noicp] [--clip a,b]

The scan is moved into the model frame by rotz about Z, then dz along Z (the documented frame relation).
Signed deviation of every scan sample to the CAD surface: + = scan outside the CAD (CAD too small there).
Two results are reported: as placed, and after A's own best fit (point-to-plane ICP, rigid). The size of the
best-fit move tells how much of the deviation was alignment. Also the reverse check: how much of the CAD
surface has scan within 0.3 mm (CAD features the scan does not show).
"""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import open3d as o3d
from ulkalib import read_stl, Mesh


def step_mesh(path, defl=0.01, ang=0.2):
    from OCP.STEPControl import STEPControl_Reader
    from OCP.BRepMesh import BRepMesh_IncrementalMesh
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_FACE, TopAbs_SOLID, TopAbs_REVERSED
    from OCP.TopoDS import TopoDS
    from OCP.BRep import BRep_Tool
    from OCP.TopLoc import TopLoc_Location
    from OCP.GProp import GProp_GProps
    from OCP.BRepGProp import BRepGProp
    r = STEPControl_Reader()
    r.ReadFile(path)
    r.TransferRoots()
    shape = r.OneShape()
    BRepMesh_IncrementalMesh(shape, defl, False, ang, True)
    tris, vols = [], []
    ex = TopExp_Explorer(shape, TopAbs_SOLID)
    while ex.More():
        g = GProp_GProps()
        BRepGProp.VolumeProperties_s(ex.Current(), g)
        vols.append(g.Mass())
        ex.Next()
    ex = TopExp_Explorer(shape, TopAbs_FACE)
    while ex.More():
        f = TopoDS.Face_s(ex.Current())
        loc = TopLoc_Location()
        t = BRep_Tool.Triangulation_s(f, loc)
        if t is not None:
            trsf = loc.Transformation()
            pts = np.array([[p.X(), p.Y(), p.Z()] for p in (t.Node(i).Transformed(trsf) for i in range(1, t.NbNodes() + 1))])
            idx = np.array([t.Triangle(i).Get() for i in range(1, t.NbTriangles() + 1)]) - 1
            if f.Orientation() == TopAbs_REVERSED:
                idx = idx[:, [0, 2, 1]]
            tris.append(pts[idx])
        ex.Next()
    return np.concatenate(tris), vols


def rigid_fit(P, C, N, w):
    """Small rigid move (rotation vector, translation) minimising the point-to-plane distance of P to (C, N)."""
    A = np.concatenate([np.cross(P, N), N], axis=1) * w[:, None]
    b = (((C - P) * N).sum(1)) * w
    x, *_ = np.linalg.lstsq(A, b, rcond=None)
    rv, t = x[:3], x[3:]
    th = np.linalg.norm(rv)
    K = np.array([[0, -rv[2], rv[1]], [rv[2], 0, -rv[0]], [-rv[1], rv[0], 0]])
    R = np.eye(3) + K + K @ K / 2 if th < 1e-9 else np.eye(3) + np.sin(th) / th * K + (1 - np.cos(th)) / th ** 2 * K @ K
    return R, t


def stats(d):
    a = np.abs(d)
    return {"n": int(len(d)), "mean": float(d.mean()), "sd": float(d.std()), "p01": float(np.percentile(d, 1)),
            "p05": float(np.percentile(d, 5)), "p50": float(np.percentile(d, 50)), "p95": float(np.percentile(d, 95)),
            "p99": float(np.percentile(d, 99)), "in_005": float((a <= 0.05).mean()), "in_010": float((a <= 0.10).mean()),
            "in_015": float((a <= 0.15).mean()), "in_025": float((a <= 0.25).mean())}


def main():
    a = sys.argv[1:]
    stp, scan, out = a[0], a[1], a[2]
    opt = {"dz": 0.0, "rotz": 0.0, "icp": "--noicp" not in a, "clip": None}
    for k in ("dz", "rotz"):
        if "--" + k in a:
            opt[k] = float(a[a.index("--" + k) + 1])
    if "--clip" in a:
        opt["clip"] = [float(v) for v in a[a.index("--clip") + 1].split(",")]
    cad, vols = step_mesh(stp)
    cm = Mesh(cad)
    sm = Mesh(read_stl(scan))
    P, idx = sm.sample(400000, seed=7)
    ang = np.radians(opt["rotz"])
    Rz = np.array([[np.cos(ang), -np.sin(ang), 0], [np.sin(ang), np.cos(ang), 0], [0, 0, 1]])
    P = P @ Rz.T + np.array([0, 0, opt["dz"]])
    if opt["clip"]:
        k = (P[:, 2] >= opt["clip"][0]) & (P[:, 2] <= opt["clip"][1])
        P = P[k]
    scene = o3d.t.geometry.RaycastingScene()
    v = cad.reshape(-1, 3).astype(np.float32)
    scene.add_triangles(o3d.core.Tensor(v), o3d.core.Tensor(np.arange(len(v), dtype=np.uint32).reshape(-1, 3)))

    def dev(Q):
        r = scene.compute_closest_points(o3d.core.Tensor(Q.astype(np.float32)))
        C = r["points"].numpy().astype(float)
        n = cm.n[r["primitive_ids"].numpy()]
        return ((Q - C) * n).sum(1), C, n, np.linalg.norm(Q - C, axis=1)

    d0, C, n, u0 = dev(P)
    res = {"step": stp, "scan": scan, "options": opt, "cad_solids": len(vols), "cad_volumes": vols,
           "cad_bbox": [cad.reshape(-1, 3).min(0).tolist(), cad.reshape(-1, 3).max(0).tolist()],
           "scan_bbox_in_model_frame": [P.min(0).tolist(), P.max(0).tolist()]}
    near0 = u0 < 1.0
    res["as_placed"] = stats(d0[near0])
    res["as_placed"]["far_fraction"] = float((~near0).mean())
    Q = P.copy()
    Rt, tt = np.eye(3), np.zeros(3)
    if opt["icp"]:
        for it in range(25):
            d, C, n, u = dev(Q)
            lim = max(0.15, 3 * np.median(np.abs(d[u < 1.0])))
            w = (u < lim).astype(float)
            R, t = rigid_fit(Q, C, n, w)
            Q = Q @ R.T + t
            Rt, tt = R @ Rt, R @ tt + t
            if np.linalg.norm(t) < 2e-4 and np.degrees(np.arccos(min(1.0, (np.trace(R) - 1) / 2))) < 2e-4:
                break
        d1, C, n, u1 = dev(Q)
        near1 = u1 < 1.0
        res["best_fit"] = stats(d1[near1])
        res["best_fit"]["far_fraction"] = float((~near1).mean())
        res["best_fit_move"] = {"shift": tt.tolist(), "shift_norm": float(np.linalg.norm(tt)),
                                "rotation_deg": float(np.degrees(np.arccos(min(1.0, (np.trace(Rt) - 1) / 2)))), "iterations": it + 1}
    else:
        d1, u1, near1 = d0, u0, near0
    # reverse: CAD surface covered by the scan
    S, _ = cm.sample(200000, seed=8)
    sc2 = o3d.t.geometry.RaycastingScene()
    sv = (sm.tri @ Rz.T + np.array([0, 0, opt["dz"]]))
    if opt["icp"]:
        sv = sv @ Rt.T + tt
    sv = sv.reshape(-1, 3).astype(np.float32)
    sc2.add_triangles(o3d.core.Tensor(sv), o3d.core.Tensor(np.arange(len(sv), dtype=np.uint32).reshape(-1, 3)))
    ud = np.linalg.norm(sc2.compute_closest_points(o3d.core.Tensor(S.astype(np.float32)))["points"].numpy() - S, axis=1)
    res["cad_covered_by_scan"] = {"within_015": float((ud <= 0.15).mean()), "within_030": float((ud <= 0.30).mean()),
                                  "beyond_10": float((ud > 1.0).mean())}
    # where are the big deviations: 8 worst clusters by octant-free binning (2 mm cells)
    big = near1 & (np.abs(d1) > 0.15)
    cells = {}
    for p, dv in zip(np.floor(Q[big] / 2.0).astype(int), d1[big]):
        cells.setdefault(tuple(p), []).append(dv)
    worst = sorted(cells.items(), key=lambda kv: -len(kv[1]))[:8]
    res["over_015_cells"] = [{"cell_centre": [(c + 0.5) * 2.0 for c in k], "n": len(vv), "mean": float(np.mean(vv))} for k, vv in worst]
    json.dump(res, open(out + ".json", "w"), indent=1)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axs = plt.subplots(2, 3, figsize=(21, 13))
    views = [(0, 1, 2, 1, "from +Z"), (0, 1, 2, -1, "from -Z"), (0, 2, 1, 1, "from +Y"), (0, 2, 1, -1, "from -Y"),
             (1, 2, 0, 1, "from +X"), (1, 2, 0, -1, "from -X")]
    for ax, (i, j, h, sg, ttl) in zip(axs.ravel(), views):
        o = np.argsort(sg * Q[near1, h])
        s = ax.scatter(Q[near1][o, i], Q[near1][o, j], c=d1[near1][o], s=0.4, cmap="RdBu_r", vmin=-0.2, vmax=0.2, linewidths=0)
        ax.set_aspect("equal"); ax.set_title(ttl, fontsize=9); ax.tick_params(labelsize=6); ax.grid(True, lw=0.2)
    fig.colorbar(s, ax=axs, fraction=0.015, label="scan - CAD (mm), + = scan outside")
    fig.suptitle(os.path.basename(stp) + (" (best fit)" if opt["icp"] else " (as placed)"), fontsize=11)
    fig.savefig(out + ".png", dpi=60)
    b, p0 = res.get("best_fit"), res["as_placed"]
    print(os.path.basename(stp), "solids", len(vols), "volumes", [round(x, 2) for x in vols])
    print(f"  as placed: mean {p0['mean']:+.3f} sd {p0['sd']:.3f} p05 {p0['p05']:+.3f} p50 {p0['p50']:+.3f} p95 {p0['p95']:+.3f} | "
          f"in 0.05 {p0['in_005']:.2f} 0.10 {p0['in_010']:.2f} 0.15 {p0['in_015']:.2f} 0.25 {p0['in_025']:.2f} far {p0['far_fraction']:.3f}")
    if b:
        mv = res["best_fit_move"]
        print(f"  best fit : mean {b['mean']:+.3f} sd {b['sd']:.3f} p05 {b['p05']:+.3f} p50 {b['p50']:+.3f} p95 {b['p95']:+.3f} | "
              f"in 0.05 {b['in_005']:.2f} 0.10 {b['in_010']:.2f} 0.15 {b['in_015']:.2f} 0.25 {b['in_025']:.2f} far {b['far_fraction']:.3f}")
        print(f"  best-fit move: shift {np.round(mv['shift'], 3)} |{mv['shift_norm']:.3f}| rot {mv['rotation_deg']:.3f} deg ({mv['iterations']} it)")
    c = res["cad_covered_by_scan"]
    print(f"  CAD surface with scan within 0.15: {c['within_015']:.2f}, 0.30: {c['within_030']:.2f}, none within 1.0: {c['beyond_10']:.2f}")
    print("  cells with most |dev| > 0.15: " + "; ".join(f"{np.round(w['cell_centre'], 0)} n={w['n']} mean {w['mean']:+.2f}" for w in res["over_015_cells"][:6]))


if __name__ == "__main__":
    main()
