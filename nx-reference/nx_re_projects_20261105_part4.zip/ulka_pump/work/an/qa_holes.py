r"""Off-axis holes / pins (parallel to Z) on the A-registered scan vs the CAD: free circle fit in a z band.
  python -I qa_holes.py <CODE> <part.stp> <scan.stl> <holes.json>
holes.json: [{"name", "c": [x, y], "z": [a, b], "r": [rmin, rmax], "side": -1 hole / +1 pin}]
Uses the registration (R, t) written by qa_dev.py in qa\<CODE>_qa.json. Appends "K1_holes" to that json."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from ulkalib import read_stl, Mesh, fit_circle, AN
from qa_dev_r385 import step_mesh

code, stp, scan, hp = sys.argv[1:5]
qa = json.load(open(os.path.join(AN, "qa", code + "_qa.json")))
R, t = np.array(qa["registration"]["R"]), np.array(qa["registration"]["t"])
sm = Mesh(read_stl(scan))
P, i = sm.sample(600000, seed=5); N = sm.n[i]
P = P @ R.T + t; N = N @ R.T
cm = Mesh(step_mesh(stp)[0])
C, j = cm.sample(600000, seed=6); NC = cm.n[j]


def fit(P, N, h):
    d = P[:, :2] - np.array(h["c"]); r = np.hypot(d[:, 0], d[:, 1])
    s = (P[:, 2] >= h["z"][0]) & (P[:, 2] <= h["z"][1]) & (r >= h["r"][0]) & (r <= h["r"][1])
    nr = (N[:, 0] * d[:, 0] + N[:, 1] * d[:, 1]) / np.maximum(r, 1e-9)
    s &= nr * h["side"] > 0.6
    if s.sum() < 20:
        return None
    cx, cy, rr, rms = fit_circle(P[s, 0], P[s, 1])
    return {"D": 2 * rr, "c": [cx, cy], "rms": rms, "n": int(s.sum())}


rows = []
for h in json.load(open(hp)):
    a, b = fit(P, N, h), fit(C, NC, h)
    row = {"name": h["name"], "scan": a, "cad": b}
    if a and b:
        row["dD"] = a["D"] - b["D"]; row["dc"] = float(np.hypot(*(np.array(a["c"]) - np.array(b["c"]))))
        band = max(0.05, 2 * a["rms"]); row["band"] = band; row["pass_"] = bool(abs(row["dD"]) <= band)
        print(f"{h['name']:14s} D scan {a['D']:.3f} cad {b['D']:.3f} dD {row['dD']:+.3f} band {band:.3f} centre off {row['dc']:.3f} -> {'PASS' if row['pass_'] else 'TUTMADI'}")
    else:
        print(f"{h['name']:14s} not measurable (scan {a is not None}, cad {b is not None})")
    rows.append(row)
qa["K1_holes"] = rows
json.dump(qa, open(os.path.join(AN, "qa", code + "_qa.json"), "w"), indent=1)
