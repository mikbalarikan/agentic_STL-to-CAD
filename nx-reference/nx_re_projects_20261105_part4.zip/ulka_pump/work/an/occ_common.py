"""Common (overlap) of two STEP solids in the same frame: volume and bounding boxes of the overlap pieces."""
import sys
from OCP.STEPControl import STEPControl_Reader
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
def rd(p):
    r = STEPControl_Reader(); r.ReadFile(p); r.TransferRoots(); return r.OneShape()
a, b = rd(sys.argv[1]), rd(sys.argv[2])
c = BRepAlgoAPI_Common(a, b).Shape()
ex = TopExp_Explorer(c, TopAbs_SOLID)
while ex.More():
    g = GProp_GProps(); BRepGProp.VolumeProperties_s(ex.Current(), g)
    bb = Bnd_Box(); BRepBndLib.Add_s(ex.Current(), bb)
    print(round(g.Mass(), 4), [round(v, 2) for v in bb.Get()])
    ex.Next()
