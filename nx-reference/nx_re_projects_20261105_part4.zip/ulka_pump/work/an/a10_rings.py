import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
for k in range(4):
    m = Mesh(read_stl(os.path.join(WS, "scan", "A_rough", f"A_SL04_c{k}.stl")))
    P = m.tri.reshape(-1, 3)
    cx, cy, R0, rms = fit_circle(P[:, 0], P[:, 1])
    for it in range(3):
        r = np.hypot(P[:, 0] - cx, P[:, 1] - cy)
        # torus: centre circle radius = mean r of points near max height
        top = P[:, 2] > P[:, 2].max() - 0.3
        cx, cy, R0, rms = fit_circle(P[top, 0], P[top, 1])
    r = np.hypot(P[:, 0] - cx, P[:, 1] - cy)
    h, e = np.histogram(r, bins=np.arange(0, r.max() + 0.2, 0.2))
    print(f"c{k}: crest circle D={2*R0:.2f} (rms {rms:.3f}), hmax {P[:,2].max():.2f}, r 0.5/99.5 pct {np.percentile(r,0.5):.2f}/{np.percentile(r,99.5):.2f}")
    print("    hist r:", " ".join(f"{e[i]:.1f}:{h[i]}" for i in range(len(h)) if h[i] > 0.01 * h.max()))
