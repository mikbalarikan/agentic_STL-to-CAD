import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
m = Mesh(read_stl(os.path.join(WS, "scan", "A_rough", "A_HS02_rough.stl")))
P, idx = m.sample(400000); N = m.n[idx]
for z0 in (18, 23, 25.5, 28, 31):
    s = (np.abs(P[:, 2] - z0) < 0.3)
    r = np.hypot(P[s, 0], P[s, 1]); th = np.degrees(np.arctan2(P[s, 1], P[s, 0]))
    nr = (N[s, 0] * P[s, 0] + N[s, 1] * P[s, 1]) / r
    o = (r > 5) & (nr > 0.5)
    h = []
    for a in range(-180, 180, 15):
        q = o & (th >= a) & (th < a + 15)
        h.append(f"{np.median(r[q]):.2f}" if q.sum() > 10 else " -- ")
    print(f"z={z0:5.1f}", " ".join(h))
