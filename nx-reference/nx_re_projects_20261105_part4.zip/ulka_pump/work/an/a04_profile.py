r"""r(z) profile of a scan in its rough axis frame (from a03). Usage: a04_profile.py CODE [all]
'all' keeps every non-table component (moved with the same transform)."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
import glob
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
code = sys.argv[1]; allc = len(sys.argv) > 2 and sys.argv[2] == "all"
ax = json.load(open(os.path.join(AN, "a03_axes.json")))[code]
if allc:
    p = glob.glob(os.path.join(SRC, f"EP5-{code}*.stl"))[0]
    tri = read_stl(p); R = np.array(ax["R"]); ctr = np.array(ax["ctr"])
    t = (tri - ctr) @ R.T - np.array([0, 0, ax["z0"]])
    if ax.get("table_removed"):
        pass
    m = Mesh(t)
else:
    m = Mesh(read_stl(os.path.join(WS, "scan", "A_rough", f"A_{code}_rough.stl")))
P, idx = m.sample(300000)
N = m.n[idx]
r = np.hypot(P[:, 0], P[:, 1]); z = P[:, 2]
rr = np.where(r > 1e-6, r, 1)
nr = (N[:, 0] * P[:, 0] + N[:, 1] * P[:, 1]) / rr
fig, a = plt.subplots(figsize=(16, 7))
sc = a.scatter(z, r, s=0.3, c=nr, cmap="coolwarm", vmin=-1, vmax=1)
a.set_xlabel("z"); a.set_ylabel("r"); a.set_aspect("equal"); a.grid(True, lw=0.3)
a.set_xticks(np.arange(np.floor(z.min()), z.max() + 1, 1.0), minor=True); a.grid(True, which="minor", lw=0.1)
a.set_title(f"{code} r(z)  colour = radial normal (red out, blue in)")
fig.tight_layout(); fig.savefig(os.path.join(FIG, f"p_{code}{'_all' if allc else ''}.png"), dpi=90)
# radius histogram per z bin: outer-facing and inner-facing medians
print("z    r_out(med) n   r_in(med) n")
for z0 in np.arange(np.floor(z.min()), z.max(), 0.5):
    s = (z >= z0) & (z < z0 + 0.5)
    so, si = s & (nr > 0.8), s & (nr < -0.8)
    print(f"{z0:6.1f} {np.median(r[so]) if so.sum() > 20 else float('nan'):7.3f} {so.sum():5d}  {np.median(r[si]) if si.sum() > 20 else float('nan'):7.3f} {si.sum():5d}")
