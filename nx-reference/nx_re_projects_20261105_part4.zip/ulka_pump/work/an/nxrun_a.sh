#!/bin/bash
# usage: nxrun_a.sh <script.py> <timeout> <arg1> [arg2 ...] -- takes the shared NX lock (mkdir), checks free RAM >= 2.5 GB,
# runs the journal headless, releases the lock. ULKA-A copy of C's nxrun.sh.
S="$1"; T="$2"; shift 2; L=/c/NX_MCP_WORKSPACE/ulka/nx.lock
while true; do
  free=$(powershell -NoProfile -c "[int]((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1024)")
  if [ "$free" -ge 2500 ] && mkdir "$L" 2>/dev/null; then break; fi
  echo "waiting (free ${free} MB, lock: $(cat $L/owner.txt 2>/dev/null))"; sleep 30
done
echo "ULKA-A $(date '+%Y-%m-%d %H:%M:%S') $S" > "$L/owner.txt"
trap 'rm -rf "$L"' EXIT
ARGS=""; for a in "$@"; do ARGS="$ARGS,'$(cygpath -w "$a")'"; done; ARGS="${ARGS#,}"
powershell -NoProfile -Command "& 'C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1' -Script '$(cygpath -w "$S")' -WorkDir '$(cygpath -w "$(dirname "$S")")' -JArgs @($ARGS) -TimeoutSec $T" 2>&1 | tail -5
