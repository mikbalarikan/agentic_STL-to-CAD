"""Inventory of the 13 scans: size, components, revolution axis (from normals), extents along / across it."""
import os, glob, json, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
out = {}
for p in sorted(glob.glob(os.path.join(SRC, "*.stl"))):
    name = os.path.basename(p)[:8]
    tri = read_stl(p)
    m = Mesh(tri)
    lab, areas = components(tri)
    # PCA of area-weighted centres
    w = m.a / m.a.sum()
    c0 = (m.c * w[:, None]).sum(0)
    C = ((m.c - c0) * w[:, None]).T @ (m.c - c0)
    ev, evec = np.linalg.eigh(C)
    best = None
    for k in range(3):
        d, ns, rms = fit_dir(m.n, evec[:, k])
        frac = ns / len(m.n)
        if best is None or rms < best[2] * 0.7:
            best = (d, ns, rms, k)
    d = best[0]
    ctr, sig, _ = fit_centre(m.c, m.n, d)
    R = frame_from_axis(d)
    q = (tri.reshape(-1, 3) - ctr) @ R.T
    r = np.hypot(q[:, 0], q[:, 1])
    out[name] = dict(file=os.path.basename(p), ntri=len(tri), area=float(m.a.sum()),
                     ncomp=int(lab.max() + 1), comp_area=[round(float(a), 1) for a in areas[:6]],
                     bbox=[[round(float(v), 2) for v in tri.reshape(-1, 3).min(0)], [round(float(v), 2) for v in tri.reshape(-1, 3).max(0)]],
                     pca_sd=[round(float(np.sqrt(e)), 2) for e in ev], axis=[round(float(v), 4) for v in d],
                     axis_from_pca=best[3], axis_wall_rms=round(best[2], 4), centre=[round(float(v), 3) for v in ctr],
                     centre_miss=round(sig, 4), zlen=round(float(np.ptp(q[:, 2])), 2), zmin=round(float(q[:,2].min()),2),
                     rmax=round(float(r.max()), 2))
    print(name, json.dumps(out[name]), flush=True)
jdump(out, os.path.join(AN, "a01_inventory.json"))
