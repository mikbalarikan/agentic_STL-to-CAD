"""Three hillshade views of each scan along its PCA axes (largest first)."""
import os, glob, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
for p in sorted(glob.glob(os.path.join(SRC, "*.stl"))):
    name = os.path.basename(p)[:8]
    m = Mesh(read_stl(p))
    P, _ = m.sample(600000)
    c0 = P.mean(0); ev, V = np.linalg.eigh(np.cov((P - c0).T)); V = V[:, ::-1]
    Q = (P - c0) @ V
    fig, axs = plt.subplots(1, 4, figsize=(20, 5.5))
    res = max(0.05, np.ptp(Q[:, 0]) / 500)
    hillshade(axs[0], Q, 0, 1, 2, res, 1, "PCA0-PCA1 from +2")
    hillshade(axs[1], Q, 0, 1, 2, res, -1, "PCA0-PCA1 from -2")
    hillshade(axs[2], Q, 0, 2, 1, res, 1, "PCA0-PCA2 from +1")
    hillshade(axs[3], Q, 1, 2, 0, res, 1, "PCA1-PCA2 from +0")
    for a in axs: a.set_aspect("equal")
    fig.suptitle(name); fig.tight_layout(); fig.savefig(os.path.join(FIG, f"v_{name}.png"), dpi=70); plt.close(fig)
    print(name, flush=True)
