r"""Circle fits of section loops at given z in the rough frame. a08_loops.py CODE [all] z1 z2 ..."""
import os, sys, glob, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
code = sys.argv[1]; args = sys.argv[2:]
allc = args and args[0] == "all"
if allc:
    args = args[1:]
    ax = json.load(open(os.path.join(AN, "a03_axes.json")))[code]
    tri = read_stl(glob.glob(os.path.join(SRC, f"EP5-{code}*.stl"))[0])
    m = Mesh((tri - np.array(ax["ctr"])) @ np.array(ax["R"]).T - np.array([0, 0, ax["z0"]]))
else:
    m = Mesh(read_stl(os.path.join(WS, "scan", "A_rough", f"A_{code}_rough.stl")))
for z in map(float, args):
    rows = circle_loops(m, z, min_len=2.0)
    print(f"z={z:6.2f}: " + "; ".join(f"D={r[2]:.3f} c=({r[0]:.2f},{r[1]:.2f}) rms={r[3]:.3f} cov={r[6]:.2f}" for r in rows if r[6] > 0.25))
