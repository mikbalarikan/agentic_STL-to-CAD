r"""Independent scan-vs-CAD check, session A (ULKA). Run with the cadgenbench venv:

  python -I qa_dev.py <CODE> <part.stp> <scan.stl> [--sym] [--keep-table] [--nocomp]

A's own registration: the scan is cleaned (scanner table plane removed, largest components kept), then a
multi-start rigid fit to the CAD (principal-axis starts x 4 sign cases, plus 24 turns about the CAD z axis for
--sym parts), point-to-plane ICP from every start, best trimmed median kept, then a full ICP. The drawer's
numbers and frames are not used. Results:
  K2 general surface: share of scan samples within +-T after the best fit (T from the Rev A gate), as placed share,
      best-fit move;
  K1 functional features: the same primitive fitted to the aligned scan and to the CAD, listed in qa\specs\<CODE>.json
      ([{"name","type":"cyl"|"zplane","z":[a,b],"r":[a,b],"side":+1|-1}] in the CAD frame);
  reverse coverage: CAD surface with scan within 0.15 / 0.30.
Writes qa\<CODE>_qa.json and qa\<CODE>_qa.png.
"""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import open3d as o3d
from scipy.optimize import least_squares
from ulkalib import read_stl, Mesh, components, table_mask, AN
from qa_dev_r385 import step_mesh, rigid_fit, stats

T_GATE = {"HS02": 0.18}          # Rev A K2: T = max(0.15, 2.5 sd_part)
QA = os.path.join(AN, "qa")
os.makedirs(os.path.join(QA, "specs"), exist_ok=True)


def clean_scan(tri, keep_table=False, nocomp=False):
    m = Mesh(tri)
    if not keep_table:
        s, n, d, rms, area = table_mask(m)
        if area / m.a.sum() > 0.2:
            h = m.c @ n - d
            side = np.sign(np.average(h[~s], weights=m.a[~s]))
            tri = tri[h * side > 0.3]
    if nocomp:
        return tri
    lab, areas = components(tri)
    keep = np.isin(lab, np.nonzero(areas > 0.02 * areas[0])[0])
    return tri[keep]


def rot_z(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.0]])


class Target:
    def __init__(self, cad):
        self.cm = Mesh(cad)
        v = cad.reshape(-1, 3).astype(np.float32)
        self.scene = o3d.t.geometry.RaycastingScene()
        self.scene.add_triangles(o3d.core.Tensor(v), o3d.core.Tensor(np.arange(len(v), dtype=np.uint32).reshape(-1, 3)))

    def dev(self, Q):
        r = self.scene.compute_closest_points(o3d.core.Tensor(Q.astype(np.float32)))
        C = r["points"].numpy().astype(float)
        n = self.cm.n[r["primitive_ids"].numpy()]
        return ((Q - C) * n).sum(1), C, n, np.linalg.norm(Q - C, axis=1)

    def icp(self, Q, iters=30, lim0=3.0):
        Rt, tt = np.eye(3), np.zeros(3)
        lim = lim0
        for it in range(iters):
            d, C, n, u = self.dev(Q)
            lim = max(0.15, min(lim, 3 * np.median(u)))
            w = (u < lim).astype(float)
            if w.sum() < 50:
                break
            R, t = rigid_fit(Q, C, n, w)
            Q = Q @ R.T + t
            Rt, tt = R @ Rt, R @ tt + t
            if np.linalg.norm(t) < 1e-4 and np.degrees(np.arccos(min(1.0, (np.trace(R) - 1) / 2))) < 1e-4:
                break
        d, C, n, u = self.dev(Q)
        return Q, Rt, tt, float(np.median(u))


def cone_fit(P):
    def f(p):
        x0, y0, a, b, r0, k = p
        x = P[:, 0] - x0 - a * P[:, 2]; y = P[:, 1] - y0 - b * P[:, 2]
        return np.hypot(x, y) - (r0 + k * P[:, 2])
    r = np.hypot(P[:, 0], P[:, 1])
    s = least_squares(f, [0, 0, 0, 0, np.median(r), 0], loss="soft_l1", f_scale=0.05)
    return s.x, float(np.std(s.fun))


def feature(P, N, spec):
    z0, z1 = spec["z"]; r0, r1 = spec.get("r", [0, 1e9])
    r = np.hypot(P[:, 0], P[:, 1])
    s = (P[:, 2] >= z0) & (P[:, 2] <= z1) & (r >= r0) & (r <= r1)
    if spec["type"] == "cyl":
        nr = (N[:, 0] * P[:, 0] + N[:, 1] * P[:, 1]) / np.maximum(r, 1e-9)
        s &= nr * spec.get("side", 1) > 0.7
        if s.sum() < 30:
            return None
        x, sd = cone_fit(P[s])
        zm = (z0 + z1) / 2
        ang = np.degrees(np.arctan2(P[s, 1], P[s, 0]))
        cover = len(np.unique(np.floor(ang / 10))) * 10
        rr = r[s]
        d_ax = 2 * float(np.median(rr))
        out = {"D_free": 2 * (x[4] + x[5] * zm), "D_axis": d_ax, "sd": sd, "n": int(s.sum()), "coverage_deg": int(cover)}
        # partial arcs: a free circle centre wanders; the registered CAD axis (fitted on every surface) is used instead
        out["D"] = out["D_free"] if cover >= 180 else d_ax
        out["sd"] = sd if cover >= 180 else float(np.std(2 * rr) / 2)
        return out
    if spec["type"] == "zplane":
        s &= np.abs(N[:, 2]) > 0.9
        if s.sum() < 30:
            return None
        z = P[s, 2]
        return {"z": float(np.median(z)), "sd": float(np.std(z)), "n": int(s.sum())}


def main():
    a = sys.argv[1:]
    code, stp, scan = a[0], a[1], a[2]
    sym = "--sym" in a
    cad, vols = step_mesh(stp)
    tg = Target(cad)
    tri = clean_scan(read_stl(scan), "--keep-table" in a, "--nocomp" in a)
    sm = Mesh(tri)
    P, idx = sm.sample(300000, seed=7)
    N = sm.n[idx]
    C, _ = tg.cm.sample(200000, seed=3)
    # starts: principal axes of scan -> CAD
    def pca(X):
        c = X.mean(0); w, v = np.linalg.eigh(np.cov((X - c).T)); return c, v[:, ::-1]
    cs, Vs = pca(P); cc, Vc = pca(C)
    starts = []
    for sx in (1, -1):
        for sy in (1, -1):
            D = np.diag([sx, sy, sx * sy])
            R0 = Vc @ D @ Vs.T
            if sym:
                zc = Vc[:, 0] if abs(Vc[:, 0][2]) > 0.9 else np.array([0, 0, 1.0])
                for k in range(12):
                    starts.append((rot_z(2 * np.pi * k / 12) @ R0, 0.0))
            else:
                starts.append((R0, 0.0))
    if "--axisfit" in a:      # partly scanned revolved parts (springs): axis from the normals, not the centroid
        from ulkalib import fit_dir, fit_centre, frame_from_axis
        d0 = Vs[:, 0]
        dax, _, _ = fit_dir(N, d0)
        ctr, _, _ = fit_centre(P, N, dax)
        Ra = frame_from_axis(dax)                       # rows: scan axis frame
        q = (P - ctr) @ Ra.T
        zc = (q[:, 2].min() + q[:, 2].max()) / 2
        czc = (C[:, 2].min() + C[:, 2].max()) / 2
        starts = []
        for flip in (1, -1):
            Fl = np.diag([1, flip, flip])
            for k in range(24):
                R0 = rot_z(2 * np.pi * k / 24) @ Fl @ Ra
                # map: scan point -> R0 (p - ctr) ; then shift so axial centres match
                starts.append(("axis", R0, ctr, flip * zc, czc))
    if "--zsearch" in a:      # long revolved parts: the axial position is weakly held, try offsets along the CAD axis
        starts = [(R0, dz) for R0, dz0 in starts[::2] for dz in np.arange(-7.5, 7.51, 1.5)]
    rng = np.random.default_rng(0)
    sub = P[rng.choice(len(P), 15000, replace=False)]
    best = None
    for st_ in starts:
        if isinstance(st_[0], str):
            _, R0, ctr_, zc_, czc_ = st_
            dz = 0.0
            Q0 = (sub - ctr_) @ R0.T + np.array([0, 0, czc_ - zc_])
            cs_eff = ctr_; cc_eff = np.array([0, 0, czc_ - zc_])
        else:
            R0, dz = st_
            Q0 = (sub - cs) @ R0.T + cc + np.array([0, 0, dz])
            cs_eff, cc_eff = cs, cc + np.array([0, 0, dz])
        Q, Rt, tt, med = tg.icp(Q0, iters=20, lim0=5.0)
        d_, _, _, u_ = tg.dev(Q)
        score = -float(((np.abs(d_) <= T_GATE.get(code, 0.15)) & (u_ < 1.0)).mean())   # share within T (far points count as misses)
        med = score
        if best is None or med < best[0]:
            best = (med, R0, Rt, tt, cs_eff, cc_eff)
    med, R0, Rt, tt, cs_eff, cc_eff = best
    Rall = Rt @ R0
    tall = Rt @ (cc_eff - R0 @ cs_eff) + tt
    Q = P @ Rall.T + tall
    Q, R2, t2, med2 = tg.icp(Q, iters=40, lim0=1.0)
    Rall = R2 @ Rall; tall = R2 @ tall + t2
    if sym:   # angular features (flats, slits, windows) are small: pick the turn about the CAD axis by share within T
        Tq = T_GATE.get(code, 0.15)
        sub2 = Q[rng.choice(len(Q), 20000, replace=False)]
        best_a, best_s = 0.0, -1
        for ang in np.radians(np.arange(0, 360, 3)):
            d_, _, _, u_ = tg.dev(sub2 @ rot_z(ang).T)
            sh = float((np.abs(d_[u_ < 1.0]) <= Tq).mean())
            if sh > best_s:
                best_a, best_s = ang, sh
        Rz = rot_z(best_a)
        Q = Q @ Rz.T
        Q, R3, t3, med2 = tg.icp(Q, iters=40, lim0=0.5)
        Rall = R3 @ Rz @ Rall; tall = R3 @ (Rz @ tall) + t3
    NQ = N @ Rall.T
    d1, Cp, n1, u1 = tg.dev(Q)
    near = u1 < 1.0
    if "--exclude-z" in a:      # zone listed in the part report BEFORE QA (Rev A K2 rule)
        z0, z1 = [float(v) for v in a[a.index("--exclude-z") + 1].split(",")]
        near &= ~((Q[:, 2] >= z0) & (Q[:, 2] <= z1))
    if "--exclude-zr" in a:     # z band inside radius rmax (bores), listed before QA
        z0, z1, rm = [float(v) for v in a[a.index("--exclude-zr") + 1].split(",")]
        near &= ~((Q[:, 2] >= z0) & (Q[:, 2] <= z1) & (np.hypot(Q[:, 0], Q[:, 1]) <= rm))
    T = T_GATE.get(code, 0.15)
    res = {"code": code, "step": stp, "scan": scan, "cad_solids": len(vols), "cad_volumes": vols, "T_gate": T,
           "registration": {"starts": len(starts), "start_median": best[0], "final_median": med2,
                            "R": Rall.tolist(), "t": tall.tolist()}}
    st = stats(d1[near]); st["far_fraction"] = float((~near).mean())
    st["in_T"] = float((np.abs(d1[near]) <= T).mean())
    res["best_fit"] = st
    res["K2"] = {"T": T, "share_in_T": st["in_T"], "gate": 0.90, "pass": bool(st["in_T"] >= 0.90)}
    # as placed: the drawer's file is in the assembly / own frame; how far is A's best fit from identity?
    # (only meaningful when the scan file itself is already in that frame; reported for the record)
    # K1 features
    spec_p = os.path.join(QA, "specs", code + ".json")
    feats = []
    if os.path.exists(spec_p):
        Ccad, ci = tg.cm.sample(300000, seed=11)
        Ncad = tg.cm.n[ci]
        for sp in json.load(open(spec_p, encoding="utf-8")):
            fs, fc = feature(Q, NQ, sp), feature(Ccad, Ncad, sp)
            row = {"name": sp["name"], "type": sp["type"], "scan": fs, "cad": fc}
            if fs and fc:
                key = "D" if sp["type"] == "cyl" else "z"
                delta = fs[key] - fc[key]
                weak = fs.get("coverage_deg", 360) < 180 or fs["sd"] > 0.06
                band = max(0.05, 2 * fs["sd"]) if weak else 0.05
                row.update(delta=delta, band=band, weak=bool(weak), pass_=bool(abs(delta) <= band))
            feats.append(row)
    res["K1"] = feats
    # reverse coverage
    S, _ = tg.cm.sample(150000, seed=8)
    sc2 = o3d.t.geometry.RaycastingScene()
    sv = (sm.tri @ Rall.T + tall).reshape(-1, 3).astype(np.float32)
    sc2.add_triangles(o3d.core.Tensor(sv), o3d.core.Tensor(np.arange(len(sv), dtype=np.uint32).reshape(-1, 3)))
    ud = np.linalg.norm(sc2.compute_closest_points(o3d.core.Tensor(S.astype(np.float32)))["points"].numpy() - S, axis=1)
    res["cad_covered_by_scan"] = {"within_015": float((ud <= 0.15).mean()), "within_030": float((ud <= 0.30).mean()),
                                  "beyond_10": float((ud > 1.0).mean())}
    big = near & (np.abs(d1) > T)
    cells = {}
    for p, dv in zip(np.floor(Q[big] / 2.0).astype(int), d1[big]):
        cells.setdefault(tuple(p), []).append(dv)
    worst = sorted(cells.items(), key=lambda kv: -len(kv[1]))[:8]
    res["over_T_cells"] = [{"cell_centre": [(c + 0.5) * 2.0 for c in k], "n": len(vv), "mean": float(np.mean(vv))} for k, vv in worst]
    json.dump(res, open(os.path.join(QA, code + "_qa.json"), "w"), indent=1)
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axs = plt.subplots(2, 3, figsize=(21, 13))
    views = [(0, 1, 2, 1, "from +Z"), (0, 1, 2, -1, "from -Z"), (0, 2, 1, 1, "from +Y"), (0, 2, 1, -1, "from -Y"),
             (1, 2, 0, 1, "from +X"), (1, 2, 0, -1, "from -X")]
    for ax, (i, j, h, sg, ttl) in zip(axs.ravel(), views):
        o = np.argsort(sg * Q[near, h])
        s = ax.scatter(Q[near][o, i], Q[near][o, j], c=d1[near][o], s=0.4, cmap="RdBu_r", vmin=-0.25, vmax=0.25, linewidths=0)
        ax.set_aspect("equal"); ax.set_title(ttl, fontsize=9); ax.tick_params(labelsize=6); ax.grid(True, lw=0.2)
    fig.colorbar(s, ax=axs, fraction=0.015, label="scan - CAD (mm), + = scan outside")
    fig.suptitle(f"{code} A best fit, in +-{T}: {st['in_T']:.3f}", fontsize=11)
    fig.savefig(os.path.join(QA, code + "_qa.png"), dpi=60)
    print(f"{code}: solids {len(vols)} vol {[round(v, 1) for v in vols]} | reg median {med2:.3f} ({len(starts)} starts)")
    print(f"  best fit: mean {st['mean']:+.3f} sd {st['sd']:.3f} p05 {st['p05']:+.3f} p95 {st['p95']:+.3f} | in T={T}: {st['in_T']:.3f}"
          f"  -> K2 {'PASS' if res['K2']['pass'] else 'TUTMADI'} | far {st['far_fraction']:.3f}")
    for f in feats:
        if "delta" in f:
            print(f"  K1 {f['name']:28s} scan {f['scan'].get('D', f['scan'].get('z')):8.3f} cad {f['cad'].get('D', f['cad'].get('z')):8.3f}"
                  f" d {f['delta']:+.3f} band {f['band']:.3f}{' zayif' if f['weak'] else ''} -> {'PASS' if f['pass_'] else 'TUTMADI'}")
        else:
            print(f"  K1 {f['name']:28s} not measurable (scan {f['scan'] is not None}, cad {f['cad'] is not None})")
    c = res["cad_covered_by_scan"]
    print(f"  CAD covered within 0.15: {c['within_015']:.2f}, 0.30: {c['within_030']:.2f}, none within 1.0: {c['beyond_10']:.2f}")


main()
