r"""Per scan: remove scanner table plane(s), find the revolution axis, write the scan in its own rough frame
(z = axis, origin at axis point at zmin) to C:\NX_MCP_WORKSPACE\ulka\scan\A_<code>_rough.stl, plus r(z) envelope."""
import os, glob, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
OUT = os.path.join(WS, "scan", "A_rough"); os.makedirs(OUT, exist_ok=True)

rep = {}
for p in sorted(glob.glob(os.path.join(SRC, "*.stl"))):
    code = os.path.basename(p)[4:8]
    tri = read_stl(p); m = Mesh(tri)
    s, n, d, rms, area = table_mask(m)
    frac = area / m.a.sum()
    info = dict(table_area_frac=round(frac, 3), table_rms=round(rms, 4))
    keep = np.ones(len(tri), bool)
    if frac > 0.25:   # a scanner table / putty plane is present: drop it and everything below/at it
        h = m.c @ n - d
        side = np.sign(np.average(h[~s], weights=m.a[~s]))
        keep = (h * side > 0.35)
        info["table_removed"] = True
    mk = Mesh(tri[keep])
    lab, areas = components(mk.tri)
    big = lab == 0
    mk = Mesh(mk.tri[big])
    w = mk.a / mk.a.sum(); c0 = (mk.c * w[:, None]).sum(0)
    ev, V = np.linalg.eigh(((mk.c - c0) * w[:, None]).T @ (mk.c - c0))
    cands = []
    for k in range(3):
        dd, ns, wr = fit_dir(mk.n, V[:, k])
        ctr, sig, inl = fit_centre(mk.c, mk.n, dd)
        cands.append((sig, k, dd, ctr, ns / len(mk.n), wr))
    cands.sort(key=lambda t: t[0])
    sig, k, dd, ctr, wfrac, wr = cands[0]
    R = frame_from_axis(dd)
    q = (mk.tri.reshape(-1, 3) - ctr) @ R.T
    z0 = q[:, 2].min()
    t = ((mk.tri - ctr) @ R.T) - np.array([0, 0, z0])
    write_stl(os.path.join(OUT, f"A_{code}_rough.stl"), t)
    info.update(dict(ncomp_after=int(lab.max() + 1), kept_area=round(float(mk.a.sum()), 1), axis_seed=int(k),
                     centre_miss=round(sig, 4), wall_frac=round(wfrac, 3), wall_rms=round(wr, 4),
                     R=R.tolist(), ctr=ctr.tolist(), z0=float(z0), length=round(float(np.ptp(t[:, :, 2])), 3),
                     cand=[(round(c[0], 3), c[1]) for c in cands]))
    rep[code] = info
    print(code, {k2: v for k2, v in info.items() if k2 not in ("R", "ctr")}, flush=True)
jdump(rep, os.path.join(AN, "a03_axes.json"))
