"""ULKA scan analysis helpers (session A). Run with the cadgenbench venv:
    %USERPROFILE%\\.venvs\\cadgenbench\\Scripts\\python.exe -I <script>
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import sys
import json
import numpy as np

sys.stdout.reconfigure(encoding="utf-8")

SRC = r"H:\My Drive\Mini Pumps\ulka re"
WS = r"C:\NX_MCP_WORKSPACE\ulka"
AN = os.path.join(WS, "an")
FIG = os.path.join(AN, "fig")
SCAN = os.path.join(WS, "scan")


def read_stl(path):
    """Binary STL -> (n, 3, 3) float64 triangles."""
    with open(path, "rb") as f:
        f.seek(80)
        n = int(np.frombuffer(f.read(4), "<u4")[0])
        dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
        d = np.frombuffer(f.read(n * 50), dt, count=n)
    return d["v"].astype(np.float64)


def write_stl(path, tri):
    tri = np.asarray(tri, np.float32)
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    n /= np.maximum(np.linalg.norm(n, axis=1), 1e-20)[:, None]
    d = np.zeros(len(tri), np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]))
    d["n"], d["v"] = n, tri
    with open(path, "wb") as f:
        f.write(b"ulka".ljust(80, b" "))
        f.write(np.uint32(len(tri)).tobytes())
        f.write(d.tobytes())


def weld(tri, tol=1e-4):
    """Triangles -> (vertices, faces) with coincident vertices merged."""
    v = tri.reshape(-1, 3)
    q = np.round(v / tol).astype(np.int64)
    _, idx, inv = np.unique(q, axis=0, return_index=True, return_inverse=True)
    return v[idx], inv.reshape(-1, 3)


def components(tri):
    """Label each triangle with its edge-connected component (largest area first)."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    v, f = weld(tri)
    n = len(v)
    i = np.concatenate([f[:, 0], f[:, 1], f[:, 2]])
    j = np.concatenate([f[:, 1], f[:, 2], f[:, 0]])
    g = coo_matrix((np.ones(len(i), np.int8), (i, j)), shape=(n, n))
    _, lab = connected_components(g, directed=False)
    fl = lab[f[:, 0]]
    a = np.linalg.norm(np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]), axis=1) / 2
    area = np.bincount(fl, weights=a)
    order = np.argsort(-area)
    rank = np.empty_like(order)
    rank[order] = np.arange(len(order))
    return rank[fl], area[order]


class Mesh:
    def __init__(self, tri):
        self.tri = tri
        self.c = tri.mean(axis=1)
        nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        a = np.linalg.norm(nrm, axis=1)
        self.n = nrm / np.maximum(a, 1e-12)[:, None]
        self.a = a / 2
        self.lo = tri.min(axis=1)
        self.hi = tri.max(axis=1)

    def moved(self, R, t):
        """New mesh with p' = R @ p + t."""
        return Mesh(self.tri @ R.T + t)

    def section(self, axis, value, box=None):
        """Segments (m, 2, 3) where the plane axis=value cuts the mesh."""
        m = (self.lo[:, axis] <= value) & (self.hi[:, axis] >= value)
        if box is not None:
            for ax, (a0, a1) in box.items():
                m &= (self.hi[:, ax] >= a0) & (self.lo[:, ax] <= a1)
        t = self.tri[m]
        d = t[:, :, axis] - value
        segs = []
        for i, j, k in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
            s = (d[:, i] * d[:, j] < 0) & (d[:, i] * d[:, k] < 0)
            if not s.any():
                continue
            ti, di, dj, dk = t[s], d[s, i], d[s, j], d[s, k]
            p1 = ti[:, i] + (ti[:, j] - ti[:, i]) * (di / (di - dj))[:, None]
            p2 = ti[:, i] + (ti[:, k] - ti[:, i]) * (di / (di - dk))[:, None]
            segs.append(np.stack([p1, p2], axis=1))
        if not segs:
            return np.zeros((0, 2, 3))
        return np.concatenate(segs)

    def sample(self, n, seed=0, mask=None):
        rng = np.random.default_rng(seed)
        a = self.a if mask is None else np.where(mask, self.a, 0.0)
        idx = rng.choice(len(a), size=n, p=a / a.sum())
        u, v = rng.random(n), rng.random(n)
        f = u + v > 1
        u[f], v[f] = 1 - u[f], 1 - v[f]
        t = self.tri[idx]
        return t[:, 0] + (t[:, 1] - t[:, 0]) * u[:, None] + (t[:, 2] - t[:, 0]) * v[:, None], idx


def frame_from_axis(a, xhint=None):
    """Rotation R (rows = new x, y, z in old coordinates) with z along a."""
    z = np.asarray(a, float) / np.linalg.norm(a)
    h = np.array([1.0, 0, 0]) if xhint is None else np.asarray(xhint, float)
    if abs(h @ z) > 0.9:
        h = np.array([0, 1.0, 0])
    x = h - (h @ z) * z
    x /= np.linalg.norm(x)
    return np.stack([x, np.cross(z, x), z])


def fit_circle(x, y, w=None):
    """Algebraic (Kasa) circle fit, weighted. Returns cx, cy, r, rms."""
    w = np.ones_like(x) if w is None else w
    A = np.stack([2 * x, 2 * y, np.ones_like(x)], axis=1) * w[:, None]
    b = (x ** 2 + y ** 2) * w
    (cx, cy, c), *_ = np.linalg.lstsq(A, b, rcond=None)
    r = np.sqrt(c + cx ** 2 + cy ** 2)
    res = np.hypot(x - cx, y - cy) - r
    return cx, cy, r, float(np.sqrt(np.average(res ** 2, weights=w)))


def fit_dir(N, d0, cos_max=0.15, iters=8):
    """Direction that the 'vertical wall' normals are perpendicular to (cylinders, prismatic walls
    with symmetric draft). Smallest eigenvector of the normal scatter of the faces with |n.d| < cos_max.
    (A 6-unknown Plucker line fit is degenerate on a pure cylinder: the line at infinity fits too.)"""
    d = np.asarray(d0, float) / np.linalg.norm(d0)
    for _ in range(iters):
        s = np.abs(N @ d) < cos_max
        w, v = np.linalg.eigh(N[s].T @ N[s] / s.sum())
        dn = v[:, 0] * np.sign(v[:, 0] @ d)
        done = np.degrees(np.arccos(min(1.0, dn @ d))) < 1e-4
        d = dn
        if done:
            break
    return d, int(s.sum()), float(np.sqrt(w[0]))


def fit_centre(P, N, d, iters=8, k=2.5):
    """Point of the axis (direction d) from surfaces of revolution: every normal line meets the axis.
    Works across mixed radii. Returns the centre in the plane through the origin perpendicular to d,
    the rms miss distance of the normal lines, and the inlier mask."""
    R = frame_from_axis(d)
    p, n = P @ R.T, N @ R.T
    ln = np.hypot(n[:, 0], n[:, 1])
    ok = ln > 0.3
    A = np.stack([n[:, 1], -n[:, 0]], axis=1) / np.maximum(ln, 1e-9)[:, None]
    b = (p[:, 0] * n[:, 1] - p[:, 1] * n[:, 0]) / np.maximum(ln, 1e-9)
    w = ok.copy()
    for _ in range(iters):
        c, *_ = np.linalg.lstsq(A[w], b[w], rcond=None)
        res = A @ c - b
        sig = max(float(np.sqrt(np.mean(res[w] ** 2))), 1e-6)
        w = ok & (np.abs(res) < k * sig)
    return R.T @ np.array([c[0], c[1], 0.0]), sig, w


def hillshade(ax, P, u, v, h, res=0.1, sign=1, title="", cmap=None, lim=None):
    """Height map of points P seen along the h axis (columns u, v are the image axes)."""
    import matplotlib.pyplot as plt
    from matplotlib.colors import LightSource
    if lim is None:
        lim = (P[:, u].min(), P[:, u].max(), P[:, v].min(), P[:, v].max())
    x0, x1, y0, y1 = lim
    nx, ny = int((x1 - x0) / res) + 1, int((y1 - y0) / res) + 1
    s = (P[:, u] >= x0) & (P[:, u] <= x1) & (P[:, v] >= y0) & (P[:, v] <= y1)
    Q = P[s]
    ix = np.clip(((Q[:, u] - x0) / res).astype(int), 0, nx - 1)
    iy = np.clip(((Q[:, v] - y0) / res).astype(int), 0, ny - 1)
    flat = iy * nx + ix
    o = np.argsort(sign * Q[:, h])
    g = np.full(ny * nx, np.nan)
    g[flat[o]] = Q[o, h]
    g = g.reshape(ny, nx)
    f = np.where(np.isnan(g), np.nanmin(sign * g) * sign - 3 * sign, g)
    ls = LightSource(azdeg=315, altdeg=45)
    rgb = ls.shade(sign * f, cmap=cmap or plt.cm.turbo, vert_exag=2.0, dx=res, dy=res, blend_mode="soft",
                   vmin=np.nanmin(sign * g), vmax=np.nanmax(sign * g))
    rgb[np.isnan(g)] = (1, 1, 1, 1)
    ax.imshow(rgb, origin="lower", extent=[x0, x1, y0, y1], interpolation="nearest")
    ax.set_title(title, fontsize=9)
    ax.tick_params(labelsize=6)
    ax.grid(True, lw=0.15, color="k", alpha=0.3)
    return g


def plot_section(ax, segs, axis, **kw):
    from matplotlib.collections import LineCollection
    o = [i for i in range(3) if i != axis]
    lc = LineCollection(segs[:, :, o], **{"linewidths": 0.5, "colors": "k", **kw})
    ax.add_collection(lc)
    ax.set_aspect("equal")
    ax.autoscale()
    return o


def jdump(obj, path):
    def conv(o):
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        raise TypeError(type(o))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, default=conv)


def chain_loops(segs2d, tol=1e-5):
    """Group section segments (m, 2, 2) into connected polylines. Returns a list of (k, 2) point arrays
    (unordered points of each connected curve) and whether each is closed (every node has degree 2)."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    pts = segs2d.reshape(-1, 2)
    q = np.round(pts / tol).astype(np.int64)
    _, inv = np.unique(q, axis=0, return_inverse=True)
    inv = inv.reshape(-1, 2)
    n = inv.max() + 1
    g = coo_matrix((np.ones(len(inv)), (inv[:, 0], inv[:, 1])), shape=(n, n))
    _, lab = connected_components(g, directed=False)
    deg = np.bincount(inv.ravel(), minlength=n)
    out = []
    sl = lab[inv[:, 0]]
    for c in np.unique(sl):
        s = segs2d[sl == c]
        nodes = np.unique(inv[sl == c])
        length = float(np.linalg.norm(s[:, 1] - s[:, 0], axis=1).sum())
        out.append((s, bool((deg[nodes] == 2).all()), length))
    return out


def circle_loops(mesh, z, min_len=3.0):
    """Section the mesh at z and fit a circle to every connected section curve.
    Returns rows (cx, cy, D, rms, length, closed, coverage) sorted by D."""
    segs = mesh.section(2, z)[:, :, :2]
    rows = []
    for s, closed, length in chain_loops(segs):
        if length < min_len:
            continue
        mid = s.mean(axis=1)
        w = np.linalg.norm(s[:, 1] - s[:, 0], axis=1)
        cx, cy, r, rms = fit_circle(mid[:, 0], mid[:, 1], w)
        cov = length / (2 * np.pi * r) if r > 0 else 0
        rows.append((cx, cy, 2 * r, rms, length, closed, cov))
    return sorted(rows, key=lambda t: t[2])


def table_mask(m, tol=0.25):
    """Largest plane by area among face normals (RANSAC-lite on normal clusters). Returns mask of faces on it,
    plane (n, d) and rms of the in-plane residual."""
    rng = np.random.default_rng(1)
    best = (0, None)
    idx = rng.choice(len(m.n), 400, p=m.a / m.a.sum())
    for i in idx:
        n = m.n[i]; d = n @ m.c[i]
        s = (np.abs(m.c @ n - d) < tol) & (m.n @ n > 0.95)
        a = m.a[s].sum()
        if a > best[0]: best = (a, (n, d))
    n, d = best[1]
    for _ in range(3):
        s = (np.abs(m.c @ n - d) < tol) & (np.abs(m.n @ n) > 0.95)
        P = m.c[s]; c = np.average(P, axis=0, weights=m.a[s])
        w, v = np.linalg.eigh(np.cov((P - c).T, aweights=m.a[s]))
        n = v[:, 0] * np.sign(v[:, 0] @ n); d = n @ c
    res = m.c[s] @ n - d
    return s, n, d, float(np.sqrt(np.average(res ** 2, weights=m.a[s]))), best[0]

