"""EM02 frame: face planes, sheet thickness, hole circles."""
import os, sys, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
p = glob.glob(os.path.join(SRC, "EP5-EM02*.stl"))[0]
m = Mesh(read_stl(p))
# dominant normal directions
rng = np.random.default_rng(0)
dirs = []
Nw = m.n.copy()
for it in range(6):
    best = None
    free = np.ones(len(Nw), bool)
    for d in dirs: free &= np.abs(Nw @ d) < 0.5
    pa = np.where(free, m.a, 0); pa = pa / pa.sum()
    for i in rng.choice(len(Nw), 300, p=pa):
        s = np.abs(Nw @ Nw[i]) > 0.98
        a = m.a[s].sum()
        if best is None or a > best[0]: best = (a, Nw[i])
    n = best[1]
    if any(abs(n @ d) > 0.9 for d in dirs): 
        continue
    s = np.abs(m.n @ n) > 0.97
    w, v = np.linalg.eigh((m.n[s] * m.a[s, None]).T @ m.n[s])
    n = v[:, -1]
    dirs.append(n)
    h = m.c[s] @ n
    hist, edges = np.histogram(h, bins=np.arange(h.min() - 0.1, h.max() + 0.1, 0.05), weights=m.a[s])
    pk = [(edges[i] + 0.025, hist[i]) for i in range(1, len(hist) - 1) if hist[i] > hist[i - 1] and hist[i] >= hist[i + 1] and hist[i] > 0.03 * hist.max()]
    print("dir", np.round(n, 4), "area", round(m.a[s].sum(), 1), "peaks", [(round(a, 2), round(b, 1)) for a, b in pk])
