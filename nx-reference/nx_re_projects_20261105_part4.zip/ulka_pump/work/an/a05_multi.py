r"""Multi-part / flat-lying scans: remove the table, split components, report each one in the table frame
(h = height above table). Usage: a05_multi.py CODE"""
import os, sys, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
code = sys.argv[1]
p = glob.glob(os.path.join(SRC, f"EP5-{code}*.stl"))[0]
tri = read_stl(p); m = Mesh(tri)
s, n, d, rms, area = table_mask(m)
h = m.c @ n - d
side = np.sign(np.average(h[~s], weights=m.a[~s]))
n = n * side; d = d * side
R = frame_from_axis(n)
t = (tri - n * d) @ R.T          # table plane -> z = 0
keep = t[:, :, 2].min(1) > 0.12
mk = Mesh(t[keep])
lab, areas = components(mk.tri)
print(f"{code}: table rms {rms:.4f}, components {lab.max()+1}")
rows = []
for k in range(lab.max() + 1):
    mm = Mesh(mk.tri[lab == k])
    if mm.a.sum() < 3: continue
    P = mm.tri.reshape(-1, 3)
    c = P[:, :2].mean(0)
    cx, cy, rr, rres = fit_circle(P[:, 0], P[:, 1])
    rad = np.hypot(P[:, 0] - cx, P[:, 1] - cy)
    rows.append((k, mm.a.sum(), P[:, 0].min(), P[:, 0].max(), P[:, 1].min(), P[:, 1].max(), P[:, 2].max(), cx, cy, np.percentile(rad, 1), np.percentile(rad, 99)))
    print(f" c{k:2d} area {mm.a.sum():7.1f}  x[{P[:,0].min():7.2f},{P[:,0].max():7.2f}] y[{P[:,1].min():7.2f},{P[:,1].max():7.2f}] hmax {P[:,2].max():5.2f}  circ c=({cx:6.2f},{cy:6.2f}) r1..r99 {np.percentile(rad,1):5.2f}..{np.percentile(rad,99):5.2f}")
    write_stl(os.path.join(WS, "scan", "A_rough", f"A_{code}_c{k}.stl"), mm.tri)
