r"""Axial plane levels (faces with |nz|>0.95) in the rough frame, with radial range and sign of nz. a09_levels.py CODE [all]"""
import os, sys, glob, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ulkalib import *
code = sys.argv[1]; allc = len(sys.argv) > 2
if allc:
    ax = json.load(open(os.path.join(AN, "a03_axes.json")))[code]
    tri = read_stl(glob.glob(os.path.join(SRC, f"EP5-{code}*.stl"))[0])
    m = Mesh((tri - np.array(ax["ctr"])) @ np.array(ax["R"]).T - np.array([0, 0, ax["z0"]]))
else:
    m = Mesh(read_stl(os.path.join(WS, "scan", "A_rough", f"A_{code}_rough.stl")))
r = np.hypot(m.c[:, 0], m.c[:, 1])
for sgn in (+1, -1):
    s = m.n[:, 2] * sgn > 0.95
    z = m.c[s, 2]; a = m.a[s]
    edges = np.arange(z.min() - 0.1, z.max() + 0.15, 0.05)
    h, e = np.histogram(z, edges, weights=a)
    tot = a.sum()
    print(f"normal {'+z' if sgn > 0 else '-z'} (total {tot:.1f} mm2)")
    for i in range(1, len(h) - 1):
        if h[i] >= h[i - 1] and h[i] > h[i + 1] and h[i] > max(0.5, 0.01 * tot):
            q = s.copy(); q[s] = np.abs(z - e[i] - 0.025) < 0.15
            zz = np.average(m.c[q, 2], weights=m.a[q]); sd = np.sqrt(np.average((m.c[q, 2] - zz) ** 2, weights=m.a[q]))
            print(f"   z={zz:7.3f} sd={sd:.3f} area={m.a[q].sum():7.1f}  r[{np.percentile(r[q],2):6.2f},{np.percentile(r[q],98):6.2f}]")
