# ULKA_INTERFACES - Ulka EP5 arayüz belgesi

**Rev H** - 2026-10-16 - yazar ULKA-A (tek yazar). Kontrol parçası `C:\NX_MCP_WORKSPACE\ulka\ctrl\EP5-AS00_CTRL.prt`
(`ctrl_params.json` -> `ctrl_build.py`; sonuç `ctrl_build.json`). Değerlerin dökümü bu belgenin sonunda (§9) ve
`ctrl_values_py.json`'da. Çelişki bulan oturum `cr\CR-<harf>-nn.md` yazar ve A'ya haber verir; kontrol parçasına
dokunmaz. Ölçüm gerekçeleri: `sessions\A_MEASURED.md`, `B_/C_/D_MEASURED.md`.

## 1. Eksen takımı (donduruldu)
- Z = EM02'nin iki büyük deliğinin ortak ekseni = kartuş ekseni, **+Z girişten (HS01 nipeli) çıkışa (HS02 ucu)**.
- Orijin = EM02 çıkış duvarı **dış yüzü** ∩ eksen (`z_em02_out` = 0).
- +Y = EM02 şerit genişliği yönü, **EM01 fast-on terminallerinin tarafı**. +X = Y × Z (EM02 düz duvar normali);
  FS01 vidaları (±`fs_pitch`/2, 0).
- Kontrol parçasında datum düzlemleri (adları expression adının büyük harfi: `Z_HS01_FLANGE` ...) ve `PUMP_AXIS`.

## 2. Parça yerleşimi (kim, hangi çerçevede)
Sabit parçalar montaj koordinatında **yerinde** modellenir; bileşenler montaja orijinde kısıtsız eklenir.
Hareketli parçalar kendi ekseninde modellenir, A konumlar.

| Parça | Sahip | Çerçeve | Yerleşim / açısal konum |
|---|---|---|---|
| EM02 | B | yerinde | düz duvarlar ±X, açık yanlar ±Y; birleşme yarığı çıkış duvarında X=0 |
| EM01 | B | yerinde | terminal ucu `z_em01_term` (Rev H: iki duvar arasında ortalı, -3,30), plaka ve fast-on'lar +Y, bıçaklar -Z yönünde (datasheet yan görünüş, türetildi) |
| EM03 | B | yerinde, EM03-A konumu (`z_em03a_bot`..) | ikinci kopya A'da +(em03_len+hs04_h) ötelenir; yarık +X'te |
| HS04 | B | yerinde | `z_hs04_bot`..`z_hs04_top` |
| HS01 | C | yerinde | flanş üst yüzü `z_hs01_flange` (C'nin z0'ı) |
| DR01 | C | kendi: z0 = armatür ön alnı, +z piston ucuna | A: `z_dr01` (dinlenme), strok taraması |
| DR02, DR03 | C | kendi: z0 = bir uç düzlemi, +z öbür uç | serbest boyda; uzunluk parça içinde adlı expression (`dr02_len` / `dr03_len`, varsayılan l0) olsun, A sıkışmış kopyayı `dr0x_l_inst` ile yapar |
| HS05 | D | yerinde | alt yüz `z_hs05` |
| HS02 | D | yerinde | flanş yüzü `z_hs02` (D'nin z0'ı); CH12 düzlüklerinin normali ±X |
| HS03 | D | yerinde | alt yüz `z_hs03`; kulaklar ±X, pimler (±pin_x, ±pin_y) |
| SL01..SL04 | D | yerinde, nötr (kalıp) halinde torus | SL01 alt yüzü `z_em03b_top`; SL02 alt yüzü `z_sl02`; SL03 alt yüzü `z_sl03`; SL04 HS02 havşasında (havşa tabanına dayalı) |
| VL01 | D | kendi: merkez orijinde | A: piston ucu havşasına oturur |
| VL02, VL03, VL04 | D | kendi: z0 = alt (giriş tarafı) uç, +z çıkışa | serbest boyda; uzunluk adlı expression; A konumlar |
| VL05 | D | yerinde | HS02 çıkış havşasında tırnaklarıyla sıkı, alt yüzü `z_vl05` = `z_hs02`+`hs02_vl05_z` (31,92; Rev D, CR-D-02); üstünde G1/8 iç diş 4,8 boy (kozmetik; datasheet min 7 tutmuyor, türetme) |
| FS01 | A | yerinde (+X vidası) | ikinci kopya A'da X'te -fs_pitch |

## 3. Eksenel yığın (özet; değerler §9)
Giriş duvarı iç yüzü -> EM03-A (18,9) -> HS04 (9,1) -> EM03-B (18,9, çıkış duvarı deliğinden geçer, dış yüzün 0,22
altında) -> SL01 -> HS01 flanşı -> soket ağzı -> HS05 -> HS02 flanşı -> SL03 -> HS03 üst kademesi. Bu zincir
kapalıdır; SL01 ve SL03 birlikte `sl_sq` (%22,7, Rev F) sıkışır. SL02 HS01 flanşı üstünde, HS03 alt deliğinde, dudakta
radyal conta (`sq_sl02` %2,5 - zayıf, türetildi). Armatürün dinlenme konumu yay dengesinden (`dr_defl`, `dr02_k`,
`dr03_k`); manyetik strok `stroke_mag` 4,48 (armatür girişe çekilir), yukarı sert dayanma `stroke_up` 5,81.
Toplam boy `total_len` 121,62 (datasheet 122). Rev C: manyetik strok 7,71, yukarı dayanma 2,58.

## 4. Türetilen (taramada yok) değerler - kaynağıyla
| Değer | Rev A | Kaynak / gerekçe | Ölçüm önerisi |
|---|---|---|---|
| `hs01_inner_bot` | 52,0 (Rev A 55,3) | HS01 dış geçişinin (z -54..-56,8) üstünde ~2 cidar, C'nin tahmini 53; Usta'nın tel ölçüleri + CR-C-01 sarımlarıyla 15 bar kontrolü (`p_max_check` 15,9) | A_OLCUM #2 |
| `hs01_bore_d` tüp boyunca | 14,92 | ağızdan 10 mm görülen, tüp boyunca sabit kabul (C) | - |
| SL01 yeri (flanş altı) | - | kapalı zincirin tek tutarlı yeri; flanş üstünde olsa 10 bar çıkar | - |
| `z_em01_term` (terminal ucu çıkışta) | -3,0 | datasheet yan görünüşte terminal kutusu çerçevenin üst (çıkış) yarısında | - |
| `dr02_k`, `dr03_k` | 1,17 / 2,82 (formül) | Usta'nın tel ölçüsü 1,0 / 1,3 (CR-D-01) + tarama sarım merkez çapı 11,75/11,54 (CR-C-02) ve n_a 4,55/6,5; G 69 / 79 GPa. **Çelişki:** tarama teli 1,19 / 1,41 (C, iki yöntem); k tel^4 ile ~2 kat değişir | A_OLCUM #3 (k ölçümü çelişkiyi çözer) |
| `hs02_seat_d` | 4,0 | VL03 kubbe R2,76 (D) | A_OLCUM #4 |
| HS02 basınç odası | Ø6,2, dibi D'de | D türetir; VL02 montaj boyu 12-13 olacak şekilde | A_OLCUM #4 |
| VL02 / VL04 tel, sarım | 0,5 / 0,45 | tarama zayıf (D) | A_OLCUM #5 |
| `em03_slit_w` | 0,5 | F04 (B) | - |
| `fs01_len` | 8 | M4x10 makara alnına girerdi | - |
| G1/8 iç diş | kozmetik | datasheet "1/8 Gas min 7"; HS02 çıkış havşası Ø8,52 = delik çapı | - |
| `z_dr01` ve stroklar | -3,70 | yay dengesi | E doğrular |

## 5. Yuvarlama ve standart eşlemeler
- Değerler taramaya sadık tutuldu (0,01 mm). Tasarım niyetine yuvarlama yalnız fark uydurma kesinliğinin içindeyse:
  yay telleri 1,23 -> 1,2 ve 1,43 -> 1,4 (sd 0,12 / 0,06), VL01 3,606 -> 3,572 (9/64", 1 sd), SL02 ISO 3601 15,47 x 2,62,
  SL04 4,5 x 2,0. **d_p 4,97 kaldı** (5,00'a 0,03-0,04: piston yüzeyinde sd 0,014-0,028, ortalama çok daha kesin;
  yuvarlama gürültü dışı). SL01 / SL03 standart eşlemesini D raporda yazar (değerler şimdilik tarama).
- FS01: ISO 7045 M4 x 8 H (yıldız, silindir/pan baş), EM02'de M4 diş (kozmetik, delik taramadaki Ø3,5).

## 6. Kabul kapıları (modellemeden ÖNCE sabitlendi; sonuç görüldükten sonra gevşetilmez)
A her parçayı kendi hizalamasıyla ölçer (`an\qa_dev.py`, çizenin sayılarına bakmadan); sonuç `sessions\A_QA.md`.

**K1 - İşlevsel yüzeyler** (aşağıdaki liste): aynı primitif (silindir / düzlem / küre / torus) taramaya ve CAD'e
A tarafından uydurulur; |ΔØ| ≤ **0,05**, parça içi düzlem konumu |Δz| ≤ **0,05**. Tarama özelliği zayıfsa
(kapsama < 180° ya da uydurma sd > 0,06): bant = max(0,05; 2·sd_uydurma), raporda "zayıf" yazılır.
İşlevsel liste: EM02 delikleri (büyük 2, pim 4, vida 2), iç eksenel açıklık, t; EM01 delik, gövde Ø, boy; EM03 OD/ID/boy;
HS04 OD/ID/boy; HS01 tüp dışı, soket deliği, dudak dışı, flanş Ø ve üst yüz, nipel; DR01 armatür Ø, alınlar, piston
d_p, pilotlar, uç havşası; yaylar d, OD, L0; HS02 flanş Ø/kalınlık, SL04 havşası, gövde Ø (HS03 boğazında), çıkış
havşası, boy; HS03 alt yüz, üç delik ve iki kademe, pimler, kulak delikleri; HS05 OD/delik/kalınlık; elastomerler
ID/kesit (bant ±0,10: yalnız üst yarı taranmış); VL01 Ø; VL03 baş.

**K2 - Genel yüzey**: A'nın rijit en iyi oturtmasından (nokta-düzlem ICP, %2 kırpma) sonra tarama örneklerinin
±T içinde kalan payı **≥ %90**; T = max(0,15; 2,5·sd_parça). sd_parça A'nın gürültü tablosundan
(`A_MEASURED` §5): HS02 0,073 -> T = 0,18; diğer bütün parçalar T = 0,15. Ayrıca "yerinde" (oturtmasız) pay ve
oturtma hareketi raporlanır; hareket > 0,3 mm ya da > 1° ise not düşülür. Taramanın göstermediği bölgeler
(masa izleri, tüp içi, HS02 orta iç) yalnız parça raporunda **QA'dan önce** listelenmişse dışarıda tutulur.

**K3 - Montaj**: sert girişim yok. Beklenen temaslar / girişimler: O-ring sıkışmaları (SL01-SL04, nötr torus ile),
VL05'in HS02 havşasına geçmesi, yay uç temasları, FS01 dişinin EM02 deliğinde (Ø3,5 / M4), HS01 flanşı - SL01 - EM03.
Strok taraması: DR01 `z_dr01` - (`stroke_mag` + 0,5) .. `z_dr01` + `stroke_up`, 0,25 adım; DR01 ile sabit parçalar
arası çarpışma yok (yaylar uç konumlarda ayrıca: blok boyu kontrolü).

Tutmayan kapı raporda "tutmadı" diye, ölçüsüyle yazılır.

## 7. Açık konular (Rev A'da)
1. SL01 / SL02 etiketi D'nin kesit ölçüsüne göre (BOM metniyle ters olabilir; yalnız ad).
2. EM01 makara alnında FS01 ucu için boşluk (M4x8 ile 0,8 mm kısa kalır, girişim yok).
3. EM02 büküm iç R: Rev G'den beri dört bükümde 1,9 (CR-B-02). Çıkış duvarı dış yüzünün 0,2-0,45 çöküntüsü modellenmez.
4. HS02 orta iç profili D türetir; A_OLCUM #4 gelirse Rev B.

## 8. Revizyon geçmişi
- Rev H (2026-10-16): A'nın montaj kontrolü. EM01 flanş kenarları EM02'nin iç büküm radyüslerine (R1,9) giriyordu (2,4 + 1,9 mm³, X ±22-23,5, Z -3,0..-3,6). `z_em01_term` = çıkış duvarı iç yüzü - (44,12-43,52)/2 = -3,30 (bobin ortalı; türetildi). B'den: flanş uç kenar yuvarlatması taramadaki gibi (uç yüzde r 22,2-22,9, 1 mm içeride 23,8). Etkilenen yalnız B (EM01).
- Rev G (2026-10-16): CR-B-02 kabul. `em02_ri_out` 1,1 -> 1,9 (tek şerit, tek kalıp: dört bükümde aynı iç R; tasarım niyeti, kapıya ayar değil). Etkilenen yalnız B (EM02).
- Rev F (2026-10-16): CR-D-03 kabul. `sl01_cs` 2,10 -> 2,20; `sl03_id` 13,00 -> 13,15, `sl03_cs` 0,91 -> 1,10. Kapalı zincirde `sl_sq` %15,3 -> %22,7; HS01 flanşı ve ona bağlı kartuş zinciri (HS01, HS05, HS02, SL02, SL03, SL04, VL05, DR01 dinlenme) -0,079 kayar: `z_hs01_flange` 4,710, `z_hs02` 12,420, `z_dr01` -0,550; `stroke_mag` 7,63, `p_max_check` 15,7. Etkilenen: C (HS01 yeniden koşu), D (SL01, SL03 ve yerinde kartuş parçaları yeniden koşu).
- Rev E (2026-10-16): CR-B-01 kabul. `em01_len` 43,45 -> 43,52 (uç yüzlerin çerçeveye dayanan dış halkaları); `z_em01_far` -46,52, giriş duvarına boşluk 0,60. Etkilenen yalnız B (EM01).
- Rev D (2026-10-16): CR-D-02 kabul. `hs02_vl05_z` 31,92 yeni, `z_vl05` buna bağlı (HS02 iç yığını Rev C dinlenme konumuyla: oda dibi 24,0, duvar 0,8, VL04 montaj 3,9). G1/8 diş boyu 4,8 < datasheet min 7: türetmenin bilinen çelişkisi (A_OLCUM #4 ölçülürse çözülür). Etkilenen yalnız D.
- Rev C (2026-10-16): CR-C-02 kabul. `dr02_od` 12,94 -> 12,75, `dr03_od` 12,95 -> 12,84 (tel merkez çapı taramadan + Usta teli). k 1,17 / 2,82; `z_dr01` -0,47, `stroke_mag` 7,71, `stroke_up` 2,58, `p_max_check` 15,9. Taramanın ince metalde yan başına 0,07-0,11 şişmesi notu: d_p için A_OLCUM #1 zaten var. Etkilenen yalnız C (yaylar).
- Rev B (2026-10-16): CR-D-01 ve CR-C-01 kabul. CR-C-01: `dr02_od` 12,94, `dr03_od` 12,95, `dr02_nt` 6,06, `dr03_nt` 8,15, `dr02_na` 4,55, `dr03_na` 6,5. CR-D-01: Usta'nın tel ölçüsü `dr02_d` 1,0 / `dr03_d` 1,3 (Rev A 1,2 / 1,4; tarama 1,23 / 1,43 - sprey ve kesit bulanıklığı); `dr02_k`, `dr03_k` artık formül (`dr02_na`, `dr03_na` yeni); `hs01_inner_bot` 55,3 -> 52,0 (15 bar kontrolü); `z_vl05` yeni (VL05 oda tabanında). Değişen konumlar: `z_dr01` -3,70 -> -0,42, `stroke_mag` 4,48 -> 7,76, `stroke_up` 5,81 -> 2,53. Etkilenen: C (DR02, DR03; HS01 iç dip), D (VL05 yeri). B etkilenmez.
- Rev A (2026-10-16): ilk yayın. B/C/D Aşama 1 ölçümleri + A'nın eksenel yığını.

## 9. Kontrol parçası expression'ları (Rev H, değerlendirilmiş)
