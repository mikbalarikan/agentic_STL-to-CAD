"""Markdown table of ctrl_params.json with evaluated values (for ULKA_INTERFACES.md)."""
import json, math, sys
spec = json.load(open("ctrl_params.json", encoding="utf-8"))
env = {"pi": lambda: math.pi}
rows = []
for x in spec["expressions"]:
    v = x["value"]
    val = eval(v.replace("^", "**"), {"__builtins__": {}}, env) if isinstance(v, str) else v
    env[x["name"]] = val
    f = v if isinstance(v, str) else ""
    rows.append(f"| `{x['name']}` | {val:.3f} | {('`' + f + '`') if f else ''} | {x['comment'].replace('|', '/')} |")
print("| Expression | Değer | Formül | Açıklama / kaynak |\n|---|---|---|---|")
print("\n".join(rows))
