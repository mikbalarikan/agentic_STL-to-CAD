| Expression | Değer | Formül | Açıklama / kaynak |
|---|---|---|---|
| `z_em02_out` | 0.000 |  | pump origin: EM02 outlet-wall outer face (HS03 seat); Z = EM02 big-hole axis, +Z inlet->outlet |
| `em02_t` | 3.000 |  | EM02 sheet thickness [B 2.93/3.02 two-face] |
| `em02_in_axial` | 44.120 |  | EM02 inner faces of the holed walls [B] |
| `z_em02_out_in` | -3.000 | `z_em02_out-em02_t` | EM02 outlet wall inner face |
| `z_em02_in_in` | -47.120 | `z_em02_out_in-em02_in_axial` | EM02 inlet wall inner face |
| `z_em02_in_out` | -50.120 | `z_em02_in_in-em02_t` | EM02 inlet wall outer face (outer axial 50.12, datasheet 50) |
| `em02_out_x` | 53.960 |  | EM02 outer size along X (flat walls) [B; datasheet 54.3 incl. label] |
| `em02_w` | 32.060 |  | EM02 strip width along Y [B] |
| `em02_ri_out` | 1.900 |  | EM02 inner bend radius, outlet-wall corners = inlet corners: one strip, one tool [CR-B-02; Rev A-F 1.1] |
| `em02_ri_in` | 1.900 |  | EM02 inner bend radius, inlet-wall corners [B 1.8-1.9, sd 0.26] |
| `em02_hole_out_d` | 21.240 |  | EM02 outlet-wall hole [B, sd 0.036] |
| `em02_hole_in_d` | 16.740 |  | EM02 inlet-wall hole [B, sd 0.031] |
| `fs_pitch` | 37.900 |  | FS01 / HS03 ear-hole pitch along X [B 37.82, D 37.95, A 37.86] |
| `em02_fs_hole_d` | 3.500 |  | EM02 FS01 hole as scanned; thread M4 cosmetic (minor 3.24-3.42) [B 3.49/3.54] |
| `pin_x` | 14.000 |  | HS03 pin / EM02 pin-hole centre /X/ [B 13.91..14.10, D 13.93] |
| `pin_y` | 5.000 |  | HS03 pin / EM02 pin-hole centre /Y/ [B, D 5.00] |
| `em02_pin_hole_d` | 3.720 |  | EM02 pin holes (4) [B] |
| `em03_od` | 21.000 |  | EM03 OD [B 21.00/20.97] |
| `em03_id` | 16.710 |  | EM03 ID [B 16.71/16.72] |
| `em03_len` | 18.900 |  | EM03 length, both sleeves [B 18.92 full, other >=18.7] |
| `em03_slit_w` | 0.500 |  | EM03 slit width (derived, F04) [B] |
| `hs04_od` | 20.780 |  | HS04 OD [B] |
| `hs04_id` | 17.110 |  | HS04 ID [B] |
| `hs04_h` | 9.100 |  | HS04 height [B] |
| `z_em03a_bot` | -47.120 | `z_em02_in_in` | EM03-A (inlet sleeve) seats on the EM02 inlet wall inner face (hole 16.74 < OD 21.0) |
| `z_hs04_bot` | -28.220 | `z_em03a_bot+em03_len` | HS04 bottom = EM03-A top |
| `z_hs04_top` | -19.120 | `z_hs04_bot+hs04_h` | HS04 top = EM03-B bottom |
| `z_em03b_top` | -0.220 | `z_hs04_top+em03_len` | EM03-B top; passes the 21.24 outlet hole, ends 0.22 below the outer face |
| `em01_body_d` | 47.210 |  | EM01 bobbin body OD [B rms 0.025] |
| `em01_len` | 43.520 |  | EM01 bobbin end faces, outer rings (frame-bearing) [CR-B-01; Rev A-D 43.45] |
| `em01_bore_min_d` | 21.450 |  | EM01 bore, narrowest (middle) [B] |
| `em01_bore_end_d` | 21.900 |  | EM01 bore at the ends (core-pin draft) [B 21.78-21.96] |
| `z_em01_term` | -3.300 | `z_em02_out_in-(em02_in_axial-em01_len)/2` | EM01 terminal-end face, coil centred between the holed walls: the bend radii (1.9) carry the flange edges (DERIVED, A montage check Rev H; terminals at the outlet end from the datasheet side view) |
| `z_em01_far` | -46.820 | `z_em01_term-em01_len` | EM01 plain-end face (0.67 to the inlet wall) |
| `hs01_tube_od` | 16.090 |  | HS01 tube OD [C 16.093 rms 0.039; A 16.07] |
| `hs01_bore_d` | 14.920 |  | HS01 tube / socket bore [C, seen 10 mm from the mouth; along the tube derived] |
| `hs01_flange_d` | 20.230 |  | HS01 flange OD [C] |
| `hs01_flange_t` | 3.230 |  | HS01 flange thickness [C, lower face weak +-0.2] |
| `hs01_lip_od` | 15.820 |  | HS01 socket lip OD [C] |
| `hs01_lip_h` | 5.310 |  | HS01 flange top face -> socket mouth [C] |
| `hs01_neck_d` | 12.920 |  | HS01 neck OD [C] |
| `hs01_len` | 78.000 |  | HS01 socket mouth -> nipple tip [C +-0.2] |
| `hs01_nip_d` | 6.900 |  | HS01 nipple barb crest [C 6.9; datasheet 7.2] |
| `hs01_inner_bot` | 52.000 |  | HS01 flange top face -> tube inner bottom (DR03 seat), DERIVED: inside the outer step z -54..-56.8 (C est. 53); 15-bar check with the Usta wire sizes and CR-C-01 coils (Rev B, was 55.3) |
| `sl01_id` | 16.200 |  | SL01 ID [D 16.20-16.26]; standard mapping by D |
| `sl01_cs` | 2.200 |  | SL01 cross-section [CR-D-03, OD 20.60; Rev A-E 2.1] |
| `sl02_id` | 15.470 |  | SL02 ID, ISO 3601 15.47x2.62 (AS568-115) [D] |
| `sl02_cs` | 2.620 |  | SL02 cross-section [D] |
| `sl03_id` | 13.150 |  | SL03 ID [CR-D-03, A_QA fit; Rev A-E 13.0] |
| `sl03_cs` | 1.100 |  | SL03 cross-section [CR-D-03; Rev A-E 0.91 = flattened height] |
| `sl04_id` | 4.500 |  | SL04 ID, 4.5x2.0 [D] |
| `sl04_cs` | 2.000 |  | SL04 cross-section [D] |
| `hs05_t` | 2.400 |  | HS05 thickness [D 2.35-2.45] |
| `hs05_od` | 15.700 |  | HS05 OD [D] |
| `hs05_hole_d` | 5.650 |  | HS05 hole [D 5.60-5.72] |
| `hs02_len` | 41.220 |  | HS02 length [D; A 41.23] |
| `hs02_flange_d` | 15.770 |  | HS02 flange OD [D] |
| `hs02_flange_t` | 2.880 |  | HS02 flange thickness [D; A 2.81] |
| `hs02_body_d` | 13.400 |  | HS02 body OD at the HS03 throat [D 13.40-13.47; A 13.37] |
| `hs02_sl04_d` | 8.630 |  | HS02 inlet recess (SL04 seat) diameter [D] |
| `hs02_sl04_depth` | 2.150 |  | HS02 inlet recess depth [D; A 2.18] |
| `hs02_out_d` | 8.520 |  | HS02 outlet counterbore (valve room; G1/8 tapping size) [D] |
| `hs02_out_floor` | 29.220 |  | HS02 outlet counterbore floor from the HS02 inlet face [D] |
| `hs02_seat_d` | 4.000 |  | HS02 outlet valve seat edge, DERIVED (VL03 dome R2.76) [D] |
| `hs02_ch_s` | 11.800 |  | HS02 wrench flats across (two flats 180 deg apart; datasheet CH12) [A 11.8, D 2x5.8] |
| `hs02_ch_z0` | 22.180 |  | HS02 flats start from the HS02 inlet face [D] |
| `hs02_ch_z1` | 28.550 |  | HS02 flats end [D] |
| `hs03_plate_t` | 5.820 |  | HS03 plate thickness [D; A 5.80] |
| `hs03_bore1_d` | 20.930 |  | HS03 lower bore (SL02, HS01 flange) [D] |
| `hs03_step1` | 8.160 |  | HS03 lower step from the plate underside [D; A 8.166] |
| `hs03_bore2_d` | 16.500 |  | HS03 middle bore (HS01 lip, HS05, HS02 flange) [D 16.42-16.63; A 16.53] |
| `hs03_step2` | 16.150 |  | HS03 upper step (SL03 face seal) from the underside [D 16.1-16.2; A 16.06] |
| `hs03_bore3_d` | 14.260 |  | HS03 upper throat [D; A 14.29] |
| `hs03_len` | 19.900 |  | HS03 underside -> top face [D; A 19.91] |
| `hs03_ear_hole_d` | 4.550 |  | HS03 ear holes (M4 clearance) [D 4.50/4.57] |
| `hs03_pin_d` | 3.150 |  | HS03 locating pins (4) [D; A 3.12-3.15] |
| `hs03_pin_len` | 3.020 |  | HS03 pin length below the underside [D] |
| `z_hs03` | 0.000 | `z_em02_out` | HS03 underside on the EM02 outlet wall |
| `sl_sq` | 0.227 | `(sl01_cs+sl03_cs-(z_hs03+hs03_step2-z_em03b_top-hs01_flange_t-hs01_lip_h-hs05_t-hs02_flange_t))/(sl01_cs+sl03_cs)` | axial squeeze of SL01 (under the HS01 flange) and SL03 (on the HS02 flange), DERIVED from the closed chain |
| `z_hs01_flange_bot` | 1.480 | `z_em03b_top+sl01_cs*(1-sl_sq)` | HS01 flange lower face (SL01 between it and EM03-B) |
| `z_hs01_flange` | 4.710 | `z_hs01_flange_bot+hs01_flange_t` | HS01 flange top face = C part z0 |
| `z_hs01_mouth` | 10.020 | `z_hs01_flange+hs01_lip_h` | HS01 socket mouth |
| `z_hs01_tip` | -67.980 | `z_hs01_mouth-hs01_len` | HS01 nipple tip |
| `z_hs01_bot` | -47.290 | `z_hs01_flange-hs01_inner_bot` | HS01 tube inner bottom = DR03 seat (derived) |
| `z_hs05` | 10.020 | `z_hs01_mouth` | HS05 lower face on the HS01 socket mouth |
| `z_hs02` | 12.420 | `z_hs05+hs05_t` | HS02 inlet (flange) face = D part z0 |
| `z_hs02_tip` | 53.640 | `z_hs02+hs02_len` | HS02 outlet tip |
| `z_sl03` | 15.300 | `z_hs02+hs02_flange_t` | SL03 lower face (on the HS02 flange) |
| `z_sl02` | 4.710 | `z_hs01_flange` | SL02 lower face (on the HS01 flange, in HS03 bore1; radial seal on the HS01 lip) |
| `total_len` | 121.620 | `z_hs02_tip-z_hs01_tip` | pump length nipple tip -> HS02 tip (datasheet 122) |
| `dr01_arm_d` | 14.340 |  | DR01 armature OD [C 14.341 rms 0.012; A 14.34] |
| `dr01_arm_len` | 20.040 |  | DR01 armature front face -> rear face [C; A 20.03] |
| `dp` | 4.970 |  | DR01 piston OD d_p [C 4.966/4.978, A 4.964]; kept to the scan (5.00 is 0.03-0.04 off) |
| `dr01_tip` | 25.330 |  | DR01 front face -> piston tip [C] |
| `dr01_collar_d` | 8.500 |  | DR01 collar OD [C] |
| `dr01_collar_front` | 7.990 |  | DR01 front face -> collar front face [C] |
| `dr01_fpilot_d` | 10.020 |  | DR01 front pilot (DR02 centring) [C] |
| `dr01_rpilot_d` | 9.500 |  | DR01 rear pilot (DR03 centring) [C +-0.15] |
| `dr01_rear_len` | 0.980 |  | DR01 rear face -> rear pilot end [C 21.02-20.04] |
| `dr01_bore_d` | 6.090 |  | DR01 rear axial bore [C] |
| `dr01_pin_id` | 2.720 |  | DR01 piston bore [C] |
| `dr01_seat_d` | 4.000 |  | DR01 tip countersink mouth (VL01 seat) [C] |
| `dr02_d` | 1.000 |  | DR02 wire: Usta measured 1.0 (CR-D-01) [scan C 1.23] |
| `dr02_od` | 12.750 |  | DR02 OD = coil centre dia 11.75 (scan, wire centres) + Usta wire 1.0 [CR-C-02; Rev B 12.94, Rev A 12.65] |
| `dr02_l0` | 18.930 |  | DR02 free length [C] |
| `dr02_nt` | 6.060 |  | DR02 total coils [CR-C-01 helix fit; Rev A 5.4] |
| `dr02_na` | 4.550 |  | DR02 active coils [CR-C-01] |
| `dr02_k` | 1.169 | `69000*dr02_d^4/(8*(dr02_od-dr02_d)^3*dr02_na)` | DR02 rate N/mm, DERIVED G 69 GPa stainless (+-15%) |
| `dr03_d` | 1.300 |  | DR03 wire: Usta measured 1.3 (CR-D-01) [scan C 1.43] |
| `dr03_od` | 12.840 |  | DR03 OD = coil centre dia 11.54 + Usta wire 1.3 [CR-C-02; Rev B 12.95, Rev A 12.63] |
| `dr03_l0` | 30.160 |  | DR03 free length [C] |
| `dr03_nt` | 8.150 |  | DR03 total coils [CR-C-01; Rev A 7.6] |
| `dr03_na` | 6.500 |  | DR03 active coils [CR-C-01] |
| `dr03_k` | 2.823 | `79000*dr03_d^4/(8*(dr03_od-dr03_d)^3*dr03_na)` | DR03 rate N/mm, DERIVED G 79 GPa steel (+-15%) |
| `dr_defl` | 11.820 | `dr02_l0+dr03_l0-(z_hs05-z_hs01_bot-dr01_arm_len)` | total spring deflection at rest (both springs preloaded) |
| `dr03_l_inst` | 26.700 | `dr03_l0-dr_defl*dr02_k/(dr02_k+dr03_k)` | DR03 installed length at rest (force balance) |
| `dr02_l_inst` | 10.570 | `dr02_l0-dr_defl*dr03_k/(dr02_k+dr03_k)` | DR02 installed length at rest |
| `z_dr01_rear` | -20.590 | `z_hs01_bot+dr03_l_inst` | DR01 rear face at rest (power off) |
| `z_dr01` | -0.550 | `z_dr01_rear+dr01_arm_len` | DR01 front face at rest = C part z0 |
| `z_dr01_tip` | 24.780 | `z_dr01+dr01_tip` | piston tip at rest |
| `stroke_mag` | 7.630 | `z_dr01_rear-z_hs04_bot` | magnetic stroke to the EM03-A pole (armature pulled toward the inlet), DERIVED |
| `stroke_up` | 2.580 | `z_hs05-(z_dr01+dr01_collar_front)` | upward hard stop: collar front face -> HS05 lower face |
| `p_max_check` | 15.700 | `(dr02_k+dr03_k)*stroke_mag/(pi()*dp*dp/4)*10` | spring-delivered pressure at full magnetic stroke, bar (datasheet Q=0 at 15 bar) |
| `vl01_d` | 3.572 |  | VL01 ball 9/64 in [D 3.606 sd 0.031] |
| `vl02_l0` | 15.000 |  | VL02 free length [D] |
| `vl02_d` | 0.500 |  | VL02 wire [D, weak] |
| `vl03_head_d` | 5.000 |  | VL03 head max diameter [D] |
| `vl03_head_r` | 2.760 |  | VL03 dome radius [D] |
| `vl04_l0` | 6.800 |  | VL04 free length [D] |
| `vl04_d` | 0.450 |  | VL04 wire [D, weak] |
| `vl05_od` | 8.400 |  | VL05 ring OD [D 8.0-8.4] |
| `vl05_t` | 4.500 |  | VL05 thickness [D 4.3-4.7] |
| `hs02_vl05_z` | 31.920 |  | VL05 lower face from the HS02 inlet face, DERIVED by D from the Rev C kinematics (VL02 solid + VL04 lift chain), press-fit tabs [CR-D-02] |
| `z_vl05` | 44.340 | `z_hs02+hs02_vl05_z` | VL05 lower face (Rev D; Rev B/C on the counterbore floor 29.22) |
| `fs01_d` | 4.000 |  | FS01 ISO 7045 M4 pan head cross recess |
| `fs01_len` | 8.000 |  | FS01 length M4x8 (M4x10 would enter the EM01 flange zone by 1.2), DERIVED |
| `fs01_dk` | 8.000 |  | ISO 7045 M4 head diameter |
| `fs01_k` | 3.100 |  | ISO 7045 M4 head height |
| `z_fs01_head` | 5.820 | `z_hs03+hs03_plate_t` | FS01 head bearing face = HS03 ear top |
| `c_arm_tube` | 0.290 | `(hs01_bore_d-dr01_arm_d)/2` | radial: armature / HS01 bore |
| `c_tube_em03` | 0.310 | `(em03_id-hs01_tube_od)/2` | radial: HS01 tube / EM03 bore |
| `c_tube_hs04` | 0.510 | `(hs04_id-hs01_tube_od)/2` | radial: HS01 tube / HS04 |
| `c_tube_em02` | 0.325 | `(em02_hole_in_d-hs01_tube_od)/2` | radial: HS01 tube / EM02 inlet hole |
| `c_em03_em02` | 0.120 | `(em02_hole_out_d-em03_od)/2` | radial: EM03-B / EM02 outlet hole |
| `c_em03_em01` | 0.225 | `(em01_bore_min_d-em03_od)/2` | radial: EM03 / EM01 bore (narrowest) |
| `c_hs04_em01` | 0.335 | `(em01_bore_min_d-hs04_od)/2` | radial: HS04 / EM01 bore |
| `c_flange_hs03` | 0.350 | `(hs03_bore1_d-hs01_flange_d)/2` | radial: HS01 flange / HS03 bore1 |
| `c_lip_hs03` | 0.340 | `(hs03_bore2_d-hs01_lip_od)/2` | radial: HS01 lip / HS03 bore2 |
| `c_hs05_hs03` | 0.400 | `(hs03_bore2_d-hs05_od)/2` | radial: HS05 / HS03 bore2 |
| `c_hs02fl_hs03` | 0.365 | `(hs03_bore2_d-hs02_flange_d)/2` | radial: HS02 flange / HS03 bore2 |
| `c_hs02_hs03` | 0.430 | `(hs03_bore3_d-hs02_body_d)/2` | radial: HS02 body / HS03 throat |
| `c_pin` | 0.285 | `(em02_pin_hole_d-hs03_pin_d)/2` | radial: HS03 pin / EM02 pin hole |
| `c_piston_hs05` | 0.340 | `(hs05_hole_d-dp)/2` | radial: piston / HS05 hole |
| `c_collar_hs01` | 3.210 | `(hs01_bore_d-dr01_collar_d)/2` | radial: collar / HS01 bore |
| `sq_sl04` | 0.085 | `1-(hs02_sl04_d-dp)/2/sl04_cs` | SL04 radial squeeze on the piston |
| `sq_sl02` | 0.025 | `1-(hs03_bore1_d-hs01_lip_od)/2/sl02_cs` | SL02 radial squeeze HS01 lip / HS03 bore1 |
