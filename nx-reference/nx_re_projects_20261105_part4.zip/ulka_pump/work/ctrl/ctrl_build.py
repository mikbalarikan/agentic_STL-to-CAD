"""Build the ULKA EP5 control part from ctrl_params.json.

  run_journal ctrl_build.py -args <ctrl folder> [<out name without .prt>]

ctrl_params.json: {"rev": "...", "expressions": [{"name", "value", "unit", "comment"}...],
                   "planes": [{"name", "z"}...], "axes": [{"name", "origin": [x, y, z], "dir": [dx, dy, dz]}...]}
Plane z and axis coordinates are formulas over the expressions. Writes ctrl_build.json ("result": PASS | FAIL).
"""
import json
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR", r"C:\Users\marya\.claude\skills\nx-journal-core\scripts"))
import nxh  # noqa: E402
import nxf  # noqa: E402
import NXOpen  # noqa: E402

OUT = sys.argv[1]
NAME = sys.argv[2] if len(sys.argv) > 2 else "EP5-AS00_CTRL"
res = {"result": "FAIL", "name": NAME}
try:
    spec = json.load(open(os.path.join(OUT, "ctrl_params.json"), encoding="utf-8"))
    part = nxh.new_part(os.path.join(OUT, NAME + ".prt"))
    for e in spec["expressions"]:
        nxh.expr(part, e["name"], e["value"], (e.get("unit", "mm") or None), e.get("comment", ""))
    d = nxh.Datums(part)
    planes = {}
    for p in spec.get("planes", []):
        f, pl = nxf.datum_plane(part, "offset", [d.xy], p["z"], name=p["name"])
        planes[p["name"]] = [round(v, 6) for v in (pl.Origin.X, pl.Origin.Y, pl.Origin.Z)]
    axes = {}
    for a in spec.get("axes", []):
        f, ax = nxf.datum_axis(part, "point_dir", tuple(a["origin"]), tuple(float(v) for v in a["dir"]), name=a["name"])
        axes[a["name"]] = [round(v, 6) for v in (ax.Origin.X, ax.Origin.Y, ax.Origin.Z, ax.Direction.X, ax.Direction.Y, ax.Direction.Z)]
    nxh.update()
    errs = nxh.feature_errors(part)
    part.SetUserAttribute("ULKA_CTRL_REV", -1, spec["rev"], NXOpen.Update.Option.Now)
    vals = {e.Name: e.Value for e in nxh.user_expressions(part)}
    res.update(rev=spec["rev"], expressions=vals, planes=planes, axes=axes, feature_errors=[str(x) for x in errs])
    nxh.save(part)
    res["result"] = "PASS" if not errs and len(vals) >= len(spec["expressions"]) else "FAIL"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "ctrl_build.json"), res)
