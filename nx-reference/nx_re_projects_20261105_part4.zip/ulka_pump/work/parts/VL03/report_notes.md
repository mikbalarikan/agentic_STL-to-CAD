## Çerçeve
Kendi çerçevesinde: z0 = kubbe tepesi (giriş tarafı, HS02 Ø4,0 oturma kenarına), +Z sapa doğru. Kubbe R 2,76
(`vl03_head_r`), baş Ø5,0 (`vl03_head_d`) z 1,59-2,4, alt koni boyun Ø3,3'e (z 4,3), boyun z 6,0'a kadar.
**Türetilen**: sap Ø2,0 ve toplam boy 12,7 (taramada yay içinde görünmüyor; tarayıcı masasında sapı üzerinde
durduğu için tepe 12,97'de). Siyah elastomer baş + gövde tek gövde olarak modellendi.
Ön kontrol (yalnız baş+boyun taraması): kendi oturmasından sonra %95,6 ±0,15 (tarama baş merkezi 0,4 yanda).
