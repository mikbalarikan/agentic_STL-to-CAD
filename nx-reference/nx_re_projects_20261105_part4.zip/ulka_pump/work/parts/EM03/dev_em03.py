"""EM03: both sleeve scans against the NX model (EM03-A position). Scan frames: z=0 bottom face, slit turned to +X."""
import os, sys, json
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\_B_common")
import numpy as np
import rb, dev

O = r"C:\NX_MCP_WORKSPACE\ulka\parts\EM03\out"
zb = json.load(open(os.path.join(O, "build.json"), encoding="utf-8"))["linked"]["z_em03a_bot"]
r = lambda P: np.hypot(P[:, 0], P[:, 1])
z = lambda P: P[:, 2] - zb
rad = lambda P, N: (P[:, 0] * N[:, 0] + P[:, 1] * N[:, 1]) / np.maximum(r(P), 1e-9)
zones = {
    "outer wall (OD)": lambda P, N: (z(P) > 0.6) & (z(P) < 18.3) & (rad(P, N) > 0.8),
    "inner wall (ID)": lambda P, N: (z(P) > 0.6) & (z(P) < 18.3) & (rad(P, N) < -0.8),
    "end faces": lambda P, N: ((z(P) < 0.4) | (z(P) > 18.5)) & (np.abs(N[:, 2]) > 0.8),
}
excl = lambda P, N: (r(P) < 7.9) | (r(P) > 11.0) | (z(P) < -0.3) | (z(P) > 19.2)
refit = {"walls": lambda P, N: (z(P) > 0.6) & (z(P) < 18.3) & (np.abs(N[:, 2]) < 0.3)}
for nm, ang in (("sleeve1", -69.0), ("sleeve2", 93.0)):
    T = rb.rotz(-ang); T[2, 3] = zb
    dev.run("EM03", [os.path.join(O, "EP5-EM03_FLUX-SLEEVE_body.stl")], os.path.join(rb.SCAN, "EP5-EM03_%s_aligned.stl" % nm), zones, T=T,
            exclude=excl, refit=refit, tag="dev_" + nm)
