## Çerçeve ve tasarım niyeti

Pompa çerçevesinde yerinde, EM03-A (giriş) konumunda (Rev A §2): alt yüz `z_em03a_bot` = -47,12 (EM02 giriş
duvarı iç yüzü), üst yüz -28,22; yarık +X. EM03-B aynı dosyanın ikinci kopyasıdır: A +(em03_len + hs04_h) = 28,0
öteler (alt -19,12, üst -0,22). OD / ID / boy / yarık kontrol parçasından. Parça içi tek ölçü `em03_edge_r` 0,3:
dört uç kenarda rulo sac kenar kırması (taramada yuvarlak).

## Taramanın göstermediği / dışarıda tutulan bölgeler (QA'dan önce)

- Burç 1'in bir uç yüzü taranmamış (uçta 18,7-18,8'e kadar nokta var); boy burç 2'den (18,92) -> 18,9.
- Yarık taramada kısmen köprülenmiş (dış deri yarığın üstünü kapatıyor); genişlik 0,5 türetildi (F04).
- Dışarıda: r < 7,9 ve r > 11,0 ile uçların 0,3 ötesi (tarama uç kırıntıları / masa). Tarama yarığı +X'e döndürüldü
  (burç 1: +69°, burç 2: -93°).

## Kabul (B'nin kendi ölçümü; bağımsız QA A'da)

- K1: OD 21,00 / ID 16,71 / boy 18,9 = Rev A (CAD tam). Tarama: OD 21,002 / 20,972, ID 16,714 / 16,716, boy 18,92
  (burç 2).
- K2 (T = 0,15): burç 2 (aşağıdaki tablo) %95,2; burç 1 (`qa\dev_sleeve1.json`) %95,1 - ikisi de tuttu.
