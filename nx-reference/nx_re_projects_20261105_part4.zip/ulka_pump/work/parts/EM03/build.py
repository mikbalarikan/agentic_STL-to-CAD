"""EP5-EM03 slotted flux sleeve - native parametric build (NX 2206, headless).

    run_journal build.py -args <out dir>

Modelled in place in the pump frame at the EM03-A (inlet) position (ULKA_INTERFACES Rev A §2): bottom face on
z_em03a_bot (the EM02 inlet wall inner face), length em03_len; A places the second copy (EM03-B) by
+(em03_len + hs04_h). OD / ID / length / slit width come from the control part; the slit is on +X.
The four end edges are rolled-sheet edge breaks (scan: rounded, about 0.3), modelled as R0.3 blends.
Features: PL_EM03_BOT + AX_BOT_X -> SK_PROFILE -> Revolve -> 4 edge blends -> SK_SLIT -> Extrude (subtract).
"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\_B_common\nxlib")
import NXOpen
import nxh, nxf, nxa
import rj
from rj import BOOL, X, Y, Z

OUT = sys.argv[1]
NAME = "EP5-EM03_FLUX-SLEEVE"
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, NAME)
    p, M = c.part, c.M
    for n in ("z_em03a_bot", "em03_od", "em03_id", "em03_len", "em03_slit_w", "hs01_tube_od", "em01_bore_min_d", "em02_hole_out_d"):
        c.link(n)
    c.e("em03_edge_r", 0.3, "rolled-sheet edge break on the four end edges [scan r-z: rounded ~0.3]")
    c.e("slit_over", 0.5, "slit sketch overlap past ID / OD (construction)")
    c.d("c_em03_tube", "(em03_id-hs01_tube_od)/2", "radial clearance sleeve / HS01 tube")
    c.d("c_em03_bore", "(em01_bore_min_d-em03_od)/2", "radial clearance sleeve / EM01 bore (narrowest)")
    c.d("c_em03_hole", "(em02_hole_out_d-em03_od)/2", "radial clearance EM03-B / EM02 outlet hole")
    zb = M["z_em03a_bot"]
    fp, pl = nxf.datum_plane(p, "offset", [c.dat.xy], "z_em03a_bot", "PL_EM03_BOT")
    fa, ax = nxf.datum_axis(p, "intersection", pl, c.dat.xz, name="AX_BOT_X")

    ri, ro, L = M["em03_id"] / 2, M["em03_od"] / 2, M["em03_len"]
    pv = [(ri, 0.0, "em03_id/2", None), (ro, 0.0, "em03_od/2", None), (ro, L, None, "em03_len"), (ri, L)]
    S = c.sketch("xz", "SK_PROFILE", hax=ax, shift=(0.0, 0.0, zb))
    S.profile(pv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, ((ri + ro) / 2, L / 2)), nxf.axis_from(p, c.dat.z))
    f.SetName("SLEEVE")
    body = f.GetBodies()[0]
    v0 = math.pi * (ro * ro - ri * ri) * L
    c.chk("tube volume", c.vol(body), v0, 1e-6 * v0)

    # ---- edge breaks: the four circular end edges
    def ring_edges(z):
        out = []
        for ed in body.GetEdges():
            b = nxh.bbox(ed)
            if abs(b[2] - z) < 1e-4 and abs(b[5] - z) < 1e-4:
                out.append(ed)
        return out
    eds = ring_edges(zb) + ring_edges(zb + L)
    c.chk("four end edges", len(eds), 4, 0)
    f = nxh.blend(p, eds, "em03_edge_r"); f.SetName("EDGE_BREAKS")
    v1 = c.vol(body)
    rr = M["em03_edge_r"]
    corner = (1 - math.pi / 4) * rr * rr                     # area removed per corner of the r-z section
    xc = rr * (10 - 3 * math.pi) / (3 * (4 - math.pi))      # distance of the removed region's centroid from the corner
    dv = 2 * corner * 2 * math.pi * (ro - xc) + 2 * corner * 2 * math.pi * (ri + xc)
    c.chk("edge breaks volume (Pappus)", v0 - v1, dv, 1e-4)

    # ---- slit on +X, through the wall, full length
    hw = M["em03_slit_w"] / 2
    sv = [(ri - M["slit_over"], -hw, "em03_id/2-slit_over", "em03_slit_w/2"), (ro + M["slit_over"], -hw, "em03_od/2+slit_over", None),
          (ro + M["slit_over"], hw, None, "em03_slit_w/2"), (ri - M["slit_over"], hw)]
    S2 = c.sketch("xy", "SK_SLIT", on=pl, shift=(0.0, 0.0, zb))
    S2.profile(sv)
    c.done(S2)
    f = nxh.extrude(p, S2.section(None, (ro, 0.0)), Z, "-1", "em03_len+1", op=BOOL.Subtract, target=body)
    f.SetName("SLIT")
    v2 = c.vol(body)
    # removed = annulus strip |y| < hw, x > 0, over the length, less the blended corners inside the strip (small)
    def strip_area(r):
        return hw * math.sqrt(r * r - hw * hw) + r * r * math.asin(hw / r)
    a_strip = strip_area(ro) - strip_area(ri)
    c.chk("slit volume = strip of the annulus (blend corners within 1 %)", v1 - v2, a_strip * L, 0.01 * a_strip * L)
    c.chk("one solid", len(nxh.solids(p)), 1, 0)

    # ---- interface read-back
    cf = rj.cyl_faces(body)
    c.chk("OD", 2 * max(abs(q[3]) for q in cf), M["em03_od"], 1e-9)
    c.chk("ID", 2 * min(abs(q[3]) for q in cf if abs(abs(q[3]) - rr) > 1e-6), M["em03_id"], 1e-9)
    c.chk("bottom face (probe)", abs(nxh.dist_to(p, body, (-(ri + ro) / 2, 0.0, zb))), 0.0, 1e-6)
    c.chk("top face (probe)", abs(nxh.dist_to(p, body, (-(ri + ro) / 2, 0.0, zb + L))), 0.0, 1e-6)
    sl = [q for q in rj.plane_faces(body) if abs(abs(q[2][1]) - 1) < 1e-9]
    c.chk("two slit faces, normal +-Y", len(sl), 2, 0)
    c.chk("slit width", abs(sl[0][1][1] - sl[1][1][1]) if len(sl) == 2 else -1, M["em03_slit_w"], 1e-9)
    c.chk.true("radial clearances positive", M["c_em03_tube"] > 0 and M["c_em03_bore"] > 0 and M["c_em03_hole"] > 0,
               (M["c_em03_tube"], M["c_em03_bore"], M["c_em03_hole"]))
    c.notes["z_planes"] = {"EM03-A bottom": zb, "EM03-A top": zb + L}
    c.notes["clearances"] = {"sleeve/HS01 tube": M["c_em03_tube"], "sleeve/EM01 bore": M["c_em03_bore"], "EM03-B/EM02 outlet hole": M["c_em03_hole"]}

    # ---- regeneration: edge break 0.3 -> 0.5 -> 0.3
    v_nom = c.vol(body)
    nxh.set_expr(p, "em03_edge_r", 0.5); nxh.update()
    v_big = c.vol(body)
    errs = [str(x) for x in nxh.feature_errors(p)]
    nxh.set_expr(p, "em03_edge_r", 0.3); nxh.update()
    c.chk.true("regeneration em03_edge_r 0.3 -> 0.5 removes material", v_big < v_nom, (v_nom, v_big))
    c.chk.true("regeneration: no feature errors", not errs, errs)
    c.chk("regeneration back to nominal", c.vol(body), v_nom, 1e-6 * v_nom)
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
