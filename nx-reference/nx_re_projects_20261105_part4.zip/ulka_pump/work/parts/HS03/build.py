"""EP5-HS03 outlet flange - native parametric build (NX 2206, headless).   run_journal build.py -args <out>

In place in the pump frame (ULKA_INTERFACES Rev A): Z = pump axis, +Z inlet -> outlet; the plate underside (pins, on
the EM02 outlet wall) on PL_HS03 at z_hs03; ears on +-X, pins at (+-pin_x, +-pin_y). Interface values are interpart
expressions from EP5-AS00_CTRL.prt; part-internal values are named expressions (sessions/D_MEASURED.md section 2).
Features: PL_HS03 -> SK_PLATE (two ear arcs + two side arcs, tangent lines) -> Extrude (plate) -> SK_BOSS -> Revolve
(unite) -> SK_BORE -> Revolve (subtract: three bores and two steps) -> SK_EARS -> Extrude (subtract, ear holes) ->
SK_PINS -> Extrude (unite, 4 pins down) -> SK_POCKETS -> Extrude (subtract, two underside pockets).
"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\D_common\nxlib")
import NXOpen
import nxh, nxf, nxa
import rj, ps
from rj import BOOL, X, Y, Z

OUT = sys.argv[1]
NAME = "EP5-HS03_OUTLET-FLANGE"
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, NAME)
    p, M = c.part, c.M
    for n in ("z_hs03", "hs03_plate_t", "hs03_bore1_d", "hs03_step1", "hs03_bore2_d", "hs03_step2", "hs03_bore3_d",
              "hs03_len", "hs03_ear_hole_d", "hs03_pin_d", "hs03_pin_len", "fs_pitch", "pin_x", "pin_y"):
        c.link(n)
    c.d("ear_cx", "fs_pitch/2", "ear end arc concentric with the ear hole [scan: tip r 23.18-23.30 = 18.95 + 4.25]")
    c.e("ear_r", 4.25, "ear end arc radius [scan: edge lines 12.13 from the axis, normal 65.45 deg, tangent to it]")
    c.e("side_r", 12.13, "plate side arc about the axis = distance of the straight edges [scan 12.08-12.18, four edges]")
    c.e("boss_d", 23.94, "boss lower outer diameter [scan 23.94 sd 0.075]")
    c.e("boss_z1", 11.1, "end of the lower boss cylinder from the underside [scan r 11.89 at 11.0, 11.66 at 11.5]")
    c.e("top_d", 20.45, "boss upper outer diameter [scan 20.45 sd 0.046]")
    c.e("cone_z1", 13.4, "end of the boss cone (start of the upper cylinder) [scan r 10.29 at 13.5]")
    c.e("st1_ch", 0.5, "chamfer at the lower step (bore1 -> bore2) [scan r 10.09 at 8.0, 8.55 at 8.5]")
    c.e("pk_x", 13.45, "underside pocket centre /X/ [scan 12.3 .. 14.6]")
    c.e("pk_w", 2.3, "underside pocket size along X [scan]")
    c.e("pk_l", 5.0, "underside pocket size along Y [scan -2.4 .. 2.7]")
    c.e("pk_d", 2.1, "underside pocket depth [scan floor z 2.13]")
    c.e("tp_floor", 3.6, "top pocket floor above the underside [scan 3.56-3.64]")
    c.e("tp_rim", 1.6, "top pocket rim along the plate edges [scan wall 10.55 from the axis vs edge 12.13]")
    c.e("tp_ri", 12.2, "top pocket inner wall radius about the axis [scan 12.21-12.25]")
    c.e("tp_rh", 4.4, "top pocket outer wall radius about the ear hole [scan 4.39-4.43]")
    c.e("top_ch", 0.4, "boss top outer edge chamfer [scan rounded]")
    c.e("win_c", 1.1, "side window centre offset along X (+y window at +win_c, -y window at -win_c) [scan +0.98 / -1.33]")
    c.e("win_w", 5.3, "side window width along X [scan 5.65 / 4.95]")
    c.e("win_z0", 0.8, "side window lower edge above the underside [scan 0.8-0.9]")
    c.e("win_z1", 4.5, "side window upper edge [scan 4.4-4.5]")
    c.e("win_zs", 2.3, "side window: the wide part starts here; below it only the slot [scan 2.3]")
    c.e("win_ls", 1.9, "side window lower slot width (at the -X end of the +y window, point symmetric) [scan]")
    z0 = M["z_hs03"]
    m = M
    fp, pl = nxf.datum_plane(p, "offset", [c.dat.xy], "z_hs03", "PL_HS03")
    fa, ax = nxf.datum_axis(p, "intersection", pl, c.dat.xz, name="AX_HS03_X")

    # ---- plate outline
    R1, R2, ec = m["side_r"], m["ear_r"], m["ear_cx"]
    sa = (R1 - R2) / ec
    ca = math.sqrt(1 - sa * sa)
    F = ps.FREE
    vt = [(ec + R2 * sa, -R2 * ca, F, F), (ec + R2 * sa, R2 * ca, F, F), (R1 * sa, R1 * ca, F, F), (-R1 * sa, R1 * ca, F, F),
          (-ec - R2 * sa, R2 * ca, F, F), (-ec - R2 * sa, -R2 * ca, F, F), (-R1 * sa, -R1 * ca, F, F), (R1 * sa, -R1 * ca, F, F)]
    Sp = c.sketch("xy", "SK_PLATE", on=pl, shift=(0.0, 0.0, z0))
    segs = Sp.profile(vt, arcs={0: (ec, 0.0, "ear_r"), 2: (0.0, 0.0, "side_r"), 4: (-ec, 0.0, "ear_r"), 6: (0.0, 0.0, "side_r")})
    Sp.centre_on(segs[0], "h"); Sp.centre_dim(segs[0], "u", "ear_cx")
    Sp.centre_on(segs[4], "h"); Sp.centre_dim(segs[4], "u", "ear_cx")
    Sp.centre_on(segs[2], "h"); Sp.centre_on(segs[2], "v")
    Sp.centre_on(segs[6], "h"); Sp.centre_on(segs[6], "v")
    for li, (a, b) in {1: (0, 2), 3: (2, 4), 5: (4, 6), 7: (6, 0)}.items():
        Sp.tangent(segs[li], segs[a], at=vt[li][:2])
        Sp.tangent(segs[li], segs[b], at=vt[(li + 1) % 8][:2])
    c.done(Sp)
    fpl = nxh.extrude(p, Sp.section(None, (15.0, 0.0)), Z, 0, "hs03_plate_t", origin=(0.0, 0.0, z0))
    fpl.SetName("PLATE")
    body = fpl.GetBodies()[0]
    al = math.asin(sa)
    poly = [(q[0], q[1]) for q in vt]
    ap = 0.5 * abs(sum(poly[i][0] * poly[(i + 1) % 8][1] - poly[(i + 1) % 8][0] * poly[i][1] for i in range(8)))
    th_e, th_s = math.pi - 2 * al, 2 * al          # ear arc sweep, side arc sweep
    seg_e = 0.5 * R2 * R2 * (th_e - math.sin(th_e))
    seg_s = 0.5 * R1 * R1 * (th_s - math.sin(th_s))
    area = ap + 2 * seg_e + 2 * seg_s
    c.notes["plate_area_mm2"] = area
    c.chk("plate volume = outline area x plate_t", c.vol(body), area * m["hs03_plate_t"], 1e-5 * area * m["hs03_plate_t"])

    # ---- boss (revolve, unite)
    L = m["hs03_len"]
    tch = m["top_ch"]
    pb = [(0.0, 0.0), (m["boss_d"] / 2, 0.0, "boss_d/2", None), (m["boss_d"] / 2, m["boss_z1"], None, "boss_z1"),
          (m["top_d"] / 2, m["cone_z1"], "top_d/2", "cone_z1"), (m["top_d"] / 2, L - tch, None, "hs03_len-top_ch"),
          (m["top_d"] / 2 - tch, L, "top_d/2-top_ch", "hs03_len"), (0.0, L)]
    Sb = c.sketch("xz", "SK_BOSS", hax=ax, shift=(0.0, 0.0, z0))
    Sb.profile(pb)
    c.done(Sb)
    v0 = c.vol(body)
    fb = nxf.revolve(p, Sb.section(None, (5.0, 5.0)), nxf.axis_from(p, c.dat.z), op=BOOL.Unite, target=body)
    fb.SetName("BOSS")
    body = nxh.solids(p)[0]
    vb = rj.revolve_volume([(q[0], q[1]) for q in pb])
    vb_in_plate = math.pi * (m["boss_d"] / 2) ** 2 * m["hs03_plate_t"]
    c.chk("boss added = revolve - part inside the plate", c.vol(body) - v0, vb - vb_in_plate, 1e-5 * vb)

    # ---- bores (revolve, subtract) - runs 1 mm past both ends
    r1, r2, r3 = m["hs03_bore1_d"] / 2, m["hs03_bore2_d"] / 2, m["hs03_bore3_d"] / 2
    s1, s2, ch = m["hs03_step1"], m["hs03_step2"], m["st1_ch"]
    pr = [(0.0, -1.0, None, "1"), (r1, -1.0, "hs03_bore1_d/2", None), (r1, s1 - ch, None, "hs03_step1-st1_ch"),
          (r1 - ch, s1, "hs03_bore1_d/2-st1_ch", "hs03_step1"), (r2, s1, "hs03_bore2_d/2", None), (r2, s2, None, "hs03_step2"),
          (r3, s2, "hs03_bore3_d/2", None), (r3, L + 1.0, None, "hs03_len+1"), (0.0, L + 1.0)]
    Sr = c.sketch("xz", "SK_BORE", hax=ax, shift=(0.0, 0.0, z0))
    Sr.profile(pr)
    c.done(Sr)
    v0 = c.vol(body)
    fr = nxf.revolve(p, Sr.section(None, (3.0, 5.0)), nxf.axis_from(p, c.dat.z), op=BOOL.Subtract, target=body)
    fr.SetName("BORES")
    body = nxh.solids(p)[0]
    vr = rj.revolve_volume([(q[0], max(0.0, min(L, q[1]))) for q in pr])
    c.chk("bores removed = revolved bore profile inside 0..len", v0 - c.vol(body), vr, 1e-5 * vr)

    # ---- ear holes (through the plate)
    Se = c.sketch("xy", "SK_EARS", on=pl, shift=(0.0, 0.0, z0))
    hx = m["fs_pitch"] / 2
    Se.circle(hx, 0.0, m["hs03_ear_hole_d"], cuf="fs_pitch/2", df="hs03_ear_hole_d")
    Se.circle(-hx, 0.0, m["hs03_ear_hole_d"], cuf="fs_pitch/2", df="hs03_ear_hole_d")
    c.done(Se)
    v0 = c.vol(body)
    fe = nxh.extrude(p, Se.section(None, (hx, 0.0)), Z, -1, "hs03_plate_t+1", op=BOOL.Subtract, target=body, origin=(0.0, 0.0, z0))
    fe.SetName("EAR_HOLES")
    body = nxh.solids(p)[0]
    c.chk("ear holes removed 2 x pi/4 d^2 t", v0 - c.vol(body), 2 * math.pi / 4 * m["hs03_ear_hole_d"] ** 2 * m["hs03_plate_t"], 1e-5 * v0)

    # ---- pins (down from the underside)
    Sn = c.sketch("xy", "SK_PINS", on=pl, shift=(0.0, 0.0, z0))
    for sx in (1, -1):
        for sy in (1, -1):
            Sn.circle(sx * m["pin_x"], sy * m["pin_y"], m["hs03_pin_d"], cuf="pin_x", cvf="pin_y", df="hs03_pin_d")
    c.done(Sn)
    v0 = c.vol(body)
    fn = nxh.extrude(p, Sn.section(None, (m["pin_x"], m["pin_y"])), (0, 0, -1), 0, "hs03_pin_len", op=BOOL.Unite, target=body, origin=(0.0, 0.0, z0))
    fn.SetName("PINS")
    body = nxh.solids(p)[0]
    c.chk("pins added 4 x pi/4 d^2 len", c.vol(body) - v0, 4 * math.pi / 4 * m["hs03_pin_d"] ** 2 * m["hs03_pin_len"], 1e-5 * v0)

    # ---- underside pockets
    Sk = c.sketch("xy", "SK_POCKETS", on=pl, shift=(0.0, 0.0, z0))
    for sx in (1, -1):
        x0, x1 = sx * (m["pk_x"] - m["pk_w"] / 2), sx * (m["pk_x"] + m["pk_w"] / 2)
        y0 = m["pk_l"] / 2
        Sk.profile([(x0, -y0, "pk_x-pk_w/2", "pk_l/2"), (x1, -y0, "pk_x+pk_w/2", None), (x1, y0, None, "pk_l/2"), (x0, y0, None, None)])
    c.done(Sk)
    v0 = c.vol(body)
    fk = nxh.extrude(p, Sk.section(None, (m["pk_x"], 0.0)), Z, 0, "pk_d", op=BOOL.Subtract, target=body, origin=(0.0, 0.0, z0))
    fk.SetName("POCKETS")
    body = nxh.solids(p)[0]
    c.chk("pockets removed 2 x w x l x d", v0 - c.vol(body), 2 * m["pk_w"] * m["pk_l"] * m["pk_d"], 1e-5 * v0)
    # ---- top pockets: plate outline offset inward by tp_rim, from tp_floor up, minus the ring about the boss and
    #      the rings about the ear holes (what is left are the two coring pockets between boss and ears)
    fpt, plt_ = nxf.datum_plane(p, "offset", [c.dat.xy], "z_hs03+tp_floor", "PL_TOP_POCKET")
    v0 = c.vol(body)
    ft = nxf.extrude_ex(p, Sp.section(None, (15.0, 0.0)), Z, "tp_floor", "hs03_plate_t+1", single_offset="-tp_rim", origin=(0.0, 0.0, z0))
    tool = [b_ for b_ in nxh.solids(p) if b_.Tag != body.Tag]
    if len(tool) != 1 or nxh.volume(p, tool[0]) > area * 3:
        # offset went outward: flip the sign
        nxh.undo_to(None) if False else None
        raise RuntimeError("top pocket tool: unexpected offset result %s" % [nxh.volume(p, t_) for t_ in tool])
    tool = tool[0]
    Sq = c.sketch("xy", "SK_TOP_POCKET_KEEP", on=plt_, shift=(0.0, 0.0, z0 + m["tp_floor"]))
    Sq.circle(0.0, 0.0, 2 * m["tp_ri"], df="2*tp_ri")
    Sq.circle(hx, 0.0, 2 * m["tp_rh"], cuf="fs_pitch/2", df="2*tp_rh")
    Sq.circle(-hx, 0.0, 2 * m["tp_rh"], cuf="fs_pitch/2", df="2*tp_rh")
    c.done(Sq)
    fq = nxh.extrude(p, Sq.section(None, (0.0, 0.0)), Z, -0.5, "hs03_plate_t-tp_floor+1.5", origin=(0.0, 0.0, z0 + m["tp_floor"]))
    keep = [b_ for b_ in nxh.solids(p) if b_.Tag not in (body.Tag, tool.Tag)]
    nxh.subtract(p, tool, keep, check=False)          # the tool splits into the two pockets: expected
    tools = [b_ for b_ in nxh.solids(p) if b_.Tag != body.Tag]
    c.chk("top pocket tool = two pockets", len(tools), 2, 0)
    nxh.subtract(p, body, tools)
    body = [b_ for b_ in nxh.solids(p)][0]
    c.chk("one solid after the top pockets", len(nxh.solids(p)), 1, 0)
    c.notes["top_pockets_removed_mm3"] = round(v0 - c.vol(body), 3)
    c.chk.true("top pockets removed material", v0 - c.vol(body) > 5.0, v0 - c.vol(body))
    # ---- side windows through the thin wall at the narrow plate sides (y = +-12), point symmetric about Z
    wc, ww, wz0, wz1 = m["win_c"], m["win_w"], m["win_z0"], m["win_z1"]
    for sg, nm in ((1, "SK_WINDOW_PY"), (-1, "SK_WINDOW_MY")):
        x0, x1 = sg * wc - ww / 2, sg * wc + ww / 2
        f0 = "win_w/2-win_c" if sg > 0 else "win_c+win_w/2"
        f1 = "win_c+win_w/2" if sg > 0 else "win_w/2-win_c"
        Sw = c.sketch("xz", nm, shift=(0.0, 0.0, z0))
        ls, zs = m["win_ls"], m["win_zs"]
        xs = x0 + ls if sg > 0 else x1 - ls
        if sg > 0:
            pw = [(x0, wz0, f0, "win_z0"), (xs, wz0, "win_c-win_w/2+win_ls", None), (xs, zs, None, "win_zs"), (x1, zs, f1, None),
                  (x1, wz1, None, "win_z1"), (x0, wz1, None, None)]
        else:
            pw = [(x1, wz0, f1, "win_z0"), (x1, wz1, None, "win_z1"), (x0, wz1, f0, None), (x0, zs, None, "win_zs"),
                  (xs, zs, "win_c-win_w/2+win_ls", None), (xs, wz0, None, None)]
        Sw.profile(pw)
        c.done(Sw)
        v0 = c.vol(body)
        fw = nxh.extrude(p, Sw.section(None, (sg * wc, (zs + wz1) / 2)), (0, sg, 0), 9.0, 13.0, op=BOOL.Subtract, target=body)
        fw.SetName("WINDOW_" + ("PY" if sg > 0 else "MY"))
        body = nxh.solids(p)[0]
        c.chk.true("window %+d removed material" % sg, v0 - c.vol(body) > 3.0, v0 - c.vol(body))
        c.chk.true("window %+d open at the wall middle" % sg, abs(nxh.dist_to(p, body, (sg * wc, sg * 11.3, z0 + (zs + wz1) / 2))) > 0.5,
                   nxh.dist_to(p, body, (sg * wc, sg * 11.3, z0 + (zs + wz1) / 2)))
    c.chk("one solid", len(nxh.solids(p)), 1, 0)

    # ---- interface read-back
    def probe(name, q):
        c.chk(name, abs(nxh.dist_to(p, body, (q[0], q[1], z0 + q[2]))), 0.0, 1e-6)
    probe("underside at z_hs03", (0.0, (r1 + m["boss_d"] / 2) / 2, 0.0))
    probe("plate top at plate_t", (hx, 3.5, m["hs03_plate_t"]))
    probe("top pocket floor", (13.6, 0.0, m["tp_floor"]))
    probe("bore1", (-r1, 0.0, s1 / 2))
    probe("step1 face", (0.0, (r1 - ch + r2) / 2, s1))
    probe("bore2", (0.0, r2, (s1 + s2) / 2))
    probe("step2 face (SL03 face seal)", (0.0, (r2 + r3) / 2, s2))
    probe("bore3", (0.0, r3, (s2 + L) / 2))
    probe("top face", (0.0, (r3 + m["top_d"] / 2) / 2, L))
    probe("ear hole +X", (hx + m["hs03_ear_hole_d"] / 2, 0.0, 3.0))
    probe("ear hole -X", (-hx - m["hs03_ear_hole_d"] / 2, 0.0, 3.0))
    probe("pin tip", (m["pin_x"], m["pin_y"], -m["hs03_pin_len"]))
    probe("pin side", (-m["pin_x"] - m["hs03_pin_d"] / 2, -m["pin_y"], -1.0))
    probe("ear tip", (ec + R2, 0.0, 2.0))
    c.notes["plate_length"] = 2 * (ec + R2)

    # ---- regeneration: internal boss_d +1 -> back
    v_nom = c.vol(body)
    nxh.set_expr(p, "boss_d", m["boss_d"] + 1.0); nxh.update()
    v2 = c.vol(nxh.solids(p)[0])
    errs = [str(x) for x in nxh.feature_errors(p)]
    nxh.set_expr(p, "boss_d", m["boss_d"]); nxh.update()
    c.chk.true("regeneration boss_d +1: volume grows, no errors", v2 > v_nom + 10 and not errs, "%.3f -> %.3f %s" % (v_nom, v2, errs))
    body = nxh.solids(p)[0]
    c.chk("regeneration back to nominal", c.vol(body), v_nom, 1e-6 * v_nom)
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
