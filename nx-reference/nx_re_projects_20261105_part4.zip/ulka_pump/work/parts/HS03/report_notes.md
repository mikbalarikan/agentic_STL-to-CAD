## Çerçeve ve yerleşim
Yerinde (Rev A): plaka alt yüzü (pimli, EM02 çıkış duvarına oturan) `z_hs03` = 0'da, +Z göbek ucuna; kulaklar ±X,
pimler (±`pin_x`, ±`pin_y`). Tarama `scan\EP5-HS03_aligned.stl` aynı çerçevede (z ekseni 4 düzlem yüzün normali,
orijin 5 dairesel özelliğin ortak merkezi, +x kulak deliği), dönüşümsüz karşılaştırıldı.

## Modelleme kararları (ölçüden)
- Plaka hattı: kulak yayları kulak deliğiyle eş merkezli (`ear_cx` = `fs_pitch`/2), R 4,25; düz kenarlar eksenden 12,13
  (dört kenar 12,08-12,18), uç r 23,20 (tarama 23,18-23,30).
- Alt cepler 2 x (2,3 x 5,0 x 2,1), pimler arasında. Üst cepler: plaka hattı 1,6 içeri ofset, göbek çevresinde r 12,2 ve
  kulak deliği çevresinde R 4,4 dışarıda kalır, taban z 3,6 (tarama 3,56-3,64).
- Göbek: Ø23,94 -> ~33° konik -> Ø20,45, üst dış kenar 0,4 pah; iç Ø20,93 / Ø16,50 / Ø14,26 (kontrol parçası).

## Modellenmeyen / tutmayan
- Dar yan pencereleri (A_QA ilk tur notu üzerine eklendi): ince duvarda (Ø20,93 delik / kenar 12,13) L biçimli açıklık:
  geniş kısım 5,3 x 2,2 (z 2,3-4,5), altında 1,9 genişlikte yarık z 0,8'e iner; +y yanında x = +1,1, -y yanında x = -1,1
  merkezli, yarık sırasıyla -X / +X ucunda (eksene göre 180° simetrik; tarama +0,98 / -1,33).
- Göbek-plaka birleşiminde ~R1 dolgu modellenmedi (dolgu dar yanda plaka kenarını aşıyor: kenar r 12,13, göbek r 11,97).
- Ön kontrol (D, pencerelerden sonra): yerinde %84,8, kendi oturmasıyla %85,1 ±0,15 içinde (**%90 kapısının altında**).
  Gürültü sınırı: taramaya uydurulan silindirlerin (Ø20,93 / Ø16,50 / Ø14,26 / göbek) artıkları sd 0,065-0,124; sd 0,11
  ile kusursuz model de ±0,15 içinde ancak ≈%82'de kalır. Pencere bölgesi toplam farkın %3'ü. Fark bölgelere yayılı (plaka yanları %4,3,
  delikler %3,3, birleşim %1,8, göbek %3,6, pimler %1,3, üst %1,0 katkı); tarama gürültüsü HS03'te duvarlarda sd 0,10-0,12.
  A'nın kendi ICP'si ve %2 kırpması ile sonuç A_QA'da kesinleşir.
