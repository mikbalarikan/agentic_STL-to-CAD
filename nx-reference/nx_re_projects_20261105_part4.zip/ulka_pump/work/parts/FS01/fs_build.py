"""EP5-FS01_SCR-FLANGE: ISO 7045 M4 x 8 pan head cross recess screw, simplified standard part, modelled IN PLACE
(the +X screw of the pair; A places the second instance at -fs_pitch along X).

  run_journal fs_build.py -args <parts\\FS01 folder> <control part path>

Axis: (fs_pitch/2, 0) parallel to Z; head bearing face at z_fs01_head (HS03 ear top), head in +Z, shank in -Z.
Sizes from the control part by interpart expressions. Thread not modelled (shank at the major diameter);
H2 cross recess as two crossing slots (derived, ISO 4757 size 2 approximation: m 4.4, width 1.0, depth 1.9).
Writes fs_build.json ("result": PASS | FAIL).
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR", r"C:\Users\marya\.claude\skills\nx-journal-core\scripts"))
import nxh  # noqa: E402
import nxf  # noqa: E402
import nxa  # noqa: E402

OUT, CTRL = sys.argv[1], sys.argv[2]
NAME = "EP5-FS01_SCR-FLANGE"
chk = nxh.Check()
res = {"result": "FAIL", "name": NAME}
try:
    ctrl = nxh.open_part(CTRL)
    part = nxh.new_part(os.path.join(OUT, NAME + ".prt"))
    names = ("fs_pitch", "z_fs01_head", "fs01_d", "fs01_len", "fs01_dk", "fs01_k")
    for n in names:
        nxa.interpart_expr(part, n, ctrl)
    v = {n: part.Expressions.FindObject(n).Value for n in names}
    nxh.expr(part, "tip_leg", 0.5, "mm", "point chamfer leg (simplified point)")
    nxh.expr(part, "crown_r", 1.2, "mm", "pan head crown blend (simplified ISO 7045 crown)")
    nxh.expr(part, "rec_m", 4.4, "mm", "cross recess span (ISO 4757 H2, derived)")
    nxh.expr(part, "rec_w", 1.0, "mm", "cross recess slot width (derived)")
    nxh.expr(part, "rec_t", 1.9, "mm", "cross recess depth (derived)")
    x0, z0 = v["fs_pitch"] / 2, v["z_fs01_head"]
    head = nxh.cylinder(part, (x0, 0, z0), (0, 0, 1), "fs01_dk", "fs01_k")[1]
    shank = nxh.cylinder(part, (x0, 0, z0), (0, 0, -1), "fs01_d", "fs01_len")[1]
    nxh.unite(part, head, [shank])
    body = nxh.one(nxh.solids(part), "solid")
    v0 = math.pi / 4 * (v["fs01_dk"] ** 2 * v["fs01_k"] + v["fs01_d"] ** 2 * v["fs01_len"])
    chk("head + shank volume = analytic", nxh.volume(part, body), v0, 1e-3)
    ztop = z0 + v["fs01_k"]
    top = nxh.one([e for e in nxh.edges_at(body, 2, ztop) if abs(nxh.bbox(e)[3] - (x0 + v["fs01_dk"] / 2)) < 1e-3], "head top edge")
    nxf.edge_blend(part, [([top], "crown_r")])
    body = nxh.one(nxh.solids(part), "solid")
    tipe = nxh.one(nxh.edges_at(body, 2, z0 - v["fs01_len"]), "tip edge")
    nxf.chamfer(part, [tipe], "tip_leg")
    body = nxh.one(nxh.solids(part), "solid")
    vol_plain = nxh.volume(part, body)
    m, w, t = 4.4, 1.0, 1.9
    nxh.block(part, (x0 - m / 2, -w / 2, ztop - t), ("rec_m", "rec_w", "rec_t + 1"), op=nxh.BOOL.Subtract, target=body)
    nxh.block(part, (x0 - w / 2, -m / 2, ztop - t), ("rec_w", "rec_m", "rec_t + 1"), op=nxh.BOOL.Subtract, target=body)
    body = nxh.one(nxh.solids(part), "solid")
    vol = nxh.volume(part, body)
    chk("recess removed = analytic", vol_plain - vol, (2 * m * w - w * w) * t, 1e-3)
    r, R = 1.2, v["fs01_dk"] / 2
    a_bl = (1 - math.pi / 4) * r * r
    c_bl = R - r + r * (1 - (10 - 3 * math.pi) / (12 - 3 * math.pi))
    rs, tl = v["fs01_d"] / 2, 0.5
    v_ch = math.pi * tl * (rs ** 2 - (rs ** 2 + rs * (rs - tl) + (rs - tl) ** 2) / 3)
    chk("blend + chamfer volume = analytic", vol_plain, v0 - 2 * math.pi * c_bl * a_bl - v_ch, 2e-2)
    bb = nxh.bbox(body)
    chk("tip z", bb[2], z0 - v["fs01_len"], 1e-3)
    chk("head top z", bb[5], ztop, 1e-3)
    chk("axis x", (bb[0] + bb[3]) / 2, x0, 1e-3)
    chk.true("no feature errors", not nxh.feature_errors(part), nxh.feature_errors(part))
    body.SetName(NAME)
    nxh.save(part)
    stp = os.path.join(OUT, NAME + ".stp")
    nxf.step_export(part, stp)
    res.update(volume=vol, bbox=[round(x, 4) for x in bb], values=v, step=os.path.exists(stp) and os.path.getsize(stp))
    res.update(chk.report())
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "fs_build.json"), res)
