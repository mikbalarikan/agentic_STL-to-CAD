"""EP5-VL04_SPRING-VALVE - native parametric build (NX 2206, headless), ULKA-D. Builder: D_common/nxlib/dsmall.py:spring."""
import os, sys, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\D_common\nxlib")
import nxh, rj, dsmall
OUT = sys.argv[1]
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, "EP5-VL04_SPRING-VALVE")
    body = dsmall.spring(c, "VL04", 3.95, 5.35, 3, 0, "scan: OD 4.4 -> 6.2 (weak); big end kept 5.8 OD for the 6.0 valve bore")
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
