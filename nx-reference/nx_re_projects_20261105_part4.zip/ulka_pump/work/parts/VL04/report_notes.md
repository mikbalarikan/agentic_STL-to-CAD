## Çerçeve ve tasarım
Kendi çerçevesinde: z0 = giriş tarafı ucu (VL03 başına dayanan küçük uç), +Z çıkışa (VL05'e). Boy `vl04_len` (=
`vl04_l0` 6,8). Konik: Dm 3,95 (OD 4,4) -> 3 sarımda smoothstep -> Dm 5,35 (OD 5,8); toplam 5,5 sarım, aktif hatve 1,53,
blok ≈2,9. Büyük uç OD 5,8 alındı (tarama ~6,2 zayıf/bulanık; Ø6,0 valf deliğinde çalışır). Tel Ø 0,45 (`vl04_d`).

## Tarama
Parçalı; karşılaştırma yapılmadı. Montaj (CR-D-02): VL03 başı ile VL05 arası montaj boyu 3,9, valf kalkışı ≈1,0.
