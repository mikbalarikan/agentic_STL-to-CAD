## Çerçeve
Yerinde: alt yüz `z_hs05` (HS01 soket ağzında), +Z. Tarama tek yüzden (alt yüz masada, 0,25 mm alt kesik): üst yüz,
dış çap ve delik karşılaştırılabilir. F15'teki bir yüzdeki delik çevresi kademe taramada görülmediği için modellenmedi;
dış kenarlarda 0,2 pah. Ön kontrol: kendi oturmasından sonra %93,8 ±0,15 içinde (eğim 0,8°: masa düzlemi kesiği).
