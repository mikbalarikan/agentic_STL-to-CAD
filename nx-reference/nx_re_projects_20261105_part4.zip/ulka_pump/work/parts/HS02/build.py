"""EP5-HS02 piston cylinder - native parametric build (NX 2206, headless).   run_journal build.py -args <out>

In place in the pump frame (ULKA_INTERFACES Rev A): Z = pump axis, +Z inlet -> outlet; the flange (inlet) face on
PL_HS02 at z_hs02. Interface values are interpart expressions from EP5-AS00_CTRL.prt; part-internal values are named
expressions. Inner profile from the chamber bottom to the outlet is DERIVED (cr/CR-D-01): chamber, seat wall with
the VL03 seat hole, valve bore, VL05 seat, G1/8 outlet (cosmetic; modelled at the tapping size hs02_out_d).
Features: PL_HS02 + AX_HS02_X -> SK_PROFILE -> Revolve -> PL_FLATS + SK_FLATS -> Extrude (subtract, CH12 flats).
"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\D_common\nxlib")
import NXOpen
import nxh, nxf, nxa
import rj
from rj import BOOL, X, Y, Z

OUT = sys.argv[1]
NAME = "EP5-HS02_CYLINDER"
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, NAME)
    p, M = c.part, c.M
    for n in ("z_hs02", "hs02_len", "hs02_flange_d", "hs02_flange_t", "hs02_body_d", "hs02_sl04_d", "hs02_sl04_depth",
              "hs02_out_d", "hs02_out_floor", "hs02_seat_d", "hs02_ch_s", "hs02_ch_z0", "hs02_ch_z1"):
        c.link(n)
    c.e("fl_ch", 0.3, "flange face outer chamfer [scan OD 15.50 at z 0 vs 15.60 at 0.4]")
    c.e("body1_d", 13.47, "body OD between flange and band [scan 13.46-13.50, z 3.6-9.6]")
    c.e("band_d", 13.13, "shallow band OD [scan 13.13-13.15, z 10.8-14.4]")
    c.e("band_z0", 10.6, "band start from the flange face [scan transition 10.4-10.8]")
    c.e("band_z1", 14.8, "band end [scan transition 14.4-15.2]")
    c.e("tip_ch_z", 1.2, "outer tip chamfer axial length [scan 13.22 at 40.0 -> 12.66 at 40.8]")
    c.e("tip_ch_r", 0.39, "outer tip chamfer radial depth -> tip OD 12.62 [scan]")
    c.e("tip_cyl", 0.42, "outer tip cylinder length after the chamfer [scan 40.8-41.22]")
    c.e("mouth_d", 11.2, "outlet mouth lead-in outer diameter [scan 11.2 at the tip face]")
    c.e("mouth_z", 1.2, "outlet lead-in depth [scan 40.0 -> 41.22]")
    c.e("entry_d", 6.4, "piston bore entry diameter at the SL04 recess floor [scan 6.40 at z 2.2]")
    c.e("entry_z", 5.0, "end of the entry cone from the flange face [scan 6.0 from z ~5]")
    c.e("bore_d", 6.0, "pressure chamber / piston bore [scan 6.0-6.06 at z 5-7.5 local axis; deeper DERIVED]")
    c.e("ch_bot", 24.0, "chamber bottom from the flange face, DERIVED from the Rev C stroke (cr/CR-D-02)")
    c.e("wall_t", 0.8, "seat wall thickness, DERIVED (cr/CR-D-02)")
    c.e("vbore_d", 6.0, "outlet valve bore (VL03 head) [scan 6.0-6.1 at the room floor; length DERIVED]")
    c.link("hs02_vl05_z"); c.link("vl05_t")
    c.d("thr_len", "hs02_len-hs02_vl05_z-vl05_t", "G1/8 thread length from the tip down to the VL05 top (cosmetic; datasheet min 7 not met, cr/CR-D-02)")
    c.d("thr_start", "hs02_len-thr_len", "G1/8 thread start from the flange face")

    zb = M["z_hs02"]
    fp, pl = nxf.datum_plane(p, "offset", [c.dat.xy], "z_hs02", "PL_HS02")
    fa, ax = nxf.datum_axis(p, "intersection", pl, c.dat.xz, name="AX_HS02_X")
    m = M
    L = m["hs02_len"]
    pv = [(m["hs02_sl04_d"] / 2, 0.0, "hs02_sl04_d/2", None),
          (m["hs02_flange_d"] / 2 - m["fl_ch"], 0.0, "hs02_flange_d/2-fl_ch", None),
          (m["hs02_flange_d"] / 2, m["fl_ch"], "hs02_flange_d/2", "fl_ch"),
          (m["hs02_flange_d"] / 2, m["hs02_flange_t"], None, "hs02_flange_t"),
          (m["body1_d"] / 2, m["hs02_flange_t"], "body1_d/2", None),
          (m["body1_d"] / 2, m["band_z0"], None, "band_z0"),
          (m["band_d"] / 2, m["band_z0"], "band_d/2", None),
          (m["band_d"] / 2, m["band_z1"], None, "band_z1"),
          (m["hs02_body_d"] / 2, m["band_z1"], "hs02_body_d/2", None),
          (m["hs02_body_d"] / 2, L - m["tip_ch_z"], None, "hs02_len-tip_ch_z"),
          (m["hs02_body_d"] / 2 - m["tip_ch_r"], L - m["tip_cyl"], "hs02_body_d/2-tip_ch_r", "hs02_len-tip_cyl"),
          (m["hs02_body_d"] / 2 - m["tip_ch_r"], L, None, "hs02_len"),
          (m["mouth_d"] / 2, L, "mouth_d/2", None),
          (m["hs02_out_d"] / 2, L - m["mouth_z"], "hs02_out_d/2", "hs02_len-mouth_z"),
          (m["hs02_out_d"] / 2, m["hs02_out_floor"], None, "hs02_out_floor"),
          (m["vbore_d"] / 2, m["hs02_out_floor"], "vbore_d/2", None),
          (m["vbore_d"] / 2, m["ch_bot"] + m["wall_t"], None, "ch_bot+wall_t"),
          (m["hs02_seat_d"] / 2, m["ch_bot"] + m["wall_t"], "hs02_seat_d/2", None),
          (m["hs02_seat_d"] / 2, m["ch_bot"], None, "ch_bot"),
          (m["bore_d"] / 2, m["ch_bot"], "bore_d/2", None),
          (m["bore_d"] / 2, m["entry_z"], None, "entry_z"),
          (m["entry_d"] / 2, m["hs02_sl04_depth"], "entry_d/2", "hs02_sl04_depth"),
          (m["hs02_sl04_d"] / 2, m["hs02_sl04_depth"], None, None)]
    S = c.sketch("xz", "SK_PROFILE", hax=ax, shift=(0.0, 0.0, zb))
    S.profile(pv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (6.0, 8.0)), nxf.axis_from(p, c.dat.z))
    f.SetName("BODY_REVOLVE")
    body = f.GetBodies()[0]
    v_rev = rj.revolve_volume([(a[0], a[1]) for a in pv])
    c.chk("revolved volume = profile (Pappus)", c.vol(body), v_rev, 1e-6 * v_rev)

    # ---- CH12 flats: two flats +-X, hs02_ch_s across, z hs02_ch_z0 .. hs02_ch_z1
    fpf, plf = nxf.datum_plane(p, "offset", [c.dat.xy], "z_hs02+hs02_ch_z0", "PL_FLATS")
    h = m["hs02_ch_s"] / 2
    Sf = c.sketch("xy", "SK_FLATS", on=plf, shift=(0.0, 0.0, zb + m["hs02_ch_z0"]))
    Sf.profile([(h, -8.0, "hs02_ch_s/2", "8"), (9.0, -8.0, "9", None), (9.0, 8.0, None, "8"), (h, 8.0, None, None)])
    Sf.profile([(-h, -8.0, "hs02_ch_s/2", "8"), (-h, 8.0, None, "8"), (-9.0, 8.0, "9", None), (-9.0, -8.0, None, None)])
    c.done(Sf)
    v0 = c.vol(body)
    ff = nxh.extrude(p, Sf.section(None, (8.0, 0.0)), Z, 0, "hs02_ch_z1-hs02_ch_z0", op=BOOL.Subtract, target=body,
                     origin=(0.0, 0.0, zb + m["hs02_ch_z0"]))
    ff.SetName("CH12_FLATS")
    body = nxh.solids(p)[0]
    R = m["hs02_body_d"] / 2
    seg = R * R * math.acos(h / R) - h * math.sqrt(R * R - h * h)
    dv = 2 * seg * (m["hs02_ch_z1"] - m["hs02_ch_z0"])
    c.chk("flats removed 2 x segment x length", v0 - c.vol(body), dv, 1e-6 * v0)
    c.chk("one solid", len(nxh.solids(p)), 1, 0)

    # ---- interface read-back (probes on the faces at designed coordinates)
    def probe(name, r, zl, ang=90.0):
        q = (r * math.cos(math.radians(ang)), r * math.sin(math.radians(ang)), zb + zl)
        c.chk(name, abs(nxh.dist_to(p, body, q)), 0.0, 1e-6)
    probe("flange face at z_hs02", (m["hs02_sl04_d"] + m["hs02_flange_d"]) / 4, 0.0)
    probe("flange OD", m["hs02_flange_d"] / 2, m["hs02_flange_t"] / 2)
    probe("SL04 recess bore", m["hs02_sl04_d"] / 2, m["hs02_sl04_depth"] / 2)
    probe("SL04 recess floor", (m["hs02_sl04_d"] + m["entry_d"]) / 4, m["hs02_sl04_depth"])
    probe("body OD at HS03 throat", m["hs02_body_d"] / 2, 33.0)
    probe("outlet bore (tapping size)", m["hs02_out_d"] / 2, 35.0)
    probe("outlet room floor", (m["hs02_out_d"] + m["vbore_d"]) / 4, m["hs02_out_floor"])
    probe("seat edge hole", m["hs02_seat_d"] / 2, m["ch_bot"] + m["wall_t"] / 2)
    probe("tip face", (m["mouth_d"] / 2 + R - m["tip_ch_r"]) / 2, L)
    probe("flat face +X", h, (m["hs02_ch_z0"] + m["hs02_ch_z1"]) / 2, 0.0)
    probe("flat face -X", h, (m["hs02_ch_z0"] + m["hs02_ch_z1"]) / 2, 180.0)
    bx = nxh.bbox(body)
    c.chk("length", bx[5] - bx[2], L, 1e-4)
    c.notes["chamber_volume_mm3"] = round(math.pi / 4 * m["bore_d"] ** 2 * (m["ch_bot"] - m["entry_z"]) + math.pi / 12 * (m["entry_z"] - m["hs02_sl04_depth"]) * (m["entry_d"] ** 2 + m["entry_d"] * m["bore_d"] + m["bore_d"] ** 2), 2)
    c.notes["thread"] = "G1/8 (BSPP 28 tpi) internal, z %.2f .. %.2f local (cosmetic; bore at tapping size %.2f)" % (L - m["thr_len"], L, m["hs02_out_d"])

    # ---- regeneration: internal wall_t 0.8 -> 1.3 -> back
    v_nom = c.vol(body)
    nxh.set_expr(p, "wall_t", 1.3); nxh.update()
    v2 = c.vol(nxh.solids(p)[0])
    errs = [str(x) for x in nxh.feature_errors(p)]
    nxh.set_expr(p, "wall_t", 0.8); nxh.update()
    dvx = math.pi / 4 * (m["vbore_d"] ** 2 - m["hs02_seat_d"] ** 2) * 0.5
    c.chk("regeneration wall_t 0.8 -> 1.3: volume + (vbore^2-seat^2)*pi/4*0.5", v2 - v_nom, dvx, 1e-6 * v_nom)
    c.chk.true("regeneration: no feature errors", not errs, errs)
    body = nxh.solids(p)[0]
    c.chk("regeneration back to nominal", c.vol(body), v_nom, 1e-6 * v_nom)
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
