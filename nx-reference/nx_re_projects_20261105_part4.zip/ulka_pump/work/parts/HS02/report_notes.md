## Çerçeve ve yerleşim
Yerinde, pompa çerçevesinde (Rev A): Z pompa ekseni, +Z girişten çıkışa; flanş (giriş) yüzü `z_hs02` = 12,499'da
(`PL_HS02`). CH12 düzlüklerinin normali ±X. Tarama karşılaştırması için hizalı tarama
`scan\EP5-HS02_aligned.stl` (z0 = flanş yüzü, düzlük normalleri ±X; iki düzlük 9,41° / 188,68° -> -9,05° döndürüldü,
5,846 + 5,881 = 11,73 aralık) z_hs02 kadar ötelenip kullanıldı.

## Ölçülen / türetilen
- Ölçülen (taramadan): flanş Ø/kalınlık, SL04 havşası, giriş konisi (Ø6,40 -> Ø6,0, z 2,15-5,0), gövde Ø ve bant,
  CH12 düzlükleri, uç pahları, ağız pahı, oda tabanı z 29,22, valf deliği Ø6,0 (görülen kısa boy).
- **Türetilen** (taramada yok, Usta ölçemiyor; `cr\CR-D-01.md`): `cr\CR-D-02.md` (Rev C kinematiği): basınç odası dibi `ch_bot` 24,0 (VL02 dinlenmede 9,33,
  yukarı dayanmada 6,75 > blok 6,25); duvar `wall_t` 0,8 ve oturma deliği `hs02_seat_d` Ø4,0 (kenar z 24,8); valf deliği
  Ø6,0 (24,8-29,22); VL05 yeri `hs02_vl05_z` 31,92-36,42 (kontrol parçası, Rev D); G1/8 iç diş: diş dibi / matkap çapında `hs02_out_d` 8,52 delik,
  **diş kozmetik** (z 36,42-41,22, `thr_len` = boy - `hs02_vl05_z` - `vl05_t` = 4,8; datasheet "min 7" **tutmuyor**, CR-D-02).

## QA'dan önce dışarıda tutulacak bölgeler (K2)
1. Çıkış odası z 29,2-41,2 iç yüzeyi: G1/8 iç diş taranmış (tarama ortalaması Ø9,15 = G1/8 bölüm dairesi 9,147),
   CAD diş dibinde (8,52). Fark 0,47 radyal, kasıtlı (kozmetik diş).
2. Orta iç (z 7,5-29,2): taramada yok.
K1 notu: SL04 havşası Ø serbest daire uydurmasında 8,59, gövde eksenine göre 8,73 (kapsama 220°); Rev A 8,63.
Flanş çevresinde ~0,1 y-kayması (taramanın iki geçişinin birleşme ofseti; flanş ucu altkümesi kendi oturmasından
sonra %91,2 ±0,15 içinde).

Ön kontrol (D, A'nın QA'sı değil): 1. bölge dışarıda tutulunca yerinde (oturtmasız) %94,5 tarama ±0,18 içinde (%91,6 ±0,15).
