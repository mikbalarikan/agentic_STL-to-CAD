# ULKA-B: re-run every B part after a control-part revision: journal (under the NX lock), own scan check, report.
$py = 'C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe'
foreach ($c in @("HS04", "EM03", "EM01", "EM02")) {
    "== $c"
    & C:\NX_MCP_WORKSPACE\ulka\parts\_B_common\run.ps1 -Code $c | Select-Object -First 4
    $dev = Get-ChildItem "C:\NX_MCP_WORKSPACE\ulka\parts\$c\dev_*.py" | Where-Object { $_.Name -ne "dev_bad.py" } | Select-Object -First 1
    Push-Location "C:\NX_MCP_WORKSPACE\ulka\parts\$c"
    & $py $dev.FullName | Select-String "  all " | Select-Object -Last 1
    if ($c -eq "EM03") { Copy-Item qa\dev_sleeve2.json qa\dev.json -Force }
    & python ..\_B_common\report.py $c
    Pop-Location
}
