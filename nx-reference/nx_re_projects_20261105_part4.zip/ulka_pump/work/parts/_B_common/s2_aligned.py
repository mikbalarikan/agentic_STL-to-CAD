"""Write the B aligned scan copies in part frames and the transforms (raw scanner -> aligned)."""
import sys
import numpy as np
import rb
sys.stdout.reconfigure(encoding="utf-8")
out = {}
# EM01: bore axis, z=0 on the terminal-side end face (bore frame z=-23.93), +X toward the end tabs (85.2 deg)
T = np.array(rb.load_json("EM01", "m_em01_T.json")["T"])
T = rb.rotz(-85.2) @ T
T[2, 3] += 23.93
out["EM01"] = T
# EM02: box frame -> Z = hole axis (+y box, the 6-hole wall), origin on the hole axis at the outer face of that wall,
# X = box x (plain-wall normal), Y = Z x X (= -box z)
J = rb.load_json("EM02", "m_em02a.json"); D = np.array(J["D"]); c0 = np.array(J["c0"])
zb = np.cross(D[0], D[1]); zb /= np.linalg.norm(zb)
Tb = rb.frame(zb, c0, x=D[0])
R = np.array([[1, 0, 0, -0.107], [0, 0, -1, 0], [0, 1, 0, -25.128], [0, 0, 0, 1.0]])
out["EM02"] = R @ Tb
# HS04: from m_hs04 (table frame centred on the outer wall) + concentric centre shift
T = np.array(rb.load_json("HS04", "m_hs04.json")["T_raw_to_aligned"])
Tc = np.eye(4); Tc[:2, 3] = [-0.16847, 0.01672]
out["HS04"] = Tc @ T
# EM03: sleeve frames, z=0 at the lower end face
J = rb.load_json("EM03", "m_em03.json")
for nm, zlo in (("sleeve1", -9.343), ("sleeve2", -9.542)):
    T = np.array(J[nm]["T"]); T[2, 3] -= zlo
    out["EM03_" + nm] = T
tri_raw = {}
for key, T in out.items():
    code = key[:4]
    if code not in tri_raw:
        tri_raw[code] = rb.read_stl(rb.raw_path(code))
    tri = tri_raw[code]
    if code == "EM03":
        v, f = rb.weld(tri); lab = rb.components(f, len(v)); cnt = np.bincount(lab); order = np.argsort(-cnt)
        tri = tri[lab == order[int(key[-1]) - 1]]
    t = rb.apply(T, tri.reshape(-1, 3)).reshape(-1, 3, 3)
    if code == "HS04":
        mm = rb.Mesh(t); r = np.hypot(mm.c[:, 0], mm.c[:, 1])
        keep = (r < 12.5) & ~((mm.c[:, 2] < 0.35) & (mm.n[:, 2] > 0.8))
        t = t[keep]
    name = "EP5-%s_aligned.stl" % key.replace("EM03_", "EM03_")
    rb.write_stl(rb.os.path.join(rb.SCAN, name), t)
    lo, hi = t.reshape(-1, 3).min(0), t.reshape(-1, 3).max(0)
    print("%-16s %7d facets  bbox %s .. %s" % (name, len(t), np.round(lo, 2), np.round(hi, 2)))
rb.save_json("_B_common", "aligned_transforms.json", {k: v for k, v in out.items()})
