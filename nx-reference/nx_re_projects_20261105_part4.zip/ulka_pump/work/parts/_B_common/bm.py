"""ULKA session B - extra measurement helpers on top of rb.py."""
import numpy as np
import rb


def robust_circle(xy, w=None, iters=6, k=2.5):
    """Algebraic (Kasa) circle fit with MAD clipping. Returns (cx, cy, r, sd, n_used, mask)."""
    xy = np.asarray(xy, float)
    m = np.ones(len(xy), bool)
    for _ in range(iters):
        A = np.c_[2 * xy[m, 0], 2 * xy[m, 1], np.ones(m.sum())]
        b = (xy[m] ** 2).sum(1)
        c = np.linalg.lstsq(A, b, rcond=None)[0]
        r = np.sqrt(c[2] + c[0] ** 2 + c[1] ** 2)
        res = np.hypot(xy[:, 0] - c[0], xy[:, 1] - c[1]) - r
        s = 1.4826 * np.median(np.abs(res[m]))
        m = np.abs(res) < k * max(s, 0.005)
    res = np.hypot(xy[:, 0] - c[0], xy[:, 1] - c[1]) - r
    return c[0], c[1], r, float(res[m].std()), int(m.sum()), m


def table_frame(m, d, z_cut=None):
    """Frame with +Z = d, origin on the dominant plane facing +d (scanner table / seat face)."""
    T = rb.frame(d, np.average(m.c, axis=0, weights=m.a))
    q = m.moved(T)
    up = q.n[:, 2] > 0.98
    zz = q.c[up, 2]
    pk = rb.hist_peaks(zz, q.a[up], bin=0.02, min_frac=0.05, sep=0.3)
    return T, q, pk


def refine_plane(q, mask):
    """Fit plane z = a x + b y + c on facet centroids of mask (robust). Returns normal (unit, +z) and point."""
    p = q.c[mask]
    keep = np.ones(len(p), bool)
    for _ in range(5):
        A = np.c_[p[keep, 0], p[keep, 1], np.ones(keep.sum())]
        a, b, c = np.linalg.lstsq(A, p[keep, 2], rcond=None)[0]
        res = p[:, 2] - (a * p[:, 0] + b * p[:, 1] + c)
        s = 1.4826 * np.median(np.abs(res[keep]))
        keep = np.abs(res) < 3 * max(s, 0.003)
    n = np.array([-a, -b, 1.0]); n /= np.linalg.norm(n)
    return n, np.array([0, 0, c]), float(res[keep].std())


def concentric_fit(groups, c0=(0.0, 0.0), iters=8, k=2.5):
    """Common-centre circle fit for several point groups [(xy), ...]. Returns centre, radii, sds, masks."""
    from scipy.optimize import least_squares
    masks = [np.ones(len(g), bool) for g in groups]
    x0 = np.r_[c0, [np.median(np.hypot(g[:, 0] - c0[0], g[:, 1] - c0[1])) for g in groups]]
    for _ in range(iters):
        def f(x):
            return np.concatenate([np.hypot(g[m, 0] - x[0], g[m, 1] - x[1]) - x[2 + i] for i, (g, m) in enumerate(zip(groups, masks))])
        x0 = least_squares(f, x0).x
        new = []
        for i, g in enumerate(groups):
            res = np.hypot(g[:, 0] - x0[0], g[:, 1] - x0[1]) - x0[2 + i]
            s = 1.4826 * np.median(np.abs(res[masks[i]]))
            new.append(np.abs(res) < k * max(s, 0.005))
        masks = new
    sds = [float((np.hypot(g[m, 0] - x0[0], g[m, 1] - x0[1]) - x0[2 + i]).std()) for i, (g, m) in enumerate(zip(groups, masks))]
    return x0[:2], x0[2:], sds, masks
