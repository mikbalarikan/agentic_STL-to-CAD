param([Parameter(Mandatory = $true)][string]$Code, [string]$Script = "build.py", [int]$Timeout = 900)
# ULKA-B: runs parts\<Code>\<Script> headless in NX 2206 under the shared NX lock and the free-RAM rule.
$lock = 'C:\NX_MCP_WORKSPACE\ulka\nx.lock'
$s = 'C:\Users\marya\.claude\skills\nx-journal-core\scripts'
$w = "C:\NX_MCP_WORKSPACE\ulka\parts\$Code"
$o = "$w\out"
New-Item -ItemType Directory -Force $o | Out-Null
# 1. lock (mkdir is atomic); wait while someone else holds it
$t0 = Get-Date
while ($true) {
    try { New-Item -ItemType Directory $lock -ErrorAction Stop | Out-Null; break }
    catch {
        $own = Get-Content "$lock\owner.txt" -ErrorAction SilentlyContinue
        if (((Get-Date) - $t0).TotalMinutes -gt 30) { "LOCK TIMEOUT, held by: $own"; exit 3 }
        Start-Sleep -Seconds 20
    }
}
"ULKA-B Stator $Code/$Script " + (Get-Date -Format s) | Set-Content "$lock\owner.txt"
try {
    # 2. free RAM >= 2.5 GB
    $t1 = Get-Date
    while (((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory / 1MB) -lt 2.5) {
        if (((Get-Date) - $t1).TotalMinutes -gt 20) { "RAM WAIT TIMEOUT"; exit 4 }
        Start-Sleep -Seconds 20
    }
    $json = "$o\" + [IO.Path]::GetFileNameWithoutExtension($Script) + ".json"
    if (Test-Path $json) { Remove-Item $json }
    $t2 = Get-Date
    & "$s\run_journal.ps1" -Script "$w\$Script" -WorkDir $w -JArgs $o -TimeoutSec $Timeout 2>&1 | Select-Object -Last 4
    "elapsed " + [int]((Get-Date) - $t2).TotalSeconds + " s"
    & 'C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe' 'C:\NX_MCP_WORKSPACE\ulka\parts\_B_common\show.py' $json
}
finally { Remove-Item -Recurse -Force $lock }
