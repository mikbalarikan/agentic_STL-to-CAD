"""EM02 frame details in the box frame (x = wall normal of the plain walls, y = hole axis, z = strip width)."""
import sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rb, bm
sys.stdout.reconfigure(encoding="utf-8")
q = rb.Mesh(rb.read_stl(rb.os.path.join(rb.SCAN, "EP5-EM02_box-frame.stl")))
res = {}
# strip edges (z)
s = np.abs(q.n[:, 2]) > 0.95
for val, sh in sorted(rb.hist_peaks(q.c[s, 2], q.a[s], bin=0.01, min_frac=0.03, sep=0.3)):
    ss = s & (np.abs(q.c[:, 2] - val) < 0.1)
    print("z-edge %.3f facing %+.0f area %.0f" % (val, np.sign(np.median(q.n[ss, 2])), q.a[ss].sum()))
# x-walls planes, per z band to check flatness
for side in (-1, 1):
    for nm, sg in (("outer", side), ("inner", -side)):
        s = (q.c[:, 0] * side > 20) & (q.n[:, 0] * sg > 0.97) & (np.abs(q.c[:, 1]) < 18)
        print("x-wall %+d %s: x median %.3f sd %.3f n %d" % (side, nm, np.median(q.c[s, 0]), q.c[s, 0].std(), s.sum()))
# y-walls
for side in (-1, 1):
    for nm, sg in (("outer", side), ("inner", -side)):
        s = (q.c[:, 1] * side > 18) & (q.n[:, 1] * sg > 0.97) & (np.abs(q.c[:, 0]) < 20)
        if s.sum() > 100:
            print("y-wall %+d %s: y median %.3f sd %.3f n %d" % (side, nm, np.median(q.c[s, 1]), q.c[s, 1].std(), s.sum()))
# holes on the y walls: wall facets of holes (normals in x-z plane), cluster by centre guess
guess = {1: [(0, 0, 10.6), (-14, -5, 2), (-14, 5, 2), (14, -5, 2), (14, 5, 2), (-19, 0, 2), (19, 0, 2)], -1: [(0, 0, 8.4)]}
holes = []
for side in (-1, 1):
    for gx, gz, gr in guess[side]:
        xz = q.c[:, [0, 2]] - [gx, gz]
        r = np.hypot(xz[:, 0], xz[:, 1])
        rn = (xz * q.n[:, [0, 2]]).sum(1) / np.maximum(r, 1e-9)
        s = (q.c[:, 1] * side > 21.5) & (q.c[:, 1] * side < 25.3) & (np.abs(q.n[:, 1]) < 0.4) & (rn < -0.7) & (np.abs(r - gr) < 0.8)
        c = bm.robust_circle(q.c[s][:, [0, 2]])
        cov = len(np.unique(np.round(np.degrees(np.arctan2(xz[s, 1], xz[s, 0])) / 10))) * 10
        holes.append({"side": side, "x": c[0], "z": c[1], "D": 2 * c[2], "sd": c[3], "n": c[4], "cover": cov})
        print("hole y%+d at (%.3f, %.3f) D %.3f sd %.3f n %d cover %d" % (side, c[0], c[1], 2 * c[2], c[3], c[4], cov))
res["holes"] = holes
# x-y section at z = 0 and z = +-10 for corner radii (outer)
fig, ax = plt.subplots(figsize=(11, 11))
for zz, col in ((-10, "b"), (0, "k"), (10, "r")):
    sg = q.section(2, zz)
    rb.plot_segs(ax, sg[:, :, :2], lw=0.5, color=col)
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_title("EM02 x-y sections z=-10 (b), 0 (k), +10 (r)")
fig.savefig(rb.os.path.join(rb.pdir("EM02", "fig"), "xy_sections.png"), dpi=100)
rb.save_json("EM02", "m_em02b.json", res)
