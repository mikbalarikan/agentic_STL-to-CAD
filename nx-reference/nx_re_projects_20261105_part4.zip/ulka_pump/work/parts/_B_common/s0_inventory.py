"""Stage 0 - describe each raw scan: facets, shells, open edges, bbox, volume, PCA axes."""
import sys
import time
import numpy as np
import rb

sys.stdout.reconfigure(encoding="utf-8")
codes = sys.argv[1:] or list(rb.RAW)
for code in codes:
    t0 = time.time()
    tri = rb.read_stl(rb.raw_path(code))
    v, f = rb.weld(tri)
    lab = rb.components(f, len(v))
    cnt = np.bincount(lab)
    cnt = cnt[cnt > 0]
    order = np.argsort(-np.bincount(lab))
    n_open, n_nonman = rb.open_edges(f)
    m = rb.Mesh(tri)
    lo, hi = v.min(axis=0), v.max(axis=0)
    c = np.average(m.c, axis=0, weights=m.a)
    cov = np.cov((m.c - c).T, aweights=m.a)
    ev, evec = np.linalg.eigh(cov)
    edge = np.sqrt(4 * m.a / np.sqrt(3))
    info = {
        "file": rb.RAW[code], "facets": len(tri), "vertices": len(v),
        "shells": int(len(cnt)), "shell_facets_top": sorted(cnt.tolist(), reverse=True)[:8],
        "open_edges": n_open, "nonmanifold_edges": n_nonman,
        "bbox_lo": lo, "bbox_hi": hi, "bbox_size": hi - lo,
        "area": float(m.a.sum()), "volume_signed": rb.volume(tri),
        "centroid_area": c, "pca_sigma": np.sqrt(ev), "pca_axes_rows": evec.T,
        "edge_median": float(np.median(edge)), "edge_p95": float(np.percentile(edge, 95)),
    }
    # per-shell bbox for the biggest shells
    shells = []
    for s in order[:6]:
        ms = lab == s
        if ms.sum() < 4:
            continue
        ts = tri[ms]
        shells.append({"facets": int(ms.sum()), "lo": ts.min(axis=(0, 1)), "hi": ts.max(axis=(0, 1)),
                       "area": float(m.a[ms].sum()), "volume": rb.volume(ts)})
    info["shell_detail"] = shells
    rb.save_json(code, "s0_inventory.json", info)
    rb.out("== %s  %s  (%.1fs)" % (code, rb.RAW[code], time.time() - t0))
    rb.out("   facets %d  verts %d  shells %d  top %s" % (len(tri), len(v), len(cnt), info["shell_facets_top"]))
    rb.out("   open edges %d  non-manifold %d" % (n_open, n_nonman))
    rb.out("   bbox lo %s hi %s size %s" % (np.round(lo, 2), np.round(hi, 2), np.round(hi - lo, 2)))
    rb.out("   area %.1f  volume %.1f  edge median %.3f p95 %.3f" % (info["area"], info["volume_signed"], info["edge_median"], info["edge_p95"]))
    rb.out("   pca sigma %s" % np.round(np.sqrt(ev), 2))
    for r in evec.T:
        rb.out("      axis %s" % np.round(r, 4))
    for s in shells[1:]:
        rb.out("   extra shell: facets %d lo %s hi %s vol %.2f" % (s["facets"], np.round(s["lo"], 2), np.round(s["hi"], 2), s["volume"]))
