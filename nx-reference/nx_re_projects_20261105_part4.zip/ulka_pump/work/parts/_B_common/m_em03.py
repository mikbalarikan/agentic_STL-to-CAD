"""EM03 flux sleeves (two in one scan). Split shells, axis from normals, fit OD / ID cylinders, ends, slit."""
import sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rb, bm
sys.stdout.reconfigure(encoding="utf-8")
code = "EM03"
tri = rb.read_stl(rb.raw_path(code))
v, f = rb.weld(tri)
lab = rb.components(f, len(v))
cnt = np.bincount(lab)
order = np.argsort(-cnt)[:2]
out = {}
for k, L in enumerate(order):
    m = rb.Mesh(tri[lab == L])
    c0 = np.average(m.c, axis=0, weights=m.a)
    # axis: direction least represented in the normals of non-end facets
    C = (m.n * m.a[:, None]).T @ m.n
    w, e = np.linalg.eigh(C)
    ax = e[:, 0]
    for it in range(3):
        side = np.abs(m.n @ ax) < 0.3
        C = (m.n[side] * m.a[side, None]).T @ m.n[side]
        ax = np.linalg.eigh(C)[1][:, 0]
    T = rb.frame(ax, c0)
    q = m.moved(T)
    # centre: concentric fit outer/inner, with radial normal sign
    cen = np.zeros(2)
    for it in range(3):
        P = q.c[:, :2] - cen
        r = np.hypot(P[:, 0], P[:, 1])
        rad = (P * q.n[:, :2]).sum(1) / np.maximum(r, 1e-9)
        wall = np.abs(q.n[:, 2]) < 0.2
        o = wall & (rad > 0.85); i = wall & (rad < -0.85)
        c, R, sd, msk = bm.concentric_fit([q.c[o, :2], q.c[i, :2]], c0=cen)
        cen = c
    Tc = np.eye(4); Tc[:2, 3] = -cen
    T = Tc @ T
    q = m.moved(T)
    # cylinder refinement of the outer wall (axis tilt)
    P = q.c; r, th, z = rb.cyl(P)
    rad = (P[:, :2] * q.n[:, :2]).sum(1) / np.maximum(r, 1e-9)
    o = (np.abs(q.n[:, 2]) < 0.2) & (rad > 0.85)
    cy = rb.fit_cylinder(P[o], [0, 0, 1], clip=2.5)
    T = rb.frame(cy["axis"] * np.sign(cy["axis"][2]), cy["point"]) @ T
    q = m.moved(T)
    P = q.c; r, th, z = rb.cyl(P)
    rad = (P[:, :2] * q.n[:, :2]).sum(1) / np.maximum(r, 1e-9)
    wall = np.abs(q.n[:, 2]) < 0.2
    o = wall & (rad > 0.85); i = wall & (rad < -0.85)
    c, R, sd, msk = bm.concentric_fit([P[o, :2], P[i, :2]])
    # ends
    ends = np.abs(q.n[:, 2]) > 0.95
    zs = rb.hist_peaks(z[ends], q.a[ends], bin=0.02, min_frac=0.05, sep=0.5)
    zlo, zhi = np.percentile(z[o], 0.5), np.percentile(z[o], 99.5)
    # slit: angular histogram of wall facets in mid length
    mid = wall & (z > zlo + 1) & (z < zhi - 1)
    h, e = np.histogram(th[mid], bins=360, range=(-180, 180), weights=q.a[mid])
    # walls by z slab
    rows = []
    for z0 in np.arange(np.floor(zlo) + 0.5, zhi, 1.0):
        so = o & (np.abs(z - z0) < 0.5); si = i & (np.abs(z - z0) < 0.5)
        rows.append((z0, 2 * np.median(r[so]) if so.sum() > 30 else np.nan, 2 * np.median(r[si]) if si.sum() > 30 else np.nan))
    name = "sleeve%d" % (k + 1)
    rb.out("== %s: %d facets  axis(raw) %s" % (name, len(m.tri), np.round(np.linalg.inv(T)[:3, 2], 4)))
    rb.out("   OD %.3f (sd %.3f, n %d)  ID %.3f (sd %.3f, n %d)  wall %.3f  centre offset %s" % (2 * R[0], sd[0], msk[0].sum(), 2 * R[1], sd[1], msk[1].sum(), R[0] - R[1], np.round(c, 3)))
    rb.out("   outer wall z %.3f .. %.3f  (len %.3f)   end-face peaks %s" % (zlo, zhi, zhi - zlo, [(round(a, 3), round(b, 2)) for a, b in zs]))
    for row in rows:
        rb.out("     z %.1f  OD %.3f  ID %.3f" % row)
    rb.write_stl(rb.os.path.join(rb.SCAN, "EP5-EM03_%s_aligned.stl" % name), q.tri)
    out[name] = {"T": T, "OD": 2 * R[0], "ID": 2 * R[1], "sd": sd, "zlo": zlo, "zhi": zhi, "ends": zs, "slab": rows, "hist": h}
    fig, axs = plt.subplots(1, 2, figsize=(15, 5))
    axs[0].bar(np.arange(-179.5, 180), h, width=1); axs[0].set_title(name + " wall area per degree (mid length)")
    s = np.random.default_rng(0).choice(len(P), min(len(P), 80000), replace=False)
    axs[1].scatter(th[s], z[s], s=0.2, c=r[s], cmap="turbo"); axs[1].set_title("theta-z, colour r")
    fig.savefig(rb.os.path.join(rb.pdir(code, "fig"), name + "_slit.png"), dpi=90)
rb.save_json(code, "m_em03.json", out)
