"""Occupancy map of a wall of the box-frame scan: occ.py <axis 0|1> <side +-1> <png>; prints boundary features."""
import sys
import numpy as np, rb
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy import ndimage
ax_, side, png = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
q = rb.Mesh(rb.read_stl(rb.os.path.join(rb.SCAN, "EP5-EM02_box-frame.stl")))
o = [1, 0][ax_]
s = (q.c[:, ax_] * side > 20.5) & (np.abs(q.n[:, ax_]) > 0.9)
P, _ = q.sample(1500000, mask=s)
res = 0.1
a0, a1, z0, z1 = -28, 28, -17.5, 17.5
H, _, _ = np.histogram2d(P[:, o], P[:, 2], bins=[int((a1 - a0) / res), int((z1 - z0) / res)], range=[[a0, a1], [z0, z1]])
occ = ndimage.binary_closing(H > 0, iterations=2)
occ = ndimage.binary_fill_holes(occ) & occ | ndimage.binary_opening(occ, iterations=1)
fig, ax = plt.subplots(figsize=(12, 8))
ax.imshow(occ.T, origin="lower", extent=[a0, a1, z0, z1], cmap="gray_r"); ax.grid(True, lw=0.3)
ax.set_xticks(np.arange(-28, 29, 2)); ax.set_yticks(np.arange(-17, 18, 1)); ax.tick_params(labelsize=6)
ax.set_title("wall axis %d side %+d: horizontal = axis %d, vertical = z" % (ax_, side, o))
fig.savefig(png, dpi=90)
# column profile: z extent per horizontal position
cols = np.arange(a0, a1, res) + res / 2
for c in np.arange(-26, 27, 1.0):
    i = int((c - a0) / res)
    zz = np.nonzero(occ[i])[0]
    if len(zz):
        print("h %6.1f : z %.2f .. %.2f  filled %.1f" % (c, z0 + zz.min() * res, z0 + (zz.max() + 1) * res, len(zz) * res))
