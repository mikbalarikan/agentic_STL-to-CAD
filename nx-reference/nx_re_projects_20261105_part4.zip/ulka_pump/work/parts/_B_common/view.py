"""Multi-view render of an STL (cadgenbench venv: pyvista).
usage: view.py <in.stl> <out.png> [frame]      frame = views along the file's own X/Y/Z instead of PCA axes
       optional: boundary  -> draw open (boundary) edges in red"""
import sys
import numpy as np
import pyvista as pv

src, out = sys.argv[1:3]
args = sys.argv[3:]
pv.OFF_SCREEN = True
m = pv.read(src)
c = np.array(m.center)
if "frame" in args:
    u, v, ax = np.eye(3)
else:
    pts = np.asarray(m.points) - c
    w, e = np.linalg.eigh(np.cov(pts[:: max(1, len(pts) // 200000)].T))
    ax = e[:, 0]          # thinnest direction = normal of a flat part / axis candidates follow
    u, v = e[:, 2], e[:, 1]
L = m.length
views = [("+a (looking along -a)", ax, u), ("-a", -ax, u), ("+u", u, ax), ("-u", -u, ax), ("+v", v, ax), ("-v", -v, ax),
         ("iso 1", 0.55 * ax + 0.6 * u + 0.5 * v, ax), ("iso 2", -0.55 * ax + 0.6 * u - 0.5 * v, ax)]
pl = pv.Plotter(off_screen=True, shape=(2, 4), window_size=(2800, 1500))
bd = None
if "boundary" in args:
    bd = m.extract_feature_edges(boundary_edges=True, feature_edges=False, non_manifold_edges=False, manifold_edges=False)
for k, (name, d, up) in enumerate(views):
    pl.subplot(k // 4, k % 4)
    pl.set_background("white")
    pl.add_mesh(m, color="#b8c4cf", specular=0.2, ambient=0.25, diffuse=0.8, smooth_shading=False)
    if bd is not None and bd.n_cells:
        pl.add_mesh(bd, color="red", line_width=2.0)
    d = np.array(d, float) / np.linalg.norm(d)
    pl.camera.position = tuple(c + d * L * 1.2)
    pl.camera.focal_point = tuple(c)
    pl.camera.up = tuple(up)
    pl.camera.parallel_projection = True
    pl.camera.parallel_scale = L * 0.42
    pl.add_text(name, font_size=10, color="black")
    pl.add_axes()
pl.screenshot(out)
print("saved", out)
