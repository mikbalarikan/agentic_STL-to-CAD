"""HS04 spacer ring: scan stands on the scanner table. Level on the table, crop the ring, fit walls, write aligned copy."""
import sys, json
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rb, bm
sys.stdout.reconfigure(encoding="utf-8")
code = "HS04"
m = rb.Mesh(rb.read_stl(rb.raw_path(code)))
d = np.array([-0.51645, -0.07368, 0.85314])
T, q, pk = bm.table_frame(m, d)
print("table peaks", pk)
zt = pk[0][0] if pk[0][1] > 0.3 else min(p[0] for p in pk)
# refine table plane on the annulus 14..30 mm around rough centre
cen = np.array([0.341, 5.427])
r = np.hypot(q.c[:, 0] - cen[0], q.c[:, 1] - cen[1])
tab = (np.abs(q.c[:, 2] - zt) < 0.3) & (r > 14) & (r < 30) & (q.n[:, 2] > 0.95)
n, p0, sd = bm.refine_plane(q, tab)
print("table plane sd %.4f  tilt %.3f deg" % (sd, np.degrees(np.arccos(n[2]))))
T2 = rb.frame(n, p0) @ T
q = m.moved(T2)
# ring walls: rough centre = centroid of everything clearly above the table
up = q.c[:, 2] > 1.0
cen = np.average(q.c[up, :2], axis=0, weights=q.a[up])
print("rough centre", cen)
for it in range(4):
    r = np.hypot(q.c[:, 0] - cen[0], q.c[:, 1] - cen[1])
    rad = ((q.c[:, 0] - cen[0]) * q.n[:, 0] + (q.c[:, 1] - cen[1]) * q.n[:, 1]) / np.maximum(r, 1e-9)
    zok = (q.c[:, 2] > 0.6) & (q.c[:, 2] < 7.5) & (np.abs(q.n[:, 2]) < 0.3)
    out = zok & (rad > 0.8) & (r > 9.0) & (r < 12)
    inn = zok & (rad < -0.8) & (r > 7.0) & (r < 9.8)
    co = bm.robust_circle(q.c[out, :2])
    ci = bm.robust_circle(q.c[inn, :2])
    cen = np.array(co[:2])
    print("it%d outer c (%.3f %.3f) D %.3f sd %.3f n %d | inner c (%.3f %.3f) D %.3f sd %.3f n %d" % (it, co[0], co[1], 2 * co[2], co[3], co[4], ci[0], ci[1], 2 * ci[2], ci[3], ci[4]))
Tc = np.eye(4); Tc[:2, 3] = -cen
T3 = Tc @ T2
q = m.moved(T3)
r, th, z = rb.cyl(q.c)
keep = (r < 14) & (q.c[:, 2] > 0.05) | ((r < 14) & (q.n[:, 2] < 0.9))
ring = q.sub((r < 13) & (q.c[:, 2] > 0.08))
rb.write_stl(rb.os.path.join(rb.SCAN, "EP5-HS04_aligned.stl"), ring.tri)
# top level
r, th, z = rb.cyl(ring.c)
top = (ring.n[:, 2] > 0.97) & (r > 8.9) & (r < 10.1)
zt_ = np.median(ring.c[top, 2]); print("top face z %.3f (sd %.3f, n %d)" % (zt_, ring.c[top, 2].std(), top.sum()))
print("top face r range %.2f..%.2f" % (np.percentile(r[top], 1), np.percentile(r[top], 99)))
# outer/inner by z slabs (taper check)
rad = (ring.c[:, 0] * ring.n[:, 0] + ring.c[:, 1] * ring.n[:, 1]) / np.maximum(r, 1e-9)
res = {}
for nm, s0 in (("outer", rad > 0.9), ("inner", rad < -0.9)):
    rows = []
    for z0 in np.arange(0.5, 8.0, 0.5):
        s = s0 & (np.abs(z - z0) < 0.25)
        if s.sum() > 30:
            c = bm.robust_circle(ring.c[s, :2])
            rows.append((z0, 2 * c[2], c[3], int(s.sum()), len(np.unique(np.round(th[s] / 10)))*10))
    res[nm] = rows
    for row in rows: print("  %s z %.1f D %.3f sd %.3f n %d cover %d" % ((nm,) + row))
# r-z profile
fig, ax = plt.subplots(figsize=(8, 6))
for t0 in range(0, 360, 30):
    s = ring.rz(t0)
    if len(s): rb.plot_segs(ax, s, lw=0.5)
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_title("HS04 r-z, 12 half planes")
fig.savefig(rb.os.path.join(rb.pdir(code, "fig"), "rz.png"), dpi=130)
rb.save_json(code, "m_hs04.json", {"T_raw_to_aligned": T3, "top_z": zt_, "slabs": res})
