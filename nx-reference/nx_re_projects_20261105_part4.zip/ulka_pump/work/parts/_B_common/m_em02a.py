"""EM02 frame: three box directions from facet normals, wall planes (outer/inner -> sheet thickness)."""
import sys
import numpy as np
from scipy.spatial import cKDTree
import rb, bm
sys.stdout.reconfigure(encoding="utf-8")
code = "EM02"
m = rb.Mesh(rb.read_stl(rb.raw_path(code)))
# dominant normal directions (folded), greedy
N = 20000; i = np.arange(N) + 0.5
phi = np.arccos(1 - 2 * i / N); th = np.pi * (1 + 5 ** 0.5) * i
dirs = np.c_[np.cos(th) * np.sin(phi), np.sin(th) * np.sin(phi), np.cos(phi)]
tree = cKDTree(dirs)
_, j = tree.query(m.n); _, jo = tree.query(-dirs)
h = np.bincount(j, weights=m.a, minlength=N); hf = h + h[jo]
found = []
for k in range(3):
    hh = hf.copy()
    for d in found:
        hh[np.abs(dirs @ d) > np.cos(np.radians(30))] = 0
    d = dirs[int(np.argmax(hh))]
    for _ in range(5):
        c = m.n @ d; s = np.abs(c) > np.cos(np.radians(5))
        d = (m.n[s] * (np.sign(c[s]) * m.a[s])[:, None]).sum(0); d /= np.linalg.norm(d)
    found.append(d)
    print("dir %d %s share %.3f" % (k, np.round(d, 5), m.a[np.abs(m.n @ d) > np.cos(np.radians(5))].sum() / m.a.sum()))
D = np.array(found)
print("pairwise angles", [round(np.degrees(np.arccos(abs(D[a] @ D[b]))), 3) for a, b in ((0, 1), (0, 2), (1, 2))])
c0 = np.average(m.c, axis=0, weights=m.a)
for k, d in enumerate(D):
    s = np.abs(m.n @ d) > np.cos(np.radians(5))
    x = (m.c[s] - c0) @ d
    sg = np.sign(m.n[s] @ d)
    print("dir %d planes (offset, facing, share):" % k)
    for val, sh in sorted(rb.hist_peaks(x, m.a[s], bin=0.01, min_frac=0.01, sep=0.25)):
        ss = np.abs(x - val) < 0.1
        print("    %8.3f  facing %+.0f  area %.0f" % (val, np.sign(np.median(sg[ss])), m.a[s][ss].sum()))
rb.save_json(code, "m_em02a.json", {"D": D, "c0": c0})
