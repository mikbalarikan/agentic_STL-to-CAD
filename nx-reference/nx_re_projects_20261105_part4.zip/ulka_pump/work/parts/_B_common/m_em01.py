"""EM01 coil: axis from the bore + body cylinders, levels, r-z profile."""
import sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rb, bm
sys.stdout.reconfigure(encoding="utf-8")
code = "EM01"
m = rb.Mesh(rb.read_stl(rb.raw_path(code)))
cs = rb.load_json(code, "s1_census.json")
T = np.array(cs["T_provisional"])
q = m.moved(T)
cen = np.zeros(2)
for it in range(4):
    P = q.c[:, :2] - cen; r = np.hypot(P[:, 0], P[:, 1])
    rad = (P * q.n[:, :2]).sum(1) / np.maximum(r, 1e-9)
    wall = np.abs(q.n[:, 2]) < 0.2
    body = wall & (rad > 0.9) & (np.abs(r - 23.6) < 1.0) & (q.c[:, 2] > -12) & (q.c[:, 2] < 22)
    bore = wall & (rad < -0.9) & (np.abs(r - 10.9) < 1.0)
    c, R, sd, msk = bm.concentric_fit([q.c[body, :2], q.c[bore, :2]], c0=cen)
    cen = c
    print("it", it, np.round(c, 3), "Dbody %.3f Dbore %.3f sd %s n %d %d" % (2 * R[0], 2 * R[1], np.round(sd, 3), msk[0].sum(), msk[1].sum()))
Tc = np.eye(4); Tc[:2, 3] = -cen; T = Tc @ T; q = m.moved(T)
# axis tilt from body cylinder
P = q.c; r, th, z = rb.cyl(P)
rad = (P[:, :2] * q.n[:, :2]).sum(1) / np.maximum(r, 1e-9)
body = (np.abs(q.n[:, 2]) < 0.2) & (rad > 0.9) & (np.abs(r - 23.6) < 0.8) & (z > -12) & (z < 22)
cy = rb.fit_cylinder(P[body], [0, 0, 1], clip=2.5)
print("body cylinder D %.3f rms %.3f axis %s" % (2 * cy["r"], cy["rms"], np.round(cy["axis"], 5)))
bore = (np.abs(q.n[:, 2]) < 0.2) & (rad < -0.9) & (np.abs(r - 10.9) < 0.8)
cb = rb.fit_cylinder(P[bore], [0, 0, 1], clip=2.5)
print("bore cylinder D %.3f rms %.3f axis %s point %s" % (2 * cb["r"], cb["rms"], np.round(cb["axis"], 5), np.round(cb["point"], 3)))
ang = np.degrees(np.arccos(abs(cy["axis"] @ cb["axis"])))
print("body vs bore axis angle %.3f deg" % ang)
# use bore axis (functional)
a = cb["axis"] * np.sign(cb["axis"][2])
T = rb.frame(a, cb["point"]) @ T
q = m.moved(T)
rb.save_json(code, "m_em01_T.json", {"T": T})
P = q.c; r, th, z = rb.cyl(P)
# levels
for sg in (1, -1):
    s = (q.n[:, 2] * sg > 0.97)
    for zz, sh in rb.hist_peaks(z[s], q.a[s], bin=0.02, min_frac=0.01, sep=0.25):
        ss = s & (np.abs(z - zz) < 0.2)
        print("level %+d z %8.3f  area %7.1f  r %.2f..%.2f" % (sg, zz, q.a[ss].sum(), np.percentile(r[ss], 2), np.percentile(r[ss], 98)))
fig, ax = plt.subplots(figsize=(12, 10))
for t0 in range(0, 360, 20):
    s = q.rz(t0)
    if len(s): rb.plot_segs(ax, s, lw=0.4, color=plt.cm.hsv(t0 / 360))
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_title("EM01 r-z, 18 half planes (colour = angle)")
fig.savefig(rb.os.path.join(rb.pdir(code, "fig"), "rz.png"), dpi=110)
