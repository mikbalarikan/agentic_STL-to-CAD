## Çerçeve
Yerinde, nötr (kalıp) halinde torus: alt yüz `z_em03b_top` (EM03-B üstü, HS01 flanşı altı). ID / kesit kontrol parçasından.

Standart eşleme: tarama ID 16,20-16,26, kesit 2,04-2,24, OD 20,6 -> **metrik 16,5 x 2,0** en yakın (alternatif 16 x 2). Rev F değeri (16,2 x 2,2, tarama; CR-D-03) modellendi. Ön kontrol: kendi oturmasıyla %97,7 ±0,15.
