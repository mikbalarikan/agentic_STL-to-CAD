"""ULKA session B (from R385 session B) - shared journal helpers (NX 2206, headless).

A part is opened with the control part loaded first; interface values come into the part as interpart
expressions (`link`), part-internal dimensions as named expressions (`e`). The control part is never saved."""
import math
import os
import time

import NXOpen
import nxh
import nxf
import nxa
import nxre
import ps

CTRL = os.environ.get("ULKA_CTRL", r"C:\NX_MCP_WORKSPACE\ulka\ctrl\EP5-AS00_CTRL.prt")  # actual name from Rev A
BOOL = nxh.BOOL
X, Y, Z = (1, 0, 0), (0, 1, 0), (0, 0, 1)
F = ps.FREE


class Ctx:
    def __init__(self, out, name):
        self.out, self.name = out, name
        self.t0 = time.time()
        self.ctrl = nxh.open_part(CTRL)
        self.ctrl_rev = None
        self.path = os.path.join(out, name + ".prt")
        self.part = nxh.new_part(self.path)
        self.dat = nxh.Datums(self.part)
        self.M, self.linked, self.internal = {}, {}, {}
        self.chk, self.log, self.sk, self.notes = nxh.Check(), [], {}, {}

    # ---- expressions
    def val(self, name):
        ex = self.part.Expressions.FindObject(name)
        try:
            return float(ex.GetValueUsingUnits(NXOpen.Expression.UnitsOption.Expression))
        except Exception:  # noqa: BLE001
            return float(ex.Value)

    def link(self, name, unit="mm"):
        """interface value: interpart expression to the control part"""
        nxa.interpart_expr(self.part, name, self.ctrl, unit=unit)
        self.M[name] = self.val(name)
        self.linked[name] = self.M[name]
        return self.M[name]

    def e(self, name, value, comment="", unit="mm"):
        """part-internal master (a number). unit None = unitless, 'deg' = angle"""
        nxh.expr(self.part, name, value, unit, comment)
        self.M[name] = float(value)
        self.internal[name] = {"value": float(value), "unit": unit or "-", "comment": comment}
        return float(value)

    def d(self, name, formula, comment="", unit="mm"):
        """derived expression (a formula); its value is read back from NX"""
        nxh.expr(self.part, name, formula, unit, comment)
        self.M[name] = self.val(name)
        self.internal[name] = {"formula": formula, "value": self.M[name], "unit": unit or "-", "comment": comment}
        return self.M[name]

    def say(self, msg):
        self.log.append("%6.1fs  %s" % (time.time() - self.t0, msg))

    # ---- sketches
    def sketch(self, plane, name, **kw):
        return ps.Sketch(self.part, self.dat, plane, name, **kw)

    def done(self, S):
        st = S.finish()
        self.sk[S.name] = {"status": st["status"], "dof": st["dof"], "auto_dims": st["auto_dims"], "dims": len(st["dims"])}
        return S

    def vol(self, body):
        return nxh.volume(self.part, body)

    # ---- finish
    def finish(self, bodies, res, step=True, stl=True):
        """bodies: {name: body}. Saves the part, writes one STL per body and a STEP of the part."""
        p = self.part
        errs = [str(x) for x in nxh.feature_errors(p)]
        self.chk.true("no feature errors", not errs, errs)
        for nm, b in bodies.items():
            self.chk.true("body %s passes Examine Geometry" % nm, nxh.body_ok(p, b))
        self.chk.true("all sketches fully constrained (DOF 0, no automatic dimensions)",
                      all(s["status"] == "WellConstrained" and s["dof"] == 0 and s["auto_dims"] == 0 for s in self.sk.values()), self.sk)
        nxh.save(p)
        res["part"] = self.path
        res["volumes"] = {nm: self.vol(b) for nm, b in bodies.items()}
        res["bbox"] = {nm: nxh.bbox(b) for nm, b in bodies.items()}
        if stl:
            res["stl"] = {}
            for nm, b in bodies.items():
                f = os.path.join(self.out, "%s_%s.stl" % (self.name, nm))
                size, nerr = nxre.stl_export(p, b, f, chord=0.002)
                res["stl"][nm] = f
        if step:
            stp = os.path.join(self.out, self.name + ".stp")
            if os.path.exists(stp):
                os.remove(stp)
            nxf.step_export(p, stp)
            rt = nxf.step_roundtrip_check(stp, self.out, name=self.name + "_stepcheck", restore=p, part=p)
            res["step"] = stp
            res["step_roundtrip"] = {k: rt.get(k) for k in ("schema", "solids", "volume", "volumes", "max_rel", "match", "healthy", "restored")}
            self.chk.true("STEP round trip: same solids and volumes, healthy", bool(rt.get("match")) and bool(rt.get("healthy")), res["step_roundtrip"])
        res["linked"] = self.linked
        res["internal"] = self.internal
        res["sketches"] = self.sk
        top, n_int = nxh.top_features(p)
        res["features"] = ["%d %s %s" % (i, f.FeatureType, f.Name) for i, f in enumerate(top)]
        res["notes"] = self.notes
        res["log"] = self.log
        res.update(self.chk.report())


def revolve_volume(verts):
    """Volume of a closed (r, z) polygon turned 360 deg about r = 0."""
    v = 0.0
    n = len(verts)
    for i in range(n):
        r0, z0 = verts[i][0], verts[i][1]
        r1, z1 = verts[(i + 1) % n][0], verts[(i + 1) % n][1]
        v += (r0 * r0 + r0 * r1 + r1 * r1) * (z1 - z0)
    return abs(v) * math.pi / 3.0


def sind(a):
    return math.sin(math.radians(a))


def cosd(a):
    return math.cos(math.radians(a))


def tand(a):
    return math.tan(math.radians(a))


def cyl_faces(body, radius=None, tol=1e-4):
    out = []
    for f in body.GetFaces():
        t, pt, d, rad = nxh.face_data(f)
        if t == nxh.CYLINDER and (radius is None or abs(abs(rad) - radius) < tol):
            out.append((f, pt, d, rad))
    return out


def plane_faces(body):
    out = []
    for f in body.GetFaces():
        t, pt, d, rad = nxh.face_data(f)
        if t == nxh.PLANE:
            out.append((f, pt, d))
    return out
