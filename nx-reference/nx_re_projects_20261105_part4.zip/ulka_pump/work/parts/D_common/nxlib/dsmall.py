"""ULKA-D: builders for the small revolved parts (HS05, VL01, VL03, VL05, SL01-SL04). Each is called from a
one-line parts/<code>/build.py; every value is a named expression (linked or part-internal)."""
import math
import NXOpen
import nxh, nxf
import rj, ps
from rj import BOOL, Z


def plane_at(c, expr, name):
    fp, pl = nxf.datum_plane(c.part, "offset", [c.dat.xy], expr, name)
    fa, ax = nxf.datum_axis(c.part, "intersection", pl, c.dat.xz, name="AX_" + name)
    return pl, ax


def probe(c, body, name, q, tol=1e-6):
    c.chk(name, abs(nxh.dist_to(c.part, body, q)), 0.0, tol)


def regen(c, name, delta, grow=True):
    p = c.part
    body = nxh.solids(p)[0]
    v0 = c.vol(body)
    old = c.M[name]
    nxh.set_expr(p, name, old + delta); nxh.update()
    v2 = c.vol(nxh.solids(p)[0])
    errs = [str(x) for x in nxh.feature_errors(p)]
    nxh.set_expr(p, name, old); nxh.update()
    ok = (v2 > v0) if grow else (v2 < v0)
    c.chk.true("regeneration %s %+g: volume changes the right way, no errors" % (name, delta), ok and not errs, "%.4f -> %.4f %s" % (v0, v2, errs))
    body = nxh.solids(p)[0]
    c.chk("regeneration back to nominal", c.vol(body), v0, 1e-6 * v0)
    return body


def hs05(c):
    """HS05 washer, in place: lower face z_hs05 (on the HS01 socket mouth)."""
    for n in ("z_hs05", "hs05_od", "hs05_hole_d", "hs05_t"):
        c.link(n)
    c.e("hs05_ch", 0.2, "edge breaks (outer edges, both faces) [scan rounded rim]")
    m = c.M
    pl, ax = plane_at(c, "z_hs05", "PL_HS05")
    ri, ro, t, ch = m["hs05_hole_d"] / 2, m["hs05_od"] / 2, m["hs05_t"], m["hs05_ch"]
    pv = [(ri, 0.0, "hs05_hole_d/2", None), (ro - ch, 0.0, "hs05_od/2-hs05_ch", None), (ro, ch, "hs05_od/2", "hs05_ch"),
          (ro, t - ch, None, "hs05_t-hs05_ch"), (ro - ch, t, None, "hs05_t"), (ri, t, None, None)]
    S = c.sketch("xz", "SK_PROFILE", hax=ax, shift=(0.0, 0.0, m["z_hs05"]))
    S.profile(pv)
    c.done(S)
    f = nxf.revolve(c.part, S.section(None, ((ri + ro) / 2, t / 2)), nxf.axis_from(c.part, c.dat.z))
    f.SetName("WASHER")
    body = f.GetBodies()[0]
    v = rj.revolve_volume([(q[0], q[1]) for q in pv])
    c.chk("volume = revolved profile", c.vol(body), v, 1e-6 * v)
    z0 = m["z_hs05"]
    probe(c, body, "lower face at z_hs05", (0.0, (ri + ro) / 2, z0))
    probe(c, body, "upper face at z_hs05 + hs05_t", (0.0, (ri + ro) / 2, z0 + t))
    probe(c, body, "hole", (ri, 0.0, z0 + t / 2))
    probe(c, body, "OD", (0.0, -ro, z0 + t / 2))
    return regen(c, "hs05_ch", 0.1, grow=False)


def vl01(c):
    """VL01 ball, own frame: centre at the origin."""
    c.link("vl01_d")
    m = c.M
    r = m["vl01_d"] / 2
    F = ps.FREE
    pv = [(0.0, -r, None, F), (0.0, r, None, F)]
    S = c.sketch("xz", "SK_PROFILE")
    segs = S.profile(pv, arcs={1: (0.0, 0.0, "vl01_d/2")})
    S.centre_on(segs[1], "h"); S.centre_on(segs[1], "v")
    c.done(S)
    f = nxf.revolve(c.part, S.section(None, (r / 2, 0.0)), nxf.axis_from(c.part, c.dat.z))
    f.SetName("BALL")
    body = f.GetBodies()[0]
    c.chk("volume = pi d^3 / 6", c.vol(body), math.pi * m["vl01_d"] ** 3 / 6, 1e-6)
    probe(c, body, "surface at +X", (r, 0.0, 0.0))
    probe(c, body, "surface at +Z", (0.0, 0.0, r))
    probe(c, body, "surface at 45 deg", (r * math.sqrt(0.5), r * math.sqrt(0.5), 0.0))
    return body


def oring(c, code, zexpr, top=False):
    """O-ring as a neutral (moulded) torus, in place. zexpr = control expression of its lower face, or of its upper
    face when top=True (SL04 bears on the recess floor with its upper side)."""
    k = code.lower()
    c.link("%s_id" % k); c.link("%s_cs" % k)
    for n in zexpr.replace("+", " ").replace("-", " ").split():
        if not n.replace(".", "").isdigit():
            c.link(n)
    m = c.M
    c.d("z_%s_ref" % k, zexpr, "reference face of the ring (%s face)" % ("upper" if top else "lower"))
    pl, ax = plane_at(c, "z_%s_ref" % k, "PL_" + code)
    idd, cs = m["%s_id" % k], m["%s_cs" % k]
    rc = (idd + cs) / 2
    zc = -cs / 2 if top else cs / 2
    S = c.sketch("xz", "SK_SECTION", hax=ax, shift=(0.0, 0.0, m["z_%s_ref" % k]))
    S.circle(rc, zc, cs, cuf="(%s_id+%s_cs)/2" % (k, k), cvf="%s_cs/2" % k, df="%s_cs" % k)
    c.done(S)
    f = nxf.revolve(c.part, S.section(None, (rc, zc)), nxf.axis_from(c.part, c.dat.z))
    f.SetName("TORUS")
    body = f.GetBodies()[0]
    v = 2 * math.pi * rc * math.pi * cs * cs / 4
    c.chk("volume = 2 pi Rc x pi cs^2/4 (Pappus)", c.vol(body), v, 1e-6 * v)
    z0 = m["z_%s_ref" % k]
    probe(c, body, "ID", (idd / 2, 0.0, z0 + zc))
    probe(c, body, "OD", (0.0, idd / 2 + cs, z0 + zc))
    probe(c, body, "reference face touches z", (0.0, -rc, z0))
    c.notes["ring"] = {"ID": idd, "cs": cs, "OD": idd + 2 * cs, "z_ref": z0, "ref_face": "upper" if top else "lower"}
    return regen(c, "%s_cs" % k, 0.1)


def vl03(c):
    """VL03 outlet valve poppet, own frame: z0 = dome tip (inlet side, on the HS02 seat), +z to the outlet."""
    c.link("vl03_head_d"); c.link("vl03_head_r")
    c.e("cyl_z", 2.4, "end of the head cylinder from the tip [scan max dia 5.0 at 2.0-2.5 from the tip]")
    c.e("neck_d", 3.3, "neck diameter [scan 3.21-3.36]")
    c.e("taper_z", 4.3, "head underside taper ends on the neck [scan dia 3.65 at 4.0, 3.36 at 4.5]")
    c.e("neck_z", 6.0, "neck end / stem start from the tip [scan neck visible to 6.0]")
    c.e("stem_d", 2.0, "stem diameter, DERIVED (inside VL04, through the VL05 hub)")
    c.e("vl03_len", 12.7, "overall length, DERIVED (stood on its stem on the scanner table: tip 12.97 above it)")
    c.e("stem_ch", 0.2, "stem end chamfer")
    m = c.M
    R, rh = m["vl03_head_r"], m["vl03_head_d"] / 2
    zh = R - math.sqrt(R * R - rh * rh)
    F = ps.FREE
    pv = [(0.0, 0.0, None, None), (rh, zh, "vl03_head_d/2", F), (rh, m["cyl_z"], None, "cyl_z"),
          (m["neck_d"] / 2, m["taper_z"], "neck_d/2", "taper_z"), (m["neck_d"] / 2, m["neck_z"], None, "neck_z"),
          (m["stem_d"] / 2, m["neck_z"], "stem_d/2", None), (m["stem_d"] / 2, m["vl03_len"] - m["stem_ch"], None, "vl03_len-stem_ch"),
          (m["stem_d"] / 2 - m["stem_ch"], m["vl03_len"], "stem_d/2-stem_ch", "vl03_len"), (0.0, m["vl03_len"], None, None)]
    S = c.sketch("xz", "SK_PROFILE")
    segs = S.profile(pv, arcs={0: (0.0, R, "vl03_head_r")})
    S.centre_on(segs[0], "v")
    c.done(S)
    f = nxf.revolve(c.part, S.section(None, (0.5, 3.0)), nxf.axis_from(c.part, c.dat.z))
    f.SetName("POPPET")
    body = f.GetBodies()[0]
    cap = math.pi * zh * zh * (3 * R - zh) / 3
    rest = rj.revolve_volume([(q[0], q[1]) for q in pv[1:]] + [(0.0, zh)])
    c.chk("volume = spherical cap + revolved rest", c.vol(body), cap + rest, 1e-5 * (cap + rest))
    probe(c, body, "dome tip at z0", (0.0, 0.0, 0.0))
    probe(c, body, "head max diameter", (rh, 0.0, (zh + m["cyl_z"]) / 2))
    probe(c, body, "stem end", (0.0, 0.0, m["vl03_len"]))
    c.notes["seat_contact"] = "on a %.2f edge the dome centre is %.3f above the edge; tip dips %.3f" % (
        4.0, math.sqrt(R * R - 4.0), R - math.sqrt(R * R - 4.0))
    return regen(c, "stem_d", 0.2)


def vl05(c):
    """VL05 cage / spring retainer, in place: lower face at z_vl05 (control part; D proposes z_hs02 + 31.92, cr/CR-D-02)."""
    for n in ("z_vl05", "vl05_od", "vl05_t"):
        c.link(n)
    c.e("ring_w", 0.8, "ring wall [scan ring 8.0-8.4 outer, cross arms inside; F18]")
    c.e("arm_w", 1.2, "cross arm width [scan]")
    c.e("hub_d", 3.4, "hub diameter at the cross centre [scan]")
    c.e("hub_hole_d", 2.4, "hub hole (VL03 stem guide), DERIVED")
    m = c.M
    pl, ax = plane_at(c, "z_vl05", "PL_VL05")
    z0 = m["z_vl05"]
    ro, ri, aw, t = m["vl05_od"] / 2, m["vl05_od"] / 2 - m["ring_w"], m["arm_w"] / 2, m["vl05_t"]
    S = c.sketch("xy", "SK_RING", on=pl, shift=(0.0, 0.0, z0))
    S.circle(0.0, 0.0, m["vl05_od"], df="vl05_od")
    S.circle(0.0, 0.0, 2 * ri, df="vl05_od-2*ring_w")
    c.done(S)
    f = nxh.extrude(c.part, S.section(None, ((ro + ri) / 2, 0.0)), Z, 0, "vl05_t", origin=(0.0, 0.0, z0))
    f.SetName("RING")
    body = f.GetBodies()[0]
    c.chk("ring volume", c.vol(body), math.pi * (ro * ro - ri * ri) * t, 1e-6 * t * ro * ro)
    # cross arms (two bars, run 0.3 into the ring) + hub
    L = ri + 0.3
    Sa = c.sketch("xy", "SK_ARMS", on=pl, shift=(0.0, 0.0, z0))
    Sa.profile([(-L, -aw, "vl05_od/2-ring_w+0.3", "arm_w/2"), (L, -aw, "vl05_od/2-ring_w+0.3", None), (L, aw, None, "arm_w/2"), (-L, aw, None, None)])
    c.done(Sa)
    v0 = c.vol(body)
    fa = nxh.extrude(c.part, Sa.section(None, (0.0, 0.0)), Z, 0, "vl05_t", op=BOOL.Unite, target=body, origin=(0.0, 0.0, z0))
    Sb = c.sketch("xy", "SK_ARMS2", on=pl, shift=(0.0, 0.0, z0))
    Sb.profile([(-aw, -L, "arm_w/2", "vl05_od/2-ring_w+0.3"), (aw, -L, "arm_w/2", None), (aw, L, None, "vl05_od/2-ring_w+0.3"), (-aw, L, None, None)])
    c.done(Sb)
    body = nxh.solids(c.part)[0]
    fb = nxh.extrude(c.part, Sb.section(None, (0.0, ri - 0.5)), Z, 0, "vl05_t", op=BOOL.Unite, target=body, origin=(0.0, 0.0, z0))
    body = nxh.solids(c.part)[0]
    Sc = c.sketch("xy", "SK_HUB", on=pl, shift=(0.0, 0.0, z0))
    Sc.circle(0.0, 0.0, m["hub_d"], df="hub_d")
    c.done(Sc)
    fc = nxh.extrude(c.part, Sc.section(None, (0.0, 0.0)), Z, 0, "vl05_t", op=BOOL.Unite, target=body, origin=(0.0, 0.0, z0))
    body = nxh.solids(c.part)[0]
    Sh = c.sketch("xy", "SK_HOLE", on=pl, shift=(0.0, 0.0, z0))
    Sh.circle(0.0, 0.0, m["hub_hole_d"], df="hub_hole_d")
    c.done(Sh)
    fh = nxh.extrude(c.part, Sh.section(None, (0.0, 0.0)), Z, -1, "vl05_t+1", op=BOOL.Subtract, target=body, origin=(0.0, 0.0, z0))
    body = nxh.solids(c.part)[0]
    c.chk("one solid", len(nxh.solids(c.part)), 1, 0)
    probe(c, body, "lower face at the room floor", (0.0, (ro + ri) / 2, z0))
    probe(c, body, "upper face", ((ro + ri) / 2, 0.0, z0 + t))
    probe(c, body, "OD", (ro, 0.0, z0 + t / 2))
    probe(c, body, "hub hole", (m["hub_hole_d"] / 2, 0.0, z0 + t / 2), 1e-5)
    c.notes["open_area_mm2"] = round(c.vol(body) and (math.pi * ri * ri - (c.vol(body) / t - math.pi * (ro * ro - ri * ri)) - math.pi * m["hub_hole_d"] ** 2 / 4 * 0), 3)
    return regen(c, "arm_w", 0.2)


def law_curve(part, fx, fy, fz, name, tol=0.001):
    """Law Curve by equation (copied from ULKA-C spring_nx.py / nx-curves-and-sketches law_curve_gear.py)."""
    import NXOpen.GeometricUtilities as GU
    b = part.Features.CreateLawCurveBuilder(NXOpen.Features.LawCurve.Null)
    try:
        for law, fn in ((b.XLaw, fx), (b.YLaw, fy), (b.ZLaw, fz)):
            law.LawType = GU.LawBuilder.Type.ByEquation
            law.Parameter = "t"
            law.Function = fn
        b.DistanceTolerance = tol
        f = b.CommitFeature()
    finally:
        b.Destroy()
    f.SetName(name)
    return f, [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)][0]


def spring(c, code, dm_small, dm_big, n_taper, n_cyl, desc):
    """Compression spring, closed (not ground) ends, own frame: z0 = inlet-side end plane, +z to the outlet.
    Centre line = one Law Curve over s = nt*t turns (C1 everywhere, so one Tube makes the wire):
      pitch: pe (= wire + gap) for a_end turns, ramp to the active pitch p over b turns, p, ramp back, pe for a_end;
      mean diameter: dm1 up to the end of the first closed turn, smoothstep to dm2 over the n_taper turns, then dm2.
    p is DERIVED from the length <code>_len (= <code>_l0 by default; A drives an installed copy through it)."""
    k = code.lower()
    q = lambda n: k + "_" + n
    c.link(q("l0")); c.link(q("d"))
    c.e(q("dm1"), dm_small, "mean coil diameter at the small (inlet-side) end [%s]" % desc)
    c.e(q("dm2"), dm_big, "mean coil diameter at the big end [%s]" % desc)
    c.e(q("ntap"), n_taper, "active turns over which the diameter grows (smoothstep)", None)
    c.e(q("ncyl"), n_cyl, "active turns at the big diameter", None)
    c.e(q("a"), 0.75, "closed turns at each end (coils touch: pitch pe)", None)
    c.e(q("b"), 0.5, "pitch ramp between the closed and the active turns", None)
    c.e(q("gap"), 0.05, "gap between touching closed coils (keeps the wire body valid)")
    c.d(q("nt"), "2*%s+2*%s+%s+%s" % (q("a"), q("b"), q("ntap"), q("ncyl")), "total turns", None)
    c.d(q("pe"), "%s+%s" % (q("d"), q("gap")), "closed-end pitch")
    c.d(q("len"), q("l0"), "spring length: free length by default; A sets the installed length on a copy")
    c.d(q("n_act"), "%s-2*%s-2*%s" % (q("nt"), q("a"), q("b")), "turns at the active pitch", None)
    c.d(q("p"), "(%s-%s-2*%s*%s-%s*%s)/(%s+%s)" % (q("len"), q("d"), q("pe"), q("a"), q("pe"), q("b"), q("b"), q("n_act")),
        "active pitch, DERIVED from the length")
    nxh.expr(c.part, "t", "1", None, "law curve parameter (NX runs it 0..1)")
    S = "(%s*t)" % q("nt")
    s1, s2 = q("a"), "(%s+%s)" % (q("a"), q("b"))
    s3, s4 = "(%s-%s-%s)" % (q("nt"), q("a"), q("b")), "(%s-%s)" % (q("nt"), q("a"))
    pe, pp, b = q("pe"), q("p"), q("b")
    c.d(q("z0"), "%s/2" % q("d"), "wire centre at the start (end coil on z = 0)")
    c.d(q("zA"), "%s+%s*%s" % (q("z0"), pe, s1), "")
    c.d(q("zB"), "%s+(%s+%s)/2*%s" % (q("zA"), pe, pp, b), "")
    c.d(q("zC"), "%s+%s*(%s-%s)" % (q("zB"), pp, s3, s2), "")
    c.d(q("zD"), "%s+(%s+%s)/2*%s" % (q("zC"), pp, pe, b), "")
    z_ex = ("if (%(s)s<=%(s1)s) (%(z0)s+%(pe)s*%(s)s) else (if (%(s)s<=%(s2)s) (%(zA)s+%(pe)s*(%(s)s-%(s1)s)+(%(pp)s-%(pe)s)*(%(s)s-%(s1)s)^2/(2*%(b)s)) "
            "else (if (%(s)s<=%(s3)s) (%(zB)s+%(pp)s*(%(s)s-%(s2)s)) else (if (%(s)s<=%(s4)s) (%(zC)s+%(pp)s*(%(s)s-%(s3)s)-(%(pp)s-%(pe)s)*(%(s)s-%(s3)s)^2/(2*%(b)s)) "
            "else (%(zD)s+%(pe)s*(%(s)s-%(s4)s)))))") % dict(s=S, s1=s1, s2=s2, s3=s3, s4=s4, z0=q("z0"), pe=pe, pp=pp, b=b,
                                                         zA=q("zA"), zB=q("zB"), zC=q("zC"), zD=q("zD"))
    # mean radius: dm1 for s <= a, smoothstep over ntap turns, then dm2
    u = "((%s-%s)/%s)" % (S, q("a"), q("ntap"))
    if n_taper > 0:
        r_ex = "if (%(s)s<=%(a)s) (%(d1)s/2) else (if (%(s)s>=%(a)s+%(nt)s) (%(d2)s/2) else (%(d1)s/2+(%(d2)s-%(d1)s)/2*(3*%(u)s^2-2*%(u)s^3)))" % dict(
            s=S, a=q("a"), nt=q("ntap"), d1=q("dm1"), d2=q("dm2"), u=u)
    else:
        r_ex = "%s/2" % q("dm2")
    nxh.expr(c.part, q("cr"), r_ex, "mm", "centre line radius r(t)")
    nxh.expr(c.part, q("cx"), "%s*cos(360*%s)" % (q("cr"), S), "mm", "centre line x(t)")
    nxh.expr(c.part, q("cy"), "%s*sin(360*%s)" % (q("cr"), S), "mm", "centre line y(t) (right hand)")
    nxh.expr(c.part, q("cz"), z_ex, "mm", "centre line z(t), piecewise pitch (C1)")
    fl, crv = law_curve(c.part, q("cx"), q("cy"), q("cz"), "CENTRE_LINE")
    ft, body = nxf.tube(c.part, q("d"), curves=[crv])
    ft.SetName("WIRE_TUBE")
    m = c.M
    sol = nxh.solids(c.part)
    c.chk("one solid", len(sol), 1, 0)
    body = sol[0]
    d = m[q("d")]
    bx = nxh.bbox(body)
    c.chk("free length (bbox z)", bx[5] - bx[2], m[q("len")], 0.02)
    c.chk("big-end OD (bbox x)", bx[3] - bx[0], m[q("dm2")] + d, 0.03)
    c.chk("starts on z0", bx[2], 0.0, 0.01)
    Lc = crv.GetLength()
    c.chk("wire volume = pi d^2/4 x centre-line length", c.vol(body), math.pi * d * d / 4 * Lc, 1e-3 * math.pi * d * d / 4 * Lc)
    c.notes["spring"] = {"d": d, "OD_small": m[q("dm1")] + d, "OD_big": m[q("dm2")] + d, "L0": m[q("len")],
                         "pitch": round(c.val(q("p")), 4), "turns_total": c.val(q("nt")), "turns_active_pitch": c.val(q("n_act")),
                         "solid_length_approx": round((c.val(q("nt")) + 1) * d, 3), "wire_length": round(Lc, 3)}
    return body
