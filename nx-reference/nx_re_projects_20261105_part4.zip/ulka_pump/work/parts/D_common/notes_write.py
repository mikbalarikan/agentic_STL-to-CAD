"""ULKA-D: hand-written report notes of the small parts and HS03 (parts/<code>/report_notes.md)."""
import os

P = r"C:\NX_MCP_WORKSPACE\ulka\parts"
N = {}
N["HS03"] = """## Çerçeve ve yerleşim
Yerinde (Rev A): plaka alt yüzü (pimli, EM02 çıkış duvarına oturan) `z_hs03` = 0'da, +Z göbek ucuna; kulaklar ±X,
pimler (±`pin_x`, ±`pin_y`). Tarama `scan\\EP5-HS03_aligned.stl` aynı çerçevede (z ekseni 4 düzlem yüzün normali,
orijin 5 dairesel özelliğin ortak merkezi, +x kulak deliği), dönüşümsüz karşılaştırıldı.

## Modelleme kararları (ölçüden)
- Plaka hattı: kulak yayları kulak deliğiyle eş merkezli (`ear_cx` = `fs_pitch`/2), R 4,25; düz kenarlar eksenden 12,13
  (dört kenar 12,08-12,18), uç r 23,20 (tarama 23,18-23,30).
- Alt cepler 2 x (2,3 x 5,0 x 2,1), pimler arasında. Üst cepler: plaka hattı 1,6 içeri ofset, göbek çevresinde r 12,2 ve
  kulak deliği çevresinde R 4,4 dışarıda kalır, taban z 3,6 (tarama 3,56-3,64).
- Göbek: Ø23,94 -> ~33° konik -> Ø20,45, üst dış kenar 0,4 pah; iç Ø20,93 / Ø16,50 / Ø14,26 (kontrol parçası).

## Modellenmeyen / tutmayan
- Dar yan pencereleri (A_QA ilk tur notu üzerine eklendi): ince duvarda (Ø20,93 delik / kenar 12,13) L biçimli açıklık:
  geniş kısım 5,3 x 2,2 (z 2,3-4,5), altında 1,9 genişlikte yarık z 0,8'e iner; +y yanında x = +1,1, -y yanında x = -1,1
  merkezli, yarık sırasıyla -X / +X ucunda (eksene göre 180° simetrik; tarama +0,98 / -1,33).
- Göbek-plaka birleşiminde ~R1 dolgu modellenmedi (dolgu dar yanda plaka kenarını aşıyor: kenar r 12,13, göbek r 11,97).
- Ön kontrol (D, pencerelerden sonra): yerinde %84,8, kendi oturmasıyla %85,1 ±0,15 içinde (**%90 kapısının altında**).
  Gürültü sınırı: taramaya uydurulan silindirlerin (Ø20,93 / Ø16,50 / Ø14,26 / göbek) artıkları sd 0,065-0,124; sd 0,11
  ile kusursuz model de ±0,15 içinde ancak ≈%82'de kalır. Pencere bölgesi toplam farkın %3'ü. Fark bölgelere yayılı (plaka yanları %4,3,
  delikler %3,3, birleşim %1,8, göbek %3,6, pimler %1,3, üst %1,0 katkı); tarama gürültüsü HS03'te duvarlarda sd 0,10-0,12.
  A'nın kendi ICP'si ve %2 kırpması ile sonuç A_QA'da kesinleşir.
"""
N["HS05"] = """## Çerçeve
Yerinde: alt yüz `z_hs05` (HS01 soket ağzında), +Z. Tarama tek yüzden (alt yüz masada, 0,25 mm alt kesik): üst yüz,
dış çap ve delik karşılaştırılabilir. F15'teki bir yüzdeki delik çevresi kademe taramada görülmediği için modellenmedi;
dış kenarlarda 0,2 pah. Ön kontrol: kendi oturmasından sonra %93,8 ±0,15 içinde (eğim 0,8°: masa düzlemi kesiği).
"""
N["VL01"] = """## Çerçeve
Kendi çerçevesinde, merkez orijinde (A konumlar). Ø `vl01_d` = 3,572 (9/64"), tarama küre uydurması 3,606 (sd 0,031).
Ön kontrol: %100 ±0,15, %92,4 ±0,05 içinde.
"""
N["VL02"] = """## Çerçeve ve tasarım
Kendi çerçevesinde: z0 = giriş tarafı ucu (bilya tarafı, küçük uç), +Z çıkışa; boy `vl02_len` (= `vl02_l0` 15,0; A
sıkışmış kopyayı buradan verir), aktif hatve boydan türetilir. Tel merkez eğrisi tek Law Curve (C1; ULKA-C'nin yöntemi):
0,75 kapalı sarım (hatve tel + 0,05), 0,5 sarım hatve geçişi, aktif sarımlar, uçta aynısı; çap küçük uçta Dm 3,6
(OD 4,1), 2 sarımda smoothstep ile Dm 5,1'e (OD 5,6). Toplam 11,5 sarım, aktif hatve 1,41 (tarama ≈1,4), blok ≈6,25.
Uçlar kapalı, taşlanmamış. Tel Ø 0,5 (`vl02_d`, tarama zayıf).

## Tarama
Tarama parçalı (tel parçaları); bağımsız ölçüm için zayıf, karşılaştırma yapılmadı; ölçüler D_MEASURED §4.
Montaj (CR-D-02): HS02 odasında bilya tepesi ile oda dibi (z 24,0) arası; dinlenmede 9,33, yukarı dayanmada 6,75.
"""
N["VL04"] = """## Çerçeve ve tasarım
Kendi çerçevesinde: z0 = giriş tarafı ucu (VL03 başına dayanan küçük uç), +Z çıkışa (VL05'e). Boy `vl04_len` (=
`vl04_l0` 6,8). Konik: Dm 3,95 (OD 4,4) -> 3 sarımda smoothstep -> Dm 5,35 (OD 5,8); toplam 5,5 sarım, aktif hatve 1,53,
blok ≈2,9. Büyük uç OD 5,8 alındı (tarama ~6,2 zayıf/bulanık; Ø6,0 valf deliğinde çalışır). Tel Ø 0,45 (`vl04_d`).

## Tarama
Parçalı; karşılaştırma yapılmadı. Montaj (CR-D-02): VL03 başı ile VL05 arası montaj boyu 3,9, valf kalkışı ≈1,0.
"""
N["VL03"] = """## Çerçeve
Kendi çerçevesinde: z0 = kubbe tepesi (giriş tarafı, HS02 Ø4,0 oturma kenarına), +Z sapa doğru. Kubbe R 2,76
(`vl03_head_r`), baş Ø5,0 (`vl03_head_d`) z 1,59-2,4, alt koni boyun Ø3,3'e (z 4,3), boyun z 6,0'a kadar.
**Türetilen**: sap Ø2,0 ve toplam boy 12,7 (taramada yay içinde görünmüyor; tarayıcı masasında sapı üzerinde
durduğu için tepe 12,97'de). Siyah elastomer baş + gövde tek gövde olarak modellendi.
Ön kontrol (yalnız baş+boyun taraması): kendi oturmasından sonra %95,6 ±0,15 (tarama baş merkezi 0,4 yanda).
"""
N["VL05"] = """## Çerçeve
Yerinde: alt yüz `z_vl05` = `z_hs02` + `hs02_vl05_z` (31,92; Rev D, CR-D-02), HS02 Ø8,52 deliğinde, üstünde G1/8 diş. Halka Ø8,4
(`vl05_od`) x 4,5 (`vl05_t`), et 0,8, iki kol 1,2 genişlikte (artı), göbek Ø3,4, göbek deliği Ø2,4 (VL03 sap kılavuzu,
**türetildi**). Dış tırnaklar (~Ø8,6-9,0) modellenmedi.

## Tarama
Tarama çok zayıf (delikli, parçalı); ön kontrol %30-34 ±0,15 - **tutmadı**; şekil F18 fotoğrafından, ölçü kaynağı dış
çap ve kalınlık (D_MEASURED §4).
"""
REF = {"SL01": "alt yüz `z_em03b_top` (EM03-B üstü, HS01 flanşı altı)",
       "SL02": "alt yüz `z_sl02` (HS01 flanşı üstü, HS03 Ø20,93 içinde)",
       "SL03": "alt yüz `z_sl03` (HS02 flanşı üstü, HS03 üst kademesine yüz contası)",
       "SL04": "üst yüz HS02 havşa tabanında (`z_hs02` + `hs02_sl04_depth`)"}
for k, ref in REF.items():
    N[k] = "## Çerçeve\nYerinde, nötr (kalıp) halinde torus: %s. ID / kesit kontrol parçasından.\n\n" % ref
N["SL01"] += ("Standart eşleme: tarama ID 16,20-16,26, kesit 2,04-2,24, OD 20,6 -> **metrik 16,5 x 2,0** en yakın (alternatif "
              "16 x 2). Rev F değeri (16,2 x 2,2, tarama; CR-D-03) modellendi. Ön kontrol: kendi oturmasıyla %97,7 ±0,15.\n")
N["SL02"] += ("Standart eşleme: **ISO 3601-1 / AS568-115, 15,47 x 2,62** (tarama OD 20,70). Taramada yükseklik 2,89 (yatarken "
              "hafif ovallik). Ön kontrol: kendi oturmasından sonra %87,3 ±0,15 (elastomer bandı ±0,10; yalnız üst yarı taranmış).\n")
N["SL03"] += ("Rev F (CR-D-03): 13,15 x 1,10 (OD 15,35), A'nın ID / OD uydurmasından; standart dışı, tarama değeri (en yakın "
              "metrik 13 x 1,0). Tarama tepe yüksekliği 0,91 (halka altlıkta yassı), genişlik 1,34. Ön kontrol: kendi oturmasıyla "
              "%84,8 ±0,15 (Rev A kesitiyle %60) - elastomer bandında yassılık nedeniyle **tutmayabilir**.\n")
N["SL04"] += ("Standart eşleme: **metrik 4,5 x 2,0** (OD 8,5). Piston d_p 4,97 ile radyal sıkışma `sq_sl04` %8,5. "
              "Ön kontrol: %89,1 ±0,15.\n")
for k, v in N.items():
    with open(os.path.join(P, k, "report_notes.md"), "w", encoding="utf-8") as f:
        f.write(v)
print("written", sorted(N))
