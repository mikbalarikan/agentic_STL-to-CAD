"""Part report + delivery: copies the part / STEP to the project's cad folder and writes cad/<name>_REPORT.md
from the journal result (out/build.json), the deviation result (qa/dev.json) and the hand-written notes
(parts/<code>/report_notes.md: frame, known deviations).     usage: report.py <code>"""
import datetime
import json
import os
import shutil
import sys

sys.stdout.reconfigure(encoding="utf-8")
code = sys.argv[1]
W = r"C:\NX_MCP_WORKSPACE\ulka\parts\%s" % code
CAD = r"H:\My Drive\Mini Pumps\ulka re\cad"
b = json.load(open(os.path.join(W, "out", "build.json"), encoding="utf-8"))
dp = os.path.join(W, "qa", "dev.json")
d = json.load(open(dp, encoding="utf-8")) if os.path.exists(dp) else None
name = os.path.splitext(os.path.basename(b["part"]))[0]
notes = open(os.path.join(W, "report_notes.md"), encoding="utf-8").read().strip() if os.path.exists(os.path.join(W, "report_notes.md")) else ""
ctrl = json.load(open(r"C:\NX_MCP_WORKSPACE\ulka\ctrl\ctrl_params.json", encoding="utf-8"))


def num(x, n=3):
    return ("%.*f" % (n, x)).replace(".", ",")


def pct(x):
    return ("%.1f" % (100 * x)).replace(".", ",")


L = []
L.append("# %s - parça raporu" % name)
L.append("")
L.append("Yazar: ULKA-D Hidrolik. Tarih: %s. Kontrol parçası revizyonu: %s. Journal sonucu: **%s** (%d kontrol, %d başarısız)." % (
    datetime.date.today().isoformat(), ctrl.get("rev", "?"), b.get("result"), len(b.get("checks", [])), sum(1 for c in b.get("checks", []) if not c.get("ok"))))
L.append("Dosyalar: `cad\\%s.prt`, `cad\\%s.stp`; journal `C:\\NX_MCP_WORKSPACE\\ulka\\parts\\%s\\build.py`, sonuç `out\\build.json`," % (name, name, code))
L.append("tarama karşılaştırması `dev_%s.py` -> `qa\\dev.json`, `fig\\dev.png`." % code.lower())
L.append("")
if notes:
    L.append(notes)
    L.append("")
L.append("## Unsur ağacı")
L.append("")
L.append(" -> ".join(f.split(" ", 1)[1] for f in b.get("features", [])))
L.append("")
L.append("Sketch'ler: " + "; ".join("%s %s, DOF %s, otomatik ölçü %s, %s ölçü" % (k, v["status"], v["dof"], v["auto_dims"], v["dims"]) for k, v in b.get("sketches", {}).items()) + ".")
L.append("Gövdeler: " + "; ".join("%s %s mm3" % (k, num(v, 2)) for k, v in b.get("volumes", {}).items()) + ".")
rt = b.get("step_roundtrip") or {}
if rt:
    L.append("STEP (%s) geri okuma: %s katı, hacim farkı en çok %.1e, sağlıklı: %s." % (rt.get("schema"), rt.get("solids"), rt.get("max_rel") or 0.0, "evet" if rt.get("healthy") else "hayır"))
L.append("")
L.append("## Expression'lar")
L.append("")
L.append("Kontrol parçasından (interpart): " + ", ".join("`%s` = %s" % (k, num(v, 4).rstrip("0").rstrip(",")) for k, v in b.get("linked", {}).items()) + ".")
L.append("")
L.append("| Parça içi | Değer | Açıklama |")
L.append("|---|---|---|")
for k, v in b.get("internal", {}).items():
    val = num(v["value"], 4).rstrip("0").rstrip(",") + (" (= `%s`)" % v["formula"] if "formula" in v else "")
    L.append("| `%s` | %s | %s |" % (k, val, v.get("comment", "")))
L.append("")
if d is None:
    L.append("## Tarama karşılaştırması")
    L.append("")
    L.append("Yapılmadı: taraması parçalı / zayıf. Ölçüler `sessions/D_MEASURED.md` tablosundan.")
else:
    L.append("## Tarama karşılaştırması (tarama - CAD; + = tarama CAD'in dışında)")
    L.append("")
    L.append("| Bölge | n | ortalama | sd | \\|d\\| p50 | p95 | ±0,05 içinde % | ±0,15 içinde % |")
    L.append("|---|---|---|---|---|---|---|---|")


    def row(nm, s):
        if not s.get("n"):
            return "| %s | 0 | | | | | | |" % nm
        return "| %s | %d | %s | %s | %s | %s | %s | %s |" % (nm, s["n"], ("%+.3f" % s["mean"]).replace(".", ","), num(s["sd"]), num(s["p50"]), num(s["p95"]), pct(s["in_0.05"]), pct(s["in_0.15"]))


    L.append(row("**tümü**", d["all"]))
    if "excluded" in d:
        L.append(row("(toplam dışı bırakılan)", d["excluded"]))
    for k, v in d.get("zones", {}).items():
        L.append(row(k, v))
    for k, v in d.get("refit", {}).items():
        L.append(row(k + ": kendi en iyi oturmasından sonra", v["after"]))
    L.append("")
    for k, v in d.get("refit", {}).items():
        L.append("- %s: taramayı CAD'e oturtan küçük hareket: dönme %s°, öteleme (%s; %s; %s)." % (k, num(v["rotation_deg"]), num(v["translation"][0]), num(v["translation"][1]), num(v["translation"][2])))
    L.append("- CAD yüzeyinin %% %s'inde 0,3 mm içinde tarama yok (taranmamış ya da türetilmiş bölge)." % pct(d.get("cad_without_scan_share", 0)))
if b.get("notes"):
    L.append("")
    L.append("## Journal notları")
    L.append("")
    for k, v in b["notes"].items():
        L.append("- `%s`: %s" % (k, json.dumps(v, ensure_ascii=False)))
os.makedirs(CAD, exist_ok=True)
with open(os.path.join(CAD, name + "_REPORT.md"), "w", encoding="utf-8") as f:
    f.write("\n".join(L) + "\n")
for ext in (".prt", ".stp"):
    src = os.path.join(W, "out", name + ext)
    if os.path.exists(src):
        shutil.copy2(src, os.path.join(CAD, name + ext))
# hand-over for A's independent comparison: prt, STEP, STL(s) and the check result next to the journal
for fn in os.listdir(os.path.join(W, "out")):
    if fn.startswith(name) and fn.endswith((".prt", ".stp", ".stl")) and "stepcheck" not in fn:
        shutil.copy2(os.path.join(W, "out", fn), os.path.join(W, fn))
shutil.copy2(os.path.join(W, "out", "build.json"), os.path.join(W, name + "_build.json"))
shutil.copy2(os.path.join(CAD, name + "_REPORT.md"), os.path.join(W, name + "_REPORT.md"))
print("delivered", name, "->", CAD, "and", W)
