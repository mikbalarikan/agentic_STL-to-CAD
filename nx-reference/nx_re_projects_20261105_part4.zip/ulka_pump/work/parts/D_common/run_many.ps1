param([string[]]$Codes)
# ULKA-D: runs parts\<code>\build.py one after the other (each takes / releases the shared lock via run.ps1)
foreach ($c in $Codes) { "===== $c"; & C:\NX_MCP_WORKSPACE\ulka\parts\D_common\run.ps1 -Code $c -Timeout 900 }
