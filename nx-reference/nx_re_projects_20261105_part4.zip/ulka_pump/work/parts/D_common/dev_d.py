"""ULKA-D: scan-to-CAD deviation of one D part.   usage: dev_d.py <code>
The aligned scan (part frame, D_MEASURED) is moved into the pump frame with the placement of the part in Rev A,
then the shared dev.run (B's tool) reports signed deviation by zone and the subset refits."""
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rb
from dev import run

code = sys.argv[1]
W = r"C:\NX_MCP_WORKSPACE\ulka\parts\%s" % code
b = json.load(open(os.path.join(W, "out", "build.json"), encoding="utf-8"))
cad = list(b["stl"].values())
V = json.load(open(r"C:\NX_MCP_WORKSPACE\ulka\ctrl\ctrl_values_py.json", encoding="utf-8"))
V = V.get("values", V)


def val(n):
    x = V[n]
    return float(x["value"] if isinstance(x, dict) else x)


SCAN = r"C:\NX_MCP_WORKSPACE\ulka\scan\EP5-%s_aligned.stl" % code
T = np.eye(4)
zones, refit, exclude = {}, {}, None
r = lambda P: np.hypot(P[:, 0], P[:, 1])

if code == "HS02":
    z0 = val("z_hs02")
    T[2, 3] = z0
    zl = lambda P: P[:, 2] - z0
    zones = {
        "flange OD": lambda P, N: (r(P) > 7.4) & (zl(P) > 0.4) & (zl(P) < 2.6),
        "flange face": lambda P, N: (np.abs(zl(P)) < 0.15) & (N[:, 2] < -0.8),
        "SL04 recess bore": lambda P, N: (r(P) > 4.0) & (r(P) < 4.6) & (zl(P) > 0.3) & (zl(P) < 1.9),
        "body OD (z 15-22, 29-39)": lambda P, N: (r(P) > 6.3) & (((zl(P) > 15.5) & (zl(P) < 22)) | ((zl(P) > 29.5) & (zl(P) < 39.5))) & (np.abs(N[:, 2]) < 0.3),
        "flats": lambda P, N: (np.abs(np.abs(P[:, 0]) - 5.9) < 0.3) & (zl(P) > 22.6) & (zl(P) < 28.1),
        "tip face": lambda P, N: (zl(P) > 41.0) & (N[:, 2] > 0.8),
        "outlet bore (G1/8 thread, cosmetic)": lambda P, N: (r(P) < 5.3) & (r(P) > 3.6) & (zl(P) > 30.5) & (zl(P) < 40),
    }
    refit = {"flange end (z<4)": lambda P, N: zl(P) < 4, "outlet end (z>29)": lambda P, N: zl(P) > 29, "all": lambda P, N: zl(P) > -1}
elif code == "HS03":
    zones = {
        "underside": lambda P, N: (np.abs(P[:, 2]) < 0.15) & (N[:, 2] < -0.8),
        "plate top": lambda P, N: (np.abs(P[:, 2] - 5.82) < 0.2) & (N[:, 2] > 0.8),
        "bore1": lambda P, N: (r(P) > 9.8) & (r(P) < 11) & (P[:, 2] > 0.8) & (P[:, 2] < 7.5),
        "bore2": lambda P, N: (r(P) > 7.8) & (r(P) < 8.8) & (P[:, 2] > 9) & (P[:, 2] < 15.6),
        "bore3": lambda P, N: (r(P) > 6.8) & (r(P) < 7.6) & (P[:, 2] > 16.6) & (P[:, 2] < 19.6),
        "boss OD": lambda P, N: (r(P) > 9.8) & (r(P) < 12.6) & (P[:, 2] > 6.2) & (np.abs(N[:, 2]) < 0.3),
        "ear holes": lambda P, N: (np.hypot(np.abs(P[:, 0]) - 18.95, P[:, 1]) < 2.6) & (P[:, 2] > 0.3) & (P[:, 2] < 5.5),
        "pins": lambda P, N: (P[:, 2] < -0.3),
        "plate outline": lambda P, N: (r(P) > 12.4) & (np.abs(N[:, 2]) < 0.3) & (np.hypot(np.abs(P[:, 0]) - 18.95, P[:, 1]) > 2.6) & (P[:, 2] > 0.3) & (P[:, 2] < 5.5),
    }
    refit = {"all": lambda P, N: P[:, 2] > -5}
elif code == "HS05":
    T[2, 3] = val("z_hs05")
    refit = {"all": lambda P, N: P[:, 2] > -50}
elif code in ("SL01", "SL02", "SL03", "SL04"):
    lower = {"SL01": val("z_em03b_top"), "SL02": val("z_sl02"), "SL03": val("z_sl03"),
             "SL04": val("z_hs02") + val("hs02_sl04_depth") - val("sl04_cs")}[code]
    T[2, 3] = lower
    refit = {"all": lambda P, N: P[:, 2] > -500}
elif code == "VL01":
    refit = {"all": lambda P, N: P[:, 2] > -50}
elif code == "VL03":
    SCAN = r"C:\NX_MCP_WORKSPACE\ulka\scan\EP5-VL03_head_aligned.stl"
    T = np.diag([1.0, -1.0, -1.0, 1.0])
    T[2, 3] = 12.97
    refit = {"all": lambda P, N: P[:, 2] > -50}
elif code == "VL05":
    T[2, 3] = val("z_vl05") + val("vl05_t") / 2
    refit = {"all": lambda P, N: P[:, 2] > -500}
run(code, cad, SCAN, zones=zones, T=T, refit=refit, exclude=exclude)
