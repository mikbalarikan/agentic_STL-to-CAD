"""ULKA session B (adapted from R385 session B) - scan analysis helpers (system Python: numpy, scipy, matplotlib).

Raw scans are read-only in SRC; working copies go to SCAN as EP5-<code>_clean.stl (cleaned, scanner frame)
and EP5-<code>_aligned.stl (part frame). Per-part output: parts/<code>/qa (json), parts/<code>/fig (png).
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
import sys
import numpy as np

SRC = r"H:\My Drive\Mini Pumps\ulka re"
WS = r"C:\NX_MCP_WORKSPACE\ulka"
SCAN = os.path.join(WS, "scan")
PARTS = os.path.join(WS, "parts")
RAW = {
    "EM01": "EP5-EM01 Bobin.stl",
    "EM02": "EP5-EM02 Manyetik Cerceve.stl",
    "EM03": "EP5-EM03 Aki burcu.stl",
    "HS04": "EP5-HS04 Plastik ara halka.stl",
}
DT = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])


def raw_path(code):
    return os.path.join(SRC, RAW[code])


def pdir(code, sub=None):
    d = os.path.join(PARTS, code) if sub is None else os.path.join(PARTS, code, sub)
    os.makedirs(d, exist_ok=True)
    return d


def read_stl(path):
    """(n, 3, 3) float64 triangles of a binary STL."""
    with open(path, "rb") as f:
        f.seek(80)
        n = int(np.frombuffer(f.read(4), "<u4")[0])
    size = os.path.getsize(path)
    if size != 84 + 50 * n:
        raise ValueError("not a binary STL: %s (%d bytes, %d facets)" % (path, size, n))
    d = np.memmap(path, DT, mode="r", offset=84, shape=(n,))
    return np.asarray(d["v"], dtype=np.float64)


def write_stl(path, tri, header=b"ulka-B"):
    tri = np.asarray(tri, np.float32)
    d = np.zeros(len(tri), DT)
    d["v"] = tri
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    d["n"] = n / np.maximum(np.linalg.norm(n, axis=1), 1e-20)[:, None]
    with open(path, "wb") as f:
        f.write(header.ljust(80, b" ")[:80])
        f.write(np.uint32(len(tri)).tobytes())
        f.write(d.tobytes())


def weld(tri, decimals=5):
    """Indexed mesh (vertices, faces) by rounding coordinates."""
    v = tri.reshape(-1, 3)
    key = np.round(v, decimals)
    uniq, inv = np.unique(key, axis=0, return_inverse=True)
    return uniq, inv.reshape(-1, 3)


def components(faces, nv):
    """Connected-component label per face (vertex connectivity)."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    e = np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]]])
    g = coo_matrix((np.ones(len(e), np.int8), (e[:, 0], e[:, 1])), shape=(nv, nv))
    _, lab = connected_components(g, directed=False)
    return lab[faces[:, 0]]


def open_edges(faces):
    """Number of edges used by exactly one face, and by more than two."""
    e = np.sort(np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]]), axis=1)
    _, cnt = np.unique(e, axis=0, return_counts=True)
    return int((cnt == 1).sum()), int((cnt > 2).sum())


def volume(tri):
    return float(np.einsum("ij,ij->i", tri[:, 0], np.cross(tri[:, 1], tri[:, 2])).sum() / 6.0)


def apply(T, p):
    T = np.asarray(T, float)
    return p @ T[:3, :3].T + T[:3, 3]


def frame(z, origin, x=None):
    """4x4 that maps scanner coordinates to a frame with the given +Z direction, origin and (optional) +X hint."""
    z = np.asarray(z, float)
    z = z / np.linalg.norm(z)
    if x is None:
        x = np.eye(3)[np.argmin(np.abs(z))]
    x = np.asarray(x, float)
    x = x - z * (x @ z)
    x = x / np.linalg.norm(x)
    y = np.cross(z, x)
    R = np.stack([x, y, z])
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = -R @ np.asarray(origin, float)
    return T


def rotz(deg):
    a = np.radians(deg)
    T = np.eye(4)
    T[:2, :2] = [[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]]
    return T


class Mesh:
    def __init__(self, tri):
        self.tri = tri
        self.c = tri.mean(axis=1)
        nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        a = np.linalg.norm(nrm, axis=1)
        self.n = nrm / np.maximum(a, 1e-12)[:, None]
        self.a = a / 2
        self.lo = tri.min(axis=1)
        self.hi = tri.max(axis=1)

    def sub(self, mask):
        return Mesh(self.tri[mask])

    def moved(self, T):
        return Mesh(apply(T, self.tri))

    def section(self, axis, value):
        m = (self.lo[:, axis] <= value) & (self.hi[:, axis] >= value)
        return plane_cut(self.tri[m], np.eye(3)[axis], value)

    def cut(self, normal, d):
        normal = np.asarray(normal, float)
        s = self.tri @ normal - d
        m = (s.min(axis=1) <= 0) & (s.max(axis=1) >= 0)
        return plane_cut(self.tri[m], normal, d)

    def rz(self, theta_deg, both=False):
        """Half-plane section through the Z axis at angle theta: (m, 2, 2) segments in (r, z)."""
        t = np.radians(theta_deg)
        e = np.array([np.cos(t), np.sin(t), 0.0])
        s = self.cut([-np.sin(t), np.cos(t), 0.0], 0.0)
        if not len(s):
            return np.zeros((0, 2, 2))
        r = s @ e
        if not both:
            keep = (r > 0).all(axis=1)
            r, s = r[keep], s[keep]
        return np.stack([r, s[:, :, 2]], axis=2)

    def sample(self, n, seed=0, mask=None):
        """Area-weighted random surface points and their facet index."""
        rng = np.random.default_rng(seed)
        a = self.a if mask is None else np.where(mask, self.a, 0.0)
        idx = rng.choice(len(a), size=n, p=a / a.sum())
        u, v = rng.random(n), rng.random(n)
        f = u + v > 1
        u[f], v[f] = 1 - u[f], 1 - v[f]
        t = self.tri[idx]
        return t[:, 0] + (t[:, 1] - t[:, 0]) * u[:, None] + (t[:, 2] - t[:, 0]) * v[:, None], idx


def plane_cut(t, normal, value):
    d = t @ np.asarray(normal, float) - value
    segs = []
    for i, j, k in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
        s = (d[:, i] * d[:, j] < 0) & (d[:, i] * d[:, k] < 0)
        if not s.any():
            continue
        ti, di, dj, dk = t[s], d[s, i], d[s, j], d[s, k]
        p1 = ti[:, i] + (ti[:, j] - ti[:, i]) * (di / (di - dj))[:, None]
        p2 = ti[:, i] + (ti[:, k] - ti[:, i]) * (di / (di - dk))[:, None]
        segs.append(np.stack([p1, p2], axis=1))
    if not segs:
        return np.zeros((0, 2, 3))
    return np.concatenate(segs)


def cyl(p):
    """r, theta (deg, -180..180), z."""
    return np.hypot(p[..., 0], p[..., 1]), np.degrees(np.arctan2(p[..., 1], p[..., 0])), p[..., 2]


# ---------------------------------------------------------------- fits
def fit_plane(p, w=None, clip=None, iters=4):
    """Least-squares plane with optional sigma clipping -> dict(n, c, rms, n_used). n is unit, sign arbitrary."""
    p = np.asarray(p, float)
    keep = np.ones(len(p), bool)
    for _ in range(iters if clip else 1):
        q = p[keep]
        ww = None if w is None else w[keep]
        c = np.average(q, axis=0, weights=ww)
        d = q - c
        if ww is not None:
            d = d * np.sqrt(ww)[:, None]
        n = np.linalg.svd(d, full_matrices=False)[2][2]
        r = (p - c) @ n
        rms = float(np.sqrt(np.mean(r[keep] ** 2)))
        if clip:
            keep = np.abs(r) <= max(clip * rms, 1e-6)
    return {"n": n, "c": c, "rms": rms, "n_used": int(keep.sum()), "res": r, "keep": keep}


def fit_circle(xy, clip=None, iters=4):
    """Algebraic (Kasa) circle fit refined by Gauss-Newton -> dict(c, r, rms, n_used)."""
    xy = np.asarray(xy, float)
    keep = np.ones(len(xy), bool)
    out = None
    for _ in range(iters if clip else 1):
        q = xy[keep]
        A = np.c_[2 * q, np.ones(len(q))]
        sol = np.linalg.lstsq(A, (q ** 2).sum(axis=1), rcond=None)[0]
        c = sol[:2]
        r = np.sqrt(sol[2] + c @ c)
        for _ in range(10):
            d = q - c
            rho = np.linalg.norm(d, axis=1)
            J = np.c_[-d / rho[:, None], -np.ones(len(q))]
            step = np.linalg.lstsq(J, -(rho - r), rcond=None)[0]
            c = c + step[:2]
            r = r + step[2]
        res = np.linalg.norm(xy - c, axis=1) - r
        rms = float(np.sqrt(np.mean(res[keep] ** 2)))
        out = {"c": c, "r": float(r), "rms": rms, "n_used": int(keep.sum()), "res": res, "keep": keep}
        if clip:
            keep = np.abs(res) <= max(clip * rms, 1e-6)
    return out


def fit_cylinder(p, axis0, clip=None, iters=4):
    """Cylinder through points, axis near axis0 -> dict(axis, point, r, rms, n_used).
    Parametrised by two tilt angles and a 2D centre in the plane normal to axis0."""
    from scipy.optimize import least_squares
    p = np.asarray(p, float)
    a0 = np.asarray(axis0, float)
    a0 = a0 / np.linalg.norm(a0)
    u = np.cross(a0, np.eye(3)[np.argmin(np.abs(a0))])
    u /= np.linalg.norm(u)
    v = np.cross(a0, u)
    c0 = p.mean(axis=0)

    def geom(x):
        ax = a0 + x[0] * u + x[1] * v
        ax = ax / np.linalg.norm(ax)
        pt = c0 + x[2] * u + x[3] * v
        return ax, pt

    def resid(x, q):
        ax, pt = geom(x)
        d = q - pt
        rad = np.linalg.norm(d - np.outer(d @ ax, ax), axis=1)
        return rad - x[4]

    d0 = p - c0
    r0 = np.median(np.linalg.norm(d0 - np.outer(d0 @ a0, a0), axis=1))
    x = np.array([0.0, 0.0, 0.0, 0.0, r0])
    keep = np.ones(len(p), bool)
    for _ in range(iters if clip else 1):
        x = least_squares(resid, x, args=(p[keep],), method="lm").x
        res = resid(x, p)
        rms = float(np.sqrt(np.mean(res[keep] ** 2)))
        if clip:
            keep = np.abs(res) <= max(clip * rms, 1e-6)
    ax, pt = geom(x)
    pt = pt - ax * ((pt - c0) @ ax)
    return {"axis": ax, "point": pt, "r": float(abs(x[4])), "rms": rms, "n_used": int(keep.sum()), "res": res, "keep": keep}


def fit_cone(p, axis0, clip=None, iters=4):
    """Cone, axis near axis0 -> dict(axis, apex, half_angle_deg, rms). Radius = r0 + k * s along the axis."""
    from scipy.optimize import least_squares
    p = np.asarray(p, float)
    a0 = np.asarray(axis0, float)
    a0 = a0 / np.linalg.norm(a0)
    u = np.cross(a0, np.eye(3)[np.argmin(np.abs(a0))])
    u /= np.linalg.norm(u)
    v = np.cross(a0, u)
    c0 = p.mean(axis=0)

    def geom(x):
        ax = a0 + x[0] * u + x[1] * v
        return ax / np.linalg.norm(ax), c0 + x[2] * u + x[3] * v

    def resid(x, q):
        ax, pt = geom(x)
        d = q - pt
        s = d @ ax
        rad = np.linalg.norm(d - np.outer(s, ax), axis=1)
        return (rad - (x[4] + x[5] * s)) / np.sqrt(1 + x[5] ** 2)

    d0 = p - c0
    s0 = d0 @ a0
    rad0 = np.linalg.norm(d0 - np.outer(s0, a0), axis=1)
    k0, r0 = np.polyfit(s0, rad0, 1)
    x = np.array([0, 0, 0, 0, r0, k0], float)
    keep = np.ones(len(p), bool)
    for _ in range(iters if clip else 1):
        x = least_squares(resid, x, args=(p[keep],), method="lm").x
        res = resid(x, p)
        rms = float(np.sqrt(np.mean(res[keep] ** 2)))
        if clip:
            keep = np.abs(res) <= max(clip * rms, 1e-6)
    ax, pt = geom(x)
    return {"axis": ax, "point": pt, "r_at_point": float(x[4]), "slope": float(x[5]),
            "half_angle_deg": float(np.degrees(np.arctan(x[5]))), "rms": rms, "n_used": int(keep.sum()), "res": res, "keep": keep}


def hist_peaks(x, w=None, bin=0.02, min_frac=0.01, sep=0.3):
    """Peaks of a weighted histogram: list of (value, weight share) sorted by weight."""
    x = np.asarray(x, float)
    lo, hi = x.min(), x.max()
    nb = max(int(np.ceil((hi - lo) / bin)), 1)
    h, e = np.histogram(x, bins=nb, range=(lo, lo + nb * bin), weights=w)
    tot = h.sum()
    k = max(int(round(sep / bin)), 1)
    from scipy.ndimage import maximum_filter1d, uniform_filter1d
    hs = uniform_filter1d(h.astype(float), 5, mode="constant")
    top = (hs == maximum_filter1d(hs, 2 * k + 1, mode="constant")) & (hs > 0)
    out = []
    mid = 0.5 * (e[:-1] + e[1:])
    for i in np.nonzero(top)[0]:
        a, b = max(i - k, 0), min(i + k + 1, nb)
        share = h[a:b].sum() / tot
        if share < min_frac:
            continue
        # centroid of the core of the peak (bins above half of its height)
        core = h[a:b] >= 0.5 * h[a:b].max()
        out.append((float(np.average(mid[a:b][core], weights=h[a:b][core])), float(share)))
    out.sort(key=lambda t: -t[1])
    return out


def loops(segs, tol=1e-4):
    """Chain section segments (m, 2, 3) into connected polylines -> list of (k, 3) point arrays, longest first."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    if not len(segs):
        return []
    pts = segs.reshape(-1, 3)
    _, inv = np.unique(np.round(pts / tol).astype(np.int64), axis=0, return_inverse=True)
    inv = inv.reshape(-1, 2)
    n = inv.max() + 1
    g = coo_matrix((np.ones(len(inv), np.int8), (inv[:, 0], inv[:, 1])), shape=(n, n))
    _, lab = connected_components(g, directed=False)
    sl = lab[inv[:, 0]]
    out = []
    for k in np.unique(sl):
        s = segs[sl == k]
        out.append(s)
    out.sort(key=lambda s: -np.linalg.norm(s[:, 1] - s[:, 0], axis=1).sum())
    return out


def seg_points(segs, step=0.05):
    """Points spaced ~step along segments (m, 2, d): length-uniform sampling for fits."""
    d = segs[:, 1] - segs[:, 0]
    L = np.linalg.norm(d, axis=1)
    n = np.maximum(np.ceil(L / step).astype(int), 1)
    idx = np.repeat(np.arange(len(segs)), n)
    t = (np.concatenate([np.arange(k) for k in n]) + 0.5) / n[idx]
    return segs[idx, 0] + d[idx] * t[:, None]


def circles_at(mesh, z, rmax=None, min_len=2.0):
    """Section at z: every connected loop with its circle fit -> list of dicts (c, r, rms, length, span_deg, n)."""
    out = []
    for s in loops(mesh.section(2, z)):
        L = np.linalg.norm(s[:, 1] - s[:, 0], axis=1).sum()
        if L < min_len:
            continue
        p = seg_points(s[:, :, :2], 0.03)
        f = fit_circle(p, clip=3.0)
        if rmax is not None and f["r"] > rmax:
            continue
        a = np.degrees(np.arctan2(p[:, 1] - f["c"][1], p[:, 0] - f["c"][0]))
        span = len(np.unique(np.round(a / 5))) * 5
        out.append({"c": f["c"], "r": f["r"], "rms": f["rms"], "length": float(L), "span_deg": float(min(span, 360)), "z": z,
                    "ratio": float(L / (2 * np.pi * f["r"]))})
    return out


# ---------------------------------------------------------------- named measurements on an aligned mesh (Z = part axis)
def polar(q, c=(0.0, 0.0)):
    """r, theta_deg, radial component of the normal (+ = facing away from the centre c) per facet."""
    dx, dy = q.c[:, 0] - c[0], q.c[:, 1] - c[1]
    r = np.hypot(dx, dy)
    rad = (dx * q.n[:, 0] + dy * q.n[:, 1]) / np.maximum(r, 1e-9)
    return r, np.degrees(np.arctan2(dy, dx)), rad


def cover(theta, step=5.0):
    return float(min(len(np.unique(np.round(np.asarray(theta) / step))) * step, 360.0))


def level(q, facing, zwin, rwin=None, mask=None, c=(0.0, 0.0), nz=0.9):
    """Plane square to Z: facets facing +-Z inside a z window / radius window.
    -> z (area-weighted mean after clipping), rms about the free plane, tilt of the free plane, area, r range."""
    r, th, _ = polar(q, c)
    s = (facing * q.n[:, 2] > nz) & (q.c[:, 2] > zwin[0]) & (q.c[:, 2] < zwin[1])
    if rwin is not None:
        s &= (r > rwin[0]) & (r < rwin[1])
    if mask is not None:
        s &= mask
    if s.sum() < 20:
        return {"n": int(s.sum())}
    pl = fit_plane(q.c[s], q.a[s], clip=3.0)
    k = pl["keep"]
    z = np.average(q.c[s, 2][k], weights=q.a[s][k])
    nrm = pl["n"] * np.sign(pl["n"][2])
    zc = pl["c"][2] + (nrm[:2] @ (np.asarray(c) - pl["c"][:2])) / -nrm[2]
    return {"z": float(z), "z_at_axis": float(zc), "rms": pl["rms"], "tilt_deg": float(np.degrees(np.arccos(min(1.0, nrm[2])))),
            "tilt_dir_deg": float(np.degrees(np.arctan2(nrm[1], nrm[0]))), "area": float(q.a[s][k].sum()), "n": int(k.sum()),
            "r_min": float(np.percentile(r[s], 1)), "r_max": float(np.percentile(r[s], 99)), "cover_deg": cover(th[s])}


def wall(q, kind, rwin, zwin, c=(0.0, 0.0), mask=None, slabs=4, nzmax=0.3):
    """Coaxial cylinder / cone: facets facing radially (kind 'boss' outwards, 'bore' inwards) in an r / z window.
    -> circle fit of the whole band (centre, r, rms), r per z slab, slope (draft), free-axis tilt."""
    r, th, rad = polar(q, c)
    sg = 1.0 if kind == "boss" else -1.0
    s = (np.abs(q.n[:, 2]) < nzmax) & (sg * rad > 0.8) & (r > rwin[0]) & (r < rwin[1]) & (q.c[:, 2] > zwin[0]) & (q.c[:, 2] < zwin[1])
    if mask is not None:
        s &= mask
    if s.sum() < 30:
        return {"n": int(s.sum())}
    p = q.c[s]
    f = fit_circle(p[:, :2], clip=3.0)
    out = {"r": f["r"], "d": 2 * f["r"], "c": f["c"], "rms": f["rms"], "n": f["n_used"], "cover_deg": cover(th[s]),
           "z_min": float(np.percentile(p[:, 2], 1)), "z_max": float(np.percentile(p[:, 2], 99))}
    if slabs > 1 and out["z_max"] - out["z_min"] > 1.0:
        e = np.linspace(out["z_min"], out["z_max"], slabs + 1)
        zs, rs = [], []
        for a, b in zip(e[:-1], e[1:]):
            ss = (p[:, 2] >= a) & (p[:, 2] <= b)
            if ss.sum() < 30:
                continue
            g = fit_circle(p[ss, :2], clip=3.0)
            zs.append(0.5 * (a + b)); rs.append(g["r"])
        if len(zs) >= 2:
            k = np.polyfit(zs, rs, 1)
            out["r_by_z"] = [[float(a), float(b)] for a, b in zip(zs, rs)]
            out["draft_deg"] = float(np.degrees(np.arctan(k[0])))       # + = radius grows with z
        if cover(th[s]) > 200:
            cy = fit_cylinder(p, [0, 0, 1], clip=3.0)
            ax = cy["axis"] * np.sign(cy["axis"][2])
            out["axis_tilt_deg"] = float(np.degrees(np.arccos(min(1.0, ax[2]))))
    return out


def hole(q, cxy, rmax, zwin, kind="bore", it=3, nzmax=0.4):
    """Small cylinder parallel to Z near cxy: circle fit of the wall facets -> c, r, rms, cover."""
    c = np.asarray(cxy, float)
    sg = 1.0 if kind == "boss" else -1.0
    out = {"n": 0}
    for _ in range(it):
        r, th, rad = polar(q, c)
        s = (np.abs(q.n[:, 2]) < nzmax) & (sg * rad > 0.6) & (r < rmax) & (q.c[:, 2] > zwin[0]) & (q.c[:, 2] < zwin[1])
        if s.sum() < 15:
            return {"n": int(s.sum())}
        f = fit_circle(q.c[s, :2], clip=3.0)
        c = f["c"]
        out = {"c": f["c"], "r": f["r"], "d": 2 * f["r"], "rms": f["rms"], "n": f["n_used"], "cover_deg": cover(th[s]),
               "z_min": float(np.percentile(q.c[s, 2], 1)), "z_max": float(np.percentile(q.c[s, 2], 99)),
               "pcr": float(np.hypot(*f["c"])), "ang_deg": float(np.degrees(np.arctan2(f["c"][1], f["c"][0])))}
    return out


def flat_edge(q, cxy, facing, zwin, rmax, nbin=24, nz=0.95):
    """Opening in a flat face square to Z: per angular sector the smallest radius (about cxy) at which the flat
    face exists -> circle fit of those edge points, extents along x / y, centre of the extents."""
    c = np.asarray(cxy, float)
    for _ in range(3):
        r, th, _ = polar(q, c)
        s = (facing * q.n[:, 2] > nz) & (q.c[:, 2] > zwin[0]) & (q.c[:, 2] < zwin[1]) & (r < rmax)
        if s.sum() < 50:
            return {"n": int(s.sum())}
        b = np.floor((th[s] + 180.0) / (360.0 / nbin)).astype(int) % nbin
        pts = []
        for k in range(nbin):
            m = b == k
            if m.sum() < 5:
                continue
            i = np.argsort(r[s][m])[: max(3, m.sum() // 50)]
            pts.append(q.c[s][m][i, :2].mean(axis=0))
        pts = np.array(pts)
        if len(pts) < 8:
            return {"n": len(pts)}
        f = fit_circle(pts, clip=2.5)
        c = f["c"]
    lo, hi = pts.min(axis=0), pts.max(axis=0)
    return {"c": f["c"], "r": f["r"], "d": 2 * f["r"], "rms": f["rms"], "n": len(pts), "cover_deg": 360.0 * len(pts) / nbin,
            "x_min": float(lo[0]), "x_max": float(hi[0]), "y_min": float(lo[1]), "y_max": float(hi[1]),
            "pcr": float(np.hypot(*f["c"])), "ang_deg": float(np.degrees(np.arctan2(f["c"][1], f["c"][0]))),
            "z_min": zwin[0], "z_max": zwin[1]}


def show(name, d):
    """One-line print of a measurement dict."""
    if "z" in d and "tilt_deg" in d:
        out("  %-28s z %8.3f  rms %.3f  tilt %.2f deg  area %6.1f  r %.2f..%.2f  cover %3.0f" % (name, d["z"], d["rms"], d["tilt_deg"], d["area"], d["r_min"], d["r_max"], d["cover_deg"]))
    elif "pcr" in d:
        out("  %-28s D %7.3f  c (%7.3f, %7.3f)  pcr %7.3f  ang %8.3f  rms %.3f  cover %3.0f  z %.2f..%.2f  n %d" % (
            name, d["d"], d["c"][0], d["c"][1], d["pcr"], d["ang_deg"], d["rms"], d["cover_deg"], d["z_min"], d["z_max"], d["n"]))
    elif "r" in d:
        extra = ""
        if "draft_deg" in d:
            extra += "  draft %+.2f deg" % d["draft_deg"]
        if "axis_tilt_deg" in d:
            extra += "  axis tilt %.2f deg" % d["axis_tilt_deg"]
        out("  %-28s D %7.3f  c (%6.3f, %6.3f)  rms %.3f  cover %3.0f  z %.2f..%.2f%s" % (
            name, d["d"], d["c"][0], d["c"][1], d["rms"], d["cover_deg"], d["z_min"], d["z_max"], extra))
    else:
        out("  %-28s too few facets (%s)" % (name, d.get("n")))


# ---------------------------------------------------------------- output
def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items() if k not in ("res", "keep")}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    if isinstance(o, (np.floating, float)):
        return round(float(o), 5)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    return o


def save_json(code, name, data):
    path = os.path.join(pdir(code, "qa"), name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(jsonable(data), f, indent=1, ensure_ascii=False)
    return path


def load_json(code, name):
    with open(os.path.join(pdir(code, "qa"), name), encoding="utf-8") as f:
        return json.load(f)


def out(*a):
    print(*a)
    sys.stdout.flush()


def plot_segs(ax, segs2, **kw):
    from matplotlib.collections import LineCollection
    lc = LineCollection(segs2, **{"linewidths": 0.5, "colors": "k", **kw})
    ax.add_collection(lc)
    ax.set_aspect("equal")
    ax.autoscale()
