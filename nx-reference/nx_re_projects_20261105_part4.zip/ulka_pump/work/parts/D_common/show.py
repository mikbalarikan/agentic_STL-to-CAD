"""Print the verdict of a journal result JSON: failed checks in full, passed ones as a count."""
import json
import sys

sys.stdout.reconfigure(encoding="utf-8")
path = sys.argv[1]
full = "all" in sys.argv[2:]
try:
    r = json.load(open(path, encoding="utf-8"))
except Exception as ex:  # noqa: BLE001
    print("NO RESULT FILE:", path, ex)
    raise SystemExit(1)
print("RESULT", r.get("result"))
if "error" in r:
    print(r["error"])
rows = r.get("checks", [])
bad = [c for c in rows if not c.get("ok")]
print("checks: %d, failed: %d" % (len(rows), len(bad)))
for c in (rows if full else bad):
    if "got" in c:
        print("  %s %-62s got %s want %s tol %s" % ("ok  " if c["ok"] else "FAIL", c["name"], c.get("got"), c.get("want"), c.get("tol")))
    else:
        print("  %s %-62s %s" % ("ok  " if c["ok"] else "FAIL", c["name"], str(c.get("note", ""))[:300]))
for k in ("volumes", "bbox", "sketches", "notes", "step_roundtrip", "features"):
    if k in r:
        print(k + ":", json.dumps(r[k], ensure_ascii=False)[:1400])
