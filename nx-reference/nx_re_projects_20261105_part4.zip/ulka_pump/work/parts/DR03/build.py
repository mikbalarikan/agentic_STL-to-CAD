"""EP5-DR03_SPRING-REAR rear spring (long, dark) - free length, closed and ground ends (NX 2206 journal, headless).

    run_journal build.py -args <out dir>        (ULKA_OFFLINE=1: CR-C-01 values as placeholders)

Moving part, own axis: Z = coil axis, z = 0 and z = dr03_len the ground end planes, wire start at +X, right hand.
dr03_len = dr03_l0 (free); A makes the installed copy by setting dr03_len. Centre line = law curve with a
piecewise pitch (closed end turns, ramps, active pitch derived from the length) -> Tube -> two Trim Bodies.
Sources: sessions/C_MEASURED.md, cr/CR-C-01.md (fit: parts/C_common/spring_fit2.py on scan EP5-DR03\_aligned.stl).
"""
import os, sys
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\C_common\nxlib")
import spring_job

LINKS = {   # control part (Rev F)
    "dr03_d": ("mm", 1.4), "dr03_od": ("mm", 12.95), "dr03_l0": ("mm", 30.16), "dr03_nt": (None, 8.15),
}
INTERNAL = {   # fitted to the whole scan surface with pitch(end) = d (Usta) + gap, parts/C_common/spring_fit3.py
    "dr03_pe_gap": (0.02, "mm", "gap between touching end coils (closed ends)"),
    "dr03_a1": (0.927, None, "closed turns at the z = 0 end [fit with closed-end pitch = d + gap, spring_fit3.py]"),
    "dr03_b1": (0.167, None, "pitch ramp turns at the z = 0 end [fit with closed-end pitch = d + gap, spring_fit3.py]"),
    "dr03_a2": (0.884, None, "closed turns at the far end [fit with closed-end pitch = d + gap, spring_fit3.py]"),
    "dr03_b2": (0.1, None, "pitch ramp turns at the far end [fit with closed-end pitch = d + gap, spring_fit3.py]"),
    "dr03_grind": (0.4, "mm", "grind depth at the ends [fit with closed-end pitch = d + gap, spring_fit3.py]"),
}
spring_job.run(sys.argv[1], "EP5-DR03_SPRING-REAR", "dr03_", LINKS, INTERNAL, {"pitch": 4.374})
