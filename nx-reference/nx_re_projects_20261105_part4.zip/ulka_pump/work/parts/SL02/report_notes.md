## Çerçeve
Yerinde, nötr (kalıp) halinde torus: alt yüz `z_sl02` (HS01 flanşı üstü, HS03 Ø20,93 içinde). ID / kesit kontrol parçasından.

Standart eşleme: **ISO 3601-1 / AS568-115, 15,47 x 2,62** (tarama OD 20,70). Taramada yükseklik 2,89 (yatarken hafif ovallik). Ön kontrol: kendi oturmasından sonra %87,3 ±0,15 (elastomer bandı ±0,10; yalnız üst yarı taranmış).
