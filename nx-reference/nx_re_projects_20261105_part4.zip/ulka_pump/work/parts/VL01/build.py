"""EP5-VL01 - native parametric build (NX 2206, headless), ULKA-D. Builder: D_common/nxlib/dsmall.py:vl01."""
import os, sys, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\D_common\nxlib")
import nxh, rj, dsmall
OUT = sys.argv[1]
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, "EP5-VL01_BALL")
    body = dsmall.vl01(c)
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
