## Çerçeve
Kendi çerçevesinde, merkez orijinde (A konumlar). Ø `vl01_d` = 3,572 (9/64"), tarama küre uydurması 3,606 (sd 0,031).
Ön kontrol: %100 ±0,15, %92,4 ±0,05 içinde.
