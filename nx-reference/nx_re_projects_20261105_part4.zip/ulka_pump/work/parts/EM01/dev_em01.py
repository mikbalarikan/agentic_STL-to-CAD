"""EM01: scan against the NX model. Scan frame (_B_common): x_s = +Y, y_s = +X, z_s = z_em01_term - Z."""
import os, sys, json
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\_B_common")
import numpy as np
import rb, dev

O = r"C:\NX_MCP_WORKSPACE\ulka\parts\EM01\out"
zt = json.load(open(os.path.join(O, "build.json"), encoding="utf-8"))["linked"]["z_em01_term"]
T = np.array([[0, 1, 0, 0], [1, 0, 0, 0], [0, 0, -1, zt], [0, 0, 0, 1.0]])
r = lambda P: np.hypot(P[:, 0], P[:, 1])
s = lambda P: zt - P[:, 2]                     # depth from the terminal end face (scan z)
rad = lambda P, N: (P[:, 0] * N[:, 0] + P[:, 1] * N[:, 1]) / np.maximum(r(P), 1e-9)
zones = {
    "body OD (away from plate / housing)": lambda P, N: (r(P) > 22.5) & (r(P) < 25) & (s(P) > 7) & (s(P) < 41.5) & (rad(P, N) > 0.8) & (P[:, 1] < 15),
    "bore": lambda P, N: (r(P) < 11.6) & (rad(P, N) < -0.8),
    "terminal end face": lambda P, N: (np.abs(s(P)) < 0.4) & (r(P) > 11.5) & (r(P) < 23) & (np.abs(N[:, 2]) > 0.8),
    "plain end face + recess": lambda P, N: (s(P) > 42.4) & (s(P) < 43.8) & (r(P) > 11.5) & (r(P) < 21.5) & (np.abs(N[:, 2]) > 0.8),
    "end tabs": lambda P, N: (np.abs(P[:, 0]) < 2.5) & (P[:, 1] > 12) & (P[:, 1] < 16.5) & ((s(P) < -0.3) | (s(P) > 43.8)),
    "plate outer + top": lambda P, N: (P[:, 1] > 24) & (s(P) > 0.3) & (s(P) < 6.0) & (np.abs(P[:, 0]) < 22),
    "fast-on blades": lambda P, N: (P[:, 1] > 29.8) & (s(P) > 6.5) & (s(P) < 15.0),
    "Klixon housing": lambda P, N: (P[:, 0] > 6.5) & (P[:, 0] < 19.5) & (P[:, 1] > 24) & (s(P) > 6.5),
}
# not the part / not modelled: scanner sheet fringes beyond the bobbin ends, plate underside feet, bore-mouth notches
excl = lambda P, N: (s(P) < -1.2) & ~((np.abs(P[:, 0]) < 2.5) & (P[:, 1] > 12) & (P[:, 1] < 16.5)) | (s(P) > 43.8) & ~((np.abs(P[:, 0]) < 2.5) & (P[:, 1] > 12) & (P[:, 1] < 16.5)) \
    | ((r(P) < 12.2) & ((s(P) < 1.5) | (s(P) > 41.5)))
refit = {"whole part (rigid best fit, K2)": lambda P, N: np.ones(len(P), bool),
         "body OD + bore (pose of the bobbin)": lambda P, N: ((r(P) > 22.5) & (r(P) < 25) & (s(P) > 7) & (s(P) < 41.5) & (rad(P, N) > 0.8) & (P[:, 1] < 15)) | ((r(P) < 11.6) & (rad(P, N) < -0.8))}
dev.run("EM01", [os.path.join(O, "EP5-EM01_COIL_body.stl")], os.path.join(rb.SCAN, "EP5-EM01_aligned.stl"), zones, T=T, exclude=excl, refit=refit)
# second pass: zones after the whole-part rigid best fit (what A's K2 sees)
J = rb.load_json("EM01", "dev.json")
Rt = np.array(J["refit"]["whole part (rigid best fit, K2)"]["T"])
dev.run("EM01", [os.path.join(O, "EP5-EM01_COIL_body.stl")], os.path.join(rb.SCAN, "EP5-EM01_aligned.stl"), zones, T=Rt @ T, exclude=excl, tag="dev_fit")
