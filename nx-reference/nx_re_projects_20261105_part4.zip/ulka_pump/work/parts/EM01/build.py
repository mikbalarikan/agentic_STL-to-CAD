"""EP5-EM01 coil (purchased part) - envelope model, native parametric build (NX 2206, headless).

    run_journal build.py -args <out dir>

Modelled in place in the pump frame (ULKA_INTERFACES Rev A §1-2): Z = pump axis, +Z inlet -> outlet. The terminal
end face of the bobbin sits on z_em01_term (EM02 outlet wall inner face), the plain end on z_em01_term - em01_len;
terminal plate, fast-on blades, Klixon housing and the two end tabs on +Y; the blades point to -Z.
Precise (control part): body OD, length, bore (two core-pin cones: em01_bore_end_d at the ends, em01_bore_min_d in
the middle). From the scan (part-internal): end tabs, plain-end recess, plate, blades, rib, housing.
Not modelled: winding, Klixon, diode, lettering, the small notches at the bore mouths, the feet under the plate.
Scan frame (parts/_B_common): x_scan = +Y, y_scan = +X, z_scan = z_em01_term - Z.
Features: PL_TERM + AX_TERM_Y -> SK_BODY -> Revolve -> blend -> SK_TAB -> 2 extrudes -> SK_PLATE -> extrude ->
SK_BLADE1/2 -> extrudes -> PL_RIB + SK_RIB -> extrude -> SK_HOUSING -> extrude.
"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\_B_common\nxlib")
import NXOpen
import nxh, nxf, nxa
import rj
from rj import BOOL, X, Y, Z

OUT = sys.argv[1]
NAME = "EP5-EM01_COIL"
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, NAME)
    p, M = c.part, c.M
    for n in ("z_em01_term", "em01_len", "em01_body_d", "em01_bore_min_d", "em01_bore_end_d", "em03_od", "hs04_od", "em02_w", "em02_out_x", "em02_t"):
        c.link(n)
    # ---- part-internal masters (B_MEASURED §1, scan frame values)
    c.e("rec_r", 17.25, "plain-end face recess, outer radius [scan: floor to r 16.5, step 17.0..17.75]")
    c.e("rec_dt", 0.29, "terminal-end face recess depth below the outer ring [scan planes r 11.5-16.5: +0.21, r 18-22: -0.08]")
    c.e("rec_d", 0.6, "plain-end face recess depth [scan floor 42.85 vs face 43.45..43.50]")
    c.e("end_r_t", 1.0, "terminal-end outer edge round, on the half without the flange [scan r-z corner]")
    c.e("end_r", 1.5, "plain-end outer edge round [scan: face drops from r 22]")
    c.e("tab_w", 3.9, "end tab width (X) [scan -1.90..+1.97 / -1.90..+1.72]")
    c.e("tab_r0", 12.3, "end tab inner radius [scan r 12.3..12.4]")
    c.e("tab_r1", 16.05, "end tab outer face [scan 16.10 / 15.96]")
    c.e("tab_h_term", 2.9, "terminal-end tab height past the end face [scan 2.80..3.03]")
    c.e("tab_h_far", 2.15, "plain-end tab height past the end face [scan 45.60 - 43.45]")
    c.e("plate_y1", 31.67, "terminal plate outer face [scan 31.666]")
    c.e("plate_y0", 17.5, "half size of the square notch that keeps the flange sketch out of the bore and the end recess (construction, > rec_r)")
    c.e("plate_xn", 22.43, "terminal plate outer corner on -X [scan -22.43]")
    c.e("plate_xp", 22.04, "terminal plate outer corner on +X [scan 22.04]")
    c.e("plate_t", 5.63, "flange top from the end face [scan 5.56..5.73]")
    c.e("foot_d", 0.86, "flange underside rim below the end face plane [scan -0.77..-0.99]")
    c.e("foot_y0", 21.5, "flange underside rim starts at Y [scan row Y 22 at -0.9, Y 20 at 0]")
    c.e("upk_d", 0.56, "underside pocket depth inside the rim [scan pocket -0.27..-0.42 vs rim -0.86]")
    for k, v, cm in (("upk_x0", 21.2, "-X edge"), ("upk_x1", 17.0, "+X edge"), ("upk_y0", 23.3, "Y from"), ("upk_y1", 27.3, "Y to")):
        c.e(k, v, "flange underside pocket %s [scan height map]" % cm)
    c.e("step_d", 0.43, "flange top step on the blade side [scan 5.15..5.29 vs 5.6]")
    c.e("step_x1", 1.5, "flange top step +X edge [scan between X 0 and 3]")
    c.e("step_y0", 25.0, "flange top step Y from [scan between Y 24 and 26]")
    c.e("blade_w", 6.3, "fast-on blade width (6.3 x 0.8 standard) [scan 6.25 / 6.20]")
    c.e("blade_t", 0.8, "fast-on blade thickness (standard; scan sees one face only)")
    c.e("blade_y", 31.0, "fast-on blade outer face [scan 31.06 / 30.95]")
    c.e("blade_x1", -15.12, "fast-on blade 1 centre X [scan]")
    c.e("blade_x2", -2.35, "fast-on blade 2 centre X [scan]")
    c.e("notch_w", 6.46, "pocket in the flange outer face under each blade, width [scan blade side faces -18.36/-11.90, -5.59/0.92]")
    c.e("notch_y0", 30.45, "pocket bottom (flange outer face there) [scan sections 30.4..30.6]")
    c.e("blade_top", 14.7, "fast-on blade tip from the end face [scan 14.72 / 14.67]")
    c.e("rib_x", -8.97, "triangular rib mid plane X [scan faces -9.88 / -8.06]")
    c.e("rib_t", 1.82, "triangular rib thickness [scan]")
    c.e("rib_y0", 21.0, "rib inner edge (inside the body, construction)")
    c.e("rib_h0", 21.54, "rib height at rib_y0 from the end face [scan line z = 18.26 - 1.64 (y - 24)]")
    # Klixon housing: open-top box on the body, walls fitted on the scan (pump X-Y): outer faces u = 29.23 along
    # (cos 59.1, sin 59.1) and w = +5.777 / -5.553 along (cos 150.4, sin 150.4); cavity faces u = 23.98 .. 28.2
    # (far one = outer - 1.03 wall), w = +4.70 / -4.48, split by a partition w = -0.154 .. +0.846 (face at +0.846
    # fitted, 1.0 thick DERIVED) into two pockets hk_* and hm_*. Body-side corners at u = 20 (inside the body). Cavity floor
    # not scanned: DERIVED down to the flange top. Corners (X, Y):
    for k, v in (("hs_ax", 5.248), ("hs_ay", 20.015), ("hs_bx", 9.988), ("hs_by", 27.935), ("hs_cx", 19.839), ("hs_cy", 22.338), ("hs_dx", 15.099), ("hs_dy", 14.418), ("hk_ax", 8.228), ("hk_ay", 22.898), ("hk_bx", 10.395), ("hk_by", 26.519), ("hk_cx", 13.746), ("hk_cy", 24.615), ("hk_dx", 11.579), ("hk_dy", 20.994), ("hm_ax", 12.449), ("hm_ay", 20.5), ("hm_bx", 14.616), ("hm_by", 24.121), ("hm_cx", 18.377), ("hm_cy", 21.985), ("hm_dx", 16.21), ("hm_dy", 18.364)):
        c.e(k, v, "Klixon housing corner (" + ("outer" if k.startswith("hs") else "cavity") + ", from the fitted walls)")
    c.e("hs_top", 22.49, "Klixon housing top from the end face [scan 22.49]")
    zt = M["z_em01_term"]
    L = M["em01_len"]
    ro, rbe, rbm = M["em01_body_d"] / 2, M["em01_bore_end_d"] / 2, M["em01_bore_min_d"] / 2
    fp, pl = nxf.datum_plane(p, "offset", [c.dat.xy], "z_em01_term", "PL_TERM")
    fa, ax = nxf.datum_axis(p, "intersection", pl, c.dat.yz, name="AX_TERM_Y")

    # ---- 1. bobbin body: revolved half section (u = radius along Y, v = Z from the terminal end face)
    rr, rd = M["rec_r"], M["rec_d"]
    rdt = M["rec_dt"]
    pv = [(rbe, -rdt, "em01_bore_end_d/2", "rec_dt"), (rr, -rdt, "rec_r", None), (rr, 0.0), (ro, 0.0, "em01_body_d/2", None), (ro, -L, None, "em01_len"),
          (rr, -L, "rec_r", None), (rr, -L + rd, None, "em01_len-rec_d"), (rbe, -L + rd, "em01_bore_end_d/2", None),
          (rbm, -L / 2, "em01_bore_min_d/2", "em01_len/2")]
    S = c.sketch("yz", "SK_BODY", hax=ax, shift=(0.0, 0.0, zt))
    S.profile(pv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, ((ro + rbe) / 2, -L / 2)), nxf.axis_from(p, c.dat.z))
    f.SetName("BOBBIN")
    body = f.GetBodies()[0]
    v0 = rj.revolve_volume([(a[0], a[1]) for a in pv])
    c.chk("bobbin volume = revolved section", c.vol(body), v0, 1e-6 * v0)

    ed = [e for e in body.GetEdges() if abs(nxh.bbox(e)[2] - (zt - L)) < 1e-4 and abs(nxh.bbox(e)[5] - (zt - L)) < 1e-4 and abs(nxh.bbox(e)[3] - ro) < 1e-4]
    c.chk("plain-end outer edge found", len(ed), 1, 0)
    f = nxh.blend(p, ed, "end_r"); f.SetName("END_ROUND")
    v1 = c.vol(body)
    er = M["end_r"]
    xc = er * (10 - 3 * math.pi) / (3 * (4 - math.pi))
    c.chk("end round volume (Pappus)", v0 - v1, (1 - math.pi / 4) * er * er * 2 * math.pi * (ro - xc), 1e-4)

    # ---- 2. end tabs on +Y (one sketch on the terminal end plane, two extrudes)
    hw = M["tab_w"] / 2
    tv = [(-hw, M["tab_r0"], "tab_w/2", "tab_r0"), (hw, M["tab_r0"], "tab_w/2", None), (hw, M["tab_r1"], None, "tab_r1"), (-hw, M["tab_r1"])]
    S = c.sketch("xy", "SK_TAB", on=pl, shift=(0.0, 0.0, zt))
    S.profile(tv)
    c.done(S)
    f = nxh.extrude(p, S.section(None, (0.0, (M["tab_r0"] + M["tab_r1"]) / 2)), Z, "-rec_dt", "tab_h_term", op=BOOL.Unite, target=body)
    f.SetName("TAB_TERM")
    v2 = c.vol(body)
    tab_a = M["tab_w"] * (M["tab_r1"] - M["tab_r0"])
    c.chk("terminal-end tab (from the recess floor)", v2 - v1, tab_a * (M["tab_h_term"] + rdt), 1e-3)
    f = nxh.extrude(p, S.section(None, (0.0, (M["tab_r0"] + M["tab_r1"]) / 2)), Z, "-(em01_len+tab_h_far)", "-(em01_len-rec_d)", op=BOOL.Unite, target=body)
    f.SetName("TAB_FAR")
    v3 = c.vol(body)
    c.chk("plain-end tab (from the recess floor)", v3 - v2, tab_a * (M["tab_h_far"] + rd), 1e-3)

    # ---- 3. terminal flange: D shape = body circle + trapezoid from the body diameter at Y = 0 to the outer face
    y1p, nh = M["plate_y1"], M["plate_y0"]
    plv = [(-ro, 0.0, "em01_body_d/2", None), (-nh, 0.0, "plate_y0", None), (-nh, nh, None, "plate_y0"), (nh, nh, "plate_y0", None), (nh, 0.0),
           (ro, 0.0, "em01_body_d/2", None), (M["plate_xp"], y1p, "plate_xp", "plate_y1"), (-M["plate_xn"], y1p, "plate_xn", None)]
    S = c.sketch("xy", "SK_PLATE", on=pl, shift=(0.0, 0.0, zt))
    S.profile(plv)
    c.done(S)
    f = nxh.extrude(p, S.section(None, (0.0, 28.0)), Z, "-plate_t", "0", op=BOOL.Unite, target=body)
    f.SetName("PLATE")
    v4 = c.vol(body)
    trap = 0.5 * (2 * ro + M["plate_xp"] + M["plate_xn"]) * y1p
    # the square notch corners stick out of the body circle: that bit of flange is missing (numeric, 2 corners)
    nn = 4000
    lost = 0.0
    for i in range(nn):
        xq = (i + 0.5) * nh / nn
        if xq < ro:
            lost += max(0.0, nh - math.sqrt(max(ro * ro - xq * xq, 0.0))) * nh / nn
        else:
            lost += nh * nh / nn
    c.chk("flange = trapezoid less the half disc less the notch corners (sides cut the circle by < 0.03)", v4 - v3,
          (trap - math.pi * ro * ro / 2 - 2 * lost) * M["plate_t"], 1e-3 * trap * M["plate_t"])
    c.notes["flange notch corner loss mm2"] = 2 * lost

    # ---- 3a. terminal-end outer edge round, made while the end face still has one closed outer boundary
    #      (body arc on -Y, the two slanted flange sides, the flange outer edge) [scan on the end face: edge at
    #      r 22.2..22.9, 0.4 in r 23.3..23.6, 1.0 in r 23.8 -> about R1; it clears the EM02 inner bend, A Rev H]
    eds = []
    for e in body.GetEdges():
        b = nxh.bbox(e)
        if abs(b[2] - zt) > 0.02 or abs(b[5] - zt) > 0.02:
            continue
        if b[1] < -ro + 0.1 or (min(abs(b[0]), abs(b[3])) > 21.5 and b[0] * b[3] > 0 and abs(b[3] - b[0]) > 0.3) or b[1] > M["plate_y1"] - 0.01:
            eds.append(e)
    c.notes["terminal edge round edges"] = len(eds)
    vr = c.vol(body)
    f = nxh.blend(p, eds, "end_r_t")
    f.SetName("TERM_EDGE_ROUND")
    v4r = c.vol(body)
    c.chk.true("terminal edge round on the closed outer boundary (4 edges), a little material removed", len(eds) == 4 and 0.0 < vr - v4r < 40.0, (len(eds), vr - v4r))
    v4 = v4r

    # ---- 3b. flange details: underside rim (foot), underside pocket, top step on the blade side
    fv = [(-M["plate_xn"], M["foot_y0"], "plate_xn", "foot_y0"), (M["plate_xp"], M["foot_y0"], "plate_xp", None), (M["plate_xp"], M["plate_y1"], None, "plate_y1"),
          (-M["plate_xn"], M["plate_y1"])]
    S = c.sketch("xy", "SK_FOOT", on=pl, shift=(0.0, 0.0, zt))
    S.profile(fv)
    c.done(S)
    f = nxh.extrude(p, S.section(None, (0.0, 28.0)), Z, "0", "foot_d", op=BOOL.Unite, target=body)
    f.SetName("FLANGE_FOOT")
    v = c.vol(body)
    c.chk("flange underside rim", v - v4, (M["plate_xp"] + M["plate_xn"]) * (M["plate_y1"] - M["foot_y0"]) * M["foot_d"], 1e-3)
    vols = v
    uv = [(-M["upk_x0"], M["upk_y0"], "upk_x0", "upk_y0"), (M["upk_x1"], M["upk_y0"], "upk_x1", None), (M["upk_x1"], M["upk_y1"], None, "upk_y1"), (-M["upk_x0"], M["upk_y1"])]
    S = c.sketch("xy", "SK_UPOCKET", on=pl, shift=(0.0, 0.0, zt))
    S.profile(uv)
    c.done(S)
    f = nxh.extrude(p, S.section(None, (0.0, 25.0)), Z, "foot_d-upk_d", "foot_d+1", op=BOOL.Subtract, target=body)
    f.SetName("FLANGE_UNDER_POCKET")
    v = c.vol(body)
    c.chk("flange underside pocket", vols - v, (M["upk_x0"] + M["upk_x1"]) * (M["upk_y1"] - M["upk_y0"]) * M["upk_d"], 1e-3)
    vols = v
    sv = [(-(M["plate_xn"] + 1.0), M["step_y0"], "plate_xn+1", "step_y0"), (M["step_x1"], M["step_y0"], "step_x1", None),
          (M["step_x1"], M["plate_y1"] + 1.0, None, "plate_y1+1"), (-(M["plate_xn"] + 1.0), M["plate_y1"] + 1.0)]
    S = c.sketch("xy", "SK_STEP", on=pl, shift=(0.0, 0.0, zt))
    S.profile(sv)
    c.done(S)
    f = nxh.extrude(p, S.section(None, (-10.0, 28.0)), Z, "-plate_t-1", "-(plate_t-step_d)", op=BOOL.Subtract, target=body)
    f.SetName("FLANGE_TOP_STEP")
    v = c.vol(body)
    xe = lambda yy: ro - (ro - M["plate_xn"]) * yy / M["plate_y1"]          # -X flange side at Y
    c.chk("flange top step (to the slanted -X flange side)", vols - v, (0.5 * (xe(M["step_y0"]) + xe(M["plate_y1"])) + M["step_x1"]) * (M["plate_y1"] - M["step_y0"]) * M["step_d"], 1e-3)
    vols = v
    # ---- 4. fast-on blades: 6.3 x 0.8 through pockets of the flange, outer face blade_y, up to blade_top
    for k, xn in (("1", "blade_x1"), ("2", "blade_x2")):
        xc_ = M[xn]
        nw = M["notch_w"] / 2
        nv = [(xc_ - nw, M["notch_y0"], "abs(%s-notch_w/2)" % xn, "notch_y0"), (xc_ + nw, M["notch_y0"], "abs(%s+notch_w/2)" % xn, None),
              (xc_ + nw, M["plate_y1"] + 1.0, None, "plate_y1+1"), (xc_ - nw, M["plate_y1"] + 1.0)]
        S = c.sketch("xy", "SK_NOTCH" + k, on=pl, shift=(0.0, 0.0, zt))
        S.profile(nv)
        c.done(S)
        f = nxh.extrude(p, S.section(None, (xc_, M["notch_y0"] + 0.5)), Z, "-plate_t-1", "1", op=BOOL.Subtract, target=body)
        f.SetName("BLADE_POCKET" + k)
        v = c.vol(body)
        c.chk("blade pocket %s volume (less the edge-round corner already gone)" % k, vols - v,
              M["notch_w"] * ((M["plate_y1"] - M["notch_y0"]) * (M["plate_t"] - M["step_d"] + M["foot_d"]) - (1 - math.pi / 4) * M["end_r_t"] ** 2), 1e-3)
        vols = v
    for k, xn in (("1", "blade_x1"), ("2", "blade_x2")):
        xc_ = M[xn]
        bw = M["blade_w"] / 2
        y0, y1 = M["blade_y"] - M["blade_t"], M["blade_y"]
        bv = [(xc_ - bw, y0), (xc_ + bw, y0), (xc_ + bw, y1), (xc_ - bw, y1)]
        S = c.sketch("xy", "SK_BLADE" + k, on=pl, shift=(0.0, 0.0, zt))
        crv = S.profile([(bv[0][0], bv[0][1], "abs(%s-blade_w/2)" % xn, "blade_y-blade_t"), (bv[1][0], bv[1][1], "abs(%s+blade_w/2)" % xn, None),
                         (bv[2][0], bv[2][1], None, "blade_y"), (bv[3][0], bv[3][1])])
        c.done(S)
        f = nxh.extrude(p, S.section(None, (xc_, (y0 + y1) / 2)), Z, "-blade_top", "0", op=BOOL.Unite, target=body)
        f.SetName("BLADE" + k)
        v = c.vol(body)
        c.chk("blade %s volume (through the flange, rooted in it)" % k, v - vols, M["blade_w"] * M["blade_t"] * M["blade_top"] - M["blade_w"] * (M["notch_y0"] - (M["blade_y"] - M["blade_t"])) * (M["plate_t"] - M["step_d"]), 1e-3)
        vols = v

    # ---- 5. triangular rib in the plane X = rib_x (u = Y, v = Z from the terminal end face)
    fpr, plr = nxf.datum_plane(p, "offset", [c.dat.yz], "rib_x", "PL_RIB")
    y0r, y1r = M["rib_y0"], M["plate_y1"]
    rv = [(y0r, -(M["plate_t"] - M["step_d"]), "rib_y0", "plate_t-step_d"), (y1r, -(M["plate_t"] - M["step_d"]), "plate_y1", None), (y0r, -M["rib_h0"], None, "rib_h0")]
    S = c.sketch("yz", "SK_RIB", on=plr, hax=ax, shift=(M["rib_x"], 0.0, zt))
    S.profile(rv)
    c.done(S)
    f = nxh.extrude(p, S.section(None, ((2 * y0r + y1r) / 3, -(2 * (M["plate_t"] - M["step_d"]) + M["rib_h0"]) / 3)), X, "-rib_t/2", "rib_t/2", op=BOOL.Unite, target=body)
    f.SetName("RIB")
    v5 = c.vol(body)
    tri = 0.5 * (y1r - y0r) * (M["rib_h0"] - M["plate_t"]) * M["rib_t"]
    c.chk.true("rib added, less than its full triangle (part of it inside the body)", 0.0 < v5 - vols < tri, (v5 - vols, tri))

    # ---- 6. Klixon housing: quadrilateral A-B-C-D, plate top -> hs_top
    hv = [(M["hs_ax"], M["hs_ay"], "hs_ax", "hs_ay"), (M["hs_bx"], M["hs_by"], "hs_bx", "hs_by"), (M["hs_cx"], M["hs_cy"], "hs_cx", "hs_cy"),
          (M["hs_dx"], M["hs_dy"], "hs_dx", "hs_dy")]
    S = c.sketch("xy", "SK_HOUSING", on=pl, shift=(0.0, 0.0, zt))
    S.profile(hv)
    c.done(S)
    cx_ = sum(q[0] for q in hv) / 4; cy_ = sum(q[1] for q in hv) / 4
    f = nxh.extrude(p, S.section(None, (cx_, cy_)), Z, "-hs_top", "-plate_t", op=BOOL.Unite, target=body)
    f.SetName("KLIXON_HOUSING")
    v6 = c.vol(body)
    quad = 0.5 * abs(sum(hv[i][0] * hv[(i + 1) % 4][1] - hv[(i + 1) % 4][0] * hv[i][1] for i in range(4)))
    hbox = quad * (M["hs_top"] - M["plate_t"])
    c.chk.true("housing added, less than its full prism (part inside the body)", 0.0 < v6 - v5 < hbox, (v6 - v5, hbox))
    for nm, pfx in (("KLIXON_CAVITY_1", "hk"), ("KLIXON_CAVITY_2", "hm")):
        kv = [(M[pfx + "_ax"], M[pfx + "_ay"], pfx + "_ax", pfx + "_ay"), (M[pfx + "_bx"], M[pfx + "_by"], pfx + "_bx", pfx + "_by"),
              (M[pfx + "_cx"], M[pfx + "_cy"], pfx + "_cx", pfx + "_cy"), (M[pfx + "_dx"], M[pfx + "_dy"], pfx + "_dx", pfx + "_dy")]
        S = c.sketch("xy", "SK_" + nm[7:], on=pl, shift=(0.0, 0.0, zt))
        S.profile(kv)
        c.done(S)
        f = nxh.extrude(p, S.section(None, (sum(q[0] for q in kv) / 4, sum(q[1] for q in kv) / 4)), Z, "-hs_top-1", "-plate_t", op=BOOL.Subtract, target=body)
        f.SetName(nm)
        v7 = c.vol(body)
        kq = 0.5 * abs(sum(kv[i][0] * kv[(i + 1) % 4][1] - kv[(i + 1) % 4][0] * kv[i][1] for i in range(4)))
        c.chk("%s = quadrilateral prism (inside the housing)" % nm, v6 - v7, kq * (M["hs_top"] - M["plate_t"]), 1e-3)
        v6 = v7
    c.chk("one solid", len(nxh.solids(p)), 1, 0)

    # ---- interface read-back
    cf = rj.cyl_faces(body)
    c.chk("body OD", 2 * max(abs(q[3]) for q in cf), M["em01_body_d"], 1e-9)
    c.chk("terminal end face, outer ring (probe)", abs(nxh.dist_to(p, body, (-(rr + ro) / 2, 0.0, zt))), 0.0, 1e-6)
    c.chk("plain end face (probe)", abs(nxh.dist_to(p, body, (-(rr + ro - er) / 2, 0.0, zt - L))), 0.0, 1e-6)
    c.chk("bore at the terminal end recess floor (probe)", abs(nxh.dist_to(p, body, (-rbe, 0.0, zt - rdt))), 0.0, 1e-6)
    c.chk("bore narrowest at mid length (probe)", abs(nxh.dist_to(p, body, (-rbm, 0.0, zt - L / 2))), 0.0, 1e-6)
    c.chk.true("bore > EM03 OD and HS04 OD", M["em01_bore_min_d"] > M["em03_od"] and M["em01_bore_min_d"] > M["hs04_od"])
    c.notes["z_planes"] = {"terminal end face": zt, "plain end face": zt - L, "terminal tab top": zt + M["tab_h_term"],
                           "plain tab end": zt - L - M["tab_h_far"], "plate top": zt - M["plate_t"], "blade tips": zt - M["blade_top"]}
    c.notes["tabs vs EM02"] = "tabs (width %.2f, r %.2f..%.2f) sit in the EM02 outlet-wall seam slot (terminal end) and the inlet-wall notch (plain end); EM02 openings must clear them" % (
        M["tab_w"], M["tab_r0"], M["tab_r1"])
    c.notes["not_modelled"] = "winding, Klixon, diode, lettering, bore-mouth notches, plate feet (plate underside 0.3..0.86 below the end face at r > 23), blade dimple holes"

    # ---- regeneration: plate_t 5.63 -> 6.5 -> 5.63 (blades and housing follow the plate top)
    v_nom = c.vol(body)
    nxh.set_expr(p, "plate_t", 6.5); nxh.update()
    v_big = c.vol(body)
    errs = [str(x) for x in nxh.feature_errors(p)]
    nxh.set_expr(p, "plate_t", 5.63); nxh.update()
    c.chk.true("regeneration plate_t 5.63 -> 6.5 adds material", v_big > v_nom, (v_nom, v_big))
    c.chk.true("regeneration: no feature errors", not errs, errs)
    c.chk("regeneration back to nominal", c.vol(body), v_nom, 1e-6 * v_nom)
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
