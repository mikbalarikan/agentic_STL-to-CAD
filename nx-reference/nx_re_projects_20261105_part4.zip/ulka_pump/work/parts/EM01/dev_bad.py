import os, sys, json, io, contextlib
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\_B_common")
import numpy as np
import rb, dev
exec(open("dev_em01.py", encoding="utf-8").read().split("dev.run(")[0])
J = rb.load_json("EM01", "dev.json")
Rt = np.array(J["refit"]["whole part (rigid best fit, K2)"]["T"])
if True:
    out, P, N, d = dev.run("EM01", [os.path.join(O, "EP5-EM01_COIL_body.stl")], os.path.join(rb.SCAN, "EP5-EM01_aligned.stl"), zones, T=Rt @ T, exclude=excl, tag="dev_tmp")
keep = ~excl(P, N)
bad = keep & (np.abs(d) > 0.15)
print("bad share %.3f of %d" % (bad.sum() / keep.sum(), keep.sum()))
# classify bad points into regions
reg = {"r<11.6 bore": r(P) < 11.6, "Y>23.7 (flange/blades/housing side)": (P[:, 1] > 23.7), "end faces |n_z|>0.8": np.abs(N[:, 2]) > 0.8,
       "body OD r 22.5..24": (r(P) > 22.5) & (r(P) < 24.2) & (np.abs(N[:, 2]) < 0.5)}
for k, m in reg.items():
    print("%-40s bad %6d (%.1f %% of bad)  share bad in region %.1f %%" % (k, (bad & m).sum(), 100 * (bad & m).sum() / bad.sum(), 100 * (bad & m).sum() / max((keep & m).sum(), 1)))
cell = np.floor(P[bad] / 3.0).astype(int)
key, cnt = np.unique(cell, axis=0, return_counts=True)
o = np.argsort(-cnt)[:15]
for i in o:
    mm = bad & np.all(np.floor(P / 3.0).astype(int) == key[i], axis=1)
    print("cell centre %s: %d bad, mean d %+.2f" % ((key[i] * 3 + 1.5).tolist(), cnt[i], d[mm].mean()))
