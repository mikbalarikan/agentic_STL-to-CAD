## Çerçeve ve tasarım niyeti

Satın alınan parça, dış zarf modeli. Pompa çerçevesinde yerinde (Rev A §2): terminal ucu dış halkası
`z_em01_term` = -3,30 (Rev H: bobin iki duvar arasında ortalı), düz uç -46,82; terminal flanşı, fast-on'lar, Klixon yuvası ve
uç tırnakları +Y'de, bıçaklar -Z yönünde. Kontrol parçasından: gövde Ø47,21, boy 43,45, delik (iki çekirdek konisi:
uçlarda Ø21,90, ortada Ø21,45). Taramadan parça içi: uç yüz çöküntüleri (terminal 0,29 / düz 0,6, r < 17,25),
uç tırnakları (3,9 x 3,75, terminal ucunda +2,9, düz uçta 2,15), D biçimli terminal flanşı (gövdeye teğet kenarlar,
dış yüz 31,67, alt kenar ayağı 0,86, alt cep 0,56, bıçak tarafında üst basamak 0,43), iki fast-on 6,3 x 0,8
(X -15,12 / -2,35, dış yüz Y 31,0, uç Z -17,7) flanş ceplerinden geçerek, üçgen nervür (X -8,97, 1,82),
Klixon yuvası (duvarları taramaya uydurulmuş açık kutu, iki göz).
Modellenmeyen: sargı, Klixon, diyot, yazılar, delik ağzı çentikleri, bıçak delikleri, Klixon yuvası dış duvarındaki tel yarığı.

CR-B-01 kabul edildi (Rev E): `em01_len` 43,52. Rev H (A'nın montaj bulgusu): terminal ucu -3,30 ve terminal ucu dış
kenarına R1 yuvarlatma (gövde yayı + iki eğik flanş kenarı + flanş dış kenarı, uç yüzün kapalı dış sınırı;
taramada uç yüzde r 22,2-22,9 / 0,4 içeride 23,3-23,6 / 1,0 içeride 23,8). B'nin kendi girişim denetimi:
EM01 yüzeyinden 600 000 nokta EM02 içinde değil, en yakın 0,05 mm.

## Taramanın göstermediği / dışarıda tutulan bölgeler (QA'dan önce)

- Bobin uçlarının 1,2 mm ötesindeki tarayıcı kenar saçakları (tırnaklar hariç); delik ağzı çentikleri
  (r < 12,2, uçlardan 1,5 mm içinde).
- Delik içi yarım taranmış (kapsama 100-160°); Klixon gözlerinin tabanı taranmamış (flanş üstüne kadar
  türetildi); bıçakların iç yüzü taranmamış (kalınlık 0,8 standart).

## Kabul (B'nin kendi ölçümü; bağımsız QA A'da)

- K1 (işlevsel): gövde Ø, delik, boy Rev A expression'larıyla CAD'de tam. Tarama karşılaştırması (bütün parça
  rijit oturtmasından sonra, `qa\dev_fit.json`): gövde dışı ±0,15 içinde %100 (sd 0,039), delik %92, düz uç
  yüzü %97,2, terminal ucu yüzü %89,2 (Rev E).
- **K2 (T = 0,15): tutmadı** - bütün parça rijit en iyi oturtmadan sonra %82,7 ±0,15 içinde (kapı ≥ %90).
  Sapmanın büyük kısmı kalıp ayrıntısı olan flanş / Klixon yuvası / bıçak bölgesinde (Y > 23,7 bölgesinde
  noktaların yaklaşık yarısı bant dışı: Klixon yuvası duvar eğimleri ve iç bölmeler, bıçak kökleri, flanş
  kenar yuvarlatmaları). Gövde, delik ve uç yüzler bant içinde. Satın alınan parçada bu bölge zarf olarak
  modellendi; daha ileri ayrıntı Usta / A isterse eklenir.
