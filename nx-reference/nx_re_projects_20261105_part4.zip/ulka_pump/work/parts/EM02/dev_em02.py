"""EM02: scan against the NX model. The scan copy is already in the pump frame (Rev A §1 = B's EM02 frame)."""
import os, sys, json
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\_B_common")
import numpy as np
import rb, dev

O = r"C:\NX_MCP_WORKSPACE\ulka\parts\EM02\out"
cad = [os.path.join(O, "EP5-EM02_FRAME_body.stl")]
scan = os.path.join(rb.SCAN, "EP5-EM02_aligned.stl")
r = lambda P: np.hypot(P[:, 0], P[:, 1])
zones = {
    "outlet wall faces": lambda P, N: (P[:, 2] > -3.3) & (np.abs(P[:, 0]) < 22.5) & (np.abs(N[:, 2]) > 0.8),
    "inlet wall faces": lambda P, N: (P[:, 2] < -46.8) & (np.abs(P[:, 0]) < 22.5) & (np.abs(N[:, 2]) > 0.8),
    "flat walls": lambda P, N: (np.abs(P[:, 0]) > 23.5) & (P[:, 2] > -45) & (P[:, 2] < -5) & (np.abs(N[:, 0]) > 0.8),
    "outlet big hole": lambda P, N: (P[:, 2] > -3.3) & (r(P) < 11.2) & (np.abs(N[:, 2]) < 0.5),
    "inlet big hole": lambda P, N: (P[:, 2] < -46.8) & (r(P) < 8.9) & (np.abs(N[:, 2]) < 0.5),
    "small holes (screw + pin)": lambda P, N: (P[:, 2] > -3.3) & (np.abs(N[:, 2]) < 0.5) & ((np.hypot(np.abs(P[:, 0]) - 18.95, P[:, 1]) < 2.3) | (np.hypot(np.abs(P[:, 0]) - 14.0, np.abs(P[:, 1]) - 5.0) < 2.4)),
    "bends": lambda P, N: (np.abs(P[:, 0]) > 21) & ((P[:, 2] > -5) | (P[:, 2] < -45)),
}
excl = lambda P, N: (np.abs(P[:, 1]) > 16.3)
refit = {"whole part (rigid best fit, K2)": lambda P, N: np.ones(len(P), bool)}
dev.run("EM02", cad, scan, zones, T=None, exclude=excl, refit=refit)
J = rb.load_json("EM02", "dev.json")
Rt = np.array(J["refit"]["whole part (rigid best fit, K2)"]["T"])
dev.run("EM02", cad, scan, zones, T=Rt, exclude=excl, tag="dev_fit")
