"""EP5-EM02 magnetic frame - NX Sheet Metal, native parametric build (NX 2206, headless).

    run_journal build.py -args <out dir>

One strip bent into a closed rectangle (ULKA_INTERFACES Rev A §1-2), modelled in place in the pump frame:
Z = pump axis (the axis of the two big holes), +Z inlet -> outlet, origin on the outlet wall outer face; flat walls on
+-X, open sides +-Y (strip width em02_w). The two strip ends meet in the middle of the outlet wall (X = 0) with a
narrow seam. Bends: inlet-wall corners em02_ri_in, outlet-wall corners em02_ri_out (both inner radii, Rev A §7.3).
Features: PL_IN_OUT -> SK_TAB -> Tab (inlet wall) -> 2 Flanges (flat walls, R ri_in) -> 2 Flanges (outlet-wall halves,
R ri_out) -> Normal Cutouts: outlet wall (hole, 2 screw holes, 4 pin holes, 2 notches), inlet wall (hole, 2 notches)
-> 2 window cuts in the flat walls at the outlet bends (extrude subtract: they run into the bend).
Not modelled: label (sticker), bulge of the strip edges at the bends, M4 thread (cosmetic in Rev A §5).
"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, os.environ.get("NXSM_DIR", r"C:\Users\marya\.claude\skills\nx-sheet-metal\scripts"))
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\_B_common\nxlib")
import NXOpen
import NXOpen.Features.SheetMetal as SM
import NXOpen.Preferences
import nxh, nxf, nxa
import sheet_metal_bracket as smb
import rj
from rj import BOOL, X, Y, Z

OUT = sys.argv[1]
NAME = "EP5-EM02_FRAME"
res = {"result": "FAIL"}
FB = SM.FlangeBendPropertiesBuilder
NCS = SM.NormalCutoutBuilder.DepthSideOptions


def strip_area(R, a):
    """area of the disc of radius R inside |x| < a"""
    a = min(a, R)
    return 2 * (a * math.sqrt(R * R - a * a) + R * R * math.asin(a / R))


try:
    c = rj.Ctx(OUT, NAME, template="sheet-metal-mm-template.prt")
    p, M = c.part, c.M
    for n in ("z_em02_out", "em02_t", "em02_in_axial", "z_em02_in_out", "em02_out_x", "em02_w", "em02_ri_out", "em02_ri_in",
              "em02_hole_out_d", "em02_hole_in_d", "fs_pitch", "em02_fs_hole_d", "pin_x", "pin_y", "em02_pin_hole_d",
              "em03_od", "hs01_tube_od", "em01_body_d", "em01_len"):
        c.link(n)
    c.e("k_factor", 0.44, "neutral factor (DERIVED: shop default for t/r about 1-2; only the flat blank depends on it)", unit=None)
    c.e("seam_w", 1.03, "seam between the two strip ends in the outlet wall [scan end faces X -0.55 / +0.48]")
    c.e("notch_w", 4.15, "notch width, both holed walls [scan X +-2.04 outlet, +-2.10 inlet]")
    c.e("notch_bot", 11.82, "notch bottom from the axis [scan inlet +11.80 / -11.84]")
    c.e("notch_r", 0.8, "notch bottom corner radius [scan: gap 3.0..3.6 at 0.2 above the bottom], DERIVED; 0.8 clears the EM01 tab corner (3.9 wide, r 12.3)")
    c.e("win_w", 6.2, "window in the flat walls at the outlet bends, width along Y [scan Y -3.3..+2.9]")
    c.e("win_z0", 5.75, "window far edge from the outlet outer face [scan section Y=0: flat-wall top at -5.7..-5.8]")
    c.e("win_z1", -1.0, "window runs out through the outlet face: the whole bend is cut away there (construction)")
    c.e("win_x0", 22.3, "window: the outlet-wall half ends at |X| [scan section Y=0: end face 22.2..22.3]")
    c.d("c_tab_notch", "(notch_w-3.9)/2", "side clearance EM01 end tab (3.9) / notch")
    c.d("c_em01_axial", "em02_in_axial-em01_len", "axial room of the EM01 bobbin between the holed walls")
    c.d("c_em01_x", "(em02_out_x-2*em02_t-em01_body_d)/2", "radial room EM01 body / flat walls")
    RI, RO = "em02_ri_in", "em02_ri_out"
    if os.environ.get("ULKA_B_TRY_R"):                      # trial of CR-B-02 radii without a control-part revision
        a_, b_ = [float(v) for v in os.environ["ULKA_B_TRY_R"].split(",")]
        c.e("try_ri_in", a_, "TRIAL CR-B-02"); c.e("try_ri_out", b_, "TRIAL CR-B-02")
        RI, RO = "try_ri_in", "try_ri_out"
        M["em02_ri_in"], M["em02_ri_out"] = a_, b_
    t, hx, hw = M["em02_t"], M["em02_out_x"] / 2, M["em02_w"] / 2
    zi, zo = M["z_em02_in_out"], M["z_em02_out"]
    ri, ro_ = M["em02_ri_in"], M["em02_ri_out"]

    # ---- sheet-metal globals -> the linked thickness, the inlet radius, the K factor
    ps_ = p.Preferences.PartSheetmetal
    ps_.SetBendDefinitionMethodOption(False, NXOpen.Preferences.PartSheetmetal.BendDefinitionMethodOptions.NeutralFactorValue)
    ps_.GetThickness().RightHandSide = "em02_t"
    ps_.GetBendRadius().RightHandSide = RI
    ps_.GetNeutralFactor().RightHandSide = "k_factor"
    ps_.GetBendReliefDepth().RightHandSide = "em02_t"
    ps_.GetBendReliefWidth().RightHandSide = "em02_t"
    nxh.update("sheet metal prefs")

    # ---- 1. Tab = inlet wall, sketched on its outer face, thickness towards +Z
    fp, pl_in = nxf.datum_plane(p, "offset", [c.dat.xy], "z_em02_in_out", "PL_IN_OUT")
    tv = [(-hx, -hw, "em02_out_x/2", "em02_w/2"), (hx, -hw, "em02_out_x/2", None), (hx, hw, None, "em02_w/2"), (-hx, hw)]
    S = c.sketch("xy", "SK_TAB", on=pl_in, shift=(0.0, 0.0, zi))
    S.profile(tv)
    c.done(S)
    tab = smb.tab(p, ps_, S.sk, "TAB_INLET_WALL")
    body = tab.GetBodies()[0]
    c.chk("tab volume", c.vol(body), 2 * hx * 2 * hw * t, 1e-6)

    # ---- 2. flat walls: flanges on the +-X edges of the tab's inner face, outside length to the outlet outer face
    for nm, sx in (("FLANGE_PX", 1.0), ("FLANGE_NX", -1.0)):
        ed = nxh.one(nxh.edges(body, lambda b, sx=sx: abs(b[0] - sx * hx) < 1e-4 and abs(b[3] - sx * hx) < 1e-4 and
                               abs(b[2] - (zi + t)) < 1e-4 and abs(b[5] - (zi + t)) < 1e-4), nm + " edge")
        smb.flange(p, ps_, ed, "z_em02_out-z_em02_in_out", nm)
    bb = nxh.bbox(body)
    c.chk("after the flat walls: top at the outlet outer face", bb[5], zo, 1e-4)
    c.chk("after the flat walls: outside X", bb[3] - bb[0], M["em02_out_x"], 1e-4)

    # ---- 3. outlet-wall halves: flanges on the inner top edges of the flat walls, turning inwards, own radius
    for nm, sx in (("FLANGE_OUT_PX", 1.0), ("FLANGE_OUT_NX", -1.0)):
        xi = sx * (hx - t)
        ed = nxh.one(nxh.edges(body, lambda b, xi=xi: abs(b[0] - xi) < 1e-4 and abs(b[3] - xi) < 1e-4 and
                               abs(b[2] - zo) < 1e-4 and abs(b[5] - zo) < 1e-4), nm + " edge")
        f = smb.flange(p, ps_, ed, "em02_out_x/2-seam_w/2", nm)
        b2 = p.Features.SheetmetalManager.CreateMultiFlangeBuilder(f)
        try:
            fb = b2.FlangePropertiesList.FeatureBendPropertiesList.FindItem(0)
            fb.BendOptions.UseGlobalBendRadius = False
            fb.BendOptions.BendRadius.RightHandSide = RO
            b2.CommitFeature()
        finally:
            b2.Destroy()
    nxh.update("outlet flanges")
    bb = nxh.bbox(body)
    c.chk("closed frame: Z from the inlet outer face", bb[2], zi, 1e-4)
    c.chk("closed frame: Z to the outlet outer face", bb[5], zo, 1e-4)
    c.chk("closed frame: width", bb[4] - bb[1], M["em02_w"], 1e-4)
    straight = (2 * hx - 2 * (ri + t)) + 2 * ((zo - zi) - (ri + t) - (ro_ + t)) + 2 * (hx - (ro_ + t) - M["seam_w"] / 2)
    arcs = 2 * (math.pi / 2) * (ri + t / 2) + 2 * (math.pi / 2) * (ro_ + t / 2)
    v_formed = 2 * hw * t * (straight + arcs)
    c.chk("formed volume = width x t x (straights + bend mid-fibre arcs)", c.vol(body), v_formed, 1e-3)
    sm = p.Features.SheetmetalManager
    bends = []
    for fc in smb.inner_bends(p, body):
        bp = smb.bend_parameters(p, fc)
        bends.append((round(bp.get("BendAngle", -1), 3), round(bp.get("InnerRadius", -1), 4)))
    c.notes["bends (angle, inner radius)"] = sorted(bends)
    c.chk.true("four 90 deg bends: two R ri_in, two R ri_out", sorted(bends) == sorted([(90.0, round(ri, 4))] * 2 + [(90.0, round(ro_, 4))] * 2), bends)

    # ---- 4. Normal Cutouts. Outlet wall: sketch on PL_OUT (z_em02_out), symmetric depth 2t cuts this wall only
    fp2, pl_out = nxf.datum_plane(p, "offset", [c.dat.xy], "z_em02_out", "PL_OUT")
    v0 = c.vol(body)
    S = c.sketch("xy", "SK_OUT_HOLES", on=pl_out, shift=(0.0, 0.0, zo))
    S.circle(0.0, 0.0, M["em02_hole_out_d"], df="em02_hole_out_d")
    for sx in (1, -1):
        S.circle(sx * M["fs_pitch"] / 2, 0.0, M["em02_fs_hole_d"], cuf="fs_pitch/2", df="em02_fs_hole_d")
        for sy in (1, -1):
            S.circle(sx * M["pin_x"], sy * M["pin_y"], M["em02_pin_hole_d"], cuf="pin_x", cvf="pin_y", df="em02_pin_hole_d")
    c.done(S)
    smb.normal_cutout(p, S.sk, body, "CUT_OUT_HOLES", depth="2*em02_t", side=NCS.Symmetric)
    v1 = c.vol(body)
    rh = M["em02_hole_out_d"] / 2
    a_big = math.pi * rh * rh - strip_area(rh, M["seam_w"] / 2)
    a_small = 2 * math.pi * (M["em02_fs_hole_d"] / 2) ** 2 + 4 * math.pi * (M["em02_pin_hole_d"] / 2) ** 2
    c.chk("outlet holes (big one less the seam strip, 2 screw, 4 pin)", v0 - v1, (a_big + a_small) * t, 1e-3)

    def notch_profile(sy):
        a, yb, r_, ye = M["notch_w"] / 2, M["notch_bot"], M["notch_r"], hw + 1.0
        vs = [(-a, sy * (yb + r_), "notch_w/2", "notch_bot+notch_r"), (-(a - r_), sy * yb, "notch_w/2-notch_r", "notch_bot"),
              (a - r_, sy * yb, "notch_w/2-notch_r", None), (a, sy * (yb + r_), "notch_w/2", "notch_bot+notch_r"),
              (a, sy * ye, None, "em02_w/2+1"), (-a, sy * ye)]
        arcs = {0: (-(a - r_), sy * (yb + r_), "notch_r"), 2: (a - r_, sy * (yb + r_), "notch_r")}
        return vs, arcs
    a_notch = M["notch_w"] * (hw - M["notch_bot"]) - (4 - math.pi) * M["notch_r"] ** 2 / 2
    for wall, pl_, zw, seam in (("OUT", pl_out, zo, True), ("IN", pl_in, zi, False)):
        vb = c.vol(body)
        S = c.sketch("xy", "SK_%s_NOTCHES" % wall, on=pl_, shift=(0.0, 0.0, zw))
        for sy in (1, -1):
            vs, arcs_ = notch_profile(sy)
            S.profile(vs, arcs=arcs_)
        if wall == "IN":
            S.circle(0.0, 0.0, M["em02_hole_in_d"], df="em02_hole_in_d")
        c.done(S)
        smb.normal_cutout(p, S.sk, body, "CUT_%s_NOTCHES" % wall, depth="2*em02_t", side=NCS.Symmetric)
        va = c.vol(body)
        want = 2 * a_notch
        if seam:
            want -= 2 * M["seam_w"] * (hw - M["notch_bot"])     # the seam strip is already empty
        else:
            want += math.pi * (M["em02_hole_in_d"] / 2) ** 2
        c.chk("%s wall notches%s" % (wall.lower(), "" if seam else " + hole"), vb - va, want * t, 1e-3)

    # ---- 5. windows in the flat walls at the outlet bends (run into the bend): extrude subtract along X
    wv = [(-M["win_w"] / 2, -M["win_z0"], "win_w/2", "win_z0"), (M["win_w"] / 2, -M["win_z0"], "win_w/2", None),
          (M["win_w"] / 2, -M["win_z1"], None, "-win_z1"), (-M["win_w"] / 2, -M["win_z1"])]
    S = c.sketch("yz", "SK_WINDOWS", hax=c.dat.y, shift=(0.0, 0.0, zo))
    S.profile(wv)
    c.done(S)
    for nm, a0, a1 in (("WINDOW_PX", "win_x0", "em02_out_x/2+1"), ("WINDOW_NX", "-(em02_out_x/2+1)", "-win_x0")):
        vb = c.vol(body)
        f = nxh.extrude(p, S.section(None, (0.0, -(M["win_z0"] + M["win_z1"]) / 2)), X, a0, a1, op=BOOL.Subtract, target=body)
        f.SetName(nm)
        va = c.vol(body)
        flat_part = M["win_w"] * (M["win_z0"] - (t + ro_)) * t     # at least the flat wall up to the bend start
        c.chk.true("%s removed the flat-wall part and some of the bend" % nm, flat_part < vb - va < M["win_w"] * (M["win_z0"] - M["win_z1"]) * (hx - M["win_x0"]) + 1e-6,
                   (vb - va, flat_part))
    c.chk("one solid", len(nxh.solids(p)), 1, 0)
    c.chk.true("still a sheet-metal body", sm.IsSheetmetalBody(body))

    # ---- interface read-back
    cf = rj.cyl_faces(body)
    def has_hole(d, x, y, z0, z1):
        for f_, pt, dr, rad in cf:
            if abs(abs(rad) - d / 2) < 1e-6 and abs(pt[0] - x) < 1e-6 and abs(pt[1] - y) < 1e-6 and abs(abs(dr[2]) - 1) < 1e-9:
                return True
        return False
    c.chk.true("outlet hole on the axis", has_hole(M["em02_hole_out_d"], 0, 0, -t, 0))
    c.chk.true("inlet hole on the axis", has_hole(M["em02_hole_in_d"], 0, 0, zi, zi + t))
    c.chk.true("screw holes at (+-fs_pitch/2, 0)", all(has_hole(M["em02_fs_hole_d"], sx * M["fs_pitch"] / 2, 0, -t, 0) for sx in (1, -1)))
    c.chk.true("pin holes at (+-pin_x, +-pin_y)", all(has_hole(M["em02_pin_hole_d"], sx * M["pin_x"], sy * M["pin_y"], -t, 0) for sx in (1, -1) for sy in (1, -1)))
    c.chk("inlet wall inner face (probe)", abs(nxh.dist_to(p, body, (15.0, 5.0, zi + t))), 0.0, 1e-6)
    c.chk("outlet wall inner face (probe)", abs(nxh.dist_to(p, body, (20.0, -8.0, zo - t))), 0.0, 1e-6)
    c.chk("flat wall inner face (probe)", abs(nxh.dist_to(p, body, (hx - t, 0.0, -25.0))), 0.0, 1e-6)
    c.chk.true("room for EM01: axial and radial clearances positive", M["c_em01_axial"] > 0 and M["c_em01_x"] > 0 and M["c_tab_notch"] > 0,
               (M["c_em01_axial"], M["c_em01_x"], M["c_tab_notch"]))
    c.notes["clearances"] = {"EM01 axial room": M["c_em01_axial"], "EM01 body / flat walls": M["c_em01_x"], "EM01 tab / notch side": M["c_tab_notch"]}

    # ---- regeneration: thickness 3.0 -> 2.5 -> 3.0 (outside sizes kept, bends and cutouts follow)
    v_nom = c.vol(body)
    # interface thickness is linked: test with the part-internal seam instead (outlet flange length follows)
    nxh.set_expr(p, "seam_w", 2.0); nxh.update()
    v_big = c.vol(body)
    errs = [str(x) for x in nxh.feature_errors(p)]
    nxh.set_expr(p, "seam_w", 1.03); nxh.update()
    c.chk.true("regeneration seam_w 1.03 -> 2.0: less material, at most the strip shortening", 0.0 < v_nom - v_big <= 0.97 * t * 2 * hw + 1e-6, v_nom - v_big)
    c.chk.true("regeneration: no feature errors", not errs, errs)
    c.chk("regeneration back to nominal", c.vol(body), v_nom, 1e-6 * v_nom)
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
