## Çerçeve ve tasarım niyeti

NX Sheet Metal parçası (Tab + 4 Flange + Normal Cutout'lar), pompa çerçevesinde yerinde (Rev A §1-2): Z = iki
büyük deliğin ekseni, orijin çıkış duvarı dış yüzü, düz duvarlar ±X, açık yanlar ±Y. Tek şerit: giriş duvarı Tab,
düz duvarlar 90° flanş (iç R `em02_ri_in`), çıkış duvarının iki yarısı içe dönen flanşlar (iç R `em02_ri_out`,
yerel radyüs); iki uç X = 0'da 1,03 mm birleşme yarığıyla buluşur. Delik / pim / vida konumları ve çapları
kontrol parçasından. Parça içi (taramadan): `seam_w` 1,03, çentikler 4,15 x (kenardan |Y| 11,82'ye) R0,8 köşeli (türetildi; R1 EM01 tırnak köşesine 0,02 değiyordu) (iki
delikli duvarda da, ±Y; EM01 tırnağı 3,9 bunlara oturur, yan boşluk 0,125), düz duvar pencereleri (çıkış
bükümünde, Y ±3,1, çıkış yarısı |X| 22,3'te biter, düz duvar Z -5,75'e kadar açık - bükümün tamamı kesik;
pencereler extrude çıkarma, Normal Cutout değil). K faktörü 0,44 türetildi (yalnız açınımı etkiler).
Modellenmeyen: etiket, şerit kenarlarının bükümlerdeki şişmesi (Y 16,2'ye), çıkış duvarının düzlemsizliği
(ortada +0,2, köşelere doğru -0,2..-0,45), M4 diş (Rev A §5 kozmetik).

CR-B-02 kabul edildi (Rev G): dört bükümde tek iç R 1,9 (`em02_ri_out` 1,9). Model Rev G ile yeniden koşuldu.

## Taramanın göstermediği / dışarıda tutulan bölgeler (QA'dan önce)

- Delikli duvarların her biri tek yüzden taranmış (çıkış: dış, giriş: iç yüz); diğer yüz t = 3,0 ile.
- Giriş köşelerinin dış yüzü kısmen taranmamış. Dışarıda: |Y| > 16,3 (şerit kenarı ötesindeki tarama saçağı).

## Kabul (B'nin kendi ölçümü; bağımsız QA A'da)

- K1: delikler (Ø21,24 / Ø16,74 / Ø3,5 x2 / Ø3,72 x4), t, iç eksenel açıklık Rev A expression'larıyla CAD'de tam.
  Tarama karşılaştırması (rijit oturtma sonrası, `qa\dev_fit.json`): büyük delikler ±0,15 içinde %97-99, küçük
  delikler %91, düz duvarlar %96, giriş duvarı %93.
- **K2 (T = 0,15): tutmadı** - Rev G modelinde bütün parça rijit en iyi oturtmadan sonra %89,6 (kapı ≥ %90; Rev A
  radyüsleriyle %87,2). Bant dışı noktalar bükümlerde (%60 içinde) ve çıkış duvarının köşelere doğru çöken
  bölgesinde (%81): sac düzlemsizliği, sabit kalınlıklı sac metalde modellenmiyor.
