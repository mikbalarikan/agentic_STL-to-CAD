## Çerçeve
Yerinde: alt yüz `z_vl05` = `z_hs02` + `hs02_vl05_z` (31,92; Rev D, CR-D-02), HS02 Ø8,52 deliğinde, üstünde G1/8 diş. Halka Ø8,4
(`vl05_od`) x 4,5 (`vl05_t`), et 0,8, iki kol 1,2 genişlikte (artı), göbek Ø3,4, göbek deliği Ø2,4 (VL03 sap kılavuzu,
**türetildi**). Dış tırnaklar (~Ø8,6-9,0) modellenmedi.

## Tarama
Tarama çok zayıf (delikli, parçalı); ön kontrol %30-34 ±0,15 - **tutmadı**; şekil F18 fotoğrafından, ölçü kaynağı dış
çap ve kalınlık (D_MEASURED §4).
