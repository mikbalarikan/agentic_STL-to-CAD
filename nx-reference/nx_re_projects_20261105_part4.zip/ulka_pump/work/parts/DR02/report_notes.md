## Çerçeve
Hareketli parça, kendi ekseninde: Z = sarım ekseni, z = 0 ve z = `dr02_len` taşlanmış uç düzlemleri, tel başı +X'te,
sağ helis. `dr02_len` = `dr02_l0` (serbest boy); A montaj kopyasında bu expression'a `dr02_l_inst` verir, aktif adım
boydan türetilir (uç sarımları sabit kalır).
Unsur ağacı: law curve merkez çizgisi (`CENTRE_LINE`: x, y = coil_d/2·cos/sin(360·n_t·t), z = parçalı adım:
kapalı uç adımı = d + 0,02 [sarımlar değer] -> geçiş -> aktif adım -> geçiş -> kapalı uç) -> Tube (tel Ø) -> iki Trim Body
(z = 0 ve z = len düzlemleri = taşlanmış uçlar). Sketch yok (eğri denklemle).
Kontrol parçasından: d (Usta ölçüsü), od, l0, nt (Rev F). Uç sarımı parametreleri taramaya oturtuldu
(`parts\C_common\spring_fit3.py`, kapalı uç adımı = d kısıtıyla).

## Bilinen sapma - taramanın tel şişmesi (K2'den önce bildirilir)
Tel CAD'de Usta'nın ölçtüğü Ø1,0; taramada aynı tel Ø1,22 görünüyor (yan başına ~+0,11). Sarım merkez çizgisi ve
adım taramadan (merkez çizgisi silindiri rms 0,04-0,05), bu yüzden tarama yüzeyi CAD tel yüzeyinin sistematik olarak
~0,11 dışında kalır: aşağıdaki tabloda "ortalama" sütunu bu kaymadır, "sd" sütunu kaymadan arındırılmış uyumdur.
Bu sistematik fark modelleme hatası değildir; K2 sonucunu A değerlendirir (CR-C-02 kapı notu).
Tarama yayın yan yatmış halidir; masaya bakan alt yarı yoktu (masa silindi).
**K2 dışında tutulması istenen tarama bölgeleri:** yok.

## C'nin kendi K2 tahmini
Fazı / uç yönü en iyi oturtmadan sonra ±0,15 içinde %63,4: **tutmadı** (kapı %90). Ortalama +0,104 = tel şişmesi
(Usta 1,0 / tarama 1,22); aktif sarımlarda kaymadan arındırılmış sd 0,113, uç sarımlarında 0,21 (uç sarımlarının
gerçek şekli parçalı adım modelinden sapıyor; taramanın en zayıf bölgesi). Tel Usta ölçüsünde bırakıldı (tasarım
niyeti ve hesap için doğru değer); kapıyı geçirmek için teli taramaya şişirmek doğru olmaz.
