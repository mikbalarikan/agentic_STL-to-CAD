"""EP5-DR02_SPRING-FRONT front spring (short, stainless) - free length, closed and ground ends (NX 2206 journal, headless).

    run_journal build.py -args <out dir>        (ULKA_OFFLINE=1: CR-C-01 values as placeholders)

Moving part, own axis: Z = coil axis, z = 0 and z = dr02_len the ground end planes, wire start at +X, right hand.
dr02_len = dr02_l0 (free); A makes the installed copy by setting dr02_len. Centre line = law curve with a
piecewise pitch (closed end turns, ramps, active pitch derived from the length) -> Tube -> two Trim Bodies.
Sources: sessions/C_MEASURED.md, cr/CR-C-01.md (fit: parts/C_common/spring_fit2.py on scan EP5-DR02\_aligned.stl).
"""
import os, sys
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\C_common\nxlib")
import spring_job

LINKS = {   # control part (Rev F)
    "dr02_d": ("mm", 1.2), "dr02_od": ("mm", 12.94), "dr02_l0": ("mm", 18.93), "dr02_nt": (None, 6.06),
}
INTERNAL = {   # fitted to the whole scan surface with pitch(end) = d (Usta) + gap, parts/C_common/spring_fit3.py
    "dr02_pe_gap": (0.02, "mm", "gap between touching end coils (closed ends)"),
    "dr02_a1": (0.835, None, "closed turns at the z = 0 end [fit with closed-end pitch = d + gap, spring_fit3.py]"),
    "dr02_b1": (0.1, None, "pitch ramp turns at the z = 0 end [fit with closed-end pitch = d + gap, spring_fit3.py]"),
    "dr02_a2": (0.75, None, "closed turns at the far end [fit with closed-end pitch = d + gap, spring_fit3.py]"),
    "dr02_b2": (0.1, None, "pitch ramp turns at the far end [fit with closed-end pitch = d + gap, spring_fit3.py]"),
    "dr02_grind": (0.36, "mm", "grind depth at the ends [fit with closed-end pitch = d + gap, spring_fit3.py]"),
}
spring_job.run(sys.argv[1], "EP5-DR02_SPRING-FRONT", "dr02_", LINKS, INTERNAL, {"pitch": 3.891})
