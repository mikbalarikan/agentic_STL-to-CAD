"""DR01 scan-to-CAD deviation by zones. usage: dev_dr01.py <cad stl> [tag]"""
import sys, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\C_common")
import rb
from dev import run
cad = sys.argv[1]; tag = sys.argv[2] if len(sys.argv) > 2 else "dev"
def rr(P): return np.hypot(P[:, 0], P[:, 1])
zones = {
    "F armature OD": lambda P, N: (rr(P) > 6.9) & (P[:, 2] > -19.4) & (P[:, 2] < -0.6),
    "F piston OD (d_p)": lambda P, N: (rr(P) < 2.8) & (rr(P) > 2.2) & (P[:, 2] > 8.5) & (P[:, 2] < 25.0) & (np.abs(N[:, 2]) < 0.5),
    "F front face": lambda P, N: (np.abs(P[:, 2]) < 0.1) & (rr(P) > 5.2) & (rr(P) < 6.6),
    "F rear face": lambda P, N: (np.abs(P[:, 2] + 20.04) < 0.1) & (rr(P) > 5.2) & (rr(P) < 6.6),
    "F front pilot": lambda P, N: (rr(P) > 4.7) & (rr(P) < 5.3) & (P[:, 2] > 0.2) & (P[:, 2] < 1.0),
    "F collar OD": lambda P, N: (rr(P) > 4.0) & (rr(P) < 4.6) & (P[:, 2] > 6.5) & (P[:, 2] < 7.8),
    "F ball seat + piston bore": lambda P, N: (rr(P) < 2.2) & (P[:, 2] > 22.0),
    "F rear bore": lambda P, N: (rr(P) < 3.3) & (P[:, 2] < -16.0) & (P[:, 2] > -20.6),
    "window region": lambda P, N: (P[:, 2] > 1.3) & (P[:, 2] < 6.5) & (rr(P) < 4.6),
    "all": lambda P, N: np.ones(len(P), bool),
}
run("DR01", [cad], rb.SCAN + r"\EP5-DR01_aligned.stl", zones=zones, tag=tag)
