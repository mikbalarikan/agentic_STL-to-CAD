## Çerçeve
Hareketli parça, kendi ekseninde: Z = armatür ekseni, +Z piston ucuna (= pompa +Z), z = 0 armatür ön alnı (DR02
oturma yüzü), **+X = yan pencere (çapraz delik) ekseni**. A montajda `z_dr01` ile konumlar. Tek gövde (armatür +
pres geçmiş piston birleşik).
Unsur ağacı: `SK_BODY` (tüm dönel profil: arka pilot, armatür, ön pilot, yaka, piston, eksenel delik, piston deliği,
VL01 oturma havşası; DOF 0) -> Revolve -> `SK_WINDOW` (Ø5,15 daire) -> Extrude (±X, Subtract) -> köşe radyusları.

## Türetilen (taramada yok) bölgeler - K2'den önce bildirilir
- Eksenel delik Ø6,09'un sonu = piston deliğinin başı z = 6,36 (`bore_end_z`): delik duvarı pencereden z 5,5'e kadar
  görülüyor; aradaki geçiş ve armatür içindeki delik boyu (z -16,2 .. 1,4 arası görülmedi) türetildi.
- Piston borusu ile armatür arasındaki pres sınırı modellenmedi (tek gövde; taramada da sınır yok).
**K2 dışında tutulması istenen tarama bölgeleri:** yok.

## Bilinen sapmalar / notlar
- Pencere Aşama 1'de "enine yarık" diye okunmuştu; çevrimdışı karşılaştırmada çapraz delik olduğu görüldü: Ø5,154
  silindir uydurması (rms 0,030), ekseni z 3,91, armatür eksenini 0,04 kaçıkla kesiyor. C_MEASURED düzeltildi.
- Bilya oturma havşası + piston deliği: ±0,15 içinde %96,2 (kapsama ~95°, ince delik içi).
- Tarama kapsaması ~265° (tüm boyda +Y tarafı, θ ≈ +45..+145, gölge).
- `d_p` = 4,97 (Rev A/B). Not: Usta'nın tel ölçüsü (DR02 1,0 / DR03 1,3) taramanın ince tellerde 0,07-0,11/yan
  şiştiğini gösterdi; piston için bunun etkisi CR-C-02'de A'ya yazıldı (pistonda ölçülmeden bilinemez).
