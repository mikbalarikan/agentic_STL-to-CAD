"""EP5-DR01 armature + hollow piston - native parametric build (NX 2206 journal, headless).

    run_journal build.py -args <out dir>        (ULKA_OFFLINE=1: dry run with placeholder links, before Rev A)

Part frame (moving part, own axis; A places it along the stroke): Z = armature axis, +Z to the piston tip
(= pump +Z), z = 0 the armature front face (DR02 seat). One solid (armature and pressed-in piston as one body).
Features: SK_BODY -> Revolve (whole turned profile incl. bore, piston bore and ball seat) -> SK_WINDOW ->
Extrude symmetric (subtract, transverse slot through the collar) -> edge rounds.
Sources: sessions/C_MEASURED.md (scan EP5-DR01_aligned.stl).
"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\C_common\nxlib")
import NXOpen
import nxh, nxf, nxa
import rj
from rj import BOOL, X, Y, Z

OUT = sys.argv[1]
NAME = "EP5-DR01_ARMATURE-PISTON"
LINKS = {   # control-part expressions (ULKA_INTERFACES Rev A section 9): name -> unit, offline placeholder
    "dr01_arm_d": ("mm", 14.34), "dr01_arm_len": ("mm", 20.04), "dp": ("mm", 4.97), "dr01_tip": ("mm", 25.33),
    "dr01_collar_d": ("mm", 8.5), "dr01_collar_front": ("mm", 7.99), "dr01_fpilot_d": ("mm", 10.02),
    "dr01_rpilot_d": ("mm", 9.5), "dr01_rear_len": ("mm", 0.98), "dr01_bore_d": ("mm", 6.09),
    "dr01_pin_id": ("mm", 2.72), "dr01_seat_d": ("mm", 4.0),
}
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, NAME)
    p, M = c.part, c.M
    for n, (u, off) in LINKS.items():
        c.link(n, u, off)
    # ---- part-internal masters (C_MEASURED, DR01 table)
    c.e("step_h", 1.24, "front pilot step height above the front face [scan 1.242]")
    c.e("seat_depth", 0.72, "axial depth of the ball seat cone at the tip [scan cone 24.61 .. 25.33]")
    c.e("xh_d", 5.15, "transverse cross hole (side window) through the collar, axis = +X [scan cylinder fit 5.154, rms 0.030]")
    c.e("xh_z", 3.91, "cross-hole axis height [scan 3.906 (axis 0.04 off the armature axis)]")
    c.e("bore_end_z", 6.36, "end of the axial bore = start of the piston bore, DERIVED: bore wall seen through the window up to z 5.5, flat at 6.36")
    c.e("r_arm", 0.5, "armature outer edge rounds [scan R0.5-0.6]")
    c.e("r_pilot", 0.4, "rear pilot outer edge round [scan ~R0.4]")
    c.e("r_tip", 0.15, "piston tip outer edge round [scan ~R0.2]")

    A, L, fp, rp = M["dr01_arm_d"] / 2, M["dr01_arm_len"], M["dr01_fpilot_d"] / 2, M["dr01_rpilot_d"] / 2
    h, b, st, cd, cz = M["dr01_rear_len"], M["dr01_bore_d"] / 2, M["step_h"], M["dr01_collar_d"] / 2, M["dr01_collar_front"]
    rp_, tz, sd, pb, sdep, w1 = M["dp"] / 2, M["dr01_tip"], M["dr01_seat_d"] / 2, M["dr01_pin_id"] / 2, M["seat_depth"], M["bore_end_z"]
    hv = [(b, -(L + h), "dr01_bore_d/2", "dr01_arm_len+dr01_rear_len"),
          (rp, -(L + h), "dr01_rpilot_d/2", None),
          (rp, -L, None, "dr01_arm_len"),
          (A, -L, "dr01_arm_d/2", None),
          (A, 0.0),
          (fp, 0.0, "dr01_fpilot_d/2", None),
          (fp, st, None, "step_h"),
          (cd, st, "dr01_collar_d/2", None),
          (cd, cz, None, "dr01_collar_front"),
          (rp_, cz, "dp/2", None),
          (rp_, tz, None, "dr01_tip"),
          (sd, tz, "dr01_seat_d/2", None),
          (pb, tz - sdep, "dr01_pin_id/2", "dr01_tip-seat_depth"),
          (pb, w1, None, "bore_end_z"),  # axial bore ends, piston bore starts (DERIVED)
          (b, w1)]
    S = c.sketch("xz", "SK_BODY")
    S.profile(hv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (A - 0.1, -1.0)), nxf.axis_from(p, c.dat.z))
    f.SetName("BODY_REVOLVE")
    body = f.GetBodies()[0]
    v_rev = rj.revolve_volume([(q[0], q[1]) for q in hv])
    c.chk("revolved body volume = profile (Pappus)", c.vol(body), v_rev, 1e-3)

    # ---- window: transverse cross hole through the collar (openings face +-X)
    xa, xz = M["xh_d"] / 2, M["xh_z"]
    S = c.sketch("yz", "SK_WINDOW")
    S.circle(0.0, xz, M["xh_d"], cvf="xh_z", df="xh_d")
    c.done(S)
    f = nxh.extrude(p, S.section(None, (0.0, xz)), X, "-dr01_arm_d", "dr01_arm_d", op=BOOL.Subtract, target=body)
    f.SetName("WINDOW_CROSS_HOLE")
    v_win = v_rev - c.vol(body)
    # removed = hole cylinder x material between r_in (bore below xh_z, piston bore above) and the collar
    n, vv = 600, 0.0
    for i in range(n):
        y = -xa + (i + 0.5) * 2 * xa / n
        hz = math.sqrt(max(xa * xa - y * y, 0.0))
        for j in range(n):
            z = xz - hz + (j + 0.5) * 2 * hz / n
            ri = b if z < w1 else pb
            if abs(y) < cd:
                vv += 2 * (math.sqrt(cd * cd - y * y) - math.sqrt(max(ri * ri - y * y, 0.0))) * (2 * xa / n) * (2 * hz / n)
    c.chk("window volume = hole x collar material (numeric, 600x600 grid)", v_win, vv, 0.03)
    c.chk("still one solid", len(nxh.solids(p)), 1, 0)

    # ---- edge rounds
    def ring(radius, z):
        out = []
        for ed in body.GetEdges():
            bb = nxh.bbox(ed)
            if abs(bb[2] - z) < 1e-4 and abs(bb[5] - z) < 1e-4 and abs(bb[3] - radius) < 1e-3 and abs(bb[0] + radius) < 1e-3:
                out.append(ed)
        return out
    v0 = c.vol(body)
    e_arm = ring(A, 0.0) + ring(A, -L)
    c.chk("two armature rim edges", len(e_arm), 2, 0)
    nxh.blend(p, e_arm, "r_arm").SetName("ARM_RIM_R")
    e_p = ring(rp, -(L + h))
    c.chk("rear pilot rim edge", len(e_p), 1, 0)
    nxh.blend(p, e_p, "r_pilot").SetName("PILOT_RIM_R")
    e_t = ring(rp_, tz)
    c.chk("piston tip outer edge", len(e_t), 1, 0)
    nxh.blend(p, e_t, "r_tip").SetName("TIP_R")
    dv = v0 - c.vol(body)
    # edge round on a convex 90 deg ring edge of radius R removes (1 - pi/4) r^2 x 2 pi (R - k r), k = (10-3pi)/(3(4-pi))
    k = (10 - 3 * math.pi) / (3 * (4 - math.pi))
    rnd = lambda R, r: (1 - math.pi / 4) * r * r * 2 * math.pi * (R - k * r)
    exp = 2 * rnd(A, M["r_arm"]) + rnd(rp, M["r_pilot"]) + rnd(rp_, M["r_tip"])
    c.chk("edge rounds removed the analytic ring volumes", dv, exp, 1e-3)

    # ---- interface read-back from the solid
    def cyl_d(r0):
        fs = [q for q in rj.cyl_faces(body) if abs(abs(q[3]) - r0) < 1e-6]
        return 2 * abs(fs[0][3]) if fs else None
    c.chk("armature diameter", cyl_d(A), M["dr01_arm_d"], 1e-6)
    c.chk("piston diameter d_p", cyl_d(rp_), M["dp"], 1e-6)
    bb = nxh.bbox(body)
    c.chk("piston tip z", bb[5], tz, 1e-4)
    c.chk("rear end z", bb[2], -(L + h), 1e-4)
    fr = [q for q in rj.plane_faces(body) if abs(q[2][2]) > 0.999 and abs(q[1][2]) < 1e-6]
    c.chk.true("front face at z = 0 exists", len(fr) >= 1)

    # ---- regeneration (internal master; linked values are never edited here): cross hole 5.15 -> 5.5 -> back
    v_nom = c.vol(body)
    nxh.set_expr(p, "xh_d", 5.5); nxh.update()
    v_big = c.vol(body)
    errs = [str(x) for x in nxh.feature_errors(p)]
    nxh.set_expr(p, "xh_d", M["xh_d"]); nxh.update()
    c.chk.true("regeneration xh_d -> 5.5: volume drops, no errors", v_big < v_nom and not errs, "%.4f -> %.4f %s" % (v_nom, v_big, errs))
    c.chk("regeneration back to nominal", c.vol(body), v_nom, 1e-6 * v_nom)
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
