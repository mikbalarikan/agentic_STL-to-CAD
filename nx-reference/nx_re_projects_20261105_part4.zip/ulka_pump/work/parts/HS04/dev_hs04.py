"""HS04: scan against the NX model. Scan frame: z=0 bottom (scanner table), axis = ring axis -> pump z + z_hs04_bot."""
import os, sys, json
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\_B_common")
import numpy as np
import rb, dev

O = r"C:\NX_MCP_WORKSPACE\ulka\parts\HS04\out"
zb = json.load(open(os.path.join(O, "build.json"), encoding="utf-8"))["linked"]["z_hs04_bot"]
T = np.eye(4); T[2, 3] = zb
r = lambda P: np.hypot(P[:, 0], P[:, 1])
z = lambda P: P[:, 2] - zb
rad = lambda P, N: (P[:, 0] * N[:, 0] + P[:, 1] * N[:, 1]) / np.maximum(r(P), 1e-9)
zones = {
    "outer wall (OD)": lambda P, N: (z(P) > 0.5) & (z(P) < 8.6) & (rad(P, N) > 0.8),
    "inner wall (ID)": lambda P, N: (z(P) > 0.5) & (z(P) < 8.6) & (rad(P, N) < -0.8),
    "top face": lambda P, N: (z(P) > 8.5) & (N[:, 2] > 0.8),
}
excl = lambda P, N: (z(P) < 0.35) | (r(P) < 8.0)
refit = {"walls (pose of the ring)": lambda P, N: (z(P) > 0.5) & (z(P) < 8.6) & (np.abs(N[:, 2]) < 0.3)}
dev.run("HS04", [os.path.join(O, "EP5-HS04_SPACER-RING_body.stl")], os.path.join(rb.SCAN, "EP5-HS04_aligned.stl"), zones, T=T, exclude=excl, refit=refit)
