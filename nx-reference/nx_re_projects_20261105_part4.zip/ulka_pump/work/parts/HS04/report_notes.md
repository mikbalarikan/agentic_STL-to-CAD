## Çerçeve ve tasarım niyeti

Pompa çerçevesinde yerinde (Rev A §1-2): Z pompa ekseni, alt yüz `z_hs04_bot` = -28,22, üst yüz -19,12. OD / ID /
boy kontrol parçasından. Tek parça içi ölçü `hs04_ch` 0,35 x 45° iç kenar pahı: taramada bir uçta (üst yüz iç
kenarı r 8,91, delik r 8,56) görülen kenar kırma. Halkanın pompadaki yönü bilinmiyor; pah +Z (çıkış) ucuna
konuldu. Başka simetri kırıcı özellik yok.

## Taramanın göstermediği / dışarıda tutulan bölgeler (QA'dan önce)

- Tarama masada dik, tek yönden: dış duvar yalnız bir yarıda, iç duvar öbür yarıda (~140° her biri). Alt yüz
  masaya oturuyordu, taranmadı: taramada alt yüz bölgesi (z < 0,35 parça içi) ve masa kalıntısı (r < 8,0) dışarıda.
- OD tarama boyunca 20,68 (alt) -> 20,98 (üst) değişiyor; ortak merkezli uydurma 20,78 = Rev A. Duvarlarda
  kalan sapmanın büyük kısmı bu koniklik / eğik tarama (kendi oturmasında 0,89° eğim).

## Kabul (B'nin kendi ölçümü; bağımsız QA A'da)

- K1: OD 20,78, ID 17,11, boy 9,1 = Rev A expression'ları (CAD tam). Tarama özelliği zayıf (kapsama < 180°) ->
  bant max(0,05; 2·sd).
- K2 (T = 0,15): toplamın %91,1'i ±0,15 içinde (≥ %90 tuttu).
