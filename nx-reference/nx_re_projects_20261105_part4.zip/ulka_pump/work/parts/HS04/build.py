"""EP5-HS04 plastic spacer ring - native parametric build (NX 2206, headless).

    run_journal build.py -args <out dir>

Modelled in place in the pump frame (ULKA_INTERFACES Rev A): Z = pump axis, +Z inlet -> outlet; the ring sits in the
EM01 bore between the two EM03 sleeves, z_hs04_bot .. z_hs04_bot + hs04_h. OD / ID / height come from the control
part. The scanned inner edge break (one end, r 8.91 on the face) is a 45 deg chamfer at the +Z end (orientation in
the pump not known - the ring is symmetric otherwise).
Features: PL_HS04_BOT + AX_BOT_X -> SK_PROFILE -> Revolve.
"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\_B_common\nxlib")
import NXOpen
import nxh, nxf, nxa
import rj
from rj import BOOL, X, Y, Z

OUT = sys.argv[1]
NAME = "EP5-HS04_SPACER-RING"
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, NAME)
    p, M = c.part, c.M
    for n in ("z_hs04_bot", "hs04_od", "hs04_id", "hs04_h", "em01_bore_min_d", "hs01_tube_od"):
        c.link(n)
    c.e("hs04_ch", 0.35, "inner edge chamfer at the +Z end [scan: top face inner edge r 8.91 vs bore r 8.56]")
    c.d("c_hs04_bore", "(em01_bore_min_d-hs04_od)/2", "radial clearance ring / EM01 bore (narrowest)")
    c.d("c_hs04_tube", "(hs04_id-hs01_tube_od)/2", "radial clearance ring / HS01 tube")
    zb = M["z_hs04_bot"]
    fp, pl = nxf.datum_plane(p, "offset", [c.dat.xy], "z_hs04_bot", "PL_HS04_BOT")
    fa, ax = nxf.datum_axis(p, "intersection", pl, c.dat.xz, name="AX_BOT_X")

    ri, ro, h, ch = M["hs04_id"] / 2, M["hs04_od"] / 2, M["hs04_h"], M["hs04_ch"]
    pv = [(ri, 0.0, "hs04_id/2", None), (ro, 0.0, "hs04_od/2", None), (ro, h, None, "hs04_h"),
          (ri + ch, h, "hs04_id/2+hs04_ch", None), (ri, h - ch, None, "hs04_h-hs04_ch")]
    S = c.sketch("xz", "SK_PROFILE", hax=ax, shift=(0.0, 0.0, zb))
    S.profile(pv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, ((ri + ro) / 2, h / 2)), nxf.axis_from(p, c.dat.z))
    f.SetName("RING")
    body = f.GetBodies()[0]
    v0 = rj.revolve_volume([(a[0], a[1]) for a in pv])
    c.chk("ring volume = revolved profile", c.vol(body), v0, 1e-6 * v0)
    c.chk("one solid", len(nxh.solids(p)), 1, 0)

    # ---- interface read-back
    cf = rj.cyl_faces(body)
    c.chk("OD", 2 * max(abs(q[3]) for q in cf), M["hs04_od"], 1e-9)
    c.chk("ID", 2 * min(abs(q[3]) for q in cf), M["hs04_id"], 1e-9)
    pf = rj.plane_faces(body)
    c.chk.true("bottom face on z_hs04_bot", any(abs(q[1][2] - zb) < 1e-6 and q[2][2] < -0.999999 for q in pf), [q[1] for q in pf])
    c.chk.true("top face on z_hs04_bot + hs04_h", any(abs(q[1][2] - zb - h) < 1e-6 and q[2][2] > 0.999999 for q in pf), [q[1] for q in pf])
    c.chk.true("radial clearances positive", M["c_hs04_bore"] > 0 and M["c_hs04_tube"] > 0, (M["c_hs04_bore"], M["c_hs04_tube"]))
    c.notes["z_planes"] = {"bottom": zb, "top": zb + h}
    c.notes["clearances"] = {"ring/EM01 bore": M["c_hs04_bore"], "ring/HS01 tube": M["c_hs04_tube"]}

    # ---- regeneration: chamfer 0.35 -> 0.6 -> 0.35
    v_nom = c.vol(body)
    nxh.set_expr(p, "hs04_ch", 0.6); nxh.update()
    v_big = c.vol(body)
    errs = [str(x) for x in nxh.feature_errors(p)]
    nxh.set_expr(p, "hs04_ch", 0.35); nxh.update()
    pv2 = [(ri, 0.0), (ro, 0.0), (ro, h), (ri + 0.6, h), (ri, h - 0.6)]
    c.chk("regeneration hs04_ch 0.35 -> 0.6", v_big, rj.revolve_volume(pv2), 1e-6 * v_nom)
    c.chk.true("regeneration: no feature errors", not errs, errs)
    c.chk("regeneration back to nominal", c.vol(body), v_nom, 1e-6 * v_nom)
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
