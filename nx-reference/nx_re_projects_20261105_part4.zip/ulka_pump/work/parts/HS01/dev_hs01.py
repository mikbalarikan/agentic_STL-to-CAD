"""HS01 scan-to-CAD deviation by zones (CAD in the scan part frame: flange face z = 0). usage: dev_hs01.py <cad stl> [tag] [zshift]"""
import sys, numpy as np
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\C_common")
import rb
from dev import run
cad = sys.argv[1]; tag = sys.argv[2] if len(sys.argv) > 2 else "dev"
zs = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0      # assembly z of the flange face (CAD frame) -> scan moved by +zs
T = np.eye(4); T[2, 3] = zs
def rr(P): return np.hypot(P[:, 0], P[:, 1])
def z(P): return P[:, 2] - zs
zones = {
    "F tube OD": lambda P, N: (rr(P) > 7.7) & (rr(P) < 8.4) & (z(P) > -50) & (z(P) < -5),
    "F socket bore": lambda P, N: (rr(P) < 7.65) & (z(P) > -5.5) & (z(P) < 5.0),
    "F flange face": lambda P, N: (np.abs(z(P)) < 0.1) & (rr(P) > 8.5) & (rr(P) < 9.9),
    "F lip OD": lambda P, N: (rr(P) > 7.7) & (rr(P) < 8.3) & (z(P) > 0.6) & (z(P) < 5.0),
    "flange OD": lambda P, N: (rr(P) > 9.6) & (z(P) > -3) & (z(P) < -0.2),
    "neck": lambda P, N: (z(P) > -61.5) & (z(P) < -54),
    "nipple": lambda P, N: (z(P) < -62.5),
    "all": lambda P, N: np.ones(len(P), bool),
}
run("HS01", [cad], rb.SCAN + r"\EP5-HS01_aligned.stl", zones=zones, T=T, tag=tag)
