"""EP5-HS01 inlet body + armature tube - native parametric build (NX 2206 journal, headless).

    run_journal build.py -args <out dir>        (ULKA_OFFLINE=1: dry run with placeholder links, before Rev A)

Fixed part, modelled in place in the pump frame: Z = pump axis, +Z from the inlet nipple to the socket mouth;
the flange face (outlet side) on PL_HS01_FLANGE at z = z_hs01_flange (Rev A). No angular features (a body of revolution).
Features: datums -> SK_PROFILE (outer: nipple with two barbs, neck, tube, flange, socket lip; inner: socket / tube
bore, nipple bore) -> Revolve.
Sources: sessions/C_MEASURED.md (scan EP5-HS01_aligned.stl, z = 0 there = flange face).
"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\C_common\nxlib")
import NXOpen
import nxh, nxf, nxa
import rj
from rj import BOOL, X, Y, Z

OUT = sys.argv[1]
NAME = "EP5-HS01_INLET-BODY"
LINKS = {   # control-part expressions (ULKA_INTERFACES Rev A/B section 9): name -> unit, offline placeholder
    "z_hs01_flange": ("mm", 4.789), "hs01_tube_od": ("mm", 16.09), "hs01_bore_d": ("mm", 14.92),
    "hs01_flange_d": ("mm", 20.23), "hs01_flange_t": ("mm", 3.23), "hs01_lip_od": ("mm", 15.82), "hs01_lip_h": ("mm", 5.31),
    "hs01_neck_d": ("mm", 12.92), "hs01_len": ("mm", 78.0), "hs01_nip_d": ("mm", 6.9), "hs01_inner_bot": ("mm", 52.0),
}
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, NAME)
    p, M = c.part, c.M
    for n, (u, off) in LINKS.items():
        c.link(n, u, off)
    # ---- part-internal masters (C_MEASURED, HS01 table; depths below the flange face are positive numbers)
    c.e("fl_ch", 0.5, "chamfer at the flange underside rim [scan ~0.5]")
    c.e("tube_end_z", 54.8, "end of the tube cylinder below the flange face [scan r-z overlay: cone 54.8 -> 56.9]")
    c.e("neck_top_z", 56.9, "top of the neck cylinder (cone tube -> neck above it) [scan r 7.5 at -55.5, 6.75 at -56.5]")
    c.e("neck_z", 61.0, "neck lower face below the flange face [scan -60.8 .. -61.3]")
    c.e("barb_root_d", 6.1, "nipple barb root / shank diameter [scan 6.15]")
    c.e("barb1_z", 68.6, "crest of the barb nearer the tip [scan -68.8]")
    c.e("barb2_z", 65.6, "crest of the second barb [scan -65.8]")
    c.e("barb_back", 0.4, "axial length of the barb back face [scan ~0.5, blurred]")
    c.e("nip_tip_d", 5.3, "nipple tip diameter [scan 5.3]")
    c.d("hs01_len_nip", "hs01_len-hs01_lip_h", "nipple tip below the flange face [scan -72.7]")
    c.e("nip_bore_d", 3.0, "nipple / inlet bore, DERIVED (not scanned; tip wall ~1.15)")

    zf = M["z_hs01_flange"]
    fpl, pl_face = nxf.datum_plane(p, "offset", [c.dat.xy], "z_hs01_flange", "PL_HS01_FLANGE")
    fax, ax_face = nxf.datum_axis(p, "intersection", pl_face, c.dat.xz, name="AX_FLANGE_X")

    to, bi, fo, ch, lo = M["hs01_tube_od"] / 2, M["hs01_bore_d"] / 2, M["hs01_flange_d"] / 2, M["fl_ch"], M["hs01_lip_od"] / 2
    nb, br, bc, bb = M["nip_bore_d"] / 2, M["barb_root_d"] / 2, M["hs01_nip_d"] / 2, M["barb_back"]
    pv = [(nb, -M["hs01_len_nip"], "nip_bore_d/2", "hs01_len_nip"),
          (M["nip_tip_d"] / 2, -M["hs01_len_nip"], "nip_tip_d/2", None),
          (bc, -M["barb1_z"], "hs01_nip_d/2", "barb1_z"),
          (br, -(M["barb1_z"] - bb), "barb_root_d/2", "barb1_z-barb_back"),
          (bc, -M["barb2_z"], "hs01_nip_d/2", "barb2_z"),
          (br, -(M["barb2_z"] - bb), "barb_root_d/2", "barb2_z-barb_back"),
          (br, -M["neck_z"], None, "neck_z"),
          (M["hs01_neck_d"] / 2, -M["neck_z"], "hs01_neck_d/2", None),
          (M["hs01_neck_d"] / 2, -M["neck_top_z"], None, "neck_top_z"),
          (to, -M["tube_end_z"], "hs01_tube_od/2", "tube_end_z"),
          (to, -M["hs01_flange_t"], None, "hs01_flange_t"),
          (fo - ch, -M["hs01_flange_t"], "hs01_flange_d/2-fl_ch", None),
          (fo, -(M["hs01_flange_t"] - ch), "hs01_flange_d/2", "hs01_flange_t-fl_ch"),
          (fo, 0.0),
          (lo, 0.0, "hs01_lip_od/2", None),
          (lo, M["hs01_lip_h"], None, "hs01_lip_h"),
          (bi, M["hs01_lip_h"], "hs01_bore_d/2", None),
          (bi, -M["hs01_inner_bot"], None, "hs01_inner_bot"),
          (nb, -M["hs01_inner_bot"])]
    S = c.sketch("xz", "SK_PROFILE", hax=ax_face, shift=(0.0, 0.0, zf))
    S.profile(pv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (to - 0.1, -20.0)), nxf.axis_from(p, c.dat.z))
    f.SetName("BODY_REVOLVE")
    body = f.GetBodies()[0]
    v_rev = rj.revolve_volume([(a[0], a[1]) for a in pv])
    c.chk("body volume = revolved profile (Pappus)", c.vol(body), v_rev, 1e-3)

    # ---- interface read-back
    def cyl_d(r0):
        fs = [q for q in rj.cyl_faces(body) if abs(abs(q[3]) - r0) < 1e-6]
        return 2 * abs(fs[0][3]) if fs else None
    c.chk("tube outer diameter", cyl_d(to), M["hs01_tube_od"], 1e-6)
    c.chk("tube / socket bore", cyl_d(bi), M["hs01_bore_d"], 1e-6)
    bx = nxh.bbox(body)
    c.chk("socket mouth z", bx[5], zf + M["hs01_lip_h"], 1e-4)
    c.chk("nipple tip z", bx[2], zf - M["hs01_len_nip"], 1e-4)
    c.chk("flange face at z_hs01_flange (probe)", abs(nxh.dist_to(p, body, (0.0, (fo + lo) / 2, zf))), 0.0, 1e-6)
    c.chk("bore bottom at flange - hs01_inner_bot (probe)", abs(nxh.dist_to(p, body, (0.0, (nb + bi) / 2, zf - M["hs01_inner_bot"]))), 0.0, 1e-6)
    c.notes["tube_wall"] = round((M["hs01_tube_od"] - M["hs01_bore_d"]) / 2, 4)
    c.notes["bottom_wall_to_neck_face"] = round(M["neck_z"] - M["hs01_inner_bot"], 4)
    c.chk.true("flat tube bottom above the outer tube end (Rev B: 52.0 < 55.0)", M["hs01_inner_bot"] < M["tube_end_z"], c.notes)

    # ---- regeneration (internal master only; linked values are never edited here): nip_bore_d 3.0 -> 3.5 -> back
    v_nom = c.vol(body)
    nxh.set_expr(p, "nip_bore_d", 3.5); nxh.update()
    v2 = c.vol(body)
    errs = [str(x) for x in nxh.feature_errors(p)]
    nxh.set_expr(p, "nip_bore_d", M["nip_bore_d"]); nxh.update()
    c.chk.true("regeneration nip_bore_d 3.5: volume drops, no errors", v2 < v_nom and not errs, "%.3f -> %.3f %s" % (v_nom, v2, errs))
    c.chk("regeneration back to nominal", c.vol(body), v_nom, 1e-6 * v_nom)
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
