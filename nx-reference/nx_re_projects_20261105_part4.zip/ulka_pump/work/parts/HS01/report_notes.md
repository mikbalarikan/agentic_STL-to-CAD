## Çerçeve ve yerleşim
Sabit parça, montaj koordinatında yerinde: Z pompa ekseni, +Z nipelden soket ağzına. Flanş üst yüzü
`PL_HS01_FLANGE` datum düzleminde, z = `z_hs01_flange` (Rev F 4,710). Parça dönel; açısal özellik yok.
Tek unsur: profil sketch'i (`SK_PROFILE`, flanş yüzü ekseninden ölçülü, DOF 0) -> Revolve.
Taramaya karşılaştırma: tarama parça çerçevesinde (flanş yüzü z=0) -> z_hs01_flange kadar ötelenerek (`dev_hs01.py ... <z_hs01_flange>`).

## Türetilen (taramada yok) bölgeler - K2'den önce bildirilir
- Tüp iç Ø14,92 boyunca (taramada yalnız ağızdan ~10 mm, z_flanş +5,3..-5,2 görülüyor): Rev A `hs01_bore_d`.
- Tüp iç dibi: flanştan `hs01_inner_bot` = 52,0 (Rev B, türetildi; Rev A 55,3). Düz dip, delik Ø14,92 dibe kadar;
  dış geçişe (54,8) 2,8 mm et. DR03 düz dibe oturur.
- Nipel iç deliği Ø3,0 (`nip_bore_d`), uçtan tüp dibine kadar: taranmadı, türetildi.
- Nipel kökü z_flanş -61,3 .. -63,3 bölgesi taranmadı (gölge); tırnak dibi Ø6,1 ile köke kadar uzatıldı.
**K2 dışında tutulması istenen tarama bölgeleri:** yok (bu bölgelerde tarama noktası da yok; yalnız CAD yüzeyi var).

## Bilinen sapmalar
- Boyun geçişi (dış koni z_flanş -54,8 -> -56,9, r-z bindirmesinden) ve boyun alt ağzı (-60,5..-61, taramada küçük
  bir genişleme ~Ø14, modellenmedi): genel yüzey bölgesi, oranı aşağıdaki tabloda ("neck").
- Nipel tırnakları Ø6,9 (Rev A `hs01_nip_d`; datasheet 7,2): tarama 200-230° kapsıyor, tırnak arka yüzü bulanık;
  ±0,15 içinde %85,6.
- Flanş dış çevresinde birkaç tarama kümesi r ≈ 11'de (+0,4..0,55): kalıp çapağı / tarama artığı, modellenmedi.
