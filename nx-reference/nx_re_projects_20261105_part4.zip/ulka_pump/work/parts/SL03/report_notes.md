## Çerçeve
Yerinde, nötr (kalıp) halinde torus: alt yüz `z_sl03` (HS02 flanşı üstü, HS03 üst kademesine yüz contası). ID / kesit kontrol parçasından.

Rev F (CR-D-03): 13,15 x 1,10 (OD 15,35), A'nın ID / OD uydurmasından; standart dışı, tarama değeri (en yakın metrik 13 x 1,0). Tarama tepe yüksekliği 0,91 (halka altlıkta yassı), genişlik 1,34. Ön kontrol: kendi oturmasıyla %84,8 ±0,15 (Rev A kesitiyle %60) - elastomer bandında yassılık nedeniyle **tutmayabilir**.
