"""Quick look: raw scan in census frame -> 2 axial sections (0/90 deg) + side silhouette. usage: look.py code [T.json key]"""
import sys, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rb
code = sys.argv[1]
path = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2].endswith('.stl') else rb.raw_path(code)
J = rb.load_json(code, "s1_census.json")
T = np.array(J["T_provisional"]) if 'aligned' not in path else np.eye(4)
m = rb.Mesh(rb.read_stl(path)).moved(T)
fig, ax = plt.subplots(1, 3, figsize=(18, 9))
for k, th in enumerate((0, 90)):
    s = m.rz(th, both=True)
    rb.plot_segs(ax[k], s, color="k", lw=0.5)
    ax[k].set_aspect("equal"); ax[k].grid(True, lw=0.3); ax[k].set_title("%s section %d deg (r,z)" % (code, th))
idx = np.random.default_rng(0).choice(len(m.c), min(60000, len(m.c)), replace=False)
ax[2].scatter(m.c[idx, 0], m.c[idx, 2], s=0.1, c=m.c[idx, 1], cmap="viridis")
ax[2].set_aspect("equal"); ax[2].grid(True, lw=0.3); ax[2].set_title("x-z points")
out = rb.pdir(code, "fig") + "/look.png"
plt.tight_layout(); plt.savefig(out, dpi=80); print(out)
