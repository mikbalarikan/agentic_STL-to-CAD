"""Spring scan: drop table plane, fit coil axis, write aligned working copy, r / theta-z plots.
usage: spring1.py code"""
import sys, numpy as np, matplotlib, json
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rb
code = sys.argv[1]
J = rb.load_json(code, "s1_census.json")
T0 = np.array(J["T_provisional"])
m = rb.Mesh(rb.read_stl(rb.raw_path(code))).moved(T0)
ztab = [L["z"] for L in J["levels"] if L["area"] > 300][0]
# table: facets near ztab facing +-z, and anything below ztab+0.35
keep = m.c[:, 2] > ztab + 0.35
print("table z %.3f, dropped %d of %d facets" % (ztab, (~keep).sum(), len(keep)))
s = m.sub(keep)
# drop small shells
v, f = rb.weld(s.tri); lab = rb.components(f, len(v)); cnt = np.bincount(lab)
k2 = cnt[lab] >= 0.01 * len(lab)
s = s.sub(k2); print("after shells:", len(s.c))
# axis direction: PCA of points in xy (spring lies flat, axis horizontal)
p = s.c
C = np.cov((p - p.mean(0)).T, aweights=s.a)
w, V = np.linalg.eigh(C)
ax0 = V[:, np.argmax(w)]
print("pca axis", ax0, w)
fc = rb.fit_cylinder(p, ax0, clip=2.5)
print("cyl fit r %.4f rms %.4f axis %s pt %s" % (fc["r"], fc["rms"], np.round(fc["axis"],4), np.round(fc["point"],3)))
axis = np.asarray(fc["axis"]); axis /= np.linalg.norm(axis)
# orient +Z along original +y-ish (arbitrary); origin = projection of min end
T1 = rb.frame(axis, np.asarray(fc["point"]))
q = s.moved(T1)
z0 = np.percentile(q.tri[:, :, 2], 0.01)
T2 = np.eye(4); T2[2, 3] = -z0
T = T2 @ T1 @ T0
q = s.moved(T2 @ T1)
rb.write_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code, q.tri, b"ulka C %s aligned: z = coil axis, z=0 at lower end" % code.encode())
rb.save_json(code, "align.json", {"T_raw_to_part": T, "table_z": ztab, "cyl": fc})
r, th, z = rb.cyl(q.c)
print("r pct 0.5/50/99.5: %.3f %.3f %.3f  -> ID %.3f OD %.3f  z range %.3f..%.3f" % (np.percentile(r, .5), np.median(r), np.percentile(r, 99.5), 2*np.percentile(r, .5), 2*np.percentile(r, 99.5), q.lo[:, 2].min(), q.hi[:, 2].max()))
fig, ax = plt.subplots(2, 1, figsize=(16, 12))
ax[0].scatter(th, z, s=0.05, c=r, cmap="jet"); ax[0].set_xlabel("theta"); ax[0].set_ylabel("z"); ax[0].grid(True)
ax[1].hist(r, 300); ax[1].grid(True)
plt.tight_layout(); plt.savefig(rb.pdir(code, "fig") + "/spring_thz.png", dpi=70)
