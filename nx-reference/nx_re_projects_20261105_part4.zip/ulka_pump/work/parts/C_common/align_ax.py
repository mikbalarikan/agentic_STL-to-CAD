"""Axisymmetric part: clean (drop small shells / table plane), refit the axis on a chosen wall, set z origin on a
chosen level, write scan/EP5-<code>_clean.stl (scanner frame) and EP5-<code>_aligned.stl (part frame).
usage: align_ax.py code   (parameters in CFG)"""
import sys, numpy as np
import rb
CFG = {
    # wall used for the axis: (kind, r window, z window) in the census frame; table: drop z below; flip: turn 180 about x
    "HS01": dict(wall=("boss", (7.6, 8.5), (-14, 32)), table=-34.2, rmax=10.8, flip=False, zero=(+1, (37.5, 39.5), (8.5, 10.5))),
    "DR01": dict(wall=("boss", (6.8, 7.5), (-14, 3)), table=None, flip=False, zero=(+1, (3.5, 5.0), (5.0, 7.0))),
}
code = sys.argv[1]; P = CFG[code]
J = rb.load_json(code, "s1_census.json")
T0 = np.array(J["T_provisional"])
raw = rb.read_stl(rb.raw_path(code))
v, f = rb.weld(raw); lab = rb.components(f, len(v)); cnt = np.bincount(lab)
keep = cnt[lab] >= 0.02 * len(raw)
m = rb.Mesh(raw).moved(T0)
if P["table"] is not None:
    keep &= m.lo[:, 2] > P["table"]
if P.get("rmax"):
    keep &= np.hypot(m.c[:, 0], m.c[:, 1]) < P["rmax"]
print("%s: %d facets, keep %d" % (code, len(raw), keep.sum()))
rb.write_stl(rb.SCAN + "/EP5-%s_clean.stl" % code, raw[keep], b"ulka C %s clean, scanner frame" % code.encode())
m = m.sub(keep)
kind, rw, zw = P["wall"]
q = m
for it in range(3):
    r, th, rad = rb.polar(q)
    sg = 1 if kind == "boss" else -1
    s = (np.abs(q.n[:, 2]) < 0.25) & (sg * rad > 0.8) & (r > rw[0]) & (r < rw[1]) & (q.c[:, 2] > zw[0]) & (q.c[:, 2] < zw[1])
    cy = rb.fit_cylinder(q.c[s], [0, 0, 1], clip=2.5)
    ax = cy["axis"] * np.sign(cy["axis"][2])
    T1 = rb.frame(ax, cy["point"])
    # keep z of the old frame: frame() puts origin at point; shift back so z stays comparable
    T1z = np.eye(4); T1z[2, 3] = (cy["point"] @ ax)
    Tit = T1z @ T1
    q = q.moved(Tit); T0 = Tit @ T0
    print(" it%d wall r %.4f (D %.4f) rms %.4f tilt %.3f deg, n %d" % (it, cy["r"], 2 * cy["r"], cy["rms"], np.degrees(np.arccos(min(1, ax[2]))), cy["n_used"]))
if P["flip"]:
    F = np.diag([1.0, -1.0, -1.0, 1.0]); q = q.moved(F); T0 = F @ T0
fac, zw, rw = P["zero"]
L = rb.level(q, fac, zw, rw)
print(" zero level: z %.4f rms %.4f tilt %.3f area %.1f r %.2f..%.2f" % (L["z"], L["rms"], L["tilt_deg"], L["area"], L["r_min"], L["r_max"]))
Tz = np.eye(4); Tz[2, 3] = -L["z"]
q = q.moved(Tz); T = Tz @ T0
rb.write_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code, q.tri, b"ulka C %s aligned (part frame)" % code.encode())
rb.save_json(code, "align.json", {"T_raw_to_part": T, "zero_level": L, "axis_wall": {"r": cy["r"], "rms": cy["rms"]}})
print(" bbox", np.round(q.lo.min(0), 3), np.round(q.hi.max(0), 3))
