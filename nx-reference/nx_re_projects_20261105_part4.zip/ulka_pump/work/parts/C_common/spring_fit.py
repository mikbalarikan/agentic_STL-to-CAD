"""Fit a piecewise-pitch helix centre-line z(s) (s = turns from the wire start) to the wire-section centres.
pitch: pe on [0,a], ramp to p over b, p, ramp to pe over b, pe on the last a; total nt turns; start angle th0.
usage: spring_fit.py code d_wire"""
import sys, json, numpy as np
from scipy.optimize import least_squares
import rb
code = sys.argv[1]
R = np.load(rb.pdir(code, "qa") + "/wire_sections.npy")
R = R[(R[:, 3] > 0.3) & (R[:, 3] < 1.0) & (R[:, 4] < 0.06)]
th, zc = R[:, 0], R[:, 2]
m = rb.Mesh(rb.read_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code)); L0 = float(m.hi[:, 2].max())

def zmod(s, x):
    zc0, pe, a, b, p, nt = x
    s1, s2, s3, s4 = a, a + b, nt - a - b, nt - a
    zA = zc0 + pe * s1; zB = zA + (pe + p) / 2 * b; zC = zB + p * (s3 - s2); zD = zC + (p + pe) / 2 * b
    return np.select([s <= s1, s <= s2, s <= s3, s <= s4, True],
                     [zc0 + pe * s, zA + pe * (s - s1) + (p - pe) * (s - s1) ** 2 / (2 * b), zB + p * (s - s2),
                      zC + p * (s - s3) - (p - pe) * (s - s3) ** 2 / (2 * b), zD + pe * (s - s4)])

def resid(x, th0, hand=1):
    s0 = ((hand * th - th0) % 360) / 360.0
    best = np.full(len(th), 9.0)
    for k in range(-1, 12):
        s = s0 + k
        ok = (s >= 0) & (s <= x[5])
        r = np.where(ok, zc - zmod(np.clip(s, 0, x[5]), x), 9.0)
        best = np.where(np.abs(r) < np.abs(best), r, best)
    return np.clip(best, -1.5, 1.5)

out = []
d = float(sys.argv[2])
for th0 in np.arange(0, 360, 10):
    x0 = [d / 2, d, 0.6, 0.6, (L0 - 2 * d) / 5, 7.0]
    try:
        r = least_squares(lambda x: resid(x, th0), x0, bounds=([0.2, 0.3, 0.1, 0.1, 2, 3], [1.5, 2.5, 1.5, 1.5, 6, 10]), loss="soft_l1", f_scale=0.1)
        out.append((np.sqrt(np.mean(np.minimum(r.fun ** 2, 0.25))), th0, r.x))
    except Exception as e:
        pass
out.sort(key=lambda o: o[0])
rms, th0, x = out[0]
for o in out[:3]: print("rms %.3f th0 %d x %s" % (o[0], o[1], np.round(o[2], 3)))
zc0, pe, a, b, p, nt = x
end = zmod(np.array([nt]), x)[0]
print("%s: start angle %d deg, z_c(0) %.3f, end pitch %.3f, end flat turns %.2f, ramp %.2f, active pitch %.3f, total turns %.2f, z_c(end) %.3f (L0 %.3f -> top gap %.3f)" % (code, th0, zc0, pe, a, b, p, nt, end, L0, L0 - end))
na = nt - 2 * a - b  # active turns (classic: total minus ~1 per end incl. half ramps)
print("  active (p) turns incl. half ramps: %.2f ; inactive per end ~ %.2f" % (nt - 2 * a - b, a + b / 2))
res = resid(x, th0); good = np.abs(res) < 0.5
print("  residual rms on %d of %d sections: %.3f" % (good.sum(), len(res), np.sqrt(np.mean(res[good] ** 2))))
rb.save_json(code, "helix_fit.json", {"th0_deg": th0, "zc0": zc0, "pitch_end": pe, "end_flat_turns": a, "ramp_turns": b, "pitch": p, "total_turns": nt, "zc_end": end, "L0": L0, "rms": float(np.sqrt(np.mean(res[good] ** 2)))})
