"""Shared body of the DR02 / DR03 build journals (ULKA session C)."""
import os, traceback
import nxh
import rj, spring_nx


def run(OUT, NAME, PRE, LINKS, INTERNAL, checks):
    res = {"result": "FAIL"}
    try:
        c = rj.Ctx(OUT, NAME)
        p, M = c.part, c.M
        for n, (u, off) in LINKS.items():
            c.link(n, u, off)
        for n, (v, u, cm) in INTERNAL.items():
            c.e(n, v, cm, u)
        body, info = spring_nx.build(c, PRE)
        c.notes.update(info)
        c.notes["active_pitch"] = M[PRE + "p"]
        c.chk("active pitch ~ scan", M[PRE + "p"], checks["pitch"], 0.1)
        c.chk("one solid", len(nxh.solids(p)), 1, 0)
        # no coil overlap: rise over any one-turn window >= wire diameter (python twin of the z law)
        P = {k: M[PRE + k] for k in ("pe", "a1", "b1", "a2", "b2", "p", "nt", "z0")}
        def zc(s):
            s1, s2, s3, s4 = P["a1"], P["a1"] + P["b1"], P["nt"] - P["a2"] - P["b2"], P["nt"] - P["a2"]
            zA = P["z0"] + P["pe"] * s1; zB = zA + (P["pe"] + P["p"]) / 2 * P["b1"]
            zC = zB + P["p"] * (s3 - s2); zD = zC + (P["p"] + P["pe"]) / 2 * P["b2"]
            if s <= s1: return P["z0"] + P["pe"] * s
            if s <= s2: return zA + P["pe"] * (s - s1) + (P["p"] - P["pe"]) * (s - s1) ** 2 / (2 * P["b1"])
            if s <= s3: return zB + P["p"] * (s - s2)
            if s <= s4: return zC + P["p"] * (s - s3) - (P["p"] - P["pe"]) * (s - s3) ** 2 / (2 * P["b2"])
            return zD + P["pe"] * (s - s4)
        n = 400
        rise = min(zc(min(P["nt"], i * (P["nt"] - 1) / n + 1)) - zc(i * (P["nt"] - 1) / n) for i in range(n + 1))
        c.notes["min_rise_per_turn"] = rise
        c.chk.true("no coil overlap (min rise per turn >= d)", rise >= M[PRE + "d"] - 1e-6, "%.4f vs d %.3f" % (rise, M[PRE + "d"]))
        bb = nxh.bbox(body)
        c.chk("ground end z = 0 (bbox, B-surface padding)", bb[2], 0.0, 0.01)
        c.chk("ground end z = len (bbox)", bb[5], M[PRE + "len"], 0.01)
        ln = nxh.line(p, (0.0, 0.0, -2.0), (0.0, 0.0, M[PRE + "len"] + 2.0))
        c.chk("inner diameter = od - 2 d (min distance to the axis x 2)", 2 * nxh.min_dist(ln, body), M[PRE + "od"] - 2 * M[PRE + "d"], 0.01)   # law-curve spline + B-surface tube
        nxh.S.UpdateManager.AddToDeleteList(ln); nxh.update()
        c.notes["bbox_xy_padded"] = [bb[3] - bb[0], bb[4] - bb[1]]
        c.chk.true("ground ends removed a little", 0 < info["v_tube"] - info["v_trimmed"] < 0.06 * info["v_tube"], info)
        # regeneration: the installed-length copy A makes - len = 0.8 l0 -> back
        v_nom = c.vol(body)
        nxh.set_expr(p, PRE + "len", "%s*0.8" % (PRE + "l0")); nxh.update()
        bb2 = nxh.bbox(body)
        errs = [str(x) for x in nxh.feature_errors(p)]
        nxh.set_expr(p, PRE + "len", PRE + "l0"); nxh.update()
        c.chk.true("regeneration len = 0.8 l0: ends follow, no errors", abs(bb2[5] - 0.8 * M[PRE + "l0"]) < 0.01 and not errs, "%s %s" % (bb2[5], errs))
        c.chk("regeneration back to nominal", c.vol(body), v_nom, 1e-5 * v_nom)
        c.finish({"body": body}, res)
    except Exception:
        res["error"] = traceback.format_exc()
    nxh.write_json(os.path.join(OUT, "build.json"), res)
