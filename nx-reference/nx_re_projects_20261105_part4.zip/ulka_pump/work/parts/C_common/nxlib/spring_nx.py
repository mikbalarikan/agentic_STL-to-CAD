"""Compression spring, closed and ground ends, free length (NX 2206 journal helper, ULKA session C).

Centre line = Law Curve by equation over the parameter t (0..1): s = n_t*t turns, angle 360*s deg (right hand),
z(s) piecewise: end pitch pe for a_end turns, linear pitch ramp over b_ramp turns, active pitch p, ramp back,
pe for the last a_end turns (C1, the pitch is continuous). Centre starts at z = d/2 - g (g = grind depth) and the
active pitch p is DERIVED from the free length L0, so L0 / n_t / d / D are the masters. Tube of the wire diameter
along it, then two Trim Bodies at z = 0 and z = L0 give the ground ends.
"""
import math

import NXOpen
import NXOpen.Features
import NXOpen.GeometricUtilities as GU
import nxh
import nxf


def law_curve(part, fx, fy, fz, name, tol=0.001):
    """Law Curve by equation (copied from nx-curves-and-sketches law_curve_gear.py, verified there)."""
    b = part.Features.CreateLawCurveBuilder(NXOpen.Features.LawCurve.Null)
    try:
        for law, fn in ((b.XLaw, fx), (b.YLaw, fy), (b.ZLaw, fz)):
            law.LawType = GU.LawBuilder.Type.ByEquation
            law.Parameter = "t"
            law.Function = fn
        b.DistanceTolerance = tol
        f = b.CommitFeature()
    finally:
        b.Destroy()
    f.SetName(name)
    return f, [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)][0]




def build(c, pre):
    """c = rj.Ctx holding <pre>d, <pre>od, <pre>l0, <pre>nt (control part) and the internal masters <pre>pe_gap,
    <pre>a1, <pre>b1, <pre>a2, <pre>b2 (closed / ramp turns at the z = 0 end and at the far end), <pre>grind.
    Creates <pre>len (= <pre>l0, the length A changes for the installed copy); the active pitch follows it.
    Returns (body, info)."""
    p, M = c.part, c.M
    q = lambda n: pre + n
    c.d(q("pe"), "%s+%s" % (q("d"), q("pe_gap")), "pitch of the closed end turns = wire + gap (coils touch)")
    c.d(q("len"), q("l0"), "spring length: free length by default; A sets the installed length on a copy")
    c.d(q("coil_d"), "%s-%s" % (q("od"), q("d")), "mean coil diameter")
    c.d(q("z0"), "%s/2-%s" % (q("d"), q("grind")), "wire centre height at the start (ground end)")
    c.d(q("n_act"), "%s-%s-%s-%s-%s" % (q("nt"), q("a1"), q("a2"), q("b1"), q("b2")), "turns at the active pitch", None)
    c.d(q("p"), "(%s-2*%s-%s*(%s+%s)-%s*(%s+%s)/2)/((%s+%s)/2+%s)" % (q("len"), q("z0"), q("pe"), q("a1"), q("a2"), q("pe"), q("b1"), q("b2"),
                                                                q("b1"), q("b2"), q("n_act")), "active pitch, DERIVED from the length")
    nxh.expr(p, "t", "1", None, "law curve parameter (NX runs it 0..1)")
    s = "(%s*t)" % q("nt")
    s1, s2 = q("a1"), "(%s+%s)" % (q("a1"), q("b1"))
    s3, s4 = "(%s-%s-%s)" % (q("nt"), q("a2"), q("b2")), "(%s-%s)" % (q("nt"), q("a2"))
    pe, pp, b1, b2 = q("pe"), q("p"), q("b1"), q("b2")
    c.d(q("zA"), "%s+%s*%s" % (q("z0"), pe, s1), "")
    c.d(q("zB"), "%s+(%s+%s)/2*%s" % (q("zA"), pe, pp, b1), "")
    c.d(q("zC"), "%s+%s*(%s-%s)" % (q("zB"), pp, s3, s2), "")
    c.d(q("zD"), "%s+(%s+%s)/2*%s" % (q("zC"), pp, pe, b2), "")
    z_ex = ("if (%(s)s<=%(s1)s) (%(z0)s+%(pe)s*%(s)s) else (if (%(s)s<=%(s2)s) (%(zA)s+%(pe)s*(%(s)s-%(s1)s)+(%(pp)s-%(pe)s)*(%(s)s-%(s1)s)^2/(2*%(b1)s)) "
            "else (if (%(s)s<=%(s3)s) (%(zB)s+%(pp)s*(%(s)s-%(s2)s)) else (if (%(s)s<=%(s4)s) (%(zC)s+%(pp)s*(%(s)s-%(s3)s)-(%(pp)s-%(pe)s)*(%(s)s-%(s3)s)^2/(2*%(b2)s)) "
            "else (%(zD)s+%(pe)s*(%(s)s-%(s4)s)))))") % dict(s=s, s1=s1, s2=s2, s3=s3, s4=s4, z0=q("z0"), pe=pe, pp=pp, b1=b1, b2=b2,
                                                         zA=q("zA"), zB=q("zB"), zC=q("zC"), zD=q("zD"))
    nxh.expr(p, q("cx"), "%s/2*cos(360*%s)" % (q("coil_d"), s), "mm", "centre line x(t)")
    nxh.expr(p, q("cy"), "%s/2*sin(360*%s)" % (q("coil_d"), s), "mm", "centre line y(t) (right hand)")
    nxh.expr(p, q("cz"), z_ex, "mm", "centre line z(t), piecewise pitch")
    fl, crv = law_curve(p, q("cx"), q("cy"), q("cz"), "CENTRE_LINE")
    ft, body = nxf.tube(p, q("d"), curves=[crv])
    ft.SetName("WIRE_TUBE")
    v_tube = nxh.volume(p, body)
    _, pl0 = nxf.datum_plane(p, "offset", [c.dat.xy], "0", "PL_END_0")
    _, pl1 = nxf.datum_plane(p, "offset", [c.dat.xy], q("len"), "PL_END_LEN")
    L = M[q("len")]
    nxf.trim_body(p, body, keep_point=(0.0, 0.0, L * 0.5), datum_plane=pl0)
    nxf.trim_body(p, body, keep_point=(0.0, 0.0, L * 0.5), datum_plane=pl1)
    info = {"v_tube": v_tube, "v_trimmed": nxh.volume(p, body)}
    return body, info
