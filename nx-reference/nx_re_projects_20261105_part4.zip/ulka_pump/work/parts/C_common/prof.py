"""r-z profile of an aligned axisymmetric scan: facet centres (r,z) coloured by facing, + 4 half-plane sections.
usage: prof.py code [zlo zhi]"""
import sys, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import rb
code = sys.argv[1]
q = rb.Mesh(rb.read_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code))
zl = (float(sys.argv[2]), float(sys.argv[3])) if len(sys.argv) > 3 else (q.lo[:, 2].min(), q.hi[:, 2].max())
r, th, rad = rb.polar(q)
s = (q.c[:, 2] > zl[0]) & (q.c[:, 2] < zl[1])
fig, ax = plt.subplots(1, 2, figsize=(20, 14), gridspec_kw=dict(width_ratios=[1, 1]))
col = np.where(np.abs(q.n[:, 2]) > 0.8, 2, np.where(rad > 0, 0, 1))
for k, (c, lbl) in enumerate((("r", "outward"), ("b", "inward"), ("g", "axial"))):
    ss = s & (col == k)
    idx = np.where(ss)[0]
    if len(idx) > 80000: idx = np.random.default_rng(0).choice(idx, 80000, replace=False)
    ax[0].scatter(r[idx], q.c[idx, 2], s=0.2, c=c, label=lbl)
ax[0].legend(); ax[0].set_aspect("equal"); ax[0].grid(True, lw=0.3); ax[0].set_title(code + " facet centres (r,z)")
ax[0].set_ylim(*zl)
from matplotlib.ticker import MultipleLocator
ax[0].xaxis.set_minor_locator(MultipleLocator(0.5)); ax[0].yaxis.set_minor_locator(MultipleLocator(1)); ax[0].grid(True, which="minor", lw=0.15)
for th0, c in ((0, "k"), (90, "m"), (180, "c"), (270, "y")):
    sg = q.rz(th0)
    rb.plot_segs(ax[1], sg, color=c, lw=0.6)
ax[1].set_aspect("equal"); ax[1].grid(True, lw=0.3); ax[1].set_ylim(*zl); ax[1].set_title("sections 0/90/180/270 (k/m/c/y)")
ax[1].xaxis.set_minor_locator(MultipleLocator(0.5)); ax[1].grid(True, which="minor", lw=0.15)
plt.tight_layout(); out = rb.pdir(code, "fig") + "/prof_%g_%g.png" % zl; plt.savefig(out, dpi=60); print(out)
