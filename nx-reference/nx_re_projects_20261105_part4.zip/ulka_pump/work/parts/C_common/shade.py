"""Hill-shaded height maps of a region of an aligned scan, seen from +Z and from -Z.
usage: shade.py <aligned.stl> <out.png> x0 x1 y0 y1 [res] [zlo zhi]"""
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LightSource
import rb

src, out = sys.argv[1:3]
x0, x1, y0, y1 = [float(v) for v in sys.argv[3:7]]
res = float(sys.argv[7]) if len(sys.argv) > 7 else 0.05
zwin = [float(v) for v in sys.argv[8:10]] if len(sys.argv) > 9 else None
m = rb.Mesh(rb.read_stl(src))
mask = (m.hi[:, 0] > x0) & (m.lo[:, 0] < x1) & (m.hi[:, 1] > y0) & (m.lo[:, 1] < y1)
if zwin:
    mask &= (m.hi[:, 2] > zwin[0]) & (m.lo[:, 2] < zwin[1])
area = (x1 - x0) * (y1 - y0)
P, idx = m.sample(int(min(8e6, max(1.5e6, area / res ** 2 * 40))), seed=2, mask=mask)
s = (P[:, 0] > x0) & (P[:, 0] < x1) & (P[:, 1] > y0) & (P[:, 1] < y1)
if zwin:
    s &= (P[:, 2] > zwin[0]) & (P[:, 2] < zwin[1])
P = P[s]
nx, ny = int(round((x1 - x0) / res)), int(round((y1 - y0) / res))
ix = np.clip(((P[:, 0] - x0) / res).astype(int), 0, nx - 1)
iy = np.clip(((P[:, 1] - y0) / res).astype(int), 0, ny - 1)
flat = iy * nx + ix
o = np.argsort(P[:, 2])
top = np.full(ny * nx, np.nan); top[flat[o]] = P[o, 2]
bot = np.full(ny * nx, np.nan); bot[flat[o[::-1]]] = P[o[::-1], 2]
ls = LightSource(azdeg=315, altdeg=45)
w, h = x1 - x0, y1 - y0
sc = min(11.0 / w, 10.0 / h)
fig, axs = plt.subplots(1, 2, figsize=(2 * w * sc + 3, h * sc + 1.2))
for ax, (ttl, hm, sgn) in zip(axs, (("seen from +Z (highest surface)", top, 1), ("seen from -Z (lowest surface), same x-y axes", bot, -1))):
    g = hm.reshape(ny, nx)
    f = np.where(np.isnan(g), np.nanmin(g) - 1, g)
    rgb = ls.shade(sgn * f, cmap=plt.cm.turbo, vert_exag=2.0, dx=res, dy=res, blend_mode="soft", vmin=np.nanmin(sgn * g), vmax=np.nanmax(sgn * g))
    rgb[np.isnan(g)] = (1, 1, 1, 1)
    ax.imshow(rgb, origin="lower", extent=[x0, x1, y0, y1], interpolation="nearest")
    span = max(w, h)
    step = 0.5 if span <= 8 else 1 if span <= 20 else 2 if span <= 50 else 5
    ax.set_xticks(np.arange(np.ceil(x0 / step) * step, x1 + 1e-6, step)); ax.set_yticks(np.arange(np.ceil(y0 / step) * step, y1 + 1e-6, step))
    ax.tick_params(labelsize=6); ax.grid(True, lw=0.2, color="k", alpha=0.35)
    ax.set_title("%s   z %.2f .. %.2f" % (ttl, np.nanmin(g), np.nanmax(g)), fontsize=9)
fig.tight_layout(); fig.savefig(out, dpi=100)
print("saved", out)
