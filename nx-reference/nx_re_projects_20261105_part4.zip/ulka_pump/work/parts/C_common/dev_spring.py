"""Spring CAD vs scan: best phase about Z (and end flip), then the zone report. usage: dev_spring.py code cad.stl [tag]"""
import sys, numpy as np
import rb, dev
code, cad = sys.argv[1], sys.argv[2]; tag = sys.argv[3] if len(sys.argv) > 3 else "dev"
C = rb.Mesh(rb.read_stl(cad)); S = rb.Mesh(rb.read_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code))
sc = dev.scene_of(C.tri)
L0 = C.hi[:, 2].max()
idx = np.random.default_rng(1).choice(len(S.c), 20000, replace=False); P0 = S.c[idx]
best = None
for flip in (False, True):
    P1 = P0.copy()
    if flip: P1 = np.c_[P1[:, 0], -P1[:, 1], L0 - P1[:, 2]]
    for ph in np.arange(0, 360, 2.0):
        R = rb.rotz(ph)[:3, :3]; P = P1 @ R.T
        d, _ = dev.closest(sc, C, P)
        m = np.sqrt(np.mean(np.minimum(d ** 2, 0.25)))
        if best is None or m < best[0]: best = (m, flip, ph)
m, flip, ph = best
for dph in np.arange(-2, 2.01, 0.25):
    P1 = P0.copy()
    if flip: P1 = np.c_[P1[:, 0], -P1[:, 1], L0 - P1[:, 2]]
    R = rb.rotz(ph + dph)[:3, :3]; d, _ = dev.closest(sc, C, P1 @ R.T)
    mm = np.sqrt(np.mean(np.minimum(d ** 2, 0.25)))
    if mm < m: m, best = mm, (mm, flip, ph + dph)
m, flip, ph = best
print("best: flip %s phase %.2f deg, clipped rms %.4f" % (flip, ph, m))
T = rb.rotz(ph)
if flip: T = T @ np.array([[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, L0], [0, 0, 0, 1.0]])
def rr(P): return np.hypot(P[:, 0], P[:, 1])
zones = {"outer (r > R)": lambda P, N: rr(P) > 0.5 * (C.hi[:, 0].max()) - 0.6 + 0.0 if False else rr(P) > 5.7,
         "inner (r < R)": lambda P, N: rr(P) <= 5.7,
         "end coils (z<2.5 or z>L0-2.5)": lambda P, N: (P[:, 2] < 2.5) | (P[:, 2] > L0 - 2.5),
         "active coils": lambda P, N: (P[:, 2] >= 2.5) & (P[:, 2] <= L0 - 2.5),
         "all": lambda P, N: np.ones(len(P), bool)}
dev.run(code, [cad], rb.SCAN + "/EP5-%s_aligned.stl" % code, zones=zones, T=T, tag=tag)
rb.save_json(code, "dev_pose_%s.json" % tag, {"flip": flip, "phase_deg": ph, "T_scan_to_cad": T})
