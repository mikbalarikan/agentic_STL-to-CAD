"""Wire cross-sections of an aligned spring: half-plane sections every 15 deg, circle fit per wire.
usage: spring2.py code"""
import sys, numpy as np, matplotlib, json
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rb
code = sys.argv[1]
m = rb.Mesh(rb.read_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code))
rows = []
fig, axs = plt.subplots(1, 4, figsize=(16, 10))
for k, th in enumerate(np.arange(-180, 180, 15)):
    s = m.rz(th)
    if not len(s):
        continue
    pts = rb.seg_points(s, 0.02)
    # cluster by z gaps
    o = np.argsort(pts[:, 1]); pz = pts[o]
    cut = np.where(np.diff(pz[:, 1]) > 0.35)[0] + 1
    for g in np.split(pz, cut):
        if len(g) < 30:
            continue
        span = np.ptp(g, axis=0)
        if span.max() < 0.4:
            continue
        fc = rb.fit_circle(g, clip=2.5)
        # angular coverage of the arc about its centre
        a = np.degrees(np.arctan2(g[:, 1] - fc["c"][1], g[:, 0] - fc["c"][0]))
        cov = len(np.unique(np.round(a / 10))) * 10
        rows.append([th, fc["c"][0], fc["c"][1], fc["r"], fc["rms"], cov, len(g)])
    if k % 6 == 0:
        ax = axs[k // 6]
        rb.plot_segs(ax, s); ax.set_title("theta %d" % th); ax.grid(True, lw=.3)
plt.tight_layout(); plt.savefig(rb.pdir(code, "fig") + "/wire_sections.png", dpi=70)
R = np.array(rows)
good = (R[:, 5] >= 180) & (R[:, 4] < 0.03) & (R[:, 3] > 0.2) & (R[:, 3] < 1.2)
print("%s: %d wire sections, %d good (cover>=180 deg, rms<0.03)" % (code, len(R), good.sum()))
G = R[good]
print("wire d: median %.3f  mean %.3f  sd %.3f   | coil mean R (centre r): median %.3f sd %.3f" % (2*np.median(G[:, 3]), 2*G[:, 3].mean(), 2*G[:, 3].std(), np.median(G[:, 1]), G[:, 1].std()))
print("-> OD = 2R+d = %.3f  ID = 2R-d = %.3f" % (2*np.median(G[:, 1]) + 2*np.median(G[:, 3]), 2*np.median(G[:, 1]) - 2*np.median(G[:, 3])))
np.save(rb.pdir(code, "qa") + "/wire_sections.npy", R)
# helix centre-line: z of wire centre vs unwrapped angle
for th in (-180, -90, 0, 90):
    z = np.sort(R[(R[:, 0] == th)][:, 2])
    print("theta %4d wire centre z: %s" % (th, np.round(z, 2)))
zmax = m.hi[:, 2].max(); print("free length (z range) %.3f" % zmax)
