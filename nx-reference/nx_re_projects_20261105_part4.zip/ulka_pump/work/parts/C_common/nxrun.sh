#!/bin/bash
# usage: nxrun.sh <script.py> <outdir> [timeout]  -- takes the shared NX lock, checks free RAM, runs headless, releases
S="$1"; O="$2"; T="${3:-900}"; L=/c/NX_MCP_WORKSPACE/ulka/nx.lock
mkdir -p "$O"
while true; do
  free=$(powershell -NoProfile -c "[int]((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1024)")
  if [ "$free" -ge 2500 ] && mkdir "$L" 2>/dev/null; then break; fi
  echo "waiting (free ${free} MB, lock: $(cat $L/owner.txt 2>/dev/null))"; sleep 30
done
echo "ULKA-C $(date '+%Y-%m-%d %H:%M:%S') $S" > "$L/owner.txt"
trap 'rm -rf "$L"' EXIT
powershell -NoProfile -File "C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1" -Script "$(cygpath -w "$S")" -WorkDir "$(cygpath -w "$(dirname "$S")")" -JArgs "$(cygpath -w "$O")" -TimeoutSec "$T" 2>&1 | tail -5
