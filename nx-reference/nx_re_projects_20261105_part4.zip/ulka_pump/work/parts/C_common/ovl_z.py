"""Overlay z-sections of scan (black) and CAD (red). usage: ovl_z.py code cad.stl z1,z2,... [lim] [tag]"""
import sys, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import rb
code, cad, zs = sys.argv[1], sys.argv[2], [float(t) for t in sys.argv[3].split(",")]
lim = float(sys.argv[4]) if len(sys.argv) > 4 else 8; tag = sys.argv[5] if len(sys.argv) > 5 else "ovl"
S = rb.Mesh(rb.read_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code)); C = rb.Mesh(rb.read_stl(cad))
fig, ax = plt.subplots(1, len(zs), figsize=(5 * len(zs), 5.5))
for a, z in zip(np.atleast_1d(ax), zs):
    for m, col in ((S, "k"), (C, "r")):
        for seg in m.section(2, z): a.plot(seg[:, 0], seg[:, 1], col + "-", lw=0.7)
    a.set_aspect("equal"); a.set_xlim(-lim, lim); a.set_ylim(-lim, lim); a.grid(True, lw=.3); a.set_title("%s z=%.2f" % (code, z))
plt.tight_layout(); out = rb.pdir(code, "fig") + "/%s.png" % tag; plt.savefig(out, dpi=60); print(out)
