"""Overlay r-z of scan facet centres (black dots) and CAD facet centres (red) in a z window.
usage: ovl_rz.py code cad.stl zlo zhi [zshift] [tag]"""
import sys, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import rb
code, cad, zl, zh = sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4])
zs = float(sys.argv[5]) if len(sys.argv) > 5 else 0.0; tag = sys.argv[6] if len(sys.argv) > 6 else "ovl_rz"
S = rb.Mesh(rb.read_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code)); C = rb.Mesh(rb.read_stl(cad))
fig, ax = plt.subplots(figsize=(10, 12))
for m, col, dz, s in ((S, "k", 0.0, 0.3), (C, "r", -zs, 0.6)):
    z = m.c[:, 2] + dz; r = np.hypot(m.c[:, 0], m.c[:, 1]); k = (z > zl) & (z < zh)
    ax.scatter(r[k], z[k], s=s, c=col)
ax.set_aspect("equal"); ax.grid(True, lw=.3); ax.set_title("%s r-z: scan black, CAD red" % code)
out = rb.pdir(code, "fig") + "/%s.png" % tag; plt.savefig(out, dpi=70); print(out)
