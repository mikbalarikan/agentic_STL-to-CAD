"""Stage 1 - find the part axis from the facet normals and list what is on it.
usage: s1_census.py <code> [stl path]   (default: raw scan, small shells dropped)

1. dominant plane-normal direction d (mode of the area-weighted normals, antipodes folded, refined)
2. axis position: least-squares meeting point of the normal lines of the wall facets (normal square to d)
3. census in the provisional frame (z = d, origin on the axis at the area centroid height):
   - levels: z of facets facing along +-z, as area peaks
   - walls: radius of facets facing radially (outward = boss, inward = bore), as area peaks
"""
import sys
import numpy as np
from scipy.spatial import cKDTree
import rb

sys.stdout.reconfigure(encoding="utf-8")
code = sys.argv[1]
path = sys.argv[2] if len(sys.argv) > 2 else rb.raw_path(code)
tri = rb.read_stl(path)
v, f = rb.weld(tri)
lab = rb.components(f, len(v))
cnt = np.bincount(lab)
keep = cnt[lab] >= 0.02 * len(tri)
rb.out("%s: %d facets, %d kept after dropping %d small shells (%d facets)" % (code, len(tri), keep.sum(), (cnt < 0.02 * len(tri)).sum() - (cnt == 0).sum(), (~keep).sum()))
m = rb.Mesh(tri[keep])

# 1. mode of the normals on a Fibonacci half sphere
N = 20000
i = np.arange(N) + 0.5
phi = np.arccos(1 - 2 * i / N)
th = np.pi * (1 + 5 ** 0.5) * i
dirs = np.c_[np.cos(th) * np.sin(phi), np.sin(th) * np.sin(phi), np.cos(phi)]
tree = cKDTree(dirs)
_, j = tree.query(m.n)
h = np.bincount(j, weights=m.a, minlength=N)
# fold antipodes: add the weight of the opposite bin
_, jo = tree.query(-dirs)
hf = h + h[jo]
d = dirs[int(np.argmax(hf))]
for _ in range(5):
    c = m.n @ d
    s = np.abs(c) > np.cos(np.radians(6))
    d = (m.n[s] * (np.sign(c[s]) * m.a[s])[:, None]).sum(axis=0)
    d /= np.linalg.norm(d)
share = m.a[np.abs(m.n @ d) > np.cos(np.radians(6))].sum() / m.a.sum()
rb.out("axis direction d = %s   (%.1f %% of the area faces within 6 deg of +-d)" % (np.round(d, 5), 100 * share))

# 2. axis position from wall normals
T0 = rb.frame(d, np.average(m.c, axis=0, weights=m.a))
q = m.moved(T0)
wall = np.abs(q.n[:, 2]) < 0.12
p2, n2 = q.c[wall, :2], q.n[wall, :2]
n2 = n2 / np.linalg.norm(n2, axis=1)[:, None]
w = q.a[wall]
cen = np.zeros(2)
for it in range(8):
    # distance of the centre from each normal line: cross(p - c, n)
    t2 = np.c_[-n2[:, 1], n2[:, 0]]
    b = (p2 * t2).sum(axis=1)
    ww = w.copy()
    if it:
        res = t2 @ cen - b
        s = 1.4826 * np.median(np.abs(res))
        ww = w * (np.abs(res) < 2.0 * max(s, 0.02))
    A = t2 * np.sqrt(ww)[:, None]
    cen = np.linalg.lstsq(A, b * np.sqrt(ww), rcond=None)[0]
res = t2 @ cen - b
rb.out("axis centre in provisional frame = %s   wall facets used %.0f %% (line-distance MAD %.3f)" % (np.round(cen, 3), 100 * (ww > 0).sum() / len(ww), 1.4826 * np.median(np.abs(res))))
T1 = np.eye(4)
T1[:2, 3] = -cen
T = T1 @ T0
q = m.moved(T)

# 3. census
lev = np.abs(q.n[:, 2]) > 0.97
rb.out("levels (z, share of area, facing):")
levels = []
for sgn, name in ((1, "+z"), (-1, "-z")):
    s = lev & (np.sign(q.n[:, 2]) == sgn)
    if s.sum() < 50:
        continue
    for z, sh in rb.hist_peaks(q.c[s, 2], q.a[s], bin=0.02, min_frac=0.02, sep=0.25):
        ss = s & (np.abs(q.c[:, 2] - z) < 0.25)
        r = np.hypot(q.c[ss, 0], q.c[ss, 1])
        levels.append({"z": z, "facing": name, "area": float(q.a[ss].sum()), "r_min": float(np.percentile(r, 1)), "r_max": float(np.percentile(r, 99))})
levels.sort(key=lambda L: L["z"])
for L in levels:
    rb.out("   z %8.3f  %s  area %7.1f mm2   r %.2f .. %.2f" % (L["z"], L["facing"], L["area"], L["r_min"], L["r_max"]))
r, thq, z = rb.cyl(q.c)
rad = (q.c[:, 0] * q.n[:, 0] + q.c[:, 1] * q.n[:, 1]) / np.maximum(r, 1e-9)
walls = []
rb.out("coaxial walls (r, share, type, z range):")
for sgn, name in ((1, "boss"), (-1, "bore")):
    s = (np.abs(q.n[:, 2]) < 0.12) & (sgn * rad > 0.97)
    if s.sum() < 50:
        continue
    for rr, sh in rb.hist_peaks(r[s], q.a[s], bin=0.02, min_frac=0.02, sep=0.25):
        ss = s & (np.abs(r - rr) < 0.25)
        walls.append({"r": rr, "type": name, "area": float(q.a[ss].sum()), "z_min": float(np.percentile(z[ss], 1)), "z_max": float(np.percentile(z[ss], 99)),
                      "cover_deg": float(len(np.unique(np.round(thq[ss] / 5))) * 5)})
walls.sort(key=lambda L: L["r"])
for L in walls:
    rb.out("   r %7.3f (D %7.3f)  %s  area %7.1f   z %.2f .. %.2f   covers %3.0f deg" % (L["r"], 2 * L["r"], L["type"], L["area"], L["z_min"], L["z_max"], L["cover_deg"]))
rb.save_json(code, "s1_census.json", {"source": path, "d": d, "T_provisional": T, "levels": levels, "walls": walls,
                                      "bbox_lo": q.lo.min(axis=0), "bbox_hi": q.hi.max(axis=0)})
rb.out("bbox in provisional frame: lo %s hi %s" % (np.round(q.lo.min(axis=0), 2), np.round(q.hi.max(axis=0), 2)))
