"""Trace helix centre-line from wire sections (spring2 output): unwrapped angle vs z, ends, total turns."""
import sys, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import rb
code = sys.argv[1]; p = float(sys.argv[2]); hand = float(sys.argv[3]) if len(sys.argv) > 3 else 1
R = np.load(rb.pdir(code, "qa") + "/wire_sections.npy")
R = R[(R[:, 3] > 0.3) & (R[:, 3] < 1.0) & (R[:, 4] < 0.06)]
th, z = R[:, 0], R[:, 2]
# rough unwrapping with mid pitch
zmid = np.median(z)
k = np.round((z - zmid - hand * p * th / 360) / p)
u = hand * th + 360 * k * hand
o = np.argsort(u); u, z, Rr = u[o], z[o], R[o]
for a, b, rr in zip(u, z, Rr):
    pass
fig, ax = plt.subplots(figsize=(14, 7)); ax.plot(u / 360, z, '.'); ax.grid(True); ax.set_xlabel("turns"); ax.set_ylabel("z centre")
plt.savefig(rb.pdir(code, "fig") + "/helix_u_z.png", dpi=70)
print("u range turns %.2f .. %.2f  -> %.2f turns of centre-line (sections)" % (u.min()/360, u.max()/360, np.ptp(u)/360))
np.savetxt(rb.pdir(code, "qa") + "/helix_u_z.txt", np.c_[u, z, Rr[:, 3]*2, Rr[:, 1]], fmt="%.3f")
