"""Fit spring_nx centre-line parameters to the aligned scan: scan points -> distance to the centre line - d/2.
Free: n_t, pe, a_end, b_ramp, grind, phase, coil_d, d (L0 from the scan). Both ends share a_end/b_ramp (symmetric
model) but a separate fit with end-specific values is reported too. usage: spring_fit2.py code d0 D0 nt0"""
import sys, numpy as np
from scipy.optimize import least_squares
from scipy.spatial import cKDTree
import rb
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\C_common\nxlib")
code, d0, D0, nt0 = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4])
FLIPS = (sys.argv[6] == "1",) if len(sys.argv) > 6 else (False, True)
DTRUE = float(sys.argv[5]) if len(sys.argv) > 5 else None   # true wire (Usta): closed-end pitch = DTRUE + 0.02, centre z0 = DTRUE/2 - grind
S = rb.Mesh(rb.read_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code))
L0 = float(S.hi[:, 2].max())
P = S.c[np.random.default_rng(0).choice(len(S.c), 8000, replace=False)]

def zc(s, pe, a1, b1, a2, b2, p, nt, z0):
    s1, s2, s3, s4 = a1, a1 + b1, nt - a2 - b2, nt - a2
    zA = z0 + pe * s1; zB = zA + (pe + p) / 2 * b1; zC = zB + p * (s3 - s2); zD = zC + (p + pe) / 2 * b2
    return np.select([s <= s1, s <= s2, s <= s3, s <= s4, True],
                     [z0 + pe * s, zA + pe * (s - s1) + (p - pe) * (s - s1) ** 2 / (2 * b1), zB + p * (s - s2),
                      zC + p * (s - s3) - (p - pe) * (s - s3) ** 2 / (2 * b2), zD + pe * (s - s4)])

def centre(x, flip):
    nt, pe, a1, b1, a2, b2, g, ph, D, d = x
    if DTRUE is not None:
        pe = DTRUE + 0.02
        z0 = DTRUE / 2 - g
    else:
        z0 = d / 2 - g
    p = (L0 - 2 * z0 - pe * (a1 + a2) - pe * (b1 + b2) / 2) / ((b1 + b2) / 2 + (nt - a1 - a2 - b1 - b2))
    s = np.linspace(0, nt, int(nt * 720))
    th = np.radians(360 * s + ph)
    C = np.c_[D / 2 * np.cos(th), D / 2 * np.sin(th), zc(s, pe, a1, b1, a2, b2, p, nt, z0)]
    if flip: C = np.c_[C[:, 0], -C[:, 1], L0 - C[:, 2]]
    return C, p

def resid(x, flip):
    C, p = centre(x, flip)
    t = cKDTree(C)
    dist, i = t.query(P)
    r = dist - x[9] / 2
    # points whose nearest centre point is an END of the wire: penalise only if beyond the cap (outside)
    return np.clip(r, -0.6, 0.6)

best = None
for flip in FLIPS:
    for ph in range(0, 360, 30):
        x0 = [nt0, 0.3, 0.5, 0.3, 0.5, 0.3, 0.1, ph, D0, d0]
        lo = [nt0 - 0.8, 0.05, 0.1, 0.1, 0.1, 0.1, 0.0, ph - 40, D0 - 0.4, d0 - 0.15]
        hi = [nt0 + 0.8, 1.5, 1.2, 1.0, 1.2, 1.0, 0.4, ph + 40, D0 + 0.4, d0 + 0.15]
        r = least_squares(resid, x0, args=(flip,), bounds=(lo, hi), loss="soft_l1", f_scale=0.05, diff_step=1e-3)
        m = np.sqrt(np.mean(r.fun ** 2))
        if best is None or m < best[0]:
            best = (m, flip, r.x)
m, flip, x = best
C, p = centre(x, flip)
names = ["n_t", "pe", "a1", "b1", "a2", "b2", "grind", "phase", "coil_d", "d_wire"]
print("%s L0 %.3f  best flip %s  rms %.4f  active pitch %.3f" % (code, L0, flip, m, p))
print("  " + "  ".join("%s %.3f" % (n, v) for n, v in zip(names, x)))
rr = resid(x, flip); print("  |r| p50 %.3f p95 %.3f within 0.15: %.1f %%" % (np.median(np.abs(rr)), np.percentile(np.abs(rr), 95), 100 * np.mean(np.abs(rr) < 0.15)))
rb.save_json(code, "spring_fit3%s.json" % ("_dtrue" if DTRUE else ""), {"L0": L0, "flip": flip, "rms": m, "pitch": p, **{n: float(v) for n, v in zip(names, x)}})
