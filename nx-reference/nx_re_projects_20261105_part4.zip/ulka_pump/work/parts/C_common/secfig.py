"""Section figure of an aligned scan: r-z half sections at given angles + z sections.
usage: secfig.py <aligned.stl> <out.png> --rz a1,a2,... --z z1,z2,... [--grid g]"""
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import rb

src, out = sys.argv[1:3]
args = sys.argv[3:]


def opt(name, default=""):
    for i, a in enumerate(args):
        if a == name:
            return args[i + 1]
        if a.startswith(name + "="):
            return a[len(name) + 1:]
    return default


rz = [float(v) for v in opt("--rz").split(",") if v]
zs = [float(v) for v in opt("--z").split(",") if v]
grid = float(opt("--grid", "1"))
m = rb.Mesh(rb.read_stl(src))
n = len(rz) + len(zs)
cols = min(n, 3)
rows = int(np.ceil(n / cols))
fig, axs = plt.subplots(rows, cols, figsize=(8.5 * cols, 7.5 * rows), squeeze=False)
axs = axs.ravel()
k = 0
for a in rz:
    ax = axs[k]; k += 1
    s = m.rz(a, both=True)
    rb.plot_segs(ax, s)
    ax.set_title("section through Z axis at %.1f deg (r < 0 = opposite side)" % a, fontsize=10)
    ax.set_xlabel("r"); ax.set_ylabel("z")
for z in zs:
    ax = axs[k]; k += 1
    s = m.section(2, z)
    rb.plot_segs(ax, s[:, :, :2])
    ax.set_title("section z = %.2f" % z, fontsize=10)
    ax.set_xlabel("x"); ax.set_ylabel("y")
box = [float(v) for v in opt("--box").split(",") if v]
for ax in axs[:k]:
    if box:
        ax.set_xlim(box[0], box[1]); ax.set_ylim(box[2], box[3])
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
    ax.set_xticks(np.arange(np.floor(x0 / grid) * grid, x1 + grid, grid), minor=True)
    ax.set_yticks(np.arange(np.floor(y0 / grid) * grid, y1 + grid, grid), minor=True)
    ax.grid(True, which="both", lw=0.2, color="b", alpha=0.35)
    ax.axhline(0, color="r", lw=0.4); ax.axvline(0, color="r", lw=0.4)
    ax.tick_params(labelsize=7)
for ax in axs[k:]:
    ax.axis("off")
fig.tight_layout()
fig.savefig(out, dpi=100)
print("saved", out)
