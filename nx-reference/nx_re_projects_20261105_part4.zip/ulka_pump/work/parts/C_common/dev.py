"""Scan-to-CAD deviation (cadgenbench venv: open3d).

    from dev import run
    run("DR01", [cad stl, ...], scan_aligned.stl, zones={name: lambda P, N: mask}, T=None)

Signed distance of scan surface points to the CAD mesh: + = the scan lies outside the CAD material (CAD too small),
- = inside (CAD too big). T = 4x4 that moves the scan into the CAD frame (None = same frame).
Zones are predicates on the scan points P (n, 3) and their facet normals N (n, 3), both in the CAD frame.
Also the other direction: CAD surface points with no scan within `far` mm (unscanned or extra CAD)."""
import json
import os
import sys

import numpy as np
import open3d as o3d
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import rb


def scene_of(tri):
    v = tri.reshape(-1, 3).astype(np.float32)
    f = np.arange(len(v), dtype=np.uint32).reshape(-1, 3)
    s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(v), o3d.core.Tensor(f))
    return s


def closest(scene, mesh, pts):
    r = scene.compute_closest_points(o3d.core.Tensor(pts.astype(np.float32)))
    q = r["points"].numpy().astype(np.float64)
    tid = r["primitive_ids"].numpy()
    d = pts - q
    dist = np.linalg.norm(d, axis=1)
    sign = np.sign(np.einsum("ij,ij->i", d, mesh.n[tid]))
    sign[sign == 0] = 1.0
    return dist * sign, tid


def stats(d):
    d = np.asarray(d)
    a = np.abs(d)
    if not len(a):
        return {"n": 0}
    return {"n": int(len(a)), "mean": float(d.mean()), "sd": float(d.std()), "rms": float(np.sqrt((a ** 2).mean())), "p50": float(np.percentile(a, 50)),
            "p95": float(np.percentile(a, 95)), "p99": float(np.percentile(a, 99)), "max": float(a.max()),
            "in_0.05": float((a <= 0.05).mean()), "in_0.10": float((a <= 0.10).mean()), "in_0.15": float((a <= 0.15).mean())}


def line(name, s):
    if not s.get("n"):
        return "  %-34s no points" % name
    return "  %-34s n %6d  mean %+.3f  sd %.3f  |d| p50 %.3f p95 %.3f p99 %.3f  within 0.05: %5.1f %%  0.15: %5.1f %%" % (
        name, s["n"], s["mean"], s["sd"], s["p50"], s["p95"], s["p99"], 100 * s["in_0.05"], 100 * s["in_0.15"])


def run(code, cad_stls, scan_stl, zones=None, T=None, n=200000, far=0.3, tag="dev", exclude=None, refit=None):
    """exclude = predicate (P, N) -> mask of scan points that are not the part (table, known artefacts): reported
    separately and left out of the totals."""
    sys.stdout.reconfigure(encoding="utf-8")
    cad = rb.Mesh(np.concatenate([rb.read_stl(f) for f in cad_stls]))
    scan = rb.Mesh(rb.read_stl(scan_stl))
    if T is not None:
        scan = scan.moved(np.asarray(T, float))
    P, idx = scan.sample(n, seed=1)
    N = scan.n[idx]
    d, tid = closest(scene_of(cad.tri), cad, P)
    keep = np.ones(len(P), bool)
    out = {"cad": cad_stls, "scan": scan_stl, "n": n}
    if exclude is not None:
        ex = exclude(P, N)
        keep &= ~ex
        out["excluded"] = stats(d[ex])
    out["all"] = stats(d[keep])
    print("%s scan -> CAD (+ = scan outside the CAD)" % code)
    print(line("all", out["all"]))
    if exclude is not None:
        print(line("(excluded from the total)", out["excluded"]))
    out["zones"] = {}
    for nm, fn in (zones or {}).items():
        m = fn(P, N) & keep
        out["zones"][nm] = stats(d[m])
        print(line(nm, out["zones"][nm]))
    # pose or shape? small rigid motion of the scan that best fits a subset (point-to-plane), and what is left after it
    out["refit"] = {}
    sc = scene_of(cad.tri)
    for nm, fn in (refit or {}).items():
        m = fn(P, N) & keep
        Q = P[m].copy()
        Rt = np.eye(4)
        for _ in range(4):
            dq, tq = closest(sc, cad, Q)
            ok = np.abs(dq) < 0.6
            nn = cad.n[tq[ok]]
            A = np.c_[np.cross(Q[ok], nn), nn]
            x = -np.linalg.lstsq(A, dq[ok], rcond=None)[0]
            w, tv = x[:3], x[3:]
            th = np.linalg.norm(w)
            K = np.array([[0, -w[2], w[1]], [w[2], 0, -w[0]], [-w[1], w[0], 0]])
            Rm = np.eye(3) + K + 0.5 * K @ K if th < 1e-9 else np.eye(3) + np.sin(th) / th * K + (1 - np.cos(th)) / th ** 2 * K @ K
            S4 = np.eye(4); S4[:3, :3] = Rm; S4[:3, 3] = tv
            Q = rb.apply(S4, Q)
            Rt = S4 @ Rt
        dq, _ = closest(sc, cad, Q)
        ang = np.degrees(np.arccos(np.clip((np.trace(Rt[:3, :3]) - 1) / 2, -1, 1)))
        tilt = np.degrees(np.arccos(np.clip(Rt[2, 2], -1, 1)))
        out["refit"][nm] = {"before": stats(d[m]), "after": stats(dq), "rotation_deg": float(ang), "tilt_of_z_deg": float(tilt), "translation": Rt[:3, 3].tolist(), "T": Rt.tolist()}
        print(line(nm + " as placed", out["refit"][nm]["before"]))
        print(line(nm + " after own best fit", out["refit"][nm]["after"]))
        print("      best-fit motion of the scan subset: rotation %.3f deg (tilt of Z %.3f deg), translation (%.3f, %.3f, %.3f)" % (ang, tilt, *Rt[:3, 3]))
    # the other direction: where the CAD has no scan nearby
    C, cidx = cad.sample(n // 2, seed=2)
    dc, _ = closest(scene_of(scan.tri), scan, C)
    out["cad_without_scan_share"] = float((np.abs(dc) > far).mean())
    out["cad_to_scan"] = stats(dc[np.abs(dc) <= far])
    print("  CAD -> scan: %.1f %% of the CAD surface has no scan within %.2f mm; the rest: |d| p50 %.3f p95 %.3f" % (
        100 * out["cad_without_scan_share"], far, out["cad_to_scan"].get("p50", np.nan), out["cad_to_scan"].get("p95", np.nan)))
    # worst spots: 1 mm cells with |mean| > 0.15
    cell = np.floor(P[keep] / 1.0).astype(int)
    key, inv, cnt = np.unique(cell, axis=0, return_inverse=True, return_counts=True)
    inv = inv.ravel()
    mean = np.bincount(inv, weights=d[keep]) / cnt
    bad = np.nonzero((np.abs(mean) > 0.15) & (cnt >= 20))[0]
    bad = bad[np.argsort(-np.abs(mean[bad]) * np.sqrt(cnt[bad]))][:14]
    out["worst_cells"] = [{"centre": (key[i] + 0.5).tolist(), "mean": float(mean[i]), "n": int(cnt[i])} for i in bad]
    if len(bad):
        print("  worst 1 mm cells (centre x y z: mean dev, n): " + "; ".join("(%.1f %.1f %.1f): %+.2f, %d" % (*(key[i] + 0.5), mean[i], cnt[i]) for i in bad[:10]))
    rb.save_json(code, tag + ".json", out)
    # figure
    fig, axs = plt.subplots(2, 3, figsize=(21, 13))
    views = [("x", "z", 1, 0, 2, +1), ("x", "z (seen from +Y)", 1, 0, 2, -1), ("y", "z", 0, 1, 2, +1), ("y", "z (seen from -X)", 0, 1, 2, -1), ("x", "y (seen from +Z)", 2, 0, 1, +1), ("x", "y (seen from -Z)", 2, 0, 1, -1)]
    Pk, dk = P[keep], d[keep]
    for ax, (hl, vl, depth, hi, vi, sg) in zip(axs.ravel(), views):
        o = np.argsort(sg * Pk[:, depth])
        scp = ax.scatter(Pk[o, hi], Pk[o, vi], c=dk[o], s=1.0, cmap="RdBu_r", vmin=-0.3, vmax=0.3, linewidths=0)
        ax.set_aspect("equal"); ax.set_xlabel(hl); ax.set_ylabel(vl); ax.grid(True, lw=0.2)
        ax.set_title("nearest side: %s %s" % ("+" if sg > 0 else "-", "xyz"[depth]), fontsize=9)
    fig.colorbar(scp, ax=axs, shrink=0.6, label="scan - CAD (mm): red = scan outside the CAD")
    fig.suptitle("%s scan-to-CAD deviation: mean %+.3f, sd %.3f, %.1f %% within 0.15, %.1f %% within 0.05" % (
        code, out["all"]["mean"], out["all"]["sd"], 100 * out["all"]["in_0.15"], 100 * out["all"]["in_0.05"]))
    png = os.path.join(rb.pdir(code, "fig"), tag + ".png")
    fig.savefig(png, dpi=80)
    plt.close(fig)
    print("  figure", png)
    return out, P, N, d
