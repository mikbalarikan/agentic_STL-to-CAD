"""Re-align a spring scan on the axis of its wire-centre line (cylinder fit of the wire-section centres)."""
import sys, numpy as np, rb
code = sys.argv[1]
R = np.load(rb.pdir(code, "qa") + "/wire_sections.npy")
R = R[(R[:, 3] > 0.3) & (R[:, 3] < 1.0) & (R[:, 4] < 0.04) & (R[:, 5] >= 180)]
th = np.radians(R[:, 0]); pts = np.c_[R[:, 1] * np.cos(th), R[:, 1] * np.sin(th), R[:, 2]]
cy = rb.fit_cylinder(pts, [0, 0, 1], clip=3)
ax = cy["axis"] * np.sign(cy["axis"][2])
m = rb.Mesh(rb.read_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code))
T1 = rb.frame(ax, cy["point"])
q = m.moved(T1)
z0 = np.percentile(q.tri[:, :, 2], 0.01); Tz = np.eye(4); Tz[2, 3] = -z0
q = q.moved(Tz)
J = rb.load_json(code, "align.json"); T = Tz @ T1 @ np.array(J["T_raw_to_part"])
rb.write_stl(rb.SCAN + "/EP5-%s_aligned.stl" % code, q.tri, b"ulka C %s aligned: z = axis of the wire centre line, z=0 lower end" % code.encode())
J["T_raw_to_part"] = T; J["axis_refit"] = {"R_centre": cy["r"], "rms": cy["rms"], "n": cy["n_used"]}
rb.save_json(code, "align.json", J)
print(code, "centre R %.4f rms %.4f, new z range 0..%.3f" % (cy["r"], cy["rms"], q.hi[:, 2].max()))
