"""Probe: helix with variable pitch (closed ends) + Tube + ground-end trims. Not a deliverable."""
import os, sys, traceback, math
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen, NXOpen.Features, NXOpen.GeometricUtilities as GU
import nxh, nxf
OUT = sys.argv[1]
res = {"result": "FAIL", "log": []}
def log(m): res["log"].append(str(m))
try:
    part = nxh.new_part(os.path.join(OUT, "helix_probe.prt"))
    b = part.Features.CreateHelixBuilder(NXOpen.Features.Helix.Null)
    res["law_types"] = nxh.enum_names(GU.LawBuilder.Type)
    res["helix_doc"] = {k: str(v)[:300] for k, v in nxh.builder_doc(b).items()}
    res["law_doc"] = {k: str(v)[:300] for k, v in nxh.builder_doc(b.PitchLaw).items()}
    b.Destroy()
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "probe.json"), res)
