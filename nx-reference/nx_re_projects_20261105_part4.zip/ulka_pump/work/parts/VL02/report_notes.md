## Çerçeve ve tasarım
Kendi çerçevesinde: z0 = giriş tarafı ucu (bilya tarafı, küçük uç), +Z çıkışa; boy `vl02_len` (= `vl02_l0` 15,0; A
sıkışmış kopyayı buradan verir), aktif hatve boydan türetilir. Tel merkez eğrisi tek Law Curve (C1; ULKA-C'nin yöntemi):
0,75 kapalı sarım (hatve tel + 0,05), 0,5 sarım hatve geçişi, aktif sarımlar, uçta aynısı; çap küçük uçta Dm 3,6
(OD 4,1), 2 sarımda smoothstep ile Dm 5,1'e (OD 5,6). Toplam 11,5 sarım, aktif hatve 1,41 (tarama ≈1,4), blok ≈6,25.
Uçlar kapalı, taşlanmamış. Tel Ø 0,5 (`vl02_d`, tarama zayıf).

## Tarama
Tarama parçalı (tel parçaları); bağımsız ölçüm için zayıf, karşılaştırma yapılmadı; ölçüler D_MEASURED §4.
Montaj (CR-D-02): HS02 odasında bilya tepesi ile oda dibi (z 24,0) arası; dinlenmede 9,33, yukarı dayanmada 6,75.
