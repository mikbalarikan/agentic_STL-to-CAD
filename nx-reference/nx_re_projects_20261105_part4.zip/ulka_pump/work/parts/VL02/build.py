"""EP5-VL02_SPRING-BALL - native parametric build (NX 2206, headless), ULKA-D. Builder: D_common/nxlib/dsmall.py:spring."""
import os, sys, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\ulka\parts\D_common\nxlib")
import nxh, rj, dsmall
OUT = sys.argv[1]
res = {"result": "FAIL"}
try:
    c = rj.Ctx(OUT, "EP5-VL02_SPRING-BALL")
    body = dsmall.spring(c, "VL02", 3.6, 5.1, 2, 7, "scan: small end OD 4.0-4.4, body OD 5.6-5.9")
    c.finish({"body": body}, res)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "build.json"), res)
