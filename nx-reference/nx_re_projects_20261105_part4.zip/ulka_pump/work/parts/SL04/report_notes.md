## Çerçeve
Yerinde, nötr (kalıp) halinde torus: üst yüz HS02 havşa tabanında (`z_hs02` + `hs02_sl04_depth`). ID / kesit kontrol parçasından.

Standart eşleme: **metrik 4,5 x 2,0** (OD 8,5). Piston d_p 4,97 ile radyal sıkışma `sq_sl04` %8,5. Ön kontrol: %89,1 ±0,15.
