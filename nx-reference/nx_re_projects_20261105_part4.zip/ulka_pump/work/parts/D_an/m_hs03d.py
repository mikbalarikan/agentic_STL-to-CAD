import numpy as np,trimesh
from cfit import circ
m=trimesh.load('HS03_axisframe.stl',process=True); v=m.vertices; n=m.vertex_normals; z=v[:,2]
r=np.hypot(v[:,0],v[:,1])
def plane(sel):
    q=v[sel]; c=q.mean(0); u,s,vt=np.linalg.svd(q-c); nn=vt[2]*np.sign(vt[2][2]); 
    res=(q-c)@nn; return c,nn,res.std(),len(q)
for nm,sel in [('bottom face',(np.abs(z-3.35)<0.4)&(n[:,2]<-0.9)),('top plate',(np.abs(z-9.2)<0.5)&(n[:,2]>0.9)),('top end',(z>22.8)&(n[:,2]>0.9)),('step 11.5',(np.abs(z-11.5)<0.4)&(n[:,2]<-0.9))]:
    c,nn,sd,k=plane(sel); print(nm,'z@0 %.3f'%(c[2]-(nn[0]*(0-c[0])+nn[1]*(0-c[1]))/nn[2]*-1 if False else c[2]),'normal',np.round(nn,4),'tilt deg %.2f'%np.degrees(np.arccos(nn[2])),'sd %.3f n %d'%(sd,k),'ctr',np.round(c,2))
# holes and pins by windowed circle fits
def hole(cx,cy,rlo,rhi,zlo,zhi,inward):
    for it in range(6):
        d=np.hypot(v[:,0]-cx,v[:,1]-cy)
        rn=(n[:,0]*(v[:,0]-cx)+n[:,1]*(v[:,1]-cy))/np.maximum(d,1e-9)
        s=(d>rlo)&(d<rhi)&(z>zlo)&(z<zhi)&(np.abs(n[:,2])<0.35)&((rn<-0.5) if inward else (rn>0.5))
        cx,cy,R=circ(v[s,0],v[s,1])
    res=np.hypot(v[s,0]-cx,v[s,1]-cy)-R
    return cx,cy,2*R,res.std(),s.sum()
for c0 in [(18.6,7.3),(-18.6,-7.1)]:
    cx,cy,D,sd,k=hole(*c0,1.2,3.2,3.6,8.9,True); print('ear hole c=(%.3f,%.3f) rc=%.3f ang=%.2f D=%.3f sd %.3f n %d'%(cx,cy,np.hypot(cx,cy),np.degrees(np.arctan2(cy,cx)),D,sd,k))
for c0 in [(-15,-0.5),(-11,-9.8),(11.1,10),(15,0.8)]:
    cx,cy,D,sd,k=hole(*c0,0.8,2.3,0.8,2.9,False); print('pin c=(%.3f,%.3f) rc=%.3f ang=%.2f D=%.3f sd %.3f n %d'%(cx,cy,np.hypot(cx,cy),np.degrees(np.arctan2(cy,cx)),D,sd,k))
# ear outer arc radius about hole centre
for c0 in [(18.6,7.3),(-18.6,-7.1)]:
    d=np.hypot(v[:,0]-c0[0],v[:,1]-c0[1]); s=(z>4)&(z<8.5)&(d<6.5)&(np.abs(n[:,2])<0.3)
    rn=(n[:,0]*(v[:,0]-c0[0])+n[:,1]*(v[:,1]-c0[1]))/np.maximum(d,1e-9); s&=(rn>0.6)&(d>3)
    cx,cy,R=circ(v[s,0],v[s,1]); print('ear outer arc c=(%.2f,%.2f) R=%.3f'%(cx,cy,R))
