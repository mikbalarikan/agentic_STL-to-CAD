import numpy as np,trimesh,json
from cfit import circ
A=json.load(open('HS02_axis.json'))
m=trimesh.load(r"H:\My Drive\Mini Pumps\ulka re\EP5-HS02 Piston silindiri.stl",process=True)
R0=np.array(A['R']); p0=np.array(A['p0']); T0=np.eye(4); T0[:3,:3]=R0; T0[:3,3]=-R0@p0; T0[2,3]-=A['zshift']
m.apply_transform(T0)
v=m.vertices; n=m.vertex_normals; z=v[:,2]; r=np.hypot(v[:,0],v[:,1])
# planar faces
fn=m.face_normals; c=m.triangles_center; Ar=m.area_faces
for sgn in [1,-1]:
    s=fn[:,2]*sgn>0.95; h,e=np.histogram(c[s,2],bins=np.arange(-0.5,43,0.1),weights=Ar[s])
    print('planar',sgn,[(round(e[i]+0.05,2),round(h[i],1)) for i in sorted(np.argsort(h)[::-1][:8])])
def pl(sel):
    q=v[sel]; cc=q.mean(0); u,sv,vt=np.linalg.svd(q-cc); nn=vt[2]*np.sign(vt[2][2]); return nn,((q-cc)@nn).std(),len(q),cc
for nm,sel in [('flange end',(z<0.6)&(n[:,2]<-0.9)),('cbore floor',(np.abs(z-2.25)<0.3)&(n[:,2]<-0.9)),('outlet end',(z>40.8)&(n[:,2]>0.9)),('inner 28.65',(np.abs(z-28.65)<0.3)&(n[:,2]<-0.9))]:
    nn,sd,k,cc=pl(sel); print(nm,np.round(nn,4),'tilt %.2f'%np.degrees(np.arccos(nn[2])),'sd %.3f n %d ctr %s'%(sd,k,np.round(cc,2)))
