import numpy as np,trimesh
from scipy.optimize import least_squares
from cfit import circ
m=trimesh.load(r'C:\NX_MCP_WORKSPACE\ulka\scan\EP5-VL03_head_aligned.stl',process=True); v=m.vertices; n=m.vertex_normals
top=v[v[:,2]>11.3]
s=least_squares(lambda a:np.linalg.norm(top-a[:3],axis=1)-a[3],[v[:,0].mean(),v[:,1].mean(),10.5,2.5],loss='soft_l1',f_scale=0.05)
print('dome sphere ctr',np.round(s.x[:3],3),'R %.3f'%s.x[3])
cx,cy=s.x[0],s.x[1]
for z0 in np.arange(7.0,13.0,0.5):
    w=(v[:,2]>z0)&(v[:,2]<z0+0.5)
    if w.sum()>20:
        a,b,R=circ(v[w,0],v[w,1]); r=np.hypot(v[w,0]-cx,v[w,1]-cy)
        print('z %.1f circle D %.3f  r_p95 %.3f n %d'%(z0,2*R,np.percentile(r,95),w.sum()))
print('zmax',v[:,2].max())
m=trimesh.load(r'C:\NX_MCP_WORKSPACE\ulka\scan\EP5-VL04_aligned.stl',process=True); v=m.vertices
for z0 in np.arange(0.3,6.8,0.5):
    w=(v[:,2]>z0)&(v[:,2]<z0+0.5)
    if w.sum()>20:
        r=np.hypot(v[w,0]-cx,v[w,1]-cy); print('VL04 z %.1f r p5 %.2f p50 %.2f p95 %.2f n %d'%(z0,*np.percentile(r,[5,50,95]),w.sum()))
m=trimesh.load(r'C:\NX_MCP_WORKSPACE\ulka\scan\EP5-VL02_aligned.stl',process=True); v=m.vertices
for z0 in np.arange(0.3,15.3,0.5):
    w=(v[:,2]>z0)&(v[:,2]<z0+0.5)
    if w.sum()>20:
        r=np.hypot(v[w,0],v[w,1]); print('VL02 z %.1f r p5 %.2f p50 %.2f p95 %.2f n %d'%(z0,*np.percentile(r,[5,50,95]),w.sum()))
