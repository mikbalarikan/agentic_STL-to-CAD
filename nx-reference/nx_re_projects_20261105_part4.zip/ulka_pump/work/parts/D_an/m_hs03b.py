import numpy as np,trimesh
from cfit import circ
from scipy.cluster.vq import kmeans2
m=trimesh.load('HS03_axisframe.stl',process=True); v=m.vertices; n=m.vertex_normals
r=np.hypot(v[:,0],v[:,1]); z=v[:,2]
# ear holes: inward-facing wall points at r>13, z 4.5..8.5
s=(r>13)&(z>4.5)&(z<8.5)&(np.abs(n[:,2])<0.3)
P=v[s]
# candidate: points forming small circles; cluster by angle sign
for sgn in [1,-1]:
    q=P[(P[:,0]*sgn>0)]
    # seed centre from photo: hole near max r
    rr=np.hypot(q[:,0],q[:,1]); 
    cx,cy=q[np.argmax(rr)][:2]*0.92
    for it in range(8):
        d=np.hypot(q[:,0]-cx,q[:,1]-cy); sel=d<2.6
        cx,cy,R=circ(q[sel,0],q[sel,1])
    d=np.hypot(q[sel,0]-cx,q[sel,1]-cy)-R
    print('ear hole',sgn,'c=(%.3f,%.3f) r_c=%.3f ang=%.2f D=%.3f sd %.3f n %d'%(cx,cy,np.hypot(cx,cy),np.degrees(np.arctan2(cy,cx)),2*R,d.std(),sel.sum()))
# ear outer contour radius around hole: max distance from hole centre of plate points
# pins below z 3.2
s=(z<2.9)&(z>0.6)
q=v[s]; 
cent,lab=kmeans2(q[:,:2],4,seed=1,minit='++')
for k in range(4):
    w=q[lab==k]; cx,cy,R=circ(w[:,0],w[:,1]); d=np.hypot(w[:,0]-cx,w[:,1]-cy)-R
    print('pin %d c=(%.3f,%.3f) rc=%.3f ang=%.1f D=%.3f sd %.3f n %d zmin %.2f'%(k,cx,cy,np.hypot(cx,cy),np.degrees(np.arctan2(cy,cx)),2*R,d.std(),len(w),w[:,2].min()))
print('overall z min',z.min(), 'plate extent x',v[(z>4)&(z<8.5),0].min(),v[(z>4)&(z<8.5),0].max())
