import numpy as np
def circ(x,y):
    A=np.c_[2*x,2*y,np.ones_like(x)]; s=np.linalg.lstsq(A,x**2+y**2,rcond=None)[0]
    return s[0],s[1],np.sqrt(s[2]+s[0]**2+s[1]**2)
def centre_outer(p, zlo, zhi, it=6):
    s=(p[:,2]>zlo)&(p[:,2]<zhi); q=p[s]
    cx,cy,R=circ(q[:,0],q[:,1])
    for k in range(it):
        r=np.hypot(q[:,0]-cx,q[:,1]-cy)
        th=np.arctan2(q[:,1]-cy,q[:,0]-cx)
        # take outermost per 5deg sector
        sel=[]
        for a in np.arange(-np.pi,np.pi,np.pi/36):
            m=(th>=a)&(th<a+np.pi/36)
            if m.sum()>5:
                i=np.where(m)[0]; sel.extend(i[r[i]>np.percentile(r[i],80)])
        sel=np.array(sel)
        cx,cy,R=circ(q[sel,0],q[sel,1])
    res=np.hypot(q[sel,0]-cx,q[sel,1]-cy)-R
    return cx,cy,R,np.std(res)
