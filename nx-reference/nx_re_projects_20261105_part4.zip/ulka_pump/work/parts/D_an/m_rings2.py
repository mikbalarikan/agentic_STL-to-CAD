import pickle, numpy as np
T,parts=pickle.load(open('C2_parts.pkl','rb'))
C=[(-25.72,-12.94),(-15.07,16.61),(24.27,4.41),(5.52,-7.89)]
for i in range(4):
    q=parts[i].copy(); q.apply_transform(T); p=q.vertices
    cx,cy=C[i]
    # refine centre with circle fit of points near equator outer
    rr=np.hypot(p[:,0]-cx,p[:,1]-cy); th=np.arctan2(p[:,1]-cy,p[:,0]-cx)
    if i==3: p=p[rr>2.2]; rr=rr[rr>2.2]; th=th[rr>2.2] if False else np.arctan2(p[:,1]-cy,p[:,0]-cx)
    # per-angle-sector extents
    OD=[];ID=[];H=[]
    for a in np.linspace(-np.pi,np.pi,37)[:-1]:
        s=(th>=a)&(th<a+np.pi/18)
        if s.sum()<50: continue
        OD.append(np.percentile(rr[s],99.5)); ID.append(np.percentile(rr[s],0.5)); H.append(np.percentile(p[s,2],99.5))
    OD=np.array(OD);ID=np.array(ID);H=np.array(H)
    # OD/ID from opposite sectors sum -> use mean radius*2
    print(f"part{i}: OD={2*np.median(OD):.3f} (sd {np.std(OD):.3f})  ID={2*np.median(ID):.3f} (sd {np.std(ID):.3f})  width={np.median(OD-ID):.3f}  H={np.median(H):.3f} (min {H.min():.2f} max {H.max():.2f}) sectors {len(OD)}")
