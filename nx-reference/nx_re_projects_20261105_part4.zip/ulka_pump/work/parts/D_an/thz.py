import sys,pickle,numpy as np,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
key=sys.argv[1]; idx=[int(a) for a in sys.argv[2].split(',')]; out=sys.argv[3]; cx,cy=map(float,sys.argv[4].split(','))
T,parts=pickle.load(open(f'{key}_parts.pkl','rb'))
p=np.vstack([ (lambda q:(q.apply_transform(T),q.vertices)[1])(parts[i].copy()) for i in idx])
r=np.hypot(p[:,0]-cx,p[:,1]-cy); th=np.degrees(np.arctan2(p[:,1]-cy,p[:,0]-cx))
fig,ax=plt.subplots(1,2,figsize=(14,8))
sc=ax[0].scatter(th,p[:,2],c=r,s=0.3,cmap='jet',vmin=0,vmax=3.5); plt.colorbar(sc,ax=ax[0]); ax[0].grid(True); ax[0].set_yticks(np.arange(0,16,0.5)); ax[0].tick_params(labelsize=6)
ax[1].scatter(p[:,0]-cx,p[:,1]-cy,c=p[:,2],s=0.3,cmap='jet'); ax[1].set_aspect('equal'); ax[1].grid(True)
plt.savefig(out,dpi=100)
