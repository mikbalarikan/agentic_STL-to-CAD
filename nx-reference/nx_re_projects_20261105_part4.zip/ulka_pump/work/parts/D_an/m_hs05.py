import pickle,numpy as np,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from cfit import centre_outer, circ
T,parts=pickle.load(open('C1_parts.pkl','rb'))
q=parts[0].copy(); q.apply_transform(T); p=q.vertices
cx,cy,R,sd=centre_outer(p,0.4,2.0); print('outer wall: c',cx,cy,'D=%.3f sd %.3f'%(2*R,sd))
r=np.hypot(p[:,0]-cx,p[:,1]-cy)
# inner wall
s=(p[:,2]>0.4)&(p[:,2]<2.0)&(r<3.8)&(r>2.6); a,b,Ri=circ(p[s,0],p[s,1]); print('inner wall c',a,b,'D=%.3f'%(2*Ri), 'n',s.sum())
fig,ax=plt.subplots(figsize=(10,5)); ax.scatter(r,p[:,2],s=0.2,alpha=0.3); ax.set_aspect('equal'); ax.grid(True)
ax.set_xticks(np.arange(0,9,0.25)); ax.tick_params(labelsize=5); plt.savefig('fig/rz_HS05b.png',dpi=120)
# top surface z by r bins
for r0 in np.arange(2,8.6,0.25):
    m=(r>r0)&(r<r0+0.25)&(p[:,2]>1.8)
    if m.sum(): print('r %.2f top z %.3f n %d'%(r0,np.percentile(p[m,2],90),m.sum()))
