import numpy as np,trimesh,json
from cfit import circ
m=trimesh.load(r'C:\NX_MCP_WORKSPACE\ulka\scan\EP5-HS03_aligned.stl',process=True); v=m.vertices; n=m.vertex_normals; z=v[:,2]
Rj=json.load(open('HS03_meas.json'))
def fitc(cx,cy,rlo,rhi,zlo,zhi,inw):
    for it in range(6):
        d=np.hypot(v[:,0]-cx,v[:,1]-cy); rn=(n[:,0]*(v[:,0]-cx)+n[:,1]*(v[:,1]-cy))/np.maximum(d,1e-9)
        s=(d>rlo)&(d<rhi)&(z>zlo)&(z<zhi)&(np.abs(n[:,2])<0.35)&((rn<-0.5) if inw else (rn>0.5)); cx,cy,R=circ(v[s,0],v[s,1])
    res=np.hypot(v[s,0]-cx,v[s,1]-cy)-R
    return dict(c=[round(cx,3),round(cy,3)],rc=round(float(np.hypot(cx,cy)),3),ang=round(float(np.degrees(np.arctan2(cy,cx))),2),D=round(2*R,3),sd=round(res.std(),3))
H=[fitc(19,0,1.2,3.2,0.3,5.5,True),fitc(-19,0,1.2,3.2,0.3,5.5,True)]
print('holes',H, 'span %.3f'%np.hypot(H[0]['c'][0]-H[1]['c'][0],H[0]['c'][1]-H[1]['c'][1]))
# pins: find via clustering of z<-0.5 points
q=v[z<-0.6]; ang=np.degrees(np.arctan2(q[:,1],q[:,0]))
P=[]
for a0 in [-20,20,160,-160]:
    sel=np.abs(((ang-a0+180)%360)-180)<25
    c=q[sel,:2].mean(0); P.append(fitc(c[0],c[1],0.6,2.3,-2.6,-0.5,False))
print('pins',P)
# ear outer arcs about holes
E=[]
for h in H:
    cx,cy=h['c']; d=np.hypot(v[:,0]-cx,v[:,1]-cy); rn=(n[:,0]*(v[:,0]-cx)+n[:,1]*(v[:,1]-cy))/np.maximum(d,1e-9)
    s=(z>0.8)&(z<5)&(d>3.3)&(d<6.5)&(np.abs(n[:,2])<0.3)&(rn>0.7)
    a,b,R=circ(v[s,0],v[s,1]); E.append(dict(c=[round(a,3),round(b,3)],R=round(R,3)))
print('ear arcs',E)
# plate straight edges: tangent lines between ear arc and boss -> sample outer contour at z=3
s=(np.abs(z-3)<0.3)&(np.abs(n[:,2])<0.3); p=v[s]
rr=np.hypot(p[:,0],p[:,1]); th=np.degrees(np.arctan2(p[:,1],p[:,0]))
for a in range(0,360,15):
    w=np.abs(((th-a+180)%360)-180)<2
    if w.sum(): print('  plate outline ang %3d rmax %.2f'%(a,rr[w].max()))
Rj.update(ear_holes=H,pins=P,ear_arcs=E); json.dump(Rj,open('HS03_meas.json','w'),indent=1)
