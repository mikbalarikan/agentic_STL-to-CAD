import numpy as np,trimesh
from scipy.optimize import least_squares
m=trimesh.load(r'C:\NX_MCP_WORKSPACE\ulka\scan\EP5-HS02_aligned.stl',process=True); v=m.vertices; n=m.vertex_normals; z=v[:,2]
def fitfixed(sel,cx=0,cy=0):
    r=np.hypot(v[sel,0]-cx,v[sel,1]-cy); return 2*np.median(r),r.std()
def fitfree(sel):
    q=v[sel]
    f=lambda a: np.hypot(q[:,0]-a[0],q[:,1]-a[1])-a[2]
    s=least_squares(f,[0,0,np.median(np.hypot(q[:,0],q[:,1]))],loss='soft_l1',f_scale=0.05); return s.x, f(s.x).std()
r=np.hypot(v[:,0],v[:,1]); rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9); th=np.degrees(np.arctan2(v[:,1],v[:,0]))
for nm,(rlo,rhi,zlo,zhi,inw) in {'inlet_cbore':(3.9,5.0,0.3,1.9,True),'piston_bore':(2.6,3.6,2.6,7.0,True),'outlet_room':(4.2,5.3,30.5,39.5,True),'flange':(7.3,8.4,0.4,2.5,False),'body_29_39':(6.2,7.2,29.5,39.5,False)}.items():
    sel=(r>rlo)&(r<rhi)&(z>zlo)&(z<zhi)&(np.abs(n[:,2])<0.4)&((rn<-0.3) if inw else (rn>0.3))
    D,sd=fitfixed(sel); x,sd2=fitfree(sel)
    cov=len(np.unique((th[sel]//10).astype(int)))*10
    print('%-12s fixed-axis D %.3f (sd %.3f) | free fit c(%.3f,%.3f) D %.3f sd %.3f | cover %d deg n %d'%(nm,D,sd,x[0],x[1],2*x[2],sd2,cov,sel.sum()))
print('--- inner about local OD centre')
for nm,(rlo,rhi,zlo,zhi),c in [('inlet_cbore',(3.9,5.0,0.3,1.9),(-0.008,0.152)),('piston_bore',(2.6,3.6,2.6,7.0),(0.0,0.08)),('outlet_room',(4.2,5.3,30.5,39.5),(-0.033,0.182))]:
    rr=np.hypot(v[:,0]-c[0],v[:,1]-c[1]); rnn=(n[:,0]*(v[:,0]-c[0])+n[:,1]*(v[:,1]-c[1]))/np.maximum(rr,1e-9)
    sel=(rr>rlo)&(rr<rhi)&(z>zlo)&(z<zhi)&(np.abs(n[:,2])<0.4)&(rnn<-0.3)
    t=np.degrees(np.arctan2(v[sel,1]-c[1],v[sel,0]-c[0]))
    print(nm,'D %.3f sd %.3f'%(2*np.median(rr[sel]),rr[sel].std()))
    for a in range(-180,180,30):
        k=(t>=a)&(t<a+30)
        if k.sum()>10: print('   ang %4d..%4d r %.3f n %d'%(a,a+30,np.median(rr[sel][k]),k.sum()))
