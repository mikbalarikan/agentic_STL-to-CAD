import sys,json,numpy as np,trimesh,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
src=sys.argv[1]; tag=sys.argv[2]; a=json.load(open(f'{tag}_axis.json'))
m=trimesh.load(src,process=True)
R=np.array(a['R']); p0=np.array(a['p0'])
T=np.eye(4); T[:3,:3]=R; T[:3,3]=-R@p0; T[2,3]-=a['zshift']
m.apply_transform(T)
angs=[float(x) for x in sys.argv[3].split(',')] if len(sys.argv)>3 else [0,45,90,135]
fig,axs=plt.subplots(2,2,figsize=(16,16)); axs=axs.ravel()
for k,ang in enumerate(angs):
    t=np.radians(ang); n=np.array([-np.sin(t),np.cos(t),0])
    from trimesh.intersections import mesh_plane
    seg=mesh_plane(m,n,[0,0,0])
    ax=axs[k]; d=np.array([np.cos(t),np.sin(t),0])
    from matplotlib.collections import LineCollection
    L=np.stack([seg@d,seg[:,:,2]],-1); ax.add_collection(LineCollection(L,colors='k',linewidths=0.6)); ax.autoscale()
    ax.set_aspect('equal'); ax.grid(True); ax.set_title(f'{tag} section angle {ang}')
    ax.set_xticks(np.arange(-26,27,2)); ax.set_yticks(np.arange(-2,45,1)); ax.tick_params(labelsize=6)
plt.tight_layout(); plt.savefig(f'fig/sec_{tag}.png',dpi=80)
m.export(f'{tag}_axisframe.stl')
