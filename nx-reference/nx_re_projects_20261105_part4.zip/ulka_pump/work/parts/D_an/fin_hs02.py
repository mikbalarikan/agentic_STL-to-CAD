import numpy as np,trimesh,json
from cfit import circ
m=trimesh.load(r'C:\NX_MCP_WORKSPACE\ulka\scan\EP5-HS02_aligned.stl',process=True); v=m.vertices; n=m.vertex_normals; z=v[:,2]; r=np.hypot(v[:,0],v[:,1])
rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9); th=np.degrees(np.arctan2(v[:,1],v[:,0]))
R={}
def wall(nm,rlo,rhi,zlo,zhi,inw,excl_recess=False):
    s=(r>rlo)&(r<rhi)&(z>zlo)&(z<zhi)&(np.abs(n[:,2])<0.3)&((rn<-0.5) if inw else (rn>0.5))
    if excl_recess: s&=np.abs(th)>50
    cx,cy,Rr=circ(v[s,0],v[s,1]); res=np.hypot(v[s,0]-cx,v[s,1]-cy)-Rr
    zz=z[s]; h=np.median(zz); rr=np.hypot(v[s,0]-cx,v[s,1]-cy)
    R[nm]=dict(D=round(2*Rr,3),sd=round(res.std(),3),ctr=[round(cx,3),round(cy,3)],D_low=round(2*np.median(rr[zz<h]),3),D_high=round(2*np.median(rr[zz>=h]),3),z=[zlo,zhi],n=int(s.sum()),cover_deg=int(len(np.unique((th[s]//10).astype(int)))*10))
    print(nm,R[nm])
wall('flange_OD',7.3,8.4,0.4,2.6,False)
wall('body_OD_a',6.2,7.2,4,10,False)
wall('body_OD_b',6.2,7.2,10.5,15,False)
wall('body_OD_c',6.2,7.2,15.5,22,False)
wall('body_OD_d',6.2,7.2,29.5,39.5,False)
wall('inlet_cbore',4.0,5.0,0.3,2.0,True)
wall('piston_bore_in',2.6,3.6,2.6,7.5,True)
wall('outlet_cbore',4.1,5.0,30.5,39.0,True)
def lev(nm,z0,sgn,rlo=0,rhi=99,w=0.35):
    s=(np.abs(z-z0)<w)&(n[:,2]*sgn>0.85)&(r>rlo)&(r<rhi)
    if s.sum()==0: print(nm,'none'); return
    R[nm]=dict(z=round(float(np.median(z[s])),3),sd=round(float(z[s].std()),3),n=int(s.sum()),r=[round(float(np.percentile(r[s],2)),2),round(float(np.percentile(r[s],98)),2)]); print(nm,R[nm])
lev('flange_end',0,-1); lev('inlet_cbore_floor',2.25,-1,2.5,4.7); lev('flange_back',2.95,1,6.6,8.2); lev('outlet_end',41.3,1)
lev('outlet_cbore_floor',29.6,1,2.5,4.7,0.6); lev('recess_end_low',22.4,1,5.5,7,0.5); lev('recess_end_high',28.6,-1,5.5,7,0.5)
# recess: angular extent and depth
s=(z>23.2)&(z<27.8)&(rn>0.5)&(np.abs(n[:,2])<0.3)
for a in range(-90,91,10):
    w=s&(np.abs(th-a)<5)
    if w.sum()>10: print('  recess zone ang %4d r med %.3f'%(a,np.median(r[w])))
# is recess flat? fit plane to recess floor points
w=s&(r<6.4)&(np.abs(th)<40); q=v[w]; c=q.mean(0); u,sv,vt=np.linalg.svd(q-c); nn=vt[2]
print('recess floor plane normal',np.round(nn,3),'sd %.3f'%((q-c)@nn).std(),'dist from axis %.3f'%abs(c@nn), 'r range',np.percentile(r[w],[2,98]))
# chamfer at outlet end outer
for zz in np.arange(39.5,41.4,0.2):
    w=(np.abs(z-zz)<0.1)&(rn>0.3)&(r>5)
    if w.sum()>10: print('  outlet outer r z %.1f %.3f'%(zz,np.median(r[w])))
for zz in np.arange(38.5,41.4,0.25):
    w=(np.abs(z-zz)<0.1)&(rn<-0.3)&(r<6)&(r>3.5)
    if w.sum()>10: print('  outlet inner r z %.2f %.3f'%(zz,np.median(r[w])))
for zz in np.arange(2.2,9,0.5):
    w=(np.abs(z-zz)<0.2)&(rn<-0.3)&(r<4)&(r>2.4)
    if w.sum()>10: print('  piston bore r z %.1f %.3f n %d'%(zz,np.median(r[w]),w.sum()))
for zz in np.arange(28.5,31,0.25):
    w=(np.abs(z-zz)<0.12)&(r<4.7)&(r>2.0)
    if w.sum()>10: print('  outlet floor zone z %.2f rmin %.3f rmed %.3f n %d'%(zz,np.percentile(r[w],2),np.median(r[w]),w.sum()))
json.dump(R,open('HS02_meas.json','w'),indent=1)
