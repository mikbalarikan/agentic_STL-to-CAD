import pickle,numpy as np
from cfit import circ
T,parts=pickle.load(open('C1_parts.pkl','rb'))
q=parts[0].copy(); q.apply_transform(T); p=q.vertices; nz=q.vertex_normals[:,2]
cx,cy=-6.49,6.49
for it in range(5):
    r=np.hypot(p[:,0]-cx,p[:,1]-cy)
    s=(p[:,2]>0.5)&(p[:,2]<2.0)&(r>6.5)&(np.abs(nz)<0.4)
    cx,cy,R=circ(p[s,0],p[s,1])
res=np.hypot(p[s,0]-cx,p[s,1]-cy)-R
print('OD %.3f sd %.3f n %d c %.3f %.3f'%(2*R,res.std(),s.sum(),cx,cy))
r=np.hypot(p[:,0]-cx,p[:,1]-cy)
s=(p[:,2]>0.5)&(p[:,2]<2.0)&(r<3.6)&(r>2.4)&(np.abs(nz)<0.5)
a,b,Ri=circ(p[s,0],p[s,1]); res=np.hypot(p[s,0]-a,p[s,1]-b)-Ri
print('hole %.3f sd %.3f c %.3f %.3f n %d'%(2*Ri,res.std(),a,b,s.sum()))
for zz in [0.5,1.0,1.5,2.0]:
    s2=(np.abs(p[:,2]-zz)<0.15)&(np.abs(nz)<0.5)
    rr=r[s2]; print('z %.1f outer r med %.3f  inner r med %.3f'%(zz,np.median(rr[rr>6]),np.median(rr[rr<4])))
top=(nz>0.9)&(r>3.6)&(r<7.2); print('top face z med %.3f p5 %.3f p95 %.3f'%(np.median(p[top,2]),*np.percentile(p[top,2],[5,95])))
