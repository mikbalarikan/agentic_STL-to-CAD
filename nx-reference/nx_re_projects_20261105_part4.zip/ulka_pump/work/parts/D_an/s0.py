import sys, os, numpy as np, trimesh
SRC=r"H:\My Drive\Mini Pumps\ulka re"
names=[f for f in os.listdir(SRC) if f.endswith('.stl') and any(k in f for k in ['HS02','HS03','HS05','SL04','VL05'])]
for f in names:
    m=trimesh.load(os.path.join(SRC,f),process=True)
    parts=m.split(only_watertight=False,repair=False)
    print('\n==',f,len(m.faces),'faces, bbox',np.round(m.extents,2),'wt',m.is_watertight)
    big=sorted(parts,key=lambda p:-len(p.faces))
    for p in big[:12]:
        print('  comp faces %7d ext %s ctr %s wt %s vol %.1f'%(len(p.faces),np.round(p.extents,2),np.round(p.bounds.mean(0),2),p.is_watertight,p.volume if p.is_watertight else -1))
    print('  total comps',len(parts),'small(<200f)',sum(len(p.faces)<200 for p in parts))
