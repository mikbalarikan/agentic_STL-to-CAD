import sys,os,numpy as np,trimesh,json,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.optimize import least_squares
src=sys.argv[1]; tag=sys.argv[2]
m=trimesh.load(src,process=True)
n=m.face_normals; w=m.area_faces; c=m.triangles_center
# axis = direction most perpendicular to normals of cylindrical faces: eig of weighted normal covariance, smallest
C=(n*w[:,None]).T@n; ev,evec=np.linalg.eigh(C); ax=evec[:,0]
print('eig',np.round(ev/ev.sum(),3),'axis0',np.round(ax,4))
# refine: select faces with |n.ax|<0.2 (cyl walls); fit line axis: each normal line passes axis -> least squares
sel=np.abs(n@ax)<0.15
P=c[sel]; N=n[sel]; W=w[sel]
def res(a):
    d=a[:3]/np.linalg.norm(a[:3]); p0=a[3:]
    # distance between normal line and axis line
    cr=np.cross(N,d); cn=np.linalg.norm(cr,axis=1)+1e-9
    return ((P-p0)*cr).sum(1)/cn*np.sqrt(W)
p0=c.mean(0)
s=least_squares(res,np.r_[ax,p0],loss='soft_l1',f_scale=0.05)
d=s.x[:3]/np.linalg.norm(s.x[:3]); p0=s.x[3:]
print('axis',np.round(d,5),'p0',np.round(p0,3),'cost',s.cost)
# frame
x=np.cross(d,[0,0,1]); x/=np.linalg.norm(x); y=np.cross(d,x)
R=np.vstack([x,y,d]); v=(m.vertices-p0)@R.T
v[:,2]-=v[:,2].min()
json.dump(dict(R=R.tolist(),p0=p0.tolist(),zshift=float(((m.vertices-p0)@R.T)[:,2].min())),open(f'{tag}_axis.json','w'))
r=np.hypot(v[:,0],v[:,1])
fig,a=plt.subplots(figsize=(16,7)); a.scatter(v[:,2],r,s=0.05,alpha=0.3); a.set_aspect('equal'); a.grid(True)
a.set_xticks(np.arange(0,v[:,2].max()+1,1)); a.set_yticks(np.arange(0,r.max()+1,0.5)); a.tick_params(labelsize=6)
plt.savefig(f'fig/zr_{tag}.png',dpi=110)
np.save(f'{tag}_v.npy',v)
print('length',v[:,2].max())
