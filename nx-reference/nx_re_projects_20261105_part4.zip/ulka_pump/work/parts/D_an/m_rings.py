import pickle, numpy as np, trimesh
from scipy.optimize import least_squares
def fit_circle2(x,y):
    A=np.c_[2*x,2*y,np.ones_like(x)]; b=x**2+y**2
    s=np.linalg.lstsq(A,b,rcond=None)[0]; return s[0],s[1],np.sqrt(s[2]+s[0]**2+s[1]**2)
def torus(q, z0=0.0):
    p=q.vertices
    # centre: fit circle to xy of top-ish points (rough), then torus LSQ
    cx,cy,_=fit_circle2(p[:,0],p[:,1])
    def res(a):
        cx,cy,R,zc,r=a
        rr=np.hypot(p[:,0]-cx,p[:,1]-cy)
        return np.hypot(rr-R,p[:,2]-zc)-r
    R0=np.median(np.hypot(p[:,0]-cx,p[:,1]-cy)); r0=p[:,2].max()/2
    s=least_squares(res,[cx,cy,R0,r0,r0],loss='soft_l1',f_scale=0.05)
    rs=res(s.x)
    return s.x, np.std(rs), np.percentile(np.abs(rs),95)
T,parts=pickle.load(open('C2_parts.pkl','rb'))
for i in range(3):
    q=parts[i].copy(); q.apply_transform(T)
    a,sd,p95=torus(q)
    cx,cy,R,zc,r=a
    print(f"ring{i}: ctr({cx:.2f},{cy:.2f}) Rc={R:.3f} cs d2={2*r:.3f} ID d1={2*(R-r):.3f} OD={2*(R+r):.3f} zc={zc:.3f} (zc-r={zc-r:.3f}) sd={sd:.3f} p95={p95:.3f} zmax={q.vertices[:,2].max():.2f}")
# SL04 + ball
q=parts[3].copy(); q.apply_transform(T); p=q.vertices
cx,cy=5.5,-7.9
rr=np.hypot(p[:,0]-cx,p[:,1]-cy)
ring=p[(p[:,2]<1.95)|(rr>3.0)]
# ball points: z>2.1 and r<2.5
ball=p[(p[:,2]>2.2)&(rr<2.6)]
def sph(a): return np.linalg.norm(ball-a[:3],axis=1)-a[3]
s=least_squares(sph,[ball[:,0].mean(),ball[:,1].mean(),2.0,1.8],loss='soft_l1',f_scale=0.05)
print('ball centre',np.round(s.x[:3],3),'D=%.3f'%(2*s.x[3]),'sd %.3f'%np.std(sph(s.x)), 'n',len(ball))
a,sd,p95=torus(trimesh.Trimesh(ring,process=False))
cx,cy,R,zc,r=a
print(f"SL04: ctr({cx:.2f},{cy:.2f}) Rc={R:.3f} d2={2*r:.3f} d1={2*(R-r):.3f} OD={2*(R+r):.3f} zc={zc:.3f} zc-r={zc-r:.3f} sd={sd:.3f}")
