import numpy as np,trimesh,json
from cfit import circ
m=trimesh.load('HS03_axisframe.stl',process=True)
def faces(m):
    return m.vertices,m.vertex_normals
v,n=faces(m); z=v[:,2]
sels=[(np.abs(z-3.35)<0.4)&(n[:,2]<-0.9),(np.abs(z-9.2)<0.5)&(n[:,2]>0.9),(z>22.8)&(n[:,2]>0.9),(np.abs(z-11.5)<0.4)&(n[:,2]<-0.9)]
N=[]
for s in sels:
    q=v[s]; c=q.mean(0); u,sv,vt=np.linalg.svd(q-c); nn=vt[2]*np.sign(vt[2][2]); N.append(nn*len(q))
zax=np.sum(N,0); zax/=np.linalg.norm(zax); print('new z',zax)
# rotate so zax->z
def rot_to_z(a):
    k=np.cross(a,[0,0,1]); s=np.linalg.norm(k); c=a[2]
    if s<1e-12: return np.eye(3)
    k/=s; K=np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
    return np.eye(3)+s*K+(1-c)*K@K
R=rot_to_z(zax); T=np.eye(4); T[:3,:3]=R; m.apply_transform(T)
v,n=faces(m); z=v[:,2]; r=np.hypot(v[:,0],v[:,1])
# centre from bores (mean of 3 bore centres + bosses)
cs=[]
for (rlo,rhi,zlo,zhi,inw) in [(9.5,11.5,4,10.8,True),(7.4,9.2,12.5,19,True),(6.4,7.6,20.3,22.8,True),(11.3,12.8,9.8,14.2,False),(9.8,11.2,17,22.5,False)]:
    rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9)
    s=(r>rlo)&(r<rhi)&(z>zlo)&(z<zhi)&(np.abs(n[:,2])<0.3)&((rn<-0.5) if inw else (rn>0.5))
    cx,cy,Rr=circ(v[s,0],v[s,1]); cs.append((cx,cy)); print('feature ctr %.3f %.3f D %.3f'%(cx,cy,2*Rr))
c=np.mean(cs,0)
# z0 at plate bottom face
zb=np.median(v[(np.abs(z-3.35)<0.4)&(n[:,2]<-0.9),2])
T2=np.eye(4); T2[:3,3]=[-c[0],-c[1],-zb]; m.apply_transform(T2)
v,n=faces(m)
# x toward ear hole 1 (first quadrant)
from cfit import circ as C
def hole(cx,cy):
    for it in range(6):
        d=np.hypot(v[:,0]-cx,v[:,1]-cy); rn=(n[:,0]*(v[:,0]-cx)+n[:,1]*(v[:,1]-cy))/np.maximum(d,1e-9)
        s=(d>1.2)&(d<3.2)&(v[:,2]>0.3)&(v[:,2]<5.5)&(np.abs(n[:,2])<0.35)&(rn<-0.5); cx,cy,R=C(v[s,0],v[s,1])
    return cx,cy,R
h1=hole(17.6,7.3); h2=hole(-17.5,-7.0)
ang=np.arctan2(h1[1]-h2[1],h1[0]-h2[0]); Rz=trimesh.transformations.rotation_matrix(-ang,[0,0,1])
m.apply_transform(Rz)
Tall=Rz@T2@T
A=json.load(open('HS03_axis.json'))
# full chain from raw: axisframe T0 then Tall
R0=np.array(A['R']); p0=np.array(A['p0']); T0=np.eye(4); T0[:3,:3]=R0; T0[:3,3]=-R0@p0; T0[2,3]-=A['zshift']
Tfin=Tall@T0
json.dump(dict(T_raw_to_part=Tfin.tolist(),note='z = flange-plate normal toward boss end, origin = bore axis at plate bottom (EM02 mounting) face, +x toward ear hole'),open('HS03_T.json','w'),indent=1)
m.export(r'C:\NX_MCP_WORKSPACE\ulka\scan\EP5-HS03_aligned.stl')
print('done; hole1',h1,'hole2',h2)
