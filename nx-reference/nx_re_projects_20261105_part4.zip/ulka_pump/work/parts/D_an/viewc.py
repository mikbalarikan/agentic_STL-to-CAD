import sys, pickle, numpy as np, trimesh, pyvista as pv
pv.OFF_SCREEN=True
key=sys.argv[1]; idx=[int(a) for a in sys.argv[2].split(',')]; out=sys.argv[3]
T,parts=pickle.load(open(f'{key}_parts.pkl','rb'))
ms=[]
for i in idx:
    q=parts[i].copy(); q.apply_transform(T); ms.append(q)
m=trimesh.util.concatenate(ms)
f=np.hstack([np.full((len(m.faces),1),3),m.faces]).ravel()
pm=pv.PolyData(np.asarray(m.vertices),f)
pl=pv.Plotter(shape=(2,2),window_size=(1200,1200))
for k,(nm,d,up) in enumerate([('top +z',(0,0,1),(0,1,0)),('side -y',(0,-1,0),(0,0,1)),('side +x',(1,0,0),(0,0,1)),('iso',(1,-1,0.7),(0,0,1))]):
    pl.subplot(k//2,k%2); pl.add_mesh(pm,color='tan'); pl.add_text(nm,font_size=10); pl.show_grid()
    c=np.array(pm.center); L=max(m.extents)*2.8
    pl.camera_position=[tuple(c+L*np.array(d)/np.linalg.norm(d)),tuple(c),up]
pl.screenshot(out)
