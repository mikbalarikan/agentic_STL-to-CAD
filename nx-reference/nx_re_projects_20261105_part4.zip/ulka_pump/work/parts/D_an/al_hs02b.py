import numpy as np,trimesh,json
from cfit import circ
exec(open('al_hs03.py').read().split('def faces')[0].replace("m=trimesh.load('HS03_axisframe.stl',process=True)",""))
A=json.load(open('HS02_axis.json'))
m=trimesh.load(r"H:\My Drive\Mini Pumps\ulka re\EP5-HS02 Piston silindiri.stl",process=True)
R0=np.array(A['R']); p0=np.array(A['p0']); T0=np.eye(4); T0[:3,:3]=R0; T0[:3,3]=-R0@p0; T0[2,3]-=A['zshift']
m.apply_transform(T0); v=m.vertices; n=m.vertex_normals; z=v[:,2]
N=[]
for sel in [(z<0.6)&(n[:,2]<-0.9),(z>40.8)&(n[:,2]>0.9)]:
    q=v[sel]; cc=q.mean(0); u,sv,vt=np.linalg.svd(q-cc); nn=vt[2]*np.sign(vt[2][2]); N.append(nn*len(q))
za=np.sum(N,0); za/=np.linalg.norm(za)
k=np.cross(za,[0,0,1]); s=np.linalg.norm(k); k/=s; K=np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]]); R=np.eye(3)+s*K+(1-za[2])*K@K
T1=np.eye(4); T1[:3,:3]=R; m.apply_transform(T1)
v=m.vertices; n=m.vertex_normals; z=v[:,2]; r=np.hypot(v[:,0],v[:,1])
rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9)
s=(z>4)&(z<21)&(r>6)&(r<7.3)&(np.abs(n[:,2])<0.3)&(rn>0.5)
cx,cy,Rr=circ(v[s,0],v[s,1]); print('body OD ctr',cx,cy,2*Rr)
zf=np.median(v[(z<0.6)&(n[:,2]<-0.9),2])
T2=np.eye(4); T2[:3,3]=[-cx,-cy,-zf]; m.apply_transform(T2)
v=m.vertices; n=m.vertex_normals; z=v[:,2]; r=np.hypot(v[:,0],v[:,1])
# recess direction: points with r<6.4 at z 23-28 on outer (rn>0.5)
rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9)
s=(z>23)&(z<28)&(r<6.45)&(r>5.5)&(rn>0.5)
a=np.arctan2(v[s,1].mean(),v[s,0].mean()); print('recess dir deg',np.degrees(a),'n',s.sum())
Rz=trimesh.transformations.rotation_matrix(-a,[0,0,1]); m.apply_transform(Rz)
Tf=Rz@T2@T1@T0
json.dump(dict(T_raw_to_part=Tf.tolist(),note='z=pump axis, z0=flange end face (inlet side, HS05 side), +z toward outlet end; origin on body OD axis; +x toward the outer recess (z 22.5-28.6)'),open('HS02_T.json','w'),indent=1)
m.export(r'C:\NX_MCP_WORKSPACE\ulka\scan\EP5-HS02_aligned.stl')
