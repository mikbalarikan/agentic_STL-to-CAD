import sys,numpy as np,trimesh,pyvista as pv
pv.OFF_SCREEN=True
m=trimesh.load(sys.argv[1],process=False); out=sys.argv[2]
f=np.hstack([np.full((len(m.faces),1),3),m.faces]).ravel(); pm=pv.PolyData(np.asarray(m.vertices),f)
pl=pv.Plotter(shape=(2,3),window_size=(1800,1200))
V=[('+z top',(0,0,1),(0,1,0)),('-z bottom',(0,0,-1),(0,1,0)),('+x side',(1,0,0),(0,0,1)),('+y side',(0,1,0),(0,0,1)),('iso top',(1,-1,1),(0,0,1)),('iso bottom',(-1,1,-1),(0,0,1))]
for k,(nm,d,up) in enumerate(V):
    pl.subplot(k//3,k%3); pl.add_mesh(pm,color='wheat'); pl.add_text(nm,font_size=10); pl.show_grid(font_size=7)
    c=np.array(pm.center); L=max(m.extents)*2.6
    pl.camera_position=[tuple(c+L*np.array(d)/np.linalg.norm(d)),tuple(c),up]
pl.screenshot(out)
