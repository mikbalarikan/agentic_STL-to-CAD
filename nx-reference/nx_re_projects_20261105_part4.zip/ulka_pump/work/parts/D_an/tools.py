"""Shared measuring tools on an ALIGNED scan (part frame): plane levels, height maps, sections."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import cc


def load(code):
    return cc.Mesh(cc.read_stl(cc.SCAN + f"\\{cc.NAMES[code].split('_')[0]}_scan_aligned.stl"))


def levels(m, min_area=4.0, bin=0.04, cos=0.985, rlim=None, quiet=False):
    """Plane levels normal to Z: list of dicts (side, z, area, r range) sorted by z."""
    out = []
    r = np.hypot(m.c[:, 0], m.c[:, 1])
    for side, sel in (("up", m.n[:, 2] > cos), ("down", m.n[:, 2] < -cos)):
        if rlim is not None:
            sel = sel & (r >= rlim[0]) & (r <= rlim[1])
        z = m.c[sel, 2]
        a = m.a[sel]
        if not len(z):
            continue
        e = np.arange(z.min() - bin, z.max() + 2 * bin, bin)
        h, _ = np.histogram(z, bins=e, weights=a)
        # local maxima of the smoothed histogram
        hs = np.convolve(h, [0.25, 0.5, 0.25], mode="same")
        for i in range(1, len(hs) - 1):
            if hs[i] >= hs[i - 1] and hs[i] > hs[i + 1] and hs[i] * 2 > min_area * bin / 0.04 * 0.5:
                zc = e[i] + bin / 2
                mm = sel & (np.abs(m.c[:, 2] - zc) < 2.0 * bin)
                ar = m.a[mm].sum()
                if ar < min_area:
                    continue
                zz = np.average(m.c[mm, 2], weights=m.a[mm])
                sd = np.sqrt(np.average((m.c[mm, 2] - zz) ** 2, weights=m.a[mm]))
                out.append({"side": side, "z": float(zz), "area": float(ar), "sd": float(sd),
                            "r_lo": float(np.percentile(r[mm], 2)), "r_hi": float(np.percentile(r[mm], 98))})
    out.sort(key=lambda d: d["z"])
    if not quiet:
        for d in out:
            print(f"   {d['side']:4s} z {d['z']:8.3f}  area {d['area']:7.1f}  sd {d['sd']:.3f}  r {d['r_lo']:5.1f}..{d['r_hi']:5.1f}")
    return out


def plane_z(m, sel, k=2.5):
    """Mean z of a selected flat region (plane assumed normal to Z) with clipping + tilt of the free plane fit."""
    p = m.c[sel]
    w = m.a[sel]
    keep = np.ones(len(p), bool)
    for _ in range(4):
        z0 = np.average(p[keep, 2], weights=w[keep])
        sd = np.sqrt(np.average((p[keep, 2] - z0) ** 2, weights=w[keep]))
        k2 = np.abs(p[:, 2] - z0) < max(k * sd, 1e-6)
        if k2.sum() == keep.sum():
            break
        keep = k2
    n, d, rms, _ = cc.fit_plane(p[keep])
    tilt = float(np.degrees(np.arccos(min(1.0, abs(n[2])))))
    return {"z": float(z0), "sd": float(sd), "n": int(keep.sum()), "area": float(w[keep].sum()), "tilt_deg": tilt}


def height_maps(m, name, res=0.08, lim=None, zr_top=None, zr_bot=None, marks=None):
    """Top (max z) and bottom (min z) height maps of the aligned scan."""
    c = m.c
    if lim is None:
        lim = float(np.ceil(np.abs(c[:, :2]).max()))
    n = int(2 * lim / res) + 1
    ix = np.clip(((c[:, 0] + lim) / res).astype(int), 0, n - 1)
    iy = np.clip(((c[:, 1] + lim) / res).astype(int), 0, n - 1)
    top = np.full((n, n), -np.inf)
    bot = np.full((n, n), np.inf)
    np.maximum.at(top, (iy, ix), c[:, 2])
    np.minimum.at(bot, (iy, ix), c[:, 2])
    top[~np.isfinite(top)] = np.nan
    bot[~np.isfinite(bot)] = np.nan
    fig, axs = plt.subplots(1, 2, figsize=(26, 13))
    for a, img, ttl, zr in ((axs[0], top, "seen from +Z (max z)", zr_top), (axs[1], bot, "seen from -Z (min z), x NOT mirrored", zr_bot)):
        kw = {} if zr is None else {"vmin": zr[0], "vmax": zr[1]}
        im = a.imshow(img, origin="lower", extent=(-lim, lim, -lim, lim), cmap="turbo", **kw)
        a.set_title(f"{name}: {ttl}")
        a.set_xticks(np.arange(-lim, lim + 0.1, 2))
        a.set_yticks(np.arange(-lim, lim + 0.1, 2))
        a.grid(True, lw=0.25, color="k", alpha=0.35)
        fig.colorbar(im, ax=a, shrink=0.75)
        if marks:
            for (x, y, t) in marks:
                a.plot([x], [y], "k+", ms=10)
                a.annotate(t, (x, y), fontsize=9)
    fig.tight_layout()
    p = f"{cc.FIG}\\{name}_height.png"
    fig.savefig(p, dpi=80)
    plt.close(fig)
    return p, top, bot


def rz_figure(m, name, angles, xlim=None, ylim=None, centre=(0.0, 0.0), ncol=2, size=(13, 5), suffix="rz", dpi=85):
    nrow = int(np.ceil(len(angles) / ncol))
    fig, axs = plt.subplots(nrow, ncol, figsize=(size[0] * ncol, size[1] * nrow), squeeze=False)
    for a, ang in zip(axs.ravel(), angles):
        s = cc.rz_segments(m, ang, centre)
        cc.plot_segs(a, s)
        a.set_title(f"{name}: half section at {ang} deg (r, z)")
        if xlim:
            a.set_xlim(*xlim)
        if ylim:
            a.set_ylim(*ylim)
        a.set_xticks(np.arange(np.floor(a.get_xlim()[0]), a.get_xlim()[1] + 0.01, 1.0))
        a.set_yticks(np.arange(np.floor(a.get_ylim()[0]), a.get_ylim()[1] + 0.01, 1.0))
        a.grid(True, lw=0.3)
    fig.tight_layout()
    p = f"{cc.FIG}\\{name}_{suffix}.png"
    fig.savefig(p, dpi=dpi)
    plt.close(fig)
    return p


def z_figure(m, name, zs, lim=None, ncol=3, size=11, suffix="zsec", dpi=80, box=None):
    nrow = int(np.ceil(len(zs) / ncol))
    fig, axs = plt.subplots(nrow, ncol, figsize=(size * ncol, size * nrow), squeeze=False)
    for a, z0 in zip(axs.ravel(), zs):
        s = m.section(2, z0)
        cc.plot_segs(a, s[:, :, :2])
        a.set_title(f"{name}: section z = {z0}")
        if box is not None:
            a.set_xlim(box[0], box[1])
            a.set_ylim(box[2], box[3])
        elif lim:
            a.set_xlim(-lim, lim)
            a.set_ylim(-lim, lim)
        a.set_xticks(np.arange(np.floor(a.get_xlim()[0]), a.get_xlim()[1] + 0.01, 2.0))
        a.set_yticks(np.arange(np.floor(a.get_ylim()[0]), a.get_ylim()[1] + 0.01, 2.0))
        a.grid(True, lw=0.3)
    fig.tight_layout()
    p = f"{cc.FIG}\\{name}_{suffix}.png"
    fig.savefig(p, dpi=dpi)
    plt.close(fig)
    return p


def section_points(m, z0, box=None):
    """Mid points of the section segments at height z0 (N, 2) and their lengths."""
    s = m.section(2, z0, box)
    return s[:, :, :2].mean(axis=1), np.linalg.norm(s[:, 1, :2] - s[:, 0, :2], axis=1)


def section_pn(m, z0):
    """Section at height z0: mid points (N, 2), in-plane unit normals of the cut triangles (N, 2), segment lengths."""
    sel = (m.lo[:, 2] <= z0) & (m.hi[:, 2] >= z0)
    t = m.tri[sel]
    nn = m.n[sel]
    d = t[:, :, 2] - z0
    P, N, L = [], [], []
    for i, j, k in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
        s = (d[:, i] * d[:, j] < 0) & (d[:, i] * d[:, k] < 0)
        if not s.any():
            continue
        ti, di, dj, dk = t[s], d[s, i], d[s, j], d[s, k]
        p1 = ti[:, i] + (ti[:, j] - ti[:, i]) * (di / (di - dj))[:, None]
        p2 = ti[:, i] + (ti[:, k] - ti[:, i]) * (di / (di - dk))[:, None]
        P.append((p1 + p2)[:, :2] / 2)
        n2 = nn[s][:, :2]
        N.append(n2 / np.maximum(np.linalg.norm(n2, axis=1), 1e-9)[:, None])
        L.append(np.linalg.norm(p2 - p1, axis=1))
    if not P:
        return np.zeros((0, 2)), np.zeros((0, 2)), np.zeros(0)
    return np.concatenate(P), np.concatenate(N), np.concatenate(L)


def fit_line2(p, iters=4, k=2.5):
    """2D total least squares line with clipping: unit normal n, offset d (n.p = d), rms, mask."""
    p = np.asarray(p, float)
    m_ = np.ones(len(p), bool)
    for _ in range(iters):
        c = p[m_].mean(axis=0)
        _, _, vt = np.linalg.svd(p[m_] - c, full_matrices=False)
        n = vt[1]
        res = (p - c) @ n
        s = np.sqrt((res[m_] ** 2).mean())
        m2 = np.abs(res) < max(k * s, 1e-6)
        if m2.sum() == m_.sum():
            break
        m_ = m2
    return n, float(n @ c), float(s), m_


def circle_at(m, z_list, centre, r_lo, r_hi, sector=None, inward=None):
    """Fit a circle to section points pooled over several heights, within an annulus about `centre`.
    inward: True = keep hole walls (mesh normal towards the centre), False = boss walls, None = both."""
    pts = []
    for z0 in z_list:
        sel = (m.lo[:, 2] <= z0) & (m.hi[:, 2] >= z0)
        t = m.tri[sel]
        nn = m.n[sel]
        d = t[:, :, 2] - z0
        for i, j, k in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
            s = (d[:, i] * d[:, j] < 0) & (d[:, i] * d[:, k] < 0)
            if not s.any():
                continue
            ti, di, dj, dk = t[s], d[s, i], d[s, j], d[s, k]
            p1 = ti[:, i] + (ti[:, j] - ti[:, i]) * (di / (di - dj))[:, None]
            p2 = ti[:, i] + (ti[:, k] - ti[:, i]) * (di / (di - dk))[:, None]
            mid = (p1 + p2)[:, :2] / 2
            dv = mid - np.asarray(centre)
            rho = np.linalg.norm(dv, axis=1)
            ok = (rho >= r_lo) & (rho <= r_hi)
            if sector is not None:
                ang = np.degrees(np.arctan2(dv[:, 1], dv[:, 0]))
                ok &= np.abs((ang - sector[0] + 180) % 360 - 180) <= sector[1]
            if inward is not None:
                dot = (nn[s][:, 0] * dv[:, 0] + nn[s][:, 1] * dv[:, 1]) / np.maximum(rho, 1e-9)
                ok &= (dot < -0.5) if inward else (dot > 0.5)
            pts.append(mid[ok])
    pts = np.concatenate(pts) if pts else np.zeros((0, 2))
    if len(pts) < 12:
        return None
    cx, cy, r, rms, mask = cc.fit_circle(pts)
    dv = pts[mask] - np.array([cx, cy])
    ang = np.degrees(np.arctan2(dv[:, 1], dv[:, 0]))
    cover = len(np.unique(np.round(ang / 10.0))) * 10.0
    return {"x": cx, "y": cy, "r": r, "d": 2 * r, "rms": rms, "n": int(mask.sum()), "cover_deg": float(min(cover, 360.0))}
