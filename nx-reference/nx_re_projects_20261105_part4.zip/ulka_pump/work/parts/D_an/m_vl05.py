import pickle,numpy as np
from scipy.optimize import least_squares
T,parts=pickle.load(open('VL05_parts.pkl','rb'))
q=parts[0].copy(); q.apply_transform(T); p=q.vertices
# fit cylinder (ring outer) - axis roughly horizontal; search axis direction by minimizing radial spread of outer points
def res(a):
    th,ph,cx,cy,cz,R=a
    d=np.array([np.cos(th)*np.cos(ph),np.sin(th)*np.cos(ph),np.sin(ph)])
    w=p-np.array([cx,cy,cz]); rr=np.linalg.norm(w-np.outer(w@d,d),axis=1)
    return np.minimum(rr-R,0.0)*0.3+np.maximum(rr-R,0)  # penalize outside more (outer envelope)
c=p.mean(0)
best=None
for th0 in np.radians(np.arange(0,180,15)):
    s=least_squares(res,[th0,0,c[0],c[1],c[2],4.0],loss='soft_l1',f_scale=0.1)
    if best is None or s.cost<best.cost: best=s
th,ph,cx,cy,cz,R=best.x; d=np.array([np.cos(th)*np.cos(ph),np.sin(th)*np.cos(ph),np.sin(ph)])
w=p-np.array([cx,cy,cz]); ax=w@d; rr=np.linalg.norm(w-np.outer(ax,d),axis=1)
print('axis',np.round(d,3),'R env %.3f'%R)
print('radial pct 50/90/98/99.5',np.round(np.percentile(rr,[50,90,98,99.5]),3))
print('axial extent',np.round(np.percentile(ax,[0.5,2,98,99.5]),3))
for lo in np.arange(-3,3.5,0.5):
    s=(ax>lo)&(ax<lo+0.5)
    if s.sum()>30: print('  ax %.1f..%.1f rmax %.2f r50 %.2f n %d'%(lo,lo+0.5,np.percentile(rr[s],99),np.percentile(rr[s],50),s.sum()))
# angular map of outer lugs
u=np.cross(d,[0,0,1]); u/=np.linalg.norm(u); vv=np.cross(d,u)
ang=np.degrees(np.arctan2(w@vv,w@u))
for a in range(-180,180,15):
    s=(np.abs(((ang-a+180)%360)-180)<7.5)
    if s.sum()>10: print('  ang %4d rmax %.2f'%(a,np.percentile(rr[s],99)))
