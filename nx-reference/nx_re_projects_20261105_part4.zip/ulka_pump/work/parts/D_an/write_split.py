import pickle,numpy as np,trimesh,json
OUT=r'C:\NX_MCP_WORKSPACE\ulka\scan'
def place(meshes,T,cx,cy,z0=0.0):
    m=trimesh.util.concatenate([x.copy() for x in meshes]); m.apply_transform(T)
    S=np.eye(4); S[:3,3]=[-cx,-cy,-z0]; m.apply_transform(S); return m,S@T
info={}
def save(name,m,Tf,note):
    m.export(f'{OUT}\{name}.stl'); info[name]=dict(T_raw_to_part=np.round(Tf,6).tolist(),faces=len(m.faces),bbox=np.round(m.bounds,3).tolist(),note=note); print(name,len(m.faces),np.round(m.extents,2))
T,P=pickle.load(open('C1_parts.pkl','rb'))
m,Tf=place([P[0]],T,-6.435,6.471); save('EP5-HS05_aligned',m,Tf,'tek yuz taranmis (alt yuz altlikta, 0.25 mm alt kesildi); z0=altlik duzlemi, z ekseni = pul ekseni')
m,Tf=place([P[i] for i in [1,4,5,6,8,9,10,11,13,16,17,18,19]],T,7.857,-5.229); save('EP5-VL02_aligned',m,Tf,'yay dik duruyor, z0=altlik; tel parcali (tarama zayif)')
m,Tf=place([P[i] for i in [2,3,7,12,14,15]],T,13.3,12.0); save('EP5-VL03-VL04_aligned',m,Tf,'VL03 tapa (bas yukari, z>6.8) + VL04 yay (z<6.8) birlesik; z0=altlik')
# split VL03 head part
v=m.vertices; f=m.faces; keep=(v[f][:,:,2].min(1)>6.8)
h=m.submesh([np.where(keep)[0]],append=True,repair=False); save('EP5-VL03_head_aligned',h,Tf,'VL03 gorunen bas+boyun (z>6.8); govde yay icinde gorunmuyor')
k2=(v[f][:,:,2].max(1)<6.8); s=m.submesh([np.where(k2)[0]],append=True,repair=False); save('EP5-VL04_aligned',s,Tf,'VL04 yay (z<6.8), parcali')
T,P=pickle.load(open('C2_parts.pkl','rb'))
m,Tf=place([P[1]],T,-15.07,16.61); save('EP5-SL01_aligned',m,Tf,'O-ring yatik, z0=altlik; ust yari taranmis')
m,Tf=place([P[0]],T,-25.72,-12.94); save('EP5-SL02_aligned',m,Tf,'O-ring yatik, z0=altlik')
m,Tf=place([P[2]],T,24.27,4.41); save('EP5-SL03_aligned',m,Tf,'O-ring yatik, z0=altlik')
m,Tf=place([P[3]],T,5.52,-7.89)
bc=np.array([5.532,-7.277,2.023])-np.array([5.52,-7.89,0]); v=m.vertices; f=m.faces
inball=(np.linalg.norm(v[f]-bc,axis=2).max(1)<1.95)&(v[f][:,:,2].min(1)>2.0)
b=m.submesh([np.where(inball)[0]],append=True,repair=False); Sb=np.eye(4); Sb[:3,3]=-bc; b.apply_transform(Sb); save('EP5-VL01_aligned',b,Sb@Tf,'bilya ust kubbesi; merkez orijinde (D_fit=3.606)')
o=m.submesh([np.where(~inball)[0]],append=True,repair=False); save('EP5-SL04_aligned',o,Tf,'O-ring yatik, z0=altlik; ic kenari bilya ile temasli bolgede eksik')
T,P=pickle.load(open('VL05_parts.pkl','rb'))
m=P[0].copy(); m.apply_transform(T)
d=np.array([0.976,-0.217,0.021]); c=m.vertices.mean(0)
k=np.cross(d,[0,0,1]); sn=np.linalg.norm(k); k/=sn; K=np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]]); R=np.eye(3)+sn*K+(1-d[2])*K@K
T2=np.eye(4); T2[:3,:3]=R; T2[:3,3]=-R@c; m.apply_transform(T2); save('EP5-VL05_aligned',m,T2@T,'kafes, z = halka ekseni (PCA/zarf), orijin = nokta merkezi; tarama zayif')
json.dump(info,open('D_scan_index.json','w'),indent=1)
