import sys,pickle,numpy as np,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.optimize import least_squares
key=sys.argv[1]; idx=[int(a) for a in sys.argv[2].split(',')]; out=sys.argv[3]
T,parts=pickle.load(open(f'{key}_parts.pkl','rb'))
p=np.vstack([ (lambda q:(q.apply_transform(T),q.vertices)[1])(parts[i].copy()) for i in idx])
# axis: assume vertical; centre by circle fit to xy of points (robust)
x,y=p[:,0],p[:,1]
A=np.c_[2*x,2*y,np.ones_like(x)]; s=np.linalg.lstsq(A,x**2+y**2,rcond=None)[0]; cx,cy=s[0],s[1]
if len(sys.argv)>4: cx,cy=map(float,sys.argv[4].split(','))
r=np.hypot(x-cx,y-cy)
print('centre',round(cx,3),round(cy,3),'zmax',p[:,2].max().round(3))
fig,ax=plt.subplots(figsize=(9,7)); ax.scatter(r,p[:,2],s=0.2,alpha=0.3); ax.set_aspect('equal'); ax.grid(True)
ax.set_xticks(np.arange(0,np.ceil(r.max())+0.5,0.5)); ax.set_yticks(np.arange(0,np.ceil(p[:,2].max())+0.5,0.5)); ax.tick_params(labelsize=6)
plt.savefig(out,dpi=110)
np.save(out.replace('.png','.npy'),np.c_[r,p[:,2]])
