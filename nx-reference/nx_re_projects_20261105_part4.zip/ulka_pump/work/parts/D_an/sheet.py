import sys,glob,os
from PIL import Image
fs=sorted(glob.glob(sys.argv[1])); out=sys.argv[2]; n=int(sys.argv[3]) if len(sys.argv)>3 else 4
ims=[Image.open(f) for f in fs]; w=400
th=[im.resize((w,int(im.height*w/im.width))) for im in ims]
h=max(t.height for t in th); rows=(len(th)+n-1)//n
S=Image.new('RGB',(w*n,h*rows),'white')
for i,t in enumerate(th): S.paste(t,((i%n)*w,(i//n)*h))
S.save(out); print([os.path.basename(f) for f in fs])
