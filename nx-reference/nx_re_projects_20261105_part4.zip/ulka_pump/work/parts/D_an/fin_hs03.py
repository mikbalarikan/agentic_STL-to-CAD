import numpy as np,trimesh,json
from cfit import circ
m=trimesh.load(r'C:\NX_MCP_WORKSPACE\ulka\scan\EP5-HS03_aligned.stl',process=True); v=m.vertices; n=m.vertex_normals; z=v[:,2]; r=np.hypot(v[:,0],v[:,1])
R={}
def wall(nm,rlo,rhi,zlo,zhi,inw):
    rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9)
    s=(r>rlo)&(r<rhi)&(z>zlo)&(z<zhi)&(np.abs(n[:,2])<0.3)&((rn<-0.5) if inw else (rn>0.5))
    cx,cy,Rr=circ(v[s,0],v[s,1]); res=np.hypot(v[s,0]-cx,v[s,1]-cy)-Rr
    # taper: radius in lower/upper half
    zz=v[s,2]; h=np.median(zz); r1=np.median(np.hypot(v[s,0]-cx,v[s,1]-cy)[zz<h]); r2=np.median(np.hypot(v[s,0]-cx,v[s,1]-cy)[zz>=h])
    R[nm]=dict(D=round(2*Rr,3),sd=round(res.std(),3),ctr=[round(cx,3),round(cy,3)],D_low=round(2*r1,3),D_high=round(2*r2,3),z=[zlo,zhi],n=int(s.sum()))
    print(nm,R[nm])
wall('bore_lower',9.5,11.5,0.8,7.6,True)
wall('bore_mid',7.4,9.2,9.2,15.6,True)
wall('bore_top',6.4,7.6,16.9,19.5,True)
wall('boss_lower_OD',11.3,12.8,6.2,10.8,False)
wall('boss_upper_OD',9.8,11.2,13.6,19.2,False)
def lev(nm,z0,sgn,rlo=0,rhi=99):
    s=(np.abs(z-z0)<0.45)&(n[:,2]*sgn>0.9)&(r>rlo)&(r<rhi); R[nm]=dict(z=round(float(np.median(z[s])),3),sd=round(float(z[s].std()),3),n=int(s.sum())); print(nm,R[nm])
lev('plate_bottom',0,-1); lev('plate_top',5.8,1); lev('bore_step',8.15,-1); lev('top_end',19.9,1)
lev('pin_tips',-2.8,-1)
# boss chamfer between OD lower and upper: z where r crosses
for zz in np.arange(10,14.5,0.25):
    s=(np.abs(z-zz)<0.12)&(r>9.5)&(r<12.6)&(np.abs(n[:,2])<0.8)
    rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9); s&=rn>0.3
    if s.sum()>20: print('  outer r at z %.2f = %.3f'%(zz,np.median(r[s])))
for zz in np.arange(7.0,9.5,0.25):
    s=(np.abs(z-zz)<0.12)&(r>7.5)&(r<11)
    rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9); s&=rn<-0.3
    if s.sum()>20: print('  inner r at z %.2f = %.3f'%(zz,np.median(r[s])))
for zz in np.arange(15.5,17.5,0.25):
    s=(np.abs(z-zz)<0.12)&(r>6.5)&(r<9)
    rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9); s&=rn<-0.3
    if s.sum()>20: print('  inner r at z %.2f = %.3f'%(zz,np.median(r[s])))
json.dump(R,open('HS03_meas.json','w'),indent=1)
