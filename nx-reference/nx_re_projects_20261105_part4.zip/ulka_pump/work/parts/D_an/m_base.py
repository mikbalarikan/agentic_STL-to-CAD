import sys,os,pickle,numpy as np,trimesh,json
key=sys.argv[1]; T=np.array(json.load(open(f'{key}_plane.json'))['T'])
SRC=r"H:\My Drive\Mini Pumps\ulka re"
F={'C1':"EP5-HS05 Plastik pul + EP5-VL02 Bilya yayi + EP5-VL03 cikis valfi + EP5-VL04.stl",
   'C2':"EP5-SL04 Piston O-ringi + EP5-VL01 Piston cek valf + EP5-SL01O-ring + EP5-SL02O-ring + EP5-SL03O-ring.stl"}
m=trimesh.load(os.path.join(SRC,F[key]),process=False)
v=trimesh.transform_points(m.vertices,T)
for c,ro in [((float(a),float(b)),float(r)) for a,b,r in [s.split(':') for s in sys.argv[2:]]]:
    rr=np.hypot(v[:,0]-c[0],v[:,1]-c[1])
    for lo,hi in [(ro+0.5,ro+2),(ro+2,ro+5)]:
        s=v[(rr>lo)&(rr<hi)&(np.abs(v[:,2])<0.6)]
        print(c,'ann',lo,hi,'base z med %.3f p10 %.3f p90 %.3f n %d'%(np.median(s[:,2]),*np.percentile(s[:,2],[10,90]),len(s)))
    s=v[(rr<ro-2.5)&(np.abs(v[:,2])<0.6)]
    if len(s): print('   inside base z med %.3f n %d'%(np.median(s[:,2]),len(s)))
