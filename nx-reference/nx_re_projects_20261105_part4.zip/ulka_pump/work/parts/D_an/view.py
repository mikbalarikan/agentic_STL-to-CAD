import sys, os, numpy as np, trimesh, pyvista as pv
pv.OFF_SCREEN=True
src=sys.argv[1]; out=sys.argv[2]
m=trimesh.load(src,process=False)
if len(m.faces)>300000:
    pass
f=np.hstack([np.full((len(m.faces),1),3),m.faces]).ravel()
pm=pv.PolyData(np.asarray(m.vertices),f)
pl=pv.Plotter(shape=(2,2),window_size=(1400,1400))
views=[('xy',(0,0,1)),('xz',(0,-1,0)),('yz',(1,0,0)),('iso',(1,1,1))]
for i,(n,d) in enumerate(views):
    pl.subplot(i//2,i%2)
    pl.add_mesh(pm,color='tan',smooth_shading=False)
    pl.add_text(n,font_size=10)
    pl.show_axes()
    c=pm.center; L=max(m.extents)*2.5
    pl.camera_position=[tuple(np.array(c)+L*np.array(d)/np.linalg.norm(d)),c,(0,0,1) if n!='xy' else (0,1,0)]
pl.screenshot(out)
