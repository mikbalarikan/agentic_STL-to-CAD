import numpy as np,trimesh,json
from cfit import circ
m=trimesh.load('HS03_axisframe.stl',process=True); v=m.vertices; n=m.vertex_normals
r=np.hypot(v[:,0],v[:,1]); z=v[:,2]
def wallfit(rlo,rhi,zlo,zhi,inward=None):
    s=(r>rlo)&(r<rhi)&(z>zlo)&(z<zhi)&(np.abs(n[:,2])<0.3)
    rn=(n[:,0]*v[:,0]+n[:,1]*v[:,1])/np.maximum(r,1e-9)
    if inward is True: s&=rn<-0.5
    if inward is False: s&=rn>0.5
    if s.sum()<30: return None
    cx,cy,R=circ(v[s,0],v[s,1]); res=np.hypot(v[s,0]-cx,v[s,1]-cy)-R
    return 2*R,res.std(),cx,cy,s.sum()
print('--- bores (inward normals)')
for nm,a in [('bore lower Ø21',(9.5,11.5,4,10.8)),('bore mid Ø16',(7.4,9.2,12.5,19)),('bore top Ø14',(6.4,7.6,20.3,22.8))]:
    print(nm, wallfit(*a,inward=True))
print('--- outer')
for nm,a in [('boss lower',(11.3,12.8,9.8,14.2)),('boss upper',(9.8,11.2,17,22.5))]:
    print(nm, wallfit(*a,inward=False))
# levels: faces with |nz|>0.95 histogram of z
fn=m.face_normals; c=m.triangles_center; A=m.area_faces; rc=np.hypot(c[:,0],c[:,1])
for sgn in [1,-1]:
    s=fn[:,2]*sgn>0.95
    h,e=np.histogram(c[s,2],bins=np.arange(-0.5,24.5,0.1),weights=A[s])
    idx=np.argsort(h)[::-1][:10]
    print('planar faces facing',sgn,[(round(e[i]+0.05,2),round(h[i],1)) for i in sorted(idx)])
json.dump({},open('/dev/null','w')) if False else None
