import numpy as np,trimesh,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
m=trimesh.load('HS03_axisframe.stl',process=True); v=m.vertices; n=m.vertex_normals; z=v[:,2]
fig,ax=plt.subplots(1,2,figsize=(20,10))
for a,(sel,t) in zip(ax,[((z>8.6)&(z<9.8)&(n[:,2]>0.8),'top face z~9.2'),((z<3.8),'bottom face + pins z<3.8')]):
    a.scatter(v[sel,0],v[sel,1],s=0.1,c=z[sel],cmap='jet'); a.set_aspect('equal'); a.grid(True); a.set_title(t)
    a.set_xticks(np.arange(-23,24,1)); a.set_yticks(np.arange(-13,14,1)); a.tick_params(labelsize=6)
plt.tight_layout(); plt.savefig('fig/HS03_faces.png',dpi=70)
