import sys, os, json, numpy as np, trimesh
from scipy.sparse.csgraph import connected_components
SRC=r"H:\My Drive\Mini Pumps\ulka re"
F={'C1':"EP5-HS05 Plastik pul + EP5-VL02 Bilya yayi + EP5-VL03 cikis valfi + EP5-VL04.stl",
   'C2':"EP5-SL04 Piston O-ringi + EP5-VL01 Piston cek valf + EP5-SL01O-ring + EP5-SL02O-ring + EP5-SL03O-ring.stl",
   'VL05':"EP5-VL05 Valf kafesi.stl"}
key=sys.argv[1]; tol=float(sys.argv[2]) if len(sys.argv)>2 else 0.25
m=trimesh.load(os.path.join(SRC,F[key]),process=True)
v=m.vertices; rng=np.random.default_rng(0)
best=None
for it in range(400):
    i=rng.choice(len(v),3,replace=False); p=v[i]
    n=np.cross(p[1]-p[0],p[2]-p[0]); nn=np.linalg.norm(n)
    if nn<1e-9: continue
    n/=nn; d=np.abs((v-p[0])@n); c=(d<0.3).sum()
    if best is None or c>best[0]: best=(c,n,p[0])
c,n,p0=best
# refine with LSQ
for k in range(3):
    s=(v-p0)@n; inl=np.abs(s)<0.3
    q=v[inl]; cen=q.mean(0); u,sv,vt=np.linalg.svd(q-cen,full_matrices=False); n=vt[2]; p0=cen
s=(v-p0)@n
if np.median(s[np.abs(s)>1])<0: n=-n; s=-s
inl=np.abs(s)<0.3
print('plane inliers',inl.sum(),'of',len(v),'rms %.3f'%np.sqrt((s[inl]**2).mean()),'normal',np.round(n,4))
# faces kept: all verts above tol
keepf=(s[m.faces]>tol).all(1)
sub=m.submesh([np.where(keepf)[0]],append=True,repair=False)
parts=sub.split(only_watertight=False,repair=False)
parts=sorted(parts,key=lambda p:-len(p.faces))
# frame: z=plane normal, origin plane
z=n; x=np.cross([0,1,0],z); x/=np.linalg.norm(x); y=np.cross(z,x)
T=np.eye(4); T[:3,:3]=np.vstack([x,y,z]); T[:3,3]=-T[:3,:3]@p0
out=[]
for i,p in enumerate(parts):
    if len(p.faces)<150: continue
    q=p.copy(); q.apply_transform(T)
    b=q.bounds
    out.append(dict(i=i,nf=len(p.faces),ctr=np.round(b.mean(0)[:2],2).tolist(),ext=np.round(q.extents,2).tolist(),zmax=round(b[1,2],2)))
    print(out[-1])
json.dump(dict(T=T.tolist()),open(f'{key}_plane.json','w'))
import pickle; pickle.dump((T,[p for p in parts if len(p.faces)>=150]),open(f'{key}_parts.pkl','wb'))
