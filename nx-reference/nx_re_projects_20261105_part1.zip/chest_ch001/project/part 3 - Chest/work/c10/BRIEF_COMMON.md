# Common brief for the outC10 measurement agents (G1, G2, G3)

Job: CH-001 robot chest shell, reverse-engineered from a 3D scan into a native NX solid. Folder
`C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest` (ROOT). The current build (nx/outC8) has review findings
(ROOT/review_2026-10-30/REVIEW.md, section 3 table) that must be fixed in the next build. YOUR job: MEASURE the scan
for your findings and write a feature spec JSON that the lead's NX build consumes. You do NOT run NX and do NOT edit
anything outside ROOT/work/c10/ (no edits in nx/, an/, deliver/, review_2026-10-30/, STATUS.md, HANDOFF.md, memory).

Read first: ROOT/work/c10/SCHEMA.md (the output format, build order and rules) and your rows in REVIEW.md
(+ the crops / secs they name, in ROOT/review_2026-10-30/crops and /secs). CLUSTERS.md there lists the clusters (k-numbers).

Data (all in the part frame, see SCHEMA.md for axes):
- Scan mesh: `np.load(ROOT/work/mainf.npz)` -> v (7.4 M x 3 float32), f (14.7 M x 3). ROOT/an/common.py has `load()`
  and `section(v, f, axis, value)` (plane section segments). ROOT/an/sec.py = section plots; ROOT/review_2026-10-30/r9_secfill.py
  = filled CAD sections with the scan outline (env RV_CAD=<cad stl>; see its header). Loading the scan takes ~20-40 s:
  crop to your region early (vertex mask + faces whose 3 vertices are in it) and save a small npz in your work folder.
- Height maps `work/hmap.npz` (x0, y0, step 0.25; `top` = z of the surface seen from +Z = interior, `bot` = seen from -Z =
  exterior; row i -> y = y0 + i*step, col j -> x = x0 + j*step). `work/tmap.npz` t = interior wall thickness.
- Current CAD: ROOT/nx/outC8/chest_G.stl (NX STL of the outC8 build, binary). Review copy and data: review_2026-10-30/cad_C8,
  data_C8 (clusters.json, census.json, maps.npz).
- Existing build inputs (read only, so you can name what to remove): work/through.json (Z-through openings; kind R =
  built on x>0 and mirrored, C/A = as given), work/holes.json (boss holes: kind R mirrored, A one-sided; 'Lmirror' rows
  are documentation of the mirror of an R row), work/plateaus.json (flat-topped plateau loops, key h = top z, kind R/C/A,
  segs = line/arc segments), work/pads.json (stepped interior pads: symmetric, right half, from the thickness map).
  nx/build.py shows how these are built (read only).
Python: `C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe` (numpy, scipy, trimesh, matplotlib, shapely). Write every
script as a FILE in your folder ROOT/work/c10/<group>/ and run it with that python. NEVER run `python -` (stdin
scripts hang this machine). Bash and PowerShell are both available; the project path has spaces - quote it.

Method per feature: cut sections of the scan through it (2-3 planes), read positions/diameters/heights; fit circles
(least squares) for bosses/tubes; for a plan outline take a z-section of the scan just below the feature top, or the
height map. Make 1 evidence PNG per finding (scan section lines + your proposed feature outline overlaid) in your folder.
Also check your feature does not collide with what is already there in a way that makes a sliver (see SCHEMA rules).

Deliverables: ROOT/work/c10/<group>.json (valid JSON, per SCHEMA.md) and ROOT/work/c10/<group>/NOTES.md (per finding:
what the scan shows, the numbers, the evidence PNG, anything you could not resolve). Write the JSON EARLY with the
features done so far and update it as you go (a stalled run must still leave usable output).
Final reply (it goes to the lead, keep it under 250 words): which findings are covered, feature count, anything left open.
