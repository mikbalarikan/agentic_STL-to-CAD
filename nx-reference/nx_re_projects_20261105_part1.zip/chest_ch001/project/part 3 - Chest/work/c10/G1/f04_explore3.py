import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("A_shoulder_up"); cv, cf = cad()
jobs = [(1, 94.0, (70, 105, -50, 5)), (1, 91.5, (70, 105, -50, 5)), (1, 88.0, (70, 105, -50, 5)), (0, 79.0, (75, 105, -50, 5)), (0, 86.5, (75, 105, -50, 5)), (0, 94.0, (75, 105, -50, 5))]
fig, axs = plt.subplots(2, len(jobs), figsize=(4.5 * len(jobs), 9))
for i, sgn in enumerate((1, -1)):
    for j, (axis, val, lim) in enumerate(jobs):
        ax = axs[i, j]
        vv = val * sgn if axis == 0 else val
        s = sec2(v, f, axis, vv); c = sec2(cv, cf, axis, vv)
        if axis == 1:
            s[:, :, 0] *= sgn; c[:, :, 0] *= sgn
        draw(ax, c, "#777777", 0.8); draw(ax, s, "#e08a00", 1.2)
        setup(ax, lim, f"{'RL'[i]} {'xyz'[axis]}={vv}")
fig.tight_layout(); fig.savefig("f04_explore3.png", dpi=60)
