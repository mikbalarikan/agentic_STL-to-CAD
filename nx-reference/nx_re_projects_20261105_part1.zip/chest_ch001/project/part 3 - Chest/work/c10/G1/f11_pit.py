import numpy as np
from g1lib import *
v, f = crop("D_y12")
for name, c0 in (("b1", (-65.79, 12.17)), ("b2", (17.22, 12.0))):
    r = np.hypot(v[:, 0] - c0[0], v[:, 1] - c0[1])
    for rr in (0.3, 0.6, 1.0, 1.3, 1.6):
        m = (r < rr) & (v[:, 2] > -125)
        print(name, rr, m.sum(), "z max/min", np.round(v[m, 2].max(), 2) if m.sum() else None, np.round(v[m, 2].min(), 2) if m.sum() else None)
    m = (r < 2.2) & (v[:, 2] > -116)
    z = v[m, 2]; rr = r[m]
    for b in np.arange(0, 2.2, 0.2):
        k = (rr >= b) & (rr < b + 0.2)
        print(f"   r {b:.1f}-{b+0.2:.1f}: n {k.sum():4d} zmed {np.median(z[k]) if k.sum() else np.nan:.2f} zmin {z[k].min() if k.sum() else np.nan:.2f}")
