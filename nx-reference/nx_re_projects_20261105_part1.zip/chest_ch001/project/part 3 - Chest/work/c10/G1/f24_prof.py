import numpy as np, os
from g1lib import *
H = np.load(os.path.join(ROOT, "work", "hmap.npz")); top = H["top"]; x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
xs = np.arange(50, 92, 0.25)
for sgn in (1, -1):
    print("side", "RL"[sgn < 0])
    for y in (36.75, 37.5, 38.5, 39.5, 40.5, 41.5):
        i = int(round((y - y0) / st))
        z = np.array([top[i, int(round((sgn * x - x0) / st))] for x in xs])
        # detrend with a linear fit over x 56..88 and find steps: dz over 0.75 mm > 0.25
        dz = z[3:] - z[:-3]
        edges = []
        k = 0
        while k < len(dz):
            if dz[k] > 0.3:
                j = k
                while j < len(dz) and dz[j] > 0.15:
                    j += 1
                edges.append(round(float(xs[k + 1] + 0.25 * (j - k) / 2), 2)); k = j + 2
            else:
                k += 1
        print(f"  y {y}: z(52)={z[8]:.2f} z(70)={z[80]:.2f} z(88)={z[152]:.2f}  steps at x:", edges)
