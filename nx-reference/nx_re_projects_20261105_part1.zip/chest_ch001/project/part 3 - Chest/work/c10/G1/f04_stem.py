import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("A_shoulder_up")
fig, axs = plt.subplots(2, 3, figsize=(27, 12))
for i, sgn in enumerate((1, -1)):
    for j, y in enumerate((92.0, 94.0, 96.0)):
        ax = axs[i, j]
        s = sec2(v, f, 1, y); s[:, :, 0] *= sgn
        draw(ax, s, "#e08a00", 1.4)
        setup(ax, (72, 100, -22, 3), f"{'RL'[i]} y={y}")
        ax.xaxis.set_major_locator(plt.MultipleLocator(1)); ax.yaxis.set_major_locator(plt.MultipleLocator(1))
fig.tight_layout(); fig.savefig("f04_stem.png", dpi=50)
