import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("A_shoulder_up"); cv, cf = cad()
jobs = [(1, 72.0, (118, 160, -50, 4)), (1, 80.0, (118, 160, -50, 4)), (0, 132.0, (55, 97, -50, 4))]
fig, axs = plt.subplots(1, len(jobs), figsize=(10 * len(jobs), 12))
for j, (axis, val, lim) in enumerate(jobs):
    ax = axs[j]
    s = sec2(v, f, axis, val); c = sec2(cv, cf, axis, val)
    draw(ax, c, "#333333", 1.0); draw(ax, s, "#e08a00", 1.5)
    setup(ax, lim, f"R {'xyz'[axis]}={val}")
    ax.xaxis.set_major_locator(plt.MultipleLocator(2)); ax.yaxis.set_major_locator(plt.MultipleLocator(2))
fig.tight_layout(); fig.savefig("f22_sec2.png", dpi=45)
