"""Extra crops: E shoulder flange ring (|x| > 140), F shoulder top corners already in A."""
import os
import numpy as np
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest"
OUT = os.path.join(ROOT, "work", "c10", "G1")
d = np.load(os.path.join(ROOT, "work", "mainf.npz"))
v = d["v"]; f = d["f"]
m = (np.abs(v[:, 0]) > 140) & (np.abs(v[:, 1]) < 72) & (v[:, 2] < 3)
fm = m[f[:, 0]] & m[f[:, 1]] & m[f[:, 2]]
ff = f[fm]
u, inv = np.unique(ff.ravel(), return_inverse=True)
np.savez_compressed(os.path.join(OUT, "crop_E_flange.npz"), v=v[u], f=inv.reshape(-1, 3).astype(np.int32))
print(len(u), len(ff))
