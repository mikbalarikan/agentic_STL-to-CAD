import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("D_y12")
H = np.load(os.path.join(ROOT, "work", "hmap.npz")); top = H["top"]; x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
def T(x, y):
    return top[int(round((y - y0) / st)), int(round((x - x0) / st))]
for name, c0 in (("b1", (-65.7, 12.2)), ("b2", (17.1, 12.1))):
    print("==", name)
    for z in (-114.8, -115.5, -116.5, -117.5):
        s = sec2(v, f, 2, z); p = s.reshape(-1, 2); d = np.hypot(*(p - c0).T)
        q = p[(d > 2.0) & (d < 3.6)]
        if len(q) > 20:
            c, r, sd, n = fit_circle_robust(q)
            print(f"  z {z}: outer c ({c[0]:.2f},{c[1]:.2f}) d {2*r:.2f} sd {sd:.3f} n {n}")
        qb = p[d < 1.8]
        if len(qb) > 15:
            c, r, sd, n = fit_circle_robust(qb)
            print(f"        bore c ({c[0]:.2f},{c[1]:.2f}) d {2*r:.2f} sd {sd:.3f} n {n}")
    # top
    vals = [T(c0[0] + 2.0 * np.cos(a), c0[1] + 2.0 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 16, endpoint=False)]
    print("  top ring r2:", np.round(np.median(vals), 2), np.round(np.min(vals), 2), np.round(np.max(vals), 2))
    # polar profile of top at r = 3.2..6 (gussets)
    for rr in (3.2, 3.6, 4.0, 4.5, 5.0, 5.5, 6.0, 7.0):
        a = np.arange(0, 360, 7.5)
        vals = np.array([T(c0[0] + rr * np.cos(np.radians(t)), c0[1] + rr * np.sin(np.radians(t))) for t in a])
        print(f"  r {rr}: " + " ".join(f"{x:6.1f}" for x in vals))
