"""Crop the scan (work/mainf.npz) to the G1 regions, save small npz files in work/c10/G1/."""
import os
import numpy as np
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest"
OUT = os.path.join(ROOT, "work", "c10", "G1")
d = np.load(os.path.join(ROOT, "work", "mainf.npz"))
v = d["v"]; f = d["f"]
ax = np.abs(v[:, 0])
R = {
    "A_shoulder_up": (ax > 60) & (ax < 175) & (v[:, 1] > 25) & (v[:, 1] < 108) & (v[:, 2] > -65) & (v[:, 2] < 6),
    "B_shoulder_lo": (ax > 120) & (ax < 175) & (v[:, 1] > -90) & (v[:, 1] < -30) & (v[:, 2] > -55) & (v[:, 2] < 6),
    "C_neck": (ax > 30) & (ax < 92) & (v[:, 1] > 15) & (v[:, 1] < 78) & (v[:, 2] > -125) & (v[:, 2] < -40),
    "D_y12": (v[:, 0] > -85) & (v[:, 0] < 35) & (v[:, 1] > -8) & (v[:, 1] < 32) & (v[:, 2] > -140) & (v[:, 2] < -85),
}
for name, m in R.items():
    fm = m[f[:, 0]] & m[f[:, 1]] & m[f[:, 2]]
    ff = f[fm]
    u, inv = np.unique(ff.ravel(), return_inverse=True)
    np.savez_compressed(os.path.join(OUT, f"crop_{name}.npz"), v=v[u], f=inv.reshape(-1, 3).astype(np.int32))
    print(name, len(u), len(ff))
