import numpy as np, matplotlib.pyplot as plt, json, os, sys
from g1lib import *
sys.argv = ["x"]
from query import PD, poly
M = np.load(os.path.join(ROOT, "review_2026-10-30", "data", "maps.npz"))
xs, ys = M["xs"], M["ys"]
dZ = M["cad_ZI"] - M["scan_ZI"]                 # >0: CAD interior surface higher (+z) = CAD too thick
dXR = M["scan_XR"] - M["cad_XR"]                # XR: ray +x from mid-plane, hit x; CAD hit smaller x = CAD too thick (on x walls)
Tm = np.load(os.path.join(ROOT, "work", "tmap.npz"))
fig, axs = plt.subplots(2, 2, figsize=(20, 16))
win = (95, 166, 45, 105)
jx = (xs > win[0]) & (xs < win[1]); iy = (ys > win[2]) & (ys < win[3])
for k, (sgn, name) in enumerate(((1, "R"), (-1, "L"))):
    ax = axs[k, 0]
    if sgn > 0:
        D = dZ[np.ix_(iy, jx)]; ext = (xs[jx][0], xs[jx][-1], ys[iy][0], ys[iy][-1])
    else:
        jx2 = (xs < -win[0]) & (xs > -win[1]); D = dZ[np.ix_(iy, jx2)][:, ::-1]; ext = (-xs[jx2][-1], -xs[jx2][0], ys[iy][0], ys[iy][-1])
    im = ax.imshow(np.clip(D, -3, 3), origin="lower", extent=ext, cmap="RdBu_r"); plt.colorbar(im, ax=ax)
    for L in PD["loops"]:
        p = poly(L["segs"]).p
        if p[:, 0].max() > win[0] and p[:, 1].max() > win[2] and p[:, 1].min() < win[3]:
            ax.plot(np.r_[p[:, 0], p[0, 0]], np.r_[p[:, 1], p[0, 1]], "k", lw=0.4)
    ax.set_title(f"{name}: cad_ZI - scan_ZI (red = CAD too thick), pads black"); ax.set_xlim(win[0], win[1]); ax.set_ylim(win[2], win[3]); ax.grid(lw=0.3)
    ax = axs[k, 1]
    t = Tm["t"]; x0g, y0g, st = float(Tm["x0"]), float(Tm["y0"]), float(Tm["step"])
    j0 = int((sgn * win[0] - x0g) / st) if sgn > 0 else int((-win[1] - x0g) / st); j1 = j0 + int((win[1] - win[0]) / st)
    i0 = int((win[2] - y0g) / st); i1 = int((win[3] - y0g) / st)
    TT = t[i0:i1, j0:j1]
    if sgn < 0: TT = TT[:, ::-1]
    im = ax.imshow(np.clip(TT, 0, 8), origin="lower", extent=(win[0], win[1], win[2], win[3]), cmap="viridis"); plt.colorbar(im, ax=ax)
    ax.set_title(f"{name} tmap t (scan wall thickness, z)"); ax.grid(lw=0.3)
    # stats in the F22 box
    box = (135, 160, 72, 92)
    jj = (np.abs(xs) > box[0]) & (np.abs(xs) < box[1]) & (np.sign(xs) == sgn); ii = (ys > box[2]) & (ys < box[3])
    Db = dZ[np.ix_(ii, jj)]; Db = Db[np.isfinite(Db)]
    print(name, "F22 box dZ: n", Db.size, "mean", np.round(Db.mean(), 2), "p50", np.round(np.median(Db), 2), "p90", np.round(np.percentile(Db, 90), 2), "frac>0.5", np.round((Db > 0.5).mean(), 2))
fig.tight_layout(); fig.savefig("f22_maps.png", dpi=50)
