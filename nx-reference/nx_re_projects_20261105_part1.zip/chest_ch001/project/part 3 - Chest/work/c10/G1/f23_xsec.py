import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("C_neck"); cv, cf = cad()
xsv = [44.0, 46.0, 48.0, 50.0, 52.0, 54.0]
fig, axs = plt.subplots(2, len(xsv), figsize=(7 * len(xsv), 14))
for i, sgn in enumerate((1, -1)):
    for j, x in enumerate(xsv):
        ax = axs[i, j]
        s = sec2(v, f, 0, sgn * x); c = sec2(cv, cf, 0, sgn * x)
        draw(ax, c, "#333333", 1.0); draw(ax, s, "#e08a00", 1.6)
        setup(ax, (50, 78, -92, -60), f"{'RL'[i]} x={sgn*x} (y right, z up)")
        ax.xaxis.set_major_locator(plt.MultipleLocator(2)); ax.yaxis.set_major_locator(plt.MultipleLocator(2))
fig.tight_layout(); fig.savefig("f23_xsec.png", dpi=40)
