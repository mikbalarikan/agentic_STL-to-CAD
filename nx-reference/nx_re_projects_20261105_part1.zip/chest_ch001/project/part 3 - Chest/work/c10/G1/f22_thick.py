"""Normal wall thickness in the shoulder-top corner: for interior-facing vertices (normal toward a point in the
cavity) the distance to the nearest exterior-facing vertex. Scan and outC8 CAD, R and L (L mirrored), 2 mm bins."""
import numpy as np, matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from g1lib import *
C = np.array([60.0, 30.0, -10.0])
WIN = (100, 162, 48, 104)


def vnorm(v, f):
    a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
    n = np.cross(b - a, c - a); vn = np.zeros_like(v)
    for k in range(3):
        np.add.at(vn, f[:, k], n)
    return vn / np.maximum(np.linalg.norm(vn, axis=1), 1e-12)[:, None]


def thick(v, f, sgn, cad=False):
    v = v.copy(); v[:, 0] *= sgn
    m = (v[:, 0] > WIN[0] - 8) & (v[:, 0] < WIN[1] + 8) & (v[:, 1] > WIN[2] - 8) & (v[:, 1] < WIN[3] + 8) & (v[:, 2] > -62) & (v[:, 2] < -0.3)
    fm = m[f[:, 0]] & m[f[:, 1]] & m[f[:, 2]]
    ff = f[fm]; u, inv = np.unique(ff.ravel(), return_inverse=True)
    vv = v[u]; fff = inv.reshape(-1, 3)
    if sgn < 0:
        fff = fff[:, ::-1]
    vn = vnorm(vv, fff)
    toc = C - vv; toc /= np.linalg.norm(toc, axis=1)[:, None]
    d = (vn * toc).sum(1)
    if cad:  # CAD STL from NX: outward normals; flip sign convention check below
        pass
    inn = d > 0.3; ext = d < -0.3
    # orientation sanity: scan normals may be inward; pick the convention where the exterior set lies farther from C
    if np.linalg.norm(vv[inn] - C, axis=1).mean() > np.linalg.norm(vv[ext] - C, axis=1).mean():
        inn, ext = ext, inn
    tr = cKDTree(vv[ext])
    dist, _ = tr.query(vv[inn])
    return vv[inn], dist


S = crop("A_shoulder_up"); Cd = cad()
fig, axs = plt.subplots(2, 3, figsize=(27, 16))
res = {}
for i, sgn in enumerate((1, -1)):
    out = []
    for j, (name, (v, f)) in enumerate((("scan", S), ("cad", Cd))):
        p, t = thick(v, f, sgn, cad=(name == "cad"))
        xb = np.arange(WIN[0], WIN[1] + 2, 2.0); yb = np.arange(WIN[2], WIN[3] + 2, 2.0)
        H, _, _ = np.histogram2d(p[:, 0], p[:, 1], bins=[xb, yb], weights=t); N, _, _ = np.histogram2d(p[:, 0], p[:, 1], bins=[xb, yb])
        M = np.where(N > 3, H / np.maximum(N, 1), np.nan).T
        out.append(M)
        ax = axs[i, j]
        im = ax.imshow(np.clip(M, 0, 9), origin="lower", extent=(WIN[0], WIN[1], WIN[2], WIN[3]), cmap="viridis")
        plt.colorbar(im, ax=ax); ax.set_title(f"{'RL'[i]} {name}: mean normal wall thickness (2 mm bins)"); ax.grid(lw=0.3)
    ax = axs[i, 2]
    im = ax.imshow(np.clip(out[1] - out[0], -3, 3), origin="lower", extent=(WIN[0], WIN[1], WIN[2], WIN[3]), cmap="RdBu_r")
    plt.colorbar(im, ax=ax); ax.set_title(f"{'RL'[i]} CAD - scan thickness"); ax.grid(lw=0.3)
    res["RL"[i]] = out
np.savez("f22_thick.npz", R_scan=res["R"][0], R_cad=res["R"][1], L_scan=res["L"][0], L_cad=res["L"][1])
fig.tight_layout(); fig.savefig("f22_thick.png", dpi=45)
xb = np.arange(WIN[0], WIN[1] + 2, 2.0) + 1; yb = np.arange(WIN[2], WIN[3] + 2, 2.0) + 1
for side in "RL":
    s, c = res[side]
    print(side, "scan thickness rows y (top->down), cols x", xb[:-1][::2])
    for r in range(s.shape[0] - 1, -1, -2):
        print(f"  y {yb[r]:5.0f}: " + " ".join(f"{s[r, k]:4.1f}/{c[r, k]:4.1f}" if np.isfinite(s[r, k]) and np.isfinite(c[r, k]) else "   .     " for k in range(0, s.shape[1], 2)))
