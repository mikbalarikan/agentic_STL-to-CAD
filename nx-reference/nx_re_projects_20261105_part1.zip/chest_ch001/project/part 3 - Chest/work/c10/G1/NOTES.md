# G1 measurement notes (CH-001, outC10) — F04 F14 F11 F22 F23 F24 F26

Output: `work/c10/G1.json` (31 features, 3 remove_holes, 4 remove_plateaus, 5 pad_zones), written by
`make_g1.py` + `make_g1_extra.py`. Evidence PNGs in this folder: `F04_bosses.png`, `F14_tubes.png`, `F11_bosses.png`,
`F22_corner.png`, `F23_receiver.png`, `F24_channel.png`, `F26_flange.png` (scan orange, outC8 CAD grey, G1 unite blue,
subtract red dashed, pad zones green dashed). Scan crops `crop_*.npz`, CAD cache `cad_C8.npz`.

## Important for the build: the bosses and tubes are drafted cones

All vertical bosses / tubes measured here carry a ~3 deg moulding draft (diameter grows 0.10-0.11 mm per mm of
depth; circle fits sd 0.02-0.03). A plain cylinder is off by up to ±0.8 mm radius at the ends. Every such `cyl`
feature therefore has extra keys `d0` (diameter at `p0`) and `d1` (at `p0 + len*axis`); `d` is the mean-diameter
fallback. Please build them as truncated cones, e.g. `course_checks.py cone(part, origin, vec, base=d0, top=d1,
height=len)` (nx-patterns-and-body-ops skill, NX 2206 ConeBuilder DiametersAndHeight). `nx/c10_feat.py` currently
reads only `d`.

`*_cap` features: the same cone continued from z -1 to the measured top above the rim plane with `clip none` (the
`env` clip stops at z 0); same idea as the plateau pins (identical lateral surface in the overlap).

## F04 shoulder-vent boss pairs (must)

- Scan: two tubular bosses per side, concentric bores, joined by a web, each with a thin stem web up to the rim wall.
  R and L agree within 0.15 mm.
- Boss "79": centre (78.95, 87.73), D(z) = 8.07 - 0.1075 z (8.1 at z 0, 10.4 at -22), top +0.2 (hmap 0.13-0.24).
  Boss "94": centre (94.16, 84.16), D(z) = 8.43 - 0.104 z, top +2.55 (hmap 2.48-2.61). Both blend into the wall
  below z ≈ -24; cones built from z -30 (clip env).
- Bores d 3.4 (fits 3.32-3.53 at the top). The old R holes (79.085, 87.728) and (94.033, 84.181) match within 0.15 mm,
  but they are cut before stage H and would be refilled by the cones -> removed and re-cut as F04_bore79/94 with the
  old bottom_cap depths (-37.81 / -36.63; the floor is not visible in the scan).
- Boss-to-boss web: top z -23.85 (hmap -23.72..-23.99), front hump y 85.7 at x 86.5; prism z -30..-23.85.
- Stem webs to the rim wall: boss79 stem x 77.8..80.2 at the top (y 92-96 sections), 3 deg draft faces (cut planes),
  top +0.2 (clipped to the rim plane 0, -0.2); boss94 stem top flat x 93.1..95.3 (y 92) / 93.5..96.0 (y 94); its
  large root fillets (sides flare below z -5) are not modelled.
- Removed: plateau #74 (L one-sided keyhole post, point (-79.1, 84.6)) and plateau #76 (R h 2.53 boss94, point
  (94.16, 81.0)) — both replaced by the cones.

## F14 side tubes (must) + F26 raised rings

- 4 tubes, vertical axis, concentric with their bores: upper (±149.55, 63.32), lower (±159.27, -64.12). Bore-centred
  radial profile of the free face (f14_radial.py): r = 4.10 + 0.051 |z| (D 8.2 at z 0 -> 12.8 at -45), all four tubes
  within 0.15. The "bullet end" is simply the cone running into the inclined side wall (it meets the wall at the
  axis around z -45..-47): cones from z -50 with clip env give it.
- Tops: +0.25..+0.30 above the rim plane round the bore = the F26 "raised rings" -> `F14_tube*_cap` (cone, top +0.3).
- Bores d 3.4. Upper: old hole (149.63, 63.32) removed and re-cut (F14_boreU, old depth -32.56). Lower: NO hole in
  the old build (k388/k614 "extra" = CAD solid in the bore) -> F14_boreL added, bottom -31.5 ASSUMED (~4 mm above the
  exterior at the axis, like the upper one; the floor is not visible).
- k209/k227 ("extra" inside the upper bores at z -2..-8) and k388/k614: all cured by re-cutting the bores after the
  unites.
- Lug: plateau #71 (A, R only) and #72 (A, L only — its arc lay on the tube top circle, near-coincident with the cone)
  removed and replaced by the symmetric R prism `F14_lugU` (#71 outline, the part next to the tube pulled inside the
  cone). Lower lug plateau #70 (R) is kept (its edges are inside the cone or tangent where the real wall is tangent).
- pad_zones tmax 3.25 over the free side of each tube: the stepped pads T 3.95..6.75 there were the "grooved rail".
- k43/k44/k55/k60 "extra" next to the tubes (CAD 1-1.5 too thick) are the shoulder flange, see F26.

## F26 shoulder flange (should)

- `flange_t` (area-weighted median inner-face offset from the seat plane, r 56.5..66.5 round the bore axis):
  **4.46 R / 4.25 L -> flange_t ≈ 4.35**.
- BUT the inner face is a drafted plane, not parallel to the seat: tilted 2.84 deg (R) / 2.94 deg (L) about Y,
  plane-fit sd 0.025 (f26_flange_plane.json). Thickness along the seat normal: 1.98 / 1.68 at z 0, 3.47 / 3.22 at
  z -30, 4.96 / 4.76 at z -60 (R / L). Per-15-deg medians in f26_flange.json; plot F26_flange.png.
  A constant 4.35 is still ~2.4 too thick at the rim and ~0.5 too thin at the lowest point. Suggest: shell the
  flange at ~3.5 (value at the ring centre) and draft the inner face 2.9 deg from the rim plane, or trim with the
  fitted plane (R: n (0.99568, 0.07848, -0.04954) through (157.288, 0.002, -48.702); L mirror:
  n (-0.99555, 0.07878, -0.05175) through (-157.417, -0.267, -48.947)). R/L differ by ~0.25 (scan asymmetry).
- Raised rings: see F14 caps.

## F11 one-sided bosses on the y 12 rib (must)

- L boss: centre (-65.85, 12.15), d 5.3 (fits 5.28/5.29 at z -114.8/-115.5), flat top -114.48; base fillet d 5.67
  at -116.5, 6.10 at -117.5 on the floor plateau #18 (h -118.12) -> cylinder z -120.5..-114.5 + a cone ring
  (d 6.8 at -118.8 -> 5.3 at -116.3) for the fillet / gussets.
- R boss: centre (17.22, 12.0), d 5.2 (5.0 at the rounded top edge, 5.5 at the root), top -114.48; its front face
  (y 9.4) runs straight down to -126.5 (deep pocket in front), floor behind -120 -> cylinder from -127.5 (clip env).
- NOT resolved / not modelled: (1) no hole in either boss — the top has only a 0.4-0.7 deep, ~0.8 dia pin mark with
  a 0.25 raised lip at r 0.6-1.2; (2) the ~12 radial gussets round the L boss are below the 0.25 mm height-map
  resolution (< 0.2 mm relief) — one fillet ring instead. The L boss also has a short attached lobe on its +y side at
  z -115 (F11_bosses.png panel 1) and the short vertical rib below it (x -66.6..-65.2) is already in the CAD.

## F22 shoulder-top interior corners (should)

- Normal wall thickness (interior-facing vertex -> nearest exterior vertex, 2 mm bins, f22_thick.py): scan 3.3-3.4
  (= wall_t) over the whole corner; outC8 4.1-5.4 (pads T 3.95..7.45 built from the along-Z thickness map on the steep
  corner wall). -> pad zone tmax 3.25, poly (111,78) (124,76) (131,70) (140.5,66) (146,72) (146,92) (111,92).

## F23 neck clip receivers (should)

- The missing side wall is the inclined wall left of the receiver box (x 44..53, from the ledge plateau h -80.92 up to
  the neck wall): face y 60.0..61.5 at z -79 -> 64.5..66.1 at -71.5 (x 48..52), ~57-59 deg. Two R prisms with cut
  planes: `F23_sidewall_ramp` (x 46.4..53.6, plane through (y 61.25, z -79), slope 1.56) and `F23_sidewall_lobe`
  (x 44..47, the rounded outer lobe, plane through (y 57.1, z -79), slope 0.85). At x 48 the ramp is ~1 mm under
  the scan (transition to the lobe), at x 50-52 up to ~0.8 over.
- Horns: pad_zones tmax 3.95 on the left flank (pads T 5.35..6.75 on the steep neck wall; scan normal wall ≈ 4.0) and
  tmax 3.25 on the right flank (pad loop T 3.95 at x 62.3..66.4, y 60.4..67.5; the box walls are plateaus).

## F24 neck channels (should)

- The "cross ribs" are terrace risers: the channel floor (y 36..41, x 54..82) is a staircase of FLAT terraces exactly
  0.50 mm apart (z -99.65, -99.15, ... -94.65), risers at x 57.7 60.8 63.6 66.2 68.9 71.2 73.7 76.0 78.2 80.4 (y 39),
  bowed ~0.5 toward +x mid-channel (3-point edges from y 37.5 / 39 / 40.5). R and L within 0.1. Beyond x 82 it is a
  smooth ramp (CAD ok). 10 R prisms `F24_terrace02..11` (2 mm thick, 0.6 mm overlap); terrace 1 (z -99.62, x < 57.7)
  is the existing plateau #23 (kept).

## Open / for the lead

1. Cones (`d0`/`d1`) need the cone builder in stage H, otherwise use `d` (mean) with the stated error.
2. Flange draft (F26) is a stage-A change; G1 only reports it.
3. Lower tube bore depth and F04/F14 bore depths are assumed (scan cannot see the floors).
4. F11 gussets / hole not modelled (see above) — confirm with the client if the hole matters.
