import numpy as np
from g1lib import *
v, f = crop("C_neck")
zs = np.arange(-80.5, -65, 1.5)
for sgn in (1, -1):
    print("side", "RL"[sgn < 0], "z:", " ".join(f"{z:6.1f}" for z in zs))
    for x in (44.0, 45.0, 46.0, 48.0, 50.0, 52.0, 53.0):
        s = sec2(v, f, 0, sgn * x).reshape(-1, 2)   # (y, z)
        row = []
        for z in zs:
            k = (np.abs(s[:, 1] - z) < 0.35) & (s[:, 0] > 54) & (s[:, 0] < 76)
            row.append(f"{s[k, 0].min():6.1f}" if k.any() else "    - ")
        print(f"  x {x:5.1f}:   " + " ".join(row))
