import numpy as np, matplotlib.pyplot as plt
from g1lib import *
vA, fA = crop("A_shoulder_up"); vB, fB = crop("B_shoulder_lo"); cv, cf = cad()
T = [("U", vA, fA, (140, 162, 38, 75)), ("Lo", vB, fB, (145, 170, -80, -38))]
zs = [-5, -15, -25, -35]
fig, axs = plt.subplots(4, 4, figsize=(18, 24)); r = 0
for sgn in (1, -1):
    for name, v, f, lim in T:
        for j, z in enumerate(zs):
            ax = axs[r, j]
            s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
            c = sec2(cv, cf, 2, z); c[:, :, 0] *= sgn
            draw(ax, c, "#555555", 0.9); draw(ax, s, "#e08a00", 1.2)
            setup(ax, lim, f"{name} {'RL'[sgn<0]} z={z}")
        r += 1
fig.tight_layout(); fig.savefig("f14_wall_explore.png", dpi=50)
