import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("C_neck"); cv, cf = cad()
fig, axs = plt.subplots(3, 3, figsize=(30, 22))
ax = axs[0, 0]
for x, col in ((60, "r"), (66, "g"), (72, "b"), (78, "m"), (84, "k")):
    s = sec2(v, f, 0, x); draw(ax, s, col, 1.0)
setup(ax, (28, 50, -108, -86), "R x-sections 60 r 66 g 72 b 78 m 84 k (y right z up)")
ax = axs[0, 1]
for x, col in ((60, "r"), (66, "g"), (72, "b"), (78, "m"), (84, "k")):
    s = sec2(cv, cf, 0, x); draw(ax, s, col, 1.0)
setup(ax, (28, 50, -108, -86), "CAD same")
ax = axs[0, 2]
s = sec2(v, f, 0, 72.0); c = sec2(cv, cf, 0, 72.0); draw(ax, c, "#333333", 1); draw(ax, s, "#e08a00", 1.5)
setup(ax, (32, 46, -104, -90), "x=72 scan vs CAD"); ax.xaxis.set_major_locator(plt.MultipleLocator(1)); ax.yaxis.set_major_locator(plt.MultipleLocator(1))
for i, y in enumerate((37.5, 38.5, 39.5)):
    ax = axs[1, i]
    s = sec2(v, f, 1, y); c = sec2(cv, cf, 1, y); draw(ax, c, "#333333", 1); draw(ax, s, "#e08a00", 1.5)
    setup(ax, (52, 92, -106, -90), f"R y={y} (x right z up)"); ax.xaxis.set_major_locator(plt.MultipleLocator(2))
for i, z in enumerate((-96.5, -97.5, -98.5)):
    ax = axs[2, i]
    s = sec2(v, f, 2, z); c = sec2(cv, cf, 2, z); draw(ax, c, "#333333", 1); draw(ax, s, "#e08a00", 1.5)
    setup(ax, (52, 92, 30, 46), f"R z={z}"); ax.xaxis.set_major_locator(plt.MultipleLocator(2))
fig.tight_layout(); fig.savefig("f24_explore.png", dpi=40)
