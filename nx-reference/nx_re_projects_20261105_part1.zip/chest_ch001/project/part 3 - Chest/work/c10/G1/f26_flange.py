"""Flange thickness: scan inner-face offset from the shoulder datum plane, binned by angle round the bore axis."""
import json, os, numpy as np
from g1lib import *
v, f = crop("E_flange")
DT = json.load(open(os.path.join(ROOT, "work", "datums.json")))
a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
fn = np.cross(b - a, c - a); ar = np.linalg.norm(fn, axis=1) / 2
fn /= np.maximum(2 * ar, 1e-12)[:, None]
ctr = (a + b + c) / 3
res = {}
for side, key in (("R", "shoulder_R"), ("L", "shoulder_L")):
    n = np.array(DT[key]["normal"]); p0 = np.array(DT[key]["plane_pt"]); hc = np.array(DT[key]["hole_centre"])
    if (side == "L") != (n[0] < 0):
        n = -n
    s = (ctr - p0) @ n
    rel = ctr - hc
    r = np.hypot(rel[:, 1], rel[:, 2]); th = np.degrees(np.arctan2(rel[:, 2], rel[:, 1]))
    inner = (s < -1.5) & (s > -9) & (fn @ n < -0.9) & (r > 56.5) & (r < 66.5)
    outer = (np.abs(s) < 0.6) & (fn @ n > 0.9) & (r > 56.5) & (r < 66.5)
    print(f"== {side}: outer face n={outer.sum()} median s {np.median(s[outer]):.3f};  inner face n={inner.sum()} area-weighted median s:")
    rows = []
    for t0 in range(-180, 15, 15):
        m = inner & (th >= t0) & (th < t0 + 15)
        if m.sum() < 30:
            continue
        w = ar[m]; o = np.argsort(s[m]); cw = np.cumsum(w[o]) / w.sum()
        med = s[m][o][np.searchsorted(cw, 0.5)]
        p10 = s[m][o][np.searchsorted(cw, 0.1)]; p90 = s[m][o][min(np.searchsorted(cw, 0.9), m.sum() - 1)]
        rows.append((t0, int(m.sum()), round(float(med), 2), round(float(p10), 2), round(float(p90), 2), round(float(w.sum()), 1)))
        print(f"  theta {t0:5d}..{t0+15:4d}: n {m.sum():6d} area {w.sum():7.1f}  median {med:6.2f}  p10 {p10:6.2f} p90 {p90:6.2f}")
    m = inner; w = ar[m]; o = np.argsort(s[m]); cw = np.cumsum(w[o]) / w.sum()
    med = float(s[m][o][np.searchsorted(cw, 0.5)])
    print(f"  ALL area-weighted median {med:.3f}")
    res[side] = dict(bins=rows, median=round(med, 3))
json.dump(res, open("f26_flange.json", "w"), indent=0)
