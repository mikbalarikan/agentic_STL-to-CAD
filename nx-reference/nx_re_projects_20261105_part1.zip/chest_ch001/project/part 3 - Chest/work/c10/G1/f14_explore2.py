import numpy as np, matplotlib.pyplot as plt
from g1lib import *
vA, fA = crop("A_shoulder_up"); vB, fB = crop("B_shoulder_lo"); cv, cf = cad()
T = [("U", vA, fA, (149.55, 63.3)), ("L", vB, fB, (159.27, -64.1))]
fig, axs = plt.subplots(4, 4, figsize=(20, 20))
r = 0
for sgn in (1, -1):
    for name, v, f, (cx, cy) in T:
        jobs = [(1, cy, (cx - 20, cx + 15, -50, 4), 0), (0, cx, (cy - 20, cy + 20, -50, 4), 0), (0, cx - 3.5, (cy - 20, cy + 20, -50, 4), 0)]
        # oblique: plane through axis along the wall normal: use y=cy +- , skip
        for j, (axis, val, lim, _) in enumerate(jobs):
            ax = axs[r, j]
            vv = val * sgn if axis == 0 else val
            s = sec2(v, f, axis, vv); c = sec2(cv, cf, axis, vv)
            if axis == 1:
                s[:, :, 0] *= sgn; c[:, :, 0] *= sgn
            draw(ax, c, "#777777", 0.8); draw(ax, s, "#e08a00", 1.2)
            setup(ax, lim, f"{name} {'RL'[sgn<0]} {'xyz'[axis]}={vv:.2f}")
        ax = axs[r, 3]
        for z, col in ((-1, "r"), (-10, "g"), (-20, "b"), (-28, "m"), (-34, "c")):
            s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
            draw(ax, s, col, 0.8)
        setup(ax, (cx - 15, cx + 12, cy - 13, cy + 13), f"{name} {'RL'[sgn<0]} z -1 r,-10 g,-20 b,-28 m,-34 c")
        r += 1
fig.tight_layout(); fig.savefig("f14_explore2.png", dpi=50)
