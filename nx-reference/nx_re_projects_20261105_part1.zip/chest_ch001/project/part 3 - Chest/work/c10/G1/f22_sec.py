import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("A_shoulder_up"); cv, cf = cad()
jobs = [(1, 72.0, (105, 165, -60, 5)), (1, 80.0, (105, 165, -60, 5)), (1, 86.0, (105, 165, -60, 5)), (0, 132.0, (45, 105, -60, 5)), (0, 140.0, (45, 105, -60, 5))]
fig, axs = plt.subplots(2, len(jobs), figsize=(7 * len(jobs), 13))
for i, sgn in enumerate((1, -1)):
    for j, (axis, val, lim) in enumerate(jobs):
        ax = axs[i, j]
        vv = val * sgn if axis == 0 else val
        s = sec2(v, f, axis, vv); c = sec2(cv, cf, axis, vv)
        if axis == 1:
            s[:, :, 0] *= sgn; c[:, :, 0] *= sgn
        draw(ax, c, "#555555", 0.9); draw(ax, s, "#e08a00", 1.3)
        setup(ax, lim, f"{'RL'[i]} {'xyz'[axis]}={vv}")
fig.tight_layout(); fig.savefig("f22_sec.png", dpi=45)
