import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("D_y12"); cv, cf = cad()
H = np.load(os.path.join(ROOT, "work", "hmap.npz")); top = H["top"]; x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
fig, axs = plt.subplots(3, 4, figsize=(28, 21))
for r, (cx, cy) in enumerate(((-65.9, 12.5), (17.0, 12.3))):
    jobs = [(1, cy, (cx - 10, cx + 10, -128, -108)), (0, cx, (cy - 10, cy + 10, -128, -108))]
    for j, (axis, val, lim) in enumerate(jobs):
        ax = axs[r, j]
        s = sec2(v, f, axis, val); c = sec2(cv, cf, axis, val)
        draw(ax, c, "#777777", 0.8); draw(ax, s, "#e08a00", 1.3)
        setup(ax, lim, f"{'xyz'[axis]}={val}")
    ax = axs[r, 2]
    j0 = int((cx - 10 - x0) / st); j1 = int((cx + 10 - x0) / st); i0 = int((cy - 10 - y0) / st); i1 = int((cy + 10 - y0) / st)
    im = ax.imshow(top[i0:i1, j0:j1], origin="lower", extent=(cx - 10, cx + 10, cy - 10, cy + 10), cmap="viridis")
    plt.colorbar(im, ax=ax); ax.set_title("hmap top")
    ax = axs[r, 3]
    for z, col in ((-111, "r"), (-113, "g"), (-115, "b"), (-117, "m"), (-119, "k")):
        s = sec2(v, f, 2, z); draw(ax, s, col, 0.9)
    setup(ax, (cx - 10, cx + 10, cy - 10, cy + 10), "z -111 r -113 g -115 b -117 m -119 k")
ax = axs[2, 0]
j0 = int((-80 - x0) / st); j1 = int((30 - x0) / st); i0 = int((0 - y0) / st); i1 = int((25 - y0) / st)
im = ax.imshow(top[i0:i1, j0:j1], origin="lower", extent=(-80, 30, 0, 25), cmap="viridis", vmin=-125, vmax=-105, aspect="auto")
plt.colorbar(im, ax=ax)
for k in (1, 2, 3):
    axs[2, k].axis("off")
fig.tight_layout(); fig.savefig("f11_explore.png", dpi=45)
