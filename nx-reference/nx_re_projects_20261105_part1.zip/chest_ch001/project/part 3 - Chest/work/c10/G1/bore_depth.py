import numpy as np
from g1lib import *
B = [("b79", "A_shoulder_up", (78.95, 87.73)), ("b94", "A_shoulder_up", (94.16, 84.16)), ("tU", "A_shoulder_up", (149.55, 63.32)), ("tL", "B_shoulder_lo", (159.27, -64.12))]
for name, cr, (cx, cy) in B:
    v, f = crop(cr)
    for sgn in (1, -1):
        r = np.hypot(sgn * v[:, 0] - cx, v[:, 1] - cy)
        for rr in (1.0, 1.6):
            z = np.sort(v[r < rr, 2])[::-1]
            z = z[z > -70]
            gaps = np.where(np.diff(z) < -1.5)[0]
            print(f"{name} {'RL'[sgn<0]} r<{rr}: n {len(z)} z top {z[:1]} ; z clusters:", [(round(float(z[i]), 2), round(float(z[i + 1]), 2)) for i in gaps][:5], "min", round(float(z.min()), 2) if len(z) else None)
