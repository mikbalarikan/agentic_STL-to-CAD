"""Evidence PNGs for G1: scan sections (orange), outC8 CAD (grey), proposed G1 features (blue = unite, red = subtract,
green dashed = pad zones)."""
import json, os
import numpy as np, matplotlib.pyplot as plt
from g1lib import *
G = json.load(open(os.path.join(os.path.dirname(G1), "G1.json")))
FE = G["features"]


def fdia(F, z):
    p0z = F["p0"][2]; L = F["len"]
    if not (p0z - 1e-6 <= z <= p0z + L + 1e-6):
        return None
    d0, d1 = F.get("d0", F["d"]), F.get("d1", F["d"])
    return d0 + (d1 - d0) * (z - p0z) / L


def overlay_z(ax, z, sgn, finding):
    for F in FE:
        if F["finding"] not in finding:
            continue
        sides = [1, -1] if F["side"] == "R" else [1]
        for s in sides:
            if F["side"] == "A" and np.sign(F.get("p0", [1])[0] if F["type"] == "cyl" else F["outline"][0][0]) != sgn:
                continue
            col = "b" if F["op"] == "unite" else "r"
            if F["type"] == "cyl":
                d = fdia(F, z)
                if d:
                    cx = F["p0"][0] * s * (sgn if F["side"] != "A" else 1) if False else F["p0"][0] * (1 if F["side"] == "A" else 1)
                    circ(ax, (abs(F["p0"][0]) if F["side"] == "R" else F["p0"][0] * sgn, F["p0"][1]), d / 2, col, 1.2, "--" if F["op"] == "subtract" else "-")
            elif F["type"] == "prism" and F["z0"] - 1e-6 <= z <= F["z1"] + 1e-6:
                P = np.array(F["outline"]); P[:, 0] = np.abs(P[:, 0]) if F["side"] == "R" else P[:, 0] * sgn
                poly(ax, P, col, 1.2)
            break


def zones(ax):
    for Z in G["pad_zones"]:
        poly(ax, Z["poly"], "g", 1.0, "--")


def zpanel(ax, crop_name, z, sgn, lim, finding, title=""):
    v, f = crop(crop_name); cv, cf = cad()
    s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
    c = sec2(cv, cf, 2, z); c[:, :, 0] *= sgn
    draw(ax, c, "#999999", 0.7); draw(ax, s, "#e08a00", 1.3)
    overlay_z(ax, z, sgn, finding); zones(ax)
    setup(ax, lim, f"{'R' if sgn > 0 else 'L (x mirrored)'} z = {z}  {title}")


def vpanel(ax, crop_name, axis, val, sgn, lim, title=""):
    v, f = crop(crop_name); cv, cf = cad()
    vv = val * sgn if axis == 0 else val
    s = sec2(v, f, axis, vv); c = sec2(cv, cf, axis, vv)
    if axis == 1:
        s[:, :, 0] *= sgn; c[:, :, 0] *= sgn
    draw(ax, c, "#999999", 0.7); draw(ax, s, "#e08a00", 1.3)
    setup(ax, lim, f"{'R' if sgn > 0 else 'L'} {'xyz'[axis]} = {vv}  {title}")


def save(fig, name):
    fig.suptitle(f"{name}: scan orange, outC8 CAD grey, G1 unite blue / subtract red dashed, pad zones green dashed", fontsize=10)
    fig.tight_layout(); fig.savefig(os.path.join(G1, name + ".png"), dpi=55); plt.close(fig)


# F04
fig, axs = plt.subplots(2, 4, figsize=(28, 14))
for i, sgn in enumerate((1, -1)):
    for j, z in enumerate((-0.5, -8.0, -16.0, -24.5)):
        zpanel(axs[i, j], "A_shoulder_up", z, sgn, (70, 104, 76, 106), ("F04",))
save(fig, "F04_bosses")
# F14
fig, axs = plt.subplots(2, 4, figsize=(28, 14))
for i, (cr, lim) in enumerate((("E_flange", (136, 162, 48, 76)), ("E_flange", (146, 172, -78, -50)))):
    for j, (z, sgn) in enumerate(((-1.0, 1), (-20.0, 1), (-40.0, 1), (-20.0, -1))):
        zpanel(axs[i, j], cr, z, sgn, lim, ("F14",))
save(fig, "F14_tubes")
# F11
fig, axs = plt.subplots(1, 4, figsize=(28, 7))
zpanel(axs[0], "D_y12", -115.2, -1, (58, 74, 4, 20), ("F11",)); axs[0].set_xlim(58, 74)
zpanel(axs[1], "D_y12", -117.5, -1, (58, 74, 4, 20), ("F11",))
zpanel(axs[2], "D_y12", -115.2, 1, (9, 25, 4, 20), ("F11",))
vpanel(axs[3], "D_y12", 0, 17.22, 1, (2, 22, -130, -110), "boss R profile, top -114.5")
for a in axs[:2]:
    a.set_xlim(58, 74)
# note: L boss panels are drawn mirrored (x -> -x)
save(fig, "F11_bosses")
# F22
T = np.load(os.path.join(G1, "f22_thick.npz"))
fig, axs = plt.subplots(1, 2, figsize=(18, 9))
for ax, s in zip(axs, "RL"):
    D = T[f"{s}_cad"] - T[f"{s}_scan"]
    im = ax.imshow(np.clip(D, -3, 3), origin="lower", extent=(100, 162, 48, 104), cmap="RdBu_r"); plt.colorbar(im, ax=ax)
    zones(ax); ax.set_title(f"{s}: CAD - scan normal wall thickness (red = CAD too thick); green = pad zones"); ax.grid(lw=0.3)
save(fig, "F22_corner")
# F23
fig, axs = plt.subplots(1, 4, figsize=(28, 8))
for ax, x in zip(axs[:3], (46.0, 48.0, 50.0)):
    vpanel(ax, "C_neck", 0, x, 1, (52, 76, -88, -64))
    for F in FE:
        if F["finding"] == "F23" and F["outline"][0][0] - 1e-6 <= x <= max(p[0] for p in F["outline"]) + 1e-6:
            cp = F["cut_planes"][0]; p, n = np.array(cp["p"]), np.array(cp["n"])
            ys = np.array([min(q[1] for q in F["outline"]), max(q[1] for q in F["outline"])])
            zs = p[2] - n[1] * (ys - p[1]) / n[2]
            zs = np.clip(zs, F["z0"], F["z1"])
            ax.plot(ys, zs, "b", lw=1.5)
            ax.plot([ys[0], ys[0], ys[1], ys[1]], [zs[0], F["z0"], F["z0"], zs[1]], "b", lw=1.0)
zpanel(axs[3], "C_neck", -77.0, 1, (40, 70, 52, 80), ("F23",))
save(fig, "F23_receiver")
# F24
H = np.load(os.path.join(ROOT, "work", "hmap.npz")); top = H["top"]; x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
fig, axs = plt.subplots(2, 1, figsize=(20, 12))
ax = axs[0]
for sgn, col in ((1, "#e08a00"), (-1, "#a05000")):
    i = int(round((38.75 - y0) / st)); xs = np.arange(50, 92, 0.25)
    ax.plot(xs, [top[i, int(round((sgn * x - x0) / st))] for x in xs], color=col, lw=1.4, label=f"scan floor y 38.75 {'R' if sgn > 0 else 'L'}")
for F in FE:
    if F["finding"] == "F24":
        P = np.array(F["outline"]); xa = P[1, 0]; xb = P[-2, 0]
        ax.plot([xa, xb], [F["z1"], F["z1"]], "b", lw=1.2)
ax.legend(); ax.grid(lw=0.3); ax.minorticks_on(); ax.set_title("F24 channel floor profile and terrace tops (blue)")
ax = axs[1]
j0 = int((50 - x0) / st); j1 = int((92 - x0) / st); i0 = int((32 - y0) / st); i1 = int((44 - y0) / st)
ax.imshow(top[i0:i1, j0:j1], origin="lower", extent=(50, 92, 32, 44), cmap="viridis", aspect="equal")
for F in FE:
    if F["finding"] == "F24":
        poly(ax, F["outline"], "w", 1.0)
ax.set_title("R plan: hmap top + terrace outlines")
save(fig, "F24_channel")
# F26
FL = json.load(open(os.path.join(G1, "f26_flange.json")))
PLN = json.load(open(os.path.join(G1, "f26_flange_plane.json")))
fig, axs = plt.subplots(1, 3, figsize=(24, 7))
ax = axs[0]
for s, col in (("R", "C1"), ("L", "C0")):
    b = np.array([r[:3] for r in FL[s]["bins"]], float)
    ax.plot(b[:, 0] + 7.5, -b[:, 2], "o-", color=col, label=f"{s} scan inner-face offset (median per 15 deg)")
th = np.linspace(-170, -10, 50); zz = 61.0 * np.sin(np.radians(th))
for s, col in (("R", "C1"), ("L", "C0")):
    t0, t60 = PLN[s]["t_z0"], PLN[s]["t_z60"]
    ax.plot(th, t0 + (t60 - t0) * (-zz) / 60.0, "--", color=col, label=f"{s} fitted plane (draft {PLN[s]['angle_to_outer_deg']} deg)")
ax.axhline(4.6, color="grey", label="outC8 flange_t 4.6"); ax.legend(fontsize=8); ax.grid(lw=0.3)
ax.set_xlabel("angle round the shoulder bore axis (deg, -90 = lowest)"); ax.set_ylabel("flange thickness mm")
vpanel(axs[1], "E_flange", 1, 63.32, 1, (140, 160, -10, 3), "upper tube top: ring +0.3")
vpanel(axs[2], "E_flange", 0, 159.27, 1, (-74, -54, -10, 3), "lower tube top")
save(fig, "F26_flange")
print("ok")
