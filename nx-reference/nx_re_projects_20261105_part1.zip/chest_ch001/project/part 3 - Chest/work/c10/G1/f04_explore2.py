import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("A_shoulder_up"); cv, cf = cad()
zs = [-1, -6, -12, -20, -28, -33]
fig, axs = plt.subplots(2, len(zs), figsize=(4.5 * len(zs), 9))
for i, sgn in enumerate((1, -1)):
    for j, z in enumerate(zs):
        ax = axs[i, j]
        s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
        c = sec2(cv, cf, 2, z); c[:, :, 0] *= sgn
        draw(ax, c, "#777777", 0.8); draw(ax, s, "#e08a00", 1.2)
        setup(ax, (72, 102, 76, 104), f"{'RL'[i]} z={z}")
fig.tight_layout(); fig.savefig("f04_explore2.png", dpi=60)
