import numpy as np, matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter
from g1lib import *
H = np.load(os.path.join(ROOT, "work", "hmap.npz")); top = H["top"]; x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
fig, axs = plt.subplots(1, 2, figsize=(18, 9))
for ax, (cx, cy) in zip(axs, ((-65.85, 12.15), (17.22, 12.0))):
    j0 = int((cx - 10 - x0) / st); j1 = int((cx + 10 - x0) / st); i0 = int((cy - 10 - y0) / st); i1 = int((cy + 10 - y0) / st)
    Z = top[i0:i1, j0:j1].astype(float)
    hp = Z - gaussian_filter(Z, 4)
    im = ax.imshow(np.clip(hp, -0.4, 0.4), origin="lower", extent=(cx - 10, cx + 10, cy - 10, cy + 10), cmap="RdBu_r")
    plt.colorbar(im, ax=ax); ax.set_title(f"high-pass hmap top round ({cx},{cy})"); ax.grid(lw=0.3)
fig.tight_layout(); fig.savefig("f11_shade.png", dpi=60)
