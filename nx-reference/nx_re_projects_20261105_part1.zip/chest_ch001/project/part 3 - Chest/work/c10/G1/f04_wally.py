import numpy as np
from g1lib import *
v, f = crop("A_shoulder_up")
for sgn in (1, -1):
    for z in (0.0, -0.5, -3, -8, -14, -20, -24, -28, -32):
        s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
        row = []
        for x in (79.0, 86.5, 94.5):
            m = (np.minimum(s[:, 0, 0], s[:, 1, 0]) <= x) & (np.maximum(s[:, 0, 0], s[:, 1, 0]) >= x)
            ys = []
            for a, b in s[m]:
                t = (x - a[0]) / (b[0] - a[0]) if b[0] != a[0] else 0
                ys.append(a[1] + t * (b[1] - a[1]))
            ys = sorted(y for y in ys if 76 < y < 106)
            row.append(f"x{x}: " + ",".join(f"{y:.1f}" for y in ys))
        print(f"{'RL'[sgn<0]} z {z:6.1f} | " + " | ".join(row))
