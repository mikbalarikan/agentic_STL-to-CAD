import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("A_shoulder_up")
H = np.load(os.path.join(ROOT, "work", "hmap.npz")); top = H["top"]; x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
zs = [(-1.5, "r"), (-6, "g"), (-12, "b"), (-20, "m"), (-24.3, "k"), (-26, "c")]
fig, axs = plt.subplots(1, 3, figsize=(27, 10))
for i, sgn in enumerate((1, -1)):
    ax = axs[i]
    for z, col in zs:
        s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
        draw(ax, s, col, 0.9)
    setup(ax, (72, 102, 78, 102), f"{'RL'[i]} z -1.5 r, -6 g, -12 b, -20 m, -24.3 k, -26 c")
    ax.xaxis.set_major_locator(plt.MultipleLocator(2)); ax.yaxis.set_major_locator(plt.MultipleLocator(2))
# hmap top image R
ax = axs[2]
j0 = int((72 - x0) / st); j1 = int((102 - x0) / st); i0 = int((78 - y0) / st); i1 = int((102 - y0) / st)
im = ax.imshow(top[i0:i1, j0:j1], origin="lower", extent=(72, 102, 78, 102), vmin=-30, vmax=3, cmap="viridis")
plt.colorbar(im, ax=ax); ax.set_title("hmap top R")
fig.tight_layout(); fig.savefig("f04_plan.png", dpi=55)
def T(x, y):
    return top[int(round((y - y0) / st)), int(round((x - x0) / st))]
for sgn in (1, -1):
    print("side", sgn, "web top samples:", [round(float(T(sgn * x, y)), 2) for x, y in ((85, 85.5), (86.5, 86), (88, 86.5), (86.5, 88), (85.5, 89))])
    print("  b79 ring top:", [round(float(T(sgn * x, y)), 2) for x, y in ((76.5, 87.7), (81.4, 87.7), (79, 85.3), (79, 90.2))])
    print("  b94 ring top:", [round(float(T(sgn * x, y)), 2) for x, y in ((91.7, 84.2), (96.5, 84.2), (94.1, 81.8), (94.1, 86.6))])
    print("  stem79 top:", [round(float(T(sgn * x, y)), 2) for x, y in ((79, 92), (79, 94), (79, 96), (78, 94), (80, 94))])
    print("  stem94 top:", [round(float(T(sgn * x, y)), 2) for x, y in ((94.5, 89.5), (94.5, 91), (94.5, 93), (93, 92), (96, 92))])
