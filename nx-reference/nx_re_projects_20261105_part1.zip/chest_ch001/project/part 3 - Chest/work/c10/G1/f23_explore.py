import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("C_neck"); cv, cf = cad()
zs = [-58, -64, -70, -74, -78, -82, -86]
fig, axs = plt.subplots(2, len(zs) + 2, figsize=(5 * (len(zs) + 2), 10))
for i, sgn in enumerate((1, -1)):
    for j, z in enumerate(zs):
        ax = axs[i, j]
        s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
        c = sec2(cv, cf, 2, z); c[:, :, 0] *= sgn
        draw(ax, c, "#555555", 0.8); draw(ax, s, "#e08a00", 1.2)
        setup(ax, (38, 66, 50, 78), f"{'RL'[i]} z={z}")
    for j, (axis, val, lim) in enumerate(((1, 63.5, (38, 66, -95, -50)), (0, 52.5, (50, 78, -95, -50)))):
        ax = axs[i, len(zs) + j]
        vv = val * sgn if axis == 0 else val
        s = sec2(v, f, axis, vv); c = sec2(cv, cf, axis, vv)
        if axis == 1:
            s[:, :, 0] *= sgn; c[:, :, 0] *= sgn
        draw(ax, c, "#555555", 0.8); draw(ax, s, "#e08a00", 1.2)
        setup(ax, lim, f"{'RL'[i]} {'xyz'[axis]}={vv}")
fig.tight_layout(); fig.savefig("f23_explore.png", dpi=45)
