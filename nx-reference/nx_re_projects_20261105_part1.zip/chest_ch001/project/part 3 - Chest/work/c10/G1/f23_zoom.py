import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("C_neck"); cv, cf = cad()
zs = [-68, -71, -74, -77, -80]
fig, axs = plt.subplots(2, len(zs), figsize=(8 * len(zs), 16))
for i, sgn in enumerate((1, -1)):
    for j, z in enumerate(zs):
        ax = axs[i, j]
        s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
        c = sec2(cv, cf, 2, z); c[:, :, 0] *= sgn
        draw(ax, c, "#333333", 1.0); draw(ax, s, "#e08a00", 1.6)
        setup(ax, (40, 66, 54, 78), f"{'RL'[i]} z={z}")
        ax.xaxis.set_major_locator(plt.MultipleLocator(2)); ax.yaxis.set_major_locator(plt.MultipleLocator(2))
fig.tight_layout(); fig.savefig("f23_zoom.png", dpi=40)
