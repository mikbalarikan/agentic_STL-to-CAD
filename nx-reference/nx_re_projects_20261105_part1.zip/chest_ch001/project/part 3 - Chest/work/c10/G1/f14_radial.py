"""Radial distance of the tube's free face from the bore axis, per z and per angle sector (centre fixed = bore centre)."""
import numpy as np
from g1lib import *
T = [("U", "A_shoulder_up", (149.55, 63.32)), ("Lo", "B_shoulder_lo", (159.27, -64.1))]
secs = [(110, 135), (135, 160), (160, 185), (185, 210), (210, 235), (235, 255), (255, 290), (290, 330), (330, 360), (0, 40), (40, 80), (80, 110)]
for name, cr, (cx, cy) in T:
    v, f = crop(cr)
    for sgn in (1, -1):
        print(f"== {name} {'RL'[sgn<0]}  centre ({cx},{cy}); columns = sectors {secs} (deg from +x, x mirrored for L)")
        for z in [-0.5, -10, -20, -31, -37, -40, -43, -45, -47, -49, -51, -53]:
            s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
            p = s.reshape(-1, 2) - [cx, cy]
            r = np.hypot(*p.T); a = np.degrees(np.arctan2(p[:, 1], p[:, 0])) % 360
            row = []
            for a0, a1 in secs:
                m = (a >= a0) & (a < a1) & (r > 3.0) & (r < 12)
                row.append(f"{np.min(r[m]):6.2f}" if m.sum() > 3 else "   -  ")
            print(f"  z {z:6.1f}: " + " ".join(row))
