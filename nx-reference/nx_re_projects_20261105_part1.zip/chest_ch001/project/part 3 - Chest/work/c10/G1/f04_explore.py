import numpy as np, matplotlib.pyplot as plt
from g1lib import *
v, f = crop("A_shoulder_up"); cv, cf = cad()
zs = [-2, -8, -15, -22, -30, -36, -40, -44]
fig, axs = plt.subplots(2, len(zs), figsize=(5 * len(zs), 10))
for i, sgn in enumerate((1, -1)):
    for j, z in enumerate(zs):
        ax = axs[i, j]
        s = sec2(v, f, 2, z); s[:, :, 0] *= sgn
        c = sec2(cv, cf, 2, z); c[:, :, 0] *= sgn
        draw(ax, c, "#777777", 0.8); draw(ax, s, "#e08a00", 1.0)
        setup(ax, (65, 115, 62, 112), f"{'RL'[i]} z={z} (x mirrored to +)")
fig.tight_layout(); fig.savefig("f04_explore.png", dpi=55)
