import numpy as np
from g1lib import *
v, f = crop("C_neck")
for sgn in (1, -1):
    p = v.copy(); p[:, 0] *= sgn
    m = (p[:, 0] > 46) & (p[:, 0] < 52.5) & (p[:, 1] > 59.5) & (p[:, 1] < 67.5) & (p[:, 2] > -79.5) & (p[:, 2] < -71.5)
    P = p[m]
    for it in range(4):
        A = np.c_[np.ones(len(P)), P[:, 0], P[:, 1]]
        c, *_ = np.linalg.lstsq(A, P[:, 2], rcond=None)
        r = P[:, 2] - A @ c
        k = np.abs(r) < 2.5 * r.std(); P = P[k]
    print("RL"[sgn < 0], "z = %.2f + %.4f x + %.4f y" % tuple(c), "sd %.3f n %d" % (r[k].std(), len(P)))
    # left edge of the lobe: min x of scan points with y in 58..66, z in -80..-74, that are above the ledge
    m2 = (p[:, 1] > 55) & (p[:, 1] < 66) & (p[:, 2] > -80.5) & (p[:, 2] < -73) & (p[:, 0] > 40) & (p[:, 0] < 47)
    print("  lobe left points x range", np.round(np.percentile(p[m2, 0], [1, 50, 99]), 2), len(p[m2]))
