import numpy as np, os
from g1lib import *
H = np.load(os.path.join(ROOT, "work", "hmap.npz")); top = H["top"]; x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
for y in (38.5, 39.0):
    i = int(round((y - y0) / st))
    xs = np.arange(52, 86, 0.25)
    z = np.array([top[i, int(round((x - x0) / st))] for x in xs])
    lin = np.polyfit(xs, z, 1)
    print("y", y, "fit slope", np.round(lin, 4))
    for k in range(0, len(xs), 8):
        print("  " + " ".join(f"{xs[j]:.2f}:{z[j]:.2f}({z[j]-np.polyval(lin, xs[j]):+.2f})" for j in range(k, min(k + 8, len(xs)))))
