import numpy as np, matplotlib.pyplot as plt
from g1lib import *
vA, fA = crop("A_shoulder_up"); vB, fB = crop("B_shoulder_lo"); cv, cf = cad()
rows = []
for sgn in (1, -1):
    for (vv, ff, yc) in ((vA, fA, 62), (vB, fB, -63)):
        rows.append((sgn, vv, ff, yc))
zs = [0.8, -1, -5, -12, -20, -28, -36]
fig, axs = plt.subplots(len(rows), len(zs) + 1, figsize=(4 * (len(zs) + 1), 4 * len(rows)))
for i, (sgn, vv, ff, yc) in enumerate(rows):
    for j, z in enumerate(zs):
        ax = axs[i, j]
        s = sec2(vv, ff, 2, z); s[:, :, 0] *= sgn
        c = sec2(cv, cf, 2, z); c[:, :, 0] *= sgn
        draw(ax, c, "#777777", 0.8); draw(ax, s, "#e08a00", 1.2)
        setup(ax, (135, 170, yc - 17.5, yc + 17.5), f"{'RL'[sgn<0]} z={z}")
    ax = axs[i, -1]
    s = sec2(vv, ff, 1, yc); s[:, :, 0] *= sgn
    c = sec2(cv, cf, 1, yc); c[:, :, 0] *= sgn
    draw(ax, c, "#777777", 0.8); draw(ax, s, "#e08a00", 1.2)
    setup(ax, (130, 170, -50, 5), f"{'RL'[sgn<0]} y={yc} (x right, z up)")
fig.tight_layout(); fig.savefig("f14_explore.png", dpi=55)
