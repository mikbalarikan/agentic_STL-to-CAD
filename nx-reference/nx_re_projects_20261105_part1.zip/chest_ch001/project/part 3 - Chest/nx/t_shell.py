"""Test: NX Shell of the half envelope at several wall thicknesses (for the stepped pad bodies). args: out"""
import sys, os, time
OUT = sys.argv[1]
sys.argv = [sys.argv[0], OUT, "A"]
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "build.py"), encoding="utf-8").read())
res["shell_test"] = []
for T in (4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 17.0):
    t0 = time.time()
    try:
        ef2, (cp,) = nxf.extract_body(part, [envx])
        w, op, s_, p_, c_ = shell_faces(cp)
        nxf.shell(part, cp, op, str(T), inward=True)
        v = nxh.volume(part, cp); ok = nxh.body_ok(part, cp)
        res["shell_test"].append([T, "ok", round(v), ok, round(time.time() - t0, 1)])
    except Exception as e:  # noqa: BLE001
        res["shell_test"].append([T, "FAIL " + str(e)[:200], round(time.time() - t0, 1)])
    nxh.write_json(os.path.join(OUT, "build.json"), res)
nxh.save(part)
