"""Clean design-intent features for nx/build_clean.py (work/clean/features.json, written by work/clean/make_spec.py).
Every profile is made of lines, arcs and circles with round values; sloped tops are planes; pockets keep a constant
wall; repeated slots are NX Pattern Features."""
import math
import NXOpen
import nxh, nxf

BOOL = nxh.BOOL


def _arc(part, c, r, a0, a1, z):
    while a1 <= a0:
        a1 += 2 * math.pi
    return nxh.arc(part, (c[0], c[1], z), (1, 0, 0), (0, 1, 0), r, a0, a1)


def _poly(part, pts, z):
    n = len(pts)
    return [nxh.line(part, (pts[i][0], pts[i][1], z), (pts[(i + 1) % n][0], pts[(i + 1) % n][1], z)) for i in range(n)]


def rect_curves(part, x0, x1, y0, y1, r, z):
    if r <= 0:
        return _poly(part, [(x0, y0), (x1, y0), (x1, y1), (x0, y1)], z)
    cs = [nxh.line(part, (x0 + r, y0, z), (x1 - r, y0, z)), nxh.line(part, (x1, y0 + r, z), (x1, y1 - r, z)),
          nxh.line(part, (x1 - r, y1, z), (x0 + r, y1, z)), nxh.line(part, (x0, y1 - r, z), (x0, y0 + r, z))]
    h = math.pi / 2
    cs += [_arc(part, (x1 - r, y0 + r), r, -h, 0, z), _arc(part, (x1 - r, y1 - r), r, 0, h, z),
           _arc(part, (x0 + r, y1 - r), r, h, 2 * h, z), _arc(part, (x0 + r, y0 + r), r, 2 * h, 3 * h, z)]
    return cs


def rib_pts(p0, p1, t):
    d = (p1[0] - p0[0], p1[1] - p0[1]); L = math.hypot(*d); u = (d[0] / L, d[1] / L); n = (-u[1] * t / 2, u[0] * t / 2)
    return [(p0[0] + n[0], p0[1] + n[1]), (p1[0] + n[0], p1[1] + n[1]), (p1[0] - n[0], p1[1] - n[1]), (p0[0] - n[0], p0[1] - n[1])]


def slot_curves(part, c, L, w, ang, z):
    a = math.radians(ang); u = (math.cos(a), math.sin(a)); v = (-u[1], u[0]); h = L / 2 - w / 2; r = w / 2
    e1 = (c[0] + h * u[0], c[1] + h * u[1]); e2 = (c[0] - h * u[0], c[1] - h * u[1])
    cs = [nxh.line(part, (e2[0] + r * v[0], e2[1] + r * v[1], z), (e1[0] + r * v[0], e1[1] + r * v[1], z)),
          nxh.line(part, (e1[0] - r * v[0], e1[1] - r * v[1], z), (e2[0] - r * v[0], e2[1] - r * v[1], z))]
    cs += [_arc(part, e1, r, a - math.pi / 2, a + math.pi / 2, z), _arc(part, e2, r, a + math.pi / 2, a + 1.5 * math.pi, z)]
    return cs


def obround2_curves(part, c0, r0, c1, r1, z):
    """Two circles joined by their outer tangents (a tapered slot)."""
    d = (c1[0] - c0[0], c1[1] - c0[1]); L = math.hypot(*d); u = (d[0] / L, d[1] / L); w = (-u[1], u[0])
    a = (r0 - r1) / L; b = math.sqrt(1 - a * a)
    np_ = (a * u[0] + b * w[0], a * u[1] + b * w[1]); nm = (a * u[0] - b * w[0], a * u[1] - b * w[1])
    cs = [nxh.line(part, (c0[0] + r0 * np_[0], c0[1] + r0 * np_[1], z), (c1[0] + r1 * np_[0], c1[1] + r1 * np_[1], z)),
          nxh.line(part, (c0[0] + r0 * nm[0], c0[1] + r0 * nm[1], z), (c1[0] + r1 * nm[0], c1[1] + r1 * nm[1], z))]
    ap, am = math.atan2(np_[1], np_[0]), math.atan2(nm[1], nm[0])
    cs += [_arc(part, c0, r0, ap, am, z), _arc(part, c1, r1, am, ap, z)]
    return cs, (c0[0], c0[1], z)


def lowvent_curves(part, o, z):
    xt, yt, xs, ych, ya, yb = o["x_top"], o["y_top"], o["x_side"], o["y_ch"], o["y_arc"], o["y_bot"]
    # centre (0, yc) of the arc through (+-xs, ya) and (0, yb): xs^2 + (ya-yc)^2 = (yb-yc)^2
    yc = (xs * xs + ya * ya - yb * yb) / (2.0 * (ya - yb))
    R = abs(yb - yc)
    cs = _poly(part, [(-xt, yt), (xt, yt), (xs, ych), (xs, ya)], z)[:3]
    cs += [nxh.line(part, (-xs, ya, z), (-xs, ych, z)), nxh.line(part, (-xs, ych, z), (-xt, yt, z))]
    a_r = math.atan2(ya - yc, xs); a_l = math.atan2(ya - yc, -xs)
    cs.append(_arc(part, (0.0, yc), R, a_l, a_r, z))
    return cs, (0.0, yt, z)


def bodies(f):
    return [b for b in f.GetBodies() if b.IsSolidBody]


def prism(part, curves, hp, z0, z1):
    f = nxh.extrude(part, nxh.section(part, curves=curves, help_point=hp), (0, 0, 1), 0, z1 - z0)
    return bodies(f)


def cone(part, c, d0, d1, z0, z1):
    b = part.Features.CreateConeBuilder(NXOpen.Features.Cone.Null)
    try:
        b.Type = NXOpen.Features.ConeBuilder.Types.DiametersAndHeight
        b.Axis = nxh.axis(part, (c[0], c[1], z0), (0, 0, 1))
        b.BaseDiameter.RightHandSide = str(d0)
        b.TopDiameter.RightHandSide = str(d1)
        b.Height.RightHandSide = str(z1 - z0)
        b.BooleanOption.Type = BOOL.Create
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return bodies(f)


def halfspace(part, p, n, size=900.0):
    """Solid on the side of the plane (p, n) that n points to: a square on the plane extruded along n."""
    n = [v / math.sqrt(sum(w * w for w in n)) for v in n]
    a = (1.0, 0.0, 0.0) if abs(n[0]) < 0.9 else (0.0, 1.0, 0.0)
    u = (n[1] * a[2] - n[2] * a[1], n[2] * a[0] - n[0] * a[2], n[0] * a[1] - n[1] * a[0])
    lu = math.sqrt(sum(v * v for v in u)); u = tuple(v / lu for v in u)
    v = (n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0])
    s = size / 2
    corners = [tuple(p[k] + su * s * u[k] + sv * s * v[k] for k in range(3)) for su, sv in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    cs = [nxh.line(part, corners[i], corners[(i + 1) % 4]) for i in range(4)]
    f = nxh.extrude(part, nxh.section(part, curves=cs, help_point=corners[0]), tuple(n), 0, size)
    return bodies(f)


def cut_planes(part, tools, planes):
    for pl in planes:
        for t in tools:
            hs = halfspace(part, pl["p"], pl["n"])
            nxh.subtract(part, t, hs, check=False)
    return tools


def mx(p):
    return [-p[0]] + list(p[1:])


def mirror_spec(F):
    """The -x image of a feature spec (for R features built after the mirror, not used for stage F)."""
    import copy
    G = copy.deepcopy(F)
    for k in ("p0", "p1", "c"):
        if k in G:
            G[k] = mx(G[k])
    if "x0" in G:
        G["x0"], G["x1"] = -F["x1"], -F["x0"]
    if "pts" in G:
        G["pts"] = [mx(p) for p in F["pts"]][::-1]
    for pl in G.get("planes", []):
        pl["p"] = mx(pl["p"]); pl["n"] = mx(pl["n"])
    if "ang" in G:
        G["ang"] = 180.0 - F["ang"]
    if "dir" in G:
        G["dir"] = mx(G["dir"])
    return G


def tool_bodies(part, F):
    """Unclipped tool bodies of a rib / rect / poly / cyl / cone / hole feature (planes applied)."""
    t = F["type"]; z0, z1 = F["z0"], F["z1"]
    if t == "rib":
        pts = rib_pts(F["p0"], F["p1"], F["t"])
        bs = prism(part, _poly(part, pts, z0), pts[0] + (z0,), z0, z1)
    elif t == "rect":
        bs = prism(part, rect_curves(part, F["x0"], F["x1"], F["y0"], F["y1"], F.get("r", 0.0), z0), (F["x0"] + 0.01, F["y0"] + 0.01 + F.get("r", 0.0), z0), z0, z1)
    elif t == "poly":
        bs = prism(part, _poly(part, F["pts"], z0), tuple(F["pts"][0]) + (z0,), z0, z1)
    elif t in ("cyl", "hole"):
        f, c = nxh.cylinder(part, (F["c"][0], F["c"][1], z0), (0, 0, 1), F["d"], z1 - z0)
        bs = [c]
    elif t == "cone":
        bs = cone(part, F["c"], F["d0"], F["d1"], z0, z1)
    elif t == "arcrib":              # constant-thickness rib along an arc: two concentric arcs + two radial lines
        c, r, h = F["c"], F["r"], F["t"] / 2.0
        a0, a1 = math.radians(F["a0"]), math.radians(F["a1"])
        pe = [(c[0] + rr * math.cos(a), c[1] + rr * math.sin(a)) for a in (a0, a1) for rr in (r - h, r + h)]
        cs = [_arc(part, c, r + h, a0, a1, z0), _arc(part, c, r - h, a0, a1, z0),
              nxh.line(part, pe[0] + (z0,), pe[1] + (z0,)), nxh.line(part, pe[2] + (z0,), pe[3] + (z0,))]
        bs = prism(part, cs, pe[1] + (z0,), z0, z1)
    else:
        raise ValueError(t)
    if F.get("planes"):
        cut_planes(part, bs, F["planes"])
    return bs


def cap_bodies(part, F):
    """The part of a cone above z -1 (it stands above the rim plane, outside the envelope): same cone surface."""
    z0, z1 = F["z0"], F["z1"]
    k = (F["d1"] - F["d0"]) / (z1 - z0)
    dm = F["d0"] + k * (-1.0 - z0)
    return cone(part, F["c"], dm, F["d1"], -1.0, z1)


def clip(part, bs, env):
    out = []
    for b in bs:
        fi = nxh.intersect(part, b, [env], check=False, keep_tool=True)
        out += bodies(fi)
    return out


def pocket_tools(part, F, log):
    """(inner wall body, void body) of a constant-wall exterior pocket. Void = outline extruded through the skin with
    draft, minus everything beyond the floor planes; wall body = the same, profile offset by the wall and planes
    moved by the wall (it is clipped by the envelope and united before the void is cut)."""
    o = F["outline"]; zs = F["zs"]; w = F["wall"]
    res = []
    for off in (w, 0.0):
        if o["kind"] == "obround2":
            cs, hp = obround2_curves(part, o["c0"], o["r0"] + off, o["c1"], o["r1"] + off, zs)
        elif o["kind"] == "poly":
            cs, hp = _poly(part, o["pts"], zs), tuple(o["pts"][0]) + (zs,)
        else:
            cs, hp = lowvent_curves(part, o, zs)
        sec = nxh.section(part, curves=cs, help_point=hp)
        best = None
        for sgn in ((1.0, -1.0) if (off > 0 and o["kind"] != "obround2") else (None,)):
            m = nxh.mark("pocket", False)
            f = nxf.extrude_ex(part, sec, (0, 0, 1), start=-60.0, end=80.0, draft=F["draft"],
                               single_offset=(sgn * off if sgn is not None else None))
            b = bodies(f)[0]
            v = nxh.volume(part, b)
            if sgn is None:
                best = b; break
            if best is None or v > best[1]:
                if best is not None:
                    nxf.delete_body(part, [best[0]])
                best = (b, v)
            else:
                nxf.delete_body(part, [b])
        b = best[0] if isinstance(best, tuple) else best
        planes = [{"p": [pl["p"][k] + off * pl["n"][k] for k in range(3)], "n": pl["n"]} for pl in F["planes"]]
        cut_planes(part, [b], planes)
        log(f"{F['id']}: {'wall' if off else 'void'} tool {nxh.volume(part, b):.0f} mm3")
        res.append(b)
    return res[0], res[1]


def slot_pattern(part, body, F, log):
    """First slot = Extrude (subtract) from a line/arc slot sketch, then Pattern Feature linear n x pitch."""
    cs = slot_curves(part, F["c"], F["len"], F["w"], F["ang"], F["z0"])
    sec = nxh.section(part, curves=cs, help_point=(F["c"][0], F["c"][1], F["z0"]))
    f = nxf.extrude_ex(part, sec, (0, 0, 1), start=0, end=F["z1"] - F["z0"], op=BOOL.Subtract, target=body)
    nm = "n_" + F["id"]
    nxh.expr(part, nm, F["n"], None)
    try:
        pf = nxf.pattern_linear(part, [f], (F["dir"][0], F["dir"][1], 0.0), nm, F["pitch"])
        log(f"{F['id']}: Pattern Feature {F['n']} x {F['pitch']}")
        return "pattern"
    except Exception as e:  # noqa: BLE001
        log(f"{F['id']}: Pattern Feature failed ({str(e)[:100]}); explicit instances")
        for k in range(1, F["n"]):
            c = (F["c"][0] + k * F["pitch"] * F["dir"][0], F["c"][1] + k * F["pitch"] * F["dir"][1])
            cs = slot_curves(part, c, F["len"], F["w"], F["ang"], F["z0"])
            nxf.extrude_ex(part, nxh.section(part, curves=cs, help_point=(c[0], c[1], F["z0"])), (0, 0, 1),
                           start=0, end=F["z1"] - F["z0"], op=BOOL.Subtract, target=body)
        return "instances"
