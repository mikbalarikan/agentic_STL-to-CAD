"""CH-001 Rev B: clean continuous neck band and bottom-end band (2026-10-31, user: "continuity, one U-shaped surface").
Appended at the END of the user's history on a COPY of Deviation_Check/CH-001_Chest_RevB_vs_SCAN_END_POSTS.prt (08:10).
args: src_prt dst_prt

1 NECK_LIP_R / NECK_LIP_L: thin Extrude (3.0 into the wall, from 1 below the edge to 5.5 above it, along +z) of the
  neck inner edge + the edge up to the rim, one per side, each trimmed exactly at x 0 (NECK_LIP_*_HALF) and united:
  together one continuous U band from rim to rim (a single chain is refused by NX at x 0).
2 NECK_U_BOTTOM: the bottom of the U is lowered to the scan with ONE smooth cut: a Studio Spline in the x-z plane
  through the scan's band top (z -88.4 at x 0 ... -73.9 at +-44, then above the band) extruded along -y over y 64..36;
  it meets the band top tangentially near |x| 44, so the band runs on without a step.
3 END_TRIM: one planar cut of the bottom end at y -272.9: a single continuous end band from rim to rim (it takes the
  corner relief corners, the end chamfers and the old end face off together)."""
import os, sys, math, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, os.path.join(os.path.dirname(os.environ["NXH_DIR"].rstrip("\\/")), "..", "nx-curves-and-sketches", "scripts"))
import NXOpen
import nxh, nxf, nxre
import curvekit as ck

SRC, DST = sys.argv[1], sys.argv[2]
OUT = os.path.dirname(DST)
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": []}
log = res["log"].append
LIP_T, LIP_H, LIP_BELOW = 3.0, 5.5, 1.0
U_PTS = [(0.0, -88.42), (20.0, -87.2), (32.0, -84.9), (38.0, -82.3), (42.0, -78.1), (46.0, -68.3), (50.0, -55.5)]
U_Y0, U_Y1, U_ZTOP = 64.0, 36.0, -30.0
END_Y = -275.0


def fvol(part, body, acc=0.99):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


def is_conv(b):
    try:
        return bool(b.IsConvergentBody)
    except Exception:  # noqa: BLE001
        return False


def inside(part, b, xyz):
    return nxh.dist_to(part, b, xyz) < 1e-4


def new_solids(part, before):
    tags = {b.Tag for b in before}
    return [b for b in part.Bodies if b.IsSolidBody and b.Tag not in tags]


try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)
    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: fvol(part, b))
    res["features_before"] = len(list(part.Features))
    res["errors_before"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    D = nxh.Datums(part)
    E = {k: nxh.expr(part, nm, val, comment=cm).Name for k, nm, val, cm in (
        ("T", "CH_NECK_LIP_T", LIP_T, "neck band thickness (from the neck cut face into the wall)"),
        ("H", "CH_NECK_LIP_H", LIP_H, "neck band height above the inner neck edge (along z)"),
        ("Y", "CH_END_Y", END_Y, "bottom end plane"))}

    find = lambda mid: [e for e in body.GetEdges() if math.dist(nxh.edge_points(e, n=3)[1], mid) < 0.3]
    mR, tR = find((47.57, 70.39, -71.02)), find((56.38, 109.1, -8.82))
    mL, tL = find((-47.57, 70.39, -71.02)), find((-56.38, 109.1, -8.82))
    log(f"neck edges: main R {len(mR)} top R {len(tR)} main L {len(mL)} top L {len(tL)}")
    assert len(mR) == len(tR) == len(mL) == len(tL) == 1

    # ------------------------------------------------ 1 neck band, two halves meeting on x 0
    # each half ends exactly on x 0, where the two end faces meet only along an edge (NX refuses that); the U-bottom
    # cut below takes the whole band height off for |x| < ~30, so each half is trimmed at |x| 20 instead
    X_HALF = 20.0
    for side, es, sx in (("R", mR + tR, 1.0), ("L", mL + tL, -1.0)):
        _, pl0 = nxh.datum_plane(part, (sx * X_HALF, 0, 0), (sx, 0, 0), name=f"NECK_LIP_{side}_END_PLANE")
        q_in, q_out = (sx * 48.9, 69.5, -69.5), (sx * 46.4, 70.4, -69.5)
        made = None
        for thin in ((0, E["T"]), (f"-{E['T']}", 0)):
            mk = nxh.mark("thin", False)
            before = list(part.Bodies)
            try:
                f = nxf.extrude_ex(part, nxh.section(part, edges=es, help_point=tuple(nxh.edge_points(es[0], n=3)[1])),
                                   (0, 0, 1), start=-LIP_BELOW, end=E["H"], thin=thin)
            except Exception as ex:  # noqa: BLE001
                log(f"{side}: thin {thin} failed: {str(ex)[:100]}")
                nxh.undo_to(mk)
                continue
            bs = new_solids(part, before)
            if bs and any(inside(part, x, q_in) for x in bs) and not any(inside(part, x, q_out) for x in bs):
                made = (f, bs, thin)
                break
            nxh.undo_to(mk)
        assert made is not None, f"neck band {side} not made"
        f, bs, thin = made
        f.SetName(f"NECK_LIP_{side}")
        for x in bs:
            mk = nxh.mark("half", False)
            ftb, _ = nxf.trim_body(part, x, datum_plane=pl0, reverse=True)       # keeps the arm side (|x| > 20)
            if not inside(part, x, q_in):
                nxh.undo_to(mk)
                ftb, _ = nxf.trim_body(part, x, datum_plane=pl0, reverse=False)
            assert inside(part, x, q_in), f"band {side} lost its arm"
            ftb.SetName(f"NECK_LIP_{side}_HALF")
        fu = nxh.unite(part, body, tools=bs, check=False)
        fu.SetName(f"NECK_LIP_{side}_UNITE")
        log(f"NECK_LIP_{side}: thin {thin}, trimmed on x 0, united")

    # ------------------------------------------------ 2 smooth U-bottom cut
    pts = [(-x, U_Y0, z) for x, z in reversed(U_PTS[1:])] + [(x, U_Y0, z) for x, z in U_PTS]
    fs, spl = ck.studio_spline(part, pts, degree=3)
    if fs is not None:
        fs.SetName("NECK_U_BOTTOM_CURVE")
    xe, ze = U_PTS[-1]
    ln = [nxh.line(part, (xe, U_Y0, ze), (xe, U_Y0, U_ZTOP)), nxh.line(part, (xe, U_Y0, U_ZTOP), (-xe, U_Y0, U_ZTOP)),
          nxh.line(part, (-xe, U_Y0, U_ZTOP), (-xe, U_Y0, ze))]
    sec = nxh.section(part, curves=[spl] + ln, help_point=(0.0, U_Y0, U_ZTOP))
    v0 = fvol(part, body)
    fcut = nxf.extrude_ex(part, sec, (0, -1, 0), start=0, end=U_Y0 - U_Y1, op=BOOL.Subtract, target=body)
    fcut.SetName("NECK_U_BOTTOM")
    log(f"U bottom cut: {v0 - fvol(part, body):.0f} mm3 (0.99 volume, noisy)")
    pr = {"u_mid_above_scan": nxh.dist_to(part, body, (0.0, 41.0, -87.6)),        # just above the scan's top: air
          "u_mid_below": nxh.dist_to(part, body, (0.0, 39.5, -90.0)),             # in the wall: inside
          "arm_band_R": nxh.dist_to(part, body, (48.9, 69.5, -69.5)), "arm_band_L": nxh.dist_to(part, body, (-48.9, 69.5, -69.5)),
          "rim_band_R": nxh.dist_to(part, body, (57.4, 109.1, -6.0))}

    # ------------------------------------------------ 2b bottom-end corners, built from the scan's face structure
    # (an/r1_segment.py, an/r1_cornerz.py, an/r1_cornerfit.py): rim .. z -24 = post r 3.05 (59.55, -264.6) with a free
    # east side (slot to the side wall) + straight wall L1 (x 56.5) tangent to its west side + diagonal wall L2 to the end
    # tip; below -24 = the cone (CORNER_POST_TAPER, already in the history) + L2 / U wall; L2 = the curl plane.
    # CORNER_FILL_UPPER / _LOWER close the old voids (relief, Rev A slit) inside the outer skin, CORNER_CUT (one
    # drafted profile: L1 + post arc + slot + side wall) and END_CURL_R/L (the plane) give the inner surface.
    DRAFT = 3.0
    PC, PR = (59.55, -264.6), 3.05
    _, plu = nxh.datum_plane(part, (0, 0, 0.0), (0, 0, 1), name="CORNER_FILL_UPPER_PLANE")
    sku = nxf.new_sketch(part, plu, D.x, nxh.point(part, 0, 0, 0.0), name="CORNER_FILL_UPPER_SKETCH")
    for sx in (1.0, -1.0):
        q = [(54.5, -259.5), (54.5, -269.5), (62.8, -276.3), (73.0, -266.0), (66.0, -264.0), (61.0, -259.0)]
        if sx < 0:
            q = q[::-1]
        nxf.add(sku, *nxh.polyline(part, [(sx * x, y, 0.0) for x, y in q]), infer=True)
    nxf.finish_sketch(sku)
    fu1 = nxf.extrude_ex(part, nxh.section_feature(part, [sku.Feature]), (0, 0, -1), start=0, end=24.0, op=BOOL.Unite, target=body)
    fu1.SetName("CORNER_FILL_UPPER")
    # lower fill: z -24 .. -46, extruded along a tilted direction so its outer edge follows the outer skin inwards
    dL = (-0.108, 0.120, -1.0)
    _, pll2 = nxh.datum_plane(part, (0, 0, -24.0), (0, 0, 1), name="CORNER_FILL_LOWER_PLANE")
    for side, sx in (("R", 1.0), ("L", -1.0)):
        skl2 = nxf.new_sketch(part, pll2, D.x, nxh.point(part, 0, 0, -24.0), name=f"CORNER_FILL_LOWER_{side}_SKETCH")
        q = [(52.5, -267.6), (61.0, -267.6), (63.5, -266.8), (70.0, -268.2), (63.2, -276.0), (52.5, -276.0)]
        if sx < 0:
            q = q[::-1]
        nxf.add(skl2, *nxh.polyline(part, [(sx * x, y, -24.0) for x, y in q]), infer=True)
        nxf.finish_sketch(skl2)
        fl2 = nxf.extrude_ex(part, nxh.section_feature(part, [skl2.Feature]), (sx * dL[0], dL[1], dL[2]), start=0,
                             end=round(22.0 * math.sqrt(sum(c * c for c in dL)), 3), op=BOOL.Unite, target=body)
        fl2.SetName(f"CORNER_FILL_LOWER_{side}")
    # drafted cut: the cavity side of L1 + post arc + slot + side wall, rim .. z -24
    _, plk = nxh.datum_plane(part, (0, 0, 0.0), (0, 0, 1), name="CORNER_CUT_PLANE")
    for side, sx in (("R", 1.0), ("L", -1.0)):
        skk = nxf.new_sketch(part, plk, D.x, nxh.point(part, 0, 0, 0.0), name=f"CORNER_CUT_{side}_SKETCH")
        a20 = (PC[0] + PR * math.cos(math.radians(20)), PC[1] + PR * math.sin(math.radians(20)))
        chain = [(PC[0] - PR, PC[1]), (56.5, -268.3), (45.0, -271.0), (45.0, -250.0), (77.5, -250.0), (77.5, -256.2),
                 (64.6, -266.9), (63.0, -266.6), a20]
        pts = [(sx * x, y, 0.0) for x, y in chain]
        cs = [nxh.line(part, pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
        if sx > 0:
            cs.append(nxh.arc(part, (PC[0], PC[1], 0.0), (1, 0, 0), (0, 1, 0), PR, math.radians(20), math.radians(180)))
        else:
            cs.append(nxh.arc(part, (-PC[0], PC[1], 0.0), (1, 0, 0), (0, 1, 0), PR, 0.0, math.radians(160)))
        nxf.add(skk, *cs, infer=True)
        stk = nxf.finish_sketch(skk)
        fk = nxf.extrude_ex(part, nxh.section_feature(part, [skk.Feature]), (0, 0, -1), start=0, end=24.0,
                            op=BOOL.Subtract, target=body, draft=DRAFT)
        fk.SetName(f"CORNER_CUT_{side}")
        log(f"CORNER_CUT_{side}: sketch {stk['status']} n_geom {stk['n_geom']}")
    # L2 = the scan's curl plane (n (-0.5432, -0.8343, 0.0938)): cut along it, rim .. z -46
    nC = (-0.5432, -0.8343, 0.0938)
    dC = [0.0, 0.0, -1.0]
    k_ = sum(dC[i] * nC[i] for i in range(3))
    dC = [dC[i] - k_ * nC[i] for i in range(3)]
    ln_ = math.sqrt(sum(c * c for c in dC)); dC = [c / ln_ for c in dC]
    ZS, ZB = 2.0, -46.0
    y50 = -265.30 + 0.651 * 4.0
    x280 = 54.0 + (280.0 - 265.30) / 0.651
    _, plc = nxh.datum_plane(part, (0, 0, ZS), (0, 0, 1), name="END_CURL_PLANE")
    for side, sx in (("R", 1.0), ("L", -1.0)):
        skc = nxf.new_sketch(part, plc, D.x, nxh.point(part, 0, 0, ZS), name=f"END_CURL_{side}_SKETCH")
        tri = [(sx * 50.0, y50, ZS), (sx * 50.0, -280.0, ZS), (sx * x280, -280.0, ZS)]
        nxf.add(skc, *nxh.polyline(part, tri), infer=True)
        nxf.finish_sketch(skc)
        fc_ = nxf.extrude_ex(part, nxh.section_feature(part, [skc.Feature]), (sx * dC[0], dC[1], dC[2]), start=0,
                             end=round((ZS - ZB) / -dC[2], 3), op=BOOL.Subtract, target=body)
        fc_.SetName(f"END_CURL_{side}")
    # below z -46 the Rev A gap between the post and the end web runs on: END_CURL_FILL_LOWER (west edge = plane trace)
    ty = lambda x: -270.69 - 0.651 * (x - 54.0)
    _, pll = nxh.datum_plane(part, (0, 0, -46.0), (0, 0, 1), name="END_CURL_FILL_LOWER_PLANE")
    skl = nxf.new_sketch(part, pll, D.x, nxh.point(part, 0, 0, -46.0), name="END_CURL_FILL_LOWER_SKETCH")
    for sx in (1.0, -1.0):
        q = [(53.5, ty(53.5)), (55.7, ty(55.7)), (56.5, ty(55.7)), (56.5, -268.0), (53.5, -268.0)]
        if sx < 0:
            q = q[::-1]
        nxf.add(skl, *nxh.polyline(part, [(sx * x, y, -46.0) for x, y in q]), infer=True)
    nxf.finish_sketch(skl)
    fl = nxf.extrude_ex(part, nxh.section_feature(part, [skl.Feature]), (0, 0, -1), start=0, end=14.0, op=BOOL.Unite, target=body)
    fl.SetName("END_CURL_FILL_LOWER")
    # the post bores (D3, eccentric as Rev A) re-cut through the fills
    _, plb = nxh.datum_plane(part, (0, 0, 0.5), (0, 0, 1), name="CORNER_BORE_PLANE")
    skb = nxf.new_sketch(part, plb, D.x, nxh.point(part, 0, 0, 0.5), name="CORNER_BORE_SKETCH")
    for sx in (1.0, -1.0):
        nxf.sketch_circle(part, skb, nxh.point(part, sx * 59.3, -265.8, 0.5), "3.0")
    nxf.finish_sketch(skb)
    fb_ = nxf.extrude_ex(part, nxh.section_feature(part, [skb.Feature]), (0, 0, -1), start=0, end=60.5, op=BOOL.Subtract, target=body)
    fb_.SetName("CORNER_BORE")

    # ------------------------------------------------ 3 planar bottom end
    _, ple = nxh.datum_plane(part, (0, END_Y, 0), (0, 1, 0), name="END_TRIM_PLANE")
    sq = [(-200, -200), (200, -200), (200, 50), (-200, 50)]
    cs = [nxh.line(part, (sq[i][0], END_Y, sq[i][1]), (sq[(i + 1) % 4][0], END_Y, sq[(i + 1) % 4][1])) for i in range(4)]
    v1 = fvol(part, body)
    fe = nxf.extrude_ex(part, nxh.section(part, curves=cs, help_point=(-200, END_Y, -200)), (0, -1, 0), start=0, end=40,
                        op=BOOL.Subtract, target=body)
    fe.SetName("END_TRIM")
    log(f"END_TRIM at y {END_Y}: {v1 - fvol(part, body):.0f} mm3")
    pr["end_band_arm_R"] = nxh.dist_to(part, body, (65.0, END_Y + 0.5, -20.0))
    pr["end_band_bottom"] = nxh.dist_to(part, body, (0.0, END_Y + 0.5, -84.5))
    pr["slot_open_z10"] = nxh.dist_to(part, body, (63.6, -265.0, -10.0))      # slot east of the post: air
    pr["post_north_z10"] = nxh.dist_to(part, body, (59.55, -262.0, -10.0))   # post: inside
    pr["L1_west_z10"] = nxh.dist_to(part, body, (55.8, -266.5, -10.0))      # west of L1: air
    pr["web_z10"] = nxh.dist_to(part, body, (60.0, -268.5, -10.0))          # web: inside
    pr["skin_out_z40"] = nxh.dist_to(part, body, (62.5, -274.0, -40.0))     # outside the outer skin: air
    pr["curl_web_gone_z44"] = nxh.dist_to(part, body, (57.0, -272.4, -44.0))   # SW of the plane: air (> 0)
    pr["curl_fill_z30"] = nxh.dist_to(part, body, (61.3, -272.4, -30.0))       # NE of the plane, was over-cut: inside
    pr["post_top"] = nxh.dist_to(part, body, (57.3, -267.5, -3.0))             # post near the rim: inside
    pr["bore_top"] = nxh.dist_to(part, body, (59.3, -265.8, -5.0))             # bore: air
    pr["slit_closed_z30"] = nxh.dist_to(part, body, (56.0, -270.5, -30.0))     # old slit: inside now
    pr["gap_closed_z52"] = nxh.dist_to(part, body, (55.0, -270.5, -52.0))      # old gap: inside now
    pr["outer_ok_z56"] = nxh.dist_to(part, body, (57.5, -272.5, -60.0)); pr["outer_ok2"] = nxh.dist_to(part, body, (56.5, -272.3, -59.0))        # outside the skin: still air
    pr["cavity_z10"] = nxh.dist_to(part, body, (53.0, -268.5, -10.0))          # cavity side of the plane: air
    res["probes"] = pr

    res["solids_after"] = len([bb for bb in part.Bodies if bb.IsSolidBody and not bb.IsBlanked and not is_conv(bb)])
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["features_after"] = len(list(part.Features))
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["new_features"] = [g.GetFeatureName() + " / " + g.Name for g in list(part.Features)[res["features_before"]:]]
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    res["stl"] = nxre.stl_export(part, body, os.path.join(OUT, "chest_R13.stl"), chord=0.01, max_edge=2.5)
    ok = res["body_ok"] and res["solids_after"] == 1 and len(res["errors_after"]) <= len(res["errors_before"])
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_clean13.json", res)
