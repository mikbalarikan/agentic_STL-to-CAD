# -*- coding: utf-8 -*-
"""CH-001 Chest (front shell): manufacturing drawing set, third angle, A1.
run_journal dwg_chest.py -args <model.prt> <out_dir> [dump|full]
Master-model drawing; the model is placed with drawing (X, Y, Z) = model (-x, z, y), so the NX Front view shows the
exterior face-on (model +y up), the Right view the profile (rim plane = right-hand vertical edge), the Back view the
interior. M(x, y, z) maps a MODEL point to drawing-part coordinates.
Datums: A = rim (parting) plane, B = right shoulder bore Ø111, C = left shoulder bore Ø111.
SH1 general arrangement 1:2, SH2 front panel 1:1 (sections B-B through the hole, C-C through the recess),
SH3 shoulder flanges (section D-D through both bore centres), SH4 interior features (balloons + location table)."""
import json
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXD_DIR"])
sys.path.insert(0, r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest\nx\dwglib")
import NXOpen  # noqa: E402
import NXOpen.Annotations  # noqa: E402
import nxh  # noqa: E402
import nxd  # noqa: E402
import nxd2  # noqa: E402
import ptdwg  # noqa: E402
import m3d  # noqa: E402
import gdt  # noqa: E402
from m3d import D, N, xy  # noqa: E402

MODEL, OUTD = sys.argv[1], sys.argv[2]
MODE = sys.argv[3] if len(sys.argv) > 3 else "full"
os.makedirs(OUTD, exist_ok=True)
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest"
NO, TITLE = "CH-001", "CHEST - FRONT SHELL"
PJ = json.load(open(os.path.join(ROOT, "nx", "params.json")))
FIN = json.load(open(os.path.join(os.path.dirname(MODEL), "_finalize.json")))
MASS = "%.2f kg" % (FIN["mass_g_al6061"] / 1000.0)
MAT = "Al 6061-T6"
R = [[-1.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, 1.0, 0.0]]
S = nxd.SNAP
A = NXOpen.Annotations
DT = 5.0        # dimension text
GT = 4.5        # notes, GD&T frames, datum letters
DIA = "Ø"
res = {"result": "FAIL", "dims": {}, "errors": {}, "gdt": {}}
m3d.start(res)
_style0 = ptdwg._style
ptdwg._style = lambda b, prec=2, text_size=None: _style0(b, prec, text_size or DT)
SH = PJ["shoulder"]; PN = PJ["panel"]
XC = SH["xc"]; BORE = SH["bore_d"]


def M(x, y, z):
    return (-x, z, y)


def note_lines(lines, x, y, step=8.0, size=GT):
    for i, t in enumerate(lines):
        if t:
            N("note_%d_%d" % (int(x), int(y - i * step)), lambda t=t, i=i: nxd.note(m3d.CTX["dwg"], [t], (x, y - i * step), size=size))


def table(origin, cw, rows, size=3.5, rh=8.0):
    m = [(0, 0, 0, len(cw) - 1)]
    _ts, tn = nxd2.table(m3d.CTX["dwg"], origin, cw, [rh] * len(rows), rows, text_size=size, merges=m, sizes={(0, 0): size})
    return nxd2.table_text(tn)


def dumpv(tag, v):
    res["dump_" + tag] = m3d.dump(v, os.path.join(OUTD, "dump_%s.json" % tag))


try:
    dwg, comp = m3d.new_drawing(os.path.join(OUTD, NO + "_dwg.prt"), MODEL, "CHEST", R, refset="SOLID")
    sheets = []
    # ================================================================ SHEET 1 general arrangement (A1, 1:2)
    sh1, _g = ptdwg.sheet(dwg, "A1"); sheets.append(sh1)
    front = nxd.base_view(dwg, dwg, "Front", (205.0, 300.0), scale=(1.0, 2.0))
    right = nxd.base_view(dwg, dwg, "Right", (360.0, 300.0), scale=(1.0, 2.0))     # base views: projected views
    top = nxd.base_view(dwg, dwg, "Top", (205.0, 480.0), scale=(1.0, 2.0))         # do not inherit the 1:2 scale
    iso = nxd.base_view(dwg, dwg, "Isometric", (640.0, 390.0), scale=(1.0, 3.0))
    res["views1"] = {v.Name: nxd.view_info(v) for v in (front, right, top, iso)}
    res["tb1"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:2 (iso 1:3)", 1, 4, rev="A", subtitle="general arrangement")
    dumpv("sh1_front", front); dumpv("sh1_right", right); dumpv("sh1_top", top)

    # ================================================================ SHEET 2 front panel (A1, 1:1)
    sh2, _g = ptdwg.sheet(dwg, "A1"); sheets.append(sh2)
    f2 = nxd.base_view(dwg, dwg, "Front", (232.0, 300.0), scale=(1.0, 1.0))
    secB = N("secB", lambda: nxd2.section(dwg, f2, M(0.0, PN["hole_c"][1], -120.0), (615.0, 480.0), (1.0, 1.0)))
    secC = N("secC", lambda: nxd2.section(dwg, f2, M(0.0, PN["circle_c"][1], -120.0), (615.0, 250.0), (1.0, 1.0)))
    res["views2"] = {v.Name: nxd.view_info(v) for v in (f2, secB, secC) if v is not None}
    res["tb2"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 2, 4, rev="A", subtitle="front panel")
    dumpv("sh2_front", f2)
    if secB is not None: dumpv("sh2_secB", secB)
    if secC is not None: dumpv("sh2_secC", secC)

    # ================================================================ SHEET 3 shoulder flanges (A1)
    sh3, _g = ptdwg.sheet(dwg, "A1"); sheets.append(sh3)
    f3 = nxd.base_view(dwg, dwg, "Front", (150.0, 420.0), scale=(1.0, 3.0))
    secD = N("secD", lambda: nxd2.section(dwg, f3, M(0.0, 0.0, -60.0), (450.0, 200.0), (1.0, 1.0)))
    r3 = nxd.base_view(dwg, dwg, "Right", (770.0, 400.0), scale=(1.0, 2.0))
    res["views3"] = {v.Name: nxd.view_info(v) for v in (f3, secD, r3) if v is not None}
    res["tb3"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1 (D-D), 1:2, 1:3", 3, 4, rev="A", subtitle="shoulder flanges")
    if secD is not None: dumpv("sh3_secD", secD)
    dumpv("sh3_right", r3)

    # ================================================================ SHEET 4 interior features (A1, 1:1)
    sh4, _g = ptdwg.sheet(dwg, "A1"); sheets.append(sh4)
    back = nxd.base_view(dwg, dwg, "Back", (235.0, 300.0), scale=(1.0, 1.0))
    res["views4"] = {v.Name: nxd.view_info(v) for v in (back,)}
    res["tb4"] = ptdwg.title_block(dwg, "A1", TITLE, NO, MAT, MASS, "1:1", 4, 4, rev="A", subtitle="interior features")
    dumpv("sh4_back", back)

    if MODE != "dump":
        exec(open(os.path.join(ROOT, "nx", "dwg_annot.py"), encoding="utf-8").read())
    for i, sh in enumerate(sheets, 1):
        res["overlaps%d" % i] = nxd.overlaps(sh)
    res["export"] = ptdwg.export(dwg, sheets, OUTD, NO)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUTD, "dwg_result.json"), res)
