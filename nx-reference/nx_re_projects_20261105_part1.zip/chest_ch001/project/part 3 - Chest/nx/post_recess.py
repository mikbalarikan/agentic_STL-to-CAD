"""Deep exterior pockets after a build: recess.json levels >= D0 (the core offset of recess_half() fails from D 7.0:
"a face no longer intersects a previous neighbor"). Those levels lie inside regions already cut by the shallower
levels, so a plain Shell slab of the half envelope (wall D) is used as the cut volume: prism (Z -200..0) intersected
with the slab, tools mirrored about the mid-plane, subtracted. The half envelope `envh` is the blanked solid of the
build part whose box starts at x 0.  args: built_prt out_dir D1,D2,... (the levels whose core offset failed)"""
import os, sys, math, json, time
SRC, OUTD = sys.argv[1], sys.argv[2]
DLIST = [float(t) for t in sys.argv[3].split(",")]          # the failed levels
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "build.py"), encoding="utf-8").read()
sys.argv = [sys.argv[0], OUTD, "Z"]
exec(src[:src.index("\npart = None\n")])          # imports, helpers, log(), shell_faces(), seg_curves() ...
import shutil
os.makedirs(OUTD, exist_ok=True)
dst = os.path.join(OUTD, "Chest.prt")
shutil.copyfile(SRC, dst)
part = nxh.open_part(dst)
PN = P["panel"]; g = PN["dzdy"]; cosg = 1.0 / math.sqrt(1.0 + g * g)
npn = (0.0, -g * cosg, cosg); z_ext = PN["z_int_at_y_m100"] - PN["t_panel"] / cosg
yc = PN["circle_c"][1]; z_cf = PN["z_circle_int_at_c"] - PN["t_disc"] / cosg
a = math.radians(P["shoulder"]["angle_deg"]); nsh = (math.cos(a), math.sin(a), 0.0)
try:
    sol = [b for b in part.Bodies if b.IsSolidBody]
    body = max([b for b in sol if not b.IsBlanked], key=lambda b: nxh.volume(part, b))
    halves = sorted([b for b in sol if b.IsBlanked], key=lambda b: nxh.bbox(b)[0] + nxh.bbox(b)[3])   # NX boxes are padded: the half envelope has the box centre furthest to +x
    log(f"body {nxh.volume(part, body):.0f}; blanked solids {[[round(v) for v in nxh.bbox(b)] for b in halves]}")
    envh = halves[-1]
    dat = nxh.Datums(part)
    D = json.load(open(os.path.join(WK, "recess.json")))
    tools = []
    for k, T in enumerate(D["levels"]):
        if not any(abs(T - d_) < 1e-6 for d_ in DLIST):
            continue
        loops = [L for L in D["loops"] if L["k"] == k]
        if not loops:
            continue
        cp = None
        for dT in (0.0, 0.05, -0.05, 0.1, -0.1, 0.15):        # NX refuses some thicknesses ("Cannot apply Shell")
            ef2, (cp,) = nxf.extract_body(part, [envh])
            cp.Blank()
            _w, op_faces, _s, _p, _c = shell_faces(cp)
            try:
                nxf.shell(part, cp, op_faces, str(round(T + dT, 3)), inward=True)
                log(f"deep recess level {T}: shell {T + dT:.2f}")
                break
            except Exception as e:  # noqa: BLE001
                log(f"deep recess level {T}: shell {T + dT:.2f} refused")
                nxf.delete_body(part, [cp]); cp = None
        if cp is None:
            continue
        nt = 0
        for L in loops:
            cs = seg_curves(part, L["segs"], -200.0)
            for H in L["holes"]:
                cs += seg_curves(part, H, -200.0)
            f = nxh.extrude(part, nxh.section(part, curves=cs, help_point=tuple(L["segs"][0][1]) + (-200.0,)), (0, 0, 1), 0, 200.0)
            for pb in [b_ for b_ in f.GetBodies() if b_.IsSolidBody]:
                before = {b_.Tag for b_ in part.Bodies}
                nxh.intersect(part, pb, [cp], check=False, keep_tool=True)
                got = [b_ for b_ in part.Bodies if b_.IsSolidBody and (b_.Tag == pb.Tag or b_.Tag not in before) and b_.Tag != cp.Tag]
                tools += got; nt += len(got)
        nxf.delete_body(part, [cp])
        log(f"deep recess level {T}: {len(loops)} loops, {nt} tools")
    fm, mt = nxf.mirror_geometry(part, tools, dat.yz)
    tools += [b_ for b_ in mt if b_.IsSolidBody]
    nxh.subtract(part, body, tools, check=False)
    log(f"deep recesses subtracted ({len(tools)} tools); body {nxh.volume(part, body):.0f}")
    left = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and b.Tag != body.Tag]
    if left:
        log(f"loose after subtract {[round(nxh.volume(part, b)) for b in left]}")
        nxf.delete_body(part, left)
    nxh.save(part); log("saved")
    nxre.stl_export(part, body, os.path.join(OUTD, "chest_G.stl"), chord=0.01, max_edge=2.0)
    res["body_ok"] = [nxh.body_ok(part, body)]
    res["result"] = "PASS"
    log("STL exported")
except Exception:
    import traceback
    res["error"] = traceback.format_exc(); log("ERROR")
nxh.write_json(os.path.join(OUTD, "build.json"), res)
