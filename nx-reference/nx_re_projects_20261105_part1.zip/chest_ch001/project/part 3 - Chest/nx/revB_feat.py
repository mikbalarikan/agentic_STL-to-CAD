"""CH-001 Rev B: the features the user marked on the scan overlay (2026-10-31), appended at the END of the Rev A
history on a COPY of deliver/CAD/CH-001_Chest.prt (the source is never written).
args: src_prt dst_prt spec_json (work/r1/spec_r1.json, written by an/r1_prep.py)

1 TAB_C_NOTCH_RL / TAB_C_NOTCH_T11: half-round channel R3.5 in the hole-facing face of the 3 clip tabs, from the
  tab top down to its floor (sketch: circles on a plane at the tab top, Extrude subtract).
2 RIM_LIP_nn: thin tongue on the inner edge of every rim face (z 0): Extrude of the inner rim edges, thin wall
  0 / 1.2 outward, height 1.7.
3 SIDE_PAD_R + SIDE_PAD_RIB_R: raised pad on the lower side wall (one sketch: outer loop + 6 window loops, lines and
  tangent arcs) extruded from the inner wall face to an Offset Surface 2.0 of it; rib = band along its lower edge
  to an Offset Surface 2.9 (from the side tube to the boss pair).
4 BOSS_LOBE_R + LOCATING_PIN_R: lobe D5 on the lower boss pair and the D2.6 pin on it, top R0.6.
5 Mirror Geometry of the pad, rib, lobe and pin about the YZ plane, then one Unite.
"""
import os, sys, json, math, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, DST, SPEC = sys.argv[1:4]
OUT = os.path.dirname(DST)
BOOL = nxh.BOOL
ET = nxf.ET
res = {"result": "FAIL", "log": []}
log = res["log"].append
sp = json.load(open(SPEC))


def fvol(part, body, acc=0.99):
    """Volume at accuracy 0.99 (nxh.volume uses 0.999999: tens of minutes on this B-surface body)."""
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


nxh.volume = fvol


def add3(a, b, s=1.0):
    return [a[i] + s * b[i] for i in range(3)]


def is_conv(b):
    try:
        return bool(b.IsConvergentBody)
    except Exception:  # noqa: BLE001
        return False


def inside(part, body, xyz):
    return nxh.dist_to(part, body, xyz) < 1e-4


def extrude_between(part, sec, vec, start_face, end_face, op=None, target=None, kind=ET.UntilExtended):
    b = part.Features.CreateExtrudeBuilder(nxf.NF)
    try:
        b.Section = sec
        b.Direction = nxf._direction(part, vec)
        op = BOOL.Create if op is None else op
        b.BooleanOperation.Type = op
        if op != BOOL.Create:
            b.BooleanOperation.SetTargetBodies([target])
        b.Limits.StartExtend.TrimType = kind
        b.Limits.StartExtend.Target = start_face
        b.Limits.EndExtend.TrimType = kind
        b.Limits.EndExtend.Target = end_face
        return b.CommitFeature()
    finally:
        b.Destroy()


def new_solids(part, before):
    tags = {b.Tag for b in before}
    return [b for b in part.Bodies if b.IsSolidBody and b.Tag not in tags]


try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)
    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: fvol(part, b))
    res["body"] = body.Name
    res["features_before"] = len(list(part.Features))
    res["errors_before"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    v0 = fvol(part, body)
    res["vol_before"] = v0
    D = nxh.Datums(part)

    E = {}
    for k, nm, val, cm in (("LIP_H", "CH_RIM_LIP_H", sp["lip"]["h"], "rim lip height above the rim plane"),
                           ("LIP_T", "CH_RIM_LIP_T", sp["lip"]["t"], "rim lip thickness (from the inner edge out)"),
                           ("PAD_T", "CH_SIDE_PAD_T", sp["pad"]["t"], "lower side pad thickness on the inner wall"),
                           ("RIB_T", "CH_SIDE_RIB_T", sp["rib"]["t"], "side pad rib height on the inner wall"),
                           ("NOTCH_R", "CH_TAB_NOTCH_R", sp["notches"][0]["r"], "clip tab C notch radius"),
                           ("LOBE_D", "CH_BOSS_LOBE_D", sp["lobe"]["d"], "lobe on the lower boss pair"),
                           ("PIN_D", "CH_PIN_D", sp["pin"]["d"], "locating pin diameter"),
                           ("PIN_H", "CH_PIN_H", sp["pin"]["z1"] - sp["pin"]["z0"], "locating pin height above the boss top")):
        E[k] = nxh.expr(part, nm, val, comment=cm).Name

    # ---------------------------------------------------------------- 1 tab C notches
    def notch_feature(name, items, z_floor):
        z_top = items[0]["z_top"]
        _, pl = nxh.datum_plane(part, (0, 0, z_top), (0, 0, 1), name=name + "_PLANE")
        sk = nxf.new_sketch(part, pl, D.x, nxh.point(part, 0, 0, z_top), name=name + "_SKETCH")
        for it in items:
            nxf.sketch_circle(part, sk, nxh.point(part, it["c"][0], it["c"][1], z_top), f"2*{E['NOTCH_R']}")
        st = nxf.finish_sketch(sk)
        sec = nxh.section_feature(part, [sk.Feature])
        vb = fvol(part, body)
        f = nxf.extrude_ex(part, sec, (0, 0, -1), start=0, end=round(z_top - z_floor, 3), op=BOOL.Subtract, target=body)
        f.SetName(name)
        va = fvol(part, body)
        log(f"{name}: sketch {st['status']} dof {st['dof']}, removed {vb - va:.1f} mm3, to z {z_floor}")
        return vb - va

    nr = [n_ for n_ in sp["notches"] if n_["id"] in ("R", "L")]
    nt = [n_ for n_ in sp["notches"] if n_["id"] == "T11"]
    res["notch_RL"] = notch_feature("TAB_C_NOTCH_RL", nr, -125.2)
    res["notch_T11"] = notch_feature("TAB_C_NOTCH_T11", nt, -122.4)
    # probe: the channel is open at mid height, the tab behind it is solid
    pr = {}
    for it in sp["notches"]:
        c = it["c"]
        pr[it["id"] + "_open"] = nxh.dist_to(part, body, (c[0], c[1], -115.0))
    pr["R_tab_back"] = nxh.dist_to(part, body, (33.5, -125.9, -115.0))
    res["notch_probes"] = pr
    log(f"notch probes {pr}")

    # ---------------------------------------------------------------- 2 rim lip
    cell = {}
    for p in sp["lip"]["pts"]:
        cell.setdefault((int(math.floor(p[0])), int(math.floor(p[1]))), []).append(p)

    def near_lip(x, y, r=0.8):
        ix, iy = int(math.floor(x)), int(math.floor(y))
        for i in (ix - 1, ix, ix + 1):
            for j in (iy - 1, iy, iy + 1):
                for q in cell.get((i, j), ()):
                    if (q[0] - x) ** 2 + (q[1] - y) ** 2 < r * r:
                        return True
        return False

    rim = []
    for fc in body.GetFaces():
        bb = nxh.bbox(fc)
        if abs(bb[2]) < 0.02 and abs(bb[5]) < 0.02 and (bb[3] - bb[0]) + (bb[4] - bb[1]) > 5:
            nn = nxh.normal_at(fc, ((bb[0] + bb[3]) / 2, (bb[1] + bb[4]) / 2, 0.0))
            if nn[2] > 0.9:
                rim.append(fc)
    log(f"rim faces at z 0: {len(rim)}")
    groups = []
    for fc in rim:
        bb = nxh.bbox(fc)
        if bb[0] < 0:                       # right side only: the left lips are mirrored with the side features
            continue
        inner = []
        for e in fc.GetEdges():
            pts = nxh.edge_points(e, n=9)
            frac = sum(1 for p in pts if near_lip(p[0], p[1], 1.2)) / len(pts)
            L = sum(math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))
            if frac >= 0.7 and L > 1.0:
                inner.append(e)
        if inner:
            groups.append((fc, inner, bb))
        log(f"rim face bbox {[round(x, 1) for x in bb]}: {len(inner)} inner edges of {len(fc.GetEdges())}")
    lip_feats, lips_R = [], []
    for k, (fc, inner, bb) in enumerate(groups):
        # probe at the middle of the longest inner edge: which side is the rim face
        e0 = max(inner, key=lambda e: math.dist(*[nxh.edge_points(e, n=2)[i] for i in (0, 1)]))
        pts = nxh.edge_points(e0, n=11)
        m, a, b2 = pts[5], pts[4], pts[6]
        t = [b2[0] - a[0], b2[1] - a[1]]; lt = math.hypot(*t); t = [t[0] / lt, t[1] / lt]
        pdir = [-t[1], t[0]]
        on_face = nxh.dist_to(part, fc, (m[0] + 0.6 * pdir[0], m[1] + 0.6 * pdir[1], 0.0)) < 1e-3
        s = pdir if on_face else [-pdir[0], -pdir[1]]
        q_in = (m[0] + 0.6 * s[0], m[1] + 0.6 * s[1], 0.85)
        q_out = (m[0] - 0.6 * s[0], m[1] - 0.6 * s[1], 0.85)
        done = None
        for thin in ((0, E["LIP_T"]), (f"-{E['LIP_T']}", 0)):
            mk = nxh.mark("lip", False)
            before = list(part.Bodies)
            try:
                sec = nxh.section(part, edges=inner, help_point=tuple(m))
                f = nxf.extrude_ex(part, sec, (0, 0, 1), start=0, end=E["LIP_H"], thin=thin)
            except Exception as ex:  # noqa: BLE001
                log(f"lip {k}: thin {thin} failed: {str(ex)[:120]}")
                nxh.undo_to(mk)
                continue
            lb_ = new_solids(part, before)
            if lb_ and any(inside(part, b, q_in) for b in lb_) and not any(inside(part, b, q_out) for b in lb_):
                done = (f, thin)
                lips_R += lb_
                break
            log(f"lip {k}: thin {thin} on the wrong side, undo")
            nxh.undo_to(mk)
        if done is None:
            log(f"lip {k}: NOT MADE (face bbox {[round(x, 1) for x in bb]})")
            continue
        f, thin = done
        f.SetName(f"RIM_LIP_{k + 1:02d}")
        lip_feats.append(f.Name)
        log(f"RIM_LIP_{k + 1:02d}: {len(inner)} edges, thin {thin}, face bbox {[round(x, 1) for x in bb]}")
    res["lips"] = lip_feats
    v1 = fvol(part, body)
    res["vol_after_lips"] = v1

    # ---------------------------------------------------------------- 3 side pad + rib (right), as tool bodies
    fr = sp["frame"]
    c0, n, u, v = fr["c0"], fr["n"], fr["u"], fr["v"]
    O = add3(c0, n, -45.0)

    def to3(q):
        return [O[i] + q[0] * u[i] + q[1] * v[i] for i in range(3)]

    def seg_curves(segs):
        cs = []
        for s in segs:
            if s[0] == "L":
                cs.append(nxh.line(part, to3(s[1]), to3(s[2])))
            else:
                cs.append(nxh.arc(part, to3(s[1]), u, v, s[2], s[3], s[4]))
        return cs

    p_in = fr["p_in"]
    dw = sorted(((nxh.dist_to(part, fc, p_in), i, fc) for i, fc in enumerate(body.GetFaces())), key=lambda t_: t_[:2])
    log(f"inner wall face nearest p_in at {dw[0][0]:.4f} mm (next {dw[1][0]:.4f})")
    assert dw[0][0] < 0.05, "no inner wall face at p_in"
    wall = dw[0][2]
    p_in = list(nxh.UFS.Modeling.AskFaceProps(wall.Tag, nxh.UFS.Modeling.AskFaceParm(wall.Tag, [float(x) for x in p_in])[0])[0])
    nw = nxh.normal_at(wall, p_in)
    res["wall_normal"] = [round(x, 4) for x in nw]
    log(f"inner wall normal at p_in {res['wall_normal']} (spec n {[round(x, 3) for x in n]})")

    # Offset Surface of the whole inner shell face fails ("could not be offset": tight curvature elsewhere), so
    # the pad tops are offsets of a patch of it: Extract Face, Trim Sheet to a rectangle round the pad (along n)
    EFB = NXOpen.Features.ExtractFaceBuilder
    eb = part.Features.CreateExtractFaceBuilder(nxf.NF)
    try:                                  # fixed at this timestamp: the chest is united with the pad later
        eb.ParentPart = EFB.ParentPartType.WorkPart
        eb.Type = EFB.ExtractType.Face
        eb.FaceOption = EFB.FaceOptionType.SingleFace
        eb.ObjectToExtract.Add(wall)
        eb.Associative = True
        eb.FixAtCurrentTimestamp = True
        eb.HideOriginal = False
        fe = eb.CommitFeature()
    finally:
        eb.Destroy()
    fe.SetName("SIDE_PAD_WALL_EXTRACT")
    wsheet = [b for b in fe.GetBodies()][0]
    rq = [(-78, -52), (93, -52), (93, 54), (-78, 54)]
    rc = [nxh.line(part, to3(rq[i]), to3(rq[(i + 1) % 4])) for i in range(4)]
    ft = nxf.trim_sheet(part, wsheet, p_in, keep=True, curves=rc, vec=n)
    ft.SetName("SIDE_PAD_WALL_PATCH")
    patch = list(wsheet.GetFaces())
    wsheet.Blank()
    log(f"wall patch: {len(patch)} faces")

    def offset_sheet(dist_expr, dist_val, name):
        f = nxf.offset_surface(part, patch, dist_expr)
        sh = [b for b in f.GetBodies()][0]
        target = add3(p_in, nw, dist_val)
        d = nxh.dist_to(part, sh, target)
        if d > 0.1:
            nxh.S.UpdateManager.AddObjectsToDeleteList([f]); nxh.S.UpdateManager.DoUpdate(nxh.mark("del"))
            f = nxf.offset_surface(part, patch, dist_expr, flip=True)
            sh = [b for b in f.GetBodies()][0]
            d = nxh.dist_to(part, sh, target)
        f.SetName(name)
        sh.Blank()
        log(f"{name}: sheet at {d:.4f} mm from p_in + {dist_val} n")
        return f, sh.GetFaces()[0]

    f_off2, face2 = offset_sheet(E["PAD_T"], sp["pad"]["t"], "SIDE_PAD_TOP_OFFSET")
    f_off3, face3 = offset_sheet(E["RIB_T"], sp["rib"]["t"], "SIDE_RIB_TOP_OFFSET")
    _, plR = nxh.datum_plane(part, O, n, name="SIDE_PAD_PLANE")
    axR = nxf.datum_axis(part, "point_dir", O, u, name="SIDE_PAD_U_AXIS")[1]

    def pad_body(name, loops, face_top):
        sk = nxf.new_sketch(part, plR, axR, nxh.point(part, *O), name=name + "_SKETCH")
        for lp in loops:
            nxf.add(sk, *seg_curves(lp), infer=True)
        st = nxf.finish_sketch(sk)
        sec = nxh.section_feature(part, [sk.Feature])
        before = list(part.Bodies)
        try:
            f = extrude_between(part, sec, n, patch[0], face_top)
            how = "until extended"
        except Exception as ex:  # noqa: BLE001
            log(f"{name}: until extended failed ({str(ex)[:100]}), until selected")
            f = extrude_between(part, sec, n, patch[0], face_top, kind=ET.UntilSelected)
            how = "until selected"
        f.SetName(name)
        bs = new_solids(part, before)
        vol = sum(fvol(part, b) for b in bs)
        log(f"{name}: sketch {st['status']} dof {st['dof']} n_geom {st['n_geom']}, {how}, {len(bs)} body, {vol:.0f} mm3")
        return bs, vol

    pad, res["pad_vol"] = pad_body("SIDE_PAD_R", [sp["pad"]["outer"]] + list(sp["pad"]["windows"].values()), face2)
    rib, res["rib_vol"] = pad_body("SIDE_PAD_RIB_R", [sp["rib"]["loop"]], face3)

    # ---------------------------------------------------------------- 4 lobe + pin (right)
    lb, pn = sp["lobe"], sp["pin"]
    _, plZ = nxh.datum_plane(part, (0, 0, lb["z_top"]), (0, 0, 1), name="BOSS_TOP_PLANE")
    sk = nxf.new_sketch(part, plZ, D.x, nxh.point(part, 0, 0, lb["z_top"]), name="BOSS_LOBE_R_SKETCH")
    nxf.sketch_circle(part, sk, nxh.point(part, lb["c"][0], lb["c"][1], lb["z_top"]), E["LOBE_D"])
    st1 = nxf.finish_sketch(sk)
    before = list(part.Bodies)
    f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature]), (0, 0, -1), start=0, end=round(lb["z_top"] - lb["z_bot"], 3))
    f.SetName("BOSS_LOBE_R")
    lobe = new_solids(part, before)
    sk = nxf.new_sketch(part, plZ, D.x, nxh.point(part, 0, 0, pn["z0"]), name="LOCATING_PIN_R_SKETCH")
    nxf.sketch_circle(part, sk, nxh.point(part, pn["c"][0], pn["c"][1], pn["z0"]), E["PIN_D"])
    st2 = nxf.finish_sketch(sk)
    before = list(part.Bodies)
    f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature]), (0, 0, 1), start=0, end=E["PIN_H"])
    f.SetName("LOCATING_PIN_R")
    pin = new_solids(part, before)
    top = [e for e in pin[0].GetEdges() if abs(nxh.bbox(e)[2] - pn["z1"]) < 0.01 and abs(nxh.bbox(e)[5] - pn["z1"]) < 0.01]
    fb = nxf.edge_blend(part, [(top, pn["r_top"])])
    fb.SetName("LOCATING_PIN_R_TOP")
    log(f"lobe sketch {st1['status']} dof {st1['dof']}, pin sketch {st2['status']} dof {st2['dof']}, pin top edges {len(top)}")

    # ---------------------------------------------------------------- 5 mirror + unite
    tools_R = lips_R + pad + rib + lobe + pin
    fm, mirrored = nxf.mirror_geometry(part, tools_R, D.yz)
    fm.SetName("SIDE_FEATURES_MIRROR")
    mirrored = [b for b in mirrored if b.IsSolidBody]
    log(f"mirror: {len(mirrored)} bodies")
    fu = nxh.unite(part, body, tools=tools_R + mirrored, check=False)
    fu.SetName("SIDE_FEATURES_UNITE")
    v2 = fvol(part, body)
    res["vol_after"] = v2
    res["delta"] = dict(notches=-(res["notch_RL"] + res["notch_T11"]), lip_bodies_R=len(lips_R),
                        side=v2 - v1)
    log(f"volumes: before {v0:.0f}, after lips {v1:.0f}, after side features {v2:.0f}")

    # probes: pad stands 2.0 proud of the wall at p_in (pad is solid there), pin top
    q = add3(p_in, nw, 1.0)
    res["probe_pad_mid"] = nxh.dist_to(part, body, q)
    res["probe_pad_above"] = nxh.dist_to(part, body, add3(p_in, nw, 3.0))
    res["probe_pin_top"] = nxh.dist_to(part, body, (pn["c"][0], pn["c"][1], pn["z1"] - 1.0))
    res["probe_pin_L_top"] = nxh.dist_to(part, body, (-pn["c"][0], pn["c"][1], pn["z1"] - 1.0))

    solids_after = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    res["solids_after"] = len(solids_after)
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["features_after"] = len(list(part.Features))
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["new_features"] = [f.GetFeatureName() + " / " + f.Name for f in list(part.Features)[res["features_before"]:]]
    for b in part.Bodies:
        if not b.IsSolidBody:
            b.Layer = 200
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    stl = os.path.join(OUT, "chest_R1.stl")
    res["stl"] = nxre.stl_export(part, body, stl, chord=0.01, max_edge=2.5)
    ok = res["body_ok"] and res["solids_after"] == 1 and len(res["errors_after"]) <= len(res["errors_before"])
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_revB_feat.json", res)
