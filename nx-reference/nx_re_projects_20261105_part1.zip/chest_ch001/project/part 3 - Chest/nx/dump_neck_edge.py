"""Read-only: 400 points along the right neck inner edge and the top-end edge to the rim. args: prt out_json"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import nxh

PRT, OUT = sys.argv[1], sys.argv[2]
res = {}
try:
    part = nxh.open_part(PRT)
    sol = [b for b in part.Bodies if b.IsSolidBody and not getattr(b, "IsConvergentBody", False)]
    body = max(sol, key=lambda b: len(b.GetFaces()))
    find = lambda mid: [e for e in body.GetEdges() if math.dist(nxh.edge_points(e, n=3)[1], mid) < 0.3]
    res["main"] = [[round(c, 4) for c in p] for p in nxh.edge_points(find((47.57, 70.39, -71.02))[0], n=400)]
    res["top"] = [[round(c, 4) for c in p] for p in nxh.edge_points(find((56.38, 109.1, -8.82))[0], n=60)]
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
