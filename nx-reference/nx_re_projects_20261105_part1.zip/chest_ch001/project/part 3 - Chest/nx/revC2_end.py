﻿"""CH-001 Rev C: bottom end (joint to the hip part) rebuilt in the user's order (2026-10-31): the two long screw bosses
and everything the earlier corner fixes added go first, then the end joint face and the walls are made clean and
continuous, and the screw bosses come back last as clean features. Appended after nx/revC1_neck.py.
args: src_prt (the revC1 result) dst_prt

Scan analysis (an/r2_secs.py, r1_segment.py endR, an/r2_endfit.py):
- the shell wall runs straight to the end; the scan's end is at y -275.1 .. -275.6 -> one planar joint face at
  y CH_END_JOINT_Y = -275.3 (datum END_JOINT_PLANE)
- boss: rim .. z -14 r 3.05 -> 3.26, flares between z -18 and -30, then a cone r 5.55 (z -30) -> 7.41 (z -62) on
  (59.2, -265.7), merging into the side wall; bore D3.1 at (59.25, -265.9)
- web from the boss to the end tip: plane n (-0.5384, -0.8383, 0.0854) through (59.77, -271.52, -19.49), sd 0.34
- the last ~9 mm (between the transverse rib at y -266.3 and the joint plane) is a thickened joint flange: flat top
  z -82.5 at the bottom centre, ~5 mm wall round the U corners, tapering to the tip at the joint plane
Features (named END_*):
1 END_SKIN_UNTRIM + END_SKIN_TRIM_*: the outer skin face untrimmed (the old END_CORNER_RELIEF had cut it at the
  corner tips) and cut back to |x| < 82, y -240 .. -275.6 (Rev A skin end: no extrapolated surface), z < 6.
  END_WALL_3_25 / END_LIP_5 / END_LIP_DEEP / END_OUTSIDE_SKIN: Thickens of it (wall, lip, 12 mm for the flat floor,
  10 mm outward = "outside the skin"), trimmed on the rim.
2 END_CLEAR: ONE region subtracted: the whole end band (|x| < 72, y < -266.3) + round each old post (revolve about the
  boss axis, old post + 0.1) + the old slit / relief pocket: old posts, fills, curl cuts, slit, relief, chamfers go.
  Put back: plain wall (END_WALL) everywhere in it, the 5 mm lip in the band (END_LIP) and the flat floor below
  z -82.5 (END_LIP_FLAT): the walls, the joint flange and the inner surfaces run on unbroken.
3 END_BOSS_R/L (last): ONE revolve per corner united straight into the body, concentric with the screw hole, smooth
  spline profile r 3.5 at the rim -> 8.9 at z -86 (0.05 over the old post below z -30, so nothing old shows).
  END_BOSS_WEB_R/L: one extrude in the web plane (its south-west face IS the plane), boss line y -266.8 .. joint plane.
  END_SLOT_SIDE_R/L (slot south wall, leaning 0.06/mm as on the scan, rim .. z -37) and END_SLOT_FLOOR_R/L (z -37 ..
  -63, between boss and wall). END_RIB_R/L: the long rib (x 58.5..60, top z -77.2) run on into the boss.
  END_SKIN_CLIP: everything outside the outer skin goes. END_JOINT_CUT: one plane, y CH_END_JOINT_Y -> the datum
  joint face END_JOINT_PLANE round the whole U. END_BOSS bores D CH_END_BORE_D, rim .. z -60."""
import os, sys, math, json, shutil, traceback, time
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, os.path.join(os.path.dirname(os.environ["NXH_DIR"].rstrip("\\/")), "..", "nx-curves-and-sketches", "scripts"))
import NXOpen
import nxh, nxf, nxre
import curvekit as ck

SRC, DST = sys.argv[1], sys.argv[2]
STOP = sys.argv[3] if len(sys.argv) > 3 else "Z"
OUT = os.path.dirname(DST)
os.makedirs(OUT, exist_ok=True)
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": [], "probes": {}}
T0 = time.time()
JS = os.path.splitext(DST)[0] + "_end.json"
END_Y = -275.3
WALL = 3.25
# corner region cleared: everything round the old post (r 7.6 about the boss axis on its north-east side, so the side
# wall's pad / recess north of y -264.3 is not touched) and between the post and the end; it crosses the side wall
# south of the pad
PRISM = [(-72.0, -282.0), (72.0, -282.0), (72.0, -270.0), (69.0, -262.5), (50.0, -266.3), (-50.0, -266.3), (-69.0, -262.5),
         (-72.0, -270.0)]                                         # the whole end band + the corners (old slit / relief)
BAND = [(-72.0, -282.0), (72.0, -282.0), (72.0, -266.3), (-72.0, -266.3)]
LIP_T, LIP_TOP = 5.0, -82.5
# + the old post itself: a revolve about the boss axis, r = the old post (Rev A D8.6 eccentric + CORNER_POST_TAPER
# r 5.41 at z -26 -> 7.44 at z -62) + 0.1; the new boss is 0.05 bigger again below z -30, so it covers it exactly
CLEAR_RZ = [(5.60, 3.0), (5.60, -26.0), (5.74, -30.0), (7.54, -62.0), (8.89, -86.0)]
RIB_X, RIB_Y, RIB_TOP = (58.5, 60.0), (-259.5, -245.5), -77.2      # scan: the long rib runs on into the boss
BOSS_AX = (59.2, -265.75)
BORE_C, BORE_D = (59.25, -265.9), 3.1
# boss profile r(z): rim 3.5 (scan 3.05..3.26 north-west, the concentric boss covers the eccentric scan post),
# flare z -18..-30, cone 5.55 -> 7.41 (scan), into the bottom wall
BOSS_RZ = [(3.50, 0.0), (3.58, -10.0), (3.75, -17.0), (4.55, -23.5), (5.79, -30.0), (6.35, -40.0), (7.03, -52.0),
           (7.59, -62.0), (8.15, -72.0), (8.94, -86.0)]
WEB_N, WEB_P = (-0.5384, -0.8383, 0.0854), (59.77, -271.52, -19.49)


def log(m):
    res["log"].append(f"[{time.time() - T0:5.0f}s] {m}")
    nxh.write_json(JS, res)


def is_conv(b):
    try:
        return bool(b.IsConvergentBody)
    except Exception:  # noqa: BLE001
        return False


def fvol(part, body, acc=0.99):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


def inside(part, b, xyz):
    return nxh.dist_to(part, b, xyz) < 1e-4


def new_bodies(part, before, solid=None):
    tags = {b.Tag for b in before}
    return [b for b in part.Bodies if b.Tag not in tags and (solid is None or b.IsSolidBody == solid)]


def prism(part, pts, z0, z1, sx, name):
    q = [(sx * x, y, z0) for x, y in pts]
    if sx < 0:
        q = q[::-1]
    cs = [nxh.line(part, q[i], q[(i + 1) % len(q)]) for i in range(len(q))]
    before = list(part.Bodies)
    f = nxh.extrude(part, nxh.section(part, curves=cs, help_point=q[0]), (0, 0, 1), 0, z1 - z0)
    f.SetName(name)
    return new_bodies(part, before, True)[0]


def copy_of(part, b, name):
    before = list(part.Bodies)
    f, _ = nxf.extract_body(part, [b])
    f.SetName(name)
    return new_bodies(part, before, True)[0]


try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)
    sol = [b for b in part.Bodies if b.IsSolidBody and not is_conv(b)]
    vis = [b for b in sol if not b.IsBlanked]
    body = max(vis, key=lambda b: fvol(part, b))
    res["features_before"] = len(list(part.Features))
    res["errors_before"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["bodies"] = [{"blanked": b.IsBlanked, "bbox": [round(v, 1) for v in nxh.bbox(b)], "faces": len(b.GetFaces())} for b in sol]
    log(f"solids {len(sol)}: {res['bodies']}")
    # The delivered part has no hidden Rev A envelope any more: the clean wall is made from the part's own outer skin
    # face (Rev A B-surface, = the shell's outer face): a copy trimmed to each corner box, extended above the rim,
    # thickened inward by the wall (= the shell's inner face) and cut at the rim; outward = "outside the skin".
    _BB = {}

    def faces_at(pts, tol):
        if _BB.get("n") != len(body.GetFaces()):
            _BB["n"] = len(body.GetFaces()); _BB["f"] = [(f_, nxh.bbox(f_)) for f_ in body.GetFaces()]
        out = []
        for pt in pts:
            for f_, bb in _BB["f"]:
                if all(bb[i] - 0.5 <= pt[i] <= bb[i + 3] + 0.5 for i in range(3)) and abs(nxh.dist_to(part, f_, pt)) < tol:
                    if f_.Tag not in [g.Tag for g in out]:
                        out.append(f_)
        return out
    SKIN_PT = [(80.0, -258.8, -30.0), (-80.0, -258.8, -30.0)]          # outer skin of the side walls, clear of the corner
    skf = faces_at(SKIN_PT, 0.4)
    skf.sort(key=lambda f_: -(nxh.bbox(f_)[3] - nxh.bbox(f_)[0]) * (nxh.bbox(f_)[4] - nxh.bbox(f_)[1]))
    log(f"skin faces at the probes: {len(skf)}, biggest bbox {[round(v, 1) for v in nxh.bbox(skf[0])] if skf else None}")
    assert skf, "outer skin face not found"
    E = {k: nxh.expr(part, nm, val, unit=u, comment=cm).Name for k, nm, val, u, cm in (
        ("Y", "CH_END_JOINT_Y", END_Y, "mm", "joint face to the hip part (datum END_JOINT_PLANE)"),
        ("BD", "CH_END_BORE_D", BORE_D, "mm", "screw hole in the end bosses"))}
    v0 = fvol(part, body)
    _, pl_rim = nxh.datum_plane(part, (0, 0, 0.0), (0, 0, 1), name="END_RIM_PLANE")
    # ONE skin copy for the whole end, UNTRIMMED (the old END_CORNER_RELIEF had cut the skin face at the corner tips),
    # cut to |x| < 82, y < -240 and z < 6 (the walls are trimmed on the rim afterwards)
    before = list(part.Bodies)
    ub = part.Features.CreateUntrimBuilder(NXOpen.Features.Feature.Null)
    try:
        ub.FacesToUntrim.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb([skf[0]])], False)
        ub.CommitFeature().SetName("END_SKIN_UNTRIM")
    finally:
        ub.Destroy()
    sk = new_bodies(part, before, False)[0]
    keep = (66.0, -262.4, -30.0)
    for nm_, org, nrm in (("XP", (82.0, 0, 0), (1, 0, 0)), ("XN", (-82.0, 0, 0), (-1, 0, 0)), ("Y0", (0, -240.0, 0), (0, -1, 0)),
                          ("ZT", (0, 0, 6.0), (0, 0, 1)), ("YE", (0, -275.6, 0), (0, 1, 0))):   # YE: Rev A skin end, no extrapolation
        _, pl_ = nxh.datum_plane(part, org, nrm, name=f"END_SKIN_{nm_}")
        kp = tuple(nxh.UFS.Modeling.AskFaceParm(sk.GetFaces()[0].Tag, [float(v) for v in keep])[1])
        mk = nxh.mark("skin trim", False)
        try:
            nxf.trim_sheet(part, sk, kp, keep=True, datum_plane=pl_).SetName(f"END_SKIN_TRIM_{nm_}")
        except Exception as ex:  # noqa: BLE001
            log(f"skin trim {nm_} refused: {str(ex)[:70]}")
            nxh.undo_to(mk)
    log(f"skin copy (untrimmed) area {nxh.sheet_area(part, list(sk.GetFaces()))[0]:.0f}")
    wall_in = (70.0, -267.4, -30.0)        # 1.7 (in y) inside the outer skin at y -269.1
    wall_out = (70.0, -271.0, -30.0)       # outside the skin
    cav = (68.0, -256.0, -30.0)            # cavity side

    def thick(a, name, pin, pout):
        for rev in (False, True):
            mk = nxh.mark("thk", False)
            bf = list(part.Bodies)
            try:
                nxf.thicken(part, sk, a, 0, reverse=rev).SetName(name)
            except Exception as ex:  # noqa: BLE001
                log(f"{name} rev={rev}: {str(ex)[:80]}"); nxh.undo_to(mk); continue
            w = new_bodies(part, bf, True)
            if len(w) == 1 and all(inside(part, w[0], q) for q in pin) and not any(inside(part, w[0], q) for q in pout):
                return w[0]
            nxh.undo_to(mk)
        raise RuntimeError(f"{name}: no side fits")
    W3 = thick(WALL, "END_WALL_3_25", [wall_in], [wall_out, cav])
    W6 = thick(LIP_T, "END_LIP_5", [wall_in], [wall_out, cav])
    WD = thick(12.0, "END_LIP_DEEP", [wall_in], [wall_out])
    OUTALL = thick(10.0, "END_OUTSIDE_SKIN", [wall_out], [wall_in])
    OUTP = {"R": OUTALL}
    for b_ in (W3, W6, WD):
        nxf.trim_body(part, b_, datum_plane=pl_rim, reverse=False)
        if not inside(part, b_, wall_in):
            log("rim trim kept the wrong side")
    # end band = joint flange: 6.0 wall + below the flat lip top z -82.5 (scan: 6.0 +- 0.2 normal at x 38..50, flat
    # -82.5..-83 at the bottom centre), between the transverse rib (y -266.3) and the joint plane
    band = prism(part, BAND, -130.0, 5.0, 1.0, "END_BAND_TOOL")
    band2 = copy_of(part, band, "END_BAND_TOOL_2")
    nxh.intersect(part, W6, [band], check=False).SetName("END_LIP_6_BAND")
    fz, blz = nxh.block(part, (-80.0, -290.0, -140.0), (160.0, 30.0, 140.0 + LIP_TOP))
    nxh.intersect(part, WD, [band2], check=False)
    nxh.intersect(part, WD, [blz], check=False).SetName("END_LIP_FLAT")

    # ---------------------------------------------------------------- 1 + 2 clear the whole end, put it back clean
    clear = prism(part, PRISM, -130.0, 5.0, 1.0, "END_CLEAR_TOOL")
    for side, sx in (("R", 1.0), ("L", -1.0)):
        axc = (sx * BOSS_AX[0], BOSS_AX[1])
        Pc = lambda r, z: (axc[0] + sx * r, axc[1], z)
        qc = [Pc(0.0, CLEAR_RZ[0][1])] + [Pc(r, z) for r, z in CLEAR_RZ] + [Pc(0.0, CLEAR_RZ[-1][1])]
        csc = [nxh.line(part, qc[i], qc[(i + 1) % len(qc)]) for i in range(len(qc))]
        bf_ = list(part.Bodies)
        nxf.revolve(part, nxh.section(part, curves=csc, help_point=Pc(1.0, -30.0)), nxh.axis(part, (axc[0], axc[1], 0.0), (0, 0, 1))).SetName(f"END_CLEAR_{side}_POST")
        nxh.unite(part, clear, [new_bodies(part, bf_, True)[0]], check=False)
    clear2 = copy_of(part, clear, "END_CLEAR_TOOL_2")
    nxh.subtract(part, body, [clear], check=False).SetName("END_CLEAR")
    nxh.intersect(part, W3, [clear2], check=False).SetName("END_WALL_3_25_CUT")
    for nm_, b_ in (("END_WALL", W3), ("END_LIP", W6), ("END_LIP_FLAT", WD)):
        nxh.unite(part, body, [b_], check=False).SetName(nm_ + "_UNITE")
    pieces = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b) and b.Tag != body.Tag
              and b.Tag != OUTALL.Tag]
    log(f"end cleared + wall/lip: {fvol(part, body) - v0:+.0f} mm3, loose solids {[round(fvol(part, b), 1) for b in pieces]}")
    if pieces:
        nxf.delete_body(part, pieces)
    if STOP == "C":
        raise StopIteration    # ---------------------------------------------------------------- 4 + 5 + 6 bosses, webs, bores
    for side, sx in (("R", 1.0), ("L", -1.0)):
        ax0 = (sx * BOSS_AX[0], BOSS_AX[1])
        # profile in the plane y = axis y: radial = +x for R, -x for L
        P3 = lambda r, z: (ax0[0] + sx * r, ax0[1], z)
        top = BOSS_RZ[0]; bot = BOSS_RZ[-1]
        fsp, sp = ck.studio_spline(part, [P3(r, z) for r, z in BOSS_RZ], degree=3)
        if fsp is not None:
            fsp.SetName(f"END_BOSS_{side}_PROFILE")
        cs = [sp, nxh.line(part, P3(*bot), P3(0.0, bot[1])), nxh.line(part, P3(0.0, bot[1]), P3(0.0, top[1])),
              nxh.line(part, P3(0.0, top[1]), P3(*top))]
        before = list(part.Bodies)
        before_boss = list(part.Bodies)
        # revolve united straight into the body (a separate revolved body is refused by Unite: "tool completely outside")
        nf0 = len(nxh.feature_errors(part, recheck=False))
        fr = nxf.revolve(part, nxh.section(part, curves=cs, help_point=P3(1.0, -30.0)), nxh.axis(part, (ax0[0], ax0[1], 0.0), (0, 0, 1)),
                         op=BOOL.Unite, target=body)
        fr.SetName(f"END_BOSS_{side}")
        res.setdefault("boss_unite", []).append({"side": side, "inside": [inside(part, body, q) for q in
                                                 [(sx * 57.0, -265.75, -10.0), (sx * 59.2, -260.5, -40.0)]],
                                                 "new_errors": len(nxh.feature_errors(part, recheck=False)) - nf0})
        log(f"{side}: boss revolve+unite {res['boss_unite'][-1]}")
        boss = None
        # (clipped to the skin AFTER the unite: a boss pre-clipped on the skin surface is refused by the unite)
        # web: ONE extrude united into the body: profile at z 0 = boss line y -266.8, the web plane's trace, the
        # side-wall line x 68.5; extruded down inside the web plane (direction = -z projected on it), so its
        # south-west face IS the web plane
        n_ = (sx * WEB_N[0], WEB_N[1], WEB_N[2]); p_ = (sx * WEB_P[0], WEB_P[1], WEB_P[2])
        k_ = n_[2]                       # d - (d.n) n with d = (0, 0, -1)
        dC = [0.0 + k_ * n_[0], 0.0 + k_ * n_[1], -1.0 + k_ * n_[2]]
        ln_ = math.sqrt(sum(c * c for c in dC)); dC = [c / ln_ for c in dC]
        yat = lambda x, z: p_[1] + (-n_[0] * (x - p_[0]) - n_[2] * (z - p_[2])) / n_[1]      # trace y(x) at height z
        xat = lambda y, z: p_[0] + (-n_[1] * (y - p_[1]) - n_[2] * (z - p_[2])) / n_[0]
        A = (sx * BOSS_AX[0], -266.8); B = (xat(-266.8, 0.0), -266.8); C = (sx * 68.5, yat(sx * 68.5, 0.0)); Dp = (sx * 68.5, -266.8)
        q = [(x, y, 0.0) for x, y in (A, B, C, Dp)]
        cs_w = [nxh.line(part, q[i], q[(i + 1) % 4]) for i in range(4)]
        fw = nxh.extrude(part, nxh.section(part, curves=cs_w, help_point=q[0]), tuple(dC), 0, round(50.0 / abs(dC[2]), 3),
                         op=BOOL.Unite, target=body)
        fw.SetName(f"END_BOSS_WEB_{side}")
        log(f"{side}: web profile {[(round(x, 2), round(y, 2)) for x, y in (A, B, C, Dp)]}, dir {[round(c, 4) for c in dC]}")
        web = None
        # slot floor: on the scan the slot between the boss and the side wall is open from the rim to z ~-28; below
        # it the corner is solid. One extrude, flat top at z -26, inside the boss / wall outline (old Rev A slit gone)
        sq = [(61.5, -270.0), (71.0, -270.0), (71.0, -260.8), (66.6, -263.2), (64.5, -262.6), (62.5, -262.6)]
        sq = [(sx * x, y, -37.0) for x, y in sq]
        css = [nxh.line(part, sq[i], sq[(i + 1) % len(sq)]) for i in range(len(sq))]
        nxh.extrude(part, nxh.section(part, curves=css, help_point=sq[0]), (0, 0, -1), 0, 26.0, op=BOOL.Unite, target=body).SetName(f"END_SLOT_FLOOR_{side}")
        # slot side: the slot's south wall on the scan runs from y -266.6 at the rim to -265.1 at z -25 (leans north
        # 0.06 / mm): one extrude from the rim along that lean down to the slot floor
        ss = [(62.0, -266.6), (70.8, -266.6), (70.8, -271.0), (62.0, -271.0)]
        ss = [(sx * x, y, 0.0) for x, y in ss]
        csd = [nxh.line(part, ss[i], ss[(i + 1) % 4]) for i in range(4)]
        dl = (0.0, 0.06, -1.0); nl = math.sqrt(sum(c * c for c in dl)); dl = tuple(c / nl for c in dl)
        nxh.extrude(part, nxh.section(part, curves=csd, help_point=ss[0]), dl, 0, round(37.0 / abs(dl[2]), 3), op=BOOL.Unite, target=body).SetName(f"END_SLOT_SIDE_{side}")
        # the long rib (x 58.5..60, top z -77.2) runs on into the boss, as on the scan
        rq = [(RIB_X[0], RIB_Y[0]), (RIB_X[1], RIB_Y[0]), (RIB_X[1], RIB_Y[1]), (RIB_X[0], RIB_Y[1])]
        rq = [(sx * x, y, RIB_TOP) for x, y in rq]
        csr = [nxh.line(part, rq[i], rq[(i + 1) % 4]) for i in range(4)]
        nxh.extrude(part, nxh.section(part, curves=csr, help_point=rq[0]), (0, 0, -1), 0, 20.0, op=BOOL.Unite, target=body).SetName(f"END_RIB_{side}")   # down through the wall; the skin clip trims it
        skip_ = {body.Tag} | {o.Tag for o in OUTP.values()} | {b.Tag for b in before_boss}
        tools_ = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b) and b.Tag not in skip_]
        vols_ = [(b, fvol(part, b)) for b in tools_]
        log(f"{side}: boss/web pieces {[(round(v_, 1), [round(q, 1) for q in nxh.bbox(b)]) for b, v_ in vols_]}")
        P_ = [(sx * 70.0, -267.4, -30.0), (sx * 62.0, -262.0, -70.0), (sx * 59.2, -261.0, -70.0), (sx * 57.0, -265.75, -10.0)]

        log(f"{side}: body has {[inside(part, body, q) for q in P_]}; pieces have {[[inside(part, b, q) for q in P_] for b, _ in vols_]}")
        crumbs = [b for b, v_ in vols_ if v_ < 2.0]
        if crumbs:
            nxf.delete_body(part, crumbs)
        for k_, (b, v_) in enumerate(sorted([(b, v_) for b, v_ in vols_ if v_ >= 2.0], key=lambda q: -q[1])):
            mk = nxh.mark("unite piece", False)
            nf0 = len(nxh.feature_errors(part, recheck=False))
            fu_ = nxh.unite(part, body, [b], check=False)
            if len(nxh.feature_errors(part, recheck=False)) > nf0:
                msgs = []
                for m_ in ("GetFeatureErrorMessages", "GetFeatureWarningMessages", "GetFeatureInformationalMessages"):
                    try:
                        msgs += list(getattr(fu_, m_)())
                    except Exception:  # noqa: BLE001
                        pass
                log(f"{side}: piece {v_:.0f} unite reports {msgs}: dropped")
                nxh.undo_to(mk)
                nxf.delete_body(part, [b])
                continue
            fu_.SetName(f"END_BOSS_{side}" + ("" if k_ == 0 else f"_{k_}"))
        log(f"boss + web {side} united")
    # the web plane bounds the corner on the outside (scan face L2, z 0 .. ~-46): one planar cut per corner takes away
    # what the lip offsets of the untrimmed skin put beyond it near the corner tip
    for side, sx in (() if True else (("R", 1.0), ("L", -1.0))):     # not needed once the skin copy ends at the Rev A end (y -275.6)
        x0_ = 52.0 if sx > 0 else -72.0
        fbw, bw = nxh.block(part, (x0_, -282.0, -40.0), (20.0, 20.0, 43.0))
        n_ = (sx * WEB_N[0], WEB_N[1], WEB_N[2]); p_ = (sx * WEB_P[0], WEB_P[1], WEB_P[2])
        _, plc = nxh.datum_plane(part, p_, n_, name=f"END_WEB_CUT_{side}_PLANE")
        out_pt, in_pt = (sx * 54.5, -272.5, -10.0), (sx * 61.0, -268.5, -10.0)
        ok_ = False
        for rev in (False, True):
            mk = nxh.mark("web cut", False)
            nxf.trim_body(part, bw, datum_plane=plc, reverse=rev)
            if inside(part, bw, out_pt) and not inside(part, bw, in_pt):
                ok_ = True
                break
            nxh.undo_to(mk)
        if ok_:
            nxh.subtract(part, body, [bw], check=False).SetName(f"END_WEB_PLANE_CUT_{side}")
        else:
            log(f"{side}: web-plane cut tool side not found"); nxf.delete_body(part, [bw])
    # everything the bosses and webs put outside the outer skin goes in one cut per side
    for side, sx in (("R", 1.0), ("L", -1.0)):
        if side in OUTP:
            nxh.subtract(part, body, [OUTP[side]], check=False).SetName("END_SKIN_CLIP")
    lo = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b) and b.Tag != body.Tag]
    if lo:
        log(f"loose after the skin clip: {[round(fvol(part, b), 1) for b in lo]}")
        nxf.delete_body(part, lo)

    # ---------------------------------------------------------------- 3 joint face (after the bosses and webs, so
    # nothing they bring reaches past it)
    _, pl_e = nxh.datum_plane(part, (0, END_Y, 0), (0, 1, 0), name="END_JOINT_PLANE")
    fb, blk = nxh.block(part, (-250.0, END_Y - 60.0, -200.0), (500.0, 60.0, 260.0))
    fb.SetName("END_JOINT_TOOL")
    nxh.subtract(part, body, [blk], check=False).SetName("END_JOINT_CUT")
    log(f"joint cut at y {END_Y}")
    for side, sx in (("R", 1.0), ("L", -1.0)):
        nxh.cylinder(part, (sx * BORE_C[0], BORE_C[1], -60.0), (0, 0, 1), BORE_D, 62.0, op=BOOL.Subtract, target=body)
    log("bores cut")
    pr = {}
    for sx, s in ((1.0, "R"), (-1.0, "L")):
        pr[f"boss_rim_{s}"] = round(nxh.dist_to(part, body, (sx * 59.2, -262.6, -2.0)), 3)        # boss wall north: in
        pr[f"bore_{s}"] = round(nxh.dist_to(part, body, (sx * 59.25, -265.9, -20.0)), 3)          # bore: air
        pr[f"web_{s}"] = round(nxh.dist_to(part, body, (sx * 61.0, -268.5, -10.0)), 3)            # web: in
        pr[f"west_of_web_{s}"] = round(nxh.dist_to(part, body, (sx * 56.0, -272.5, -10.0)), 3)    # beyond web plane: air
        pr[f"slot_{s}"] = round(nxh.dist_to(part, body, (sx * 64.0, -264.0, -8.0)), 3)            # slot boss/wall: air
        pr[f"cone_{s}"] = round(nxh.dist_to(part, body, (sx * 53.5, -265.75, -50.0)), 3)          # cone west z -50: in
        pr[f"beyond_end_{s}"] = round(nxh.dist_to(part, body, (sx * 62.0, END_Y - 0.3, -30.0)), 3)  # air
        pr[f"end_face_{s}"] = round(nxh.dist_to(part, body, (sx * 66.0, END_Y + 0.3, -20.0)), 3)    # wall end: in
    res["probes"] = pr
except StopIteration:
    log("stopped at " + STOP)
except Exception:
    res["error"] = traceback.format_exc()
    log("ERROR")
try:
    res["solids_after"] = len([bb for bb in part.Bodies if bb.IsSolidBody and not bb.IsBlanked and not is_conv(bb)])
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["features_after"] = len(list(part.Features))
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["new_features"] = [g.GetFeatureName() + " / " + g.Name for g in list(part.Features)[res["features_before"]:]]
    for b in part.Bodies:
        if b.Tag != body.Tag and not is_conv(b) and not b.IsBlanked and b.Tag not in [x.Tag for x in vis if x.Tag != body.Tag]:
            try:
                b.Blank()
            except Exception:  # noqa: BLE001
                pass
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    res["stl"] = nxre.stl_export(part, body, os.path.join(OUT, "chest_C2.stl"), chord=0.01, max_edge=2.5)
    ok = res["body_ok"] and res["solids_after"] == 1 and len(res["errors_after"]) <= len(res["errors_before"]) and "error" not in res
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error_final"] = traceback.format_exc()
nxh.write_json(JS, res)





























