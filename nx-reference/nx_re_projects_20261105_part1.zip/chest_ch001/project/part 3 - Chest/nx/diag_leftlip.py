"""Diagnostic (nothing saved): right neck lip + unite, then the left lip alone in several ways. args: prt out_json"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf

PRT, OUT = sys.argv[1], sys.argv[2]
res = {"log": []}
log = res["log"].append


def inside(part, b, xyz):
    return nxh.dist_to(part, b, xyz) < 1e-4


def new_solids(part, before):
    tags = {b.Tag for b in before}
    return [b for b in part.Bodies if b.IsSolidBody and b.Tag not in tags]


try:
    part = nxh.open_part(PRT)
    sol = [b for b in part.Bodies if b.IsSolidBody and not getattr(b, "IsConvergentBody", False)]
    body = max(sol, key=lambda b: len(b.GetFaces()))
    find = lambda mid: [e for e in body.GetEdges() if math.dist(nxh.edge_points(e, n=3)[1], mid) < 0.3]
    mR, tR = find((47.57, 70.39, -71.02)), find((56.38, 109.1, -8.82))
    mL, tL = find((-47.57, 70.39, -71.02)), find((-56.38, 109.1, -8.82))
    log(f"edges mR {len(mR)} tR {len(tR)} mL {len(mL)} tL {len(tL)}")
    for e, nm in ((mR[0], "mR"), (mL[0], "mL")):
        p = nxh.edge_points(e, n=5)
        log(f"{nm} start {[round(c, 3) for c in p[0]]} end {[round(c, 3) for c in p[-1]]}; faces " +
            "; ".join(f"{[round(c, 3) for c in nxh.normal_at(g, p[2])]}" for g in e.GetFaces()))
    qR_in, qR_out = (48.9, 69.5, -69.5), (46.4, 70.4, -69.5)
    qL_in, qL_out = (-48.9, 69.5, -69.5), (-46.4, 70.4, -69.5)

    def attempt(es, q_in, q_out, label, unite=True):
        for thin in ((0, 3.0), (-3.0, 0)):
            mk = nxh.mark("t", False)
            before = list(part.Bodies)
            try:
                f = nxf.extrude_ex(part, nxh.section(part, edges=es, help_point=tuple(nxh.edge_points(es[0], n=3)[1])),
                                   (0, 0, 1), start=-1.0, end=5.5, thin=thin)
            except Exception as ex:  # noqa: BLE001
                log(f"{label} thin {thin}: extrude failed {str(ex)[:80]}")
                nxh.undo_to(mk); continue
            bs = new_solids(part, before)
            ok = bs and any(inside(part, x, q_in) for x in bs) and not any(inside(part, x, q_out) for x in bs)
            log(f"{label} thin {thin}: {len(bs)} bodies, side ok {ok}, bbox {[round(c, 1) for c in nxh.bbox(bs[0])] if bs else None}")
            if not ok:
                nxh.undo_to(mk); continue
            if not unite:
                return bs
            try:
                nxh.unite(part, body, tools=bs, check=False)
                log(f"{label}: UNITE OK")
                return bs
            except Exception as ex:  # noqa: BLE001
                log(f"{label}: unite refused {str(ex)[:70]}")
                nxh.undo_to(mk)
                return None
        return None

    attempt(mR + tR, qR_in, qR_out, "right main+top")
    attempt(mL, qL_in, qL_out, "left main")
    attempt(tL, (-57.9, 109.0, -7.0), (-55.5, 109.0, -7.0), "left top")
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
