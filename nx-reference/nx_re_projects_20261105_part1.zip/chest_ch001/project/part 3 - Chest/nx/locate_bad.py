"""Locate a BodyConsistency fault: open a part, find the UF consistency call, report each fault's token and the
entity type / bounding box.  args: prt out_json"""
import sys, os, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh
res = {"faults": []}
try:
    hits = []
    for nm in dir(nxh.UFS):
        try:
            o = getattr(nxh.UFS, nm)
        except Exception:  # noqa: BLE001
            continue
        for m in ("AskBodyConsistency", "ValidateBody"):
            if hasattr(o, m):
                hits.append(f"{nm}.{m}")
    res["hits"] = hits
    part = nxh.open_part(sys.argv[1])
    sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
    body = max(sol, key=lambda b: len(b.GetFaces()))
    for h in hits:
        cls, m = h.split(".")
        try:
            r = getattr(getattr(nxh.UFS, cls), m)(body.Tag)
            res[h] = str(r)[:3000]
            seq = r if isinstance(r, (list, tuple)) else [r]
            tags = []
            for x in seq:
                if isinstance(x, (list, tuple)):
                    tags += [t for t in x if isinstance(t, int)]
            for tg in tags[:50]:
                try:
                    o = NXOpen.TaggedObjectManager.GetTaggedObject(tg)
                    row = {"via": h, "tag": tg, "type": type(o).__name__}
                    try:
                        row["bbox"] = [round(v, 2) for v in nxh.bbox(o)]
                    except Exception as e:  # noqa: BLE001
                        row["bbox_err"] = str(e)[:80]
                    res["faults"].append(row)
                except Exception:  # noqa: BLE001
                    pass
        except Exception as e:  # noqa: BLE001
            res[h + "_err"] = str(e)[:300]
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(sys.argv[2], res)
