# -*- coding: utf-8 -*-
"""nxd2 - drafting additions for the POOL TIME IM01 package (on top of skills/nx-drafting/scripts/nxd.py):
own ISO 7200 title block and parts list as tabular notes, notes and ID symbols with leaders, view-dependent
lines (parting line), dimension text override, removal of the Siemens example title block."""
import os

import NXOpen
import NXOpen.Annotations
import NXOpen.Drawings

import nxh
import nxd

S = nxh.S
UFS = nxh.UFS
A = NXOpen.Annotations
P = nxh.P


def obj(tag):
    return NXOpen.TaggedObjectManager.GetTaggedObject(tag)


# ---------------------------------------------------------------- sheet clean-up
def sheet_objects(sh):
    """[(object, type name, origin or None)] of everything visible in the sheet view (not member views)."""
    out = []
    for o in sh.View.AskVisibleObjects():
        org = None
        try:
            p = o.AnnotationOrigin
            org = (round(p.X, 2), round(p.Y, 2))
        except Exception:  # noqa: BLE001
            pass
        out.append((o, type(o).__name__, org))
    return out


def remove_title_block(part, sh, box=(225.0, 11.0, 409.0, 75.0)):
    """Delete the Siemens example title block (TitleBlock objects + every annotation / curve of the sheet view
    whose origin or bbox lies inside `box` [x0, y0, x1, y1]). Returns the census of what was deleted."""
    gone = {}
    dels = []
    for tb in list(part.DraftingManager.TitleBlocks):
        dels.append(tb)
        gone["TitleBlock"] = gone.get("TitleBlock", 0) + 1
    for o, tn, org in sheet_objects(sh):
        inside = False
        if org is not None:
            inside = box[0] <= org[0] <= box[2] and box[1] <= org[1] <= box[3]
        else:
            try:
                bb = nxh.bbox(o)
                inside = box[0] - 1 <= bb[0] and bb[3] <= box[2] + 1 and box[1] - 1 <= bb[1] and bb[4] <= box[3] + 1
            except Exception:  # noqa: BLE001
                inside = False
        if inside and o not in dels:
            dels.append(o)
            gone[tn] = gone.get(tn, 0) + 1
    if dels:
        m = nxh.mark("del title block")
        S.UpdateManager.AddObjectsToDeleteList(dels)
        S.UpdateManager.DoUpdate(m)
    return gone


# ---------------------------------------------------------------- tabular notes
PREF_ERRORS = []


def _just_enum():
    """NXOpen.UF.TabnotJust (NOT DrawTabnotJust: SetCellPrefs rejects that one)."""
    return getattr(NXOpen.UF, "TabnotJust", None)


def _cell_prefs(pr, size, al):
    """Text height + horizontal justification of a UF tabular-note cell (TabnotCellPrefs_Struct)."""
    pr.TextHeight = size
    J = _just_enum()
    if J is not None and al:
        want = {"L": "LEFT", "C": "CENTER", "R": "RIGHT"}[al]
        for n in dir(J):
            if n.upper().endswith(want):
                pr.HorizJust = getattr(J, n)
                break


def table(part, origin, col_widths, row_heights, cells, text_size=2.5, merges=(), aligns=None, sizes=None):
    """Tabular note with its top-left corner at `origin` (sheet mm). cells[r][c] = text ('' for empty);
    merges = [(r0, c0, r1, c1)]; aligns {(r, c): 'L'|'C'|'R'}; sizes {(r, c): text height}.
    Returns (TableSection, tabular note tag)."""
    b = part.Annotations.TableSections.CreateTableSectionBuilder(NXOpen.Annotations.TableSection.Null)
    try:
        b.NumberOfColumns = len(col_widths)
        b.NumberOfRows = len(row_heights)
        b.ColumnWidth = float(col_widths[0])
        b.RowHeight = float(row_heights[0])
        b.Origin.Origin.SetValue(None, None, P(origin[0], origin[1], 0.0))
        try:
            b.Origin.Anchor = A.OriginBuilder.AlignmentPosition.TopLeft
        except Exception:  # noqa: BLE001
            pass
        ts = b.Commit()
    finally:
        b.Destroy()
    tn = UFS.Tabnot.AskTabularNoteOfSection(ts.Tag)
    nr, nc = UFS.Tabnot.AskNmRows(tn), UFS.Tabnot.AskNmColumns(tn)
    for j in range(nc):
        UFS.Tabnot.SetColumnWidth(UFS.Tabnot.AskNthColumn(tn, j), float(col_widths[j]))
    for i in range(nr):
        UFS.Tabnot.SetRowHeight(UFS.Tabnot.AskNthRow(tn, i), float(row_heights[i]))
    for (r0, c0, r1, c1) in merges:
        a = UFS.Tabnot.AskCellAtRowCol(UFS.Tabnot.AskNthRow(tn, r0), UFS.Tabnot.AskNthColumn(tn, c0))
        z = UFS.Tabnot.AskCellAtRowCol(UFS.Tabnot.AskNthRow(tn, r1), UFS.Tabnot.AskNthColumn(tn, c1))
        UFS.Tabnot.MergeCells(a, z)
    for i in range(nr):
        for j in range(nc):
            txt = cells[i][j] if i < len(cells) and j < len(cells[i]) else ""
            cell = UFS.Tabnot.AskCellAtRowCol(UFS.Tabnot.AskNthRow(tn, i), UFS.Tabnot.AskNthColumn(tn, j))
            try:
                pr = UFS.Tabnot.AskCellPrefs(cell)
                _cell_prefs(pr, float((sizes or {}).get((i, j), text_size)), (aligns or {}).get((i, j), "L"))
                UFS.Tabnot.SetCellPrefs(cell, pr)
            except Exception as ex:  # noqa: BLE001
                PREF_ERRORS.append(str(ex))
            if txt:
                UFS.Tabnot.SetCellText(cell, txt)
    UFS.Tabnot.Update(tn)
    return ts, tn


def table_text(tn):
    nr, nc = UFS.Tabnot.AskNmRows(tn), UFS.Tabnot.AskNmColumns(tn)
    return [[UFS.Tabnot.AskCellText(UFS.Tabnot.AskCellAtRowCol(UFS.Tabnot.AskNthRow(tn, i), UFS.Tabnot.AskNthColumn(tn, j)))
             for j in range(nc)] for i in range(nr)]


# ---------------------------------------------------------------- leaders
def _leader(part, lb, target, view, at_model, arrow="filled_arrow", side=None):
    ld = part.Annotations.CreateLeaderData()
    ld.StubSize = 4.0
    AH = A.LeaderData.ArrowheadType
    ld.Arrowhead = {"filled_arrow": AH.FilledArrow, "dot": AH.FilledDot}.get(arrow, AH.FilledArrow)
    ld.StubSide = {"left": A.LeaderSide.Left, "right": A.LeaderSide.Right}.get(side, A.LeaderSide.Inferred)
    lb.Leaders.Append(ld)
    ld.Leader.SetValue(target, view, P(*at_model))      # MODEL point (a sheet point sends the leader astray)
    return ld


def leader_note(part, lines, pos, target=None, view=None, at=None, size=2.5, arrow="filled_arrow", side=None):
    """Note at sheet pos with a leader to `target` (drafting curve / view object) picked at MODEL point `at`
    in `view` (mapped to the sheet)."""
    b = part.Annotations.CreateDraftingNoteBuilder(NXOpen.Annotations.SimpleDraftingAid.Null)
    try:
        b.Text.TextBlock.SetText(list(lines))
        b.Style.LetteringStyle.GeneralTextSize = float(size)
        if target is not None:
            _leader(part, b.Leader, target, view, at, arrow, side)
        b.Origin.Origin.SetValue(None, None, P(pos[0], pos[1], 0.0))
        n = b.Commit()
    finally:
        b.Destroy()
    return n


def balloon(part, text, pos, target, view, at, size=8.0, text_size=3.5):
    """Circle ID symbol (balloon) at sheet pos with a dot-terminated leader to target at MODEL point `at`."""
    b = part.Annotations.IdSymbols.CreateIdSymbolBuilder(NXOpen.Annotations.IdSymbol.Null)
    try:
        b.Type = A.IdSymbolBuilder.SymbolTypes.Circle
        b.UpperText = str(text)
        b.Size = float(size)
        try:
            b.Style.LetteringStyle.GeneralTextSize = float(text_size)
        except Exception:  # noqa: BLE001
            pass
        _leader(part, b.Leader, target, view, at, "dot")
        b.Origin.Origin.SetValue(None, None, P(pos[0], pos[1], 0.0))
        s = b.Commit()
    finally:
        b.Destroy()
    return s


# ---------------------------------------------------------------- sheet lines
def sheet_line(part, a, b, font="solid", width=None):
    """Line in SHEET coordinates (mm). Created while a sheet is open, a line belongs to that sheet (it is a
    drawing object; UF_VIEW_convert_to_view refuses it with 'Object not qualified to be converted')."""
    ln = part.Curves.CreateLine(P(a[0], a[1], 0.0), P(b[0], b[1], 0.0))
    F = NXOpen.DisplayableObject.ObjectFont
    ln.LineFont = {"phantom": F.Phantom, "dashed": F.Dashed, "solid": F.Solid, "center": F.Centerline}[font]
    if width is not None:
        W = NXOpen.DisplayableObject.ObjectWidth
        ln.LineWidth = {"thin": W.Thin, "normal": W.Normal, "thick": W.Thick}[width]
    ln.RedisplayObject()
    return ln


def view_line(part, view, a, b, font="phantom", width=None):
    """Sheet line between the sheet images of MODEL points a, b of `view` (does not follow a later view move)."""
    return sheet_line(part, nxd.to_sheet(view, a), nxd.to_sheet(view, b), font, width)


def section(part, parent, through, pos, scale, kind="simple", extra=()):
    """Section view with an explicit scale (nxd.section_view leaves it at 1:1 whatever the parent's scale).
    The section line runs HORIZONTAL in the parent view (NX default hinge; SpecifySectionLineBuilder has no
    hinge direction) - orient the parent so the wanted cut plane is horizontal there."""
    SVB = NXOpen.Drawings.SectionViewBuilder
    b = part.DraftingViews.CreateSectionViewBuilder(NXOpen.Drawings.SectionView.Null)
    try:
        b.SectionViewType = SVB.SectionLineType.Half if kind == "half" else SVB.SectionLineType.SimpleStepped
        b.ParentView.View.Value = parent
        seg = b.SectionLineSegments.SegmentLocation
        seg.AddCutSegment(part.Points.CreatePoint(P(*through)))
        for q in extra:
            seg.AddCutSegment(part.Points.CreatePoint(P(*q)))
        sc = b.ViewStyle.ViewStyleGeneral.Scale
        sc.Numerator, sc.Denominator = float(scale[0]), float(scale[1])
        b.ViewPlacement.Placement.SetValue(None, part.Views.WorkView, P(pos[0], pos[1], 0.0))
        v = b.Commit()
    finally:
        b.Destroy()
    return v


def override_text(d, lines):
    """Replace the main dimension text (e.g. a thread designation instead of the measured diameter)."""
    d.SetDimensionText(list(lines))
    return d.GetDimensionText()
