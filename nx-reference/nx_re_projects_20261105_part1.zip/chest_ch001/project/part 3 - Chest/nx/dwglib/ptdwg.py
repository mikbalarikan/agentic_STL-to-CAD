# -*- coding: utf-8 -*-
"""POOL TIME IM01 drawing frame: master-model drawing part, A3/A2 sheet (Siemens border + zones, its example title
block removed), ISO 7200 title block as a tabular note, first-angle symbol, curve pick by model point, dimensions with
text override / tolerance, export (PDF per sheet + combined, DWG per sheet). Copied from m2_dwg/nx (M2 session) for the M3 package; PRODUCT changed."""
import os
import shutil

import NXOpen
import NXOpen.Annotations

import nxh
import nxa
import nxd
import nxd2

UFS = nxh.UFS
P = nxh.P
SNAP = nxd.SNAP
CLIENT = "Paul Clark"
PRODUCT = "Robot - chest"
DRAWN = "M. I. Arikan"
DATE = "2026-10-29"
FRAME = {"A3": (20.0, 10.0, 410.0, 287.0), "A2": (20.0, 10.0, 584.0, 410.0), "A1": (20.0, 10.0, 831.0, 584.0), "A0": (20.0, 10.0, 1179.0, 831.0)}   # inner border x0 y0 x1 y1


def new_drawing(path, model_prt, comp_name, r=None):
    """Master-model drawing part: assembly-template part with the model as its only component (MODEL refset)."""
    dwg = nxa.new_assembly(path)
    comp = nxa.add_component(dwg, model_prt, comp_name, (0.0, 0.0, 0.0), r)
    nxh.save(dwg)
    nxd.enter(dwg)
    nxd.load_standard(dwg, "ISO")
    return dwg, comp


ANGLE = "third"


def sheet(dwg, size="A3"):
    """Template sheet (border + zones), projection ANGLE, the Siemens example title block deleted."""
    sh = nxd.sheet(dwg, "SH", angle=ANGLE, template=nxd.template_path(size))
    gone = nxd2.remove_title_block(dwg, sh, box=(-1, -1, -1, -1))
    return sh, gone


def first_angle_symbol(dwg, x, y, h=7.0):
    """ISO 5456-2 first-angle symbol, bottom-left corner at (x, y), height h: truncated cone (small end left)
    and, to its RIGHT, the end view seen from the small end (two circles)."""
    d1, d2, L = 0.5 * h, h, 1.0 * h
    cy = y + h / 2.0
    pts = [(x, cy - d1 / 2), (x + L, cy - d2 / 2), (x + L, cy + d2 / 2), (x, cy + d1 / 2)]
    for i in range(4):
        nxd2.sheet_line(dwg, pts[i], pts[(i + 1) % 4])
    nxd2.sheet_line(dwg, (x - 1.0, cy), (x + L + 1.0, cy), font="center")
    cx = x + L + 0.35 * h + d2 / 2
    for rr in (d1 / 2, d2 / 2):
        nxh.circle(dwg, (cx, cy, 0.0), rr)
    nxd2.sheet_line(dwg, (cx - d2 / 2 - 1.0, cy), (cx + d2 / 2 + 1.0, cy), font="center")
    nxd2.sheet_line(dwg, (cx, cy - d2 / 2 - 1.0), (cx, cy + d2 / 2 + 1.0), font="center")


def third_angle_symbol(dwg, x, y, h=7.0):
    """Third-angle symbol: end view (two circles) on the LEFT, truncated cone (small end left) on the right."""
    d1, d2, L = 0.5 * h, h, 1.0 * h
    cy = y + h / 2.0
    cx = x + d2 / 2
    for rr in (d1 / 2, d2 / 2):
        nxh.circle(dwg, (cx, cy, 0.0), rr)
    nxd2.sheet_line(dwg, (cx - d2 / 2 - 1.0, cy), (cx + d2 / 2 + 1.0, cy), font="center")
    nxd2.sheet_line(dwg, (cx, cy - d2 / 2 - 1.0), (cx, cy + d2 / 2 + 1.0), font="center")
    x0 = cx + d2 / 2 + 0.35 * h
    pts = [(x0, cy - d1 / 2), (x0 + L, cy - d2 / 2), (x0 + L, cy + d2 / 2), (x0, cy + d1 / 2)]
    for i in range(4):
        nxd2.sheet_line(dwg, pts[i], pts[(i + 1) % 4])
    nxd2.sheet_line(dwg, (x0 - 1.0, cy), (x0 + L + 1.0, cy), font="center")


def title_block(dwg, size, title, dwg_no, material, mass, scale, sheet_no, n_sheets, rev="IM01", subtitle=""):
    """ISO 7200 title block, 180 mm wide, bottom right on the inner border. Returns the cell texts."""
    x0, y0, x1, y1 = FRAME[size]
    cw = [22.0, 70.0, 20.0, 34.0, 34.0]
    rh = [6.0, 6.0, 11.0, 6.0, 6.0, 6.0, 6.0]
    top = y0 + sum(rh)
    left = x1 - sum(cw)
    cells = [
        ["Client", CLIENT, "", "", ""],
        ["Product", PRODUCT + (" - " + subtitle if subtitle else ""), "", "", ""],
        ["Title", title, "", "", ""],
        ["Drawing no.", dwg_no, "Revision", rev, "Sheet %d / %d" % (sheet_no, n_sheets)],
        ["Material", material, "Mass", mass, "Format " + size],
        ["Scale", scale, "Date", DATE, "Units mm"],
        ["Drawn", DRAWN, "Checked", "-", ("3rd" if ANGLE == "third" else "1st") + " angle"],
    ]
    sizes = {(2, 1): 5.0, (3, 1): 3.5, (3, 3): 3.5}
    for i in range(7):
        sizes[(i, 0)] = 2.0
    for (i, j) in ((3, 2), (4, 2), (5, 2), (6, 2)):
        sizes[(i, j)] = 2.0
    ts, tn = nxd2.table(dwg, (left, top), cw, rh, cells, text_size=2.5,
                        merges=[(0, 1, 0, 3), (1, 1, 1, 3), (2, 1, 2, 4)], sizes=sizes)
    # projection symbol in the merged cell column 4, rows 0-1
    (third_angle_symbol if ANGLE == "third" else first_angle_symbol)(dwg, left + sum(cw[:4]) + 6.0, top - 12.0 + 2.5, h=7.0)
    return nxd2.table_text(tn)


def free_area(size):
    x0, y0, x1, y1 = FRAME[size]
    return x0, y0, x1, y1


# ---------------------------------------------------------------- picking drafting curves by model geometry
def _d(a, b):
    return sum((a[i] - b[i]) ** 2 for i in range(3)) ** 0.5


def pick(view, xyz, tol=0.03, kind="end"):
    """(curve, snap) of the view at MODEL point xyz. kind 'end': a curve with an END point at xyz (snap
    Start / End; straight curves report [start, end, mid], splines [start, end]); 'on': any straight curve
    through xyz (snap Mid). Among several, the closest wins; raises if nothing is found."""
    best = None
    if kind == "end":
        for c, _ps in nxd.curves(view):
            pts = nxd.curve_points(c)
            if len(pts) not in (2, 3):
                continue
            if len(pts) == 2 and _is_arc(c):
                continue
            for k, snap in ((0, SNAP.Start), (1, SNAP.End)):
                dd = _d(pts[k], xyz) + (0.0 if len(pts) == 3 else 0.5 * tol)     # straight curves first
                if dd <= 1.5 * tol and (best is None or dd < best[2]):
                    best = (c, snap, dd)
    if best is None:
        cs = nxd.curve_at(view, xyz, tol=tol)
        if cs:
            best = (cs[0], SNAP.Mid, 0.0)
    if best is None:
        raise RuntimeError("pick: nothing at %s in %s (%s)" % ([round(v, 3) for v in xyz], view.Name, kind))
    return best[0], best[1]


def _is_arc(c):
    try:
        return "Arc" in type(c.GetDraftingCurveInfo()).__name__ or c.GetDraftingCurveInfo().CurveType == 1
    except Exception:  # noqa: BLE001
        return False


def near(view, xyz):
    """(curve, its characteristic MODEL point) of the view closest to xyz (any curve type)."""
    best = None
    for c, _ps in nxd.curves(view):
        for p in nxd.curve_points(c):
            dd = _d(p, xyz)
            if best is None or dd < best[2]:
                best = (c, p, dd)
    return best[0], best[1]


def find(view, pred):
    """Curves of the view whose characteristic MODEL points satisfy pred(points)."""
    return [c for c, _ps in nxd.curves(view) if pred(nxd.curve_points(c))]


def arc_at(view, centre, radius, tol=0.03):
    """Circular drafting curve with this MODEL centre and radius."""
    for c, _ps in nxd.curves(view):
        pts = nxd.curve_points(c)
        if len(pts) == 2 and _d(pts[0], centre) <= tol and abs(_d(pts[0], pts[1]) - radius) <= tol:
            return c
    raise RuntimeError("arc_at: no arc R%.3f at %s in %s" % (radius, centre, view.Name))


def _style(b, prec=2, text_size=None):
    """2 decimals, decimal POINT (the notes and tables use points), trailing zeros shown."""
    ds = b.Style.DimensionStyle
    ds.DimensionValuePrecision = prec
    ds.ToleranceValuePrecision = 2
    us = b.Style.UnitsStyle
    us.DecimalPointCharacter = NXOpen.Annotations.DecimalPointCharacter.Period
    try:
        us.DisplayTrailingZeros = True
    except Exception:  # noqa: BLE001
        pass
    if text_size:
        b.Style.LetteringStyle.DimensionTextSize = float(text_size)


def dim_linear(dwg, view, ca, cb, origin, method, sa, sb, tol=None, before=None, after=None, prec=2):
    meth = {"horizontal": nxd.MM.Horizontal, "vertical": nxd.MM.Vertical, "point": nxd.MM.PointToPoint,
            "perpendicular": nxd.MM.Perpendicular, "cylindrical": nxd.MM.Cylindrical}[method]
    b = dwg.Dimensions.CreateLinearDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    try:
        b.Measurement.Method = meth
        b.FirstAssociativity.SetValue(sa, ca, view, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(sb, cb, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=tol, before=before, after=after)
        _style(b, prec)
        b.Origin.Origin.SetValue(None, None, P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    return d


def _delete(objs):
    m = nxh.mark("del")
    nxh.S.UpdateManager.AddObjectsToDeleteList(list(objs))
    nxh.S.UpdateManager.DoUpdate(m)


def dim(dwg, view, a, b, origin, method="horizontal", text=None, tol=None, before=None, after=None, kind=("end", "end"),
        ptol=0.03, expect=None, etol=0.005, prec=2):
    """Linear dimension between MODEL points a and b (picked curves + snaps). text overrides the value.
    expect: the value the measurement must give; other Start / End combinations are tried if it does not
    (the snap of a spline end is not always the GetLocations order)."""
    ca, sa = pick(view, a, ptol, kind[0])
    cb, sb = pick(view, b, ptol, kind[1])
    swap = {SNAP.Start: SNAP.End, SNAP.End: SNAP.Start}
    tries = [(sa, sb), (swap.get(sa, sa), sb), (sa, swap.get(sb, sb)), (swap.get(sa, sa), swap.get(sb, sb))]
    d = None
    got = []
    for x, y in tries:
        d = dim_linear(dwg, view, ca, cb, origin, method, x, y, tol=tol, before=before, after=after, prec=prec)
        got.append(round(d.ComputedSize, 4))
        if expect is None or abs(d.ComputedSize - expect) <= etol:
            break
        _delete([d])
        d = None
    if d is None:
        raise RuntimeError("dim: no snap combination gives %.4f (%s -> %s): got %s, curves %s / %s" % (
            expect, a, b, got, [[round(v, 3) for v in q] for q in nxd.curve_points(ca)], [[round(v, 3) for v in q] for q in nxd.curve_points(cb)]))
    if text:
        nxd2.override_text(d, text if isinstance(text, list) else [text])
    return d


def dim_curves(dwg, view, ca, cb, origin, method="horizontal", text=None, tol=None, before=None, after=None,
               snaps=(SNAP.Mid, SNAP.Mid), expect=None, etol=0.005):
    """Linear dimension between two given drafting curves (e.g. thread crests, snap Mid)."""
    d = dim_linear(dwg, view, ca, cb, origin, method, snaps[0], snaps[1], tol=tol, before=before, after=after)
    if expect is not None and abs(d.ComputedSize - expect) > etol:
        v = d.ComputedSize
        _delete([d])
        raise RuntimeError("dim_curves: %.4f instead of %.4f" % (v, expect))
    if text:
        nxd2.override_text(d, text if isinstance(text, list) else [text])
    return d


def radius(dwg, view, centre, r, origin, text=None, diameter=False):
    c = arc_at(view, centre, r)
    b = dwg.Dimensions.CreateRadialDimensionBuilder(NXOpen.Annotations.Dimension.Null)
    try:
        b.Measurement.Method = nxd.MM.Diametral if diameter else nxd.MM.Radial
        b.FirstAssociativity.SetValue(SNAP.NotSet, c, view, nxd.P0, None, None, nxd.P0)
        _style(b)
        b.Origin.Origin.SetValue(None, None, P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if text:
        nxd2.override_text(d, [text])
    return d


def info(d):
    i = nxd.dim_info(d)
    i["value"] = round(i["value"], 4)
    return i


# ---------------------------------------------------------------- export
def export(dwg, sheets, out_dir, base):
    """One PDF per sheet (<base>_SH<n>.pdf), the combined <base>.pdf, one DWG per sheet. Returns sizes."""
    os.makedirs(out_dir, exist_ok=True)
    nxh.save(dwg)
    res = {}
    for i, sh in enumerate(sheets, 1):
        p = os.path.join(out_dir, "%s_SH%d.pdf" % (base, i))
        res[os.path.basename(p)] = nxd.export_pdf(dwg, [sh], p)
    p = os.path.join(out_dir, base + ".pdf")
    res[os.path.basename(p)] = nxd.export_pdf(dwg, sheets, p)
    for i, sh in enumerate(sheets, 1):
        p = os.path.join(out_dir, "%s_SH%d.dwg" % (base, i))
        try:
            res[os.path.basename(p)] = nxd.export_dxf(dwg, sh.Name, p, dwg=True)
        except Exception as ex:  # noqa: BLE001
            res[os.path.basename(p)] = "ERROR " + str(ex)
    return res


def sheet_names(dwg):
    return [s.Name for s in dwg.DraftingDrawingSheets]
