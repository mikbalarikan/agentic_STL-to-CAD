"""CH-001 Rev B: tapered bottom corner posts (2026-10-31), appended at the END of the history on a COPY.
args: src_prt dst_prt

Scan (an/r1_post.py): below z -26 each post is a cone on the bore axis (+-59.3, -265.8): r 5.41 at z -26 -> 7.44 at
z -62 (3.2 deg), the same on both sides; above it the Rev A post D8.6 stays. CORNER_POST_TAPER = one sketch with the
two circles D10.8 on a plane at z -26, Extrude Unite from z -24 down to the inner wall face (Until Extended), draft
-3.2 deg (the section grows downwards). CORNER_POST_BORE = the D3.0 bores re-cut through the new material to z -60
(the Rev A bore depth)."""
import os, sys, math, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, DST = sys.argv[1], sys.argv[2]
OUT = os.path.dirname(DST)
BOOL = nxh.BOOL
ET = nxf.ET
GU = nxf.GU
res = {"result": "FAIL", "log": []}
log = res["log"].append
CX, CY = 59.3, -265.8
Z_SK, D_SK, DRAFT, Z_START = -26.0, 10.8, 3.2, -24.0
BORE_D, BORE_Z0, BORE_Z1 = 3.0, -60.0, -20.0
WALL_PT = (59.3, -258.0, -73.76)          # inner wall under the north side of the right post (CAD STL ray)


def fvol(part, body, acc=0.99):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


def is_conv(b):
    try:
        return bool(b.IsConvergentBody)
    except Exception:  # noqa: BLE001
        return False


try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)
    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: fvol(part, b))
    res["features_before"] = len(list(part.Features))
    res["errors_before"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    v0 = fvol(part, body)
    D = nxh.Datums(part)
    E = {k: nxh.expr(part, nm, val, unit=u, comment=cm).Name for k, nm, val, u, cm in (
        ("D", "CH_CORNER_POST_D26", D_SK, "mm", "corner post diameter at z -26"),
        ("A", "CH_CORNER_POST_TAPER", DRAFT, "deg", "corner post taper (half angle), growing downwards"))}

    dw = sorted(((nxh.dist_to(part, fc, WALL_PT), i, fc) for i, fc in enumerate(body.GetFaces())), key=lambda t: t[:2])
    log(f"inner wall face at {WALL_PT}: {dw[0][0]:.4f} mm (next {dw[1][0]:.4f})")
    assert dw[0][0] < 0.05
    wall = dw[0][2]
    # the left post must end on the same face (symmetric wall): check its distance
    res["wall_left_dist"] = nxh.dist_to(part, wall, (-WALL_PT[0], WALL_PT[1], WALL_PT[2]))

    _, pl = nxh.datum_plane(part, (0, 0, Z_SK), (0, 0, 1), name="CORNER_POST_TAPER_PLANE")
    sk = nxf.new_sketch(part, pl, D.x, nxh.point(part, 0, 0, Z_SK), name="CORNER_POST_TAPER_SKETCH")
    for s in (1, -1):
        nxf.sketch_circle(part, sk, nxh.point(part, s * CX, CY, Z_SK), E["D"])
    st = nxf.finish_sketch(sk)
    sec = nxh.section_feature(part, [sk.Feature])
    b = part.Features.CreateExtrudeBuilder(nxf.NF)
    try:
        b.Section = sec
        b.Direction = nxh.direction(part, (0, 0, -1))
        b.BooleanOperation.Type = BOOL.Unite
        b.BooleanOperation.SetTargetBodies([body])
        b.Limits.StartExtend.Value.RightHandSide = str(Z_START - Z_SK)     # -2: 2 mm above the sketch plane
        b.Limits.EndExtend.TrimType = ET.UntilExtended
        b.Limits.EndExtend.Target = wall
        b.Draft.DraftOption = GU.SimpleDraft.SimpleDraftType.SimpleFromProfile
        b.Draft.FrontDraftAngle.RightHandSide = f"-{E['A']}"
        f = b.CommitFeature()
    finally:
        b.Destroy()
    f.SetName("CORNER_POST_TAPER")
    v1 = fvol(part, body)
    log(f"taper sketch {st['status']} dof {st['dof']}; added {v1 - v0:.1f} mm3")

    _, plb = nxh.datum_plane(part, (0, 0, BORE_Z1), (0, 0, 1), name="CORNER_POST_BORE_PLANE")
    sk2 = nxf.new_sketch(part, plb, D.x, nxh.point(part, 0, 0, BORE_Z1), name="CORNER_POST_BORE_SKETCH")
    for s in (1, -1):
        nxf.sketch_circle(part, sk2, nxh.point(part, s * CX, CY, BORE_Z1), str(BORE_D))
    st2 = nxf.finish_sketch(sk2)
    f2 = nxf.extrude_ex(part, nxh.section_feature(part, [sk2.Feature]), (0, 0, -1), start=0, end=BORE_Z1 - BORE_Z0,
                        op=BOOL.Subtract, target=body)
    f2.SetName("CORNER_POST_BORE")
    v2 = fvol(part, body)
    log(f"bore sketch {st2['status']} dof {st2['dof']}; removed {v1 - v2:.1f} mm3")

    pr = {}
    for s, nm in ((1, "R"), (-1, "L")):
        r40 = D_SK / 2 + math.tan(math.radians(DRAFT)) * 14.0          # radius at z -40
        pr[nm + "_post_west_z-40"] = nxh.dist_to(part, body, (s * (CX - (r40 - 0.4)), CY, -40.0))   # inside: < 0
        pr[nm + "_post_west_out"] = nxh.dist_to(part, body, (s * (CX - (r40 + 0.6)), CY, -40.0))    # outside: > 0
        pr[nm + "_bore_z-50"] = nxh.dist_to(part, body, (s * CX, CY, -50.0))                         # in the bore: > 0
    res["probes"] = pr
    res["solids_after"] = len([bb for bb in part.Bodies if bb.IsSolidBody and not bb.IsBlanked and not is_conv(bb)])
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["features_after"] = len(list(part.Features))
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["new_features"] = [g.GetFeatureName() + " / " + g.Name for g in list(part.Features)[res["features_before"]:]]
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    res["stl"] = nxre.stl_export(part, body, os.path.join(OUT, "chest_R3.stl"), chord=0.01, max_edge=2.5)
    ok = res["body_ok"] and res["solids_after"] == 1 and len(res["errors_after"]) <= len(res["errors_before"])
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_post.json", res)
