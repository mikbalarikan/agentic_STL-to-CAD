"""outC10 helpers (imported by build.py and t_c10.py): smooth exterior pocket / bump tools from work/c10/sheets.json
(an/c10_sheets.py) and the discrete review-fix features from work/c10/G*.json (work/c10/SCHEMA.md)."""
import math, json, os
import NXOpen
import nxh, nxf, curvekit as ck


def polyline(part, pts, z):
    n = len(pts)
    return [nxh.line(part, (pts[i][0], pts[i][1], z), (pts[(i + 1) % n][0], pts[(i + 1) % n][1], z)) for i in range(n)]


def prism(part, pts, z0, z1, holes=()):
    cs = polyline(part, pts, z0)
    for H in holes:
        cs += polyline(part, H, z0)
    f = nxh.extrude(part, nxh.section(part, curves=cs, help_point=(pts[0][0], pts[0][1], z0)), (0, 0, 1), 0, z1 - z0)
    return [b for b in f.GetBodies() if b.IsSolidBody]


def loft(part, secs):
    sps = []
    for s in secs:
        f, sp = ck.studio_spline(part, [tuple(p) for p in s], degree=3, poles=True)
        sps.append(sp)
    tc = nxf.through_curves(part, [nxh.section(part, curves=[sp]) for sp in sps], solid=False)
    return tc.GetBodies()[0]


def trim_keep(part, body, sheet, v_keep, v_drop, log, label):
    """Trim body by sheet; keep the side whose volume is nearer v_keep (expected) than v_drop."""
    best = None
    for rev in (False, True):
        m = nxh.mark("c10 trim", False)
        try:
            nxf.trim_body(part, body, reverse=rev, sheet=sheet)
            v = nxh.volume(part, body)
        except Exception as e:  # noqa: BLE001
            nxh.undo_to(m); log(f"{label}: trim rev={rev} failed {str(e)[:80]}"); continue
        if abs(v - v_keep) < abs(v - v_drop):
            return v
        nxh.undo_to(m)
        best = v
    raise RuntimeError(f"{label}: no trim side near the expected {v_keep:.0f} (got {best})")


def sheet_tool(part, rec, log):
    """Tool body of one sheets.json record (pocket: below 'hi'; bump: between 'lo' and 'hi'), or None."""
    name = rec["name"]
    if "outline3" in rec:            # local frame: outline at the start plane, extruded along dir
        P3 = rec["outline3"]; n_ = len(P3)
        cs = [nxh.line(part, tuple(P3[i]), tuple(P3[(i + 1) % n_])) for i in range(n_)]
        f = nxh.extrude(part, nxh.section(part, curves=cs, help_point=tuple(P3[0])), tuple(rec["dir"]), 0, rec["len"])
        bodies = [b for b in f.GetBodies() if b.IsSolidBody]
    else:
        bodies = prism(part, rec["outline"], rec["z0"], rec["z1"])
    if len(bodies) != 1:
        raise RuntimeError(f"{name}: prism gave {len(bodies)} bodies")
    t = bodies[0]
    junk = []
    hi = loft(part, rec["sheets"]["hi"]); junk.append(hi)
    v = trim_keep(part, t, hi, rec["v_below_hi"], rec["v_above_hi"], log, name + " hi")
    if "lo" in rec["sheets"]:
        lo = loft(part, rec["sheets"]["lo"]); junk.append(lo)
        vb = rec["v_below_hi"] - rec["v_below_lo"]
        v = trim_keep(part, t, lo, vb, rec["v_below_lo"], log, name + " lo")
    for j in junk:
        try:
            j.Blank()
        except Exception:  # noqa: BLE001
            pass
    if rec["kind"] == "bump":         # nothing above the rim plane z = 0
        bb = nxh.bbox(t)
        log(f"{name}: before rim cap body_ok {nxh.body_ok(part, t)}, zmax {bb[5]:.2f}")
        if bb[5] > 1e-3:
            fb, blk = nxh.block(part, (-300.0, -400.0, 0.0), (600.0, 600.0, 100.0))
            try:
                nxh.subtract(part, t, [blk], check=False)
                v = nxh.volume(part, t)
            except Exception as e:  # noqa: BLE001
                log(f"{name}: rim cap failed {str(e)[:80]}")
    log(f"{name}: tool {v:.0f} mm3")
    return t, junk


# ---------------- discrete features (SCHEMA.md) ----------------
def _mx(p):
    return [-p[0]] + list(p[1:])


def _slot_pts(c, L, w, ang_deg, n_arc=8):
    a = math.radians(ang_deg); u = (math.cos(a), math.sin(a)); v = (-u[1], u[0])
    h = max(L / 2.0 - w / 2.0, 0.0); r = w / 2.0
    pts = []
    for end, sgn in ((1, 1.0), (-1, -1.0)):
        cx, cy = c[0] + sgn * h * u[0], c[1] + sgn * h * u[1]
        for k in range(n_arc + 1):
            th = -math.pi / 2 + math.pi * k / n_arc
            dx = math.cos(th) * sgn; dy = math.sin(th) * sgn
            pts.append((cx + r * (dx * u[0] + dy * v[0]), cy + r * (dx * u[1] + dy * v[1])))
    return pts


def feature_bodies(part, F, mirror=False):
    """Solid bodies of one SCHEMA feature (mirror=True: its image at -x)."""
    t = F["type"]
    if t == "cyl":
        p0 = _mx(F["p0"]) if mirror else F["p0"]; ax = _mx(F["axis"]) if mirror else F["axis"]
        if "d0" in F and "d1" in F and abs(F["d0"] - F["d1"]) > 1e-3:      # tapered boss / tube (truncated cone)
            b = part.Features.CreateConeBuilder(NXOpen.Features.Cone.Null)
            try:
                b.Type = NXOpen.Features.ConeBuilder.Types.DiametersAndHeight
                b.Axis = nxh.axis(part, tuple(p0), tuple(ax))
                b.BaseDiameter.RightHandSide = str(F["d0"])
                b.TopDiameter.RightHandSide = str(F["d1"])
                b.Height.RightHandSide = str(F["len"])
                b.BooleanOption.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
                f = b.CommitFeature()
            finally:
                b.Destroy()
            return [x for x in f.GetBodies() if x.IsSolidBody]
        f, c = nxh.cylinder(part, tuple(p0), tuple(ax), F["d"], F["len"])
        return [c]
    if t == "sphere":
        c = _mx(F["c"]) if mirror else F["c"]
        b = part.Features.CreateSphereBuilder(NXOpen.Features.Sphere.Null)
        try:
            b.Type = NXOpen.Features.SphereBuilder.Types.CenterPointAndDiameter
            b.CenterPoint = nxh.point(part, *c)
            b.Diameter.RightHandSide = str(F["d"])
            b.BooleanOption.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
            f = b.CommitFeature()
        finally:
            b.Destroy()
        return [x for x in f.GetBodies() if x.IsSolidBody]
    if t == "prism_x":                # outline in (z, y) on the plane x = x0, extruded along +x to x1 (side-wall features)
        sx = -1.0 if mirror else 1.0
        P3 = [(sx * F["x0"], p[1], p[0]) for p in F["outline_zy"]]
        n_ = len(P3)
        cs = [nxh.line(part, P3[i], P3[(i + 1) % n_]) for i in range(n_)]
        f = nxh.extrude(part, nxh.section(part, curves=cs, help_point=P3[0]), (sx, 0.0, 0.0), 0, F["x1"] - F["x0"])
        return [b for b in f.GetBodies() if b.IsSolidBody]
    if t in ("prism", "slot"):
        if t == "prism":
            pts = [tuple(p) for p in F["outline"]]
            holes = [[tuple(p) for p in F["hole"]]] if F.get("hole") else []
        else:
            pts = _slot_pts(F["c"], F["len"], F["w"], F["ang"]); holes = []
        if mirror:
            pts = [(-p[0], p[1]) for p in pts][::-1]
            holes = [[(-p[0], p[1]) for p in H][::-1] for H in holes]
        bodies = prism(part, pts, F["z0"], F["z1"], holes)
        for cp in F.get("cut_planes", []):
            p = _mx(cp["p"]) if mirror else cp["p"]; n = _mx(cp["n"]) if mirror else cp["n"]
            fpl, pl = nxh.datum_plane(part, tuple(p), tuple(n))
            for b in bodies:
                v0 = nxh.volume(part, b)
                ok = False
                for rev in (False, True):
                    m = nxh.mark("cut plane", False)
                    try:
                        nxf.trim_body(part, b, reverse=rev, datum_plane=pl)
                    except Exception:  # noqa: BLE001
                        nxh.undo_to(m); continue
                    # keep the side opposite n: test the bbox centre shift against n
                    bb = nxh.bbox(b); cen = [0.5 * (bb[k] + bb[k + 3]) for k in range(3)]
                    s = sum((cen[k] - p[k]) * n[k] for k in range(3))
                    if s <= 1e-6 and nxh.volume(part, b) < v0:
                        ok = True; break
                    nxh.undo_to(m)
                if not ok:
                    raise RuntimeError(f"{F['id']}: cut plane trim failed")
        return bodies
    raise RuntimeError(f"unknown feature type {t}")
