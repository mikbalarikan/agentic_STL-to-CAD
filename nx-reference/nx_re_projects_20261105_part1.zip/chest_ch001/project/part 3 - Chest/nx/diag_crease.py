"""Diagnose the neck crease edges of a revC1 result: per edge its length, end points and the face on the other side
(type, area, bbox). args: prt spec_json out_json"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

PRT, SPEC, OUTJ = sys.argv[1], sys.argv[2], sys.argv[3]
res = {}
try:
    S = json.load(open(SPEC))
    part = nxh.open_part(PRT)
    body = max([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked], key=lambda b: len(b.GetFaces()))
    faces = [(f, nxh.bbox(f)) for f in body.GetFaces()]

    def at(pts, tol):
        out = []
        for pt in pts:
            for f, bb in faces:
                if all(bb[i] - 0.3 <= pt[i] <= bb[i + 3] + 0.3 for i in range(3)) and abs(nxh.dist_to(part, f, pt)) < tol:
                    if f.Tag not in [g.Tag for g in out]:
                        out.append(f)
        return out
    fr = S["station_frames"]

    def fpts(off, back):
        pts = []
        for st in fr:
            for x in (1.0, -1.0):
                pt = [st["tip"][i] + back * st["e1"][i] + off * st["e2"][i] for i in range(3)]; pt[0] *= x; pts.append(pt)
        return pts
    for nm, off in (("out", 0.0), ("in", 3.25)):
        fs = at(fpts(off, -1.0), 0.02)
        rows = []
        for f in fs:
            for e in f.GetEdges():
                o = [g for g in e.GetFaces() if g.Tag != f.Tag]
                pp = nxh.edge_points(e, n=3)
                if not o:
                    continue
                g = o[0]
                rows.append({"p0": [round(v, 1) for v in pp[0]], "p1": [round(v, 1) for v in pp[2]],
                             "other_type": nxh.face_data(g)[0], "other_area": round(nxh.sheet_area(part, [g])[0], 1),
                             "other_bbox": [round(v, 1) for v in nxh.bbox(g)], "other_name": g.JournalIdentifier})
        res[nm] = {"faces": len(fs), "edges": rows}
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(OUTJ, res)
