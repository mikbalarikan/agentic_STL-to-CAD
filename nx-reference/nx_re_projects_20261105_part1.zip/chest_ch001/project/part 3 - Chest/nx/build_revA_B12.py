"""CH-001 Chest - native NX rebuild from the scan.  args: out_dir [stop_stage]
Frame: origin on the mirror plane x rim (parting) plane, at the height of the two shoulder-bore centres;
Z = rim-plane normal toward the open back, X = mirror-plane normal, Y toward the neck.
The RIGHT half (x >= 0) is built, then mirrored about the YZ datum plane and united; one-sided features after.
Stages: A skin envelope + inner-skin cavity -> constant-wall shell, shoulder flange + bore, neck cut;
F symmetric features; M mirror + unite; G one-sided features. Numbers: nx/params.json, work/*.json (an/)."""
import os, sys, json, math, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, curvekit as ck, nxre

OUT = sys.argv[1]
STOP = sys.argv[2] if len(sys.argv) > 2 else "Z"


def _fast_volume(part, body):
    """Bookkeeping volume at accuracy 0.99: nxh.volume measures at 0.999999, which takes tens of minutes on the
    shelled B-surface body (run outB4 spent most of its 5 h in those measurements)."""
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, 0.99, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


nxh.volume = _fast_volume
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest"
WK = os.path.join(ROOT, "work")
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": [], "checks": {}}
T0 = time.time()
os.makedirs(OUT, exist_ok=True)


def log(msg):
    res["log"].append(f"[{time.time()-T0:6.0f}s] {msg}")
    nxh.write_json(os.path.join(OUT, "build.json"), res)


P = json.load(open(os.path.join(ROOT, "nx", "params.json")))


def loft_sheet(part, jsonfile):
    sec = json.load(open(os.path.join(WK, jsonfile)))["sections"]
    sps = []
    for s in sec:
        f, sp = ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True)
        sps.append(sp)
    tc = nxf.through_curves(part, [nxh.section(part, curves=[sp]) for sp in sps], solid=False)
    return tc, tc.GetBodies()[0], sps


def trim_smaller(part, body, name, frac, **tool):
    """Trim Body keeping the side whose volume is below frac of the start volume (the bowl interior is ~1/3 of the
    block; nxf.trim_body's bounding-box keep test cannot tell the two sides of a bowl apart)."""
    v0 = nxh.volume(part, body)
    for rev in (False, True):
        m = nxh.mark("trim " + name, False)
        try:
            f, _r = nxf.trim_body(part, body, reverse=rev, **tool)
        except Exception as e:  # noqa: BLE001
            nxh.undo_to(m)
            log(f"{name}: trim reverse={rev} failed {e}")
            continue
        v1 = nxh.volume(part, body)
        if 0.02 * v0 < v1 < frac * v0:
            return f, v1
        nxh.undo_to(m)
    raise RuntimeError(f"{name}: no side of the trim gives a volume below {frac} of {v0:.0f}")


def trim_bigger(part, body, name, frac, **tool):
    """Trim Body keeping the side with more than frac of the start volume (small cut-offs)."""
    v0 = nxh.volume(part, body)
    for rev in (False, True):
        m = nxh.mark("trim " + name, False)
        try:
            f, _r = nxf.trim_body(part, body, reverse=rev, **tool)
        except Exception as e:  # noqa: BLE001
            nxh.undo_to(m)
            log(f"{name}: trim reverse={rev} failed {e}")
            continue
        v1 = nxh.volume(part, body)
        if frac * v0 < v1 < v0 - 1.0:
            return f, v1
        nxh.undo_to(m)
    raise RuntimeError(f"{name}: no side of the trim keeps more than {frac} of {v0:.0f}")


def block_trimmed(part, sheet, name, x0):
    bf, blk = nxh.block(part, (x0, -300.0, -150.0), (215.0 - x0, 445.0, 150.0))
    f, v1 = trim_smaller(part, blk, name, 0.5, sheet=sheet)
    return blk, v1


def check(name, ok, value=None):
    res["checks"][name] = {"ok": bool(ok), "value": value}
    if not ok:
        log(f"CHECK FAILED {name}: {value}")


def seg_curves(part, segs, z):
    """("L", p0, p1) | ("A", p0, p1, centre, r, ccw) in the plane Z = z."""
    cs = []
    for s in segs:
        if s[0] == "L":
            cs.append(nxh.line(part, (s[1][0], s[1][1], z), (s[2][0], s[2][1], z)))
        else:
            p0, p1, c, r, ccw = s[1], s[2], s[3], s[4], s[5]
            a0 = math.atan2(p0[1] - c[1], p0[0] - c[0]); a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
            if not ccw:
                a0, a1 = a1, a0
            while a1 <= a0:
                a1 += 2 * math.pi
            cs.append(nxh.arc(part, (c[0], c[1], z), (1, 0, 0), (0, 1, 0), r, a0, a1))
    return cs


def clip_unite(part, body, tools, envx):
    """Intersect each tool body with a kept copy of the envelope, unite the pieces into body."""
    pieces = []
    for t in tools:
        f = nxh.intersect(part, t, [envx], check=False, keep_tool=True)
        pieces += [b for b in f.GetBodies() if b.IsSolidBody]
    if pieces:
        nxh.unite(part, body, pieces, check=False)
    return len(pieces)


def solids(part, skip=()):
    return [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and b.Tag not in skip]


part = None
body = None
try:
    part = nxh.new_part(os.path.join(OUT, "Chest.prt"))
    SH = P["shoulder"]
    a = math.radians(SH["angle_deg"])
    nsh = (math.cos(a), math.sin(a), 0.0)
    for k, v in (("wall_t", P["wall_t"]), ("shoulder_angle", SH["angle_deg"]), ("shoulder_xc", SH["xc"]),
                 ("shoulder_bore_d", SH["bore_d"]), ("shoulder_flange_t", SH["flange_t"])):
        nxh.expr(part, k, v, "deg" if "angle" in k else "mm")
    dat = nxh.Datums(part)

    # ---- A: envelope (block below the rim, inside the exterior skin), right half only
    tc, skin, _ = loft_sheet(part, "sections.json")
    log(f"A skin loft: area {nxh.sheet_area(part, skin)[0]:.0f}")
    env, venv = block_trimmed(part, skin, "skin", 0.0)
    log(f"A envelope half {venv:.0f}")
    # shoulder: the ring face is the envelope cut by the shoulder plane
    c0 = (SH["xc"], 0.0, 0.0)
    fpl, pl_sh = nxh.datum_plane(part, c0, nsh, name="SHOULDER_R")
    trim_bigger(part, env, "shoulder plane", 0.8, datum_plane=pl_sh)
    # neck cut: closed plan profile above the neck edge, through all Z
    nk = [tuple(p) for p in P["neck"]["pts"]]
    zc = -200.0
    f_sp, sp = ck.studio_spline(part, [(x, y, zc) for x, y in nk], degree=3)
    xe, ye = nk[-1]
    cs = [sp, nxh.line(part, (xe, ye, zc), (xe, 150.0, zc)), nxh.line(part, (xe, 150.0, zc), (-5.0, 150.0, zc)),
          nxh.line(part, (-5.0, 150.0, zc), (-5.0, nk[0][1], zc)), nxh.line(part, (-5.0, nk[0][1], zc), (0.0, nk[0][1], zc))]
    fn = nxh.extrude(part, nxh.section(part, curves=cs, help_point=(0.0, nk[0][1], zc)), (0, 0, 1), 0, 260.0)
    nxh.subtract(part, env, fn.GetBodies(), check=False)
    log(f"A shoulder plane + neck cut: envelope {nxh.volume(part, env):.0f}")
    # front panel: flat racetrack plate inset into the skin (tilted tilt_deg about X) with a circular recess;
    # pocket + recess are cut into the envelope, the Shell then gives the plate (t_panel) and the disc (t_disc)
    PN = P["panel"]
    g = PN["dzdy"]
    cosg = 1.0 / math.sqrt(1.0 + g * g)
    npn = (0.0, -g * cosg, cosg)                                        # panel normal, toward the open back
    z_ext = PN["z_int_at_y_m100"] - PN["t_panel"] / cosg                # exterior plate plane at y = -100
    yc = PN["circle_c"][1]
    z_cf = PN["z_circle_int_at_c"] - PN["t_disc"] / cosg               # recess floor at the circle centre
    fpp, pl_pan = nxh.datum_plane(part, (0.0, -100.0, z_ext), npn, name="PANEL_EXT")
    fpc, pl_cf = nxh.datum_plane(part, (0.0, yc, z_cf), npn, name="PANEL_RECESS_FLOOR")
    cs = seg_curves(part, PN["outline_segs"], -160.0)
    fpk = nxh.extrude(part, nxh.section(part, curves=cs, help_point=tuple(PN["outline_segs"][0][1]) + (-160.0,)), (0, 0, 1), 0, 160.0)
    pk = [b for b in fpk.GetBodies() if b.IsSolidBody][0]
    trim_smaller(part, pk, "panel pocket tool", 0.5, datum_plane=pl_pan)
    fcy, cyl = nxh.cylinder(part, (0.0, yc, -160.0), (0, 0, 1), PN["circle_d"], 160.0)
    trim_smaller(part, cyl, "circle recess tool", 0.5, datum_plane=pl_cf)
    nxh.subtract(part, env, [pk, cyl], check=False)
    log(f"A panel pocket + circle recess: envelope {nxh.volume(part, env):.0f}")
    # exterior recesses (lower vent box, LED slot recess): outline prism limited to a band around the fitted floor,
    # trimmed by the floor plane (kept on the outside), cut into the envelope; the Shell then makes the box
    for rc in json.load(open(os.path.join(WK, "recesses.json"))):
        if rc["name"] not in P.get("recesses_on", ()):
            continue
        try:
            z0, z1 = rc["z_lo"] - 4.0, rc["z_hi"] + 1.5
            cs = seg_curves(part, rc["segs"], z0)
            fr = nxh.extrude(part, nxh.section(part, curves=cs, help_point=tuple(rc["segs"][0][1]) + (z0,)), (0, 0, 1), 0, z1 - z0)
            tool = [b for b in fr.GetBodies() if b.IsSolidBody][0]
            fpr, plr = nxh.datum_plane(part, tuple(rc["plane_pt"]), tuple(rc["normal"]), name="RECESS_" + rc["name"].upper())
            vt0 = nxh.volume(part, tool)
            nxf.trim_body(part, tool, reverse=True, datum_plane=plr)       # keep the side the outward normal points to
            vt1 = nxh.volume(part, tool)
            if not (0.0 < vt1 < vt0):
                raise RuntimeError(f"recess tool trim kept {vt1:.0f} of {vt0:.0f}")
            nxh.subtract(part, env, [tool], check=False)
            log(f"A recess {rc['name']}: envelope {nxh.volume(part, env):.0f}")
        except Exception as e:  # noqa: BLE001
            log(f"A recess {rc['name']} failed: {e}")
    ef, (envx,) = nxf.extract_body(part, [env])
    envx.Blank()
    # constant wall: Shell inward, the rim, mid-plane and neck faces open, the shoulder face a 4.6 flange
    walls, opened, shf, pfl, cfl = [], [], None, [], []
    for fc in env.GetFaces():
        t, _pt, d, _r = nxh.face_data(fc)          # UF gives no usable point for extruded (type 20) faces:
        bb = nxh.bbox(fc)                           # sort by the face bounding box instead
        pt = [0.5 * (bb[k] + bb[k + 3]) for k in range(3)]
        area = nxh.sheet_area(part, [fc])[0]
        if t == nxh.PLANE and abs(d[1] + npn[1]) < 1e-3 and abs(d[2] + npn[2]) < 1e-3:
            zp_ext = z_ext + g * (pt[1] + 100.0)
            zp_cf = z_cf + g * (pt[1] - yc)
            (pfl if abs(pt[2] - zp_ext) < abs(pt[2] - zp_cf) else cfl).append(fc)
        elif t == nxh.PLANE and abs(d[0] - nsh[0]) < 1e-3 and abs(d[1] - nsh[1]) < 1e-3:
            shf = fc                                  # shoulder ring face -> flange wall
        elif t == nxh.PLANE and abs(d[2] - 1.0) < 1e-4 and abs(bb[2]) < 0.05 and abs(bb[5]) < 0.05:
            opened.append(fc)                         # rim plane
        elif t == nxh.PLANE and abs(d[0] + 1.0) < 1e-4 and abs(bb[0]) < 0.05 and abs(bb[3]) < 0.05:
            opened.append(fc)                         # mid plane
        elif bb[1] > 36.0 and bb[3] < 72.0 and area < 20000.0:
            opened.append(fc)                         # neck cut faces
        else:
            walls.append(fc)                          # skin, panel pocket and recess walls
        res.setdefault("shell_faces", []).append([t, [round(v, 3) for v in d], round(area), [round(v, 1) for v in bb]])
    log(f"A shell faces: walls {len(walls)}, opened {len(opened)}, shoulder face {shf is not None}, panel {len(pfl)}, disc {len(cfl)}")
    v_env = nxh.volume(part, env)
    alt = ([([shf], "shoulder_flange_t")] if shf else []) + ([(pfl, str(PN["t_panel"]))] if pfl else []) + ([(cfl, str(PN["t_disc"]))] if cfl else [])
    nxf.shell(part, env, opened, "wall_t", inward=True, alternate=alt)
    body = env
    log(f"A shell: {v_env:.0f} -> {nxh.volume(part, body):.0f}")
    # front through hole, normal to the panel
    hc = PN["hole_c"]
    zh = z_ext + g * (hc[1] + 100.0)
    nxh.cylinder(part, (hc[0], hc[1] - 20.0 * npn[1], zh - 20.0 * npn[2]), npn, PN["hole_d"], 40.0, op=BOOL.Subtract, target=body)
    log(f"A front hole; body {nxh.volume(part, body):.0f}")
    # shoulder bore
    nxh.cylinder(part, tuple(c0[i] - 30.0 * nsh[i] for i in range(3)), nsh, SH["bore_d"], 60.0, op=BOOL.Subtract, target=body)
    log(f"A shoulder bore; body {nxh.volume(part, body):.0f}")
    # bottom: straight edge at the scanned min y (the skin beyond it is extrapolation) and the centre notch
    BT = P["bottom"]
    f1, b1 = nxh.block(part, (-10.0, -400.0, -200.0), (260.0, 400.0 + BT["y_edge"], 220.0))
    f2, b2 = nxh.block(part, (-10.0, -400.0, BT["notch_z"]), (10.0 + BT["notch_x"], 400.0 + BT["notch_y"], 20.0 - BT["notch_z"]))
    nxh.subtract(part, body, [b1, b2], check=False)
    log(f"A bottom edge + notch; body {nxh.volume(part, body):.0f}")
    SN = P["shoulder_notch"]
    nxh.cylinder(part, (SN["x"], SN["y0"], SN["z"]), (0, 1, 0), SN["d"], SN["y1"] - SN["y0"], op=BOOL.Subtract, target=body)
    log(f"A shoulder-top notch; body {nxh.volume(part, body):.0f}")
    check("A single solid", len(solids(part, (envx.Tag,))) == 1, [round(nxh.volume(part, b)) for b in solids(part, (envx.Tag,))])
    if STOP == "A":
        raise StopIteration

    # ---- F: flat-topped features of the right half (ribs, bosses, clips, pads): plateau outline extruded from
    # below up to its top level, clipped by the envelope copy, united
    PL = json.load(open(os.path.join(WK, "plateaus.json")))

    def inside(pt, segs):
        poly = [s[1] for s in segs]
        x, y = pt; c = False
        for i in range(len(poly)):
            (x1, y1), (x2, y2) = poly[i], poly[(i + 1) % len(poly)]
            if (y1 > y) != (y2 > y) and x < x1 + (y - y1) * (x2 - x1) / (y2 - y1):
                c = not c
        return c

    def plateau_tools(kinds):
        """(top, clipped tool bodies, unclipped tool bodies) per plateau loop. Every loop gets a column from below the
        part up to min(top, rim) that is clipped by the envelope (bosses reach down to the shell); a top above the rim
        (pins) gets an extra short unclipped piece from 1 mm below the rim."""
        tools = []
        for L in PL["loops"]:
            if L["kind"] not in kinds or L["area"] < 0:
                continue
            h = L["h"]
            holes = [M for M in PL["loops"] if M["area"] < 0 and abs(M["h"] - h) < 1e-6 and inside(M["segs"][0][1], L["segs"])]
            parts_ = []
            for (za, zb_) in ((-160.0, min(h, 0.0)),) + (((-1.0, h),) if h > 0.05 else ()):
                try:
                    cs = seg_curves(part, L["segs"], za)
                    for M in holes:
                        cs += seg_curves(part, M["segs"], za)
                    f = nxh.extrude(part, nxh.section(part, curves=cs, help_point=tuple(L["segs"][0][1]) + (za,)), (0, 0, 1), 0, zb_ - za)
                    parts_.append([b for b in f.GetBodies() if b.IsSolidBody])
                except Exception as e:  # noqa: BLE001
                    log(f"plateau {L['kind']} h {h} area {L['area']:.0f}: extrude failed {e}")
                    parts_.append([])
            tools.append((h, parts_[0] if parts_ else [], parts_[1] if len(parts_) > 1 else []))
        return tools

    def add_plateaus(kinds, envelope):
        n = 0
        for h, clipped, free in plateau_tools(kinds):
            try:
                if clipped:
                    n += clip_unite(part, body, clipped, envelope)
                if free:
                    nxh.unite(part, body, free, check=False); n += len(free)
            except Exception as e:  # noqa: BLE001
                log(f"plateau h {h}: clip/unite failed {e}")
        return n

    TH = json.load(open(os.path.join(WK, "through.json")))

    def cut_openings(kinds):
        tools = []
        for o in TH:
            if o["kind"] not in kinds or o["area"] < 3.0:
                continue
            try:
                if o["circle"]:
                    f, c_ = nxh.cylinder(part, (o["circle"][0], o["circle"][1], -200.0), (0, 0, 1), 2 * o["circle"][2], 205.0)
                    tools.append(c_)
                else:
                    cs = seg_curves(part, o["segs"], -200.0)
                    f = nxh.extrude(part, nxh.section(part, curves=cs, help_point=tuple(o["segs"][0][1]) + (-200.0,)), (0, 0, 1), 0, 205.0)
                    tools += [b for b in f.GetBodies() if b.IsSolidBody]
            except Exception as e:  # noqa: BLE001
                log(f"opening at {o['cen']}: {e}")
        if tools:
            nxh.subtract(part, body, tools, check=False)
        return len(tools)

    HO = json.load(open(os.path.join(WK, "holes.json")))

    def cut_holes(kinds):
        tools = []
        for hh in HO:
            if hh["kind"] not in kinds:
                continue
            ztop = hh["top"] + 1.0
            zb = hh["bottom"] if hh["bottom"] is not None else hh["top"] - 25.0
            f, c_ = nxh.cylinder(part, (hh["x"], hh["y"], zb), (0, 0, 1), hh["d_design"], ztop - zb)
            tools.append(c_)
        if tools:
            nxh.subtract(part, body, tools, check=False)
        return len(tools)

    def drop_crumbs(tag_skip, label):
        sol = solids(part, tag_skip)
        if len(sol) > 1:
            sol.sort(key=lambda b: -nxh.volume(part, b))
            log(f"{label}: {len(sol) - 1} loose pieces deleted {[round(nxh.volume(part, b)) for b in sol[1:]]}")
            nxf.delete_body(part, sol[1:])
            return sol[0]
        return sol[0] if sol else body

    n = add_plateaus(("R",), envx)
    log(f"F right-half plateaus {n}; body {nxh.volume(part, body):.0f}")
    body = drop_crumbs((envx.Tag,), "F")
    n = cut_openings(("R",))
    log(f"F right-half openings {n}; body {nxh.volume(part, body):.0f}")
    n = cut_holes(("R",))
    log(f"F right-half boss holes {n}; body {nxh.volume(part, body):.0f}")
    # styling groove (round bottom, tube along the scanned centre line on the skin)
    GR = json.load(open(os.path.join(WK, "grooves.json")))
    for name, gp in GR["paths"].items():
        if gp["kind"] != "R":
            continue
        try:
            f, sp = ck.studio_spline(part, [tuple(p) for p in gp["pts"]], degree=3)
            tf, tb = nxf.tube(part, GR["tube_d"], "0", curves=[sp])
            nxh.subtract(part, body, [tb], check=False)
            log(f"F groove {name}: body {nxh.volume(part, body):.0f}")
        except Exception as e:  # noqa: BLE001
            log(f"F groove {name} failed: {e}")
    check("F single solid", len(solids(part, (envx.Tag,))) == 1, [round(nxh.volume(part, b)) for b in solids(part, (envx.Tag,))])
    if STOP == "F":
        raise StopIteration

    # ---- M: mirror about the YZ datum plane (the mid-plane), unite; the envelope copy too
    fm, nb = nxf.mirror_geometry(part, [body], dat.yz)
    nxh.unite(part, body, [b for b in nb if b.IsSolidBody], check=False)
    fm2, nb2 = nxf.mirror_geometry(part, [envx], dat.yz)
    for b in nb2:
        b.Blank()
    log(f"M mirrored + united: body {nxh.volume(part, body):.0f}")
    check("M single solid", len(solids(part, [envx.Tag] + [b.Tag for b in nb2])) == 1)
    envf = envx
    try:
        nxh.unite(part, envx, [b for b in nb2 if b.IsSolidBody], check=False)
    except Exception as e:  # noqa: BLE001
        log(f"M envelope unite failed {e}")
    nxh.save(part); log("M saved")
    if STOP == "M":
        raise StopIteration

    # ---- G: features across the mid-plane (made symmetric in the analysis) and one-sided features
    n = add_plateaus(("C", "A"), envf)
    log(f"G mid-plane + one-sided plateaus {n}; body {nxh.volume(part, body):.0f}")
    body = drop_crumbs([envx.Tag] + [b.Tag for b in nb2], "G")
    n = cut_openings(("C",))
    log(f"G mid-plane openings {n}; body {nxh.volume(part, body):.0f}")
    n = cut_holes(("C", "A"))
    log(f"G one-sided boss holes {n}; body {nxh.volume(part, body):.0f}")
    if STOP == "G":
        raise StopIteration

    raise StopIteration
except StopIteration:
    pass
except Exception:
    res["error"] = traceback.format_exc()
    log("ERROR")
try:
    if part is not None:
        nxh.save(part)                      # save and export first: the checks below are slow on this body
        log("saved")
        sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
        res["solids"] = [round(nxh.volume(part, b), 1) for b in sol]
        if sol:
            big = max(sol, key=lambda b: nxh.volume(part, b))
            nxre.stl_export(part, big, os.path.join(OUT, f"chest_{STOP}.stl"), chord=0.01, max_edge=2.0)
            log("STL exported")
        res["feature_errors"] = [str(e) for e in nxh.feature_errors(part, recheck=False)][:20]
        res["body_ok"] = [nxh.body_ok(part, b) for b in sol]
        if "error" not in res:
            res["result"] = "PASS"
except Exception:
    res["error_final"] = traceback.format_exc()
res["t"] = round(time.time() - T0, 1)
nxh.write_json(os.path.join(OUT, "build.json"), res)
