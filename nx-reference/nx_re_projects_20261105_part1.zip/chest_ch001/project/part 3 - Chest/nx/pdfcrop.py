"""Rasterise a region of one PDF page. usage: pdfcrop.py in.pdf page(1-based) x0,y0,x1,y1(mm from top-left) out.png [dpi]"""
import sys
import fitz
doc = fitz.open(sys.argv[1]); pg = doc[int(sys.argv[2]) - 1]
x0, y0, x1, y1 = [float(t) * 72 / 25.4 for t in sys.argv[3].split(",")]
dpi = int(sys.argv[5]) if len(sys.argv) > 5 else 150
pg.get_pixmap(dpi=dpi, clip=fitz.Rect(x0, y0, x1, y1)).save(sys.argv[4])
print("ok")
