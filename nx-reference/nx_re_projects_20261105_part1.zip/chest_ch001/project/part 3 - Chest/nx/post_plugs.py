"""Stage P again on a finished build (features with op "subtract" are cut) (P is the last stage, so this equals a rebuild): unite the plug features of the
given work/c12 jsons into the body, save to out_dir/Chest.prt, export chest_G.stl.
args: built_prt out_dir plugs_a.json[,plugs_b.json ...]"""
import os, sys, json, time, traceback
SRC, OUTD, FILES = sys.argv[1], sys.argv[2], sys.argv[3].split(",")
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "build.py"), encoding="utf-8").read()
sys.argv = [sys.argv[0], OUTD, "Z"]
exec(src[:src.index("\npart = None\n")])          # imports, helpers, log() ...
import shutil
import c10_feat as cf
os.makedirs(OUTD, exist_ok=True)
dst = os.path.join(OUTD, "Chest.prt")
shutil.copyfile(SRC, dst)
part = nxh.open_part(dst)
try:
    sol = [b for b in part.Bodies if b.IsSolidBody]
    body = max([b for b in sol if not b.IsBlanked], key=lambda b: nxh.volume(part, b))
    log(f"body {nxh.volume(part, body):.0f}")
    nok = nf = 0
    for fn_ in FILES:
        for F in json.load(open(os.path.join(WK, "c12", fn_)))["features"]:
            for mir in ((False, True) if F["side"] == "R" else (False,)):
                try:
                    for b_ in cf.feature_bodies(part, F, mir):
                        (nxh.subtract if F.get("op") == "subtract" else nxh.unite)(part, body, [b_], check=False); nok += 1
                except Exception as e:  # noqa: BLE001
                    nf += 1; log(f"P plug {F['id']} mirror {mir} FAILED {str(e)[:150]}")
    log(f"P plugs: {nok} ok, {nf} failed; body {nxh.volume(part, body):.0f}")
    loose = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and b.Tag != body.Tag]
    if loose:
        log(f"loose pieces deleted {[round(nxh.volume(part, b)) for b in loose]}"); nxf.delete_body(part, loose)
    nxh.save(part); log("saved")
    nxre.stl_export(part, body, os.path.join(OUTD, "chest_G.stl"), chord=0.01, max_edge=2.0); log("STL exported")
    res["solids"] = [round(nxh.volume(part, b), 1) for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
    res["body_ok"] = nxh.body_ok(part, body)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc(); log("ERROR")
nxh.write_json(os.path.join(OUTD, "build.json"), res)
