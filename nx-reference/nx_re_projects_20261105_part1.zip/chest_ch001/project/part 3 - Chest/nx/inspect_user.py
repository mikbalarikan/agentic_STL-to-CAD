"""Read-only look at the user's edited part (run on a COPY): features after a given index, bodies, and an STL of the
largest solid. args: prt_copy out_dir first_index"""
import os, sys, json, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxre

PRT, OUT, FIRST = sys.argv[1], sys.argv[2], int(sys.argv[3])
res = {"result": "FAIL"}


def fvol(part, body, acc=0.99):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


try:
    part = nxh.open_part(PRT)
    feats = list(part.Features)
    res["n_features"] = len(feats)
    res["tail"] = []
    for i, f in enumerate(feats[FIRST:], FIRST):
        try:
            sup = f.Suppressed
        except Exception:  # noqa: BLE001
            sup = None
        res["tail"].append(f"{i} {f.GetFeatureName()} / {f.Name} / suppressed {sup}")
    res["current"] = str(nxh.current_feature(part).GetFeatureName()) if nxh.current_feature(part) else None
    sol = []
    for b in part.Bodies:
        try:
            conv = bool(b.IsConvergentBody)
        except Exception:  # noqa: BLE001
            conv = False
        if b.IsSolidBody and not conv:
            sol.append((fvol(part, b), b))
    res["solids"] = [(round(v), b.Name, b.IsBlanked) for v, b in sol]
    body = max(sol, key=lambda t: t[0])[1]
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["errors"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["stl"] = nxre.stl_export(part, body, os.path.join(OUT, "chest_user.stl"), chord=0.01, max_edge=2.5)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "inspect_user.json"), res)
