"""Bottom-edge cuts on a built chest part (copy): the extrapolated skin beyond the scanned bottom edge (y < Y_BOT) and
the bottom notch (|x| < NOTCH_X, z > NOTCH_Z, y < NOTCH_Y) are removed in ONE subtract.
args: src_prt out_dir"""
import os, sys, json, shutil, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
P = json.load(open(r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest\nx\params.json"))
BT = P["bottom"]
res = {"result": "FAIL", "log": []}


def fvol(part, body, acc=0.99):
    """Volume at a chosen accuracy (nxh.volume uses 0.999999, which takes tens of minutes on this body)."""
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()
T0 = time.time()


def log(m):
    res["log"].append(f"[{time.time()-T0:6.0f}s] {m}")
    nxh.write_json(os.path.join(OUT, "post_fix.json"), res)


try:
    dst = os.path.join(OUT, "Chest.prt")
    shutil.copyfile(SRC, dst)
    part = nxh.open_part(dst)
    sol = sorted([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked], key=lambda b: -fvol(part, b))
    body = sol[0]
    v0 = fvol(part, body)
    log(f"opened; body {v0:.0f}, solids {len(sol)}")
    f1, b1 = nxh.block(part, (-250.0, -400.0, -200.0), (500.0, 400.0 + BT["y_edge"], 220.0))
    f2, b2 = nxh.block(part, (-BT["notch_x"], -400.0, BT["notch_z"]), (2 * BT["notch_x"], 400.0 + BT["notch_y"], 20.0 - BT["notch_z"]))
    nxh.subtract(part, body, [b1, b2], check=False)
    v1 = fvol(part, body)
    log(f"bottom edge + notch cut: {v0:.0f} -> {v1:.0f}")
    sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
    res["solids"] = [round(fvol(part, b), 1) for b in sol]
    nxh.save(part)
    nxre.stl_export(part, body, os.path.join(OUT, "chest_post.stl"), chord=0.01, max_edge=2.0)
    log("saved + STL")
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "post_fix.json"), res)
