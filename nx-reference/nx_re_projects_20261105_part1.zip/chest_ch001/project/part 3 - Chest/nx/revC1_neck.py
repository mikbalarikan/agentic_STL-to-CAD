﻿"""CH-001 Rev C: neck U opening rebuilt from the scan's design intent (2026-10-31, user: "throw the neck U away and
redraw it continuous and clean"). Appended at the END of the user's history on a COPY of their last saved master
(Deviation_Check/CH-001_Chest_RevB_vs_SCAN_END_POSTS.prt, 08:10). None of the earlier neck patches (revB4..B14) are in it.
args: src_prt dst_prt spec_json

Scan analysis (an/r2_edge.py, r2_prof.py, r2_ruled.py, r2_lower.py, r2_neckspec.py -> work/r2/neckspec.json):
the opening edge is ONE constant flange all round the U: 3.25-3.35 thick, square end face, both faces ruled along
one direction D (25.6 deg from +Z toward +Y, within +-2 deg at every station). The wall bends into it along a single
bend line B: 3-6 deg at the U bottom (in line), 11-28 deg at the corners, 40-68 deg up the arms. The old outer skin
bulged 1-3 mm past the scan within 8 mm of the edge at the corners and arms; behind B it matches the scan.

Features (all new, named NECK_*):
1 NECK_FLANGE_PROFILE: the flange outer face seen along D (fitted spline, symmetric) -> NECK_FLANGE_SURF_A / _B:
  sheet extrudes along D (the flange outer face S_out, two copies).
2 NECK_TIP_CURVE (the opening edge, on S_out) and NECK_BAND_CURVE (14 mm back along the flange).
  S_out copy A trimmed to the opening region (NECK_OPEN_SHEET), copy B to the band tip..14 mm (NECK_BAND_SHEET).
3 NECK_OPEN_CUT = Thicken of the opening sheet +-12 -> subtract: everything beyond the edge goes (old lips, chamfers,
  notches); its side face along NECK_TIP_CURVE is the new end face, normal to the flange, one face round the U.
4 NECK_OUTSIDE_CUT = Thicken of the band sheet 12 outward -> subtract: the old skin bulge outside S_out goes.
5 NECK_FLANGE = Thicken of the band sheet CH_NECK_FLANGE_T inward, minus NECK_SKIN_OUT (Thicken outward of the old
  outer skin faces behind the bend = everything outside the skin) and minus the space above the rim -> united. Its
  outer face meets the old skin exactly on B; behind B it lies inside the old wall.
6 NECK_BEND_OUT (R CH_NECK_BEND_RO) on the outer crease along B, NECK_BEND_IN (R CH_NECK_BEND_RI) on the inner crease."""
import os, sys, math, json, shutil, traceback, time
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, os.path.join(os.path.dirname(os.environ["NXH_DIR"].rstrip("\\/")), "..", "nx-curves-and-sketches", "scripts"))
import NXOpen
import nxh, nxf, nxre
import curvekit as ck

SRC, DST, SPEC = sys.argv[1], sys.argv[2], sys.argv[3]
OUT = os.path.dirname(DST)
STOP = sys.argv[4] if len(sys.argv) > 4 else "Z"
os.makedirs(OUT, exist_ok=True)
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": [], "probes": {}}
T0 = time.time()
JS = os.path.splitext(DST)[0] + "_neck.json"


def log(m):
    res["log"].append(f"[{time.time() - T0:5.0f}s] {m}")
    nxh.write_json(JS, res)


def is_conv(b):
    try:
        return bool(b.IsConvergentBody)
    except Exception:  # noqa: BLE001
        return False


def fvol(part, body, acc=0.99):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


def inside(part, b, xyz):
    return nxh.dist_to(part, b, xyz) < 1e-4


def new_bodies(part, before, solid=None):
    tags = {b.Tag for b in before}
    return [b for b in part.Bodies if b.Tag not in tags and (solid is None or b.IsSolidBody == solid)]


_BB = {}


def faces_at(part, body, pts, tol):
    """nxh.face_at for many points, with a bounding-box prefilter (face_at alone took 500 s on this body)."""
    key = (body.Tag, len(body.GetFaces()))
    if _BB.get("key") != key:
        _BB["key"] = key
        _BB["faces"] = [(f_, nxh.bbox(f_)) for f_ in body.GetFaces()]
    out = []
    for pt in pts:
        for f_, bb in _BB["faces"]:
            if all(bb[i] - 0.3 <= pt[i] <= bb[i + 3] + 0.3 for i in range(3)):
                if abs(nxh.dist_to(part, f_, pt)) < tol and f_.Tag not in [g.Tag for g in out]:
                    out.append(f_)
    return out


def thicken_checked(part, sheet, a, b, inside_pts, outside_pts, name):
    """Thicken sheet over (a, b) along its normal; if the probes say the wrong side, flip. Returns the solid."""
    for rev in (False, True):
        mk = nxh.mark("thk " + name, False)
        before = list(part.Bodies)
        try:
            f = nxf.thicken(part, sheet, a, b, reverse=rev)
        except Exception as ex:  # noqa: BLE001
            log(f"{name}: thicken ({a}, {b}) reverse={rev} refused: {str(ex)[:90]}")
            nxh.undo_to(mk)
            continue
        sol = new_bodies(part, before, True)
        ok = len(sol) == 1 and all(inside(part, sol[0], q) for q in inside_pts) and not any(inside(part, sol[0], q) for q in outside_pts)
        if ok:
            f.SetName(name)
            log(f"{name}: thicken ({a}, {b}) reverse={rev}")
            return sol[0]
        nxh.undo_to(mk)
    raise RuntimeError(f"{name}: no thicken side satisfies the probes")


try:
    S = json.load(open(SPEC))
    Dv, Uv, Vv = S["D"], S["U"], S["V"]
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)
    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: fvol(part, b))
    res["features_before"] = len(list(part.Features))
    res["errors_before"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    E = {k: nxh.expr(part, nm, val, unit=u, comment=cm).Name for k, nm, val, u, cm in (
        ("T", "CH_NECK_FLANGE_T", 3.25, "mm", "neck flange thickness (scan 3.25-3.35)"),
        ("A", "CH_NECK_D_ANGLE", S["angle_deg"], "deg", "neck flange rule direction D: from +Z toward +Y"),
        ("RO", "CH_NECK_BEND_RO", 4.0, "mm", "outer bend radius wall -> flange"),
        ("RI", "CH_NECK_BEND_RI", 2.5, "mm", "inner bend radius wall -> flange"))}
    v0 = fvol(part, body)
    log(f"opened; body volume {v0:.0f}")

    # ---------------------------------------------------------------- 1 flange outer face S_out
    lam0, lam1 = S["lam_min"], S["lam_max"]
    pts = [tuple(u * Uv[i] + v * Vv[i] + lam0 * Dv[i] for i in range(3)) for u, v in S["c_uv"]]
    fpc, cprof = ck.studio_spline(part, pts, degree=3)
    if fpc is not None:
        fpc.SetName("NECK_FLANGE_PROFILE")
    sheets = []
    for nm in ("A", "B"):
        before = list(part.Bodies)
        fe = nxh.extrude(part, nxh.section(part, curves=[cprof], help_point=pts[len(pts) // 2]), tuple(Dv), 0, round(lam1 - lam0, 3), sheet=True)
        fe.SetName(f"NECK_FLANGE_SURF_{nm}")
        sh = new_bodies(part, before, False)
        assert len(sh) == 1, f"S_out {nm}: {len(sh)} sheets"
        sheets.append(sh[0])
    SA, SB = sheets
    # ---------------------------------------------------------------- 2 tip + band curves, trims
    ftc, tipc = ck.studio_spline(part, [tuple(p) for p in S["tip_xyz"]], degree=3)
    if ftc is not None:
        ftc.SetName("NECK_TIP_CURVE")
    fbc, backc = ck.studio_spline(part, [tuple(p) for p in S["back_xyz"]], degree=3)
    if fbc is not None:
        fbc.SetName("NECK_BAND_CURVE")
    PB = S["probes"]

    def on_sheet(sh, xyz):
        """closest point of the sheet's (single) face: region points must lie exactly on the sheet"""
        fc = sh.GetFaces()[0]
        _parm, pnt = nxh.UFS.Modeling.AskFaceParm(fc.Tag, [float(v) for v in xyz])
        return tuple(pnt)
    op_pt = on_sheet(SA, S["open_pt"])
    band_pt = on_sheet(SB, PB[6]["band_pt"])
    log(f"region points: open {op_pt} (spec {S['open_pt']}), band {band_pt}")
    nxf.trim_sheet(part, SA, op_pt, keep=True, curves=[tipc], hp=tuple(S["tip_xyz"][0])).SetName("NECK_OPEN_SHEET")
    nxf.trim_sheet(part, SB, band_pt, keep=True, curves=[tipc], hp=tuple(S["tip_xyz"][0])).SetName("NECK_BAND_SHEET_TIP")
    band_pt = on_sheet(SB, PB[6]["band_pt"])
    nxf.trim_sheet(part, SB, band_pt, keep=True, curves=[backc], hp=tuple(S["back_xyz"][0])).SetName("NECK_BAND_SHEET")
    _, pl_rim0 = nxh.datum_plane(part, (0, 0, 0.0), (0, 0, 1), name="NECK_BAND_RIM_PLANE")
    band_pt = on_sheet(SB, PB[6]["band_pt"])
    nxf.trim_sheet(part, SB, band_pt, keep=True, datum_plane=pl_rim0).SetName("NECK_BAND_SHEET_RIM")
    res["sheet_area"] = {"open": round(nxh.sheet_area(part, list(SA.GetFaces()))[0]), "band": round(nxh.sheet_area(part, list(SB.GetFaces()))[0])}
    log(f"sheets trimmed: {res['sheet_area']}")
    if STOP == "S":
        raise StopIteration

    # ---------------------------------------------------------------- 3 + 4 cuts
    opn = thicken_checked(part, SA, 12, -12, [q["open_air"] for q in PB], [q["fl_in"] for q in PB], "NECK_OPEN_CUT")
    bey = thicken_checked(part, SB, 6, 0,[q["out_air"] for q in PB], [q["fl_in"] for q in PB], "NECK_OUTSIDE_CUT")
    # ---------------------------------------------------------------- 5 flange
    fl = thicken_checked(part, SB, E["T"], 0, [q["fl_in"] for q in PB], [q["out_air"] for q in PB], "NECK_FLANGE_RAW")
    # old outer skin faces behind the bend -> sheet -> thicken outward = everything just outside the skin
    sk = faces_at(part, body, [(x * q["skin"][0], q["skin"][1], q["skin"][2]) for q in PB for x in (1.0, -1.0)], 0.08)
    log(f"old skin faces behind the bend: {len(sk)} bboxes {[[round(v, 1) for v in nxh.bbox(g)] for g in sk]}")
    assert sk, "no skin face found"
    before = list(part.Bodies)
    fx = nxf.extract_face(part, sk, associative=False)
    fx.SetName("NECK_SKIN_COPY")
    sks = new_bodies(part, before, False)
    # the whole Rev A skin cannot be offset 13 mm (concave shoulders): keep only the neck end of the copy
    for nm_, org, nrm, keep in (("Y", (0, 22.0, 0), (0, 1, 0), (0.0, 60.0)), ("XP", (78.0, 0, 0), (1, 0, 0), (-1.0, 0.0)),
                                ("XN", (-78.0, 0, 0), (-1, 0, 0), (1.0, 0.0))):
        _, pl_ = nxh.datum_plane(part, org, nrm, name=f"NECK_SKIN_COPY_TRIM_{nm_}")
        for s_ in sks:
            kp = [q["skin"] for q in PB][6]
            kp = (abs(kp[0]) * (1.0 if nm_ != "XN" else -1.0) if nm_ != "Y" else kp[0], kp[1], kp[2])
            nxf.trim_sheet(part, s_, on_sheet(s_, kp), keep=True, datum_plane=pl_).SetName(f"NECK_SKIN_COPY_{nm_}")
    outs = []
    for i, s_ in enumerate(sks):
        pin = [(x * q["skin_out"][0], q["skin_out"][1], q["skin_out"][2]) for q in PB for x in (1.0, -1.0)
               if nxh.dist_to(part, s_, (x * q["skin"][0], q["skin"][1], q["skin"][2])) < 0.1][:6]
        assert pin, f"skin sheet {i}: no probe on it"
        outs.append(thicken_checked(part, s_, 13, 0, pin, [q["fl_in"] for q in PB[6:9]], f"NECK_SKIN_OUT_{i}"))
    nxh.subtract(part, fl, outs, check=False).SetName("NECK_FLANGE_CLIP_SKIN")
    fls = [b for b in new_bodies(part, before, True) if b.Tag not in [o.Tag for o in outs]]
    fls = [b for b in part.Bodies if b.IsSolidBody and b.Tag in [x.Tag for x in fls]] or [fl]
    log(f"flange pieces after the skin clip: {[[round(v, 2) for v in nxh.bbox(b)] for b in fls]}")
    # rim: Trim Body on the rim plane (a block subtract is refused: the skin-clip edge lies exactly on z 0)
    _, pl_rim = nxh.datum_plane(part, (0, 0, 0.0), (0, 0, 1), name="NECK_RIM_PLANE")
    probe_low = PB[6]["fl_in"]
    for b in list(fls):
        mk = nxh.mark("rim trim", False)
        done = False
        for rev in (False, True):
            try:
                nxf.trim_body(part, b, datum_plane=pl_rim, reverse=rev)[0].SetName("NECK_FLANGE_CLIP_RIM")
            except Exception as ex:  # noqa: BLE001
                log(f"rim trim reverse={rev} refused: {str(ex)[:80]}")
                nxh.undo_to(mk)
                continue
            if inside(part, b, probe_low):
                done = True
                break
            nxh.undo_to(mk)
        log(f"rim trim done: {done}")
    fls = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b) and b.Tag != body.Tag
           and b.Tag not in [x.Tag for x in cand] and b.Tag not in (opn.Tag, bey.Tag)]
    res["flange_pieces"] = [round(fvol(part, b), 1) for b in fls]
    log(f"flange pieces {res['flange_pieces']}")
    if STOP == "F":
        raise StopIteration
    v1 = fvol(part, body)
    nxh.subtract(part, body, [opn], check=False).SetName("NECK_OPEN_CUT_SUB")
    v2 = fvol(part, body)
    nxh.subtract(part, body, [bey], check=False).SetName("NECK_OUTSIDE_CUT_SUB")
    v3 = fvol(part, body)
    sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b) and b.Tag not in [x.Tag for x in fls]]
    log(f"cuts: open {v1 - v2:.0f}, outside {v2 - v3:.0f} mm3; solids now {len(sol)}")
    if len(sol) > 1:
        sol.sort(key=lambda b: -fvol(part, b))
        res["crumbs"] = [round(fvol(part, b), 1) for b in sol[1:]]
        nxf.delete_body(part, sol[1:])
        log(f"loose pieces deleted {res['crumbs']}")
    nxh.unite(part, body, fls, check=False).SetName("NECK_FLANGE_UNITE")
    v4 = fvol(part, body)
    log(f"flange united: +{v4 - v3:.0f} mm3")
    for q in PB:
        res["probes"][f"k{q['k']}"] = {n_: round(nxh.dist_to(part, body, q[n_]), 3) for n_ in ("fl_in", "out_air", "open_air")}
    if STOP == "U":
        raise StopIteration

    # ---------------------------------------------------------------- 6 bend blends
    fr = S["station_frames"]
    def flange_face(off, back=-1.0, tol=0.02):
        pts = []
        for st in fr:
            e1, e2, tp = st["e1"], st["e2"], st["tip"]
            for x in (1.0, -1.0):
                pt = [tp[i] + back * e1[i] + off * e2[i] for i in range(3)]
                pt[0] *= x
                pts.append(pt)
        return faces_at(part, body, pts, tol)
    fo = flange_face(0.0)
    fi = flange_face(3.25)
    tipf = flange_face(1.6, back=0.0, tol=0.05)
    res["faces"] = {"flange_out": len(fo), "flange_in": len(fi), "tip": len(tipf)}
    log(f"flange faces: out {len(fo)}, in {len(fi)}, tip {len(tipf)}")
    skip = {f_.Tag for f_ in fo + fi + tipf}

    def crease_edges(faces):
        es = []
        for f_ in faces:
            for e in f_.GetEdges():
                other = [g for g in e.GetFaces() if g.Tag != f_.Tag]
                if not other or other[0].Tag in skip:
                    continue
                pp = nxh.edge_points(e, n=5)
                if min(p[2] for p in pp) > -0.3:          # rim
                    continue
                if e.Tag not in [x.Tag for x in es]:
                    es.append(e)
        return es
    eo, ei = crease_edges(fo), crease_edges(fi)
    res["crease_edges"] = {"out": len(eo), "in": len(ei)}
    log(f"crease edges {res['crease_edges']}")
    # old rim lip + plate at the outer arm-top corner, beyond the scan (scan above the rim ends at y 111.7, the wall
    # outer corner at y 114.3): A = the plate y > 115.2 (z -5..5), B = the lip above the rim y 111.8..115.2
    for nm_, org, size in (("A", (54.5, 115.2, -5.0), (17.5, 11.0, 10.0)),):
        mk = nxh.mark("arm top " + nm_, False)
        blks = [nxh.block(part, org, size)[1], nxh.block(part, (-org[0] - size[0], org[1], org[2]), size)[1]]
        try:
            nxh.subtract(part, body, blks, check=False).SetName(f"NECK_ARM_TOP_TRIM_{nm_}")
            log(f"arm-top trim {nm_} done")
        except Exception as ex:  # noqa: BLE001
            log(f"arm-top trim {nm_} refused: {str(ex)[:80]}")
            nxh.undo_to(mk)
    sol2 = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b) and b.Tag != body.Tag
            and b.Tag not in [x.Tag for x in cand]]
    if sol2:
        log(f"loose after arm-top trim: {[round(fvol(part, b), 1) for b in sol2]}")
        nxf.delete_body(part, sol2)
    # bend blends: only the crease against the big skin face (outer) / big inner wall face (inner): one chain each
    _BB.clear()
    fo = flange_face(0.0); fi = flange_face(3.25)

    _area = {}

    def area_of(g):
        if g.Tag not in _area:
            _area[g.Tag] = nxh.sheet_area(part, [g])[0]
        return _area[g.Tag]

    def big_crease(faces, amin=5000.0):
        es = []
        for f_ in faces:
            for e in f_.GetEdges():
                o = [g for g in e.GetFaces() if g.Tag != f_.Tag]
                if o and area_of(o[0]) > amin and e.Tag not in [x.Tag for x in es]:
                    es.append(e)
        return es
    eo, ei = big_crease(fo), big_crease(fi)
    res["crease_big"] = {"out": len(eo), "in": len(ei)}
    log(f"crease edges against the big faces: {res['crease_big']}")
    rep = []
    if eo:
        rep += nxf.blend_chains(part, [(eo, E["RO"])], 4.0, smaller=(0.75, 0.5), chamfer=False, overflow="retry")
    if ei:
        rep += nxf.blend_chains(part, [(ei, E["RI"])], 2.5, smaller=(0.6,), chamfer=False, overflow="retry")
    res["blends"] = [{k: (v if isinstance(v, (str, int, float, bool, type(None))) else str(v)[:200]) for k, v in r.items()
                      if k in ("built", "size", "overflow", "edges", "treated", "untreated", "errors")} for r in rep]
    log(f"blends {res['blends']}")
except StopIteration:
    log("stopped at stage " + STOP)
except Exception:
    res["error"] = traceback.format_exc()
    log("ERROR")
try:
    res["solids_after"] = len([bb for bb in part.Bodies if bb.IsSolidBody and not bb.IsBlanked and not is_conv(bb)])
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["features_after"] = len(list(part.Features))
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["new_features"] = [g.GetFeatureName() + " / " + g.Name for g in list(part.Features)[res["features_before"]:]]
    # tool sheets / bodies left visible would clutter the user's view: blank them
    for b in part.Bodies:
        if b.Tag != body.Tag and not is_conv(b) and not b.IsBlanked and b.Tag not in [x.Tag for x in cand if x.Tag != body.Tag]:
            try:
                b.Blank()
            except Exception:  # noqa: BLE001
                pass
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    res["stl"] = nxre.stl_export(part, body, os.path.join(OUT, "chest_C1.stl"), chord=0.01, max_edge=2.5)
    ok = res["body_ok"] and res["solids_after"] == 1 and len(res["errors_after"]) <= len(res["errors_before"]) and "error" not in res
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error_final"] = traceback.format_exc()
nxh.write_json(JS, res)






