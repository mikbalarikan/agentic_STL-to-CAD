"""CH-001 Rev B: neck lip all round + bottom-end band up the arms (2026-10-31, user: "complete it"), appended at the END of the user's history on a COPY
of Deviation_Check/CH-001_Chest_RevB_vs_SCAN_END_POSTS.prt (saved by the user 08:10). args: src_prt dst_prt

Scan (an/r1_necklip.py, sections y 70 / 90): along both arms of the neck opening (rim down to y ~45) the wall turns up
into a lip on its inner side, about 3.0 thick, standing ~3.5 above the inner wall; its outer face is the existing neck
cut face. NECK_LIP_R = thin Extrude (3.0 into the material) of the edge between the neck cut face and the inner wall,
along +z from 1 mm below the edge to 3.5 above it; Mirror Geometry + Unite for the left arm."""
import os, sys, math, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, DST = sys.argv[1], sys.argv[2]
OUT = os.path.dirname(DST)
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": []}
log = res["log"].append
LIP_T, LIP_H, LIP_BELOW, LIP_R = 3.0, 5.5, 1.0, 1.2
CUT_PT = (47.5, 70.0, -73.8)            # on the right neck cut face (CAD section y 70)
Y_MIN = 56.0                            # the lip ends here (scan: below it the lip fades into the U bottom)


def fvol(part, body, acc=0.99):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


def is_conv(b):
    try:
        return bool(b.IsConvergentBody)
    except Exception:  # noqa: BLE001
        return False


def inside(part, b, xyz):
    return nxh.dist_to(part, b, xyz) < 1e-4


def new_solids(part, before):
    tags = {b.Tag for b in before}
    return [b for b in part.Bodies if b.IsSolidBody and b.Tag not in tags]


try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)
    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: fvol(part, b))
    res["features_before"] = len(list(part.Features))
    res["errors_before"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    v0 = fvol(part, body)
    D = nxh.Datums(part)
    E = {k: nxh.expr(part, nm, val, comment=cm).Name for k, nm, val, cm in (
        ("T", "CH_NECK_LIP_T", LIP_T, "neck lip thickness (from the neck cut face into the wall)"),
        ("H", "CH_NECK_LIP_H", LIP_H, "neck lip height above the edge of the inner wall (along z)"))}

    dc = sorted(((nxh.dist_to(part, fc, CUT_PT), i, fc) for i, fc in enumerate(body.GetFaces())), key=lambda t: t[:2])
    cut = dc[0][2]
    ncut = nxh.normal_at(cut, CUT_PT)
    log(f"face at the probe: {dc[0][0]:.4f} mm, normal {[round(x, 3) for x in ncut]}, bbox {[round(x, 1) for x in nxh.bbox(cut)]}")
    if abs(ncut[2]) > 0.15:
        # the probe hit the user's chamfer on the outer neck edge: step to the vertical neck cut face above it
        best = None
        for e in cut.GetEdges():
            pts = nxh.edge_points(e, n=7)
            L = sum(math.dist(pts[i], pts[i + 1]) for i in range(6))
            for g in e.GetFaces():
                if g.Tag != cut.Tag and abs(nxh.normal_at(g, pts[3])[2]) < 0.12 and (best is None or L > best[0]):
                    best = (L, g)
        cut = best[1]
        log(f"stepped to the vertical neck cut face, bbox {[round(x, 1) for x in nxh.bbox(cut)]}")
    edges = []
    for e in cut.GetEdges():
        bb = nxh.bbox(e)
        pts = nxh.edge_points(e, n=7)
        m = pts[3]
        others = [g for g in e.GetFaces() if g.Tag != cut.Tag]
        if not others:
            continue
        nz = nxh.normal_at(others[0], m)[2]
        L = sum(math.dist(pts[i], pts[i + 1]) for i in range(6))
        log(f"  cut edge bbox {[round(x, 1) for x in bb]} len {L:.1f} other nz {nz:.2f}")
        if nz > 0.2 and bb[4] > Y_MIN + 5 and L > 2.0:
            edges.append(e)
    assert edges, "no inner-wall edge on the neck cut face"
    # continue to the rim: the edge between the plane x 56.38 (top end of the neck cut) and the inner wall
    TOP_MID = (56.38, 109.1, -8.82)
    top = [e for e in body.GetEdges() if math.dist(nxh.edge_points(e, n=3)[1], TOP_MID) < 0.3]
    log(f"top-end edges to the rim: {len(top)}")
    edges += top
    # the left half: the mirror images of these edges, so ONE thin extrude runs round the whole U (no seam at x 0)
    def mirror_of(es):
        out = []
        for e in es:
            mm = nxh.edge_points(e, n=3)[1]
            tgt = (-mm[0], mm[1], mm[2])
            out += [g for g in body.GetEdges() if math.dist(nxh.edge_points(g, n=3)[1], tgt) < 0.3]
        return out

    main_R = [e for e in edges if e not in top]
    main_L, top_L = mirror_of(main_R), mirror_of(top)
    log(f"edges: main R {len(main_R)}, top R {len(top)}, main L {len(main_L)}, top L {len(top_L)}")
    res["edges"] = [[round(x, 1) for x in nxh.bbox(e)] for e in main_R + top]

    # material side at the point of the right edge nearest y 70 (middle of the right arm)
    sam = [p for e in main_R for p in nxh.edge_points(e, n=201)]
    k = min(range(len(sam)), key=lambda i: abs(sam[i][1] - 70.0))
    k = min(max(k, 2), len(sam) - 3)
    m = sam[k]; a, b_ = sam[k - 2], sam[k + 2]
    log(f"arm probe point on the edge {[round(c, 2) for c in m]}")
    t = [b_[0] - a[0], b_[1] - a[1]]; lt = math.hypot(*t); t = [t[0] / lt, t[1] / lt]
    pdir = [-t[1], t[0]]
    s = pdir if inside(part, body, (m[0] + 0.8 * pdir[0], m[1] + 0.8 * pdir[1], m[2] - 1.0)) else [-pdir[0], -pdir[1]]
    q_in = (m[0] + 1.5 * s[0], m[1] + 1.5 * s[1], m[2] + 2.0)
    q_out = (m[0] - 1.0 * s[0], m[1] - 1.0 * s[1], m[2] + 2.0)
    q_in_L = (-q_in[0], q_in[1], q_in[2])

    def lip_and_unite(es, label):
        """Thin extrude of the chain (the side that holds q_in) + Unite. Undone completely when refused."""
        mk0 = nxh.mark("lip " + label, False)
        for thin in ((0, E["T"]), (f"-{E['T']}", 0)):
            mk = nxh.mark("thin", False)
            before = list(part.Bodies)
            try:
                f = nxf.extrude_ex(part, nxh.section(part, edges=es, help_point=tuple(m)), (0, 0, 1),
                                   start=-LIP_BELOW, end=E["H"], thin=thin)
            except Exception as ex:  # noqa: BLE001
                log(f"{label}: thin {thin} failed: {str(ex)[:100]}")
                nxh.undo_to(mk)
                continue
            bs = new_solids(part, before)
            if not (bs and any(inside(part, x, q_in) for x in bs) and not any(inside(part, x, q_out) for x in bs)):
                log(f"{label}: thin {thin} on the wrong side")
                nxh.undo_to(mk)
                continue
            try:
                fu = nxh.unite(part, body, tools=bs, check=False)
            except Exception as ex:  # noqa: BLE001
                log(f"{label}: unite refused ({str(ex)[:90]})")
                nxh.undo_to(mk0)
                return None
            return f, fu, thin, sum(fvol(part, x) for x in bs) if False else 0.0
        nxh.undo_to(mk0)
        return None

    # one lip per side (the thin extrude overshoots x 0 at the bottom of the U, so two halves would overlap there):
    # each half is trimmed at |x| 20 - the bottom of the U is shaped by NECK_U_TIP_CUT (|x| < 40) anyway
    X_END = 20.0
    for side, es, qi, qo in (("R", main_R + top, q_in, q_out), ("L", main_L + top_L, q_in_L, (-q_out[0], q_out[1], q_out[2]))):
        made = None
        for thin in ((0, E["T"]), (f"-{E['T']}", 0)):
            mk = nxh.mark("thin", False)
            before = list(part.Bodies)
            try:
                f = nxf.extrude_ex(part, nxh.section(part, edges=es, help_point=tuple(nxh.edge_points(es[0], n=3)[1])),
                                   (0, 0, 1), start=-LIP_BELOW, end=E["H"], thin=thin)
            except Exception as ex:  # noqa: BLE001
                log(f"{side}: thin {thin} failed: {str(ex)[:100]}")
                nxh.undo_to(mk)
                continue
            bs = new_solids(part, before)
            if bs and any(inside(part, x, qi) for x in bs) and not any(inside(part, x, qo) for x in bs):
                made = (f, bs, thin)
                break
            log(f"{side}: thin {thin} on the wrong side")
            nxh.undo_to(mk)
        assert made is not None, f"neck lip {side} not made"
        f, bs, thin = made
        f.SetName(f"NECK_LIP_{side}")
        sx = 1.0 if side == "R" else -1.0
        _, plx = nxh.datum_plane(part, (sx * X_END, 0, 0), (sx, 0, 0), name=f"NECK_LIP_{side}_END_PLANE")
        for x in bs:
            mk = nxh.mark("trim", False)
            ftb, _ = nxf.trim_body(part, x, datum_plane=plx, reverse=True)       # keep the arm side (|x| > 20)
            if not inside(part, x, qi):
                nxh.undo_to(mk)
                ftb, _ = nxf.trim_body(part, x, datum_plane=plx, reverse=False)
            assert inside(part, x, qi), f"lip {side} lost the arm in the trim"
            ftb.SetName(f"NECK_LIP_{side}_END")
        fu = nxh.unite(part, body, tools=bs, check=False)
        fu.SetName(f"NECK_LIP_{side}_UNITE")
        log(f"NECK_LIP_{side}: thin {thin}, trimmed at |x| {X_END}, united")
    res["lip_variant"] = "two halves to the rim, trimmed at |x| 20"
    v1 = fvol(part, body)
    log(f"added {v1 - v0:.1f} mm3")
    res["added"] = v1 - v0
    # NECK_U_TIP_CUT: round the bottom of the U the scan's wall ends about 4 mm lower than the CAD's pointed end; its
    # top follows an arc in the x-z plane (z -88.3 at x 0, -87.5 at 20, -86 at 30, -84.6 at 38: centre (0, 108.5),
    # R 196.8). One sketch on a plane y 50, Extrude subtract along -y to y 36 (|x| < 40, above the arc).
    ZC, RA, XA, ZT, YP = 108.5, 196.8, 40.0, -50.0, 58.0
    XE, ZE = 48.0, -72.0                   # the cut boundary rises from the arc end to the arm lip top here
    _, plu = nxh.datum_plane(part, (0, YP, 0), (0, 1, 0), name="NECK_U_TIP_PLANE")
    sku = nxf.new_sketch(part, plu, D.x, nxh.point(part, 0, YP, 0), name="NECK_U_TIP_SKETCH")
    za = ZC - math.sqrt(RA * RA - XA * XA)
    a0 = math.atan2(za - ZC, XA); a1 = math.atan2(za - ZC, -XA)       # angles in the x-z plane (x right, z up)
    arc = part.Curves.CreateArc(nxh.P(0, YP, ZC), nxh.V(1, 0, 0), nxh.V(0, 0, 1), RA, min(a0, a1), max(a0, a1))
    ln = [nxh.line(part, (XA, YP, za), (XE, YP, ZE)), nxh.line(part, (XE, YP, ZE), (XE, YP, ZT)),
          nxh.line(part, (XE, YP, ZT), (-XE, YP, ZT)), nxh.line(part, (-XE, YP, ZT), (-XE, YP, ZE)),
          nxh.line(part, (-XE, YP, ZE), (-XA, YP, za))]
    nxf.add(sku, arc, *ln, infer=True)
    stu = nxf.finish_sketch(sku)
    vb = fvol(part, body)
    fcut = nxf.extrude_ex(part, nxh.section_feature(part, [sku.Feature]), (0, -1, 0), start=0, end=YP - 36.0,
                          op=BOOL.Subtract, target=body)
    fcut.SetName("NECK_U_TIP_CUT")
    va = fvol(part, body)
    log(f"U tip cut: sketch {stu['status']} dof {stu['dof']}, removed {vb - va:.1f} mm3, arc ends z {za:.2f}")
    res["u_tip_removed"] = vb - va
    v1 = va
    # END_ARM_CHAMFER: above z -42 the corner relief meets the outer skin in a sharp corner, so the end band
    # stopped there; a 2.5 chamfer on that corner is a narrow face looking -y, like the scan's wall end
    arm = []
    for sx in (1, -1):
        mid = (sx * 64.38, -273.99, -21.06)
        arm += [e for e in body.GetEdges() if math.dist(nxh.edge_points(e, n=3)[1], mid) < 0.3]
    log(f"end arm corner edges: {len(arm)}")
    res["end_arm_chamfer"] = None
    for size in (2.5, 2.0, 1.5):
        mk = nxh.mark("arm chamfer", False)
        n_err = len(nxh.feature_errors(part, recheck=False))
        try:
            fca = nxf.chamfer(part, arm, size)
            if len(nxh.feature_errors(part, recheck=False)) > n_err:
                raise RuntimeError("feature warning")
            fca.SetName("END_ARM_CHAMFER")
            res["end_arm_chamfer"] = size
            break
        except Exception as ex:  # noqa: BLE001
            log(f"end arm chamfer {size} refused: {str(ex)[:100]}")
            nxh.undo_to(mk)
    log(f"end arm chamfer {res['end_arm_chamfer']}")
    res["probes"] = {"R_in": nxh.dist_to(part, body, q_in), "L_in": nxh.dist_to(part, body, q_in_L),
                     "R_opening": nxh.dist_to(part, body, q_out)}
    res["solids_after"] = len([bb for bb in part.Bodies if bb.IsSolidBody and not bb.IsBlanked and not is_conv(bb)])
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["features_after"] = len(list(part.Features))
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["new_features"] = [g.GetFeatureName() + " / " + g.Name for g in list(part.Features)[res["features_before"]:]]
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    res["stl"] = nxre.stl_export(part, body, os.path.join(OUT, "chest_R5.stl"), chord=0.01, max_edge=2.5)
    ok = res["body_ok"] and res["solids_after"] == 1 and len(res["errors_after"]) <= len(res["errors_before"])
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_finish.json", res)
