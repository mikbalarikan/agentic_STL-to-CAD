"""CH-001 Chest - native NX rebuild from the scan.  args: out_dir [stop_stage]
Frame: origin on the mirror plane x rim (parting) plane, at the height of the two shoulder-bore centres;
Z = rim-plane normal toward the open back, X = mirror-plane normal, Y toward the neck.
The RIGHT half (x >= 0) is built, then mirrored about the YZ datum plane and united; one-sided features after.
Stages: A skin envelope + inner-skin cavity -> constant-wall shell, shoulder flange + bore, neck cut;
F symmetric features; M mirror + unite; G one-sided features. Numbers: nx/params.json, work/*.json (an/)."""
import os, sys, json, math, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, curvekit as ck, nxre

OUT = sys.argv[1]
STOP = sys.argv[2] if len(sys.argv) > 2 else "Z"
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest"
WK = os.path.join(ROOT, "work")
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": [], "checks": {}}
T0 = time.time()
os.makedirs(OUT, exist_ok=True)


def log(msg):
    res["log"].append(f"[{time.time()-T0:6.0f}s] {msg}")
    nxh.write_json(os.path.join(OUT, "build.json"), res)


P = json.load(open(os.path.join(ROOT, "nx", "params.json")))


def loft_sheet(part, jsonfile):
    sec = json.load(open(os.path.join(WK, jsonfile)))["sections"]
    sps = []
    for s in sec:
        f, sp = ck.studio_spline(part, [tuple(p) for p in s["poles"]], degree=3, poles=True)
        sps.append(sp)
    tc = nxf.through_curves(part, [nxh.section(part, curves=[sp]) for sp in sps], solid=False)
    return tc, tc.GetBodies()[0], sps


def trim_smaller(part, body, name, frac, **tool):
    """Trim Body keeping the side whose volume is below frac of the start volume (the bowl interior is ~1/3 of the
    block; nxf.trim_body's bounding-box keep test cannot tell the two sides of a bowl apart)."""
    v0 = nxh.volume(part, body)
    for rev in (False, True):
        m = nxh.mark("trim " + name, False)
        try:
            f, _r = nxf.trim_body(part, body, reverse=rev, **tool)
        except Exception as e:  # noqa: BLE001
            nxh.undo_to(m)
            log(f"{name}: trim reverse={rev} failed {e}")
            continue
        v1 = nxh.volume(part, body)
        if 0.02 * v0 < v1 < frac * v0:
            return f, v1
        nxh.undo_to(m)
    raise RuntimeError(f"{name}: no side of the trim gives a volume below {frac} of {v0:.0f}")


def trim_bigger(part, body, name, frac, **tool):
    """Trim Body keeping the side with more than frac of the start volume (small cut-offs)."""
    v0 = nxh.volume(part, body)
    for rev in (False, True):
        m = nxh.mark("trim " + name, False)
        try:
            f, _r = nxf.trim_body(part, body, reverse=rev, **tool)
        except Exception as e:  # noqa: BLE001
            nxh.undo_to(m)
            log(f"{name}: trim reverse={rev} failed {e}")
            continue
        v1 = nxh.volume(part, body)
        if frac * v0 < v1 < v0 - 1.0:
            return f, v1
        nxh.undo_to(m)
    raise RuntimeError(f"{name}: no side of the trim keeps more than {frac} of {v0:.0f}")


def block_trimmed(part, sheet, name, x0):
    bf, blk = nxh.block(part, (x0, -300.0, -150.0), (215.0 - x0, 445.0, 150.0))
    f, v1 = trim_smaller(part, blk, name, 0.5, sheet=sheet)
    return blk, v1


def check(name, ok, value=None):
    res["checks"][name] = {"ok": bool(ok), "value": value}
    if not ok:
        log(f"CHECK FAILED {name}: {value}")


def seg_curves(part, segs, z):
    """("L", p0, p1) | ("A", p0, p1, centre, r, ccw) in the plane Z = z."""
    cs = []
    for s in segs:
        if s[0] == "L":
            cs.append(nxh.line(part, (s[1][0], s[1][1], z), (s[2][0], s[2][1], z)))
        else:
            p0, p1, c, r, ccw = s[1], s[2], s[3], s[4], s[5]
            a0 = math.atan2(p0[1] - c[1], p0[0] - c[0]); a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
            if not ccw:
                a0, a1 = a1, a0
            while a1 <= a0:
                a1 += 2 * math.pi
            cs.append(nxh.arc(part, (c[0], c[1], z), (1, 0, 0), (0, 1, 0), r, a0, a1))
    return cs


def clip_unite(part, body, tools, envx):
    """Intersect each tool body with a kept copy of the envelope, unite the pieces into body."""
    pieces = []
    for t in tools:
        f = nxh.intersect(part, t, [envx], check=False, keep_tool=True)
        pieces += [b for b in f.GetBodies() if b.IsSolidBody]
    if pieces:
        nxh.unite(part, body, pieces, check=False)
    return len(pieces)


def solids(part, skip=()):
    return [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and b.Tag not in skip]


part = None
body = None
try:
    part = nxh.new_part(os.path.join(OUT, "Chest.prt"))
    SH = P["shoulder"]
    a = math.radians(SH["angle_deg"])
    nsh = (math.cos(a), math.sin(a), 0.0)
    for k, v in (("wall_t", P["wall_t"]), ("shoulder_angle", SH["angle_deg"]), ("shoulder_xc", SH["xc"]),
                 ("shoulder_bore_d", SH["bore_d"]), ("shoulder_flange_t", SH["flange_t"])):
        nxh.expr(part, k, v, "deg" if "angle" in k else "mm")
    dat = nxh.Datums(part)

    # ---- A: envelope (block below the rim, inside the exterior skin), right half only
    tc, skin, _ = loft_sheet(part, "sections.json")
    log(f"A skin loft: area {nxh.sheet_area(part, skin)[0]:.0f}")
    env, venv = block_trimmed(part, skin, "skin", 0.0)
    log(f"A envelope half {venv:.0f}")
    # shoulder: the ring face is the envelope cut by the shoulder plane
    c0 = (SH["xc"], 0.0, 0.0)
    fpl, pl_sh = nxh.datum_plane(part, c0, nsh, name="SHOULDER_R")
    trim_bigger(part, env, "shoulder plane", 0.8, datum_plane=pl_sh)
    # neck cut: closed plan profile above the neck edge, through all Z
    nk = [tuple(p) for p in P["neck"]["pts"]]
    zc = -200.0
    f_sp, sp = ck.studio_spline(part, [(x, y, zc) for x, y in nk], degree=3)
    xe, ye = nk[-1]
    cs = [sp, nxh.line(part, (xe, ye, zc), (xe, 150.0, zc)), nxh.line(part, (xe, 150.0, zc), (-5.0, 150.0, zc)),
          nxh.line(part, (-5.0, 150.0, zc), (-5.0, nk[0][1], zc)), nxh.line(part, (-5.0, nk[0][1], zc), (0.0, nk[0][1], zc))]
    fn = nxh.extrude(part, nxh.section(part, curves=cs, help_point=(0.0, nk[0][1], zc)), (0, 0, 1), 0, 260.0)
    nxh.subtract(part, env, fn.GetBodies(), check=False)
    log(f"A shoulder plane + neck cut: envelope {nxh.volume(part, env):.0f}")
    # front panel: flat racetrack plate inset into the skin (tilted tilt_deg about X) with a circular recess;
    # pocket + recess are cut into the envelope, the Shell then gives the plate (t_panel) and the disc (t_disc)
    PN = P["panel"]
    g = PN["dzdy"]
    cosg = 1.0 / math.sqrt(1.0 + g * g)
    npn = (0.0, -g * cosg, cosg)                                        # panel normal, toward the open back
    z_ext = PN["z_int_at_y_m100"] - PN["t_panel"] / cosg                # exterior plate plane at y = -100
    yc = PN["circle_c"][1]
    z_cf = PN["z_circle_int_at_c"] - PN["t_disc"] / cosg               # recess floor at the circle centre
    fpp, pl_pan = nxh.datum_plane(part, (0.0, -100.0, z_ext), npn, name="PANEL_EXT")
    fpc, pl_cf = nxh.datum_plane(part, (0.0, yc, z_cf), npn, name="PANEL_RECESS_FLOOR")
    cs = seg_curves(part, PN["outline_segs"], -160.0)
    fpk = nxh.extrude(part, nxh.section(part, curves=cs, help_point=tuple(PN["outline_segs"][0][1]) + (-160.0,)), (0, 0, 1), 0, 160.0)
    pk = [b for b in fpk.GetBodies() if b.IsSolidBody][0]
    trim_smaller(part, pk, "panel pocket tool", 0.5, datum_plane=pl_pan)
    fcy, cyl = nxh.cylinder(part, (0.0, yc, -160.0), (0, 0, 1), PN["circle_d"], 160.0)
    trim_smaller(part, cyl, "circle recess tool", 0.5, datum_plane=pl_cf)
    nxh.subtract(part, env, [pk, cyl], check=False)
    log(f"A panel pocket + circle recess: envelope {nxh.volume(part, env):.0f}")
    ef, (envx,) = nxf.extract_body(part, [env])
    envx.Blank()
    # constant wall: Shell inward, the rim, mid-plane and neck faces open, the shoulder face a 4.6 flange
    walls, opened, shf, pfl, cfl = [], [], None, [], []
    for fc in env.GetFaces():
        t, pt, d, _r = nxh.face_data(fc)
        area = nxh.sheet_area(part, [fc])[0]
        if t == nxh.PLANE and abs(d[1] + npn[1]) < 1e-3 and abs(d[2] + npn[2]) < 1e-3:
            zp_ext = z_ext + g * (pt[1] + 100.0)
            zp_cf = z_cf + g * (pt[1] - yc)
            (pfl if abs(pt[2] - zp_ext) < abs(pt[2] - zp_cf) else cfl).append(fc)
        elif t == nxh.PLANE and abs(d[0] - nsh[0]) < 1e-3 and abs(d[1] - nsh[1]) < 1e-3:
            shf = fc                                  # shoulder ring face -> flange wall
        elif t == nxh.PLANE and abs(d[2] - 1.0) < 1e-4 and abs(pt[2]) < 0.01:
            opened.append(fc)                         # rim plane
        elif t == nxh.PLANE and abs(d[0] + 1.0) < 1e-4 and abs(pt[0]) < 0.01:
            opened.append(fc)                         # mid plane
        elif t != nxh.BSURF and pt[1] > 38.0 and pt[0] < 70.0:
            opened.append(fc)                         # neck cut faces
        else:
            walls.append(fc)                          # skin, panel pocket and recess walls
        res.setdefault("shell_faces", []).append([t, [round(v, 3) for v in d], round(area)])
    log(f"A shell faces: walls {len(walls)}, opened {len(opened)}, shoulder face {shf is not None}, panel {len(pfl)}, disc {len(cfl)}")
    v_env = nxh.volume(part, env)
    alt = ([([shf], "shoulder_flange_t")] if shf else []) + ([(pfl, str(PN["t_panel"]))] if pfl else []) + ([(cfl, str(PN["t_disc"]))] if cfl else [])
    nxf.shell(part, env, opened, "wall_t", inward=True, alternate=alt)
    body = env
    log(f"A shell: {v_env:.0f} -> {nxh.volume(part, body):.0f}")
    # front through hole, normal to the panel
    hc = PN["hole_c"]
    zh = z_ext + g * (hc[1] + 100.0)
    nxh.cylinder(part, (hc[0], hc[1] - 20.0 * npn[1], zh - 20.0 * npn[2]), npn, PN["hole_d"], 40.0, op=BOOL.Subtract, target=body)
    log(f"A front hole; body {nxh.volume(part, body):.0f}")
    # shoulder bore
    nxh.cylinder(part, tuple(c0[i] - 30.0 * nsh[i] for i in range(3)), nsh, SH["bore_d"], 60.0, op=BOOL.Subtract, target=body)
    log(f"A shoulder bore; body {nxh.volume(part, body):.0f}")
    # bottom: straight edge at the scanned min y (the skin beyond it is extrapolation) and the centre notch
    BT = P["bottom"]
    f1, b1 = nxh.block(part, (-10.0, -400.0, -200.0), (260.0, 400.0 + BT["y_edge"], 220.0))
    f2, b2 = nxh.block(part, (-10.0, -400.0, BT["notch_z"]), (10.0 + BT["notch_x"], 400.0 + BT["notch_y"], 20.0 - BT["notch_z"]))
    nxh.subtract(part, body, [b1, b2], check=False)
    log(f"A bottom edge + notch; body {nxh.volume(part, body):.0f}")
    check("A single solid", len(solids(part, (envx.Tag,))) == 1, [round(nxh.volume(part, b)) for b in solids(part, (envx.Tag,))])
    if STOP == "A":
        raise StopIteration

    # ---- M: the half shell is mirrored about the YZ datum plane (the mid-plane) and united; the envelope copy too
    fm, nb = nxf.mirror_geometry(part, [body], dat.yz)
    nxh.unite(part, body, [b for b in nb if b.IsSolidBody], check=False)
    fm2, nb2 = nxf.mirror_geometry(part, [envx], dat.yz)
    nxh.unite(part, envx, [b for b in nb2 if b.IsSolidBody], check=False)
    envx.Blank()
    log(f"M shell mirrored + united: body {nxh.volume(part, body):.0f}, envelope {nxh.volume(part, envx):.0f}")
    check("M single solid", len(solids(part, (envx.Tag,))) == 1, [round(nxh.volume(part, b)) for b in solids(part, (envx.Tag,))])
    nxh.save(part); log("M saved")
    if STOP == "M":
        raise StopIteration

    # ---- F: all features on the full body. Right-half features (kind R) are placed with their mirror images (same
    # data, x -> -x: the mirror is done on the measured outline, so both sides are identical), mid-plane (C) and
    # one-sided (A) features as measured. Combined booleans: one unite of all tool prisms, one intersect with the
    # envelope, one unite into the body; one subtract for all openings, one for all holes.
    PL = json.load(open(os.path.join(WK, "plateaus.json")))
    TH = json.load(open(os.path.join(WK, "through.json")))
    HO = json.load(open(os.path.join(WK, "holes.json")))
    GR = json.load(open(os.path.join(WK, "grooves.json")))

    def mseg(segs):
        out = []
        for s in segs:
            if s[0] == "L":
                out.append(["L", [-s[1][0], s[1][1]], [-s[2][0], s[2][1]]])
            else:
                out.append(["A", [-s[1][0], s[1][1]], [-s[2][0], s[2][1]], [-s[3][0], s[3][1]], s[4], not s[5]])
        return out

    def inside(pt, segs):
        poly = [s[1] for s in segs]
        x, y = pt; c = False
        for i in range(len(poly)):
            (x1, y1), (x2, y2) = poly[i], poly[(i + 1) % len(poly)]
            if (y1 > y) != (y2 > y) and x < x1 + (y - y1) * (x2 - x1) / (y2 - y1):
                c = not c
        return c

    def variants(segs, kind):
        return [segs, mseg(segs)] if kind == "R" else [segs]

    low, high = [], []
    for Lp in PL["loops"]:
        if Lp["area"] < 0:
            continue
        h = Lp["h"]
        z0 = h - 4.0 if h > -1.0 else -160.0
        holes = [Mh for Mh in PL["loops"] if Mh["area"] < 0 and abs(Mh["h"] - h) < 1e-6 and inside(Mh["segs"][0][1], Lp["segs"])]
        for k, segs in enumerate(variants(Lp["segs"], Lp["kind"])):
            try:
                cs = seg_curves(part, segs, z0)
                for Mh in holes:
                    cs += seg_curves(part, Mh["segs"] if k == 0 else mseg(Mh["segs"]), z0)
                f = nxh.extrude(part, nxh.section(part, curves=cs, help_point=tuple(segs[0][1]) + (z0,)), (0, 0, 1), 0, h - z0)
                (high if h > -1.0 else low).extend([b for b in f.GetBodies() if b.IsSolidBody])
            except Exception as e:  # noqa: BLE001
                log(f"plateau {Lp['kind']} h {h}: extrude failed {e}")
    log(f"F plateau tools: {len(low)} below the rim, {len(high)} at the rim")
    if low:
        t0 = low[0]
        if len(low) > 1:
            nxh.unite(part, t0, low[1:], check=False)
        skip = {envx.Tag, body.Tag} | {b.Tag for b in high}
        tl = [b for b in solids(part) if b.Tag not in skip]          # the united tool (disjoint tools stay separate)
        pieces = []
        for t in tl:
            fi = nxh.intersect(part, t, [envx], check=False, keep_tool=True)
            pieces += [b for b in fi.GetBodies() if b.IsSolidBody]
        log(f"F plateau tools clipped by the envelope: {len(pieces)} pieces")
        nxh.unite(part, body, pieces, check=False)
    if high:
        nxh.unite(part, body, high, check=False)
    log(f"F plateaus united; body {nxh.volume(part, body):.0f}")
    sol = solids(part, (envx.Tag,))
    if len(sol) > 1:
        sol.sort(key=lambda b: -nxh.volume(part, b))
        log(f"F: {len(sol) - 1} loose pieces deleted {[round(nxh.volume(part, b)) for b in sol[1:]]}")
        nxf.delete_body(part, sol[1:])
        body = sol[0]
    tools = []
    for o in TH:
        if o["kind"] not in ("R", "C") or o["area"] < 3.0:
            continue
        for segs in variants(o["segs"], o["kind"]):
            try:
                f = nxh.extrude(part, nxh.section(part, curves=seg_curves(part, segs, -200.0), help_point=tuple(segs[0][1]) + (-200.0,)), (0, 0, 1), 0, 205.0)
                tools += [b for b in f.GetBodies() if b.IsSolidBody]
            except Exception as e:  # noqa: BLE001
                log(f"opening at {o['cen']}: {e}")
    if tools:
        nxh.subtract(part, body, tools, check=False)
    log(f"F openings {len(tools)}; body {nxh.volume(part, body):.0f}")
    tools = []
    for hh in HO:
        if hh["kind"] == "Lmirror":
            continue
        ztop = hh["top"] + 1.0
        zb = hh["bottom"] if hh["bottom"] is not None else hh["top"] - 25.0
        for x in ([hh["x"], -hh["x"]] if hh["kind"] == "R" else [hh["x"]]):
            f, c_ = nxh.cylinder(part, (x, hh["y"], zb), (0, 0, 1), hh["d_design"], ztop - zb)
            tools.append(c_)
    if tools:
        nxh.subtract(part, body, tools, check=False)
    log(f"F boss holes {len(tools)}; body {nxh.volume(part, body):.0f}")
    tools = []
    for name, gp in GR["paths"].items():
        for sgn in ((1.0, -1.0) if gp["kind"] == "R" else (1.0,)):
            try:
                f, sp = ck.studio_spline(part, [(sgn * p[0], p[1], p[2]) for p in gp["pts"]], degree=3)
                tf, tb = nxf.tube(part, GR["tube_d"], "0", curves=[sp])
                tools.append(tb)
            except Exception as e:  # noqa: BLE001
                log(f"F groove {name} {sgn} failed: {e}")
    if tools:
        nxh.subtract(part, body, tools, check=False)
    log(f"F grooves {len(tools)}; body {nxh.volume(part, body):.0f}")
    check("F single solid", len(solids(part, (envx.Tag,))) == 1, [round(nxh.volume(part, b)) for b in solids(part, (envx.Tag,))])
    raise StopIteration
except StopIteration:
    pass
except Exception:
    res["error"] = traceback.format_exc()
    log("ERROR")
try:
    if part is not None:
        sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
        res["solids"] = [round(nxh.volume(part, b), 1) for b in sol]
        res["body_ok"] = [nxh.body_ok(part, b) for b in sol]
        res["feature_errors"] = [str(e) for e in nxh.feature_errors(part, recheck=False)][:20]
        if sol:
            big = max(sol, key=lambda b: nxh.volume(part, b))
            nxre.stl_export(part, big, os.path.join(OUT, f"chest_{STOP}.stl"), chord=0.01, max_edge=2.0)
        nxh.save(part)
        if "error" not in res:
            res["result"] = "PASS"
except Exception:
    res["error_final"] = traceback.format_exc()
res["t"] = round(time.time() - T0, 1)
nxh.write_json(os.path.join(OUT, "build.json"), res)
