"""Read-only: edges of the largest solid inside a box, with their two faces' normals at the edge middle.
args: prt out_json x0 x1 y0 y1 z0 z1"""
import os, sys, json, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh

PRT, OUT = sys.argv[1], sys.argv[2]
B = list(map(float, sys.argv[3:9]))
res = {"edges": []}
try:
    part = nxh.open_part(PRT)
    sol = []
    for b in part.Bodies:
        try:
            conv = bool(b.IsConvergentBody)
        except Exception:  # noqa: BLE001
            conv = False
        if b.IsSolidBody and not conv:
            sol.append(b)
    body = max(sol, key=lambda b: len(b.GetFaces()))
    for e in body.GetEdges():
        bb = nxh.bbox(e)
        if bb[3] < B[0] or bb[0] > B[1] or bb[4] < B[2] or bb[1] > B[3] or bb[5] < B[4] or bb[2] > B[5]:
            continue
        pts = nxh.edge_points(e, n=7)
        L = sum(math.dist(pts[i], pts[i + 1]) for i in range(6))
        fs = []
        for g in e.GetFaces():
            try:
                fs.append([g.Tag, [round(c, 2) for c in nxh.normal_at(g, pts[3])], [round(c, 1) for c in nxh.bbox(g)]])
            except Exception as ex:  # noqa: BLE001
                fs.append([g.Tag, str(ex)[:40]])
        res["edges"].append(dict(tag=e.Tag, len=round(L, 2), p0=[round(c, 2) for c in pts[0]], pm=[round(c, 2) for c in pts[3]],
                                 p1=[round(c, 2) for c in pts[-1]], faces=fs))
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
