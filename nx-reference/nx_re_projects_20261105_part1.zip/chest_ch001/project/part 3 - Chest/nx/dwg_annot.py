# -*- coding: utf-8 -*-
# Annotations of the CH-001 drawing set; exec'd inside dwg_chest.py (views, helpers and res are in scope).
# Drafting-curve points are drawing-part coordinates = M(model point).


def straight(view, pred):
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 3 and pred(p[0], p[1]):
            out.append((c, p))
    return out


def longest(cands):
    if not cands:
        raise RuntimeError("no curve")
    return max(cands, key=lambda cp: sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)))


def L(cp):
    return sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)) ** 0.5


def lin(view, ca, cb, origin, method, sa, sb, basic=False, tol=None, before=None, after=None, expect=None, etol=0.05):
    meth = {"horizontal": nxd.MM.Horizontal, "vertical": nxd.MM.Vertical, "point": nxd.MM.PointToPoint,
            "cylindrical": nxd.MM.Cylindrical}[method]
    b = dwg.Dimensions.CreateLinearDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = meth
        b.FirstAssociativity.SetValue(sa, ca, view, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(sb, cb, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=tol, before=before, after=after)
        _style0(b, 2, DT)
        if basic:
            b.Style.DimensionStyle.ToleranceType = A.ToleranceType.Basic
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if expect is not None and abs(d.ComputedSize - expect) > etol:
        v = d.ComputedSize
        ptdwg._delete([d])
        raise RuntimeError("lin: %.4f instead of %.4f" % (v, expect))
    return d


def vline(view, X, tol=0.06, minlen=0.5):
    """straight drafting curves at drawing X_d = X (both ends)."""
    return [cp for cp in straight(view, lambda p0, p1: abs(p0[0] - X) < tol and abs(p1[0] - X) < tol) if L(cp) >= minlen]


def zline(view, Z, tol=0.06, minlen=0.5, axis=1):
    return [cp for cp in straight(view, lambda p0, p1: abs(p0[axis] - Z) < tol and abs(p1[axis] - Z) < tol) if L(cp) >= minlen]


def stack_below(ann):
    ao = A.Annotation.AssociativeOriginData()
    ao.OriginType = A.AssociativeOriginType.AttachedToStack
    ao.StackAlignmentPosition = A.StackAlignmentPosition.Below
    ao.OffsetAnnotation = ann
    return ao


def stack_fcf(name, dim, char, tol, datums=(), dia=False, pos=None):
    def f():
        try:
            b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
            try:
                b.Characteristic = gdt.characteristic(char)
                b.FrameStyle = A.FeatureControlFrameBuilder.FcfFrameStyle.SingleFrame
                b.FeatureControlFrameDataList.Append(dwg.Annotations.CreateFeatureControlFrameDataBuilder(None))
                d = b.FeatureControlFrameDataList.FindItem(0)
                if dia:
                    d.ZoneShape = A.FeatureControlFrameDataBuilder.ToleranceZoneShape.Diameter
                d.ToleranceValue = str(tol)
                for r_, l_ in zip((d.PrimaryDatumReference, d.SecondaryDatumReference, d.TertiaryDatumReference), datums):
                    r_.Letter = l_
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(dim))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-300:]
            if pos is None:
                raise
            res["gdt"][name] = "free"
            return gdt.fcf(dwg, char, tol, datums, dia, pos, size=GT)
    return N(name, f)


def datum_under(name, letter, ann, fallback):
    def f():
        try:
            b = dwg.Annotations.Datums.CreateDraftingDatumFeatureSymbolBuilder(None)
            try:
                b.Letter = letter
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(ann))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-300:]
            res["gdt"][name] = "leader"
            return fallback()
    return N(name, f)


BB = FIN.get("bbox_exact_stl", FIN["bbox"])
SZ = (BB[3] - BB[0], BB[4] - BB[1], BB[5] - BB[2])

# ---------------------------------------------------------------- SH1
sheets[0].Open()
# Right view: rim plane edge-on = straight curves at drawing Y_d = model z = 0
rim = sorted(zline(right, 0.0, 0.06, 5.0), key=lambda cp: -L(cp))
res["sh1_rim_curves"] = len(rim)
if rim:
    ends = []
    for c, _ps in nxd.curves(right):
        p = nxd.curve_points(c)
        if len(p) >= 2:
            ends += [(c, p[0]), (c, p[1])]
    ctop = max(ends, key=lambda e: e[1][2]); cbot = min(ends, key=lambda e: e[1][2])
    res["sh1_height_ends"] = [[round(v, 2) for v in ctop[1]], [round(v, 2) for v in cbot[1]]]
    hx = xy(right, (0.0, 0.0, 0.0))[0]
    D("H_overall", lambda: m3d.dim_ends(right, ctop[0], ctop[1], cbot[0], cbot[1], (hx + 30.0, xy(right, (0, 0, -80.0))[1]), "vertical",
                                        expect=ctop[1][2] - cbot[1][2], etol=0.05))
    crim = rim[0]
    pm = [0.5 * (crim[1][0][i] + crim[1][1][i]) for i in range(3)]
    fA = N("fcf_flat_A", lambda: gdt.fcf(dwg, "Flatness", "0.1", (), False, (hx + 16.0, xy(right, (0, 0, 75.0))[1]), crim[0], right, pm, size=GT))
    if fA is not None:
        datum_under("datum_A", "A", fA, lambda: gdt.datum(dwg, "A", (hx + 16.0, xy(right, (0, 0, 60.0))[1]), crim[0], right, pm, size=GT))


def ends(view):
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) >= 2:
            out += [(c, p[0]), (c, p[1])]
    return out


TOL1 = (0.1, -0.1)
# overall width in the Front view (extreme curve end points; the shoulder flange corners)
ef = ends(front)
cl = min(ef, key=lambda e: e[1][0]); cr = max(ef, key=lambda e: e[1][0])
res["sh1_width_ends"] = [[round(v, 2) for v in cl[1]], [round(v, 2) for v in cr[1]], round(SZ[0], 2)]
ybot1 = xy(front, (0.0, 0.0, BB[1]))[1]
D("W_overall", lambda: m3d.dim_ends(front, cl[0], cl[1], cr[0], cr[1], (xy(front, (0, 0, 0))[0], ybot1 - 30.0), "horizontal",
                                    expect=cr[1][0] - cl[1][0], etol=0.05))
# depth in the Right view: rim plane A (edge-on line Y_d = 0) to the front-most point
er = ends(right)
cf = min(er, key=lambda e: e[1][1])
res["sh1_depth_end"] = [round(v, 2) for v in cf[1]]
if rim:
    D("D_overall", lambda: m3d.dim_ends(right, rim[0][0], rim[0][1][0], cf[0], cf[1], (xy(right, (0, -70.0, 0))[0], ybot1 - 30.0),
                                        "horizontal", expect=-cf[1][1], etol=0.05))
# bottom notch (|x| < 50, from the bottom edge up to y = notch_y): its two side edges are seen in the Front view
BT_ = PJ["bottom"]
nl_ = vline(front, BT_["notch_x"], 0.08, 2.0); nr_ = vline(front, -BT_["notch_x"], 0.08, 2.0)
res["sh1_notch_edges"] = [len(nl_), len(nr_)]
if nl_ and nr_:
    D("W_notch", lambda: lin(front, longest(nr_)[0], longest(nl_)[0], (xy(front, (0, 0, 0))[0], ybot1 - 14.0), "horizontal",
                             S.Mid, S.Mid, tol=TOL1, expect=2 * BT_["notch_x"], etol=0.05))
x0, y0 = 425.0, 205.0
note_lines(["NOTES",
            "1. GENERAL TOLERANCES ISO 2768-mK. GD&T PER ISO 1101.",
            "2. GEOMETRY NOT DIMENSIONED PER 3D MODEL CH-001 REV A.",
            "3. ALL SURFACES UNLESS OTHERWISE SPECIFIED:",
            "",
            "4. WALL 3.25 UNLESS SHOWN. INTERNAL CORNERS R1 MAX. BREAK EDGES 0.2-0.5.",
            "5. Ra 3.2 UNLESS OTHERWISE SPECIFIED.",
            "6. PART IS SYMMETRIC ABOUT THE MID-PLANE (X = 0) EXCEPT SH4 ITEMS MARKED *.",
            "7. OVERALL SIZE %.1f x %.1f x %.1f (REF)." % SZ], x0, y0, step=9.0)
N("fcf_profile_all", lambda: gdt.fcf(dwg, "ProfileOfASurface", "0.3", ("A", "B", "C"), False, (x0 + 7.0, y0 - 4 * 9.0 + 2.0), size=GT))

# ---------------------------------------------------------------- SH2 front panel
sheets[1].Open()
hr = PN["hole_d"] / 2.0
rr = PN["circle_d"] / 2.0
if secB is not None:
    # the hole wall in the cut is a short arc (tilted cylinder): pick any curve whose two end points sit at X_d = -+r
    def walls(view, X):
        out = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) >= 3 and abs(p[0][0] - X) < 0.15 and abs(p[1][0] - X) < 0.15 and abs(p[0][1] - p[1][1]) > 0.5:
                out.append((c, max(p[:2], key=lambda q: q[1])))
        return out
    wa, wb = walls(secB, -hr), walls(secB, hr)
    res["secB_hole_walls"] = [len(wa), len(wb)]
    if wa and wb:
        (ca, pa), (cb, pb) = wa[0], wb[0]
        dB = D("D_hole", lambda: m3d.dim_ends(secB, ca, pa, cb, pb, (xy(secB, pa)[0] + hr, xy(secB, pa)[1] + 38.0), "cylindrical",
                                             expect=PN["hole_d"], etol=0.1))
        if dB is not None:
            stack_fcf("fcf_pos_hole", dB, "Position", "0.2", ("A", "B", "C"), True, None)
if secC is not None:
    wl = [cp for cp in vline(secC, -rr, 0.12) + vline(secC, rr, 0.12)]
    res["secC_recess_walls"] = [[round(v, 2) for v in cp[1][0]] for cp in wl]
    a_ = [cp for cp in wl if cp[1][0][0] < 0]; b_ = [cp for cp in wl if cp[1][0][0] > 0]
    if a_ and b_:
        ca, cb = longest(a_), longest(b_)
        yb = min(ca[1][0][1], ca[1][1][1]); zb = ca[1][0][2]
        dC = D("D_recess", lambda: lin(secC, ca[0], cb[0], (xy(secC, (0.0, yb, zb))[0], xy(secC, (0.0, yb, zb))[1] + 26.0),
                                         "cylindrical", S.Mid, S.Mid, expect=PN["circle_d"], etol=0.1))
    # plate, disc and recess step: horizontal lines of the cut (constant model z); values are measured along Z in
    # the section plane (the panel is tilted 4.7 deg about X: 2.70 / 1.95 normal = 2.71 / 1.96 in the cut)
    cg = 1.0 / math.sqrt(1.0 + PN["dzdy"] ** 2)
    yc_ = PN["circle_c"][1]
    z_pi = PN["z_int_at_y_m100"] + PN["dzdy"] * (yc_ + 100.0)          # plate interior at the cut
    z_pe = z_pi - PN["t_panel"] / cg                                 # plate exterior
    z_di = PN["z_circle_int_at_c"]                                   # disc interior
    z_de = z_di - PN["t_disc"] / cg                                  # disc exterior
    res["secE_levels"] = [round(v, 3) for v in (z_pe, z_de, z_pi, z_di)]

    def hl(view, z, xa, xb):
        c_ = [cp for cp in straight(view, lambda p0, p1: abs(p0[1] - z) < 0.03 and abs(p1[1] - z) < 0.03)
              if min(abs(cp[1][0][0]), abs(cp[1][1][0])) >= xa - 0.1 and max(abs(cp[1][0][0]), abs(cp[1][1][0])) <= xb + 0.1]
        return longest(c_)
if secC is not None and detE is not None:
    gx, gy = xy(detE, (35.0, -130.6, yc_))
    yd = lambda z: xy(detE, (35.0, z, yc_))[1]
    D("T_plate", lambda: lin(detE, hl(detE, z_pe, rr, rr + 8.0)[0], hl(detE, z_pi, rr + 3.0, rr + 11.0)[0],
                             (gx + 40.0, 0.5 * (yd(z_pe) + yd(z_pi))), "vertical", S.Mid, S.Mid, tol=TOL1, expect=z_pi - z_pe, etol=0.02))
    # outC14: attach at points inside the detail circle (S.Mid of the full-width disc lines lay far outside it and drew
    # extension lines across the sheet, work/dwg9 SH2)
    xq = rr - 1.5
    D("T_disc", lambda: m3d.dim_ends(detE, hl(detE, z_de, 0.0, rr)[0], (xq, z_de, yc_), hl(detE, z_di, 0.0, rr + 3.5)[0], (xq, z_di, yc_),
                                     (gx - 40.0, 0.5 * (yd(z_de) + yd(z_di))), "vertical", tol=TOL1, expect=z_di - z_de, etol=0.02))
    D("H_recess", lambda: m3d.dim_ends(detE, hl(detE, z_pe, rr, rr + 8.0)[0], (rr + 1.5, z_pe, yc_), hl(detE, z_de, 0.0, rr)[0], (xq, z_de, yc_),
                                       (gx - 62.0, 0.5 * (yd(z_pe) + yd(z_de))), "vertical", tol=TOL1, expect=z_de - z_pe, etol=0.02))
# panel width (racetrack outline, Front view): its two widest points are curve end points at X_d = -+38.5
pw = [e for e in ends(f2) if abs(abs(e[1][0]) - 38.5) < 0.1 and abs(e[1][2] + 77.58) < 0.3]
res["sh2_panel_ends"] = [[round(v, 2) for v in e[1]] for e in pw]
pa_ = [e for e in pw if e[1][0] < 0]; pb_ = [e for e in pw if e[1][0] > 0]
if pa_ and pb_:
    D("W_panel", lambda: m3d.dim_ends(f2, pa_[0][0], pa_[0][1], pb_[0][0], pb_[0][1], (xy(f2, (0, 0, -181.0))[0], xy(f2, (0, 0, -181.0))[1]),
                                      "horizontal", tol=TOL1, expect=pb_[0][1][0] - pa_[0][1][0], etol=0.05))
TH = json.load(open(os.path.join(ROOT, "work", "through.json")))
led = [o for o in TH if o["kind"] == "R" and o["cen"][1] > -30 and o["cen"][1] < -10]
led_d = round(2.0 * math.sqrt(sum(o["area"] for o in led) / max(1, len(led)) / math.pi), 1) if led else 2.5
rows = [["FRONT PANEL (BASIC, MODEL FRAME)", ""],
        ["PANEL PLANE", "TILTED %.1f° ABOUT X TO DATUM A" % PN["tilt_deg"]],
        ["PANEL PLATE / RECESSED DISC", "%.2f / %.2f THICK (NORMAL TO PANEL)" % (PN["t_panel"], PN["t_disc"])],
        ["THROUGH HOLE %s%.1f" % (DIA, PN["hole_d"]), "X 0, Y %.1f, AXIS NORMAL TO PANEL" % PN["hole_c"][1]],
        ["RECESS %s%.1f" % (DIA, PN["circle_d"]), "X 0, Y %.1f, FLOOR 1.73 BELOW PANEL" % PN["circle_c"][1]],
        ["LED HOLES 4X %s%.1f THRU" % (DIA, led_d), "X ±%.1f / ±%.1f, Y %.1f" % (abs(min(o["cen"][0] for o in led)) if led else 0,
                                                                         abs(max(o["cen"][0] for o in led)) if led else 0,
                                                                         sum(o["cen"][1] for o in led) / max(1, len(led)))],
        ["SLOTS (VENTS)", "2 X 7 SHOULDER, 15 LOWER: THRU, NORMAL TO A"]]
N("table_panel", lambda: table((440.0, 140.0), [92.0, 160.0], rows))

# ---------------------------------------------------------------- SH3 shoulder flanges
sheets[2].Open()
if secD is not None:
    fR = vline(secD, -XC, 0.08, 3.0); fL = vline(secD, XC, 0.08, 3.0)
    res["secD_faces"] = [len(fR), len(fL)]
    if fR and fL:
        cR, cL = longest(fR), longest(fL)
        ztop = max(max(cR[1][0][1], cR[1][1][1]), max(cL[1][0][1], cL[1][1][1]))
        dW = D("W_shoulders", lambda: lin(secD, cR[0], cL[0], (xy(secD, (0, 0, 0))[0], xy(secD, (0, 0.0, 0))[1] - 20.0),
                                            "horizontal", S.Mid, S.Mid, basic=True, expect=2 * XC, etol=0.1))
        pR = [0.5 * (cR[1][0][i] + cR[1][1][i]) for i in range(3)]
        pL = [0.5 * (cL[1][0][i] + cL[1][1][i]) for i in range(3)]
        N("fcf_perp_R", lambda: gdt.fcf(dwg, "Perpendicularity", "0.05", ("A",), False, (xy(secD, pR)[0] - 60.0, xy(secD, pR)[1] - 45.0), cR[0], secD, pR, size=GT))
        # flange thickness in the cut (the face is turned 4.5 deg about Z: 4.60 normal = 4.61 along X in F-F)
        fiR = vline(secD, -(XC - SH["flange_t"] / math.cos(math.radians(SH["angle_deg"]))), 0.05, 3.0)
        res["secF_inner_face"] = len(fiR)
        if fiR:
            D("T_flange", lambda: lin(secD, cR[0], longest(fiR)[0], (xy(secD, pR)[0] + 22.0, xy(secD, pR)[1] - 34.0), "horizontal",
                                      S.Mid, S.Mid, tol=TOL1, expect=SH["flange_t"] / math.cos(math.radians(SH["angle_deg"])), etol=0.03))


def dia_h(view, arc, origin, fit):
    """Diameter with horizontal text, placed outside (text in white space, leader to the arc)."""
    b = dwg.Dimensions.CreateRadialDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = nxd.MM.Diametral
        b.FirstAssociativity.SetValue(nxd.SNAP.NotSet, arc, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=fit)
        _style0(b, 2, DT)
        for attr, val in (("TextOrientation", "Horizontal"), ("TextPlacement", "ManualArrowsOut")):
            try:
                setattr(b.Style.DimensionStyle, attr, getattr(getattr(A, attr), val))
            except Exception as e:  # noqa: BLE001
                res["errors"]["dia_h_" + attr] = str(e)[:150]
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    return d


# bores: true circles in the views along the bore axes (BORE_R / BORE_L)
for bv, right_side in ((r3R, True), (r3, False)):
    if bv is None:
        continue
    ctr = (-XC if right_side else XC, 0.0, 0.0)
    cand = [(c, ce, r) for c, ce, r in m3d.arcs(bv) if abs(r - BORE / 2.0) < 0.05 and math.dist(ce, ctr) < 0.2]
    res["bore_arcs_%s" % ("R" if right_side else "L")] = len(cand)
    if not cand:
        continue
    c = cand[0][0]
    cx_, cy_ = xy(bv, ctr)
    side = -1.0 if right_side else 1.0                # the bore opens toward the rim: right view to the left
    org = (cx_ + side * (82.0 if right_side else 48.0), cy_ + (10.0 if right_side else 14.0))
    dbo = D("D_bore_%s" % ("R" if right_side else "L"), lambda c=c, org=org: dia_h(bv, c, org, "H7"))
    if dbo is not None:
        if abs(dbo.ComputedSize - BORE) > 0.05:
            res["errors"]["D_bore_value"] = dbo.ComputedSize
        f_ = stack_fcf("fcf_bore_%s" % ("R" if right_side else "L"), dbo, "Position", "0.1", ("A",), True, None)
        letter = "B" if right_side else "C"
        if f_ is not None:
            datum_under("datum_" + letter, letter, f_, lambda c=c, letter=letter, org=org: gdt.datum(dwg, letter, (org[0], org[1] - 30.0), c, bv, ctr, size=GT))
rows3 = [["SHOULDER FLANGES (BOTH SIDES, BASIC)", ""],
         ["FACE ANGLE", "%.1f° ABOUT Z, FACES OPEN TOWARD +Y" % SH["angle_deg"]],
         ["FACE / BORE AXIS POINT", "X ±%.2f, Y 0, Z 0 (ON A)" % XC],
         ["BORE", "%s%.0f H7, AXIS NORMAL TO FACE" % (DIA, BORE)],
         ["FLANGE THICKNESS", "%.2f (NORMAL TO FACE)" % SH["flange_t"]],
         ["FACE: PERPENDICULARITY 0.05 TO A, POSITION OF BORE AXIS %s0.1 A" % DIA, ""]]
N("table_shoulder", lambda: table((560.0, 565.0), [150.0, 110.0], rows3))

# ---------------------------------------------------------------- SH4 interior features: balloons + table
sheets[3].Open()
HO = json.load(open(os.path.join(ROOT, "work", "holes.json")))
feats = []
for h in HO:
    if h["kind"] == "Lmirror":
        continue
    pts = [(h["x"], h["y"])] + ([(-h["x"], h["y"])] if h["kind"] == "R" else [])
    for (x_, y_) in pts:
        depth = (h["top"] - h["bottom"]) if h["bottom"] is not None else None
        feats.append(dict(x=x_, y=y_, d=h["d_design"], top=h["top"], depth=depth, one=(h["kind"] == "A")))
feats.sort(key=lambda f: (-f["y"], f["x"]))
rows4 = [["BOSS HOLES (BASIC, MODEL FRAME: ORIGIN ON A AT THE BORE CENTRES)", "", "", "", "", ""],
         ["ID", "X", "Y", "HOLE", "TOP Z", "DEPTH"]]
for i, f_ in enumerate(feats, 1):
    f_["id"] = "H%d%s" % (i, "*" if f_["one"] else "")
    rows4.append([f_["id"], "%.2f" % f_["x"], "%.2f" % f_["y"], "%s%.1f" % (DIA, f_["d"]), ("ON A" if abs(f_["top"]) < 1e-6 else "%.2f" % f_["top"]),
                  "%.1f" % f_["depth"] if f_["depth"] else "-"])
N("table4", lambda: table((440.0, 575.0), [22.0, 30.0, 30.0, 26.0, 30.0, 26.0], rows4))
N("fcf_table4", lambda: gdt.fcf(dwg, "Position", "0.2", ("A", "B", "C"), True, (440.0, 575.0 - 8.0 * len(rows4) - 14.0), size=GT))
N("fcf_table4_note", lambda: nxd.note(dwg, ["ALL H HOLES:"], (440.0, 575.0 - 8.0 * len(rows4) - 5.0), size=GT))
N("note4", lambda: nxd.note(dwg, ["* ONE SIDE ONLY (NOT MIRRORED)."], (440.0, 575.0 - 8.0 * len(rows4) - 28.0), size=GT))
# hole pitches (symmetric pairs, centre to centre), text in white space: the neck opening and below the part
HP = {}
for f_ in feats:
    HP.setdefault((round(abs(f_["x"]), 2), round(f_["y"], 2)), []).append(f_)


def hole_arc(f_):
    return m3d.arc_near(back, M(f_["x"], f_["y"], f_["top"]), f_["d"] / 2.0, tol=0.3, axis=1)


for (ax_, ay_), ybal in (((31.48, -125.89), -139.0), ((74.89, -232.98), -304.0), ((105.79, -150.35), -318.0)):
    pr = [f_ for k_, v_ in HP.items() if abs(k_[0] - ax_) < 0.05 and abs(k_[1] - ay_) < 0.05 for f_ in v_]
    if len(pr) != 2:
        res["errors"]["pitch_%.0f" % ay_] = "pair not found"
        continue
    fa, fb = sorted(pr, key=lambda f_: f_["x"])
    D("P_%s_%s" % (fa["id"].rstrip("*"), fb["id"].rstrip("*")),
      lambda fa=fa, fb=fb, ybal=ybal, dx=(-15.0 if abs(ay_ + 125.89) < 0.1 else 0.0):   # outC14: centre the text inside the D37.4 hole
      lin(back, hole_arc(fa), hole_arc(fb), (xy(back, M(0.0, ybal, fa["top"]))[0] + dx, xy(back, M(0.0, ybal, fa["top"]))[1]), "horizontal",
                                          S.Center, S.Center, tol=TOL1, expect=abs(fb["x"] - fa["x"]), etol=0.05))

# balloons: each just outside the part outline at the outline point nearest to its hole, offset along the
# outline's outward normal; 14 mm apart; then any two leaders that cross swap their balloons
OL = json.load(open(os.path.join(ROOT, "work", "outline.json")))["pts"]
NO_ = len(OL)


def inside_ol(x, y):
    c = False
    for i in range(0, NO_, 2):
        x1, y1 = OL[i]; x2, y2 = OL[(i + 2) % NO_]
        if (y1 > y) != (y2 > y) and x < x1 + (y - y1) * (x2 - x1) / (y2 - y1):
            c = not c
    return c


GAP = 13.0
cands = []
for i in range(0, NO_, 6):
    (xa, ya), (xb, yb) = OL[(i - 8) % NO_], OL[(i + 8) % NO_]
    tx, ty = xb - xa, yb - ya
    ln = math.hypot(tx, ty) or 1.0
    nx_, ny_ = -ty / ln, tx / ln
    qx, qy = OL[i]
    if inside_ol(qx + 2.0 * nx_, qy + 2.0 * ny_):
        nx_, ny_ = -nx_, -ny_
    bx, by = qx + GAP * nx_, qy + GAP * ny_
    if inside_ol(bx, by) or min(math.hypot(bx - px, by - py) for (px, py) in OL[::4]) < GAP - 1.5:
        continue                                    # a concave corner: the offset point falls back into the part
    cands.append((bx, by, qx, qy))
res["balloon_cands"] = len(cands)


def segx(p1, p2, p3, p4):
    def o(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
    return o(p1, p2, p3) * o(p1, p2, p4) < 0 and o(p3, p4, p1) * o(p3, p4, p2) < 0


for f_ in feats:
    f_["dist"] = min(math.hypot(c_[2] - f_["x"], c_[3] - f_["y"]) for c_ in cands)
place = {}
for f_ in sorted(feats, key=lambda f: f["dist"]):
    best = None
    for (bx, by, qx, qy) in cands:
        if any(math.hypot(bx - u[0], by - u[1]) < 14.0 for u in place.values()):
            continue
        cost = math.hypot(bx - f_["x"], by - f_["y"])
        cross = sum(1 for g_id, u in place.items() if segx((bx, by), (f_["x"], f_["y"]), u, u[2]))
        cost += 200.0 * cross
        if best is None or cost < best[0]:
            best = (cost, bx, by)
    place[f_["id"]] = (best[1], best[2], (f_["x"], f_["y"]))
for _it in range(40):                               # swap the balloons of crossing leaders
    changed = False
    ids = list(place)
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            u, v = place[ids[i]], place[ids[j]]
            if segx(u[:2], u[2], v[:2], v[2]):
                place[ids[i]], place[ids[j]] = (v[0], v[1], u[2]), (u[0], u[1], v[2])
                changed = True
    if not changed:
        break
res["balloon_crossings"] = sum(1 for i, a_ in enumerate(place.values()) for j, b_ in enumerate(place.values())
                               if i < j and segx(a_[:2], a_[2], b_[:2], b_[2]))
res["balloons"] = []
for f_ in feats:
    bx, by, _h = place[f_["id"]]
    pos = xy(back, M(bx, by, f_["top"]))

    def mk(f_=f_, pos=pos):
        z = f_["top"]
        try:
            c = hole_arc(f_)
            a = M(f_["x"] + f_["d"] / 2.0 * (1 if f_["x"] > 0 else -1), f_["y"], z)
        except RuntimeError:
            c, a = ptdwg.near(back, M(f_["x"], f_["y"], z))
            res.setdefault("balloon_near", []).append(f_["id"])
        return gdt.balloon(dwg, f_["id"].rstrip("*"), pos, c, back, a, size=11.0, text_size=4.5)
    N("balloon_" + f_["id"], mk)
    res["balloons"].append([f_["id"], round(bx, 1), round(by, 1), round(math.hypot(bx - f_["x"], by - f_["y"]), 1)])
