"""Diagnostic (nothing saved): which one-piece neck band variants unite. Each attempt is undone. args: prt out_json"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf

PRT, OUT = sys.argv[1], sys.argv[2]
res = {"log": []}
log = res["log"].append


def inside(part, b, xyz):
    return nxh.dist_to(part, b, xyz) < 1e-4


def new_solids(part, before):
    tags = {b.Tag for b in before}
    return [b for b in part.Bodies if b.IsSolidBody and b.Tag not in tags]


try:
    part = nxh.open_part(PRT)
    sol = [b for b in part.Bodies if b.IsSolidBody and not getattr(b, "IsConvergentBody", False)]
    body = max(sol, key=lambda b: len(b.GetFaces()))
    find = lambda mid: [e for e in body.GetEdges() if math.dist(nxh.edge_points(e, n=3)[1], mid) < 0.3]
    mR, tR = find((47.57, 70.39, -71.02)), find((56.38, 109.1, -8.82))
    mL, tL = find((-47.57, 70.39, -71.02)), find((-56.38, 109.1, -8.82))
    qR_in, qR_out = (48.9, 69.5, -69.5), (46.4, 70.4, -69.5)
    qL_in = (-48.9, 69.5, -69.5)

    def attempt(es, label, start=-1.0, end=5.5):
        for thin in ((0, 3.0), (-3.0, 0)):
            mk = nxh.mark("t", False)
            before = list(part.Bodies)
            try:
                f = nxf.extrude_ex(part, nxh.section(part, edges=es, help_point=tuple(nxh.edge_points(es[0], n=3)[1])),
                                   (0, 0, 1), start=start, end=end, thin=thin)
            except Exception as ex:  # noqa: BLE001
                log(f"{label} thin {thin}: extrude failed {str(ex)[:70]}")
                nxh.undo_to(mk); continue
            bs = new_solids(part, before)
            okR = any(inside(part, x, qR_in) for x in bs) and not any(inside(part, x, qR_out) for x in bs)
            okL = any(inside(part, x, qL_in) for x in bs)
            if not (okR or okL):
                nxh.undo_to(mk); continue
            try:
                nxh.unite(part, body, tools=bs, check=False)
                log(f"{label} thin {thin} start {start}: {len(bs)} body, R {okR} L {okL}: UNITE OK")
            except Exception as ex:  # noqa: BLE001
                log(f"{label} thin {thin} start {start}: {len(bs)} body, R {okR} L {okL}: unite refused")
            nxh.undo_to(mk)
            return

    attempt(mL, "left main alone")
    attempt(mL + tL, "left main+top alone")
    attempt(mR + tR + mL + tL, "one chain", start=-1.0)
    attempt(mR + tR + mL + tL, "one chain", start=-0.3)
    attempt(mR + tR + mL + tL, "one chain", start=0.0)
    attempt(mR + mL, "one chain no tops", start=-0.3)
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(OUT, res)
