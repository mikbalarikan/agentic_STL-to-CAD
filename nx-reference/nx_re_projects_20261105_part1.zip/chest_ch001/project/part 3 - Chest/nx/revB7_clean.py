"""CH-001 Rev B: clean continuous neck band and bottom-end band (2026-10-31, user: "continuity, one U-shaped surface").
Appended at the END of the user's history on a COPY of Deviation_Check/CH-001_Chest_RevB_vs_SCAN_END_POSTS.prt (08:10).
args: src_prt dst_prt

1 NECK_LIP_R / NECK_LIP_L: thin Extrude (3.0 into the wall, from 1 below the edge to 5.5 above it, along +z) of the
  neck inner edge + the edge up to the rim, one per side, each trimmed exactly at x 0 (NECK_LIP_*_HALF) and united:
  together one continuous U band from rim to rim (a single chain is refused by NX at x 0).
2 NECK_U_BOTTOM: the bottom of the U is lowered to the scan with ONE smooth cut: a Studio Spline in the x-z plane
  through the scan's band top (z -88.4 at x 0 ... -73.9 at +-44, then above the band) extruded along -y over y 64..36;
  it meets the band top tangentially near |x| 44, so the band runs on without a step.
3 END_TRIM: one planar cut of the bottom end at y -272.9: a single continuous end band from rim to rim (it takes the
  corner relief corners, the end chamfers and the old end face off together)."""
import os, sys, math, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, os.path.join(os.path.dirname(os.environ["NXH_DIR"].rstrip("\\/")), "..", "nx-curves-and-sketches", "scripts"))
import NXOpen
import nxh, nxf, nxre
import curvekit as ck

SRC, DST = sys.argv[1], sys.argv[2]
OUT = os.path.dirname(DST)
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": []}
log = res["log"].append
LIP_T, LIP_H, LIP_BELOW = 3.0, 5.5, 1.0
U_PTS = [(0.0, -88.42), (20.0, -87.2), (32.0, -84.9), (38.0, -82.3), (42.0, -78.1), (46.0, -68.3), (50.0, -55.5)]
U_Y0, U_Y1, U_ZTOP = 64.0, 36.0, -30.0
END_Y = -272.9


def fvol(part, body, acc=0.99):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


def is_conv(b):
    try:
        return bool(b.IsConvergentBody)
    except Exception:  # noqa: BLE001
        return False


def inside(part, b, xyz):
    return nxh.dist_to(part, b, xyz) < 1e-4


def new_solids(part, before):
    tags = {b.Tag for b in before}
    return [b for b in part.Bodies if b.IsSolidBody and b.Tag not in tags]


try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)
    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: fvol(part, b))
    res["features_before"] = len(list(part.Features))
    res["errors_before"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    D = nxh.Datums(part)
    E = {k: nxh.expr(part, nm, val, comment=cm).Name for k, nm, val, cm in (
        ("T", "CH_NECK_LIP_T", LIP_T, "neck band thickness (from the neck cut face into the wall)"),
        ("H", "CH_NECK_LIP_H", LIP_H, "neck band height above the inner neck edge (along z)"),
        ("Y", "CH_END_Y", END_Y, "bottom end plane"))}

    # the vertical END_CORNER_RELIEF (z +2..-42) left a 4-6 mm jog in the end band at z -42: replaced by END_CURL_* below
    old_rel = [g for g in part.Features if g.Name in ("END_CORNER_RELIEF", "END_FACE_INNER_CHAMFER")]
    assert len(old_rel) == 2, f"relief / end chamfer not found: {[g.Name for g in old_rel]}"
    # the end chamfer sits within 2.7 mm of the old end and goes with END_TRIM anyway; it depends on the relief
    part.Features.SuppressFeatures(old_rel)
    nxh.update("suppress relief")
    log(f"END_CORNER_RELIEF suppressed; feature errors {[str(e) for e in nxh.feature_errors(part, recheck=False)]}")
    find = lambda mid: [e for e in body.GetEdges() if math.dist(nxh.edge_points(e, n=3)[1], mid) < 0.3]
    mR, tR = find((47.57, 70.39, -71.02)), find((56.38, 109.1, -8.82))
    mL, tL = find((-47.57, 70.39, -71.02)), find((-56.38, 109.1, -8.82))
    log(f"neck edges: main R {len(mR)} top R {len(tR)} main L {len(mL)} top L {len(tL)}")
    assert len(mR) == len(tR) == len(mL) == len(tL) == 1

    # ------------------------------------------------ 1 neck band, two halves meeting on x 0
    # each half ends exactly on x 0, where the two end faces meet only along an edge (NX refuses that); the U-bottom
    # cut below takes the whole band height off for |x| < ~30, so each half is trimmed at |x| 20 instead
    X_HALF = 20.0
    for side, es, sx in (("R", mR + tR, 1.0), ("L", mL + tL, -1.0)):
        _, pl0 = nxh.datum_plane(part, (sx * X_HALF, 0, 0), (sx, 0, 0), name=f"NECK_LIP_{side}_END_PLANE")
        q_in, q_out = (sx * 48.9, 69.5, -69.5), (sx * 46.4, 70.4, -69.5)
        made = None
        for thin in ((0, E["T"]), (f"-{E['T']}", 0)):
            mk = nxh.mark("thin", False)
            before = list(part.Bodies)
            try:
                f = nxf.extrude_ex(part, nxh.section(part, edges=es, help_point=tuple(nxh.edge_points(es[0], n=3)[1])),
                                   (0, 0, 1), start=-LIP_BELOW, end=E["H"], thin=thin)
            except Exception as ex:  # noqa: BLE001
                log(f"{side}: thin {thin} failed: {str(ex)[:100]}")
                nxh.undo_to(mk)
                continue
            bs = new_solids(part, before)
            if bs and any(inside(part, x, q_in) for x in bs) and not any(inside(part, x, q_out) for x in bs):
                made = (f, bs, thin)
                break
            nxh.undo_to(mk)
        assert made is not None, f"neck band {side} not made"
        f, bs, thin = made
        f.SetName(f"NECK_LIP_{side}")
        for x in bs:
            mk = nxh.mark("half", False)
            ftb, _ = nxf.trim_body(part, x, datum_plane=pl0, reverse=True)       # keeps the arm side (|x| > 20)
            if not inside(part, x, q_in):
                nxh.undo_to(mk)
                ftb, _ = nxf.trim_body(part, x, datum_plane=pl0, reverse=False)
            assert inside(part, x, q_in), f"band {side} lost its arm"
            ftb.SetName(f"NECK_LIP_{side}_HALF")
        fu = nxh.unite(part, body, tools=bs, check=False)
        fu.SetName(f"NECK_LIP_{side}_UNITE")
        log(f"NECK_LIP_{side}: thin {thin}, trimmed on x 0, united")

    # ------------------------------------------------ 2 smooth U-bottom cut
    pts = [(-x, U_Y0, z) for x, z in reversed(U_PTS[1:])] + [(x, U_Y0, z) for x, z in U_PTS]
    fs, spl = ck.studio_spline(part, pts, degree=3)
    if fs is not None:
        fs.SetName("NECK_U_BOTTOM_CURVE")
    xe, ze = U_PTS[-1]
    ln = [nxh.line(part, (xe, U_Y0, ze), (xe, U_Y0, U_ZTOP)), nxh.line(part, (xe, U_Y0, U_ZTOP), (-xe, U_Y0, U_ZTOP)),
          nxh.line(part, (-xe, U_Y0, U_ZTOP), (-xe, U_Y0, ze))]
    sec = nxh.section(part, curves=[spl] + ln, help_point=(0.0, U_Y0, U_ZTOP))
    v0 = fvol(part, body)
    fcut = nxf.extrude_ex(part, sec, (0, -1, 0), start=0, end=U_Y0 - U_Y1, op=BOOL.Subtract, target=body)
    fcut.SetName("NECK_U_BOTTOM")
    log(f"U bottom cut: {v0 - fvol(part, body):.0f} mm3 (0.99 volume, noisy)")
    pr = {"u_mid_above_scan": nxh.dist_to(part, body, (0.0, 41.0, -87.6)),        # just above the scan's top: air
          "u_mid_below": nxh.dist_to(part, body, (0.0, 39.5, -90.0)),             # in the wall: inside
          "arm_band_R": nxh.dist_to(part, body, (48.9, 69.5, -69.5)), "arm_band_L": nxh.dist_to(part, body, (-48.9, 69.5, -69.5)),
          "rim_band_R": nxh.dist_to(part, body, (57.4, 109.1, -6.0))}

    # ------------------------------------------------ 2b corner curl (the scan's fitted plane, an/r1_curl.py)
    # plane n (-0.5432, -0.8343, 0.0938) through (59.70, -271.69, -21.84); sketch at z +2 = the plane's trace there,
    # extruded down ALONG the plane (its steepest-descent direction) to z -60, where it meets the wall
    nC = (-0.5432, -0.8343, 0.0938)
    dC = [0.0, 0.0, -1.0]
    k_ = sum(dC[i] * nC[i] for i in range(3))
    dC = [dC[i] - k_ * nC[i] for i in range(3)]
    ln_ = math.sqrt(sum(c * c for c in dC)); dC = [c / ln_ for c in dC]
    ZS, ZB = 2.0, -60.0
    y50 = -265.30 + 0.651 * 4.0                      # trace at z +2: (54, -265.30), slope -0.651
    x280 = 54.0 + (280.0 - 265.30) / 0.651
    _, plc = nxh.datum_plane(part, (0, 0, ZS), (0, 0, 1), name="END_CURL_PLANE")
    for side, sx in (("R", 1.0), ("L", -1.0)):
        skc = nxf.new_sketch(part, plc, D.x, nxh.point(part, 0, 0, ZS), name=f"END_CURL_{side}_SKETCH")
        tri = [(sx * 50.0, y50, ZS), (sx * 50.0, -280.0, ZS), (sx * x280, -280.0, ZS)]
        nxf.add(skc, *nxh.polyline(part, tri), infer=True)
        nxf.finish_sketch(skc)
        dv = (sx * dC[0], dC[1], dC[2])
        fc_ = nxf.extrude_ex(part, nxh.section_feature(part, [skc.Feature]), dv, start=0, end=round((ZS - ZB) / -dC[2], 3),
                             op=BOOL.Subtract, target=body)
        fc_.SetName(f"END_CURL_{side}")
    log(f"END_CURL R/L: direction {[round(c, 4) for c in dC]}")
    # the plane clips the Rev A post near the rim: restore it (D8.6 round its eccentric D3.0 bore) down to the taper
    _, plp = nxh.datum_plane(part, (0, 0, 0.5), (0, 0, 1), name="CORNER_POST_RESTORE_PLANE")
    skp = nxf.new_sketch(part, plp, D.x, nxh.point(part, 0, 0, 0.5), name="CORNER_POST_RESTORE_SKETCH")
    for sx in (1.0, -1.0):
        nxf.sketch_circle(part, skp, nxh.point(part, sx * 61.1, -266.9, 0.5), "8.6")
        nxf.sketch_circle(part, skp, nxh.point(part, sx * 59.3, -265.8, 0.5), "3.0")
    stp = nxf.finish_sketch(skp)
    fp = nxf.extrude_ex(part, nxh.section_feature(part, [skp.Feature]), (0, 0, -1), start=0, end=24.5, op=BOOL.Unite, target=body)
    fp.SetName("CORNER_POST_RESTORE")
    log(f"CORNER_POST_RESTORE sketch {stp['status']} dof {stp['dof']}")

    # ------------------------------------------------ 3 planar bottom end
    _, ple = nxh.datum_plane(part, (0, END_Y, 0), (0, 1, 0), name="END_TRIM_PLANE")
    sq = [(-200, -200), (200, -200), (200, 50), (-200, 50)]
    cs = [nxh.line(part, (sq[i][0], END_Y, sq[i][1]), (sq[(i + 1) % 4][0], END_Y, sq[(i + 1) % 4][1])) for i in range(4)]
    v1 = fvol(part, body)
    fe = nxf.extrude_ex(part, nxh.section(part, curves=cs, help_point=(-200, END_Y, -200)), (0, -1, 0), start=0, end=40,
                        op=BOOL.Subtract, target=body)
    fe.SetName("END_TRIM")
    log(f"END_TRIM at y {END_Y}: {v1 - fvol(part, body):.0f} mm3")
    pr["end_band_arm_R"] = nxh.dist_to(part, body, (65.0, END_Y + 0.5, -20.0))
    pr["end_band_bottom"] = nxh.dist_to(part, body, (0.0, END_Y + 0.5, -84.5))
    pr["curl_excess_gone"] = nxh.dist_to(part, body, (57.5, -272.5, -30.0))      # was corner web: now air (> 0)
    pr["curl_wall_kept"] = nxh.dist_to(part, body, (58.5, -272.4, -55.0))        # wall at depth: inside (< 0)
    pr["post_top"] = nxh.dist_to(part, body, (57.3, -267.5, -3.0))               # post SW side near the top: inside
    res["probes"] = pr

    res["solids_after"] = len([bb for bb in part.Bodies if bb.IsSolidBody and not bb.IsBlanked and not is_conv(bb)])
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["features_after"] = len(list(part.Features))
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["new_features"] = [g.GetFeatureName() + " / " + g.Name for g in list(part.Features)[res["features_before"]:]]
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    res["stl"] = nxre.stl_export(part, body, os.path.join(OUT, "chest_R7.stl"), chord=0.01, max_edge=2.5)
    ok = res["body_ok"] and res["solids_after"] == 1 and len(res["errors_after"]) <= len(res["errors_before"])
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_clean7.json", res)
