"""Test: build every smooth pocket / bump tool of work/c10/sheets.json in an empty part (time, volume vs expected),
plus one feature of each SCHEMA type.  args: out_dir"""
import os, sys, json, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXCK_DIR"]); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import NXOpen
import nxh, nxf
import c10_feat as cf

OUT = sys.argv[1]; os.makedirs(OUT, exist_ok=True)
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest"
res = {"log": []}; T0 = time.time()


def _fv(part, body):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, 0.99, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


nxh.volume = _fv


def log(m):
    res["log"].append(f"[{time.time()-T0:6.0f}s] {m}"); nxh.write_json(os.path.join(OUT, "t.json"), res)


try:
    part = nxh.new_part(os.path.join(OUT, "t.prt"))
    S = json.load(open(os.path.join(ROOT, "work", "c10", sys.argv[2] if len(sys.argv) > 2 else "sheets.json")))
    for rec in S["tools"]:
        t1 = time.time()
        try:
            t, junk = cf.sheet_tool(part, rec, log)
            exp = rec["v_below_hi"] - (rec.get("v_below_lo", 0.0))
            log(f"  {rec['name']}: {time.time()-t1:.0f}s, expected {exp:.0f}, body_ok {nxh.body_ok(part, t)}")
        except Exception as e:  # noqa: BLE001
            log(f"  {rec['name']} FAILED {traceback.format_exc()[-400:]}")
    tests = [
        {"id": "c", "type": "cyl", "p0": [0, 0, -10], "axis": [0, 0, 1], "d": 6, "len": 10},
        {"id": "k", "type": "cyl", "p0": [10, 0, -10], "axis": [0.6, 0, 0.8], "d": 6, "d0": 7, "d1": 5, "len": 10},
        {"id": "s", "type": "sphere", "c": [20, 0, 0], "d": 6},
        {"id": "p", "type": "prism", "outline": [[40, 0], [50, 0], [50, 8], [40, 8]], "z0": -10, "z1": 0,
         "cut_planes": [{"p": [45, 4, -3], "n": [0.3, 0, 1]}]},
        {"id": "r", "type": "prism", "outline": [[60, 0], [70, 0], [70, 8], [60, 8]], "hole": [[62, 2], [68, 2], [68, 6], [62, 6]], "z0": -10, "z1": 0},
        {"id": "sl", "type": "slot", "c": [80, 0], "len": 7.3, "w": 1.7, "ang": 66, "z0": -10, "z1": 0},
    ]
    for F in tests:
        for mir in (False, True):
            try:
                bs = cf.feature_bodies(part, F, mir)
                log(f"feature {F['id']} mirror {mir}: {[round(nxh.volume(part, b), 1) for b in bs]} bbox {[round(v, 1) for v in nxh.bbox(bs[0])]}")
            except Exception:  # noqa: BLE001
                log(f"feature {F['id']} FAILED {traceback.format_exc()[-300:]}")
    nxh.save(part); log("saved")
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc(); log("ERROR")
nxh.write_json(os.path.join(OUT, "t.json"), res)
