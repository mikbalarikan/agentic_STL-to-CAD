"""Rasterise PDF pages to PNG. usage: pdf2png.py in.pdf out_prefix [dpi]"""
import sys
import fitz
doc = fitz.open(sys.argv[1]); dpi = int(sys.argv[3]) if len(sys.argv) > 3 else 60
for i, pg in enumerate(doc, 1):
    pg.get_pixmap(dpi=dpi).save(f"{sys.argv[2]}_p{i}.png")
print(len(doc), "pages")
