# -*- coding: utf-8 -*-
# Annotations of the CH-001 drawing set; exec'd inside dwg_chest.py (views, helpers and res are in scope).
# Drafting-curve points are drawing-part coordinates = M(model point).


def straight(view, pred):
    out = []
    for c, _ps in nxd.curves(view):
        p = nxd.curve_points(c)
        if len(p) == 3 and pred(p[0], p[1]):
            out.append((c, p))
    return out


def longest(cands):
    if not cands:
        raise RuntimeError("no curve")
    return max(cands, key=lambda cp: sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)))


def L(cp):
    return sum((cp[1][0][i] - cp[1][1][i]) ** 2 for i in range(3)) ** 0.5


def lin(view, ca, cb, origin, method, sa, sb, basic=False, tol=None, before=None, after=None, expect=None, etol=0.05):
    meth = {"horizontal": nxd.MM.Horizontal, "vertical": nxd.MM.Vertical, "point": nxd.MM.PointToPoint,
            "cylindrical": nxd.MM.Cylindrical}[method]
    b = dwg.Dimensions.CreateLinearDimensionBuilder(A.Dimension.Null)
    try:
        b.Measurement.Method = meth
        b.FirstAssociativity.SetValue(sa, ca, view, nxd.P0, None, None, nxd.P0)
        b.SecondAssociativity.SetValue(sb, cb, view, nxd.P0, None, None, nxd.P0)
        nxd._style(b, tol=tol, before=before, after=after)
        _style0(b, 2, DT)
        if basic:
            b.Style.DimensionStyle.ToleranceType = A.ToleranceType.Basic
        b.Origin.Origin.SetValue(None, None, nxh.P(origin[0], origin[1], 0.0))
        d = b.Commit()
    finally:
        b.Destroy()
    if expect is not None and abs(d.ComputedSize - expect) > etol:
        v = d.ComputedSize
        ptdwg._delete([d])
        raise RuntimeError("lin: %.4f instead of %.4f" % (v, expect))
    return d


def vline(view, X, tol=0.06, minlen=0.5):
    """straight drafting curves at drawing X_d = X (both ends)."""
    return [cp for cp in straight(view, lambda p0, p1: abs(p0[0] - X) < tol and abs(p1[0] - X) < tol) if L(cp) >= minlen]


def zline(view, Z, tol=0.06, minlen=0.5, axis=1):
    return [cp for cp in straight(view, lambda p0, p1: abs(p0[axis] - Z) < tol and abs(p1[axis] - Z) < tol) if L(cp) >= minlen]


def stack_below(ann):
    ao = A.Annotation.AssociativeOriginData()
    ao.OriginType = A.AssociativeOriginType.AttachedToStack
    ao.StackAlignmentPosition = A.StackAlignmentPosition.Below
    ao.OffsetAnnotation = ann
    return ao


def stack_fcf(name, dim, char, tol, datums=(), dia=False, pos=None):
    def f():
        try:
            b = dwg.Annotations.CreateDraftingFeatureControlFrameBuilder(A.Fcf.Null)
            try:
                b.Characteristic = gdt.characteristic(char)
                b.FrameStyle = A.FeatureControlFrameBuilder.FcfFrameStyle.SingleFrame
                b.FeatureControlFrameDataList.Append(dwg.Annotations.CreateFeatureControlFrameDataBuilder(None))
                d = b.FeatureControlFrameDataList.FindItem(0)
                if dia:
                    d.ZoneShape = A.FeatureControlFrameDataBuilder.ToleranceZoneShape.Diameter
                d.ToleranceValue = str(tol)
                for r_, l_ in zip((d.PrimaryDatumReference, d.SecondaryDatumReference, d.TertiaryDatumReference), datums):
                    r_.Letter = l_
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(dim))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-300:]
            if pos is None:
                raise
            res["gdt"][name] = "free"
            return gdt.fcf(dwg, char, tol, datums, dia, pos, size=GT)
    return N(name, f)


def datum_under(name, letter, ann, fallback):
    def f():
        try:
            b = dwg.Annotations.Datums.CreateDraftingDatumFeatureSymbolBuilder(None)
            try:
                b.Letter = letter
                b.Style.LetteringStyle.GeneralTextSize = GT
                b.Origin.SetAssociativeOrigin(stack_below(ann))
                o = b.Commit()
            finally:
                b.Destroy()
            res["gdt"][name] = "stacked"
            return o
        except Exception:  # noqa: BLE001
            res["gdt"][name + "_stack_err"] = traceback.format_exc()[-300:]
            res["gdt"][name] = "leader"
            return fallback()
    return N(name, f)


BB = FIN.get("bbox_exact_stl", FIN["bbox"])
SZ = (BB[3] - BB[0], BB[4] - BB[1], BB[5] - BB[2])

# ---------------------------------------------------------------- SH1
sheets[0].Open()
# Right view: rim plane edge-on = straight curves at drawing Y_d = model z = 0
rim = sorted(zline(right, 0.0, 0.06, 5.0), key=lambda cp: -L(cp))
res["sh1_rim_curves"] = len(rim)
if rim:
    ends = []
    for c, _ps in nxd.curves(right):
        p = nxd.curve_points(c)
        if len(p) >= 2:
            ends += [(c, p[0]), (c, p[1])]
    ctop = max(ends, key=lambda e: e[1][2]); cbot = min(ends, key=lambda e: e[1][2])
    res["sh1_height_ends"] = [[round(v, 2) for v in ctop[1]], [round(v, 2) for v in cbot[1]]]
    hx = xy(right, (0.0, 0.0, 0.0))[0]
    D("H_overall", lambda: m3d.dim_ends(right, ctop[0], ctop[1], cbot[0], cbot[1], (hx + 30.0, xy(right, (0, 0, -80.0))[1]), "vertical",
                                        expect=ctop[1][2] - cbot[1][2], etol=0.05))
    crim = rim[0]
    pm = [0.5 * (crim[1][0][i] + crim[1][1][i]) for i in range(3)]
    fA = N("fcf_flat_A", lambda: gdt.fcf(dwg, "Flatness", "0.1", (), False, (hx + 16.0, xy(right, (0, 0, 75.0))[1]), crim[0], right, pm, size=GT))
    if fA is not None:
        datum_under("datum_A", "A", fA, lambda: gdt.datum(dwg, "A", (hx + 16.0, xy(right, (0, 0, 60.0))[1]), crim[0], right, pm, size=GT))
x0, y0 = 425.0, 205.0
note_lines(["NOTES",
            "1. GENERAL TOLERANCES ISO 2768-mK. GD&T PER ISO 1101.",
            "2. GEOMETRY NOT DIMENSIONED PER 3D MODEL CH-001 REV A.",
            "3. ALL SURFACES UNLESS OTHERWISE SPECIFIED:",
            "",
            "4. WALL 3.25 UNLESS SHOWN. INTERNAL CORNERS R1 MAX. BREAK EDGES 0.2-0.5.",
            "5. Ra 3.2 UNLESS OTHERWISE SPECIFIED.",
            "6. PART IS SYMMETRIC ABOUT THE MID-PLANE (X = 0) EXCEPT SH4 ITEMS MARKED *.",
            "7. OVERALL SIZE %.1f x %.1f x %.1f (REF)." % SZ], x0, y0, step=9.0)
N("fcf_profile_all", lambda: gdt.fcf(dwg, "ProfileOfASurface", "0.3", ("A", "B", "C"), False, (x0 + 7.0, y0 - 4 * 9.0 + 2.0), size=GT))

# ---------------------------------------------------------------- SH2 front panel
sheets[1].Open()
hr = PN["hole_d"] / 2.0
rr = PN["circle_d"] / 2.0
if secB is not None:
    # the hole wall in the cut is a short arc (tilted cylinder): pick any curve whose two end points sit at X_d = -+r
    def walls(view, X):
        out = []
        for c, _ps in nxd.curves(view):
            p = nxd.curve_points(c)
            if len(p) >= 3 and abs(p[0][0] - X) < 0.15 and abs(p[1][0] - X) < 0.15 and abs(p[0][1] - p[1][1]) > 0.5:
                out.append((c, max(p[:2], key=lambda q: q[1])))
        return out
    wa, wb = walls(secB, -hr), walls(secB, hr)
    res["secB_hole_walls"] = [len(wa), len(wb)]
    if wa and wb:
        (ca, pa), (cb, pb) = wa[0], wb[0]
        dB = D("D_hole", lambda: m3d.dim_ends(secB, ca, pa, cb, pb, (xy(secB, pa)[0] + hr, xy(secB, pa)[1] + 30.0), "cylindrical",
                                             expect=PN["hole_d"], etol=0.1))
        if dB is not None:
            stack_fcf("fcf_pos_hole", dB, "Position", "0.2", ("A", "B", "C"), True, None)
if secC is not None:
    wl = [cp for cp in vline(secC, -rr, 0.12) + vline(secC, rr, 0.12)]
    res["secC_recess_walls"] = [[round(v, 2) for v in cp[1][0]] for cp in wl]
    a_ = [cp for cp in wl if cp[1][0][0] < 0]; b_ = [cp for cp in wl if cp[1][0][0] > 0]
    if a_ and b_:
        ca, cb = longest(a_), longest(b_)
        yb = min(ca[1][0][1], ca[1][1][1]); zb = ca[1][0][2]
        dC = D("D_recess", lambda: lin(secC, ca[0], cb[0], (xy(secC, (0.0, yb, zb))[0], xy(secC, (0.0, yb, zb))[1] + 26.0),
                                         "cylindrical", S.Mid, S.Mid, expect=PN["circle_d"], etol=0.1))
TH = json.load(open(os.path.join(ROOT, "work", "through.json")))
led = [o for o in TH if o["kind"] == "R" and o["cen"][1] > -30 and o["cen"][1] < -10]
led_d = round(2.0 * math.sqrt(sum(o["area"] for o in led) / max(1, len(led)) / math.pi), 1) if led else 2.5
rows = [["FRONT PANEL (BASIC, MODEL FRAME)", ""],
        ["PANEL PLANE", "TILTED %.1f° ABOUT X TO DATUM A" % PN["tilt_deg"]],
        ["PANEL PLATE / RECESSED DISC", "%.2f / %.2f THICK (NORMAL TO PANEL)" % (PN["t_panel"], PN["t_disc"])],
        ["THROUGH HOLE %s%.1f" % (DIA, PN["hole_d"]), "X 0, Y %.1f, AXIS NORMAL TO PANEL" % PN["hole_c"][1]],
        ["RECESS %s%.1f" % (DIA, PN["circle_d"]), "X 0, Y %.1f, FLOOR 1.73 BELOW PANEL" % PN["circle_c"][1]],
        ["LED HOLES 4X %s%.1f THRU" % (DIA, led_d), "X ±%.1f / ±%.1f, Y %.1f" % (abs(min(o["cen"][0] for o in led)) if led else 0,
                                                                         abs(max(o["cen"][0] for o in led)) if led else 0,
                                                                         sum(o["cen"][1] for o in led) / max(1, len(led)))],
        ["SLOTS (VENTS)", "2 X 7 SHOULDER, 15 LOWER: THRU, NORMAL TO A"]]
N("table_panel", lambda: table((440.0, 140.0), [92.0, 160.0], rows))

# ---------------------------------------------------------------- SH3 shoulder flanges
sheets[2].Open()
if secD is not None:
    fR = vline(secD, -XC, 0.08, 3.0); fL = vline(secD, XC, 0.08, 3.0)
    res["secD_faces"] = [len(fR), len(fL)]
    if fR and fL:
        cR, cL = longest(fR), longest(fL)
        ztop = max(max(cR[1][0][1], cR[1][1][1]), max(cL[1][0][1], cL[1][1][1]))
        dW = D("W_shoulders", lambda: lin(secD, cR[0], cL[0], (xy(secD, (0, 0, 0))[0], xy(secD, (0, 0.0, 0))[1] - 20.0),
                                            "horizontal", S.Mid, S.Mid, basic=True, expect=2 * XC, etol=0.1))
        pR = [0.5 * (cR[1][0][i] + cR[1][1][i]) for i in range(3)]
        pL = [0.5 * (cL[1][0][i] + cL[1][1][i]) for i in range(3)]
        N("fcf_perp_R", lambda: gdt.fcf(dwg, "Perpendicularity", "0.05", ("A",), False, (xy(secD, pR)[0] - 45.0, xy(secD, pR)[1] - 20.0), cR[0], secD, pR, size=GT))
    # bore bottom: horizontal lines at model z = -bore/2 (drawing Z_d = model y = 0 plane; the section shows model z
    # on the drawing Y_d axis)
    # bore edge in the cut: arc R = bore/2 about the bore centre on the rim (drawing (-+XC, 0, 0))
    cands = []
    for c, _ps in nxd.curves(secD):
        p = nxd.curve_points(c)
        if len(p) == 4 and abs(abs(p[2][0]) - XC) < 0.1 and abs(p[2][1]) < 0.1 and                 all(abs(math.dist(p[k], p[2]) - BORE / 2.0) < 0.1 for k in (0, 1, 3)):
            cands.append((c, p))
    res["secD_bores"] = [[round(v, 2) for v in p[2]] for c, p in cands]
    for right_side in (True, False):                              # model +x is drawing -X_d
        dbo = None
        for c, p in [cp for cp in cands if (cp[1][2][0] < 0) == right_side]:
            org = (xy(secD, p[1])[0] + (-70.0 if right_side else 70.0), xy(secD, p[1])[1] - 40.0)
            try:
                d_ = m3d.dim_radial(secD, c, org, diameter=True, tol="H7")
            except Exception:  # noqa: BLE001
                continue
            if abs(d_.ComputedSize - BORE) < 0.05:
                dbo = d_; res["dims"]["D_bore_%s" % ("R" if right_side else "L")] = ptdwg.info(d_)
                break
            ptdwg._delete([d_])                                   # an elliptic edge, not the bore arc
        if dbo is not None:
            f_ = stack_fcf("fcf_bore_%s" % ("R" if right_side else "L"), dbo, "Position", "0.1", ("A",), True, None)
            letter = "B" if right_side else "C"
            if f_ is not None:
                datum_under("datum_" + letter, letter, f_, lambda c=c, p=p, letter=letter, org=org: gdt.datum(dwg, letter, (org[0], org[1] - 30.0), c, secD, p[3], size=GT))
rows3 = [["SHOULDER FLANGES (BOTH SIDES, BASIC)", ""],
         ["FACE ANGLE", "%.1f° ABOUT Z, FACES OPEN TOWARD +Y" % SH["angle_deg"]],
         ["FACE / BORE AXIS POINT", "X ±%.2f, Y 0, Z 0 (ON A)" % XC],
         ["BORE", "%s%.0f H7, AXIS NORMAL TO FACE" % (DIA, BORE)],
         ["FLANGE THICKNESS", "%.2f (NORMAL TO FACE)" % SH["flange_t"]],
         ["FACE: PERPENDICULARITY 0.05 TO A, POSITION OF BORE AXIS %s0.1 A" % DIA, ""]]
N("table_shoulder", lambda: table((440.0, 565.0), [150.0, 110.0], rows3))

# ---------------------------------------------------------------- SH4 interior features: balloons + table
sheets[3].Open()
HO = json.load(open(os.path.join(ROOT, "work", "holes.json")))
feats = []
for h in HO:
    if h["kind"] == "Lmirror":
        continue
    pts = [(h["x"], h["y"])] + ([(-h["x"], h["y"])] if h["kind"] == "R" else [])
    for (x_, y_) in pts:
        depth = (h["top"] - h["bottom"]) if h["bottom"] is not None else None
        feats.append(dict(x=x_, y=y_, d=h["d_design"], top=h["top"], depth=depth, one=(h["kind"] == "A")))
feats.sort(key=lambda f: (-f["y"], f["x"]))
rows4 = [["BOSS HOLES (BASIC, MODEL FRAME: ORIGIN ON A AT THE BORE CENTRES)", "", "", "", "", ""],
         ["ID", "X", "Y", "HOLE", "TOP Z", "DEPTH"]]
for i, f_ in enumerate(feats, 1):
    f_["id"] = "H%d%s" % (i, "*" if f_["one"] else "")
    rows4.append([f_["id"], "%.2f" % f_["x"], "%.2f" % f_["y"], "%s%.1f" % (DIA, f_["d"]), ("ON A" if abs(f_["top"]) < 1e-6 else "%.2f" % f_["top"]),
                  "%.1f" % f_["depth"] if f_["depth"] else "-"])
N("table4", lambda: table((440.0, 575.0), [22.0, 30.0, 30.0, 26.0, 30.0, 26.0], rows4))
N("fcf_table4", lambda: gdt.fcf(dwg, "Position", "0.2", ("A", "B", "C"), True, (440.0, 575.0 - 8.0 * len(rows4) - 14.0), size=GT))
N("fcf_table4_note", lambda: nxd.note(dwg, ["ALL H HOLES:"], (440.0, 575.0 - 8.0 * len(rows4) - 5.0), size=GT))
N("note4", lambda: nxd.note(dwg, ["* ONE SIDE ONLY (NOT MIRRORED)."], (440.0, 575.0 - 8.0 * len(rows4) - 28.0), size=GT))
# balloons: outside the plan outline, pushed radially from the part centre
OL = json.load(open(os.path.join(ROOT, "work", "outline.json")))["pts"]


def outline_hit(cx, cy, dx, dy):
    best = None
    for (px, py) in OL[::3]:
        vx, vy = px - cx, py - cy
        t = vx * dx + vy * dy
        if t <= 0:
            continue
        off = abs(vx * dy - vy * dx)
        if off < 3.0 and (best is None or t > best):
            best = t
    return best


cx0, cy0 = 0.0, -80.0


def offset_point(th, gap=16.0):
    dx, dy = math.cos(th), math.sin(th)
    t = outline_hit(cx0, cy0, dx, dy) or 150.0
    return cx0 + (t + gap) * dx, cy0 + (t + gap) * dy


res["balloons"] = []
placed = []
for f_ in feats:
    f_["th"] = math.atan2(f_["y"] - cy0, f_["x"] - cx0)
for f_ in sorted(feats, key=lambda f: f["th"]):
    th = f_["th"]
    bx, by = offset_point(th)
    k = 0
    while any(math.hypot(bx - qx, by - qy) < 13.0 for qx, qy in placed) and k < 80:
        k += 1
        th += math.radians(0.6)
        bx, by = offset_point(th)
    placed.append((bx, by))
    pos = xy(back, M(bx, by, f_["top"]))

    def mk(f_=f_, pos=pos):
        z = f_["top"]
        try:
            c = m3d.arc_near(back, M(f_["x"], f_["y"], z), f_["d"] / 2.0, tol=0.3, axis=1)
            a = M(f_["x"] + f_["d"] / 2.0 * (1 if f_["x"] > 0 else -1), f_["y"], z)
        except RuntimeError:
            c, a = ptdwg.near(back, M(f_["x"], f_["y"], z))
            res.setdefault("balloon_near", []).append(f_["id"])
        return gdt.balloon(dwg, f_["id"].rstrip("*"), pos, c, back, a, size=11.0, text_size=4.5)
    N("balloon_" + f_["id"], mk)
    res["balloons"].append([f_["id"], round(bx, 1), round(by, 1)])
