"""Remove faces that fail the body consistency check with Delete Face (heal) and re-check. Works on a copy of the
built part.  args: built_prt out_dir"""
import sys, os, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf
SRC, OUTD = sys.argv[1], sys.argv[2]
os.makedirs(OUTD, exist_ok=True)
res = {"log": []}
try:
    dst = os.path.join(OUTD, "Chest.prt"); shutil.copyfile(SRC, dst)
    part = nxh.open_part(dst)
    sol = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked]
    body = max(sol, key=lambda b: len(b.GetFaces()))
    for it in range(4):
        n, toks, tags = nxh.UFS.Modeling.AskBodyConsistency(body.Tag)
        res["log"].append(f"pass {it}: {n} faults {list(toks)}")
        if n == 0:
            break
        faces = [NXOpen.TaggedObjectManager.GetTaggedObject(t) for t in tags]
        faces = [f for f in faces if type(f).__name__ == "Face"]
        res["log"].append(f"faces {[[round(v, 2) for v in nxh.bbox(f)] for f in faces]}")
        try:
            nxf.delete_face(part, faces, heal=True)
            res["log"].append("delete face (heal) ok")
        except Exception as e:  # noqa: BLE001
            res["log"].append(f"delete face failed: {str(e)[:200]}"); break
    res["examine"] = nxh.examine_geometry(part, body)
    nxh.save(part)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUTD, "heal.json"), res)
