"""CH-001 Rev B: bottom-end corner fix after the user's own edits (2026-10-31). Appended at the END of the user's
history on a COPY of Deviation_Check/CH-001_Chest_RevB_vs_SCAN.prt (the user's file is never written).
args: src_prt dst_prt

In the scan the wall curls from the bottom corner post to the end face along a plane (an/r1_curl.py: n (-0.543,
-0.834, 0.094), rms 0.42 mm); Rev A filled that corner with the corner web block (x 56.8..65.4 to y -277), 4-6 mm of
material the scan does not have. Fix = END_CORNER_RELIEF: one sketch (a triangle per corner, mirrored about x 0,
hypotenuse = the plane's trace at z -15) and one Extrude subtract from z +2 down to z -42."""
import os, sys, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"]); sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxf, nxre

SRC, DST = sys.argv[1], sys.argv[2]
OUT = os.path.dirname(DST)
BOOL = nxh.BOOL
res = {"result": "FAIL", "log": []}
log = res["log"].append
TRI_R = [(50.0, -264.6), (50.0, -280.0), (73.6, -280.0)]
Z_TOP, Z_BOT = 2.0, -42.0


def fvol(part, body, acc=0.99):
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, acc, [body])
    try:
        return mb.Volume
    finally:
        mb.Dispose()


def is_conv(b):
    try:
        return bool(b.IsConvergentBody)
    except Exception:  # noqa: BLE001
        return False


try:
    if os.path.exists(DST):
        os.remove(DST)
    shutil.copyfile(SRC, DST)
    part = nxh.open_part(DST)
    cand = [b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)]
    body = max(cand, key=lambda b: fvol(part, b))
    res["features_before"] = len(list(part.Features))
    res["errors_before"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    v0 = fvol(part, body)
    D = nxh.Datums(part)
    # probes before: excess material in the corner, and points that must stay (post, outer wall, end face outer part)
    probes = {"excess_R": (58.5, -273.5, -20.0), "excess_L": (-58.5, -273.5, -20.0),
              "post_R": (61.1, -266.9, -20.0), "wall_R": (69.0, -271.2, -10.0), "end_bottom": (0.0, -275.0, -85.0)}
    res["probes_before"] = {k: nxh.dist_to(part, body, p) for k, p in probes.items()}

    _, pl = nxh.datum_plane(part, (0, 0, Z_TOP), (0, 0, 1), name="END_CORNER_RELIEF_PLANE")
    sk = nxf.new_sketch(part, pl, D.x, nxh.point(part, 0, 0, Z_TOP), name="END_CORNER_RELIEF_SKETCH")
    for sgn in (1, -1):
        pts = [(sgn * x, y, Z_TOP) for x, y in TRI_R]
        nxf.add(sk, *nxh.polyline(part, pts), infer=True)
    st = nxf.finish_sketch(sk)
    sec = nxh.section_feature(part, [sk.Feature])
    f = nxf.extrude_ex(part, sec, (0, 0, -1), start=0, end=Z_TOP - Z_BOT, op=BOOL.Subtract, target=body)
    f.SetName("END_CORNER_RELIEF")
    v1 = fvol(part, body)
    log(f"sketch {st['status']} dof {st['dof']} n_geom {st['n_geom']}; removed {v0 - v1:.1f} mm3")
    res["removed"] = v0 - v1

    # END_FACE_INNER_CHAMFER: the scan's end face is a narrow band, its inner edge bevelled over the last 2-3 mm
    ends = []
    for fc in body.GetFaces():
        bb = nxh.bbox(fc)
        if bb[4] - bb[1] < 0.05 and bb[1] < -274.0 and bb[3] - bb[0] > 5.0:
            ends.append(fc)
    log(f"end faces: {[[round(x, 1) for x in nxh.bbox(fc)] for fc in ends]}")
    inner = []
    end_tags = {fc.Tag for fc in ends}
    for fc in ends:
        for e in fc.GetEdges():
            pts = nxh.edge_points(e, n=5)
            m = pts[2]
            if sum(abs(pts[0][i] - pts[-1][i]) for i in range(3)) + abs(m[0] - pts[0][0]) < 0.5:
                continue
            others = [g for g in e.GetFaces() if g.Tag not in end_tags]
            if not others:
                continue
            nn = nxh.normal_at(others[0], m)
            radial = (m[0], 0.0, m[2] + 40.0)          # from the U centre line (x 0, z -40) to the edge
            if nn[0] * radial[0] + nn[2] * radial[2] < 0:   # the other face looks into the U: inner edge
                inner.append(e)
    log(f"end face inner edges: {len(inner)}")
    res["chamfer"] = None
    n_err0 = len(nxh.feature_errors(part, recheck=False))

    def try_chamfer(edges, size):
        mk = nxh.mark("chamfer", False)
        try:
            fch = nxf.chamfer(part, edges, size)
        except Exception as ex:  # noqa: BLE001
            nxh.undo_to(mk)
            return None, str(ex)[:100]
        if len(nxh.feature_errors(part, recheck=False)) > n_err0:     # committed with a warning: partial chamfer
            nxh.undo_to(mk)
            return None, "feature warning"
        return fch, ""

    for size in (2.5, 2.0):
        good = []
        for e in inner:                     # edges that chamfer cleanly on their own
            fch, why = try_chamfer([e], size)
            if fch is not None:
                nxh.undo_to(nxh.mark("x", False)) if False else None
                nxh.S.UpdateManager.AddObjectsToDeleteList([fch]); nxh.S.UpdateManager.DoUpdate(nxh.mark("del", False))
                good.append(e)
            else:
                log(f"chamfer {size}: edge at {[round(c, 1) for c in nxh.edge_points(e, n=3)[1]]} refused ({why})")
        # keep the chamfer symmetric: drop an edge whose mirror image (x -> -x) was refused
        bad_mid = [nxh.edge_points(e, n=3)[1] for e in inner if e not in good]
        good = [e for e in good if not any(abs(nxh.edge_points(e, n=3)[1][0] + q[0]) < 0.3 and
                                           abs(nxh.edge_points(e, n=3)[1][1] - q[1]) < 0.3 and
                                           abs(nxh.edge_points(e, n=3)[1][2] - q[2]) < 0.3 for q in bad_mid)]
        if not good:
            continue
        fch, why = try_chamfer(good, size)
        if fch is not None:
            fch.SetName("END_FACE_INNER_CHAMFER")
            res["chamfer"] = size
            res["chamfer_edges"] = f"{len(good)} of {len(inner)}"
            break
        log(f"chamfer {size} on {len(good)} edges refused ({why})")
    v2 = fvol(part, body)
    res["chamfer_removed"] = v1 - v2
    log(f"chamfer {res['chamfer']}: removed {v1 - v2:.1f} mm3")
    res["probes_after"] = {k: nxh.dist_to(part, body, p) for k, p in probes.items()}
    res["solids_after"] = len([b for b in part.Bodies if b.IsSolidBody and not b.IsBlanked and not is_conv(b)])
    res["bbox"] = [round(x, 3) for x in nxh.bbox(body)]
    res["body_ok"] = nxh.body_ok(part, body)
    try:
        res["examine"] = nxh.examine_geometry(part, body)
    except Exception as e:  # noqa: BLE001
        res["examine_err"] = str(e)
    res["features_after"] = len(list(part.Features))
    res["errors_after"] = [str(e) for e in nxh.feature_errors(part, recheck=False)]
    res["new_features"] = [g.GetFeatureName() + " / " + g.Name for g in list(part.Features)[res["features_before"]:]]
    nxh.save(part)
    res["size"] = os.path.getsize(DST)
    res["stl"] = nxre.stl_export(part, body, os.path.join(OUT, "chest_R2.stl"), chord=0.01, max_edge=2.5)
    ok = res["body_ok"] and res["solids_after"] == 1 and len(res["errors_after"]) <= len(res["errors_before"])
    res["result"] = "PASS" if ok else "CHECK"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.splitext(DST)[0] + "_end.json", res)
