# CH-001 Chest - front shell: reverse-engineering report

Source: `share-Chest.stl` (14,776,735 triangles, 3D-scan mesh; one main shell of 14,733,629 faces plus 2,118 scan crumbs, the largest 77 mm2, ignored).
Native CAD: Siemens NX 2206, solid body `CHEST`, rebuilt feature by feature on the scan (not a mesh conversion): right half modelled, mirrored about the mid-plane datum, one-sided features added after the mirror.

## Part data

- Volume 593,405 mm3, mass 1.602 kg in Al 6061 (2.70 g/cm3).
- Bounding box (model frame, exact from the CAD tessellation) [-166.889, -275.6, -140.127, 166.889, 115.43, 2.5].
- Model frame: origin on the mid-plane, on the rim (parting) plane, at the height of the two shoulder-bore centres;
  +Z = rim-plane normal toward the open back; +X = mid-plane normal; +Y = up (toward the neck).

## Symmetry of the scan

Scan reflected about its best mirror plane and fitted onto itself: residual p50 0.090, p90 0.359 mm, 84.7 % within 0.2 mm, 92.8 % within 0.5 mm. Above that: the lower side panels (warp, about +-0.4 mm) and the one-sided features. The CAD is symmetric (design intent), so that warp shows below as an equal split left/right.

## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)

| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |
|---|---|---|---|---|---|---|---|
| whole part | 3,000,000 | +0.334 | 0.108 | 1.427 | 2.108 | 62.2 % | 74.4 % |
| exterior freeform skin | 1,065,333 | -0.009 | 0.064 | 0.371 | 0.598 | 82.8 % | 93.1 % |
|   exterior, right half (x > 0) | 543,000 | +0.063 | 0.060 | 0.335 | 0.543 | 83.4 % | 94.2 % |
|   exterior, left half (x < 0) | 522,333 | -0.084 | 0.067 | 0.421 | 0.645 | 82.2 % | 91.9 % |
| shoulder flanges (|x| > 145) | 134,219 | +0.023 | 0.084 | 0.745 | 0.881 | 66.2 % | 79.3 % |
| rim band (z > -6) | 121,094 | +0.234 | 0.190 | 1.509 | 1.849 | 51.0 % | 70.5 % |
| interior (wall, ribs, bosses, clips, panel) | 1,679,354 | +0.584 | 0.206 | 1.966 | 2.827 | 49.6 % | 62.5 % |

CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 0.116, p90 1.671, p95 2.334 mm.

Against the first build of this part (same scan, same zones, within 0.5 mm): whole part 74.4 % (first build 71.8 %),
exterior skin 93.1 % (92.9 %), shoulder flanges 79.3 % (80.8 %), rim band 70.5 % (57.3 %), interior 62.5 % (58.7 %).

## How the part is modelled

Design-intent features only, as the part would have been designed: the wall is one constant 3.25 mm Shell of the
fitted exterior skin (shoulder flanges 4.35, front panel plate 2.70, recessed disc 1.95). Every interior feature is
a plain design feature with round values: ribs of constant 1.5 mm thickness with flat tops and square ends (at least 1 mm tall), cylindrical bosses with
holes, drafted cones for the tall bosses and side tubes, gussets and hooks with plane tops, blocks for the tabs,
latch and rim bands, three exterior pockets with a constant 3.25 mm wall behind them (upper vent box, shoulder
vents, lower vent) and the vent slots as Pattern Features (8 per shoulder, 15 lower). No profile is traced from the
scan and the inside has no stepped pads. The values were measured on the scan (rib centre lines, flat tops, boss
diameters, pocket floors) and rounded; the deviation below is the result of that choice, not a target.

## Where the remaining deviation is

- Features left out on purpose (README simplifications): the dummy PCB board relief (largest single cluster, about
  32 600 mm2), the side-scoop rails, the window-frame lips of the lower side walls, the neck-channel floor steps,
  logo and marks.
- Root fillets and edge rounds and the draft of ribs and bosses (the CAD ribs are 1.5 mm straight walls; the
  print's ribs widen toward their roots): the thin + bands along rib and boss roots.
- Deep narrow bores: the scanner closes them, so the scan shows material inside the CAD bores (not a CAD error).
- Lower side panels: print warp (left side in, right side out, about 0.75 mm) against the symmetric CAD.
- Exterior skin outline: at the bottom corners (x +-68, y -273), at the shoulder top corners (x +-138, y 83) and on
  one right-side flare (x 108, y -226) the skin lies 2-7 mm inside the print's outer face (seen as small "openings"
  in a view along Z). These are skin-outline differences of the base skin, not holes through a wall.

## STEP check (independent, OpenCascade, `stepcheck.py`)

- `CH-001_Chest_AP214.step`: 1 solid, 765 faces, valid True, volume 592,460 mm3 (-0.16 % against NX).
- `CH-001_Chest_AP242.step`: 1 solid, 765 faces, valid True, volume 592,570 mm3 (-0.14 % against NX).
- The NX tessellation of the same solid (`CH-001_Chest.stl`) gives 593,364 mm3, -0.007 % from NX.

Maps: `deviation_map_*.png` (scan coloured by its distance to the CAD, +-0.5 mm scale).