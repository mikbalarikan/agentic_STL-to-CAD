"""outC10 gates on a review data dir (bash run_c10.sh <tag> first).  usage: gate_c10.py data_<tag>
- zones (scan -> CAD within 0.5, all vertices) vs outC8: whole 87.8, rim 86.2, interior 83.3, skin 96.2
- CAD Z-through openings with no scan opening (census cad_open with scan None, area >= 2 mm2)
- r8_thin: CAD thin clusters > 5 mm2 where the scan wall >= 1.2 mm"""
import os, sys, json
D = sys.argv[1]
r1 = json.load(open(os.path.join(D, "r1_dev.json")))
z = r1["scan_to_cad_vertices"]
ref = {"all": 0.8784, "rim": 0.8624, "interior": 0.8327, "outer_skin": 0.9622}     # outC8 exact
print("zones:", {k: (v.get("within_0p5"), v.get("p50")) for k, v in z.items() if isinstance(v, dict)})
ok = True
for k, lim in ref.items():
    key = [k] if k in z else []
    if key:
        w = z[key[0]]["within_0p5"]; good = w >= lim - 1e-4; ok &= good
        print(f"  {k:9s} {100 * w:6.2f} % (outC8 {100 * lim:.1f})  {'OK' if good else 'WORSE'}")
c = json.load(open(os.path.join(D, "census.json")))
extra = [o for o in c["cad_open"] if o.get("scan") is None and o["area"] >= 2.0]
print(f"CAD Z-openings without a scan opening (>= 2 mm2): {len(extra)}")
for o in extra:
    print("   ", o["ctr"], o["area"], "len", o["len"], "wid", o["wid"])
miss = [o for o in c["scan_open"] if o.get("cad") is None and o["area"] >= 2.0]
print(f"scan Z-openings missing in the CAD (>= 2 mm2): {len(miss)}", [(o["ctr"], o["area"]) for o in miss])
t = json.load(open(os.path.join(D, "thin.json")))
big = [q for q in t["thin"] if q["area"] > 5.0 and q.get("t_scan_med", 0) >= 1.2]
print(f"thin CAD clusters > 5 mm2 where the scan wall >= 1.2: {len(big)} (all {len(t['thin'])}), stray shells {len(t['stray_shells'])}")
for q in sorted(big, key=lambda q: -q["area"])[:25]:
    print("   ", q["area"], [round(v, 1) for v in q["ctr"]], "t_scan", q["t_scan_med"])
print("GATES", "zones OK" if ok else "zones WORSE", "| openings", len(extra), "| thin", len(big))
