"""Diff maps per view from data/maps.npz.  miss = how far the scan surface stands in FRONT of the CAD surface along the
view ray (+ = scan has material the CAD lacks, red; - = CAD extra, blue). Green = scan open / CAD closed (CAD blocks an
opening); magenta = CAD open / scan closed (CAD has a hole the scan lacks or misses material).
usage: r4_diffmaps.py [view] [x0 x1 y0 y1 name] -> data/diff_<view>[_name].png"""
import os, sys
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from rc import D
M = np.load(os.path.join(D, "maps.npz"))
SG = {"ZI": -1, "ZE": 1, "XR": 1, "XL": -1, "XRE": -1, "XLE": 1}
xs, ys, zs = M["xs"], M["ys"], M["zs"]


def diff(vw):
    s, c = M["scan_" + vw], M["cad_" + vw]
    d = SG[vw] * (c - s)
    return d, s, c


def plot(vw, win=None, name=""):
    d, s, c = diff(vw)
    a = xs if vw.startswith("Z") else zs
    ext = [a[0], a[-1], ys[0], ys[-1]]
    if win:
        j0, j1 = np.searchsorted(a, win[0]), np.searchsorted(a, win[1]); i0, i1 = np.searchsorted(ys, win[2]), np.searchsorted(ys, win[3])
        d, s, c = d[i0:i1, j0:j1], s[i0:i1, j0:j1], c[i0:i1, j0:j1]; ext = [a[j0], a[j1 - 1], ys[i0], ys[i1 - 1]]
    rgb = plt.get_cmap("seismic")((np.clip(np.nan_to_num(d), -2, 2) + 2) / 4)[..., :3]
    rgb[np.isnan(s) & np.isnan(c)] = 1
    rgb[np.isnan(s) & ~np.isnan(c)] = (0, 0.75, 0)
    rgb[~np.isnan(s) & np.isnan(c)] = (0.9, 0, 0.9)
    W_ = (ext[1] - ext[0]); H_ = (ext[3] - ext[2])
    sc = 26 / max(W_, H_) if not win else 18 / max(W_, H_)
    fig, ax = plt.subplots(1, 2 if win else 1, figsize=((2 if win else 1) * W_ * sc + 1, H_ * sc + 1), squeeze=False)
    ax[0][0].imshow(rgb, origin="lower", extent=ext, interpolation="nearest")
    ax[0][0].set_title(f"{vw} {name}: red = scan material CAD lacks, blue = CAD extra (+-2 mm); green = CAD blocks a scan opening; magenta = CAD open, scan closed", fontsize=8)
    if win:
        im = ax[0][1].imshow(s, origin="lower", extent=ext, cmap="nipy_spectral", interpolation="nearest")
        plt.colorbar(im, ax=ax[0][1], shrink=0.7); ax[0][1].set_title("scan hit coordinate", fontsize=8)
    g = 10 if max(W_, H_) > 120 else 5
    for a_ in ax[0]:
        a_.set_xticks(np.arange(np.ceil(ext[0] / g) * g, ext[1], g)); a_.set_yticks(np.arange(np.ceil(ext[2] / g) * g, ext[3], g))
        a_.tick_params(labelsize=6); a_.grid(lw=0.3, color="k", alpha=0.3)
        a_.set_xlabel("x" if vw.startswith("Z") else "z", fontsize=7); a_.set_ylabel("y", fontsize=7)
        if vw.startswith("X"): a_.invert_xaxis() if vw in ("XR", "XLE") else None
    fig.tight_layout(); fig.savefig(os.path.join(D, f"diff_{vw}{'_' + name if name else ''}.png"), dpi=60); plt.close(fig)


if __name__ == "__main__":
    if len(sys.argv) > 2:
        plot(sys.argv[1], [float(t) for t in sys.argv[2:6]], sys.argv[6])
    else:
        for vw in (sys.argv[1:] or SG):
            plot(vw)
    print("ok")
