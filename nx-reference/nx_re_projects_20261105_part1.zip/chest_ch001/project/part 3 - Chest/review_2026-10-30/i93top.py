"""Top-side depth map (max z seen from +Z), scan (lifted) vs CAD STL. usage: i93top.py cad.stl tag -> work/depthtop_<tag>.npz
Stored with the same keys as i93 (zs, zc, diff) but as NEGATED heights (-max z), so the open-side tools (hf_tool,
i99_autofix) work unchanged: 'add' there = CAD top too LOW, 'cut' = CAD top too HIGH (material above the scan)."""
import sys, os, json
import numpy as np
import open3d as o3d
from common import W
stl, tag = sys.argv[1], sys.argv[2]
DZ = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))["seat_dz"]
d = np.load(W + r"\hmap2.npz"); L = d["L"]; X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
ny, nx = L.shape
cm = o3d.io.read_triangle_mesh(stl)
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
xs = X0 + (np.arange(nx) + 0.5) * C; ys = Y0 + (np.arange(ny) + 0.5) * C
XX, YY = np.meshgrid(xs, ys)
rays = np.zeros((ny * nx, 6), np.float32); rays[:, 0] = XX.ravel(); rays[:, 1] = YY.ravel(); rays[:, 2] = 200.0; rays[:, 5] = -1.0
t = sc.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
ztc = np.where(np.isfinite(t), 200.0 - t, np.nan).reshape(ny, nx)
zts = np.where(np.isfinite(L), -L + DZ, np.nan)
np.savez_compressed(W + rf"\depth_top_{tag}.npz", zs=-zts, zc=-ztc, diff=(-ztc) - (-zts), ext=d["ext"], cell=C)
dd = (ztc - zts)[np.isfinite(ztc) & np.isfinite(zts)]
print("top: CAD above scan > 0.3: %.2f %%, below > 0.3: %.2f %%" % (100 * (dd > 0.3).mean(), 100 * (dd < -0.3).mean()))
