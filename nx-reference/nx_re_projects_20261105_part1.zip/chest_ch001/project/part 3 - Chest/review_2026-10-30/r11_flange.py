"""Shoulder flange faces (actuator seats): signed scan->CAD deviation of scan vertices on the outer flange face
(|x| > 155, vertex normal ~ +-x, within 6 mm of the datum plane), per side; plus the inner face of the flange."""
import os, json
import numpy as np
from rc import D, load, W
v, f = load()
dv = np.load(os.path.join(D, "r1_dvert.npy"))
a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
fn = np.cross(b - a, c - a); del a, b, c
vn = np.zeros_like(v)
for k in range(3):
    np.add.at(vn, f[:, k], fn)
vn /= np.maximum(np.linalg.norm(vn, axis=1), 1e-12)[:, None]
DT = json.load(open(os.path.join(W, "datums.json")))
out = {}
for side, key in (("R", "shoulder_R"), ("L", "shoulder_L")):
    n = np.array(DT[key]["normal"]); p0 = np.array(DT[key]["plane_pt"])
    if side == "L" and n[0] > 0:
        n = -n
    if side == "R" and n[0] < 0:
        n = -n
    s = (v - p0) @ n
    r = np.hypot(*(v - np.array(DT[key]["hole_centre"]))[:, 1:].T)
    for face, sel in (("outer", (np.abs(s) < 1.0) & (vn @ n > 0.95)), ("inner", (s < -2) & (s > -8) & (vn @ n < -0.95))):
        m = sel & (r > 56) & (r < 66)
        d = dv[m]
        out[f"{side}_{face}"] = dict(n=int(m.sum()), median=round(float(np.median(d)), 3), p10=round(float(np.percentile(d, 10)), 3),
                                     p90=round(float(np.percentile(d, 90)), 3), plane_offset_med=round(float(np.median(s[m])), 3))
print(json.dumps(out, indent=1))
json.dump(out, open(os.path.join(D, "flange.json"), "w"), indent=1)
