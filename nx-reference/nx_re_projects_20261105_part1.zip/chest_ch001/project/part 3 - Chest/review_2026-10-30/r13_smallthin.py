"""Top-10 thin clusters (LO..HI mm2, scan wall >= 1.2) of a gate run as filled sections (r9_secfill), plane
normal to the cluster's longest plan extent.  usage: r13_smallthin.py data_<tag> <name> [lo hi]  -> secs/<name>_a.png, _b.png"""
import os, sys, json, subprocess
D, name = sys.argv[1], sys.argv[2]
LO, HI = (float(sys.argv[3]), float(sys.argv[4])) if len(sys.argv) > 4 else (5.0, 20.0)
t = json.load(open(os.path.join(D, "thin.json")))["thin"]
q = sorted([c for c in t if LO <= c["area"] < HI and c.get("t_scan_med", 0) >= 1.2], key=lambda c: -c["area"])[:10]
here = os.path.dirname(os.path.abspath(__file__))
for part, sel in (("a", q[:5]), ("b", q[5:])):
    args = []
    for c in sel:
        ext = [c["hi"][k] - c["lo"][k] for k in range(3)]
        ax = 0 if ext[0] >= ext[1] else 1
        oth = [k for k in range(3) if k != ax]
        args += ["xyz"[ax], f"{c['ctr'][ax]:.2f}", f"{c['ctr'][oth[0]]:.2f}", f"{c['ctr'][oth[1]]:.2f}", "6"]
        print(part, c["area"], c["ctr"], "t_scan", c["t_scan_med"], "t_cad_min", c["t_cad_min"])
    if args:
        subprocess.run([sys.executable, os.path.join(here, "r9_secfill.py"), f"{name}_{part}"] + args, check=True)
