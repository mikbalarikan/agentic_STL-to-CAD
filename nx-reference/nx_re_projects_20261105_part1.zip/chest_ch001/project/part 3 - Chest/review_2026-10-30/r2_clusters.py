"""Two-way signed deviation clusters from r1 outputs (full-res scan triangles + 3 M CAD samples).
missing (+): scan triangles outside the CAD by > THR, and CAD samples inside the scan material by > THR.
extra   (-): scan triangles inside the CAD by > THR, and CAD samples outside the scan by > THR.
0.8 mm voxels; cores (|d| > 1.0) 26-connected and grown by REACH 2.4 mm (binary dilation); thr voxels inside a grown
core take its label; the rest (shallow) are labelled on their own. Per cluster: area (scan / CAD side), peak (p99), p90,
mean d, centroid, bbox, PCA extents, mean view normal, zone mix, side (R/L/C), volume estimate = area * mean |d|.
usage: r2_clusters.py [thr=0.3] [min_area=3]  -> data/clusters.json, data/clusters_pts.npz"""
import os, sys, json, time
import numpy as np
from scipy import ndimage
from rc import D, load
from zones import zone_labels
THR = float(sys.argv[1]) if len(sys.argv) > 1 else 0.3
AMIN = float(sys.argv[2]) if len(sys.argv) > 2 else 3.0
t0 = time.time(); lg = lambda *a: print(f"[{time.time()-t0:6.0f}s]", *a, flush=True)
v, f = load()
dt = np.load(os.path.join(D, "r1_dtri.npy")); at = np.load(os.path.join(D, "r1_atri.npy"))
sel = np.abs(dt) > THR
fi = np.flatnonzero(sel)
a, b, c = v[f[fi, 0]], v[f[fi, 1]], v[f[fi, 2]]
cen = ((a + b + c) / 3).astype(np.float32); n = np.cross(b - a, c - a); n /= np.maximum(np.linalg.norm(n, axis=1), 1e-12)[:, None]
ds, ar, ns = dt[fi], at[fi], n.astype(np.float32)
del a, b, c, n, dt, at
Q = np.load(os.path.join(D, "r1_cadpts.npy"))
cad_area = json.load(open(os.path.join(D, "r1_dev.json")))["cad_area"]; aq = cad_area / len(Q)
qs = np.abs(Q[:, 6]) > THR
Qp, Qn, dq = Q[qs, :3], Q[qs, 3:6], Q[qs, 6]
lg("points", len(cen), len(Qp))
VOX, CORE, REACH = 0.8, 1.0, 2.4
lo = np.array([-172.0, -280.0, -146.0]); hi = np.array([172.0, 120.0, 8.0])
shape = tuple(np.ceil((hi - lo) / VOX).astype(int))
vox = lambda p: np.clip(np.floor((p - lo) / VOX).astype(int), 0, np.array(shape) - 1)
out = {"thr": THR, "min_area": AMIN, "vox": VOX, "core": CORE, "reach": REACH, "clusters": []}
allpts = {}
for sign, ms_, mq_ in (("missing", ds > 0, dq < 0), ("extra", ds < 0, dq > 0)):
    ps, pq = cen[ms_], Qp[mq_]; dsa, dqa = np.abs(ds[ms_]), np.abs(dq[mq_])
    g = np.zeros(shape, bool); gc = np.zeros(shape, bool)
    for p, d_ in ((ps, dsa), (pq, dqa)):
        iv = vox(p); g[tuple(iv.T)] = True; gc[tuple(vox(p[d_ > CORE]).T)] = True
    lc, nc = ndimage.label(gc, structure=np.ones((3, 3, 3)))
    it = int(round(REACH / VOX))
    grown = ndimage.grey_dilation(lc, footprint=np.ones((3, 3, 3)), mode="constant") if False else None
    lab = lc.copy()
    for _ in range(it):                       # grow labels into thr voxels only
        dil = ndimage.maximum_filter(lab, size=3, mode="constant")
        m = (lab == 0) & g & (dil > 0)
        lab[m] = dil[m]
    rest = g & (lab == 0)
    lr, nr = ndimage.label(rest, structure=np.ones((3, 3, 3)))
    lab[rest] = lr[rest] + nc
    nl = nc + nr
    ls, lq = lab[tuple(vox(ps).T)], lab[tuple(vox(pq).T)]
    a_s = np.bincount(ls, weights=ar[ms_], minlength=nl + 1); a_q = np.bincount(lq, minlength=nl + 1) * aq
    keep = [k for k in range(1, nl + 1) if max(a_s[k], a_q[k]) >= AMIN]
    nsel, qnsel, arsel = ns[ms_], Qn[mq_], ar[ms_]
    order_s = np.argsort(ls); bs = np.searchsorted(ls[order_s], np.arange(nl + 2))
    order_q = np.argsort(lq); bq = np.searchsorted(lq[order_q], np.arange(nl + 2))
    for k in keep:
        is_ = order_s[bs[k]:bs[k + 1]]; iq = order_q[bq[k]:bq[k + 1]]
        pts = np.vstack([ps[is_], pq[iq]]).astype(float); dd = np.concatenate([dsa[is_], dqa[iq]])
        ctr = pts.mean(0)
        ev = np.sort(np.linalg.eigvalsh(np.cov((pts - ctr).T))) if len(pts) > 3 else np.zeros(3)
        nv = np.vstack([nsel[is_], qnsel[iq]]).mean(0)
        sub = pts[np.random.default_rng(0).choice(len(pts), min(len(pts), 3000), replace=False)]
        zl = np.bincount(zone_labels(sub), minlength=4) / len(sub)
        xr = (pts[:, 0] > 2).mean(); xl = (pts[:, 0] < -2).mean()
        side = "C" if (xr < 0.8 and xl < 0.8) else ("R" if xr >= 0.8 else "L")
        area = float(max(a_s[k], a_q[k]))
        meand = float(np.average(dsa[is_], weights=arsel[is_])) if len(is_) else float(dqa[iq].mean())
        out["clusters"].append(dict(sign=sign, core=bool(k <= nc), area_scan=round(float(a_s[k]), 1), area_cad=round(float(a_q[k]), 1),
                                    area=round(area, 1), peak=round(float(np.percentile(dd, 99)), 2), p90=round(float(np.percentile(dd, 90)), 2),
                                    mean=round(meand, 2), vol=round(area * meand, 1), ctr=ctr.round(1).tolist(),
                                    lo=pts.min(0).round(1).tolist(), hi=pts.max(0).round(1).tolist(),
                                    ext=(4 * np.sqrt(np.maximum(ev, 0))).round(1).tolist(), n_view=np.round(nv, 2).tolist(),
                                    zone=dict(skin=round(zl[0], 2), shoulder=round(zl[1], 2), rim=round(zl[2], 2), interior=round(zl[3], 2)),
                                    side=side, n_s=int(len(is_)), n_q=int(len(iq))))
        allpts[f"k{len(out['clusters']) - 1}"] = np.c_[pts, dd].astype(np.float32)
    lg(sign, "labels", nl, "kept", len(keep))
for i, c_ in enumerate(out["clusters"]):
    c_["key"] = f"k{i}"
out["clusters"].sort(key=lambda c_: -c_["vol"])
for i, c_ in enumerate(out["clusters"]):
    c_["id"] = i
json.dump(out, open(os.path.join(D, "clusters.json"), "w"), indent=1)
np.savez_compressed(os.path.join(D, "clusters_pts.npz"), **allpts)
for s in ("missing", "extra"):
    cl = [c_ for c_ in out["clusters"] if c_["sign"] == s]
    print(s, len(cl), "area", round(sum(c_["area"] for c_ in cl)), "vol", round(sum(c_["vol"] for c_ in cl)))
for c_ in out["clusters"][:120]:
    print(c_["id"], c_["sign"][:4], c_["side"], "C" if c_["core"] else "s", c_["area"], c_["peak"], c_["mean"], c_["vol"], c_["ctr"], c_["ext"], c_["zone"])
lg("done")
