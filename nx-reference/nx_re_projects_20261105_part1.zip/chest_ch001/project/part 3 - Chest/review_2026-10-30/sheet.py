"""Contact sheets of crops: sheet.py <out_prefix> <scale> <files...> -> 4 crops per sheet (2x2), jpg"""
import sys, os
from PIL import Image
pre, sc, files = sys.argv[1], float(sys.argv[2]), sys.argv[3:]
os.makedirs(os.path.dirname(pre), exist_ok=True)
for s in range(0, len(files), 4):
    ims = [Image.open(p).convert("RGB") for p in files[s:s + 4]]
    w, h = int(ims[0].width * sc), int(ims[0].height * sc)
    sh = Image.new("RGB", (2 * w + 6, 2 * h + 6), "black")
    for k, im in enumerate(ims):
        sh.paste(im.resize((w, h), Image.LANCZOS), ((k % 2) * (w + 6), (k // 2) * (h + 6)))
    sh.save(f"{pre}_{s // 4:02d}.jpg", quality=82)
print("ok")
