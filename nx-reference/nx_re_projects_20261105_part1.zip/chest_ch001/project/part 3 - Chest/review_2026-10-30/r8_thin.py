"""Knife edges, fins and spikes in the CAD: local wall thickness along the inward normal (ray cast inside the solid)
for 1.5 M CAD surface samples, the same for 1.5 M scan vertices; CAD spots thinner than 0.6 mm where the scan wall at
the same place is >= 1.2 mm are slivers / spikes / fins the scan does not have. Also lists the stray STL shells.
Writes data/thin.json"""
import os, json
import numpy as np, open3d as o3d, trimesh
from scipy import ndimage
from rc import CAD, D, load, read_stl, weld
T = read_stl(CAD); cv, cf = weld(T)
m = trimesh.Trimesh(cv, cf, process=False)
stray = [dict(tris=len(c.faces), area=round(float(c.area), 3), ctr=c.bounds.mean(0).round(2).tolist()) for c in m.split(only_watertight=False) if len(c.faces) < 1000]
cm = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(cv), o3d.utility.Vector3iVector(cf)); cm.compute_triangle_normals()
cs = o3d.t.geometry.RaycastingScene(); cs.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
pc = cm.sample_points_uniformly(1500000, use_triangle_normal=True)
Q = np.asarray(pc.points, np.float32); N = np.asarray(pc.normals, np.float32)
rays = np.c_[Q - N * 0.005, -N].astype(np.float32)
tc = cs.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
# scan thickness at the closest scan point: tile-free nearest vertex via KD tree, scan thickness by ray in the full scan (y tiles)
v, f = load()
from scipy.spatial import cKDTree
a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
fn = np.cross(b - a, c - a); fn /= np.maximum(np.linalg.norm(fn, axis=1), 1e-12)[:, None]
vn = np.zeros_like(v)
for k in range(3):
    np.add.at(vn, f[:, k], fn)
vn /= np.maximum(np.linalg.norm(vn, axis=1), 1e-12)[:, None]
del a, b, c, fn
kd = cKDTree(v)
dd, ii = kd.query(Q, workers=-1)
ts = np.full(len(Q), np.nan, np.float32)
cy = v[f, 1]; ymin, ymax = cy.min(1), cy.max(1); del cy
edges = np.linspace(v[:, 1].min() - 1, v[:, 1].max() + 1, 9)
P0 = v[ii]; NN = vn[ii]
for k in range(8):
    qm = (P0[:, 1] >= edges[k]) & (P0[:, 1] < edges[k + 1])
    tm = (ymax >= edges[k] - 25) & (ymin <= edges[k + 1] + 25)
    used, inv = np.unique(f[tm], return_inverse=True)
    sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.core.Tensor(v[used].astype(np.float32)), o3d.core.Tensor(inv.reshape(-1, 3).astype(np.uint32)))
    r = np.c_[P0[qm] - NN[qm] * 0.005, -NN[qm]].astype(np.float32)
    ts[qm] = sc.cast_rays(o3d.core.Tensor(r))["t_hit"].numpy()
    del sc
bad = (tc < 0.6) & (ts >= 1.2) & (dd < 3.0)
print("CAD samples", len(Q), "thin<0.6 where scan>=1.2:", int(bad.sum()), "area ~", round(bad.sum() * m.area / len(Q), 1), "mm2")
VOX = 1.0; lo = np.array([-172.0, -280.0, -146.0])
iv = np.floor((Q[bad] - lo) / VOX).astype(int)
shape = tuple(iv.max(0) + 2)
g = np.zeros(shape, bool); g[tuple(iv.T)] = True
lab, n = ndimage.label(g, structure=np.ones((3, 3, 3)))
lv = lab[tuple(iv.T)]
out = []
qa = m.area / len(Q)
for k in range(1, n + 1):
    mm = lv == k
    if mm.sum() * qa < 1.0:
        continue
    p = Q[bad][mm]
    out.append(dict(area=round(float(mm.sum() * qa), 1), ctr=p.mean(0).round(1).tolist(), lo=p.min(0).round(1).tolist(), hi=p.max(0).round(1).tolist(),
                    t_cad_min=round(float(tc[bad][mm].min()), 3), t_scan_med=round(float(np.median(ts[bad][mm])), 2)))
out.sort(key=lambda r: -r["area"])
json.dump(dict(stray_shells=stray, thin=out), open(os.path.join(D, "thin.json"), "w"), indent=1)
print("stray shells", len(stray)); [print(s) for s in stray]
print("thin clusters", len(out))
for r in out[:60]:
    print(r)
