"""Depth maps of scan and CAD along 6 view rays, 0.25 mm cells (full-res scan, y tiles with margin).
Views (ray origin plane -> direction):  ZI interior from the open side (z=+20, dir -Z, map = z of first hit)
ZE exterior from the front (z=-200, +Z)  XR right interior from the mid-plane (x=0, +X)  XL left interior (x=0, -X)
XRE right exterior (x=+220, -X)  XLE left exterior (x=-220, +X).  Map value = hit coordinate along the ray axis.
Writes data/maps.npz (scan_<V>, cad_<V>, grid info)."""
import os, json, time
import numpy as np, open3d as o3d
from rc import CAD, D, load, read_stl, weld
t0 = time.time(); lg = lambda *a: print(f"[{time.time()-t0:6.0f}s]", *a, flush=True)
C = 0.25
X0, X1, Y0, Y1, Z0, Z1 = -170.0, 170.0, -278.0, 117.0, -144.0, 6.0
xs = np.arange(X0, X1, C) + C / 2; ys = np.arange(Y0, Y1, C) + C / 2; zs = np.arange(Z0, Z1, C) + C / 2
VIEWS = {"ZI": (2, -1, 20.0), "ZE": (2, 1, -200.0), "XR": (0, 1, 0.0), "XL": (0, -1, 0.0), "XRE": (0, -1, 220.0), "XLE": (0, 1, -220.0)}


def rays_for(view, ysel):
    ax, sg, o = VIEWS[view]
    if ax == 2:
        A, B = np.meshgrid(xs, ysel, indexing="xy"); org = np.c_[A.ravel(), B.ravel(), np.full(A.size, o)]
    else:
        A, B = np.meshgrid(zs, ysel, indexing="xy"); org = np.c_[np.full(A.size, o), B.ravel(), A.ravel()]
    dr = np.zeros_like(org); dr[:, ax] = sg
    return np.c_[org, dr].astype(np.float32), A.shape


def cast(scene, view, ysel):
    r, shp = rays_for(view, ysel)
    t = scene.cast_rays(o3d.core.Tensor(r))["t_hit"].numpy()
    ax, sg, o = VIEWS[view]
    val = np.where(np.isfinite(t), o + sg * t, np.nan).astype(np.float32)
    if view in ("XR", "XL"):           # rays start on the mid-plane, ignore hits closer than 1 mm (mid-plane ribs stay)
        pass
    return val.reshape(shp)


out = {}
T = read_stl(CAD); cv, cf = weld(T); del T
cs = o3d.t.geometry.RaycastingScene(); cs.add_triangles(o3d.core.Tensor(cv.astype(np.float32)), o3d.core.Tensor(cf.astype(np.uint32)))
for vw in VIEWS:
    out["cad_" + vw] = cast(cs, vw, ys)
lg("cad maps")
v, f = load()
cy = v[f, 1]; ymin, ymax = cy.min(1), cy.max(1); del cy
edges = np.linspace(Y0, Y1, 9)
parts = {vw: [] for vw in VIEWS}
for k in range(8):
    tm = (ymax >= edges[k] - 0.5) & (ymin <= edges[k + 1] + 0.5)
    used, inv = np.unique(f[tm], return_inverse=True)
    sc = o3d.t.geometry.RaycastingScene()
    sc.add_triangles(o3d.core.Tensor(v[used].astype(np.float32)), o3d.core.Tensor(inv.reshape(-1, 3).astype(np.uint32)))
    ysel = ys[(ys >= edges[k]) & (ys < edges[k + 1])]
    for vw in VIEWS:
        parts[vw].append(cast(sc, vw, ysel))
    del sc; lg("tile", k)
for vw in VIEWS:
    out["scan_" + vw] = np.vstack(parts[vw])
np.savez_compressed(os.path.join(D, "maps.npz"), xs=xs, ys=ys, zs=zs, cell=C, **out)
lg("done")
