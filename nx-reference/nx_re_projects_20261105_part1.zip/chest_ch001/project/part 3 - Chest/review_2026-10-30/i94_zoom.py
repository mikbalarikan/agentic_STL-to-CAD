"""Zoom of work/depth_<tag>.npz: diff (CAD z - scan z) and scan z with its CAD z next to it.
usage: i94_zoom.py tag name x0 x1 y0 y1 [vmin vmax]"""
import sys
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
tag, nm = sys.argv[1], sys.argv[2]
a0, a1, b0, b1 = [float(t) for t in sys.argv[3:7]]
vmin, vmax = (float(sys.argv[7]), float(sys.argv[8])) if len(sys.argv) > 8 else (34, 100)
d = np.load(W + rf"\depth_{tag}.npz"); X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
i0, i1 = int((b0 - Y0) / C), int((b1 - Y0) / C); j0, j1 = int((a0 - X0) / C), int((a1 - X0) / C)
ext = [a0, a1, b0, b1]
fig, ax = plt.subplots(1, 3, figsize=(27, 9 * (b1 - b0) / (a1 - a0) + 1))
im = ax[0].imshow(np.clip(d["diff"][i0:i1, j0:j1], -3, 3), origin="lower", extent=ext, cmap="seismic", vmin=-3, vmax=3)
plt.colorbar(im, ax=ax[0], shrink=0.7); ax[0].set_title("CAD z - scan z: red = CAD missing, blue = CAD extra")
for k, key in ((1, "zs"), (2, "zc")):
    z = d[key][i0:i1, j0:j1]
    im = ax[k].imshow(z, origin="lower", extent=ext, cmap="nipy_spectral", vmin=vmin, vmax=vmax)
    plt.colorbar(im, ax=ax[k], shrink=0.7)
    lv = np.arange(np.floor(vmin), vmax, 2.0)
    ax[k].contour(np.linspace(a0, a1, z.shape[1]), np.linspace(b0, b1, z.shape[0]), np.nan_to_num(z, nan=200), levels=lv, colors="k", linewidths=0.3)
    ax[k].set_title(("scan" if key == "zs" else "CAD") + " z seen from the open side (contours every 2 mm)")
g = 5 if max(a1 - a0, b1 - b0) <= 80 else 10
for a in ax:
    a.set_xticks(np.arange(np.ceil(a0 / g) * g, a1 + 0.1, g)); a.set_yticks(np.arange(np.ceil(b0 / g) * g, b1 + 0.1, g))
    a.grid(lw=0.4, color="k", alpha=0.35); a.tick_params(labelsize=8)
fig.tight_layout(); fig.savefig(W + rf"\diag\zoom_{tag}_{nm}.png", dpi=60)
print("ok")
