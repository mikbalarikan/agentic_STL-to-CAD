"""Sanity: CAD STL watertight / volume / bbox / components; scan main shell in part frame vs raw STL + frame.json."""
import os, json, time
import numpy as np, trimesh
from rc import CAD, ROOT, W, D, read_stl, load
t0 = time.time()
T = read_stl(CAD)
m = trimesh.Trimesh(*__import__("rc").weld(T), process=False)
cc = m.split(only_watertight=False)
out = dict(cad=CAD, tris=len(T), watertight=bool(m.is_watertight), volume=float(m.volume), area=float(m.area),
           bbox=[m.bounds[0].round(3).tolist(), m.bounds[1].round(3).tolist()],
           components=[dict(tris=len(c.faces), vol=round(float(c.volume), 1), lo=c.bounds[0].round(1).tolist(), hi=c.bounds[1].round(1).tolist()) for c in cc[:10]])
print(json.dumps(out, indent=1), flush=True)
v, f = load()
out["scan_main"] = dict(verts=len(v), tris=len(f), lo=v.min(0).round(3).tolist(), hi=v.max(0).round(3).tolist())
# independent frame check: raw STL triangles -> frame.json -> must coincide with mainf vertices
fr = json.load(open(os.path.join(W, "frame.json"))); R = np.array(fr["R"]); o = np.array(fr["o"])
with open(os.path.join(ROOT, "share-Chest.stl"), "rb") as fh:
    fh.read(80); n = int(np.frombuffer(fh.read(4), np.uint32)[0])
    dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
    idx = np.sort(np.random.default_rng(3).choice(n, 20000, replace=False))
    raw = np.memmap(os.path.join(ROOT, "share-Chest.stl"), dt, "r", offset=84, shape=(n,))["v"][idx].reshape(-1, 3).astype(np.float64)
pr = (raw - o) @ R.T
from scipy.spatial import cKDTree
dd, _ = cKDTree(v).query(pr)
out["frame_check"] = dict(raw_tris=n, sample_pts=len(pr), p50=float(np.median(dd)), p99=float(np.percentile(dd, 99)),
                          frac_on_main=float((dd < 1e-2).mean()), R=fr["R"], o=fr["o"])
print(json.dumps(out["scan_main"]), json.dumps(out["frame_check"]), round(time.time() - t0), "s")
json.dump(out, open(os.path.join(D, "r0_check.json"), "w"), indent=1)
