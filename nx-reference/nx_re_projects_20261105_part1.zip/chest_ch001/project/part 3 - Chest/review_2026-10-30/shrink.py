"""Half-size copies of crops for triage: shrink.py <glob> -> crops/small/"""
import sys, os, glob
from PIL import Image
os.makedirs("crops/small", exist_ok=True)
for p in sorted(glob.glob(sys.argv[1])):
    im = Image.open(p); f = float(sys.argv[2]) if len(sys.argv) > 2 else 0.5
    im.resize((int(im.width * f), int(im.height * f)), Image.LANCZOS).convert("RGB").save(os.path.join("crops/small", os.path.basename(p).replace(".png", ".jpg")), quality=85)
print("ok")
