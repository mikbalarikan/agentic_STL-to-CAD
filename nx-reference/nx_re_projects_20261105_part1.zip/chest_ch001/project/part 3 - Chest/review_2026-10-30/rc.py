"""Review helpers: paths, scan loader (shared an/common.py), STL reader."""
import os, sys
import numpy as np
RV = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(RV)
sys.path.insert(0, os.path.join(ROOT, "an"))
from common import load, section, W  # noqa
CAD = os.environ.get("RV_CAD", os.path.join(RV, "cad", "CH-001_Chest.stl"))      # frozen copy of deliver/CAD (outC7)
D = os.environ.get("RV_DATA", os.path.join(RV, "data"))


def read_stl(p):
    with open(p, "rb") as fh:
        fh.read(80); n = int(np.frombuffer(fh.read(4), np.uint32)[0])
        dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
        return np.fromfile(fh, dt, n)["v"]


def weld(T, tol=1e-4):
    V = T.reshape(-1, 3)
    q = np.round(V / tol).astype(np.int64)
    u, first, inv = np.unique(q, axis=0, return_index=True, return_inverse=True)
    return V[first].astype(np.float64), inv.reshape(-1, 3).astype(np.int32)
