# CH-001 outC7: deviation clusters > 0.3 mm (two-way, full-res scan), ranked by volume = area x mean |d|

587 missing (scan has material the CAD lacks) and 494 extra clusters >= 3 mm2. Top 150 below.

| k | sign | side | zone | centre x, y, z (mm) | area mm2 | peak (p99) mm | mean mm | vol mm3 | crop |
|---|---|---|---|---|---|---|---|---|---|
| 0 | missing | R | interior | 88.3, -223.2, -29.3 | 12025.9 | 10.16 | 2.36 | 28360.1 | [png](crops/k000_missing.png) |
| 1 | missing | L | interior | -64.2, -254.7, -43.2 | 5866.8 | 6.53 | 2.06 | 12112.1 | [png](crops/k001_missing.png) |
| 2 | missing | R | interior | 88.6, 83.1, -23.3 | 2206.8 | 13.13 | 3.65 | 8054.4 | [png](crops/k002_missing.png) |
| 3 | missing | C | interior | 6.4, -214.3, -99.4 | 4035.9 | 6.16 | 1.53 | 6165.5 | [png](crops/k003_missing.png) |
| 4 | missing | R | skin | 105.6, -205.5, -42.4 | 6637.4 | 0.8 | 0.54 | 3607.8 | [png](crops/k004_missing.png) |
| 5 | missing | L | interior | -89.7, 83.0, -25.4 | 2688.4 | 3.23 | 1.13 | 3047.8 | [png](crops/k005_missing.png) |
| 6 | missing | C | interior | 6.3, -28.4, -130.4 | 3179.5 | 3.98 | 0.95 | 3017.2 | [png](crops/k006_missing.png) |
| 7 | missing | L | interior | -106.2, -211.8, -18.8 | 3989.5 | 2.5 | 0.67 | 2678.7 | [png](crops/k007_missing.png) |
| 8 | missing | R | interior | 121.9, -80.2, -67.9 | 791.2 | 9.89 | 3.04 | 2401.9 | [png](crops/k008_missing.png) |
| 9 | extra | L | interior | -17.4, -204.8, -107.5 | 1980.9 | 5.47 | 1.15 | 2279.7 | [png](crops/k009_extra.png) |
| 10 | extra | L | interior | -131.9, 73.4, -32.0 | 1636.2 | 2.64 | 1.37 | 2248.0 | [png](crops/k010_extra.png) |
| 11 | extra | R | interior | 16.8, -204.6, -107.9 | 1885.6 | 5.41 | 1.13 | 2122.7 | [png](crops/k011_extra.png) |
| 12 | extra | R | interior | 132.0, 73.5, -32.0 | 1529.6 | 2.56 | 1.35 | 2058.7 | [png](crops/k012_extra.png) |
| 13 | extra | L | skin | -101.2, -219.8, -36.3 | 3991.1 | 0.85 | 0.48 | 1933.4 | [png](crops/k013_extra.png) |
| 14 | missing | L | interior | -127.8, -145.3, -10.4 | 1812.5 | 2.96 | 1.04 | 1894.0 | [png](crops/k014_missing.png) |
| 15 | extra | L | interior | -102.6, 72.4, -46.9 | 2379.0 | 5.76 | 0.72 | 1717.7 | [png](crops/k015_extra.png) |
| 16 | extra | R | interior | 102.1, 72.4, -46.9 | 2319.7 | 5.72 | 0.72 | 1675.3 | [png](crops/k016_extra.png) |
| 17 | missing | R | interior | 146.9, 62.2, -19.6 | 749.3 | 4.52 | 2.11 | 1577.8 | [png](crops/k017_missing.png) |
| 18 | missing | L | interior | -21.6, -233.2, -84.7 | 259.7 | 10.15 | 5.73 | 1487.4 | [png](crops/k018_missing.png) |
| 19 | missing | R | interior | 156.7, -63.0, -18.1 | 782.4 | 4.54 | 1.88 | 1474.0 | [png](crops/k019_missing.png) |
| 20 | missing | L | interior | -156.7, -63.2, -17.5 | 724.3 | 4.41 | 1.93 | 1397.2 | [png](crops/k020_missing.png) |
| 21 | extra | L | interior | -126.1, -167.1, -11.6 | 1585.7 | 1.4 | 0.77 | 1217.5 | [png](crops/k021_extra.png) |
| 22 | missing | C | interior | 1.7, -266.6, -83.7 | 1475.3 | 3.21 | 0.76 | 1126.4 | [png](crops/k022_missing.png) |
| 23 | extra | L | interior | -59.2, -271.5, -40.4 | 1101.1 | 6.06 | 0.94 | 1038.7 | [png](crops/k023_extra.png) |
| 24 | missing | L | interior | -149.5, 63.3, -19.3 | 326.8 | 4.72 | 3.12 | 1021.3 | [png](crops/k024_missing.png) |
| 25 | extra | R | interior | 59.6, -269.2, -44.6 | 1024.0 | 6.04 | 0.99 | 1013.5 | [png](crops/k025_extra.png) |
| 26 | missing | R | interior | 38.1, -46.1, -128.4 | 399.0 | 7.19 | 2.51 | 1003.1 | [png](crops/k026_missing.png) |
| 27 | extra | C | interior | -0.7, -242.6, -100.6 | 404.8 | 3.35 | 2.46 | 994.6 | [png](crops/k027_extra.png) |
| 28 | extra | C | interior | 0.9, -74.4, -134.9 | 1294.2 | 1.9 | 0.77 | 994.0 | [png](crops/k028_extra.png) |
| 29 | missing | C | interior | 4.1, 13.2, -120.4 | 887.0 | 3.78 | 1.0 | 887.3 | [png](crops/k029_missing.png) |
| 30 | missing | R | interior | 105.7, -150.3, -60.6 | 222.2 | 4.39 | 3.16 | 701.5 | [png](crops/k030_missing.png) |
| 31 | missing | R | interior | 105.7, -150.1, -62.3 | 721.3 | 3.16 | 0.95 | 687.2 | [png](crops/k031_missing.png) |
| 32 | missing | L | interior | -105.8, -150.2, -62.3 | 707.9 | 3.35 | 0.93 | 657.5 | [png](crops/k032_missing.png) |
| 33 | missing | L | interior | -105.8, -150.4, -60.9 | 207.7 | 4.49 | 3.16 | 657.2 | [png](crops/k033_missing.png) |
| 34 | missing | R | interior | 120.2, -110.6, -50.2 | 539.7 | 4.37 | 1.19 | 640.3 | [png](crops/k034_missing.png) |
| 35 | missing | L | interior | -120.2, -83.3, -68.9 | 646.1 | 2.74 | 0.9 | 580.4 | [png](crops/k035_missing.png) |
| 36 | missing | L | interior | -146.8, 61.3, -26.4 | 486.6 | 1.99 | 1.17 | 567.7 | [png](crops/k036_missing.png) |
| 37 | missing | L | interior | -44.6, -46.2, -130.0 | 537.3 | 3.36 | 1.04 | 556.2 | [png](crops/k037_missing.png) |
| 38 | missing | L | interior | -74.9, -233.0, -69.1 | 192.4 | 4.58 | 2.86 | 550.7 | [png](crops/k038_missing.png) |
| 39 | missing | R | interior | 74.9, -233.0, -69.8 | 183.3 | 4.56 | 2.94 | 539.6 | [png](crops/k039_missing.png) |
| 40 | missing | R | shoulder | 159.7, -0.5, -39.2 | 711.8 | 0.86 | 0.72 | 511.1 | [png](crops/k040_missing.png) |
| 41 | extra | C | interior | -0.2, -274.6, -81.7 | 617.7 | 3.51 | 0.81 | 501.8 | [png](crops/k041_extra.png) |
| 42 | extra | C | interior | -0.7, 43.2, -87.3 | 633.7 | 4.8 | 0.78 | 491.3 | [png](crops/k042_extra.png) |
| 43 | extra | L | shoulder | -162.4, -52.9, -24.8 | 399.7 | 2.34 | 1.21 | 485.3 | [png](crops/k043_extra.png) |
| 44 | extra | L | shoulder | -154.1, 52.8, -24.1 | 393.0 | 2.36 | 1.23 | 483.2 | [png](crops/k044_extra.png) |
| 45 | missing | C | interior | 1.5, 33.4, -100.2 | 945.6 | 0.84 | 0.5 | 471.0 | [png](crops/k045_missing.png) |
| 46 | extra | C | interior | 0.4, -37.6, -133.0 | 470.2 | 2.43 | 0.94 | 440.1 | [png](crops/k046_extra.png) |
| 47 | extra | R | interior | 35.9, -64.4, -130.7 | 445.5 | 2.93 | 0.99 | 439.4 | [png](crops/k047_extra.png) |
| 48 | extra | L | interior | -125.4, -70.1, -79.8 | 317.1 | 3.09 | 1.37 | 434.3 | [png](crops/k048_extra.png) |
| 49 | missing | R | interior | 46.1, -272.3, -72.9 | 200.3 | 5.47 | 2.16 | 432.9 | [png](crops/k049_missing.png) |
| 50 | missing | L | interior | -46.8, -271.2, -73.3 | 217.5 | 5.29 | 1.96 | 426.3 | [png](crops/k050_missing.png) |
| 51 | extra | L | interior | -100.2, -235.3, -11.4 | 660.7 | 1.22 | 0.63 | 418.5 | [png](crops/k051_extra.png) |
| 52 | extra | R | interior | 51.9, 85.6, -48.6 | 714.4 | 2.71 | 0.58 | 413.5 | [png](crops/k052_extra.png) |
| 53 | missing | R | interior | 48.5, 64.2, -73.8 | 344.1 | 3.42 | 1.18 | 405.6 | [png](crops/k053_missing.png) |
| 54 | missing | L | shoulder | -159.8, -1.6, -39.4 | 647.0 | 0.75 | 0.62 | 401.6 | [png](crops/k054_missing.png) |
| 55 | extra | R | shoulder | 154.0, 53.6, -21.8 | 333.0 | 2.29 | 1.2 | 401.2 | [png](crops/k055_extra.png) |
| 56 | extra | R | interior | 124.8, -69.3, -80.5 | 291.8 | 3.78 | 1.32 | 384.6 | [png](crops/k056_extra.png) |
| 57 | missing | R | interior | 68.4, -59.7, -124.3 | 605.9 | 2.41 | 0.63 | 382.5 | [png](crops/k057_missing.png) |
| 58 | missing | L | interior | -67.8, -60.7, -124.4 | 592.5 | 2.39 | 0.62 | 367.5 | [png](crops/k058_missing.png) |
| 59 | extra | L | interior | -52.1, 86.2, -48.1 | 664.9 | 2.63 | 0.55 | 366.5 | [png](crops/k059_extra.png) |
| 60 | extra | R | shoulder | 162.5, -54.0, -22.0 | 313.6 | 2.25 | 1.16 | 363.5 | [png](crops/k060_extra.png) |
| 61 | extra | L | interior | -33.7, -220.5, -99.8 | 221.6 | 4.68 | 1.6 | 354.1 | [png](crops/k061_extra.png) |
| 62 | missing | L | interior | -49.2, 66.6, -71.7 | 267.1 | 3.43 | 1.31 | 351.0 | [png](crops/k062_missing.png) |
| 63 | extra | R | interior | 108.4, -173.3, -59.5 | 335.3 | 1.61 | 1.05 | 351.0 | [png](crops/k063_extra.png) |
| 64 | missing | R | interior | 17.4, -19.3, -128.0 | 127.7 | 5.2 | 2.6 | 332.3 | [png](crops/k064_missing.png) |
| 65 | extra | L | interior | -109.0, -173.0, -59.1 | 340.5 | 1.59 | 0.98 | 332.1 | [png](crops/k065_extra.png) |
| 66 | missing | R | interior | 10.9, -171.0, -118.3 | 118.8 | 4.05 | 2.75 | 326.2 | [png](crops/k066_missing.png) |
| 67 | missing | L | interior | -55.3, -92.1, -125.4 | 203.7 | 4.8 | 1.6 | 325.5 | [png](crops/k067_missing.png) |
| 68 | missing | L | interior | -118.2, -111.6, -53.5 | 354.4 | 3.12 | 0.91 | 323.6 | [png](crops/k068_missing.png) |
| 69 | missing | L | interior | -17.5, -19.3, -127.9 | 117.3 | 5.24 | 2.61 | 306.2 | [png](crops/k069_missing.png) |
| 70 | missing | L | interior | -55.5, -18.6, -127.2 | 226.0 | 3.34 | 1.3 | 293.4 | [png](crops/k070_missing.png) |
| 71 | extra | R | interior | 88.0, -243.3, -30.4 | 302.5 | 1.57 | 0.92 | 278.5 | [png](crops/k071_extra.png) |
| 72 | missing | R | interior | 134.1, -102.4, -31.5 | 496.5 | 0.87 | 0.55 | 272.4 | [png](crops/k072_missing.png) |
| 73 | missing | R | interior | 68.6, 37.0, -97.3 | 398.4 | 3.24 | 0.68 | 269.6 | [png](crops/k073_missing.png) |
| 74 | extra | L | interior | -89.1, -207.5, -74.8 | 236.6 | 1.94 | 1.14 | 269.6 | [png](crops/k074_extra.png) |
| 75 | extra | L | interior | -39.7, -69.8, -130.9 | 307.5 | 2.4 | 0.83 | 256.5 | [png](crops/k075_extra.png) |
| 76 | extra | L | interior | -120.0, -177.5, -20.6 | 214.8 | 2.18 | 1.19 | 255.5 | [png](crops/k076_extra.png) |
| 77 | missing | L | interior | -133.7, -103.7, -34.9 | 463.3 | 0.87 | 0.54 | 252.3 | [png](crops/k077_missing.png) |
| 78 | missing | L | interior | -70.6, 37.2, -97.4 | 351.6 | 3.22 | 0.71 | 248.1 | [png](crops/k078_missing.png) |
| 79 | extra | R | interior | 88.0, -208.3, -75.1 | 202.5 | 2.07 | 1.19 | 241.0 | [png](crops/k079_extra.png) |
| 80 | missing | R | interior | 34.9, -19.1, -127.4 | 101.1 | 4.7 | 2.34 | 236.5 | [png](crops/k080_missing.png) |
| 81 | missing | L | interior | -35.0, -19.2, -127.2 | 93.3 | 4.68 | 2.39 | 223.3 | [png](crops/k081_missing.png) |
| 82 | missing | R | interior | 129.3, -120.1, -37.1 | 262.5 | 1.55 | 0.84 | 219.5 | [png](crops/k082_missing.png) |
| 83 | missing | L | interior | -76.8, -212.9, -81.4 | 368.0 | 2.25 | 0.57 | 209.2 | [png](crops/k083_missing.png) |
| 84 | extra | L | skin | -106.4, -226.6, -13.6 | 283.2 | 1.34 | 0.74 | 208.3 | [png](crops/k084_extra.png) |
| 85 | missing | L | interior | -65.1, -20.0, -117.6 | 98.8 | 3.88 | 2.01 | 198.6 | [png](crops/k085_missing.png) |
| 86 | missing | L | interior | -120.1, -167.4, -31.8 | 391.2 | 0.73 | 0.5 | 194.5 | [png](crops/k086_missing.png) |
| 87 | missing | R | interior | 10.7, -170.0, -120.5 | 302.9 | 1.72 | 0.63 | 191.1 | [png](crops/k087_missing.png) |
| 88 | extra | C | interior | -0.1, -153.8, -123.4 | 426.6 | 0.79 | 0.43 | 184.7 | [png](crops/k088_extra.png) |
| 89 | missing | L | interior | -43.7, 37.0, -99.7 | 267.0 | 3.26 | 0.68 | 182.8 | [png](crops/k089_missing.png) |
| 90 | missing | L | interior | -65.9, 12.5, -116.1 | 94.7 | 3.97 | 1.93 | 182.6 | [png](crops/k090_missing.png) |
| 91 | missing | R | interior | 43.5, 37.1, -99.4 | 267.0 | 3.26 | 0.66 | 176.8 |  |
| 92 | missing | R | skin | 125.0, -81.9, -66.3 | 449.1 | 0.66 | 0.39 | 173.5 |  |
| 93 | extra | R | interior | 35.3, -224.1, -98.8 | 382.6 | 6.59 | 0.44 | 169.1 | [png](crops/k093_extra.png) |
| 94 | extra | R | interior | 38.4, -114.3, -127.1 | 231.6 | 2.29 | 0.73 | 168.3 | [png](crops/k094_extra.png) |
| 95 | missing | R | interior | 86.2, -180.4, -81.8 | 352.1 | 0.72 | 0.47 | 166.4 |  |
| 96 | extra | L | interior | -38.4, -114.5, -127.1 | 224.0 | 2.34 | 0.72 | 160.9 | [png](crops/k096_extra.png) |
| 97 | missing | L | interior | -34.9, -233.6, -93.9 | 68.0 | 5.14 | 2.31 | 157.4 |  |
| 98 | missing | R | skin | 116.8, -199.6, -14.0 | 415.4 | 1.11 | 0.37 | 151.8 |  |
| 99 | extra | R | interior | 108.5, -210.2, -24.6 | 170.9 | 1.82 | 0.88 | 151.1 |  |
| 100 | extra | L | interior | -123.5, -77.0, -82.0 | 371.2 | 0.75 | 0.4 | 147.6 |  |
| 101 | extra | L | interior | -111.4, -114.0, -65.0 | 147.6 | 2.37 | 0.99 | 146.2 | [png](crops/k101_extra.png) |
| 102 | missing | R | shoulder | 156.5, 0.7, -63.1 | 326.4 | 0.66 | 0.45 | 145.8 |  |
| 103 | missing | L | interior | -124.4, -80.4, -71.7 | 58.6 | 3.92 | 2.44 | 142.9 |  |
| 104 | missing | L | interior | -72.3, -11.9, -123.0 | 245.0 | 2.02 | 0.56 | 137.8 |  |
| 105 | missing | R | interior | 72.5, -11.8, -122.9 | 244.7 | 1.88 | 0.56 | 136.9 |  |
| 106 | extra | R | interior | 113.8, -112.8, -61.5 | 124.3 | 3.73 | 1.09 | 135.6 | [png](crops/k106_extra.png) |
| 107 | missing | R | interior | 16.9, -215.9, -88.6 | 90.3 | 2.64 | 1.45 | 130.6 |  |
| 108 | missing | R | interior | 94.1, 84.3, -20.8 | 410.1 | 5.01 | 0.31 | 128.9 | [png](crops/k108_missing.png) |
| 109 | missing | L | skin | -116.5, -198.9, -8.7 | 265.0 | 0.67 | 0.47 | 125.7 |  |
| 110 | missing | L | interior | -84.7, -182.8, -82.9 | 275.8 | 0.67 | 0.45 | 123.4 |  |
| 111 | missing | L | interior | -94.0, 84.1, -19.6 | 401.2 | 5.0 | 0.31 | 122.5 |  |
| 112 | extra | L | interior | -128.7, 73.9, -45.3 | 332.9 | 0.6 | 0.36 | 120.3 |  |
| 113 | missing | L | interior | -103.7, -214.1, -38.8 | 292.9 | 0.69 | 0.41 | 120.0 |  |
| 114 | missing | R | interior | 139.2, -85.0, -37.5 | 145.0 | 1.32 | 0.81 | 116.8 |  |
| 115 | missing | L | interior | -37.1, -91.8, -126.5 | 128.5 | 2.54 | 0.9 | 115.4 |  |
| 116 | extra | R | interior | 77.9, -254.7, -20.5 | 271.9 | 0.58 | 0.4 | 109.6 |  |
| 117 | extra | L | interior | -117.0, 82.7, -22.5 | 236.1 | 0.77 | 0.46 | 108.8 |  |
| 118 | missing | R | interior | 140.0, 77.1, -28.2 | 211.9 | 1.6 | 0.5 | 105.2 |  |
| 119 | missing | R | skin | 63.9, -272.6, -36.5 | 238.8 | 0.89 | 0.44 | 103.9 |  |
| 120 | missing | L | interior | -140.0, 76.8, -29.0 | 187.9 | 1.48 | 0.55 | 102.8 |  |
| 121 | missing | L | interior | -128.5, -124.8, -35.9 | 128.6 | 1.48 | 0.8 | 102.4 |  |
| 122 | missing | L | interior | -29.8, -129.5, -123.2 | 155.8 | 1.38 | 0.64 | 99.8 |  |
| 123 | extra | R | interior | 95.8, -132.6, -84.7 | 104.1 | 2.33 | 0.96 | 99.6 |  |
| 124 | extra | L | interior | -76.2, -244.8, -64.0 | 277.8 | 0.68 | 0.36 | 99.1 |  |
| 125 | extra | L | shoulder | -160.7, -40.3, -45.6 | 181.9 | 0.82 | 0.54 | 97.4 |  |
| 126 | missing | L | interior | -56.9, 61.0, -78.6 | 42.8 | 3.43 | 2.24 | 96.1 | [png](crops/k126_missing.png) |
| 127 | extra | R | shoulder | 160.9, -43.3, -42.4 | 173.8 | 0.83 | 0.55 | 95.3 |  |
| 128 | extra | R | interior | 117.1, 82.1, -23.8 | 206.9 | 0.75 | 0.46 | 95.0 |  |
| 129 | extra | L | shoulder | -154.3, 40.3, -44.9 | 176.8 | 0.82 | 0.53 | 94.4 |  |
| 130 | missing | R | interior | 64.1, 83.0, -51.0 | 287.5 | 0.37 | 0.33 | 94.0 |  |
| 131 | missing | L | interior | -32.8, -125.3, -118.1 | 212.3 | 0.65 | 0.44 | 93.5 |  |
| 132 | missing | R | interior | 56.9, 61.0, -78.3 | 43.0 | 3.4 | 2.17 | 93.1 |  |
| 133 | extra | R | shoulder | 154.1, 43.3, -42.0 | 166.4 | 0.87 | 0.56 | 92.7 |  |
| 134 | extra | L | interior | -45.8, 45.6, -96.4 | 119.6 | 1.27 | 0.77 | 92.4 |  |
| 135 | missing | L | interior | -17.2, -218.7, -106.8 | 229.5 | 0.87 | 0.39 | 90.0 |  |
| 136 | extra | R | interior | 121.0, -177.6, -18.3 | 114.4 | 1.13 | 0.78 | 89.6 |  |
| 137 | extra | L | interior | -101.8, -168.8, -69.0 | 185.8 | 0.74 | 0.47 | 86.9 |  |
| 138 | missing | R | interior | 27.8, -129.7, -123.1 | 132.0 | 1.42 | 0.66 | 86.6 |  |
| 139 | missing | R | interior | 34.8, -126.5, -118.8 | 187.6 | 3.93 | 0.46 | 85.8 | [png](crops/k139_missing.png) |
| 140 | missing | R | interior | 64.0, -66.0, -125.5 | 195.4 | 0.83 | 0.44 | 85.6 |  |
| 141 | extra | R | rim | 112.5, -194.2, -5.4 | 148.1 | 0.89 | 0.58 | 85.4 |  |
| 142 | extra | R | interior | 45.7, 45.7, -96.3 | 111.9 | 1.22 | 0.76 | 84.9 |  |
| 143 | missing | L | interior | -18.3, -212.8, -104.2 | 186.0 | 1.02 | 0.46 | 84.8 |  |
| 144 | missing | R | interior | 93.6, 81.6, -7.8 | 150.1 | 0.84 | 0.56 | 83.5 |  |
| 145 | extra | L | interior | -72.7, -257.9, -43.1 | 115.9 | 1.47 | 0.7 | 81.5 |  |
| 146 | missing | R | interior | 36.4, -91.3, -127.3 | 142.3 | 2.48 | 0.57 | 81.4 |  |
| 147 | missing | L | interior | -94.5, 81.7, -8.4 | 147.0 | 0.82 | 0.55 | 80.7 |  |
| 148 | missing | R | interior | 137.0, -109.7, -14.6 | 172.0 | 0.83 | 0.46 | 78.5 |  |
| 149 | extra | L | interior | -91.1, -240.5, -23.5 | 97.8 | 1.27 | 0.8 | 78.4 |  |
