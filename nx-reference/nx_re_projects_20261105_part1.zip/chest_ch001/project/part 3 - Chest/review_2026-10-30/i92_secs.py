"""Plane sections, scan (orange, lifted by seat_dz) vs CAD STL (black).
usage: i92_secs.py cad.stl out.png AXIS v1,v2,.. lim a0 a1 b0 b1 [grid g]
2D coords = the other two axes in order (x: y,z  y: x,z  z: x,y)."""
import sys, os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import load, section, W

cad, out, axs_, vals = sys.argv[1], sys.argv[2], sys.argv[3], [float(t) for t in sys.argv[4].split(",")]
a = sys.argv[5:]
lim = [float(t) for t in a[a.index("lim") + 1:a.index("lim") + 5]]
grid = float(a[a.index("grid") + 1]) if "grid" in a else 5.0
axn = "xyz".index(axs_); other = [k for k in range(3) if k != axn]
DZ = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))["seat_dz"]
v, f = load(); v = v.copy(); v[:, 2] += DZ
import trimesh
cm = trimesh.load(cad)
cv, cf = np.asarray(cm.vertices, float), np.asarray(cm.faces)
nc = min(len(vals), 3)
nr = int(np.ceil(len(vals) / nc))
asp = (lim[3] - lim[2]) / max(lim[1] - lim[0], 1e-9)
fig, axs = plt.subplots(nr, nc, figsize=(8 * nc, 8 * nr * asp + 0.6), squeeze=False)
for k, val in enumerate(vals):
    ax = axs[k // nc][k % nc]
    for vv, ff, col, lw in ((v, f, "#e08a00", 1.6), (cv, cf, "k", 0.8)):
        s = section(vv, ff, axn, val)[:, :, other]
        mm = ((s[:, :, 0] > lim[0]) & (s[:, :, 0] < lim[1]) & (s[:, :, 1] > lim[2]) & (s[:, :, 1] < lim[3])).any(1)
        ax.add_collection(LineCollection(s[mm], colors=col, lw=lw))
    ax.set_xlim(lim[0], lim[1]); ax.set_ylim(lim[2], lim[3]); ax.set_aspect("equal")
    ax.set_xticks(np.arange(np.ceil(lim[0] / grid) * grid, lim[1], grid)); ax.set_yticks(np.arange(np.ceil(lim[2] / grid) * grid, lim[3], grid))
    ax.tick_params(labelsize=7); ax.grid(lw=0.3)
    ax.set_title(f"{axs_} = {val}   ({'xyz'[other[0]]} right, {'xyz'[other[1]]} up)  scan orange, CAD black", fontsize=9)
fig.tight_layout(); fig.savefig(out, dpi=70)
print("ok", out)
