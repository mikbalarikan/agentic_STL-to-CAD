"""Open-side depth map (min z seen from -Z), scan (lifted by seat_dz) vs CAD STL, as tiles at readable scale.
usage: i93_depth.py cad.stl tag   -> work/diag/depth_<tag>_<tile>.png, work/depth_<tag>.npz
diff = CAD z - scan z: + (red) = CAD surface further in than the scan = CAD MISSING material; - (blue) = CAD extra."""
import sys, os, json
import numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import open3d as o3d
from common import W
stl, tag = sys.argv[1], sys.argv[2]
DZ = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))["seat_dz"]
d = np.load(W + r"\hmap2.npz"); H = d["H"]; X0, X1, Y0, Y1 = d["ext"]; C = float(d["cell"])
ny, nx = H.shape
cm = o3d.io.read_triangle_mesh(stl)
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
xs = X0 + (np.arange(nx) + 0.5) * C; ys = Y0 + (np.arange(ny) + 0.5) * C
XX, YY = np.meshgrid(xs, ys)
rays = np.zeros((ny * nx, 6), np.float32); rays[:, 0] = XX.ravel(); rays[:, 1] = YY.ravel(); rays[:, 2] = 0.0; rays[:, 5] = 1.0
t = sc.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
zc = np.where(np.isfinite(t), t, np.nan).reshape(ny, nx)
zs = np.where(np.isfinite(H), -H + DZ, np.nan)
diff = zc - zs
np.savez_compressed(W + rf"\depth_{tag}.npz", diff=diff, zs=zs, zc=zc, ext=d["ext"], cell=C)
os.makedirs(W + r"\diag", exist_ok=True)
tiles = {"knee": (-75, 125, -72, 70), "mid": (-75, 125, 60, 190), "hip": (-75, 125, 180, 292)}
for nm, (a0, a1, b0, b1) in tiles.items():
    i0, i1 = int((b0 - Y0) / C), int((b1 - Y0) / C); j0, j1 = int((a0 - X0) / C), int((a1 - X0) / C)
    fig, ax = plt.subplots(1, 2, figsize=(30, 30 * (b1 - b0) / (a1 - a0) / 2 + 1.5))
    im = ax[0].imshow(np.clip(diff[i0:i1, j0:j1], -3, 3), origin="lower", extent=[a0, a1, b0, b1], cmap="seismic", vmin=-3, vmax=3)
    plt.colorbar(im, ax=ax[0], shrink=0.6); ax[0].set_title(f"{tag}: CAD z - scan z (open side); red = CAD missing material, blue = CAD extra")
    im = ax[1].imshow(zs[i0:i1, j0:j1], origin="lower", extent=[a0, a1, b0, b1], cmap="nipy_spectral", vmin=34, vmax=112)
    plt.colorbar(im, ax=ax[1], shrink=0.6); ax[1].set_title("scan z (min z per cell, lifted)")
    for a in ax:
        a.set_xticks(np.arange(a0, a1 + 1, 10)); a.set_yticks(np.arange(b0 - b0 % 10, b1 + 1, 10)); a.grid(lw=0.4, color="k", alpha=0.4)
        a.tick_params(labelsize=8)
    fig.tight_layout(); fig.savefig(W + rf"\diag\depth_{tag}_{nm}.png", dpi=55); plt.close(fig)
a = diff[np.isfinite(diff)]
print("cells", a.size, "|diff|>0.3: %.1f %%, CAD missing>0.3 %.1f %%, CAD extra>0.3 %.1f %%" % (100 * (abs(a) > 0.3).mean(), 100 * (a > 0.3).mean(), 100 * (a < -0.3).mean()))
