"""Feature census on the ZI (open-side) and ZE (front) depth maps, own detection on the scan, matched to the CAD.
Openings: cells with no hit through the whole part (ZI nan) inside the part outline -> connected components.
Raised features (ZI view): white top-hat of the scan height (disk r 6 mm) > 0.8 mm -> components = bosses/pins/ribs/
gussets/fins; same on the CAD map; matched by overlap (IoU). Pits next to / in raised features (black top-hat, disk r 2.5
mm, > 0.8 mm) = holes in bosses. Exterior (ZE): white / black top-hat (r 3 mm) of the front height for text and marks.
Writes data/census.json + data/census_maps.npz"""
import os, json
import numpy as np
from scipy import ndimage
from rc import D
M = np.load(os.path.join(D, "maps.npz")); xs, ys, C = M["xs"], M["ys"], float(M["cell"])
X, Y = np.meshgrid(xs, ys)


def disk(r_mm):
    r = int(round(r_mm / C)); yy, xx = np.mgrid[-r:r + 1, -r:r + 1]; return (xx ** 2 + yy ** 2) <= r * r


def comps(mask, minpx):
    lab, n = ndimage.label(mask, structure=np.ones((3, 3)))
    sz = np.bincount(lab.ravel(), minlength=n + 1); keep = np.flatnonzero(sz >= minpx); keep = keep[keep > 0]
    out = []
    objs = ndimage.find_objects(lab)
    for k in keep:
        sl = objs[k - 1]; m = lab[sl] == k
        xx, yy = X[sl][m], Y[sl][m]
        pts = np.c_[xx, yy]; ev = np.sort(np.linalg.eigvalsh(np.cov(pts.T))) if len(pts) > 3 else np.zeros(2)
        out.append(dict(k=int(k), area=round(float(m.sum() * C * C), 1), ctr=[round(float(xx.mean()), 1), round(float(yy.mean()), 1)],
                        lo=[round(float(xx.min()), 1), round(float(yy.min()), 1)], hi=[round(float(xx.max()), 1), round(float(yy.max()), 1)],
                        len=round(float(4 * np.sqrt(max(ev[1], 0))), 1), wid=round(float(4 * np.sqrt(max(ev[0], 0))), 1)))
    return lab, out


def match(labA, A, labB, B, key):
    """for each comp of A: best overlapping comp of B (IoU)."""
    Bk = {b_["k"]: b_ for b_ in B}
    for a in A:
        m = labA == a["k"]; hit = labB[m]; hit = hit[hit > 0]
        if len(hit) == 0:
            a[key] = None; continue
        bk = int(np.bincount(hit).argmax()); inter = (hit == bk).sum()
        b = Bk.get(bk)
        uni = m.sum() + (labB == bk).sum() - inter
        a[key] = dict(k=bk, iou=round(float(inter / uni), 2), area=b["area"] if b else None, ctr=b["ctr"] if b else None,
                      h_max=b.get("h_max") if b else None, z_top=b.get("z_top") if b else None)


res = {}; labs = {}
s_any = ~np.isnan(M["scan_ZI"]) | ~np.isnan(M["scan_ZE"])
outline = ndimage.binary_fill_holes(ndimage.binary_closing(s_any, disk(1.0)))
for nm in ("scan", "cad"):
    op = np.isnan(M[nm + "_ZI"]) & outline
    op = ndimage.binary_opening(op, np.ones((2, 2)))
    labs[nm + "_open"], res[nm + "_open"] = comps(op, 4)
match(labs["scan_open"], res["scan_open"], labs["cad_open"], res["cad_open"], "cad")
match(labs["cad_open"], res["cad_open"], labs["scan_open"], res["scan_open"], "scan")
for nm in ("scan", "cad"):
    z = M[nm + "_ZI"].copy(); bad = np.isnan(z); z[bad] = -200
    th = z - ndimage.grey_opening(z, footprint=disk(6.0)); th[bad] = 0
    lab, cs = comps(th > 0.8, 12)
    for c_ in cs:
        m = lab == c_["k"]; c_["h_max"] = round(float(th[m].max()), 2); c_["h_p90"] = round(float(np.percentile(th[m], 90)), 2)
        c_["z_top"] = round(float(z[m].max()), 2)
    res[nm + "_raised"] = cs; labs[nm + "_raised"] = lab
    bh = ndimage.grey_closing(z, footprint=disk(2.5)) - z; bh[bad] = 0
    lab2, cs2 = comps((bh > 0.8) & ndimage.binary_dilation(lab > 0, disk(1.0)), 6)
    res[nm + "_pits"] = cs2; labs[nm + "_pits"] = lab2
for k in ("raised", "pits"):
    match(labs["scan_" + k], res["scan_" + k], labs["cad_" + k], res["cad_" + k], "cad")
    match(labs["cad_" + k], res["cad_" + k], labs["scan_" + k], res["scan_" + k], "scan")
ext = {}
for nm in ("scan", "cad"):
    z = -M[nm + "_ZE"].copy(); bad = np.isnan(z); z[bad] = -500
    wt = z - ndimage.grey_opening(z, footprint=disk(3.0)); wt[bad] = 0
    bt = ndimage.grey_closing(z, footprint=disk(3.0)) - z; bt[bad] = 0
    ext[nm + "_ext_w"] = wt.astype(np.float32); ext[nm + "_ext_b"] = bt.astype(np.float32)
np.savez_compressed(os.path.join(D, "census_maps.npz"), **labs, **ext)
json.dump(res, open(os.path.join(D, "census.json"), "w"), indent=1)
for k in ("scan_open", "cad_open", "scan_raised", "cad_raised", "scan_pits", "cad_pits"):
    print(k, len(res[k]))
for k, other in (("scan_open", "cad"), ("cad_open", "scan"), ("scan_raised", "cad"), ("cad_raised", "scan"), ("scan_pits", "cad"), ("cad_pits", "scan")):
    print("==", k, ": no match or IoU < 0.5")
    for c_ in res[k]:
        mt = c_[other]
        if mt is None or mt["iou"] < 0.5:
            print(c_["ctr"], c_["area"], "L", c_["len"], "W", c_["wid"], "h", c_.get("h_max"), "->", None if mt is None else (mt["iou"], mt["area"], mt["ctr"]))
