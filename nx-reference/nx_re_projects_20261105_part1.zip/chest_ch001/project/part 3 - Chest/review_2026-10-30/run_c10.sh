# usage: bash run_c10.sh <tag>   (CAD = ../nx/out<tag>/chest_G.stl, data -> data_<tag>/)
T=$1
mkdir -p data_$T cad_$T
cp "../nx/out$T/chest_G.stl" cad_$T/chest_G.stl
export RV_CAD="$PWD/cad_$T/chest_G.stl" RV_DATA="$PWD/data_$T"
P=/c/Users/marya/.venvs/cadgenbench/Scripts/python.exe
$P -u r1_dev.py > data_$T/r1.log 2>&1
$P -u r3_maps.py > data_$T/r3.log 2>&1
$P -u r4_diffmaps.py ZE ZI > data_$T/r4.log 2>&1
$P -u r6_census.py > data_$T/r6.log 2>&1
$P -u r10_measure.py > data_$T/r10.log 2>&1
$P -u r8_thin.py > data_$T/r8.log 2>&1
$P -u r2_clusters.py 0.3 3 > data_$T/r2.log 2>&1
echo done > data_$T/DONE
