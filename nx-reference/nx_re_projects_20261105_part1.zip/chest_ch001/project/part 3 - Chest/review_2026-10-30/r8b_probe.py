"""Probe thin-CAD spots: at points inside a box, the CAD ray thickness along -normal, the normal of the hit triangle,
the number of CAD surface crossings along the whole ray, and the CAD section through the spot (y = const) as png.
usage: r8b_probe.py x y z half  -> prints + data/probe_<x>_<y>_<z>.png"""
import sys, os
import numpy as np, open3d as o3d
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from rc import CAD, D, read_stl, weld, load, section
x, y, z, h = [float(t) for t in sys.argv[1:5]]
T = read_stl(CAD); cv, cf = weld(T)
cm = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(cv), o3d.utility.Vector3iVector(cf)); cm.compute_triangle_normals()
TN = np.asarray(cm.triangle_normals)
cs = o3d.t.geometry.RaycastingScene(); cs.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
pc = cm.sample_points_uniformly(1500000, use_triangle_normal=True)
Q = np.asarray(pc.points, np.float32); N = np.asarray(pc.normals, np.float32)
m = np.all(np.abs(Q - [x, y, z]) < h, axis=1)
Q, N = Q[m], N[m]
r = np.c_[Q - N * 0.005, -N].astype(np.float32)
res = cs.cast_rays(o3d.core.Tensor(r)); t = res["t_hit"].numpy(); pid = res["primitive_ids"].numpy()
cnt = cs.count_intersections(o3d.core.Tensor(np.c_[Q - N * 0.005, -N].astype(np.float32))).numpy()
thin = t < 0.6
print("pts", len(Q), "thin", int(thin.sum()))
for i in np.flatnonzero(thin)[:12]:
    print(np.round(Q[i], 2), "n", np.round(N[i], 2), "t", round(float(t[i]), 4), "hit n", np.round(TN[pid[i]], 2), "crossings", int(cnt[i]))
v, f = load()
fig, ax = plt.subplots(1, 2, figsize=(16, 8))
for a_, axis, ij in ((ax[0], 1, (0, 2)), (ax[1], 0, (1, 2))):
    val = y if axis == 1 else x
    for vv, ff, col, lw in ((v, f, "#e08a00", 1.6), (cv, cf, "k", 0.7)):
        s = section(vv, ff, axis, val)[:, :, list(ij)]
        c0 = (x, z) if axis == 1 else (y, z)
        k = (np.abs(s[:, :, 0] - c0[0]) < h).all(1) & (np.abs(s[:, :, 1] - c0[1]) < h).all(1)
        a_.add_collection(LineCollection(s[k], colors=col, lw=lw))
    a_.set_xlim(c0[0] - h, c0[0] + h); a_.set_ylim(c0[1] - h, c0[1] + h); a_.set_aspect("equal"); a_.grid(lw=0.3)
    a_.set_title(f"{'xyz'[axis]} = {val}: scan orange, CAD black", fontsize=9)
fig.tight_layout(); fig.savefig(os.path.join(D, f"probe_{x:g}_{y:g}_{z:g}.png"), dpi=60)
