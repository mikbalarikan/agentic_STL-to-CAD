"""Two-way SIGNED deviation clusters, full-resolution scan vs a CAD STL (scan lifted by seat_dz).
usage: i90_clusters.py cad.stl tag [thr=0.3] [min_area=4]
missing  (+) = scan surface OUTSIDE the CAD solid (scan triangle centroids, signed distance > thr), plus CAD surface
               points lying INSIDE the scan material (CAD->scan, signed by the scan normal) -> CAD lacks material.
extra    (-) = scan surface INSIDE the CAD solid, plus CAD surface points standing OUTSIDE the scan -> CAD has material
               the scan does not.
Points of each sign are binned in 1 mm voxels; 26-connected voxels form a cluster. For each cluster: area (scan side and
CAD side), max / p90 |d|, centroid, bbox, PCA width (fillet-like = long + narrow + shallow), mean CAD normal.
Writes work/clusters_<tag>.json and work/clusters_<tag>_pts.npz."""
import sys, os, json
import numpy as np
import open3d as o3d
from scipy import ndimage
from common import W, load

cad, tag = sys.argv[1], sys.argv[2]
THR = float(sys.argv[3]) if len(sys.argv) > 3 else 0.3
AMIN = float(sys.argv[4]) if len(sys.argv) > 4 else 4.0
DZ = json.load(open(os.path.join(os.path.dirname(W), "nx", "params.json")))["seat_dz"]

cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices(); cm.compute_triangle_normals()
cs = o3d.t.geometry.RaycastingScene(); cs.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
v, f = load()
v = v.copy(); v[:, 2] += DZ
a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
n = np.cross(b - a, c - a); ar = 0.5 * np.linalg.norm(n, axis=1)
cen = ((a + b + c) / 3).astype(np.float32)
nsc = n / np.maximum(2 * ar, 1e-12)[:, None]
del a, b, c, n
ds = cs.compute_signed_distance(o3d.core.Tensor(cen)).numpy()
print("scan->CAD done", len(ds))

# CAD -> scan, signed by the scan triangle normal at the closest point
sm = o3d.t.geometry.TriangleMesh(o3d.core.Tensor(v.astype(np.float32)), o3d.core.Tensor(f.astype(np.int32)))
ss = o3d.t.geometry.RaycastingScene(); ss.add_triangles(sm)
cad_area = cm.get_surface_area()
NS = 3000000
pc = cm.sample_points_uniformly(NS, use_triangle_normal=True)
Q = np.asarray(pc.points, np.float32); QN = np.asarray(pc.normals)
cp = ss.compute_closest_points(o3d.core.Tensor(Q))
P = cp["points"].numpy(); pid = cp["primitive_ids"].numpy()
dq = np.linalg.norm(Q - P, axis=1)
sgn = np.sign(np.einsum("ij,ij->i", Q - P, nsc[pid]))
# scan normals: check they point out of the material (agree with the CAD normals where the two coincide)
near = dq < 0.05
agree = float(np.mean(np.einsum("ij,ij->i", QN[near], nsc[pid[near]]) > 0))
print("scan normal orientation agreement", round(agree, 3))
if agree < 0.5:
    sgn = -sgn; nsc = -nsc
dqs = dq * sgn            # + = CAD point outside the scan = CAD extra
area_q = cad_area / NS
print("CAD->scan done")

VOX, CORE, REACH = 0.6, 1.0, 3.0
lo = np.array([-75.0, -75.0, 25.0])
shape = tuple(np.ceil((np.array([125.0, 295.0, 120.0]) - lo) / VOX).astype(int))


def vox(p):
    return np.clip(np.floor((p - lo) / VOX).astype(int), 0, np.array(shape) - 1)


def labels(ps, ds_, pq, dq_):
    """Two-level labels: cores (|d| > CORE) 26-connected; thr voxels within REACH of a core join it; the remaining
    thr voxels (shallow: fillets, steps, noise) are labelled among themselves."""
    g = np.zeros(shape, bool); gc = np.zeros(shape, bool)
    for p, d_ in ((ps, ds_), (pq, dq_)):
        iv = vox(p); g[tuple(iv.T)] = True
        ic = iv[d_ > CORE]; gc[tuple(ic.T)] = True
    lc, nc = ndimage.label(gc, structure=np.ones((3, 3, 3)))
    dist, ind = ndimage.distance_transform_edt(~gc, return_indices=True)
    near = g & (dist * VOX <= REACH)
    lab = np.zeros(shape, np.int32)
    lab[near] = lc[ind[0][near], ind[1][near], ind[2][near]]
    rest = g & (lab == 0)
    lr, nr = ndimage.label(rest, structure=np.ones((3, 3, 3)))
    lab[rest] = lr[rest] + nc
    return lab, nc + nr, nc


out = {"cad": cad, "thr": THR, "min_area": AMIN, "scan_tri": int(len(f)), "cad_samples": NS, "normal_agree": agree,
       "vox": VOX, "core": CORE, "reach": REACH, "clusters": []}
allpts = {}
for sign, sel_s, sel_q in (("missing", ds > THR, dqs < -THR), ("extra", ds < -THR, dqs > THR)):
    ps, pq = cen[sel_s], Q[sel_q]
    dsel_s, dsel_q = np.abs(ds[sel_s]), np.abs(dqs[sel_q])
    lab, nl, ncore = labels(ps, dsel_s, pq, dsel_q)
    ls = lab[tuple(vox(ps).T)]; lq = lab[tuple(vox(pq).T)]
    as_ = np.bincount(ls, weights=ar[sel_s], minlength=nl + 1)
    aq = np.bincount(lq, minlength=nl + 1) * area_q
    keep = [k for k in range(1, nl + 1) if max(as_[k], aq[k]) >= AMIN]
    nq_sel, ns_sel = QN[sel_q], nsc[sel_s]
    for k in keep:
        ms, mq = ls == k, lq == k
        pts = np.vstack([ps[ms], pq[mq]]).astype(float)
        dd = np.concatenate([dsel_s[ms], dsel_q[mq]])
        ctr = pts.mean(0)
        ev = np.sort(np.linalg.eigvalsh(np.cov((pts - ctr).T))) if len(pts) > 3 else np.zeros(3)
        ext = 4 * np.sqrt(np.maximum(ev, 0))        # ~ +-2 sigma extents, small to large
        nm = nq_sel[mq].mean(0) if mq.any() else np.zeros(3)
        nv = np.vstack([ns_sel[ms], nq_sel[mq]]).mean(0)
        out["clusters"].append(dict(sign=sign, core=bool(k <= ncore), area_scan=round(float(as_[k]), 1),
                                    area_cad=round(float(aq[k]), 1),
                                    area=round(float(max(as_[k], aq[k])), 1), dmax=round(float(np.percentile(dd, 99)), 2),
                                    p90=round(float(np.percentile(dd, 90)), 2), ctr=ctr.round(1).tolist(),
                                    lo=pts.min(0).round(1).tolist(), hi=pts.max(0).round(1).tolist(),
                                    ext=ext.round(1).tolist(), n_cad=[round(x, 2) for x in nm.tolist()],
                                    n_view=[round(x, 2) for x in nv.tolist()], n_s=int(ms.sum()), n_q=int(mq.sum())))
        allpts[f"c{len(out['clusters']) - 1}"] = np.c_[pts, dd].astype(np.float32)
for i, c_ in enumerate(out["clusters"]):
    c_["key"] = f"c{i}"
out["clusters"].sort(key=lambda c_: -c_["area"] * c_["p90"])
for i, c_ in enumerate(out["clusters"]):
    c_["id"] = i
json.dump(out, open(os.path.join(W, f"clusters_{tag}.json"), "w"), indent=1)
np.savez_compressed(os.path.join(W, f"clusters_{tag}_pts.npz"), **allpts)
tot = {s: [sum(c_["area"] for c_ in out["clusters"] if c_["sign"] == s), sum(1 for c_ in out["clusters"] if c_["sign"] == s)] for s in ("missing", "extra")}
print("clusters", len(out["clusters"]), tot)
for c_ in out["clusters"][:90]:
    print(c_["id"], c_["sign"], "C" if c_["core"] else "s", c_["area"], c_["p90"], c_["dmax"], c_["ctr"], c_["ext"], c_["n_cad"])
