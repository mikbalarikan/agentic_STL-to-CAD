"""Targeted measurements on the depth maps:
1. through-slot orientation (PCA angle of each Z-through opening) for the lower vent and the shoulder vents, scan vs CAD;
2. exterior relief (raised text / marks) heights: ZE white top-hat > 0.12 mm components on the scan, CAD value there;
3. interior relief text near the PCB (ZI white/black top-hat).  -> data/measure.json, data/text_*.png"""
import os, json
import numpy as np
from scipy import ndimage
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from rc import D
M = np.load(os.path.join(D, "maps.npz")); xs, ys, C = M["xs"], M["ys"], float(M["cell"])
X, Y = np.meshgrid(xs, ys)
out = {}


def slots(nm, box):
    op = np.isnan(M[nm + "_ZI"]) & ~np.isnan(np.where(np.isnan(M[nm + "_ZI"]), 0, 0))
    m = (X > box[0]) & (X < box[1]) & (Y > box[2]) & (Y < box[3])
    lab, n = ndimage.label(np.isnan(M[nm + "_ZI"]) & m)
    res = []
    for k in range(1, n + 1):
        mm = lab == k
        if mm.sum() < 20 or mm.sum() > 4000:
            continue
        p = np.c_[X[mm], Y[mm]]; c = p.mean(0); ev, evec = np.linalg.eigh(np.cov((p - c).T))
        d = evec[:, 1]; ang = np.degrees(np.arctan2(d[0], d[1]))      # angle of the long axis from +y, + = leaning to +x
        ang = (ang + 90) % 180 - 90
        res.append(dict(ctr=c.round(2).tolist(), area=round(float(mm.sum() * C * C), 1), len=round(float(4 * np.sqrt(ev[1])), 2),
                        wid=round(float(4 * np.sqrt(ev[0])), 2), lean_deg=round(float(ang), 1)))
    return sorted(res, key=lambda r: r["ctr"][0])


for nm in ("scan", "cad"):
    out[nm + "_lowvent"] = slots(nm, (-45, 45, -210, -196))
    out[nm + "_shvent_R"] = slots(nm, (80, 130, 62, 85))
    out[nm + "_shvent_L"] = slots(nm, (-130, -80, 62, 85))
# exterior relief: front height h = -z (ZE), white top-hat 3 mm
th = {}
for nm in ("scan", "cad"):
    z = -M[nm + "_ZE"].copy(); bad = np.isnan(z); z[bad] = -500
    disk = (np.add.outer(np.arange(-12, 13) ** 2, np.arange(-12, 13) ** 2) <= 144)
    w = z - ndimage.grey_opening(z, footprint=disk); w[bad] = 0
    th[nm] = w
for name, box in {"T800": (-35, 40, -15, 10), "glyphs": (-110, -55, 10, 45)}.items():
    m = (X > box[0]) & (X < box[1]) & (Y > box[2]) & (Y < box[3])
    s, c = th["scan"][m], th["cad"][m]
    rel = s > 0.12
    out["relief_" + name] = dict(box=box, scan_relief_area_mm2=round(float(rel.sum() * C * C), 1),
                                 scan_relief_p50=round(float(np.median(s[rel])), 3) if rel.any() else 0,
                                 scan_relief_p95=round(float(np.percentile(s[rel], 95)), 3) if rel.any() else 0,
                                 cad_relief_p95_same_cells=round(float(np.percentile(c[rel], 95)), 3) if rel.any() else 0)
    i0, i1 = np.searchsorted(ys, box[2]), np.searchsorted(ys, box[3]); j0, j1 = np.searchsorted(xs, box[0]), np.searchsorted(xs, box[1])
    fig, ax = plt.subplots(1, 2, figsize=(16, 16 * (box[3] - box[2]) / (box[1] - box[0]) / 2 + 1.2))
    for a_, nm in zip(ax, ("scan", "cad")):
        im = a_.imshow(th[nm][i0:i1, j0:j1][:, ::-1], origin="lower", extent=[box[1], box[0], box[2], box[3]], cmap="magma", vmin=0, vmax=0.6)
        a_.set_title(f"{name}: {nm} exterior relief height (mm), seen from the front", fontsize=9); plt.colorbar(im, ax=a_, shrink=0.6)
    fig.tight_layout(); fig.savefig(os.path.join(D, f"text_{name}.png"), dpi=60); plt.close(fig)
# interior text below the PCB (y -255..-245)
for nm in ("scan", "cad"):
    z = M[nm + "_ZI"].copy(); bad = np.isnan(z); z[bad] = -500
    disk = (np.add.outer(np.arange(-12, 13) ** 2, np.arange(-12, 13) ** 2) <= 144)
    th[nm + "_i"] = np.maximum(z - ndimage.grey_opening(z, footprint=disk), ndimage.grey_closing(z, footprint=disk) - z); th[nm + "_i"][bad] = 0
box = (-35, 30, -258, -242)
m = (X > box[0]) & (X < box[1]) & (Y > box[2]) & (Y < box[3])
rel = th["scan_i"][m] > 0.12
out["relief_inner_text"] = dict(box=box, scan_relief_area_mm2=round(float(rel.sum() * C * C), 1),
                                scan_relief_p95=round(float(np.percentile(th["scan_i"][m][rel], 95)), 3) if rel.any() else 0,
                                cad_relief_p95_same_cells=round(float(np.percentile(th["cad_i"][m][rel], 95)), 3) if rel.any() else 0)
i0, i1 = np.searchsorted(ys, box[2]), np.searchsorted(ys, box[3]); j0, j1 = np.searchsorted(xs, box[0]), np.searchsorted(xs, box[1])
fig, ax = plt.subplots(2, 1, figsize=(16, 9))
for a_, nm in zip(ax, ("scan_i", "cad_i")):
    im = a_.imshow(th[nm][i0:i1, j0:j1], origin="lower", extent=[box[0], box[1], box[2], box[3]], cmap="magma", vmin=0, vmax=0.6)
    a_.set_title(f"interior text: {nm} relief (mm), seen from the open side", fontsize=9); plt.colorbar(im, ax=a_, shrink=0.6)
fig.tight_layout(); fig.savefig(os.path.join(D, "text_inner.png"), dpi=60); plt.close(fig)
json.dump(out, open(os.path.join(D, "measure.json"), "w"), indent=1)
for k, v_ in out.items():
    if isinstance(v_, list):
        print(k, [(r["ctr"][0], r["lean_deg"], r["len"], r["wid"]) for r in v_])
    else:
        print(k, v_)
