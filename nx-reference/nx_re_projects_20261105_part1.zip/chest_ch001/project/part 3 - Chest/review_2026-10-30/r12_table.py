"""Markdown table of the deviation clusters (data/clusters.json) -> CLUSTERS.md (top N by volume, crops linked)."""
import json, os, sys
from rc import D, RV
N = int(sys.argv[1]) if len(sys.argv) > 1 else 150
cl = json.load(open(os.path.join(D, "clusters.json")))["clusters"]
L = ["# CH-001 outC7: deviation clusters > 0.3 mm (two-way, full-res scan), ranked by volume = area x mean |d|", "",
     f"{sum(c['sign']=='missing' for c in cl)} missing (scan has material the CAD lacks) and {sum(c['sign']=='extra' for c in cl)} extra clusters >= 3 mm2. Top {N} below.", "",
     "| k | sign | side | zone | centre x, y, z (mm) | area mm2 | peak (p99) mm | mean mm | vol mm3 | crop |", "|---|---|---|---|---|---|---|---|---|---|"]
for c in cl[:N]:
    z = max(c["zone"], key=c["zone"].get)
    crop = f"crops/k{c['id']:03d}_{c['sign']}.png"
    L.append(f"| {c['id']} | {c['sign']} | {c['side']} | {z} | {c['ctr'][0]}, {c['ctr'][1]}, {c['ctr'][2]} | {c['area']} | {c['peak']} | {c['mean']} | {c['vol']} | {'[png](' + crop + ')' if os.path.exists(os.path.join(RV, crop)) else ''} |")
open(os.path.join(RV, "CLUSTERS.md"), "w").write("\n".join(L) + "\n")
print("ok")
