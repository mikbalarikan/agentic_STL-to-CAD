export RV_CAD="$PWD/cad_C8/chest_G.stl" RV_DATA="$PWD/data_C8"
P=/c/Users/marya/.venvs/cadgenbench/Scripts/python.exe
$P -u r1_dev.py > data_C8/r1.log 2>&1
$P -u r3_maps.py > data_C8/r3.log 2>&1
$P -u r4_diffmaps.py ZE ZI > data_C8/r4.log 2>&1
$P -u r6_census.py > data_C8/r6.log 2>&1
$P -u r10_measure.py > data_C8/r10.log 2>&1
$P -u r2_clusters.py 0.3 3 > data_C8/r2.log 2>&1
echo done > data_C8/DONE
