# CH-001 Chest: independent final deviation review (2026-10-30)

Reviewer: independent session (review only). Nothing in `nx/`, `deliver/`, `STATUS.md`, `HANDOFF.md` or memory was touched.
Nothing was sent to anyone. No NX was needed or started.

## What was reviewed

- **CAD: `deliver/CAD/CH-001_Chest.stl` = NX build `nx/outC7`**, frozen copy in `cad/` (sha256 `5c8bc67c…5995`, `cad/sha256.txt`).
  1 908 368 triangles; volume 659 180 mm3; bbox x ±166.89, y -275.60..113.88, z -140.13..2.53 (matches the scan).
  Note: `_finalize.json` lists a bbox of x ±189.5 / z +30.4. That box includes the helper bodies, not this solid.
- **outC8 finished while this review ran** (build PASS 00:29; its `.prt` was being finalized into `deliver/CAD` at 00:32,
  while the STL there was still outC7's). The main checks were re-run on `nx/outC8/chest_G.stl`: see the last
  section. **Every must-fix finding below is still present in outC8.**
- Scan: `share-Chest.stl`, main shell in the part frame (`work/mainf.npz`, 7 406 457 vertices, 14 733 629 triangles).
  Frame checked independently. 60 000 points from 20 000 raw STL triangles, transformed with `work/frame.json`, land on
  `mainf` with p50 4e-6 mm. 99.8 % fall within 0.01 mm; the rest are the scan crumbs (`data/r0_check.json`).

## 1. Two-way deviation (full resolution, every scan vertex, no sampling)

`r1_dev.py`: scan to CAD is the signed distance of all 7.41 M vertices (zones use the `an/dev2.py` rules). CAD to scan uses 3 M CAD
samples measured to the full-res scan.

| zone (scan->CAD, within 0.5 mm) | this review, all vertices | `work/dev2_C7.json` (3 M sample) | p50 mm (review / dev2) |
|---|---|---|---|
| whole part | **87.04 %** | 87.04 % | 0.091 / 0.091 |
| exterior skin | **96.20 %** (R 95.4, L 97.0) | 96.19 % | 0.063 / 0.063 |
| interior | **81.99 %** | 81.98 % | 0.123 / 0.124 |
| rim band (z > -6) | **84.42 %** | 84.47 % | 0.109 / 0.110 |
| shoulder flanges | **79.95 %** | 79.97 % | 0.080 / 0.080 |
| CAD->scan (unsigned) | p50 0.117, p95 2.18, 78.0 % within 0.5 | p50 0.117, p95 2.19 | |

**The numbers agree with `dev2_C7.json` to within ±0.05 points.** Area-weighted (per triangle), the whole part is 87.6 % within 0.5 mm.
CAD->scan signed: 10.4 % of the CAD surface stands > 0.3 mm outside the scan (extra) and 19.6 % lies > 0.3 mm inside the scan material (missing).

Clusters (> 0.3 mm, 0.8 mm voxels, both directions, `r2_clusters.py`): **587 "missing" clusters (83 700 mm2)
and 494 "extra" clusters (43 900 mm2)** of at least 3 mm2. They are ranked by volume = area x mean |d| in
[CLUSTERS.md](CLUSTERS.md), with crops for the top 90 plus 24 selected small high-peak clusters.

The CAD surface area is 422 600 mm2 against 354 600 mm2 for the scan (+19 %). The extra area is the risers of the 0.7 mm
stepped pads and recesses. It is a side effect of the method (and the 344 MB prt), not a deviation by itself.

## 2. Feature census (own detection on the scan, matched to the CAD)

Method: depth maps at 0.25 mm along 6 view rays, full-res scan, CAD STL (`r3_maps.py`). Through-openings, raised features and pits are
found as map components (`r6_census.py`). Left/right one-sidedness comes from own-mirror differences (`r7_sym.py`). Slot lean and text
relief are in `r10_measure.py`, thin CAD walls in `r8_thin.py`, filled sections in `r9_secfill.py`, and every finding was checked by eye in the crops.

| feature class | scan | CAD (outC7) | result |
|---|---|---|---|
| through-openings (Z) | 40 | 69 | Ø37.4 front hole, 4 upper-vent holes (±17.6, ±52.6) and 2 x 8 shoulder-vent slots + end holes all match (IoU 0.7-0.99, lean ±8° mirror-symmetric in both). Wrong: lower vent (15 parallel slots, F03), 2 mid-plane slots (F01/F02), slit under the cross rib (F01), holes beside the lower vent (±34.8, -209.9; 40-50 mm2), bottom notches (±47.2, -273.8; F06), pill hole (0, -190.7; F13), side holes (±120, -83; F09), hole (-58, -19.2; F10). Scan slits at (±59.6, -266) are missing in the CAD (F07). |
| bosses / posts with holes | shoulder-vent pair x2, upper-vent row of 8, y 12 rib ends x2, front floor (38, -46), side tubes x4, lower-side boss pairs, PCB board | see findings | 2 shoulder-vent bosses wrong (F04), 6-8 upper-row bosses missing or short (F10), 2 one-sided bosses missing (F11), front boss missing (F12), 4 side tubes undersized (F14) |
| ribs / gussets / webs | | | gussets missing at (±75, -233) and (±105.7, -150) (F15a); webs at the shoulder-vent bosses (F04); cross rib in the upper vent cut loose (F01); L front-floor T-rib broken (F12); 2 x 12 cross ribs in the neck channels missing (F24); thin window-frame lips on the lower sides missing (F15b) |
| fins / spikes / rails (Inner-type errors) | none | many | spikes between the shoulder-vent slots (F08) and the lower-vent slots (F03); saw-tooth fins at the bottom corners (F07); horn-shaped pad fragments at the neck clips (F23); extra rail along the oval edge (F20); slit cracks inside walls (F05) |
| clips / latches / hooks | R latch block, 2 bottom hooks, 2 hollow clip tabs, 2 neck clip receivers | | latch missing (F09), hooks cut flat (F06), tabs solid (F25), receivers rough (F23) |
| text / marks | T800 logo and glyph block (raised, front), "2001010021 9-00" (interior, below the PCB) | none | missing (F17) |
| L/R symmetry | one-sided: PCB board, latch (R), bosses (+17, 12) and (-65.9, 12.5), front boss (38, -46), lower-vent slot lean | mirror build + A features | the CAD mirrors the lower-vent slots and the PCB board; one-sided bosses missing; the shoulder-vent 2nd boss is modelled one-sided (L only) but it is two-sided in the scan |

## 3. Findings (ranked)

Severity key:
- **must fix**: a hole, crack or spike that is not in the part; a missing or wrong fastener or fit feature; or a visible exterior defect.
- **should fix**: a shape error that does not affect fit or appearance much.
- **acceptable**: method, print or scan effect.

Coordinates are in the part frame (x mirror normal, y toward the neck, z toward the open back, origin at the bore-centre height on the rim plane).
"Peak" is the cluster p99 |d|. Crops are CAD alone | scan alone | overlay (scan orange, CAD grey) | signed deviation. Sections are in `secs/`.

| id | sev | feature, location (mm) | size | peak / area / vol | cause (as far as visible) | fix suggestion (fits `nx/build.py`) | crops |
|---|---|---|---|---|---|---|---|
| F01 | **must** | **Mid-plane through-slot, upper vent box**, x -2.1..+2.1, y -34..-10.5, front wall z -131..-135. Also a **through-slit under the cross rib**, y -29.6..-27.5, x about -40..+40: the front wall under the rib is gone and only a 0.5 mm skin is left at y -29.5. | 4.2 x 23.5 mm slot + 2 x 80 mm slit | CAD opening 177 mm2, open from both sides | Stepped pads are kept ≥ 1.5-2 mm off the mid-plane (s31 mask x < -2), but the exterior recess (vent box, 0.7..13.3) cuts across the full width. Behind the recess there is no pad in \|x\| < 2.1 or under the rib root, so the cut goes through. | Give each pad level a mid-plane bridge: one C pad per level, the outline clipped to \|x\| ≤ 3 (or let the right-half loops run to x = -0.6 so Mirror + Unite fuses them). Under the cross rib, extend the rib-root pad outline by 1 mm on both sides. Re-run the opening census: no Z-through cells where the scan is closed. | `crops/F01_midslot_upper_front.png`, `F01_midslot_upper_inside.png`, `secs/midslot.png`, `secs/slit_lowside.png` (mid panel) |
| F02 | **must** | **Mid-plane through-slot, lower vent box**, x -2.3..+2.1, y -228..-198 (it swallows the centre vent slot) | 4.4 x 30 mm | CAD opening 120 mm2, visible from the front | as F01 | as F01 | `crops/F02_midslot_lower_front.png`, `secs/midslot.png` (panels 3-4) |
| F03 | **must** | **Lower vent slots mirrored**, x -36..+36, y -207..-199. The scan has 15 parallel slots, pitch 5.17 (x = -36.0 + 5.17 k), 7.3 x 1.7 mm, all leaning -24° from +y. The CAD mirrors the right 7 slots onto the left (lean +38° on the left half, IoU 0.07-0.2). The right slots read 8.9 x 2.6 at -38° in the through map. CAD spikes stand between the slots, with 2 extra holes beside the row (±34.8, -209.9) and the vent-box floor shape is wrong (CAD 2 mm proud along the slot strip, 0.5-2 mm too deep below it). | 15 slots | k9/k11 extra 1 900 mm2 each, peak 5.5; k3 4 036 mm2, peak 6.2 | `work/through.json` slots are kind "R" and get mirrored; the recess terraces leave remnants around the slot cuts | Cut the 15 slots after the Mirror (stage G, kind C) as one linear pattern: 1.7 x 7.3, lean -24°, pitch 5.17, first at x -36.0. Delete the 2 side holes. Rebuild the vent pocket as one recess with a sloped floor (see F08), not 0.7 mm terraces. | `crops/F02_midslot_lower_front.png`, `data/diff_ZE_lowvent.png`, `crops/k009_extra.png`, `k011_extra.png`, `k003_missing.png` |
| F04 | **must** | **Shoulder-vent boss pairs** (both sides): the scan has 2 tubular bosses with bores at x ≈ ±80 and ±94, y ≈ 84, z 0..-45, joined by a web, plus a web up to the rim wall. CAD R: only the outer boss; the inner boss and both webs are missing. CAD L: the inner post is a solid keyhole-topped cylinder with no bore (a one-sided A feature) and the webs are missing. | boss OD ≈ 7, bore ≈ 3, length ≈ 40 | R k2: 2 207 mm2, peak **13.1**, vol 8 054; L k5: 2 688 mm2, peak 3.2; k108/k111 peak 5.0 | The 2nd boss was read as a one-sided plateau without a hole; the webs were never modelled | Model the inner boss as an R plateau (cylinder) with its hole, mirrored. Add the boss-to-boss web and the boss-to-rim web as R pads. Delete the one-sided A post. | `crops/F04_shvent_boss_pair_R.png`, `_L.png`, `k002_missing.png`, `k005_missing.png`, `k286_extra.png`, `secs/rimslit_upper.png` |
| F05 | **must** | **Slit cracks inside the CAD walls**, 0.1-0.5 mm wide, 10-25 mm deep, running down from the rim: 4-6 per side in the lower side walls (x ±105..±133, y -135..-240), more at the shoulder vents, the neck (±49, 80), the side scoops (±119, -117), the bottom corners and under the upper-vent cross rib. The deviation statistics do not show them. | about 30 clusters > 50 mm2; 3 500 mm2 of "thin" CAD wall per lower side | CAD wall thickness < 0.6 mm where the scan wall is 4-6 mm (`data/thin.json`) | Pad / tongue / bump loops lie 0.1-0.5 mm from the wall or from each other (SEP rule). The prism-intersect pieces touch the wall only at their base, so a gap is left between piece and wall. | Offset every pad, bump and tongue loop ≥ 0.6 mm into the wall it meets (overlap) before the Shell intersect, or unite with an overlap tool. Gate: re-run `r8_thin.py` (needs 0 clusters > 5 mm2 where the scan wall is ≥ 1.2 mm) and check plan sections at z -6 and -15 (`secs/rimslit_R.png`). | `secs/rimslit_R.png`, `secs/rimslit_upper.png`, `secs/slit_lowside.png`, `crops/F05_wallcracks_R.png`, `_L.png`, `k051_extra.png`, `k084_extra.png` |
| F06 | **must** | **Bottom edge snap hooks** at x ±47, y -275..-265. The scan has a hook-shaped lug rising to z -67. The CAD cuts it flat at z -77 and adds a through notch (±47.2, -273.8) that the scan does not have. | 21 mm2 notch each; hook about 8 x 10 x 10 | k49/k50 peak 5.3-5.5; k41 | the stage A "bottom edge cut + notch" params; the hook was never modelled | Remove the notch cut. Add the hook as a plateau / extrusion of its plan outline from the scan, top z -67 (sloped), and cut the bottom-edge block after it, leaving the hook. | `crops/F06_bottom_hook_R.png`, `k049_missing.png`, `k050_missing.png`, `k041_extra.png`, `secs/flange_bottom.png` (panel 3) |
| F07 | **must** | **Bottom corner posts** (±57..60, y -272..-259). The CAD has a saw-tooth fin (stepped-pad remnant) at y -264..-260, z -46..-62, and its wall sits at y -270..-265. The scan has a thin wall at y -259 and through slits at (±59.6, -266), 2.1 mm2 each; the CAD has neither slit (the R slit is A in `through.json` and gets filled again, the L slit is missing). | | k23/k25 extra ≈ 1 000 mm2 each, peak 6.0; k210/k220/k256 fins | stepped pads on a near-vertical double wall; slit listed only as R | Model the corner as 2 walls (plan outlines from a z -45 section) with no pads there. Cut both slits as C or mirrored openings at the end of G. | `crops/F07_bottom_corner_R.png`, `_L.png`, `k023_extra.png`, `k025_extra.png`, `k256_extra.png`, `secs/flange_bottom.png` (panel 4) |
| F08 | **must** | **Spikes between the shoulder-vent slots and terraced exterior pockets** (both sides, ±104, 73, z -47). The CAD has tapering fins up to 5.7 mm between the slots and 0.7 mm contour steps on the visible pocket walls. The scan pocket is smooth with a filleted edge. | 2 x 8 slots | k15/k16 extra 2 350 mm2 each, peak 5.7; k263 | Exterior recess levels (0.7 mm) interact with the slot cuts; the terraces are on a visible face | Make each vent pocket one recess body: offset the skin inward by the measured floor depth (one Shell slab, as `post_recess.py` already does) with a single drafted wall. Cut the slots after it, through the full pocket depth. No terraces on exterior faces. | `crops/F08_shvent_spikes_R.png`, `k015_extra.png`, `k016_extra.png`, `k263_missing.png` |
| F09 | **must** | **R side latch block** at (122, -80, -68), one-sided. The scan has a rectangular latch / clip block with cross slots and a boss with a hole below it. The CAD has a through hole (22.9 mm2 at (119.8, -83.5)) and no latch. On the L side the scan has only a boss and rib, but the CAD has 2 extra holes (-120, -86.3) and (-118.9, -80.4). | about 12 x 16 x 10 block | k8 791 mm2, peak 9.9, vol 2 400; k56; k35/k103 (L) | one-sided feature not modelled; hole entries mirrored | Add the latch as an A plateau (R) with its slots. Remove the side-hole openings on both sides and add the L rib as an A pad. outC8 closed the R hole, but the latch is still missing. | `crops/F09_latch_R.png`, `k008_missing.png`, `k056_extra.png`, `k035_missing.png` |
| F10 | **must** | **Upper-vent boss row** at y -19, z -128..-123. The scan has 8 bosses with holes: ±17.5, ±35 and an end pair at about ±53 / ±59..65. The CAD has through holes at ±17.6 / ±52.6 with no boss (flat), nothing at ±35 and an extra hole at (-58, -19.2). The bosses are 4-5 mm short or absent. | boss OD ≈ 6, height ≈ 5 | k64/k69 peak 5.2; k80/k81 peak 4.7; k70/k85 | treated as holes only; bosses lost under the vent recess | Add the bosses as plateaus (top z from the scan, about -123) with their holes, cut after the recess. Remove the (-58, -19.2) hole. | `crops/F10_upper_boss_row.png`, `k064_missing.png`, `k080_missing.png`, `k085_missing.png` |
| F11 | **must** | **One-sided bosses on the y 12 rib**: (-65.9, 12.5, -116), a boss with a hole and about 12 radial gussets, and (+17, 12), a boss. Both are missing. | OD ≈ 8 | k90 peak 4.0; sym map | one-sided A features not in the A list | Add both as A plateaus with their holes; the gussets can be one small pad ring. | `crops/F11_y12_bosses.png`, `k090_missing.png`, `data/sym_ZI.png` |
| F12 | **must** | **Front-floor boss** (38, -46, -128) on a rectangular pad at the end of a T-rib (one-sided R): missing. On the L side the T-rib (-44.6, -46) is broken into separate bars. | OD ≈ 7, height ≈ 7 | k26 399 mm2, peak 7.2; k37 peak 3.4; k47 | one-sided; the L rib is split by pad outlines | Add the boss and pad as A features. Make the L rib one plateau from the wall to the boss. | `crops/k026_missing.png`, `k037_missing.png`, `k047_extra.png` |
| F13 | **must** | **Extra CAD hole** at (0, -190.7), a pill shape through the front face on the mid-plane. The scan is solid there (only a shallow groove), and the hole is visible from the front. | 4.3 x 2.2 mm (8 mm2) | k352 | probably the same mid-plane pad gap as F01 under a local recess | Fill: the mid-plane bridge from F01 fixes it; otherwise add a C pad. | `crops/F13_hole_y190.png`, `k352_missing.png` |
| F14 | **must** | **Side tubes undersized** (4 bullet-shaped bosses with bores along the shoulder side walls: (±147..157, 62, -20) and (±157, -63, -18)). The scan OD is 1.5-4.5 mm larger. The CAD tube is a thin grooved "rail" and the wall around it is 1-1.5 mm too thick; the tube ends near the rim have thin sliver fins. | 4 tubes, about 40 mm long | k17/k19/k20/k36/k55 peak 4.4-4.5; k43/k44/k60 extra 2.3; k209/k388/k614 peak 3-4.6 | built from narrow pad / plateau outlines, not as cylinders | Model each tube as a cylinder (axis + OD fitted to the scan) plus a hemispherical or bullet end, united, then cut the bore. Remove the pads under it. | `crops/k017_missing.png`, `k019_missing.png`, `k043_extra.png`, `k209_extra.png`, `k614_extra.png` |
| F15a | **must** | **Lower-side gussets and pins**: gussets missing at the boss + hole pairs (±75, -233, -69) (k38/k39 peak 4.6) and at (±105.7, -150, -61) (k30/k33 peak 4.4); the tube roots (±105.8, -150) are not blended (k31/k32 peak 3.3); small pins on the boss pairs at (±88, -243) are missing (k1/k79/k83). | | see crops | pads do not resolve thin ribs | Add the gussets as rib plateaus (plan outline + sloped top) and the pins as cylinders. | `crops/k038_missing.png`, `k030_missing.png`, `k031_missing.png`, `k083_missing.png` |
| F18 | **must** | **PCB dummy board** (x -45..+45, y -245..-200) is one-sided in the scan but mirrored in the CAD. Missing: a tall cylinder L (-21.6, -233, Ø ≈ 10, peak **10.2**), 3 tall cylinders R (16, -229, peak 9.1), boss rings with holes, and the bar under the slot row. Extra: the R connector body (35, -224, peak 6.6) and the mirrored circles / recesses on the L half. | | k18, k170/k173, k27, k93, k9/k11 | the board relief was treated as symmetric | Rebuild the board as A features from the scan (plateaus with tops), nothing mirrored. If the client does not need the dummy relief, ask; but it must not be a mirror. | `crops/k003_missing.png`, `k018_missing.png`, `k170_missing.png`, `k093_extra.png`, `k027_extra.png` |
| F28 | **must** | **Rim ledge on the lower side walls** (both sides, y -160..-235, z 0..-15). At z -6 the scan inner wall stands 3-6 mm inboard of the CAD (a ledge / lip), and at z -15 a frame rib runs inward. This is most of the rim-zone p95 (2.6 mm). | about 75 mm long per side | inside k0 (12 026 mm2, peak 10.2) and k1/k7/k14 | rim tongue / lip pads too narrow | Add the ledge as a rim pad (plan outline from a z -6 section, top at the rim) overlapping the wall (see F05). | `secs/rimslit_R.png`, `crops/k014_missing.png`, `k000_missing.png` |
| F15b | should | **Lower-side pocket windows**: thin raised frame lips (≈ 1 wide, 0.5-1 tall) round the rounded-rectangle windows are missing, and the window floors are 1-1.5 mm off (CAD too thick inside, too thin outside) | both sides, x ±60..±130, y -140..-265 | k0 / k1 / k7 / k63 / k65 / k71 / k74 / k76 / k86 | stepped pads at 0.7 mm cannot form 1 mm lips | Model the frames as rib loops (plan outline + constant height) and the floors as one level per window. | `crops/k000_missing.png`, `k063_extra.png`, `k071_extra.png` |
| F17 | should | **Text / marks missing**: raised "T800" logo (x -25..+33, y -10..+5, about 0.3-0.5 mm), the raised glyph block (x -105..-70, y 15..40, about 0.2-0.3 mm), and the interior text "2001010021 9-00" (y -255..-245, about 0.3 mm). | | relief p50 0.46 (T800) | not modelled | Ask the client whether the marks belong in the CAD; if yes, NX Text curves + extrude 0.3-0.5 on the skin (G stage, after the recesses). | `crops/F17_text_T800.png`, `F17_text_glyphs.png`, `data/diff_ZE_text.png`, `data/text_inner.png` |
| F20 | should | **Oval racetrack recess**: the CAD step is about 1 mm off (blue outer ring, red inner strips at x ±35, y -60..-150). There is an extra CAD rail along the oval edge (±38.4, -114, 52 mm long, peak 2.3), the kind of wrong rail found on the Inner, and the arc rib is offset (k47/k75). | | k28 1 294 mm2, peak 1.9; k94/k96 | panel outline fit | Refit the racetrack outline from a z section and delete the rail pads at ±38. | `crops/k028_extra.png`, `k094_extra.png`, `k096_extra.png`, `k075_extra.png` |
| F21 | should | **Side-scoop rails** (±112..120, -110..-120): the rail is offset 1-1.5 mm laterally and the end block is missing | | k34/k82/k101/k106/k68 peak 2.4-4.4 | pad outlines | Model the rail as one plateau (outline + top) with its end block. | `crops/k034_missing.png`, `k101_extra.png`, `k106_extra.png` |
| F22 | should | **Shoulder-top interior corners** (±150, 75..90): CAD wall too thick, mean 1.4 mm, up to 2.6 | 1 600 mm2 per side | k10/k12 | pad level too high | Lower or remove the pad level there. | `crops/k010_extra.png`, `k012_extra.png` |
| F23 | should | **Neck clip receivers** (±49..57, 61..66): the CAD has horn-shaped pad fragments on both sides of each receiver (fin-like) and one side wall is missing | | k126/k132 peak 3.4; k53/k62 | pad fragments | Remove the fragments (raise AMIN or mask the receiver footprint) and add the side wall as a plateau. | `crops/k126_missing.png`, `k053_missing.png` |
| F24 | should | **Neck channels with cross ribs** (±70, 37, -97): about 12 small cross ribs in each channel are missing (the CAD channel is plain) | 2 x 12 ribs | k73/k78 peak 3.2 | below the pad resolution | Add one rib, patterned; or confirm with the client that they are only grip texture. | `crops/k073_missing.png`, `k078_missing.png` |
| F25 | should | **Clip tabs beside the Ø37 hole** (±33, -126): hollow box tabs with windows in the scan, solid blocks in the CAD | | k139/k202 peak 3.9-4.8 | plateau without a pocket | Pocket the tab (shell or cut) to the scan's wall thickness. | `crops/k139_missing.png` |
| F19 | should | **Arc ledge above the circle** in the upper vent box (y -35..-40, x -20..+20): a ≈ 1 mm ledge is missing | | k6/k46 | | Add an arc pad. | `crops/k006_missing.png`, `k046_extra.png` |
| F26 | should | **Shoulder flange**: the outer seat faces are fine (median +0.05 R / -0.05 L), but the flange is 4.6 thick where the scan reads about 4.3 (inner face median -0.2 / -0.3, p10 -1.3). The raised rings round the shoulder-lug holes (±150, 63) are missing. | | `data/flange.json`; k24/k227 | | Set flange thickness 4.3-4.4 and add the lug rings. | `crops/k024_missing.png`, `k227_extra.png` |
| F27 | should | **Step lines on the exterior lower side panels**: the CAD shows curved 0.3-0.7 mm step edges (recess / groove terrace edges) that the scan does not have | both lower panels | k4/k13 | exterior recess levels follow the print warp | Keep exterior recess levels off the lower side panels (the warp is not a feature). | `crops/k004_missing.png`, `k013_extra.png` |
| A1 | acceptable | Lower side panel warp, R +0.5..0.8 / L -0.5..-0.85 (known; symmetric model) | | k4/k13/k21 | print warp | none | |
| A2 | acceptable | Stepped interior pads, step 0.7 mm (≤ 0.35 mm error on thickness). The step height is right for the scan wherever the pads do not create fins or slits (F05/F07/F08/F23). | | | method | none | |
| A3 | acceptable | Scan shards beside the side wall pockets (±134, -103), support or print remnants, not part geometry | | k72/k77 | scan | do not model | |
| A4 | acceptable | 19 two-triangle zero-area shells in the NX STL (tessellation residue, e.g. (-46.15, -45.4, z -127..-132)) | | `data/thin.json` stray_shells | export | none (check `stepcheck` stays 1 solid) | |

**Count: 17 must fix (F01-F14, F15a, F18, F28), 11 should fix, 4 acceptable.**

## 4. outC8 (finished during this review): what changed

Re-run on `nx/outC8/chest_G.stl` (`data_C8/`, `cad_C8/sha256.txt`). Zones: whole **87.84 %** (p50 0.090), skin 96.22 %, interior 83.27 %,
rim 86.24 %, shoulder 79.96 %. CAD area 432 500 mm2.

- Still present: F01 / F02 (CAD openings 158.6 mm2 at (0.7, -24.6) and 119.9 mm2 at (0, -212.8); section `secs/C8_check.png`), F03 (left
  lower-vent slots lean +36..+40°), F05 (same slits at y -207), F06 notches (±47.2, -273.8), F13 (0, -190.9), the side holes (±34, -209)
  and (-58, -19.1), F04 (R k2-equivalent 2 505 mm2, peak 11.3), F09 (latch 675 mm2, peak 9.7), F12, F11, F14, F08, F18, F10, F06 hook, F07.
- Changed: the R side hole at (119.8, -83.5) is closed. Rim zone +1.8 points, interior +1.3 points.

## 5. Reproduce

Python `C:\Users\marya\.venvs\cadgenbench\Scripts\python.exe`, run from this folder. `RV_CAD=<stl> RV_DATA=<dir>` reviews another build
(`run_c8.sh`).

`r0_check.py` (CAD + frame) -> `r1_dev.py` (two-way, zones) -> `r2_clusters.py 0.3 3` -> `r3_maps.py` (6 depth maps) -> `r4_diffmaps.py`
-> `r6_census.py` -> `r7_sym.py ZI` -> `r8_thin.py` (slits / fins) -> `r10_measure.py` (slot lean, text) -> `r11_flange.py`
-> `r5_crops.py clusters 0-89` / `r5_crops.py views views.json` -> `r9_secfill.py <name> <axis> <v> <c0> <c1> <half> ...` -> `r12_table.py`.

The `i9*.py` files are the unmodified copies of the Inner tools that these scripts were adapted from.
