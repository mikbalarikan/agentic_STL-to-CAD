"""Crops per cluster / per named view: CAD alone | scan alone | overlay (scan orange, CAD grey) | signed scan deviation.
Style of part 2 i91_crops.py with CROP_SPLIT=1, plus the deviation panel. Full-res scan (main shell, part frame).
usage: r5_crops.py clusters <ids e.g. 0-40 or 3,7> [margin]     -> crops/k###_<sign>.png
       r5_crops.py views <json [{name, ctr, half, dir, up, title}]>  -> crops/<name>.png"""
import sys, os, json
import numpy as np, pyvista as pv, open3d as o3d
import matplotlib.image as mpimg
from rc import CAD, D, RV, load, read_stl
OUT = os.path.join(RV, "crops"); os.makedirs(OUT, exist_ok=True)
ORANGE, GREY = "#f2a11f", "#a7acb2"
v, f = load()
SC = np.empty((len(f), 3), np.float32)
for i in range(0, len(f), 2000000):
    SC[i:i + 2000000] = (v[f[i:i + 2000000, 0]] + v[f[i:i + 2000000, 1]] + v[f[i:i + 2000000, 2]]) / 3
C = read_stl(CAD); CC = C.mean(1)
cm = o3d.io.read_triangle_mesh(CAD)
rs = o3d.t.geometry.RaycastingScene(); rs.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))


def crop_scan(lo, hi):
    m = np.flatnonzero(np.all((SC >= lo) & (SC <= hi), axis=1))
    ff = f[m]; u, inv = np.unique(ff, return_inverse=True)
    return pv.PolyData(v[u], np.c_[np.full(len(m), 3), inv.reshape(-1, 3)].ravel())


def crop_cad(lo, hi):
    m = np.all((CC >= lo) & (CC <= hi), axis=1)
    t = C[m].reshape(-1, 3)
    return pv.PolyData(t.astype(float), np.c_[np.full(m.sum(), 3), np.arange(3 * m.sum()).reshape(-1, 3)].ravel()).clean(tolerance=1e-6)


def render(name, ctr, half, d, up, title=""):
    ctr = np.asarray(ctr, float); half = np.asarray(half, float); lo, hi = ctr - half, ctr + half
    ms, mc = crop_scan(lo, hi), crop_cad(lo, hi)
    if ms.n_points == 0 and mc.n_points == 0:
        return
    if ms.n_points:
        ms["dev"] = rs.compute_signed_distance(o3d.core.Tensor(np.asarray(ms.points, np.float32))).numpy()
    d = np.asarray(d, float); d /= np.linalg.norm(d)
    R = float(np.max(half)) * 3.6

    def panel(items, label):
        p = pv.Plotter(off_screen=True, window_size=(760, 730)); p.set_background("white")
        for m_, kw in items:
            if m_.n_points:
                p.add_mesh(m_, **kw)
        p.add_text(label, font_size=9, color="black")
        p.camera_position = [tuple(ctr + d * R), tuple(ctr), tuple(up)]; p.camera.view_angle = 30
        img = p.screenshot(None, return_img=True); p.close(); return img
    gk = dict(color=GREY, smooth_shading=False, ambient=0.25, diffuse=0.75, specular=0.2)
    ok_ = dict(color=ORANGE, smooth_shading=False, ambient=0.25, diffuse=0.75)
    imgs = [panel([(mc, gk)], f"{title}\nCAD alone"), panel([(ms, ok_)], "scan alone"),
            panel([(mc, gk), (ms, ok_)], "overlay: scan orange, CAD grey"),
            panel([(mc, dict(color="#d0d0d0", opacity=0.3)),
                   (ms, dict(scalars="dev", cmap="coolwarm", clim=(-1.5, 1.5), show_scalar_bar=True,
                             scalar_bar_args=dict(title="scan-CAD mm (+ CAD missing)", fmt="%.1f", n_labels=5)))], "signed deviation on the scan")]
    mpimg.imsave(os.path.join(OUT, f"{name}.png"), np.vstack([np.hstack(imgs[:2]), np.hstack(imgs[2:])]))


if sys.argv[1] == "views":
    for v_ in json.load(open(sys.argv[2])):
        render(v_["name"], v_["ctr"], v_["half"], v_["dir"], v_.get("up", (0, 1, 0)), v_.get("title", v_["name"]))
        print("ok", v_["name"], flush=True)
    sys.exit(0)
cl = json.load(open(os.path.join(D, "clusters.json")))["clusters"]
MARG = float(sys.argv[3]) if len(sys.argv) > 3 else 10.0
ids = []
for p_ in sys.argv[2].split(","):
    if "-" in p_:
        a, b = p_.split("-"); ids += list(range(int(a), int(b) + 1))
    else:
        ids.append(int(p_))
for i in ids:
    c = cl[i]
    nv = np.asarray(c["n_view"], float)
    dd = nv / np.linalg.norm(nv) if np.linalg.norm(nv) > 0.3 else np.array([0.0, 0.0, 1.0])
    if c["zone"]["skin"] < 0.5:
        dd = dd + np.array([0.0, 0.0, 0.5])      # interior: look a little from the open side (+Z)
    up = (0, 1, 0) if abs(dd[1]) < 0.8 * np.linalg.norm(dd) else (0, 0, 1)
    half = np.clip((np.asarray(c["hi"]) - np.asarray(c["lo"])) / 2 + MARG, 8, 55)
    ctr = (np.asarray(c["hi"]) + np.asarray(c["lo"])) / 2
    t = f"k{i} {c['sign']} {c['side']} {c['area']:.0f}mm2 peak {c['peak']} vol {c['vol']:.0f} @({ctr[0]:.0f},{ctr[1]:.0f},{ctr[2]:.0f})"
    render(f"k{i:03d}_{c['sign']}", ctr, half, dd, up, t)
    print("ok", i, flush=True)
