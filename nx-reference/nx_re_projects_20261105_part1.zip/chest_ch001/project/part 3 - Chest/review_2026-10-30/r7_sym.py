"""Left/right symmetry census on the ZI / ZE depth maps: own-mirror difference of the scan and of the CAD.
asym(x, y) = h(x, y) - h(-x, y) with h = height toward the viewer (+ = this side stands higher / has more material).
A feature present on one side only shows as +/- in the scan map; the CAD (mirror build) shows only its one-sided adds.
Panels: scan asym | CAD asym | scan asym - CAD asym (one-sidedness the CAD does not reproduce), right half only (x > 0;
red = right side higher, blue = left side higher). Writes data/sym_<view>[_name].png and data/sym_<view>_comps.json"""
import os, sys, json
import numpy as np
from scipy import ndimage
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from rc import D
M = np.load(os.path.join(D, "maps.npz")); xs, ys, C = M["xs"], M["ys"], float(M["cell"])
SG = {"ZI": 1, "ZE": -1}            # height toward the viewer
vw = sys.argv[1] if len(sys.argv) > 1 else "ZI"
win = [float(t) for t in sys.argv[2:6]] if len(sys.argv) > 5 else None
name = sys.argv[6] if len(sys.argv) > 6 else ""
out = {}
for nm in ("scan", "cad"):
    h = SG[vw] * M[f"{nm}_{vw}"]
    hm = h[:, ::-1]
    a = h - hm
    a[np.isnan(h) & ~np.isnan(hm)] = -9; a[~np.isnan(h) & np.isnan(hm)] = 9      # open on one side only
    out[nm] = a
dd = out["scan"] - out["cad"]
xr = xs > 0
ext = [0, xs[-1], ys[0], ys[-1]]
if not win:
    win = [0, 170, ys[0], ys[-1]]
j0, j1 = np.searchsorted(xs, win[0]), np.searchsorted(xs, win[1]); i0, i1 = np.searchsorted(ys, win[2]), np.searchsorted(ys, win[3])
ext = [xs[j0], xs[j1 - 1], ys[i0], ys[i1 - 1]]
W_, H_ = ext[1] - ext[0], ext[3] - ext[2]; sc = 13 / max(W_, H_)
fig, ax = plt.subplots(1, 3, figsize=(3 * W_ * sc + 2, H_ * sc + 1))
for a_, (t, m) in zip(ax, (("scan: right minus mirrored left", out["scan"]), ("CAD: right minus mirrored left", out["cad"]),
                           ("scan asym - CAD asym (one-sidedness the CAD lacks)", dd))):
    im = a_.imshow(np.clip(m[i0:i1, j0:j1], -2, 2), origin="lower", extent=ext, cmap="seismic", vmin=-2, vmax=2, interpolation="nearest")
    a_.set_title(f"{vw} {name}: {t}\nred = right (+x) side has more / stands higher", fontsize=8)
    g = 10 if max(W_, H_) > 100 else 5
    a_.set_xticks(np.arange(np.ceil(ext[0] / g) * g, ext[1], g)); a_.set_yticks(np.arange(np.ceil(ext[2] / g) * g, ext[3], g))
    a_.tick_params(labelsize=6); a_.grid(lw=0.3, color="k", alpha=0.3)
fig.tight_layout(); fig.savefig(os.path.join(D, f"sym_{vw}{'_' + name if name else ''}.png"), dpi=70); plt.close(fig)
# components of one-sidedness (|scan asym - CAD asym| > 1 mm, right-half coordinates; sign tells which side)
if not name:
    res = []
    for sgn in (1, -1):
        m = (sgn * dd > 1.0) & xr[None, :]
        m = ndimage.binary_opening(m, np.ones((3, 3)))
        lab, n = ndimage.label(m)
        for k, sl in enumerate(ndimage.find_objects(lab), 1):
            mm = lab[sl] == k
            if mm.sum() * C * C < 4:
                continue
            X, Y = np.meshgrid(xs[sl[1]], ys[sl[0]])
            res.append(dict(side_more="R" if sgn > 0 else "L", area=round(float(mm.sum() * C * C), 1),
                            ctr_right=[round(float(X[mm].mean()), 1), round(float(Y[mm].mean()), 1)],
                            lo=[round(float(X[mm].min()), 1), round(float(Y[mm].min()), 1)], hi=[round(float(X[mm].max()), 1), round(float(Y[mm].max()), 1)],
                            peak=round(float(np.abs(dd[sl][mm]).max()), 2)))
    res.sort(key=lambda r: -r["area"])
    json.dump(res, open(os.path.join(D, f"sym_{vw}_comps.json"), "w"), indent=1)
    for r in res[:60]:
        print(r)
print("ok")
