"""Independent two-way deviation, FULL-resolution scan main shell vs the frozen CAD STL (part frame, no sampling of the scan).
scan->CAD: signed distance of every scan vertex (zone stats, same zone rules as an/dev2.py) and of every scan triangle
           centroid (area-weighted, for clusters). + = scan outside the CAD = CAD lacks material.
CAD->scan: 3 M uniform CAD surface samples, closest point on the full-res scan (y tiles with 12 mm margin to bound
           memory), signed by the scan triangle normal. + = CAD point outside the scan = CAD has extra material.
Writes data/r1_*.npy and data/r1_dev.json."""
import os, json, time
import numpy as np, open3d as o3d
from rc import CAD, D, load, read_stl, weld
from zones import zone_labels
t0 = time.time()
lg = lambda *a: print(f"[{time.time()-t0:6.0f}s]", *a, flush=True)
T = read_stl(CAD)
cv, cf = weld(T); del T
cm = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(cv), o3d.utility.Vector3iVector(cf))
cm.compute_triangle_normals()
cs = o3d.t.geometry.RaycastingScene(); cs.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
v, f = load()
lg("loaded scan", len(v), len(f))


def sdist(P, ch=1500000):
    out = np.empty(len(P), np.float32)
    for i in range(0, len(P), ch):
        out[i:i + ch] = cs.compute_signed_distance(o3d.core.Tensor(np.ascontiguousarray(P[i:i + ch], np.float32)), nsamples=3).numpy()
    return out


dv = sdist(v); lg("vertex sdist")
np.save(os.path.join(D, "r1_dvert.npy"), dv)
zl = np.empty(len(v), np.int8)
for i in range(0, len(v), 1000000):
    zl[i:i + 1000000] = zone_labels(v[i:i + 1000000])
np.save(os.path.join(D, "r1_zone.npy"), zl); lg("zones")
# triangle centroids / areas / normals
cen = np.empty((len(f), 3), np.float32); ar = np.empty(len(f), np.float32); nrm = np.empty((len(f), 3), np.float32)
for i in range(0, len(f), 2000000):
    a, b, c = v[f[i:i + 2000000, 0]], v[f[i:i + 2000000, 1]], v[f[i:i + 2000000, 2]]
    n = np.cross(b - a, c - a); s = np.linalg.norm(n, axis=1)
    cen[i:i + 2000000] = (a + b + c) / 3; ar[i:i + 2000000] = s / 2; nrm[i:i + 2000000] = n / np.maximum(s, 1e-12)[:, None]
dt = sdist(cen); lg("centroid sdist")
np.save(os.path.join(D, "r1_dtri.npy"), dt); np.save(os.path.join(D, "r1_atri.npy"), ar)
# CAD -> scan
NS = 3000000
pc = cm.sample_points_uniformly(NS, use_triangle_normal=True)
Q = np.asarray(pc.points, np.float32); QN = np.asarray(pc.normals, np.float32)
cad_area = cm.get_surface_area()
dq = np.full(NS, np.nan, np.float32); sg = np.zeros(NS, np.float32); agree_n = [0, 0]
edges = np.linspace(v[:, 1].min() - 1, v[:, 1].max() + 1, 9)
cy = cen[:, 1]
for k in range(8):
    y0, y1 = edges[k], edges[k + 1]
    qm = (Q[:, 1] >= y0) & (Q[:, 1] < y1) if k < 7 else (Q[:, 1] >= y0)
    if k == 0: qm |= Q[:, 1] < y0
    tm = (cy > y0 - 12) & (cy < y1 + 12)
    ff = f[tm]
    used, inv = np.unique(ff, return_inverse=True)
    sm = o3d.t.geometry.TriangleMesh(o3d.core.Tensor(v[used].astype(np.float32)), o3d.core.Tensor(inv.reshape(-1, 3).astype(np.int32)))
    ss = o3d.t.geometry.RaycastingScene(); ss.add_triangles(sm)
    cp = ss.compute_closest_points(o3d.core.Tensor(Q[qm]))
    P = cp["points"].numpy(); pid = cp["primitive_ids"].numpy()
    nn = nrm[np.flatnonzero(tm)[pid]]
    dd = np.linalg.norm(Q[qm] - P, axis=1)
    dq[qm] = dd; sg[qm] = np.sign(np.einsum("ij,ij->i", Q[qm] - P, nn))
    near = dd < 0.05
    agree_n[0] += int((np.einsum("ij,ij->i", QN[qm][near], nn[near]) > 0).sum()); agree_n[1] += int(near.sum())
    del ss, sm, cp
    lg("tile", k, int(qm.sum()), int(tm.sum()))
agree = agree_n[0] / max(agree_n[1], 1)
lg("scan normal agreement with CAD normals", round(agree, 3))
if agree < 0.5:
    sg = -sg
dqs = dq * sg
np.save(os.path.join(D, "r1_cadpts.npy"), np.c_[Q, QN, dqs].astype(np.float32))


def st(x):
    ax = np.abs(x)
    return dict(n=int(len(x)), mean=round(float(x.mean()), 4), p50=round(float(np.percentile(ax, 50)), 4),
                p90=round(float(np.percentile(ax, 90)), 4), p95=round(float(np.percentile(ax, 95)), 4),
                p99=round(float(np.percentile(ax, 99)), 4), within_0p5=round(float((ax <= 0.5).mean()), 4),
                over_1=round(float((ax > 1).mean()), 4))


def sta(x, w):
    ax = np.abs(x); o = np.argsort(ax); cw = np.cumsum(w[o]) / w.sum()
    q = lambda p: round(float(ax[o][np.searchsorted(cw, p)]), 4)
    return dict(area=round(float(w.sum()), 1), p50=q(0.5), p95=q(0.95), within_0p5=round(float(w[ax <= 0.5].sum() / w.sum()), 4))


names = ["outer_skin", "shoulder", "rim", "interior"]
res = {"cad": CAD, "scan_vertices": int(len(v)), "scan_tris": int(len(f)), "cad_samples": NS, "cad_area": cad_area,
       "normal_agree": agree, "scan_to_cad_vertices": {"all": st(dv)}, "scan_to_cad_area_weighted": {"all": sta(dt, ar)}}
for z, nm in enumerate(names):
    res["scan_to_cad_vertices"][nm] = st(dv[zl == z])
res["scan_to_cad_vertices"]["outer_skin_right"] = st(dv[(zl == 0) & (v[:, 0] > 0)])
res["scan_to_cad_vertices"]["outer_skin_left"] = st(dv[(zl == 0) & (v[:, 0] < 0)])
res["cad_to_scan"] = {"all_unsigned": st(np.abs(dqs)), "extra_over_0p3_frac": round(float((dqs > 0.3).mean()), 4),
                      "inside_scan_over_0p3_frac": round(float((dqs < -0.3).mean()), 4)}
json.dump(res, open(os.path.join(D, "r1_dev.json"), "w"), indent=1)
print(json.dumps(res, indent=1)); lg("done")
