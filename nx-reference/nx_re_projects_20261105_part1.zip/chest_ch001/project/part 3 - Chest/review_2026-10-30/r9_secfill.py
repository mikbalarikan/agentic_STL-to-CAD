"""Filled plane sections: CAD solid filled grey (trimesh polygons), CAD outline black, scan outline orange.
usage: r9_secfill.py name axis value c0 c1 half [axis value c0 c1 half ...]  (c0, c1 = window centre in the 2 other axes)
-> secs/<name>.png"""
import sys, os
import numpy as np, trimesh
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import PathPatch
from matplotlib.path import Path
from rc import CAD, RV, read_stl, weld, load, section
name = sys.argv[1]; a = sys.argv[2:]
jobs = [(int("xyz".index(a[i])), float(a[i + 1]), float(a[i + 2]), float(a[i + 3]), float(a[i + 4])) for i in range(0, len(a), 5)]
T = read_stl(CAD); cv, cf = weld(T)
cm = trimesh.Trimesh(cv, cf, process=False)
v, f = load()
n = len(jobs); fig, axs = plt.subplots(1, n, figsize=(8 * n, 8), squeeze=False)
for ax, (axis, val, c0, c1, h) in zip(axs[0], jobs):
    other = [k for k in range(3) if k != axis]
    nrm = np.zeros(3); nrm[axis] = 1; org = np.zeros(3); org[axis] = val
    sl = cm.section(plane_origin=org, plane_normal=nrm)
    if sl is not None:
        segs = sl.discrete
        for s in segs:
            p = s[:, other]
            ax.fill(p[:, 0], p[:, 1], color="#bbbbbb", alpha=0.0)
        # even-odd fill of all loops together
        verts, codes = [], []
        for s in segs:
            p = s[:, other]
            verts += p.tolist(); codes += [Path.MOVETO] + [Path.LINETO] * (len(p) - 1)
        if verts:
            ax.add_patch(PathPatch(Path(verts, codes), facecolor="#c8c8c8", edgecolor="k", lw=0.6, fill=True))
    s = section(v, f, axis, val)[:, :, other]
    k = (np.abs(s[:, :, 0] - c0) < h).all(1) & (np.abs(s[:, :, 1] - c1) < h).all(1)
    ax.add_collection(LineCollection(s[k], colors="#e08a00", lw=1.6))
    ax.set_xlim(c0 - h, c0 + h); ax.set_ylim(c1 - h, c1 + h); ax.set_aspect("equal")
    ax.minorticks_on(); ax.grid(lw=0.3); ax.grid(which="minor", lw=0.1)
    ax.set_title(f"{'xyz'[axis]} = {val}  ({'xyz'[other[0]]} right, {'xyz'[other[1]]} up)  CAD solid grey, scan orange", fontsize=9)
fig.tight_layout(); fig.savefig(os.path.join(RV, "secs", f"{name}.png"), dpi=65)
print("ok", name)
