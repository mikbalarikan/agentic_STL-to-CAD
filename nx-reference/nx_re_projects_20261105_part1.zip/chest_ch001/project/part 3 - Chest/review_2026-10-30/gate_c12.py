"""Gates after the lead decisions of 2026-10-30 (session 4).  usage: gate_c12.py data_<tag> [data_<tag2> ...]
- zones (scan -> CAD within 0.5, all vertices) vs outC8: whole 87.8, rim 86.2, interior 83.3
- skin: outside the lower-side-panel warp box (|x| 80..140, y -260..-140; A1 print warp, F27 keeps the CAD smooth)
  at least outC8's value in the same mask (data_C8); the full-skin number is reported too
- CAD Z-through openings with no scan opening (census cad_open with scan None, area >= 2 mm2): must be 0
- r8_thin: CAD thin clusters >= 20 mm2 where the scan wall >= 1.2 mm: must be 0; smaller ones (> 5 mm2) counted"""
import os, sys, json
import numpy as np
from rc import load, RV
v, f = load(); del f
warp = (np.abs(v[:, 0]) >= 80) & (np.abs(v[:, 0]) <= 140) & (v[:, 1] >= -260) & (v[:, 1] <= -140)


def skin(D):
    dv = np.load(os.path.join(D, "r1_dvert.npy")); zl = np.load(os.path.join(D, "r1_zone.npy"))
    s = zl == 0
    return float((np.abs(dv[s & ~warp]) <= 0.5).mean()), float((np.abs(dv[s]) <= 0.5).mean()), float((np.abs(dv[s & warp]) <= 0.5).mean())


ref_skin = skin(os.path.join(RV, "data_C8"))
ref = {"all": 0.8784, "rim": 0.8624, "interior": 0.8327}     # outC8 exact
for D in sys.argv[1:]:
    print("=====", D)
    z = json.load(open(os.path.join(D, "r1_dev.json")))["scan_to_cad_vertices"]
    ok = True
    for k, lim in ref.items():
        w = z[k]["within_0p5"]; good = w >= lim - 1e-4; ok &= good
        print(f"  {k:9s} {100 * w:6.2f} % (outC8 {100 * lim:.2f})  {'OK' if good else 'WORSE'}")
    sm, sf, sw = skin(D); good = sm >= ref_skin[0] - 1e-4; ok &= good
    print(f"  skin outside warp box {100 * sm:6.2f} % (outC8 {100 * ref_skin[0]:.2f})  {'OK' if good else 'WORSE'}")
    print(f"  skin full            {100 * sf:6.2f} % (outC8 {100 * ref_skin[1]:.2f}); inside warp box {100 * sw:.2f} (outC8 {100 * ref_skin[2]:.2f})")
    print(f"  shoulder {100 * z['shoulder']['within_0p5']:.2f} %")
    c = json.load(open(os.path.join(D, "census.json")))
    extra = [o for o in c["cad_open"] if o.get("scan") is None and o["area"] >= 2.0]
    miss = [o for o in c["scan_open"] if o.get("cad") is None and o["area"] >= 2.0]
    print(f"  extra CAD Z-openings: {len(extra)}", [(o["ctr"], o["area"]) for o in extra])
    print(f"  scan openings missing in CAD: {len(miss)}", [(o["ctr"], o["area"]) for o in miss])
    if not os.path.exists(os.path.join(D, "thin.json")):
        print("  (no thin.json)"); continue
    t = json.load(open(os.path.join(D, "thin.json")))["thin"]
    b20 = [q for q in t if q["area"] >= 20 and q.get("t_scan_med", 0) >= 1.2]
    b5 = [q for q in t if 5 < q["area"] < 20 and q.get("t_scan_med", 0) >= 1.2]
    print(f"  thin clusters >= 20 mm2 (scan >= 1.2): {len(b20)}; 5..20 mm2: {len(b5)}")
    for q in sorted(b20, key=lambda q: -q["area"])[:12]:
        print("     ", q["area"], [round(x, 1) for x in q["ctr"]], "t_scan", q["t_scan_med"])
    print("GATES", "zones OK" if ok else "zones WORSE", "| openings", len(extra), "| thin>=20", len(b20))
