# CH-001 Chest Rev A: clean feature-based rebuild plan (session 5, 2026-10-30)

Follows the nx-modeling-strategy skill (section 0 plan form, class E scan rebuild, moulded-part feature order).
The user's rule: clean design-intent features only; whatever deviation results is accepted.

```
PART     CH-001 Chest, robot chest shell, printed (MJF/SLA-type), mm. One solid, symmetric about x = 0 except
         the one-sided features listed under A.
CLASS    E (rebuild from scan), built as native NX features in a journal (nx/build_clean.py).
MASTERS  wall_t = 3.25, shoulder_flange_t = 4.35, shoulder_angle = 4.5 deg, shoulder_xc = 161.65,
         shoulder_bore_d = 111.0 (Rev A expressions, nx/params.json); rib t = 1.5; pocket wall = 3.25;
         n_slots_lower = 15 (pitch 5.2), n_slots_shoulder = 8 (pitch 5.4).
DATUMS   Datum CSYS = part frame: YZ plane = mirror plane, XY plane = rim (parting) plane z = 0, origin at the
         height of the shoulder-bore centres. SHOULDER_R plane (4.5 deg), PANEL_EXT / PANEL_RECESS_FLOOR planes.
```

## Base (unchanged from Rev A outB12, stage A)
| # | feature | values |
|---|---|---|
| 1 | Through Curves skin (82 sections) -> block trimmed = right-half envelope | as Rev A |
| 2 | Trim by SHOULDER_R plane; neck cut (spline + lines, extrude) | as Rev A |
| 3 | Front panel pocket (racetrack, tilt 4.7 deg) + circle recess D63 | as Rev A |
| 4 | Extract envelope copy (clip body for all later features) | |
| 5 | **Shell** 3.25 inward, rim / mid-plane / neck faces open, shoulder face 4.35 (flange), panel 2.7, disc 1.95 | the one constant-wall feature |
| 6 | Front hole D37.4, shoulder bore D111, bottom edge y -275.6 + centre notch, shoulder-top notch D23.4 | as Rev A |

Rev A's 78 scan-traced plateau loops, its traced through-openings and its hole list are NOT used any more.

## Clean features (work/clean/make_spec.py -> work/clean/features.json, values rounded to 0.1 mm)
Order inside each stage: pocket wall bodies (united) -> ribs / bosses / blocks (united, clipped by the envelope so
they stand on the wall) -> pocket voids (cut) -> holes and bores -> slot Pattern Features.

**Stage F, right half (then Mirror Geometry + Unite = all R features are mirrored):**
| group | features | type / values |
|---|---|---|
| shoulder-vent pocket (F08) | 1 pocket | outline = circles (82.8, 79.4) R3.2 + (124.5, 63.0) R8.0 + tangents; floor = 2 planes (slot face + ramp); draft 3 deg; constant wall 3.25 behind it |
| shoulder-vent slots | 8 slots | slot 6.0 x 2.3, lean 12 deg (102 deg), Pattern Feature 8 x 5.4 along -14.2 deg (pocket edge) |
| F04 boss pair | 2 cones + 3 webs + 2 bores | cones (79.0, 87.7) D11.3 -> 8.1, top +0.2; (94.2, 84.2) D11.6 -> 8.2, top +2.5 (3 deg draft); web t3 top -23.9; 2 stems t2.4 to the rim; bores D3.4 |
| rib frame | rib x 65.8 (y 12.75..-111.5), rib y -20 (x 65.8..92), rib y -45.7 (29.5..65.8), rib y -91.5 (38.2..65.8) | t 1.5, flat tops -118.1 / -118.1 / -125.6 / -122.8 |
| upper-vent boss row (F10) | 4 bosses + 2 stems | x 17.5 / 35.0 / 52.7 / 58.0 at y -19.1, D6.0 / 5.5 / 6.0 / 6.0, tops -125.1 / -124.6 / -125.0 / -124.5; holes D2.7 through, D2.2 blind; stems t1.6 |
| rib-end boss | (38.2, -91.5) D6.4 top -122.8, hole D2.5 | |
| side tubes (F14) + lug rings (F26) | 2 cones + bores | (149.6, 63.3), (159.3, -64.1): D13.3 at z -50 -> D8.2 at the ring top +0.3; bores D3.4 |
| side tube (F15a) | 1 cone + bore | (105.8, -150.3) D12.6 -> 7.5, top -42.9; bore D2.5 |
| lower boss pair + gusset (F15a) | 2 bosses + web + gusset | (77.6, -222.3) D9.0 top -63.4 bore D3.4; (74.9, -233.0) D7.6 top -53.1 bore D2.5; web t4; gusset block 3.4 x 10.6 with a 30 deg top plane |
| lower T rib | 2 ribs | y -223.8 (x 37.5..74), x 59.2 (y -223.8..-246), t 1.5, top -77.2 |
| PCB mount bosses (F18) | 2 bosses | (31.7, -208.8), (31.7, -242.4) D6.0, top -92.5, pilot D2.2. The dummy board relief itself is left out |
| bottom corner post (F07) | 1 boss + bore | (61.1, -266.9) D8.6 to the rim; bore D3.0 at (59.3, -265.8) |
| bottom snap hooks (F06) | 2 blocks | x 38..46 and 45.5..51, y -275.6..-266, sloped tops = 2 planes each |
| clip tab (F25) | 1 block + hole | x 26..35.4, y -132.2..-119.6, top -106.8, R1 corners; hole D2.5 |
| neck clip receiver (F23) | ledge + cup + cup opening | ledge 22 x 8.5 top -80.9; cup 10 x 9 R2 top -71.6; opening 7 x 6 to z -74.9 |
| rim ledge (F28) | 2 blocks | straight inner edge (115.2, -187.5)-(125.7, -150) and (90.3, -240)-(99.7, -227.5), z -10..0, run into the wall |

**Stage G, across the mid-plane (C) and one-sided (A):**
| group | features | values |
|---|---|---|
| lower-vent pocket (F03) | 1 pocket | outline: top line y -198.5 (x +-37.5), chamfers to (+-45, -206), sides to -212, arc R73.1 through (0, -227.5); floor = slot face 49 deg + ramp 28.5 deg; draft 3 deg; wall 3.25 |
| lower-vent slots (F03) | 15 slots | 6.4 x 1.8, lean 24.5 deg (114.5 deg, same lean for all: not mirrored), Pattern Feature 15 x 5.2 from x -36.4 |
| cross ribs | rib y 12, rib y -28.6, neck rib y 34.8 | t 1.5, tops -118.1 / -123.2 / -92.8 |
| bottom lip | block x +-38, y -275.6..-265.5, top -82.5 | |
| one-sided bosses (F11) | (17.2, 12.0) D5.0, (-65.9, 12.2) D5.4, (-65.8, -20.0) D5.1 + hole D2.0 | tops -114.5 / -114.4 / -114.5 |
| front-floor boss (F12) | R: pad 9.4 x 9.8 R2 top -124.3 + tail block top -120.8 + boss D5.4 top -121.5 + hole D2.6; L: boss D6.4 top -125.6 + hole D2.6 | |
| tab (11, -171) | block 12.6 x 9.8 top -106.8, hole D2.5 | one-sided |
| R latch (F09) | root block 8.8 x 10 top -65 + boss D5.4 top -62.6 + hole D2.6 + 2 rails + tongue | rectangles |
| L latch-side boss | (-124.4, -80.4) D6.0 top -66.8, hole D2.5 | |

## Budget
Base 6 groups (about 20 history steps, Rev A). Clean features: 80 spec rows = about 60 solid features + 2 Pattern
Features + 2 pockets + Mirror. A moulded housing of this complexity is normally 40-80 steps; Rev A had 78 plateau
loops + 18 holes + 19 openings. Face-count target: near Rev A (about 1 700 faces, files near Rev A size).

## Left out on purpose (simplifications, README)
PCB dummy board relief (F18: only its 4 mount bosses are modelled), text and marks (F17, on hold), 0.5 mm stair
texture of the neck channel floor (F24), the 0.35 mm ring round the front hole, window-frame lips on the lower side
pockets (F15b), side scoop rail and end blocks (F21), interior V-ridge apex ribs (F09 ridge), hollow interior of the
clip tabs (F25), the slit of the corner posts (F07), the pin on the lower boss pair (F15a), small shoulder-top corner
pads (F22), scan-traced lug pads beside the side tubes, the shoulder-vent pocket scoop curvature (2 planes instead).

## Checks
One solid (body_ok), feature summary 0 failed, NX Examine via finalize, stepcheck (OCP), face count. Deviation
(an/dev2.py + review chain run_c10.sh) only to catch modelling errors: no openings where the scan is closed, no
slits / fins (r8_thin), no feature misplaced by more than about 1 mm. CAD-alone renders (an/render_cadonly.py):
open side, outside, isos and zooms must read as a clean designed part.

## As built (outD3, final) - changes against the table above
- F06 hooks: not two roof-plane blocks (sections showed wedges) but a lip block x 38..51, top -77.2 + a 2.0 mm barb
  rib along y -272.4 with a 1.33 mm/mm top plane (scan -74 at x 42, -66 at x 48); a 1.6 mm rail at y -265.7 (|x| < 38).
- F28: the two ledges are one rim band per side (inner face = 2 straight lines (88, -243)-(104.6, -221)-(126.6, -150),
  z -10..0), like the scan's z -1.5 / -5 sections.
- F07: the corner post cylinder gets a web block to the outer wall (no slit).
- F04 cones and side tubes start at z -60 (same draft law), so they reach the wall.
- Latch bores blind to z -75 (they broke through at -79.3).
- Added: neck ledge (|x| < 39, y 34.05..42, top -92.8); upper vent box exterior pocket (constant wall 3.25, right half
  with the outline 6 mm past the mid-plane, floor plane per half); arch rib R22.6 t 1.8 over the front hole + legs to
  the clip tabs (top -122.8); scoop band (flat top -19.7, straight inner edge).
- Result: 91 features, 1 solid, 762 faces (target was "near Rev A, about 1 700": well under it), prt 36 MB.
