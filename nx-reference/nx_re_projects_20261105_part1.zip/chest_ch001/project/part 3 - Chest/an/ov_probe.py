"""200 random scan vertices of the overlay STL -> work/overlay/probe_pts.json (sanity probe for nx/overlay.py).
usage: ov_probe.py scan.stl"""
import sys, os, json
import numpy as np, open3d as o3d
from common import W
v = np.asarray(o3d.io.read_triangle_mesh(sys.argv[1]).vertices)
P = v[np.random.default_rng(3).choice(len(v), 200, replace=False)]
json.dump(P.round(4).tolist(), open(os.path.join(W, "overlay", "probe_pts.json"), "w"))
print(len(P))
