import os
from PIL import Image
W = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest\work"
f = Image.open(os.path.join(W, "dev2_C5r_front.png")); f.crop((380, 850, 1120, 1300)).save(os.path.join(W, "rv", "why_p50_front_lower_panels.png"))
b = Image.open(os.path.join(W, "dev2_C5r_back.png")); b.crop((360, 860, 1140, 1300)).save(os.path.join(W, "rv", "why_p50_back_lower_sides.png"))
leg = f.crop((500, 1340, 1440, 1430)); leg.save(os.path.join(W, "rv", "why_p50_legend.png"))
print("ok")
