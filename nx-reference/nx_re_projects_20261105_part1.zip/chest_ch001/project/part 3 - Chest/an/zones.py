"""Zone labels for points (same rules as dev2.py). zone_labels(P) -> array of 'outer','shoulder','rim','inner' codes 0..3."""
import os, json
import numpy as np
from scipy.interpolate import BSpline
from common import W


def skin_dist(P):
    s = np.load(os.path.join(W, "skin_fit.npz"))
    tk, CF, C = s["tk"], s["CF"], s["C"]
    u = P - C; rr = np.linalg.norm(u, axis=1); u = u / rr[:, None]
    psi = np.arccos(np.clip(-u[:, 2], -1, 1)); sn = np.maximum(np.sin(psi), 1e-9)
    pp, qq = psi * u[:, 0] / sn, psi * u[:, 1] / sn
    ok = np.hypot(pp, qq) < tk[-4]
    rs = np.full(len(P), np.nan)
    Sq = BSpline(tk, CF, 3)
    qb = np.round(qq / 0.002) * 0.002
    for qv in np.unique(qb[ok]):
        k = ok & (qb == qv)
        rs[k] = BSpline(tk, Sq(np.clip(qv, tk[3], tk[-4])), 3)(np.clip(pp[k], tk[3], tk[-4]))
    return np.abs(rr - rs)


def zone_labels(P):
    de = skin_dist(P)
    DT = json.load(open(os.path.join(W, "datums.json")))
    nr = np.array(DT["shoulder_R"]["normal"]); prr = np.array(DT["shoulder_R"]["plane_pt"])
    nl = np.array(DT["shoulder_L"]["normal"]); pl = np.array(DT["shoulder_L"]["plane_pt"])
    shoulder = (np.abs(P[:, 0]) > 145) & ((np.abs((P - prr) @ nr) < 6) | (np.abs((P - pl) @ nl) < 6))
    rim = (P[:, 2] > -6) & ~shoulder
    outer = (de < 1.0) & ~shoulder & ~rim
    z = np.full(len(P), 3)
    z[outer] = 0; z[shoulder] = 1; z[rim] = 2
    return z
