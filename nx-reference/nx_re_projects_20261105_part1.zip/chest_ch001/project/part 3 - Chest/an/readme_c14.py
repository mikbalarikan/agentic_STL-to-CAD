"""Rewrite the numbers and the simplification list of deliver/README.md for the session-4 model (outC14p).
Numbers from work/dev2_revA.json and deliver/CAD/_finalize.json."""
import os, json, re
from common import ROOT
P = os.path.join(ROOT, "deliver", "README.md")
s = open(P, encoding="utf-8").read()
dev = json.load(open(os.path.join(ROOT, "work", "dev2_revA.json")))["scan_to_cad"]
fin = json.load(open(os.path.join(ROOT, "deliver", "CAD", "_finalize.json")))
vol = fin["volume_mm3"]; kg = vol * 2.70e-6
s = re.sub(r"One valid solid, [0-9 ]+ mm³, [0-9.]+ kg in Al 6061\.", f"One valid solid, {vol:,.0f} mm³, {kg:.2f} kg in Al 6061.".replace(",", " ").replace("solid  ", "solid, ").replace(" mm³  ", " mm³, "), s)


def row(nm, k):
    z = dev[k]
    return f"| {nm} | {z['p50']:.3f} | {z['p95']:.2f} | {100 * z['within_0p5']:.0f} % |"


i0 = s.index("| Zone | Scan → CAD p50 |"); i1 = s.index("- Functional features come from")
s = s[:i0] + "\n".join(["| Zone | Scan → CAD p50 | p95 | Within 0.5 mm |", "|---|---|---|---|",
                        row("Exterior freeform skin", "outer_skin"), row("Shoulder flanges", "shoulder"),
                        row("Rim band (z > -6)", "rim"), row("Interior (wall, ribs, bosses, clips)", "interior"),
                        row("Whole part", "all")]) + "\n\n" + s[i1:]
s = s.replace("- Most of the remaining interior deviation is listed under simplifications 2-5 below.",
              "- Most of the remaining interior deviation is the 0.7 mm pad steps and the items under simplifications below.")
s = s.replace("side panels (left side about 0.4 mm in, right side about 0.4 mm out)", "side panels (left side about 0.75 mm in, right side about 0.75 mm out)")
s = s.replace("Features that exist on one side only (some bosses, clips, the PCB pad details) are\nmodelled where they are",
              "Features that exist on one side only (some bosses, the right-hand latch, the PCB relief) are\nmodelled where they are")
i2 = s.index("1. **Wall.**"); i3 = s.index("8. **Threads.**")
simp = """1. **Wall.** 3.25 mm shell (measured 3.15-3.37, mean 3.27). Where the print is thicker (ridges behind the panel lines,
   lower side pads, rim and neck lips, box walls) the inside follows the measured thickness in 0.7 mm steps (within
   ±0.35 mm). Front panel plate 2.70, recessed disc 1.95, shoulder flanges 4.35, all normal to their faces.
2. **Root fillets and edge rounds** of the print (R0.5-R3) are not modelled; the CAD corners are sharp. Drawing note 4
   sets internal corners R1 max and edge break 0.2-0.5, so the shop can use its cutter radius.
3. **Smooth exterior pockets and raised areas.** The vent boxes, LED box, side scoops, the raised shoulder corners, scoop
   lips and neck sides are smooth surfaces lofted through the scan (smoothed over 0.7-2.5 mm, so print ripple and very
   small edges are not copied). The 3 mm lip along the upper edge of each shoulder vent pocket is rounded off.
4. **Lower side window frames.** The thin raised lips (about 1 mm wide, 0.5-1 mm tall) round the windows on the lower
   side walls are not modelled, and the window floors keep the general wall (0.5-2 mm thicker than the print there):
   the inner face varies by ±5 mm inside a window, so a flat floor would cut through the wall.
5. **Neck chamfer.** Modelled as one 0.7 mm step instead of the smooth chamfer of the print.
6. **Lower side panel bands.** Two shallow (about 0.7 mm) recessed bands on each lower side panel are blended into the
   smooth skin; on those panels the print is also warped (see Left/right symmetry).
7. **Styling lines and marks.** The main exterior "shield" line is a Ø1.8 round-bottom groove 0.9 mm deep along the
   scanned centre line, the panel-line step is one 0.7 mm step. The raised logo lettering on the upper front, the small
   badge on the upper left and the engraved part number inside are not modelled. Apply part marking per your own
   standard, or tell us if you want them in the CAD.
"""
s = s[:i2] + simp + s[i3:]
open(P, "w", encoding="utf-8").write(s)
print("README updated:", f"{vol:.0f} mm3 {kg:.2f} kg")
