"""Exterior recesses (vent boxes, LED slot recess): scan points inside the smooth skin by more than 0.5 mm within a
zone -> mask (plan, 0.5 mm) -> largest component, symmetrised (C zones across x = 0; R zones are right-half only)
-> outline loop (lines/arcs) + robust floor plane of the recessed exterior points.
Writes work/recesses.json: [{name, kind, segs, plane_pt, normal (outward, -Z side), depth}] + figure."""
import os, json
import numpy as np
from scipy import ndimage
import contourpy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W, fit_plane_robust
from arcfit import fit_loop, seg_points

A = np.load(os.path.join(W, "skin_res_all.npy"))
X, res = A[:, :3], A[:, 3]
ZONES = {"bottom_vent": ("C", (-52, 52, -220, -184)), "led_slot": ("C", (-74, 74, -36, -6)), "shoulder_vent": ("R", (66, 154, 54, 94))}
st = 0.5
out = []
fig, axs = plt.subplots(1, 3, figsize=(24, 8))
for ax, (name, (kind, (xa, xb, ya, yb))) in zip(axs, ZONES.items()):
    z = (X[:, 0] > xa) & (X[:, 0] < xb) & (X[:, 1] > ya) & (X[:, 1] < yb)
    P, r = X[z], res[z]
    if kind == "C":                                   # use both halves folded onto x >= 0 and mirror back
        P2 = P.copy(); P2[:, 0] = -P2[:, 0]
        P, r = np.vstack([P, P2]), np.r_[r, r]
    nx_, ny_ = int((xb - xa) / st) + 1, int((yb - ya) / st) + 1
    ix = np.clip(((P[:, 0] - xa) / st).astype(int), 0, nx_ - 1); iy = np.clip(((P[:, 1] - ya) / st).astype(int), 0, ny_ - 1)
    S = np.zeros((ny_, nx_)); C = np.zeros((ny_, nx_))
    np.add.at(S, (iy, ix), (r < -0.5).astype(float)); np.add.at(C, (iy, ix), 1.0)
    m = (C > 0) & (S / np.maximum(C, 1) > 0.5)
    m = ndimage.binary_fill_holes(ndimage.binary_opening(ndimage.binary_closing(m, iterations=3), iterations=2))
    lab, n = ndimage.label(m)
    if n == 0:
        continue
    m = lab == (1 + np.argmax(ndimage.sum(m, lab, range(1, n + 1))))
    G = np.pad(ndimage.gaussian_filter(m.astype(float), 1.0), 2)
    best = max(contourpy.contour_generator(z=G, line_type="Separate").lines(0.5), key=len)
    Q = np.c_[xa + (best[:, 0] - 2) * st, ya + (best[:, 1] - 2) * st][:-1]
    Lc = np.r_[0, np.cumsum(np.linalg.norm(np.diff(np.vstack([Q, Q[:1]]), axis=0), axis=1))]
    sg = np.arange(0, Lc[-1], 0.1); Qc = np.vstack([Q, Q[:1]])
    Qu = np.c_[np.interp(sg, Lc, Qc[:, 0]), np.interp(sg, Lc, Qc[:, 1])]
    Qu = np.c_[ndimage.gaussian_filter1d(Qu[:, 0], 6, mode="wrap"), ndimage.gaussian_filter1d(Qu[:, 1], 6, mode="wrap")]
    segs = fit_loop(Qu, tol=0.15)
    # floor plane: recessed exterior points well inside the mask (eroded 2 mm), deepest 60 %
    me = ndimage.binary_erosion(m, iterations=4)
    inside = me[iy, ix] & (r < -0.5)
    F = P[inside]
    if len(F) < 200:
        continue
    c, nn, sd, k = fit_plane_robust(F, k=2.0)
    if nn[2] > 0: nn = -nn
    if name == "shoulder_vent":                    # flat floor (sections at x 100, 125): horizontal plane at the median
        c = np.array([F[:, 0].mean(), F[:, 1].mean(), float(np.median(F[:, 2]))]); nn = np.array([0.0, 0.0, -1.0])
        sd = float(np.std(F[:, 2] - c[2]))
    out.append(dict(name=name, kind=kind, segs=[([s[0], s[1].tolist(), s[2].tolist()] if s[0] == "L" else [s[0], s[1].tolist(), s[2].tolist(), s[3].tolist(), float(s[4]), bool(s[5])]) for s in segs],
                    plane_pt=c.round(3).tolist(), normal=nn.round(5).tolist(), sd=round(sd, 3), depth=round(float(-np.median(r[inside])), 3),
                    area=round(float(m.sum() * st * st), 1), z_lo=round(float(np.percentile(F[:, 2], 2)), 2), z_hi=round(float(np.percentile(F[:, 2], 98)), 2)))
    ax.imshow(S / np.maximum(C, 1), origin="lower", extent=[xa, xb, ya, yb], cmap="Blues")
    Qp = np.vstack([seg_points(s) for s in segs]); ax.plot(Qp[:, 0], Qp[:, 1], "r-"); ax.set_aspect("equal"); ax.set_title(name)
    print(name, kind, "area", out[-1]["area"], "depth", out[-1]["depth"], "plane sd", out[-1]["sd"], "normal", out[-1]["normal"], "segs", len(segs))
fig.tight_layout(); fig.savefig(os.path.join(W, "recesses.png"), dpi=60)
json.dump(out, open(os.path.join(W, "recesses.json"), "w"))
