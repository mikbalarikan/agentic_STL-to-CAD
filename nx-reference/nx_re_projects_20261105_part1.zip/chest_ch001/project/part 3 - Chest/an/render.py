"""Shaded renders of the CAD STL (part 1 style: grey metal, white background). usage: render.py cad.stl out_dir prefix"""
import os, sys
import numpy as np
import pyvista as pv

stl, out, pre = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(out, exist_ok=True)
m = pv.read(stl).compute_normals(split_vertices=True, feature_angle=35)
c = np.array(m.center)
views = {"front_iso": ((0.55, -0.35, -1.0), (0, 1, 0)), "front": ((0, 0, -1), (0, 1, 0)), "interior_iso": ((-0.5, -0.4, 1.0), (0, 1, 0)),
         "side": ((1, 0, -0.15), (0, 1, 0)), "top": ((0.0, 1.0, -0.35), (0, 0, -1))}
for name, (dv, up) in views.items():
    p = pv.Plotter(off_screen=True, window_size=(1800, 1800))
    p.set_background("white")
    p.add_mesh(m, color=(0.62, 0.64, 0.66), smooth_shading=True, specular=0.35, specular_power=20, ambient=0.18, diffuse=0.8)
    p.enable_lightkit()
    p.camera_position = [tuple(c + np.array(dv, float) / np.linalg.norm(dv) * 1100), tuple(c), up]
    p.camera.view_angle = 30
    p.reset_camera(); p.camera.zoom(1.15)
    p.screenshot(os.path.join(out, f"{pre}_{name}.png")); p.close()
print("renders ok")
