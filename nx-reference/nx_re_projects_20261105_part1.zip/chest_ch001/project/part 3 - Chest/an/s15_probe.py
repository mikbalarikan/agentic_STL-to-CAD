"""Print interior top z (height map from +Z) along given lines/points. usage: s15_probe.py"""
import os, sys
import numpy as np
from common import W
H = np.load(os.path.join(W, "raised.npz"))
st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"]); top = H["top"]; zin = H["zin"]
def z(x, y, w=1):
    i = int(round((x - x0) / st)); j = int(round((y - y0) / st))
    a = top[j - w:j + w + 1, i - w:i + w + 1]; return float(np.nanmax(a))
def zi(x, y):
    i = int(round((x - x0) / st)); j = int(round((y - y0) / st)); return float(zin[j, i])
def ridge(x, y, dx, dy, half=3.0):
    # max top across the rib (perpendicular search)
    best = -1e9
    for t in np.arange(-half, half + 1e-9, 0.25):
        best = max(best, z(x + t * dy, y - t * dx, 0))
    return best
print("rib y=-28 (x):", [(x, round(ridge(x, -28, 1, 0), 2), round(zi(x, -28), 2)) for x in range(-60, 61, 15)])
print("rib y=12 (x):", [(x, round(ridge(x, 12, 1, 0), 2), round(zi(x, 12), 2)) for x in range(-65, 66, 15)])
print("rib x=68 (y):", [(y, round(ridge(68, y, 0, 1), 2), round(zi(68, y), 2)) for y in range(10, -101, -15)])
print("rib x=-68 (y):", [(y, round(ridge(-68, y, 0, 1), 2), round(zi(-68, y), 2)) for y in range(10, -101, -15)])
print("rib y=35 (x):", [(x, round(ridge(x, 35.5, 1, 0), 2), round(zi(x, 35.5), 2)) for x in range(-100, 101, 20)])
print("rib y=-45 (x):", [(x, round(ridge(x, -45, 1, 0), 2), round(zi(x, -45), 2)) for x in (-60, -45, 45, 60)])
print("rib y=-92 (x):", [(x, round(ridge(x, -92, 1, 0), 2), round(zi(x, -92), 2)) for x in (-60, -45, 45, 60)])
for nm, (x, y) in {"bossR(157,64)": (157, 64), "bossR(160,-64)": (160, -64), "boss(60,-266)": (60, -266), "boss(-60,-266)": (-60, -266),
                    "boss(88,89)": (88, 89), "boss(73,93)": (73, 93), "boss(75,-222)": (75, -222), "boss(77,-230)": (77, -230),
                    "boss(105,-148)": (105, -148), "boss(-105,-148)": (-105, -148), "boss(-125,-80)": (-125, -80),
                    "boss(68,12)": (-68, 12), "boss(17,12)": (17, 12), "boss(-30,-45)": (-30, -45), "boss(-38,-92)": (-38, -92), "boss(38,-92)": (38, -92),
                    "pcb plate": (0, -220), "clip(30,-124)": (30, -124), "clip(10,-172)": (10, -172), "clip(-30,-124)": (-30, -124)}.items():
    print(nm, "top", round(z(x, y, 8), 2), "zin", round(zi(x, y), 2))
