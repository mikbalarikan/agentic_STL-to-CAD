"""CAD-alone inspection renders (no scan): open side (+Z), outside (-Z), isos and zoomed interior quadrants.
usage: render_cadonly.py cad.stl out_dir prefix [zoom_only]"""
import os, sys
import numpy as np
import pyvista as pv

stl, out, pre = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(out, exist_ok=True)
m = pv.read(stl).compute_normals(split_vertices=True, feature_angle=30)
c = np.array(m.center)
# (view dir from target to camera, up, focal point or None, parallel scale or None)
views = {"open": ((0, 0, 1), (0, 1, 0), None, None), "outside": ((0, 0, -1), (0, 1, 0), None, None),
         "open_iso": ((0.45, -0.35, 1.0), (0, 1, 0), None, None), "open_iso2": ((-0.45, 0.4, 1.0), (0, 1, 0), None, None),
         "out_iso": ((0.55, -0.35, -1.0), (0, 1, 0), None, None),
         "z_neck": ((0.2, -0.3, 1), (0, 1, 0), (0, 50, -80), 75), "z_upper": ((0.15, 0.35, 1), (0, 1, 0), (0, -60, -120), 80),
         "z_lower": ((0.15, 0.35, 1), (0, 1, 0), (0, -235, -90), 70), "z_Rside": ((-0.5, 0.2, 1), (0, 1, 0), (110, -180, -50), 80),
         "z_Rshoulder": ((-0.4, -0.3, 1), (0, 1, 0), (120, 50, -40), 65), "z_Lshoulder": ((0.4, -0.3, 1), (0, 1, 0), (-120, 50, -40), 65),
         "z_Lside": ((0.5, 0.2, 1), (0, 1, 0), (-110, -180, -50), 80), "z_bottom": ((0, 0.6, 1), (0, 1, 0), (0, -255, -60), 80)}
only = sys.argv[4].split(",") if len(sys.argv) > 4 else None
for name, (dv, up, fp, ps) in views.items():
    if only and name not in only:
        continue
    p = pv.Plotter(off_screen=True, window_size=(1600, 1600))
    p.set_background("white")
    p.add_mesh(m, color=(0.66, 0.68, 0.70), smooth_shading=True, specular=0.3, specular_power=20, ambient=0.2, diffuse=0.8)
    p.enable_lightkit()
    f = np.array(fp, float) if fp is not None else c
    p.camera_position = [tuple(f + np.array(dv, float) / np.linalg.norm(dv) * 1100), tuple(f), up]
    if ps is None:
        p.camera.view_angle = 30; p.reset_camera(); p.camera.zoom(1.15)
    else:
        p.enable_parallel_projection(); p.camera.parallel_scale = ps
    p.screenshot(os.path.join(out, f"{pre}_{name}.png")); p.close()
print("renders ok")
