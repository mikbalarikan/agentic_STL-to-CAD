"""Bottom-end right corner, scan: per z, fit the pieces of the inner profile and the outer skin:
post circle (NW half, about the post), L1 = straight wall x~56.5 under the post, L2 = diagonal wall to the end tip,
S1 = outer skin line from the tip NE, S2 = side wall inner line NE of the post. Prints a table (line as point at a
reference coordinate + slope) and the end tip (lowest y). usage: r1_cornerfit.py"""
import numpy as np
from common import load, section, fit_circle_robust

v, f = load()
fc = v[f[:, 0]]
sel = (fc[:, 0] > 44) & (fc[:, 0] < 80) & (fc[:, 1] > -278) & (fc[:, 1] < -250) & (fc[:, 2] > -70) & (fc[:, 2] < 3)


def line(Q):
    q0 = Q.mean(0); U, S, Vt = np.linalg.svd(Q - q0); d = Vt[0]
    nrm = np.array([-d[1], d[0]]); r = (Q - q0) @ nrm
    return q0, d, float(np.sqrt((r ** 2).mean()))


for z in (-1, -5, -10, -15, -20, -25, -30, -35, -40, -45):
    P = section(v, f, 2, float(z), sel=sel).reshape(-1, 2, 3)[:, 0, :2]
    AX = np.array([59.4, -265.0])
    d = np.linalg.norm(P - AX, axis=1)
    ang = np.degrees(np.arctan2(P[:, 1] - AX[1], P[:, 0] - AX[0]))
    out = f"z {z:4d}:"
    mc = (d > 2.6) & (d < 8) & (ang > 45) & (ang < 200)
    cc, r, sd, _ = fit_circle_robust(P[mc])
    out += f" post ({cc[0]:.2f},{cc[1]:.2f}) r {r:.2f}"
    tip = P[(P[:, 0] > 55) & (P[:, 0] < 70)]
    tp = tip[np.argmin(tip[:, 1])]
    out += f" | tip ({tp[0]:.2f},{tp[1]:.2f})"
    m1 = (P[:, 0] < cc[0] - r + 1.2) & (P[:, 1] < cc[1] - 0.5) & (P[:, 1] > cc[1] - 3.5) & (P[:, 0] > 50)
    if m1.sum() > 8:
        q0, dd, rms = line(P[m1])
        out += f" | L1 x@y-267 {q0[0] + (-267 - q0[1]) * dd[0] / dd[1]:.2f} rms {rms:.2f}"
    m2 = (P[:, 1] < cc[1] - 4.5) & (P[:, 1] > tp[1] + 1.0) & (P[:, 0] < tp[0] - 0.8) & (P[:, 0] > cc[0] - r - 2)
    if m2.sum() > 8:
        q0, dd, rms = line(P[m2])
        s = dd[1] / dd[0]
        out += f" | L2 y@x60 {q0[1] + (60 - q0[0]) * s:.2f} slope {s:.3f} rms {rms:.2f}"
    m3 = (P[:, 0] > tp[0] + 1.5) & (P[:, 0] < 78) & (P[:, 1] < tp[1] + 9) & (P[:, 1] > tp[1] + 0.5)
    m3 &= (P[:, 1] - tp[1]) < 1.2 * (P[:, 0] - tp[0]) + 0.5
    if m3.sum() > 8:
        q0, dd, rms = line(P[m3])
        s = dd[1] / dd[0]
        out += f" | S1 x@y-268 {q0[0] + (-268 - q0[1]) / s:.2f} slope {s:.3f}"
    print(out)
