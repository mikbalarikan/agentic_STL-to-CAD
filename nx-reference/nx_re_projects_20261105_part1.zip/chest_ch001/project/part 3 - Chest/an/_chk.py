import numpy as np, trimesh
m = trimesh.load(r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest\nx\outA4\chest_A.stl")
v = m.vertices
print("bbox", v.min(0).round(2), v.max(0).round(2))
for y0 in (-276, -280, -285, -290, -295):
    k = v[:, 1] < y0
    if k.any(): print(y0, k.sum(), "x", v[k, 0].min().round(1), v[k, 0].max().round(1), "z", v[k, 2].min().round(1), v[k, 2].max().round(1))
k = v[:, 1] > 114.5
if k.any(): print(">114.5", k.sum(), "x", v[k, 0].min().round(1), v[k, 0].max().round(1), "z", v[k, 2].min().round(1), v[k, 2].max().round(1), "ymax", v[k,1].max())
k = v[:, 0] > 167.5
if k.any(): print("x>167.5", k.sum(), v[k].min(0).round(1), v[k].max(0).round(1))
