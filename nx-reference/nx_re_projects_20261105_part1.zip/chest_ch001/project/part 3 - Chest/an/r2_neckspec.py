﻿"""Neck flange spec for the NX rebuild (nx/revC1_neck.py).
S_out = the flange's outer face, ruled along D: a 2D curve c (frame U, V, normal D) fitted to the scan's flange-bottom
points (station profiles, e1 = -1..-4), symmetric, extruded along D. The tip curve = the scan's outer tip edge moved
onto S_out. Reports, per station, where the CAD's outer skin crosses S_out (bend line B) and at what angle.
Writes work/r2/neckspec.json + neckspec.png.
usage: r2_neckspec.py tag cad.stl [bias_bottom=0.0]"""
import sys, os, json
import numpy as np
from scipy.interpolate import splprep, splev
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, section, W
from r2_secs import read_stl

tag, cad = sys.argv[1], sys.argv[2]
BIAS = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
ANG = np.radians(25.6)
D = np.array([0.0, np.sin(ANG), np.cos(ANG)])
U = np.array([1.0, 0.0, 0.0]); V = np.cross(D, U)
E = json.load(open(os.path.join(W, "r2", f"edge_{tag}.json")))["stations"]
L = {r["k"]: r for r in json.load(open(os.path.join(W, "r2", f"lower_{tag}.json")))}
PR = {r["k"]: r for r in json.load(open(os.path.join(W, "r2", f"prof_{tag}.json")))}
uv = lambda P: np.array([P @ U, P @ V])

# ---- c: flange-bottom points
pts2, tips = [], []
for s in E:
    k = s["k"]; p, e1, e2 = (np.array(s[q]) for q in ("p", "e1", "e2"))
    offs = (-1, -2, -3, -4) if k >= 8 else (-1, -2, -3)
    for a in offs:
        y = L[k]["scan"][str(a)][0]
        pts2.append(uv(p + a * e1 + y * e2))
    tips.append(p + PR[k]["bot"] * e2)
pts2 = np.array(pts2); tips = np.array(tips)
allp = np.vstack([pts2 * [-1, 1], pts2])
order = np.argsort(allp[:, 0]); allp = allp[order]
# parametrise by arc length after a coarse sort along the curve: sort by angle about a point above the smile
ang = np.arctan2(allp[:, 1] - 140.0, allp[:, 0]); allp = allp[np.argsort(ang)]
tck, _ = splprep(allp.T, s=len(allp) * 0.01, k=3)
uu = np.linspace(0, 1, 4000); C = np.array(splev(uu, tck)).T
res = []
from scipy.spatial import cKDTree
kd = cKDTree(C)
d, i = kd.query(allp)
# signed residual: along the curve normal
dC = np.gradient(C, axis=0); dC /= np.linalg.norm(dC, axis=1, keepdims=True); nC = np.c_[-dC[:, 1], dC[:, 0]]
sres = ((allp - C[i]) * nC[i]).sum(1)
print("c fit residual: rms %.3f max %.3f" % (np.sqrt((sres ** 2).mean()), np.abs(sres).max()))
# symmetrise: average C(u) with mirrored C(1-u)
Cm = (C + (C[::-1] * [-1, 1])) / 2
# the fitted ends curl (the arm tops hook back at the rim): cut c at |u| 57 and extend it straight along the mean
# direction of the arm part u 49..57, 16 mm (the flange reaches u ~64 at the top stations)
UCUT = float(os.environ.get("NECK_UCUT", "57"))
Cm = Cm[np.abs(Cm[:, 0]) <= UCUT]
def extend(Cm, L_=16.0):
    t1 = Cm[-1] - Cm[-25]; t1 /= np.linalg.norm(t1)        # local end tangent (dense samples, ~1 mm)
    t0 = t1 * [-1, 1]
    a = np.array([Cm[0] + t0 * x for x in np.linspace(L_, 0.5, 12)])
    b = np.array([Cm[-1] + t1 * x for x in np.linspace(0.5, L_, 12)])
    return np.vstack([a, Cm, b])
Ce = extend(Cm)
Cm = Ce
# resample at ~3 mm
seg = np.r_[0, np.cumsum(np.linalg.norm(np.diff(Ce, axis=0), axis=1))]
n = int(seg[-1] / 3.0) + 1
Cs = np.c_[np.interp(np.linspace(0, seg[-1], n), seg, Ce[:, 0]), np.interp(np.linspace(0, seg[-1], n), seg, Ce[:, 1])]
Cs[:, 0] -= Cs[:, 0].mean() * 0  # symmetric already
kdC = cKDTree(Cm)

# ---- tip curve on S_out: move the tip's 2D point onto c (along the curve normal), keep lambda
tip_on = []
for t in tips:
    q = uv(t); dd, j = kdC.query(q)
    tip_on.append(Cm[j, 0] * U + Cm[j, 1] * V + (t @ D) * D)
tip_on = np.array(tip_on)
TT = np.vstack([(tip_on * [-1, 1, 1])[::-1], tip_on])
tck3, _ = splprep(TT.T, s=len(TT) * 0.05, k=3)
T3 = np.array(splev(np.linspace(0, 1, 3000), tck3)).T
T3 = (T3 + (T3[::-1] * [-1, 1, 1])) / 2
# extend the arm ends 14 mm along their tangent (above the rim)
def ext3(T, L_=14.0):
    t0 = T[0] - T[30]; t0 /= np.linalg.norm(t0); t1 = T[-1] - T[-31]; t1 /= np.linalg.norm(t1)
    return np.vstack([[T[0] + t0 * x for x in np.linspace(L_, 0.5, 10)], T, [T[-1] + t1 * x for x in np.linspace(0.5, L_, 10)]])
T3e = ext3(T3, 30.0)
seg = np.r_[0, np.cumsum(np.linalg.norm(np.diff(T3e, axis=0), axis=1))]
n3 = int(seg[-1] / 3.0) + 1
Ts = np.array([np.interp(np.linspace(0, seg[-1], n3), seg, T3e[:, j]) for j in range(3)]).T
# keep the curve on S_out after smoothing: snap 2D onto c
Ts = np.array([Cm[kdC.query(uv(q))[1], 0] * U + Cm[kdC.query(uv(q))[1], 1] * V + (q @ D) * D for q in Ts])

# ---- bend line: where the CAD outer skin crosses S_out, per station (profile frame)
vc, fc = read_stl(cad); cc = vc[fc].mean(1)
rows = []
for s in E:
    k = s["k"]; p, t, e1, e2 = (np.array(s[q]) for q in ("p", "t", "e1", "e2"))
    # S_out in this station's profile: points of c near the station, as e2 offsets at e1 = -1..-14
    m = np.linalg.norm(cc - p, axis=1) < 26
    R = np.array([e1, e2, t])
    sg = section((vc - p) @ R.T, fc[m], 2, 0.0)[:, :, :2]
    prof = []
    for a in np.arange(-0.5, -16.01, -0.5):
        # S_out height at e1 = a: the point p + a e1 + h e2 whose 2D projection lies on c -> solve for h
        hs = np.linspace(-4, 4, 161)
        Q = np.array([uv(p + a * e1 + h * e2) for h in hs])
        dq, _ = kdC.query(Q)
        # signed: sample c normal
        h0 = hs[np.argmin(dq)]
        A_, B_ = sg[:, 0], sg[:, 1]
        sel = (A_[:, 0] - a) * (B_[:, 0] - a) <= 0
        tt = (a - A_[sel, 0]) / (B_[sel, 0] - A_[sel, 0] + 1e-12)
        y = np.sort(A_[sel, 1] + tt * (B_[sel, 1] - A_[sel, 1]))
        prof.append((a, h0, y[0] if len(y) else np.nan))
    prof = np.array(prof)
    diff = prof[:, 2] - prof[:, 1]               # CAD outer minus S_out (>0: skin inside S_out)
    cross = None
    for j in range(len(diff) - 1):
        if np.isfinite(diff[j]) and np.isfinite(diff[j + 1]) and diff[j] < 0 <= diff[j + 1]:
            f_ = -diff[j] / (diff[j + 1] - diff[j])
            cross = prof[j, 0] + f_ * (prof[j + 1, 0] - prof[j, 0])
            slope = (diff[j + 1] - diff[j]) / 0.5
            break
    rows.append(dict(k=k, B_e1=None if cross is None else round(float(cross), 2),
                     angle=None if cross is None else round(float(np.degrees(np.arctan(abs(slope)))), 1),
                     diff=[round(float(x), 2) for x in diff[[1, 3, 5, 7, 11, 15, 19, 23, 27, 31]]]))
    print(rows[-1])

# ---- back curve of the rebuild band: the tip moved BAND mm back along the flange (-e1), kept on S_out
BAND = 14.0
snap = lambda q: Cm[kdC.query(uv(q))[1], 0] * U + Cm[kdC.query(uv(q))[1], 1] * V + (q @ D) * D
back = np.array([snap(tip_on[s["k"]] - BAND * np.array(s["e1"])) for s in E])
BB = np.vstack([(back * [-1, 1, 1])[::-1], back])
tckb, _ = splprep(BB.T, s=len(BB) * 0.3, k=3)
B3 = np.array(splev(np.linspace(0, 1, 3000), tckb)).T
B3 = (B3 + (B3[::-1] * [-1, 1, 1])) / 2
B3e = ext3(B3, 34.0)
seg = np.r_[0, np.cumsum(np.linalg.norm(np.diff(B3e, axis=0), axis=1))]
nb = int(seg[-1] / 3.0) + 1
Bs = np.array([np.interp(np.linspace(0, seg[-1], nb), seg, B3e[:, j]) for j in range(3)]).T
Bs = np.array([snap(q) for q in Bs])
# probes (station frames): inside the new flange, air outside S_out, air beyond the tip, a point on the CAD skin
# behind the bend (old skin face) and 1 mm outside it
probes = []
for k in (0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22):
    s = E[k]; p, e1, e2 = (np.array(s[q]) for q in ("p", "e1", "e2")); tp = tip_on[k]
    a = -10 if k >= 5 else -8
    yc = L[k]["cad"][str(a)][0]
    probes.append(dict(k=k, fl_in=(snap(tp - 2 * e1) + 1.6 * e2).round(3).tolist(),
                       out_air=(snap(tp - 3 * e1) - 1.0 * e2).round(3).tolist(),
                       open_air=(tp + 1.0 * e1 + 1.6 * e2).round(3).tolist(),
                       skin=(p + a * e1 + yc * e2).round(3).tolist(), skin_out=(p + a * e1 + (yc - 1.0) * e2).round(3).tolist(),
                       band_pt=snap(tp - 5 * e1).round(3).tolist()))
ic = int(np.argmin(np.abs(Ts[:, 0])))

# ---- frame + NX data
lam_tip = tip_on @ D
spec = dict(D=D.round(6).tolist(), U=U.tolist(), V=V.round(6).tolist(), angle_deg=25.6,
            lam_min=round(float(lam_tip.min() - 22.0), 2), lam_max=round(float((np.array([0, 112.0, 6.0]) @ D) + 26.0), 2),
            c_uv=Cs.round(4).tolist(), tip_xyz=Ts.round(4).tolist(), back_xyz=Bs.round(4).tolist(), band=BAND, stations=rows,
            open_pt=(Ts[ic] + 15.0 * D).round(4).tolist(), probes=probes,
            probe_flange=[(tip_on[k] + (-2.0) * np.array(E[k]["e1"]) + 1.6 * np.array(E[k]["e2"])).round(3).tolist() for k in (0, 6, 12, 18)],
            probe_open=[(tip_on[k] + 2.0 * np.array(E[k]["e1"]) + 1.6 * np.array(E[k]["e2"])).round(3).tolist() for k in (0, 6, 12, 18)],
            station_frames=[dict(k=s["k"], p=s["p"], e1=s["e1"], e2=s["e2"], tip=tip_on[s["k"]].round(3).tolist()) for s in E])
json.dump(spec, open(os.path.join(W, "r2", "neckspec.json"), "w"), indent=1)
fig, ax = plt.subplots(1, 2, figsize=(15, 6))
ax[0].plot(allp[:, 0], allp[:, 1], ".", ms=2); ax[0].plot(Cs[:, 0], Cs[:, 1], "r-"); ax[0].set_aspect("equal"); ax[0].set_title("c (seen along D)")
ax[0].plot(*np.array([uv(q) for q in Ts]).T, "g-", lw=0.8)
ax[1].plot(Ts[:, 0], Ts[:, 2], "g-"); ax[1].plot(tips[:, 0], tips[:, 2], "k.", ms=4); ax[1].set_aspect("equal"); ax[1].set_title("tip curve x-z")
fig.savefig(os.path.join(W, "r2", "neckspec.png"), dpi=100)
print("lam range", spec["lam_min"], spec["lam_max"], "c pts", len(Cs), "tip pts", len(Ts))

