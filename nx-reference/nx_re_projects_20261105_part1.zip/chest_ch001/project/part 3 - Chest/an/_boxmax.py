import os, numpy as np
from common import W
T = np.load(os.path.join(W, "tmap.npz")); E = np.load(os.path.join(W, "emap.npz"))
t, e, x0, y0, st = T["t"], E["e"], float(T["x0"]), float(T["y0"]), float(T["step"])
ny, nx = t.shape
XX, YY = np.meshgrid(x0 + np.arange(nx) * st, y0 + np.arange(ny) * st)
for nm, (xa, xb, ya, yb) in {"shvent": (75, 150, 55, 95), "led": (-60, 60, -35, -5), "scoop": (100, 135, -115, -40), "lowvent": (-45, 45, -225, -195), "lowbox": (-35, 35, -245, -205)}.items():
    m = (XX > xa) & (XX < xb) & (YY > ya) & (YY < yb)
    print(nm, "t p50/p95/max", np.round(np.nanpercentile(t[m], [50, 95, 99.5]), 2), " e p50/p95/max", np.round(np.nanpercentile(e[m], [50, 95, 99.5]), 2))
