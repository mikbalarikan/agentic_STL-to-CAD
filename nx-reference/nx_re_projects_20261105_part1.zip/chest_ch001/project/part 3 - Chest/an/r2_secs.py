"""Plane sections of the full-res scan (orange) and a CAD STL (grey) side by side in one figure, cropped to a box.
usage: r2_secs.py cad.stl out.png x0 x1 y0 y1 z0 z1 plane [plane ...]
plane = x=VAL | y=VAL | z=VAL | n=nx,ny,nz@px,py,pz (general plane; drawn in its own u,v frame)"""
import sys, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import load, section


def read_stl(p):
    with open(p, "rb") as fh:
        fh.read(80); n = int(np.frombuffer(fh.read(4), np.uint32)[0])
        dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
        t = np.fromfile(fh, dt, n)["v"].astype(np.float64)
    return t.reshape(-1, 3), np.arange(len(t) * 3).reshape(-1, 3)


def gsection(v, f, n, p0):
    """section by a general plane: rotate so the plane is z = 0, cut, rotate back (u, v, w) coordinates."""
    n = np.asarray(n, float); n /= np.linalg.norm(n)
    u = np.cross(n, [0, 0, 1] if abs(n[2]) < 0.9 else [1, 0, 0]); u /= np.linalg.norm(u); w = np.cross(n, u)
    R = np.array([u, w, n])
    vr = (v - p0) @ R.T
    return section(vr, f, 2, 0.0), (u, w)


if __name__ == "__main__":
    cad, out = sys.argv[1], sys.argv[2]
    B = np.array(list(map(float, sys.argv[3:9]))).reshape(3, 2)
    planes = sys.argv[9:]
    vs, fs = load()
    cs = vs[fs].mean(1)
    ms = np.all((cs >= B[:, 0] - 2) & (cs <= B[:, 1] + 2), axis=1)
    vs_f = fs[ms]
    vc, fc = read_stl(cad)
    cc = vc[fc].mean(1)
    mc = np.all((cc >= B[:, 0] - 2) & (cc <= B[:, 1] + 2), axis=1)
    fc = fc[mc]
    nn = len(planes); ncol = min(nn, 3); nrow = (nn + ncol - 1) // ncol
    fig, axs = plt.subplots(nrow, ncol, figsize=(7 * ncol, 6.5 * nrow), squeeze=False)
    names = "xyz"
    for k, pl in enumerate(planes):
        ax = axs[k // ncol][k % ncol]
        if pl[0] in "xyz":
            a = names.index(pl[0]); val = float(pl[2:])
            ss = section(vs, vs_f, a, val); sc = section(vc, fc, a, val)
            i, j = [q for q in range(3) if q != a]
            S2, C2 = ss[:, :, [i, j]], sc[:, :, [i, j]]
            lab = (names[i], names[j])
        else:
            nv, pv_ = pl[2:].split("@")
            n_ = np.array(list(map(float, nv.split(",")))); p0 = np.array(list(map(float, pv_.split(","))))
            ss, _ = gsection(vs, vs_f, n_, p0); sc, _ = gsection(vc, fc, n_, p0)
            S2, C2 = ss[:, :, :2], sc[:, :, :2]
            lab = ("u", "w")
        ax.add_collection(LineCollection(C2, colors="#555555", linewidths=1.6))
        ax.add_collection(LineCollection(S2, colors="#f2a11f", linewidths=0.9))
        allp = np.concatenate([S2.reshape(-1, 2), C2.reshape(-1, 2)]) if len(S2) + len(C2) else np.zeros((1, 2))
        lo, hi = allp.min(0), allp.max(0); pad = 0.05 * (hi - lo).max() + 1
        ax.set_xlim(lo[0] - pad, hi[0] + pad); ax.set_ylim(lo[1] - pad, hi[1] + pad)
        ax.set_aspect("equal"); ax.grid(alpha=0.3); ax.set_title(f"{pl}   scan orange / CAD grey", fontsize=10)
        ax.set_xlabel(lab[0]); ax.set_ylabel(lab[1])
    for k in range(nn, nrow * ncol):
        axs[k // ncol][k % ncol].axis("off")
    fig.tight_layout(); fig.savefig(out, dpi=110)
    print("ok", out)
