"""Neck edge profiles at the stations of work/r2/edge_<tag>.json: scan (orange) vs a CAD STL (grey), local frame
e1 (out of the edge) / e2. Also the mirrored stations (left arm) on a second sheet when side=L.
usage: r2_profcheck.py tag cad.stl out.png [side=R|L]"""
import sys, os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import load, section, W
from r2_secs import read_stl

tag, cad, out = sys.argv[1], sys.argv[2], sys.argv[3]
side = sys.argv[4] if len(sys.argv) > 4 else "R"
M = np.array([-1.0, 1, 1]) if side == "L" else np.ones(3)
E = json.load(open(os.path.join(W, "r2", f"edge_{tag}.json")))["stations"]
v, f = load(); cs = v[f].mean(1)
vc, fc = read_stl(cad); cc = vc[fc].mean(1)
ncol = 6; nrow = (len(E) + ncol - 1) // ncol
fig, axs = plt.subplots(nrow, ncol, figsize=(3.6 * ncol, 3.6 * nrow), squeeze=False)
for k, s in enumerate(E):
    p, t, e1, e2 = (np.array(s[q]) * M for q in ("p", "t", "e1", "e2"))
    R = np.array([e1, e2, t])
    ms = np.linalg.norm(cs - p, axis=1) < 22; mc = np.linalg.norm(cc - p, axis=1) < 22
    ss = section((v - p) @ R.T, f[ms], 2, 0.0)[:, :, :2]
    sc = section((vc - p) @ R.T, fc[mc], 2, 0.0)[:, :, :2]
    ax = axs[k // ncol][k % ncol]
    ax.add_collection(LineCollection(sc, colors="#555555", linewidths=1.3))
    ax.add_collection(LineCollection(ss, colors="#f2a11f", linewidths=0.9))
    ax.set_xlim(-14, 8); ax.set_ylim(-11, 11); ax.set_aspect("equal"); ax.grid(alpha=0.3)
    ax.set_title(f"{side}#{k} ({p[0]:.0f},{p[1]:.0f},{p[2]:.0f})", fontsize=8); ax.tick_params(labelsize=6)
for k in range(len(E), nrow * ncol):
    axs[k // ncol][k % ncol].axis("off")
fig.suptitle(f"neck edge sections, scan orange / CAD grey ({os.path.basename(cad)})", fontsize=10)
fig.tight_layout(); fig.savefig(out, dpi=100)
print("ok", out)
