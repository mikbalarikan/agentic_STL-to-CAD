import os, numpy as np
from common import W
A = np.load(os.path.join(W, "dev2_B10_scan2cad.npy")); P, d = A[:, :3], A[:, 3]
m = (P[:, 2] > -6) & (np.abs(P[:, 0]) < 145)
big = m & (d > 0.5)
print("rim band pts", m.sum(), "over 0.5:", big.sum(), round(big.sum() / m.sum(), 3))
key = np.round(P[big][:, :2] / 20).astype(int)
u, inv, cnt = np.unique(key, axis=0, return_inverse=True, return_counts=True)
for k in np.argsort(-cnt)[:15]:
    mm = inv == k
    print(cnt[k], P[big][mm].mean(0).round(1), "d med", round(float(np.median(d[big][mm])), 2))
# interior overall: where are the biggest misses (d > 0.5) by 30 mm cells
inner = (P[:, 2] < -6) & (d > 0.5)
key = np.round(P[inner][:, :2] / 30).astype(int)
u, inv, cnt = np.unique(key, axis=0, return_inverse=True, return_counts=True)
print("interior over 0.5 cells:")
for k in np.argsort(-cnt)[:15]:
    mm = inv == k
    print(cnt[k], P[inner][mm].mean(0).round(1), "d med", round(float(np.median(d[inner][mm])), 2))
