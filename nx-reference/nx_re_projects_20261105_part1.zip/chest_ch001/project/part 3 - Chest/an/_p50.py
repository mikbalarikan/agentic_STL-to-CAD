"""Why the whole-part p50 stays above 0.06: share of points within 0.06 mm per zone (C5r, 400 k sample)."""
import os, numpy as np
from common import W
A = np.load(os.path.join(W, "dev2_C5r_scan2cad.npy")); P, d = A[:, :3], np.abs(A[:, 3])
Z = np.load(os.path.join(W, "rv", "zones400k.npy"))
names = ("exterior skin", "shoulder", "rim", "interior")
print("all: within 0.06 %.1f %%, p50 %.3f" % (100 * (d <= 0.06).mean(), np.median(d)))
for i, n in enumerate(names):
    m = Z == i
    print("%-14s share %4.1f %%  within 0.06 %4.1f %%  within 0.10 %4.1f %%  p50 %.3f" % (n, 100 * m.mean(), 100 * (d[m] <= 0.06).mean(), 100 * (d[m] <= 0.1).mean(), np.median(d[m])))
# exterior skin split: lower side panels (|x| > 60, y < -120: the print warp) vs the rest
m = Z == 0
w = m & (np.abs(P[:, 0]) > 60) & (P[:, 1] < -120)
print("skin, lower side panels: share of skin %.1f %%, p50 %.3f; rest of skin p50 %.3f" % (100 * w.sum() / m.sum(), np.median(d[w]), np.median(d[m & ~w])))
