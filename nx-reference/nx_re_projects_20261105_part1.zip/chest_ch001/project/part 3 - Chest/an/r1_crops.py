"""Crops of deviation clusters in the NX-overlay look (scan orange, CAD grey) + the signed scan deviation next to it.
usage: i91_crops.py cad.stl clusters_tag out_dir [ids e.g. 0-40 or 3,7,9] [margin=12]
or     i91_crops.py cad.stl views:<json file with [{name, ctr, half, dir, up}]> out_dir
Scan = work/overlay/scan_in_part_frame.stl (full resolution, already lifted by seat_dz)."""
import sys, os, json
import numpy as np
import pyvista as pv
import open3d as o3d
from common import W

cad, ctag, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
MARG = float(sys.argv[5]) if len(sys.argv) > 5 else 12.0
ORANGE, GREY = "#f2a11f", "#a7acb2"


def read_stl(p):
    with open(p, "rb") as fh:
        fh.read(80); n = int(np.frombuffer(fh.read(4), np.uint32)[0])
        dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
        return np.fromfile(fh, dt, n)["v"]


S = read_stl(os.path.join(os.path.dirname(W), "Deviation_Check", "CH-001_scan_in_part_frame_0p6mm.stl"))
SC = S.mean(1)
C = read_stl(cad); CC = C.mean(1)
cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices()
rs = o3d.t.geometry.RaycastingScene(); rs.add_triangles(o3d.t.geometry.TriangleMesh(o3d.core.Tensor(np.asarray(cm.vertices, np.float32)), o3d.core.Tensor(np.asarray(cm.triangles, np.int32))))


def crop(T, TC, lo, hi):
    m = np.all((TC >= lo) & (TC <= hi), axis=1)
    t = T[m].reshape(-1, 3)
    faces = np.c_[np.full(m.sum(), 3), np.arange(3 * m.sum()).reshape(-1, 3)].ravel()
    pd = pv.PolyData(t.astype(float), faces)
    return pd.clean(tolerance=1e-6)


SPLIT = os.environ.get("CROP_SPLIT") == "1"


def render(name, ctr, half, d, up, title=""):
    ctr = np.asarray(ctr, float); lo, hi = ctr - half, ctr + half
    ms, mc = crop(S, SC, lo, hi), crop(C, CC, lo, hi)
    if ms.n_points == 0 and mc.n_points == 0:
        return
    if ms.n_points:
        ms["dev"] = rs.compute_signed_distance(o3d.core.Tensor(np.asarray(ms.points, np.float32))).numpy()
    d = np.asarray(d, float); d /= np.linalg.norm(d)
    R = float(np.max(half)) * 3.6
    def panel(items, label, bar=False):
        p = pv.Plotter(off_screen=True, window_size=(850, 820))
        p.set_background("white")
        for m_, kw in items:
            if m_.n_points:
                p.add_mesh(m_, **kw)
        p.add_text(label, font_size=9, color="black")
        p.camera_position = [tuple(ctr + d * R), tuple(ctr), tuple(up)]; p.camera.view_angle = 30
        img = p.screenshot(None, return_img=True); p.close()
        return img
    gk = dict(color=GREY, smooth_shading=False, ambient=0.25, diffuse=0.75, specular=0.2)
    ok_ = dict(color=ORANGE, smooth_shading=False, ambient=0.25, diffuse=0.75)
    if SPLIT:
        imgs = [panel([(mc, gk)], f"{title}  CAD alone"), panel([(ms, ok_)], "scan alone"),
                panel([(mc, gk), (ms, ok_)], "overlay: scan orange, CAD grey")]
    else:
        imgs = [panel([(mc, gk), (ms, ok_)], f"{title}  overlay: scan orange, CAD grey"),
                panel([(mc, dict(color="#d0d0d0", opacity=0.35)),
                       (ms, dict(scalars="dev", cmap="coolwarm", clim=(-1.5, 1.5), show_scalar_bar=True,
                                 scalar_bar_args=dict(title="scan-CAD mm (+ CAD missing)", fmt="%.1f", n_labels=5)))], "signed deviation")]
    import matplotlib.image as mpimg
    mpimg.imsave(os.path.join(OUT, f"{name}.png"), np.hstack(imgs))


if ctag.startswith("views:"):
    for v_ in json.load(open(ctag[6:])):
        render(v_["name"], v_["ctr"], np.asarray(v_["half"], float), v_["dir"], v_.get("up", (1, 0, 0)), v_.get("title", v_["name"]))
    sys.exit(0)
cl = json.load(open(os.path.join(W, f"clusters_{ctag}.json")))["clusters"]
sel = sys.argv[4] if len(sys.argv) > 4 else "0-40"
ids = []
for part_ in sel.split(","):
    if "-" in part_:
        a, b = part_.split("-"); ids += list(range(int(a), int(b) + 1))
    else:
        ids.append(int(part_))
for i in ids:
    c = cl[i]
    nv = np.asarray(c["n_view"], float)
    d = nv / np.linalg.norm(nv) if np.linalg.norm(nv) > 0.3 else np.array([0.0, 0.0, -1.0])
    d = d + np.array([0.0, 0.0, -0.35])      # a little from the open side, like the user's inside views
    up = (1, 0, 0) if abs(d[0]) < 0.8 * np.linalg.norm(d) else (0, 1, 0)
    half = np.clip((np.asarray(c["hi"]) - np.asarray(c["lo"])) / 2 + MARG, 8, 60)
    ctr = (np.asarray(c["hi"]) + np.asarray(c["lo"])) / 2
    t = f"#{i} {c['sign']} {c['area']:.0f}mm2 p90 {c['p90']} @({ctr[0]:.0f},{ctr[1]:.0f},{ctr[2]:.0f})"
    render(f"c{i:03d}_{c['sign']}", ctr, half, d, up, t)
    print("ok", i)
