"""Section plots of the framed scan. usage: sec.py axis(x|y|z) v1,v2,.. out_tag [lo,hi window on 1st plot axis]
Each value one subplot, 1:1 aspect, 1 mm grid labels every 10."""
import sys, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import W, load, section

ax = "xyz".index(sys.argv[1]); vals = [float(t) for t in sys.argv[2].split(",")]; tag = sys.argv[3]
win = [float(t) for t in sys.argv[4].split(",")] if len(sys.argv) > 4 else None
v, f = load()
pa = {0: (1, 2), 1: (0, 2), 2: (0, 1)}[ax]
fig, axs = plt.subplots(len(vals), 1, figsize=(22, 6 * len(vals)), squeeze=False)
for a_, val in zip(axs[:, 0], vals):
    s = section(v, f, ax, val)
    seg = s[:, :, list(pa)]
    if win:
        k = (seg[:, :, 0] >= win[0]).all(1) & (seg[:, :, 0] <= win[1]).all(1)
        if len(win) > 2:
            k &= (seg[:, :, 1] >= win[2]).all(1) & (seg[:, :, 1] <= win[3]).all(1)
        seg = seg[k]
    a_.add_collection(LineCollection(seg, lw=0.6, color="k"))
    a_.autoscale(); a_.set_aspect("equal")
    a_.minorticks_on(); a_.grid(True, which="major", lw=0.4); a_.grid(True, which="minor", lw=0.15, alpha=0.5)
    a_.set_title(f"{'xyz'[ax]} = {val}  ({'xyz'[pa[0]]} right, {'xyz'[pa[1]]} up)")
fig.tight_layout(); fig.savefig(os.path.join(W, f"sec_{tag}.png"), dpi=70); plt.close(fig)
print("ok")
