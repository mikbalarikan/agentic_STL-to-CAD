"""Circle recess and through hole from the exterior height-map boundaries (sub-pixel contours) -> panel.json."""
import os, json
import numpy as np
import contourpy
from common import W, fit_circle_robust
H = np.load(os.path.join(W, "hmap.npz")); st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"]); bot = H["bot"]
P = json.load(open(os.path.join(W, "panel.json")))
e = P["ext_plane"]
ny, nx = bot.shape
XX, YY = np.meshgrid(x0 + np.arange(nx) * st, y0 + np.arange(ny) * st)
d = np.where(np.isfinite(bot), bot - (e["z_at_origin"] + e["dzdx"] * XX + e["dzdy"] * YY), -5.0)
win = (np.abs(XX) < 37) & (YY > -112) & (YY < -38)
def circ(field, lev, win):
    G = np.where(win, field, np.nan)
    best = max(contourpy.contour_generator(z=G, line_type="Separate").lines(lev), key=len)
    Q = np.c_[x0 + best[:, 0] * st, y0 + best[:, 1] * st]
    c, r, sd, k = fit_circle_robust(Q)
    return dict(c=c.round(3).tolist(), d=round(2 * r, 3), sd=round(sd, 4), n=int(k.sum()))
P["circle"] = circ(d, 1.0, win)
fin = np.isfinite(bot).astype(float)
P["hole"] = circ(fin, 0.5, (np.abs(XX) < 25) & (YY > -160) & (YY < -112))
json.dump(P, open(os.path.join(W, "panel.json"), "w"), indent=1)
print(P["circle"], P["hole"])
