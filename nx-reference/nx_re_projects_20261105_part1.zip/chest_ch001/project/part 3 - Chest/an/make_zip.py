"""Package deliver/ as CH-001_RevA_Chest.zip, laid out like part 1's Rev A zip:
CH-001_RevA_Chest/CH-001_RevA/{CAD, Drawings, Deviation Report, Renders, README.md}.
Drawings: the multi-sheet PDF plus one PDF and one DWG per sheet (the client was promised DWG)."""
import os, zipfile, glob
from common import ROOT

D = os.path.join(ROOT, "deliver")
ZIP = os.path.join(ROOT, "CH-001_RevA_Chest.zip")
TOP = "CH-001_RevA_Chest/CH-001_RevA/"
items = []
for f in ("CH-001_Chest.prt", "CH-001_Chest_AP214.step", "CH-001_Chest_AP242.step", "CH-001_Chest.x_t", "CH-001_Chest.stl"):
    items.append((os.path.join(D, "CAD", f), TOP + "CAD/" + f))
for f in sorted(glob.glob(os.path.join(D, "Drawings", "CH-001*.pdf")) + glob.glob(os.path.join(D, "Drawings", "CH-001_SH*.dwg"))):
    items.append((f, TOP + "Drawings/" + os.path.basename(f)))
for f in sorted(glob.glob(os.path.join(D, "QA", "*"))):
    items.append((f, TOP + "Deviation Report/" + os.path.basename(f)))
for f in sorted(glob.glob(os.path.join(D, "Renders", "*.png"))):
    items.append((f, TOP + "Renders/" + os.path.basename(f)))
items.append((os.path.join(D, "README.md"), TOP + "README.md"))
missing = [s for s, _ in items if not os.path.exists(s)]
assert not missing, missing
if os.path.exists(ZIP):
    os.remove(ZIP)
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for src, arc in items:
        z.write(src, arc)
with zipfile.ZipFile(ZIP) as z:
    bad = z.testzip()
    for i in z.infolist():
        print(f"{i.file_size:>10}  {i.filename}")
print("zip", ZIP, os.path.getsize(ZIP), "bytes; testzip:", bad)
