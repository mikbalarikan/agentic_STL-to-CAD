"""outC12 plugs for the CAD Z-through openings the scan does not have (review census, lead decision 3: gate 0).
One prism per opening: plan outline = the CAD opening cells dilated 0.75 mm (fuses with the CAD wall around it), minus the
scan's own openings; bottom / top = planes fitted to the scan exterior (ZE) / interior (ZI) heights over that outline.
usage: s40_plugs.py <review data dir>  -> work/c12/plugs.json (G-schema features, side A, clip none; build.py stage P
unites them after every cut)."""
import os, sys, json
import numpy as np
from scipy import ndimage
import contourpy
from skimage.measure import approximate_polygon
from common import W
D = sys.argv[1]
M = np.load(os.path.join(D, "maps.npz")); CM = np.load(os.path.join(D, "census_maps.npz"))
xs, ys, C = M["xs"], M["ys"], float(M["cell"])
X, Y = np.meshgrid(xs, ys)
ZE, ZI = M["scan_ZE"], M["scan_ZI"]
cens = json.load(open(os.path.join(D, "census.json")))
extra = [o for o in cens["cad_open"] if o.get("scan") is None and o["area"] >= 2.0]
scan_open = ndimage.binary_dilation(CM["scan_open"] > 0, iterations=1)
DIL = int(round(0.75 / C))


def fit(m, Z):
    x, y, z = X[m], Y[m], Z[m]
    ok = np.isfinite(z); x, y, z = x[ok], y[ok], z[ok]
    A = np.c_[x, y, np.ones_like(x)]
    for _ in range(3):
        c, *_ = np.linalg.lstsq(A, z, rcond=None)
        r = np.abs(A @ c - z); keep = r < max(1.0, 2.5 * np.median(r))
        if keep.all():
            break
        A, z = A[keep], z[keep]
    return c, float(np.abs(A @ c - z).max())


feats = []
for o in extra:
    m = CM["cad_open"] == o["k"]
    fp = ndimage.binary_dilation(m, iterations=DIL) & ~scan_open
    G = np.pad(ndimage.gaussian_filter(fp.astype(float), 0.7), 2)
    lines = [l for l in contourpy.contour_generator(z=G, line_type="Separate").lines(0.5) if np.linalg.norm(l[0] - l[-1]) < 1e-6]
    for li, L in enumerate(sorted(lines, key=len, reverse=True)):
        P = approximate_polygon(np.c_[xs[0] + (L[:, 0] - 2) * C, ys[0] + (L[:, 1] - 2) * C], 0.08)[:-1]
        xq, yq = P[:, 0], P[:, 1]; cr = xq * np.roll(yq, -1) - np.roll(xq, -1) * yq
        area = 0.5 * cr.sum()
        if abs(area) < 1.0:
            continue
        cx_, cy_ = ((xq + np.roll(xq, -1)) * cr).sum() / (6 * area), ((yq + np.roll(yq, -1)) * cr).sum() / (6 * area)
        from matplotlib.path import Path
        inside = Path(P).contains_points(np.c_[X.ravel(), Y.ravel()]).reshape(X.shape)
        rim = np.nanmedian(ZI[m]) > -1.5
        if rim:      # edge strip at the rim (CAD wall face inboard of the scan): scan outer face over the strip itself, top = rim plane
            cb, eb = fit(m, ZE); ct, et = np.array([0.0, 0.0, 0.0]), 0.0
        else:        # hole / slit end through a wall: plug between the scan exterior and interior over the footprint
            cb, eb = fit(inside, ZE); ct, et = fit(inside, ZI)
        zb = cb[0] * X[inside] + cb[1] * Y[inside] + cb[2]; zt = ct[0] * X[inside] + ct[1] * Y[inside] + ct[2]
        zbm = cb[0] * X[m] + cb[1] * Y[m] + cb[2]; ztm = ct[0] * X[m] + ct[1] * Y[m] + ct[2]
        if (ztm - zbm).min() < (0.0 if rim else 0.5):
            print("skip (top below bottom)", o["ctr"], li); continue
        p0 = [round(cx_, 3), round(cy_, 3)]
        nb = np.array([cb[0], cb[1], -1.0]); nb /= np.linalg.norm(nb)
        nt = np.array([-ct[0], -ct[1], 1.0]); nt /= np.linalg.norm(nt)
        feats.append({"id": f"P_open_{o['ctr'][0]:+.0f}_{o['ctr'][1]:+.0f}" + (f"_{li}" if li else ""), "finding": "gate3", "op": "unite",
                      "side": "A", "clip": "none", "type": "prism", "outline": np.round(P, 3).tolist(),
                      "z0": round(float(zb.min()) - 0.5, 3), "z1": round(float(zt.max()) + (0.0 if rim else 0.5), 3),
                      "cut_planes": [{"p": [p0[0], p0[1], round(float(cb[0] * cx_ + cb[1] * cy_ + cb[2]), 3)], "n": nb.round(5).tolist()}]
                                    + ([] if rim else [{"p": [p0[0], p0[1], round(float(ct[0] * cx_ + ct[1] * cy_ + ct[2]), 3)], "n": nt.round(5).tolist()}]),
                      "evidence": f"census cad_open {o['ctr']} {o['area']} mm2; plan area {abs(area):.1f}; scan ZE fit max res {eb:.2f}, ZI {et:.2f}; "
                                  f"z {zb.mean():.2f}..{zt.mean():.2f}, rim strip {bool(rim)}"})
        print(feats[-1]["id"], feats[-1]["evidence"])
json.dump({"group": "c12_plugs", "features": feats}, open(os.path.join(W, "c12", "plugs.json"), "w"), indent=1)
print(len(feats), "plugs")
