"""Plane sections of the full-res framed scan (orange) and a CAD STL (black), one panel per slice.
usage: r1_sec.py cad.stl out.png axis val a0 a1 b0 b1 [axis val a0 a1 b0 b1 ...]
(a, b) = the other two axes in order (x,y,z minus axis), window a0..a1, b0..b1. Grid 1 mm."""
import sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import load, section

cad, out = sys.argv[1], sys.argv[2]
a = sys.argv[3:]; sl = [(int(a[i]), float(a[i + 1]), *map(float, a[i + 2:i + 6])) for i in range(0, len(a), 6)]
v, f = load()


def read_stl(p):
    with open(p, "rb") as fh:
        fh.read(80); n = int(np.frombuffer(fh.read(4), np.uint32)[0])
        dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
        return np.fromfile(fh, dt, n)["v"].astype(np.float64)


C = read_stl(cad); cv = C.reshape(-1, 3); cf = np.arange(len(cv)).reshape(-1, 3)
n = len(sl); cols = min(n, 3); rows = (n + cols - 1) // cols
fig, axs = plt.subplots(rows, cols, figsize=(7 * cols, 7 * rows), squeeze=False)
NM = "xyz"
for k, (ax_, val, a0, a1, b0, b1) in enumerate(sl):
    oa = [i for i in range(3) if i != ax_]
    lo = np.full(3, -1e9); hi = np.full(3, 1e9)
    lo[ax_], hi[ax_] = val - 2, val + 2; lo[oa[0]], hi[oa[0]] = a0 - 2, a1 + 2; lo[oa[1]], hi[oa[1]] = b0 - 2, b1 + 2
    p = axs[k // cols][k % cols]
    for vv, ff, col, lw in ((v, f, "#e8900c", 1.4), (cv, cf, "black", 0.9)):
        fc = vv[ff[:, 0]]
        m = np.all((fc >= lo) & (fc <= hi), axis=1)
        sg = section(vv, ff, ax_, val, sel=m)
        if len(sg):
            p.add_collection(LineCollection(sg[:, :, oa], colors=col, linewidths=lw))
    p.set_xlim(a0, a1); p.set_ylim(b0, b1); p.set_aspect("equal")
    p.set_xticks(np.arange(np.ceil(a0), a1 + 1e-9, 1), minor=True); p.set_yticks(np.arange(np.ceil(b0), b1 + 1e-9, 1), minor=True)
    p.grid(True, which="minor", lw=0.2, color="#ddd"); p.grid(True, which="major", lw=0.5, color="#aaa")
    p.set_xlabel(NM[oa[0]]); p.set_ylabel(NM[oa[1]]); p.set_title(f"{NM[ax_]} = {val}  (scan orange, CAD black)")
plt.tight_layout(); plt.savefig(out, dpi=90)
print("ok", out)
