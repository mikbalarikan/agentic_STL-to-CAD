"""Relief map of the scan's inner wall over the CAD inner wall in a box: scan faces facing the cavity, coloured by the
signed distance to the CAD solid (+ = scan stands proud of the CAD = CAD lacks material), drawn in the coordinates of a
plane fitted to the CAD inner wall in the box (u right, v = projected +z). Writes out.png and out.json (plane frame).
usage: r1_relief.py cad.stl out.png x0 x1 y0 y1 z0 z1 [clim_lo clim_hi]"""
import sys, json
import numpy as np
import open3d as o3d
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, tri_data

cad, out = sys.argv[1], sys.argv[2]
b = np.array(list(map(float, sys.argv[3:9]))).reshape(3, 2)
cl = (float(sys.argv[9]), float(sys.argv[10])) if len(sys.argv) > 10 else (-1.0, 3.0)
cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices()
CV, CF = np.asarray(cm.vertices), np.asarray(cm.triangles)
rs = o3d.t.geometry.RaycastingScene()
rs.add_triangles(o3d.t.geometry.TriangleMesh(o3d.core.Tensor(CV.astype(np.float32)), o3d.core.Tensor(CF.astype(np.int32))))
cc, cn, ca = tri_data(CV, CF)
inb = lambda p: np.all((p >= b[:, 0]) & (p <= b[:, 1]), axis=1)
# CAD inner wall in the box: faces whose normal points to the cavity side (towards the box centre's +-x side and up)
mid = b.mean(1)
side = np.sign(mid[0]) if abs(mid[0]) > 20 else 0.0
want = np.array([-side, 0.0, 0.5]); want /= np.linalg.norm(want)
mc = inb(cc) & (cn @ want > 0.4)
w = ca[mc]; P = cc[mc]; c0 = (P * w[:, None]).sum(0) / w.sum()
U, S, Vt = np.linalg.svd((P - c0) * np.sqrt(w[:, None]), full_matrices=False)
n = Vt[2]; n = n if n @ want > 0 else -n
v = np.array([0, 0, 1.0]) - n[2] * n; v /= np.linalg.norm(v); u = np.cross(v, n)
v_, f_ = load()
sc, sn, sa = tri_data(v_, f_)
ms = inb(sc) & (sn @ n > 0.3)
Q = sc[ms]
d = rs.compute_signed_distance(o3d.core.Tensor(Q.astype(np.float32))).numpy()
d = -d if False else d
uu, vv = (Q - c0) @ u, (Q - c0) @ v
fig, ax = plt.subplots(figsize=(18, 14))
s_ = ax.scatter(uu, vv, s=0.15, c=d, cmap="turbo", vmin=cl[0], vmax=cl[1])
plt.colorbar(s_, shrink=0.6, label="scan - CAD (mm), + = scan proud of CAD")
ax.set_aspect("equal"); ax.grid(lw=0.3)
ax.set_xticks(np.arange(np.floor(uu.min() / 5) * 5, uu.max() + 5, 5)); ax.set_yticks(np.arange(np.floor(vv.min() / 5) * 5, vv.max() + 5, 5))
ax.tick_params(labelsize=7)
ax.set_title(f"plane c0={c0.round(2).tolist()} n={n.round(3).tolist()} u={u.round(3).tolist()} v={v.round(3).tolist()}")
plt.tight_layout(); plt.savefig(out, dpi=70)
json.dump(dict(c0=c0.tolist(), n=n.tolist(), u=u.tolist(), v=v.tolist(), box=b.tolist()), open(out[:-4] + ".json", "w"), indent=1)
np.savez_compressed(out[:-4] + ".npz", uu=uu.astype(np.float32), vv=vv.astype(np.float32), d=d.astype(np.float32), Q=Q.astype(np.float32))
print("ok", len(Q), c0.round(2), n.round(3))
