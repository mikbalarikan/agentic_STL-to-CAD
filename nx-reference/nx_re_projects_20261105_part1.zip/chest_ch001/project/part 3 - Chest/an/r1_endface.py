"""Bottom end of the chest: scan faces whose normal points to -y (the end face and anything facing the bottom), drawn
in the x-z plane coloured by y, with the CAD faces of the same kind in grey outline. Also prints y of the scan end face
per x/z bin. usage: r1_endface.py cad.stl out.png"""
import sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, tri_data

v, f = load()
c, n, a = tri_data(v, f)
m = (c[:, 1] < -255) & (n[:, 1] < -0.7)
C = c[m]
with open(sys.argv[1], "rb") as fh:
    fh.read(80); k = int(np.frombuffer(fh.read(4), np.uint32)[0])
    T = np.fromfile(fh, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), k)["v"].astype(float)
tc = T.mean(1); tn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); tn /= np.maximum(np.linalg.norm(tn, axis=1), 1e-12)[:, None]
mc = (tc[:, 1] < -255) & (tn[:, 1] < -0.7)
fig, axs = plt.subplots(1, 2, figsize=(26, 11))
s = axs[0].scatter(C[:, 0], C[:, 2], s=0.4, c=C[:, 1], cmap="viridis", vmin=-278, vmax=-262)
plt.colorbar(s, ax=axs[0], label="scan y")
axs[0].set_title("scan faces facing -y (y < -255)")
s2 = axs[1].scatter(tc[mc, 0], tc[mc, 2], s=0.4, c=tc[mc, 1], cmap="viridis", vmin=-278, vmax=-262)
plt.colorbar(s2, ax=axs[1], label="CAD y")
axs[1].set_title("CAD faces facing -y (y < -255)")
for ax in axs:
    ax.set_aspect("equal"); ax.grid(lw=0.3); ax.set_xlim(-85, 85); ax.set_ylim(-100, 5)
    ax.set_xticks(np.arange(-80, 81, 10)); ax.set_yticks(np.arange(-100, 6, 5))
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=60)
# end-face y per bin (median), scan
for zz in (-5, -20, -40, -60, -75, -85):
    row = []
    for xx in range(-75, 80, 10):
        q = (np.abs(C[:, 0] - xx) < 2.5) & (np.abs(C[:, 2] - zz) < 2.5)
        row.append(f"{np.median(C[q, 1]):7.1f}" if q.sum() > 5 else "     - ")
    print(f"z {zz:4d}:", " ".join(row))
print("x bins:", list(range(-75, 80, 10)))
