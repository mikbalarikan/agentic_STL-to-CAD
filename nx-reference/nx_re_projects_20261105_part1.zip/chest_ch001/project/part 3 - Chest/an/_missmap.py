"""Miss-density plan map: number of zone points with |d| > 0.5 per 5 mm cell. usage: _missmap.py tag zone(3 inner|2 rim) [sign +|-|a]"""
import sys, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W
tag, zi = sys.argv[1], int(sys.argv[2]); sg = sys.argv[3] if len(sys.argv) > 3 else "a"
A = np.load(os.path.join(W, f"dev2_{tag}_scan2cad.npy")); P, d = A[:, :3], A[:, 3]
Z = np.load(os.path.join(W, "rv", "zones400k.npy"))
m = (Z == zi) & ((d > .5) if sg == "+" else (d < -.5) if sg == "-" else (np.abs(d) > .5))
H, xe, ye = np.histogram2d(P[m, 0], P[m, 1], bins=[np.arange(-170, 171, 5), np.arange(-280, 121, 5)])
fig, ax = plt.subplots(figsize=(17, 20))
im = ax.imshow(H.T, origin="lower", extent=[-170, 170, -280, 120], cmap="magma_r", vmax=np.percentile(H[H > 0], 98))
ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.tick_params(labelsize=6); ax.grid(lw=0.3, color="c")
plt.colorbar(im, shrink=.5); ax.set_title(f"{tag} zone {zi} misses {sg}: {m.sum()} of {(Z==zi).sum()}")
fig.tight_layout(); fig.savefig(os.path.join(W, "rv", f"miss_{tag}_{zi}{sg}.png"), dpi=55)
