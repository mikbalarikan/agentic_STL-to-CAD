import os, json, numpy as np
from common import W
from arcfit import seg_points
P0 = np.array([55.5, 96.0])
for fn in ("pads.json", "recess.json", "bumps.json"):
    D = json.load(open(os.path.join(W, fn)))
    for L in D["loops"]:
        for S in [L["segs"]] + L["holes"]:
            Q = np.vstack([seg_points([g[0], np.array(g[1]), np.array(g[2])] + ([np.array(g[3]), g[4], g[5]] if g[0] == "A" else [])) for g in S])
            d = np.min(np.hypot(*(Q - P0).T))
            if d < 1.5:
                print(fn, "level", L["T"], "area", round(L["area"]), "dist", round(d, 2))
