"""outC10 smooth exterior pockets (review F08 / F27: no terraces on exterior faces).
The stepped recesses (work/recess.json, 0.7 mm levels) are replaced, for the multi-level pockets (lower vent box, upper
vent box, side scoops, shoulder vents), by ONE cut tool per pocket: a Z prism over the pocket trimmed by a smooth sheet
z_sheet(x, y) = the scan's exterior height map inside the pocket, pushed 0.6 mm outside the CAD skin beyond the mouth.
The sheet is a loft through constant-x sections whose poles are the smoothed samples (B-spline poles: no overshoot).
Height maps along Z: scan `bot` (work/hmap.npz) and the Rev A CAD skin (nx/outB12/chest_G.stl, no recesses) cast here.
usage: c10_pockets.py [plot]  -> work/c10/pockets.json, work/c10/pockets/*.png"""
import os, sys, json
import numpy as np
from scipy import ndimage
import open3d as o3d
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.path import Path
from common import W, ROOT
from arcfit import seg_points

OUTD = os.path.join(W, "c10", "pockets"); os.makedirs(OUTD, exist_ok=True)
H = np.load(os.path.join(W, "hmap.npz"))
x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
bot = H["bot"].astype(np.float64)
ny, nx = bot.shape
xs = x0 + np.arange(nx) * st; ys = y0 + np.arange(ny) * st
X, Y = np.meshgrid(xs, ys)

cache = os.path.join(W, "c10", "botB12.npy")
if os.path.exists(cache):
    botB = np.load(cache)
else:
    def read_stl(p):
        with open(p, "rb") as fh:
            fh.read(80); n = int(np.frombuffer(fh.read(4), np.uint32)[0])
            dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
            return np.fromfile(fh, dt, n)["v"]
    T = read_stl(os.path.join(ROOT, "nx", "outB12", "chest_G.stl")).reshape(-1, 3)
    m = o3d.t.geometry.TriangleMesh()
    m.vertex.positions = o3d.core.Tensor(T.astype(np.float32))
    m.triangle.indices = o3d.core.Tensor(np.arange(len(T), dtype=np.int32).reshape(-1, 3))
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(m)
    rays = np.zeros((X.size, 6), np.float32); rays[:, 0] = X.ravel(); rays[:, 1] = Y.ravel(); rays[:, 2] = -200.0; rays[:, 5] = 1.0
    t = sc.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
    botB = np.where(np.isfinite(t), -200.0 + t, np.nan).reshape(X.shape)
    np.save(cache, botB)

dz = bot - botB                       # > 0: the scan surface lies deeper (toward +Z) than the skin = recess

# pockets: the multi-level groups of work/recess.json, picked by their level-0 loop box (right half)
R = json.load(open(os.path.join(W, "recess.json")))


def loop_pts(L):
    return np.vstack([seg_points([g[0], np.array(g[1]), np.array(g[2])] + ([np.array(g[3]), g[4], g[5]] if g[0] == "A" else [])) for g in L["segs"]])


POCKETS = {   # name: (box of the level-0 loop centre, side)  side C = full width (crosses the mid-plane), R = +x and mirrored
    "lower_vent": ((-3, 50, -230, -195), "C"),
    "upper_vent": ((-3, 65, -50, -9), "C"),
    "side_scoop": ((98, 132, -133, -45), "R"),
    "shoulder_vent": ((70, 132, 54, 86), "R"),
}
out = {"note": __doc__.split("\n")[0], "pockets": []}
for name, (bx, side) in POCKETS.items():
    L0 = [L for L in R["loops"] if L["k"] == 0]
    sel = []
    for L in L0:
        Q = loop_pts(L); c = Q.mean(0)
        if bx[0] <= Q[:, 0].min() + 0.5 and Q[:, 0].max() <= bx[1] and bx[2] <= Q[:, 1].min() and Q[:, 1].max() <= bx[3]:
            sel.append(Q)
    if not sel:
        print(name, "no loop"); continue
    Q = max(sel, key=lambda q: abs(np.sum(q[:, 0] * np.roll(q[:, 1], -1) - q[:, 1] * np.roll(q[:, 0], -1))))
    mouth = Path(Q).contains_points(np.c_[X.ravel(), Y.ravel()]).reshape(X.shape)
    if side == "C":
        mouth = mouth | mouth[:, ::-1] if abs(xs[0] + xs[-1]) < st else mouth
        # symmetric grid check: x(i) = -x(nx-1-i)
    print(name, "grid symmetric", abs(xs[0] + xs[-1]) < 1e-6, "mouth cells", mouth.sum())
    out["pockets"].append(dict(name=name, side=side, loop=Q.tolist()))
    # stats
    d = dz[mouth]
    print(f"  depth p10 {np.nanpercentile(d,10):.2f} p50 {np.nanpercentile(d,50):.2f} p90 {np.nanpercentile(d,90):.2f} max {np.nanmax(d):.2f}"
          f"  nan {np.isnan(d).mean():.2f}  |nz| p10 {np.nanpercentile(np.abs(H['nbot'][mouth]),10):.2f}")
    if "plot" in sys.argv:
        r0, r1 = np.where(mouth.any(1))[0][[0, -1]]; c0, c1 = np.where(mouth.any(0))[0][[0, -1]]
        r0, c0 = max(r0 - 20, 0), max(c0 - 20, 0); r1, c1 = r1 + 20, c1 + 20
        fig, axs = plt.subplots(1, 3, figsize=(24, 8))
        ext = [xs[c0], xs[c1], ys[r0], ys[r1]]
        axs[0].imshow(dz[r0:r1, c0:c1], origin="lower", extent=ext, cmap="turbo", vmin=-1, vmax=14); axs[0].set_title(name + " depth_z scan-skin")
        axs[0].plot(Q[:, 0], Q[:, 1], "w-", lw=0.6)
        axs[1].imshow(np.abs(H["nbot"][r0:r1, c0:c1]), origin="lower", extent=ext, cmap="gray", vmin=0, vmax=1); axs[1].set_title("|n_z| scan")
        rmid = (r0 + r1) // 2; cmid = (c0 + c1) // 2
        axs[2].plot(xs[c0:c1], bot[rmid, c0:c1], "k-", label=f"scan bot y={ys[rmid]:.1f}")
        axs[2].plot(xs[c0:c1], botB[rmid, c0:c1], "r-", label="skin")
        axs[2].plot(ys[r0:r1] - ys[r0] + xs[c0], bot[r0:r1, cmid], "b-", label=f"scan bot x={xs[cmid]:.1f} (y shifted)")
        axs[2].plot(ys[r0:r1] - ys[r0] + xs[c0], botB[r0:r1, cmid], "m-")
        axs[2].legend(); axs[2].set_aspect("equal")
        fig.tight_layout(); fig.savefig(os.path.join(OUTD, name + ".png"), dpi=60); plt.close(fig)
json.dump(out, open(os.path.join(W, "c10", "pockets_loops.json"), "w"))
