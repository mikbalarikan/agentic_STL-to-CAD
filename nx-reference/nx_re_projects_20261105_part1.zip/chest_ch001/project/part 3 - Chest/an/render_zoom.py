"""One zoomed CAD-alone view. usage: render_zoom.py cad.stl out.png fx,fy,fz dx,dy,dz scale"""
import sys
import numpy as np, pyvista as pv
m = pv.read(sys.argv[1]).compute_normals(split_vertices=True, feature_angle=30)
f = np.array([float(v) for v in sys.argv[3].split(",")]); dv = np.array([float(v) for v in sys.argv[4].split(",")])
p = pv.Plotter(off_screen=True, window_size=(1200, 1200)); p.set_background("white")
p.add_mesh(m, color=(0.66, 0.68, 0.70), smooth_shading=True, specular=0.3, ambient=0.2, diffuse=0.8); p.enable_lightkit()
p.camera_position = [tuple(f + dv / np.linalg.norm(dv) * 900), tuple(f), (0, 1, 0)]
p.enable_parallel_projection(); p.camera.parallel_scale = float(sys.argv[5]); p.screenshot(sys.argv[2]); p.close(); print("ok")
