"""Stepped wall pads (interior thickening: panel-line ridge bands, lower side pads, rim and neck lips, box ramps).
The interior wall thickness t (work/tmap.npz, distance of the interior surface to the exterior skin) is made
symmetric (mean of t(x) and t(-x)), masked (front panel pocket, shoulder flanges) and cut into levels
T_k = wall + k * STEP. Level k region = {t >= T_k - STEP/2}; in NX each region outline is extruded along Z and
intersected with a Shell of the envelope of thickness T_k, the pieces united: the CAD wall then follows t within
+-STEP/2. Right half only (x >= -0.6), mirrored with the body.  usage: s31_pads.py [step] [t_max]
Writes work/pads.json + work/rv/pads.png."""
import os, json, sys
import numpy as np
from scipy import ndimage
import contourpy
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.path import Path
from common import W, ROOT
from arcfit import fit_loop, seg_points

MODE = sys.argv[3] if len(sys.argv) > 3 else "pad"          # pad: tmap, base wall, right half; recess: emap, base 0, full width
STEP = float(sys.argv[1]) if len(sys.argv) > 1 else 0.7
TMAX = float(sys.argv[2]) if len(sys.argv) > 2 else 12.0
P = json.load(open(os.path.join(ROOT, "nx", "params.json")))
WALL = P["wall_t"]
M = np.load(os.path.join(W, "tmap.npz" if MODE == "pad" else "emap.npz"))
t, x0, y0, st = M["t" if MODE == "pad" else "e"].astype(np.float64), float(M["x0"]), float(M["y0"]), float(M["step"])
if MODE == "recess":
    WALL = 0.0
if MODE == "bump":                 # exterior standing out of the fitted skin: -e, built from outward shells
    WALL = 0.0; t = -t
ny, nx = t.shape
XX, YY = np.meshgrid(x0 + np.arange(nx) * st, y0 + np.arange(ny) * st)
# symmetric thickness: x(i) = -x(nx - i)
tm = np.full_like(t, np.nan)
tm[:, 1:] = t[:, ::-1][:, :-1]
ts = np.where(np.isnan(t), tm, np.where(np.isnan(tm), t, 0.5 * (t + tm)))
# masks
mask = np.zeros(t.shape, bool)
from arcfit import seg_points as _sp
poly = np.vstack([_sp([s[0], np.array(s[1]), np.array(s[2])] + ([np.array(s[3]), s[4], s[5]] if s[0] == "A" else []))
                  for s in P["panel"]["outline_segs"]])
pin = Path(poly).contains_points(np.c_[XX.ravel(), YY.ravel()]).reshape(t.shape)
mask |= ndimage.binary_dilation(pin, iterations=int(2.0 / st))
a = np.radians(P["shoulder"]["angle_deg"]); nsh = np.array([np.cos(a), np.sin(a)])
dsh = np.abs(np.abs(XX) * nsh[0] + YY * nsh[1] - P["shoulder"]["xc"])
mask |= (dsh < 9.0) & (np.abs(YY) < 75)
if MODE in ("pad", "recess", "bump"):  # right half; recess tools and bump pieces are mirrored in NX
    if MODE != "pad":
        mask |= XX < -2.0     # outlines >= 1.5 mm off the mid-plane face of the half shells (outC6: near-coincident at x 0)
    # pads (outC10, review F01/F02/F13): regions run ACROSS the mid-plane to x = -3 (clipped below), so the piece is
    # cut exactly at x = 0 by the half shell copy and fuses with its mirror image; no gap at |x| < 2 any more
if MODE == "pad":
    # plateau footprints (+ their mirror images) + 0.4: the plateau column already fills the full depth there, and a
    # pad outline that nearly coincides with a plateau wall made the plateau's unite fail (outC4, band at y 33..44)
    PLT = json.load(open(os.path.join(W, "plateaus.json")))
    fp = np.zeros(t.shape, bool)
    pts = np.c_[XX.ravel(), YY.ravel()]
    for L in PLT["loops"]:
        if L["area"] <= 0:
            continue
        Q = np.vstack([seg_points([g[0], np.array(g[1]), np.array(g[2])] + ([np.array(g[3]), g[4], g[5]] if g[0] == "A" else [])) for g in L["segs"]])
        for sx in ((1.0, -1.0) if L["kind"] in ("R", "C") else (1.0,)):   # one-sided (A) plateaus: own place only
            Qm = Q * [sx, 1.0]
            x0q, y0q = Qm.min(0) - 1; x1q, y1q = Qm.max(0) + 1
            sel = (pts[:, 0] > x0q) & (pts[:, 0] < x1q) & (pts[:, 1] > y0q) & (pts[:, 1] < y1q)
            if sel.any():
                fp.ravel()[np.where(sel)[0][Path(Qm).contains_points(pts[sel])]] = True
    # outC10 (review F01 slit under the cross rib, F05): pads reach 0.75 mm UNDER the plateau footprints (overlap)
    # instead of stopping 0.5 mm short of them (that gap let the exterior pockets cut through)
    mask |= ndimage.binary_erosion(fp, iterations=3)
# outC10 pad zones from the review-fix measurements (work/c10/G*.json "pad_zones"): wall thickness capped at tmax
# inside each polygon (given for x >= 0, applied at +-x)
if MODE == "pad":
    import glob
    for gj in sorted(glob.glob(os.path.join(W, "c10", "G*.json"))):
        for Z in json.load(open(gj)).get("pad_zones", []):
            pz = np.array(Z["poly"], float)
            inz = Path(pz).contains_points(np.c_[np.abs(XX).ravel(), YY.ravel()]).reshape(t.shape)
            ts = np.where(inz, np.minimum(ts, Z["tmax"]), ts)
            print("pad zone", os.path.basename(gj), Z.get("why", ""), "cells", int(inz.sum()), "tmax", Z["tmax"])
good = ~np.isnan(ts) & ~mask
# cells outside the part (no data, connected to the map border): a region touching the part edge is extended 2 mm
# into them, so no prism wall runs along an edge face of the part (outC8: sliver face at the neck cut, x 55.5 y 96,
# from the neck-lip pad and neck-chamfer recess outlines 0.1-0.2 mm from the cut -> BodyConsistency 1)
nan_ = np.isnan(ts)
labn, nn = ndimage.label(nan_)
edge_labs = set(np.unique(np.r_[labn[0], labn[-1], labn[:, 0], labn[:, -1]])) - {0}
outside = np.isin(labn, list(edge_labs))
edge_band = ndimage.binary_dilation(outside, iterations=3)          # outside + the last 0.75 mm of the part
SEP = 0.4             # EDT steps 0.25 / 0.354 / 0.5: >= 0.4 keeps outlines 2 px (0.5 mm) apart
FITTOL = 0.15         # outline fit tolerance: 0.08 gave ~7000 segments -> 19 400 faces, a 352 MB STEP (outC5);
                      # 0.5 broke the level separation and gave invalid sections (outC6)
AMIN = 12.0           # smallest region kept, mm2
levels = []
T = WALL + STEP
while T <= TMAX + 1e-9:
    levels.append(round(T, 3)); T += STEP


def _simple(Pp):
    """True if the closed polyline Pp (k,2) does not cross itself."""
    A_ = Pp; B_ = np.roll(Pp, -1, axis=0); n = len(A_)
    d1 = B_ - A_
    for i in range(n):
        p, r = A_[i], d1[i]
        q, sv = A_, d1
        den = r[0] * sv[:, 1] - r[1] * sv[:, 0]
        ok = np.abs(den) > 1e-12
        qp = q - p
        t = np.where(ok, (qp[:, 0] * sv[:, 1] - qp[:, 1] * sv[:, 0]) / np.where(ok, den, 1), -1)
        u = np.where(ok, (qp[:, 0] * r[1] - qp[:, 1] * r[0]) / np.where(ok, den, 1), -1)
        hit = ok & (t > 1e-6) & (t < 1 - 1e-6) & (u > 1e-6) & (u < 1 - 1e-6)
        hit[[i, (i - 1) % n, (i + 1) % n]] = False
        if hit.any():
            return False
    return True


def fit_valid(Q):
    """Line/arc loop within tolerance of the contour Q that is a simple polygon; finer tolerance if not."""
    for tol in (FITTOL, 0.08, 0.04):
        try:
            segs = fit_loop(Q, tol=tol, resample=0.3 if tol > 0.1 else 0.15)
        except Exception:  # noqa: BLE001
            continue
        Pp = np.vstack([seg_points(sg, 8)[:-1] for sg in segs])
        dmax = max(np.min(np.hypot(Q[:, 0] - x, Q[:, 1] - y)) for x, y in Pp[::3])
        if dmax < 3 * tol + 0.1 and _simple(Pp):
            return segs
    return None


def to_mm(rc):
    return np.c_[x0 + rc[:, 1] * st, y0 + rc[:, 0] * st]


def area(Q):
    return 0.5 * (np.dot(Q[:, 0], np.roll(Q[:, 1], -1)) - np.dot(Q[:, 1], np.roll(Q[:, 0], -1)))


def segs_json(segs):
    return [([s[0], s[1].tolist(), s[2].tolist()] if s[0] == "L" else [s[0], s[1].tolist(), s[2].tolist(), s[3].tolist(), float(s[4]), bool(s[5])]) for s in segs]


out = {"step": STEP, "levels": levels, "loops": []}
fig, ax = plt.subplots(figsize=(14 if MODE == "pad" else 26, 21))
ax.imshow(np.where(good, ts, np.nan), origin="lower", extent=[x0, x0 + nx * st, y0, y0 + ny * st], cmap="Greys", vmin=2, vmax=14, alpha=0.7)
cm = plt.get_cmap("turbo")
Rprev = None
for k, T in enumerate(levels):
    R = good & (ts >= T - STEP / 2)
    R = ndimage.binary_opening(R, iterations=2)
    if Rprev is not None:
        # a level's outline must stay >= 0.25 mm inside the one below: at steep walls (rib roots, box walls) the
        # outlines of successive levels otherwise nearly coincide and NX booleans fail with intersection gaps
        R &= ndimage.distance_transform_edt(Rprev) * st >= SEP
    Rprev = R.copy()
    if MODE == "pad":
        # outC10 (review F05 slit cracks): every region grown 0.75 mm so its piece overlaps the wall / the neighbour
        # piece it meets instead of stopping 0.1-0.5 mm short (equal growth keeps the level separation SEP)
        R = ndimage.binary_dilation(R, iterations=3)       # (the piece is clipped by the shell copy anyway)
    R = R | (ndimage.binary_dilation(R, iterations=int(round(2.0 / st))) & edge_band)
    if MODE == "pad":
        R &= XX >= -3.0
    lab, n = ndimage.label(R)
    if n == 0:
        continue
    sizes = ndimage.sum(R, lab, range(1, n + 1)) * st * st
    R = np.isin(lab, 1 + np.where(sizes >= AMIN)[0])
    # close pin-holes (< 3 mm2) so tiny holes do not become loops
    hl, hn = ndimage.label(ndimage.binary_fill_holes(R) & ~R)
    if hn:
        hs = ndimage.sum(np.ones_like(R), hl, range(1, hn + 1)) * st * st
        R |= np.isin(hl, 1 + np.where(hs < (25.0 if MODE == "pad" else 3.0))[0])   # outC10: vent slots (~10 mm2) no longer hollow the pads (thin floor at the shoulder vents); the slots are cut again
    G = ndimage.gaussian_filter(R.astype(float), 1.5)
    G = np.pad(G, 2, constant_values=0.0)
    loops = []
    for C in contourpy.contour_generator(z=G, line_type="Separate").lines(0.5):
        if np.linalg.norm(C[0] - C[-1]) > 1e-6:
            continue
        Q = to_mm(C[:, ::-1] - 2.0)[:-1]
        A = area(Q)
        if abs(A) < (AMIN if A > 0 else 6.0):
            continue
        segs = fit_valid(Q)
        if segs is None:
            continue
        loops.append(dict(A=A, Q=Q, segs=segs))
    outer = [L for L in loops if L["A"] > 0]
    for L in outer:
        L["holes"] = []
    for H in [L for L in loops if L["A"] < 0]:
        for L in outer:
            if Path(L["Q"]).contains_point(H["Q"][0]):
                L["holes"].append(H); break
    for L in outer:
        out["loops"].append(dict(T=T, k=k, area=float(L["A"]), n_seg=len(L["segs"]) + sum(len(H["segs"]) for H in L["holes"]),
                                 segs=segs_json(L["segs"]), holes=[segs_json(H["segs"]) for H in L["holes"]]))
        for S in [L] + L["holes"]:
            Qp = np.vstack([seg_points(s) for s in S["segs"]])
            ax.plot(Qp[:, 0], Qp[:, 1], "-", lw=0.5, color=cm(k / max(1, len(levels) - 1)))
json.dump(out, open(os.path.join(W, {"pad": "pads.json", "recess": "recess.json", "bump": "bumps.json"}[MODE]), "w"))
from collections import Counter
c = Counter(L["k"] for L in out["loops"])
print("levels", levels)
print("loops per level", dict(sorted(c.items())), "total", len(out["loops"]), "segs", sum(L["n_seg"] for L in out["loops"]))
ax.set_xlim(-5 if MODE == "pad" else -170, 170); ax.set_ylim(-280, 120); ax.set_aspect("equal"); ax.set_xticks(np.arange(0, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.grid(lw=.3)
fig.tight_layout(); fig.savefig(os.path.join(W, "rv", MODE + "s.png"), dpi=70)
