"""Wall thickness: rays from the exterior surface inward along the exterior normal, first hit = interior wall.
Exterior points = 'bot' height map hits (seen from -Z) with consistent normals. Writes work/wall.npz + map."""
import os
import numpy as np
import open3d as o3d
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W, load

v, f = load()
m = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
H = np.load(os.path.join(W, "hmap.npz"))
st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"])
bot = H["bot"]
J, I = np.nonzero(np.isfinite(bot))
sel = (J % 4 == 0) & (I % 4 == 0)
J, I = J[sel], I[sel]
P = np.c_[x0 + I * st, y0 + J * st, bot[J, I]]
# exterior normal from a local plane: use the hit primitive normal of a ray from -Z
rays = np.c_[P[:, :2], np.full(len(P), -200.0), np.zeros((len(P), 2)), np.ones(len(P))].astype(np.float32)
r = sc.cast_rays(o3d.core.Tensor(rays))
nrm = r["primitive_normals"].numpy().astype(np.float64)
nrm *= np.sign(nrm[:, 2:3] + 1e-9)             # make it point inward (+Z side)
start = P + 0.05 * nrm
r2 = sc.cast_rays(o3d.core.Tensor(np.c_[start, nrm].astype(np.float32)))
t = r2["t_hit"].numpy() + 0.05
ok = np.isfinite(t) & (t < 15) & (np.abs(nrm[:, 2]) > 0.3)
t = np.where(ok, t, np.nan)
np.savez(os.path.join(W, "wall.npz"), P=P, t=t, n=nrm)
tt = t[np.isfinite(t)]
print("wall t: n", len(tt), "p5/25/50/75/95", np.round(np.percentile(tt, [5, 25, 50, 75, 95]), 3))
h, e = np.histogram(tt, bins=np.arange(0, 8, 0.05))
print("mode", round(e[np.argmax(h)] + 0.025, 3), "share 2.2-2.8:", round(((tt > 2.2) & (tt < 2.8)).mean(), 3))
fig, ax = plt.subplots(figsize=(14, 16))
s_ = ax.scatter(P[:, 0], P[:, 1], c=np.clip(t, 1.5, 4.0), s=1.5, cmap="turbo")
plt.colorbar(s_, ax=ax, shrink=0.6); ax.set_aspect("equal"); ax.grid(True, lw=0.3)
ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-190, 201, 10)); ax.tick_params(labelsize=6)
fig.tight_layout(); fig.savefig(os.path.join(W, "wall_map.png"), dpi=70)
