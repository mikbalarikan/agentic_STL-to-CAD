"""Plan maps of interior misses split by thickness class."""
import os, sys
import numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
tag = sys.argv[1]
A = np.load(os.path.join(W, f"dev2_{tag}_scan2cad.npy")); P, d = A[:, :3], A[:, 3]
Z = np.load(os.path.join(W, "rv", "zones400k.npy")); t = -np.load(os.path.join(W, "rv", "t400k.npy"))
cls = {"tneg": t < -1, "t0_3": (t > -1) & (t < 2.75), "t4_9": (t > 3.75) & (t < 9), "t9p": t > 9}
fig, axs = plt.subplots(1, 4, figsize=(40, 13))
for a_, (k, c) in zip(axs, cls.items()):
    m = (Z >= 2) & c & (np.abs(d) > .5)
    H, xe, ye = np.histogram2d(P[m, 0], P[m, 1], bins=[np.arange(-170, 171, 4), np.arange(-280, 121, 4)])
    a_.imshow(H.T, origin="lower", extent=[-170, 170, -280, 120], cmap="magma_r", vmax=max(1, np.percentile(H[H > 0], 97)))
    a_.set_xticks(np.arange(-170, 171, 20)); a_.set_yticks(np.arange(-280, 121, 20)); a_.grid(lw=.3, color="c"); a_.set_title(f"{k}: {m.sum()}")
fig.tight_layout(); fig.savefig(os.path.join(W, "rv", f"tmap_{tag}.png"), dpi=45)
