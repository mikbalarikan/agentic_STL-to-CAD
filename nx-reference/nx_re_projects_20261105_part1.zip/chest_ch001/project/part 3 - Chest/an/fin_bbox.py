"""Add the exact bounding box, watertightness and volume of the delivered CAD tessellation to _finalize.json (the NX
box of the B-spline body is padded by up to 23 mm).  usage: fin_bbox.py deliver/CAD"""
import sys, os, json
import trimesh
d = sys.argv[1]
m = trimesh.load(os.path.join(d, "CH-001_Chest.stl"), process=False)
m.merge_vertices(digits_vertex=4)
fj = os.path.join(d, "_finalize.json"); F = json.load(open(fj))
b = m.bounds
F["bbox_exact_stl"] = [round(float(x), 3) for x in list(b[0]) + list(b[1])]
F["stl_watertight"] = bool(m.is_watertight)
F["stl_volume_mm3"] = float(abs(m.volume))
F["stl_open_edges"] = int(len(trimesh.grouping.group_rows(m.edges_sorted, require_count=1)))
json.dump(F, open(fj, "w"), indent=1)
print(F["bbox_exact_stl"], F["stl_watertight"], round(F["stl_volume_mm3"]), F["stl_open_edges"], "NX", round(F["volume_mm3"]))
