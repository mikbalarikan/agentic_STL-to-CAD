"""Measure a rib on the scan ZI map along a guessed centre line. usage: clean_rib.py x0 y0 x1 y1 [halfwin=4] [n=9]
Per station: top z (max in the window), width of the run with z >= top-0.5 around the max, centre offset (+ = left
of p0->p1). Prints medians -> rib centre line, width, top."""
import sys, os
import numpy as np
from scipy.ndimage import map_coordinates
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = np.load(os.path.join(ROOT, "work", "clean", "relief.npz")); Z = R["z"].astype(float); xs, ys = R["xs"], R["ys"]
a = list(map(float, sys.argv[1:5])); hw = float(sys.argv[5]) if len(sys.argv) > 5 else 4.0; n = int(sys.argv[6]) if len(sys.argv) > 6 else 9
p0, p1 = np.array(a[:2]), np.array(a[2:]); t = p1 - p0; L = np.linalg.norm(t); t /= L; nrm = np.array([-t[1], t[0]])
Zf = np.where(np.isfinite(Z), Z, -300.0)
def zat(P):
    return map_coordinates(Zf, [(P[:, 1] - ys[0]) / 0.25, (P[:, 0] - xs[0]) / 0.25], order=1)
offs = np.arange(-hw, hw + 1e-9, 0.05)
rows = []
for s in np.linspace(0.1, 0.9, n) * L:
    c = p0 + t * s
    z = zat(c[None, :] + offs[:, None] * nrm[None, :])
    k = np.argmax(z); top = z[k]
    i = k
    while i > 0 and z[i - 1] >= top - 0.5: i -= 1
    j = k
    while j < len(z) - 1 and z[j + 1] >= top - 0.5: j += 1
    rows.append((s, top, offs[j] - offs[i], 0.5 * (offs[i] + offs[j]), z[0], z[-1]))
    print(f"s {s:6.1f} top {top:8.2f} width {offs[j]-offs[i]:5.2f} centre {0.5*(offs[i]+offs[j]):+5.2f}  edges z {z[0]:8.2f} {z[-1]:8.2f}")
r = np.array(rows)
print(f"MEDIAN top {np.median(r[:,1]):.2f} width {np.median(r[:,2]):.2f} centre {np.median(r[:,3]):+.2f}")
