import os, numpy as np
from common import W
H = np.load(os.path.join(W, "hmap.npz")); st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"]); top = H["top"]
for (x, y) in ((123.0, -170.0), (99.5, -230.0), (141.5, -100.0), (106, 70)):
    i = int(round((y - y0) / st)); j0 = int(round((x - 6 - x0) / st))
    print((x, y), np.round(top[i, j0:j0 + 48:2], 2))
from scipy import ndimage
ny, nx = top.shape
XX, YY = np.meshgrid(x0 + np.arange(nx) * st, y0 + np.arange(ny) * st)
part = ~np.isnan(top)
edge = ndimage.distance_transform_edt(ndimage.binary_fill_holes(part)) * st
R0 = (top > 0.6) & (top < 4.0)
print("R0", R0.sum(), "edge<8", (R0 & (edge < 8)).sum(), "edge stats at R0", np.percentile(edge[R0], [5, 50, 95]) if R0.any() else None)
