"""Closed polyline -> chain of lines and arcs within a tolerance (pure numpy).
Breakpoints are polygon vertices, so the chain is continuous; arcs pass through both ends.
segments: ("L", p0, p1) | ("A", p0, p1, centre, radius, ccw)"""
import numpy as np


def _x2(u, v):
    return u[0] * v[1] - u[1] * v[0]


def _line_dev(P):
    a, b = P[0], P[-1]
    d = b - a
    L = np.linalg.norm(d)
    if L < 1e-9:
        return np.max(np.linalg.norm(P - a, axis=1))
    n = np.array([-d[1], d[0]]) / L
    return np.max(np.abs((P - a) @ n))


def _arc_fit(P):
    """Circle through P[0], P[-1] with the centre on their bisector, least squares on the rest."""
    a, b = P[0], P[-1]
    m = (a + b) / 2
    d = b - a
    L = np.linalg.norm(d)
    if L < 1e-6 or len(P) < 4:
        return None
    n = np.array([-d[1], d[0]]) / L
    # centre c = m + s n ; residual |p - c| - |a - c|
    best = None
    # solve linearised: |p-c|^2 - |a-c|^2 = 0 -> linear in s
    # |p-m-sn|^2 - |a-m-sn|^2 = |p-m|^2 - |a-m|^2 - 2 s n.(p-m) + 2 s n.(a-m) = 0 ; n.(a-m)=0
    q = P[1:-1] - m
    A = 2 * (q @ n)
    B = (q * q).sum(1) - (L / 2) ** 2
    den = (A * A).sum()
    if den < 1e-12:
        return None
    s = (A * B).sum() / den
    c = m + s * n
    r = np.linalg.norm(a - c)
    if r > 5000:
        return None
    dev = np.max(np.abs(np.linalg.norm(P - c, axis=1) - r))
    # direction: sign of cross of (a-c) to midpoint
    mid = P[len(P) // 2] - c
    ccw = _x2(a - c, mid) > 0
    # sweep must be consistent: angles monotone
    ang = np.unwrap(np.arctan2(P[:, 1] - c[1], P[:, 0] - c[0]))
    da = np.diff(ang)
    if not (np.all(da > -1e-3) or np.all(da < 1e-3)):
        return None
    if abs(ang[-1] - ang[0]) > np.radians(300):
        return None
    return c, r, dev, bool(ccw)


def fit_open(P, tol, min_len=0.4):
    """Recursive split of an open polyline."""
    if len(P) < 3 or np.linalg.norm(P[-1] - P[0]) < min_len:
        return [("L", P[0], P[-1])]
    if _line_dev(P) <= tol:
        return [("L", P[0], P[-1])]
    af = _arc_fit(P)
    if af is not None and af[2] <= tol and af[1] > 0.3:
        c, r, dev, ccw = af
        return [("A", P[0], P[-1], c, r, ccw)]
    # split at max deviation from the chord
    a, b = P[0], P[-1]
    d = b - a
    L = np.linalg.norm(d)
    if L < 1e-9:
        k = len(P) // 2
    else:
        n = np.array([-d[1], d[0]]) / L
        k = int(np.argmax(np.abs((P - a) @ n)))
        k = min(max(k, 1), len(P) - 2)
    return fit_open(P[:k + 1], tol, min_len) + fit_open(P[k:], tol, min_len)


def merge(segs, Pfull_lookup, tol):
    """Greedy merge of neighbours when a single line/arc still fits the union of their points."""
    changed = True
    while changed and len(segs) > 1:
        changed = False
        out = []
        i = 0
        while i < len(segs):
            if i + 1 < len(segs):
                P = Pfull_lookup(segs[i][1], segs[i + 1][2])
                if P is not None and len(P) >= 3:
                    cand = None
                    if _line_dev(P) <= tol:
                        cand = ("L", P[0], P[-1])
                    else:
                        af = _arc_fit(P)
                        if af is not None and af[2] <= tol:
                            cand = ("A", P[0], P[-1], af[0], af[1], af[3])
                    if cand is not None:
                        out.append(cand); i += 2; changed = True
                        continue
            out.append(segs[i]); i += 1
        segs = out
    return segs


def corners(P, win=6, ang=35.0):
    """Indices of sharp corners (turning > ang deg over +-win points)."""
    n = len(P)
    idx = []
    for i in range(n):
        a = P[(i - win) % n]; b = P[i]; c = P[(i + win) % n]
        u = b - a; v = c - b
        if np.linalg.norm(u) < 1e-9 or np.linalg.norm(v) < 1e-9:
            continue
        t = np.degrees(np.arccos(np.clip(u @ v / np.linalg.norm(u) / np.linalg.norm(v), -1, 1)))
        if t > ang:
            idx.append((t, i))
    # non-max suppression
    keep = []
    for t, i in sorted(idx, reverse=True):
        if all(min(abs(i - j), n - abs(i - j)) > win for j in keep):
            keep.append(i)
    return sorted(keep)


def fit_loop(P, tol=0.06, resample=0.15):
    """P closed polygon (k,2) without repeated end. Returns segment chain."""
    # resample uniformly
    Q = np.vstack([P, P[:1]])
    L = np.r_[0, np.cumsum(np.linalg.norm(np.diff(Q, axis=0), axis=1))]
    s = np.arange(0, L[-1], resample)
    R = np.c_[np.interp(s, L, Q[:, 0]), np.interp(s, L, Q[:, 1])]
    n = len(R)
    cs = corners(R)
    if not cs:
        cs = [0, n // 3, 2 * n // 3]
    elif len(cs) == 1:
        cs = [cs[0], (cs[0] + n // 2) % n]
        cs.sort()
    segs = []
    for k in range(len(cs)):
        i0, i1 = cs[k], cs[(k + 1) % len(cs)]
        piece = R[i0:i1 + 1] if i1 > i0 else np.vstack([R[i0:], R[:i1 + 1]])
        segs += fit_open(piece, tol)
    # merge pass using the resampled loop
    Rl = R

    def lookup(p0, p1):
        i0 = int(np.argmin(np.linalg.norm(Rl - p0, axis=1)))
        i1 = int(np.argmin(np.linalg.norm(Rl - p1, axis=1)))
        if i1 >= i0:
            return Rl[i0:i1 + 1]
        return np.vstack([Rl[i0:], Rl[:i1 + 1]])
    segs = merge(segs, lookup, tol)
    return segs


def seg_points(seg, n=20):
    if seg[0] == "L":
        t = np.linspace(0, 1, n)[:, None]
        return seg[1] * (1 - t) + seg[2] * t
    _, a, b, c, r, ccw = seg
    a0 = np.arctan2(a[1] - c[1], a[0] - c[0]); a1 = np.arctan2(b[1] - c[1], b[0] - c[0])
    if ccw and a1 < a0: a1 += 2 * np.pi
    if (not ccw) and a1 > a0: a1 -= 2 * np.pi
    t = np.linspace(a0, a1, n)
    return np.c_[c[0] + r * np.cos(t), c[1] + r * np.sin(t)]
