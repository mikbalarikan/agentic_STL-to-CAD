"""Raster a relief npz (0.5 mm, median d), contour at a level, simplify (Douglas-Peucker) and print/plot the polygons.
usage: r1_contour.py rel.npz out.png level tol [u0 u1 v0 v1]"""
import sys, json
import numpy as np
from scipy import ndimage
from skimage import measure
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
z = np.load(sys.argv[1]); uu, vv, d = z["uu"], z["vv"], z["d"]
lev, tol = float(sys.argv[3]), float(sys.argv[4])
H = 0.5
u0, u1, v0, v1 = (map(float, sys.argv[5:9]) if len(sys.argv) > 8 else (uu.min(), uu.max(), vv.min(), vv.max()))
m = (uu >= u0) & (uu <= u1) & (vv >= v0) & (vv <= v1)
iu = ((uu[m] - u0) / H).astype(int); iv = ((vv[m] - v0) / H).astype(int)
nu, nv = iu.max() + 1, iv.max() + 1
S = np.zeros((nv, nu)); C = np.zeros((nv, nu))
np.add.at(S, (iv, iu), d[m]); np.add.at(C, (iv, iu), 1)
G = np.where(C > 0, S / np.maximum(C, 1), np.nan)
G = ndimage.generic_filter(np.nan_to_num(G, nan=-5), np.median, size=3)
cs = measure.find_contours(G, lev)
fig, ax = plt.subplots(figsize=(20, 14))
ax.imshow(G, origin="lower", extent=(u0, u0 + nu * H, v0, v0 + nv * H), cmap="turbo", vmin=-1, vmax=3)
out = []
for c in cs:
    p = np.c_[u0 + c[:, 1] * H, v0 + c[:, 0] * H]
    if len(p) < 20:
        continue
    s = measure.approximate_polygon(p, tol)
    L = np.sum(np.linalg.norm(np.diff(p, axis=0), axis=1))
    if L < 15:
        continue
    out.append(s.round(1).tolist())
    ax.plot(s[:, 0], s[:, 1], "w-", lw=1.2); ax.plot(s[:, 0], s[:, 1], "k.", ms=4)
    for q in s:
        ax.annotate(f"{q[0]:.0f},{q[1]:.0f}", q, fontsize=5.5, color="white")
ax.set_xticks(np.arange(np.ceil(u0 / 5) * 5, u1, 5)); ax.set_yticks(np.arange(np.ceil(v0 / 5) * 5, v1, 5)); ax.grid(lw=0.3, color="w")
ax.tick_params(labelsize=7)
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=75)
json.dump(out, open(sys.argv[2][:-4] + ".json", "w"))
for i, s in enumerate(out):
    print(i, len(s), s if len(s) < 40 else s[:40])
