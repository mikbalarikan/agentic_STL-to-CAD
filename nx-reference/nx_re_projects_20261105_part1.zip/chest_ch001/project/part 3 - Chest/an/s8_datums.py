"""Functional-feature fits in the (provisional) part frame: front through hole, circular recess, shoulder ring faces
+ arm-hole circles, rim levels, pad plane. Writes work/datums.json."""
import os, json
import numpy as np
from common import W, load, tri_data, fit_plane_robust, fit_circle_robust

v, f = load()
c, n, a = tri_data(v, f)
out = {}


def cyl_axis_fit(pts, nrm, axis0, it=3):
    """Cylinder with axis ~ axis0: refine axis as the direction most perpendicular to the normals, then circle fit."""
    ax = np.array(axis0, float)
    for _ in range(it):
        nn = nrm - np.outer(nrm @ ax, ax)
        u, s, vt = np.linalg.svd(nrm, full_matrices=False)
        ax = vt[2] * np.sign(vt[2] @ axis0)
    e1 = np.cross(ax, [0, 1, 0] if abs(ax[1]) < 0.9 else [1, 0, 0]); e1 /= np.linalg.norm(e1); e2 = np.cross(ax, e1)
    q = np.c_[pts @ e1, pts @ e2]
    cc, r, sd, k = fit_circle_robust(q)
    ctr = cc[0] * e1 + cc[1] * e2
    return ax, ctr, r, sd, k


# front through hole near (0,-55): wall faces, normal ~ radial in XY
m = (np.hypot(c[:, 0], c[:, 1] + 136.9) < 22) & (np.hypot(c[:, 0], c[:, 1] + 136.9) > 15) & (np.abs(n[:, 2]) < 0.3)
ax, ctr, r, sd, k = cyl_axis_fit(c[m], n[m], (0, 0, 1))
p = c[m][k]
# point of the axis at z = mean
t = ((p - 0) @ ax).mean()
out["front_hole"] = dict(axis=ax.round(5).tolist(), d=round(2 * r, 3), sd=round(sd, 4), n=int(k.sum()),
                         z_range=[round(float(p[:, 2].min()), 2), round(float(p[:, 2].max()), 2)])
# axis point at z = -50
lam = (-128 - ctr[2]) / ax[2] if abs(ax[2]) > 0.1 else 0
out["front_hole"]["pt_z-128"] = (ctr + lam * ax).round(3).tolist()
# with axis forced to Z
q = c[m][:, :2]; cc, rr, sdd, kk = fit_circle_robust(q)
out["front_hole_axisZ"] = dict(c=cc.round(3).tolist(), d=round(2 * rr, 3), sd=round(sdd, 4))
# shoulder rings
for s in (1, -1):
    mm = (n[:, 0] * s > 0.95) & (c[:, 0] * s > 150)
    ctrp, nn, sdp, kp = fit_plane_robust(c[mm])
    if nn[0] * s < 0: nn = -nn
    P = c[mm][kp]
    e2 = np.array([0, 0, 1.0]) - nn[2] * nn; e2 /= np.linalg.norm(e2); e1 = np.cross(e2, nn)
    q = np.c_[(P - ctrp) @ e1, (P - ctrp) @ e2]
    # inner boundary of the annulus: polar about a provisional centre -> min radius per angle bin, circle fit
    cc0 = np.median(q, 0)
    for _ in range(3):
        ang = np.arctan2(q[:, 1] - cc0[1], q[:, 0] - cc0[0]); rad = np.hypot(q[:, 0] - cc0[0], q[:, 1] - cc0[1])
        bins = np.digitize(ang, np.linspace(-np.pi, np.pi, 181))
        pts = []
        for b in np.unique(bins):
            kb = bins == b
            if kb.sum() < 20: continue
            i = np.argmin(rad[kb]); pts.append(q[kb][i])
        pts = np.array(pts)
        cc, rr, sdd, kk = fit_circle_robust(pts)
        cc0 = cc
    cen3 = ctrp + cc[0] * e1 + cc[1] * e2
    out[f"shoulder_{'R' if s > 0 else 'L'}"] = dict(normal=nn.round(5).tolist(), plane_pt=ctrp.round(3).tolist(), flat_sd=round(sdp, 4),
                                                   hole_centre=cen3.round(3).tolist(), hole_d=round(2 * rr, 3), circ_sd=round(sdd, 3),
                                                   n_boundary=len(pts), outer_rmax=round(float(np.percentile(np.hypot(*(q - cc).T), 99)), 2))
# rim levels: faces nz > 0.95, z > 60
mm = (n[:, 2] > 0.95) & (c[:, 2] > -18)
h, e = np.histogram(c[mm, 2], bins=np.arange(-18, 4, 0.05), weights=a[mm])
lv = []
for i in np.argsort(-h)[:12]:
    if all(abs(e[i] - l) > 0.3 for l, _ in lv): lv.append((float(e[i] + 0.025), float(h[i])))
out["rim_levels"] = sorted([(round(l, 3), round(w)) for l, w in lv if w > 20])
for L, _ in out["rim_levels"][:6]:
    mk = mm & (np.abs(c[:, 2] - L) < 0.25)
    if mk.sum() > 200:
        ctrp, nn, sdp, kp = fit_plane_robust(c[mk])
        out.setdefault("rim_fits", []).append(dict(level=L, z=round(float(ctrp[2]), 3), normal=nn.round(5).tolist(), sd=round(sdp, 4),
                                                   area=round(float(a[mk][kp].sum())), x=[round(float(c[mk][kp][:, 0].min()), 1), round(float(c[mk][kp][:, 0].max()), 1)],
                                                   y=[round(float(c[mk][kp][:, 1].min()), 1), round(float(c[mk][kp][:, 1].max()), 1)]))
mm = (n[:, 2] > 0.95) & (np.abs(c[:, 2] + 91.0) < 0.4)
ctrp, nn, sdp, kp = fit_plane_robust(c[mm])
out["pad"] = dict(z=round(float(ctrp[2]), 3), normal=nn.round(5).tolist(), sd=round(sdp, 4), area=round(float(a[mm][kp].sum())))
print(json.dumps(out, indent=1))
json.dump(out, open(os.path.join(W, "datums.json"), "w"), indent=1)
