import os, numpy as np
from common import W
d = np.load(os.path.join(W, "wall.npz")); P, t = d["P"], d["t"]
def st(name, m):
    x = t[m & np.isfinite(t)]; x = x[(x > 1.5) & (x < 5)]
    print(f"{name:28s} n {len(x):6d} p25 {np.percentile(x,25):.3f} p50 {np.percentile(x,50):.3f} p75 {np.percentile(x,75):.3f}")
X, Y = P[:,0], P[:,1]
for s in (1, -1):
    st(f"upper side {s}", (X*s > 75) & (X*s < 130) & (Y > 60) & (Y < 125))
    st(f"mid side {s}", (X*s > 60) & (X*s < 100) & (Y > -40) & (Y < 20))
    st(f"low side {s}", (X*s > 60) & (X*s < 90) & (Y > -140) & (Y < -100))
    st(f"shoulder {s}", (X*s > 100) & (X*s < 140) & (Y > 120) & (Y < 150))
st("centre top", (abs(X) < 40) & (Y > 105) & (Y < 125))
st("pocket floor", (abs(X) < 25) & (Y > -30) & (Y < -10))
st("circle recess", (abs(X) < 15) & (Y > 15) & (Y < 35))
st("bottom centre", (abs(X) < 30) & (Y > -150) & (Y < -135))
