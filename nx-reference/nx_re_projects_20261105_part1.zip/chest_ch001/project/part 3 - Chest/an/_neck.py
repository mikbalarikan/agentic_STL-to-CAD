import os, json, numpy as np
from common import W
O = np.array(json.load(open(os.path.join(W, "outline.json")))["pts"])
m = (O[:, 0] > 50) & (O[:, 0] < 75) & (O[:, 1] > 95)
Q = O[m]; Q = Q[np.argsort(Q[:, 0])]
print(len(O), "pts; near tip:"); print(np.round(Q[::2], 2))
H = np.load(os.path.join(W, "hmap.npz")); st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"]); top = H["top"]
for x in (55.0, 56.0, 57.0, 58.0, 59.0, 60.0, 61.0, 62.0, 64.0):
    j = int(round((x - x0) / st)); col = top[:, j]; ok = np.where(~np.isnan(col))[0]
    print(x, "ymax", round(y0 + ok.max() * st, 2), "z at ymax", round(float(col[ok.max()]), 2))
