"""Bottom-end corner fits on the full-res scan (right side): the web face L2 (plane, normal near (-0.54,-0.83,0.09)),
the boss rings per z (circle fits of the boss surface points), the end-face points (y near -275) and the wall
thickness near the corner. Prints the numbers used by nx/revC2_end.py.
usage: r2_endfit.py"""
import numpy as np
from common import load, tri_data, fit_plane_robust, fit_circle_robust, section

v, f = load()
c, n, a = tri_data(v, f)
box = (c[:, 0] > 50) & (c[:, 0] < 70) & (c[:, 1] > -277) & (c[:, 1] < -255) & (c[:, 2] > -75) & (c[:, 2] < 2)
# web face: normals near the old curl normal
n0 = np.array([-0.5432, -0.8343, 0.0938])
for zlo, zhi in ((-12, -2), (-25, -12), (-40, -25), (-40, -2)):
    m = box & (n @ n0 > 0.93) & (c[:, 2] > zlo) & (c[:, 2] < zhi) & (c[:, 1] > -274.5) & (c[:, 1] < -266)
    if m.sum() < 30:
        print("web", zlo, zhi, "few", m.sum()); continue
    c0, nn, sd, mm = fit_plane_robust(c[m])
    nn = nn * np.sign(nn @ n0)
    print(f"web z {zlo}..{zhi}: n {nn.round(4)} point {c0.round(2)} sd {sd:.3f} n_tri {mm.sum()} of {m.sum()}")
# boss rings: section at z, keep the boss arc (points within 9 mm of the bore axis, north/west of it)
bc = np.array([59.3, -265.8])
for z in (-2, -6, -10, -14, -18, -22, -26, -30, -34, -40, -46, -52, -58, -62):
    seg = section(v, f[box | ((np.abs(c[:, 2] - z) < 3) & (np.linalg.norm(c[:, :2] - bc, axis=1) < 12))], 2, z)
    P = seg.reshape(-1, 3)[:, :2]
    d = np.linalg.norm(P - bc, axis=1)
    ang = np.degrees(np.arctan2(P[:, 1] - bc[1], P[:, 0] - bc[0]))
    m = (d > 2.0) & (d < 9.5) & (ang > 60) & (ang < 200)       # north-west quadrant of the boss (free of web/wall)
    if m.sum() < 10:
        print("ring z", z, "few"); continue
    cc, r, sd, mm = fit_circle_robust(P[m])
    # bore
    mb = (d < 2.2)
    cb, rb, sdb, _ = fit_circle_robust(P[mb]) if mb.sum() > 10 else ((np.nan, np.nan), np.nan, np.nan, None)
    print(f"ring z {z}: centre ({cc[0]:.2f}, {cc[1]:.2f}) r {r:.2f} sd {sd:.3f} | bore ({cb[0]:.2f}, {cb[1]:.2f}) r {rb:.2f}")
# end face: scan extent in y per z at the corner and centre
for z in (-3, -20, -40, -60, -80):
    m = (np.abs(c[:, 2] - z) < 1.0) & (np.abs(c[:, 0]) < 90) & (c[:, 1] < -268)
    if m.sum():
        print(f"min y at z {z}: {c[m, 1].min():.2f} (x {c[m][np.argmin(c[m, 1]), 0]:.1f})")
