import os, numpy as np
from scipy import ndimage
from common import W
A = np.load(os.path.join(W, "dev2_B6_cad2scan.npy")); Q, d = A[:, :3], A[:, 3]
for t in (1, 3, 5, 10):
    print("cad2scan >", t, "mm:", round(float((d > t).mean()) * 100, 2), "%")
far = Q[d > 3]
# coarse clusters on a 10 mm grid
key = np.round(far / 15).astype(int)
u, inv, cnt = np.unique(key, axis=0, return_inverse=True, return_counts=True)
order = np.argsort(-cnt)[:25]
for k in order:
    m = inv == k
    print(cnt[k], far[m].mean(0).round(1), "dmax", round(float(d[d > 3][m].max()), 1))
