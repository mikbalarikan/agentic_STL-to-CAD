"""Left/right mirror symmetry of the scan: reflect about a candidate plane, ICP the reflection onto the scan,
recover the best mirror plane, report the residual (unsigned distance of mirrored points to the scan).
usage: s2_symmetry.py [axis 0/1/2] -> work/symmetry.json + residual map."""
import os, sys, json
import numpy as np
import open3d as o3d
import pyvista as pv
from common import W

AX = int(sys.argv[1]) if len(sys.argv) > 1 else 0
d = np.load(os.path.join(W, "main.npz"))
v, f = d["v"].astype(np.float64), d["f"]
m = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
rng = np.random.default_rng(3)
P = v[rng.choice(len(v), 400000, replace=False)]
n0 = np.zeros(3); n0[AX] = 1.0
c0 = 0.5 * (v.min(0) + v.max(0))
M0 = np.eye(4); M0[:3, :3] -= 2 * np.outer(n0, n0); M0[:3, 3] = 2 * (c0 @ n0) * n0
src = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(P)); src.transform(M0)
dst = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(P)); dst.estimate_normals(o3d.geometry.KDTreeSearchParamHybrid(radius=1.5, max_nn=30))
T = np.eye(4)
for thr in (5.0, 2.0, 0.8, 0.4):
    r = o3d.pipelines.registration.registration_icp(src, dst, thr, T, o3d.pipelines.registration.TransformationEstimationPointToPlane(),
                                                    o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=60))
    T = r.transformation
S = T @ M0
Rm = S[:3, :3]
w, V = np.linalg.eig(Rm)
k = int(np.argmin(np.real(w)))
n = np.real(V[:, k]); n /= np.linalg.norm(n)
if n[AX] < 0: n = -n
# reflection x' = x - 2 (n.x - dd) n  -> translation = 2 dd n
dd = float(S[:3, 3] @ n / 2.0)
Mf = np.eye(4); Mf[:3, :3] -= 2 * np.outer(n, n); Mf[:3, 3] = 2 * dd * n
Q = (P @ Mf[:3, :3].T) + Mf[:3, 3]
dist = sc.compute_distance(o3d.core.Tensor(Q.astype(np.float32))).numpy()
# signed side offset: residual of the pure reflection vs the ICP (rotation part beyond a reflection)
rot_err = float(np.degrees(np.arccos(np.clip((np.trace(Rm @ Mf[:3, :3].T) - 1) / 2, -1, 1))))
out = dict(axis=AX, normal=n.round(6).tolist(), d=round(dd, 4), angle_to_axis_deg=round(float(np.degrees(np.arccos(abs(n[AX])))), 4),
           icp_fitness=r.fitness, icp_rmse=r.inlier_rmse, non_reflection_rotation_deg=round(rot_err, 4),
           residual=dict(p50=float(np.percentile(dist, 50)), p75=float(np.percentile(dist, 75)), p90=float(np.percentile(dist, 90)),
                         p95=float(np.percentile(dist, 95)), within_0p2=float((dist < 0.2).mean()), within_0p5=float((dist < 0.5).mean()),
                         over_2=float((dist > 2).mean())))
print(json.dumps(out, indent=1))
json.dump(out, open(os.path.join(W, f"symmetry_ax{AX}.json"), "w"), indent=1)
np.save(os.path.join(W, f"symmetry_ax{AX}_pts.npy"), np.c_[P, dist])
pc = pv.PolyData(P); pc["d"] = np.minimum(dist, 3.0)
c = P.mean(0)
for name, dv, up in (("front", (0, -1, 0.3), (0, 0, 1)), ("back", (0, 1, 0.3), (0, 0, 1)), ("top", (0, 0, 1), (0, 1, 0)), ("bot", (0, 0, -1), (0, 1, 0))):
    p = pv.Plotter(off_screen=True, window_size=(1400, 1200))
    p.add_mesh(pc, scalars="d", cmap="turbo", clim=(0, 1.5), point_size=2, render_points_as_spheres=False,
               scalar_bar_args=dict(title="mirror residual (mm)"))
    p.camera_position = [tuple(c + np.array(dv, float) / np.linalg.norm(dv) * 1100), tuple(c), up]; p.camera.view_angle = 30
    p.screenshot(os.path.join(W, f"symmetry_ax{AX}_{name}.png")); p.close()
