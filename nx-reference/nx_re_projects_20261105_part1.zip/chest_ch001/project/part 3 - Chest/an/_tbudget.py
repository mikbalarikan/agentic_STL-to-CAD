"""Interior misses by wall thickness t (distance of the scan point to the exterior skin)."""
import os, sys
import numpy as np, open3d as o3d
from common import W
tag = sys.argv[1]
A = np.load(os.path.join(W, f"dev2_{tag}_scan2cad.npy")); P, d = A[:, :3], A[:, 3]
Z = np.load(os.path.join(W, "rv", "zones400k.npy"))
tf = os.path.join(W, "rv", "t400k.npy")
if os.path.exists(tf):
    t = np.load(tf)
else:
    m = o3d.io.read_triangle_mesh(os.path.join(W, "skin_mesh_out.ply"))
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
    t = sc.compute_signed_distance(o3d.core.Tensor(P.astype(np.float32))).numpy(); np.save(tf, t)
print("sign check: median t of outer zone", np.median(t[Z == 0]), "inner", np.median(t[Z == 3]))
t = -t
for zi in (3, 2):
    m = Z == zi; mm = m & (np.abs(d) > 0.5)
    print("zone", zi, "n", m.sum(), "misses", mm.sum())
    bins = [-50, -1, 0, 1.5, 2.75, 3.75, 4.25, 4.75, 5.25, 5.75, 6.5, 7.5, 9, 12, 20, 40, 200]
    h_all, _ = np.histogram(t[m], bins); h_m, _ = np.histogram(t[mm], bins)
    hp, _ = np.histogram(t[mm & (d > 0)], bins)
    for i in range(len(bins) - 1):
        print(f"  t {bins[i]:6}..{bins[i+1]:5}: pts {h_all[i]:7d}  misses {h_m[i]:6d} (+ {hp[i]:6d})  share of zone {100*h_m[i]/m.sum():5.1f}%")
