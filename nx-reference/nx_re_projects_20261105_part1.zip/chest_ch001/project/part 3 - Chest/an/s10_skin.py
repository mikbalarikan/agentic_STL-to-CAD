"""Exterior skin as a radial map r(p, q) seen from the centre point C = (0, YC, ZC) above the open back.
Direction: psi = angle from -Z, beta = azimuth from +X; p = psi cos(beta), q = psi sin(beta) (azimuthal
equidistant, smooth at the front). Point = C + r d(p, q). Mirror symmetric: data used with p and -p.
Data: rays cast from outside toward C (first hit = exterior), kept when the hit faces the ray source.
Fit: tensor cubic B-spline, 2nd-difference penalty, robust re-weighting (features / steps drop out).
usage: s10_skin.py KNOT_DEG LAM [reuse] -> work/skin_data.npz, work/skin_fit.npz, residual map."""
import sys, os, json
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.interpolate import BSpline
import open3d as o3d
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, W

C = np.array([0.0, -81.0, 60.0])
KD = float(sys.argv[1]) if len(sys.argv) > 1 else 2.0
LAM = float(sys.argv[2]) if len(sys.argv) > 2 else 1e-2
PQ = 1.50                        # half width of the (p, q) domain, rad
STEP = 0.0025


def dirs(p, q):
    psi = np.hypot(p, q); b = np.arctan2(q, p)
    s = np.sinc(psi / np.pi)    # sin(psi)/psi, smooth at 0
    return np.stack([p * s, q * s, -np.cos(psi)], -1)


dpath = os.path.join(W, "skin_data.npz")
if "reuse" in sys.argv and os.path.exists(dpath):
    dd = np.load(dpath); P_, Q_, R_, INC = dd["p"], dd["q"], dd["r"], dd["inc"]
else:
    v, f = load()
    m = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
    g = np.arange(-PQ, PQ + 1e-9, STEP)
    Pg, Qg = np.meshgrid(g, g)
    keep = np.hypot(Pg, Qg) < 1.52
    Pg, Qg = Pg[keep], Qg[keep]
    d = dirs(Pg, Qg)
    RB = 800.0
    rays = np.c_[C + RB * d, -d].astype(np.float32)
    out = sc.cast_rays(o3d.core.Tensor(rays))
    t = out["t_hit"].numpy(); n = out["primitive_normals"].numpy().astype(np.float64)
    hit = np.isfinite(t)
    r = RB - t
    inc = (n * d).sum(1)          # > 0: the surface faces the ray source (exterior)
    ok = hit & (inc > 0.2) & (r > 20)
    P_, Q_, R_, INC = Pg[ok], Qg[ok], r[ok], inc[ok]
    np.savez(dpath, p=P_, q=Q_, r=R_, inc=INC, C=C)
    print("rays", len(Pg), "hits", int(hit.sum()), "kept", int(ok.sum()), flush=True)
X = C + R_[:, None] * dirs(P_, Q_)
mask = X[:, 2] < -2.5
# shoulder ring faces are planes (cut), not skin
DT = json.load(open(os.path.join(W, "datums.json")))
for k in ("shoulder_R", "shoulder_L"):
    nn = np.array(DT[k]["normal"]); pp = np.array(DT[k]["plane_pt"])
    mask &= ~(np.abs((X - pp) @ nn) < 1.5)
# feature zones (modelled as features), the robust pass removes the rest
mask &= ~((np.abs(X[:, 0]) < 44) & (X[:, 1] > -165) & (X[:, 1] < -30))      # racetrack pocket, circle recess, hole
mask &= ~((np.abs(X[:, 0]) < 70) & (X[:, 1] > -32) & (X[:, 1] < -10))       # LED slot recess
mask &= ~((np.abs(X[:, 0]) < 50) & (X[:, 1] > -215) & (X[:, 1] < -188))     # bottom vent
mask &= ~((np.abs(X[:, 0]) > 70) & (np.abs(X[:, 0]) < 150) & (X[:, 1] > 58) & (X[:, 1] < 90))   # shoulder vents
print("data", len(R_), "masked in", int(mask.sum()), flush=True)


def knots(lo, hi, h, k=3):
    n = max(1, int(round((hi - lo) / h)))
    return np.r_[[lo] * k, np.linspace(lo, hi, n + 1), [hi] * k]


tk = knots(-PQ, PQ, np.radians(KD))
nk = len(tk) - 4
rng = np.random.default_rng(1)
sel = np.nonzero(mask)[0]
if len(sel) > 900000:
    sel = rng.choice(sel, 900000, replace=False)
pp = np.r_[P_[sel], -P_[sel]]; qq = np.r_[Q_[sel], Q_[sel]]; rr = np.r_[R_[sel], R_[sel]]; ww = np.r_[INC[sel], INC[sel]]


def design(pv, qv):
    Bp = BSpline.design_matrix(np.clip(pv, tk[3], tk[-4] - 1e-9), tk, 3).tocsr()
    Bq = BSpline.design_matrix(np.clip(qv, tk[3], tk[-4] - 1e-9), tk, 3).tocsr()
    ip = Bp.indices.reshape(-1, 4); vp = Bp.data.reshape(-1, 4)
    iq = Bq.indices.reshape(-1, 4); vq = Bq.data.reshape(-1, 4)
    cols = (iq[:, :, None] * nk + ip[:, None, :]).reshape(len(pv), 16)       # coef index = iq * nk + ip
    vals = (vq[:, :, None] * vp[:, None, :]).reshape(len(pv), 16)
    return sp.csr_matrix((vals.ravel(), cols.ravel(), np.arange(0, 16 * len(pv) + 1, 16)), shape=(len(pv), nk * nk))


A0 = design(pp, qq)


def d2(n):
    return sp.diags([1, -2, 1], [0, 1, 2], shape=(n - 2, n))


D1 = sp.diags([1, -1], [0, 1], shape=(nk - 1, nk))
PEN = (sp.kron(d2(nk), sp.eye(nk)).T @ sp.kron(d2(nk), sp.eye(nk)) + sp.kron(sp.eye(nk), d2(nk)).T @ sp.kron(sp.eye(nk), d2(nk))
       + 2 * sp.kron(D1, D1).T @ sp.kron(D1, D1))
rw = np.ones(len(pp))
for it in range(5):
    w = ww * rw
    A = sp.diags(w) @ A0
    M = (A.T @ A + LAM * len(pp) / (nk * nk) * PEN).tocsc()
    coef = spl.spsolve(M, A.T @ (rr * w))
    res = (rr - A0 @ coef) * ww
    sd = 1.4826 * np.median(np.abs(res[rw == 1]))
    rw = np.where(np.abs(res) < max(3 * sd, 0.2), 1.0, 0.01)
    print(f"it {it}: normal res p50 {np.percentile(abs(res), 50):.3f} p90 {np.percentile(abs(res), 90):.3f} inliers {np.mean(rw == 1):.3f} "
          f"(inlier p50 {np.percentile(abs(res[rw == 1]), 50):.3f} p95 {np.percentile(abs(res[rw == 1]), 95):.3f})", flush=True)
CF = coef.reshape(nk, nk)        # CF[iq, ip]
np.savez(os.path.join(W, "skin_fit.npz"), tk=tk, CF=CF, C=C, KD=KD, LAM=LAM, PQ=PQ)
# residual over ALL data (incl. masked) for a map
Ball = design(P_, Q_)
resall = (R_ - Ball @ coef) * INC
np.save(os.path.join(W, "skin_res_all.npy"), np.c_[X, resall])
fig, ax = plt.subplots(figsize=(16, 18))
s_ = ax.scatter(X[::3, 0], X[::3, 1], c=np.clip(resall[::3], -0.5, 0.5), s=0.15, cmap="seismic", vmin=-0.5, vmax=0.5)
plt.colorbar(s_, ax=ax, shrink=0.6); ax.set_aspect("equal"); ax.grid(True, lw=0.3)
ax.set_title(f"exterior: scan - skin fit, normal (mm), + = scan outside; knots {KD} deg, lam {LAM}")
fig.tight_layout(); fig.savefig(os.path.join(W, f"skin_res_{KD:g}.png"), dpi=60)
print("all-data residual p50", round(float(np.percentile(abs(resall), 50)), 4), "within 0.2", round(float((abs(resall) < 0.2).mean()), 3))
