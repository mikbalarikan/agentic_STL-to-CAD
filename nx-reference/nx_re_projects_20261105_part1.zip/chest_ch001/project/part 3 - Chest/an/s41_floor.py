"""outC12 smooth interior floor of the shoulder vents (lead decision 4: no thin wall / saw-tooth on the vent floor).
Stepped pads are switched off over the floor (pad_zone in work/c10/G4.json, written here too); ONE unite tool per side
replaces them: Z prism over the floor, between the sheets lo = scan exterior (pocket floor) + 0.6 mm (inside the floor)
and hi = scan interior surface (bosses / slots inpainted). outC13: united in H1 (listed in work/c10/sheets.json), BEFORE the shoulder_vent pocket, which trims the lo side.
usage: s41_floor.py  -> work/c12/floor.json (sheets.json format, Z frame) + work/c10/G4.json pad_zones + plot"""
import os, json
import numpy as np
from scipy import ndimage
from scipy.interpolate import RegularGridInterpolator
import contourpy
from skimage.measure import approximate_polygon
from matplotlib.path import Path
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
from c10_sheets_lib import loops_in, inpaint, fill_nearest
H = np.load(os.path.join(W, "hmap.npz"))
x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
top = H["top"].astype(np.float64); bot = H["bot"].astype(np.float64)
ny, nx = top.shape
xs = x0 + np.arange(nx) * st; ys = y0 + np.arange(ny) * st
X, Y = np.meshgrid(xs, ys)
SP, SIG, OFF, ERO = 1.0, 1.0, -1.0, 0.3     # OFF < 0: lo 1 mm OUTSIDE the scan floor; the shoulder_vent pocket (cut after) trims it
pts = np.c_[X.ravel(), Y.ravel()]
mouth = np.zeros(X.shape, bool)
for Q in loops_in("recess.json", (70, 132, 54, 86)):
    mouth |= Path(Q).contains_points(pts).reshape(X.shape)
t = top - bot
botB = np.load(os.path.join(W, "c10", "botB12.npy")).astype(np.float64)        # Rev A CAD skin (no pockets), same grid
rec_ = ndimage.gaussian_filter(np.nan_to_num(bot - botB, nan=0.0), 0.7 / st) > 1.0  # scan recessed > 1 mm: the pocket
floor = ndimage.binary_erosion(mouth, iterations=int(round(ERO / st))) & rec_ & np.isfinite(t) & (t < 15.0) & (t > 0.8)
lab, n = ndimage.label(floor); sz = ndimage.sum(floor, lab, range(1, n + 1))
floor = lab == (1 + int(np.argmax(sz)))
floor = ndimage.binary_closing(floor, iterations=8) & mouth
# bosses / webs (top stands > 1 mm above the local floor) and slots / see-through cells -> inpainted
med = ndimage.median_filter(np.nan_to_num(top, nan=-1e3), size=41)
odd = ~np.isfinite(top) | (np.abs(top - med) > 1.0)
topf = inpaint(np.where(floor | ndimage.binary_dilation(floor, iterations=20), top, np.nan), ndimage.binary_dilation(odd, iterations=3), sig_px=6)
medb = ndimage.median_filter(np.nan_to_num(bot, nan=1e3), size=41)
oddb = ~np.isfinite(bot) | (np.abs(bot - medb) > 1.0)
botf = inpaint(np.where(floor | ndimage.binary_dilation(floor, iterations=20), bot, np.nan), ndimage.binary_dilation(oddb, iterations=3), sig_px=6)
# outT13a: a region running up the steep pocket walls made the hi trim fail -> floor = slope < 45 deg only, and both
# sheets come from the floor cells, extended flat beyond them
gy_, gx_ = np.gradient(ndimage.gaussian_filter(fill_nearest(topf), 1.0 / st), st)
floor &= np.hypot(gx_, gy_) < float(os.environ.get("FLOOR_SLOPE", "1.0"))
lab, n = ndimage.label(floor); sz = ndimage.sum(floor, lab, range(1, n + 1))
floor = ndimage.binary_opening(lab == (1 + int(np.argmax(sz))), iterations=4)
hi = ndimage.gaussian_filter(fill_nearest(np.where(ndimage.binary_erosion(floor, iterations=2), topf, np.nan)), SIG / st)
# lo from the floor cells only, extended flat beyond them (the steep pocket wall made the trim fail, outT12b)
lo = ndimage.gaussian_filter(fill_nearest(np.where(ndimage.binary_erosion(floor, iterations=2), botf, np.nan)), 2 * SIG / st) + OFF
hi = np.maximum(hi, lo + 0.8)
G = np.pad(ndimage.gaussian_filter(floor.astype(float), 1.0), 2)
lines = [c for c in contourpy.contour_generator(z=G, line_type="Separate").lines(0.5) if np.linalg.norm(c[0] - c[-1]) < 1e-6]
C = max(lines, key=len)
outline = approximate_polygon(np.c_[xs[0] + (C[:, 0] - 2) * st, ys[0] + (C[:, 1] - 2) * st], 0.25)[:-1]
inside = Path(outline).contains_points(pts).reshape(X.shape)
bx0, by0 = outline.min(0); bx1, by1 = outline.max(0)
gx = np.arange(np.floor(bx0) - 2, bx1 + 2 + 1e-9, SP); gy = np.arange(np.floor(by0) - 2, by1 + 2 + 1e-9, SP)
GX, GY = np.meshgrid(gx, gy, indexing="ij")
ZG = {k: RegularGridInterpolator((ys, xs), fill_nearest(np.where(np.isfinite(F_), F_, np.nan)), bounds_error=False, fill_value=None)(np.c_[GY.ravel(), GX.ravel()]).reshape(GX.shape)
      for k, F_ in (("lo", lo), ("hi", hi))}
zlo = min(np.nanmin(lo[inside]), ZG["lo"].min()) - 2.0; zhi = max(np.nanmax(hi[inside]), ZG["hi"].max()) + 2.0
rec = dict(name="shvent_floor", kind="bump", op="unite", outline=np.round(outline, 4).tolist(), z0=round(float(zlo), 3), z1=round(float(zhi), 3), sheets={})
cell = st * st
for k, F_ in (("lo", lo), ("hi", hi)):
    rec["sheets"][k] = [[[round(float(gx[i]), 3), round(float(gy[j]), 3), round(float(ZG[k][i, j]), 3)] for j in range(len(gy))] for i in range(len(gx))]
    zc = np.clip(np.where(inside, F_, np.nan), zlo, zhi)
    rec[f"v_below_{k}"] = round(float(np.nansum(zc - zlo) * cell), 1); rec[f"v_above_{k}"] = round(float(np.nansum(zhi - zc) * cell), 1)
m = json.loads(json.dumps(rec)); m["name"] = "shvent_floor_L"
m["outline"] = [[-p[0], p[1]] for p in rec["outline"]][::-1]
for k in m["sheets"]:
    m["sheets"][k] = [[[-p[0], p[1], p[2]] for p in sec] for sec in rec["sheets"][k][::-1]]
os.makedirs(os.path.join(W, "c12"), exist_ok=True)
json.dump({"note": __doc__.split("\n")[0], "tools": [rec, m]}, open(os.path.join(W, "c12", "floor.json"), "w"))
# pads off over the floor, 0.75 mm inside the tool outline (the tool overlaps the remaining pads)
er = ndimage.binary_erosion(floor, iterations=12)   # outC14: pads stay 3 mm under the tool edge (outC13 left a wedge gap / knife at the edge)
G2 = np.pad(er.astype(float), 2)
C2 = max([c for c in contourpy.contour_generator(z=G2, line_type="Separate").lines(0.5) if np.linalg.norm(c[0] - c[-1]) < 1e-6], key=len)
pz = approximate_polygon(np.c_[xs[0] + (C2[:, 0] - 2) * st, ys[0] + (C2[:, 1] - 2) * st], 0.25)[:-1]
json.dump({"group": "G4", "features": [], "pad_zones": [{"poly": np.round(pz, 3).tolist(), "tmax": 3.25, "why": "outC12 shoulder-vent floor: smooth floor tool (work/c12/floor.json) instead of stepped pads"}],
           "notes": "written by an/s41_floor.py"}, open(os.path.join(W, "c10", "G4.json"), "w"), indent=1)
fig, axs = plt.subplots(1, 3, figsize=(24, 7))
sl = (slice(int((by0 - 8 - y0) / st), int((by1 + 8 - y0) / st)), slice(int((bx0 - 8 - x0) / st), int((bx1 + 8 - x0) / st)))
ext = [xs[sl[1]][0], xs[sl[1]][-1], ys[sl[0]][0], ys[sl[0]][-1]]
axs[0].imshow(np.where(inside, hi - lo, np.nan)[sl], origin="lower", extent=ext, cmap="turbo"); axs[0].plot(outline[:, 0], outline[:, 1], "k-"); axs[0].plot(pz[:, 0], pz[:, 1], "w--")
axs[0].set_title("floor tool thickness hi - lo (mm); white dashed = pads off")
for ax_, xc in ((axs[1], 95.0), (axs[2], 110.0)):
    j = int((xc - x0) / st); r = sl[0]
    ax_.plot(ys[r], top[r, j], "k-", lw=0.8, label="scan top"); ax_.plot(ys[r], bot[r, j], "k:", lw=0.8, label="scan bot")
    ax_.plot(ys[r], np.where(inside[r, j], hi[r, j], np.nan), "r--", label="hi"); ax_.plot(ys[r], np.where(inside[r, j], lo[r, j], np.nan), "b--", label="lo")
    ax_.set_aspect("equal"); ax_.legend(); ax_.grid(lw=0.3); ax_.set_title(f"x = {xc}")
fig.tight_layout(); fig.savefig(os.path.join(W, "c12", "floor.png"), dpi=60)
print("outline", len(outline), "pts; area", round(float(inside.sum() * cell), 1), "z", zlo, zhi, "poles", GX.shape, {k: rec[k] for k in rec if k.startswith("v_")})
