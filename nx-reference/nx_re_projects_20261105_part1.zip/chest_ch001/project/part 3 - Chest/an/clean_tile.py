"""Zoomed hillshade tile of the scan ZI map with the Rev A (outB12) plateau loops (red, labelled with their top h)
and holes (blue). usage: clean_tile.py maps.npz out_dir tag x0 x1 y0 y1 [key]"""
import sys, os, json
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
f, out, tag = sys.argv[1:4]; x0, x1, y0, y1 = map(float, sys.argv[4:8]); key = sys.argv[8] if len(sys.argv) > 8 else "scan_ZI"
d = np.load(f); xs, ys = d["xs"], d["ys"]; Z = d[key].astype(float)
ix = (xs >= x0) & (xs <= x1); iy = (ys >= y0) & (ys <= y1); Z = Z[np.ix_(iy, ix)]
Zf = np.where(np.isfinite(Z), Z, np.nanmin(Z) - 5)
gy, gx = np.gradient(Zf, 0.25); az, alt = np.radians(315), np.radians(45)
sl = np.pi / 2 - np.arctan(np.hypot(gx, gy)); asp = np.arctan2(-gx, gy)
hs = np.sin(alt) * np.sin(sl) + np.cos(alt) * np.cos(sl) * np.cos(az - asp)
fig, ax = plt.subplots(figsize=((x1 - x0) / 7 + 1, (y1 - y0) / 7 + 1), dpi=100)
ax.imshow(hs, cmap="gray", origin="lower", extent=(x0, x1, y0, y1), vmin=0, vmax=1)
cs = ax.contour(xs[ix], ys[iy], Zf, levels=np.arange(-150, 5, 1.0), colors="tab:orange", linewidths=0.3, alpha=0.5)
PL = json.load(open(os.path.join(ROOT, "work", "plateaus.json")))["loops"]
for L in PL:
    for sx in ((1, -1) if L["kind"] == "R" else (1,)):
        p = np.array([s[1] for s in L["segs"]] + [L["segs"][0][1]]); p[:, 0] *= sx
        if p[:, 0].max() < x0 or p[:, 0].min() > x1 or p[:, 1].max() < y0 or p[:, 1].min() > y1:
            continue
        ax.plot(p[:, 0], p[:, 1], "r-", lw=0.6)
        if L["area"] > 0:
            ax.text(p[:, 0].mean(), p[:, 1].mean(), f"{L['h']:.1f}", color="red", fontsize=6)
for hh in json.load(open(os.path.join(ROOT, "work", "holes.json"))):
    ax.add_patch(plt.Circle((hh["x"], hh["y"]), hh["d_design"] / 2, fill=False, color="blue", lw=0.6))
ax.set_xlim(x0, x1); ax.set_ylim(y0, y1)
ax.set_xticks(np.arange(np.ceil(x0 / 5) * 5, x1 + 0.1, 5)); ax.set_yticks(np.arange(np.ceil(y0 / 5) * 5, y1 + 0.1, 5))
ax.grid(True, color="cyan", lw=0.3, alpha=0.6); ax.tick_params(labelsize=6)
ax.set_title(f"{tag} {key} (orange: 1 mm contours; red: Rev A plateaus + top h; blue: Rev A holes)", fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(out, f"{tag}.png")); plt.close(fig)
