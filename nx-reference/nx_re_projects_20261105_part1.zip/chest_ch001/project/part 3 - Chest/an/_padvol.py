"""Expected right-half pad volume (plan area x thickness above the wall, levels <= Tmax) from work/pads.json loops."""
import os, json, sys
import numpy as np
from matplotlib.path import Path
from common import W
from arcfit import seg_points
D = json.load(open(os.path.join(W, "pads.json")))
nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 99
tot = 0.0
for L in D["loops"]:
    if L["k"] >= nmax:
        continue
    def poly(segs):
        return np.vstack([seg_points([s[0], np.array(s[1]), np.array(s[2])] + ([np.array(s[3]), s[4], s[5]] if s[0] == "A" else [])) for s in segs])
    def area(Q):
        return 0.5 * abs(np.dot(Q[:, 0], np.roll(Q[:, 1], -1)) - np.dot(Q[:, 1], np.roll(Q[:, 0], -1)))
    A = area(poly(L["segs"])) - sum(area(poly(h)) for h in L["holes"])
    tot += A * D["step"]
print("pad volume (plan area x step, levels < %d): %.0f mm3" % (nmax, tot))
