"""Racetrack inset panel on the front: exterior plane, interior plane, circular recess (exterior floor, interior boss
plane, circle), through hole, outline (exterior step, symmetrised, line/arc loop). Writes work/panel.json + figure."""
import os, json
import numpy as np
from scipy import ndimage
import contourpy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W, load, tri_data, fit_plane_robust, fit_circle_robust
from arcfit import fit_loop, seg_points

v, f = load()
c, n, a = tri_data(v, f)
box = (np.abs(c[:, 0]) < 45) & (c[:, 1] > -168) & (c[:, 1] < -30) & (c[:, 2] < -100)
hole_c = np.array([0.0, -136.2])
rh = np.hypot(c[:, 0] - hole_c[0], c[:, 1] - hole_c[1])
out = {}
# circular recess: exterior floor (normal -z) near (0, -75); find circle centre first from the exterior map
H = np.load(os.path.join(W, "hmap.npz")); st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"]); bot = H["bot"]; top = H["top"]
ny, nx = bot.shape
XX, YY = np.meshgrid(x0 + np.arange(nx) * st, y0 + np.arange(ny) * st)


def fitp(mask, name, sgn):
    p = c[mask]
    ctr, nn, sd, k = fit_plane_robust(p, k=2.5)
    if nn[2] * sgn < 0: nn = -nn
    # z(x, y) = z0 + gx x + gy y
    z0 = ctr @ nn / nn[2]; gx = -nn[0] / nn[2]; gy = -nn[1] / nn[2]
    out[name] = dict(normal=nn.round(6).tolist(), z_at_origin=round(float(z0), 4), dzdx=round(float(gx), 6), dzdy=round(float(gy), 6),
                     sd=round(sd, 4), n=int(k.sum()), tilt_about_x_deg=round(float(np.degrees(np.arctan(gy))), 3))
    return z0, gx, gy


# rough ring zone: inside |x| < 34, outside the circle (r > 38 from (0,-75)) and outside the hole (r > 22)
rc = np.hypot(c[:, 0], c[:, 1] + 75)
ring = box & (np.abs(c[:, 0]) < 33) & (rc > 40) & (rh > 22) & (c[:, 1] > -158) & (c[:, 1] < -42)
z0e, gxe, gye = fitp(ring & (n[:, 2] < -0.97), "ext_plane", -1)
z0i, gxi, gyi = fitp(ring & (n[:, 2] > 0.97) & (c[:, 2] > z0e + gye * c[:, 1] + 2.0), "int_plane", 1)
# circle recess floor (exterior) and interior disc
disc = box & (rc < 30)
z0c, gxc, gyc = fitp(disc & (n[:, 2] < -0.97), "circle_ext_floor", -1)
z0d, gxd, gyd = fitp(disc & (n[:, 2] > 0.97) & (c[:, 2] < z0c + gyc * c[:, 1] + 4.0), "circle_int_plane", 1)
# circle wall: exterior step wall points around r ~ 33-36, normals radial-in plane
cw = box & (rc > 28) & (rc < 40) & (np.abs(n[:, 2]) < 0.5) & (c[:, 2] < z0e + gye * c[:, 1] + 0.5)
cc, r, sd, k = fit_circle_robust(c[cw][:, :2])
out["circle"] = dict(c=cc.round(3).tolist(), d=round(2 * r, 3), sd=round(sd, 3), n=int(k.sum()))
# through hole
hw = box & (rh > 15) & (rh < 22) & (np.abs(n[:, 2]) < 0.3)
cc2, r2, sd2, k2 = fit_circle_robust(c[hw][:, :2])
out["hole"] = dict(c=cc2.round(3).tolist(), d=round(2 * r2, 3), sd=round(sd2, 3), n=int(k2.sum()))
# outline: exterior pixels on the panel plane (within 0.6) in the box, filled, symmetrised, contour
zpl = z0e + gxe * XX + gye * YY
m = np.isfinite(bot) & (np.abs(bot - zpl) < 0.6) & (np.abs(XX) < 46) & (YY > -170) & (YY < -28)
m |= np.isfinite(bot) & (bot > zpl) & (np.abs(XX) < 30) & (YY > -170) & (YY < -28)      # the circle recess (deeper side)
m = ndimage.binary_fill_holes(ndimage.binary_closing(m, iterations=3))
lab, nl = ndimage.label(m); m = lab == (1 + np.argmax(ndimage.sum(m, lab, range(1, nl + 1))))
sdf = ndimage.distance_transform_edt(~m) - ndimage.distance_transform_edt(m)
mir = np.zeros_like(sdf); mir[:, 1:] = sdf[:, :0:-1]
fld = ndimage.gaussian_filter(0.5 * (sdf + mir), 1.0)
G = np.pad(-fld, 2, constant_values=-50)
best = max(contourpy.contour_generator(z=G, line_type="Separate").lines(0.0), key=len)
P = np.c_[x0 + (best[:, 0] - 2) * st, y0 + (best[:, 1] - 2) * st][:-1]
Lc = np.r_[0, np.cumsum(np.linalg.norm(np.diff(np.vstack([P, P[:1]]), axis=0), axis=1))]
sg = np.arange(0, Lc[-1], 0.1); Pc = np.vstack([P, P[:1]])
Pu = np.c_[np.interp(sg, Lc, Pc[:, 0]), np.interp(sg, Lc, Pc[:, 1])]
Pu = np.c_[ndimage.gaussian_filter1d(Pu[:, 0], 5, mode="wrap"), ndimage.gaussian_filter1d(Pu[:, 1], 5, mode="wrap")]
segs = fit_loop(Pu, tol=0.12)
out["outline_segs"] = [([s[0], s[1].tolist(), s[2].tolist()] if s[0] == "L" else [s[0], s[1].tolist(), s[2].tolist(), s[3].tolist(), float(s[4]), bool(s[5])]) for s in segs]
out["outline_bbox"] = [round(float(Pu[:, 0].min()), 2), round(float(Pu[:, 1].min()), 2), round(float(Pu[:, 0].max()), 2), round(float(Pu[:, 1].max()), 2)]
json.dump(out, open(os.path.join(W, "panel.json"), "w"), indent=1)
print(json.dumps({k: v for k, v in out.items() if k != "outline_segs"}, indent=1), "\noutline segs", len(segs))
fig, ax = plt.subplots(figsize=(8, 12))
ax.imshow(np.where(np.isfinite(bot), bot - zpl, np.nan), origin="lower", extent=[x0, x0 + nx * st, y0, y0 + ny * st], cmap="coolwarm", vmin=-4, vmax=4)
Q = np.vstack([seg_points(s) for s in segs]); ax.plot(Q[:, 0], Q[:, 1], "k-", lw=0.8)
t = np.linspace(0, 2 * np.pi, 200)
ax.plot(cc[0] + r * np.cos(t), cc[1] + r * np.sin(t), "g-", lw=0.8); ax.plot(cc2[0] + r2 * np.cos(t), cc2[1] + r2 * np.sin(t), "g-", lw=0.8)
ax.set_xlim(-60, 60); ax.set_ylim(-180, -20); ax.set_aspect("equal"); ax.grid(True, lw=0.3)
fig.tight_layout(); fig.savefig(os.path.join(W, "panel.png"), dpi=80)
