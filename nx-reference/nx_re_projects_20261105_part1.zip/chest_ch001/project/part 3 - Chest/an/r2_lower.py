"""Per neck station: e2 of the outer (lower) line and the inner (upper) line at given e1 offsets, on the scan and on a
CAD STL (station frames from work/r2/edge_<tag>.json). Writes work/r2/lower_<tag>.json.
usage: r2_lower.py tag cad.stl"""
import sys, os, json
import numpy as np
from common import load, section, W
from r2_secs import read_stl

tag, cad = sys.argv[1], sys.argv[2]
E = json.load(open(os.path.join(W, "r2", f"edge_{tag}.json")))["stations"]
v, f = load(); cs = v[f].mean(1)
vc, fc = read_stl(cad); cc = vc[fc].mean(1)
OFFS = [-1, -2, -3, -4, -5, -6, -8, -10, -12]


def lines(V, Fc, C, p, R):
    m = np.linalg.norm(C - p, axis=1) < 26
    seg = section((V - p) @ R.T, Fc[m], 2, 0.0)[:, :, :2]
    out = {}
    for a in OFFS:
        # crossings of the profile with the line e1 = a
        A, B = seg[:, 0], seg[:, 1]
        s = (A[:, 0] - a) * (B[:, 0] - a) <= 0
        A, B = A[s], B[s]
        t = np.where(np.abs(B[:, 0] - A[:, 0]) > 1e-9, (a - A[:, 0]) / (B[:, 0] - A[:, 0] + 1e-12), 0.5)
        y = A[:, 1] + t * (B[:, 1] - A[:, 1])
        y = np.sort(y[np.abs(y) < 16])
        out[a] = [round(float(q), 3) for q in y]
    return out


rows = []
for s in E:
    p, t, e1, e2 = (np.array(s[k]) for k in ("p", "t", "e1", "e2"))
    R = np.array([e1, e2, t])
    rows.append(dict(k=s["k"], scan=lines(v, f, cs, p, R), cad=lines(vc, fc, cc, p, R)))
    sc, cd = rows[-1]["scan"], rows[-1]["cad"]
    print(s["k"], "scan", {a: sc[a][:3] for a in (-2, -5, -8)}, "| cad", {a: cd[a][:3] for a in (-2, -5, -8)})
json.dump(rows, open(os.path.join(W, "r2", f"lower_{tag}.json"), "w"), indent=0)
