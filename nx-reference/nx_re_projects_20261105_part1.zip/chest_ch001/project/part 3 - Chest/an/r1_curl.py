"""Fit a plane to the scan's inner end-corner surface (right bottom corner: where the wall curls from the post to the
end face) and print it with its traces at several z. usage: r1_curl.py"""
import json, os
import numpy as np
from common import load, tri_data, W

v, f = load()
c, n, a = tri_data(v, f)
box = (c[:, 0] > 53.5) & (c[:, 0] < 67.5) & (c[:, 1] > -276.2) & (c[:, 1] < -268.0) & (c[:, 2] > -45) & (c[:, 2] < -3)
sel = box & (n[:, 1] < -0.3) & (n[:, 0] < -0.15)
P, w = c[sel], a[sel]
print("points", len(P))
for it in range(6):
    c0 = (P * w[:, None]).sum(0) / w.sum()
    U, S, Vt = np.linalg.svd((P - c0) * np.sqrt(w[:, None]), full_matrices=False)
    nn = Vt[2]
    if nn[1] > 0:
        nn = -nn
    r = (P - c0) @ nn
    sd = np.sqrt((w * r * r).sum() / w.sum())
    keep = np.abs(r) < 2.0 * sd + 0.2
    print(f"it {it}: n {nn.round(4)} c0 {c0.round(2)} rms {sd:.3f} keep {keep.mean():.3f}")
    P, w = P[keep], w[keep]
for zz in (0, -10, -20, -30, -40, -45):
    # trace: points with n.(p - c0) = 0 at z = zz: p = (x, y): n0 x + n1 y = n.c0 - n2 zz
    k = nn @ c0 - nn[2] * zz
    xs = np.array([54.0, 67.0]); ys = (k - nn[0] * xs) / nn[1]
    print(f"z {zz:4d}: trace through ({xs[0]}, {ys[0]:.2f}) and ({xs[1]}, {ys[1]:.2f})")
json.dump(dict(n=nn.tolist(), c0=c0.tolist()), open(os.path.join(W, "r1", "curl_plane.json"), "w"))
