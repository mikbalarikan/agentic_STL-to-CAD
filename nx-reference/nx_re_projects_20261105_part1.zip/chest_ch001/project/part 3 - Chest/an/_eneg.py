import os, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
E = np.load(os.path.join(W, "emap.npz")); e, x0, y0, st = E["e"], float(E["x0"]), float(E["y0"]), float(E["step"])
ny, nx = e.shape
print("cells e<-0.3:", int(np.nansum(e < -0.3)), "e<-0.6:", int(np.nansum(e < -0.6)), "of", int(np.sum(~np.isnan(e))))
fig, ax = plt.subplots(figsize=(18, 21))
im = ax.imshow(np.where(e < 0, e, np.nan), origin="lower", extent=[x0, x0 + nx * st, y0, y0 + ny * st], cmap="viridis", vmin=-3, vmax=0)
plt.colorbar(im, shrink=.5); ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.tick_params(labelsize=6); ax.grid(lw=.3)
fig.tight_layout(); fig.savefig(os.path.join(W, "rv", "eneg.png"), dpi=55)
