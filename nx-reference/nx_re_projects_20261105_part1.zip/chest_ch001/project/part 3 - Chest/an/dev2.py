"""Two-way deviation report scan <-> CAD with zones (chest).
usage: dev2.py cad.stl tag [n_scan_samples] [nomaps]
scan->CAD: signed distance of scan vertices (main shell, part frame) to the CAD solid (+ = scan outside CAD = material
missing in CAD). CAD->scan: unsigned distance of CAD surface samples to the scan mesh.
Zones: exterior skin (scan point within 1 mm of the fitted exterior skin, facing out), shoulder flanges (|x| > 150
near the ring planes), rim band (z > -6), interior (everything else: inner wall, ribs, bosses, features).
Writes work/dev2_<tag>.json, work/dev2_<tag>_*.png."""
import sys, os, json
import numpy as np
import open3d as o3d
import pyvista as pv
from scipy.interpolate import BSpline
from common import W, load

cad, tag = sys.argv[1], sys.argv[2]
N = int(sys.argv[3]) if len(sys.argv) > 3 else 1500000
cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices()
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(cm))
v, f = load()
rng = np.random.default_rng(7)
idx = rng.choice(len(v), min(N, len(v)), replace=False)
P = v[idx].astype(np.float32)
if "half" in sys.argv:            # right-half test builds: compare x > 1 only
    P = P[P[:, 0] > 1.0]
d =sc.compute_signed_distance(o3d.core.Tensor(P)).numpy()
# exterior-skin distance: radial distance to the skin fit along the ray from C
s = np.load(os.path.join(W, "skin_fit.npz"))
tk, CF, C = s["tk"], s["CF"], s["C"]
u = P - C; rr = np.linalg.norm(u, axis=1); u /= rr[:, None]
psi = np.arccos(np.clip(-u[:, 2], -1, 1)); sn = np.maximum(np.sin(psi), 1e-9)
pp, qq = psi * u[:, 0] / sn, psi * u[:, 1] / sn
ok = np.hypot(pp, qq) < tk[-4]
rs = np.full(len(P), np.nan)
Sq = BSpline(tk, CF, 3)
order = np.argsort(qq)
# evaluate tensor spline row by row in q-bins (vectorised enough)
qb = np.round(qq / 0.002) * 0.002
for qv in np.unique(qb[ok]):
    k = ok & (qb == qv)
    rs[k] = BSpline(tk, Sq(np.clip(qv, tk[3], tk[-4])), 3)(np.clip(pp[k], tk[3], tk[-4]))
de = np.abs(rr - rs)
DT = json.load(open(os.path.join(W, "datums.json")))
nr = np.array(DT["shoulder_R"]["normal"]); prr = np.array(DT["shoulder_R"]["plane_pt"])
nl = np.array(DT["shoulder_L"]["normal"]); pl = np.array(DT["shoulder_L"]["plane_pt"])
shoulder = (np.abs(P[:, 0]) > 145) & ((np.abs((P - prr) @ nr) < 6) | (np.abs((P - pl) @ nl) < 6))
rim = (P[:, 2] > -6) & ~shoulder
outer = (de < 1.0) & ~shoulder & ~rim
inner = ~outer & ~shoulder & ~rim


def st(x):
    ax = np.abs(x)
    if len(x) == 0:
        return {}
    return dict(n=int(len(x)), mean=round(float(x.mean()), 4), rms=round(float(np.sqrt((x ** 2).mean())), 4),
                p50=round(float(np.percentile(ax, 50)), 4), p90=round(float(np.percentile(ax, 90)), 4),
                p95=round(float(np.percentile(ax, 95)), 4), p99=round(float(np.percentile(ax, 99)), 4),
                within_0p1=round(float((ax <= 0.1).mean()), 4), within_0p2=round(float((ax <= 0.2).mean()), 4),
                within_0p5=round(float((ax <= 0.5).mean()), 4), over_1=round(float((ax > 1).mean()), 4))


out = {"scan_to_cad": {"all": st(d), "outer_skin": st(d[outer]), "shoulder": st(d[shoulder]), "rim": st(d[rim]), "interior": st(d[inner])}}
out["scan_to_cad"]["outer_skin_right"] = st(d[outer & (P[:, 0] > 0)]); out["scan_to_cad"]["outer_skin_left"] = st(d[outer & (P[:, 0] < 0)])
sm = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
ss = o3d.t.geometry.RaycastingScene(); ss.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(sm))
pc = cm.sample_points_uniformly(600000)
Q = np.asarray(pc.points, dtype=np.float32)
dq = ss.compute_distance(o3d.core.Tensor(Q)).numpy()
out["cad_to_scan"] = {"all": st(dq)}
print(json.dumps(out, indent=1))
json.dump(out, open(os.path.join(W, f"dev2_{tag}.json"), "w"), indent=1)
np.save(os.path.join(W, f"dev2_{tag}_cad2scan.npy"), np.c_[Q, dq])
np.save(os.path.join(W, f"dev2_{tag}_scan2cad.npy"), np.c_[P[:400000], d[:400000]])
if "nomaps" in sys.argv:
    sys.exit(0)
mp = os.path.join(W, "scan_600k_f.ply")
if not os.path.exists(mp):
    mm = o3d.io.read_triangle_mesh(os.path.join(W, "scan_vc_f.ply")).simplify_quadric_decimation(600000)
    o3d.io.write_triangle_mesh(mp, mm)
m = pv.read(mp)
dd = sc.compute_signed_distance(o3d.core.Tensor(np.asarray(m.points, np.float32))).numpy()
m["dev"] = dd
c = np.array(m.center)
for vname, (dv, up) in {"front": ((0, 0, -1), (0, 1, 0)), "back": ((0, 0, 1), (0, 1, 0)), "iso": ((1, -1, -1), (0, 1, 0)),
                         "iso2": ((-1, -1, -1), (0, 1, 0)), "isob": ((1, 1, 1), (0, 1, 0)), "side": ((1, 0, -0.3), (0, 1, 0)),
                         "top": ((0, 1, -0.4), (0, 0, 1))}.items():
    p = pv.Plotter(off_screen=True, window_size=(1500, 1500))
    p.add_mesh(m, scalars="dev", cmap="coolwarm", clim=(-0.5, 0.5), show_scalar_bar=True,
               scalar_bar_args=dict(title="scan - CAD (mm), + = CAD missing material", fmt="%.2f"))
    p.camera_position = [tuple(c + np.array(dv, float) / np.linalg.norm(dv) * 1000), tuple(c), up]
    p.camera.view_angle = 32
    p.screenshot(os.path.join(W, f"dev2_{tag}_{vname}.png")); p.close()
print("maps ok")
