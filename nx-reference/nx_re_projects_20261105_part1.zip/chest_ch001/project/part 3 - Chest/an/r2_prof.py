"""Measure the neck flange profile at each station of work/r2/edge_<tag>.json on the full-res scan:
end face e1, flange top / bottom e2 (thickness), wall line fits far from the edge (angle, thickness) and the bend
vertex of the outer (lower) and inner (upper) lines.
usage: r2_prof.py tag"""
import sys, os, json
import numpy as np
from common import load, section, W

tag = sys.argv[1]
E = json.load(open(os.path.join(W, "r2", f"edge_{tag}.json")))
v, f = load()
cs = v[f].mean(1)


def linefit(P):
    c = P.mean(0); u, s, vt = np.linalg.svd(P - c); d = vt[0]
    return c, d, float(s[1] / np.sqrt(len(P)))


def inter(c1, d1, c2, d2):
    A = np.array([d1, -d2]).T
    t = np.linalg.lstsq(A, c2 - c1, rcond=None)[0]
    return c1 + t[0] * d1


rows = []
for s in E["stations"]:
    p, t, e1, e2 = (np.array(s[k]) for k in ("p", "t", "e1", "e2"))
    m = np.linalg.norm(cs - p, axis=1) < 25
    R = np.array([e1, e2, t])
    seg = section((v - p) @ R.T, f[m], 2, 0.0)[:, :, :2]
    P = seg.reshape(-1, 2)
    P = P[(P[:, 0] > -16) & (P[:, 0] < 6) & (np.abs(P[:, 1]) < 14)]
    # end face: points with |e2| < 0.8
    tip = float(P[np.abs(P[:, 1]) < 0.8, 0].max())
    fl = P[(P[:, 0] > -3.0) & (P[:, 0] < -1.0)]
    top = float(fl[fl[:, 1] > 0, 1].mean()) if (fl[:, 1] > 0).any() else np.nan
    bot = float(fl[fl[:, 1] < 0, 1].mean()) if (fl[:, 1] < 0).any() else np.nan
    # flange lines (near the tip) and wall lines (far): split by e2 sign near the tip; far part by distance from the
    # flange-mid line.
    lo = P[(P[:, 0] > -3.5) & (P[:, 0] < -0.8) & (P[:, 1] < 0)]
    up = P[(P[:, 0] > -3.5) & (P[:, 0] < -0.8) & (P[:, 1] > 0)]
    far = P[(P[:, 0] < -9) & (P[:, 0] > -16)]
    out = dict(k=s["k"], p=s["p"], tip=round(tip, 2), top=round(top, 2), bot=round(bot, 2), thk=round(top - bot, 2))
    if len(far) > 20 and len(lo) > 5 and len(up) > 5:
        cl, dl, _ = linefit(lo); cu, du, _ = linefit(up)
        # far points: two lines; split by a 2-means on the perpendicular offset along the overall far direction
        cf, df, _ = linefit(far)
        nf = np.array([-df[1], df[0]]); off = (far - cf) @ nf
        a_ = far[off < 0]; b_ = far[off >= 0]
        if len(a_) > 5 and len(b_) > 5:
            ca, da, ra = linefit(a_); cb, db, rb = linefit(b_)
            # which far line is the outer (lower) one: the one whose extension passes below
            wa = float(abs((cb - ca) @ np.array([-da[1], da[0]])))
            ang = float(np.degrees(np.arccos(min(1, abs(da @ dl)))))
            # outer far line = the one with lower e2 at e1 = -9
            ya = ca[1] + (-9 - ca[0]) / da[0] * da[1] if abs(da[0]) > 1e-3 else ca[1]
            yb = cb[1] + (-9 - cb[0]) / db[0] * db[1] if abs(db[0]) > 1e-3 else cb[1]
            (co, do_), (ci, di) = ((ca, da), (cb, db)) if ya < yb else ((cb, db), (ca, da))
            vo = inter(cl, dl, co, do_); vi = inter(cu, du, ci, di)
            out.update(wall_thk=round(wa, 2), bend_deg=round(ang, 1), bend_out=vo.round(2).tolist(), bend_in=vi.round(2).tolist(),
                       wall_dir=(do_ if do_[0] < 0 else -do_).round(3).tolist())
    rows.append(out)
    print(out)
json.dump(rows, open(os.path.join(W, "r2", f"prof_{tag}.json"), "w"), indent=1)
