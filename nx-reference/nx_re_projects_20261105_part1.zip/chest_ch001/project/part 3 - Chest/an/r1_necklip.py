"""Neck edge: scan points standing proud of the CAD (signed distance > thr) in the neck region, top view coloured by
the distance, with the CAD neck cut edge (CAD triangles of near-vertical faces at the opening) in black.
usage: r1_necklip.py cad.stl out.png [thr=1.0]"""
import sys
import numpy as np
import open3d as o3d
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load

cad, out = sys.argv[1], sys.argv[2]
thr = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0
cm = o3d.io.read_triangle_mesh(cad); cm.remove_duplicated_vertices()
rs = o3d.t.geometry.RaycastingScene()
rs.add_triangles(o3d.t.geometry.TriangleMesh(o3d.core.Tensor(np.asarray(cm.vertices, np.float32)),
                                             o3d.core.Tensor(np.asarray(cm.triangles, np.int32))))
v, f = load()
m = (np.abs(v[:, 0]) < 100) & (v[:, 1] > 28) & (v[:, 1] < 118) & (v[:, 2] < -1.5)
P = v[m].astype(np.float32)
d = rs.compute_signed_distance(o3d.core.Tensor(P)).numpy()
k = (d > thr) & (d < 8)
fig, ax = plt.subplots(figsize=(20, 12))
s = ax.scatter(P[k, 0], P[k, 1], s=0.3, c=d[k], cmap="turbo", vmin=thr, vmax=6)
plt.colorbar(s, label="scan proud of CAD (mm)")
V = np.asarray(cm.vertices); T = np.asarray(cm.triangles)
tc = V[T].mean(1); tn = np.cross(V[T[:, 1]] - V[T[:, 0]], V[T[:, 2]] - V[T[:, 0]])
tn /= np.maximum(np.linalg.norm(tn, axis=1), 1e-12)[:, None]
e = (np.abs(tn[:, 2]) < 0.05) & (np.abs(tc[:, 0]) < 100) & (tc[:, 1] > 28) & (tc[:, 1] < 118)
ax.scatter(tc[e, 0], tc[e, 1], s=0.2, c="k")
ax.set_aspect("equal"); ax.grid(lw=0.3); ax.set_xticks(np.arange(-100, 101, 10)); ax.set_yticks(np.arange(30, 121, 5))
ax.set_title(f"scan proud of CAD > {thr} mm (neck region, z < -1.5); black = vertical CAD faces")
plt.tight_layout(); plt.savefig(out, dpi=60)
# along the arms: height of the proud band per y bin (right arm)
for y0 in range(40, 116, 5):
    q = k & (np.abs(P[:, 1] - y0) < 1.0) & (P[:, 0] > 0)
    if q.sum() > 10:
        print(f"y {y0}: x {np.percentile(P[q, 0], 5):.1f}..{np.percentile(P[q, 0], 95):.1f}  z {np.percentile(P[q, 2], 50):.1f}  d p90 {np.percentile(d[q], 90):.2f}  n {q.sum()}")
