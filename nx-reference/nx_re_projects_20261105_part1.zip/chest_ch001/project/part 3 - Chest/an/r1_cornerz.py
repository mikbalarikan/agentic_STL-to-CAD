"""Bottom-end right corner, scan only: horizontal sections every few mm. For each z: circle fit of the post (points
within 3..9 mm of the bore axis, west/north side) and a line fit of the straight run from the post to the end tip,
and whether the line is tangent to the circle. Plot all sections (one panel each) with the fits.
usage: r1_cornerz.py out.png"""
import sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import load, section, fit_circle_robust

v, f = load()
fc = v[f[:, 0]]
sel = (fc[:, 0] > 44) & (fc[:, 0] < 76) & (fc[:, 1] > -278) & (fc[:, 1] < -248) & (fc[:, 2] > -70) & (fc[:, 2] < 3)
AX = np.array([59.3, -265.8])
zs = [-1, -5, -10, -15, -20, -25, -30, -35, -40, -45, -50, -55]
fig, axs = plt.subplots(3, 4, figsize=(24, 18))
rows = []
for k, z in enumerate(zs):
    sg = section(v, f, 2, float(z), sel=sel)
    P = sg.reshape(-1, 3)[:, :2]
    p = axs[k // 4][k % 4]
    p.add_collection(LineCollection(sg[:, :, :2], colors="#e8900c", linewidths=1.2))
    d = np.linalg.norm(P - AX, axis=1)
    ang = np.degrees(np.arctan2(P[:, 1] - AX[1], P[:, 0] - AX[0]))
    mc = (d > 2.6) & (d < 9) & (ang > 60) & (ang < 250)            # post: north-west half
    txt = f"z {z}"
    circ = None
    if mc.sum() > 30:
        cc, r, sd, mm = fit_circle_robust(P[mc])
        circ = (cc, r)
        t = np.linspace(0, 2 * np.pi, 200)
        p.plot(cc[0] + r * np.cos(t), cc[1] + r * np.sin(t), "b-", lw=0.8)
        txt += f"\npost c ({cc[0]:.2f},{cc[1]:.2f}) r {r:.2f} sd {sd:.2f}"
    # straight run: points south-east of the post, between the post and the end tip, inner side (west of the outer skin)
    ml = (P[:, 1] < AX[1] - 3.5) & (P[:, 1] > -273.6) & (P[:, 0] < 64.5) & (d > (circ[1] + 0.6 if circ else 5))
    ml &= (P[:, 0] - AX[0]) > -8
    if ml.sum() > 15:
        Q = P[ml]; q0 = Q.mean(0)
        U, S, Vt = np.linalg.svd(Q - q0); dvec = Vt[0]; nvec = np.array([-dvec[1], dvec[0]])
        res = (Q - q0) @ nvec
        p.plot([q0[0] - 8 * dvec[0], q0[0] + 8 * dvec[0]], [q0[1] - 8 * dvec[1], q0[1] + 8 * dvec[1]], "g-", lw=0.8)
        slope = dvec[1] / dvec[0]
        txt += f"\nline slope {slope:.3f} rms {np.sqrt((res**2).mean()):.2f}"
        if circ:
            dist = abs((circ[0] - q0) @ nvec)
            txt += f"\ncentre-line {dist:.2f} vs r {circ[1]:.2f}"
            rows.append((z, circ[0][0], circ[0][1], circ[1], slope, dist))
    p.set_title(txt, fontsize=9); p.set_xlim(46, 76); p.set_ylim(-278, -250); p.set_aspect("equal"); p.grid(lw=0.3)
plt.tight_layout(); plt.savefig(sys.argv[1], dpi=55)
for r_ in rows:
    print("z %4d  post c (%.2f, %.2f) r %.2f | line slope %.3f, centre-to-line %.2f (tangent if = r)" % r_)
