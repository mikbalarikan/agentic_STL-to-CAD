"""Flat-topped interior features (ribs, bosses, clips, plates): tops are planes z = L parallel to the rim.
1. levels = peaks of the histogram of interior top z over flat (n_z > 0.985), raised (> 0.7 mm) pixels;
2. per level: pixels within 0.2 mm of L and raised > 0.5 -> connected components (area > MIN_A);
3. mirror test per component (IoU with the mirrored level mask): symmetric components get the averaged shape
   (mean of the signed distance fields of the component and its mirror image);
   kind "R" = right half only (mirrored in NX), "C" = crosses the mirror plane (added whole after the mirror),
   "A" = one-sided (asymmetric, added whole after the mirror);
4. loops (outer + holes) from the contour of the field, Douglas-Peucker 0.08 mm; round loops -> circles.
Writes work/plateaus.json + work/plateaus.png."""
import os, json
import numpy as np
from scipy import ndimage as ndi
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W, fit_circle

R = np.load(os.path.join(W, "raised.npz"))
H = np.load(os.path.join(W, "hmap.npz"))
st, x0, y0 = float(R["step"]), float(R["x0"]), float(R["y0"])
top, rs, ntop = R["top"], R["raise_"], H["ntop"]
ny, nx = top.shape
assert abs(x0 + (nx * st) / 2) < 1e-6 + st, "grid not symmetric about x = 0"
MIN_A = 3.0 / (st * st)


def mirror(a):
    out = np.zeros_like(a)
    out[:, 1:] = a[:, :0:-1]
    return out


# grid x of column i: x0 + i st; mirror of column i is nx - i (x0 = -nx st / 2)
xs = x0 + np.arange(nx) * st; ys = y0 + np.arange(ny) * st
flat = (ntop > 0.985) & (rs > 1.2) & np.isfinite(top)
h, e = np.histogram(top[flat], bins=np.arange(-140, 4, 0.05))
hs = np.convolve(h, np.ones(3), "same")
pk = [i for i in range(1, len(hs) - 1) if hs[i] >= hs[i - 1] and hs[i] > hs[i + 1] and hs[i] > 120]
levels = []
for i in sorted(pk, key=lambda i: -hs[i]):
    L = e[i] + 0.075
    if all(abs(L - l) > 0.35 for l in levels):
        levels.append(round(float(L), 2))
levels.sort()
print("levels", levels)


def rdp(P, eps):
    if len(P) < 3:
        return P
    a, b = P[0], P[-1]
    ab = b - a; L = np.linalg.norm(ab)
    if L < 1e-9:
        d = np.linalg.norm(P - a, axis=1)
    else:
        d = np.abs(ab[0] * (P[:, 1] - a[1]) - ab[1] * (P[:, 0] - a[0])) / L
    i = int(np.argmax(d))
    if d[i] > eps:
        return np.vstack([rdp(P[:i + 1], eps)[:-1], rdp(P[i:], eps)])
    return np.vstack([a, b])


def loops_of(field):
    """contour at 0 of a field (<0 inside), padded; returns list of (pts, signed area)."""
    f = np.pad(field, 2, constant_values=10.0)
    cs = plt.contour(f, levels=[0.0]); plt.close()
    out = []
    for seg in cs.allsegs[0]:
        if len(seg) < 6:
            continue
        P = np.c_[x0 + (seg[:, 0] - 2) * st, y0 + (seg[:, 1] - 2) * st]
        A = 0.5 * np.sum(P[:-1, 0] * P[1:, 1] - P[1:, 0] * P[:-1, 1])
        out.append((P, A))
    return out


def sdf(mask):
    return ndi.distance_transform_edt(~mask) - ndi.distance_transform_edt(mask)


feats = []
fig, ax = plt.subplots(figsize=(17, 20))
ax.imshow(np.where(np.isfinite(top), 0.0, np.nan), origin="lower", extent=[x0, x0 + nx * st, y0, y0 + ny * st], cmap="Greys", vmin=-1, vmax=1)
cm = plt.get_cmap("tab20")
for li, L in enumerate(levels):
    m = (np.abs(top - L) < 0.2) & (rs > 0.5)
    m = ndi.binary_opening(ndi.binary_closing(m, iterations=1), iterations=1)
    lab, n = ndi.label(m)
    mm = mirror(m)
    for k in range(1, n + 1):
        c = lab == k
        area = c.sum()
        if area < MIN_A:
            continue
        # reject pieces of a gently sloping continuous surface (inset panel): most of a ring around them at ~ the same z
        ring = ndi.binary_dilation(c, iterations=5) & ~ndi.binary_dilation(c, iterations=1)
        tr = top[ring]
        if np.mean(np.isfinite(tr) & (np.abs(tr - L) < 0.6)) > 0.5:
            continue
        cmir = mirror(c)
        mm_loc = mm & ndi.binary_dilation(c, iterations=6)
        iou = (c & mm_loc).sum() / max(1, (c | mm_loc).sum())
        jj, ii = np.nonzero(c)
        xmin, xmax = xs[ii].min(), xs[ii].max()
        if iou > 0.55:
            # averaged shape of this component and its mirror partner (partner = mirrored level mask near cmir)
            part_ = mirror(mm_loc)
            fld = 0.5 * (sdf(c) + sdf(part_))
            fld = 0.5 * (fld + mirror(fld)) if xmin < 0 < xmax else fld
            kind = "C" if xmin < 0 < xmax else ("R" if xmin > 0 else "skip")
        else:
            fld = sdf(ndi.gaussian_filter(c.astype(float), 0.8) > 0.5)
            kind = "A"
        if kind == "skip":
            continue
        fld = ndi.gaussian_filter(fld, 0.7)
        lps = []
        for P, A in loops_of(fld):
            if abs(A) < 1.0:
                continue
            Q = rdp(P, 0.08)
            cc, r, res = fit_circle(P)
            circ = bool(np.std(res) < max(0.03, 0.02 * r) and len(P) > 12 and r < 15)
            lps.append(dict(area=round(float(A), 2), circle=[round(float(cc[0]), 3), round(float(cc[1]), 3), round(float(r), 3)] if circ else None,
                            pts=Q.round(3).tolist()))
        if not lps:
            continue
        lps.sort(key=lambda l: -abs(l["area"]))
        feats.append(dict(level=L, kind=kind, iou=round(float(iou), 2), area_mm2=round(float(area * st * st), 1),
                          bbox=[round(float(xmin), 2), round(float(ys[jj].min()), 2), round(float(xmax), 2), round(float(ys[jj].max()), 2)], loops=lps))
        for l in lps:
            P = np.array(l["pts"])
            ax.plot(P[:, 0], P[:, 1], "-", lw=0.8, color={"R": "tab:blue", "C": "tab:green", "A": "tab:red"}[kind])
        ax.text(xmax + 1, ys[jj].max(), f"{L:.1f}", fontsize=5, color="k")
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.tick_params(labelsize=6)
ax.set_title("plateaus: blue = right half (mirrored), green = across the mirror plane, red = one-sided")
fig.tight_layout(); fig.savefig(os.path.join(W, "plateaus.png"), dpi=80)
json.dump(dict(levels=levels, feats=feats), open(os.path.join(W, "plateaus.json"), "w"))
from collections import Counter
print("features", len(feats), Counter(f["kind"] for f in feats), "circles", sum(1 for f in feats for l in f["loops"] if l["circle"]))
