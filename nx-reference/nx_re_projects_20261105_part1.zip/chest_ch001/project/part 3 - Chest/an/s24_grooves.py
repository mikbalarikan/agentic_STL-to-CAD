"""Styling grooves of the exterior (part 1 seams method, automatic): skin-fit residual < THR (scan below the smooth skin)
rasterised in plan (0.5 mm), thin long components = groove lines; each ordered into a path (greedy walk from an end),
refined to the residual minimum across, smoothed, mapped onto the skin (radial fit) and lifted along the outward
normal by LIFT (tube centre). Right-half paths with a mirror partner -> "R"; paths across x = 0 -> "C".
Writes work/grooves.json + figure. Depth / width measured from the residual profile."""
import os, json
import numpy as np
from scipy import ndimage
from scipy.interpolate import BSpline
from scipy.spatial import cKDTree
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W

THR = -0.18
TUBE_D = 1.8
A = np.load(os.path.join(W, "skin_res_all.npy"))
X, res = A[:, :3], A[:, 3]
s = np.load(os.path.join(W, "skin_fit.npz")); tk, CF, C = s["tk"], s["CF"], s["C"]
Sq = BSpline(tk, CF, 3)
# features already modelled elsewhere are excluded (panel, LED recess, vents, shoulder planes, rim band)
ex = ((np.abs(X[:, 0]) < 44) & (X[:, 1] > -168) & (X[:, 1] < -30)) | ((np.abs(X[:, 0]) < 72) & (X[:, 1] > -34) & (X[:, 1] < -8)) \
    | ((np.abs(X[:, 0]) < 52) & (X[:, 1] > -218) & (X[:, 1] < -186)) | ((np.abs(X[:, 0]) > 68) & (np.abs(X[:, 0]) < 152) & (X[:, 1] > 56) & (X[:, 1] < 92)) \
    | (X[:, 2] > -8) | (np.abs(X[:, 0]) > 150) | ((np.abs(X[:, 0]) < 40) & (X[:, 1] > -15) & (X[:, 1] < 10))
g = (res < THR) & ~ex
st = 0.5
x0, y0 = -170.0, -280.0
ix = np.round((X[g, 0] - x0) / st).astype(int); iy = np.round((X[g, 1] - y0) / st).astype(int)
G = np.zeros((int(400 / st), int(340 / st)), bool); G[iy, ix] = True
G = ndimage.binary_closing(G, iterations=2)
lab, n = ndimage.label(G, structure=np.ones((3, 3)))
tree = cKDTree(X[:, :2])


def path_of(mask):
    jj, ii = np.nonzero(mask)
    P = np.c_[x0 + ii * st, y0 + jj * st]
    if len(P) < 20:
        return None
    # thin: keep points, walk greedily from the point farthest from the centroid
    t = cKDTree(P)
    start = int(np.argmax(np.linalg.norm(P - P.mean(0), axis=1)))
    used = np.zeros(len(P), bool); path = [P[start]]; cur = P[start]
    for _ in range(5000):
        idx = t.query_ball_point(cur, 2.5)
        used[idx] = True
        cand = [k for k in t.query_ball_point(cur, 4.0) if not used[k]]
        if not cand:
            break
        nxt = P[cand].mean(0)
        if np.linalg.norm(nxt - cur) < 0.5:
            break
        path.append(nxt); cur = nxt
    Q = np.array(path)
    return Q if len(Q) > 6 else None


paths = []
for k in range(1, n + 1):
    m = lab == k
    jj, ii = np.nonzero(m)
    ext = np.hypot(np.ptp(ii), np.ptp(jj)) * st
    if ext < 25 or m.sum() * st * st / ext > 3.0:        # long and thin only
        continue
    Q = path_of(m)
    if Q is None:
        continue
    # refine across: residual minimum within +-2 mm (perpendicular in plan), then smooth
    T = np.gradient(Q, axis=0); T /= np.linalg.norm(T, axis=1)[:, None] + 1e-12
    Nn = np.c_[-T[:, 1], T[:, 0]]
    Qr = Q.copy(); depth = []
    for i in range(len(Q)):
        best = None
        for o in np.linspace(-2, 2, 17):
            p = Q[i] + o * Nn[i]
            d_, j_ = tree.query(p)
            if d_ < 0.6 and (best is None or res[j_] < best[0]):
                best = (res[j_], p)
        if best is not None:
            Qr[i] = best[1]; depth.append(best[0])
    Qs = np.c_[ndimage.gaussian_filter1d(Qr[:, 0], 2.0, mode="nearest"), ndimage.gaussian_filter1d(Qr[:, 1], 2.0, mode="nearest")]
    paths.append(dict(P=Qs, depth=float(np.median(depth)) if depth else 0.0))


def skin_point(xy):
    """exterior skin point above plan point (x, y): bisection on the ray parameter."""
    out = []
    for x, y in xy:
        # solve for (p, q) whose skin point has plan (x, y): fixed-point on the direction from C
        p, q = 0.0, 0.0
        for _ in range(40):
            psi = np.hypot(p, q); sn = np.sinc(psi / np.pi)
            dvec = np.array([p * sn, q * sn, -np.cos(psi)])
            r = BSpline(tk, Sq(np.clip(q, tk[3], tk[-4])), 3)(np.clip(p, tk[3], tk[-4]))
            P3 = C + r * dvec
            # update the direction toward (x, y, P3_z)
            tgt = np.array([x, y, P3[2]]) - C
            tgt /= np.linalg.norm(tgt)
            psi2 = np.arccos(np.clip(-tgt[2], -1, 1)); s2 = np.sin(psi2) / max(psi2, 1e-9)
            p, q = tgt[0] / s2, tgt[1] / s2
        out.append(P3)
    return np.array(out)


def normal_at(P):
    e = 0.3
    Pa = skin_point(np.c_[P[:, 0] + e, P[:, 1]]); Pb = skin_point(np.c_[P[:, 0] - e, P[:, 1]])
    Pc = skin_point(np.c_[P[:, 0], P[:, 1] + e]); Pd = skin_point(np.c_[P[:, 0], P[:, 1] - e])
    n = np.cross(Pa - Pb, Pc - Pd); n /= np.linalg.norm(n, axis=1)[:, None]
    n *= np.sign(n[:, 2:3]) * -1.0                       # outward = toward -Z side
    return n


for pth in paths:
    pth["cen"] = pth["P"].mean(0); pth["xmin"], pth["xmax"] = pth["P"][:, 0].min(), pth["P"][:, 0].max()
out = {}
fig, ax = plt.subplots(figsize=(14, 17))
ax.scatter(X[::4, 0], X[::4, 1], c=np.clip(res[::4], -0.6, 0.6), s=0.1, cmap="seismic")
k = 0
for pth in paths:
    if pth["xmin"] < -1 and pth["xmax"] > 1:
        kind = "C"
    else:
        mate = [q for q in paths if q is not pth and np.hypot(q["cen"][0] + pth["cen"][0], q["cen"][1] - pth["cen"][1]) < 6]
        kind = ("R" if pth["cen"][0] > 0 else "L") if mate else "A"
    ax.plot(pth["P"][:, 0], pth["P"][:, 1], "-", lw=1.2, color={"R": "lime", "C": "orange", "A": "magenta", "L": "cyan"}[kind])
    if kind in ("L",):
        continue
    S = skin_point(pth["P"]); Nn = normal_at(pth["P"])
    lift = TUBE_D / 2 + pth["depth"]                     # tube centre so that its bottom reaches the groove depth
    pts = S + lift * Nn
    keep = np.r_[np.arange(0, len(pts), 2), len(pts) - 1]
    k += 1
    out[f"G{k}"] = dict(kind=kind, depth=round(pth["depth"], 3), pts=pts[np.unique(keep)].round(3).tolist())
ax.set_aspect("equal"); ax.grid(True, lw=0.3)
fig.tight_layout(); fig.savefig(os.path.join(W, "groove_paths.png"), dpi=70)
json.dump(dict(tube_d=TUBE_D, paths=out), open(os.path.join(W, "grooves.json"), "w"))
print("paths", len(paths), {n_: (v["kind"], v["depth"], len(v["pts"])) for n_, v in out.items()})
