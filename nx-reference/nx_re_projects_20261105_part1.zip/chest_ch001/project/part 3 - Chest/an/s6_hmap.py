"""Height maps of the framed scan by ray casting along Z: 'top' = first hit from +Z (interior side, z of the
surface seen from the back), 'bot' = first hit from -Z (exterior). Grid step arg (default 0.25 mm).
Writes work/hmap.npz (x0, y0, step, top, bot, ntop, nbot) and grey-shaded PNGs with a mm grid."""
import os, sys
import numpy as np
import open3d as o3d
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W, load

ST = float(sys.argv[1]) if len(sys.argv) > 1 else 0.25
v, f = load()
m = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
lo, hi = v.min(0), v.max(0)
x0, x1, y0, y1 = np.floor(lo[0]) - 2, np.ceil(hi[0]) + 2, np.floor(lo[1]) - 2, np.ceil(hi[1]) + 2
xs = np.arange(x0, x1, ST); ys = np.arange(y0, y1, ST)
X, Y = np.meshgrid(xs, ys)
out = {}
for name, z, dz in (("top", 200.0, -1.0), ("bot", -200.0, 1.0)):
    rays = np.zeros((X.size, 6), np.float32)
    rays[:, 0] = X.ravel(); rays[:, 1] = Y.ravel(); rays[:, 2] = z; rays[:, 5] = dz
    r = sc.cast_rays(o3d.core.Tensor(rays))
    t = r["t_hit"].numpy(); nrm = r["primitive_normals"].numpy()
    h = np.where(np.isfinite(t), z + dz * t, np.nan).reshape(X.shape)
    out[name] = h.astype(np.float32); out["n" + name] = nrm[:, 2].reshape(X.shape).astype(np.float32)
np.savez(os.path.join(W, "hmap.npz"), x0=x0, y0=y0, step=ST, **out)
for name in ("top", "bot"):
    h = out[name]
    fig, ax = plt.subplots(figsize=(17, 20))
    gy, gx = np.gradient(np.nan_to_num(h, nan=np.nanmin(h)))
    shade = np.clip(0.5 + 2.0 * (gx - gy), 0, 1)
    ax.imshow(np.where(np.isnan(h), np.nan, shade), cmap="gray", origin="lower", extent=[x0, x1, y0, y1], vmin=0, vmax=1)
    cs = ax.imshow(h, cmap="turbo", origin="lower", extent=[x0, x1, y0, y1], alpha=0.35)
    plt.colorbar(cs, ax=ax, shrink=0.6)
    ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(10 * np.floor(y0 / 10), y1, 10)); ax.grid(True, lw=0.3, alpha=0.5)
    ax.tick_params(labelsize=6); ax.set_title(f"height map {name} (z of first hit seen from {'+' if name=='top' else '-'}Z)")
    fig.tight_layout(); fig.savefig(os.path.join(W, f"hmap_{name}.png"), dpi=80); plt.close(fig)
print("ok", X.shape)
