"""CAD surface coloured by its distance to the scan (CAD -> scan, signed: + = CAD stands outside the scan material,
i.e. CAD has extra material there; - = CAD surface inside the scan material) in a box, several views.
usage: r1_cadmap.py cad.stl out.png x0 x1 y0 y1 z0 z1 view1 [view2 ...]   view = dx,dy,dz[,upx,upy,upz]"""
import sys
import numpy as np
import open3d as o3d
import pyvista as pv
import matplotlib.image as mpimg
from common import load

cad, out = sys.argv[1], sys.argv[2]
b = np.array(list(map(float, sys.argv[3:9]))).reshape(3, 2)
views = [list(map(float, s.split(","))) for s in sys.argv[9:]]
v, f = load()
sm = o3d.t.geometry.TriangleMesh(o3d.core.Tensor(v.astype(np.float32)), o3d.core.Tensor(f.astype(np.int32)))
ss = o3d.t.geometry.RaycastingScene(); ss.add_triangles(sm)
with open(cad, "rb") as fh:
    fh.read(80); k = int(np.frombuffer(fh.read(4), np.uint32)[0])
    T = np.fromfile(fh, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), k)["v"].astype(float)
tc = T.mean(1)
m = np.all((tc >= b[:, 0]) & (tc <= b[:, 1]), axis=1)
T = T[m]; tc = tc[m]
tn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); tn /= np.maximum(np.linalg.norm(tn, axis=1), 1e-12)[:, None]
cp = ss.compute_closest_points(o3d.core.Tensor(tc.astype(np.float32)))
P = cp["points"].numpy(); d = np.linalg.norm(tc - P, axis=1)
occ = ss.compute_occupancy(o3d.core.Tensor(tc.astype(np.float32))).numpy() if False else None
sgn = np.sign(np.einsum("ij,ij->i", tc - P, tn))       # CAD point beyond the scan along the CAD normal -> CAD extra
ds = d * np.where(sgn == 0, 1, sgn)
faces = np.c_[np.full(len(T), 3), np.arange(3 * len(T)).reshape(-1, 3)].ravel()
mesh = pv.PolyData(T.reshape(-1, 3), faces)
mesh.cell_data["d"] = d
imgs = []
ctr = b.mean(1); R = float(np.max(b[:, 1] - b[:, 0])) * 1.9
for vw in views:
    dv = np.array(vw[:3]); dv /= np.linalg.norm(dv); up = vw[3:6] if len(vw) >= 6 else (0, 0, 1)
    p = pv.Plotter(off_screen=True, window_size=(900, 800)); p.set_background("white")
    p.add_mesh(mesh, scalars="d", cmap="turbo", clim=(0, 5), show_scalar_bar=True,
               scalar_bar_args=dict(title="CAD to scan distance mm", fmt="%.1f"))
    p.camera_position = [tuple(ctr + dv * R), tuple(ctr), tuple(up)]; p.camera.view_angle = 30
    imgs.append(p.screenshot(None, return_img=True)); p.close()
mpimg.imsave(out, np.hstack(imgs))
far = d > 2.0
print("CAD area in box", round(float(np.sum(np.linalg.norm(np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]), axis=1)) / 2), 1),
      "share > 2 mm", round(float(far.mean()), 3))
