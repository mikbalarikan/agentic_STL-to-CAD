"""Exterior recess depth (black top-hat of the scan ZE map, footprint 30 mm) tiles. usage: clean_recess.py maps.npz name:x0:x1:y0:y1 ..."""
import sys, os
import numpy as np
from scipy import ndimage as ndi
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
d = np.load(sys.argv[1]); xs, ys = d["xs"], d["ys"]
Z = d["scan_ZE"].astype(float); m = np.isfinite(Z); Zf = np.where(m, Z, 50.0)
D = np.where(m, Zf - ndi.grey_opening(Zf, size=(121, 121)), np.nan)   # ZE grows into the recess (toward +z)
np.savez_compressed(os.path.join(ROOT, "work", "clean", "recess.npz"), depth=D.astype(np.float32), ze=Z.astype(np.float32), xs=xs, ys=ys)
for t in sys.argv[2:]:
    name, x0, x1, y0, y1 = t.split(":"); x0, x1, y0, y1 = map(float, (x0, x1, y0, y1))
    ix = (xs >= x0) & (xs <= x1); iy = (ys >= y0) & (ys <= y1)
    fig, ax = plt.subplots(figsize=((x1 - x0) / 6 + 2, (y1 - y0) / 6 + 1), dpi=100)
    im = ax.imshow(np.clip(D[np.ix_(iy, ix)], 0, 6), cmap="turbo", origin="lower", extent=(x0, x1, y0, y1), vmin=0, vmax=6)
    fig.colorbar(im, ax=ax, fraction=0.03, label="recess depth (mm)")
    ax.contour(xs[ix], ys[iy], np.nan_to_num(D[np.ix_(iy, ix)], nan=0), levels=[0.5, 1.0, 2.0, 3.0], colors="w", linewidths=0.4)
    ax.set_xticks(np.arange(np.ceil(x0 / 5) * 5, x1 + 0.1, 5)); ax.set_yticks(np.arange(np.ceil(y0 / 5) * 5, y1 + 0.1, 5))
    ax.grid(True, color="k", lw=0.3, alpha=0.5); ax.tick_params(labelsize=6); ax.set_title(name + " exterior recess depth; contours 0.5/1/2/3", fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(ROOT, "work", "clean", "scanmaps", f"E_{name}.png")); plt.close(fig)
print("ok")
