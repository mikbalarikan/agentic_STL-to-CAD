"""Plane census in the raw scan frame: area-weighted histograms of the coordinate along each axis for faces whose
normal is within 3 deg of +-axis. Prints the strongest levels (planes) per axis direction."""
import os
import numpy as np
from common import W, tri_data

d = np.load(os.path.join(W, "main.npz"))
v, f = d["v"].astype(np.float64), d["f"]
c, n, a = tri_data(v, f)
np.save(os.path.join(W, "tri_c.npy"), c.astype(np.float32)); np.save(os.path.join(W, "tri_n.npy"), n.astype(np.float32))
np.save(os.path.join(W, "tri_a.npy"), a.astype(np.float32))
cos3 = np.cos(np.radians(3))
for ax in range(3):
    for sgn in (1, -1):
        m = n[:, ax] * sgn > cos3
        if m.sum() < 100:
            continue
        h, e = np.histogram(c[m, ax], bins=np.arange(c[:, ax].min() - 1, c[:, ax].max() + 1, 0.1), weights=a[m])
        idx = np.argsort(-h)[:40]
        lev = []
        for i in sorted(idx):
            if h[i] < 15: continue
            if lev and abs(e[i] - lev[-1][0]) < 0.35:
                if h[i] > lev[-1][1]: lev[-1] = (e[i] + 0.05, h[i])
                continue
            lev.append((e[i] + 0.05, h[i]))
        print("axis", "xyz"[ax], "+" if sgn > 0 else "-", "area", round(a[m].sum()), [(round(l, 2), round(float(w))) for l, w in lev])
