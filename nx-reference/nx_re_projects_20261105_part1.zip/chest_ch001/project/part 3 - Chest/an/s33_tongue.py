"""Rim tongue: the narrow raised band on the inner edge of the rim (sections: ~1.5 wide, top ~+1.7 above the rim
plane). Region = interior height map top in (0.6, 4) within 8 mm of the part outline, symmetric (min of the cell
and its mirror), minus the plateau loops above the rim (pins). Top level per connected piece = median top,
rounded to 0.05. Writes work/tongue.json (loops like plateaus.json, kind R, x >= -0.6) + work/rv/tongue.png."""
import os, json
import numpy as np
from scipy import ndimage
import contourpy
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
from arcfit import fit_loop, seg_points
H = np.load(os.path.join(W, "hmap.npz"))
st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"]); top = H["top"].astype(np.float64)
ny, nx = top.shape
XX, YY = np.meshgrid(x0 + np.arange(nx) * st, y0 + np.arange(ny) * st)
part = ~np.isnan(top)
edge = ndimage.distance_transform_edt(ndimage.binary_fill_holes(part)) * st
tm = np.full_like(top, np.nan); tm[:, 1:] = top[:, ::-1][:, :-1]
R = (top > 0.6) & (top < 4.0) & (edge < 8.0)
Rm = (tm > 0.6) & (tm < 4.0)
R = R & ndimage.binary_dilation(Rm, iterations=4) & (XX > -0.6)
R = ndimage.binary_closing(R, iterations=2) & (XX > -0.6)
lab, n = ndimage.label(R)
sizes = ndimage.sum(R, lab, range(1, n + 1)) * st * st
out = {"loops": []}
fig, ax = plt.subplots(figsize=(14, 21))
ax.imshow(np.where(part, np.clip(top, -5, 4), np.nan), origin="lower", extent=[x0, x0 + nx * st, y0, y0 + ny * st], cmap="gray", alpha=.6)
for k in range(1, n + 1):
    if sizes[k - 1] < 4.0:
        continue
    m = lab == k
    h = round(float(np.median(top[m])) / 0.05) * 0.05
    G = np.pad(ndimage.gaussian_filter(m.astype(float), 0.7), 2)
    for C in contourpy.contour_generator(z=G, line_type="Separate").lines(0.5):
        if np.linalg.norm(C[0] - C[-1]) > 1e-6:
            continue
        Q = np.c_[x0 + (C[:, 0] - 2) * st, y0 + (C[:, 1] - 2) * st][:-1]
        A = 0.5 * (np.dot(Q[:, 0], np.roll(Q[:, 1], -1)) - np.dot(Q[:, 1], np.roll(Q[:, 0], -1)))
        if A < 4.0:
            continue
        segs = fit_loop(Q, tol=0.06)
        out["loops"].append(dict(h=h, kind="R", area=float(A), segs=[([s[0], s[1].tolist(), s[2].tolist()] if s[0] == "L" else [s[0], s[1].tolist(), s[2].tolist(), s[3].tolist(), float(s[4]), bool(s[5])]) for s in segs]))
        Qp = np.vstack([seg_points(s) for s in segs]); ax.plot(Qp[:, 0], Qp[:, 1], "r-", lw=.6)
        ax.text(Q[0, 0], Q[0, 1], f"{h:.2f}", fontsize=6)
json.dump(out, open(os.path.join(W, "tongue.json"), "w"))
print(len(out["loops"]), "loops", sorted(set(L["h"] for L in out["loops"])), "area", round(sum(L["area"] for L in out["loops"])))
ax.set_xlim(-5, 170); ax.set_ylim(-280, 120); ax.set_aspect("equal"); ax.grid(lw=.3)
fig.tight_layout(); fig.savefig(os.path.join(W, "rv", "tongue.png"), dpi=70)
