"""Where does the inward offset of the skin fold (1 - t k < 0)? Grid Jacobian sign of the offset vs the skin."""
import os, json
import numpy as np
from scipy.interpolate import BSpline
from common import W, ROOT
T = json.load(open(os.path.join(ROOT, "nx", "params.json")))["wall_t"]
s = np.load(os.path.join(W, "skin_fit.npz")); tk, CF, C = s["tk"], s["CF"], s["C"]
g = np.arange(-1.48, 1.4801, 0.003); Pg, Qg = np.meshgrid(g, g)
Sq = BSpline(tk, CF, 3); R = np.array([BSpline(tk, Sq(q), 3)(g) for q in g])
psi = np.hypot(Pg, Qg); sn = np.sinc(psi / np.pi)
X = C + R[..., None] * np.stack([Pg * sn, Qg * sn, -np.cos(psi)], -1)
Xp = np.gradient(X, axis=1); Xq = np.gradient(X, axis=0)
N = np.cross(Xp, Xq); N /= np.linalg.norm(N, axis=-1)[..., None]
sg = np.sign(((C - X) * N).sum(-1))[..., None]
for t in (T, 2.0, 1.0):
    Xi = X + t * sg * N
    Ni = np.cross(np.gradient(Xi, axis=1), np.gradient(Xi, axis=0))
    fold = ((Ni * np.cross(Xp, Xq)).sum(-1) < 0) & (psi < 1.48)
    pts = X[fold]
    print("t", t, "fold cells", int(fold.sum()), "psi range", np.round([psi[fold].min(), psi[fold].max()], 3) if fold.any() else None)
    if fold.any():
        print("  fold xyz sample", np.round(pts[::max(1, len(pts) // 12)], 1).tolist())
