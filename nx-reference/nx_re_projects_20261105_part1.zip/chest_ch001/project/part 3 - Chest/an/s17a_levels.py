"""Candidate plateau levels: histogram of interior top z over flat (slope < 0.12), raised (> 0.8) pixels;
peaks with >= MIN mm2, merged within 0.3 mm. Writes work/levels.json (review before s17)."""
import os, json, sys
import numpy as np
from common import W
MIN = float(sys.argv[1]) if len(sys.argv) > 1 else 6.0
R = np.load(os.path.join(W, "raised.npz")); st = float(R["step"]); H = R["top"].astype(float); rs = R["raise_"]
gy, gx = np.gradient(np.nan_to_num(H, nan=-300.0), st); sl = np.hypot(gx, gy)
m = (sl < 0.12) & (rs > 0.8) & np.isfinite(H)
h, e = np.histogram(H[m], bins=np.arange(-140, 4, 0.05)); a = h * st * st
lv = []
for i in np.argsort(-a):
    if a[i] < MIN: break
    z = e[i] + 0.025
    if all(abs(z - l[0]) > 0.3 for l in lv):
        lv.append((round(float(z), 2), round(float(a[max(0, i-2):i+3].sum()), 1)))
lv.sort()
print(len(lv), lv)
json.dump(dict(levels=[l[0] for l in lv], areas=[l[1] for l in lv]), open(os.path.join(W, "levels.json"), "w"))
