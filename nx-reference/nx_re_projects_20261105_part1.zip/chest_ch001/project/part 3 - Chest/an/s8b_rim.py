"""Pooled rim (parting) plane fit: faces nz > 0.95 within -0.7..0.7 (final frame)."""
import numpy as np
from common import load, tri_data, fit_plane_robust
v, f = load(); c, n, a = tri_data(v, f)
m = (n[:, 2] > 0.95) & (c[:, 2] > -0.7) & (c[:, 2] < 0.7)
ctr, nn, sd, k = fit_plane_robust(c[m], k=3.0)
if nn[2] < 0: nn = -nn
print("rim plane normal", nn.round(6), "z at origin", round(float(ctr @ nn / nn[2]), 4), "sd", round(sd, 4), "n", int(k.sum()), "of", int(m.sum()))
