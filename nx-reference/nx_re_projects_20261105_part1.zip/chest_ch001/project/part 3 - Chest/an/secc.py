"""Scan (black) vs CAD (red) sections. usage: secc.py cad.stl axis v1,v2,.. tag [lo,hi[,lo2,hi2] window]"""
import sys, os
import numpy as np
import open3d as o3d
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import W, load, section
cad = sys.argv[1]; ax = "xyz".index(sys.argv[2]); vals = [float(t) for t in sys.argv[3].split(",")]; tag = sys.argv[4]
win = [float(t) for t in sys.argv[5].split(",")] if len(sys.argv) > 5 else None
v, f = load()
cm = o3d.io.read_triangle_mesh(cad); cv = np.asarray(cm.vertices); cf = np.asarray(cm.triangles)
pa = {0: (1, 2), 1: (0, 2), 2: (0, 1)}[ax]
fig, axs = plt.subplots(len(vals), 1, figsize=(24, 7 * len(vals)), squeeze=False)
for a_, val in zip(axs[:, 0], vals):
    for vv, ff, col, lw in ((v, f, "k", 0.5), (cv, cf, "r", 0.7)):
        seg = section(vv, ff, ax, val)[:, :, list(pa)]
        if win:
            k = (seg[:, :, 0] >= win[0]).all(1) & (seg[:, :, 0] <= win[1]).all(1)
            if len(win) > 2:
                k &= (seg[:, :, 1] >= win[2]).all(1) & (seg[:, :, 1] <= win[3]).all(1)
            seg = seg[k]
        a_.add_collection(LineCollection(seg, lw=lw, color=col))
    a_.autoscale(); a_.set_aspect("equal")
    a_.minorticks_on(); a_.grid(True, which="major", lw=0.4); a_.grid(True, which="minor", lw=0.15, alpha=0.5)
    a_.set_title(f"{'xyz'[ax]} = {val}  ({'xyz'[pa[0]]} right, {'xyz'[pa[1]]} up)  black scan, red CAD")
fig.tight_layout(); fig.savefig(os.path.join(W, "rv", f"secc_{tag}.png"), dpi=70); plt.close(fig)
print("ok")
