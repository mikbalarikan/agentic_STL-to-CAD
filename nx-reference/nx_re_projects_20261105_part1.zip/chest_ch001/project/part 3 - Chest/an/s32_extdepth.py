"""Exterior recess depth map: for each height-map cell of the exterior (seen from -Z, hmap bot) the depth of the
scanned exterior below the fitted skin, measured along the skin's radial ray (+ = recessed into the part).
Writes work/emap.npz (e) + work/rv/emap.png."""
import os
import numpy as np
from scipy.interpolate import BSpline
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
H = np.load(os.path.join(W, "hmap.npz"))
st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"]); bot = H["bot"]
ny, nx = bot.shape
XX, YY = np.meshgrid(x0 + np.arange(nx) * st, y0 + np.arange(ny) * st)
ok = ~np.isnan(bot)
Pt = np.c_[XX[ok], YY[ok], bot[ok]]
s = np.load(os.path.join(W, "skin_fit.npz")); tk, CF, C = s["tk"], s["CF"], s["C"]
u = Pt - C; rr = np.linalg.norm(u, axis=1); u /= rr[:, None]
psi = np.arccos(np.clip(-u[:, 2], -1, 1)); sn = np.maximum(np.sin(psi), 1e-9)
pp, qq = psi * u[:, 0] / sn, psi * u[:, 1] / sn
rs = np.full(len(Pt), np.nan); Sq = BSpline(tk, CF, 3)
qb = np.round(qq / 0.001) * 0.001
okk = np.hypot(pp, qq) < tk[-4]
for qv in np.unique(qb[okk]):
    k = okk & (qb == qv)
    rs[k] = BSpline(tk, Sq(np.clip(qv, tk[3], tk[-4])), 3)(np.clip(pp[k], tk[3], tk[-4]))
e = np.full(bot.shape, np.nan, np.float32); e[ok] = rs - rr
np.savez_compressed(os.path.join(W, "emap.npz"), e=e, x0=x0, y0=y0, step=st)
fig, ax = plt.subplots(figsize=(18, 21))
im = ax.imshow(e, origin="lower", extent=[x0, x0 + nx * st, y0, y0 + ny * st], cmap="nipy_spectral", vmin=-0.5, vmax=6)
plt.colorbar(im, shrink=.5); ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.tick_params(labelsize=6); ax.grid(lw=.3)
fig.tight_layout(); fig.savefig(os.path.join(W, "rv", "emap.png"), dpi=60)
print(np.nanpercentile(e, [1, 5, 50, 95, 99]))
