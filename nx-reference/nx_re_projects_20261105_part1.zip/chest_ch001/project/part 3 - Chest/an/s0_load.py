"""Load the chest STL once, weld vertices (1e-3 mm), connected components, cache npz; print a description.
Writes work/scan.npz (v float32, f int32, comp int32 per face), work/s0_describe.json."""
import os, time, json
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from common import ROOT, W

SRC = os.path.join(ROOT, "share-Chest.stl")
os.makedirs(W, exist_ok=True)
t = time.time()
with open(SRC, "rb") as f:
    f.read(80)
    n = int(np.frombuffer(f.read(4), np.uint32)[0])
    dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
    rec = np.fromfile(f, dt, n)
print("triangles", n, "read", round(time.time() - t, 1), "s", flush=True)
V = rec["v"].reshape(-1, 3)
del rec
lo = V.min(0).astype(np.float64)
q = np.round((V - lo) / 1e-3).astype(np.int64)
key = (q[:, 0] << 40) | (q[:, 1] << 20) | q[:, 2]
del q
uk, first, inv = np.unique(key, return_index=True, return_inverse=True)
verts = V[first]
faces = inv.reshape(-1, 3).astype(np.int32)
del key, inv, V
print("verts", len(verts), "weld", round(time.time() - t, 1), "s", flush=True)
deg = (faces[:, 0] == faces[:, 1]) | (faces[:, 1] == faces[:, 2]) | (faces[:, 0] == faces[:, 2])
faces = faces[~deg]
nv = len(verts)
r = np.concatenate([faces[:, 0], faces[:, 1]]); c = np.concatenate([faces[:, 1], faces[:, 2]])
g = coo_matrix((np.ones(len(r), np.int8), (r, c)), shape=(nv, nv))
ncomp, lab = connected_components(g, directed=False)
fcomp = lab[faces[:, 0]]
cnt = np.bincount(fcomp)
order = np.argsort(-cnt)
remap = np.empty_like(order); remap[order] = np.arange(len(order))
fcomp = remap[fcomp].astype(np.int32)
print("components", ncomp, "weld+cc", round(time.time() - t, 1), "s", flush=True)
np.savez(os.path.join(W, "scan.npz"), v=verts.astype(np.float32), f=faces, comp=fcomp)
tri = verts[faces].astype(np.float64)
cr = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
area = 0.5 * np.linalg.norm(cr, axis=1)
vol6 = np.einsum("ij,ij->i", tri[:, 0], np.cross(tri[:, 1], tri[:, 2]))
comps = []
for k in range(min(ncomp, 40)):
    m = fcomp == k
    p = tri[m].reshape(-1, 3)
    comps.append(dict(id=k, faces=int(m.sum()), area=round(float(area[m].sum()), 1), vol=round(float(vol6[m].sum() / 6), 1),
                      lo=np.round(p.min(0), 2).tolist(), hi=np.round(p.max(0), 2).tolist()))
ed = np.sort(np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]]), axis=1).astype(np.int64)
k2 = ed[:, 0] * (nv + 1) + ed[:, 1]
_, ec = np.unique(k2, return_counts=True)
edge = np.linalg.norm(tri[:, 1] - tri[:, 0], axis=1)
d = dict(triangles=n, verts=nv, degenerate_removed=int(deg.sum()), bbox_lo=verts.min(0).tolist(), bbox_hi=verts.max(0).tolist(),
         area=float(area.sum()), volume=float(vol6.sum() / 6), edge_median=float(np.median(edge)),
         edge_p95=float(np.percentile(edge, 95)), open_edges=int((ec == 1).sum()), nonmanifold_edges=int((ec > 2).sum()),
         n_components=int(ncomp), components_top=comps)
print(json.dumps(d, indent=1))
json.dump(d, open(os.path.join(W, "s0_describe.json"), "w"), indent=1)
