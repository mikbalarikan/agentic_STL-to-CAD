"""Profiles of a relief map (r1_relief npz): d along u at fixed v, and along v at fixed u.
usage: r1_prof.py rel.npz out.png v:10,-25,30 u:-15,5,22,40"""
import sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
z = np.load(sys.argv[1]); uu, vv, d = z["uu"], z["vv"], z["d"]
specs = sys.argv[3:]
rows = sum(len(s.split(":")[1].split(",")) for s in specs)
fig, axs = plt.subplots(rows, 1, figsize=(16, 2.6 * rows), squeeze=False)
k = 0
for s in specs:
    ax_, vals = s.split(":")
    for val in map(float, vals.split(",")):
        a, b = (uu, vv) if ax_ == "v" else (vv, uu)
        m = np.abs(b - val) < 0.4
        p = axs[k][0]; p.scatter(a[m], d[m], s=0.5)
        p.set_ylim(-1.5, 4); p.grid(lw=0.3); p.set_xticks(np.arange(np.floor(a[m].min() / 5) * 5, a[m].max() + 5, 5) if m.any() else [])
        p.set_title(f"{ax_} = {val}: d vs {'u' if ax_ == 'v' else 'v'}", fontsize=9); k += 1
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=65); print("ok")
