"""outC10 smooth exterior tools (review F08 / F27: no terraces on exterior faces), replacing the multi-level stepped
recesses (work/recess.json) and bumps (work/bumps.json) by ONE tool per region:
  pocket (subtract): Z prism over the region, the part above the sheet F removed (F = scan exterior height map in the
          pocket, 0.6 mm outside the skin beyond the mouth) -> the tool is the wall material between skin and pocket;
  bump (unite):      Z prism between F_out (scan exterior where it stands proud of the skin, 0.6 mm inside the skin
          beyond the bump) and F_in (1.4 mm inside the skin) -> fuses with the wall.
Sheets are lofts through constant-x sections whose POLES are the smoothed samples (B-spline poles: no overshoot).
Scan exterior: work/hmap.npz 'bot' (first hit from -Z); CAD skin: Rev A build nx/outB12 (no recesses), cached in
work/c10/botB12.npy by c10_pockets.py.  Writes work/c10/sheets.json + work/c10/pockets/sheet_<name>.png."""
import os, sys, json
import numpy as np
from scipy import ndimage
from scipy.interpolate import RegularGridInterpolator
import contourpy
from skimage.measure import approximate_polygon
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.path import Path
from common import W
from arcfit import seg_points

SP = float(os.environ.get("C10_SP", "1.0"))        # pole spacing, mm
SIG = 0.7                                            # smoothing of the height data, mm
OFF = 0.6                                            # clearance of the sheet from the CAD skin outside the region
DIL = 2.5                                            # region = mouth dilated by DIL (prism outline)
H = np.load(os.path.join(W, "hmap.npz"))
x0, y0, st = float(H["x0"]), float(H["y0"]), float(H["step"])
bot = H["bot"].astype(np.float64)
botB = np.load(os.path.join(W, "c10", "botB12.npy")).astype(np.float64)
ny, nx = bot.shape
xs = x0 + np.arange(nx) * st; ys = y0 + np.arange(ny) * st
X, Y = np.meshgrid(xs, ys)


def mirror(a):
    """a(-x, y) on the same grid (linear interpolation along x)."""
    out = np.full_like(a, np.nan)
    for i in range(ny):
        r = a[i]; ok = ~np.isnan(r)
        if ok.sum() > 2:
            out[i] = np.interp(-xs, xs[ok], r[ok], left=np.nan, right=np.nan)
    return out


def inpaint(a, mask_bad, sig_px=8):
    a = a.copy(); a[mask_bad] = np.nan
    for _ in range(30):
        nanm = np.isnan(a)
        if not nanm.any():
            break
        w = ndimage.gaussian_filter((~nanm).astype(float), sig_px)
        s = ndimage.gaussian_filter(np.where(nanm, 0.0, a), sig_px)
        fill = np.where(w > 1e-3, s / np.maximum(w, 1e-9), np.nan)
        a = np.where(nanm, fill, a)
    return a


def fill_nearest(a):
    """NaN cells (beyond the part edge, holes) take the value of the nearest valid cell: no cliffs in the sheet."""
    m = np.isnan(a)
    if not m.any():
        return a
    idx = ndimage.distance_transform_edt(m, return_distances=False, return_indices=True)
    return a[tuple(idx)]


def loop_pts(L):
    return np.vstack([seg_points([g[0], np.array(g[1]), np.array(g[2])] + ([np.array(g[3]), g[4], g[5]] if g[0] == "A" else [])) for g in L["segs"]])


def loops_in(jsonfile, box):
    D = json.load(open(os.path.join(W, jsonfile)))
    out = []
    for L in D["loops"]:
        if L["k"] != 0:
            continue
        Q = loop_pts(L)
        if box[0] <= Q[:, 0].min() + 0.5 and Q[:, 0].max() <= box[1] and box[2] <= Q[:, 1].min() and Q[:, 1].max() <= box[3]:
            out.append(Q)
    return out


def smoothstep(a, b, v):
    t = np.clip((v - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


REGIONS = [   # name, kind, source json, plan box of the level-0 loops (right half), side
    ("lower_vent", "pocket", "recess.json", (-3, 50, -230, -195), "C"),
    ("upper_vent", "pocket", "recess.json", (-3, 65, -50, -9), "C"),
    ("side_scoop", "pocket", "recess.json", (98, 132, -133, -45), "R"),
    ("shoulder_vent", "pocket", "recess.json", (70, 132, 54, 86), "R"),
    ("neck_chamfer", "pocket", "recess.json", (26, 63, 42, 117), "R"),
    ("scoop_bump", "bump", "bumps.json", (106, 135, -130, -44), "R"),
    ("shoulder_bump", "bump", "bumps.json", (87, 151, 51, 92), "R"),
    ("neck_bump", "bump", "bumps.json", (34, 54, 26, 68), "R"),
]
ONLY = sys.argv[1].split(",") if len(sys.argv) > 1 else None

# see-through cells (through slots: the ray hits something far behind) and holes -> inpainted from the neighbours
med = ndimage.median_filter(np.nan_to_num(bot, nan=1e3), size=21)
odd = np.isnan(bot) | (np.abs(bot - med) > 1.5)
# only small blobs (slots, holes, see-through spots); long bands at steep pocket walls are real data
lab_, n_ = ndimage.label(odd)
sz_ = ndimage.sum(odd, lab_, range(1, n_ + 1)) * st * st
bad = np.isin(lab_, 1 + np.where(sz_ < 60.0)[0])
bad = ndimage.binary_dilation(bad, iterations=3)
# lower vent: the 15 slots sit on the sloped upper wall of the box; there the scan rays see through to the board
# behind -> replace the band by a per-column linear ramp between its edge rows (the wall is a plane in x)
BANDS = [(-41.0, 41.0, -208.75, -197.5)]
bot_b = bot.copy()
for bx0_, bx1_, by0_, by1_ in BANDS:
    i0 = int(np.floor((by0_ - y0) / st)); i1 = int(np.ceil((by1_ - y0) / st))
    j0 = int(np.floor((bx0_ - x0) / st)); j1 = int(np.ceil((bx1_ - x0) / st))
    # the wall between the slots is valid: per row, cells off the row median (slots, see-through) are interpolated
    # along x from the wall strips between the slots
    for i in range(i0, i1):
        r = bot[i, j0:j1]; mr = np.nanmedian(r)
        ok = ~np.isnan(r) & (np.abs(r - mr) < 1.5)
        ok = ok & ~ndimage.binary_dilation(~ok, iterations=2)
        if ok.sum() > 10:
            bot_b[i, j0:j1] = np.interp(np.arange(j1 - j0), np.where(ok)[0], r[ok])
    bad[i0:i1, j0:j1] = False
bot_f = inpaint(bot_b, bad, sig_px=4)
nb_ = np.isnan(botB); lb_, nlb = ndimage.label(nb_)
szb = ndimage.sum(nb_, lb_, range(1, nlb + 1)) * st * st
botB = inpaint(botB, np.isin(lb_, 1 + np.where(szb < 200.0)[0]), sig_px=4)     # CAD holes / slots filled
botm = mirror(bot_f); botBm = mirror(botB)
out = {"note": __doc__.split("\n")[0], "sp": SP, "sig": SIG, "off": OFF, "tools": []}
_mesh = {}


def meshes():
    """scan main shell (part frame) and the Rev A CAD (skin without recesses) as float32 arrays (cached)."""
    if not _mesh:
        from common import load
        v, f = load()

        def rd(pth):
            with open(pth, "rb") as fh:
                fh.read(80); n = int(np.frombuffer(fh.read(4), np.uint32)[0])
                dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
                return np.fromfile(fh, dt, n)["v"]
        T = rd(os.path.join(os.path.dirname(W), "nx", "outB12", "chest_G.stl")).reshape(-1, 3)
        _mesh["scan"] = (v.astype(np.float32), f.astype(np.int32))
        _mesh["cad"] = (T.astype(np.float32), np.arange(len(T), dtype=np.int32).reshape(-1, 3))
    return _mesh


def cast(which, box, O, D_):
    """first-hit distance along D_ from the ray origins O (n x 3) on the mesh cropped to box (x0, x1, y0, y1)."""
    import open3d as o3d
    v, f = meshes()[which]
    keep = (v[:, 0] > box[0]) & (v[:, 0] < box[1]) & (v[:, 1] > box[2]) & (v[:, 1] < box[3])
    fk = f[keep[f].all(1)]
    m = o3d.t.geometry.TriangleMesh()
    m.vertex.positions = o3d.core.Tensor(v); m.triangle.indices = o3d.core.Tensor(fk)
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(m)
    rays = np.c_[O, np.tile(D_, (len(O), 1))].astype(np.float32)
    return sc.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()


def fill_small_nan(a, amax, sig_px=4, extra=None):
    nb = np.isnan(a) if extra is None else (np.isnan(a) | extra)
    lb, n = ndimage.label(nb)
    sz = ndimage.sum(nb, lb, range(1, n + 1)) * st * st
    return inpaint(a, np.isin(lb, 1 + np.where(sz < amax)[0]), sig_px=sig_px)


for name, kind, src, box, side in REGIONS:
    if ONLY and name not in ONLY:
        continue
    Qs = loops_in(src, box)
    if not Qs:
        print(name, "no loops"); continue
    pts = np.c_[X.ravel(), Y.ravel()]
    mouthZ = np.zeros(X.shape, bool)
    for Q in Qs:
        mouthZ |= Path(Q).contains_points(pts).reshape(X.shape)
    zframe = side == "C" or name in os.environ.get("C10_ZFRAME", "side_scoop,neck_bump").split(",")
    if zframe:
        # the Z height maps; frame = part frame (C: symmetric mean of both halves)
        c_, eu, ev, dd = np.zeros(3), np.array([1.0, 0, 0]), np.array([0, 1.0, 0]), np.array([0, 0, 1.0])
        us, vs = xs, ys
        if side == "C":
            mouth = mouthZ | (mirror(mouthZ.astype(float)) > 0.5)
            b = np.where(np.isnan(botm), bot_f, 0.5 * (bot_f + botm)); bB = np.where(np.isnan(botBm), botB, 0.5 * (botB + botBm))
        else:
            mouth = mouthZ; b = bot_f.copy(); bB = botB.copy()
    else:
        # side / shoulder / neck regions: local frame along the mean inward skin normal (Z prisms meet the steep
        # sheet nearly tangentially: NX trim "intersection gap", outT10 / outT10b)
        gy_, gx_ = np.gradient(fill_nearest(botB), st)
        nrm = np.c_[-gx_[mouthZ], -gy_[mouthZ], np.ones(mouthZ.sum())]
        nrm /= np.linalg.norm(nrm, axis=1)[:, None]
        dd = nrm.mean(0); dd /= np.linalg.norm(dd)
        eu = np.cross([0, 1.0, 0], dd); eu /= np.linalg.norm(eu); ev = np.cross(dd, eu)
        P0 = np.c_[X[mouthZ], Y[mouthZ], botB[mouthZ]]; P0 = P0[~np.isnan(P0[:, 2])]
        c_ = P0.mean(0)
        uu = (P0 - c_) @ eu; vv = (P0 - c_) @ ev
        mg = DIL + 7.0
        us = np.arange(uu.min() - mg, uu.max() + mg, st); vs = np.arange(vv.min() - mg, vv.max() + mg, st)
        UU, VV = np.meshgrid(us, vs)
        Gp = c_ + UU.ravel()[:, None] * eu + VV.ravel()[:, None] * ev
        O = Gp - 120.0 * dd
        bxx = (Gp[:, 0].min() - 60, Gp[:, 0].max() + 60, Gp[:, 1].min() - 60, Gp[:, 1].max() + 60)
        ts_ = cast("scan", bxx, O, dd); tc_ = cast("cad", bxx, O, dd)
        b = np.where(np.isfinite(ts_), ts_ - 120.0, np.nan).reshape(UU.shape)
        bB = np.where(np.isfinite(tc_), tc_ - 120.0, np.nan).reshape(UU.shape)
        # beyond the rim the rays enter the open back and hit the inside: not skin
        zB = (Gp + np.nan_to_num(bB.ravel(), nan=0.0)[:, None] * dd)[:, 2].reshape(UU.shape)
        bB[zB > -0.3] = np.nan
        Hp = Gp + np.nan_to_num(b.ravel(), nan=0.0)[:, None] * dd
        mouth = np.zeros(UU.shape, bool)
        for Q in Qs:
            mouth |= (Path(Q).contains_points(Hp[:, :2]).reshape(UU.shape) & ~np.isnan(b))
        # slots / see-through / holes -> inpainted (same rule as the Z map)
        md_ = ndimage.median_filter(np.nan_to_num(b, nan=1e3), size=21)
        od_ = np.isnan(b) | (np.abs(b - md_) > 1.5)
        lb2, nb2_ = ndimage.label(od_)
        sz2 = ndimage.sum(od_, lb2, range(1, nb2_ + 1)) * st * st
        bd2 = ndimage.binary_dilation(np.isin(lb2, 1 + np.where(sz2 < 60.0)[0]), iterations=3)
        b = inpaint(b, bd2, sig_px=4)
        bB = fill_small_nan(bB, 200.0)
    on_part = ndimage.binary_dilation(~np.isnan(bB), iterations=4)      # CAD skin exists (+1 mm)
    bB = fill_nearest(bB)
    bs = ndimage.gaussian_filter(fill_nearest(b), SIG / st)
    dzs = bs - bB
    reg = ndimage.binary_dilation(mouth, iterations=int(round(DIL / st))) & on_part   # never past the part edge
    inner = ndimage.binary_dilation(mouth, iterations=int(round(0.75 / st)))
    if kind == "pocket":
        w = 1.0 - smoothstep(0.2, 0.8, dzs)                    # 1 = not recessed -> push the sheet OFF outward
        w = np.where(inner, w, 1.0)
        F = bs - OFF * w
        F = np.where(w > 0.999, np.minimum(F, bB - OFF), F)
        F = ndimage.gaussian_filter(fill_nearest(F), 0.5 / st)
        sheets = {"hi": F}
    else:
        w = 1.0 - smoothstep(0.2, 0.8, -dzs)                   # 1 = not proud -> push the sheet OFF inward
        w = np.where(inner, w, 1.0)
        F = bs + OFF * w
        F = np.where(w > 0.999, bB + OFF, F)     # not proud (incl. pockets inside the region): just inside the skin
        F = ndimage.gaussian_filter(fill_nearest(F), 0.5 / st)
        # inner sheet >= 1 mm inside the outer one AFTER smoothing (crossing sheets gave an invalid tool, outT10i)
        Fin = np.maximum(ndimage.gaussian_filter(fill_nearest(bB + 1.4), 1.0 / st), F + 1.0)
        sheets = {"lo": F, "hi": Fin}
    # prism outline = contour of the dilated region (in the frame's u, v)
    G = np.pad(ndimage.gaussian_filter(reg.astype(float), 1.0), 2)
    lines = [c for c in contourpy.contour_generator(z=G, line_type="Separate").lines(0.5) if np.linalg.norm(c[0] - c[-1]) < 1e-6]
    C = max(lines, key=len)
    outline = approximate_polygon(np.c_[us[0] + (C[:, 0] - 2) * st, vs[0] + (C[:, 1] - 2) * st], 0.25)[:-1]
    bx0, by0 = outline.min(0); bx1, by1 = outline.max(0)
    GM = float(os.environ.get("C10_GM", "2.0"))
    gx = np.arange(np.floor(bx0) - GM, bx1 + GM + 1e-9, SP); gy = np.arange(np.floor(by0) - GM, by1 + GM + 1e-9, SP)
    if side == "C":
        hx = max(abs(gx[0]), abs(gx[-1])); gx = np.arange(-np.ceil(hx / SP) * SP, np.ceil(hx / SP) * SP + 1e-9, SP)
    UG, VG = np.meshgrid(us, vs)
    inside = Path(outline).contains_points(np.c_[UG.ravel(), VG.ravel()]).reshape(UG.shape)
    # pole grids first: the prism must span EVERY pole of every sheet (outT10d-f: a sheet dipping below the prism
    # floor just outside the outline gave "complete intersection" / "intersection gap" trim failures)
    ZG = {}
    for key, Fk in sheets.items():
        fi = RegularGridInterpolator((vs, us), fill_nearest(Fk), bounds_error=False, fill_value=None)
        GX, GY = np.meshgrid(gx, gy, indexing="ij")
        Z = fi(np.c_[GY.ravel(), GX.ravel()]).reshape(GX.shape)
        if side == "C":
            Z = 0.5 * (Z + Z[::-1])
        ZG[key] = Z
    zm_ = float(os.environ.get("C10_ZM", "2.0"))
    zlo = min(np.nanmin(np.where(inside, np.minimum(bB, bs), np.nan)), min(Z.min() for Z in ZG.values())) - zm_
    zhi = max(np.nanmax(np.where(inside, sheets["hi"], np.nan)), max(Z.max() for Z in ZG.values())) + zm_

    def to3(u_, v_, h_):
        return c_ + u_ * eu + v_ * ev + h_ * dd
    rec = dict(name=name, kind=kind, op="subtract" if kind == "pocket" else "unite",
               outline3=[to3(p_[0], p_[1], zlo).round(7).tolist() for p_ in outline], dir=dd.tolist(),
               len=round(float(zhi - zlo), 3), sheets={})
    cell = st * st
    for key, Fk in sheets.items():
        Z = ZG[key]
        rec["sheets"][key] = [[to3(gx[i], gy[j], Z[i, j]).round(3).tolist() for j in range(len(gy))] for i in range(len(gx))]
        zc = np.clip(np.where(inside, Fk, np.nan), zlo, zhi)
        rec[f"v_below_{key}"] = round(float(np.nansum(zc - zlo) * cell), 1)
        rec[f"v_above_{key}"] = round(float(np.nansum(zhi - zc) * cell), 1)
    rec["n_sections"] = len(gx); rec["n_poles"] = len(gy)
    out["tools"].append(rec)
    if side == "R":                  # explicit mirror image (the build makes exactly what is listed)
        m = json.loads(json.dumps(rec)); m["name"] = name + "_L"
        m["outline3"] = [[-p[0], p[1], p[2]] for p in rec["outline3"]][::-1]
        m["dir"] = [-rec["dir"][0], rec["dir"][1], rec["dir"][2]]
        for key in m["sheets"]:
            m["sheets"][key] = [[[-p[0], p[1], p[2]] for p in sec] for sec in rec["sheets"][key][::-1]]
        out["tools"].append(m)
    # evidence plot (frame coordinates u, v, h)
    r_, c2_ = np.where(reg)
    sl = (slice(max(r_.min() - 20, 0), r_.max() + 20), slice(max(c2_.min() - 20, 0), c2_.max() + 20))
    fig, axs = plt.subplots(1, 3, figsize=(24, 7))
    ext = [us[sl[1]][0], us[sl[1]][-1], vs[sl[0]][0], vs[sl[0]][-1]]
    axs[0].imshow((sheets.get("hi") if kind == "pocket" else sheets["lo"])[sl] - bB[sl], origin="lower", extent=ext, cmap="turbo"); axs[0].plot(outline[:, 0], outline[:, 1], "w-")
    axs[0].set_title(f"{name}: sheet - CAD skin (h along {np.round(dd, 2)})")
    rm = int(np.median(r_)); cm_ = int(np.median(c2_))
    for ax_, prof, along, lab in ((axs[1], (rm, sl[1]), us[sl[1]], f"v={vs[rm]:.1f}"), (axs[2], (sl[0], cm_), vs[sl[0]], f"u={us[cm_]:.1f}")):
        ax_.plot(along, b[prof], "k-", lw=0.8, label="scan (filled)")
        ax_.plot(along, bB[prof], "r-", lw=0.8, label="CAD skin")
        for key, Fk in sheets.items():
            ax_.plot(along, Fk[prof], "--", lw=1.0, label="sheet " + key)
        ax_.set_aspect("equal"); ax_.legend(); ax_.set_title(lab); ax_.grid(lw=0.3)
    fig.tight_layout(); fig.savefig(os.path.join(W, "c10", "pockets", f"sheet_{name}.png"), dpi=60); plt.close(fig)
    print(f"{name}: {kind} side {side}, dir {np.round(dd, 3)}, outline {len(outline)} pts, sections {len(gx)} x {len(gy)} poles, h {zlo:.1f}..{zhi:.1f}", flush=True)
json.dump(out, open(os.path.join(W, "c10", "sheets.json" if not ONLY else "sheets_test.json"), "w"))
