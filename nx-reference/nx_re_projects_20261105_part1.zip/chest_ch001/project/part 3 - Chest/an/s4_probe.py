"""Probe candidate datum faces in the raw frame. usage: s4_probe.py  (prints robust plane fits)."""
import os
import numpy as np
from common import W, fit_plane_robust

c = np.load(os.path.join(W, "tri_c.npy")).astype(np.float64)
n = np.load(os.path.join(W, "tri_n.npy")).astype(np.float64)
a = np.load(os.path.join(W, "tri_a.npy")).astype(np.float64)


def probe(name, m):
    p = c[m]
    if len(p) < 50:
        print(name, "too few", len(p)); return
    ctr, nn, sd, k = fit_plane_robust(p)
    if nn @ n[m].mean(0) < 0: nn = -nn
    pk = p[k]
    print(f"{name}: n={len(p)} in={k.sum()} area={a[m][k].sum():.0f} normal={np.round(nn,5)} off={ctr@nn:.3f} sd={sd:.4f} "
          f"lo={np.round(pk.min(0),1)} hi={np.round(pk.max(0),1)}")
    return ctr, nn


z = c[:, 2]
probe("rim (nz>0.9, z>70)", (n[:, 2] > 0.9) & (z > 70))
probe("rim (nz>0.9, z>55)", (n[:, 2] > 0.9) & (z > 55))
for s in (1, -1):
    probe(f"side ring x{'+' if s>0 else '-'} (|nx|>0.95, sx>150)", (n[:, 0] * s > 0.95) & (c[:, 0] * s > 150))
probe("bottom pad z+ (-14..-12.5)", (n[:, 2] > 0.95) & (z > -14) & (z < -12.6))
probe("y+ faces y in -183..-181", (n[:, 1] > 0.95) & (c[:, 1] > -183) & (c[:, 1] < -181))
h, e = np.histogram(z[n[:, 2] > 0.9], bins=np.arange(-70, 85, 1.0), weights=a[n[:, 2] > 0.9])
print("z hist nz>0.9:", [(int(e[i]), int(h[i])) for i in range(len(h)) if h[i] > 40])
