"""Relief (white top-hat) of the scan ZI map: height of narrow raised features (ribs, bosses, pins) above the
local wall, footprint 12 mm. Writes work/clean/relief.npz and colour tiles with a 5 mm grid + Rev A plateaus.
usage: clean_relief.py maps.npz [tiles...]  tile = name:x0:x1:y0:y1"""
import sys, os, json
import numpy as np
from scipy import ndimage as ndi
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "work", "clean")
d = np.load(sys.argv[1]); xs, ys = d["xs"], d["ys"]
rp = os.path.join(OUT, "relief.npz")
if os.path.exists(rp):
    R = np.load(rp)["relief"]; Z = np.load(rp)["z"]
else:
    Z = d["scan_ZI"].astype(float); m = np.isfinite(Z)
    Zf = np.where(m, Z, -200.0)
    op = ndi.grey_opening(Zf, size=(49, 49))
    R = np.where(m, Zf - op, np.nan)
    np.savez_compressed(rp, relief=R.astype(np.float32), z=Z.astype(np.float32), xs=xs, ys=ys)
PL = json.load(open(os.path.join(ROOT, "work", "plateaus.json")))["loops"]
for t in sys.argv[2:]:
    name, x0, x1, y0, y1 = t.split(":"); x0, x1, y0, y1 = map(float, (x0, x1, y0, y1))
    ix = (xs >= x0) & (xs <= x1); iy = (ys >= y0) & (ys <= y1)
    fig, ax = plt.subplots(figsize=((x1 - x0) / 7 + 1.5, (y1 - y0) / 7 + 1), dpi=100)
    im = ax.imshow(np.clip(R[np.ix_(iy, ix)], 0, 12), cmap="turbo", origin="lower", extent=(x0, x1, y0, y1), vmin=0, vmax=12)
    fig.colorbar(im, ax=ax, fraction=0.03, label="height above local wall (mm)")
    ax.contour(xs[ix], ys[iy], np.nan_to_num(Z[np.ix_(iy, ix)], nan=-200), levels=np.arange(-150, 5, 2.0), colors="w", linewidths=0.25, alpha=0.5)
    for L in PL:
        for sx in ((1, -1) if L["kind"] == "R" else (1,)):
            p = np.array([s[1] for s in L["segs"]] + [L["segs"][0][1]]); p[:, 0] *= sx
            if p[:, 0].max() < x0 or p[:, 0].min() > x1 or p[:, 1].max() < y0 or p[:, 1].min() > y1:
                continue
            ax.plot(p[:, 0], p[:, 1], "w-", lw=0.5)
            if L["area"] > 0:
                ax.text(p[:, 0].mean(), p[:, 1].mean(), f"{L['h']:.1f}", color="w", fontsize=6)
    ax.set_xlim(x0, x1); ax.set_ylim(y0, y1)
    ax.set_xticks(np.arange(np.ceil(x0 / 5) * 5, x1 + 0.1, 5)); ax.set_yticks(np.arange(np.ceil(y0 / 5) * 5, y1 + 0.1, 5))
    ax.grid(True, color="k", lw=0.3, alpha=0.5); ax.tick_params(labelsize=6)
    ax.set_title(f"{name}: scan relief (white top-hat 12 mm); white lines: 2 mm z contours + Rev A plateaus", fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "scanmaps", f"R_{name}.png")); plt.close(fig)
print("ok")
