"""README: add the interior-steps item (lead decision A, 2026-10-30) with the counts of review_2026-10-30/<data>/thin.json
and renumber the following items.  usage: readme_steps.py data_<tag>"""
import os, re, sys, json
from common import ROOT
t = json.load(open(os.path.join(ROOT, "review_2026-10-30", sys.argv[1], "thin.json")))["thin"]
b = [q for q in t if q["area"] >= 20 and q.get("t_scan_med", 0) >= 1.2]; s = [q for q in t if 5 < q["area"] < 20 and q.get("t_scan_med", 0) >= 1.2]
A20, A5 = sum(q["area"] for q in b), sum(q["area"] for q in s)
P = os.path.join(ROOT, "deliver", "README.md"); txt = open(P, encoding="utf-8").read()
txt = re.sub(r"\n8\. \*\*Interior steps\.\*\*.*?(?=\n9\. \*\*Threads)", "", txt, flags=re.S)       # idempotent
if "9. **Threads.**" in txt:          # already renumbered once
    pass
else:
    for k in range(13, 7, -1):
        txt = txt.replace(f"\n{k}. **", f"\n{k + 1}. **")
item = (f"8. **Interior steps.** Where the print's wall thickness changes gradually, the inside of the CAD changes in 0.7 mm\n"
        f"   steps (item 1). The step edges are sharp, thin ridges up to 0.7 mm tall: {len(b)} areas of 20 mm² or more\n"
        f"   ({A20:.0f} mm² in total, under 2 % of the surface) and {len(s)} smaller ones ({A5:.0f} mm²), all on interior faces, none on\n"
        f"   the rim (mating) face or the outside. Sections of the ten largest: `Deviation Report/thin_steps_top10_a.png`, `thin_steps_top10_b.png`.\n")
i = txt.index("9. **Threads.**")
txt = txt[:i] + item + txt[i:]
open(P, "w", encoding="utf-8").write(txt)
print("README steps item:", len(b), round(A20), len(s), round(A5))
