"""Neck belt: along the right neck inner edge (NX dump) compare the planned belt top (edge z + H) with the scan's
belt top (highest scan point within 3.5 mm of the edge in plan, material side). Prints per x and plots z vs x.
usage: r1_belt.py neck_edge.json out.png [H=5.5]"""
import sys, json
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from common import load

d = json.load(open(sys.argv[1])); H = float(sys.argv[3]) if len(sys.argv) > 3 else 5.5
E = np.array(d["main"])
v, f = load()
m = (v[:, 0] > -5) & (v[:, 0] < 70) & (v[:, 1] > 30) & (v[:, 1] < 118) & (v[:, 2] < 3) & (v[:, 2] > -100)
V = v[m]
tree = cKDTree(V[:, :2])
zs = []
for p in E:
    idx = tree.query_ball_point(p[:2], 3.5)
    q = V[idx]
    q = q[np.abs(q[:, 2] - p[2]) < 14]
    zs.append(q[:, 2].max() if len(q) else np.nan)
zs = np.array(zs)
zb = E[:, 2] + H
fig, ax = plt.subplots(figsize=(14, 6))
ax.plot(E[:, 0], E[:, 2], "k-", label="CAD neck inner edge z")
ax.plot(E[:, 0], zb, "b-", label=f"belt top = edge + {H}")
ax.plot(E[:, 0], zs, "r.", ms=2, label="scan top near the edge")
ax.grid(lw=0.3); ax.legend(); ax.set_xlabel("x"); ax.set_ylabel("z"); ax.set_xticks(np.arange(0, 60, 2))
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=70)
for x0 in range(0, 58, 2):
    k = np.argmin(np.abs(E[:, 0] - x0) + (E[:, 1] > 75) * 100 * (x0 < 45))
    print(f"x {E[k,0]:5.1f} y {E[k,1]:6.1f}: edge {E[k,2]:7.2f}  belt {zb[k]:7.2f}  scan {zs[k]:7.2f}  scan-belt {zs[k]-zb[k]:6.2f}")
