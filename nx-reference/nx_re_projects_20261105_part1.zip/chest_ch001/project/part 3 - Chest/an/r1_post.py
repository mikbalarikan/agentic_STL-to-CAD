"""Bottom corner post on the scan: horizontal sections every 4 mm, circle fits of the free side of the post (free
centre, and radius about the CAD bore centre (59.3, -265.8)). usage: r1_post.py [side=R]"""
import sys
import numpy as np
from common import load, section, fit_circle_robust

side = sys.argv[1] if len(sys.argv) > 1 else "R"
s = 1.0 if side == "R" else -1.0
C0 = np.array([59.3 * s, -265.8])
v, f = load()
fc = v[f[:, 0]]
sel = (np.abs(fc[:, 0] - C0[0]) < 12) & (np.abs(fc[:, 1] - C0[1]) < 12) & (fc[:, 2] > -70) & (fc[:, 2] < 3)
for z in range(-2, -63, -4):
    sg = section(v, f, 2, float(z), sel=sel)
    if not len(sg):
        continue
    P = sg.reshape(-1, 3)[:, :2]
    d = np.linalg.norm(P - C0, axis=1)
    ang = np.degrees(np.arctan2(P[:, 1] - C0[1], (P[:, 0] - C0[0]) * s))
    # free side of the post: away from the end wall (end wall lies to the south-east of the post on the right side)
    m = (d > 2.5) & (d < 8.5) & ((ang > 60) | (ang < -150))
    if m.sum() < 20:
        continue
    try:
        (xc, yc), r = fit_circle_robust(P[m])[:2]
    except Exception:  # noqa: BLE001
        xc = yc = r = np.nan
    print(f"z {z:4d}: n {m.sum():5d}  r about bore {np.median(d[m]):.2f} (p10 {np.percentile(d[m], 10):.2f} p90 {np.percentile(d[m], 90):.2f})"
          f"  free fit c ({xc:.2f}, {yc:.2f}) r {r:.2f}")
