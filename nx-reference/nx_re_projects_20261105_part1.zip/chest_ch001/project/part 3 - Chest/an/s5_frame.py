"""Model frame from functional features (raw scan frame -> part frame), p_new = R @ (p - o).
Z = normal of the interior mounting pad plane (parallel to the rim levels), toward the open (back) side.
X = mirror-plane normal (s2_symmetry), made orthogonal to Z.  Y = Z x X (toward the neck).
Origin: on the mirror plane; Y and Z from args (raw-frame point on the Z axis), default provisional.
usage: s5_frame.py [oy oz] -> work/frame.json, work/mainf.npz (framed main shell), work/scan_vc_f.ply"""
import os, sys, json
import numpy as np
import open3d as o3d
from common import W

sym = json.load(open(os.path.join(W, "symmetry_ax0.json")))
s = np.array(sym["normal"]); d = sym["d"]
zp = np.array([5.5900e-03, -2.7000e-04, 9.9998e-01]); zp /= np.linalg.norm(zp)
x = s - (s @ zp) * zp; x /= np.linalg.norm(x)
y = np.cross(zp, x)
# optional refinement (args): Z tilt from the rim-plane normal measured in the provisional frame (nx ny), and the
# origin shift (sy sz) in the provisional frame: origin = mirror plane x rim plane x shoulder-bore centre height
nrx = float(sys.argv[1]) if len(sys.argv) > 1 else 0.0
nry = float(sys.argv[2]) if len(sys.argv) > 2 else 0.0
sy = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
sz = float(sys.argv[4]) if len(sys.argv) > 4 else 0.0
R0 = np.vstack([x, y, zp])
zp = R0.T @ np.array([nrx, nry, 1.0]); zp /= np.linalg.norm(zp)
x = s - (s @ zp) * zp; x /= np.linalg.norm(x)
y = np.cross(zp, x)
o0 = d * s                       # a point of the mirror plane (raw)
o = o0 + R0.T @ np.array([0.0, sy, sz]) - R0[1] * (o0 @ R0[1]) - R0[2] * (o0 @ R0[2])
o = o - x * ((o - d * s) @ s) / (x @ s)   # back onto the mirror plane
R = np.vstack([x, y, zp])
fr = dict(R=R.tolist(), o=o.tolist(), note="p_part = R @ (p_raw - o); Z pad/rim normal, X mirror normal, Y = Z x X",
          sym_plane=sym, refine=[nrx, nry, sy, sz])
json.dump(fr, open(os.path.join(W, "frame.json"), "w"), indent=1)
dm = np.load(os.path.join(W, "main.npz"))
v = (dm["v"].astype(np.float64) - o) @ R.T
np.savez(os.path.join(W, "mainf.npz"), v=v.astype(np.float32), f=dm["f"])
m = o3d.io.read_triangle_mesh(os.path.join(W, "scan_vc.ply"))
pv_ = (np.asarray(m.vertices) - o) @ R.T
m.vertices = o3d.utility.Vector3dVector(pv_); m.compute_vertex_normals()
o3d.io.write_triangle_mesh(os.path.join(W, "scan_vc_f.ply"), m)
print("R", np.round(R, 6).tolist(), "o", np.round(o, 4).tolist(), "bbox", np.round(v.min(0), 2), np.round(v.max(0), 2))
