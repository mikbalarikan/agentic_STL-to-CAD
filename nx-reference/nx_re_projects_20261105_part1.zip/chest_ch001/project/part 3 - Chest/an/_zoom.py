"""Shaded close-up of the framed scan. usage: _zoom.py tag cx,cy,cz dx,dy,dz dist [mesh: scan|cad.stl] [clip x0,x1,y0,y1]"""
import sys, os
import numpy as np
import pyvista as pv
from common import W
tag = sys.argv[1]; c = np.array([float(t) for t in sys.argv[2].split(",")]); dv = np.array([float(t) for t in sys.argv[3].split(",")])
dist = float(sys.argv[4]); mesh = sys.argv[5] if len(sys.argv) > 5 else "scan"
m = pv.read(os.path.join(W, "scan_vc_f.ply") if mesh == "scan" else mesh)
if len(sys.argv) > 6:
    x0, x1, y0, y1 = [float(t) for t in sys.argv[6].split(",")]
    m = m.clip_box([x0, x1, y0, y1, -300, 300], invert=False)
p = pv.Plotter(off_screen=True, window_size=(1600, 1400))
p.add_mesh(m, color="lightgray", smooth_shading=False, specular=0.3)
up = (0, 0, 1) if abs(dv[2]) < 0.5 * np.linalg.norm(dv) and abs(dv[1]) > abs(dv[0]) else (0, 1, 0)
p.camera_position = [tuple(c + dv / np.linalg.norm(dv) * dist), tuple(c), up]
p.camera.view_angle = 30
p.show_axes()
p.screenshot(os.path.join(W, "rv", f"zoom_{tag}.png")); p.close()
