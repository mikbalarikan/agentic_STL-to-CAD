"""Boss / hole fit on the scan ZI map. usage: clean_boss.py x y [rsearch=6] [dz=0.6]
top = 90th pct of z within r 1.2..rsearch*0.5 ring; OD = equivalent diameter of the connected z>=top-dz region holding
the ring, centre = its centroid; hole = z < top-2.5 cells within 0.6*OD of the centre (eq. diameter + centroid)."""
import sys, os
import numpy as np
from scipy import ndimage as ndi
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = np.load(os.path.join(ROOT, "work", "clean", "relief.npz")); Z = R["z"].astype(float); xs, ys = R["xs"], R["ys"]
x, y = float(sys.argv[1]), float(sys.argv[2]); rs = float(sys.argv[3]) if len(sys.argv) > 3 else 6.0
dz = float(sys.argv[4]) if len(sys.argv) > 4 else 0.6
ix = np.where(np.abs(xs - x) <= rs)[0]; iy = np.where(np.abs(ys - y) <= rs)[0]
z = Z[np.ix_(iy, ix)]; X, Y = np.meshgrid(xs[ix], ys[iy]); r = np.hypot(X - x, Y - y)
ring = (r > 1.6) & (r < 2.6) & np.isfinite(z)
top = np.nanpercentile(z[ring], 90)
m = np.isfinite(z) & (z >= top - dz) & (r <= rs)
lab, n = ndi.label(m | (r < 1.6))
l0 = lab[np.unravel_index(np.argmin(np.where(ring & m, np.abs(r - 2.0), 99)), r.shape)]
reg = lab == l0
A = reg.sum() * 0.0625
cx, cy = X[reg].mean(), Y[reg].mean()
hole = (~np.isfinite(z) | (z < top - 2.5)) & (np.hypot(X - cx, Y - cy) < 0.6 * np.sqrt(A / np.pi) * 2)
hl, hn = ndi.label(hole); hd = None
if hn:
    k = hl[np.unravel_index(np.argmin(np.where(hole, np.hypot(X - cx, Y - cy), 99)), hl.shape)]
    hr = hl == k; ha = hr.sum() * 0.0625; hd = (np.sqrt(4 * ha / np.pi), X[hr].mean(), Y[hr].mean())
print(f"boss ({x},{y}): top {top:.2f}  OD_eq {np.sqrt(4*A/np.pi):.2f}  centre ({cx:.2f},{cy:.2f})  " + (f"hole d_eq {hd[0]:.2f} at ({hd[1]:.2f},{hd[2]:.2f})" if hd else "no hole"))
