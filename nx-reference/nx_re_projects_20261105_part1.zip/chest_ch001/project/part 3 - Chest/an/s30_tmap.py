"""Wall-thickness map of the interior: for each height-map cell (interior surface seen from +Z, work/hmap.npz top)
the unsigned distance of that point to the fitted exterior skin (work/skin_mesh_out.ply).
Writes work/tmap.npz (t, x0, y0, step) + work/rv/tmap.png."""
import os
import numpy as np, open3d as o3d
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import W
H = np.load(os.path.join(W, "hmap.npz"))
st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"]); top = H["top"]
ny, nx = top.shape
XX, YY = np.meshgrid(x0 + np.arange(nx) * st, y0 + np.arange(ny) * st)
ok = ~np.isnan(top)
m = o3d.io.read_triangle_mesh(os.path.join(W, "skin_mesh_out.ply"))
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
P = np.c_[XX[ok], YY[ok], top[ok]].astype(np.float32)
t = np.full(top.shape, np.nan, np.float32)
t[ok] = sc.compute_distance(o3d.core.Tensor(P)).numpy()
np.savez_compressed(os.path.join(W, "tmap.npz"), t=t, x0=x0, y0=y0, step=st)
fig, ax = plt.subplots(figsize=(18, 21))
im = ax.imshow(t, origin="lower", extent=[x0, x0 + nx * st, y0, y0 + ny * st], cmap="nipy_spectral", vmin=2, vmax=10)
plt.colorbar(im, shrink=.5); ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.tick_params(labelsize=6); ax.grid(lw=.3)
fig.tight_layout(); fig.savefig(os.path.join(W, "rv", "tmap.png"), dpi=60)
print("ok", np.nanpercentile(t, [5, 25, 50, 75, 95]))
