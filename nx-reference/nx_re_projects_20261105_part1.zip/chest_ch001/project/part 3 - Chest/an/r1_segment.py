"""Face segmentation of the full-res scan inside a box: triangle adjacency region growing on smoothed normals (creases
split regions, smooth curvature does not), then a plane and a cylinder fit per region. Writes a coloured render from
several directions and work/r1/seg_<tag>.json + .npz (triangle -> region).
usage: r1_segment.py tag x0 x1 y0 y1 z0 z1 [crease_deg=12] [min_area=8]"""
import sys, os, json
import numpy as np
import pyvista as pv
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from common import load, tri_data, W

tag = sys.argv[1]
B = np.array(list(map(float, sys.argv[2:8]))).reshape(3, 2)
CREASE = float(sys.argv[8]) if len(sys.argv) > 8 else 12.0
AMIN = float(sys.argv[9]) if len(sys.argv) > 9 else 8.0
v, f = load()
c, n, a = tri_data(v, f)
m = np.all((c >= B[:, 0]) & (c <= B[:, 1]), axis=1)
F = f[m]; C = c[m]; N = n[m]; A = a[m]
print("triangles", len(F))
# edge adjacency
e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]])
e.sort(axis=1)
tid = np.tile(np.arange(len(F)), 3)
key = e[:, 0].astype(np.int64) * (len(v) + 1) + e[:, 1]
o = np.argsort(key); ks = key[o]; ts = tid[o]
same = ks[1:] == ks[:-1]
I, J = ts[:-1][same], ts[1:][same]
# smooth normals (3 passes over the adjacency, area weighted)
Ns = N.copy()
for _ in range(3):
    acc = Ns * A[:, None]
    np.add.at(acc, I, Ns[J] * A[J, None]); np.add.at(acc, J, Ns[I] * A[I, None])
    Ns = acc / np.linalg.norm(acc, axis=1, keepdims=True)
cosT = np.cos(np.radians(CREASE / 3.0))
keep = np.einsum("ij,ij->i", Ns[I], Ns[J]) > cosT
G = coo_matrix((np.ones(keep.sum()), (I[keep], J[keep])), shape=(len(F), len(F)))
nr, lab = connected_components(G, directed=False)
area = np.bincount(lab, weights=A, minlength=nr)
order = np.argsort(-area)
big = [r for r in order if area[r] >= AMIN]
print("regions", nr, "with area >=", AMIN, ":", len(big))


def fit_plane(P, w):
    c0 = (P * w[:, None]).sum(0) / w.sum()
    U, S, Vt = np.linalg.svd((P - c0) * np.sqrt(w[:, None]), full_matrices=False)
    nn = Vt[2]; r = (P - c0) @ nn
    return c0, nn, float(np.sqrt((w * r * r).sum() / w.sum()))


def fit_cyl(P, Nn, w):
    # axis = direction most perpendicular to all normals; then circle fit in the plane normal to it
    U, S, Vt = np.linalg.svd(Nn * np.sqrt(w[:, None]), full_matrices=False)
    ax = Vt[2]
    u = np.cross(ax, [1, 0, 0] if abs(ax[0]) < 0.9 else [0, 1, 0]); u /= np.linalg.norm(u); vv = np.cross(ax, u)
    q = np.c_[P @ u, P @ vv]
    Am = np.c_[2 * q, np.ones(len(q))]; bm = (q ** 2).sum(1)
    sol, *_ = np.linalg.lstsq(Am * np.sqrt(w[:, None]), bm * np.sqrt(w), rcond=None)
    cc = sol[:2]; R = np.sqrt(sol[2] + cc @ cc)
    rr = np.linalg.norm(q - cc, axis=1) - R
    ctr = cc[0] * u + cc[1] * vv
    return ax, ctr, float(R), float(np.sqrt((w * rr * rr).sum() / w.sum())), float(S[2] / S[0])


out = []
for k, r in enumerate(big):
    sel = lab == r
    P, Nn, w = C[sel], Ns[sel], A[sel]
    c0, pn, prms = fit_plane(P, w)
    ax, ctr, R, crms, flat = fit_cyl(P, Nn, w)
    kind = "plane" if prms < 0.15 else ("cyl/cone" if crms < 0.25 and R < 60 else "free")
    d = dict(id=k, area=round(float(w.sum()), 1), n_mean=[round(x, 3) for x in (Nn * w[:, None]).sum(0) / np.linalg.norm((Nn * w[:, None]).sum(0))],
             bbox=[[round(x, 1) for x in P.min(0)], [round(x, 1) for x in P.max(0)]],
             plane=dict(c0=[round(x, 2) for x in c0], n=[round(x, 4) for x in pn], rms=round(prms, 3)),
             cyl=dict(axis=[round(x, 3) for x in ax], R=round(R, 2), rms=round(crms, 3)), kind=kind)
    out.append(d)
    print(f"#{k:2d} area {d['area']:7.1f} {kind:8s} n {d['n_mean']} plane rms {prms:.3f} | cyl R {R:6.2f} rms {crms:.3f} axis {d['cyl']['axis']} | bbox {d['bbox']}")
json.dump(dict(box=B.tolist(), crease=CREASE, regions=out), open(os.path.join(W, "r1", f"seg_{tag}.json"), "w"), indent=1)
rid = np.full(len(F), -1);
for k, r in enumerate(big):
    rid[lab == r] = k
np.savez_compressed(os.path.join(W, "r1", f"seg_{tag}.npz"), F=F, rid=rid)
# render
faces = np.c_[np.full(len(F), 3), F].ravel()
mesh = pv.PolyData(v, faces).extract_cells(np.arange(len(F))) if False else pv.PolyData(v, faces)
mesh = mesh.extract_cells(np.where(rid >= 0)[0])
cols = np.array(rid[rid >= 0], float)
mesh.cell_data["rid"] = cols
ctr = B.mean(1); Rr = float(np.max(B[:, 1] - B[:, 0])) * 2.0
imgs = []
import matplotlib.image as mpimg
views = [(-0.7, 0.45, 0.55), (0.0, 0.8, 0.6), (-0.95, 0.0, 0.3), (-0.3, -0.3, 0.9)]
for dv in views:
    dv = np.array(dv) / np.linalg.norm(dv)
    p = pv.Plotter(off_screen=True, window_size=(800, 800)); p.set_background("white")
    p.add_mesh(mesh, scalars="rid", cmap="tab20", show_scalar_bar=False, smooth_shading=False)
    for d in out[:20]:
        cc = np.array(d["plane"]["c0"])
        p.add_point_labels([cc], [str(d["id"])], font_size=16, point_size=1, text_color="black", shape_opacity=0.6)
    p.camera_position = [tuple(ctr + dv * Rr), tuple(ctr), (0, 0, 1)]; p.camera.view_angle = 30
    imgs.append(p.screenshot(None, return_img=True)); p.close()
mpimg.imsave(os.path.join(W, "r1", f"seg_{tag}.png"), np.vstack([np.hstack(imgs[:2]), np.hstack(imgs[2:])]))
print("ok")
