"""Collect the design values for the NX build into nx/params.json (measured -> chosen, see REBUILD.md).
Only the right half (x >= 0) is described; the build mirrors it."""
import os, json, math
import numpy as np
from common import W, ROOT

DT = json.load(open(os.path.join(W, "datums.json")))
OL = json.load(open(os.path.join(W, "outline.json")))
pp = os.path.join(ROOT, "nx", "params.json")
P = json.load(open(pp)) if os.path.exists(pp) else {}

# ---- shoulder planes: the right one is described, the left is its mirror
aR = math.degrees(math.atan2(DT["shoulder_R"]["normal"][1], DT["shoulder_R"]["normal"][0]))
aL = math.degrees(math.atan2(DT["shoulder_L"]["normal"][1], -DT["shoulder_L"]["normal"][0]))
xc = 0.5 * (DT["shoulder_R"]["hole_centre"][0] - DT["shoulder_L"]["hole_centre"][0])
P["shoulder"] = dict(angle_deg=4.5, measured_angle=[round(aR, 3), round(aL, 3)],
                     xc=round(xc / 0.05) * 0.05, measured_xc=[DT["shoulder_R"]["hole_centre"][0], DT["shoulder_L"]["hole_centre"][0]],
                     bore_d=111.0, measured_bore=[DT["shoulder_R"]["hole_d"], DT["shoulder_L"]["hole_d"]],
                     flange_t=P.get("shoulder", {}).get("flange_t", 4.6))
P.setdefault("wall_t", 3.25)
P.setdefault("rim_z", 0.0)
# ---- neck edge (x >= 0): outline points with a deep edge, smoothed, start on the mirror plane
pts = np.array(OL["pts"]); zb = np.array(OL["zmax_near"])
m = (pts[:, 0] >= -1) & (pts[:, 0] <= 66) & (pts[:, 1] > 38) & (zb < -8)
q = pts[m]
q = q[np.argsort(q[:, 0] + 0.001 * q[:, 1])]
# order along the curve: by arc from the mirror plane (x up then y up); use angle about (0, 120)
ang = np.arctan2(q[:, 0], 120.0 - q[:, 1])
q = q[np.argsort(ang)]
k = 9
qs = np.array([q[max(0, i - k):i + k + 1].mean(0) for i in range(len(q))])
L = np.r_[0, np.cumsum(np.linalg.norm(np.diff(qs, axis=0), axis=1))]
t = np.linspace(0, L[-1], 26)
neck = np.c_[np.interp(t, L, qs[:, 0]), np.interp(t, L, qs[:, 1])]
neck[0, 0] = 0.0
P["neck"] = dict(pts=neck.round(3).tolist(), note="x>=0, from the mirror plane up to the shoulder top; extended to y 140 in the build")
json.dump(P, open(pp, "w"), indent=1)
print(json.dumps({k: P[k] for k in ("shoulder", "wall_t")}, indent=1), "\nneck", neck[[0, 5, 10, 15, 20, 25]].round(2).tolist())
