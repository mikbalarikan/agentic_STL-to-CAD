"""Error budget of a dev2 run: interior/rim points over 0.5 mm in plan-view cells + plan maps.  usage: _budget.py tag"""
import sys, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W
from zones import zone_labels
tag = sys.argv[1]
A = np.load(os.path.join(W, f"dev2_{tag}_scan2cad.npy")); P, d = A[:, :3], A[:, 3]
zf = os.path.join(W, "rv", "zones400k.npy")
if os.path.exists(zf):
    Z = np.load(zf)
else:
    Z = zone_labels(P); np.save(zf, Z)
for zi, zn in enumerate(("outer", "shoulder", "rim", "inner")):
    m = Z == zi
    print(zn, m.sum(), "within0.5", round(float((np.abs(d[m]) <= .5).mean()), 4), "p50", round(float(np.median(np.abs(d[m]))), 3),
          "pos>0.5", round(float((d[m] > .5).mean()), 3), "neg<-0.5", round(float((d[m] < -.5).mean()), 3))
print("all within0.5", round(float((np.abs(d) <= .5).mean()), 4))
for zi, zn in ((3, "inner"), (2, "rim")):
    m = Z == zi
    fig, ax = plt.subplots(1, 1, figsize=(20, 22))
    s = ax.scatter(P[m, 0], P[m, 1], c=np.clip(d[m], -2, 2), s=0.3, cmap="coolwarm", vmin=-2, vmax=2)
    ax.set_aspect("equal"); ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10))
    ax.tick_params(labelsize=6); ax.grid(lw=0.3); plt.colorbar(s, shrink=0.5)
    ax.set_title(f"{zn} scan-CAD (+ = CAD lacks material), {tag}")
    fig.tight_layout(); fig.savefig(os.path.join(W, "rv", f"plan_{zn}_{tag}.png"), dpi=60); plt.close(fig)
# cells of 20 mm, ranked by number of interior misses
m = (Z == 3) & (np.abs(d) > 0.5)
key = np.floor(P[m][:, :2] / 20).astype(int)
u, inv, cnt = np.unique(key, axis=0, return_inverse=True, return_counts=True)
tot = (Z == 3).sum()
print("inner misses share of inner pts by 20mm cell (x0,y0, share%, mean d, z mean):")
for k in np.argsort(-cnt)[:40]:
    mm = inv == k
    print(u[k] * 20, round(100 * cnt[k] / tot, 2), round(float(d[m][mm].mean()), 2), round(float(P[m][mm][:, 2].mean()), 1))
