"""Footprint of scan material above the rim plane (z > zmin) over the CAD rim faces (z ~ 0, normal +z).
usage: r1_lipmap.py cad.stl out.png [zmin=0.6]"""
import sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from common import load
cad, out = sys.argv[1], sys.argv[2]
zmin = float(sys.argv[3]) if len(sys.argv) > 3 else 0.6
v, f = load()
m = v[:, 2] > zmin
P = v[m]
print("scan pts above", zmin, len(P), "z max", P[:, 2].max().round(2))
with open(cad, "rb") as fh:
    fh.read(80); n = int(np.frombuffer(fh.read(4), np.uint32)[0])
    T = np.fromfile(fh, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), n)
V = T["v"]; nz = np.cross(V[:, 1] - V[:, 0], V[:, 2] - V[:, 0]); nz = nz[:, 2] / np.maximum(np.linalg.norm(nz, axis=1), 1e-9)
rim = (np.abs(V[:, :, 2]).max(1) < 0.05) & (nz > 0.99)
top = (V[:, :, 2].min(1) > 0.05) & (nz > 0.99)
fig, ax = plt.subplots(figsize=(22, 26))
ax.add_collection(PolyCollection(V[rim][:, :, :2], facecolors="#bbbbbb", edgecolors="none"))
ax.add_collection(PolyCollection(V[top][:, :, :2], facecolors="#5577ff", edgecolors="none"))
sc = ax.scatter(P[:, 0], P[:, 1], s=0.3, c=P[:, 2], cmap="autumn_r", vmin=zmin, vmax=2.6)
plt.colorbar(sc, shrink=0.4, label="scan z")
ax.set_xlim(-175, 175); ax.set_ylim(-285, 125); ax.set_aspect("equal")
ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.grid(lw=0.3)
ax.tick_params(labelsize=7)
ax.set_title(f"grey = CAD rim face z 0, blue = CAD flat tops above 0, dots = scan z > {zmin}")
plt.tight_layout(); plt.savefig(out, dpi=60); print("ok")
