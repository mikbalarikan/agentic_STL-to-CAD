"""Colour the scan near the neck by distance from the neck tip curve (stations of edge_<tag>.json, mirrored, densified),
to see which real features lie within a rebuild zone of given radius. Writes work/r2/tipdist_<tag>.png (inside views).
usage: r2_tipdist.py tag"""
import sys, os, json
import numpy as np
import pyvista as pv
from scipy.spatial import cKDTree
from scipy.interpolate import splprep, splev
from common import load, W

tag = sys.argv[1]
S = json.load(open(os.path.join(W, "r2", f"edge_{tag}.json")))["stations"]
P = np.array([s["p"] for s in S])
M = P * [-1, 1, 1]
Q = np.vstack([M[::-1], P])
tck, u = splprep(Q.T, s=len(Q) * 0.3)
T = np.array(splev(np.linspace(0, 1, 3000), tck)).T
v, f = load()
c = v[f].mean(1)
m = (np.abs(c[:, 0]) < 90) & (c[:, 1] > 15) & (c[:, 2] > -115)
F = f[m]
d, _ = cKDTree(T).query(v[F].mean(1))
d = np.minimum(d, 20)
mesh = pv.PolyData(v, np.c_[np.full(len(F), 3), F].ravel()).extract_cells(np.arange(len(F)))
mesh.cell_data["d"] = d
imgs = []
import matplotlib.image as mpimg
ctr = np.array([0, 75, -55])
for dv, up in (((0, -0.75, 0.65), (0, 0, 1)), ((-0.6, -0.6, 0.5), (0, 0, 1)), ((0.6, -0.6, 0.5), (0, 0, 1)), ((0.01, 0, 1), (0, 1, 0))):
    dv = np.array(dv) / np.linalg.norm(dv)
    p = pv.Plotter(off_screen=True, window_size=(1000, 800)); p.set_background("white")
    p.add_mesh(mesh, scalars="d", cmap=["#d7301f", "#fc8d59", "#fdcc8a", "#b3cde3", "#8c96c6", "#88419d", "#cccccc"],
               clim=(0, 14), n_colors=7, show_scalar_bar=True, scalar_bar_args=dict(title="dist to tip mm (2 mm bands)"))
    p.add_lines(T[::10], color="black", width=3)
    p.camera_position = [tuple(ctr + dv * 260), tuple(ctr), up]; p.camera.view_angle = 30
    imgs.append(p.screenshot(None, return_img=True)); p.close()
mpimg.imsave(os.path.join(W, "r2", f"tipdist_{tag}.png"), np.vstack([np.hstack(imgs[:2]), np.hstack(imgs[2:])]))
np.save(os.path.join(W, "r2", f"tipcurve_{tag}.npy"), T)
print("ok")
