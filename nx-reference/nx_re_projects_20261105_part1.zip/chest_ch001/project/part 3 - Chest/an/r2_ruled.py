"""Is the neck flange ruled along one fixed direction D? Fit D as the direction most perpendicular to all station
e2 (flange face normals, right half + mirrored left half), report e2.D per station and the stations seen along D.
usage: r2_ruled.py tag"""
import sys, os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W

tag = sys.argv[1]
S = json.load(open(os.path.join(W, "r2", f"edge_{tag}.json")))["stations"]
E2 = np.array([s["e2"] for s in S]); P = np.array([s["p"] for s in S]); E1 = np.array([s["e1"] for s in S])
M = np.diag([-1, 1, 1])
allE2 = np.vstack([E2, E2 @ M])
u, sv, vt = np.linalg.svd(allE2)
D = vt[2] * np.sign(vt[2][2])
print("D", D.round(4), "singular", sv.round(3))
for s, e2, e1 in zip(S, E2, E1):
    print(s["k"], "e2.D %.3f" % (e2 @ D), "e1.D %.3f" % (e1 @ D), "angle(e2,D)-90 = %.1f deg" % (np.degrees(np.arccos(e2 @ D)) - 90))
X = np.cross([0, 1, 0], D); X /= np.linalg.norm(X); Y = np.cross(D, X)
q = np.c_[P @ X, P @ Y]
fig, ax = plt.subplots(figsize=(8, 7))
ax.plot(q[:, 0], q[:, 1], "o-", ms=3); ax.plot(-q[:, 0], q[:, 1], "o-", ms=3)
for p_, e1 in zip(q, E1):
    ax.arrow(p_[0], p_[1], 5 * (e1 @ X), 5 * (e1 @ Y), head_width=0.6, color="r")
ax.set_aspect("equal"); ax.grid(alpha=.3); ax.set_title(f"stations seen along D={D.round(3)} (red = flange direction e1 x5)")
fig.savefig(os.path.join(W, "r2", f"ruled_{tag}.png"), dpi=100)
json.dump(dict(D=D.tolist(), X=X.tolist(), Y=Y.tolist()), open(os.path.join(W, "r2", f"ruled_{tag}.json"), "w"))
