"""Main component only -> decimated copies (work/scan_1500k.ply, scan_600k.ply, raw frame) + shaded views."""
import os, sys, time
import numpy as np
import open3d as o3d
import pyvista as pv
from common import W

t = time.time()
d = np.load(os.path.join(W, "scan.npz"))
v, f, comp = d["v"].astype(np.float64), d["f"], d["comp"]
f = f[comp == 0]
used = np.unique(f)
remap = -np.ones(len(v), np.int64); remap[used] = np.arange(len(used))
v = v[used]; f = remap[f].astype(np.int32)
np.savez(os.path.join(W, "main.npz"), v=v.astype(np.float32), f=f)
print("main", len(v), len(f), round(time.time() - t, 1), flush=True)
m = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(v), o3d.utility.Vector3iVector(f))
for n in (1500000, 600000):
    md = m.simplify_quadric_decimation(n)
    md.compute_vertex_normals()
    o3d.io.write_triangle_mesh(os.path.join(W, f"scan_{n//1000}k.ply"), md)
    m = md
    print("dec", n, round(time.time() - t, 1), flush=True)
pm = pv.read(os.path.join(W, "scan_600k.ply"))
c = np.array(pm.center)
for name, (dv, up) in {"pz": ((0, 0, 1), (0, 1, 0)), "nz": ((0, 0, -1), (0, 1, 0)), "px": ((1, 0, 0), (0, 0, 1)),
                       "nx": ((-1, 0, 0), (0, 0, 1)), "py": ((0, 1, 0), (0, 0, 1)), "ny": ((0, -1, 0), (0, 0, 1)),
                       "iso1": ((1, -1, 1), (0, 0, 1)), "iso2": ((-1, 1, 1), (0, 0, 1)), "iso3": ((1, 1, -1), (0, 0, 1)),
                       "iso4": ((-1, -1, -1), (0, 0, 1))}.items():
    p = pv.Plotter(off_screen=True, window_size=(1400, 1400))
    p.add_mesh(pm, color="lightsteelblue", smooth_shading=True, specular=0.3)
    p.add_axes()
    p.camera_position = [tuple(c + np.array(dv, float) / np.linalg.norm(dv) * 1100), tuple(c), up]
    p.camera.view_angle = 30
    p.screenshot(os.path.join(W, f"view_raw_{name}.png")); p.close()
print("views", round(time.time() - t, 1))
