"""Plateau outlines per flat level as line/arc loops (part frame), method of the outer shell job (part 1 s16_outlines):
flat region at level h (|top - h| < 0.15, slope < 0.12) -> band of 5 mm around it -> everything in the band at
h - 0.5 or higher = the plateau -> sub-pixel contour -> smoothed -> lines/arcs (arcfit, tol 0.10).
Small holes inside a plateau are recorded (and filled in the loop).
Every loop gets a mirror test: a loop of the same level whose mirror image matches it (centroid within 1.5 mm,
area within 20 %) -> kind "R" (x > 0, mirrored in NX) / its left partner is dropped; a loop across x = 0 -> "C";
otherwise "A" (one-sided). Writes work/plateaus.json + figure."""
import os, json, sys
import numpy as np
from scipy import ndimage
import contourpy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W
from arcfit import fit_loop, seg_points

R = np.load(os.path.join(W, "raised.npz"))
cell, X0, Y0 = float(R["step"]), float(R["x0"]), float(R["y0"])
Hn = R["top"].astype(np.float64)
rs = R["raise_"]
ny, nx = Hn.shape
X1, Y1 = X0 + nx * cell, Y0 + ny * cell
gy, gx = np.gradient(np.nan_to_num(Hn, nan=-300.0), cell)
slope = np.hypot(gx, gy)
LEVELS = json.load(open(os.path.join(W, "levels.json")))["levels"]
BAND = 5.0
DROP = 0.5


def to_mm(rc):
    return np.c_[X0 + rc[:, 1] * cell, Y0 + rc[:, 0] * cell]


def area(P):
    x, y = P[:, 0], P[:, 1]
    return 0.5 * (np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))


loops_all, holes = [], []
for h in LEVELS:
    R0 = (np.abs(Hn - h) < 0.15) & (slope < 0.12) & (rs > 0.8)
    R0 = ndimage.binary_opening(R0, iterations=1)
    lab, n = ndimage.label(R0)
    if n == 0:
        continue
    sizes = ndimage.sum(R0, lab, range(1, n + 1)) * cell * cell
    R0 = np.isin(lab, 1 + np.where(sizes >= 2.0)[0])
    if not R0.any():
        continue
    band = ndimage.binary_dilation(R0, iterations=int(BAND / cell))
    inside = band & (np.nan_to_num(Hn, nan=-1e3) >= h - DROP)
    filled = ndimage.binary_fill_holes(inside)
    hl, hn = ndimage.label(filled & ~inside)
    for k in range(1, hn + 1):
        m = hl == k
        a_mm = m.sum() * cell * cell
        if a_mm > 120:
            continue
        P = to_mm(np.argwhere(m).astype(float))
        holes.append(dict(level=h, x=float(P[:, 0].mean()), y=float(P[:, 1].mean()), d_area=float(2 * np.sqrt(a_mm / np.pi)), area=float(a_mm)))
        inside |= m
    G = np.where(inside, 0.5, -0.5)
    core = band & ~np.isnan(Hn)
    G = np.where(core & (Hn < h - DROP), np.clip(Hn - (h - DROP), -0.5, 0.5), G)
    G = np.where(core & (Hn >= h - DROP), np.maximum(G, np.clip(Hn - (h - DROP), -0.5, 0.5)), G)
    G = np.pad(G, 2, constant_values=-0.5)
    for C in contourpy.contour_generator(z=G, line_type="Separate").lines(0.0):
        C = C[:, ::-1]
        P = to_mm(C - 2.0)
        if np.linalg.norm(P[0] - P[-1]) > 1e-6:
            continue
        P = P[:-1]
        A = area(P)
        if abs(A) < 2.0:
            continue
        Lc = np.r_[0, np.cumsum(np.linalg.norm(np.diff(np.vstack([P, P[:1]]), axis=0), axis=1))]
        sgrid = np.arange(0, Lc[-1], 0.1)
        Pc = np.vstack([P, P[:1]])
        Pu = np.c_[np.interp(sgrid, Lc, Pc[:, 0]), np.interp(sgrid, Lc, Pc[:, 1])]
        Pu = np.c_[ndimage.gaussian_filter1d(Pu[:, 0], 3.5, mode="wrap"), ndimage.gaussian_filter1d(Pu[:, 1], 3.5, mode="wrap")]
        loops_all.append(dict(h=h, area=float(A), P=Pu))
# mirror test per loop (outer loops only; holes inside follow their outer loop by containment in NX)
for L in loops_all:
    P = L["P"]; L["cen"] = P.mean(0); L["xmin"], L["xmax"] = P[:, 0].min(), P[:, 0].max()
for L in loops_all:
    if L["xmin"] < -0.3 and L["xmax"] > 0.3:
        L["kind"] = "C"; continue
    best = None
    for M in loops_all:
        if M is L or abs(M["h"] - L["h"]) > 0.3:
            continue
        if np.hypot(M["cen"][0] + L["cen"][0], M["cen"][1] - L["cen"][1]) < 1.5 and abs(abs(M["area"]) - abs(L["area"])) < 0.2 * abs(L["area"]):
            best = M; break
    L["kind"] = ("R" if L["cen"][0] > 0 else "Lmirror") if best is not None else "A"
out = {"levels": LEVELS, "loops": [], "holes": holes}
fig, ax = plt.subplots(figsize=(18, 21))
ax.imshow(np.where(np.isnan(Hn), np.nan, Hn), origin="lower", extent=[X0, X1, Y0, Y1], cmap="gray", vmin=-140, vmax=5, alpha=0.6)
col = {"R": "tab:blue", "C": "tab:green", "A": "tab:red", "Lmirror": "tab:cyan"}
for L in loops_all:
    segs = fit_loop(L["P"], tol=0.10)
    Q = np.vstack([seg_points(s) for s in segs])
    ax.plot(Q[:, 0], Q[:, 1], "-", lw=0.7, color=col[L["kind"]])
    if L["kind"] == "Lmirror":
        continue
    out["loops"].append(dict(h=L["h"], kind=L["kind"], area=L["area"], n_seg=len(segs), segs=[
        ([s[0], s[1].tolist(), s[2].tolist()] if s[0] == "L" else [s[0], s[1].tolist(), s[2].tolist(), s[3].tolist(), float(s[4]), bool(s[5])])
        for s in segs]))
for hh in holes:
    ax.plot(hh["x"], hh["y"], "k+", ms=4)
json.dump(out, open(os.path.join(W, "plateaus.json"), "w"))
from collections import Counter
print("loops", len(loops_all), Counter(L["kind"] for L in loops_all), "holes", len(holes))
ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.grid(True, lw=0.3); ax.tick_params(labelsize=6)
ax.set_xlim(X0, X1); ax.set_ylim(Y0, Y1); ax.set_aspect("equal")
ax.set_title("plateaus: blue = right half (mirrored), cyan = its left partner, green = across x = 0, red = one-sided")
fig.tight_layout(); fig.savefig(os.path.join(W, "plateaus.png"), dpi=75)
