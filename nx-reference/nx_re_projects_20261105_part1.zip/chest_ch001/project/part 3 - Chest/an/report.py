"""Write REPORT_deviation.md from the json results.  usage: report.py deliver_cad_dir dev_tag out_dir"""
import sys, os, json
from common import W, ROOT

CAD, TAG, OUTD = sys.argv[1], sys.argv[2], sys.argv[3]
fin = json.load(open(os.path.join(CAD, "_finalize.json")))
dev = json.load(open(os.path.join(W, f"dev2_{TAG}.json")))
sym = json.load(open(os.path.join(W, "symmetry_ax0.json")))
desc = json.load(open(os.path.join(W, "s0_describe.json")))


def row(name, s):
    return f"| {name} | {s['n']:,} | {s['mean']:+.3f} | {s['p50']:.3f} | {s['p90']:.3f} | {s['p95']:.3f} | {100*s['within_0p2']:.1f} % | {100*s['within_0p5']:.1f} % |"


import re
STEP = []
for ln in open(os.path.join(W, "stepcheck_revA.log"), encoding="utf-8", errors="ignore"):
    m = re.search(r"(CH-001_Chest_AP2\d\d\.step) read .* solids (\d+) faces (\d+) valid (\w+) volume ([\d.]+)", ln)
    if m:
        STEP.append(f"- `{m.group(1)}`: {m.group(2)} solid, {m.group(3)} faces, valid {m.group(4)}, volume {float(m.group(5)):,.0f} mm3 "
                    f"({100 * (float(m.group(5)) / fin['volume_mm3'] - 1):+.2f} % against NX).")
if fin.get("stl_volume_mm3"):
    STEP.append(f"- The NX tessellation of the same solid (`CH-001_Chest.stl`) gives {fin['stl_volume_mm3']:,.0f} mm3, "
                f"{100 * (fin['stl_volume_mm3'] / fin['volume_mm3'] - 1):+.3f} % from NX.")
L = []
L += ["# CH-001 Chest - front shell: reverse-engineering report", "",
      f"Source: `share-Chest.stl` ({desc['triangles']:,} triangles, 3D-scan mesh; one main shell of {desc['components_top'][0]['faces']:,} faces "
      f"plus {desc['n_components'] - 1:,} scan crumbs, the largest {desc['components_top'][1]['area']:.0f} mm2, ignored).",
      "Native CAD: Siemens NX 2206, solid body `CHEST`, rebuilt feature by feature on the scan (not a mesh conversion): "
      "right half modelled, mirrored about the mid-plane datum, one-sided features added after the mirror.", "",
      "## Part data", "",
      f"- Volume {fin['volume_mm3']:,.0f} mm3, mass {fin['mass_g_al6061']/1000:.3f} kg in Al 6061 (2.70 g/cm3).",
      f"- Bounding box (model frame, exact from the CAD tessellation) {fin.get('bbox_exact_stl', fin['bbox'])}.",
      "- Model frame: origin on the mid-plane, on the rim (parting) plane, at the height of the two shoulder-bore centres;",
      "  +Z = rim-plane normal toward the open back; +X = mid-plane normal; +Y = up (toward the neck).", "",
      "## Symmetry of the scan", "",
      f"Scan reflected about its best mirror plane and fitted onto itself: residual p50 {sym['residual']['p50']:.3f}, "
      f"p90 {sym['residual']['p90']:.3f} mm, {100*sym['residual']['within_0p2']:.1f} % within 0.2 mm, "
      f"{100*sym['residual']['within_0p5']:.1f} % within 0.5 mm. Above that: the lower side panels (warp, about +-0.4 mm) and "
      "the one-sided features. The CAD is symmetric (design intent), so that warp shows below as an equal split left/right.", "",
      "## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)", "",
      "| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |", "|---|---|---|---|---|---|---|---|"]
for k, nm in (("all", "whole part"), ("outer_skin", "exterior freeform skin"), ("outer_skin_right", "  exterior, right half (x > 0)"),
              ("outer_skin_left", "  exterior, left half (x < 0)"), ("shoulder", "shoulder flanges (|x| > 145)"),
              ("rim", "rim band (z > -6)"), ("interior", "interior (wall, ribs, bosses, clips, panel)")):
    if dev["scan_to_cad"].get(k):
        L.append(row(nm, dev["scan_to_cad"][k]))
c = dev["cad_to_scan"]["all"]
import numpy as _np
_A = _np.load(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "work", f"dev2_{TAG}_scan2cad.npy"))
W06 = float((_np.abs(_A[:, 3]) <= 0.06).mean())
L += ["", f"CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 {c['p50']:.3f}, p90 {c['p90']:.3f}, p95 {c['p95']:.3f} mm.", "",
      "## How the interior is modelled", "",
      "The wall is a constant 3.25 mm Shell of the fitted exterior skin. Where the print is thicker (ridges behind the",
      "panel lines, the pads of the lower side panels, the rim and neck lips, the walls of the vent and LED boxes) the",
      "measured wall thickness is turned into stepped interior pads: levels 0.7 mm apart, each a Shell offset of the skin",
      "cut to that level's outline (within +-0.35 mm of the scan by construction). The exterior is smooth: the vent",
      "boxes, LED box, side scoops and neck chamfer pockets and the raised shoulder, scoop and neck areas are single",
      "smooth tools lofted through the scan surface (no terraces on visible faces). The shoulder-vent floors are smooth",
      "too (one lofted tool between the scan exterior and interior). Bosses, tubes, gussets, hooks, the latch, the",
      "rim ledges, the PCB relief and the lower-vent slots are discrete features measured from the scan.", "",
      "## Where the remaining deviation is", "",
      "- The 0.7 mm steps of the interior pads (+-0.35 by construction): the fine ring pattern inside on the maps.",
      "- Lower side panels: print warp (left side in, right side out, about 0.75 mm) against the symmetric CAD.",
      "- Root fillets and edge rounds of the print (not modelled, sharp in CAD): the thin + band along rib and boss roots.",
      "- Window frame lips and floors on the lower side walls, the neck chamfer (one 0.7 mm step), the logo, badge and",
      "  engraved part number: not modelled (README simplifications).",
      f"- Whole-part median: {100 * W06:.0f} % of all scan points are within 0.06 mm (half would be needed for a 0.06 median).",
      "",
      "## STEP check (independent, OpenCascade, `stepcheck.py`)", ""] + STEP + ["",
      "Maps: `deviation_map_*.png` (scan coloured by its distance to the CAD, +-0.5 mm scale)."]
os.makedirs(OUTD, exist_ok=True)
open(os.path.join(OUTD, "REPORT_deviation.md"), "w", encoding="utf-8").write("\n".join(L))
print("\n".join(L))
