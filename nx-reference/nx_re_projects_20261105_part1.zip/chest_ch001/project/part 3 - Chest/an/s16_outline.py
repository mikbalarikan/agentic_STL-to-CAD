"""Plan footprint of the part (bot height map), boundary traced for x >= 0, classified per point:
z at the boundary close to the rim (> -6) = rim silhouette (pushed out, the rim plane trims there),
otherwise a real cut edge. Writes work/outline.json (boundary polyline x>=0, z, class) + figure."""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W

H = np.load(os.path.join(W, "hmap.npz"))
st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"])
bot = H["bot"]
fin = np.isfinite(bot)
# fill holes (front hole, vents) to get the outer footprint
from scipy.ndimage import binary_fill_holes, binary_closing, binary_opening
fp = binary_fill_holes(binary_closing(fin, iterations=3))
fp = binary_opening(fp, iterations=2)
_cs = plt.contour(fp.astype(float), levels=[0.5]); plt.close()
c = max(_cs.allsegs[0], key=len)[:, ::-1]      # (row, col)
P = np.c_[x0 + c[:, 1] * st, y0 + c[:, 0] * st]
# z near the boundary: min over a small inward neighbourhood of the bot map (deepest = edge depth)
J = np.clip(np.round(c[:, 0]).astype(int), 0, bot.shape[0] - 1); I = np.clip(np.round(c[:, 1]).astype(int), 0, bot.shape[1] - 1)
zb = []
for j, i in zip(J, I):
    w = bot[max(j - 6, 0):j + 7, max(i - 6, 0):i + 7]
    w = w[np.isfinite(w)]
    zb.append(np.nan if len(w) == 0 else float(np.max(w)))
zb = np.array(zb)
right = P[:, 0] >= -0.5
fig, ax = plt.subplots(figsize=(10, 14))
sc_ = ax.scatter(P[:, 0], P[:, 1], c=zb, s=2, cmap="turbo"); plt.colorbar(sc_, ax=ax)
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.tick_params(labelsize=6)
fig.tight_layout(); fig.savefig(os.path.join(W, "outline.png"), dpi=70)
json.dump(dict(pts=P.round(3).tolist(), zmax_near=np.round(zb, 2).tolist()), open(os.path.join(W, "outline.json"), "w"))
print("boundary pts", len(P), "bbox", P.min(0).round(2), P.max(0).round(2))
