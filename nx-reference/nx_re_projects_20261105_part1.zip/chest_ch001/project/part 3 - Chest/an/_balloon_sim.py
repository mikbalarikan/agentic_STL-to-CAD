"""Offline check of the SH4 balloon placer in nx/dwg_annot.py (same code path, matplotlib plot)."""
import os, json, math, re
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
ROOT = r"C:\Users\marya\Desktop\Left Thight Reverse Engineer\part 3 - Chest"
src = open(os.path.join(ROOT, "nx", "dwg_annot.py"), encoding="utf-8").read()
HO = json.load(open(os.path.join(ROOT, "work", "holes.json")))
feats = []
for h in HO:
    if h["kind"] == "Lmirror":
        continue
    for (x_, y_) in [(h["x"], h["y"])] + ([(-h["x"], h["y"])] if h["kind"] == "R" else []):
        feats.append(dict(x=x_, y=y_, d=h["d_design"], top=h["top"], one=(h["kind"] == "A")))
feats.sort(key=lambda f: (-f["y"], f["x"]))
for i, f_ in enumerate(feats, 1):
    f_["id"] = "H%d%s" % (i, "*" if f_["one"] else "")
a = src.index("OL = json.load(open(os.path.join(ROOT, \"work\", \"outline.json\")))")
b = src.index("res[\"balloons\"] = []\nfor f_ in feats:")
res = {}
exec(src[a:b])
print("cands", res["balloon_cands"], "crossings", res["balloon_crossings"])
fig, ax = plt.subplots(figsize=(12, 14))
ax.plot([p[0] for p in OL] + [OL[0][0]], [p[1] for p in OL] + [OL[0][1]], "k-", lw=0.6)
for f_ in feats:
    bx, by, h = place[f_["id"]]
    ax.plot([bx, f_["x"]], [by, f_["y"]], "b-", lw=0.6); ax.add_patch(plt.Circle((bx, by), 5.5, fill=False, color="r"))
    ax.text(bx, by, f_["id"], fontsize=6, ha="center", va="center"); ax.plot(f_["x"], f_["y"], "k.", ms=3)
ax.set_aspect("equal"); fig.tight_layout(); fig.savefig(os.path.join(ROOT, "work", "rv", "balloon_sim.png"), dpi=60)
