"""Keep the shield groove (right half, mirrored in NX); drop neck-edge artefacts (mean y > 40, |x| < 70)."""
import os, json
import numpy as np
from common import W
G = json.load(open(os.path.join(W, "grooves.json")))
keep = {}
for k, v in G["paths"].items():
    P = np.array(v["pts"])
    if P[:, 1].mean() > 40 and np.abs(P[:, 0]).mean() < 70:
        continue
    if P[:, 0].min() > 0:
        v["kind"] = "R"
    keep[k] = v
G["paths"] = keep
json.dump(G, open(os.path.join(W, "grooves.json"), "w"))
print({k: (v["kind"], v["depth"], len(v["pts"]), np.round(np.array(v["pts"])[[0, -1]], 1).tolist()) for k, v in keep.items()})
