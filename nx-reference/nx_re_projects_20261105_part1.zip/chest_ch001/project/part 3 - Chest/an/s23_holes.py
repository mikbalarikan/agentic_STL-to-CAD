"""Boss / pad holes: candidates from the plateau analysis (filled holes inside plateaus), each re-measured on the
interior height map: hole = pixels below (level - 1) connected to the centre within 6 mm, sub-pixel contour, circle
fit (accept 0.9 < r < 4.5, sd < 0.1). Bottom z = median of the visible bottom (blind) or None (through).
Mirror test (partner within 1 mm, same d within 0.3). Writes work/holes.json."""
import os, json
import numpy as np
from scipy import ndimage
import contourpy
from common import W, fit_circle_robust

PL = json.load(open(os.path.join(W, "plateaus.json")))
R = np.load(os.path.join(W, "raised.npz")); st, x0, y0 = float(R["step"]), float(R["x0"]), float(R["y0"])
top, zin = R["top"], R["zin"]
ny, nx = top.shape
res = []
seen = []
for h in PL["holes"]:
    if h["area"] < 1.5 or h["area"] > 70:
        continue
    i = int(round((h["x"] - x0) / st)); j = int(round((h["y"] - y0) / st)); w = int(6 / st)
    T = top[j - w:j + w + 1, i - w:i + w + 1]
    if T.shape != (2 * w + 1, 2 * w + 1):
        continue
    low = ~np.isfinite(T) | (T < h["level"] - 1.0)
    lab, n = ndimage.label(low)
    k = lab[w, w]
    if k == 0:
        continue
    m = lab == k
    if m[0].any() or m[-1].any() or m[:, 0].any() or m[:, -1].any():
        continue
    G = np.pad(ndimage.gaussian_filter(m.astype(float), 0.6), 2)
    best = max(contourpy.contour_generator(z=G, line_type="Separate").lines(0.5), key=len)
    P = np.c_[x0 + (i - w + best[:, 0] - 2) * st, y0 + (j - w + best[:, 1] - 2) * st]
    c, r, sd, kk = fit_circle_robust(P)
    if not (0.9 < r < 4.5 and sd < 0.1):
        continue
    if any(np.hypot(c[0] - s[0], c[1] - s[1]) < 0.8 for s in seen):
        continue
    seen.append(c)
    Tb = T[m]
    bottom = float(np.median(Tb[np.isfinite(Tb)])) if np.isfinite(Tb).mean() > 0.6 else None
    zi = float(zin[j, i]) if np.isfinite(zin[j, i]) else None
    res.append(dict(x=round(float(c[0]), 3), y=round(float(c[1]), 3), d=round(float(2 * r), 3), sd=round(float(sd), 3), top=h["level"],
                    bottom=None if bottom is None else round(bottom, 2), zin=None if zi is None else round(zi, 2)))
def depression(x, y, level, r):
    i = int(round((x - x0) / st)); j = int(round((y - y0) / st)); k = max(1, int(0.5 * r / st))
    T = top[j - k:j + k + 1, i - k:i + k + 1]
    return bool(np.all(~np.isfinite(T) | (T < level - 1.0)))


for a in res:
    mate = [b for b in res if b is not a and np.hypot(a["x"] + b["x"], a["y"] - b["y"]) < 1.0 and abs(a["d"] - b["d"]) < 0.3]
    if abs(a["x"]) < 0.5:
        a["kind"] = "C"
    elif mate:
        a["kind"] = "R" if a["x"] > 0 else "Lmirror"
    elif depression(-a["x"], a["y"], a["top"], a["d"] / 2):
        a["kind"] = "R" if a["x"] > 0 else "Rfrom_left"
    else:
        a["kind"] = "A"
for a in res:
    if a["kind"] == "Rfrom_left":
        a["x"] = -a["x"]; a["kind"] = "R"
    d = a["d"]
    a["d_design"] = 2.5 if d < 2.9 else (3.4 if d < 3.7 else round(d * 10) / 10)
json.dump(res, open(os.path.join(W, "holes.json"), "w"), indent=0)
from collections import Counter
print(len(res), Counter(a["kind"] for a in res))
for a in sorted(res, key=lambda a: (a["kind"], a["y"])):
    print(a)
