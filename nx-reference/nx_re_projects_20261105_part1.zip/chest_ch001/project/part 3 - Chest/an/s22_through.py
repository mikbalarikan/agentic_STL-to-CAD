"""Through openings of the wall (vent slots, LED holes, small holes): footprint pixels with no surface seen from either
side, connected components, contour -> lines/arcs; round ones -> circles. Mirror test like the plateaus.
Writes work/through.json + figure."""
import os, json
import numpy as np
from scipy import ndimage
import contourpy
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W, fit_circle_robust
from arcfit import fit_loop, seg_points

H = np.load(os.path.join(W, "hmap.npz")); st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"])
bot, top = H["bot"], H["top"]
ny, nx = bot.shape
fin = np.isfinite(bot) | np.isfinite(top)
fp = ndimage.binary_fill_holes(ndimage.binary_closing(fin, iterations=3))
fp = ndimage.binary_erosion(fp, iterations=6)
thr = fp & ~fin
thr = ndimage.binary_opening(thr, iterations=1)
lab, n = ndimage.label(thr)
items = []
for k in range(1, n + 1):
    m = lab == k
    a = m.sum() * st * st
    if a < 1.5 or a > 600:
        continue
    G = np.pad(ndimage.gaussian_filter(m.astype(float), 0.7), 2)
    best = max(contourpy.contour_generator(z=G, line_type="Separate").lines(0.5), key=len)
    P = np.c_[x0 + (best[:, 0] - 2) * st, y0 + (best[:, 1] - 2) * st][:-1]
    c, r, sd, kk = fit_circle_robust(P)
    circ = bool(sd < max(0.04, 0.03 * r) and abs(np.pi * r * r - a) < 0.2 * a)
    items.append(dict(area=float(a), cen=P.mean(0), P=P, circle=[float(c[0]), float(c[1]), float(r)] if circ else None))
for it in items:
    it["xmin"], it["xmax"] = it["P"][:, 0].min(), it["P"][:, 0].max()
for it in items:
    if it["xmin"] < -0.3 and it["xmax"] > 0.3:
        it["kind"] = "C"; continue
    mate = [j for j in items if j is not it and np.hypot(j["cen"][0] + it["cen"][0], j["cen"][1] - it["cen"][1]) < 1.5 and abs(j["area"] - it["area"]) < 0.25 * it["area"]]
    it["kind"] = ("R" if it["cen"][0] > 0 else "Lmirror") if mate else "A"
out = []
fig, ax = plt.subplots(figsize=(17, 20))
ax.imshow(fp, origin="lower", extent=[x0, x0 + nx * st, y0, y0 + ny * st], cmap="Greys", alpha=0.3)
for it in items:
    if it["circle"]:
        segs = None
        t = np.linspace(0, 2 * np.pi, 60); c = it["circle"]
        Q = np.c_[c[0] + c[2] * np.cos(t), c[1] + c[2] * np.sin(t)]
    else:
        Pc = it["P"]
        Lc = np.r_[0, np.cumsum(np.linalg.norm(np.diff(np.vstack([Pc, Pc[:1]]), axis=0), axis=1))]
        sg = np.arange(0, Lc[-1], 0.08); Pp = np.vstack([Pc, Pc[:1]])
        Pu = np.c_[np.interp(sg, Lc, Pp[:, 0]), np.interp(sg, Lc, Pp[:, 1])]
        Pu = np.c_[ndimage.gaussian_filter1d(Pu[:, 0], 2.5, mode="wrap"), ndimage.gaussian_filter1d(Pu[:, 1], 2.5, mode="wrap")]
        segs = fit_loop(Pu, tol=0.08)
        Q = np.vstack([seg_points(s) for s in segs])
    ax.plot(Q[:, 0], Q[:, 1], "-", lw=0.8, color={"R": "tab:blue", "C": "tab:green", "A": "tab:red", "Lmirror": "tab:cyan"}[it["kind"]])
    if it["kind"] == "Lmirror":
        continue
    out.append(dict(kind=it["kind"], area=round(it["area"], 2), cen=[round(float(v), 3) for v in it["cen"]], circle=it["circle"],
                    segs=None if segs is None else [([s[0], s[1].tolist(), s[2].tolist()] if s[0] == "L" else [s[0], s[1].tolist(), s[2].tolist(), s[3].tolist(), float(s[4]), bool(s[5])]) for s in segs]))
json.dump(out, open(os.path.join(W, "through.json"), "w"))
from collections import Counter
print("openings", len(items), Counter(i["kind"] for i in items), "circles", sum(1 for i in items if i["circle"]))
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.tick_params(labelsize=6)
fig.tight_layout(); fig.savefig(os.path.join(W, "through.png"), dpi=75)
