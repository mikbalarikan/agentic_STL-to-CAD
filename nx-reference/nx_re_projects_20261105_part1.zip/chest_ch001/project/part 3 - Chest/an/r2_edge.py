"""Neck U edge: take the continuous edge-face region of a segmentation (seg_<tag>, region id), order it along the U
(polar angle in the x-z plane about a centre), smooth it into a station curve, and cut the full-res scan + CAD STL with
planes normal to the curve at each station. Plots the local profiles (e1 = mean edge-face normal, e2 = t x e1) and
writes work/r2/edge_<tag>.json (stations: point, tangent, e1).
usage: r2_edge.py seg_tag region_id cad.stl out_tag [cx=20 cz=-50] [n_st=24]"""
import sys, os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from common import load, tri_data, section, W
from r2_secs import read_stl, gsection

tag, rid0, cad, otag = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
cx = float(sys.argv[5]) if len(sys.argv) > 5 else 20.0
cz = float(sys.argv[6]) if len(sys.argv) > 6 else -50.0
NST = int(sys.argv[7]) if len(sys.argv) > 7 else 24
v, f = load()
d = np.load(os.path.join(W, "r1", f"seg_{tag}.npz"))
F, rid = d["F"], d["rid"]
c, n, a = tri_data(v, F[rid == rid0])
ang = np.arctan2(c[:, 2] - cz, c[:, 0] - cx)          # -pi/2 = straight below the centre
lo, hi = np.percentile(ang, 0.5), np.percentile(ang, 99.5)
edges = np.linspace(lo, hi, NST + 1)
P, Nn = [], []
for i in range(NST):
    m = (ang >= edges[i]) & (ang < edges[i + 1])
    if m.sum() < 20:
        continue
    w = a[m]
    P.append((c[m] * w[:, None]).sum(0) / w.sum())
    nn = (n[m] * w[:, None]).sum(0); Nn.append(nn / np.linalg.norm(nn))
P, Nn = np.array(P), np.array(Nn)
T = np.gradient(P, axis=0); T /= np.linalg.norm(T, axis=1, keepdims=True)
vc, fc = read_stl(cad)
cc = vc[fc].mean(1)
cs = v[f].mean(1)
st = []
ncol = 6; nrow = (len(P) + ncol - 1) // ncol
fig, axs = plt.subplots(nrow, ncol, figsize=(3.6 * ncol, 3.6 * nrow), squeeze=False)
for k, (p, t, e1) in enumerate(zip(P, T, Nn)):
    e1 = e1 - (e1 @ t) * t; e1 /= np.linalg.norm(e1); e2 = np.cross(t, e1)
    ms = np.linalg.norm(cs - p, axis=1) < 22; mc = np.linalg.norm(cc - p, axis=1) < 22
    R = np.array([e1, e2, t])
    ss = section((v - p) @ R.T, f[ms], 2, 0.0)[:, :, :2]
    sc = section((vc - p) @ R.T, fc[mc], 2, 0.0)[:, :, :2]
    ax = axs[k // ncol][k % ncol]
    ax.add_collection(LineCollection(sc, colors="#555555", linewidths=1.3))
    ax.add_collection(LineCollection(ss, colors="#f2a11f", linewidths=0.9))
    ax.plot(0, 0, "r+")
    ax.set_xlim(-14, 8); ax.set_ylim(-11, 11); ax.set_aspect("equal"); ax.grid(alpha=0.3)
    ax.set_title(f"#{k} ({p[0]:.0f},{p[1]:.0f},{p[2]:.0f})", fontsize=8)
    ax.tick_params(labelsize=6)
    st.append(dict(k=k, p=p.round(2).tolist(), t=t.round(4).tolist(), e1=e1.round(4).tolist(), e2=e2.round(4).tolist()))
for k in range(len(P), nrow * ncol):
    axs[k // ncol][k % ncol].axis("off")
fig.suptitle("edge-normal sections: x = e1 (edge-face normal, out of the edge), y = e2;  scan orange / CAD grey", fontsize=10)
fig.tight_layout(); fig.savefig(os.path.join(W, "r2", f"edge_{otag}.png"), dpi=100)
json.dump(dict(seg=tag, region=rid0, stations=st), open(os.path.join(W, "r2", f"edge_{otag}.json"), "w"), indent=1)
print("stations", len(P))
for s in st:
    print(s["k"], s["p"], "t", s["t"], "e1", s["e1"])
