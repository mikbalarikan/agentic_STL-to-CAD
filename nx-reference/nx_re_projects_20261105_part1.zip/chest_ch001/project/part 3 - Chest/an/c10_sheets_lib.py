"""Helpers of c10_sheets.py as an importable module (s41_floor.py)."""
import os, json
import numpy as np
from scipy import ndimage
from common import W
from arcfit import seg_points
H = np.load(os.path.join(W, 'hmap.npz'))
x0, y0, st = float(H['x0']), float(H['y0']), float(H['step'])
ny, nx = H['bot'].shape
xs = x0 + np.arange(nx) * st


def mirror(a):
    """a(-x, y) on the same grid (linear interpolation along x)."""
    out = np.full_like(a, np.nan)
    for i in range(ny):
        r = a[i]; ok = ~np.isnan(r)
        if ok.sum() > 2:
            out[i] = np.interp(-xs, xs[ok], r[ok], left=np.nan, right=np.nan)
    return out


def inpaint(a, mask_bad, sig_px=8):
    a = a.copy(); a[mask_bad] = np.nan
    for _ in range(30):
        nanm = np.isnan(a)
        if not nanm.any():
            break
        w = ndimage.gaussian_filter((~nanm).astype(float), sig_px)
        s = ndimage.gaussian_filter(np.where(nanm, 0.0, a), sig_px)
        fill = np.where(w > 1e-3, s / np.maximum(w, 1e-9), np.nan)
        a = np.where(nanm, fill, a)
    return a


def fill_nearest(a):
    """NaN cells (beyond the part edge, holes) take the value of the nearest valid cell: no cliffs in the sheet."""
    m = np.isnan(a)
    if not m.any():
        return a
    idx = ndimage.distance_transform_edt(m, return_distances=False, return_indices=True)
    return a[tuple(idx)]


def loop_pts(L):
    return np.vstack([seg_points([g[0], np.array(g[1]), np.array(g[2])] + ([np.array(g[3]), g[4], g[5]] if g[0] == "A" else [])) for g in L["segs"]])


def loops_in(jsonfile, box):
    D = json.load(open(os.path.join(W, jsonfile)))
    out = []
    for L in D["loops"]:
        if L["k"] != 0:
            continue
        Q = loop_pts(L)
        if box[0] <= Q[:, 0].min() + 0.5 and Q[:, 0].max() <= box[1] and box[2] <= Q[:, 1].min() and Q[:, 1].max() <= box[3]:
            out.append(Q)
    return out


