import os, numpy as np
from common import W
R = np.load(os.path.join(W, "raised.npz")); H = np.load(os.path.join(W, "hmap.npz"))
st, x0, y0 = float(R["step"]), float(R["x0"]), float(R["y0"]); top, rs, nt = R["top"], R["raise_"], H["ntop"]
def win(x, y, w=8):
    i = int(round((x - x0) / st)); j = int(round((y - y0) / st))
    return top[j-w:j+w+1, i-w:i+w+1], rs[j-w:j+w+1, i-w:i+w+1], nt[j-w:j+w+1, i-w:i+w+1]
for (x, y) in [(68, -50), (157, 64), (35, -20), (88, 89), (105, -148)]:
    t, r, n = win(x, y)
    print((x, y), "top max", np.nanmax(t).round(2), "row through centre:", np.round(t[8], 2).tolist())
    print("    raise row", np.round(r[8], 1).tolist())
