"""Hillshade tiles of a ZI/ZE depth map (scan or CAD) with a mm grid, to read clean feature positions.
usage: clean_mapview.py maps.npz key out_dir tag x0 x1 y0 y1 [grid]"""
import sys, os
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
f, key, out, tag = sys.argv[1:5]
x0, x1, y0, y1 = map(float, sys.argv[5:9]); g = float(sys.argv[9]) if len(sys.argv) > 9 else 10.0
d = np.load(f); xs, ys = d["xs"], d["ys"]; Z = d[key].astype(float)
ix = (xs >= x0) & (xs <= x1); iy = (ys >= y0) & (ys <= y1)
Z = Z[np.ix_(iy, ix)]
Zf = np.where(np.isfinite(Z), Z, np.nanmin(Z) - 5)
gy, gx = np.gradient(Zf, 0.25)
az, alt = np.radians(315), np.radians(45)
sl = np.pi / 2 - np.arctan(np.hypot(gx, gy)); asp = np.arctan2(-gx, gy)
hs = np.sin(alt) * np.sin(sl) + np.cos(alt) * np.cos(sl) * np.cos(az - asp)
w = (x1 - x0) / 10; h = (y1 - y0) / 10
fig, ax = plt.subplots(figsize=(w * 0.9 + 1, h * 0.9 + 1), dpi=110)
ax.imshow(hs, cmap="gray", origin="lower", extent=(x0, x1, y0, y1), vmin=0, vmax=1)
ax.contour(xs[ix], ys[iy], Zf, levels=np.arange(-150, 5, 2.0), colors="tab:orange", linewidths=0.25, alpha=0.6)
ax.set_xticks(np.arange(np.ceil(x0 / g) * g, x1 + 0.1, g)); ax.set_yticks(np.arange(np.ceil(y0 / g) * g, y1 + 0.1, g))
ax.grid(True, color="cyan", lw=0.3, alpha=0.7); ax.tick_params(labelsize=6)
ax.set_title(f"{tag} {key} x {x0}..{x1} y {y0}..{y1} (orange contours every 2 mm)", fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(out, f"{tag}_{key}_{int(x0)}_{int(y0)}.png")); plt.close(fig)
