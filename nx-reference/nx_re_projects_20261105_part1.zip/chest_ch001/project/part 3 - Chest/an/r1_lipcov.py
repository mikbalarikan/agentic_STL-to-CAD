"""Rim lip coverage: scan points on the lip top (z 1.4..2.0) vs a CAD STL. A point is covered when the CAD surface
is within 0.6 mm. Prints coverage per 10 mm bin along the rim and plots uncovered points.
usage: r1_lipcov.py cad.stl out.png"""
import sys
import numpy as np
import open3d as o3d
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load

cm = o3d.io.read_triangle_mesh(sys.argv[1]); cm.remove_duplicated_vertices()
rs = o3d.t.geometry.RaycastingScene()
rs.add_triangles(o3d.t.geometry.TriangleMesh(o3d.core.Tensor(np.asarray(cm.vertices, np.float32)),
                                             o3d.core.Tensor(np.asarray(cm.triangles, np.int32))))
v, f = load()
P = v[(v[:, 2] > 1.4) & (v[:, 2] < 2.0)].astype(np.float32)
d = rs.compute_signed_distance(o3d.core.Tensor(P)).numpy()
cov = np.abs(d) < 0.6
print("lip-top scan points", len(P), "covered", round(float(cov.mean()), 3), "inside CAD", round(float((d < 0).mean()), 3))
for nm, m in (("R side", P[:, 0] > 0), ("L side", P[:, 0] < 0)):
    print(nm, round(float(cov[m].mean()), 3))
key = np.floor(P[:, :2] / 10).astype(int)
bad = []
for k in np.unique(key, axis=0):
    m = np.all(key == k, axis=1)
    if m.sum() > 30 and cov[m].mean() < 0.7:
        bad.append((tuple(k * 10), round(float(cov[m].mean()), 2), round(float(np.median(d[m])), 2)))
print("bins under 70 %:", bad)
fig, ax = plt.subplots(figsize=(16, 18))
ax.scatter(P[cov, 0], P[cov, 1], s=0.2, c="green")
ax.scatter(P[~cov, 0], P[~cov, 1], s=0.6, c="red")
ax.set_aspect("equal"); ax.grid(lw=0.3); ax.set_title("scan lip top: green = CAD within 0.6, red = not")
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=60)
