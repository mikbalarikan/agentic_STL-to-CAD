"""Scan (black) vs CAD (red) sections. usage: sec_cmp.py cad.stl axis v1,v2,.. out.png a0,a1,b0,b1 (window on the 2 plot axes)"""
import sys, os
import numpy as np, trimesh
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load, section
cad = trimesh.load(sys.argv[1]); ax = "xyz".index(sys.argv[2]); vals = [float(t) for t in sys.argv[3].split(",")]
out = sys.argv[4]; w = [float(t) for t in sys.argv[5].split(",")]
v, f = load(); pa = {0: (1, 2), 1: (0, 2), 2: (0, 1)}[ax]
n = len(vals); fig, axs = plt.subplots(1, n, figsize=(6 * n, 6 * (w[3] - w[2]) / (w[1] - w[0]) + 0.6), squeeze=False)
for a_, val in zip(axs[0], vals):
    for verts, faces, col in ((v, f, "k"), (np.asarray(cad.vertices), np.asarray(cad.faces), "r")):
        s = section(verts, faces, ax, val)
        if len(s):
            seg = s[:, :, list(pa)]
            k = (seg[:, :, 0] >= w[0]).all(1) & (seg[:, :, 0] <= w[1]).all(1) & (seg[:, :, 1] >= w[2]).all(1) & (seg[:, :, 1] <= w[3]).all(1)
            a_.add_collection(LineCollection(seg[k], lw=0.8, color=col))
    a_.set_xlim(w[0], w[1]); a_.set_ylim(w[2], w[3]); a_.set_aspect("equal"); a_.minorticks_on()
    a_.grid(True, which="major", lw=0.4); a_.grid(True, which="minor", lw=0.15, alpha=0.5)
    a_.set_title(f"{'xyz'[ax]} = {val} ({'xyz'[pa[0]]} right, {'xyz'[pa[1]]} up); scan black, CAD red", fontsize=8)
fig.tight_layout(); fig.savefig(out, dpi=80); plt.close(fig); print("ok")
