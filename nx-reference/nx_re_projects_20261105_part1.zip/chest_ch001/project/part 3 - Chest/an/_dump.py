import json, sys
d = json.load(open(sys.argv[1]))
mode = sys.argv[2]
for r in d:
    P = r["pts"]
    if mode == "xend":   # end points with |Xd| near a value
        v = float(sys.argv[3])
        for p in P[:2]:
            if abs(abs(p[0]) - v) < 0.3:
                print(r["cls"], len(P), [round(c, 2) for c in p], [round(c, 2) for c in P[0]], [round(c, 2) for c in P[1]])
    elif mode == "hline":   # straight-ish horizontal (const Yd) curves in a section with |x| < lim
        if len(P) == 2 or len(P) == 3:
            a, b = P[0], P[1]
            if abs(a[1] - b[1]) < 0.02 and abs(a[0] - b[0]) > 2 and abs(a[0]) < 45 and abs(b[0]) < 45:
                print(r["cls"], len(P), [round(c, 3) for c in a], [round(c, 3) for c in b])
    elif mode == "count":
        pass
print(len(d), "curves")
