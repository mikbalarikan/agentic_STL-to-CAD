"""CH-001 Rev B feature spec (user marks 2026-10-31) -> work/r1/spec_r1.json + check plot over the relief map.
All outlines are lines + tangent arcs with round values in the frame of a plane fitted to the right lower side wall
(rel_R2.json: u horizontal, v up the wall, n into the cavity). Left side = Mirror Geometry in NX."""
import os, json, math
import numpy as np
import open3d as o3d
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W, load

R1 = os.path.join(W, "r1")
fr = json.load(open(os.path.join(R1, "rel_R2.json")))
c0 = np.round(np.array(fr["c0"]), 1)
n = np.round(np.array(fr["n"]), 3); n /= np.linalg.norm(n)
u = np.cross([0, 0, 1.0], n); u /= np.linalg.norm(u)          # horizontal
if u @ np.array(fr["u"]) < 0:
    u = -u
v = np.cross(n, u)
if v[2] < 0:
    v = -v; u = -u


def rounded(pts, radii):
    """Closed polygon with a tangent fillet of radius r_i at vertex i (0 = sharp). Returns segments in plane coords:
    ["L", a, b] and ["A", centre, r, a0, a1] with a0 < a1 counter-clockwise."""
    k = len(pts); P = [np.array(p, float) for p in pts]
    tp = []
    for i in range(k):
        a, b, c = P[i - 1], P[i], P[(i + 1) % k]
        r = radii[i]
        if r <= 0:
            tp.append((b, b, None)); continue
        d1 = (a - b) / np.linalg.norm(a - b); d2 = (c - b) / np.linalg.norm(c - b)
        th = math.acos(np.clip(d1 @ d2, -1, 1))
        t = r / math.tan(th / 2)
        p1, p2 = b + d1 * t, b + d2 * t
        bis = (d1 + d2) / np.linalg.norm(d1 + d2)
        ctr = b + bis * (r / math.sin(th / 2))
        tp.append((p1, p2, (ctr, r)))
    seg = []
    for i in range(k):
        p1, p2, arc = tp[i]
        if arc is not None:
            ctr, r = arc
            a0 = math.atan2(p1[1] - ctr[1], p1[0] - ctr[0]); a1 = math.atan2(p2[1] - ctr[1], p2[0] - ctr[0])
            da = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi       # the fillet is the short way round
            if da < 0:
                a0, a1 = a1, a0
            while a1 <= a0:
                a1 += 2 * math.pi
            seg.append(["A", ctr.tolist(), r, a0, a1])
        nxt = tp[(i + 1) % k][0]
        if np.linalg.norm(nxt - p2) > 1e-6:
            seg.append(["L", p2.tolist(), nxt.tolist()])
    return seg


def rrect(cu, cv, L, Wd, ang, r):
    a = math.radians(ang); e1 = np.array([math.cos(a), math.sin(a)]); e2 = np.array([-e1[1], e1[0]])
    c = np.array([cu, cv]); h, w = L / 2, Wd / 2
    pts = [c - h * e1 - w * e2, c + h * e1 - w * e2, c + h * e1 + w * e2, c - h * e1 + w * e2]
    return rounded([p.tolist() for p in pts], [r] * 4)


def offset_poly(P, d):
    out = []
    for i in range(len(P)):
        ds = []
        if i > 0:
            t = P[i] - P[i - 1]; ds.append(np.array([-t[1], t[0]]) / np.linalg.norm(t))
        if i < len(P) - 1:
            t = P[i + 1] - P[i]; ds.append(np.array([-t[1], t[0]]) / np.linalg.norm(t))
        if len(ds) == 1:
            out.append(P[i] + d * ds[0])
        else:
            nn = ds[0] + ds[1]; nn /= np.linalg.norm(nn)
            out.append(P[i] + d * nn / (nn @ ds[0]))
    return np.array(out)


# ---------------- pad (right lower side wall): outer loop, the T window opens through its top edge
outer = [(-66, 46), (-64.5, 12), (-51, -14.5), (-35, -27), (-21, -39.5), (-8, -43), (44, -43), (50, -37), (78, -34),
         (81, 17), (83, 46), (53, 46), (52, 39.5),
         (-14.5, 39.5), (-14.5, 15.5), (-29.5, 15.5), (-29.5, 17), (-51.5, 17), (-51.5, 31), (-29.5, 31), (-29.5, 39.5),
         (-48, 39.5), (-49.5, 46)]
orad = [3, 12, 10, 8, 8, 10, 3, 3, 4, 6, 3, 3, 2, 2, 2, 2, 0, 2, 2, 0, 2, 2, 3]
windows = {
    "W1_lower": rounded([(-29.5, -25.5), (-14.5, -25.5), (-14.5, 12), (-29.5, 12)], [2, 2, 2, 2]),
    "W2_upper": rounded([(4, 6.5), (23.5, 6.5), (23.5, 37.5), (4, 37.5)], [2, 2, 3, 3]),
    "W2_lower": rounded([(10, -8), (28, -5.5), (26.5, 1), (10, 1)], [2, 2, 2, 2]),
    "W3": rrect(55.95, 15.85, 40.2, 12.7, -44.7, 2),
    "W4": rounded([(11.5, -31.5), (28, -31.5), (28, -16), (11.5, -16)], [2, 2, 2, 2]),
    "W5": rounded([(32, -35.5), (49, -35.5), (49, -4.5), (43.5, -4.5), (43.5, -15), (32, -15)], [2, 2, 2, 2, 1, 2]),
}
PAD_T = 2.0
# rib = raised band along the pad's lower border, from the side tube to the boss pair
RIB_W, RIB_T = 4.0, 2.9
P = np.array([(-51, -14.5), (-35, -27), (-21, -39.5), (-8, -43), (44, -43)], float)
Pin = offset_poly(P, RIB_W)            # left of the direction of travel = into the pad
rib_loop = [tuple(p) for p in P] + [tuple(p) for p in Pin[::-1]]
rib_rad = [0, 8, 8, 10, 0, 0, 6, 4, 4, 0]

# ---------------- CAD queries on the delivered STL
cm = o3d.io.read_triangle_mesh(os.path.join(os.path.dirname(W), "deliver", "CAD", "CH-001_Chest.stl")); cm.remove_duplicated_vertices()
rs = o3d.t.geometry.RaycastingScene()
rs.add_triangles(o3d.t.geometry.TriangleMesh(o3d.core.Tensor(np.asarray(cm.vertices, np.float32)),
                                             o3d.core.Tensor(np.asarray(cm.triangles, np.int32))))


def ray(o, d):
    r = rs.cast_rays(o3d.core.Tensor(np.array([list(o) + list(d)], np.float32)))
    t = float(r["t_hit"].numpy()[0])
    return np.array(o, float) + t * np.array(d, float) if np.isfinite(t) else None


p_in = ray(c0 + 15 * n, -n)
print("pad inner-wall point", p_in.round(3), "offset from c0 along n", round(float((p_in - c0) @ n), 2))

# C notches: half-round channels R3.5 in the hole-facing face of each clip tab, through the tab to its floor
notches = []
for nm, c in (("R", (25.7, -125.9)), ("L", (-25.7, -125.9)), ("T11", (11.0, -164.0))):
    zf = []
    for a in np.linspace(0, 2 * math.pi, 24, endpoint=False):
        q = (c[0] + 3.4 * math.cos(a), c[1] + 3.4 * math.sin(a))
        h = ray((q[0], q[1], -100.0), (0, 0, -1))
        if h is not None and h[2] < -110:
            zf.append(h[2])
    notches.append(dict(id=nm, c=c, r=3.5, z_top=-106.8, z_floor_max=round(max(zf), 2), z_floor_min=round(min(zf), 2)))
print("notches", notches)

LOBE_C = (77.6, -217.3)
top_in = ray((LOBE_C[0], LOBE_C[1], -50.0), (0, 0, -1))
ext = ray((LOBE_C[0], LOBE_C[1], -200.0), (0, 0, 1))
print("lobe: CAD hit from above", None if top_in is None else top_in.round(2), "exterior from below", None if ext is None else ext.round(2))

vs, fs = load()
L = vs[(vs[:, 2] > 0.8) & (vs[:, 2] < 2.2)]
key = np.round(L[:, :2] / 0.5).astype(int)
_, ix = np.unique(key, axis=0, return_index=True)
Lp = L[ix]
print("lip points", len(L), "-> 0.5 grid", len(Lp), "z p50/p90/p99", np.percentile(L[:, 2], [50, 90, 99]).round(2))

spec = dict(
    frame=dict(c0=c0.tolist(), n=n.tolist(), u=u.tolist(), v=v.tolist(), back=25.0, p_in=p_in.tolist()),
    pad=dict(t=PAD_T, outer=rounded(outer, orad), windows=windows),
    rib=dict(t=RIB_T, loop=rounded(rib_loop, rib_rad)),
    notches=notches,
    lobe=dict(c=LOBE_C, d=5.0, z_top=-63.4, z_bot=(round(float(ext[2]) + 1.2, 2) if ext is not None else -84.0)),
    pin=dict(c=LOBE_C, d=2.6, z0=-63.4, z1=-60.4, r_top=0.6),
    lip=dict(h=1.7, t=1.2, pts=Lp[:, :2].round(2).tolist()),
)
json.dump(spec, open(os.path.join(R1, "spec_r1.json"), "w"))

z = np.load(os.path.join(R1, "rel_R2.npz"))
fig, ax = plt.subplots(figsize=(20, 13))
ax.scatter(z["uu"], z["vv"], s=0.1, c=z["d"], cmap="turbo", vmin=-1, vmax=3)


def draw(segs, col):
    for s in segs:
        if s[0] == "L":
            ax.plot([s[1][0], s[2][0]], [s[1][1], s[2][1]], col, lw=1.6)
        else:
            t = np.linspace(s[3], s[4], 30); ax.plot(s[1][0] + s[2] * np.cos(t), s[1][1] + s[2] * np.sin(t), col, lw=1.6)


draw(spec["pad"]["outer"], "k-")
for w_ in windows.values():
    draw(w_, "w-")
draw(spec["rib"]["loop"], "m-")
ax.set_aspect("equal"); ax.grid(lw=0.3)
plt.tight_layout(); plt.savefig(os.path.join(R1, "spec_r1_check.png"), dpi=60)
print("ok")
