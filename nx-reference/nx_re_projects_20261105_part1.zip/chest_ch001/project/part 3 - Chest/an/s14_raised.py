"""Interior features = where the scan's interior surface (top height map, seen from +Z) stands above the fitted
inner skin (exterior skin offset by wall_t). Builds skin meshes from the radial fit (work/skin_mesh_{out,in}.ply),
ray-casts them on the height-map grid -> work/raised.npz (zin, zout, raise) + map."""
import os, json, sys
import numpy as np
import open3d as o3d
from scipy.interpolate import BSpline
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import W, ROOT

T = json.load(open(os.path.join(ROOT, "nx", "params.json")))["wall_t"]
s = np.load(os.path.join(W, "skin_fit.npz"))
tk, CF, C = s["tk"], s["CF"], s["C"]
g = np.arange(-1.46, 1.4601, 0.004)
Pg, Qg = np.meshgrid(g, g)                       # Qg varies along axis 0
R = np.empty_like(Pg)
Sq = BSpline(tk, CF, 3)
for i, q in enumerate(g):
    R[i] = BSpline(tk, Sq(q), 3)(g)
psi = np.hypot(Pg, Qg); sn = np.sinc(psi / np.pi)
D = np.stack([Pg * sn, Qg * sn, -np.cos(psi)], -1)
X = C + R[..., None] * D
Xp = np.gradient(X, axis=1); Xq = np.gradient(X, axis=0)
Nn = np.cross(Xp, Xq); Nn /= np.linalg.norm(Nn, axis=-1)[..., None]
sg = np.sign(((C - X) * Nn).sum(-1))[..., None]
Xi = X + T * sg * Nn
ok = psi < 1.45
n0, n1 = Pg.shape
idx = np.arange(n0 * n1).reshape(n0, n1)
a, b, c_, d_ = idx[:-1, :-1], idx[:-1, 1:], idx[1:, :-1], idx[1:, 1:]
okq = ok[:-1, :-1] & ok[:-1, 1:] & ok[1:, :-1] & ok[1:, 1:]
F = np.r_[np.c_[a[okq], b[okq], d_[okq]], np.c_[a[okq], d_[okq], c_[okq]]]
H = np.load(os.path.join(W, "hmap.npz"))
st, x0, y0 = float(H["step"]), float(H["x0"]), float(H["y0"])
top = H["top"]
ny, nx = top.shape
XX, YY = np.meshgrid(x0 + np.arange(nx) * st, y0 + np.arange(ny) * st)
out = {}
for name, V in (("out", X), ("in", Xi)):
    m = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(V.reshape(-1, 3)), o3d.utility.Vector3iVector(F))
    m.remove_unreferenced_vertices()
    o3d.io.write_triangle_mesh(os.path.join(W, f"skin_mesh_{name}.ply"), m)
    sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
    rays = np.zeros((XX.size, 6), np.float32); rays[:, 0] = XX.ravel(); rays[:, 1] = YY.ravel(); rays[:, 2] = -300; rays[:, 5] = 1
    t = sc.cast_rays(o3d.core.Tensor(rays))["t_hit"].numpy()
    out["z" + name] = np.where(np.isfinite(t), -300 + t, np.nan).reshape(XX.shape).astype(np.float32)
raise_ = top - out["zin"]
np.savez(os.path.join(W, "raised.npz"), x0=x0, y0=y0, step=st, zin=out["zin"], zout=out["zout"], top=top, raise_=raise_)
fig, ax = plt.subplots(figsize=(17, 20))
im = ax.imshow(np.clip(raise_, -1, 12), origin="lower", extent=[x0, x0 + nx * st, y0, y0 + ny * st], cmap="nipy_spectral", vmin=-1, vmax=12)
plt.colorbar(im, ax=ax, shrink=0.6); ax.set_title(f"interior raise above the inner skin (wall {T}) mm")
ax.set_xticks(np.arange(-170, 171, 10)); ax.set_yticks(np.arange(-280, 121, 10)); ax.grid(True, lw=0.3, alpha=0.6); ax.tick_params(labelsize=6)
fig.tight_layout(); fig.savefig(os.path.join(W, "raised.png"), dpi=80)
r = raise_[np.isfinite(raise_)]
print("raise p5/p25/p50/p75 over the map", np.round(np.percentile(r, [5, 25, 50, 75]), 3))
