"""Panel design values (rounded) from work/panel.json -> nx/params.json["panel"]."""
import os, json, math
from common import W, ROOT
P = json.load(open(os.path.join(W, "panel.json")))
pp = os.path.join(ROOT, "nx", "params.json"); Q = json.load(open(pp))
tilt = 4.7
g = -math.tan(math.radians(tilt))
zi = P["int_plane"]["z_at_origin"] + P["int_plane"]["dzdy"] * -100.0          # interior plane at y = -100
zci = P["circle_int_plane"]["z_at_origin"] + P["circle_int_plane"]["dzdy"] * P["circle"]["c"][1]
cy = round(P["circle"]["c"][1] * 2) / 2
Q["panel"] = dict(tilt_deg=tilt, dzdy=round(g, 6), z_int_at_y_m100=round(zi, 3), t_panel=2.7,
                  circle_c=[0.0, cy], circle_d=63.0, z_circle_int_at_c=round(zci, 3), t_disc=1.95,
                  hole_c=[0.0, -137.0], hole_d=37.4, outline_segs=P["outline_segs"],
                  measured=dict(tilts=[P["int_plane"]["tilt_about_x_deg"], P["circle_int_plane"]["tilt_about_x_deg"], P["circle_ext_floor"]["tilt_about_x_deg"]],
                                circle=P["circle"], hole=P["hole"]))
json.dump(Q, open(pp, "w"), indent=1)
print({k: v for k, v in Q["panel"].items() if k != "outline_segs"})
