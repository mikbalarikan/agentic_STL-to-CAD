"""Cap blind boss-hole bottoms at 0.8 mm above the CAD exterior (ray from -Z through the CAD STL at the hole axis).
The scan's 'bottom' inside narrow holes is unreliable; a hole must never break through the front.
usage: s23b_hole_caps.py cad.stl -> updates work/holes.json (bottom_cap, bottom)"""
import os, sys, json
import numpy as np
import open3d as o3d
from common import W

m = o3d.io.read_triangle_mesh(sys.argv[1])
sc = o3d.t.geometry.RaycastingScene(); sc.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(m))
H = json.load(open(os.path.join(W, "holes.json")))
for h in H:
    xs = [h["x"], -h["x"]] if h["kind"] == "R" else [h["x"]]
    ext = []
    for x in xs:
        # exterior under the hole rim (4 rays on the hole circle + 0.3) so the hole itself does not hide it
        r = h["d_design"] / 2 + 0.3
        for a in np.linspace(0, 2 * np.pi, 8, endpoint=False):
            ray = np.array([[x + r * np.cos(a), h["y"] + r * np.sin(a), -300.0, 0, 0, 1]], np.float32)
            t = sc.cast_rays(o3d.core.Tensor(ray))["t_hit"].numpy()[0]
            if np.isfinite(t):
                ext.append(-300.0 + t)
    if ext:
        cap = max(ext) + 0.8
        old = h["bottom"]
        if old is None or old < cap:
            h["bottom"] = round(float(cap), 2)
        h["bottom_cap"] = round(float(cap), 2); h["bottom_scan"] = old
        print(f"{h['kind']} ({h['x']:.1f}, {h['y']:.1f}) top {h['top']} scan bottom {old} cap {cap:.2f} -> {h['bottom']}")
json.dump(H, open(os.path.join(W, "holes.json"), "w"), indent=0)
