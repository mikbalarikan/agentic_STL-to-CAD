"""Dominant plane normals: area-weighted 1-deg histogram of face normals (azimuth/elevation), peaks, then for each
peak direction the offset levels (planes) along it. Raw scan frame."""
import os
import numpy as np
from scipy.ndimage import maximum_filter
from common import W

c = np.load(os.path.join(W, "tri_c.npy")).astype(np.float64)
n = np.load(os.path.join(W, "tri_n.npy")).astype(np.float64)
a = np.load(os.path.join(W, "tri_a.npy")).astype(np.float64)
az = np.degrees(np.arctan2(n[:, 1], n[:, 0])); el = np.degrees(np.arcsin(np.clip(n[:, 2], -1, 1)))
H, xe, ye = np.histogram2d(az, el, bins=[np.arange(-180, 180.5, 1.0), np.arange(-90, 90.5, 1.0)], weights=a)
pk = (H == maximum_filter(H, size=7)) & (H > 20)
ii, jj = np.nonzero(pk)
order = np.argsort(-H[ii, jj])
for k in order[:30]:
    A_, E_ = xe[ii[k]] + 0.5, ye[jj[k]] + 0.5
    d = np.array([np.cos(np.radians(E_)) * np.cos(np.radians(A_)), np.cos(np.radians(E_)) * np.sin(np.radians(A_)), np.sin(np.radians(E_))])
    m = n @ d > np.cos(np.radians(4))
    s = c[m] @ d
    h, e = np.histogram(s, bins=np.arange(s.min() - 0.5, s.max() + 0.5, 0.1), weights=a[m])
    top = np.argsort(-h)[:3]
    print(f"az {A_:7.2f} el {E_:6.2f} dir {np.round(d,4)} area {H[ii[k], jj[k]]:7.0f}  levels", [(round(e[t] + 0.05, 2), round(h[t])) for t in top])
