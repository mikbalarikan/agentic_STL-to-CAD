"""Face statistics of a STEP: count per surface type, B-spline pole counts (largest), offset surfaces."""
import sys, collections
from OCP.STEPControl import STEPControl_Reader
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE
from OCP.BRep import BRep_Tool
from OCP.TopoDS import TopoDS
from OCP.GeomAdaptor import GeomAdaptor_Surface
r = STEPControl_Reader(); r.ReadFile(sys.argv[1]); r.TransferRoots(); sh = r.OneShape()
ex = TopExp_Explorer(sh, TopAbs_FACE)
cnt = collections.Counter(); poles = []; surfs = set()
while ex.More():
    f = TopoDS.Face_s(ex.Current()); s = BRep_Tool.Surface_s(f)
    a = GeomAdaptor_Surface(s); t = str(a.GetType()).split(".")[-1]; cnt[t] += 1
    if t == "GeomAbs_BSplineSurface":
        b = a.BSpline(); poles.append(b.NbUPoles() * b.NbVPoles())
    ex.Next()
print(cnt)
poles.sort(reverse=True)
print("bspline faces", len(poles), "total poles", sum(poles), "largest", poles[:15])
# edges: curve types and B-spline pole totals
from OCP.TopAbs import TopAbs_EDGE
from OCP.BRepAdaptor import BRepAdaptor_Curve
ex = TopExp_Explorer(sh, TopAbs_EDGE); ec = collections.Counter(); ep = []
while ex.More():
    e = TopoDS.Edge_s(ex.Current())
    try:
        c = BRepAdaptor_Curve(e); t = str(c.GetType()).split(".")[-1]; ec[t] += 1
        if t == "GeomAbs_BSplineCurve":
            ep.append(c.BSpline().NbPoles())
    except Exception:
        ec["err"] += 1
    ex.Next()
print("edges", ec, "bspline edge poles total", sum(ep), "largest", sorted(ep, reverse=True)[:10])
