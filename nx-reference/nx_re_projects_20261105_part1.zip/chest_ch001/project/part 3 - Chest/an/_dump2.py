import json, sys, math
d = json.load(open(sys.argv[1])); lo, hi = float(sys.argv[2]), float(sys.argv[3])
for r in d:
    P = r["pts"]
    if len(P) in (2, 3):
        a, b = P[0], P[1]
        if lo <= abs(a[0]) <= hi and abs(a[0] - b[0]) < 0.03 and abs(a[1] - b[1]) > 1:
            print("V", len(P), [round(c, 3) for c in a], [round(c, 3) for c in b])
    if len(P) == 4 and lo - 60 <= abs(P[2][0]) <= hi:
        print("ARC", [round(c, 2) for c in P[2]], "r", round(math.dist(P[2], P[0]), 2), [round(c, 2) for c in P[0]], [round(c, 2) for c in P[1]])
