import json
d = json.load(open("../work/plateaus.json"))
for f in d["feats"]:
    print(f["level"], f["kind"], f["iou"], f["area_mm2"], f["bbox"], len(f["loops"]), [l["circle"] for l in f["loops"] if l["circle"]])
