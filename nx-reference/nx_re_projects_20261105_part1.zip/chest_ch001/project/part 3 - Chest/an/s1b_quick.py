"""Fast vertex-clustering copy of the main shell (voxel arg, default 0.7 mm) -> work/scan_vc.ply + shaded views."""
import os, sys
import numpy as np
import open3d as o3d
import pyvista as pv
from common import W

VOX = float(sys.argv[1]) if len(sys.argv) > 1 else 0.7
d = np.load(os.path.join(W, "main.npz"))
m = o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(d["v"].astype(np.float64)), o3d.utility.Vector3iVector(d["f"]))
md = m.simplify_vertex_clustering(VOX, o3d.geometry.SimplificationContraction.Quadric)
md.remove_degenerate_triangles(); md.compute_vertex_normals()
o3d.io.write_triangle_mesh(os.path.join(W, "scan_vc.ply"), md)
print("vc tris", len(md.triangles), flush=True)
pm = pv.read(os.path.join(W, "scan_vc.ply"))
c = np.array(pm.center)
views = {"pz": ((0, 0, 1), (0, 1, 0)), "nz": ((0, 0, -1), (0, 1, 0)), "px": ((1, 0, 0), (0, 1, 0)),
         "py": ((0, 1, 0), (0, 0, 1)), "ny": ((0, -1, 0), (0, 0, 1)),
         "iso1": ((1, -1, 1), (0, 1, 0)), "iso2": ((-1, 1, 1), (0, 1, 0)), "iso3": ((1, 1, -1), (0, 1, 0)), "iso4": ((-1, -1, -1), (0, 1, 0))}
for name, (dv, up) in views.items():
    p = pv.Plotter(off_screen=True, window_size=(1400, 1400))
    p.add_mesh(pm, color="lightsteelblue", smooth_shading=False, specular=0.2)
    p.add_axes()
    p.camera_position = [tuple(c + np.array(dv, float) / np.linalg.norm(dv) * 1100), tuple(c), up]
    p.camera.view_angle = 30
    p.screenshot(os.path.join(W, f"view_raw_{name}.png")); p.close()
print("views ok")
