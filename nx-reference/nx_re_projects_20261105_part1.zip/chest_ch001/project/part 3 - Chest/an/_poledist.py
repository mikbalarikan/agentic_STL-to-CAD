import sys, numpy as np
from OCP.STEPControl import STEPControl_Reader
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE
from OCP.BRep import BRep_Tool
from OCP.TopoDS import TopoDS
from OCP.GeomAdaptor import GeomAdaptor_Surface
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
r = STEPControl_Reader(); r.ReadFile(sys.argv[1]); r.TransferRoots(); sh = r.OneShape()
ex = TopExp_Explorer(sh, TopAbs_FACE); rows = []
while ex.More():
    f = TopoDS.Face_s(ex.Current()); a = GeomAdaptor_Surface(BRep_Tool.Surface_s(f))
    if str(a.GetType()).endswith("BSplineSurface"):
        b = a.BSpline(); g = GProp_GProps(); BRepGProp.SurfaceProperties_s(f, g)
        rows.append((b.NbUPoles() * b.NbVPoles(), g.Mass()))
    ex.Next()
R = np.array(rows); o = np.argsort(-R[:, 0]); R = R[o]
for lo, hi in ((10000, 1e9), (3000, 10000), (1000, 3000), (0, 1000)):
    m = (R[:, 0] >= lo) & (R[:, 0] < hi)
    print(f"poles {lo}-{hi}: faces {m.sum()}, poles {int(R[m,0].sum())}, face area {R[m,1].sum():.0f} mm2, median area {np.median(R[m,1]) if m.any() else 0:.1f}")
