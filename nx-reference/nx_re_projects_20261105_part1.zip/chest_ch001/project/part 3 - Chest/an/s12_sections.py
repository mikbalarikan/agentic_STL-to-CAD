"""Loft sections for NX from the radial skin fit: iso-q curves (q = const), p within psi <= PSI_MAX, each a clamped
cubic B-spline with poles (least squares on dense samples, chord-length parameter, uniform knots).
OFF > 0: the surface offset by OFF along the inward normal (toward C side, i.e. into the material) - inner skin.
usage: s12_sections.py DQ NP_PER_RAD OFF out_name -> work/<out_name>.json"""
import sys, os, json
import numpy as np
from scipy.interpolate import BSpline, make_lsq_spline
from common import W

DQ = float(sys.argv[1]) if len(sys.argv) > 1 else 0.035
NPR = float(sys.argv[2]) if len(sys.argv) > 2 else 30.0
OFF = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
NAME = sys.argv[4] if len(sys.argv) > 4 else "sections"
PSI_MAX = float(sys.argv[5]) if len(sys.argv) > 5 else 1.48
s = np.load(os.path.join(W, "skin_fit.npz"))
tk, CF, C = s["tk"], s["CF"], s["C"]
Sq = BSpline(tk, CF, 3)                 # along q (axis 0 of CF)


def dirs(p, q):
    psi = np.hypot(p, q)
    sn = np.sinc(psi / np.pi)
    return np.stack([p * sn, q * sn, -np.cos(psi)], -1)


def surf(p, q):
    """points (n,3) on the skin for arrays p, q (same q allowed)."""
    out = np.empty((len(p), 3))
    for qq in np.unique(q):
        k = q == qq
        coef_p = Sq(np.clip(qq, tk[3], tk[-4]))           # (nk,)
        r = BSpline(tk, coef_p, 3)(np.clip(p[k], tk[3], tk[-4]))
        out[k] = C + r[:, None] * dirs(p[k], q[k])
    return out


def surf_off(p, q, off, h=1e-4):
    X = surf(p, q)
    if off == 0:
        return X
    Xp = (surf(p + h, q) - surf(p - h, q)) / (2 * h)
    Xq = np.vstack([(surf(p[i:i + 1], np.array([q[i] + h])) - surf(p[i:i + 1], np.array([q[i] - h]))) / (2 * h) for i in range(len(p))])
    n = np.cross(Xp, Xq); n /= np.linalg.norm(n, axis=1)[:, None]
    # inward = toward the centre side (material side of the exterior skin)
    sgn = np.sign(((C - X) * n).sum(1))
    return X + off * sgn[:, None] * n


qs = np.arange(-1.42, 1.42 + 1e-9, DQ)
out = []
worst = 0.0
for q in qs:
    pm = np.sqrt(max(PSI_MAX ** 2 - q * q, 0.0))
    if pm < 0.2:
        continue
    p = np.linspace(-pm, pm, 1201)
    P = surf_off(p, np.full_like(p, q), OFF)
    L = np.r_[0, np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))]
    u = L / L[-1]
    NP = max(8, int(round(NPR * 2 * pm)))
    kn = np.r_[[0.0] * 4, np.linspace(0, 1, NP - 2)[1:-1], [1.0] * 4]
    spl = make_lsq_spline(u, P, kn, k=3)
    err = float(np.linalg.norm(spl(u) - P, axis=1).max())
    worst = max(worst, err)
    out.append(dict(q=float(q), poles=spl.c.tolist(), knots=kn.tolist(), err=err))
json.dump(dict(DQ=DQ, OFF=OFF, sections=out), open(os.path.join(W, NAME + ".json"), "w"))
allp = np.array([p for o in out for p in o["poles"]])
print(NAME, "sections", len(out), "poles", [len(o["poles"]) for o in out[::10]], "max lsq err", round(worst, 4),
      "pole bbox", allp.min(0).round(1), allp.max(0).round(1))
