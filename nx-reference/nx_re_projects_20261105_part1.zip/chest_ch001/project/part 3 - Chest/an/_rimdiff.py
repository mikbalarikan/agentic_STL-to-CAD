import os, numpy as np
from common import W
Z = np.load(os.path.join(W, "rv", "zones400k.npy"))
a = np.load(os.path.join(W, "dev2_C5_scan2cad.npy")); b = np.load(os.path.join(W, "dev2_C7_scan2cad.npy"))
P = b[:, :3]; d5, d7 = np.abs(a[:, 3]), np.abs(b[:, 3])
m = Z == 2
print("rim C5 %.3f C7 %.3f" % ((d5[m] <= .5).mean(), (d7[m] <= .5).mean()))
worse = m & (d5 <= .5) & (d7 > .5); better = m & (d5 > .5) & (d7 <= .5)
print("worse", worse.sum(), "better", better.sum())
key = np.floor(P[worse][:, :2] / 10).astype(int)
u, c = np.unique(key, axis=0, return_counts=True)
for k in np.argsort(-c)[:12]:
    print(u[k] * 10, c[k], "mean z", round(float(P[worse][(key == u[k]).all(1)][:, 2].mean()), 1), "d7 sign", round(float(np.median(b[worse][(key == u[k]).all(1)][:, 3])), 2))
mi = Z == 3
print("interior C5 %.3f C7 %.3f" % ((d5[mi] <= .5).mean(), (d7[mi] <= .5).mean()))
w2 = mi & (d5 <= .5) & (d7 > .5)
key = np.floor(P[w2][:, :2] / 20).astype(int); u, c = np.unique(key, axis=0, return_counts=True)
print("interior worse", w2.sum(), "better", (mi & (d5 > .5) & (d7 <= .5)).sum())
for k in np.argsort(-c)[:12]:
    print(u[k] * 20, c[k], "d7 med", round(float(np.median(b[w2][(key == u[k]).all(1)][:, 3])), 2))
