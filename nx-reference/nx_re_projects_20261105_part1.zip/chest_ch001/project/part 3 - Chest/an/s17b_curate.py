"""Curated plateau levels (s17a candidates minus the sloped inset-panel interior -132.4..-126.4, -125.1..-123.7 and the
sloped -41.5..-39.9 run; rim bosses at the rim plane 0.0). Writes work/levels.json."""
import os, json
from common import W
L = [-125.57, -124.57, -123.17, -122.77, -122.42, -121.72, -120.82, -118.12, -114.47, -106.77, -99.62, -93.72, -92.82,
     -90.87, -86.57, -84.92, -83.12, -81.92, -80.92, -79.42, -77.22, -74.92, -71.62, -66.82, -63.42, -54.62, -53.12,
     -42.92, -19.72, 0.0, 1.68, 2.53]
json.dump(dict(levels=L), open(os.path.join(W, "levels.json"), "w"))
print(len(L))
