# CH-001 Rev A Chest: status

## RESTART 2026-10-30 (session 5): clean feature-based rebuild from Rev A (outB12)
The user REJECTED rounds 2-4 (outC5..outC16p): stepped 0.7 mm pads, contour terraces and scan-traced pad / plateau
outlines ("lego", "broken into pieces"). The first delivery (outB12) was better. New rule: clean design-intent
features only (walls, ribs, gussets, bosses with holes, tubes, slot patterns, pockets, latch, hooks, ledges,
fillets), round values, Mirror for symmetric features; whatever deviation results is accepted.
- Round 2-4 deliverables MOVED (not deleted) to `_rounds2-4_2026-10-30/` (deliver/, CH-001_RevA_Chest.zip,
  CLIENT_MESSAGE.txt, HANDOFF_session4.md). nx/out* folders kept.
- Plan: `CLEAN_PLAN.md`; build `nx/build_clean.py` (Rev A stage A, then clean features from
  `work/clean/features.json`). Part stays Rev A. Nothing sent to the client.
- Progress of this restart: see the section "Session 5" below.

## Session 5 (2026-10-30, clean rebuild) - DONE (delivery ready, waiting for the lead's review; nothing sent)
- Archive done; baseline review chain on outB12 -> review_2026-10-30/data_B12 (r1: whole 71.79 %, skin 92.91,
  shoulder 80.75, rim 57.20, interior 58.72 within 0.5 mm).
- Survey of the scan interior (CAD-free): an/clean_relief.py (white top-hat relief tiles), an/clean_tile.py
  (hillshade + Rev A plateaus), an/clean_rib.py (rib centre / width / flat top along a line), an/clean_boss.py
  (boss OD / top / hole), an/clean_recess.py + work/clean/m_sv*.py (exterior pockets: outline, depth, floor
  planes). Tiles in work/clean/scanmaps/. Ribs are flat-topped, 1.3-1.55 wide -> t 1.5.
- Decision: Rev A's 78 plateau loops are themselves scan-traced (spiky tips, horn shapes) -> ALL interior features
  are rebuilt as clean primitives; only Rev A stage A (skin, shell, panel, holes, bore, bottom, notches) + the
  styling groove are kept. work/clean/make_spec.py -> features.json (80 rows); plan check
  work/clean/scanmaps/spec_plan.png (spec drawn over the scan hillshade).
- NX: nx/build_clean.py (stage A = build_revA_B12.py lines 1-256, stage F R features -> Mirror -> stage G C/A
  features) + nx/clean_feat.py (rib / rect / poly / cyl / cone / hole / constant-wall pocket / slot Pattern Feature).
- outD1 (19:58, 4 min): PASS, 1 solid, 724 faces. Gates (review_2026-10-30/data_D1): whole 72.81 / rim 64.73 /
  interior 60.07 / skin 92.99. Sections (work/clean/sec_hooks.png): hooks came out as wedges (the G3 roof planes are
  wrong: real shape = flat lip -77.2 + a barb along the outer edge); corner post cylinder left a thin slit to the
  wall; F04 cones / side tubes started at z -30 / -50 = hanging bases; latch bores went through (-79.3).
- outD2: hooks = hook_base block + hook_barb rib with a 1.33 mm/mm top plane; bottom rail y -265.7; neck ledge
  (y 34..42, |x| < 39, top -92.8); corner_web block to the outer wall; cones from z -60; latch bores to -75; the two
  F28 ledges replaced by one rim_band (inner face = 2 straight lines, scan z -1.5 / -5 sections). PASS, 720 faces,
  no feature errors. Gates: whole 73.62 / rim 70.59 / interior 61.10 / skin 92.99.
- outD3 (= FINAL MODEL): + P_upper_vent (exterior recess 3.3-3.9 deep at the upper vent row, scan wall there 3.2 =
  constant wall, built on the right half with the outline 6 mm past the mid-plane, floor plane per half resid
  +-0.7), arch_rib (R22.6 about the hole centre, t 1.8, top -122.8) + 2 arch legs, scoop_band (flat top -19.7, straight
  inner edge). PASS, 1 solid, 762 faces, 91 / 91 features OK, body_ok, no feature errors, build 2.7 min.
  Gates (data_D3): whole 74.42 / rim 70.59 / interior 62.48 / skin 93.07 / shoulder 79.20 (Rev A outB12: 71.79 /
  57.20 / 58.72 / 92.91 / 80.75). Openings: 5 = the same 5 Rev A skin-outline offsets (bottom corners (+-68, -273),
  R-only flare (108, -225.8), shoulder top corners (+-138.4, 83)): the Rev A loft lies 2-7 mm inboard of the scan's
  outer face there; they are not holes through a wall (sections work/clean/sec_b.png). Thin >= 20 mm2: 4 = the
  shoulder-pocket upper lip (35 deg edge where the drafted pocket wall meets the skin) and the neck-edge knife
  (Rev A shell; B12 has it too). Remaining big clusters: PCB board (left out), side scoop rails (F21, left out),
  scan-filled deep bores (scanner cannot see narrow bores; not an error).
- Finalize of outD3 -> deliver/CAD (20:28-20:31, nx/fin_D3.log). NOTE: run_journal.ps1 via Start-Process -File
  drops the 2nd JArg; call it with `& run_journal.ps1 -JArgs "a","b"` from PowerShell.
- DELIVERY READY (20:45), nothing sent:
  - deliver/CAD: 1 solid, Examine all 0, body_ok, 593 434 mm3 (1.60 kg Al 6061), 762 faces; exact bbox x +-166.889,
    y -275.6..115.43, z -140.127..2.5; files prt 36.0 MB, AP214 20.3 MB, AP242 7.7 MB, x_t 3.8 MB, STL 34.9 MB.
    stepcheck (work/stepcheck_revA.log): AP214 / AP242 1 valid solid each, 762 faces.
  - dev2 (work/dev2_clean.json) within 0.5: whole 74.45 / skin 93.08 / shoulder 79.32 / rim 70.55 / interior 62.52;
    Rev A outB12 same tool (work/dev2_B12full.json): 71.80 / 92.92 / 80.75 / 57.33 / 58.74.
  - deliver/QA: REPORT_deviation.md (method + remaining-deviation sections rewritten for the clean model, Rev A
    comparison line), deviation_map_*.png. deliver/Renders: an/render.py set. CAD-alone check views work/clean/rFinal.
  - Drawings: nx/dwg_chest_clean.py + nx/dwg_annot_clean.py (= round-4 drawing scripts dwg_chest.py / dwg_annot.py with
    the clean hole table work/clean/holes_clean.json, vent rows from features.json, note 4 "RIBS 1.5", 8 hole-pitch
    dims, table 6.4 mm rows). Final run work/dwgD3d: PASS, 18 dims (all equal to the design values), 38 balloons,
    0 leader crossings, every sheet rasterised and checked (work/dwgD3d/png_p1..4.png).
  - deliver/README.md (15 simplification items), CH-001_RevA_Chest.zip 68.3 MB (testzip OK), CLIENT_MESSAGE.txt.
- LEAD REVIEW 1 (21:00): (1) SH4 balloons on / touching the outline, H11-H12 touching, H14 next to the 35.00 text,
  long leaders; check SH2 / SH3 the same way. (2) knife-edge rib ends.
  - Rib ends: work/clean/rib_ends.py + rib_prof.py (rib height above the higher side wall from the D3 CAD ZI map):
    rib_y12 ends (x +-60..66), rib_x66 top end (y 12.75..10.8) and rib_y-20 outer end (x 90.3..92) were < 1 mm.
    Trimmed square where the rib stands 1.0 mm: rib_y12 x -59.5..59.5, rib_x66 from y 10.8, rib_y-20 to x 90.3. The
    y -28.6 rib (>= 2.3 at its ends) and the neck rib (merges level into the neck ledge) needed nothing.
    -> nx/outD4 (PASS, 765 faces, 91/91 features), finalized into deliver/CAD (Examine all 0, 593 405 mm3; AP214
    19.8 MB, AP242 7.5 MB, x_t 3.8 MB, prt 35.9 MB, STL 35.0 MB). dev2: whole 74.44 / skin 93.08 / shoulder 79.32 /
    rim 70.55 / interior 62.50. stepcheck 1 valid solid each, 765 faces.
  - SH4: one ID per hole group (mirrored pair = QTY 2, X +-), table 7 columns. Balloons planned offline:
    work/clean/plan_balloons.py (free space = outside the CAD plan silhouette from the depth maps + every STL vertex,
    4 mm clearance, keep-out for the pitch dims and their extension lines) + plan_balloons2.py (Hungarian assignment
    on leader length, no crossings, no leader through a balloon); groups that cannot get a leader <= 50 mm (H4-H10,
    H14, H17, H18: central bosses) carry no balloon, they are located by X / Y in the BASIC table (note on SH4);
    fix_h15.py puts H15 in a quadrant of the front hole (off its centre lines), fix_h21.py moves H21 6 mm off H22.
    NX ID symbols are anchored at the stub end: dwg_annot_clean.balloon_side() sets the stub side toward the hole
    and offsets the anchor by (0.29 + 1.75 x characters, -2.26) mm (calibrated on the PDF vectors, bal_cal.py:
    every circle now within 0.2 mm of plan). 12 balloons, leaders 20-50 mm. P_H24_H25 pitch dropped (the front hole
    now holds H15): 17 dims.
  - SH2: D37.40 frame placed free right of the right extension line (stacked below it sat on the dimension line);
    text moved between the extension lines. SH3: D111 frames placed free above their text, datum B / C stacked beside
    the frame (stacked below they sat on the leader underline; NOTE: StackAlignmentPosition.Above on a dimension
    moves the dimension itself - do not use). SH1: H 391.04 moved 30 mm out (it crossed the flatness frame), notes
    9 mm lower. Final drawings work/dwgD4k, all 4 sheets checked at 120 dpi -> deliver/Drawings.
  - REPORT / README / CLIENT_MESSAGE numbers updated (work/clean/upd_docs.py), zip rebuilt 67.9 MB (testzip OK).
    Nothing sent.
- LEAD REVIEW 2 (22:30): balloons must sit OUTSIDE the outer silhouette, in white space beside / above / below the
  part (H15, H16, H12, H20-H22 were inside; H11, H13 touched the wall). Done:
  - work/clean/plan_balloons_out.py <maps> H4,H5,H6,H7,H8: balloon centres only outside the part's plan bounding box
    + 11.5 mm, inside the frame, clear of the pitch dimensions (dim line = text anchor - 7.53, measured on the PDF)
    and their extension lines; 22 mm spacing (circle + two stubs); leaders measured from the NX stub end; cost =
    leader length + 20 per dimension line crossed / run along / hole passed over; Hungarian + swap / move repair.
    work/clean/check_bal.py = independent check (crossings, leader gaps, leaders passing within 3 mm of a hole).
  - The upper vent row H4-H8 (8 bosses 5 mm apart) is ballooned on a new DETAIL G (2:1, rectangle by corners,
    NX enum DetailViewBuilder.Types.RectangleByCorners) right of the main view; balloons alternate above / below
    the detail with short vertical leaders (dwg_annot_clean.py, "det" groups).
  - Final layout = the dwgD6b plan with H19 moved 12 mm left (work/clean/restore_d6b.py; a later planner run was
    worse). Drawings work/dwgD6c: PASS, 17 dims, 22 balloons (17 on the main view, 5 on detail G), every circle
    outside the silhouette, no crossings; all 4 sheets checked at 120 dpi -> deliver/Drawings; README line updated;
    zip rebuilt 67.9 MB (testzip OK). Nothing sent.


## Session 4 (2026-10-30, from ~04:00) - DONE, round 5 (lead: F07 corner, neck notches, 4 openings) = HANDOFF.md top
Lead decisions (see the lead's brief): F27 wins over "skin >= outC8" -> new skin gate OUTSIDE the warp box
(|x| 80..140, y -260..-140) >= outC8 in the same mask; shoulder_bump must be built; extra openings 0 (incl. F13 pill);
thin gate = 0 clusters >= 20 mm2 where the scan wall >= 1.2 (incl. shoulder-vent floor), smaller ones counted + top-10
crops; F15b / neck chamfer / other "not modelled" = documented simplifications; F17 on hold; file size option (a).
- Gate script for these rules: `review_2026-10-30/gate_c12.py data_<tag> [...]`. outC8 skin outside the warp box 98.83 %,
  inside 83.19; outC11 97.34 / 83.03 -> the outC11 skin loss is NOT the warp: mostly the shoulder_bump (CAD 0.7 short,
  x +-80..160, y 60..100), then scoop-bump edges, lower-vent / upper-vent slot-band edges, bottom edge strips.
- Thin clusters on outC11: 80 >= 20 mm2. Sections `review_2026-10-30/secs/s4_thinA.png`, `s4_thinB.png`: almost all are
  SAW-TOOTH TIPS of the 0.7 mm stepped pads (Z-prism risers on skin-parallel treads -> 45 deg knife edges, each tooth
  < 0.6 thick), plus a few real slits (rim ledge (+-126.8,-151.5): two 4 mm deep slits) and single fins. Asked the lead
  (A: teeth = A2 residue, fix slits/fins/open + vent floor; B: smooth interior tools everywhere). Answer pending.
- shoulder_bump: valid with smoothing SIG 2.5 / BSIG 3.0 (new env C10_BSIG smooths the CAD skin map) / SP 2.0
  (nx/outT12a: body_ok True, 6 345 mm3); SIG 1.5 still invalid. work/c10/sheets.json now has shoulder_bump(+_L) from
  work/c10/st_s25.json (old file: sheets_C11.json; old script: an/c10_sheets_C11.py).
- Openings: `an/s40_plugs.py <review data>` -> work/c12/plugs.json: one prism per extra opening (outline = CAD opening
  cells dilated 0.75 minus scan openings; rim strips: bottom plane fitted to the scan outer face, top z 0; holes / slit
  ends: between planes fitted to scan exterior and interior). build.py stage P unites them after every cut.
  Causes seen in sections (secs/s4_openA.png, s4_openB.png): F13 pill = the panel-line groove recess crossing the
  mid-plane (recess_half core is offset off x = 0); bottom / shoulder-corner / (108,-225.8) = CAD wall face 1.5-2.5 mm
  inboard of a scan flare at the rim; (+-58.8,-271.7) / (+-60.2,-260.3) = ends of F07_slit; (37.1,-207.1) = lower-vent
  pocket cut through the box wall corner.
- Shoulder-vent floor: smooth interior floor tool `an/s41_floor.py` -> work/c12/floor.json (Z prism between scan
  exterior + 0.6 and scan interior, bosses / slots inpainted) + pads off there (work/c10/G4.json pad_zone; s31 re-run,
  old pads: work/c12/pads_C11.json). build.py stage H2b unites it after the pockets. First NX test (outT12b): lo trim
  failed (steep lo at the outline) -> lo now from floor cells only, extended flat.
- build.py backup before session 4: nx/build_C11.py.
- outC12 (built 2026-10-30 12:13, 58 min incl. checks; PASS, 1 solid, body_ok True, 721 528 mm3). NOTE the launcher kills
  at 900 s by default: always pass `-TimeoutSec 7200` to run_journal.ps1 for build.py. Gates (data_C12/GATES12.txt):
  whole 89.77, rim 90.18, interior 86.63, skin outside warp box 98.34 (outC8 98.83, WORSE), full skin 95.78, inside box
  83.03; extra openings 6 (rim-strip plugs failed: a steep plane fitted to a flared wall -> trim fails), scan openings
  missing 6 (the floor tool filled the shoulder-vent slots: they are cut in stage F), thin >= 20: 80 (teeth).
  outC12p (post_plugs.py on outC12 with fixed rim plugs) failed the same way -> discarded.
- outC13 (running from ~12:50): floor tool now an H1 unite (in sheets.json) with lo 1 mm OUTSIDE the scan floor so the
  shoulder_vent pocket trims it exactly; region = recessed > 1 mm and slope < 45 deg (steep region made the hi trim fail,
  outT13a; outT13b OK 2 153 mm3); shoulder-vent slots + end holes re-cut after the pockets (both sides);
  recess_c10.json + outC8 level-0 loops 3 and 5 (the two symmetric lower-panel recess bands: blue on BOTH sides in the
  skin map, so a real feature, not the antisymmetric warp; backup work/c12/recess_c10_C12.json); bottom-strip wedge plug
  S_bottom_strip (R) instead of the auto rim plugs; plugs_manual.json also has the F28 ledge slit plugs and the
  lower-vent upper-wall plug. Still open: (108,-225.8) R-only rim flare inside the warp box (asymmetric -> warp, left
  open per decision 1 unless the lead says otherwise); scoop-bump edge skin (+0.5, (+-120..140,-120)).
- outC13 (PASS, body_ok, 717 619 mm3; data_C13/GATES13.txt): whole 89.71, rim 87.57 (!), interior 87.15, skin outside
  warp box 98.41, full 95.11, inside box 78.61 (!); openings 7, scan openings missing 0 (slot re-cut works), thin>=20 79.
  The restored recess bands (outC8 loops 3, 5) cut through the lower side wall at the rim ((124.6,-174.8) 56.7 mm2,
  (-116.6,-200.3), (-133.1,-143.5)) and cost rim / in-box skin -> REVERTED (recess_c10.json = recess_c10_C12.json).
  Remaining skin-outside losses (vs outC8, data_C13): shoulder-vent pocket upper lip (+-80..100, 80..85, z -44: the scan
  has a 3 mm lip along the pocket's upper edge and a floor 1-2.5 mm thinner there; the smooth pocket sheet (since outC10)
  rounds it off; secs/s4_c13vent.png panel 1) ~2.7 k vertices; scoop-bump edges (+-100..140,-140..-100) ~4 k (wider /
  sharper scoop_bump variants all failed the NX hi trim: outT13c-e); bottom strips (+-60..80,-280) partly.
  Floor cluster (100.4,69.4,-45.4) 395 mm2 in outC13 = wedge / knife between the floor tool's vertical side (y 67.7) and
  the pocket wall (pads were off there) -> outC14: pads kept 3 mm under the tool edge (G4 pad zone eroded 12 px).
- outC14 (running from ~14:05): outC13 - recess bands + pad-zone fix + bottom-strip plug widened / 0.3 further out.
  Next: gates (bash run_c10.sh C14; gate_c12.py data_C14), then finalize chain (unless the lead's teeth answer is B).
- outC14 (PASS, 721 604 mm3; data_C14/GATES14.txt) = DELIVERY CANDIDATE: whole 89.87, rim 90.30, interior 86.83,
  skin outside warp box 98.31 (outC8 98.83: still -0.52), full 95.76, inside box 83.03 (83.19); extra openings 4:
  (+-66.3,-274.5) 4 mm2 bottom strip (plug wedge not quite at the flare), (108,-225.8) 9 mm2 R-only rim flare inside the
  warp box, (133.8,85.9) 3 mm2 R-only shoulder corner; scan openings missing 0; thin >= 20: 73 (teeth), 5..20: 105.
  Shoulder-vent floor fixed (2.5-3.5 mm like the scan, secs/s4_c14floor.png); its remaining cluster (+-109,70.5) is a
  chain of pad tooth tips along the floor-tool edge. Finalize to deliver/CAD started ~15:35 (nx/fin_C14.log).
  Lead's teeth question still unanswered -> delivering as option A, saying so in the report.
- outC14 finalized to deliver/CAD (14:38): Examine all 0, body_ok True, 717 659 mm3; files AP214 206 MB, AP242 81 MB,
  x_t 281 MB, prt 346 MB, STL 63 MB. BUT fin_bbox found z max 10.4: the plugs P_open_+-60_-260 got a top plane from a
  poor ZI fit -> 0.5 mm spikes up to z +9 above the rim at (+-60.5,-262.3) (also in outC12/C13; secs/s4_c14spike.png).
  Fixed by nx/post_plugs.py (now also cuts op "subtract" features) with work/c12/cut_spikes.json -> nx/outC14p
  (PASS, body_ok, 721 616 mm3, STL z max 2.55); plugs.json now clamps z1 <= 0 and clips env for later builds.
  Re-finalize from outC14p started ~15:20 (nx/fin_C14p.log); gates on outC14p running (data_C14p/GATES14p.txt).
  stepcheck on the outC14 STEPs: 1 solid each, valid, 9 436 faces, but OCP volume 757 k vs NX 717 k (5.5 % high;
  AP214 'Unresolved Reference: Fails Count 1') - re-check on the outC14p STEPs, compare with an OCP volume of
  the outC8 STEP if this persists.
- Drawings: nx/dwg_chest.py ran on the outC14 model -> work/dwg8 (PASS, 0 balloon crossings, SH1 checked by eye OK;
  note 7 'overall size ... 149.9' included the spikes) -> re-run on the final prt to work/dwg9, rasterise, check, copy.
- Small thin clusters (5..20 mm2) on outC14: 105; top-10 crops review_2026-10-30/secs/c14_small_a.png / _b.png
  (r13_smallthin.py). Mostly pad tooth tips. Not teeth: the bottom corner posts (F07, (+-59..67, -262..-270, z 0..-8)):
  the CAD has an internal keyhole void (F07_slit, closed by a 0.8 mm cap) and serrated fins in plan that the scan does
  not show (secs/s4_c14slot.png) -> open item (corner needs a remodel from z sections), and (+-66.8,-268.2) gap.
- FINAL MODEL = nx/outC14p, finalized into deliver/CAD (~15:15): Examine all 0, body_ok True, 717 653 mm3,
  bbox x +-166.889, y -275.6..113.851, z -139.503..2.55; AP214 / AP242 re-read by OCP: 1 valid solid each, 9 426 faces
  (OCP GProp volume 757 k is wrong on this body; OCP mesh volume of the AP242 = 718 506, +0.12 % vs NX; noted in the
  report). dev2 (3 M pts, work/dev2_revA.json): whole p50 0.086 / 89.9 %, skin 0.061 / 95.8 %, shoulder 80.9, rim
  90.3, interior 86.9. Review gates on the same geometry: review_2026-10-30/data_C14p/GATES14p.txt (outC8 printed
  next to it). deliver/QA report + maps, deliver/Renders, deliver/README.md (an/readme_c14.py: numbers + new
  simplification list 1-7) and CLIENT_MESSAGE.txt updated. an/report.py: method text rewritten, the 0.06 share is
  computed (backup an/report_C8.py).
- Drawings: work/dwg9 on the final prt: SH2 had the D37.40 dimension on the sheet frame and detail-G extension lines
  running off the sheet; SH4 pitch text 62.96 over the hole outline. Fixed in nx/dwg_chest.py (secB 10 mm lower) and
  nx/dwg_annot.py (detail dims attached inside the detail; pitch text centred in the hole); backups *_C8.py.
  dwg10 failed (a cp1252 byte in a comment: NX reads the file as UTF-8) -> fixed -> dwg11 running.
  Then: rasterise + check, copy to deliver/Drawings, an/make_zip.py.
- Drawings final = work/dwg12 (detail G dropped: NX drew two of its section lines unclipped across SH2; its values are
  in the SH2 table; pitch text centred in the hole), PASS, 12 dims read back, 0 balloon crossings, all 4 sheets
  rasterised and checked (no text on part curves, balloons outside the part, letters A B C / D E F unique).
  Copied to deliver/Drawings. Zip rebuilt: CH-001_RevA_Chest.zip (553 MB, testzip OK). NOT SENT.

### SESSION 4 RESULT (for the lead)
| gate | outC8 | final (outC14p) |
|---|---|---|
| whole within 0.5 (all 7.41 M scan vertices) | 87.84 | 89.87 |
| rim | 86.24 | 90.30 |
| interior | 83.27 | 86.83 |
| skin OUTSIDE warp box (new gate) | 98.83 | 98.31 FAIL (-0.52) |
| skin full / inside warp box | 96.22 / 83.19 | 95.76 / 83.03 |
| shoulder | 79.96 | 80.80 |
| extra CAD Z-openings | 7 | 4 |
| scan openings missing in CAD | 2 | 0 |
| thin clusters >= 20 mm2 (scan wall >= 1.2) | - (outC11 80) | 73-82 (random sampling), all pad tooth tips |
| one solid / NX Examine | BodyConsistency 1 | 1 solid, all 0 |
Open: (1) skin outside box: shoulder-vent pocket lip, scoop-bump edges, bottom strips; (2) openings: (+-66.3,-274.5)
4 mm2 bottom strips, (108,-225.8) 9 mm2 R-only rim flare in the warp box (left open, decision 1), (133.8,85.9) 3 mm2
R-only shoulder corner; (3) teeth = option A (question to the lead unanswered); (4) F07 bottom corner posts: internal
keyhole void under a 0.8 mm cap + serrated fins + (+-66.8,-268.2) gap (secs/s4_c14slot.png) - real, not fixed;
(5) F17 on hold; files option (a): AP214 206 MB, AP242 81 MB, x_t 281 MB, prt 346 MB.

### Lead decision (A) round, 2026-10-30 ~15:50-16:40
Lead: teeth = A2 residue (count, area, top-10 crops in STATUS + README); fix every real slit / single fin / open spot
(incl. rim ledge slits and vent floor); smooth teeth locally where they show through openings or sit on rim / mating
faces; no (B) this round (list (B) in the README only if the gates pass - they do not, skin-outside still -0.52).
- Classified with sections secs/k1.png .. k6.png (data_C14p thin list: 82 >= 20 mm2, 7 738 mm2). Fixed as P-stage
  features applied by nx/post_plugs.py (now also op subtract), no rebuild: outC14p -> outC15p (plugs_c15.json) ->
  outC16p (plugs_c16.json); all in work/c12/plugs_manual.json for future builds (build.py P stage honours op):
  rim ledge slit (+-127.1,-147.8) [S_ledge_slits_top widened], rim void (+-131.1,-132.4) [S_rim_void_132], fin slits
  (+-131.7,-127.6) [S_rim_fins_127, cut plane on the scan face], upper-vent cross-rib slit (+-12,-32) [S_upvent_slit_32],
  side fins (+-144.9,-83.9) cut to the plateau [X_side_fins_145]. Verified in sections (secs/k5.png, k6.png).
- Shoulder-vent floor: thickness already = scan (outC14). The remaining teeth beside its slots sit on the foot of the
  steep pocket wall (slope > 45 deg); a wider floor tool gave the same outline (slope rule) and smooth tools on steeper
  walls fail the NX trim (outT13a) -> left as A2. The vent slot walls themselves cut the smooth floor tool (clean).
- Not fixed (open): neck V-notch slits (+-60.5,103..111, secs/k4.png: notch faces move along x, one plug plane cannot
  follow); F07 bottom corner posts (internal keyhole void, serrated fins, (+-66.8,-268.2) gap).
- outC16p finalized to deliver/CAD (16:40): Examine all 0, body_ok, 717 802 mm3. Gates data_C16p/GATES16p.txt: whole
  89.87, rim 90.37, interior 86.81, skin outside box 98.31 (FAIL vs 98.83), openings 4, thin >= 20: 69 (7 249 mm2),
  5..20: 107 (1 026 mm2). Top-10 crops: secs/c16_top_a.png, _b.png (= deliver/QA/thin_steps_top10_a/b.png).
  README item 8 'Interior steps' (an/readme_steps.py data_C16p).
- FINAL (supersedes outC14p): nx/outC16p in deliver/CAD; dev2 whole 0.086 / 89.9 %, skin 0.061 / 95.8 %, rim 90.4, interior 86.9; STEP mesh volume 718 668 (+0.12 %). Drawings work/dwg13 (layout identical to the checked dwg12) -> deliver/Drawings.
  README items 1-8 updated (8 = interior steps, counts from data_C16p), QA has thin_steps_top10_a/b.png. Zip rebuilt
  (553 MB, testzip OK). NOT SENT. (B) not listed in the README: the gates do not all pass.

## outC10 round (session 3, 2026-10-30) - IN PROGRESS (details HANDOFF.md top)
- Review fixes measured into work/c10/G1-G3.json (121 features: cones / cylinders / prisms with sloped tops / slots,
  17 plateaus, 11 openings, 7 holes removed, 9 pad zones). Smooth exterior tools (no terraces) for the lower and upper
  vent boxes, shoulder vents, side scoops, scoop and neck bumps (an/c10_sheets.py). Pads cross the mid-plane, overlap
  walls by 0.75 mm. params: bottom.notch_x 50 -> 38 (F06), shoulder flange_t 4.6 -> 4.35 (F26).
- Not done by design / open: F17 text (on hold, lead); F15b window floors (inner face varies +-5 mm, a flat cut would
  break the wall; window lips not modelled); shoulder bump smooth tool invalid in NX -> skin left smooth there; neck
  chamfer stays one 0.7 step (smooth tool failed). F03 vent pocket prism from G3 skipped (smooth sheet does it).
- outC10 (built 2026-10-30 ~03:00, 1 valid solid, 714 520 mm3), gates (review scripts, all 7.41 M scan vertices):
  whole 88.78 % within 0.5 (outC8 87.84), rim 89.22 (86.24), interior 85.47 (83.27), shoulder 80.8 (80.0),
  skin 94.96 (96.22, WORSE: lower-panel warp no longer followed (F27) + shoulder bump not built);
  extra CAD Z-openings 11 (gate 0), thin clusters > 5 mm2 167 (gate 0). NOT deliverable yet.
- outC11 running (pad holes at slots closed, boss94 cap fix). HANDOFF READY: next steps in HANDOFF.md top.

## NEXT ROUND PLAN (2026-10-30, lead): review_2026-10-30/REVIEW.md must-fix F01-F14, F15a, F18, F28 + should-fix
## F15b, F19-F27 (F17 on hold); no exterior terraces; gates: review scripts, no false Z-through openings, r8_thin 0
## slit clusters > 5 mm2, zones >= outC8 (87.8 / 86.2 / 83.3 / 96.2 %), one solid + Examine 0. Zip + client text on
## hold. Details and state: HANDOFF.md (HANDOFF READY).

## REVISE round (session 2, 2026-10-29/30) - IN PROGRESS. deliver/CAD = build nx/outC8 (see below); drawings, QA,
## README and the zip are still the OLD Rev A

| Item | State |
|---|---|
| A1 ridge bands, A2 lower side brackets, A3 recessed boxes | built into nx/outC5 (running): stepped pads + exterior recesses + bumps |
| A4 rim band | built into outC5: rim tongue (+1.55/1.60) + rim/neck lips (pads) + exterior bumps |
| A5 neck tips | built into outC5: params neck.tip_pts (scanned outline, tip y 113.9) |
| A6 deviation / stepcheck / examine | open (after outC5) |
| B1-B4 drawings | code done, verified on the old model (work/dwg6): 16 dims read back, datums A/B/C, 0 balloon crossings |
| B5 rasterise | open (on the outC5 model) |
| C deliverables, zip, client text | open |

Method (details HANDOFF.md): interior wall thickness map (an/s30_tmap.py) -> work/pads.json (right half, levels
3.95..12.35 step 0.7, 123 loops: ridge bands, lower side pads with their pockets, rim/neck lips, box ramps; plateau
footprints excluded); exterior recess depth map (an/s32_extdepth.py) -> work/recess.json (right half, 0.7..13.3, 54
loops: shoulder vent boxes, LED box, side scoops, lower vent box, neck chamfer, panel-line grooves) and
work/bumps.json (16 loops: raised shoulder corners, scoop lips, neck sides); work/tongue.json (3 loops).
Test numbers so far: outT3 (5 pad levels, right half, no recess/tongue/openings): interior 58.4 -> 67.6 % within
0.5, rim 52.6 -> 67.6 %, exterior 94.0 -> 93.5 %, whole half 71.9 -> 77.4 %.
outC5 built (2026-10-29 22:32, 47 min; work/dev2_C5.json, 3 M points, before the deep-recess post-step):
whole p50 0.089 / 88.4 % within 0.5 (Rev A 0.111 / 71.8); exterior skin 0.063 / 96.2 % (92.9); rim 0.107 / 85.3 %
(57.3); interior 0.118 / 84.4 % (58.7); shoulder 0.080 / 80.0 % (80.7); CAD->scan p50 0.120, p95 2.20 (2.58).
Recess levels 7.0, 11.9, 13.3 (deep vent-box floors, 4 loops) failed the core offset and 2 recess tools failed to
subtract: nx/post_recess.py cuts the 3 levels on the saved part with Shell slabs (running, nx/outC5r).
- outC5r finalized into deliver/CAD (22:48) but NOT deliverable: Examine BodyConsistency 1 (body_ok False) and
  files exploded (AP214 352 MB, AP242 111 MB, x_t 421 MB, prt 432 MB; Rev A 22 / 10 / 7 / 40 MB): 19 400 faces
  (10 116 cylinders + 7 659 planes from ~7 800 outline segments fitted at 0.08 mm, each with dense intersection edges).
  s31_pads now fits outlines at 0.5 mm (FITTOL, resample 0.4, sigma 2 px, AMIN 20 mm2): 1 930 segments. recess_half
  slab fallback retries thickness +-0.05..0.3. Rebuild running: nx/outC6. deliver/CAD must be re-finalized from it.
- outC6 (stopped): FITTOL 0.5 broke things - 2 invalid sections, level 4.65 mask subtract failed (outlines within
  0.5 of each other / of the mid-plane face) and drop_crumbs kept the LARGEST solid = the leftover mask block. Fixed:
  drop_crumbs keeps the body by tag; a failed mask level deletes its leftovers and redoes the level with fresh
  prisms; s31 fits at 0.15 with a validity check (simple polygon, near the contour; refit 0.08 / 0.04), SEP 0.4
  (2 px), outlines kept >= 1.5 mm off the mid-plane (mask x < -2), plateau footprints + 3 px. 3 430 segments.
  Running: nx/outC7.
- MODEL NOW IN deliver/CAD (for the review session): build nx/outC8, finalized 2026-10-30 ~01:05. NOT final:
  NX Examine BodyConsistency 1 (one 0.15 x 0.6 x 1.1 mm sliver face at the right neck cut, x 55.5 y 96 z -37,
  found with nx/locate_bad.py; Delete Face cannot heal it). Accuracy outC8 (dev2 tag C8): whole 0.090 / 87.8 %,
  skin 0.063 / 96.2 %, rim 0.106 / 86.3 %, interior 0.121 / 83.3 %, shoulder 0.080 / 80.0 %.
  outC7 (valid, Examine all 0) had rim 84.5 % (< 85) and interior 82.0 %.
  Fix running: nx/outC9 (outlines touching / within 0.75 mm of the part edge extended 2 mm past it). Zip + client
  text on hold (lead). File size question with the lead, staying with "accept" for now.
Left after outC5: deviation (dev2 3 M points) and zone check against the targets, finalize -> deliver/CAD, examine +
stepcheck, report + maps + renders, drawings on the new model + raster check, README simplifications, zip, client text.

## Rev A as first built (before the REVISE round)

| Milestone | State | Date |
|---|---|---|
| Intake / frame | done | 2026-10-29 |
| Solid built | done (run `nx/outB12`, delivered as `deliver/CAD/CH-001_Chest.prt`) | 2026-10-29 |
| Deviation | done (`deliver/QA/REPORT_deviation.md`, 7 maps) | 2026-10-29 |
| Drawings | done (4 x A1, PDF + per-sheet PDF + DWG, `deliver/Drawings`) | 2026-10-29 |
| Zip + client text | done (`CH-001_RevA_Chest.zip`, `CLIENT_MESSAGE.txt`) | 2026-10-29 |

Nothing has been sent to the client.

## Checks passed

- One valid solid: NX Examine Geometry all 11 checks 0, no feature errors, 1 solid in the part (helper envelope deleted).
- Volume 610 097 mm3 (NX, accuracy 0.9999), 1.647 kg in Al 6061; NX STL of the solid watertight, 610 071 mm3.
- STEP AP214 and AP242 re-read with OpenCascade (`an/stepcheck.py`): 1 solid each, 1 679 faces, valid True
  (volumes +0.52 % / +0.66 % against NX).
- Extents of the CAD match the scan: X ±166.89 (scan -166.79 / +166.91), Y -275.60 (scan -275.60) to 115.43
  (scan 113.89: neck tips 1.5 mm long), Z -140.13 (scan -139.38) to 2.53 (scan 2.67).
- Deviation, scan -> CAD, 3 M points (full resolution): whole part p50 0.111 mm, p95 2.77, 71.8 % within 0.5;
  exterior skin p50 0.064, p95 0.61, 92.9 % within 0.5 (right 94.0 %, left 91.7 %: print warp);
  shoulder flanges p50 0.080, 80.7 %; interior p50 0.248, 58.7 %. CAD -> scan p50 0.113, p95 2.58.
- Drawings: all 6 dimensions created and read back against the model (391.04 overall, Ø37.40, Ø63.00, 323.30 basic,
  Ø111 H7 x 2), 6 GD&T items stacked (datums A, B, C, position frames), no view overlaps except section-line
  boundaries on SH2; sheets rasterised and checked by eye for text over geometry. DWG files are AC1018.

## Below the part 1 bar (for the lead)

Part 1 reached whole part p50 0.054 / 89 % within 0.5. The chest reaches 0.111 / 72 %. The exterior is close
(0.064 vs 0.021, limited by the print's left/right warp against the symmetric model). The gap is interior:
1-2 mm ridges behind the exterior panel lines (constant wall in CAD), root fillets, the recessed vent / LED boxes
(NX Shell refused the recess pockets), and the small lower-side brackets. Listed in README items 2-5.

## Intake (2026-10-29)

- Scan `share-Chest.stl`: 14 776 735 triangles, 7.44 M vertices after weld. Edge median 0.22 mm.
- Connected components: 2 119, but one main shell holds 14 733 629 faces (99.7 %); the rest are scan crumbs
  (largest 3 401 faces, 77 mm²). One part, so no question to the client. Modelled from the main shell only.
- Mirror symmetry (ICP of the reflected scan onto itself): plane tilted 0.36° to scan X, residual p50 0.090 mm,
  p75 0.155, p90 0.359, 84.7 % within 0.2 mm, 92.8 % within 0.5 mm. Asymmetric spots: lower side panels up to
  ~0.8 mm (print warp, both sides bow outward differently), and real one-sided features (bottom PCB pad details,
  some clips and holes). Decision: mirror plane = datum, model one half + Mirror, add the one-sided features after.
- Frame (work/frame.json): Z = normal of the rim (parting) plane, pointing to the open back; X = mirror-plane normal;
  Y = Z x X (toward the neck). Origin on the mirror plane, on the rim plane, at the height of the two shoulder-bore
  centres (both at y = ±0.03).
- Interfaces: the two shoulder flanges (faces turned 4.5° about Z, bores Ø111 centred on the rim plane) are the
  actuator seats; no bolt pattern on them in the scan, no mating data invented.
