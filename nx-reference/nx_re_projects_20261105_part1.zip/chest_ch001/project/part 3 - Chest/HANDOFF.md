# CH-001 Chest: hand-over

## Session 5 (2026-10-30, clean rebuild) - DONE, delivery ready, NOTHING SENT
Task (from the lead): rebuild CH-001 as a clean feature-based part (no stepped pads / terraces / scan-traced
outlines), deliver like before, part stays Rev A. Rounds 2-4 archived in `_rounds2-4_2026-10-30/` (the session-4
hand-over is `_rounds2-4_2026-10-30/HANDOFF_session4.md`).

### State
- Lead reviews 1 + 2 done: STATUS.md "LEAD REVIEW 1/2". Final model nx/outD4, final drawings work/dwgD6c
  (SH4 balloons: work/clean/plan_balloons_out.py + restore_d6b.py, check work/clean/check_bal.py).
- Review 1 notes: final model is now nx/outD4,
  final drawings work/dwgD4k. SH4 balloons: rerun work/clean/plan_balloons2.py <maps> H4,H5,H6,H7,H8,H9,H10,H14,H17,H18
  then fix_h15.py and fix_h21.py before nx/dwg_chest_clean.py; check with work/clean/bal_cal.py <pdf> <dwg_result>.
- Earlier final model nx/outD3 (build nx/build_clean.py + nx/clean_feat.py from work/clean/features.json, which
  work/clean/make_spec.py writes; plan CLEAN_PLAN.md). Finalized into deliver/CAD; QA, renders, drawings, README,
  zip and CLIENT_MESSAGE.txt refreshed for it. Numbers and file sizes: STATUS.md section "Session 5".
- To change a feature: edit work/clean/make_spec.py (round values), run it, then
  `& run_journal.ps1 -Script nx\build_clean.py -JArgs "<abs out dir>" -TimeoutSec 7200` (about 3 min; one new out
  folder per run), CAD-alone renders `an/render_cadonly.py <stl> <dir> <tag>`, gates
  `cd review_2026-10-30; bash run_c10.sh <tag>; python gate_c12.py data_B12 data_<tag>` (the build writes
  chest_Z.stl: copy it to chest_G.stl first), sections `an/sec_cmp.py`.
- Delivery chain: finalize (`-JArgs "<prt>","<deliver\CAD>"`, 3 min) -> an/fin_bbox.py deliver/CAD -> an/dev2.py
  deliver/CAD/CH-001_Chest.stl clean 3000000 -> an/stepcheck.py both STEPs > work/stepcheck_revA.log ->
  an/report.py deliver/CAD clean deliver/QA (then re-apply the hand-written "How the part is modelled" / "Where the
  remaining deviation is" sections and the Rev A comparison line: report.py still writes the round-4 text) ->
  copy work/dev2_clean_*.png to deliver/QA/deviation_map_*.png -> an/render.py -> drawings
  nx/dwg_chest_clean.py <prt> work/dwgN full (rasterise nx/pdf2png.py, check every sheet) -> copy PDFs / DWGs /
  dwg.prt to deliver/Drawings -> README by hand -> an/make_zip.py.

### Open (for the lead / user)
- Skin-outline offsets of the Rev A base skin (2-7 mm at the bottom corners, shoulder top corners, one right-side
  flare): reported in README item 10, not holes. Fixing them needs a re-loft of the skin.
- Left out on purpose (README items 3-9): PCB board relief, text / marks (F17 on hold), side-scoop rails, window
  frame lips, neck-channel stair floor, neck lip, small details.
- Never use `python -` (stdin scripts): every script is a file.
