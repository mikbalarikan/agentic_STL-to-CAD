# CH-001 Chest: hand-over

## Session 4 -> session 5: HANDOFF READY (2026-10-30, ~17:00)

### State
- deliver/CAD = nx/outC16p (= build nx/outC14 + post_plugs passes outC14p / outC15p / outC16p), finalized: 1 solid,
  Examine all 0, 717 802 mm3. QA, renders, drawings (work/dwg13), README (items 1-8), CLIENT_MESSAGE.txt and the
  zip are refreshed for it. NOTHING SENT. Final gates: review_2026-10-30/data_C16p/GATES16p.txt (gate_c12.py).
- Fast path for P-stage fixes (no rebuild): nx/post_plugs.py <prt> <out> a.json[,b.json] (unites, or cuts for
  op "subtract"), then finalize (~40 min, -TimeoutSec 5400), then the chain below. Every P feature is also kept in
  work/c12/plugs_manual.json (+ plugs.json) so a full build (nx/build.py <out> G, -TimeoutSec 7200, ~45-60 min)
  reproduces it.

### Lead's round-5 brief (must fix, then re-finalize + refresh everything + send the gate table)
1. F07 bottom corner posts (+-57..68, -258..-276): CAD has an internal keyhole VOID under a 0.8 mm cap (F07_slit,
   G3.json, z -200..-0.8), serrated fins in plan and a gap at (+-66.8,-268.2) (secs/s4_c14slot.png, c14_small_a.png).
   Remodel as the review said: two walls from a z -45 scan section, no pads in that box (G3 pad_zone F07 exists),
   slits only where the scan has them (scan through-slit (+-59.6,-266) ~2 mm2). Needs a full rebuild (G3.json
   features F07_*: corner_post prism + draft planes + slit + slit_through; build stage H). Then a cavity census:
   no internal voids anywhere (e.g. NX body face-shell count / or ray parity along Z+X on the STL: count closed
   inner shells with trimesh split(only_watertight=False) on the CAD STL - an internal void is a separate closed
   shell with inward normals).
2. Neck V-notch slits (+-60.5, 103..111, z 0..-11; secs/k4.png): notch faces move along x 57.5..63 -> several small
   plugs along x (e.g. 1 mm slices, each with its own cut plane on the CAD inner/outer face) or a short loft, or a
   filled block + one clean cut.
3. All 4 extra openings (gate 0, the warp decision does NOT cover holes):
   (+-66.3,-274.5) ~4 mm2 bottom strips (S_bottom_strip wedge plug not quite out to the scan flare - widen / move the
   face plane outward; likely merges with the F07 remodel); (108,-225.8) 9 mm2 R-only rim flare (scan outer face
   x 108.5 vs CAD 106-107 at z 0..-28, y -231..-220; secs/s4_openA.png panel 4) -> one-sided plug (A) with a face
   plane; (133.8,85.9) 3 mm2 R-only shoulder corner after the shoulder_bump.
Accept as residue (document): teeth at the foot of the shoulder-vent pocket wall; skin outside the warp box 98.31 vs
98.83 if the loss is only the vent-pocket lips, scoop edges and bottom strips -> name them in the README (add to
item 3 / a new item).

### Delivery chain after the model changes
finalize (nx/finalize.py <prt> deliver/CAD) -> an/fin_bbox.py deliver/CAD -> an/dev2.py deliver/CAD/CH-001_Chest.stl
revA 3000000 -> an/stepcheck.py both STEPs > work/stepcheck_revA.log -> an/report.py deliver/CAD revA deliver/QA
(then re-add the OCP mesh-volume sentence: scratch script stepvol.py logic = OCP mesh volume of the AP242; see
deliver/QA/REPORT_deviation.md current text) -> copy work/dev2_revA_*.png to deliver/QA/deviation_map_*.png ->
an/render.py -> drawings nx/dwg_chest.py deliver/CAD/CH-001_Chest.prt work/dwgN full (rasterise nx/pdf2png.py; the
dims/balloons of work/dwg13 are the checked reference: compare dwg_result.json) -> copy PDFs/DWGs/dwg.prt to
deliver/Drawings -> an/readme_c14.py then an/readme_steps.py data_<tag> (README items) -> thin crops
review_2026-10-30/r13_smallthin.py data_<tag> <name> 20 1e9 -> deliver/QA/thin_steps_top10_a/b.png ->
an/make_zip.py. Gates: cd review_2026-10-30; bash run_c10.sh <tag>; gate_c12.py data_C8 data_<tag>.

### Traps found in session 4
- run_journal.ps1 default timeout 900 s: always pass -TimeoutSec.
- Edit journal sources with encoding="utf-8" (a cp1252 byte broke NX's exec of dwg_annot.py).
- Plug top planes fitted to scan maps can overshoot above the rim (outC13/C14 spikes to z +9): clamp z1 <= 0, clip env.
- Smooth Z-frame loft tools fail the NX trim on slopes > ~45 deg (outT13a/c-e).
- r8_thin uses random sampling: the cluster count moves +-10 between runs of the same STL.
- OCP default GProp volume is ~5 % high on this body; use a mesh volume.

