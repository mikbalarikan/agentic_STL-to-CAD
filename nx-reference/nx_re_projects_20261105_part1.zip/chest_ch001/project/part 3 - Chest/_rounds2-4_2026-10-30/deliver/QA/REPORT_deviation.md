# CH-001 Chest - front shell: reverse-engineering report

Source: `share-Chest.stl` (14,776,735 triangles, 3D-scan mesh; one main shell of 14,733,629 faces plus 2,118 scan crumbs, the largest 77 mm2, ignored).
Native CAD: Siemens NX 2206, solid body `CHEST`, rebuilt feature by feature on the scan (not a mesh conversion): right half modelled, mirrored about the mid-plane datum, one-sided features added after the mirror.

## Part data

- Volume 717,802 mm3, mass 1.938 kg in Al 6061 (2.70 g/cm3).
- Bounding box (model frame, exact from the CAD tessellation) [-166.889, -275.6, -139.503, 166.889, 113.851, 2.55].
- Model frame: origin on the mid-plane, on the rim (parting) plane, at the height of the two shoulder-bore centres;
  +Z = rim-plane normal toward the open back; +X = mid-plane normal; +Y = up (toward the neck).

## Symmetry of the scan

Scan reflected about its best mirror plane and fitted onto itself: residual p50 0.090, p90 0.359 mm, 84.7 % within 0.2 mm, 92.8 % within 0.5 mm. Above that: the lower side panels (warp, about +-0.4 mm) and the one-sided features. The CAD is symmetric (design intent), so that warp shows below as an equal split left/right.

## Scan -> CAD deviation (signed, + = material in the scan that the CAD does not have)

| zone | points | mean | |d| p50 | p90 | p95 | within 0.2 | within 0.5 |
|---|---|---|---|---|---|---|---|
| whole part | 3,000,000 | -0.069 | 0.086 | 0.504 | 0.814 | 73.0 % | 89.9 % |
| exterior freeform skin | 1,065,333 | -0.016 | 0.061 | 0.272 | 0.446 | 85.8 % | 95.8 % |
|   exterior, right half (x > 0) | 543,000 | +0.058 | 0.058 | 0.253 | 0.383 | 86.5 % | 96.9 % |
|   exterior, left half (x < 0) | 522,333 | -0.092 | 0.065 | 0.297 | 0.528 | 85.2 % | 94.6 % |
| shoulder flanges (|x| > 145) | 134,219 | +0.011 | 0.082 | 0.729 | 0.858 | 67.9 % | 80.9 % |
| rim band (z > -6) | 121,094 | -0.087 | 0.106 | 0.488 | 0.749 | 70.8 % | 90.4 % |
| interior (wall, ribs, bosses, clips, panel) | 1,679,354 | -0.109 | 0.113 | 0.615 | 1.059 | 65.4 % | 86.9 % |

CAD -> scan (CAD surface samples to the scan mesh, unsigned): p50 0.099, p90 0.843, p95 1.578 mm.

## How the interior is modelled

The wall is a constant 3.25 mm Shell of the fitted exterior skin. Where the print is thicker (ridges behind the
panel lines, the pads of the lower side panels, the rim and neck lips, the walls of the vent and LED boxes) the
measured wall thickness is turned into stepped interior pads: levels 0.7 mm apart, each a Shell offset of the skin
cut to that level's outline (within +-0.35 mm of the scan by construction). The exterior is smooth: the vent
boxes, LED box, side scoops and neck chamfer pockets and the raised shoulder, scoop and neck areas are single
smooth tools lofted through the scan surface (no terraces on visible faces). The shoulder-vent floors are smooth
too (one lofted tool between the scan exterior and interior). Bosses, tubes, gussets, hooks, the latch, the
rim ledges, the PCB relief and the lower-vent slots are discrete features measured from the scan.

## Where the remaining deviation is

- The 0.7 mm steps of the interior pads (+-0.35 by construction): the fine ring pattern inside on the maps.
- Lower side panels: print warp (left side in, right side out, about 0.75 mm) against the symmetric CAD.
- Root fillets and edge rounds of the print (not modelled, sharp in CAD): the thin + band along rib and boss roots.
- Window frame lips and floors on the lower side walls, the neck chamfer (one 0.7 mm step), the logo, badge and
  engraved part number: not modelled (README simplifications).
- Whole-part median: 38 % of all scan points are within 0.06 mm (half would be needed for a 0.06 median).

## STEP check (independent, OpenCascade, `stepcheck.py`)

- `CH-001_Chest_AP214.step`: 1 solid, 9488 faces, valid True, volume 757,444 mm3 (+5.52 % against NX).
- `CH-001_Chest_AP242.step`: 1 solid, 9488 faces, valid True, volume 757,311 mm3 (+5.50 % against NX).
- The OCP volumes above come from OpenCascade's default volume integration, which is inaccurate on this large
  B-spline body: a tessellated volume of the same AP242 STEP (OCP mesh, 0.05 mm deflection) is 718,668 mm3,
  +0.12 % from NX, so the STEP geometry is complete.
- The NX tessellation of the same solid (`CH-001_Chest.stl`) gives 717,758 mm3, -0.006 % from NX.

Maps: `deviation_map_*.png` (scan coloured by its distance to the CAD, +-0.5 mm scale).