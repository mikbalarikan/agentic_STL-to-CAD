# CH-001 Rev A: Chest, Front Shell (STL → solid CAD + manufacturing drawings)

Reverse-engineered from `share-Chest.stl` (3D scan, 14.78 M triangles).
The solid was rebuilt feature by feature on top of the scan in Siemens NX 2206. It is a true
B-rep solid: a freeform B-spline exterior skin shelled to a constant wall, plus exact planes,
cylinders and line/arc profiles for the functional features. It is not a faceted mesh wrapped
into STEP. One valid solid, 717 802 mm³, 1.94 kg in Al 6061.

## Contents

| Folder / file | What it is |
|---|---|
| `CAD/CH-001_Chest_AP214.step` | STEP AP214: opens in SolidWorks, Fusion 360, Inventor, Creo, Mastercam, etc. **Use this one for quoting.** |
| `CAD/CH-001_Chest_AP242.step` | STEP AP242: the same solid in the newer schema |
| `CAD/CH-001_Chest.x_t` | Parasolid: the native kernel of SolidWorks and NX. Opens in SolidWorks as a solid you can edit directly (and use FeatureWorks on), and imports into Fusion 360 |
| `CAD/CH-001_Chest.prt` | Native NX part with the full, editable feature history (reference set `SOLID`): one half modelled, mirrored about the mid-plane datum, one-sided features added after the mirror |
| `CAD/CH-001_Chest.stl` | Fine tessellation of the CAD solid (for viewing and printing) |
| `Drawings/CH-001.pdf` | Drawing set, 4 sheets A1, third-angle projection, GD&T per ISO 1101 (datums A rim/parting plane, B right shoulder bore Ø111, C left shoulder bore Ø111): SH1 general arrangement, SH2 front panel with sections, SH3 shoulder flanges, SH4 interior boss holes (ballooned) with a location table |
| `Drawings/CH-001_SH1..4.pdf`, `_SH1..4.dwg` | The same sheets, one PDF and one DWG per sheet |
| `Deviation Report/REPORT_deviation.md`, `deviation_map_*.png` | Scan-to-CAD deviation report and colour maps |
| `Renders/` | Shaded views of the CAD solid |

## Coordinate system (all files share it)

- Origin: on the mid-plane (left/right mirror plane), on the rim plane (the open back face that mates with the
  back cover), at the height of the two shoulder-bore centres.
- +Z: normal of the rim plane, pointing to the open back. The exterior (front) is at negative Z.
- +X: normal of the mid-plane, toward the robot's right shoulder. +Y: up, toward the neck.
- The shoulder bores (Ø111) are centred on the rim plane at Y = 0; each shoulder face is turned 4.5° about Z (the
  faces open toward the neck) and passes through X = ±161.65 at Y = 0.
- Units: mm.

## How accurate it is (full numbers in `Deviation Report/REPORT_deviation.md`)

| Zone | Scan → CAD p50 | p95 | Within 0.5 mm |
|---|---|---|---|
| Exterior freeform skin | 0.061 | 0.45 | 96 % |
| Shoulder flanges | 0.082 | 0.86 | 81 % |
| Rim band (z > -6) | 0.106 | 0.75 | 90 % |
| Interior (wall, ribs, bosses, clips) | 0.113 | 1.06 | 87 % |
| Whole part | 0.086 | 0.81 | 90 % |

- Functional features come from plane, circle and cylinder fits: rim plane (59 k facets), shoulder faces (flat to
  0.017 mm sd), shoulder bores, front panel planes (0.02 mm sd), through hole and recess, boss holes.
- The exterior is within 0.07 mm median on both sides; the rest of the exterior error is the print's warp (next section).
- Most of the remaining interior deviation is the 0.7 mm pad steps and the items under simplifications below.

## Left/right symmetry

The scan was tested for mirror symmetry before modelling (scan reflected and fitted onto itself): residual p50 0.090 mm,
84.7 % within 0.2 mm, 92.8 % within 0.5 mm. The print is symmetric within scan noise except for a warp of the lower
side panels (left side about 0.75 mm in, right side about 0.75 mm out) and a 0.2 mm left/right difference in wall
thickness. So the CAD is modelled as one half and mirrored (design intent), and the deviation maps show that warp as
an equal split on those panels. Features that exist on one side only (some bosses, the right-hand latch, the PCB relief) are
modelled where they are, after the mirror, and are marked * in the SH4 table.

## Simplifications and assumptions (please read)

1. **Wall.** 3.25 mm shell (measured 3.15-3.37, mean 3.27). Where the print is thicker (ridges behind the panel lines,
   lower side pads, rim and neck lips, box walls) the inside follows the measured thickness in 0.7 mm steps (within
   ±0.35 mm). Front panel plate 2.70, recessed disc 1.95, shoulder flanges 4.35, all normal to their faces.
2. **Root fillets and edge rounds** of the print (R0.5-R3) are not modelled; the CAD corners are sharp. Drawing note 4
   sets internal corners R1 max and edge break 0.2-0.5, so the shop can use its cutter radius.
3. **Smooth exterior pockets and raised areas.** The vent boxes, LED box, side scoops, the raised shoulder corners, scoop
   lips and neck sides are smooth surfaces lofted through the scan (smoothed over 0.7-2.5 mm, so print ripple and very
   small edges are not copied). The 3 mm lip along the upper edge of each shoulder vent pocket is rounded off.
4. **Lower side window frames.** The thin raised lips (about 1 mm wide, 0.5-1 mm tall) round the windows on the lower
   side walls are not modelled, and the window floors keep the general wall (0.5-2 mm thicker than the print there):
   the inner face varies by ±5 mm inside a window, so a flat floor would cut through the wall.
5. **Neck chamfer.** Modelled as one 0.7 mm step instead of the smooth chamfer of the print.
6. **Lower side panel bands.** Two shallow (about 0.7 mm) recessed bands on each lower side panel are blended into the
   smooth skin; on those panels the print is also warped (see Left/right symmetry).
7. **Styling lines and marks.** The main exterior "shield" line is a Ø1.8 round-bottom groove 0.9 mm deep along the
   scanned centre line, the panel-line step is one 0.7 mm step. The raised logo lettering on the upper front, the small
   badge on the upper left and the engraved part number inside are not modelled. Apply part marking per your own
   standard, or tell us if you want them in the CAD.
8. **Interior steps.** Where the print's wall thickness changes gradually, the inside of the CAD changes in 0.7 mm
   steps (item 1). The step edges are sharp, thin ridges up to 0.7 mm tall: 69 areas of 20 mm² or more
   (7 249 mm² in total, under 2 % of the surface) and 107 smaller ones (1 026 mm²), all on interior faces, none on
   the rim (mating) face or the outside. Sections of the ten largest: `Deviation Report/thin_steps_top10_a.png`, `thin_steps_top10_b.png`.
9. **Threads.** The scan cannot show threads. Boss holes are as measured: Ø2.5 (pilot for a self-tapping M3 or an
   insert) and Ø3.4 (M3 clearance), blind, depths in the SH4 table. Tap or insert to suit your fasteners.
10. **Material.** Not stated in the brief. The drawing assumes Al 6061-T6 (mass shown for that), like LT-OUT-001.
11. **Fits.** H7 is suggested on the two shoulder bores Ø111 from their function (they look like the shoulder
    actuator seats). A scan cannot give design tolerances, so please confirm against the shoulder actuators.
12. **Interfaces not invented.** The shoulder flanges are the obvious actuator interfaces, but the scan shows no bolt
    pattern on them (the actuator is probably clamped between this shell and the back cover). No mating data was
    added that the scan does not show.
13. **Design intent over print warp.** The CAD is symmetric, flat and square: the rim plane is exactly flat, the
    shoulder faces exactly 4.5° and the panel plate exactly 4.7° about X.
14. **Projection.** The drawings are third angle (ASME), like LT-OUT-001. They can be switched to first angle (ISO).
