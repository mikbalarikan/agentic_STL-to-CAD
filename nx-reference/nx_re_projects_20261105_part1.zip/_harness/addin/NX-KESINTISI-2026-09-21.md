# NX 21 Eylül 2026'da benim yüzümden kapanmış olabilir

Bu not, NX_MCP upstream PR'larını hazırlayan oturumdan geliyor. "Star hand clamping
knob CAD design" oturumuna mesaj olarak iletmek istedim, ama o oturum kapanmış ve
gelen kutusu yok. O işi tekrar açarsan bu notu oku.

## Ne oldu

2026-09-21 saat 04:48 ile 05:10 arasında, yeniden derlediğim C# köprü eklentisini
kendi test NX örneklerimde doğruluyordum. `Start-Process ugraf.exe` gerçek NX
süreciyle eşleşmeyen bir başlatıcı pid döndürüyor. Kendi pid'imi takip etmek yerine
`Get-Process ugraf | Stop-Process -Force` döngüsü kullandım ve bunu o aralıkta altı
kez çalıştırdım. Bu komut makinedeki **her** NX'i kapatır, yalnızca benimkini değil.

## Kanıt

- `C:\Users\marya\.nx-mcp\gui-bridge.log`: 04:45:48'de bir köprü başlamış (pid 40520),
  benim başlatmadığım bir NX'te. Ardından temiz bir "stopped" satırı yok; sert
  kapatma böyle görünür.
- `C:\NX_MCP_WORKSPACE\star_knob\build\verification\regen\` altındaki parçalar
  04:53'te yazılmış, yani tam o aralıkta.

## Senin için anlamı

Diske kaydedilmiş dosyalar yerinde. Yalnızca o NX oturumunda duran şeyler ya da o
anda süren bir journal koşusu kesilmiş olabilir. 04:45-05:10 arasındaki bir ölçüm ya
da yeniden oluşturma sonucunu bir karara dayanak yaptıysan, o adımı tekrar koş.

## Düzelttiğim davranış

Proje memory'sine de yazdım: NX asla süreç adına göre kapatılmayacak. Kendi durum
klasörümdeki günlükteki `started on ...` satırından ya da tanımlayıcının `pid`
alanından alınan pid kapatılacak, ve başlatmadan önce benim başlatmadığım bir NX
süreci var mı diye bakılacak.

Kesinti için kusura bakma.
