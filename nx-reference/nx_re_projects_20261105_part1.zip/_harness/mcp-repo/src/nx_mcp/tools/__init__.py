"""NX MCP tool modules."""
