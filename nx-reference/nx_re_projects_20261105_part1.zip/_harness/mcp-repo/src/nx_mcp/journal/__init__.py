"""NX MCP journal subsystem."""
