"""Option semantics of the sheet-finishing commands on NX 2206: Face Blend, Trim and Extend, Offset Surface,
Variable Offset, Enlarge, Bridge.

    run_journal.ps1 -Script surf_blend_trim_offset.py -WorkDir <out> -JArgs <out>   ->  <out>\\surf_blend_trim_offset.json

F1  Face Blend between a short and a long sheet: TrimmingOption ToAllFaces / Short / Long / NotSet
F2  Face Blend along a wall with a 2 deg kink: Add Tangent Faces, PropagatePastSharpEdges + PropagationAngle
F3  Face Blend radius by law along a spine; Swept section type
TE  Trim and Extend, Until Selected: a solid trimmed by a sheet that ends inside it (tool = the sheet's free EDGE)
OS  Offset Surface: several face sets in one feature, step (shelf) face, partial offset, output option
VO  Variable Offset: a distance at each of the four corners
EN  Enlarge: Natural / Linear, negative percentage, copy; planar and sewn faces
BR  Bridge surface between two sheet edges, G0 / G1 / G2
NO  The normal of a loft follows the section order
TOL Position / tangent tolerance of an approximating command (Swept on an arc guide against the true torus)
GS  Global Shaping, To Point: a crowned region on an existing sheet
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
GU = NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
FBB = NXOpen.Features.FaceBlendBuilder
TCB = NXOpen.Features.ThroughCurvesBuilder
CT = GU.Continuity.ContinuityTypes
LAW = GU.LawBuilder.Type
ONLY_CURVES = NXOpen.Section.AllowTypes.OnlyCurves
PI = math.pi
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
notes = res["notes"]


def save_json():
    out = dict(res)
    out.update(chk.report())
    nxh.write_json(os.path.join(OUT, "surf_blend_trim_offset.json"), out)


def ok(r):
    return isinstance(r, dict) and "error" not in r


def case(store, name, fn):
    m = nxh.mark(name, False)
    try:
        store[name] = fn()
    except Exception as e:  # noqa: BLE001
        store[name] = {"error": str(e)[:300]}
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass
    save_json()
    return store[name]


def edge_points(edge, n=5):
    props = nxh.UFS.ModlGeneral.AskCurveProps
    return [tuple(props(edge.Tag, (i + 1.0) / (n + 1.0))[0]) for i in range(n)]


def describe(part, bodies):
    out = []
    for b in bodies:
        d = {"solid": b.IsSolidBody, "faces": len(b.GetFaces()), "free_edges": len(nxh.free_edges(b)), "bbox": nxh.bbox(b), "types": nxh.face_census(b)["types"]}
        if b.IsSolidBody:
            d["volume"] = round(nxh.volume(part, b), 3)
        else:
            d["area"] = round(nxh.sheet_area(part, b)[0], 3)
        out.append(d)
    return out


# ---------------------------------------------------------------- small builders
def bounded_plane(part, pts):
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.BoundingCurves, curves=nxh.polyline(part, pts), help_point=pts[0])
        return b.CommitFeature().GetBodies()[0]
    finally:
        b.Destroy()


def sew(part, target, tools, tol=0.01):
    b = part.Features.CreateSewBuilder(NF)
    try:
        b.Type = NXOpen.Features.SewBuilder.Types.Sheet
        b.Tolerance = tol
        b.TargetBodies.Add(target)
        for t in tools:
            b.ToolBodies.Add(t)
        return b.CommitFeature()
    finally:
        b.Destroy()


def through_curves(part, sections, first=None, last=None):
    b = part.Features.CreateThroughCurvesBuilder(NF)
    try:
        b.PreserveShape = False
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.BodyPreference = TCB.BodyPreferenceTypes.Sheet
        for s in sections:
            b.SectionsList.Append(s)
        b.Alignment.SetSections(list(sections))
        return b.CommitFeature()
    finally:
        b.Destroy()


# ---------------------------------------------------------------- Face Blend
def face_blend(part, faces1, faces2, radius, rev1=False, rev2=False, trim=True, sew_all=True, trimming=None, add_tangent=None,
               past_sharp=None, propagation_angle=None, swept=False, spine=None, law=None, law_mode="lawcontrol", info=None):
    """Two-face Face Blend with the options this journal measures.

    trimming            FBB.TrimmingMethod.ToAllFaces | Short | Long | NotSet - how far the BLEND face runs
    add_tangent         AddTangentFaces: each chain grows over tangent neighbours
    past_sharp + propagation_angle   PropagatePastSharpEdges: the blend runs over edges up to that angle (deg)
    swept, spine        BlendType Swept: sections in planes normal to the spine (spine = (curves, help point))
    law                 (start, end) radius, linear along the spine
    """
    b = part.Features.CreateFaceBlendBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FaceBlendDefineType = FBB.DefiningType.BlendTwoFace
        b.BlendType = FBB.Type.Swept if swept else FBB.Type.RollingBall
        b.FirstFaceCollector = nxh.collector(part, faces=faces1)
        b.SecondFaceCollector = nxh.collector(part, faces=faces2)
        b.ReverseFirstFaceNormal = rev1
        b.ReverseSecondFaceNormal = rev2
        b.CrossSectionType = FBB.CrossSectionOption.Circular
        if info is not None:
            info["defaults"] = {"TrimmingOption": str(b.TrimmingOption), "AddTangentFaces": b.AddTangentFaces, "PropagatePastSharpEdges": b.PropagatePastSharpEdges,
                                "PropagationAngle": b.PropagationAngle, "TrimInputFacesToBlendFaces": b.TrimInputFacesToBlendFaces, "SewAllFaces": b.SewAllFaces,
                                "RadiusOption": str(b.CircularCrossSection.RadiusOption), "RadiusMethod_names": nxh.enum_names(GU.RadiusMethod)}
        if spine is not None:
            sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
            sec.SetAllowedEntityTypes(ONLY_CURVES)
            nxh.fill_section(part, sec, curves=spine[0], help_point=spine[1])
            b.Spine = sec
        if law is not None:
            cc = b.CircularCrossSection
            cc.RadiusOption = GU.RadiusMethod.Law
            cc.LawControl.LawType = LAW.Linear
            if law_mode == "lawcontrol":
                cc.LawControl.StartValue.RightHandSide = str(law[0])
                cc.LawControl.EndValue.RightHandSide = str(law[1])
            else:
                cc.SetLawControlStartRadius(str(law[0]))
                cc.SetLawControlEndRadius(str(law[1]))
        else:
            b.CircularCrossSection.Radius.RightHandSide = str(radius)
        if trimming is not None:
            b.TrimmingOption = trimming
        if add_tangent is not None:
            b.AddTangentFaces = add_tangent
        if past_sharp is not None:
            b.PropagatePastSharpEdges = past_sharp
        if propagation_angle is not None:
            b.PropagationAngle = float(propagation_angle)
        b.TrimInputFacesToBlendFaces = trim
        b.SewAllFaces = sew_all
        return b.CommitFeature()
    finally:
        b.Destroy()


def blend_faces(bodies):
    return [f for b in bodies for f in b.GetFaces() if nxh.face_data(f)[0] in (nxh.CYLINDER, nxh.BLEND, nxh.BSURF, nxh.CONE)]


def face_blend_auto(part, faces1, faces2, radius, accept, **kw):
    """The quadrant is where the two (possibly reversed) normals point at each other: try the four flag pairs,
    accept by measurement, undo otherwise. Returns (feature, (rev1, rev2))."""
    last = None
    for rev1 in (False, True):
        for rev2 in (False, True):
            m = nxh.mark("fb", False)
            try:
                f = face_blend(part, faces1, faces2, radius, rev1, rev2, **kw)
                if accept(f):
                    return f, (rev1, rev2)
                last = "built, rejected"
            except Exception as e:  # noqa: BLE001
                last = str(e)
            nxh.undo_to(m)
    raise RuntimeError("face blend: no normal combination accepted; last: " + str(last))


def t_face_blend(part):
    F1 = notes["F1_trimming_option"] = {}
    TM = FBB.TrimmingMethod
    info = {}

    def two_sheets(x0):
        a = bounded_plane(part, [(x0, 0, 0), (x0 + 20, 0, 0), (x0 + 20, 30, 0), (x0, 30, 0)])            # short: y 0..30
        w = bounded_plane(part, [(x0, 0, 0), (x0, 50, 0), (x0, 50, 15), (x0, 0, 15)])                    # long:  y 0..50
        return a, w

    def in_corner(f, x0):                                                 # the blend lies in x > x0, z > 0
        fs = [fc for b in f.GetBodies() for fc in b.GetFaces() if nxh.face_data(fc)[0] in (nxh.CYLINDER, nxh.BLEND)]
        return bool(fs) and all(nxh.bbox(fc)[0] > x0 - 1e-3 and nxh.bbox(fc)[2] > -1e-3 for fc in fs)

    def trim_case(x0, trimming, trim=True, sew_all=True):
        a, w = two_sheets(x0)
        before = list(part.Bodies)
        n0 = len(nxh.sheets(part))
        f, flags = face_blend_auto(part, list(a.GetFaces()), list(w.GetFaces()), 5, lambda f: in_corner(f, x0), trimming=trimming, trim=trim, sew_all=sew_all, info=info)
        bodies = list(f.GetBodies())
        bl = [fc for b in bodies for fc in b.GetFaces() if nxh.face_data(fc)[0] in (nxh.CYLINDER, nxh.BLEND)]
        return {"flags": flags, "sheets_change": len(nxh.sheets(part)) - n0, "bodies_of_feature": len(bodies), "new_bodies": len(nxh.new_bodies(part, before)),
                "blend_faces": len(bl), "blend_y_range": [min(nxh.bbox(fc)[1] for fc in bl), max(nxh.bbox(fc)[4] for fc in bl)],
                "blend_area": round(sum(nxh.sheet_area(part, [fc])[0] for fc in bl), 3), "feature_bodies": describe(part, bodies)}
    for i, (name, tm) in enumerate((("default", None), ("ToAllFaces", TM.ToAllFaces), ("Short", TM.Short), ("Long", TM.Long), ("NotSet", TM.NotSet))):
        case(F1, name, lambda tm=tm, i=i: trim_case(100.0 * i, tm))
    for i, (name, tm) in enumerate((("Long_no_trim_no_sew", TM.Long), ("NotSet_no_trim_no_sew", TM.NotSet), ("Short_no_trim_no_sew", TM.Short),
                                    ("ToAllFaces_no_trim_no_sew", TM.ToAllFaces))):
        case(F1, name, lambda tm=tm, i=i: trim_case(600.0 + 100.0 * i, tm, trim=False, sew_all=False))
    F1["builder_defaults"] = info.get("defaults")

    # ---- F2 a wall with a 2 deg kink across the blend path
    F2 = notes["F2_sharp_edge_propagation"] = {}
    H = 30.0 * math.tan(math.radians(2.0))

    def kinked(x0):
        a1 = bounded_plane(part, [(x0, 0, 0), (x0 + 20, 0, 0), (x0 + 20, 30, 0), (x0, 30, 0)])
        a2 = bounded_plane(part, [(x0, 30, 0), (x0 + 20, 30, 0), (x0 + 20, 60, H), (x0, 60, H)])
        f1 = a1.GetFaces()[0]
        sew(part, a1, [a2])
        w = bounded_plane(part, [(x0, 0, -5), (x0, 60, -5), (x0, 60, 20), (x0, 0, 20)])
        kink = [e for e in a1.GetEdges() if len(e.GetFaces()) == 2]
        ang = nxh.g1_deviation(kink[0].GetFaces()[0], kink[0].GetFaces()[1], edge_points(kink[0], 1)) if kink else None
        return a1, f1, w, ang

    def kink_case(x0, **kw):
        a, f1, w, ang = kinked(x0)
        f, flags = face_blend_auto(part, [f1], list(w.GetFaces()), 5, lambda f: bool(blend_faces(f.GetBodies())) and
                                   all(nxh.bbox(fc)[0] > x0 - 1e-3 and nxh.bbox(fc)[2] > -1e-3 for fc in f.GetBodies()[0].GetFaces()), trim=False, sew_all=False, **kw)
        bl = [fc for b in f.GetBodies() for fc in b.GetFaces()]
        zc = 15.0 * math.tan(math.radians(2.0))                           # height of the tilted face at y = 45
        return {"kink_deg": round(ang, 3), "flags": flags, "blend_faces": len(bl), "blend_y_range": [min(nxh.bbox(fc)[1] for fc in bl), max(nxh.bbox(fc)[4] for fc in bl)],
                "off_contact_line_on_face_1_at_y_15_mm": round(min(abs(nxh.dist_to(part, fc, (x0 + 5, 15, 0))) for fc in bl), 4),
                "off_contact_line_on_tilted_face_at_y_45_mm": round(min(abs(nxh.dist_to(part, fc, (x0 + 5, 45, zc))) for fc in bl), 4),
                "alerts": [str(x) for x in (f.GetFeatureErrorMessages() or [])]}
    TMS = FBB.TrimmingMethod.Short
    case(F2, "first_face_only_defaults", lambda: kink_case(1000.0))
    case(F2, "first_face_only_trim_short", lambda: kink_case(1100.0, trimming=TMS))
    case(F2, "trim_short_add_tangent_faces", lambda: kink_case(1200.0, trimming=TMS, add_tangent=True))
    case(F2, "trim_short_past_sharp_angle_3", lambda: kink_case(1300.0, trimming=TMS, past_sharp=True, propagation_angle=3))
    case(F2, "trim_short_past_sharp_angle_1", lambda: kink_case(1400.0, trimming=TMS, past_sharp=True, propagation_angle=1))
    case(F2, "trim_short_no_tangent_no_sharp", lambda: kink_case(1500.0, trimming=TMS, add_tangent=False, past_sharp=False))
    case(F2, "past_sharp_angle_3", lambda: kink_case(1600.0, past_sharp=True, propagation_angle=3))

    # ---- F3 law radius along a spine, swept section
    F3 = notes["F3_law_radius_swept_section"] = {}

    def law_case(x0, swept, law, radius=5, spine=True, law_mode="lawcontrol", spine_reversed=False):
        a = bounded_plane(part, [(x0, 0, 0), (x0 + 30, 0, 0), (x0 + 30, 60, 0), (x0, 60, 0)])
        w = bounded_plane(part, [(x0, 0, 0), (x0, 60, 0), (x0, 60, 30), (x0, 0, 30)])
        sp = nxh.line(part, (x0, 0, 0), (x0, 60, 0))
        f, flags = face_blend_auto(part, list(a.GetFaces()), list(w.GetFaces()), radius, lambda f: bool(blend_faces(f.GetBodies())) and
                                   all(nxh.bbox(fc)[0] > x0 - 1e-3 and nxh.bbox(fc)[2] > -1e-3 for fc in blend_faces(f.GetBodies())),
                                   trim=False, sew_all=False, swept=swept, spine=([sp], (x0, 60.0 if spine_reversed else 0.0, 0)) if spine else None, law=law, law_mode=law_mode)
        bl = f.GetBodies()[0].GetFaces()[0]
        out = {"flags": flags, "type": nxh.face_data(bl)[0], "area": round(nxh.sheet_area(part, [bl])[0], 3), "bbox": nxh.bbox(bl)}
        for y in (1.0, 30.0, 59.0):
            # radius of the blend at height y: its contact line on the floor is r from the corner; find it from the 45 deg point
            lo = None
            for k in range(20, 101):
                r = k / 10.0
                t = r - r / math.sqrt(2.0)
                d = abs(nxh.dist_to(part, bl, (x0 + t, y, t)))
                if lo is None or d < lo[1]:
                    lo = (r, round(d, 4))
            out["radius_at_y_%g" % y] = lo
        return out
    case(F3, "rolling_ball_constant_5_with_spine", lambda: law_case(2000.0, False, None))
    case(F3, "swept_section_constant_5_with_spine", lambda: law_case(2100.0, True, None))
    case(F3, "rolling_ball_law_3_to_6", lambda: law_case(2300.0, False, (3, 6)))


# ---------------------------------------------------------------- Trim and Extend
def t_trim_extend(part):
    TE = notes["TE_until_selected"] = {}
    TEB = NXOpen.Features.TrimAndExtendBuilder
    RF = part.ScRuleFactory

    def setup(x0):
        blk = nxh.block(part, (x0, 0, 0), (40, 30, 20))[1]
        sh = bounded_plane(part, [(x0 - 5, -5, 12), (x0 + 37, -5, 12), (x0 + 37, 35, 12), (x0 - 5, 35, 12)])       # ends 3 mm inside the block
        edge = [e for e in sh.GetEdges() if all(abs(v.X - (x0 + 37)) < 1e-6 for v in e.GetVertices())]
        return blk, sh, edge

    def new_builder(x0, tool, rev_target=False, rev_tool=False, arrow=None):
        blk, sh, edge = setup(x0)
        info = {}
        b = part.Features.TrimFeatureCollection.CreateTrimAndExtendBuilder(NXOpen.Features.TrimAndExtend.Null)
        try:
            b.DistanceTolerance = 0.01
            b.Operation = TEB.OperationType.UntilSelected
            b.TargetSelection.ReplaceRules([RF.CreateRuleFaceBody(blk)], False)
            b.ToolSelection.ReplaceRules([RF.CreateRuleEdgeDumb(edge) if tool == "edge" else RF.CreateRuleFaceBody(sh)], False)
            b.ReverseTarget = rev_target
            b.ReverseTool = rev_tool
            if arrow is not None:
                b.ArrowSideOption = arrow
            info["defaults"] = {"CombineOption": b.CombineOption, "CopyOriginalOption": b.CopyOriginalOption, "SurfaceShapeOption": str(b.SurfaceShapeOption)}
            b.CommitFeature()
        finally:
            b.Destroy()
        return {"block": describe(part, [blk]), "sheet": describe(part, [sh]), "solids": len(nxh.solids(part)), "info": info}

    def legacy_builder(x0, tool, rev_target=False, arrow=None):
        TXB = NXOpen.Features.TrimExtendBuilder
        blk, sh, edge = setup(x0)
        b = part.Features.CreateTrimExtendBuilder(NF)
        try:
            b.Tolerance = 0.01
            b.Type = TXB.CreationTypes.UntilSelected
            b.TargetCollector.ReplaceRules([RF.CreateRuleFaceBody(blk)], False)
            b.ToolCollector.ReplaceRules([RF.CreateRuleEdgeDumb(edge) if tool == "edge" else RF.CreateRuleFaceBody(sh)], False)
            b.TargetReversed = rev_target
            if arrow is not None:
                b.ArrowSideOption = arrow
            b.CommitFeature()
        finally:
            b.Destroy()
        return {"block": describe(part, [blk]), "sheet": describe(part, [sh])}
    case(TE, "new_tool_edge", lambda: new_builder(0.0, "edge"))
    case(TE, "new_tool_edge_reverse_target", lambda: new_builder(100.0, "edge", rev_target=True))
    case(TE, "new_tool_edge_reverse_tool", lambda: new_builder(200.0, "edge", rev_tool=True))
    case(TE, "new_tool_edge_arrow_delete", lambda: new_builder(300.0, "edge", arrow=TEB.ArrowSideType.Delete))
    case(TE, "new_tool_face", lambda: new_builder(400.0, "face"))
    case(TE, "legacy_tool_edge", lambda: legacy_builder(500.0, "edge"))
    case(TE, "legacy_tool_edge_arrow_delete", lambda: legacy_builder(600.0, "edge", arrow=NXOpen.Features.TrimExtendBuilder.ArrowSideOptions.Delete))
    case(TE, "legacy_tool_face", lambda: legacy_builder(700.0, "face"))


# ---------------------------------------------------------------- Offset Surface, Variable Offset
def offset_surface(part, sets, step=None, partial=None, output=None, info=None):
    """sets = [(distance, faces, flip)] - several face sets with their own distance in ONE feature."""
    b = part.Features.CreateOffsetSurfaceBuilder(NF)
    try:
        b.Tolerance = 0.01
        for dist, faces, flip in sets:
            b.FaceSets.Append(part.FaceSetOffsets.CreateFaceSet(str(dist), nxh.collector(part, faces=faces), flip, 0))
        if step is not None:
            b.StepOption = step
        if partial is not None:
            b.PartialOption = partial
        if output is not None:
            b.OutputOption = output
        f = b.CommitFeature()
        if info is not None:
            try:
                info["error_faces"] = len(b.GetErrorFaces())
            except Exception as e:  # noqa: BLE001
                info["error_faces"] = "n/a: " + str(e)[:80]
        return f
    finally:
        b.Destroy()


def t_offset(part):
    OS = notes["OS_offset_surface"] = {}

    def flat_two_faces(x0):
        """Sheet of two TANGENT faces: a plane (x0 .. x0+20) running into a cylinder R60 that curves up."""
        y0 = 3000.0
        prof = [nxh.line(part, (x0, y0, 0), (x0 + 20, y0, 0)),
                nxh.arc(part, (x0 + 20, y0, 60), (1, 0, 0), (0, 0, 1), 60.0, -PI / 2, -PI / 2 + math.radians(20))]
        sh = nxh.extrude(part, nxh.section(part, curves=prof, help_point=(x0, y0, 0)), (0, 1, 0), 0, 30, sheet=True).GetBodies()[0]
        fs = sorted(sh.GetFaces(), key=lambda f: nxh.bbox(f)[0] + nxh.bbox(f)[3])
        if len(fs) != 2:
            raise RuntimeError("expected 2 faces, got %s" % [nxh.bbox(f) for f in fs])
        return sh, fs[0], fs[1]

    def run_sets(x0, mk, **kw):
        sh, sets = mk(x0)
        before = list(part.Bodies)
        nf0 = len(part.Features.GetFeatures())
        info = {}
        offset_surface(part, sets, info=info, **kw)
        new = nxh.new_bodies(part, before)
        return {"new_bodies": describe(part, new), "new_features": len(part.Features.GetFeatures()) - nf0, "info": info, "source_faces": len(sh.GetFaces()),
                "offset_faces": sum(len(b.GetFaces()) for b in new),
                "dist_from_source_points": [round(min(abs(nxh.dist_to(part, b, q)) for b in new), 4) for q in ((x0 + 5, 3010.0, 0.0), (x0 + 30, 3010.0, 60 - math.sqrt(3500.0)))],
                "planar_faces": [{"bbox_rel": [round(nxh.bbox(f)[0] - x0, 3), nxh.bbox(f)[2], round(nxh.bbox(f)[3] - x0, 3), nxh.bbox(f)[5]],
                                  "normal": [round(v, 4) for v in nxh.face_data(f)[2]]} for b in new for f in b.GetFaces() if nxh.face_data(f)[0] == nxh.PLANE]}

    def mk_step(x0):
        sh, f1, f2 = flat_two_faces(x0)
        n = nxh.normal_at(f1, (x0 + 5, 3010.0, 0))
        return sh, [(5, [f1], n[2] < 0), (0, [f2], False)]                # flip so that the offset goes to +Z

    def mk_two(x0):
        sh, f1, f2 = flat_two_faces(x0)
        n = nxh.normal_at(f1, (x0 + 5, 3010.0, 0))
        return sh, [(5, [f1], n[2] < 0), (2, [f2], n[2] < 0)]
    case(OS, "sets_5_and_0_step_off", lambda: run_sets(0.0, mk_step, step=False))
    case(OS, "sets_5_and_0_step_on", lambda: run_sets(100.0, mk_step, step=True))
    case(OS, "sets_5_and_2_step_off", lambda: run_sets(200.0, mk_two, step=False))
    case(OS, "sets_5_and_2_step_on", lambda: run_sets(300.0, mk_two, step=True))
    OT = NXOpen.Features.OffsetSurfaceBuilder.OutputOptionType
    case(OS, "sets_5_and_2_one_feature_for_each_face", lambda: run_sets(400.0, mk_two, step=False, output=OT.OneFeatureForEachFace))

    def mk_tight(x0):
        y0 = 3000.0
        prof = [nxh.line(part, (x0, y0, 0), (x0 + 20, y0, 0)),
                nxh.arc(part, (x0 + 20, y0, 5), (1, 0, 0), (0, 0, 1), 5.0, -PI / 2, 0.0),
                nxh.line(part, (x0 + 25, y0, 5), (x0 + 25, y0, 25))]
        sh = nxh.extrude(part, nxh.section(part, curves=prof, help_point=(x0, y0, 0)), (0, 1, 0), 0, 30, sheet=True).GetBodies()[0]
        flat = [f for f in sh.GetFaces() if nxh.face_data(f)[0] == nxh.PLANE and nxh.bbox(f)[5] < 0.01][0]
        n = nxh.normal_at(flat, (x0 + 5, y0 + 10, 0))
        return sh, [(6, list(sh.GetFaces()), n[2] < 0)]                   # 6 towards +Z = towards the centre of the R5 arc
    def mk_l(x0):
        """Two planes at 90 deg in one sheet (not tangent): floor x0 .. x0+20 at z = 0, wall at x0+20 up to z = 20."""
        y0 = 3000.0
        pl = nxh.polyline(part, [(x0, y0, 0), (x0 + 20, y0, 0), (x0 + 20, y0, 20)], closed=False)
        sh = nxh.extrude(part, nxh.section(part, curves=pl, help_point=(x0, y0, 0)), (0, 1, 0), 0, 30, sheet=True).GetBodies()[0]
        floor = [f for f in sh.GetFaces() if nxh.bbox(f)[5] < 0.01][0]
        wall = [f for f in sh.GetFaces() if nxh.bbox(f)[5] > 1.0][0]
        n = nxh.normal_at(floor, (x0 + 5, y0 + 10, 0))
        return sh, [(3, [floor], n[2] < 0), (5, [wall], n[2] < 0)]        # both to the inside of the L
    case(OS, "L_quilt_sets_3_and_5", lambda: run_sets(1300.0, mk_l))

    def mk_half(x0, tail):
        y0 = 3000.0
        prof = [nxh.arc(part, (x0, y0, 5), (1, 0, 0), (0, 0, 1), 5.0, -PI / 2, PI / 2)]              # half circle opening to -X, from (x0, 0) up to (x0, 10)
        if tail:
            prof.insert(0, nxh.line(part, (x0 - 20, y0, 0), (x0, y0, 0)))
        sh = nxh.extrude(part, nxh.section(part, curves=prof, help_point=(x0 - 20 if tail else x0, y0, 0)), (0, 1, 0), 0, 30, sheet=True).GetBodies()[0]
        cyl = [f for f in sh.GetFaces() if nxh.face_data(f)[0] != nxh.PLANE][0]
        n = nxh.normal_at(cyl, (x0 + 5, y0 + 10, 5))
        return sh, [(6, list(sh.GetFaces()), n[0] > 0)]                   # towards the axis of the R5 half cylinder
    case(OS, "half_cylinder_R5_by_6_inward", lambda: run_sets(800.0, lambda x0: mk_half(x0, False)))
    case(OS, "half_cylinder_R5_by_6_inward_partial", lambda: run_sets(900.0, lambda x0: mk_half(x0, False), partial=True))
    case(OS, "plane_plus_half_cylinder_R5_by_6_inward", lambda: run_sets(1000.0, lambda x0: mk_half(x0, True)))
    case(OS, "plane_plus_half_cylinder_R5_by_6_inward_partial", lambda: run_sets(1100.0, lambda x0: mk_half(x0, True), partial=True))
    case(OS, "R5_quilt_by_6_inward", lambda: run_sets(600.0, mk_tight))
    case(OS, "R5_quilt_by_6_inward_partial", lambda: run_sets(700.0, mk_tight, partial=True))

    VO = notes["VO_variable_offset"] = {}
    VOB = NXOpen.Features.VariableOffsetBuilder

    def var_case(x0, kind, method, vals):
        y0 = 3300.0
        if kind == "plane":
            sh = bounded_plane(part, [(x0, y0, 0), (x0 + 40, y0, 0), (x0 + 40, y0 + 30, 0), (x0, y0 + 30, 0)])
            corners = [(x0, y0, 0), (x0 + 40, y0, 0), (x0 + 40, y0 + 30, 0), (x0, y0 + 30, 0)]
            mid = (x0 + 20, y0 + 15, 0)
        else:
            a = [nxh.arc(part, (x0, y0 + yy, 0), (1, 0, 0), (0, 0, 1), 40.0, math.radians(60), math.radians(120)) for yy in (0.0, 30.0)]
            sh = through_curves(part, [nxh.section(part, curves=[c], help_point=(x0 + 20, y0 + yy, 34.64), seed=c) for c, yy in zip(a, (0.0, 30.0))]).GetBodies()[0]
            corners = [(x0 + 20, y0, 34.641), (x0 - 20, y0, 34.641), (x0 - 20, y0 + 30, 34.641), (x0 + 20, y0 + 30, 34.641)]
            mid = (x0, y0 + 15, 40.0)
        before = list(part.Bodies)
        b = part.Features.CreateVariableOffsetBuilder(NXOpen.Features.VariableOffset.Null)
        try:
            b.DistanceTolerance = 0.01
            b.Face.Value = sh.GetFaces()[0]
            b.IsApplyToAll = False
            b.Method = method
            for ex, v in zip((b.OffsetAtA, b.OffsetAtB, b.OffsetAtC, b.OffsetAtD), vals):
                ex.RightHandSide = str(v)
            f = b.CommitFeature()
        finally:
            b.Destroy()
        new = nxh.new_bodies(part, before)
        return {"feature_type": f.FeatureType, "new_bodies": len(new), "corner_distances": [round(abs(nxh.dist_to(part, new[0], c)), 4) for c in corners],
                "mid_distance": round(abs(nxh.dist_to(part, new[0], mid)), 4), "area": round(nxh.sheet_area(part, new[0])[0], 3),
                "source_area": round(nxh.sheet_area(part, sh)[0], 3)}
    case(VO, "plane_linear_1_1_5_5", lambda: var_case(0.0, "plane", VOB.MethodOptions.Linear, (1, 1, 5, 5)))
    case(VO, "loft_linear_1_1_5_5", lambda: var_case(100.0, "loft", VOB.MethodOptions.Linear, (1, 1, 5, 5)))
    case(VO, "loft_cubic_1_1_5_5", lambda: var_case(200.0, "loft", VOB.MethodOptions.Cubic, (1, 1, 5, 5)))
    case(VO, "loft_linear_1_5_5_1", lambda: var_case(300.0, "loft", VOB.MethodOptions.Linear, (1, 5, 5, 1)))


# ---------------------------------------------------------------- Enlarge, Bridge, normals
def t_enlarge_bridge(part):
    EN = notes["EN_enlarge"] = {}
    EB = NXOpen.Features.EnlargeBuilder

    def enlarge(face, u0=0, u1=0, v0=0, v1=0, copy=False, ext=None):
        b = part.Features.CreateEnlargeBuilder(NXOpen.Features.Enlarge.Null)
        try:
            b.Face.Value = face
            if ext is not None:
                b.ExtensionType = ext
            b.IsCopy = copy
            rp = b.ResizeParameters
            rp.UStart.Expression.RightHandSide = str(u0)
            rp.UEnd.Expression.RightHandSide = str(u1)
            rp.VStart.Expression.RightHandSide = str(v0)
            rp.VEnd.Expression.RightHandSide = str(v1)
            return b.CommitFeature()
        finally:
            b.Destroy()

    def arc_loft(x0):
        y0 = 3600.0
        a = [nxh.arc(part, (x0, y0 + yy, 0), (1, 0, 0), (0, 0, 1), 40.0, math.radians(60), math.radians(120)) for yy in (0.0, 30.0)]
        return through_curves(part, [nxh.section(part, curves=[c], help_point=(x0 + 20, y0 + yy, 34.64), seed=c) for c, yy in zip(a, (0.0, 30.0))]).GetBodies()[0]

    def en_case(x0, kind, **kw):
        y0 = 3600.0
        if kind == "plane":
            sh = bounded_plane(part, [(x0, y0, 0), (x0 + 40, y0, 0), (x0 + 40, y0 + 30, 0), (x0, y0 + 30, 0)])
            face = sh.GetFaces()[0]
        elif kind == "sewn":
            sh = arc_loft(x0)
            face = sh.GetFaces()[0]
            fl = bounded_plane(part, [(x0 + 20, y0, 34.641016), (x0 + 60, y0, 34.641016), (x0 + 60, y0 + 30, 34.641016), (x0 + 20, y0 + 30, 34.641016)])
            sew(part, sh, [fl])
        else:
            sh = arc_loft(x0)
            face = sh.GetFaces()[0]
        a0 = nxh.sheet_area(part, [face])[0]
        before = list(part.Bodies)
        f = enlarge(face, **kw)
        new = nxh.new_bodies(part, before)
        tgt = new[0] if new else sh
        return {"feature_type": f.FeatureType, "new_bodies": len(new), "area_before": round(a0, 3), "source_body_now": describe(part, [sh]),
                "result": describe(part, [tgt]), "result_area": round(nxh.sheet_area(part, tgt)[0], 3)}
    case(EN, "loft_u_end_25_natural", lambda: en_case(0.0, "loft", u1=25, ext=EB.ExtensionTypes.Natural))
    case(EN, "loft_v_end_25_natural", lambda: en_case(100.0, "loft", v1=25, ext=EB.ExtensionTypes.Natural))
    case(EN, "loft_u_end_25_linear", lambda: en_case(200.0, "loft", u1=25, ext=EB.ExtensionTypes.Linear))
    case(EN, "loft_v_end_25_linear", lambda: en_case(300.0, "loft", v1=25, ext=EB.ExtensionTypes.Linear))
    case(EN, "loft_v_end_minus_20_natural", lambda: en_case(400.0, "loft", v1=-20, ext=EB.ExtensionTypes.Natural))
    case(EN, "loft_v_end_minus_20_linear", lambda: en_case(500.0, "loft", v1=-20, ext=EB.ExtensionTypes.Linear))
    case(EN, "loft_v_end_25_copy", lambda: en_case(600.0, "loft", v1=25, copy=True))
    case(EN, "plane_in_place", lambda: en_case(700.0, "plane", v1=25))
    case(EN, "plane_copy", lambda: en_case(800.0, "plane", v1=25, copy=True))
    case(EN, "sewn_face_in_place", lambda: en_case(900.0, "sewn", v1=25))
    case(EN, "sewn_face_copy", lambda: en_case(1000.0, "sewn", v1=25, copy=True))

    BR = notes["BR_bridge_surface"] = {}

    def bridge_case(x0, c1, c2):
        y0 = 3900.0
        s1 = bounded_plane(part, [(x0, y0, 0), (x0 + 20, y0, 0), (x0 + 20, y0 + 30, 0), (x0, y0 + 30, 0)])
        dx, dz = 10.0, 10.0 * math.tan(math.radians(60))
        s2 = bounded_plane(part, [(x0 + 40, y0, 10), (x0 + 40, y0 + 30, 10), (x0 + 40 + dx, y0 + 30, 10 + dz), (x0 + 40 + dx, y0, 10 + dz)])
        e1 = [e for e in s1.GetEdges() if all(abs(v.X - (x0 + 20)) < 1e-6 for v in e.GetVertices())][0]
        e2 = [e for e in s2.GetEdges() if all(abs(v.X - (x0 + 40)) < 1e-6 for v in e.GetVertices())][0]
        before = list(part.Bodies)
        info = {}
        b = part.Features.CreateBridgeSurfaceBuilder(NXOpen.Features.BridgeSurface.Null)
        try:
            b.G0Tolerance = 0.01
            b.G1Tolerance = 0.5
            b.G2Tolerance = 0.5
            b.FirstEdgeSelection.Value = e1
            b.SecondEdgeSelection.Value = e2
            info["defaults"] = {"first": str(b.FirstEdgeContinuity.ContinuityType), "second": str(b.SecondEdgeContinuity.ContinuityType)}
            b.FirstEdgeContinuity.ContinuityType = c1
            b.SecondEdgeContinuity.ContinuityType = c2
            f = b.CommitFeature()
        finally:
            b.Destroy()
        br = nxh.new_bodies(part, before)[0]
        bf = br.GetFaces()[0]
        out = {"feature_type": f.FeatureType, "info": info, "faces": len(br.GetFaces()), "area": round(nxh.sheet_area(part, br)[0], 3),
               "g1_dev_edge_1_deg": round(nxh.g1_deviation(s1.GetFaces()[0], bf, edge_points(e1, 5)), 3),
               "g1_dev_edge_2_deg": round(nxh.g1_deviation(s2.GetFaces()[0], bf, edge_points(e2, 5)), 3),
               "curvature_at_edge_1": round(nxh.max_curvature(bf, edge_points(e1, 1)[0]), 5), "curvature_at_edge_2": round(nxh.max_curvature(bf, edge_points(e2, 1)[0]), 5)}
        n0 = len(nxh.sheets(part))
        sew(part, s1, [br, s2])
        out["sewn"] = {"sheets_change": len(nxh.sheets(part)) - n0, "faces": len(s1.GetFaces()), "free_edges": len(nxh.free_edges(s1))}
        return out
    case(BR, "G0_G0", lambda: bridge_case(0.0, CT.G0, CT.G0))
    case(BR, "G1_G1", lambda: bridge_case(100.0, CT.G1, CT.G1))
    case(BR, "G2_G2", lambda: bridge_case(200.0, CT.G2, CT.G2))

    NO = notes["NO_normal_follows_section_order"] = {}

    def normal_case(x0, swap):
        y0 = 4200.0
        l1 = nxh.line(part, (x0, y0, 0), (x0 + 40, y0, 0))
        l2 = nxh.line(part, (x0, y0 + 30, 10), (x0 + 40, y0 + 30, 10))
        ss = [nxh.section(part, curves=[l1], help_point=(x0, y0, 0), seed=l1), nxh.section(part, curves=[l2], help_point=(x0, y0 + 30, 10), seed=l2)]
        if swap:
            ss.reverse()
        body = through_curves(part, ss).GetBodies()[0]
        return {"normal_at_mid": [round(v, 4) for v in nxh.normal_at(body.GetFaces()[0], (x0 + 20, y0 + 15, 5))]}
    case(NO, "sections_A_then_B", lambda: normal_case(0.0, False))
    case(NO, "sections_B_then_A", lambda: normal_case(100.0, True))


# ---------------------------------------------------------------- tolerances of an approximating command
def pole_count(part, face):
    """Number of poles of a B-surface face, read through a Point Set (FacePoints / BSurfacePoles); the set is removed again."""
    PSB = NXOpen.Features.PointSetBuilder
    m = nxh.mark("poles", False)
    b = part.Features.CreatePointSetBuilder(NXOpen.Features.PointSet.Null)
    try:
        b.Type = PSB.Types.FacePoints
        b.FacePointsBy = PSB.FacePointsType.BSurfacePoles
        b.MultipleFaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb([face])], False)
        f = b.CommitFeature()
        n = len([e for e in f.GetEntities() if isinstance(e, NXOpen.Point)])
    finally:
        b.Destroy()
    nxh.undo_to(m)
    return n


def t_tolerance(part):
    TL = notes["TOL_swept_tolerances"] = {}

    def torus_case(x0, g0, g1):
        y0 = 4500.0
        R, r = 50.0, 6.0
        guide = nxh.arc(part, (x0, y0, 0), (1, 0, 0), (0, 1, 0), R, 0.0, PI / 2)                       # starts at (x0 + R, y0, 0) heading +Y
        sec = nxh.arc(part, (x0 + R, y0, 0), (1, 0, 0), (0, 0, 1), r, 0.0, PI)                         # half circle in the plane normal to the guide start
        b = part.Features.CreateSweptBuilder(NXOpen.Features.Swept.Null)
        try:
            b.G0Tolerance = g0
            b.G1Tolerance = g1
            ss = [nxh.section(part, curves=[sec], help_point=(x0 + R + r, y0, 0), seed=sec)]
            b.SectionList.Append(ss[0])
            b.AlignmentMethod.SetSections(ss)
            b.GuideList.Append(nxh.section(part, curves=[guide], help_point=(x0 + R, y0, 0), seed=guide))
            b.BodyPreference.BodyType = GU.FeatureOptions.BodyStyle.Sheet
            f = b.CommitFeature()
        finally:
            b.Destroy()
        body = f.GetBodies()[0]
        dev = 0.0
        for phi in (10, 30, 45, 60, 80):
            for sa in (20, 60, 90, 120, 160):
                ph, sr = math.radians(phi), math.radians(sa)
                q = (x0 + (R + r * math.cos(sr)) * math.cos(ph), y0 + (R + r * math.cos(sr)) * math.sin(ph), r * math.sin(sr))
                dev = max(dev, abs(nxh.dist_to(part, body, q)))
        out = {"faces": len(body.GetFaces()), "area": round(nxh.sheet_area(part, body)[0], 3), "analytic_area": round(PI * r * (PI / 2) * R, 3),
               "max_deviation_from_the_true_torus_mm": round(dev, 5)}
        try:
            out["poles"] = sum(pole_count(part, fc) for fc in body.GetFaces())
        except Exception as e:  # noqa: BLE001
            out["poles"] = "n/a: " + str(e)[:120]
        return out
    for i, (g0, g1) in enumerate(((0.01, 0.5), (0.01, 0.05), (0.01, 5.0), (0.001, 0.5), (0.1, 0.5), (0.1, 5.0))):
        case(TL, "G0_%g_G1_%g" % (g0, g1), lambda g0=g0, g1=g1, i=i: torus_case(200.0 * i, g0, g1))


def t_global_shaping(part):
    GS = notes["GS_global_shaping_to_point"] = {}
    GSB = NXOpen.Features.GlobalShapingBuilder

    def to_point(x0, kind):
        y0 = 4800.0
        if kind == "plane":
            sh = bounded_plane(part, [(x0, y0, 0), (x0 + 100, y0, 0), (x0 + 100, y0 + 100, 0), (x0, y0 + 100, 0)])
        else:
            l1 = nxh.line(part, (x0, y0, 0), (x0 + 100, y0, 0))
            l2 = nxh.line(part, (x0, y0 + 100, 0), (x0 + 100, y0 + 100, 0))
            sh = through_curves(part, [nxh.section(part, curves=[l1], help_point=(x0, y0, 0), seed=l1), nxh.section(part, curves=[l2], help_point=(x0, y0 + 100, 0), seed=l2)]).GetBodies()[0]
        circ = nxh.circle(part, (x0 + 50, y0 + 50, 0), 30.0)
        before = list(part.Bodies)
        b = part.Features.CreateGlobalShapingBuilder(NXOpen.Features.GlobalShaping.Null)
        try:
            b.DeformationType = GSB.DeformationTypeValues.ToPoint
            b.DistanceTolerance = 0.01
            b.AngleTolerance = 0.5
            b.SheetToDeform.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(sh)], False)
            reg = b.RegionToDeform
            reg.SetAllowedEntityTypes(ONLY_CURVES)
            nxh.fill_section(part, reg, curves=circ, help_point=(x0 + 80, y0 + 50, 0))
            b.TargetPointMethod = GSB.PointMethodType.OffsetFromSheet
            tp = b.NewTargetPoint()
            GS["target_point_builder_members"] = [n for n in dir(type(tp)) if not n.startswith("_")]
            for nm in ("Point", "TargetPoint"):
                if hasattr(tp, nm):
                    setattr(tp, nm, part.Points.CreatePoint(nxh.P(x0 + 50, y0 + 50, 0)))
            for nm in ("Offset", "TargetPointOffset", "PointOffset"):
                if hasattr(tp, nm):
                    getattr(tp, nm).RightHandSide = "5"
            b.TargetPointsList.Append(tp)
            b.ProjectionDirection = nxh.direction(part, (0, 0, 1))
            f = b.CommitFeature()
        finally:
            b.Destroy()
        new = nxh.new_bodies(part, before)
        tgt = new[0] if new else sh
        return {"feature_type": f.FeatureType, "new_bodies": len(new), "faces": len(tgt.GetFaces()), "bbox": nxh.bbox(tgt),
                "off_centre_raised_5_mm": round(min(abs(nxh.dist_to(part, tgt, (x0 + 50, y0 + 50, z))) for z in (5.0, -5.0)), 4),
                "off_outside_region_mm": round(abs(nxh.dist_to(part, tgt, (x0 + 5, y0 + 5, 0))), 4)}
    case(GS, "planar_sheet", lambda: to_point(0.0, "plane"))
    case(GS, "lofted_flat_sheet", lambda: to_point(200.0, "loft"))


def checks():
    F1, F2, F3 = notes.get("F1_trimming_option", {}), notes.get("F2_sharp_edge_propagation", {}), notes.get("F3_law_radius_swept_section", {})
    q = 0.5 * PI * 5.0                                                    # arc length of the R5 quarter blend

    def blend_is(r, y0, y1, area):
        return ok(r) and abs(r["blend_y_range"][0] - y0) < 0.01 and abs(r["blend_y_range"][1] - y1) < 0.01 and abs(r["blend_area"] - area) < 0.01
    chk.true("F1 TrimmingOption Short: the blend is as long as the SHORT input (y 0..30)", blend_is(F1.get("Short"), 0, 30, q * 30), F1.get("Short"))
    chk.true("F1 TrimmingOption Long: the blend runs the full LONG input (y 0..50), full width", blend_is(F1.get("Long"), 0, 50, q * 50), F1.get("Long"))
    chk.true("F1 TrimmingOption ToAllFaces: runs to 50 but is cut by the boundaries of both inputs (area between Short and Long)",
             blend_is(F1.get("ToAllFaces"), 0, 50, q * 40), F1.get("ToAllFaces"))
    chk.true("F1 TrimmingOption NotSet: untrimmed - the blend overshoots BOTH ends by the radius (y -5..55)", blend_is(F1.get("NotSet"), -5, 55, q * 60), F1.get("NotSet"))
    chk.true("F1 the builder default is ToAllFaces", ok(F1.get("default")) and F1["default"]["blend_area"] == F1["ToAllFaces"]["blend_area"], F1.get("default"))
    chk.true("F1 trim + sew on: one sheet of 3 faces whatever the trimming option (sheet count -1)",
             all(ok(F1.get(k)) and F1[k]["sheets_change"] == -1 and F1[k]["feature_bodies"][0]["faces"] == 3 for k in ("ToAllFaces", "Short", "Long", "NotSet")),
             [F1.get(k, {}).get("sheets_change") for k in ("ToAllFaces", "Short", "Long", "NotSet")])
    chk.true("F1 trim + sew off: the blend is one extra sheet; the trimming option acts the same way",
             blend_is(F1.get("Short_no_trim_no_sew"), 0, 30, q * 30) and blend_is(F1.get("Long_no_trim_no_sew"), 0, 50, q * 50)
             and blend_is(F1.get("NotSet_no_trim_no_sew"), -5, 55, q * 60) and F1["Long_no_trim_no_sew"]["sheets_change"] == 1, F1.get("Long_no_trim_no_sew"))
    d = F1.get("builder_defaults") or {}
    chk.true("F1 builder defaults: AddTangentFaces True, PropagatePastSharpEdges False, PropagationAngle 0.5, trim and sew True",
             d.get("AddTangentFaces") is True and d.get("PropagatePastSharpEdges") is False and abs(d.get("PropagationAngle", 0) - 0.5) < 1e-9
             and d.get("TrimInputFacesToBlendFaces") is True and d.get("SewAllFaces") is True, d)

    sh, st, s3, s1 = (F2.get("first_face_only_trim_short"), F2.get("trim_short_add_tangent_faces"), F2.get("trim_short_past_sharp_angle_3"), F2.get("trim_short_past_sharp_angle_1"))
    chk.true("F2 wall with a 2 deg kink, first chain = the face before the kink: the blend stops at the kink (y 0..30), also with Add Tangent Faces (2 deg is not tangent)",
             ok(sh) and ok(st) and abs(sh["kink_deg"] - 2.0) < 0.01 and abs(sh["blend_y_range"][1] - 30.0) < 0.01 and abs(st["blend_y_range"][1] - 30.0) < 0.01, (sh, st))
    chk.true("F2 PropagatePastSharpEdges + PropagationAngle 3: the blend crosses the kink - 2 blend faces to y = 60, ON the contact line of the tilted face (0.000)",
             ok(s3) and s3["blend_faces"] == 2 and abs(s3["blend_y_range"][1] - 60.0) < 0.01 and s3["off_contact_line_on_tilted_face_at_y_45_mm"] < 1e-3, s3)
    chk.true("F2 PropagationAngle 1 (below the 2 deg kink): no propagation", ok(s1) and s1["blend_faces"] == 1 and abs(s1["blend_y_range"][1] - 30.0) < 0.01, s1)
    df = F2.get("first_face_only_defaults")
    chk.true("F2 trap: with the default trimming the blend of the first face alone runs on along the wall as ONE cylinder on the extension of that face - "
             "it is not on the tilted face (> 0.3 mm off its contact line)", ok(df) and df["blend_faces"] == 1 and df["off_contact_line_on_tilted_face_at_y_45_mm"] > 0.3, df)
    rb = F3.get("rolling_ball_constant_5_with_spine")
    chk.true("F3 rolling ball, constant R5 (a Spine set on the builder is ignored): exact cylinder R5 along the whole corner",
             ok(rb) and rb["type"] == nxh.CYLINDER and all(tuple(rb["radius_at_y_%g" % y]) == (5.0, 0.0) for y in (1.0, 30.0, 59.0)), rb)
    chk.true("F3 NOT WORKING in a journal with the settings tried: BlendType Swept + Spine, and RadiusOption Law (both end in an NX error for all four normal pairs)",
             not ok(F3.get("swept_section_constant_5_with_spine")) and not ok(F3.get("rolling_ball_law_3_to_6")), F3)

    TE = notes.get("TE_until_selected", {})

    def vol(k):
        return TE[k]["block"][0]["volume"] if ok(TE.get(k)) else None
    chk("TE Trim and Extend, Until Selected, target = the solid's faces, tool = the free EDGE of a sheet that ends 3 mm inside: the block is cut right through (40 x 30 x 8)",
        vol("new_tool_edge"), 9600.0, 0.01)
    chk("TE ReverseTool keeps the other side of the cut (40 x 30 x 12)", vol("new_tool_edge_reverse_tool"), 14400.0, 0.01)
    chk("TE ArrowSideOption Delete does the same as ReverseTool here", vol("new_tool_edge_arrow_delete"), 14400.0, 0.01)
    chk("TE ReverseTarget changes nothing on a solid target", vol("new_tool_edge_reverse_target"), 9600.0, 0.01)
    chk.true("TE the tool sheet itself is left as it was (1680 mm2)", ok(TE.get("new_tool_edge")) and abs(TE["new_tool_edge"]["sheet"][0]["area"] - 1680.0) < 0.01, TE.get("new_tool_edge"))
    chk.true("TE the sheet's FACE as tool (no extension): refused ('... intersection gaps.')", "intersection gaps" in TE.get("new_tool_face", {}).get("error", ""), TE.get("new_tool_face"))
    chk.true("TE the legacy builder (TrimExtendBuilder, Type UntilSelected) gives the same three results",
             vol("legacy_tool_edge") is not None and abs(vol("legacy_tool_edge") - 9600.0) < 0.01 and abs(vol("legacy_tool_edge_arrow_delete") - 14400.0) < 0.01
             and "intersection gaps" in TE.get("legacy_tool_face", {}).get("error", ""), (vol("legacy_tool_edge"), TE.get("legacy_tool_face")))

    OS = notes.get("OS_offset_surface", {})
    s0n, s0y = OS.get("sets_5_and_0_step_off", {}), OS.get("sets_5_and_0_step_on", {})
    chk.true("OS two sets (5 and 0) on TANGENT faces without StepOption: refused", "unable to provide a full solution" in s0n.get("error", ""), s0n)
    chk.true("OS the same with StepOption True: ONE sheet of 3 faces - offset face at 5, the untouched face at 0 and a 5 mm shelf face between them",
             ok(s0y) and len(s0y["new_bodies"]) == 1 and s0y["offset_faces"] == 3 and s0y["dist_from_source_points"] == [5.0, 0.0]
             and any(abs(abs(pf["normal"][0]) - 1.0) < 1e-6 and abs(pf["bbox_rel"][3] - pf["bbox_rel"][1] - 5.0) < 1e-3 for pf in s0y["planar_faces"]), s0y)
    lq = OS.get("L_quilt_sets_3_and_5", {})
    chk.true("OS two sets (3 and 5) on faces that meet at a corner: one feature, one sheet, floor at 3 and wall at 5, trimmed to each other",
             ok(lq) and len(lq["new_bodies"]) == 1 and lq["offset_faces"] == 2 and abs(lq["new_bodies"][0]["area"] - (15 * 30 + 17 * 30)) < 0.01, lq)
    t2, te = OS.get("sets_5_and_2_step_off", {}), OS.get("sets_5_and_2_one_feature_for_each_face", {})
    chk.true("OS trap: two NON-zero sets (5 and 2) on tangent faces build without a message, but the faces are extended to their intersection - "
             "the 20 mm plane at 5 survives only 1.59 mm wide", ok(t2) and len(t2["new_bodies"]) == 1 and t2["planar_faces"] and
             (t2["planar_faces"][0]["bbox_rel"][2] - t2["planar_faces"][0]["bbox_rel"][0]) < 5.0, t2)
    chk.true("OS OutputOption OneFeatureForEachFace: two features, two sheets, each face at its own distance (5 and 2), no join",
             ok(te) and te["new_features"] == 2 and len(te["new_bodies"]) == 2 and te["dist_from_source_points"] == [5.0, 2.0], te)
    hc, hcp, ph, rq = (OS.get("half_cylinder_R5_by_6_inward", {}), OS.get("half_cylinder_R5_by_6_inward_partial", {}), OS.get("plane_plus_half_cylinder_R5_by_6_inward", {}),
                       OS.get("R5_quilt_by_6_inward", {}))
    chk.true("OS a face that cannot be offset (R5 by 6 towards its axis) ALONE: error, with and without PartialOption",
             "unable to provide a full solution" in hc.get("error", "") and "unable to provide a full solution" in hcp.get("error", ""), (hc, hcp))
    chk.true("OS trap: the same tight face together with a face that CAN be offset: no error, no alert, GetErrorFaces empty - the tight face is silently missing "
             "(1 face from 2; 2 from 3 between two walls). Count the faces after every Offset Surface.",
             ok(ph) and ph["offset_faces"] == 1 and ph["source_faces"] == 2 and ph["info"]["error_faces"] == 0 and ok(rq) and rq["offset_faces"] == 2 and rq["source_faces"] == 3, (ph, rq))

    VO = notes.get("VO_variable_offset", {})
    vl, vc, vp = VO.get("loft_linear_1_1_5_5", {}), VO.get("loft_cubic_1_1_5_5", {}), VO.get("plane_linear_1_1_5_5", {})
    chk.true("VO Variable Offset (one face, OffsetAtA..D = 1, 1, 5, 5): a new sheet whose four corners are 1 / 1 / 5 / 5 from the source corners and ~3 in the middle",
             all(ok(r) and r["new_bodies"] == 1 and all(abs(a - b) < 0.06 for a, b in zip(sorted(r["corner_distances"]), (1, 1, 5, 5))) and abs(r["mid_distance"] - 3.0) < 0.06
                 for r in (vl, vp)), (vl, vp))
    chk.true("VO Method Cubic: zero slope at the corners (corner distances exactly 5.000; Linear reads 4.97 because the offset sheet is tilted there)",
             ok(vc) and abs(max(vc["corner_distances"]) - 5.0) < 1e-3 and max(vl["corner_distances"]) < 4.99, (vl.get("corner_distances"), vc.get("corner_distances")))
    chk.true("VO works on a planar face too; FeatureType VAR_OFFSET_SHEET", ok(vp) and vp["feature_type"] == "VAR_OFFSET_SHEET", vp)

    EN = notes.get("EN_enlarge", {})

    def area(k):
        return EN[k]["result_area"] if ok(EN.get(k)) else None
    base = EN.get("loft_v_end_25_natural", {}).get("area_before")
    chk.true("EN Enlarge +25 % along the straight direction: area x 1.25, in place (no new body)", ok(EN.get("loft_v_end_25_natural")) and abs(area("loft_v_end_25_natural") / base - 1.25) < 1e-3
             and EN["loft_v_end_25_natural"]["new_bodies"] == 0, EN.get("loft_v_end_25_natural"))
    chk.true("EN along the curved direction Natural continues the curvature, Linear continues straight (different areas, both larger)",
             area("loft_u_end_25_natural") is not None and area("loft_u_end_25_linear") is not None and abs(area("loft_u_end_25_natural") - area("loft_u_end_25_linear")) > 1.0
             and min(area("loft_u_end_25_natural"), area("loft_u_end_25_linear")) > base, (area("loft_u_end_25_natural"), area("loft_u_end_25_linear")))
    chk.true("EN a negative percentage shrinks the face (-20 %: area x 0.8), Natural and Linear alike on NX 2206",
             area("loft_v_end_minus_20_natural") is not None and abs(area("loft_v_end_minus_20_natural") / base - 0.8) < 1e-3
             and area("loft_v_end_minus_20_linear") is not None and abs(area("loft_v_end_minus_20_linear") / base - 0.8) < 1e-3,
             (area("loft_v_end_minus_20_natural"), area("loft_v_end_minus_20_linear")))
    cp = EN.get("loft_v_end_25_copy", {})
    chk.true("EN IsCopy True: a NEW sheet, the source face unchanged", ok(cp) and cp["new_bodies"] == 1 and abs(cp["source_body_now"][0]["area"] - base) < 1e-3
             and abs(cp["result_area"] / base - 1.25) < 1e-3, cp)
    chk.true("EN a PLANAR face in place: 'Invalid face.'; as a copy it works (new B-surface sheet, area x 1.25)",
             "Invalid face" in EN.get("plane_in_place", {}).get("error", "") and ok(EN.get("plane_copy")) and abs(area("plane_copy") - 1500.0) < 0.01
             and EN["plane_copy"]["new_bodies"] == 1, (EN.get("plane_in_place"), EN.get("plane_copy")))
    chk.true("EN a face of a SEWN sheet in place: 'Invalid face.'; as a copy it works and leaves the quilt alone (2 faces)",
             "Invalid face" in EN.get("sewn_face_in_place", {}).get("error", "") and ok(EN.get("sewn_face_copy")) and EN["sewn_face_copy"]["new_bodies"] == 1
             and EN["sewn_face_copy"]["source_body_now"][0]["faces"] == 2, (EN.get("sewn_face_in_place"), EN.get("sewn_face_copy")))

    BR = notes.get("BR_bridge_surface", {})
    b0, b1, b2 = BR.get("G0_G0", {}), BR.get("G1_G1", {}), BR.get("G2_G2", {})
    chk.true("BR Bridge surface between two sheet edges, G0 / G0: a straight ruled strip, creased at both edges (26.6 / 33.4 deg)",
             ok(b0) and b0["g1_dev_edge_1_deg"] > 20.0 and b0["g1_dev_edge_2_deg"] > 20.0, b0)
    chk.true("BR G1 / G1: tangent to both sheets (0.00 deg), curved at the edges", ok(b1) and b1["g1_dev_edge_1_deg"] < 0.05 and b1["g1_dev_edge_2_deg"] < 0.05
             and b1["curvature_at_edge_1"] > 0.01, b1)
    chk.true("BR G2 / G2: tangent and curvature 0 at both edges = the planar neighbours'", ok(b2) and b2["g1_dev_edge_1_deg"] < 0.05 and b2["g1_dev_edge_2_deg"] < 0.05
             and b2["curvature_at_edge_1"] < 1e-3 and b2["curvature_at_edge_2"] < 1e-3, b2)
    chk.true("BR the bridge is a new sheet (BRIDGESRF_SHEET); Sew joins sheet + bridge + sheet into one 3-face sheet",
             all(ok(r) and r["sewn"]["sheets_change"] == -2 and r["sewn"]["faces"] == 3 and r["feature_type"] == "BRIDGESRF_SHEET" for r in (b0, b1, b2)), b1.get("sewn"))

    NO = notes.get("NO_normal_follows_section_order", {})
    na, nb_ = NO.get("sections_A_then_B", {}).get("normal_at_mid"), NO.get("sections_B_then_A", {}).get("normal_at_mid")
    chk.true("NO the same two sections lofted in the other order: the face normal is reversed (every direction flag downstream flips with it)",
             na is not None and nb_ is not None and all(abs(x + y) < 1e-3 for x, y in zip(na, nb_)), (na, nb_))

    TL = notes.get("TOL_swept_tolerances", {})
    r1, r2, r3, r4, r5 = (TL.get("G0_0.01_G1_0.5", {}), TL.get("G0_0.01_G1_0.05", {}), TL.get("G0_0.01_G1_5", {}), TL.get("G0_0.001_G1_0.5", {}), TL.get("G0_0.1_G1_0.5", {}))
    chk.true("TOL Swept of an arc along an arc is an approximation: 0.011 mm off the true torus at G0Tolerance 0.01, 0.040 at 0.1 (within the tolerance each time)",
             ok(r1) and ok(r5) and r1["max_deviation_from_the_true_torus_mm"] <= 0.012 and r1["max_deviation_from_the_true_torus_mm"] < r5["max_deviation_from_the_true_torus_mm"] <= 0.1, (r1, r5))
    chk.true("TOL tightening G0Tolerance to 0.001 buys nothing here (same surface as 0.01); G1Tolerance 0.05 / 0.5 / 5 makes no difference at all",
             ok(r2) and ok(r3) and ok(r4) and r2["area"] == r1["area"] == r3["area"] == r4["area"], (r1.get("area"), r2.get("area"), r3.get("area"), r4.get("area")))
    chk.true("TOL the POSITION tolerance decides how heavy the face is: 121 poles at 0.01 (and at 0.001), 77 at 0.1; the angle tolerance never changed the pole count",
             all(isinstance(r.get("poles"), int) for r in (r1, r2, r3, r4, r5)) and r1["poles"] == r2["poles"] == r3["poles"] == r4["poles"] and r5["poles"] < r1["poles"],
             [r.get("poles") for r in (r1, r2, r3, r4, r5)])

    GS = notes.get("GS_global_shaping_to_point", {})
    for k in ("planar_sheet", "lofted_flat_sheet"):
        r = GS.get(k, {})
        chk.true("GS Global Shaping To Point on a %s: the sheet is deformed IN PLACE (one face), centre of the region raised 5.000, unchanged outside the region" % k.replace("_", " "),
                 ok(r) and r["feature_type"] == "GLOBAL_SHAPING" and r["new_bodies"] == 0 and r["faces"] == 1 and r["off_centre_raised_5_mm"] < 1e-3 and r["off_outside_region_mm"] < 1e-3, r)


def run():
    part = nxh.new_part(os.path.join(OUT, "surf_blend_trim_offset.prt"))
    for name, fn in (("face_blend", t_face_blend), ("trim_extend", t_trim_extend), ("offset", t_offset), ("enlarge_bridge", t_enlarge_bridge),
                     ("tolerance", t_tolerance), ("global_shaping", t_global_shaping)):
        try:
            fn(part)
        except Exception:  # noqa: BLE001
            notes[name + "_error"] = traceback.format_exc()[-900:]
            chk.true(name + " block ran", False, notes[name + "_error"][-300:])
        save_json()
    try:
        checks()
    except Exception:  # noqa: BLE001
        chk.true("checks ran", False, traceback.format_exc()[-500:])
    notes["feature_errors"] = str(nxh.feature_errors(part))
    res["features"] = len(nxh.feature_table(part))
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-500:])
save_json()
