"""Surface repair steps of a core / cavity split, on a product of our own (NX 2206, headless).

    run_journal.ps1 -Script surf_mould_repair.py -WorkDir <out> -JArgs <out>   ->  <out>\\surf_mould_repair.json

Product: 60 x 40 x 20 box, shelled 2 mm with the bottom open, two dia 8 holes in the top wall.
M1  Patch Openings on the two holes (every builder Type is tried; the working ones are recorded).
M2  Delete Edge: remove an inner loop and a notch from a sheet in place; Delete Edge before Extend Sheet on a
    copied product face (Extract Face -> Delete Edge -> Extend Sheet).
M3  Parting sheet: the product's parting-line edges extruded outward as sheets (X sides first, then the Y sides
    with the ends of the X sheets) and sewn; Ribbon Builder as the one-step alternative (recorded).
M4  Use: workpiece block - product, Split Body with the parting sheet + the two patches (not sewn) -> core
    and cavity, volumes exact.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "surf_mould_repair.log"))
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
L, W, H, T, HOLE_R = 60.0, 40.0, 20.0, 2.0, 4.0
HOLES = ((20.0, 20.0), (40.0, 20.0))


def patch_openings(part, faces_rule, edges, type_name="Quilted", output="SingleFeature"):
    """Patch Openings: faces around the openings (a face rule), the opening edges (closed loops). Returns the feature."""
    POB = NXOpen.Features.PatchOpeningsBuilder
    b = part.Features.CreatePatchOpeningsBuilder(NXOpen.Features.PatchOpenings.Null)
    try:
        b.Type = getattr(POB.Types, type_name)
        b.DistanceTolerance = 0.01
        b.Faces.ReplaceRules([faces_rule], False)
        b.Openings.ReplaceRules([part.ScRuleFactory.CreateRuleEdgeDumb(list(edges))], False)
        b.Output = getattr(POB.OutputTypes, output)
        return b.CommitFeature()
    finally:
        b.Destroy()


def delete_edge(part, edges):
    """Delete Edge: remove boundary edges (an inner loop, a notch) from a sheet body IN PLACE. Returns the feature."""
    b = part.Features.CreateDeleteEdgeBuilder(NXOpen.Features.DeleteEdge.Null)
    try:
        b.SimplyEdges.ReplaceRules([part.ScRuleFactory.CreateRuleEdgeDumb(list(edges))], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


def ribbon(part, edges, help_point, distance, view=(0, 0, 1), angle=0, reverse=False):
    """Ribbon Builder: a sheet strip of constant width off an edge chain, flat when angle = 0 to the view direction."""
    b = part.Features.CreateRibbonBuilder(NXOpen.Features.Ribbon.Null)
    try:
        b.DistanceTolerance = 0.01
        b.AngleTolerance = 0.5
        nxh.fill_section(part, b.Profile, edges=list(edges), help_point=help_point)
        b.OffsetView = nxh.direction(part, view)
        b.OffsetDistance.RightHandSide = str(distance)
        b.Angle.RightHandSide = str(angle)
        b.ReverseOffset = reverse
        return b.CommitFeature()
    finally:
        b.Destroy()


def edge_len(e):
    return e.GetLength()


def at(e, **kw):
    """Edge test on its bounding box: at(e, x=60, z=0) -> the edge lies in x = 60 and z = 0."""
    bb = nxh.bbox(e)
    ix = {"x": 0, "y": 1, "z": 2}
    return all(abs(bb[ix[k]] - v) < 1e-6 and abs(bb[ix[k] + 3] - v) < 1e-6 for k, v in kw.items())


def product(part):
    _f, body = nxh.block(part, (0, 0, 0), (L, W, H))
    bottom = nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, -1)), "bottom")
    nxf.shell(part, body, [bottom], T)
    for x, y in HOLES:
        nxh.cylinder(part, (x, y, H - T - 1), (0, 0, 1), 2 * HOLE_R, T + 2, op=nxh.BOOL.Subtract, target=body)
    return body


def run():
    part = nxh.new_part(os.path.join(OUT, "surf_mould_repair.prt"))
    prod = product(part)
    v_prod = L * W * H - (L - 2 * T) * (W - 2 * T) * (H - T) - 2 * math.pi * HOLE_R ** 2 * T
    chk("product volume (shelled box with two holes)", nxh.volume(part, prod), v_prod, 1e-3)
    top = nxh.one(nxh.faces(prod, ftype=nxh.PLANE, normal=(0, 0, 1), at=(2, H)), "top outer face")
    hole_edges = [e for e in prod.GetEdges() if at(e, z=H) and abs(edge_len(e) - 2 * math.pi * HOLE_R) < 1e-6]
    chk.true("two hole edges on the outer face", len(hole_edges) == 2, len(hole_edges))
    rf = part.ScRuleFactory

    # ---------------- M1 Patch Openings
    types = nxh.enum_names(NXOpen.Features.PatchOpeningsBuilder.Types)
    outputs = nxh.enum_names(NXOpen.Features.PatchOpeningsBuilder.OutputTypes)
    res["notes"]["patch_openings_enums"] = {"Types": types, "OutputTypes": outputs}
    def trial_patch(type_name, output):
        """Build, measure, undo: what one Type / Output combination makes on the two holes."""
        m = nxh.mark("patch trial", False)
        before, n0 = list(part.Bodies), len(part.Features.GetFeatures())
        try:
            f = patch_openings(part, rf.CreateRuleFaceTangent(top, []), hole_edges, type_name, output)
            new = nxh.new_bodies(part, before)
            out = {"result": "built" if new else "no body", "returned": type(f).__name__,
                   "new_features": [(x.GetFeatureName(), x.FeatureType) for x in part.Features.GetFeatures()[n0:]],
                   "bodies": len(new), "solid": [b.IsSolidBody for b in new],
                   "areas": [round(nxh.sheet_area(part, b)[0], 4) for b in new if not b.IsSolidBody],
                   "face_types": [nxh.face_data(fc)[0] for b in new for fc in b.GetFaces()],
                   "product_volume": nxh.volume(part, prod), "errors": nxh.feature_errors(part, recheck=False)}
        except Exception as e:  # noqa: BLE001
            out = {"result": "NOT WORKING", "error": str(e)[:300]}
        nxh.undo_to(m)
        return out

    trial = {tn: trial_patch(tn, "SingleFeature") for tn in types}
    res["notes"]["patch_openings_types"] = trial
    res["notes"]["patch_openings_outputs"] = {on: trial_patch("Quilted", on) for on in outputs if on != "SingleFeature"}
    nxh.write_json(os.path.join(OUT, "surf_mould_repair.json"), res)
    before = list(part.Bodies)
    patch_openings(part, rf.CreateRuleFaceTangent(top, []), hole_edges, "Quilted", "SingleFeature")       # the keeper
    patches = nxh.new_bodies(part, before)
    q = trial.get("Quilted", {})
    chk.true("M1 Patch Openings, Type Quilted, tangent-face rule + 2 hole edges: builds", q.get("result") == "built", q)
    area = math.pi * HOLE_R ** 2
    chk.true("M1 Quilted: one planar patch per hole, area pi r^2 each", q.get("result") == "built" and sorted(q["areas"]) == sorted([round(area, 4)] * 2)
             or (q.get("result") == "built" and len(q["areas"]) == 1 and abs(q["areas"][0] - 2 * area) < 1e-3), q.get("areas"))
    patch_faces = [fc for b in patches for fc in b.GetFaces()]
    chk.true("M1 patches lie in the outer face plane and close the hole edges", all(abs(nxh.min_dist(fc, e)) < 1e-6 for fc in patch_faces for e in hole_edges
             if abs(nxh.min_dist(fc, e)) < 1.0) and all(abs(nxh.bbox(fc)[2] - H) < 1e-3 for fc in patch_faces), [nxh.bbox(fc) for fc in patch_faces])
    chk.true("M1 the product is untouched and the patches are separate sheet bodies", abs(nxh.volume(part, prod) - v_prod) < 1e-3
             and all(not b.IsSolidBody for b in patches), len(patches))
    planar_ok = sorted(tn for tn, t in trial.items() if t.get("result") == "built" and sorted(t["areas"]) == sorted([round(area, 4)] * 2))
    res["notes"]["patch_openings_types_that_close_a_planar_hole"] = planar_ok
    chk.true("M1 other types that give the same planar patches on round holes in a flat wall", {"NSided", "Mesh"} <= set(planar_ok), planar_ok)
    chk.true("M1 Output = Sew is refused when the faces belong to a solid",
             "solid body" in res["notes"]["patch_openings_outputs"].get("Sew", {}).get("error", ""), res["notes"]["patch_openings_outputs"].get("Sew"))

    # M1b a hole in a CURVED wall: does the patch follow the wall surface?
    _f, tube = nxh.cylinder(part, (0, 100, 0), (0, 0, 1), 40, 30)
    nxh.cylinder(part, (0, 100, 0), (0, 0, 1), 36, 30, op=nxh.BOOL.Subtract, target=tube)
    nxh.cylinder(part, (0, 100, 15), (1, 0, 0), 2 * HOLE_R, 25, op=nxh.BOOL.Subtract, target=tube)
    wall = nxh.one(nxh.faces(tube, ftype=nxh.CYLINDER, radius=20.0), "tube outer wall")
    loop = [e for e in wall.GetEdges() if any(nxh.face_data(fc)[0] == nxh.CYLINDER and abs(abs(nxh.face_data(fc)[3]) - HOLE_R) < 1e-6 for fc in e.GetFaces())]
    curved = {}
    for tn in ("Quilted", "NSided", "Mesh", "ByDeletingEdges"):
        m = nxh.mark("curved trial", False)
        before = list(part.Bodies)
        try:
            patch_openings(part, rf.CreateRuleFaceTangent(wall, []), loop, tn)
            new = nxh.new_bodies(part, before)
            curved[tn] = {"result": "built" if new else "no body", "bodies": len(new), "areas": [round(nxh.sheet_area(part, b)[0], 4) for b in new],
                          "face_types": [nxh.face_data(fc)[0] for b in new for fc in b.GetFaces()],
                          "centre_off_wall": [abs(nxh.dist_to(part, b, (20.0, 100.0, 15.0))) for b in new]}
        except Exception as e:  # noqa: BLE001
            curved[tn] = {"result": "NOT WORKING", "error": str(e)[:300]}
        nxh.undo_to(m)
    res["notes"]["patch_openings_curved_wall"] = dict(curved, hole_loop_edges=len(loop), flat_patch_would_be_off_by=20.0 - math.sqrt(400.0 - HOLE_R ** 2))
    qc = curved.get("Quilted", {})
    chk.true("M1b Quilted on a hole in a cylindrical wall: the patch lies on the wall surface (centre within 0.01)",
             qc.get("result") == "built" and max(qc["centre_off_wall"]) < 0.01, qc)

    # ---------------- M2 Delete Edge
    pts = [(100, 0), (140, 0), (140, 20), (125, 20), (125, 15), (115, 15), (115, 20), (100, 20)]
    outer = nxh.polyline(part, [(x, y, 0.0) for x, y in pts])
    circ = nxh.circle(part, (108.0, 10.0, 0.0), 3.0)
    sheet = nxf.bounded_plane(part, curves=outer + circ, hp=(100.0, 0.0, 0.0)).GetBodies()[0]
    a0 = nxh.sheet_area(part, sheet)[0]
    chk("M2 test sheet with notch and hole: area", a0, 800 - 50 - math.pi * 9, 1e-3)
    n_edges0 = len(sheet.GetEdges())
    # contrast: Extend Sheet on the notched side WITHOUT healing it first
    top_edges = [e for e in sheet.GetEdges() if at(e, y=20)]
    m = nxh.mark("extend contrast", False)
    try:
        nxf.extend_sheet(part, top_edges, 5)
        res["notes"]["extend_before_delete_edge"] = {"result": "built", "area": nxh.sheet_area(part, sheet)[0], "edges": len(sheet.GetEdges()),
                                                     "bbox": nxh.bbox(sheet)}
    except Exception as e:  # noqa: BLE001
        res["notes"]["extend_before_delete_edge"] = {"result": "NOT WORKING", "error": str(e)[:300]}
    nxh.undo_to(m)
    eb = res["notes"]["extend_before_delete_edge"]
    chk.true("M2 Extend Sheet on the notched edge without Delete Edge keeps the notch as a slot (area a0 + 2 x 15 x 5)",
             eb.get("result") == "built" and abs(eb["area"] - (a0 + 150.0)) < 1e-3, eb)
    hole = [e for e in sheet.GetEdges() if abs(nxh.bbox(e)[0] - 105) < 1e-3 or abs(nxh.bbox(e)[3] - 111) < 1e-3]
    hole = [e for e in hole if nxh.bbox(e)[3] <= 111.01 and nxh.bbox(e)[0] >= 104.99]
    f1 = delete_edge(part, hole)
    a1 = nxh.sheet_area(part, sheet)[0]
    chk("M2 Delete Edge on the inner loop: the hole is gone (area)", a1, 750.0, 1e-3)
    notch = [e for e in sheet.GetEdges() if (at(e, x=115) or at(e, x=125) or at(e, y=15))]
    chk.true("M2 the notch has 3 edges", len(notch) == 3, len(notch))
    f2 = delete_edge(part, notch)
    a2 = nxh.sheet_area(part, sheet)[0]
    chk("M2 Delete Edge on the notch edges: full rectangle back (area)", a2, 800.0, 1e-3)
    chk.true("M2 Delete Edge works in place: same body, 4 edges left", len(nxh.sheets(part)) >= 1 and len(sheet.GetEdges()) == 4, (n_edges0, len(sheet.GetEdges())))
    res["notes"]["delete_edge"] = {"feature_type": f1.FeatureType, "class": type(f1).__name__, "areas": [a0, a1, a2], "edges": [n_edges0, len(sheet.GetEdges())]}
    nxf.extend_sheet(part, [e for e in sheet.GetEdges() if at(e, y=20)], 5)
    chk("M2 Extend Sheet after Delete Edge: clean 40 x 25", nxh.sheet_area(part, sheet)[0], 1000.0, 1e-3)

    # the mould use: copy the product's top face, heal the holes, extend
    cf = nxf.extract_face(part, top)
    copy = cf.GetBodies()[0]
    chk("M2 copied product face: area with the two holes", nxh.sheet_area(part, copy)[0], L * W - 2 * area, 1e-3)
    loops = [e for e in copy.GetEdges() if abs(edge_len(e) - 2 * math.pi * HOLE_R) < 1e-6]
    delete_edge(part, loops)
    chk("M2 Delete Edge on the copied face: holes healed", nxh.sheet_area(part, copy)[0], L * W, 1e-3)
    nxf.extend_sheet(part, list(copy.GetEdges()), 10)
    a_ext = nxh.sheet_area(part, copy)[0]
    res["notes"]["copied_face_extended"] = {"area": a_ext, "bbox": nxh.bbox(copy)}
    chk("M2 Extend Sheet 10 on all four edges of the healed copy: 80 x 60", a_ext, (L + 20) * (W + 20), 1e-3)

    # ---------------- M3 parting sheet from the parting-line edges
    rim = {"+x": nxh.one([e for e in prod.GetEdges() if at(e, x=L, z=0)], "rim +x"), "-x": nxh.one([e for e in prod.GetEdges() if at(e, x=0, z=0)], "rim -x"),
           "+y": nxh.one([e for e in prod.GetEdges() if at(e, y=W, z=0)], "rim +y"), "-y": nxh.one([e for e in prod.GetEdges() if at(e, y=0, z=0)], "rim -y")}
    EXT = 30.0
    sx = {}
    for key, vec in (("+x", (1, 0, 0)), ("-x", (-1, 0, 0))):
        f = nxh.extrude(part, nxh.section(part, edges=[rim[key]], help_point=nxh.bbox(rim[key])[:3]), vec, 0, EXT)
        sx[key] = f.GetBodies()[0]
    chk.true("M3 an edge extruded with an open section gives a sheet", all(not b.IsSolidBody for b in sx.values()))
    sy = {}
    for key, vec, yv in (("+y", (0, 1, 0), W), ("-y", (0, -1, 0), 0.0)):
        ends = [e for b in sx.values() for e in b.GetEdges() if at(e, y=yv, z=0)]
        chain = sorted([rim[key]] + ends, key=lambda e: nxh.bbox(e)[0])
        f = nxh.extrude(part, nxh.section(part, edges=chain, help_point=nxh.bbox(chain[0])[:3], seed=chain[0]), vec, 0, EXT)
        sy[key] = f.GetBodies()[0]
    parting = nxf.sew(part, sx["+x"], [sx["-x"], sy["+y"], sy["-y"]])
    a_part = nxh.sheet_area(part, parting)[0]
    free = nxh.free_edges(parting)
    res["notes"]["parting_sheet"] = {"area": a_part, "faces": len(parting.GetFaces()), "free_edges": len(free), "free_length": sum(edge_len(e) for e in free),
                                     "bbox": nxh.bbox(parting)}
    chk("M3 sewn parting sheet: area = outer rectangle - product footprint", a_part, (L + 2 * EXT) * (W + 2 * EXT) - L * W, 1e-3)
    chk("M3 parting sheet: free edges = outer loop + the product rim", sum(edge_len(e) for e in free), 2 * (L + W + 4 * EXT) + 2 * (L + W), 1e-3)
    chk.true("M3 parting sheet is one sheet body touching all four rim edges", not parting.IsSolidBody and all(abs(nxh.min_dist(parting, e)) < 1e-9 for e in rim.values()))
    # Ribbon Builder as the one-step alternative (recorded)
    rib = {}
    for rev in (False, True):
        m = nxh.mark("ribbon trial", False)
        before = list(part.Bodies)
        try:
            f = ribbon(part, list(rim.values()), nxh.bbox(rim["-y"])[:3], 10, reverse=rev)
            new = nxh.new_bodies(part, before)
            rib["reverse=%s" % rev] = {"result": "built" if new else "no body", "returned": type(f).__name__, "bodies": len(new),
                                       "feature_type": getattr(f, "FeatureType", None),
                                       "areas": [round(nxh.sheet_area(part, b)[0], 3) for b in new], "bbox": [nxh.bbox(b) for b in new]}
        except Exception as e:  # noqa: BLE001
            rib["reverse=%s" % rev] = {"result": "NOT WORKING", "error": str(e)[:300]}
        nxh.undo_to(m)
    res["notes"]["ribbon"] = rib
    ro = rib.get("reverse=False", {})
    chk.true("M3 Ribbon Builder on the rim, 10 wide, angle 0: one flat ring outside the rim with rounded corners (2000 + 100 pi)",
             ro.get("result") == "built" and len(ro["areas"]) == 1 and abs(ro["areas"][0] - (2000.0 + 100.0 * math.pi)) < 0.5, ro)

    # ---------------- M4 core / cavity: block - product, Split Body by parting sheet + patches (not sewn)
    _f, blk = nxh.block(part, (-20, -20, -10), (100, 80, 40))
    nxh.subtract(part, blk, [prod], keep_tool=True)
    v_blk = 100 * 80 * 40 - v_prod
    chk("M4 workpiece - product (tool kept): volume", nxh.volume(part, blk), v_blk, 1e-2)
    tool_faces = list(parting.GetFaces()) + patch_faces
    n0 = len(nxh.solids(part))
    _sf, pieces = nxf.split_body(part, [blk], faces=tool_faces)
    vols = sorted(nxh.volume(part, b) for b in pieces)
    v_core = 100 * 80 * 10 + (L - 2 * T) * (W - 2 * T) * (H - T) + 2 * math.pi * HOLE_R ** 2 * T
    res["notes"]["split"] = {"pieces": len(pieces), "volumes": vols, "solids": [n0, len(nxh.solids(part))]}
    chk.true("M4 Split Body with parting sheet + 2 patches as one tool: two pieces", len(pieces) == 2 and len(nxh.solids(part)) == n0 + 1, len(pieces))
    if len(pieces) == 2:
        chk("M4 core half volume (slab + core + hole plugs)", vols[0], v_core, 1e-2)
        chk("M4 cavity half volume", vols[1], v_blk - v_core, 1e-2)
    chk.true("M4 no feature errors", not nxh.feature_errors(part), nxh.feature_errors(part))
    res["features"] = [(f["name"], f["type"]) for f in nxh.feature_table(part)]
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-500:])
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "surf_mould_repair.json"), res)
