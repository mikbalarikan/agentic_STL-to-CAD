"""Change the blade count of an existing wheel on NX 2206: parametric model and imported, parameter-free body.

    run_journal.ps1 -Script blade_edit_count.py -WorkDir <out> -JArgs <out>   ->  <out>\\blade_edit_count.json

E1  Parametric wheel (nxblade.helicoid_wheel, 7 blades): set the count expression to 5, update.
E2  The same 7-blade wheel exported to STEP and re-imported (one BREP body, no parameters):
    blade_groups -> Delete Face (heal) on all blades but one -> Pattern Geometry of the body x 5 -> Unite.
    The result is compared with the parametric 5-blade wheel.
E3  The shortcut that is wrong: deleting only two of the seven blades leaves five blades at 360/7 spacing.
E4  Pattern Face on the faces of the kept blade instead of Pattern Geometry + Unite: same result, one feature.
"""
import os
import sys
import time
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
sys.path.insert(0, os.environ.get("NXBLADE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402
import nxblade as nb  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "blade_edit_count.log"))
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
R_MID, Z0, Z1 = 39.0, -6.0, 30.0
st = {}


def spacing(groups):
    n = len(groups)
    return [round((groups[(i + 1) % n]["angle"] - groups[i]["angle"]) % 360.0, 3) for i in range(n)]


def e1_parametric():
    part = nxh.new_part(os.path.join(OUT, "blade_edit_count.prt"))
    w = nb.helicoid_wheel(part, n_blades=7)
    body = w["body"]
    st["v7"] = nxh.volume(part, body)
    chk.true("E1 parametric wheel: 7 blades", nb.blade_count_section(part, body, R_MID, Z0, Z1) == 7)
    st["stp"] = nxf.step_export(part, os.path.join(OUT, "blade_edit_count_7.step"))
    nxh.set_expr(part, "n_blades", 5)
    nxh.update()
    groups, _hub = nb.blade_groups(part, body)
    st["v5"] = nxh.volume(part, body)
    chk.true("E1 n_blades 7->5: one solid, no feature errors", len(nxh.solids(part)) == 1 and not nxh.feature_errors(part), nxh.feature_errors(part))
    chk.true("E1 n_blades 7->5: 5 blades by section and by topology",
             nb.blade_count_section(part, body, R_MID, Z0, Z1) == 5 and len(groups) == 5, len(groups))
    chk.true("E1 n_blades 7->5: evenly spaced at 72 deg", all(abs(a - 72.0) < 0.01 for a in spacing(groups)), spacing(groups))
    chk("E1 volume per blade unchanged by the count", (st["v5"] - w["hub_volume"]) / 5, (st["v7"] - w["hub_volume"]) / 7, 0.01)
    res["notes"]["parametric"] = {"v7": st["v7"], "v5": st["v5"], "hub": w["hub_volume"]}
    nxh.close_all()


def e2_imported():
    part = nxh.new_part(os.path.join(OUT, "blade_edit_count_import.prt"))
    body = nxf.step_import(part, st["stp"], os.path.join(OUT, "blade_edit_count_tmp.prt"))[0]
    n_feat = 1 + sum(len(f.GetExpressions()) for f in part.Features.GetFeatures() if f.FeatureType != "DATUM_CSYS")
    groups, hub = nb.blade_groups(part, body)
    info = {"features": [(f["name"], f["type"]) for f in nxh.feature_table(part)], "faces": len(body.GetFaces()),
            "volume": nxh.volume(part, body), "groups": len(groups), "faces_per_blade": sorted(len(g["faces"]) for g in groups),
            "hub_faces": len(hub), "spacing": spacing(groups)}
    res["notes"]["imported"] = info
    chk("E2 imported body = the exported wheel (relative volume)", info["volume"] / st["v7"], 1.0, 1e-5)
    chk.true("E2 imported body has no parameters (no feature owns an expression)", n_feat == 1, info["features"])
    chk.true("E2 imported: 7 blade groups by topology, 7 by section", len(groups) == 7 and nb.blade_count_section(part, body, R_MID, Z0, Z1) == 7, len(groups))
    chk("E2 imported: blade thickness measured on the faces", nb.blade_thickness(part, groups[0]), 3.0, 0.002)

    # E3 the wrong shortcut: delete two blades only
    m = nxh.mark("delete two", False)
    try:
        nxf.delete_face(part, [f for g in groups[:2] for f in g["faces"]])
        g2, _h = nb.blade_groups(part, body)
        sp = spacing(g2)
        res["notes"]["delete_two_of_seven"] = {"blades": len(g2), "spacing": sp}
        chk.true("E3 deleting 2 of 7 blades leaves 5 blades that are NOT evenly spaced", len(g2) == 5 and max(sp) - min(sp) > 50.0, sp)
    finally:
        nxh.undo_to(m)

    # E2 the working route
    t = time.time()
    _df, kept = nb.strip_blades(part, body, keep=1)
    t_strip = time.time() - t
    one = {"count": nb.blade_count_section(part, body, R_MID, Z0, Z1), "faces": len(body.GetFaces()), "ok": nxh.examine_geometry(part, body),
           "volume": nxh.volume(part, body), "sec": round(t_strip, 1)}
    res["notes"]["stripped_to_one"] = one
    chk.true("E2 Delete Face on 6 blade groups: one blade left, body healthy", one["count"] == 1 and all(v == 0 for v in one["ok"].values()), one)

    # E4 Pattern Face alternative: one synchronous feature on the same body (then undone; E2 continues below)
    g1, _h = nb.blade_groups(part, body)
    m = nxh.mark("pattern face", False)
    t = time.time()
    try:
        nb.pattern_faces(part, g1[0]["faces"], 5)
        gp, _h = nb.blade_groups(part, body)
        pfr = {"result": "built", "blades": len(gp), "spacing": spacing(gp), "volume": nxh.volume(part, body), "solids": len(nxh.solids(part)),
               "examine": nxh.examine_geometry(part, body), "errors": nxh.feature_errors(part), "sec": round(time.time() - t, 1)}
    except Exception as e:  # noqa: BLE001
        pfr = {"result": "NOT WORKING", "error": str(e)[:400]}
    res["notes"]["pattern_face"] = pfr
    chk.true("E4 Pattern Face of the kept blade's faces x5: 5 evenly spaced blades, one healthy solid",
             pfr.get("result") == "built" and pfr["blades"] == 5 and pfr["solids"] == 1 and all(abs(a - 72.0) < 0.01 for a in pfr["spacing"])
             and all(v == 0 for v in pfr["examine"].values()) and not pfr["errors"], pfr)
    if pfr.get("result") == "built":
        chk("E4 Pattern Face result = the parametric 5-blade wheel (relative volume)", pfr["volume"] / st["v5"], 1.0, 1e-5)
    try:
        nxh.undo_to(m)
    except Exception:  # noqa: BLE001
        pass

    t = time.time()
    nb.repattern(part, body, 5)
    groups5, _h = nb.blade_groups(part, body)
    out = {"solids": len(nxh.solids(part)), "volume": nxh.volume(part, body), "faces": len(body.GetFaces()), "groups": len(groups5),
           "section_count": nb.blade_count_section(part, body, R_MID, Z0, Z1), "spacing": spacing(groups5),
           "examine": nxh.examine_geometry(part, body), "errors": nxh.feature_errors(part), "r_tip": nb.radial_extent(body)[1],
           "thickness": nb.blade_thickness(part, groups5[0]), "sec": round(time.time() - t, 1)}
    res["notes"]["repatterned_5"] = out
    chk.true("E2 re-pattern x5 + Unite: one solid, no feature errors", out["solids"] == 1 and not out["errors"], out["errors"])
    chk.true("E2 result: 5 blades by section and by topology", out["section_count"] == 5 and out["groups"] == 5, out["groups"])
    chk.true("E2 result: evenly spaced at 72 deg", all(abs(a - 72.0) < 0.01 for a in out["spacing"]), out["spacing"])
    chk.true("E2 result: Examine Geometry clean", all(v == 0 for v in out["examine"].values()), out["examine"])
    chk("E2 result = the parametric 5-blade wheel (relative volume)", out["volume"] / st["v5"], 1.0, 1e-5)
    chk("E2 result: tip radius kept", out["r_tip"], 60.0, 0.001)
    chk("E2 result: blade thickness kept", out["thickness"], 3.0, 0.002)
    res["features_after_edit"] = [(f["name"], f["type"]) for f in nxh.feature_table(part)]
    stp = nxf.step_export(part, os.path.join(OUT, "blade_edit_count_5.step"))
    gate = nb.step_gate(stp)
    res["notes"]["gate"] = gate
    if gate.get("available"):
        chk.true("E2 edited STEP passes the validity gate (valid, watertight, 1 solid)",
                 gate.get("valid") and gate.get("watertight") and gate.get("solids") == 1, {k: gate.get(k) for k in ("valid", "watertight", "solids", "errors")})
    else:
        rt = nxf.step_roundtrip_check(stp, OUT, "blade_edit_count", restore=part, part=part)
        chk.true("E2 edited STEP round trip (gate interpreter not installed)", rt.get("match") and rt.get("healthy"), rt.get("max_rel"))
    nxh.close_all()


for name, fn in (("E1", e1_parametric), ("E2-E4", e2_imported)):
    try:
        fn()
    except Exception:  # noqa: BLE001
        res.setdefault("errors", {})[name] = traceback.format_exc()
        chk.true(name + " ran without an exception", False, traceback.format_exc()[-300:])
        try:
            nxh.close_all()
        except Exception:  # noqa: BLE001
            pass
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "blade_edit_count.json"), res)
