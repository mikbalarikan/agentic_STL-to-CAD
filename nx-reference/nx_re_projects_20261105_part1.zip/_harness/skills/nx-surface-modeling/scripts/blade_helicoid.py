"""Thin-blade wheel (propeller / axial fan) on NX 2206: Helix + Swept + Thicken, hub by Revolve,
Pattern Geometry of the blade BODY, one Unite, root blend - with every claim measured.

    run_journal.ps1 -Script blade_helicoid.py -WorkDir <out> -JArgs <out>   ->  <out>\\blade_helicoid.json

T1  Which Swept orientation gives a helicoid on a helix guide: Fixed / ByVectorDirection / two helices.
T2  The wheel (nxblade.helicoid_wheel): 5 blades, tip 60, hub 18, pitch 120, wrap 72 deg, thickness 3.
T3  Regeneration: blade count 5 -> 7, pitch 120 -> 150 and thickness 3 -> 4, back to nominal.
T4  Deliverable: STEP export, benchmark validity gate.
T5  Why Pattern Geometry and not Pattern Feature: what a Pattern Feature of the Thicken copies (notes).
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
sys.path.insert(0, os.environ.get("NXBLADE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import nxh  # noqa: E402
import nxf  # noqa: E402
import nxblade as nb  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "blade_helicoid.log"))
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
N, R_TIP, R_HUB, R_BORE, PITCH, WRAP, THK, ROOT_R, MARGIN = 5, 60.0, 18.0, 6.0, 120.0, 72.0, 3.0, 1.5, 6.0


def t1_orientation():
    """Radial line r 16..62 swept along a helix (pitch 120, 72 deg): distance of 9 x 13 true helicoid points."""
    part = nxh.new_part(os.path.join(OUT, "blade_helicoid_orient.prt"))
    r0, r1 = R_HUB - 2, R_TIP + 2
    table = {}
    for key in ("fixed", "vector", "two"):
        lf, ln = nb.assoc_line(part, (r0, 0, 0), (r1, 0, 0))
        hf, hc = nb.helix(part, 2 * r1, PITCH, WRAP / 360.0)
        sec = nb.feature_section(part, lf, ln, (r0, 0, 0))
        g = nb.feature_section(part, hf, hc, (r1, 0, 0))
        if key == "two":
            hf2, hc2 = nb.helix(part, 2 * r0, PITCH, WRAP / 360.0)
            f = nb.swept(part, [sec], [nb.feature_section(part, hf2, hc2, (r0, 0, 0)), g], scaling=nb.SO.Uniform)
        else:
            f = nb.swept(part, [sec], [g], orientation=key)
        sheet = f.GetBodies()[0]
        table[key] = {"max_deviation": nb.helicoid_deviation(part, sheet, r0, r1, PITCH, WRAP, nr=9, nt=13),
                      "area": nxh.sheet_area(part, sheet)[0]}
    area = nb.helicoid_area(r0, r1, PITCH, WRAP)
    res["notes"]["orientation"] = dict(table, analytic_area=area)
    chk.true("T1 Fixed orientation is NOT a helicoid (deviation > 1 mm)", table["fixed"]["max_deviation"] > 1.0,
             "%.3f mm" % table["fixed"]["max_deviation"])
    chk("T1 ByVectorDirection(Z): max deviation from the helicoid", table["vector"]["max_deviation"], 0.0, 0.01)
    chk("T1 two helix guides: max deviation from the helicoid", table["two"]["max_deviation"], 0.0, 0.005)
    chk("T1 ByVectorDirection: area", table["vector"]["area"], area, 0.2)
    chk("T1 two helix guides: area", table["two"]["area"], area, 0.2)
    nxh.close_all()


def measure(part, w, n, pitch, thk):
    body = w["body"]
    rise = pitch * WRAP / 360.0
    groups, hub = nb.blade_groups(part, body)
    ext = nb.radial_extent(body)
    return {"solids": len(nxh.solids(part)), "volume": nxh.volume(part, body), "errors": nxh.feature_errors(part),
            "examine": nxh.examine_geometry(part, body), "groups": len(groups),
            "group_areas": sorted(round(g["area"], 3) for g in groups),
            "group_faces": sorted(len(g["faces"]) for g in groups),
            "pitch_angles": [round((groups[(i + 1) % len(groups)]["angle"] - groups[i]["angle"]) % 360.0, 3) for i in range(len(groups))],
            "hub_faces": len(hub), "section_count": nb.blade_count_section(part, body, (R_HUB + R_TIP) / 2, -MARGIN, rise + MARGIN),
            "classes": sorted(nb.face_classes(part, body, faces=[f for g in groups for f in g["faces"]]).values()),
            "r_tip": ext[1], "r_bore": ext[0],
            "thickness": [nb.blade_thickness(part, g) for g in groups],
            "sheet_deviation": nb.helicoid_deviation(part, w["sheet"], R_HUB - 2, R_TIP + 2, pitch, WRAP)}


def check_wheel(tag, m, n, thk):
    chk.true(tag + " one solid", m["solids"] == 1, m["solids"])
    chk.true(tag + " no feature errors", not m["errors"], m["errors"])
    chk.true(tag + " Examine Geometry clean", all(v == 0 for v in m["examine"].values()), m["examine"])
    chk.true(tag + " blade count by section at mid radius = %d" % n, m["section_count"] == n, m["section_count"])
    chk.true(tag + " blade count by topology (face groups) = %d" % n, m["groups"] == n, m["groups"])
    chk.true(tag + " all blades identical (group areas, face counts)",
             m["group_areas"][0] == m["group_areas"][-1] and m["group_faces"][0] == m["group_faces"][-1], m["group_areas"])
    chk.true(tag + " blades evenly spaced (360/%d)" % n, all(abs(a - 360.0 / n) < 0.01 for a in m["pitch_angles"]), m["pitch_angles"])
    chk.true(tag + " face census of the blade faces: every congruence class occurs %d or a multiple of %d times" % (n, n),
             bool(m["classes"]) and all(c % n == 0 for c in m["classes"]), m["classes"])
    chk(tag + " tip radius", m["r_tip"], R_TIP, 1e-6)
    chk(tag + " blade thickness (min of all blades)", min(m["thickness"]), thk, 1e-6)
    chk(tag + " blade thickness (max of all blades)", max(m["thickness"]), thk, 1e-6)
    chk(tag + " blade sheet is a helicoid", m["sheet_deviation"], 0.0, 0.005)


def t2_wheel():
    part = nxh.new_part(os.path.join(OUT, "blade_helicoid.prt"))
    w = nb.helicoid_wheel(part, N, R_TIP, R_HUB, R_BORE, PITCH, WRAP, THK, ROOT_R, MARGIN, edge_r="0.45*thk")
    res["notes"]["hub_sketch"] = w["hub_sketch_status"]
    chk.true("T2 hub sketch fully constrained", w["hub_sketch_status"]["status"] == "WellConstrained" and w["hub_sketch_status"]["dof"] == 0,
             w["hub_sketch_status"])
    rise = PITCH * WRAP / 360.0
    chk("T2 hub volume (hollow cylinder)", w["hub_volume"], math.pi * (R_HUB ** 2 - R_BORE ** 2) * (rise + 2 * MARGIN), 1e-3)
    blank = nb.helicoid_area(R_HUB - 2, R_TIP + 2, PITCH, WRAP) * THK
    chk("T2 blade blank volume = helicoid area x thk (relative)", w["blank_volume"] / blank, 1.0, 1e-3)
    chk.true("T2 tip cut removed material", w["blade_volume"] < w["blank_volume"], (w["blank_volume"], w["blade_volume"]))
    chk.true("T2 leading / trailing edge blend removed material", w["blade_volume_rounded"] < w["blade_volume"],
             w["blade_volume"] - w["blade_volume_rounded"])
    m = measure(part, w, N, PITCH, THK)
    res["notes"]["wheel"] = dict(m, hub_volume=w["hub_volume"], blade_volume=w["blade_volume_rounded"], volume_no_blend=w["volume_no_blend"])
    check_wheel("T2", m, N, THK)
    chk.true("T2 root blend added material", m["volume"] > w["volume_no_blend"], m["volume"] - w["volume_no_blend"])
    per_blade_5 = (w["volume_no_blend"] - w["hub_volume"]) / N
    v_nom = m["volume"]

    # T3 regeneration
    nxh.set_expr(part, "n_blades", 7)
    nxh.update()
    m7 = measure(part, w, 7, PITCH, THK)
    res["notes"]["n7"] = m7
    check_wheel("T3 n_blades 5->7:", m7, 7, THK)
    chk("T3 root blend follows the count: blend volume per blade is the same", (m7["volume"] - w["hub_volume"]) / 7,
        (v_nom - w["hub_volume"]) / N, 0.01)
    nxh.set_expr(part, "n_blades", N)
    nxh.set_expr(part, "pitch", 150)
    nxh.set_expr(part, "thk", 4)
    nxh.update()
    me = measure(part, w, N, 150.0, 4.0)
    res["notes"]["pitch150_thk4"] = me
    check_wheel("T3 pitch 150, thk 4:", me, N, 4.0)
    nxh.set_expr(part, "pitch", PITCH)
    nxh.set_expr(part, "thk", THK)
    nxh.update()
    chk("T3 back to nominal: volume reproduced (relative)", nxh.volume(part, w["body"]) / v_nom, 1.0, 1e-6)
    chk.true("T3 back to nominal: no feature errors", not nxh.feature_errors(part), nxh.feature_errors(part))
    res["notes"]["per_blade_volume_no_blend"] = per_blade_5
    res["features"] = [(f["name"], f["type"]) for f in nxh.feature_table(part)]

    # T4 deliverable
    stp = nxf.step_export(part, os.path.join(OUT, "blade_helicoid.step"))
    gate = nb.step_gate(stp)
    res["notes"]["gate"] = gate
    if gate.get("available"):
        chk.true("T4 STEP passes the validity gate (valid, watertight, 1 solid)",
                 gate.get("valid") and gate.get("watertight") and gate.get("solids") == 1, {k: gate.get(k) for k in ("valid", "watertight", "solids", "errors")})
        chk("T4 STEP volume = NX volume (relative)", gate["volume"] / v_nom, 1.0, 1e-4)
    else:
        rt = nxf.step_roundtrip_check(stp, OUT, "blade_helicoid", restore=part, part=part)
        res["notes"]["roundtrip"] = {k: rt.get(k) for k in ("solids", "volume", "match", "healthy", "max_rel")}
        chk.true("T4 STEP round trip (gate interpreter not installed: %s)" % gate.get("why"), rt.get("match") and rt.get("healthy"), rt.get("max_rel"))
    nxh.close_all()


def t5_pattern_feature():
    """Contrast (recorded, not required): Pattern Feature of the Thicken alone copies the blank, not the blade."""
    part = nxh.new_part(os.path.join(OUT, "blade_helicoid_pf.prt"))
    for name, val, unit in (("r_tip", R_TIP, "mm"), ("r_hub", R_HUB, "mm"), ("pitch", PITCH, "mm"), ("wrap", WRAP, None), ("thk", THK, "mm")):
        nxh.expr(part, name, val, unit)
    lf, ln = nb.assoc_line(part, ("r_hub-2", 0, 0), ("r_tip+2", 0, 0))
    h1, c1 = nb.helix(part, "2*(r_tip+2)", "pitch", "wrap/360")
    h2, c2 = nb.helix(part, "2*(r_hub-2)", "pitch", "wrap/360")
    sw = nb.swept(part, [nb.feature_section(part, lf, ln, (R_HUB - 2, 0, 0))],
                  [nb.feature_section(part, h2, c2, (R_HUB - 2, 0, 0)), nb.feature_section(part, h1, c1, (R_TIP + 2, 0, 0))], scaling=nb.SO.Uniform)
    before = list(part.Bodies)
    tf = nxf.thicken(part, sw.GetBodies()[0], "thk/2", "-thk/2")
    blade = [b for b in nxh.new_bodies(part, before) if b.IsSolidBody][0]
    nb.envelope_trim(part, blade, "2*r_tip", -MARGIN, 36)
    v_blade = nxh.volume(part, blade)
    out = {"finished_blade_volume": v_blade}
    for variational in (False, True):
        f, err = nxh.attempt("pattern feature", lambda v=variational: nxf.pattern_circular(part, [tf], (0, 0, 0), (0, 0, 1), 5, variational=v), log=log)
        key = "pattern_feature_of_thicken_%s" % ("variational" if variational else "simple")
        if err:
            out[key] = "ERR " + err
            continue
        vols = sorted(round(nxh.volume(part, b), 3) for b in nxh.solids(part) if b.Tag != blade.Tag)
        out[key] = {"instance_volumes": vols, "errors": nxh.feature_errors(part)}
    pf, copies = nxf.pattern_geometry(part, [blade], circular=dict(origin=(0, 0, 0), vec=(0, 0, 1), count=5))
    gv = [nxh.volume(part, b) for b in copies]
    out["pattern_geometry_instance_volumes"] = [round(v, 3) for v in gv]
    res["notes"]["pattern_feature_contrast"] = out
    chk.true("T5 Pattern Geometry: 4 copies, each = the finished blade (volume within 5e-5 relative)",
             len(copies) == 4 and all(abs(v / v_blade - 1.0) < 5e-5 for v in gv), gv)
    simple = out.get("pattern_feature_of_thicken_simple")
    if isinstance(simple, dict):
        chk.true("T5 Pattern Feature of the Thicken alone copies the uncut blank, not the finished blade",
                 all(v > v_blade * 1.02 for v in simple["instance_volumes"]), simple["instance_volumes"])
    nxh.close_all()


for name, fn in (("T1", t1_orientation), ("T2-T4", t2_wheel), ("T5", t5_pattern_feature)):
    try:
        fn()
    except Exception:  # noqa: BLE001
        res.setdefault("errors", {})[name] = traceback.format_exc()
        log("ERROR in", name, traceback.format_exc())
        chk.true(name + " ran without an exception", False, traceback.format_exc()[-300:])
        try:
            nxh.close_all()
        except Exception:  # noqa: BLE001
            pass
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "blade_helicoid.json"), res)
