"""Twist: Swept with an angular law (start and end angle) on NX 2206 - twisted bars, fins, bands.

    run_journal.ps1 -Script swept_twist.py -WorkDir <out> -JArgs <out>   ->  <out>\\swept_twist.json

W1  10 x 2 rectangle along a straight 100 mm guide, OrientationOption = ByAngularLaw, linear 0 -> twist_end
    (a named expression in degrees): volume, where the corners end up (sense of rotation), the two Degrees
    expressions the feature owns, an edit of twist_end 90 -> 180 -> 405.
W2  Cubic law: the same ends, a different distribution along the guide.
W3  Closed circular guide (twisted ring / Moebius-type band), 180 and 405 degrees: recorded.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
sys.path.insert(0, os.environ.get("NXBLADE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import NXOpen  # noqa: E402
import nxh  # noqa: E402
import nxblade as nb  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "swept_twist.log"))
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
HW, HT, LEN = 5.0, 1.0, 100.0          # half width, half thickness of the section, guide length


def rot(x, y, deg):
    a = math.radians(deg)
    return x * math.cos(a) - y * math.sin(a), x * math.sin(a) + y * math.cos(a)


def corner_at(x0, z, angle_about_plus_z):
    """Corner (HW, HT) of the section turned by the angle about +Z (right-hand rule), at height z."""
    cx, cy = rot(HW, HT, angle_about_plus_z)
    return (x0 + cx, cy, z)


def exprs(part):
    out = {}
    for e in part.Expressions:
        try:
            out[e.Name] = (e.RightHandSide, e.Units.Name if e.Units is not None else None)
        except Exception:  # noqa: BLE001
            out[e.Name] = (e.RightHandSide, None)
    return out


def bar(part, x0, end, cubic=False):
    rc = nxh.rect(part, x0 - HW, -HT, x0 + HW, HT, z=0.0)
    g = nxh.line(part, (x0, 0, 0), (x0, 0, LEN))
    f = nb.swept(part, [nxh.section(part, curves=rc, help_point=(x0 - HW, -HT, 0), seed=rc[0])],
                 [nxh.section(part, curves=[g], help_point=(x0, 0, 0), seed=g)], orientation="angular", angles=(0, end), cubic=cubic, solid=True)
    return f, f.GetBodies()[0]


def on(part, body, p):
    return abs(nxh.dist_to(part, body, p))


def run():
    part = nxh.new_part(os.path.join(OUT, "swept_twist.prt"))
    nxh.expr(part, "twist_end", 90, "deg", "end angle of the twist")
    before = exprs(part)
    f, body = bar(part, 0.0, "twist_end")
    new = {k: v for k, v in exprs(part).items() if k not in before}
    res["notes"]["W1_feature"] = {"type": f.FeatureType, "class": type(f).__name__, "new_expressions": new,
                                  "descriptors": [(e.Name, e.GetDescriptor(), e.RightHandSide) for e in f.GetExpressions()]}
    chk.true("W1 Swept with ByAngularLaw builds a solid", body.IsSolidBody, f.FeatureType)
    chk("W1 volume = section area x length (twist does not change it)", nxh.volume(part, body), 4 * HW * HT * LEN, 0.5)
    chk.true("W1 the feature owns two Degrees expressions (start, end); the end one = twist_end",
             sorted(u for _r, u in new.values()) == ["Degrees", "Degrees"] and any(r == "twist_end" for r, _u in new.values()), new)
    # the sense is read at mid length (45 deg): at the end a 10 x 2 rectangle turned +90 and -90 is the same shape
    plus, minus = on(part, body, corner_at(0, LEN / 2, 45)), on(part, body, corner_at(0, LEN / 2, -45))
    res["notes"]["W1_sense"] = {"mid_corner_turned_+45_about_guide_direction": plus, "mid_corner_turned_-45_about_guide_direction": minus}
    sense = -1.0 if minus < plus else 1.0
    res["notes"]["sense"] = ("a POSITIVE law angle turns the section by the NEGATIVE angle about the guide direction (left-hand rule: "
                             "clockwise when you look from the end of the guide back to its start)"
                             if sense < 0 else "a positive law angle is a right-hand rotation about the guide direction")
    chk("W1 linear law: at mid length the section has turned half the angle", min(plus, minus), 0.0, 5e-3)
    chk.true("W1 the other sense is clearly off the body", max(plus, minus) > 1.0, max(plus, minus))
    chk("W1 end section: the corner turned by the law angle lies on the body", on(part, body, corner_at(0, LEN, sense * 90)), 0.0, 1e-3)
    chk.true("W1 Examine Geometry clean", nxh.body_ok(part, body), nxh.examine_geometry(part, body))
    for end in (180, 405):
        nxh.set_expr(part, "twist_end", end)
        nxh.update()
        chk("W1 twist_end -> %d: end corner follows" % end, on(part, body, corner_at(0, LEN, sense * end)), 0.0, 1e-3)
        chk("W1 twist_end -> %d: mid-length corner follows" % end, on(part, body, corner_at(0, LEN / 2, sense * end / 2.0)), 0.0, 1e-2)
        chk("W1 twist_end -> %d: volume" % end, nxh.volume(part, body), 4 * HW * HT * LEN, 0.5)
        chk.true("W1 twist_end -> %d: Examine Geometry clean, no feature errors" % end, nxh.body_ok(part, body) and not nxh.feature_errors(part))
    res["notes"]["W1_volume_405"] = nxh.volume(part, body)

    # W2 cubic law 0 -> 90
    f2, b2 = bar(part, 40.0, 90, cubic=True)
    q_lin = on(part, b2, corner_at(40.0, LEN / 4, sense * 22.5))
    q_cub = on(part, b2, corner_at(40.0, LEN / 4, sense * 90 * (3 * 0.25 ** 2 - 2 * 0.25 ** 3)))
    res["notes"]["W2_cubic"] = {"quarter_point_linear_angle": q_lin, "quarter_point_cubic_angle_3t2-2t3": q_cub,
                                "volume": nxh.volume(part, b2)}
    chk("W2 cubic law: same end angle", on(part, b2, corner_at(40.0, LEN, sense * 90)), 0.0, 1e-3)
    chk("W2 cubic law: half the angle at mid length", on(part, b2, corner_at(40.0, LEN / 2, sense * 45)), 0.0, 5e-3)
    chk("W2 cubic law: at a quarter of the length the angle is 3t^2 - 2t^3 of the end angle (14.06 deg, not 22.5)", q_cub, 0.0, 2e-2)
    chk.true("W2 cubic differs from linear at the quarter point (the linear-law corner is off the body)", q_lin > 0.05, q_lin)

    # W3 closed circular guide: recorded
    ring = {}
    for end in (180, 405):
        m = nxh.mark("ring", False)
        try:
            yc = 200.0 + end
            sec_curves = nxh.polyline(part, [(40 - HW, yc, -HT), (40 + HW, yc, -HT), (40 + HW, yc, HT), (40 - HW, yc, HT)])
            guide = nxh.circle(part, (0.0, yc, 0.0), 40.0)
            # the guide circle lies in XY and starts at (40, yc, 0); the section stands in the XZ plane there
            fr = nb.swept(part, [nxh.section(part, curves=sec_curves, help_point=(40 - HW, yc, -HT), seed=sec_curves[0])],
                          [nxh.section(part, curves=guide, help_point=(40.0, yc, 0.0), seed=guide[0])], orientation="angular", angles=(0, end), solid=True)
            rb = fr.GetBodies()[0]
            ring[str(end)] = {"result": "built", "solid": rb.IsSolidBody, "volume": nxh.volume(part, rb) if rb.IsSolidBody else None,
                              "pappus": 4 * HW * HT * 2 * math.pi * 40.0, "faces": len(rb.GetFaces()), "examine": nxh.examine_geometry(part, rb)}
        except Exception as e:  # noqa: BLE001
            ring[str(end)] = {"result": "NOT WORKING", "error": str(e)[:300]}
            nxh.undo_to(m)
    res["notes"]["W3_closed_guide"] = ring
    r180, r405 = ring.get("180", {}), ring.get("405", {})
    chk.true("W3 closed circular guide, 180 deg twist of a rectangle: a closed ring (solid, 4 faces, no end caps), Examine Geometry clean",
             r180.get("result") == "built" and r180.get("solid") and r180.get("faces") == 4 and all(v == 0 for v in r180["examine"].values()), r180)
    if r180.get("volume"):
        chk("W3 180 deg ring: volume against Pappus (relative; a Swept on an arc guide is a B-surface)", r180["volume"] / r180["pappus"], 1.0, 0.01)
    chk.true("W3 405 deg on the closed guide: the ends do not meet (45 deg apart) - the body is INVALID (BodyConsistency) or refused",
             r405.get("result") == "NOT WORKING" or r405.get("examine", {}).get("BodyConsistency", 0) > 0 or r405.get("faces", 0) > 4, r405)
    res["features"] = [(x["name"], x["type"]) for x in nxh.feature_table(part)]
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-500:])
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "swept_twist.json"), res)
