"""Profiled blade wheel (fan / turbine / wind-turbine style) on NX 2206: ONE Through Curves solid over closed
section sketches on datum planes at station offsets (chord and twist change along the span), a round root
shank, tip cut by the envelope, Pattern Geometry of the blade body, one Unite to the hub, root blend.

    run_journal.ps1 -Script blade_sections.py -WorkDir <out> -JArgs <out>   ->  <out>\\blade_sections.json

Frame: the blade spans along +Z (stations = planes z = st1..st5), the wheel axis is X.
P1  five fully constrained section sketches; loft = solid; the designed section points lie on the faces.
P2  shank, tip cut, pattern x 9, Unite, root blend: one solid, counts, tip radius, thickness.
P3  regeneration: count 9 -> 7, one station's chord and twist, back to nominal.
P4  STEP export + benchmark validity gate.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
sys.path.insert(0, os.environ.get("NXBLADE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import nxh  # noqa: E402
import nxf  # noqa: E402
import nxblade as nb  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "blade_sections.log"))
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
AXIS = (1.0, 0.0, 0.0)
N, R_HUB, R_BORE, HUB_L, R_TIP, SHANK_D, ROOT_R, KS, KP = 9, 24.0, 8.0, 40.0, 88.0, 10.0, 1.5, 0.8, 1.5
# z, chord, stagger. Shank + root blend must stay clear of the neighbour at the hub: 2 pi r_hub / n > shank_d + 2 root_r
STATIONS = [(30.0, 30.0, 25.0), (44.0, 28.0, 34.0), (58.0, 25.0, 43.0), (74.0, 21.0, 52.0), (92.0, 17.0, 60.0)]


def on_body(part, body, xyz):
    return abs(nxh.dist_to(part, body, xyz))


def probes(part, body, stations, tag, tol=2e-3):
    """Designed section points (chord ends, mid of both arcs) must lie on the blade faces."""
    worst = 0.0
    for i, (z, c, tw) in enumerate(stations[:4]):                   # station 5 lies beyond the tip cut
        A, B, sm, pm, _t = nb.crescent_points(z, c, tw, KS, KP)
        pts = [A, B] + ([sm, pm] if i > 0 else [])                   # station 1 mid points are inside the shank
        worst = max([worst] + [on_body(part, body, p) for p in pts])
    chk(tag + " designed section points on the blade faces (max distance)", worst, 0.0, tol)
    return worst


def run():
    part = nxh.new_part(os.path.join(OUT, "blade_sections.prt"))
    for name, val, unit in (("n_blades", N, None), ("r_hub", R_HUB, "mm"), ("r_bore", R_BORE, "mm"), ("hub_l", HUB_L, "mm"),
                            ("r_tip", R_TIP, "mm"), ("shank_d", SHANK_D, "mm"), ("root_r", ROOT_R, "mm"),
                            ("k_suction", KS, None), ("k_pressure", KP, None)):
        nxh.expr(part, name, val, unit)
    for i, (z, c, tw) in enumerate(STATIONS, 1):
        nxh.expr(part, "st%d" % i, z, "mm", "station %d: distance from the wheel axis" % i)
        nxh.expr(part, "chord%d" % i, c, "mm")
        nxh.expr(part, "tw%d" % i, tw, "deg", "stagger from the axial direction")
    dat = nxh.Datums(part)

    # hub (two primitives about X), blade built on +Z
    _f, hub = nxh.cylinder(part, ("-hub_l/2", 0, 0), AXIS, "2*r_hub", "hub_l")
    nxh.cylinder(part, ("-hub_l/2", 0, 0), AXIS, "2*r_bore", "hub_l", op=nxh.BOOL.Subtract, target=hub)
    v_hub = nxh.volume(part, hub)
    chk("P1 hub volume", v_hub, math.pi * (R_HUB ** 2 - R_BORE ** 2) * HUB_L, 1e-3)

    # P1 sections and loft
    secs, stats = [], []
    for i in range(1, 6):
        s = nb.crescent_section(part, "st%d" % i, "chord%d" % i, "tw%d" % i, "SEC_%d" % i)
        stats.append((s["status"]["status"], s["status"]["dof"]))
        secs.append(nb.feature_section(part, s["sketch"].Feature, s["seed"], s["A"]))
    res["notes"]["section_sketches"] = stats
    chk.true("P1 all five section sketches fully constrained (DOF 0)", all(s == ("WellConstrained", 0) for s in stats), stats)
    loft = nxf.through_curves(part, secs, solid=True, preserve=True)
    blade = loft.GetBodies()[0]
    v_loft = nxh.volume(part, blade)
    # estimate: Simpson over the four spans with the mid chord from a parabola through neighbours is overkill;
    # trapezoid of the section areas is within 2 % for this taper
    areas = [nb.crescent_area(c, KS, KP) for _z, c, _tw in STATIONS]
    est = sum((STATIONS[i + 1][0] - STATIONS[i][0]) * (areas[i] + areas[i + 1] + math.sqrt(areas[i] * areas[i + 1])) / 3.0 for i in range(4))
    res["notes"]["loft"] = {"volume": v_loft, "estimate": est, "faces": nxh.face_census(blade), "section_areas": areas}
    chk.true("P1 Through Curves over closed sections gives a SOLID", blade.IsSolidBody)
    chk("P1 loft volume against the section-area estimate (relative)", v_loft / est, 1.0, 0.02)
    chk.true("P1 loft keeps the sharp edges: 2 side faces + 2 caps", len(blade.GetFaces()) == 4, len(blade.GetFaces()))
    probes(part, blade, STATIONS, "P1")
    A3, B3, sm3, pm3, t3 = nb.crescent_points(*STATIONS[2], KS, KP)
    pface = nxh.one([f for f in blade.GetFaces() if abs(nxh.dist_to(part, f, pm3)) < 1e-3], "pressure face at station 3")
    chk("P1 thickness at station 3: suction mid point to the pressure face", abs(nxh.dist_to(part, pface, sm3)), t3, 0.02 * t3)
    res["notes"]["thickness_station3"] = {"designed": t3, "measured": abs(nxh.dist_to(part, pface, sm3))}

    # P2 shank (separate Extrude, united into the blade), tip cut, pattern, unite, root blend
    _pf, pl_root = nxf.datum_plane(part, "offset", [dat.xy], "r_hub-2", name="PL_ROOT")
    sk = nxf.new_sketch(part, pl_root, dat.x, nxh.point(part, 0, 0, "r_hub-2"), "SK_SHANK")
    nxf.sketch_circle(part, sk, dat.origin, "shank_d")
    sst = nxf.finish_sketch(sk)
    chk.true("P2 shank sketch fully constrained", sst["status"] == "WellConstrained" and sst["dof"] == 0, sst)
    nxh.extrude(part, nxh.section_feature(part, [sk.Feature], (SHANK_D / 2, 0, R_HUB - 2)), (0, 0, 1), 0, "st1-(r_hub-2)+1",
                nxh.BOOL.Unite, blade)
    v_shank = nxh.volume(part, blade) - v_loft
    chk.true("P2 shank united into the blade body (volume grew, one blade body)", v_shank > 0 and len(nxh.solids(part)) == 2, v_shank)
    nb.envelope_trim(part, blade, "2*r_tip", -HUB_L / 2, "hub_l", vec=AXIS)
    v_blade = nxh.volume(part, blade)
    pf, uf = nb.pattern_and_unite(part, hub, blade, loft, "n_blades", vec=AXIS)
    body = hub
    v_plain = nxh.volume(part, body)
    bf = nb.root_blend(part, uf, "root_r")
    v_nom = nxh.volume(part, body)
    chk.true("P2 root blend added material", v_nom > v_plain, v_nom - v_plain)

    def measure(n, stations, tag):
        groups, hubf = nb.blade_groups(part, body, vec=AXIS)
        ext = nb.radial_extent(body, vec=AXIS)
        m = {"solids": len(nxh.solids(part)), "errors": nxh.feature_errors(part), "examine": nxh.examine_geometry(part, body),
             "groups": len(groups), "faces_per_blade": sorted(len(g["faces"]) for g in groups),
             "section_count": nb.blade_count_section(part, body, 60.0, -HUB_L / 2 + 1, HUB_L / 2 - 1, vec=AXIS),
             "r_tip": ext[1], "volume": nxh.volume(part, body), "hub_faces": len(hubf),
             "spacing": [round((groups[(i + 1) % len(groups)]["angle"] - groups[i]["angle"]) % 360.0, 3) for i in range(len(groups))]}
        res["notes"][tag] = m
        chk.true(tag + " one solid, no feature errors", m["solids"] == 1 and not m["errors"], m["errors"])
        chk.true(tag + " Examine Geometry clean", all(v == 0 for v in m["examine"].values()), m["examine"])
        chk.true(tag + " blade count by section = %d and by topology = %d" % (n, n), m["section_count"] == n and m["groups"] == n,
                 (m["section_count"], m["groups"]))
        chk.true(tag + " blades identical and evenly spaced", m["faces_per_blade"][0] == m["faces_per_blade"][-1]
                 and all(abs(a - 360.0 / n) < 0.01 for a in m["spacing"]), m["spacing"])
        chk(tag + " tip radius (tip cut by the envelope)", m["r_tip"], R_TIP, 1e-5)
        probes(part, body, stations, tag)
        return m

    measure(N, STATIONS, "P2")
    chk.true("P2 each blade adds less than its own volume (it overlaps the hub)", 0 < (v_plain - v_hub) / N < v_blade,
             ((v_plain - v_hub) / N, v_blade))
    res["notes"]["volumes"] = {"hub": v_hub, "loft": v_loft, "shank_added": v_shank, "blade": v_blade, "wheel_plain": v_plain, "wheel": v_nom}

    # P3 regeneration
    nxh.set_expr(part, "n_blades", 7)
    nxh.update()
    m7 = measure(7, STATIONS, "P3 n_blades 9->7:")
    chk("P3 added volume per blade is independent of the count", (m7["volume"] - v_hub) / 7, (v_nom - v_hub) / N, 0.05)
    nxh.set_expr(part, "n_blades", N)
    nxh.set_expr(part, "chord3", 28)
    nxh.set_expr(part, "tw3", 40)
    nxh.update()
    edited = list(STATIONS)
    edited[2] = (58.0, 28.0, 40.0)
    measure(N, edited, "P3 chord3 25->28, tw3 43->40:")
    nxh.set_expr(part, "chord3", 25)
    nxh.set_expr(part, "tw3", 43)
    nxh.update()
    chk("P3 back to nominal: volume reproduced (relative)", nxh.volume(part, body) / v_nom, 1.0, 1e-6)
    chk.true("P3 back to nominal: no feature errors", not nxh.feature_errors(part), nxh.feature_errors(part))
    res["features"] = [(f["name"], f["type"]) for f in nxh.feature_table(part)]

    # P4 deliverable
    stp = nxf.step_export(part, os.path.join(OUT, "blade_sections.step"))
    gate = nb.step_gate(stp)
    res["notes"]["gate"] = gate
    if gate.get("available"):
        chk.true("P4 STEP passes the validity gate (valid, watertight, 1 solid)",
                 gate.get("valid") and gate.get("watertight") and gate.get("solids") == 1, {k: gate.get(k) for k in ("valid", "watertight", "solids", "errors")})
        # the gate measures with OpenCascade: on lofted B-surfaces it reads 1.4e-4 below NX (helicoid wheel: 1e-6)
        chk("P4 STEP volume (gate, OpenCascade) = NX volume (relative)", gate["volume"] / v_nom, 1.0, 5e-4)
    else:
        rt = nxf.step_roundtrip_check(stp, OUT, "blade_sections", restore=part, part=part)
        chk.true("P4 STEP round trip (gate interpreter not installed)", rt.get("match") and rt.get("healthy"), rt.get("max_rel"))


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-400:])
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "blade_sections.json"), res)
