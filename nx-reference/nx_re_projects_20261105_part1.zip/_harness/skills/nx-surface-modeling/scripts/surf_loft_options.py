"""Lofting option semantics on NX 2206: what each option of Through Curves, Through Curve Mesh and Swept does.

    run_journal.ps1 -Script surf_loft_options.py -WorkDir <out> -JArgs <out>   ->  <out>\\surf_loft_options.json

Through Curves
T1  lofting degree 1 / 2 / 3 and Patch Type Single on four sections: faces, crease at an interior section
T2  Normal to End Sections: tilt of the surface at the end sections; seam against the mirrored half
T3  alignment Parameter / Arc Length / Distance on strings with corners; Preserve Shape: corner edge or not
T4  Flow Direction of a G1 end on a skew edge: Not Specified / Perpendicular / Isoparametric
T5  rebuild of the lofting direction (Manual degree 5, Advanced): the surface leaves the interior sections
Through Curve Mesh
M1  a POINT as primary string (three-sided patch), free and with G1 / G2 on both crosses to neighbour faces
M2  Emphasis Both / Primary / Cross when a cross misses the primaries by 0.05 mm; IntersectionTolerance
Swept
S1  twist law Linear vs Cubic: tangency of the twisted face to straight neighbours at the start
S2  scaling by Area Law (linear 1000 -> 600 mm2)
S3  Preserve Shape on a square section; three guides and the scaling option
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
GU = NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
TCB = NXOpen.Features.ThroughCurvesBuilder
TCM = NXOpen.Features.ThroughCurveMeshBuilder
AT = GU.AlignmentMethodBuilder.Type
CT = GU.Continuity.ContinuityTypes
RT = GU.Rebuild.RebuildTypes
FD = GU.FlowDirection.Type
LAW = GU.LawBuilder.Type
SO = GU.ScalingMethodBuilder.ScalingOptions
OO = GU.OrientationMethodBuilder.OrientationOptions
SHEET, SOLID = GU.FeatureOptions.BodyStyle.Sheet, GU.FeatureOptions.BodyStyle.Solid
ONLY_CURVES = NXOpen.Section.AllowTypes.OnlyCurves
PI = math.pi
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
notes = res["notes"]


def save_json():
    out = dict(res)
    out.update(chk.report())
    nxh.write_json(os.path.join(OUT, "surf_loft_options.json"), out)


def ok(r):
    return isinstance(r, dict) and "error" not in r


def case(store, name, fn):
    """Run one option case; an exception is recorded (the model is rolled back), not raised."""
    m = nxh.mark(name, False)
    try:
        store[name] = fn()
    except Exception as e:  # noqa: BLE001
        store[name] = {"error": str(e)[:300]}
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass
    save_json()
    return store[name]


def edge_points(edge, n=5):
    props = nxh.UFS.ModlGeneral.AskCurveProps
    return [tuple(props(edge.Tag, (i + 1.0) / (n + 1.0))[0]) for i in range(n)]


def near_face(part, body, p, skip=()):
    """The face of the body nearest to p (a lofted face meets its sections only within tolerance)."""
    return min(((abs(nxh.dist_to(part, f, p)), f) for f in body.GetFaces() if f not in skip), key=lambda t: t[0])[1]


def cross_boundary_direction(face, p, edge_dir):
    """Direction in which the isoparametric lines leave the boundary at p: the first derivative (u or v) that is
    least parallel to the edge. Returns (unit vector, angle to the edge direction in deg, 0..90)."""
    parm, _pt = nxh.UFS.Modeling.AskFaceParm(face.Tag, [float(v) for v in p])
    pr = nxh.UFS.Modeling.AskFaceProps(face.Tag, parm)
    best = None
    for d in (pr[1], pr[2]):
        n = math.sqrt(sum(x * x for x in d))
        if n < 1e-12:
            continue
        a = nxh.angle_deg(d, edge_dir)
        a = min(a, 180.0 - a)
        if best is None or a > best[1]:
            best = ([x / n for x in d], a)
    return best


# ---------------------------------------------------------------- recipes
def through_curves(part, sections, preserve=False, patch=None, align=None, align_vector=None, degree=None, rebuild=None,
                   section_rebuild=None, normal_ends=False, first=None, last=None, flow=None, solid=False, info=None):
    """Through Curves with the options this journal measures.

    degree          LoftingSurfaceRebuildData.Degree with RebuildType NotSet: 1 = an edge at every interior section
    rebuild         (RT.Manual | RT.Advanced, degree) on the lofting direction: an approximation
    section_rebuild the same on the section direction (SectionSurfaceRebuildData)
    normal_ends     NormalToEndSections: the surface leaves the first / last section normal to the section plane
    first / last    (CT.G1 | CT.G2, [neighbour faces]);  flow = FD.NotSpecified | Perpendicular | Isoparametric ...
    align           AT.Parameter | ArcLength | Distance (+ align_vector) | ...
    """
    b = part.Features.CreateThroughCurvesBuilder(NF)
    try:
        b.PreserveShape = preserve
        b.PatchType = patch if patch is not None else TCB.PatchTypes.Multiple
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.CurvatureTolerance = 0.5
        b.BodyPreference = TCB.BodyPreferenceTypes.Solid if solid else TCB.BodyPreferenceTypes.Sheet
        for s in sections:
            b.SectionsList.Append(s)
        b.Alignment.SetSections(list(sections))
        if align is not None:
            b.Alignment.AlignType = align
        if align_vector is not None:
            b.Alignment.AlignVector = nxh.direction(part, align_vector)
        if degree is not None:
            b.LoftingSurfaceRebuildData.Degree = degree
        if rebuild is not None:
            b.LoftingSurfaceRebuildData.RebuildType = rebuild[0]
            b.LoftingSurfaceRebuildData.Degree = rebuild[1]
        if section_rebuild is not None:
            b.SectionSurfaceRebuildData.RebuildType = section_rebuild[0]
            b.SectionSurfaceRebuildData.Degree = section_rebuild[1]
        if normal_ends:
            b.NormalToEndSections = True
        for cont, spec in ((b.FirstSectionContinuity, first), (b.LastSectionContinuity, last)):
            if spec:
                cont.ContinuityType = spec[0]
                cont.ConstraintFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(spec[1]))], False)
        if flow is not None:
            b.FlowDirection.FlowDirectionType = flow
        if info is not None:
            info["defaults_read_back"] = {"lofting_degree": b.LoftingSurfaceRebuildData.Degree, "lofting_rebuild": str(b.LoftingSurfaceRebuildData.RebuildType),
                                          "normal_to_end_sections": b.NormalToEndSections, "flow": str(b.FlowDirection.FlowDirectionType),
                                          "construction": str(b.Construction), "align": str(b.Alignment.AlignType)}
        return b.CommitFeature()
    finally:
        b.Destroy()


def curve_mesh(part, primaries, crosses, cont=None, emphasis=None, int_tol=0.01):
    """cont = {"FirstPrimaryContinuity" | "LastPrimaryContinuity" | "FirstCrossContinuity" | "LastCrossContinuity": (CT.x, faces)}"""
    b = part.Features.CreateThroughCurveMeshBuilder(NF)
    try:
        b.PositionTolerance = 0.01
        b.IntersectionTolerance = int_tol
        b.TangentTolerance = 0.5
        b.CurvatureTolerance = 0.5
        for s in primaries:
            b.PrimaryCurvesList.Append(s)
        for s in crosses:
            b.CrossCurvesList.Append(s)
        if emphasis is not None:
            b.Emphasis = emphasis
        for name, (ctype, faces) in (cont or {}).items():
            c = getattr(b, name)
            c.ContinuityType = ctype
            c.ConstraintFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


def point_section(part, xyz):
    """A Section that holds one point: the degenerate first / last primary string of a three-sided curve mesh."""
    pt = part.Points.CreatePoint(nxh.P(*xyz))
    sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
    rule = part.ScRuleFactory.CreateRuleCurveDumbFromPoints([pt])
    sec.AddToSection([rule], pt, NXOpen.NXObject.Null, NXOpen.NXObject.Null, nxh.P(*xyz), NXOpen.Section.Mode.Create, False)
    return sec


def swept(part, sections, guides, solid=False, angular=None, cubic=False, area_law=None, preserve=None, scaling=None, info=None):
    """angular = (start, end) deg -> OrientationOption ByAngularLaw (Linear, or Cubic with cubic=True);
    area_law = (start, end) mm2 -> ScalingOption ByAreaLaw, linear; preserve -> PreserveShapeOption."""
    b = part.Features.CreateSweptBuilder(NXOpen.Features.Swept.Null)
    try:
        b.G0Tolerance = 0.01
        b.G1Tolerance = 0.5
        for s in sections:
            b.SectionList.Append(s)
        b.AlignmentMethod.SetSections(list(sections))
        for g in guides:
            b.GuideList.Append(g)
        if info is not None:
            info["defaults"] = {"PreserveShapeOption": b.PreserveShapeOption, "ScalingOption": str(b.ScalingMethod.ScalingOption),
                                "OrientationOption": str(b.OrientationMethod.OrientationOption)}
        if angular is not None:
            om = b.OrientationMethod
            om.OrientationOption = OO.ByAngularLaw
            om.AngularLaw.LawType = LAW.Cubic if cubic else LAW.Linear
            om.AngularLaw.StartValue.RightHandSide = str(angular[0])
            om.AngularLaw.EndValue.RightHandSide = str(angular[1])
        if area_law is not None:
            sm = b.ScalingMethod
            sm.ScalingOption = SO.ByAreaLaw
            sm.AreaLaw.LawType = LAW.Linear
            sm.AreaLaw.StartValue.RightHandSide = str(area_law[0])
            sm.AreaLaw.EndValue.RightHandSide = str(area_law[1])
        if scaling is not None:
            b.ScalingMethod.ScalingOption = scaling
        if preserve is not None:
            b.PreserveShapeOption = preserve
        b.BodyPreference.BodyType = SOLID if solid else SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


def bounded_plane(part, curves, hp):
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.BoundingCurves, curves=curves, help_point=hp)
        return b.CommitFeature()
    finally:
        b.Destroy()


# ================================================================ Through Curves
SECT = ((0.0, 20.0), (20.0, 14.0), (40.0, 18.0), (60.0, 10.0))          # z, radius of four half circles; mid point (0, r, z)


def half_circle_sections(part, x0, sign=1.0):
    arcs = [(nxh.arc(part, (x0, 0, sign * z), (1, 0, 0), (0, 1, 0), r, 0.0, PI), sign * z, r) for z, r in SECT]
    return [nxh.section(part, curves=[a], help_point=(x0 + r, 0, z), seed=a) for a, z, r in arcs]


def loft_report(part, f, x0):
    body = f.GetBodies()[0]
    rep = {"faces": len(body.GetFaces()), "edges": len(body.GetEdges()), "area": round(nxh.sheet_area(part, body)[0], 3)}
    p2 = (x0, 14.0, 20.0)                                               # middle of interior section 2
    touching = [fc for fc in body.GetFaces() if abs(nxh.dist_to(part, fc, p2)) < 1e-4]
    rep["faces_meeting_at_section_2"] = len(touching)
    rep["crease_at_section_2_deg"] = round(nxh.g1_deviation(touching[0], touching[1], [p2]), 3) if len(touching) >= 2 else 0.0
    tilt = []
    for p in ((x0, 20.0, 0.0), (x0, 10.0, 60.0)):                       # middle of the first and of the last section
        n = nxh.normal_at(near_face(part, body, p), p)
        tilt.append(round(math.degrees(math.asin(min(1.0, abs(n[2])))), 3))
    rep["tilt_from_section_plane_normal_deg"] = tilt                    # 0 = the surface leaves the section plane at 90 deg
    rep["dist_to_section_mids"] = [round(abs(nxh.dist_to(part, body, (x0, r, z))), 6) for z, r in SECT]
    return rep


def t_through_curves(part):
    T1 = notes["T1_lofting_degree"] = {}
    info = {}
    case(T1, "default", lambda: loft_report(part, through_curves(part, half_circle_sections(part, 0.0), info=info), 0.0))
    T1["builder_defaults"] = info.get("defaults_read_back")
    for d in (1, 2, 3):
        case(T1, "degree_%d" % d, lambda d=d: loft_report(part, through_curves(part, half_circle_sections(part, 100.0 * d), degree=d), 100.0 * d))
    case(T1, "patch_single", lambda: loft_report(part, through_curves(part, half_circle_sections(part, 400.0), patch=TCB.PatchTypes.Single), 400.0))
    d1, d2, d3, sg, df = T1["degree_1"], T1["degree_2"], T1["degree_3"], T1["patch_single"], T1["default"]
    analytic = math.degrees(math.atan(6 / 20.0) + math.atan(4 / 20.0))
    chk.true("T1 lofting degree 1 on 4 sections: 3 faces (one per span), an edge at every interior section", ok(d1) and d1["faces"] == 3, d1)
    if ok(d1):
        chk("T1 degree 1: crease at interior section 2 = the angle between the two straight spans (28.01 deg)", d1["crease_at_section_2_deg"], analytic, 0.05)
    chk.true("T1 degree 2 and 3 (default): ONE smooth face through all four sections (0.000 mm)", ok(d2) and ok(d3) and d2["faces"] == 1 and d3["faces"] == 1
             and max(d2["dist_to_section_mids"] + d3["dist_to_section_mids"]) < 1e-4, (d2, d3))
    chk.true("T1 the builder default is degree 3 (same area as degree 3); degree 2 is a different surface", ok(df) and abs(df["area"] - d3["area"]) < 1e-3
             and abs(d2["area"] - d3["area"]) > 1.0, (df.get("area"), d2.get("area"), d3.get("area")))
    chk.true("T1 Patch Type Single on 4 sections = degree 3 (sections - 1): same surface", ok(sg) and sg["faces"] == 1 and abs(sg["area"] - d3["area"]) < 1e-3, sg)

    T2 = notes["T2_normal_to_end_sections"] = {}
    for name, ne, x0 in (("off", False, 600.0), ("on", True, 700.0)):
        def build(ne=ne, x0=x0):
            f = through_curves(part, half_circle_sections(part, x0), normal_ends=ne)
            rep = loft_report(part, f, x0)
            g = through_curves(part, half_circle_sections(part, x0, sign=-1.0), normal_ends=ne)       # the mirrored half (z -> -z)
            fa, fb = f.GetBodies()[0].GetFaces()[0], g.GetBodies()[0].GetFaces()[0]
            seam = [(x0 + 20 * math.cos(t), 20 * math.sin(t), 0.0) for t in (PI * k / 8.0 for k in range(1, 8))]
            rep["seam_to_mirrored_half_g1_dev_deg"] = round(nxh.g1_deviation(fa, fb, seam), 3)
            return rep
        case(T2, name, build)
    off, on = T2["off"], T2["on"]
    chk.true("T2 without the option the surface leaves the end sections tilted (> 30 deg at both ends)", ok(off) and min(off["tilt_from_section_plane_normal_deg"]) > 30.0, off)
    chk.true("T2 Normal to End Sections: tilt 0.00 deg at both end sections, still through all sections", ok(on) and max(on["tilt_from_section_plane_normal_deg"]) < 0.05
             and max(on["dist_to_section_mids"]) < 1e-4, on)
    chk.true("T2 seam against the mirrored half: creased without (> 60 deg), G1 with the option (< 0.1 deg) - no reference face needed",
             ok(off) and ok(on) and off["seam_to_mirrored_half_g1_dev_deg"] > 60.0 and on["seam_to_mirrored_half_g1_dev_deg"] < 0.1,
             (off.get("seam_to_mirrored_half_g1_dev_deg"), on.get("seam_to_mirrored_half_g1_dev_deg")))

    # ---- T3 alignment on two L-shaped strings (30 + 10 below, 10 + 30 above): where does the corner go?
    T3 = notes["T3_alignment_preserve_shape"] = {}

    def l_strings(x0):
        lo = nxh.polyline(part, [(x0, 0, 0), (x0 + 30, 0, 0), (x0 + 30, 10, 0)], closed=False)
        hi = nxh.polyline(part, [(x0, 0, 30), (x0 + 10, 0, 30), (x0 + 10, 30, 30)], closed=False)
        return [nxh.section(part, curves=lo, help_point=(x0, 0, 0), seed=lo[0]), nxh.section(part, curves=hi, help_point=(x0, 0, 30), seed=hi[0])]

    def l_report(f, x0):
        body = f.GetBodies()[0]
        return {"faces": len(body.GetFaces()), "edges": len(body.GetEdges()), "area": round(nxh.sheet_area(part, body)[0], 3),
                "corner_to_corner_ruling_mid_off_mm": round(abs(nxh.dist_to(part, body, (x0 + 20, 0, 15))), 4)}
    for i, (name, kw) in enumerate((("parameter", dict(align=AT.Parameter)), ("parameter_preserve_shape", dict(align=AT.Parameter, preserve=True)),
                                    ("arc_length", dict(align=AT.ArcLength)), ("arc_length_preserve_shape", dict(align=AT.ArcLength, preserve=True)))):
        case(T3, "L_" + name, lambda kw=kw, i=i: l_report(through_curves(part, l_strings(1000.0 + 100 * i), **kw), 1000.0 + 100 * i))
    pa, pp, al, alp = T3["L_parameter"], T3["L_parameter_preserve_shape"], T3["L_arc_length"], T3["L_arc_length_preserve_shape"]
    chk.true("T3 equal curve counts, Parameter: corner goes to corner (ruling mid 0.00 mm off)", ok(pa) and pa["corner_to_corner_ruling_mid_off_mm"] < 0.02, pa)
    chk.true("T3 Parameter + Preserve Shape: the corner is an EDGE (2 faces)", ok(pp) and pp["faces"] == 2 and pp["corner_to_corner_ruling_mid_off_mm"] < 1e-3, pp)
    chk.true("T3 Arc Length on the same strings: the corners do NOT meet (ruling mid > 1 mm off) - a different surface", ok(al) and al["corner_to_corner_ruling_mid_off_mm"] > 1.0, al)
    T3["note_arc_length_preserve"] = "Arc Length with Preserve Shape: " + ("error: " + alp["error"] if not ok(alp) else "built, %s" % alp)

    # Distance alignment: isoparms in planes normal to a vector
    def dist_case(x0, **kw):
        s1 = nxh.line(part, (x0, 0, 0), (x0 + 40, 0, 0))
        s2 = nxh.line(part, (x0, 30, 10), (x0 + 20, 30, 10))
        f = through_curves(part, [nxh.section(part, curves=[s1], help_point=(x0, 0, 0), seed=s1), nxh.section(part, curves=[s2], help_point=(x0, 30, 10), seed=s2)], **kw)
        body = f.GetBodies()[0]
        return {"area": round(nxh.sheet_area(part, body)[0], 3), "bbox": nxh.bbox(body),
                "analytic_area_full_40_to_20": round(30 * math.sqrt(1000.0), 3), "analytic_area_x_0_to_20_only": round(20 * math.sqrt(1000.0), 3),
                "off_far_end_of_long_string_(x0+40,0,0)": round(abs(nxh.dist_to(part, body, (x0 + 40, 0, 0))), 4)}
    case(T3, "distance_parameter_reference", lambda: dist_case(1500.0, align=AT.Parameter))
    case(T3, "distance_along_x", lambda: dist_case(1600.0, align=AT.Distance, align_vector=(1, 0, 0)))
    dp, dx = T3["distance_parameter_reference"], T3["distance_along_x"]
    chk.true("T3 Parameter joins the strings end to end (40 mm string to 20 mm string, area 948.68)", ok(dp) and abs(dp["area"] - 30 * math.sqrt(1000.0)) < 0.01
             and dp["off_far_end_of_long_string_(x0+40,0,0)"] < 1e-3, dp)
    chk.true("T3 Distance along X: rulings lie in planes x = const and the surface is only as long as the SHORTER string (the far end of the long one is left out)",
             ok(dx) and abs(dx["area"] - 20 * math.sqrt(1000.0)) < 0.01 and abs(dx["off_far_end_of_long_string_(x0+40,0,0)"] - 20.0) < 1e-3, dx)

    # Preserve Shape on rectangle -> rectangle: is there a corner edge to blend afterwards?
    def rect_case(x0, preserve):
        r0 = nxh.rect(part, x0, 0, x0 + 40, 30, 0.0)
        r1 = nxh.rect(part, x0 + 5, 5, x0 + 35, 25, 30.0)
        f = through_curves(part, [nxh.section(part, curves=r0, help_point=(x0, 0, 0), seed=r0[0]), nxh.section(part, curves=r1, help_point=(x0 + 5, 5, 30), seed=r1[0])], preserve=preserve)
        body = f.GetBodies()[0]
        corners = [(x0 + 2.5, 2.5, 15.0), (x0 + 37.5, 2.5, 15.0), (x0 + 37.5, 27.5, 15.0), (x0 + 2.5, 27.5, 15.0)]      # middles of the four corner rulings
        rep = {"faces": len(body.GetFaces()), "edges": len(body.GetEdges()), "types": nxh.face_census(body)["types"],
               "corner_points_off_mm": [round(abs(nxh.dist_to(part, body, c)), 5) for c in corners]}
        with_edge, without = [], []
        for c in corners:
            pt = part.Points.CreatePoint(nxh.P(*c))
            ce = [e for e in body.GetEdges() if len(e.GetFaces()) == 2 and abs(nxh.min_dist(pt, e)) < 0.02]
            (with_edge if ce else without).append((c, ce))
        rep["corner_rulings_that_are_edges"] = len(with_edge)
        if without:                                                      # a corner that is no edge: how sharp is it?
            c = without[0][0]
            k = nxh.max_curvature(near_face(part, body, c), c)
            rep["radius_at_a_corner_without_edge_mm"] = round(1.0 / k, 4) if k > 1e-9 else None
        try:
            target = with_edge[-1][1][0]
            nxh.blend(part, [target], 3)
            rep["edge_blend_R3_on_a_corner_edge"] = "built, faces %d" % len(body.GetFaces())
        except Exception as e:  # noqa: BLE001
            rep["edge_blend_R3_on_a_corner_edge"] = "error: " + str(e)[:120]
        return rep
    case(T3, "rect_preserve_off", lambda: rect_case(1800.0, False))
    case(T3, "rect_preserve_on", lambda: rect_case(1900.0, True))
    ro, rn = T3["rect_preserve_off"], T3["rect_preserve_on"]
    chk.true("T3 rectangle loft, Preserve Shape ON: 4 planar faces, all 4 corner rulings are edges, a corner takes an Edge Blend R3", ok(rn) and rn["faces"] == 4
             and rn["corner_rulings_that_are_edges"] == 4 and str(rn.get("edge_blend_R3_on_a_corner_edge", "")).startswith("built"), rn)
    chk.true("T3 rectangle loft, Preserve Shape OFF: B-surface faces, fewer corner edges than corners (the others are rounded within tolerance - nothing to blend)",
             ok(ro) and ro["faces"] < 4 and ro["corner_rulings_that_are_edges"] < 4 and nxh.PLANE not in [int(k) for k in ro["types"]], ro)

    # ---- T4 flow direction of a G1 end on a skew edge
    T4 = notes["T4_flow_direction"] = {}

    def flow_case(x0, flow):
        quad = nxh.polyline(part, [(x0, 0, 0), (x0 + 40, 20, 0), (x0 + 40, -20, 0), (x0, -20, 0)])     # neighbour sheet; its edge 0 is skew
        nb = bounded_plane(part, quad, (x0, 0, 0)).GetBodies()[0]
        edge = [e for e in nb.GetEdges() if abs(nxh.min_dist(part.Points.CreatePoint(nxh.P(x0 + 20, 10, 0)), e)) < 1e-6][0]
        s2 = nxh.line(part, (x0, 30, 15), (x0 + 40, 50, 15))
        f = through_curves(part, [nxh.section(part, edges=[edge], help_point=(x0, 0, 0), seed=edge), nxh.section(part, curves=[s2], help_point=(x0, 30, 15), seed=s2)],
                           first=(CT.G1, list(nb.GetFaces())), flow=flow)
        body = f.GetBodies()[0]
        face = body.GetFaces()[0]
        pts = edge_points(edge, 5)
        d, a = cross_boundary_direction(face, (x0 + 20, 10, 0), (2, 1, 0))
        return {"g1_dev_to_neighbour_deg": round(nxh.g1_deviation(nb.GetFaces()[0], face, pts), 3), "area": round(nxh.sheet_area(part, body)[0], 3),
                "isoparm_leaves_edge_at_deg": round(a, 2), "isoparm_direction": [round(v, 4) for v in d]}
    for i, (name, fl) in enumerate((("NotSpecified", FD.NotSpecified), ("Perpendicular", FD.Perpendicular), ("Isoparametric", FD.Isoparametric))):
        case(T4, name, lambda fl=fl, i=i: flow_case(2100.0 + 100 * i, fl))
    ns, pe = T4["NotSpecified"], T4["Perpendicular"]
    chk.true("T4 G1 holds for every flow direction (< 0.5 deg to the neighbour)", all(ok(r) and r["g1_dev_to_neighbour_deg"] < 0.5 for r in (ns, pe)), (ns, pe))
    chk.true("T4 Perpendicular: the isoparms leave the constraint edge at 90 deg; Not Specified: they head for the other section (skew, < 80 deg)",
             ok(pe) and ok(ns) and pe["isoparm_leaves_edge_at_deg"] > 88.0 and ns["isoparm_leaves_edge_at_deg"] < 80.0, (ns, pe))

    # ---- T5 rebuild
    T5 = notes["T5_rebuild"] = {}
    case(T5, "not_set", lambda: loft_report(part, through_curves(part, half_circle_sections(part, 2500.0)), 2500.0))
    case(T5, "lofting_manual_degree_5", lambda: loft_report(part, through_curves(part, half_circle_sections(part, 2600.0), rebuild=(RT.Manual, 5)), 2600.0))
    case(T5, "lofting_advanced", lambda: loft_report(part, through_curves(part, half_circle_sections(part, 2700.0), rebuild=(RT.Advanced, 5)), 2700.0))
    case(T5, "section_manual_degree_3", lambda: loft_report(part, through_curves(part, half_circle_sections(part, 2800.0), section_rebuild=(RT.Manual, 3)), 2800.0))
    n0, m5 = T5["not_set"], T5["lofting_manual_degree_5"]
    chk.true("T5 no rebuild: the surface passes through every section (0.000)", ok(n0) and max(n0["dist_to_section_mids"]) < 1e-5, n0)
    chk.true("T5 lofting rebuild Manual degree 5: one face, but an APPROXIMATION - off the interior sections by more than 0 and within PositionTolerance 0.01",
             ok(m5) and m5["faces"] == 1 and 1e-5 < max(m5["dist_to_section_mids"][1:3]) <= 0.01, m5)


# ================================================================ Through Curve Mesh
def t_curve_mesh(part):
    M1 = notes["M1_point_primary"] = {}
    R = 30.0

    def tri_patch(cx, cont_type):
        cy = 3000.0
        apex = (cx, cy, R)
        a = nxh.arc(part, (cx, cy, 0), (1, 0, 0), (0, 1, 0), R, 0.0, PI / 2)       # (cx+R, cy, 0) -> (cx, cy+R, 0)
        c1 = nxh.arc(part, (cx, cy, 0), (1, 0, 0), (0, 0, 1), R, 0.0, PI / 2)      # (cx+R, cy, 0) -> apex, in the plane y = cy
        c2 = nxh.arc(part, (cx, cy, 0), (0, 1, 0), (0, 0, 1), R, 0.0, PI / 2)      # (cx, cy+R, 0) -> apex, in the plane x = cx
        cont, nbf = None, []
        cross1 = nxh.section(part, curves=[c1], help_point=(cx + R, cy, 0), seed=c1)
        cross2 = nxh.section(part, curves=[c2], help_point=(cx, cy + R, 0), seed=c2)
        if cont_type is not None:
            # neighbour strips tangent to the sphere along the two great-circle arcs: cylinders with axis Y and X
            n1 = nxh.extrude(part, nxh.section(part, curves=[c1], help_point=(cx + R, cy, 0)), (0, -1, 0), 0, 10, sheet=True).GetBodies()[0]
            n2 = nxh.extrude(part, nxh.section(part, curves=[c2], help_point=(cx, cy + R, 0)), (-1, 0, 0), 0, 10, sheet=True).GetBodies()[0]
            e1 = [e for e in n1.GetEdges() if all(abs(v.Y - cy) < 1e-6 for v in e.GetVertices()) and e.SolidEdgeType != NXOpen.Edge.EdgeType.Linear][0]
            e2 = [e for e in n2.GetEdges() if all(abs(v.X - cx) < 1e-6 for v in e.GetVertices()) and e.SolidEdgeType != NXOpen.Edge.EdgeType.Linear][0]
            cross1 = nxh.section(part, edges=[e1], help_point=(cx + R, cy, 0), seed=e1)
            cross2 = nxh.section(part, edges=[e2], help_point=(cx, cy + R, 0), seed=e2)
            cont = {"FirstCrossContinuity": (cont_type, list(n1.GetFaces())), "LastCrossContinuity": (cont_type, list(n2.GetFaces()))}
            nbf = [n1.GetFaces()[0], n2.GetFaces()[0]]
        f = curve_mesh(part, [nxh.section(part, curves=[a], help_point=(cx + R, cy, 0), seed=a), point_section(part, apex)], [cross1, cross2], cont=cont)
        body = f.GetBodies()[0]
        s = R / math.sqrt(3.0)
        rep = {"faces": len(body.GetFaces()), "edges": len(body.GetEdges()), "area": round(nxh.sheet_area(part, body)[0], 3),
               "sphere_octant_area": round(4 * PI * R * R / 8, 3), "apex_off_mm": round(abs(nxh.dist_to(part, body, apex)), 5),
               "off_sphere_at_111_mm": round(abs(nxh.dist_to(part, body, (cx + s, cy + s, s))), 4),
               "examine": {k: v for k, v in nxh.examine_geometry(part, body).items() if v and k != "BodySheetBoundaries"}}
        if nbf:
            face = body.GetFaces()[0]
            p1 = [(cx + R * math.cos(t), cy, R * math.sin(t)) for t in (math.radians(v) for v in (15, 30, 45, 60, 75))]
            p2 = [(cx, cy + R * math.cos(t), R * math.sin(t)) for t in (math.radians(v) for v in (15, 30, 45, 60, 75))]
            rep["g1_dev_cross_1_deg"] = round(nxh.g1_deviation(nbf[0], face, p1), 3)
            rep["g1_dev_cross_2_deg"] = round(nxh.g1_deviation(nbf[1], face, p2), 3)
            rep["curvature_patch_vs_neighbour_at_cross_1"] = [round(nxh.max_curvature(face, p1[2]), 5), round(nxh.max_curvature(nbf[0], p1[2]), 5)]
        return rep
    for i, (name, ctp) in enumerate((("free_G0", None), ("crosses_G1", CT.G1), ("crosses_G2", CT.G2))):
        case(M1, name, lambda ctp=ctp, i=i: tri_patch(100.0 * i, ctp))
    g0, g1 = M1["free_G0"], M1["crosses_G1"]
    chk.true("M1 curve mesh with a POINT as last primary: one face with 3 edges through the apex", ok(g0) and g0["faces"] == 1 and g0["edges"] == 3 and g0["apex_off_mm"] < 1e-3, g0)
    chk.true("M1 without neighbours the three-sided patch is only a guess between its curves (> 0.5 mm inside the sphere they lie on)", ok(g0) and g0["off_sphere_at_111_mm"] > 0.5, g0)
    chk.true("M1 G1 on both crosses to neighbour faces: tangent along both (< 0.5 deg), still 3 edges", ok(g1) and g1["edges"] == 3
             and g1["g1_dev_cross_1_deg"] < 0.5 and g1["g1_dev_cross_2_deg"] < 0.5, g1)
    chk.true("M1 with G1 crosses the patch is much nearer the sphere than the free one", ok(g1) and ok(g0) and g1["off_sphere_at_111_mm"] < 0.5 * g0["off_sphere_at_111_mm"],
             (g0.get("off_sphere_at_111_mm"), g1.get("off_sphere_at_111_mm")))
    g2 = M1["crosses_G2"]
    chk.true("M1 G2 on both crosses: tangent AND the patch curvature at the edge equals the neighbour's (within 2 %; G1 alone: 27 % off)",
             ok(g2) and g2["g1_dev_cross_1_deg"] < 0.5 and abs(g2["curvature_patch_vs_neighbour_at_cross_1"][0] / g2["curvature_patch_vs_neighbour_at_cross_1"][1] - 1.0) < 0.02
             and abs(g1["curvature_patch_vs_neighbour_at_cross_1"][0] / g1["curvature_patch_vs_neighbour_at_cross_1"][1] - 1.0) > 0.1, (g1, g2))

    # ---- M2 emphasis: the middle cross is 0.05 mm above the primaries
    M2 = notes["M2_emphasis"] = {}
    LIFT = 0.05

    def mesh_case(x0, emphasis, int_tol):
        y0 = 3300.0

        def pp(x, tdeg, r=25.0):
            t = math.radians(tdeg)
            return (x, y0 + r * math.cos(t), r * math.sin(t))
        prim = [nxh.arc(part, (x, y0, 0), (0, 1, 0), (0, 0, 1), 25.0, math.radians(30), math.radians(150)) for x in (x0, x0 + 40)]
        cross = [nxh.line(part, pp(x0, 30), pp(x0 + 40, 30)), nxh.line(part, pp(x0, 90, 25.0 + LIFT), pp(x0 + 40, 90, 25.0 + LIFT)),
                 nxh.line(part, pp(x0, 150), pp(x0 + 40, 150))]
        ps = [nxh.section(part, curves=[c], help_point=pp(x, 30), seed=c) for c, x in zip(prim, (x0, x0 + 40))]
        cs = [nxh.section(part, curves=[c], help_point=pp(x0, t, r), seed=c) for c, (t, r) in zip(cross, ((30, 25.0), (90, 25.0 + LIFT), (150, 25.0)))]
        f = curve_mesh(part, ps, cs, emphasis=emphasis, int_tol=int_tol)
        body = f.GetBodies()[0]
        return {"faces": len(body.GetFaces()), "area": round(nxh.sheet_area(part, body)[0], 3),
                "off_primary_at_the_crossing_mm": round(abs(nxh.dist_to(part, body, pp(x0, 90))), 4),
                "off_cross_at_the_crossing_mm": round(abs(nxh.dist_to(part, body, pp(x0, 90, 25.0 + LIFT))), 4),
                "off_cross_mid_span_mm": round(abs(nxh.dist_to(part, body, pp(x0 + 20, 90, 25.0 + LIFT))), 4),
                "off_primary_quarter_mm": round(abs(nxh.dist_to(part, body, pp(x0, 60))), 4)}
    ET = TCM.EmphasisType
    case(M2, "both_intersection_tol_0.01", lambda: mesh_case(0.0, ET.Both, 0.01))
    for i, (name, em) in enumerate((("both", ET.Both), ("primary", ET.Primary), ("cross", ET.Cross))):
        case(M2, name + "_intersection_tol_0.1", lambda em=em, i=i: mesh_case(100.0 * (i + 1), em, 0.1))
    tight, bo, pr, cr = M2["both_intersection_tol_0.01"], M2["both_intersection_tol_0.1"], M2["primary_intersection_tol_0.1"], M2["cross_intersection_tol_0.1"]
    chk.true("M2 a cross 0.05 mm off the primaries with IntersectionTolerance 0.01: refused", not ok(tight), tight)
    chk.true("M2 IntersectionTolerance 0.1, Emphasis Both: the surface runs midway (0.025 / 0.025 mm)", ok(bo) and abs(bo["off_primary_at_the_crossing_mm"] - LIFT / 2) < 0.005
             and abs(bo["off_cross_at_the_crossing_mm"] - LIFT / 2) < 0.005, bo)
    chk.true("M2 Emphasis Primary: on the primary (0.000), the cross is missed by the full 0.05", ok(pr) and pr["off_primary_at_the_crossing_mm"] < 0.003
             and abs(pr["off_cross_at_the_crossing_mm"] - LIFT) < 0.005, pr)
    chk.true("M2 Emphasis Cross: on the cross (0.000), the primary is missed by the full 0.05", ok(cr) and cr["off_cross_at_the_crossing_mm"] < 0.003
             and abs(cr["off_primary_at_the_crossing_mm"] - LIFT) < 0.005, cr)


# ================================================================ Swept
def t_swept(part):
    S1 = notes["S1_twist_law_tangency"] = {}
    HW, HT, LEN, U = 10.0, 2.0, 50.0, 8.0

    def twist(x0, cubic):
        y0 = 3600.0
        rc = nxh.rect(part, x0 - HW, y0 - HT, x0 + HW, y0 + HT, z=0.0)
        g = nxh.line(part, (x0, y0, 0), (x0, y0, LEN))
        f = swept(part, [nxh.section(part, curves=rc, help_point=(x0 - HW, y0 - HT, 0), seed=rc[0])], [nxh.section(part, curves=[g], help_point=(x0, y0, 0), seed=g)],
                  solid=True, angular=(0, 90), cubic=cubic)
        body = f.GetBodies()[0]
        out = {"volume": round(nxh.volume(part, body), 3), "faces": len(body.GetFaces())}
        for u in (U, HW - 0.01):
            p = (x0 + u, y0 + HT, 0.0)                                   # on the start edge of the wide face
            tw = [fc for fc in body.GetFaces() if abs(nxh.dist_to(part, fc, p)) < 1e-5 and nxh.face_data(fc)[0] != nxh.PLANE]
            n = nxh.normal_at(tw[0], p)
            a = nxh.angle_deg(n, (0, 1, 0))
            out["normal_off_untwisted_face_at_u_%g_deg" % u] = round(min(a, 180 - a), 3)
        return out
    case(S1, "linear", lambda: twist(0.0, False))
    case(S1, "cubic", lambda: twist(100.0, True))
    li, cu = S1["linear"], S1["cubic"]
    analytic = math.degrees(math.atan(U * math.radians(90) / LEN))
    S1["analytic_linear_deg_at_u_8"] = round(analytic, 3)
    if ok(li):
        chk("S1 Linear twist law 0 -> 90 over 50 mm: the twisted face starts atan(u x rate) off the straight face (14.11 deg at u = 8)",
            li["normal_off_untwisted_face_at_u_%g_deg" % U], analytic, 0.3)
    chk.true("S1 Cubic law: zero twist rate at the start - tangent to a straight neighbour (< 0.3 deg), same volume", ok(cu) and cu["normal_off_untwisted_face_at_u_%g_deg" % U] < 0.3
             and abs(cu["volume"] - li["volume"]) < 1.0, (li, cu))

    S2 = notes["S2_area_law"] = {}

    def area_case(x0):
        y0 = 3800.0
        r0 = math.sqrt(1000.0 / PI)
        c = nxh.circle(part, (x0, y0, 0), r0)
        g = nxh.line(part, (x0, y0, 0), (x0, y0, 200.0))
        f = swept(part, [nxh.section(part, curves=c, help_point=(x0 + r0, y0, 0), seed=c[0])], [nxh.section(part, curves=[g], help_point=(x0, y0, 0), seed=g)],
                  solid=True, area_law=(1000, 600))
        body = f.GetBodies()[0]
        caps = {}
        for fc in body.GetFaces():
            if nxh.face_data(fc)[0] == nxh.PLANE:
                caps[round(nxh.face_data(fc)[1][2], 3)] = round(nxh.sheet_area(part, [fc])[0], 3)
        side = [fc for fc in body.GetFaces() if nxh.face_data(fc)[0] != nxh.PLANE]
        rm = math.sqrt(800.0 / PI)
        return {"solid": body.IsSolidBody, "cap_area_by_z": caps, "volume": round(nxh.volume(part, body), 2), "volume_if_area_is_linear": 160000.0,
                "mid_section_radius_for_800_off_mm": round(min(abs(nxh.dist_to(part, fc, (x0 + rm, y0, 100.0))) for fc in side), 4),
                "expressions": [(e.Name, e.RightHandSide) for e in f.GetExpressions()][:6]}
    case(S2, "linear_1000_to_600", lambda: area_case(0.0))
    ar = S2["linear_1000_to_600"]
    if ok(ar) and len(ar["cap_area_by_z"]) == 2:
        chk("S2 Area Law 1000 -> 600: start cap area", ar["cap_area_by_z"].get(0.0), 1000.0, 1.0)
        chk("S2 Area Law 1000 -> 600: end cap area", ar["cap_area_by_z"].get(200.0), 600.0, 1.0)
        chk("S2 Area Law: section at mid length has area 800 (radius sqrt(800/pi) on the surface)", ar["mid_section_radius_for_800_off_mm"], 0.0, 0.02)
        chk("S2 Area Law: volume = integral of the linear area (relative)", ar["volume"] / 160000.0, 1.0, 0.002)
    else:
        chk.true("S2 Area Law builds a solid with two caps", False, ar)

    S3 = notes["S3_preserve_shape_three_guides"] = {}

    def square_case(x0, preserve):
        y0 = 4000.0
        sq = nxh.polyline(part, [(x0 - 3, y0, -3), (x0 + 3, y0, -3), (x0 + 3, y0, 3), (x0 - 3, y0, 3)])     # in the plane y = y0
        g = nxh.arc(part, (x0 + 40, y0, 0), (-1, 0, 0), (0, 1, 0), 40.0, 0.0, PI / 2)                      # starts at (x0, y0, 0) along +Y
        info = {}
        f = swept(part, [nxh.section(part, curves=sq, help_point=(x0 - 3, y0, -3), seed=sq[0])], [nxh.section(part, curves=[g], help_point=(x0, y0, 0), seed=g)],
                  preserve=preserve, info=info)
        body = f.GetBodies()[0]
        return {"faces": len(body.GetFaces()), "edges": len(body.GetEdges()), "area": round(nxh.sheet_area(part, body)[0], 3), "builder_defaults": info.get("defaults")}
    case(S3, "square_preserve_default", lambda: square_case(0.0, None))
    case(S3, "square_preserve_false", lambda: square_case(100.0, False))
    case(S3, "square_preserve_true", lambda: square_case(200.0, True))
    pf, pt = S3["square_preserve_false"], S3["square_preserve_true"]
    chk.true("S3 Swept, square section: PreserveShapeOption True (the batch default) keeps 4 faces with corner edges; False rounds corners (fewer faces)",
             ok(pt) and pt["faces"] == 4 and ok(pf) and pf["faces"] < 4 and S3["square_preserve_default"].get("faces") == 4, (pf, pt))
    S3["note"] = "PreserveShapeOption False: %s faces; True: %s faces" % (pf.get("faces"), pt.get("faces"))

    def three_guides(x0, scaling):
        y0 = 4200.0
        a = [(x0, y0, 0), (x0 + 10, y0 + 5, 0), (x0 + 20, y0, 0)]
        e = [(x0, y0, 50), (x0 + 10, y0 + 8, 50), (x0 + 22, y0, 50)]
        sec = nxh.polyline(part, a, closed=False)
        gl = [nxh.line(part, p, q) for p, q in zip(a, e)]
        f = swept(part, [nxh.section(part, curves=sec, help_point=a[0], seed=sec[0])], [nxh.section(part, curves=[g], help_point=p, seed=g) for g, p in zip(gl, a)], scaling=scaling)
        body = f.GetBodies()[0]
        return {"faces": len(body.GetFaces()), "area": round(nxh.sheet_area(part, body)[0], 3), "guide_ends_off_mm": [round(abs(nxh.dist_to(part, body, p)), 4) for p in e]}
    case(S3, "three_guides_scaling_default", lambda: three_guides(0.0, None))
    case(S3, "three_guides_scaling_uniform", lambda: three_guides(100.0, SO.Uniform))
    case(S3, "three_guides_scaling_lateral", lambda: three_guides(200.0, SO.Lateral))
    td = S3["three_guides_scaling_default"]
    tu, tl = S3["three_guides_scaling_uniform"], S3["three_guides_scaling_lateral"]
    chk.true("S3 three guides with the scaling option left alone: builds, all three guide ends on the surface", ok(td) and max(td["guide_ends_off_mm"]) < 1e-3, td)
    chk.true("S3 three guides: Uniform / Lateral are accepted and change nothing (same area) - the third guide fixes the shape",
             ok(tu) and ok(tl) and abs(tu["area"] - td["area"]) < 1e-3 and abs(tl["area"] - td["area"]) < 1e-3, (td, tu, tl))


def run():
    part = nxh.new_part(os.path.join(OUT, "surf_loft_options.prt"))
    for name, fn in (("through_curves", t_through_curves), ("curve_mesh", t_curve_mesh), ("swept", t_swept)):
        try:
            fn(part)
        except Exception:  # noqa: BLE001
            notes[name + "_error"] = traceback.format_exc()[-900:]
            chk.true(name + " block ran", False, notes[name + "_error"][-300:])
        save_json()
    notes["feature_errors"] = str(nxh.feature_errors(part))
    res["features"] = len(nxh.feature_table(part))
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-500:])
save_json()
