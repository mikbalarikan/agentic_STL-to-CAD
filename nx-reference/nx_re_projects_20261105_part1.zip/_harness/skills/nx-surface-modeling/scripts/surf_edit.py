"""Surface editing / joining / solidifying recipes, verified on NX 2206 batch (run_journal).

Extract Face/Body, Offset Surface, Extend Sheet, Law Extension, Enlarge, Trim Sheet (curves, faces,
datum plane, vector projection, keep/discard region point), Trim and Extend, Untrim, Sew (+ gap
behaviour), Unsew, Thicken (expression driven), Trim Body with a sheet, Replace Face with a sheet, Patch.

Usage: run_journal surf_edit.py -args <output folder>
Writes <output folder>/surf_edit.json with every measurement and "result": "PASS"|"FAIL".
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
GU = NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
NULLO = NXOpen.NXObject.Null
SHEET = GU.FeatureOptions.BodyStyle.Sheet
res = {"checks": [], "notes": {}}


# ---------------------------------------------------------------- measurement helpers
def sheet_area(part, body):
    """Face area of a body. nxh.mass() is WRONG for sheet bodies (returns perimeter and area x1000)."""
    uc = part.UnitCollection
    mf = part.MeasureManager.NewFaceProperties(uc.FindObject("SquareMilliMeter"), uc.FindObject("MilliMeter"), 0.999999,
                                               list(body.GetFaces()))
    try:
        return mf.Area
    finally:
        mf.Dispose()


def free_edges(body):
    return [e for e in body.GetEdges() if len(e.GetFaces()) == 1]


def counts(part):
    return len(nxh.sheets(part)), len(nxh.solids(part))


def check(name, got, want, tol):
    ok = abs(got - want) <= tol
    res["checks"].append({"name": name, "got": round(got, 4), "want": round(want, 4), "tol": tol, "ok": ok})
    return ok


def section(part, curves=None, edges=None, start=(0, 0, 0)):
    sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
    sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
    fill(sec, part, curves, edges, start)
    return sec


def fill(sec, part, curves=None, edges=None, start=(0, 0, 0)):
    rules = []
    if curves:
        rules.append(part.ScRuleFactory.CreateRuleCurveDumb(list(curves)))
    if edges:
        rules.append(part.ScRuleFactory.CreateRuleEdgeDumb(list(edges)))
    first = list(curves)[0] if curves else list(edges)[0]
    sec.AddToSection(rules, first, NULLO, NULLO, nxh.P(*start), NXOpen.Section.Mode.Create, False)


# ---------------------------------------------------------------- input geometry
def plane_sheet(part, x0, y0, w=40, h=30, z=0.0):
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        fill(b.BoundingCurves, part, curves=nxh.rect(part, x0, y0, x0 + w, y0 + h, z), start=(x0, y0, z))
        return b.CommitFeature().GetBodies()[0]
    finally:
        b.Destroy()


def extrude_sheet(part, curves, vec, start, end, hp):
    b = part.Features.CreateExtrudeBuilder(NF)
    try:
        b.Section = section(part, curves=curves, start=hp)
        b.Direction = nxh.direction(part, vec)
        b.Limits.StartExtend.Value.RightHandSide = str(start)
        b.Limits.EndExtend.Value.RightHandSide = str(end)
        b.FeatureOptions.BodyType = SHEET
        b.BooleanOperation.Type = nxh.BOOL.Create
        return b.CommitFeature().GetBodies()[0]
    finally:
        b.Destroy()


def half_cyl(part, x0, y0, r=5, length=50):
    """Half cylinder sheet, axis +X through (x0, y0, 0), over the +Z side. Area = pi r L."""
    a = nxh.arc(part, (x0, y0, 0), (0, 1, 0), (0, 0, 1), r, 0.0, math.pi)
    return extrude_sheet(part, [a], (1, 0, 0), 0, length, (x0, y0 + r, 0))


def arc_sheet(part, x0, y0):
    """Cylindrical sheet (R60, axis along Y) that cuts right through a 60x40x20 block placed at (x0, y0, 0)."""
    a = nxh.arc(part, (x0 + 30, y0 - 5, -45), (1, 0, 0), (0, 0, 1), 60, math.radians(45), math.radians(135))
    return extrude_sheet(part, [a], (0, 1, 0), 0, 50, (x0 + 30, y0 - 5, 15))


# ---------------------------------------------------------------- recipes
def extract_face(part, faces, associative=True):
    """Associative sheet copy of one or more faces (FeatureType EXTRACT_FACE)."""
    EFB = NXOpen.Features.ExtractFaceBuilder
    b = part.Features.CreateExtractFaceBuilder(NF)
    try:
        b.Type = EFB.ExtractType.Face
        if len(faces) == 1:
            b.FaceOption = EFB.FaceOptionType.SingleFace
            b.ObjectToExtract.Add(faces[0])
        else:
            b.FaceOption = EFB.FaceOptionType.FaceChain
            b.FaceChain.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        b.Associative = associative
        b.FixAtCurrentTimestamp = False
        return b.CommitFeature()
    finally:
        b.Destroy()


def extract_body(part, body, fix_at_timestamp=True):
    """Copy of a whole body (FeatureType EXTRACT_BODY). fix_at_timestamp freezes it at this point of the tree."""
    EFB = NXOpen.Features.ExtractFaceBuilder
    b = part.Features.CreateExtractFaceBuilder(NF)
    try:
        b.Type = EFB.ExtractType.Body
        b.ExtractBodyCollector.ReplaceRules([part.ScRuleFactory.CreateRuleBodyDumb([body], True)], False)
        b.Associative = True
        b.FixAtCurrentTimestamp = fix_at_timestamp
        return b.CommitFeature()
    finally:
        b.Destroy()


def offset_surface(part, faces, dist, flip=False):
    """New sheet offset from faces; +dist goes along the face normal (outward on a solid)."""
    b = part.Features.CreateOffsetSurfaceBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FaceSets.Append(part.FaceSetOffsets.CreateFaceSet(str(dist), nxh.collector(part, faces=faces), flip, 0))
        return b.CommitFeature()
    finally:
        b.Destroy()


def extend_sheet(part, edges, dist, as_new_sheet=False):
    ESB = NXOpen.Features.ExtendSheetBuilder
    b = part.Features.TrimFeatureCollection.CreateExtendSheetBuilder(NXOpen.Features.ExtendSheet.Null)
    try:
        b.DistanceTolerance = 0.01
        b.LimitMethod = ESB.Limit.Offset
        b.TargetBoundaryEdges.ReplaceRules([part.ScRuleFactory.CreateRuleEdgeDumb(list(edges))], False)
        b.Offset.RightHandSide = str(dist)
        b.SurfaceShapeOption = ESB.SurfaceShape.NaturalCurvature
        b.BodyOutputOption = ESB.BodyOutput.ExtendasNewSheet if as_new_sheet else ESB.BodyOutput.ExtendOriginalSheet
        return b.CommitFeature()
    finally:
        b.Destroy()


def law_extension(part, face, edge, hp, length, angle):
    """Flange sheet off an edge: `angle` is measured from the reference face tangent (0 = continue, 90 = normal)."""
    LEB = NXOpen.Features.LawExtensionBuilderEx
    b = part.Features.CreateLawExtensionBuilderEx(NF)
    try:
        b.Type = LEB.Types.Faces
        b.DistanceTolerance = 0.01
        b.BaseProfile.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        fill(b.BaseProfile, part, edges=[edge], start=hp)
        b.Faces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb([face])], False)
        b.LengthLaw.LawType = GU.LawBuilder.Type.Constant
        b.LengthLaw.Value.RightHandSide = str(length)
        b.AngleLaw.LawType = GU.LawBuilder.Type.Constant
        b.AngleLaw.Value.RightHandSide = str(angle)
        return b.CommitFeature()
    finally:
        b.Destroy()


def enlarge(part, face, u0=0, u1=0, v0=0, v1=0):
    """Grow a B-surface face in place by percentages of its U/V size. Planar faces raise "Invalid face."."""
    b = part.Features.CreateEnlargeBuilder(NXOpen.Features.Enlarge.Null)
    try:
        b.Face.Value = face
        rp = b.ResizeParameters
        rp.UStart.Expression.RightHandSide = str(u0)
        rp.UEnd.Expression.RightHandSide = str(u1)
        rp.VStart.Expression.RightHandSide = str(v0)
        rp.VEnd.Expression.RightHandSide = str(v1)
        return b.CommitFeature()
    finally:
        b.Destroy()


def trim_sheet(part, body, region_xyz, keep=True, curves=None, faces=None, datum_plane=None, hp=(0, 0, 0), vec=None):
    """Trim a sheet. region_xyz = a point ON the sheet inside the region to keep (keep=True) or discard.
    Boundary: curves (projected along the face normal, or along `vec`), faces of another body, or a datum plane."""
    TSB = NXOpen.Features.TrimSheetBuilder
    b = part.Features.CreateTrimsheetBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.TargetBodies.Add(body)
        b.Regions.Append(part.CreateRegionPoint(part.Points.CreatePoint(nxh.P(*region_xyz)), body))
        b.KeepDiscardMethod = TSB.KeepDiscardOption.Keep if keep else TSB.KeepDiscardOption.Discard
        b.ExtendBoundaryObject = True       # batch default False -> "Cannot imprint ..." when the tool stops short
        if curves:
            b.BoundaryObjects.Add(section(part, curves=curves, start=hp))
        if faces:
            b.BoundaryObjects.Add(nxh.collector(part, faces=faces))
        if datum_plane is not None:         # adding the DatumPlane object itself raises "Invalid trimming objects."
            b.BoundaryObjects.Add(nxh.collector(part, datum_planes=[datum_plane]))
        if vec is not None:
            b.ProjectionDirection.ProjectDirectionMethod = GU.ProjectionOptions.DirectionType.Vector
            b.ProjectionDirection.ProjectVector = nxh.direction(part, vec)
        return b.Commit()
    finally:
        b.Destroy()


def trim_and_extend_corner(part, target, tool, reverse_target=False, reverse_tool=False):
    """Make Corner: trims both sheets at their intersection and sews them into one body."""
    TEB = NXOpen.Features.TrimAndExtendBuilder
    b = part.Features.TrimFeatureCollection.CreateTrimAndExtendBuilder(NXOpen.Features.TrimAndExtend.Null)
    try:
        b.DistanceTolerance = 0.01
        b.Operation = TEB.OperationType.MakeCorner
        b.TargetSelection.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(target)], False)
        b.ToolSelection.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(tool)], False)
        b.ReverseTarget = reverse_target
        b.ReverseTool = reverse_tool
        return b.CommitFeature()
    finally:
        b.Destroy()


def untrim(part, faces):
    b = part.Features.CreateUntrimBuilder(NF)
    try:
        b.FacesToUntrim.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


def sew(part, target, tools, tol=0.01):
    b = part.Features.CreateSewBuilder(NF)
    try:
        b.Tolerance = tol
        b.TargetBodies.Add(target)
        for t in tools:
            b.ToolBodies.Add(t)
        return b.Commit()
    finally:
        b.Destroy()


def unsew(part, faces):
    USB = NXOpen.Features.UnsewBuilder
    b = part.Features.CreateUnsewBuilder(NXOpen.Features.Unsew.Null)
    try:
        b.ToolOption = USB.UnsewTool.Face
        b.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        b.Output = USB.UnsewOutput.OneBodyForConnectedFaces
        return b.CommitFeature()
    finally:
        b.Destroy()


def thicken(part, body, first, second=0, reverse=False):
    """Sheet -> solid. first/second are offsets along the face normal (formulas allowed); the sheet stays."""
    b = part.Features.CreateThickenBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(body)], False)
        b.FirstOffset.RightHandSide = str(first)
        b.SecondOffset.RightHandSide = str(second)
        b.ReverseDirection = reverse
        b.BooleanOperation.Type = nxh.BOOL.Create
        return b.CommitFeature()
    finally:
        b.Destroy()


def trim_body_with_sheet(part, solid, tool_sheet, reverse=False):
    """Trim Body: the tool must cross the whole target. reverse=False discards the side the tool face normal
    points to (measured: normal -Z, the part below the sheet went). Assert the volume or bbox afterwards."""
    b = part.Features.CreateTrimBody2Builder(NXOpen.Features.TrimBody2.Null)
    try:
        b.Tolerance = 0.01
        b.BooleanTool.ToolOption = GU.BooleanToolBuilder.BooleanToolType.FaceOrPlane
        b.BooleanTool.FacePlaneTool.ToolFaces.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(tool_sheet)], False)
        b.TargetBodyCollector = nxh.collector(part, bodies=[solid])
        b.BooleanTool.ReverseDirection = reverse
        return b.CommitFeature()
    finally:
        b.Destroy()


def replace_face(part, faces_to_replace, replacement_faces, reverse=True):
    b = part.Features.CreateReplaceFaceBuilder(NF)
    try:
        b.FaceToReplace.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces_to_replace))], False)
        b.ReplacementFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(replacement_faces))], False)
        b.ReverseDirection = reverse
        b.OffsetDistance.RightHandSide = "0"
        return b.CommitFeature()
    finally:
        b.Destroy()


def patch(part, solid, tool_sheet, grow):
    """Patch: replace part of a solid by a sheet whose free edges lie on the solid's faces. The sheet is consumed.

    Which side survives depends on the tool sheet's normal, so ReverseDirection cannot be hard-coded: the wrong
    choice silently keeps only the pocket between sheet and solid. Commit, compare the volume with the intent
    (grow=True adds material), and flip on a mismatch. Returns (feature, reverse flag used)."""
    v0 = nxh.volume(part, solid)
    for reverse in (False, True):
        m = nxh.mark("patch", False)
        b = part.Features.CreatePatchBuilder(NF)
        try:
            b.Tolerance = 0.01
            b.Target.Value = solid
            b.Tool.Value = tool_sheet
            b.ReverseDirection = reverse
            f = b.CommitFeature()
        finally:
            b.Destroy()
        if (nxh.volume(part, solid) > v0) == grow:
            return f, reverse
        nxh.undo_to(m)
    raise RuntimeError("patch: neither direction gave the intended volume change")


# ---------------------------------------------------------------- the verified examples
def main():
    part = nxh.new_part(os.path.join(OUT, "surf_edit.prt"))
    n = res["notes"]
    below = (2 * (15 * math.sqrt(2700) + 1800 * math.asin(0.5)) - 2700) * 40      # block volume under arc_sheet

    # 1 extract -----------------------------------------------------------------------------
    _f, blk = nxh.block(part, (0, 0, 0), (60, 40, 20))
    top = nxh.faces(blk, ftype=nxh.PLANE, normal=(0, 0, 1))[0]
    side = nxh.faces(blk, ftype=nxh.PLANE, normal=(1, 0, 0))[0]
    check("extract_face_area", sheet_area(part, extract_face(part, [top]).GetBodies()[0]), 2400.0, 0.01)
    two = extract_face(part, [top, side]).GetBodies()[0]
    check("extract_2faces_area", sheet_area(part, two), 3200.0, 0.01)
    check("extract_2faces_one_body_free_edges", len(free_edges(two)), 6, 0)
    cp = extract_body(part, blk).GetBodies()[0]
    check("extract_body_volume", nxh.volume(part, cp), 48000.0, 0.01)

    # 2 offset surface -------------------------------------------------------------------------
    off = offset_surface(part, [top], 5).GetBodies()[0]
    check("offset_plane_z", nxh.bbox(off)[2], 25.0, 1e-6)
    hc = half_cyl(part, 100, 20)
    off = offset_surface(part, hc.GetFaces(), 1).GetBodies()[0]
    check("offset_halfcyl_area", sheet_area(part, off), math.pi * 6 * 50, 0.01)

    # 3 extend sheet: across the end (keeps the cylinder) and off the straight edge (keeps curving) ----
    hc = half_cyl(part, 200, 20)
    extend_sheet(part, nxh.edges(hc, lambda b: abs(b[0] - 250) < 1e-6 and abs(b[3] - 250) < 1e-6), 10)
    check("extend_end_area", sheet_area(part, hc), math.pi * 5 * 60, 0.01)
    hc = half_cyl(part, 300, 20)
    extend_sheet(part, nxh.edges(hc, lambda b: abs(b[1] - 25) < 1e-6 and abs(b[4] - 25) < 1e-6), 3)
    check("extend_side_area", sheet_area(part, hc), (math.pi * 5 + 3) * 50, 0.01)
    check("extend_side_lowest_z", nxh.bbox(hc)[2], -5 * math.sin(3 / 5), 1e-3)

    # 4 law extension -----------------------------------------------------------------------------
    sh = plane_sheet(part, 0, 100)
    e = nxh.edges(sh, lambda b: abs(b[0] - 40) < 1e-6 and abs(b[3] - 40) < 1e-6)[0]
    fl = law_extension(part, sh.GetFaces()[0], e, (40, 100, 0), 10, 90).GetBodies()[0]
    check("law_ext_area", sheet_area(part, fl), 300.0, 0.01)
    check("law_ext_90_height", nxh.bbox(fl)[5], 10.0, 1e-4)
    check("law_ext_is_new_body", int(fl.Tag != sh.Tag), 1, 0)

    # 5 trim sheet ----------------------------------------------------------------------------------
    sh = plane_sheet(part, 0, 200)
    trim_sheet(part, sh, (5, 215, 0), True, curves=[nxh.line(part, (15, 195, 0), (15, 235, 0))], hp=(15, 195, 0))
    check("trim_line_keep_left", sheet_area(part, sh), 450.0, 0.01)
    sh = plane_sheet(part, 100, 200)
    trim_sheet(part, sh, (105, 215, 0), False, curves=[nxh.line(part, (115, 195, 0), (115, 235, 0))], hp=(115, 195, 0))
    check("trim_line_discard_left", sheet_area(part, sh), 750.0, 0.01)
    sh = plane_sheet(part, 200, 200)
    trim_sheet(part, sh, (220, 215, 0), False, curves=nxh.circle(part, (220, 215, 8), 5), hp=(225, 215, 8))   # curve 8 mm above
    check("trim_circle_hole", sheet_area(part, sh), 1200 - math.pi * 25, 0.01)
    sh = plane_sheet(part, 300, 200)
    trim_sheet(part, sh, (305, 215, 0), True, curves=[nxh.line(part, (315, 210, 0), (315, 220, 0))], hp=(315, 210, 0))  # short tool
    check("trim_short_line_extended", sheet_area(part, sh), 450.0, 0.01)
    sh = plane_sheet(part, 400, 200)
    tool = extrude_sheet(part, [nxh.line(part, (415, 195, -5), (415, 235, -5))], (0, 0, 1), 0, 10, (415, 195, -5))
    trim_sheet(part, sh, (405, 215, 0), True, faces=tool.GetFaces())
    check("trim_by_faces", sheet_area(part, sh), 450.0, 0.01)
    sh = plane_sheet(part, 500, 200)
    _df, dp = nxh.datum_plane(part, (515, 200, 0), (1, 0, 0))
    trim_sheet(part, sh, (505, 215, 0), True, datum_plane=dp)
    check("trim_by_datum_plane", sheet_area(part, sh), 450.0, 0.01)
    hc = half_cyl(part, 600, 210)
    trim_sheet(part, hc, (610, 210, 5), True, curves=[nxh.line(part, (625, 200, 20), (625, 220, 20))], hp=(625, 200, 20), vec=(0, 0, -1))
    check("trim_vector_projection", sheet_area(part, hc), math.pi * 5 * 25, 0.01)

    # 6 untrim: a NEW sheet from the underlying surface; the trimmed one stays -------------------------
    sh = plane_sheet(part, 0, 300)
    trim_sheet(part, sh, (20, 315, 0), True, curves=nxh.circle(part, (20, 315, 0), 5), hp=(25, 315, 0))
    un = untrim(part, sh.GetFaces()).GetBodies()[0]
    n["untrim_plane_area"] = sheet_area(part, un)      # a plane has no natural boundary: NX returns a padded box, not 1200
    check("untrim_no_inner_loop", len(free_edges(un)), 4, 0)
    check("untrim_original_kept", sheet_area(part, sh), math.pi * 25, 0.01)

    # 7 trim and extend, make corner ---------------------------------------------------------------------
    a = plane_sheet(part, 100, 300)
    t = extrude_sheet(part, [nxh.line(part, (120, 300, -10), (120, 330, -10))], (0, 0, 1), 0, 20, (120, 300, -10))
    n0 = counts(part)
    corner = trim_and_extend_corner(part, a, t).GetBodies()[0]
    check("corner_area", sheet_area(part, corner), 900.0, 0.01)       # 20x30 of the target + 10x30 of the tool
    check("corner_faces", len(corner.GetFaces()), 2, 0)
    check("corner_merged_bodies", n0[0] - counts(part)[0], 1, 0)
    n["corner_bbox"] = nxh.bbox(corner)

    # 8 sew open sheets, gap behaviour, unsew -----------------------------------------------------------------
    a = plane_sheet(part, 0, 400)
    c = plane_sheet(part, 40.005, 400)                # 0.005 gap < tolerance 0.01
    joined = sew(part, a, [c]).GetBodies()[0]
    check("sew_open_faces", len(joined.GetFaces()), 2, 0)
    check("sew_open_free_edges", len(free_edges(joined)), 6, 0)        # 8 before
    check("sew_open_still_sheet", int(joined.IsSolidBody), 0, 0)
    a = plane_sheet(part, 100, 400)
    c = plane_sheet(part, 140.05, 400)                # 0.05 gap > tolerance
    m = nxh.mark("gap", False)
    try:
        sew(part, a, [c], 0.01)
        n["sew_gap_error"] = "no exception"
        check("sew_gap_rejected", 0, 1, 0)
    except Exception as ex:  # noqa: BLE001
        n["sew_gap_error"] = str(ex)
        nxh.undo_to(m)
        check("sew_gap_rejected", 1, 1, 0)
    a = plane_sheet(part, 200, 400)
    c = plane_sheet(part, 240.05, 400)
    joined = sew(part, a, [c], 0.1).GetBodies()[0]    # larger sew tolerance closes it (tolerant edge)
    check("sew_gap_big_tol_faces", len(joined.GetFaces()), 2, 0)
    right = [f for f in joined.GetFaces() if nxh.bbox(f)[0] > 239][0]
    parts = unsew(part, [right]).GetBodies()
    check("unsew_bodies", len(parts), 2, 0)

    # 9 thicken, expression driven ----------------------------------------------------------------------------------
    nxh.expr(part, "wall_t", "2", comment="thicken wall")
    sh = plane_sheet(part, 0, 500)
    solid = thicken(part, sh, "wall_t").GetBodies()[0]
    check("thicken_volume", nxh.volume(part, solid), 2400.0, 0.01)
    nxh.set_expr(part, "wall_t", "3.5")
    nxh.update()
    check("thicken_volume_after_edit", nxh.volume(part, solid), 4200.0, 0.01)
    hc = half_cyl(part, 100, 510)
    check("thicken_outward", nxh.volume(part, thicken(part, hc, 1).GetBodies()[0]), math.pi / 2 * 11 * 50, 0.01)
    hc = half_cyl(part, 200, 510)
    check("thicken_reversed", nxh.volume(part, thicken(part, hc, 1, 0, True).GetBodies()[0]), math.pi / 2 * 9 * 50, 0.01)
    hc = half_cyl(part, 300, 510)
    check("thicken_both_sides", nxh.volume(part, thicken(part, hc, 1, -1).GetBodies()[0]), math.pi / 2 * 20 * 50, 0.01)

    # 10 trim a solid with a sheet / replace a face with a sheet ---------------------------------------------------------
    _f, blk = nxh.block(part, (0, 600, 0), (60, 40, 20))
    n0 = counts(part)
    trim_body_with_sheet(part, blk, arc_sheet(part, 0, 600), reverse=True)
    check("trim_body_volume", nxh.volume(part, blk), below, 0.05)
    check("trim_body_solids_unchanged", counts(part)[1], n0[1], 0)
    _f, blk = nxh.block(part, (100, 600, 0), (60, 40, 20))
    trim_body_with_sheet(part, blk, arc_sheet(part, 100, 600), reverse=False)
    check("trim_body_other_side", nxh.volume(part, blk), 48000 - below, 0.05)
    _f, blk = nxh.block(part, (200, 600, 0), (60, 40, 20))
    tool = arc_sheet(part, 200, 600)
    replace_face(part, [nxh.faces(blk, ftype=nxh.PLANE, normal=(0, 0, 1))[0]], tool.GetFaces())
    check("replace_face_volume", nxh.volume(part, blk), below, 0.05)

    # 11 patch: a sewn cup (frustum wall + lid) welded onto the block top ---------------------------------------------------
    _f, blk = nxh.block(part, (0, 700, 0), (60, 40, 20))
    ln = nxh.line(part, (40, 720, 20), (35, 720, 28))
    b = part.Features.CreateRevolveBuilder(NF)
    try:
        b.Section = section(part, curves=[ln], start=(40, 720, 20))
        b.Axis = nxh.axis(part, (30, 720, 0), (0, 0, 1))
        b.Limits.StartExtend.Value.RightHandSide = "0"
        b.Limits.EndExtend.Value.RightHandSide = "360"
        b.FeatureOptions.BodyType = SHEET
        b.BooleanOperation.Type = nxh.BOOL.Create
        b.Tolerance = 0.01
        cup = b.CommitFeature().GetBodies()[0]
    finally:
        b.Destroy()
    rim = [e for e in cup.GetEdges() if abs(nxh.bbox(e)[2] - 28) < 1e-6]
    bp = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        bp.BoundingCurves.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        fill(bp.BoundingCurves, part, edges=rim, start=(35, 720, 28))
        lid = bp.CommitFeature().GetBodies()[0]
    finally:
        bp.Destroy()
    sew(part, cup, [lid])
    check("cup_free_edges", len(free_edges(cup)), 1, 0)
    n0 = counts(part)
    _pf, n["patch_reverse_used"] = patch(part, blk, cup, grow=True)
    check("patch_volume", nxh.volume(part, blk), 48000 + math.pi * 8 / 3 * 175, 0.05)
    check("patch_consumed_sheet", n0[0] - counts(part)[0], 1, 0)

    n["feature_errors"] = nxh.feature_errors(part)
    check("no_feature_errors", len(n["feature_errors"]), 0, 0)
    nxh.save(part)


try:
    main()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res["result"] = "PASS" if "error" not in res and res["checks"] and all(c["ok"] for c in res["checks"]) else "FAIL"
nxh.write_json(os.path.join(OUT, "surf_edit.json"), res)
