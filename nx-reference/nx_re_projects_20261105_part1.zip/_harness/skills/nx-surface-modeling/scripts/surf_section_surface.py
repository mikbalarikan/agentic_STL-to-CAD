"""Section Surface on NX 2206 (SectionSurfaceBuilderEx): the Conic / Circular / Cubic / Linear grouping, which
inputs each type needs, spine and U-degree rules - measured on a fillet-like corner between two faces.

    run_journal.ps1 -Script surf_section_surface.py -WorkDir <out> -JArgs <out>   ->  <out>\\surf_section_surface.json

Geometry of every case: face A = the plane z = 0 (x 10..40), face B = the plane x = 0 (z 10..40), both 60 long
in Y. Start guide = the edge of A at x = 10, end guide = the edge of B at z = 10; the two faces would meet in
the line x = z = 0 (the apex line). A cross-section runs from (10, y, 0) to (0, y, 10).

C1  Conic, Rho, slope By Faces (8.5 "Fillet-Rho"): rho 0.5 / sqrt(2)-1 / 0.7; U degree Conic / Cubic / Quintic
C2  Conic, Rho, slope By Apex (8.5 "Ends-Apex-Rho"): no faces, an apex curve instead
C3  Conic, Shoulder, slope By Apex (8.5 "Ends-Apex-Shoulder"): a shoulder curve instead of rho
C4  Conic, Rho, slope By Curves (8.5 "Ends-Slope-Rho")
C5  Cubic, Fillet Bridge between the two faces, G1 and G2
C6  Circular: Three Point, Two Point + Radius, Tangent-Tangent-Radius
C7  Spine: by vector / by curve; a spine shorter than the guides limits the surface
(A Conic type with NO spine at all ended in "Internal error: memory access violation" in the development run and
is left out of this journal on purpose: always set SpineType + SpineVector or SpineSection, Fillet Bridge excepted.)
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
GU = NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
SSB = NXOpen.Features.SectionSurfaceBuilderEx
CT = GU.Continuity.ContinuityTypes
LAW = GU.LawBuilder.Type
ONLY_CURVES = NXOpen.Section.AllowTypes.OnlyCurves
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
notes = res["notes"]
D = 10.0                # distance of both guides from the apex line
LY = 60.0


def save_json():
    out = dict(res)
    out.update(chk.report())
    nxh.write_json(os.path.join(OUT, "surf_section_surface.json"), out)


def ok(r):
    return isinstance(r, dict) and "error" not in r


def edge_points(edge, n=5):
    props = nxh.UFS.ModlGeneral.AskCurveProps
    return [tuple(props(edge.Tag, (i + 1.0) / (n + 1.0))[0]) for i in range(n)]


def bounded_plane(part, curves, hp):
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.BoundingCurves, curves=curves, help_point=hp)
        return b.CommitFeature()
    finally:
        b.Destroy()


# ---------------------------------------------------------------- the recipe
def section_surface(part, stype, mode, start=None, end=None, start_face=None, end_face=None, slope_control=None, apex=None, shoulder=None,
                    interior=(), start_slope=None, end_slope=None, rho=None, radius=None, angle=None, udegree=None, spine=None, spine_vector=None,
                    continuity=None, info=None):
    """Section Surface. A string is a dict: {"curves": [...]} or {"edges": [...]} plus "hp" (help point = its start).

    stype / mode    SSB.Types.Conic + SSB.ConicType.x | Circular + CircularType.x | Cubic + CubicType.x | Linear + LinearType.x
    start / end     the two guides the cross-section runs between (SectionStartGuide / SectionEndGuide)
    slope_control   SSB.SlopeControlType.ByApex (+ apex) | ByCurves (+ start_slope, end_slope) | ByFaces (+ start_face, end_face)
    shoulder / rho  the fullness of a conic: a curve the section passes through, or a rho value 0 < rho < 1
    interior        up to three interior guides (Circular ThreePoint, Conic FivePoint / FourPointSlope)
    spine / spine_vector   the cross-sections lie in planes normal to the spine; one of them is always needed
    continuity      (CT.G1 | CT.G2, CT.G1 | CT.G2) for the Cubic Fillet Bridge (start, end)
    """
    b = part.Features.CreateSectionSurfaceBuilderEx(NXOpen.Features.SectionSurface.Null)
    try:
        b.Type = stype
        if stype == SSB.Types.Conic:
            b.ConicTypeMode = mode
        elif stype == SSB.Types.Circular:
            b.CircularTypeMode = mode
        elif stype == SSB.Types.Cubic:
            b.CubicTypeMode = mode
        else:
            b.LinearTypeMode = mode
        b.G0Tolerance = 0.01
        b.G1Tolerance = 0.5
        b.G2Tolerance = 0.5

        def put(sec, s):
            sec.SetAllowedEntityTypes(ONLY_CURVES)
            nxh.fill_section(part, sec, curves=s.get("curves"), edges=s.get("edges"), help_point=s["hp"])
        if slope_control is not None:
            b.SlopeControl = slope_control
        if start is not None:
            put(b.SectionStartGuide, start)
        if end is not None:
            put(b.SectionEndGuide, end)
        if start_face is not None:
            b.StartFace.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(start_face))], False)
        if end_face is not None:
            b.EndFace.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(end_face))], False)
        if apex is not None:
            put(b.ApexCurve, apex)
        if shoulder is not None:
            put(b.ShoulderCurve, shoulder)
        for sec, s in zip((b.SectionInteriorGuide1, b.SectionInteriorGuide2, b.SectionInteriorGuide3), interior):
            put(sec, s)
        if start_slope is not None:
            put(b.StartSlopeCurve, start_slope)
        if end_slope is not None:
            put(b.EndSlopeCurve, end_slope)
        if rho is not None:
            b.SectionMethodRho = SSB.SectionMethodRhoType.Rho
            b.RhoLaw.LawType = LAW.Constant
            b.RhoLaw.Value.RightHandSide = str(rho)
        if radius is not None:
            b.RadiusLaw.LawType = LAW.Constant
            b.RadiusLaw.Value.RightHandSide = str(radius)
        if angle is not None:
            b.AngleLaw.LawType = LAW.Constant
            b.AngleLaw.Value.RightHandSide = str(angle)
        if udegree is not None:
            b.UDegree = udegree
        if continuity is not None:
            b.SectionMethodFilletBridge = SSB.SectionMethodFilletBridgeType.Continuity
            b.StartContinuity.ContinuityType = continuity[0]
            b.EndContinuity.ContinuityType = continuity[1]
        if spine is not None:
            b.SpineType = SSB.Spine.ByCurve
            put(b.SpineSection, spine)
        elif spine_vector is not None:
            b.SpineType = SSB.Spine.ByVector
            b.SpineVector = nxh.direction(part, spine_vector)
        b.BodyTypePreference = SSB.BodyType.Sheet
        if info is not None:
            info.update({"UDegree_set": str(b.UDegree), "SpineType": str(b.SpineType)})
        return b.CommitFeature()
    finally:
        b.Destroy()


# ---------------------------------------------------------------- the corner and the measurement
class Corner:
    """Two planar sheets around the apex line (x0, y, 0), y 0..60, plus the dumb curves the curve-driven types use."""

    def __init__(self, part, x0, faces=True):
        self.part, self.x0 = part, x0
        self.fa = self.fb = self.ea = self.eb = None
        if faces:
            a = bounded_plane(part, nxh.rect(part, x0 + D, 0, x0 + 40, LY, 0.0), (x0 + D, 0, 0)).GetBodies()[0]
            pb = nxh.polyline(part, [(x0, 0, D), (x0, LY, D), (x0, LY, 40), (x0, 0, 40)])
            bb = bounded_plane(part, pb, (x0, 0, D)).GetBodies()[0]
            self.fa, self.fb = a.GetFaces()[0], bb.GetFaces()[0]
            self.ea = [e for e in a.GetEdges() if all(abs(v.X - (x0 + D)) < 1e-6 for v in e.GetVertices())][0]
            self.eb = [e for e in bb.GetEdges() if all(abs(v.Z - D) < 1e-6 for v in e.GetVertices())][0]

    def line(self, dx, dz, y0=0.0, y1=LY):
        return nxh.line(self.part, (self.x0 + dx, y0, dz), (self.x0 + dx, y1, dz))

    def start(self):
        return {"edges": [self.ea], "hp": (self.x0 + D, 0, 0)} if self.ea is not None else {"curves": [self.line(D, 0)], "hp": (self.x0 + D, 0, 0)}

    def end(self):
        return {"edges": [self.eb], "hp": (self.x0, 0, D)} if self.eb is not None else {"curves": [self.line(0, D)], "hp": (self.x0, 0, D)}

    def string(self, dx, dz, y0=0.0, y1=LY):
        return {"curves": [self.line(dx, dz, y0, y1)], "hp": (self.x0 + dx, y0, dz)}

    def report(self, feat, rho=None):
        part, x0 = self.part, self.x0
        body = feat.GetBodies()[0]
        faces = list(body.GetFaces())
        rep = {"faces": len(faces), "types": nxh.face_census(body)["types"], "area": round(nxh.sheet_area(part, body)[0], 3),
               "y_range": [nxh.bbox(body)[1], nxh.bbox(body)[4]], "x_range": [round(nxh.bbox(body)[0] - x0, 3), round(nxh.bbox(body)[3] - x0, 3)],
               "z_range": [nxh.bbox(body)[2], nxh.bbox(body)[5]],
               "start_guide_off_mm": round(max(abs(nxh.dist_to(part, body, (x0 + D, y, 0))) for y in (15, 30, 45)), 5),
               "end_guide_off_mm": round(max(abs(nxh.dist_to(part, body, (x0, y, D))) for y in (15, 30, 45)), 5)}
        f0 = faces[0]
        # where does the cross-section at y = 30 cross the diagonal of the corner?  (t, y, t)  ->  rho = 1 - t / (D / 2)
        lo, hi = 0.0, D / 2.0
        probe = part.Curves.CreateLine(nxh.P(x0, 30, 0), nxh.P(x0 + D / 2, 30, D / 2))
        try:
            dmin = nxh.UFS.Modeling.AskMinimumDist(probe.Tag, body.Tag, 0, [0.0] * 3, 0, [0.0] * 3)
            pt = list(dmin[2])
            rep["diagonal_crossing_t_mm"] = round(pt[0] - x0, 4)
            rep["measured_rho"] = round(1.0 - (pt[0] - x0) / (D / 2.0), 4)
            rep["diagonal_miss_mm"] = round(dmin[0], 5)
        except Exception as e:  # noqa: BLE001
            rep["diagonal_error"] = str(e)[:100]
        finally:
            nxh.S.UpdateManager.AddToDeleteList(probe)
        if rho is not None:
            t = D / 2.0 * (1.0 - rho)
            rep["analytic_shoulder_off_mm"] = round(abs(nxh.dist_to(part, body, (x0 + t, 30, t))), 5)
        # tangency to the planes z = 0 and x = 0 along the guides (works with or without real faces)
        def off_plane(p, nplane):
            a = nxh.angle_deg(nxh.normal_at(f0, p), nplane)
            return min(a, 180.0 - a)
        rep["g1_dev_start_deg"] = round(max(off_plane((x0 + D, y, 0), (0, 0, 1)) for y in (10, 30, 50)), 3)
        rep["g1_dev_end_deg"] = round(max(off_plane((x0, y, D), (1, 0, 0)) for y in (10, 30, 50)), 3)
        rep["curvature_at_start_guide"] = round(nxh.max_curvature(f0, (x0 + D, 30, 0)), 5)
        rep["curvature_at_mid"] = round(nxh.max_curvature(f0, (x0 + rep.get("diagonal_crossing_t_mm", 2.5), 30, rep.get("diagonal_crossing_t_mm", 2.5))), 5)
        return rep


def case(store, name, fn):
    m = nxh.mark(name, False)
    try:
        store[name] = fn()
    except Exception as e:  # noqa: BLE001
        store[name] = {"error": str(e)[:300]}
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass
    save_json()
    return store[name]


def run():
    part = nxh.new_part(os.path.join(OUT, "surf_section_surface.prt"))
    T, CN, CI, CU, LI, SC, UD = SSB.Types, SSB.ConicType, SSB.CircularType, SSB.CubicType, SSB.LinearType, SSB.SlopeControlType, SSB.UDegreeType
    RC = math.sqrt(2.0) - 1.0                                            # the rho of a circular arc in a 90 deg corner
    nx = [0]

    def corner(faces=True):
        nx[0] += 1
        return Corner(part, 100.0 * nx[0], faces)

    # ---- C1 Conic, Rho, By Faces
    C1 = notes["C1_conic_rho_by_faces"] = {}

    def c1(rho, udeg=None, spine_vector=(0, 1, 0), spine=None):
        c = corner()
        info = {}
        sp = c.string(0, 0) if spine == "apex_line" else None
        f = section_surface(part, T.Conic, CN.Rho, start=c.start(), end=c.end(), start_face=[c.fa], end_face=[c.fb], slope_control=SC.ByFaces,
                            rho=rho, udegree=udeg, spine=sp, spine_vector=None if sp else spine_vector, info=info)
        rep = c.report(f, rho)
        rep.update(info)
        return rep
    case(C1, "rho_0.5", lambda: c1(0.5))
    case(C1, "rho_circle_0.4142", lambda: c1(RC))
    case(C1, "rho_0.7", lambda: c1(0.7))
    case(C1, "rho_0.5_udegree_conic", lambda: c1(0.5, UD.Conic))
    case(C1, "rho_0.5_udegree_cubic", lambda: c1(0.5, UD.Cubic))
    case(C1, "rho_0.5_udegree_quintic", lambda: c1(0.5, UD.Quintic))
    case(C1, "rho_0.8_udegree_conic", lambda: c1(0.8, UD.Conic))
    case(C1, "rho_0.8_udegree_cubic", lambda: c1(0.8, UD.Cubic))
    case(C1, "rho_0.5_spine_by_curve", lambda: c1(0.5, spine="apex_line"))
    case(C1, "rho_0.7_udegree_cubic", lambda: c1(0.7, UD.Cubic))
    case(C1, "rho_0.7_udegree_quintic", lambda: c1(0.7, UD.Quintic))

    # ---- C2 Conic, Rho, By Apex: curves only
    C2 = notes["C2_conic_rho_by_apex"] = {}

    def c2(rho):
        c = corner(faces=False)
        f = section_surface(part, T.Conic, CN.Rho, start=c.start(), end=c.end(), slope_control=SC.ByApex, apex=c.string(0, 0), rho=rho, spine_vector=(0, 1, 0))
        return c.report(f, rho)
    case(C2, "rho_0.5", lambda: c2(0.5))
    case(C2, "rho_0.7", lambda: c2(0.7))

    # ---- C3 Conic, Shoulder, By Apex: the shoulder curve of a rho 0.6 conic
    C3 = notes["C3_conic_shoulder_by_apex"] = {}

    def c3(rho_equiv):
        c = corner(faces=False)
        t = D / 2.0 * (1.0 - rho_equiv)
        f = section_surface(part, T.Conic, CN.Shoulder, start=c.start(), end=c.end(), slope_control=SC.ByApex, apex=c.string(0, 0), shoulder=c.string(t, t), spine_vector=(0, 1, 0))
        return c.report(f, rho_equiv)
    case(C3, "shoulder_curve_of_rho_0.6", lambda: c3(0.6))

    # ---- C4 Conic, Rho, By Curves (slope curves: the end tangents aim at them)
    C4 = notes["C4_conic_rho_by_curves"] = {}

    def c4(rho):
        c = corner(faces=False)
        f = section_surface(part, T.Conic, CN.Rho, start=c.start(), end=c.end(), slope_control=SC.ByCurves, start_slope=c.string(0, 0), end_slope=c.string(0, 0),
                            rho=rho, spine_vector=(0, 1, 0))
        return c.report(f, rho)
    case(C4, "rho_0.5_both_slope_curves_on_the_apex_line", lambda: c4(0.5))

    # ---- C5 Cubic, Fillet Bridge
    C5 = notes["C5_cubic_fillet_bridge"] = {}

    def c5(c0, c1_, spine_vector=None):
        c = corner()
        f = section_surface(part, T.Cubic, CU.FilletBridge, start=c.start(), end=c.end(), start_face=[c.fa], end_face=[c.fb], continuity=(c0, c1_), spine_vector=spine_vector)
        return c.report(f)
    case(C5, "G1_G1_no_spine", lambda: c5(CT.G1, CT.G1))
    case(C5, "G2_G2_no_spine", lambda: c5(CT.G2, CT.G2))
    case(C5, "G1_G1_spine_vector", lambda: c5(CT.G1, CT.G1, (0, 1, 0)))

    # ---- C6 Circular types
    C6 = notes["C6_circular"] = {}

    def c6_three():
        c = corner(faces=False)
        t = D - D / math.sqrt(2.0)                                       # the 45 deg point of the R10 arc centred (10, y, 10)
        f = section_surface(part, T.Circular, CI.ThreePoint, start=c.start(), end=c.end(), interior=[c.string(t, t)], spine_vector=(0, 1, 0))
        return c.report(f, RC)

    def c6_two_radius(r):
        c = corner(faces=False)
        f = section_surface(part, T.Circular, CI.TwoPointRadius, start=c.start(), end=c.end(), radius=r, spine_vector=(0, 1, 0))
        return c.report(f)

    def c6_two_radius_swapped(r):
        c = corner(faces=False)
        f = section_surface(part, T.Circular, CI.TwoPointRadius, start=c.end(), end=c.start(), radius=r, spine_vector=(0, 1, 0))
        return c.report(f)

    def c6_radius_angle(r, ang):
        c = corner()
        f = section_surface(part, T.Circular, CI.RadiusAngleArc, start=c.start(), start_face=[c.fa], radius=r, angle=ang, spine_vector=(0, 1, 0))
        return c.report(f)

    def c6_ttr(r):
        c = corner()
        f = section_surface(part, T.Circular, CI.TangentTangentRadius, start_face=[c.fa], end_face=[c.fb], radius=r, spine=c.string(0, 0))
        return c.report(f)

    def c6_two_slope():
        c = corner(faces=False)
        f = section_surface(part, T.Circular, CI.TwoPointSlope, start=c.start(), end=c.end(), start_slope=c.string(0, 0), spine_vector=(0, 1, 0))
        return c.report(f, RC)
    case(C6, "three_point", c6_three)
    case(C6, "two_point_radius_10", lambda: c6_two_radius(10))
    case(C6, "two_point_radius_15", lambda: c6_two_radius(15))
    case(C6, "tangent_tangent_radius_10", lambda: c6_ttr(10))
    case(C6, "two_point_slope", c6_two_slope)
    case(C6, "two_point_radius_10_guides_swapped", lambda: c6_two_radius_swapped(10))
    case(C6, "radius_angle_arc_10_90", lambda: c6_radius_angle(10, 90))
    case(C6, "radius_angle_arc_10_45", lambda: c6_radius_angle(10, 45))

    # ---- C7 spine: none; shorter than the guides
    C7 = notes["C7_spine"] = {}

    def c7(kind):
        c = corner()
        kw = {}
        if kind == "short_curve":
            kw["spine"] = c.string(0, 0, 15.0, 45.0)
        elif kind == "vector":
            kw["spine_vector"] = (0, 1, 0)
        f = section_surface(part, T.Conic, CN.Rho, start=c.start(), end=c.end(), start_face=[c.fa], end_face=[c.fb], slope_control=SC.ByFaces, rho=0.5, **kw)
        return c.report(f, 0.5)
    case(C7, "spine_curve_y_15_to_45", lambda: c7("short_curve"))
    case(C7, "spine_vector", lambda: c7("vector"))

    # ---- linear tangent-tangent (recorded)
    C8 = notes["C8_linear"] = {}

    def c8():
        c = corner()
        f = section_surface(part, T.Linear, LI.TangentTangent, start_face=[c.fa], end_face=[c.fb], spine=c.string(0, 0))
        return c.report(f)
    case(C8, "tangent_tangent", c8)
    # ================================================================ checks
    arc_area = 0.5 * math.pi * D * LY                                    # quarter cylinder R10 x 60 = 942.478

    def tangent_both(r, tol=0.05):
        return ok(r) and r["g1_dev_start_deg"] < tol and r["g1_dev_end_deg"] < tol and r["start_guide_off_mm"] < 1e-4 and r["end_guide_off_mm"] < 1e-4

    for name, rho in (("rho_0.5", 0.5), ("rho_circle_0.4142", RC), ("rho_0.7", 0.7)):
        r = C1[name]
        chk.true("C1 Conic / Rho / By Faces, rho %.4f: on both guides, tangent to both faces (0.00 deg)" % rho, tangent_both(r), r)
        if ok(r):
            chk("C1 rho %.4f: the section crosses the corner diagonal where the conic formula says (measured rho)" % rho, r["measured_rho"], rho, 0.001)
    rc = C1["rho_circle_0.4142"]
    chk.true("C1 rho = sqrt(2) - 1 in a 90 deg corner IS the circular fillet: curvature 1/10 at the guide and in the middle, area = quarter cylinder",
             ok(rc) and abs(rc["curvature_at_start_guide"] - 0.1) < 1e-4 and abs(rc["curvature_at_mid"] - 0.1) < 1e-4 and abs(rc["area"] - arc_area) < 0.01, rc)
    r5, r7 = C1["rho_0.5"], C1["rho_0.7"]
    chk.true("C1 a larger rho is a fuller section: flatter at the guides (curvature 0.050 -> 0.009), sharper in the middle (0.141 -> 0.330)",
             ok(r5) and ok(r7) and r7["curvature_at_start_guide"] < r5["curvature_at_start_guide"] and r7["curvature_at_mid"] > r5["curvature_at_mid"], (r5, r7))
    uc, uq, un = C1["rho_0.5_udegree_cubic"], C1["rho_0.5_udegree_quintic"], C1["rho_0.5_udegree_conic"]
    chk.true("C1 U degree Conic / Cubic / Quintic at rho 0.5 (a parabola): the same surface (area equal to 0.001)",
             all(ok(r) for r in (uc, uq, un)) and abs(uc["area"] - un["area"]) < 1e-3 and abs(uq["area"] - un["area"]) < 1e-3, (un, uc, uq))
    c7c, c7q = C1["rho_0.7_udegree_cubic"], C1["rho_0.7_udegree_quintic"]
    chk.true("C1 at rho 0.7 Cubic / Quintic are APPROXIMATIONS of the conic: same shoulder and end tangents, different area (1057.99 vs 1056.75)",
             ok(c7c) and ok(c7q) and tangent_both(c7c) and abs(c7c["measured_rho"] - 0.7) < 0.001 and abs(c7c["area"] - r7["area"]) > 0.5, (r7, c7c, c7q))
    chk.true("C1 rho 0.8 with U degree Cubic is refused ('Rho must be between 0.0001 and 0.7500 for non-conic cases.'); with Conic it builds",
             "Rho must be between" in C1["rho_0.8_udegree_cubic"].get("error", "") and tangent_both(C1["rho_0.8_udegree_conic"]),
             (C1["rho_0.8_udegree_cubic"], C1["rho_0.8_udegree_conic"]))
    chk.true("C1 spine by curve (the apex line) = spine by vector: same surface", ok(C1["rho_0.5_spine_by_curve"]) and abs(C1["rho_0.5_spine_by_curve"]["area"] - r5["area"]) < 1e-3,
             C1["rho_0.5_spine_by_curve"])

    for name, rho in (("rho_0.5", 0.5), ("rho_0.7", 0.7)):
        r = C2[name]
        chk.true("C2 Conic / Rho / By Apex (curves only, no faces), rho %.1f: end tangents aim at the apex curve - the same surface as By Faces" % rho,
                 tangent_both(r) and abs(r["measured_rho"] - rho) < 0.001 and abs(r["area"] - C1[name]["area"]) < 1e-3, r)
    r = C3["shoulder_curve_of_rho_0.6"]
    chk.true("C3 Conic / Shoulder / By Apex: the section passes through the shoulder curve (0.000 mm) - here the curve of rho 0.6", tangent_both(r)
             and r["analytic_shoulder_off_mm"] < 1e-4 and abs(r["measured_rho"] - 0.6) < 0.001, r)
    r = C4["rho_0.5_both_slope_curves_on_the_apex_line"]
    chk.true("C4 Conic / Rho / By Curves: one slope curve per end; both on the apex line gives the By Apex surface", tangent_both(r) and abs(r["area"] - r5["area"]) < 1e-3, r)

    g1, g2, g1s = C5["G1_G1_no_spine"], C5["G2_G2_no_spine"], C5["G1_G1_spine_vector"]
    chk.true("C5 Cubic / Fillet Bridge, G1 / G1: tangent to both faces, NO spine needed", tangent_both(g1), g1)
    chk.true("C5 Fillet Bridge G2 / G2: tangent and curvature 0 at the guide = the planar face's (G1: 0.159 there)", tangent_both(g2) and g2["curvature_at_start_guide"] < 1e-3
             and g1["curvature_at_start_guide"] > 0.05, (g1, g2))
    chk.true("C5 Fillet Bridge: a spine vector changes nothing (same area)", ok(g1s) and abs(g1s["area"] - g1["area"]) < 1e-3, g1s)
    chk.true("C5 the bridge is not a circle: G1 is flatter in the middle than R10 (crossing 3.23 > 2.93), G2 fuller (2.13)",
             ok(g1) and ok(g2) and g1["diagonal_crossing_t_mm"] > 2.95 and g2["diagonal_crossing_t_mm"] < 2.90, (g1.get("diagonal_crossing_t_mm"), g2.get("diagonal_crossing_t_mm")))

    tp, t10, t10s, ttr, tps, ra90, ra45 = (C6["three_point"], C6["two_point_radius_10"], C6["two_point_radius_10_guides_swapped"], C6["tangent_tangent_radius_10"],
                                           C6["two_point_slope"], C6["radius_angle_arc_10_90"], C6["radius_angle_arc_10_45"])
    for nm, r in (("Three Point (start, interior, end guide)", tp), ("Tangent-Tangent-Radius (two faces + radius, spine curve)", ttr),
                  ("Two Point + Slope (slope curve on the apex line)", tps)):
        chk.true("C6 Circular / %s: the exact R10 fillet (area 942.478, curvature 0.1, tangent to both planes)" % nm,
                 ok(r) and abs(r["area"] - arc_area) < 0.01 and abs(r["curvature_at_mid"] - 0.1) < 1e-4 and r["g1_dev_start_deg"] < 0.05 and r["g1_dev_end_deg"] < 0.05, r)
    chk.true("C6 Circular / Two Point + Radius has two arcs: the ORDER of the guides picks the side - start = edge A gives the arc bulging away "
             "(90 deg to both planes), guides swapped gives the tangent fillet",
             ok(t10) and ok(t10s) and t10["g1_dev_start_deg"] > 80.0 and t10s["g1_dev_start_deg"] < 0.05 and abs(t10s["area"] - arc_area) < 0.01, (t10, t10s))
    chk.true("C6 Circular / Radius-Angle-Arc (guide + face + radius + angle): starts ON the guide tangent to the face; area = r x angle x length (90 and 45 deg)",
             ok(ra90) and ok(ra45) and ra90["g1_dev_start_deg"] < 0.05 and abs(ra90["area"] - arc_area) < 0.01 and abs(ra45["area"] - arc_area / 2) < 0.01, (ra90, ra45))

    sc, sv = C7["spine_curve_y_15_to_45"], C7["spine_vector"]
    chk.true("C7 a spine curve shorter than the guides (y 15..45): the surface is only as long as the spine (y 15..45, half the area)",
             ok(sc) and abs(sc["y_range"][0] - 15.0) < 0.01 and abs(sc["y_range"][1] - 45.0) < 0.01 and abs(sc["area"] - sv["area"] / 2) < 0.01, (sc, sv))
    notes["C8_linear"]["note"] = "Linear / Tangent-Tangent between two planes with the apex line as spine: recorded only"
    notes["feature_errors"] = str(nxh.feature_errors(part))
    res["features"] = len(nxh.feature_table(part))
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-500:])
save_json()
