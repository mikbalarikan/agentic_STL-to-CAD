"""Course claims (NX training, surface day CAD5.4-5.6) checked by measurement on NX 2206 batch.

Alignment on a rectangle-to-triangle loft, G1/G2 at Through Curves ends, G1 on Through Curve Mesh
boundaries, headless continuity checks (the stand-in for Reflection analysis), Face Blend between sheets
and between disjoint bodies, Trim and Extend Make Corner with free edges, Law Extension angles, Thicken
offset pairs, Swept vs Sweep Along Guide on skewed sections / sharp guides, Fill Surface vs N-Sided on a
hole in a skin, closing an open shell to a solid, Examine Geometry on open / closed bodies.

Needs the nxh version that has sheet_area / free_edges / dist_to / normal_at / fill_section / Check.
Usage: run_journal surf_course_checks.py -args <output folder>
Writes <output folder>/surf_course_checks.json ("result": "PASS"|"FAIL", "checks", "notes").
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
GU = NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
TCB = NXOpen.Features.ThroughCurvesBuilder
AT = GU.AlignmentMethodBuilder.Type
CT = GU.Continuity.ContinuityTypes
SHEET, SOLID = GU.FeatureOptions.BodyStyle.Sheet, GU.FeatureOptions.BodyStyle.Solid
chk = nxh.Check()
notes = {}


# ---------------------------------------------------------------- headless surface-quality checks
def angle_deg(u, v):
    d = abs(sum(a * b for a, b in zip(u, v)))           # sign-free: sheet normals may be flipped
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))


def g1_deviation(face_a, face_b, points):
    """Max angle (deg) between the two face normals at points of their common boundary.
    0 = tangent (G1). This replaces Reflection analysis in a journal: a crease shows as degrees."""
    return max(angle_deg(nxh.normal_at(face_a, p), nxh.normal_at(face_b, p)) for p in points)


def curvature_radii(face, xyz):
    """Principal radii of curvature of a face at the point nearest xyz (sign follows the face normal)."""
    parm, _p = nxh.UFS.Modeling.AskFaceParm(face.Tag, [float(v) for v in xyz])
    return list(nxh.UFS.Modeling.AskFaceProps(face.Tag, parm)[6])


def max_curvature(face, xyz):
    """Largest principal curvature (1/mm) at a point; equal values on both sides of an edge = G2 there."""
    return max(abs(1.0 / r) if abs(r) > 1e-9 else 0.0 for r in curvature_radii(face, xyz))


def counts(part):
    return len(nxh.sheets(part)), len(nxh.solids(part))


def trial(name, fn, *a):
    """Run one experiment; an unexpected exception is recorded and fails the run."""
    m = nxh.mark("trial " + name, False)
    try:
        fn(*a)
    except Exception:  # noqa: BLE001
        notes[name + "_error"] = traceback.format_exc()[-900:]
        chk.true(name + " ran", False, notes[name + "_error"][-200:])
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------- recipes
def through_curves(part, sections, solid=False, preserve=False, align=None, first=None, last=None, points=None):
    """first / last = (ContinuityTypes.G1 | G2, [neighbour faces]). points = alignment points for AlignType.Points:
    one list of xyz per section, same count on every section, in string order."""
    b = part.Features.CreateThroughCurvesBuilder(NF)
    try:
        b.PreserveShape = preserve
        b.PatchType = TCB.PatchTypes.Multiple
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.CurvatureTolerance = 0.5
        b.BodyPreference = TCB.BodyPreferenceTypes.Solid if solid else TCB.BodyPreferenceTypes.Sheet
        for s in sections:
            b.SectionsList.Append(s)
        b.Alignment.SetSections(list(sections))
        if align is not None:
            b.Alignment.AlignType = align
        if points is not None:
            b.Alignment.AlignType = AT.Points
            dims = [b.Alignment.CreateOnPathDimBuilder(s, nxh.P(*p)) for s, pl in zip(sections, points) for p in pl]
            b.Alignment.SetAlignPoints(dims)
        for cont, spec in ((b.FirstSectionContinuity, first), (b.LastSectionContinuity, last)):
            if spec:
                cont.ContinuityType = spec[0]
                cont.ConstraintFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(spec[1]))], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


def ruled(part, c1, hp1, c2, hp2):
    b = part.Features.CreateRuledBuilder(NF)
    try:
        b.PositionTolerance = 0.01
        for sec, c, hp in ((b.FirstSection, c1, hp1), (b.SecondSection, c2, hp2)):
            sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
            nxh.fill_section(part, sec, curves=c, help_point=hp)
        b.AlignmentMethod.SetSections([b.FirstSection, b.SecondSection])
        b.BodyPreference.BodyType = SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


def curve_mesh(part, primaries, crosses, cont=None):
    """cont = {"first_primary": faces, "last_primary": faces, "first_cross": faces, "last_cross": faces} -> G1."""
    b = part.Features.CreateThroughCurveMeshBuilder(NF)
    try:
        b.PositionTolerance = 0.01
        b.IntersectionTolerance = 0.01
        b.TangentTolerance = 0.5
        for s in primaries:
            b.PrimaryCurvesList.Append(s)
        for s in crosses:
            b.CrossCurvesList.Append(s)
        for key, c in (("first_primary", b.FirstPrimaryContinuity), ("last_primary", b.LastPrimaryContinuity),
                       ("first_cross", b.FirstCrossContinuity), ("last_cross", b.LastCrossContinuity)):
            if cont and cont.get(key):
                c.ContinuityType = CT.G1
                c.ConstraintFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(cont[key]))], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


def face_blend(part, faces1, faces2, radius, rev1=False, rev2=False, trim=True, sew=True):
    """Two-face Face Blend (rolling ball, constant radius). The blend sits where the two face normals
    (after rev1/rev2) point towards each other. trim+sew -> ONE sheet body from two sheets."""
    FBB = NXOpen.Features.FaceBlendBuilder
    b = part.Features.CreateFaceBlendBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FaceBlendDefineType = FBB.DefiningType.BlendTwoFace
        b.BlendType = FBB.Type.RollingBall
        b.FirstFaceCollector = nxh.collector(part, faces=faces1)
        b.SecondFaceCollector = nxh.collector(part, faces=faces2)
        b.ReverseFirstFaceNormal = rev1
        b.ReverseSecondFaceNormal = rev2
        b.CrossSectionType = FBB.CrossSectionOption.Circular
        b.CircularCrossSection.Radius.RightHandSide = str(radius)
        b.TrimInputFacesToBlendFaces = trim
        b.SewAllFaces = sew
        return b.CommitFeature()
    finally:
        b.Destroy()


def face_blend_auto(part, faces1, faces2, radius, accept, **kw):
    """Try the four normal combinations until accept(feature) is true (the GUI's double-click on the arrows)."""
    last = None
    for rev1 in (False, True):
        for rev2 in (False, True):
            m = nxh.mark("fb", False)
            try:
                f = face_blend(part, faces1, faces2, radius, rev1, rev2, **kw)
                if accept(f):
                    return f, (rev1, rev2)
                last = "built, rejected by accept()"
            except Exception as e:  # noqa: BLE001
                last = str(e)
            nxh.undo_to(m)
    raise RuntimeError("face blend: no normal combination accepted; last: " + str(last))


def trim_and_extend_corner(part, target_edges=None, target_body=None, tool_body=None, rev_target=False, rev_tool=False):
    """Make Corner. Target = the FREE EDGES of the sheet that must grow (course rule) or a whole sheet.
    rev_target flips which half of the TOOL sheet survives (measured)."""
    TEB = NXOpen.Features.TrimAndExtendBuilder
    RF = part.ScRuleFactory
    b = part.Features.TrimFeatureCollection.CreateTrimAndExtendBuilder(NXOpen.Features.TrimAndExtend.Null)
    try:
        b.DistanceTolerance = 0.01
        b.Operation = TEB.OperationType.MakeCorner
        rule = RF.CreateRuleEdgeDumb(list(target_edges)) if target_edges else RF.CreateRuleFaceBody(target_body)
        b.TargetSelection.ReplaceRules([rule], False)
        b.ToolSelection.ReplaceRules([RF.CreateRuleFaceBody(tool_body)], False)
        b.ReverseTarget = rev_target
        b.ReverseTool = rev_tool
        return b.CommitFeature()
    finally:
        b.Destroy()


def law_extension(part, face, edges, hp, length, angle, miter=None):
    LEB = NXOpen.Features.LawExtensionBuilderEx
    b = part.Features.CreateLawExtensionBuilderEx(NF)
    try:
        b.Type = LEB.Types.Faces
        b.DistanceTolerance = 0.01
        b.BaseProfile.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.BaseProfile, edges=edges, help_point=hp)
        b.Faces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb([face])], False)
        b.LengthLaw.LawType = GU.LawBuilder.Type.Constant
        b.LengthLaw.Value.RightHandSide = str(length)
        b.AngleLaw.LawType = GU.LawBuilder.Type.Constant
        b.AngleLaw.Value.RightHandSide = str(angle)
        if miter is not None:
            b.MiterOption = miter
        return b.CommitFeature()
    finally:
        b.Destroy()


def thicken(part, body, first, second=0, reverse=False):
    b = part.Features.CreateThickenBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(body)], False)
        b.FirstOffset.RightHandSide = str(first)
        b.SecondOffset.RightHandSide = str(second)
        b.ReverseDirection = reverse
        b.BooleanOperation.Type = nxh.BOOL.Create
        return b.CommitFeature()
    finally:
        b.Destroy()


def swept(part, sections, guides, solid=False):
    b = part.Features.CreateSweptBuilder(NXOpen.Features.Swept.Null)
    try:
        b.G0Tolerance = 0.01
        b.G1Tolerance = 0.5
        for s in sections:
            b.SectionList.Append(s)
        b.AlignmentMethod.SetSections(list(sections))
        for g in guides:
            b.GuideList.Append(g)
        b.BodyPreference.BodyType = SOLID if solid else SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


def sweep_along_guide(part, sec_curves, sec_start, guide_curves, guide_start):
    b = part.Features.CreateSweepAlongGuideBuilder(NXOpen.Features.SweepAlongGuide.Null)
    try:
        b.Section.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.Section, curves=sec_curves, help_point=sec_start)
        b.Guide.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.Guide, curves=guide_curves, help_point=guide_start)
        b.FirstOffset.RightHandSide = "0"
        b.SecondOffset.RightHandSide = "0"
        b.FeatureOptions.BodyType = SOLID
        b.BooleanOperation.Type = nxh.BOOL.Create
        return b.CommitFeature()
    finally:
        b.Destroy()


def bounded_plane(part, curves=None, edges=None, hp=(0, 0, 0)):
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.BoundingCurves, curves=curves, edges=edges, help_point=hp)
        return b.CommitFeature()
    finally:
        b.Destroy()


def plane_sheet(part, x0, y0, w=40, h=30, z=0.0):
    return bounded_plane(part, curves=nxh.rect(part, x0, y0, x0 + w, y0 + h, z), hp=(x0, y0, z)).GetBodies()[0]


def fill_surface(part, edges, hp, g1=True, patch=False):
    """Fill Surface on a closed loop of edges. g1=False sets every edge to G0 through SetBorderTypeItems:
    DefaultEdgeContinuity alone leaves face-owned edges at G1 (measured)."""
    FHB = NXOpen.Features.FillHoleBuilder
    b = part.Features.FreeformSurfaceCollection.CreateFillHoleBuilder(NXOpen.Features.FillHole.Null)
    try:
        b.Tolerance = 0.01
        b.DefaultEdgeContinuity = FHB.ContinuityTypes.G1 if g1 else FHB.ContinuityTypes.G0
        b.CurveChain.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.CurveChain, edges=edges, help_point=hp)
        if not g1:
            items = []
            for e in edges:
                bc = FHB.BorderContinuity()
                bc.BorderObject = e
                bc.Continuity = FHB.ContinuityTypes.G0
                items.append(bc)
            b.SetBorderTypeItems(items)
        b.Patch = patch
        return b.CommitFeature()
    finally:
        b.Destroy()


def n_sided(part, curves=None, edges=None, hp=(0, 0, 0), trim=True):
    NSB = NXOpen.Features.NSidedSurfaceBuilder
    b = part.Features.CreateNSidedSurfaceBuilder(NXOpen.Features.NSidedSurface.Null)
    try:
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.CurvatureTolerance = 0.5
        b.Type = NSB.SurfaceType.TrimmedPatch
        b.OuterLoop.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.OuterLoop, curves=curves, edges=edges, help_point=hp)
        b.UVOrientation = NSB.UVOrientationType.Area
        b.TrimToBoundary = trim
        return b.CommitFeature()
    finally:
        b.Destroy()


def trim_sheet(part, body, region_xyz, keep, curves, hp, vec=None):
    TSB = NXOpen.Features.TrimSheetBuilder
    b = part.Features.CreateTrimsheetBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.TargetBodies.Add(body)
        b.Regions.Append(part.CreateRegionPoint(part.Points.CreatePoint(nxh.P(*region_xyz)), body))
        b.KeepDiscardMethod = TSB.KeepDiscardOption.Keep if keep else TSB.KeepDiscardOption.Discard
        b.ExtendBoundaryObject = True
        b.BoundaryObjects.Add(nxh.section(part, curves=curves, help_point=hp))
        if vec is not None:
            b.ProjectionDirection.ProjectDirectionMethod = GU.ProjectionOptions.DirectionType.Vector
            b.ProjectionDirection.ProjectVector = nxh.direction(part, vec)
        return b.Commit()
    finally:
        b.Destroy()


def sew(part, target, tools, tol=0.01):
    b = part.Features.CreateSewBuilder(NF)
    try:
        b.Tolerance = tol
        b.TargetBodies.Add(target)
        for t in tools:
            b.ToolBodies.Add(t)
        return b.Commit()
    finally:
        b.Destroy()


def unsew(part, faces):
    USB = NXOpen.Features.UnsewBuilder
    b = part.Features.CreateUnsewBuilder(NXOpen.Features.Unsew.Null)
    try:
        b.ToolOption = USB.UnsewTool.Face
        b.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


# ---------------------------------------------------------------- experiments
def t_alignment(part):
    """Course CAD5.4 00:23:43: rectangle -> triangle, Parameter creases, Arc Length better, By Points cures."""
    out = {}
    for i, key in enumerate(("parameter", "arclength", "points")):
        x0 = i * 100.0
        r = nxh.rect(part, x0, 0, x0 + 40, 30, 0.0)
        t = nxh.polyline(part, [(x0, 0, 30), (x0 + 40, 0, 30), (x0 + 20, 30, 30)])
        s1 = nxh.section(part, curves=r, help_point=(x0, 0, 0), seed=r[0])
        s2 = nxh.section(part, curves=t, help_point=(x0, 0, 30), seed=t[0])
        kw = {"parameter": {"align": AT.Parameter}, "arclength": {"align": AT.ArcLength},
              "points": {"points": [[(x0 + 40, 0, 0), (x0 + 40, 30, 0), (x0, 30, 0)],
                                    [(x0 + 40, 0, 30), (x0 + 20, 30, 30), (x0 + 10, 15, 30)]]}}[key]
        try:
            body = through_curves(part, [s1, s2], solid=True, preserve=(key != "arclength"), **kw).GetBodies()[0]
        except Exception as e:  # noqa: BLE001
            out[key] = {"error": str(e)}
            continue
        # where the base-right rectangle corner's ruling should be, and the upper-right corner -> apex ruling
        out[key] = {"volume": round(nxh.volume(part, body), 3), "faces": len(body.GetFaces()),
                    "types": nxh.face_census(body)["types"],
                    "corner_ruling_off": round(nxh.dist_to(part, body, (x0 + 40, 0, 15)), 4),
                    "apex_ruling_off": round(nxh.dist_to(part, body, (x0 + 30, 30, 15)), 4)}
    notes["alignment_rect_to_triangle"] = out
    if "error" not in out.get("points", {"error": 1}):
        chk("align by points: base corner ruling on surface", out["points"]["corner_ruling_off"], 0.0, 0.01)
        chk("align by points: corner-to-apex ruling on surface", out["points"]["apex_ruling_off"], 0.0, 0.01)
    else:
        chk.true("align by points built", False, out.get("points"))
    for key in ("parameter", "arclength"):
        if "error" not in out.get(key, {"error": 1}):
            chk.true(f"align {key}: corner ruling is OFF the surface (> 1 mm)", out[key]["corner_ruling_off"] > 1.0, out[key])


def t_g2(part):
    """G0 / G1 / G2 at a Through Curves end against a cylindrical neighbour (R20): normals and curvature."""
    out = {}
    for i, key in enumerate(("g0", "g1", "g2")):
        x0 = i * 100.0
        a = nxh.arc(part, (x0, 100, -20), (0, 1, 0), (0, 0, 1), 20, math.pi / 2, math.radians(150))
        base = nxh.extrude(part, nxh.section(part, curves=[a], help_point=(x0, 100, 0)), (1, 0, 0), 0, 40, sheet=True).GetBodies()[0]
        edge = [e for e in base.GetEdges() if abs(nxh.bbox(e)[1] - 100) < 1e-6 and abs(nxh.bbox(e)[4] - 100) < 1e-6][0]
        ln = nxh.line(part, (x0, 130, -6), (x0 + 40, 130, -6))
        s1 = nxh.section(part, edges=[edge], help_point=(x0, 100, 0))
        s2 = nxh.section(part, curves=[ln], help_point=(x0, 130, -6))
        first = {"g0": None, "g1": (CT.G1, base.GetFaces()), "g2": (CT.G2, base.GetFaces())}[key]
        body = through_curves(part, [s1, s2], first=first).GetBodies()[0]
        pts = [(x0 + 5, 100, 0), (x0 + 20, 100, 0), (x0 + 35, 100, 0)]
        out[key] = {"g1_dev_deg": round(g1_deviation(base.GetFaces()[0], body.GetFaces()[0], pts), 4),
                    "max_curvature_at_edge": round(max_curvature(body.GetFaces()[0], (x0 + 20, 100, 0)), 5),
                    "neighbour_curvature": round(max_curvature(base.GetFaces()[0], (x0 + 20, 100, 0)), 5),
                    "radii": [round(v, 3) for v in curvature_radii(body.GetFaces()[0], (x0 + 20, 100, 0))]}
    notes["through_curves_end_continuity"] = out
    chk.true("G0 end is a crease (deviation > 5 deg)", out["g0"]["g1_dev_deg"] > 5, out["g0"])
    chk("G1 end: normals agree", out["g1"]["g1_dev_deg"], 0.0, 0.05)
    chk("G2 end: normals agree", out["g2"]["g1_dev_deg"], 0.0, 0.05)
    chk("G2 end: curvature equals the neighbour's 1/20", out["g2"]["max_curvature_at_edge"], 0.05, 0.002)
    chk.true("G1 end: curvature does NOT match (so the curvature test discriminates)",
             abs(out["g1"]["max_curvature_at_edge"] - 0.05) > 0.005, out["g1"])


def t_mesh_g1(part):
    """Through Curve Mesh with G1 to the faces behind both primaries (course: tie every boundary you can)."""
    out = {}
    th = math.asin(20 / 42.5)
    t0 = math.atan2(52.25, 30)
    for i, g1 in enumerate((False, True)):
        x0 = i * 100.0
        la = nxh.line(part, (x0, 200, 0), (x0 + 60, 200, 0))
        sa = nxh.extrude(part, nxh.section(part, curves=[la], help_point=(x0, 200, 0)), (0, -1, 0), 0, 20, sheet=True).GetBodies()[0]
        ab = nxh.arc(part, (x0 + 30, 240, -42.25), (1, 0, 0), (0, 0, 1), 60.25, t0, math.pi - t0)
        sb = nxh.extrude(part, nxh.section(part, curves=[ab], help_point=(x0, 240, 10)), (0, 1, 0), 0, 20, sheet=True).GetBodies()[0]
        ea = [e for e in sa.GetEdges() if abs(nxh.bbox(e)[1] - 200) < 1e-6 and abs(nxh.bbox(e)[4] - 200) < 1e-6][0]
        eb = [e for e in sb.GetEdges() if abs(nxh.bbox(e)[1] - 240) < 1e-6 and abs(nxh.bbox(e)[4] - 240) < 1e-6][0]
        crosses = []
        for x in (x0, x0 + 60):        # S-shaped cross strings, tangent to both neighbours at their ends
            c = [nxh.arc(part, (x, 200, 42.5), (0, 1, 0), (0, 0, 1), 42.5, -math.pi / 2, -math.pi / 2 + th),
                 nxh.arc(part, (x, 240, -32.5), (0, 1, 0), (0, 0, 1), 42.5, math.pi / 2, math.pi / 2 + th)]
            crosses.append(nxh.section(part, curves=c, help_point=(x, 200, 0), seed=c[0]))
        prim = [nxh.section(part, edges=[ea], help_point=(x0, 200, 0)), nxh.section(part, edges=[eb], help_point=(x0, 240, 10))]
        cont = {"first_primary": sa.GetFaces(), "last_primary": sb.GetFaces()} if g1 else None
        body = curve_mesh(part, prim, crosses, cont).GetBodies()[0]
        f = body.GetFaces()[0]
        pa = [(x0 + 15, 200, 0), (x0 + 30, 200, 0), (x0 + 45, 200, 0)]
        pb = [(x, 240, -42.25 + math.sqrt(60.25 ** 2 - (x - x0 - 30) ** 2)) for x in (x0 + 15, x0 + 30, x0 + 45)]
        out["g1" if g1 else "g0"] = {"dev_first_primary": round(g1_deviation(sa.GetFaces()[0], f, pa), 4),
                                     "dev_last_primary": round(g1_deviation(sb.GetFaces()[0], f, pb), 4),
                                     "area": round(nxh.sheet_area(part, body)[0], 3)}
    notes["mesh_boundary_continuity"] = out
    chk("mesh G1: first primary tangent to its neighbour", out["g1"]["dev_first_primary"], 0.0, 0.1)
    chk("mesh G1: last primary tangent to its neighbour", out["g1"]["dev_last_primary"], 0.0, 0.1)
    chk.true("mesh G0: not tangent (deviation > 1 deg), so the constraint matters",
             max(out["g0"]["dev_first_primary"], out["g0"]["dev_last_primary"]) > 1.0, out["g0"])


def t_ruled_chain_vs_loft(part):
    """Course CAD5.4 00:27:20: Ruled patches crease at every shared section; one Through Curves does not."""
    spec = ((0, 20), (20, 12), (40, 20))
    arcs = [nxh.arc(part, (0, 300, z), (1, 0, 0), (0, 1, 0), r, 0.0, math.pi) for z, r in spec]
    hp = [(20, 300, 0), (12, 300, 20), (20, 300, 40)]
    r1 = ruled(part, [arcs[0]], hp[0], [arcs[1]], hp[1]).GetBodies()[0]
    r2 = ruled(part, [arcs[1]], hp[1], [arcs[2]], hp[2]).GetBodies()[0]
    pts = [(12 * math.cos(a), 300 + 12 * math.sin(a), 20) for a in (0.5, 1.5, 2.5)]
    dev = g1_deviation(r1.GetFaces()[0], r2.GetFaces()[0], pts)
    chk("ruled chain crease angle at the shared arc", dev, 2 * math.degrees(math.atan(8 / 20)), 0.1)
    arcs2 = [nxh.arc(part, (100, 300, z), (1, 0, 0), (0, 1, 0), r, 0.0, math.pi) for z, r in spec]
    secs = [nxh.section(part, curves=[a], help_point=(100 + r, 300, z)) for a, (z, r) in zip(arcs2, spec)]
    one = through_curves(part, secs).GetBodies()[0]
    chk("one Through Curves over 3 sections: single face", len(one.GetFaces()), 1, 0)
    sew(part, r1, [r2])
    eg = nxh.examine_geometry(part, r1)
    notes["examine_ruled_chain_sewn"] = eg
    notes["examine_single_loft"] = nxh.examine_geometry(part, one)
    chk("examine geometry does NOT flag the 43.6 deg crease (EdgeSmoothness + FaceSmoothness)",
        eg.get("EdgeSmoothness", 0) + eg.get("FaceSmoothness", 0), 0, 0)


def t_face_blend(part):
    """Course CAD5.6: Two-face blend between crossing sheets (trim + sew -> one sheet) and between disjoint bodies."""
    # crossing sheets: plane z=0 (x 0..40) and plane x=20 (z -10..10), R3
    a = plane_sheet(part, 0, 400)
    ln = nxh.line(part, (20, 400, -10), (20, 430, -10))
    v = nxh.extrude(part, nxh.section(part, curves=[ln], help_point=(20, 400, -10)), (0, 0, 1), 0, 20, sheet=True).GetBodies()[0]
    n0 = counts(part)
    want = 17 * 30 + 7 * 30 + math.pi / 2 * 3 * 30
    f, rev = face_blend_auto(part, a.GetFaces(), v.GetFaces(), 3,
                             lambda ft: len(nxh.sheets(part)) == n0[0] - 1 and abs(nxh.sheet_area(part, ft.GetBodies()[0])[0] - want) < 0.5)
    body = f.GetBodies()[0]
    bb = nxh.bbox(body)
    notes["face_blend_crossing"] = {"reverse_flags": rev, "bbox": bb, "census": nxh.face_census(body),
                                    "type": [f.FeatureType, type(f).__name__, f.GetFeatureName()]}
    chk("face blend trim+sew: area", nxh.sheet_area(part, body)[0], want, 0.05)
    chk("face blend trim+sew: one sheet body left of two", n0[0] - counts(part)[0], 1, 0)
    chk("face blend trim+sew: 3 faces", len(body.GetFaces()), 3, 0)
    plane_f = [x for x in body.GetFaces() if nxh.face_data(x)[0] == nxh.PLANE]
    cyl_f = [x for x in body.GetFaces() if nxh.face_data(x)[0] != nxh.PLANE][0]
    chk("face blend radius", abs(nxh.face_data(cyl_f)[3]), 3.0, 1e-4)
    # contact lines of the R3 ball in the kept quadrant (read from the result's bbox)
    sx = 1.0 if bb[3] > 20.5 else -1.0
    sz = 1.0 if bb[5] > 0.5 else -1.0
    for pf in plane_f:
        horiz = abs(nxh.face_data(pf)[2][2]) > 0.9
        p = (20 + 3 * sx, 415, 0) if horiz else (20, 415, 3 * sz)
        chk("face blend tangent to the %s sheet (deg)" % ("horizontal" if horiz else "upright"), g1_deviation(cyl_f, pf, [p]), 0.0, 0.01)
    # no trim: originals stay, blend is a third sheet
    a2 = plane_sheet(part, 100, 400)
    ln = nxh.line(part, (120, 400, -10), (120, 430, -10))
    v2 = nxh.extrude(part, nxh.section(part, curves=[ln], help_point=(120, 400, -10)), (0, 0, 1), 0, 20, sheet=True).GetBodies()[0]
    n0 = counts(part)
    face_blend(part, a2.GetFaces(), v2.GetFaces(), 3, rev[0], rev[1], trim=False, sew=False)
    chk("face blend no trim: one extra sheet", counts(part)[0] - n0[0], 1, 0)
    chk("face blend no trim: original sheet untouched", nxh.sheet_area(part, a2)[0], 1200.0, 0.01)
    # two disjoint sheets (gap between them): plane z=0 x 200..217, plane x=220 z 3..20, R5
    a3 = plane_sheet(part, 200, 400, 17, 30)
    ln = nxh.line(part, (220, 400, 3), (220, 430, 3))
    v3 = nxh.extrude(part, nxh.section(part, curves=[ln], help_point=(220, 400, 3)), (0, 0, 1), 0, 17, sheet=True).GetBodies()[0]
    notes["disjoint_gap_before"] = round(nxh.min_dist(a3, v3), 4)
    n0 = counts(part)
    want = 15 * 30 + 15 * 30 + math.pi / 2 * 5 * 30
    f, rev = face_blend_auto(part, a3.GetFaces(), v3.GetFaces(), 5,
                             lambda ft: abs(nxh.sheet_area(part, ft.GetBodies()[0])[0] - want) < 0.5)
    chk("face blend disjoint bodies: area", nxh.sheet_area(part, f.GetBodies()[0])[0], want, 0.05)
    chk("face blend disjoint bodies: two sheets became one", n0[0] - counts(part)[0], 1, 0)
    notes["face_blend_disjoint_reverse_flags"] = rev


def t_make_corner(part):
    """Course CAD5.6 00:20:35: Make Corner target must be the free EDGES of the sheet to extend."""
    out = {}
    for i, key in enumerate(("edges", "edges_rev_tool", "edges_rev_target", "faces")):
        x0 = i * 100.0
        base = plane_sheet(part, x0, 500)                                           # z=0, x0..x0+40
        ln = nxh.line(part, (x0 + 20, 500, 5), (x0 + 20, 530, 5))                    # upright stops 5 mm above the base
        up = nxh.extrude(part, nxh.section(part, curves=[ln], help_point=(x0 + 20, 500, 5)), (0, 0, 1), 0, 20, sheet=True).GetBodies()[0]
        low = [e for e in up.GetEdges() if abs(nxh.bbox(e)[2] - 5) < 1e-6 and abs(nxh.bbox(e)[5] - 5) < 1e-6]
        n0 = counts(part)
        m = nxh.mark("mc", False)
        try:
            if key == "faces":
                f = trim_and_extend_corner(part, target_body=up, tool_body=base)
            else:
                f = trim_and_extend_corner(part, target_edges=low, tool_body=base,
                                           rev_tool=(key == "edges_rev_tool"), rev_target=(key == "edges_rev_target"))
            bodies = f.GetBodies()
            out[key] = {"bodies": [{"area": round(nxh.sheet_area(part, b)[0], 3), "faces": len(b.GetFaces()), "bbox": nxh.bbox(b)} for b in bodies],
                        "sheets_before_after": [n0[0], counts(part)[0]],
                        "kept_base_x_relative": [round(nxh.bbox(bodies[0])[0] - x0, 3), round(nxh.bbox(bodies[0])[3] - x0, 3)]}
        except Exception as e:  # noqa: BLE001
            out[key] = {"error": str(e)}
            nxh.undo_to(m)
    notes["make_corner_gap_configuration"] = out
    chk.true("make corner with the sheet's FACES as target fails as the course says",
             out["faces"].get("error") == "Unable to perform Boolean.", out["faces"])
    ok = "error" not in out["edges"]
    chk.true("make corner with free edges as target builds", ok, out["edges"])
    if ok:
        chk("make corner (edges): one body", len(out["edges"]["bodies"]), 1, 0)
        chk("make corner (edges): upright reaches the base (z min 0)", out["edges"]["bodies"][0]["bbox"][2], 0.0, 1e-6)
        chk("make corner (edges): area = 25x30 upright + 20x30 base", out["edges"]["bodies"][0]["area"], 1350.0, 0.05)
    if ok and "error" not in out["edges_rev_target"]:
        chk.true("make corner: ReverseTarget keeps the OTHER half of the tool sheet",
                 out["edges"]["kept_base_x_relative"] == [20.0, 40.0] and out["edges_rev_target"]["kept_base_x_relative"] == [0.0, 20.0],
                 [out["edges"]["kept_base_x_relative"], out["edges_rev_target"]["kept_base_x_relative"]])


def t_law_extension(part):
    out = {}
    for i, ang in enumerate((60, 110)):
        x0 = i * 100.0
        sh = plane_sheet(part, x0, 600)
        e = nxh.edges(sh, lambda b, x0=x0: abs(b[0] - (x0 + 40)) < 1e-6 and abs(b[3] - (x0 + 40)) < 1e-6)
        fl = law_extension(part, sh.GetFaces()[0], e, (x0 + 40, 600, 0), 10, ang).GetBodies()[0]
        bb = nxh.bbox(fl)
        out[ang] = bb
        chk(f"law extension {ang} deg: height", max(abs(bb[2]), abs(bb[5])), 10 * math.sin(math.radians(ang)), 1e-3)
        reach = (bb[3] if ang < 90 else bb[0]) - (x0 + 40)
        chk(f"law extension {ang} deg: horizontal reach", reach, 10 * math.cos(math.radians(ang)), 1e-3)
    # tray: all four edges in one feature, sharp miter
    sh = plane_sheet(part, 200, 600)
    n0 = counts(part)
    m = nxh.mark("tray", False)
    try:
        LEB = NXOpen.Features.LawExtensionBuilderEx
        f = law_extension(part, sh.GetFaces()[0], list(sh.GetEdges()), (200, 600, 0), 10, 90, LEB.MiterOptions.Sharp)
        out["tray_4_edges_sharp"] = {"bodies": [{"area": round(nxh.sheet_area(part, b)[0], 3), "faces": len(b.GetFaces()),
                                                 "free": len(nxh.free_edges(b)), "bbox": nxh.bbox(b)} for b in f.GetBodies()],
                                     "sheets_before_after": [n0[0], counts(part)[0]]}
    except Exception as e:  # noqa: BLE001
        out["tray_4_edges_sharp"] = {"error": str(e)}
        nxh.undo_to(m)
    notes["law_extension"] = out
    tray = out["tray_4_edges_sharp"]
    chk.true("law extension on 4 edges with Sharp miter: one 4-face wall body, area 140 x 10",
             "error" not in tray and len(tray["bodies"]) == 1 and tray["bodies"][0]["faces"] == 4
             and abs(tray["bodies"][0]["area"] - 1400.0) < 0.05, tray)


def t_thicken_offsets(part):
    """Course CAD5.5 00:48:16: the solid lies BETWEEN offset 1 and offset 2 along the face normal."""
    for i, (o1, o2, vol, lo, hi) in enumerate(((2, 3, 1200.0, 2, 3), (0, 3, 3600.0, 0, 3), (-2, 3, 6000.0, -2, 3))):
        sh = plane_sheet(part, i * 100.0, 700)
        s = nxh.normal_at(sh.GetFaces()[0], (i * 100.0 + 20, 715, 0))[2]        # +1 or -1: which way "positive" goes
        body = thicken(part, sh, o1, o2).GetBodies()[0]
        bb = nxh.bbox(body)
        zs = sorted((bb[2] * s, bb[5] * s))
        chk(f"thicken ({o1},{o2}): volume", nxh.volume(part, body), vol, 0.01)
        chk(f"thicken ({o1},{o2}): starts at offset", zs[0], lo, 1e-6)
        chk(f"thicken ({o1},{o2}): ends at offset", zs[1], hi, 1e-6)


def t_swept_rules(part):
    """Course CAD5.5: a section not normal to the guide is carried upright; Swept fails on a sharp L,
    Sweep Along Guide gives the mitred elbow."""
    # skewed section: circle R4 in the YZ plane, guide a line at 45 deg in XY
    c = nxh.circle(part, (0, 800, 0), 4, xdir=(0, 1, 0), ydir=(0, 0, 1))
    g = nxh.line(part, (0, 800, 0), (50, 850, 0))
    body = swept(part, [nxh.section(part, curves=c, help_point=(0, 804, 0), seed=c[0])],
                 [nxh.section(part, curves=[g], help_point=(0, 800, 0))], solid=True).GetBodies()[0]
    v = nxh.volume(part, body)
    notes["swept_skewed_section_volume"] = [round(v, 3), "sheared = %.3f" % (math.pi * 16 * 50), "true tube = %.3f" % (math.pi * 16 * 50 * math.sqrt(2))]
    chk("swept, section not normal to guide: sheared (upright) volume", v, math.pi * 16 * 50, 2.0)
    # sharp L guide
    out = {}
    for i, key in enumerate(("swept", "sweep_along_guide")):
        x0 = 100.0 + i * 100.0
        rc = nxh.polyline(part, [(x0 - 3, 800, -2), (x0 + 3, 800, -2), (x0 + 3, 800, 2), (x0 - 3, 800, 2)])
        gl = [nxh.line(part, (x0, 800, 0), (x0, 900, 0)), nxh.line(part, (x0, 900, 0), (x0, 900, 100))]
        m = nxh.mark("L", False)
        try:
            if key == "swept":
                b = swept(part, [nxh.section(part, curves=rc, help_point=(x0 - 3, 800, -2), seed=rc[0])],
                          [nxh.section(part, curves=gl, help_point=(x0, 800, 0), seed=gl[0])], solid=True).GetBodies()[0]
            else:
                b = sweep_along_guide(part, rc, (x0 - 3, 800, -2), gl, (x0, 800, 0)).GetBodies()[0]
            out[key] = {"volume": round(nxh.volume(part, b), 3), "faces": len(b.GetFaces()), "bbox": nxh.bbox(b)}
        except Exception as e:  # noqa: BLE001
            out[key] = {"error": str(e)}
            nxh.undo_to(m)
    notes["sharp_L_guide"] = out
    chk.true("swept refuses a sharp-cornered guide", "error" in out["swept"], out["swept"])
    chk.true("sweep along guide builds on a sharp L", "error" not in out["sweep_along_guide"], out["sweep_along_guide"])
    if "error" not in out["sweep_along_guide"]:
        chk("sweep along guide on a sharp L: mitred elbow volume = area x path length",
            out["sweep_along_guide"]["volume"], 24 * 200.0, 0.5)


def t_fill_vs_nsided(part):
    """Course CAD5.5 00:35:39-00:40:24: on a hole in a skin N-Sided is flat, Fill Surface is G1 to the neighbours,
    and Fill with every edge at G0 is as creased as N-Sided. Tested on a cylinder skin and on a B-surface skin."""
    spec = ((0, 20), (20, 12), (40, 20))

    def cyl_skin(x0, y0):
        a = nxh.arc(part, (x0, y0, 0), (0, 1, 0), (0, 0, 1), 20, 0.0, math.pi)
        skin = nxh.extrude(part, nxh.section(part, curves=[a], help_point=(x0, y0 + 20, 0)), (1, 0, 0), 0, 60, sheet=True).GetBodies()[0]
        c = nxh.circle(part, (x0 + 30, y0, 30), 8)
        trim_sheet(part, skin, (x0 + 30, y0, 20), False, c, (x0 + 38, y0, 30), vec=(0, 0, -1))
        hole = [e for e in skin.GetEdges() if nxh.bbox(e)[0] > x0 + 21 and nxh.bbox(e)[3] < x0 + 39]
        return skin, hole, (x0 + 30, y0, 20)

    def loft_skin(x0, y0):
        arcs = [nxh.arc(part, (x0, y0, z), (1, 0, 0), (0, 1, 0), r, 0.0, math.pi) for z, r in spec]
        secs = [nxh.section(part, curves=[a], help_point=(x0 + r, y0, z)) for a, (z, r) in zip(arcs, spec)]
        skin = through_curves(part, secs).GetBodies()[0]
        c = nxh.circle(part, (x0, y0 + 40, 20), 6, xdir=(1, 0, 0), ydir=(0, 0, 1))
        trim_sheet(part, skin, (x0, y0 + 12, 20), False, c, (x0 + 6, y0 + 40, 20), vec=(0, -1, 0))
        hole = [e for e in skin.GetEdges() if nxh.bbox(e)[0] > x0 - 6.5 and nxh.bbox(e)[3] < x0 + 6.5
                and nxh.bbox(e)[2] > 13.5 and nxh.bbox(e)[5] < 26.5]
        return skin, hole, (x0, y0 + 12, 20)

    out = {}
    for j, (sname, mk) in enumerate((("cylinder", cyl_skin), ("bsurface", loft_skin))):
        for i, key in enumerate(("fill_g1", "fill_g0", "n_sided")):
            skin, hole, apex = mk(i * 100.0, 1000.0 + j * 100.0)
            pts = []
            for e in hole:
                for v in e.GetVertices():
                    pts.append((v.X, v.Y, v.Z))
            m = nxh.mark("fv", False)
            try:
                if key == "n_sided":
                    patch = n_sided(part, edges=hole, hp=pts[0]).GetBodies()[0]
                else:
                    patch = fill_surface(part, hole, pts[0], g1=(key == "fill_g1")).GetBodies()[0]
                out[sname + "_" + key] = {"hole_edges": len(hole), "apex_gap": round(nxh.dist_to(part, patch, apex), 4),
                                          "g1_dev_deg": round(g1_deviation(skin.GetFaces()[0], patch.GetFaces()[0], pts), 3),
                                          "area": round(nxh.sheet_area(part, patch)[0], 3),
                                          "types": nxh.face_census(patch)["types"]}
            except Exception as e:  # noqa: BLE001
                out[sname + "_" + key] = {"error": str(e)}
                nxh.undo_to(m)
    notes["hole_in_skin"] = out          # the fill_g0 rows are the course claim "all-G0 fill = N-Sided"; not gated
    for sname in ("cylinder", "bsurface"):
        g1r, nsr = out[sname + "_fill_g1"], out[sname + "_n_sided"]
        chk.true(f"fill G1 on a {sname} skin: tangent to the skin at the hole (< 0.6 deg)",
                 "error" not in g1r and g1r["g1_dev_deg"] < 0.6, g1r)
        chk.true(f"n-sided on a {sname} skin: creased (> 2 deg) and off the original surface",
                 "error" not in nsr and nsr["g1_dev_deg"] > 2.0 and nsr["apex_gap"] > 0.05, nsr)
    # N-Sided on an OPEN loop (course: "the curve set does not have to be closed")
    m = nxh.mark("open", False)
    try:
        op = nxh.polyline(part, [(300, 1000, 0), (340, 1000, 0), (340, 1030, 6), (300, 1030, 0)], closed=False)
        b = n_sided(part, curves=op, hp=(300, 1000, 0), trim=False).GetBodies()[0]
        notes["n_sided_open_loop"] = {"area": round(nxh.sheet_area(part, b)[0], 3), "bbox": nxh.bbox(b)}
        chk.true("n-sided accepts an open 3-curve loop (untrimmed patch)", True, notes["n_sided_open_loop"])
    except Exception as e:  # noqa: BLE001
        notes["n_sided_open_loop"] = {"error": str(e)}
        nxh.undo_to(m)
        chk.true("n-sided accepts an open 3-curve loop (untrimmed patch)", False, str(e))


def t_close_open_shell(part):
    """Course CAD5.5 00:41:09 + CAD4.1 import repair: open body -> Examine Geometry -> close -> solid."""
    _f, blk = nxh.block(part, (0, 1300, 0), (60, 40, 20))
    top = nxh.faces(blk, ftype=nxh.PLANE, normal=(0, 0, 1))[0]
    parts = unsew(part, [top]).GetBodies()
    shell = [b for b in parts if len(b.GetFaces()) == 5][0]
    eg0 = nxh.examine_geometry(part, shell)
    notes["examine_open_shell"] = eg0
    chk("examine geometry on the open shell: BodySheetBoundaries = its 4 free edges", eg0.get("BodySheetBoundaries", 0), 4, 0)
    route = "fill surface (all edges G0) + Patch into Part"
    m = nxh.mark("pip", False)
    try:
        fill_surface(part, nxh.free_edges(shell), (0, 1300, 20), g1=False, patch=True)
    except Exception as e:  # noqa: BLE001
        notes["fill_patch_into_part_on_sharp_box_error"] = str(e)
        nxh.undo_to(m)
        route = "bounded plane + sew"
        lid = bounded_plane(part, edges=nxh.free_edges(shell), hp=(0, 1300, 20)).GetBodies()[0]
        sew(part, shell, [lid])
    notes["open_shell_closed_by"] = route
    chk("open shell closed to a solid", int(shell.IsSolidBody), 1, 0)
    if shell.IsSolidBody:
        chk("closed shell volume", nxh.volume(part, shell), 48000.0, 0.05)
    eg1 = nxh.examine_geometry(part, shell)
    notes["examine_closed"] = eg1
    chk("examine geometry after closing: no sheet boundaries", eg1.get("BodySheetBoundaries", -1), 0, 0)


def t_four_point(part):
    """Four Point Surface: look for an NXOpen builder; the same cap is a Fill Surface over 4 lines."""
    hits = [n for n in dir(part.Features) if "FourPoint" in n]
    for sub in dir(part.Features):
        try:
            hits += [sub + "." + n for n in dir(getattr(part.Features, sub)) if "FourPoint" in n]
        except Exception:  # noqa: BLE001
            pass
    hits += ["NXOpen.Features." + n for n in dir(NXOpen.Features) if "FourPoint" in n]
    hits += ["NXOpen.GeometricUtilities." + n for n in dir(GU) if "FourPoint" in n]
    notes["four_point_surface_api"] = hits or "no FourPoint* builder in NXOpen.Features / GeometricUtilities on NX 2206"
    pts = [(0, 1400, 0), (40, 1400, 0), (40, 1430, 8), (0, 1430, 0)]            # non-planar quad
    lines = nxh.polyline(part, pts)
    b = part.Features.FreeformSurfaceCollection.CreateFillHoleBuilder(NXOpen.Features.FillHole.Null)
    try:
        b.Tolerance = 0.01
        b.CurveChain.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.CurveChain, curves=lines, help_point=pts[0])
        body = b.CommitFeature().GetBodies()[0]
    finally:
        b.Destroy()
    chk("4-corner cap by Fill Surface: all four corners on the surface",
        max(nxh.dist_to(part, body, p) for p in pts), 0.0, 0.01)
    chk("4-corner cap by Fill Surface: 4 boundary edges", len(nxh.free_edges(body)), 4, 0)


def main():
    part = nxh.new_part(os.path.join(OUT, "surf_course_checks.prt"))
    for name, fn in (("alignment", t_alignment), ("g2", t_g2), ("mesh_g1", t_mesh_g1), ("ruled_chain", t_ruled_chain_vs_loft),
                     ("face_blend", t_face_blend), ("make_corner", t_make_corner), ("law_extension", t_law_extension),
                     ("thicken_offsets", t_thicken_offsets), ("swept_rules", t_swept_rules), ("fill_vs_nsided", t_fill_vs_nsided),
                     ("close_open_shell", t_close_open_shell), ("four_point", t_four_point)):
        trial(name, fn, part)
    nxh.update()
    # informational only: after a rolled-back failed commit the NEXT feature keeps a stale alert (see nxh.feature_errors)
    notes["feature_errors_incl_stale"] = nxh.feature_errors(part)
    nxh.save(part)


res = {}
try:
    main()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res.update(chk.report())
if "error" in res:
    res["result"] = "FAIL"
res["notes"] = notes
nxh.write_json(os.path.join(OUT, "surf_course_checks.json"), res)
