"""N-Sided Surface with constraint faces on NX 2206: is the patch still creased next to its neighbours?

    run_journal.ps1 -Script surf_nsided.py -WorkDir <out> -JArgs <out>   ->  <out>\\surf_nsided.json

N1  A round hole in a cylindrical skin (R8 in R20) and in a lofted B-surface skin (R6): the same hole closed with
    - N-Sided, Trimmed, no constraint faces (the old recipe of this skill),
    - N-Sided, Trimmed, ConstraintFaces = the skin face, Continuity G1,
    - N-Sided, Triangular, without faces / with faces at G1 / at G2,
    - Fill Surface (reference).
    Measured on each: G1 deviation at 16 points of the hole edge (nxh.g1_deviation), gap between the patch and the
    original surface at the hole centre, curvature on both sides of the edge, faces of the patch, and whether
    patch + skin sew into one sheet.
N2  Repair-patch use (CAST): a closed loop of CURVES lying on a face (not edges), the face as constraint.
N3  Triangular patch: centre control (CenterControlZ) on a planar pentagon.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
GU = NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
NSB = NXOpen.Features.NSidedSurfaceBuilder
TCB = NXOpen.Features.ThroughCurvesBuilder
CT = GU.Continuity.ContinuityTypes
ONLY_CURVES = NXOpen.Section.AllowTypes.OnlyCurves
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
notes = res["notes"]


def save_json():
    out = dict(res)
    out.update(chk.report())
    nxh.write_json(os.path.join(OUT, "surf_nsided.json"), out)


def edge_points(edge, n=8):
    props = nxh.UFS.ModlGeneral.AskCurveProps
    return [tuple(props(edge.Tag, (i + 0.5) / n)[0]) for i in range(n)]


# ---------------------------------------------------------------- the recipe
def n_sided(part, curves=None, edges=None, hp=(0, 0, 0), faces=None, continuity=None, triangular=False, trim=True,
            merge=None, flow=None, uv=None, uv_vector=None, center_z=None, via_continuity_object=False, tangent_tol=0.5):
    """N-Sided Surface. faces + continuity = the neighbours the patch has to be G1 / G2 to.

    faces       the faces that own the loop edges (or the face the loop curves lie on)
    continuity  CT.G0 | CT.G1 | CT.G2 (G2 on the Triangular type)
    triangular  SurfaceType.TriangularPatch: one face per loop side, meeting in the centre
    """
    b = part.Features.CreateNSidedSurfaceBuilder(NXOpen.Features.NSidedSurface.Null)
    try:
        b.PositionTolerance = 0.01            # all three default to 0.0 in batch: "Unable to build surface."
        b.TangentTolerance = tangent_tol
        b.CurvatureTolerance = 0.5
        b.Type = NSB.SurfaceType.TriangularPatch if triangular else NSB.SurfaceType.TrimmedPatch
        b.OuterLoop.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.OuterLoop, curves=curves, edges=edges, help_point=hp)
        if uv is not None:
            b.UVOrientation = uv
            if uv_vector is not None:
                b.OrientationVector = nxh.direction(part, uv_vector)
        else:
            b.UVOrientation = NSB.UVOrientationType.Area
        if faces:
            rule = part.ScRuleFactory.CreateRuleFaceDumb(list(faces))
            if via_continuity_object:
                b.Continuity.ConstraintFaces.ReplaceRules([rule], False)
            else:
                b.ConstraintFaces.ReplaceRules([rule], False)
        if continuity is not None:
            b.Continuity.ContinuityType = continuity
        if flow is not None:
            b.FlowDirection = flow
        if merge is not None:
            b.MergeFaces = merge
        if center_z is not None:
            b.CenterControlZ.RightHandSide = str(center_z)
        if not triangular:
            b.TrimToBoundary = trim
        return b.CommitFeature()
    finally:
        b.Destroy()


def fill_surface(part, edges, hp):
    FHB = NXOpen.Features.FillHoleBuilder
    b = part.Features.FreeformSurfaceCollection.CreateFillHoleBuilder(NXOpen.Features.FillHole.Null)
    try:
        b.Tolerance = 0.01
        b.DefaultEdgeContinuity = FHB.ContinuityTypes.G1
        b.CurveChain.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.CurveChain, edges=edges, help_point=hp)
        b.Patch = False
        return b.CommitFeature()
    finally:
        b.Destroy()


def through_curves(part, sections):
    b = part.Features.CreateThroughCurvesBuilder(NF)
    try:
        b.PreserveShape = False
        b.PatchType = TCB.PatchTypes.Multiple
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.BodyPreference = TCB.BodyPreferenceTypes.Sheet
        for s in sections:
            b.SectionsList.Append(s)
        b.Alignment.SetSections(list(sections))
        return b.CommitFeature()
    finally:
        b.Destroy()


def trim_sheet(part, body, region_xyz, keep, curves, hp, vec):
    TSB = NXOpen.Features.TrimSheetBuilder
    b = part.Features.CreateTrimsheetBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.TargetBodies.Add(body)
        b.Regions.Append(part.CreateRegionPoint(part.Points.CreatePoint(nxh.P(*region_xyz)), body))
        b.KeepDiscardMethod = TSB.KeepDiscardOption.Keep if keep else TSB.KeepDiscardOption.Discard
        b.ExtendBoundaryObject = True
        b.BoundaryObjects.Add(nxh.section(part, curves=curves, help_point=hp))
        b.ProjectionDirection.ProjectDirectionMethod = GU.ProjectionOptions.DirectionType.Vector
        b.ProjectionDirection.ProjectVector = nxh.direction(part, vec)
        return b.Commit()
    finally:
        b.Destroy()


def sew(part, target, tools, tol=0.01):
    b = part.Features.CreateSewBuilder(NF)
    try:
        b.Type = NXOpen.Features.SewBuilder.Types.Sheet
        b.Tolerance = tol
        b.TargetBodies.Add(target)
        for t in tools:
            b.ToolBodies.Add(t)
        return b.CommitFeature()
    finally:
        b.Destroy()


# ---------------------------------------------------------------- the two skins with a hole
def cyl_skin(part, x0, y0):
    """Half cylinder R20, axis along X, 60 long, hole R8 cut from above. The original surface at the hole centre
    is (x0 + 30, y0, 20); its curvature is 1/20."""
    a = nxh.arc(part, (x0, y0, 0), (0, 1, 0), (0, 0, 1), 20, 0.0, math.pi)
    skin = nxh.extrude(part, nxh.section(part, curves=[a], help_point=(x0, y0 + 20, 0)), (1, 0, 0), 0, 60, sheet=True).GetBodies()[0]
    c = nxh.circle(part, (x0 + 30, y0, 30), 8)
    trim_sheet(part, skin, (x0 + 30, y0, 20), False, c, (x0 + 38, y0, 30), (0, 0, -1))
    hole = [e for e in skin.GetEdges() if nxh.bbox(e)[0] > x0 + 21 and nxh.bbox(e)[3] < x0 + 39]
    return skin, hole, (x0 + 30, y0, 20)


def loft_skin(part, x0, y0):
    """Loft through three half circles R20 / R12 / R20 (waisted B-surface), hole R6 cut from the side."""
    spec = ((0, 20), (20, 12), (40, 20))
    arcs = [nxh.arc(part, (x0, y0, z), (1, 0, 0), (0, 1, 0), r, 0.0, math.pi) for z, r in spec]
    secs = [nxh.section(part, curves=[a], help_point=(x0 + r, y0, z), seed=a) for a, (z, r) in zip(arcs, spec)]
    skin = through_curves(part, secs).GetBodies()[0]
    c = nxh.circle(part, (x0, y0 + 40, 20), 6, xdir=(1, 0, 0), ydir=(0, 0, 1))
    trim_sheet(part, skin, (x0, y0 + 12, 20), False, c, (x0 + 6, y0 + 40, 20), (0, -1, 0))
    hole = [e for e in skin.GetEdges() if nxh.bbox(e)[0] > x0 - 6.5 and nxh.bbox(e)[3] < x0 + 6.5
            and nxh.bbox(e)[2] > 13.5 and nxh.bbox(e)[5] < 26.5]
    return skin, hole, (x0, y0 + 12, 20)


def patch_report(part, skin, patch_bodies, pts, apex, skin_face=None):
    """pts = points on the loop (hole edge). The patch meets the loop only within PositionTolerance, so each point
    is measured on the patch face NEAREST to it; the largest of those distances is reported as the boundary gap."""
    skin_face = skin_face or skin.GetFaces()[0]
    pfaces = [f for b in patch_bodies for f in b.GetFaces()]
    devs, kd, gaps = [], [], []
    for p in pts:
        d, near = min(((abs(nxh.dist_to(part, f, p)), f) for f in pfaces), key=lambda t: t[0])
        gaps.append(d)
        devs.append(nxh.g1_deviation(skin_face, near, [p]))
        kd.append((nxh.max_curvature(skin_face, p), nxh.max_curvature(near, p)))
    rep = {"patch_bodies": len(patch_bodies), "patch_faces": len(pfaces),
           "area": round(sum(nxh.sheet_area(part, b)[0] for b in patch_bodies), 3),
           "points_measured": len(devs), "boundary_gap_max_mm": round(max(gaps), 5),
           "g1_dev_max_deg": round(max(devs), 3), "g1_dev_mean_deg": round(sum(devs) / len(devs), 3),
           "gap_at_centre_mm": round(min(abs(nxh.dist_to(part, f, apex)) for f in pfaces), 4),
           "curvature_skin_vs_patch_max_rel_diff": round(max(abs(a - b) / max(a, 1e-9) for a, b in kd), 3),
           "curvature_sample": [round(v, 5) for v in kd[0]],
           "types": {}}
    for f in pfaces:
        t = nxh.face_data(f)[0]
        rep["types"][t] = rep["types"].get(t, 0) + 1
    return rep


VARIANTS = (
    ("trimmed_no_faces", dict()),
    ("trimmed_faces_G1", dict(faces=True, continuity=CT.G1)),
    ("trimmed_faces_G1_via_continuity_object", dict(faces=True, continuity=CT.G1, via_continuity_object=True)),
    ("trimmed_faces_G0", dict(faces=True, continuity=CT.G0)),
    ("trimmed_faces_G2", dict(faces=True, continuity=CT.G2)),
    ("trimmed_faces_G1_tangent_tol_0.1", dict(faces=True, continuity=CT.G1, tangent_tol=0.1)),
    ("triangular_faces_G1", dict(faces=True, continuity=CT.G1, triangular=True)),
    ("triangular_faces_G1_merge", dict(faces=True, continuity=CT.G1, triangular=True, merge=True)),
    ("triangular_faces_G2_merge", dict(faces=True, continuity=CT.G2, triangular=True, merge=True)),
    ("fill_surface_G1", None),
)


def ok(r):
    return "error" not in r


def run():
    part = nxh.new_part(os.path.join(OUT, "surf_nsided.prt"))
    N1 = notes["N1_hole_in_skin"] = {}
    for j, (sname, mk) in enumerate((("cylinder", cyl_skin), ("bsurface", loft_skin))):
        for i, (vname, kw) in enumerate(VARIANTS):
            key = sname + "_" + vname
            m = nxh.mark(key, False)
            try:
                skin, hole, apex = mk(part, i * 100.0, j * 100.0)
                pts = [p for e in hole for p in edge_points(e, 8)]
                before = list(part.Bodies)
                if kw is None:
                    f = fill_surface(part, hole, pts[0])
                else:
                    kw = dict(kw)
                    if kw.pop("faces", False):
                        kw["faces"] = list(skin.GetFaces())
                    f = n_sided(part, edges=hole, hp=pts[0], **kw)
                new = [b for b in nxh.new_bodies(part, before)]
                rep = patch_report(part, skin, new, pts, apex)
                rep["hole_edges"] = len(hole)
                rep["alerts"] = [str(x) for x in (f.GetFeatureErrorMessages() or [])]
                try:                                  # do patch and skin sew into one sheet?
                    n0 = len(nxh.sheets(part))
                    sew(part, skin, new)
                    rep["sewn"] = {"sheets_change": len(nxh.sheets(part)) - n0, "faces": len(skin.GetFaces()), "free_edges": len(nxh.free_edges(skin))}
                except Exception as e:  # noqa: BLE001
                    rep["sewn"] = {"error": str(e)[:200]}
                N1[key] = rep
            except Exception as e:  # noqa: BLE001
                N1[key] = {"error": str(e)[:300]}
                try:
                    nxh.undo_to(m)
                except Exception:  # noqa: BLE001
                    pass
            save_json()

    for sname in ("cylinder", "bsurface"):
        def g(v, sname=sname):
            return N1[sname + "_" + v]
        nf, g1, co, g0, g2, t01 = (g("trimmed_no_faces"), g("trimmed_faces_G1"), g("trimmed_faces_G1_via_continuity_object"),
                                   g("trimmed_faces_G0"), g("trimmed_faces_G2"), g("trimmed_faces_G1_tangent_tol_0.1"))
        fs = g("fill_surface_G1")
        chk.true("N1 %s: Trimmed N-Sided WITHOUT constraint faces is creased against the skin (> 5 deg at 16 edge points)" % sname,
                 ok(nf) and nf["g1_dev_max_deg"] > 5.0, nf)
        chk.true("N1 %s: builder.ConstraintFaces + Continuity G1 -> tangent within TangentTolerance 0.5 deg at all 16 points" % sname,
                 ok(g1) and g1["points_measured"] == 16 and g1["g1_dev_max_deg"] <= 0.5, g1)
        chk.true("N1 %s: with TangentTolerance 0.1 the residual drops to <= 0.12 deg (the residual IS the tolerance)" % sname,
                 ok(t01) and t01["g1_dev_max_deg"] <= 0.12, t01)
        chk.true("N1 %s: faces put on builder.Continuity.ConstraintFaces instead are ignored (same crease as without faces)" % sname,
                 ok(co) and abs(co["g1_dev_max_deg"] - nf["g1_dev_max_deg"]) < 0.01, co)
        chk.true("N1 %s: constraint faces with Continuity G0 change nothing (still creased)" % sname,
                 ok(g0) and abs(g0["g1_dev_max_deg"] - nf["g1_dev_max_deg"]) < 0.01, g0)
        chk.true("N1 %s: G2 on the Trimmed type = the G1 result (edge curvature of the patch is not the skin's)" % sname,
                 ok(g2) and abs(g2["g1_dev_max_deg"] - g1["g1_dev_max_deg"]) < 0.01 and g2["curvature_skin_vs_patch_max_rel_diff"] > 1.0, g2)
        chk.true("N1 %s: the G1 patch is nearer the original surface at the hole centre than the unconstrained one, but not ON it (> 0.05 mm)" % sname,
                 ok(g1) and 0.05 < g1["gap_at_centre_mm"] < nf["gap_at_centre_mm"], (g1.get("gap_at_centre_mm"), nf.get("gap_at_centre_mm")))
        chk.true("N1 %s: Fill Surface on the same hole = the original surface (0.00 deg, 0.000 mm, same curvature)" % sname,
                 ok(fs) and fs["g1_dev_max_deg"] < 0.01 and fs["gap_at_centre_mm"] < 1e-3 and fs["curvature_skin_vs_patch_max_rel_diff"] < 0.01, fs)
        tr, trm, tr2 = g("triangular_faces_G1"), g("triangular_faces_G1_merge"), g("triangular_faces_G2_merge")
        chk.true("N1 %s: Triangular + constraint faces on a 2-edge loop without MergeFaces: 'Unable to build surface.'" % sname,
                 "Unable to build surface" in tr.get("error", ""), tr)
        chk.true("N1 %s: Triangular + faces + G1 + MergeFaces: one face, tangent (< 0.5 deg)" % sname,
                 ok(trm) and trm["patch_faces"] == 1 and trm["g1_dev_max_deg"] < 0.5, trm)
        chk.true("N1 %s: Triangular + faces + G2 + MergeFaces: tangent and edge curvature within 10 %% of the skin's" % sname,
                 ok(tr2) and tr2["g1_dev_max_deg"] < 0.5 and tr2["curvature_skin_vs_patch_max_rel_diff"] < 0.10, tr2)
        chk.true("N1 %s: every patch that built sews to the skin into one sheet (the creased one too - Sew does not test tangency)" % sname,
                 all(r["sewn"].get("sheets_change") == -1 and r["sewn"].get("faces") == 2 for r in (nf, g1, trm, fs) if ok(r)),
                 [r.get("sewn") for r in (nf, g1, trm, fs)])

    # ---------------- N2 loop of curves ON a face (repair patch): 2 rulings + 2 arcs of the cylinder R20
    N2 = notes["N2_curves_on_face"] = {}
    for i, (vname, kw) in enumerate((("no_faces", dict()), ("faces_G1", dict(faces=True, continuity=CT.G1)),
                                     ("faces_G1_tangent_tol_0.1", dict(faces=True, continuity=CT.G1, tangent_tol=0.1)),
                                     ("faces_G1_uv_vector_x", dict(faces=True, continuity=CT.G1, uv=NSB.UVOrientationType.Vector, uv_vector=(1, 0, 0))),
                                     ("faces_G1_uv_vector_y", dict(faces=True, continuity=CT.G1, uv=NSB.UVOrientationType.Vector, uv_vector=(0, 1, 0))),
                                     ("triangular_faces_G2", dict(faces=True, continuity=CT.G2, triangular=True)))):
        m = nxh.mark("N2" + vname, False)
        try:
            x0, y0 = i * 100.0, 300.0
            a = nxh.arc(part, (x0, y0, 0), (0, 1, 0), (0, 0, 1), 20, 0.0, math.pi)
            skin = nxh.extrude(part, nxh.section(part, curves=[a], help_point=(x0, y0 + 20, 0)), (1, 0, 0), 0, 60, sheet=True).GetBodies()[0]
            t0, t1 = math.radians(60), math.radians(120)

            def cp(x, t, y0=y0):
                return (x, y0 + 20 * math.cos(t), 20 * math.sin(t))
            loop = [nxh.line(part, cp(x0 + 20, t0), cp(x0 + 40, t0)),
                    nxh.arc(part, (x0 + 40, y0, 0), (0, 1, 0), (0, 0, 1), 20, t0, t1),
                    nxh.line(part, cp(x0 + 40, t1), cp(x0 + 20, t1)),
                    nxh.arc(part, (x0 + 20, y0, 0), (0, 1, 0), (0, 0, 1), 20, t0, t1)]
            pts = [cp(x0 + 20 + 20 * k / 5.0, t0) for k in range(1, 5)] + [cp(x0 + 20 + 20 * k / 5.0, t1) for k in range(1, 5)] + \
                  [cp(x0 + 40, t0 + (t1 - t0) * k / 5.0) for k in range(1, 5)] + [cp(x0 + 20, t0 + (t1 - t0) * k / 5.0) for k in range(1, 5)]
            before = list(part.Bodies)
            kw = dict(kw)
            if kw.pop("faces", False):
                kw["faces"] = list(skin.GetFaces())
            f = n_sided(part, curves=loop, hp=cp(x0 + 20, t0), **kw)
            new = nxh.new_bodies(part, before)
            rep = patch_report(part, skin, new, pts, (x0 + 30, y0, 20))
            rep["alerts"] = [str(x) for x in (f.GetFeatureErrorMessages() or [])]
            rep["analytic_patch_area"] = round(20 * (t1 - t0) * 20, 3)
            N2[vname] = rep
        except Exception as e:  # noqa: BLE001
            N2[vname] = {"error": str(e)[:300]}
            try:
                nxh.undo_to(m)
            except Exception:  # noqa: BLE001
                pass
        save_json()
    nf, g1, t01, tri = N2["no_faces"], N2["faces_G1"], N2["faces_G1_tangent_tol_0.1"], N2["triangular_faces_G2"]
    chk.true("N2 curves lying on a cylinder face, no constraint face: creased (> 3 deg)", ok(nf) and nf["g1_dev_max_deg"] > 3.0, nf)
    chk.true("N2 the face as constraint + G1: tangent to it along the loop (<= 0.6 deg at tolerance 0.5; <= 0.15 at 0.1)",
             ok(g1) and g1["g1_dev_max_deg"] <= 0.6 and ok(t01) and t01["g1_dev_max_deg"] <= 0.15, (g1, t01))
    chk.true("N2 the tangent patch is NOT the cylinder inside the loop (centre > 0.3 mm off; the unconstrained one is nearer)",
             ok(g1) and g1["gap_at_centre_mm"] > 0.3 and nf["gap_at_centre_mm"] < g1["gap_at_centre_mm"], (nf.get("gap_at_centre_mm"), g1.get("gap_at_centre_mm")))
    chk.true("N2 Triangular on a 4-curve loop: 4 faces, the centre far off the face (> 1 mm) - not a repair patch",
             ok(tri) and tri["patch_faces"] == 4 and tri["gap_at_centre_mm"] > 1.0, tri)

    # ---------------- N3 triangular patch on a planar pentagon, centre control (recorded)
    N3 = notes["N3_triangular_centre"] = {}
    for vname, cz in (("default", None), ("centre_z_0.2", 0.2), ("centre_z_1", 1)):
        m = nxh.mark("N3" + vname, False)
        try:
            pent = [(500 + 20 * math.cos(math.radians(90 + 72 * k)), 20 * math.sin(math.radians(90 + 72 * k)), 0.0) for k in range(5)]
            loop = nxh.polyline(part, pent)
            before = list(part.Bodies)
            f = n_sided(part, curves=loop, hp=pent[0], triangular=True, center_z=cz)
            body = nxh.new_bodies(part, before)[0]
            N3[vname] = {"faces": len(body.GetFaces()), "area": round(nxh.sheet_area(part, body)[0], 3),
                         "gap_centre_z0": round(abs(nxh.dist_to(part, body, (500, 0, 0))), 4), "bbox": nxh.bbox(body),
                         "feature_expressions": [(e.Name, e.RightHandSide) for e in f.GetExpressions()]}
        except Exception as e:  # noqa: BLE001
            N3[vname] = {"error": str(e)[:300]}
            try:
                nxh.undo_to(m)
            except Exception:  # noqa: BLE001
                pass
        save_json()
    d = N3.get("default", {})
    chk.true("N3 Triangular on a planar pentagon: 5 faces (one per side), flat, area = the pentagon",
             ok(d) and d["faces"] == 5 and abs(d["area"] - 2.5 * 400 * math.sin(math.radians(72))) < 0.01, d)
    notes["feature_errors"] = str(nxh.feature_errors(part))
    res["features"] = len(nxh.feature_table(part))
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-500:])
save_json()
