"""nxblade - helpers for blade sets (propeller, fan, impeller, turbine wheel) in NX 2206 journals.

Import after nxh / nxf:
    sys.path.insert(0, os.environ.get("NXBLADE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
    import nxblade

Everything here is exercised by blade_helicoid.py, blade_sections.py, blade_centrifugal.py and
blade_edit_count.py in this folder (NX 2206 batch). The wheel axis is the absolute Z axis in the
builders (the Helix feature always runs along +Z from the origin); the measuring helpers take any axis.

Building blocks : helix, assoc_line, swept (orientation / angular law), envelope_trim
Whole wheels    : helicoid_wheel (thin blades: Helix + Swept + Thicken, hub by Revolve, Pattern Geometry,
                  one Unite, root blend that follows the blade count)
Measuring       : helicoid_xyz / helicoid_deviation / helicoid_area, cyl (cylindrical coordinates),
                  radial_extent, face_classes, blade_groups, blade_count_section, blade_thickness
Editing a count : set the count expression (parametric); strip_blades + repattern or pattern_faces (imported body)
Sketches        : crescent_section (blade section on a station plane), profile_sketch (meridional polygon),
                  arc_sketch, hub_revolve - all fully constrained
Deliverable     : step_gate (the benchmark validity gate, when its interpreter is installed)
"""
import json
import math
import os
import subprocess
import sys

if os.environ.get("NXH_DIR") and os.environ["NXH_DIR"] not in sys.path:
    sys.path.insert(0, os.environ["NXH_DIR"])

import NXOpen
import NXOpen.Features
import NXOpen.GeometricUtilities as GU

import nxf
import nxh

OO = GU.OrientationMethodBuilder.OrientationOptions
SO = GU.ScalingMethodBuilder.ScalingOptions
LT = GU.LawBuilder.Type
SOLID = GU.FeatureOptions.BodyStyle.Solid
SHEET = GU.FeatureOptions.BodyStyle.Sheet
BOOL = nxh.BOOL
AXISYM_TYPES = (nxh.CYLINDER, nxh.CONE, nxh.SPHERE, nxh.REVOLVED)


# ====================================================================== curves
def curves_of(feature):
    return [e for e in feature.GetEntities() if isinstance(e, NXOpen.Curve)]


def helix(part, diameter, pitch, turns, start_angle=0, right_hand=True, name=None):
    """Helix feature along absolute +Z from the origin (the builder ignores any CSYS). diameter, pitch,
    turns, start_angle are numbers or formulas (turns is unitless: 0.2 = 72 degrees of wrap).
    Starts at (d/2 cos a, d/2 sin a, 0). Returns (feature, curve)."""
    HB = NXOpen.Features.HelixBuilder
    b = part.Features.CreateHelixBuilder(NXOpen.Features.Helix.Null)
    try:
        b.Type = HB.Types.AlongVector
        b.OrientationOption = HB.OrientationOptions.Specified
        b.StartAngle.RightHandSide = str(start_angle)
        b.SizeOption = HB.SizeOptions.Diameter
        b.SizeLaw.LawType = LT.Constant
        b.SizeLaw.Value.RightHandSide = str(diameter)
        b.PitchLaw.LawType = LT.Constant
        b.PitchLaw.Value.RightHandSide = str(pitch)
        b.LengthMethod = HB.LengthMethods.Turns
        b.Turns.RightHandSide = str(turns)
        b.TurnDirection = HB.TurnDirections.RightHand if right_hand else HB.TurnDirections.LeftHand
        b.DistanceTolerance = 0.001
        f = b.CommitFeature()
    finally:
        b.Destroy()
    if name:
        f.SetName(name)
    return f, curves_of(f)[0]


def assoc_line(part, a, b, name=None):
    """Associative Line feature between two smart points; coordinates may be formulas. Returns (feature, line)."""
    LB = NXOpen.Features.AssociativeLineBuilder
    bld = part.BaseFeatures.CreateAssociativeLineBuilder(NXOpen.Features.AssociativeLine.Null)
    try:
        bld.StartPointOptions = LB.StartOption.Point
        bld.StartPoint.Value = nxh.point(part, *a)
        bld.EndPointOptions = LB.EndOption.Point
        bld.EndPoint.Value = nxh.point(part, *b)
        bld.Associative = True
        f = bld.CommitFeature()
    finally:
        bld.Destroy()
    if name:
        f.SetName(name)
    return f, curves_of(f)[0]


def feature_section(part, feature, seed, help_point):
    """Section holding all curves of a curve feature / sketch (stays associative), started at the seed end
    nearest help_point."""
    return nxh.section(part, rules=[part.ScRuleFactory.CreateRuleCurveFeature([feature])], seed=seed,
                       help_point=help_point)


def swept(part, sections, guides, orientation="fixed", vector=(0, 0, 1), angles=None, cubic=False, scaling=None,
          solid=False):
    """Swept with the orientation options nxf.swept does not have. Returns the feature.

    orientation "fixed"    the section is translated (NX default) - NOT a helicoid on a helix guide
                "vector"   OrientationOption.ByVectorDirection: the section keeps its angle to `vector` and turns
                           with the guide about it - a helicoid when vector = the helix axis
                "angular"  ByAngularLaw, angles=(start, end) in degrees (numbers or formulas), linear or cubic:
                           the section twists about the guide; a POSITIVE angle is a LEFT-hand rotation about the
                           guide direction (measured); the feature owns two Degrees expressions (start, end)
    scaling: SO.Uniform / SO.Lateral - required with two or three guides."""
    b = part.Features.CreateSweptBuilder(NXOpen.Features.Swept.Null)
    try:
        b.G0Tolerance = 0.01
        b.G1Tolerance = 0.5
        for s in sections:
            b.SectionList.Append(s)
        b.AlignmentMethod.SetSections(list(sections))
        for g in guides:
            b.GuideList.Append(g)
        om = b.OrientationMethod
        if orientation == "vector":
            om.OrientationOption = OO.ByVectorDirection
            om.OrientationVector = nxh.direction(part, vector)
        elif orientation == "angular":
            om.OrientationOption = OO.ByAngularLaw
            law = om.AngularLaw
            law.LawType = LT.Cubic if cubic else LT.Linear
            law.StartValue.RightHandSide = str(angles[0])
            law.EndValue.RightHandSide = str(angles[1])
        elif orientation not in (None, "fixed"):
            raise ValueError("swept orientation: " + str(orientation))
        if scaling is not None:
            b.ScalingMethod.ScalingOption = scaling
        b.BodyPreference.BodyType = SOLID if solid else SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


# ====================================================================== analytic helicoid
def helicoid_xyz(r, theta_deg, pitch, start_angle=0.0, right_hand=True):
    """Point of the helicoid swept by a radial line turning about Z: z = pitch * theta / 360."""
    a = math.radians(start_angle + (theta_deg if right_hand else -theta_deg))
    return (r * math.cos(a), r * math.sin(a), pitch * theta_deg / 360.0)


def helicoid_area(r0, r1, pitch, wrap_deg):
    c = pitch / (2 * math.pi)

    def prim(x):
        s = math.sqrt(x * x + c * c)
        return 0.5 * x * s + 0.5 * c * c * math.log(x + s)

    return math.radians(wrap_deg) * (prim(r1) - prim(r0))


def helicoid_deviation(part, sheet, r0, r1, pitch, wrap_deg, start_angle=0.0, nr=5, nt=7):
    """Largest distance from nr x nt points of the true helicoid to the sheet (0 = the sheet is a helicoid)."""
    worst = 0.0
    for i in range(nr):
        r = r0 + (r1 - r0) * i / (nr - 1)
        for j in range(nt):
            th = wrap_deg * j / (nt - 1)
            worst = max(worst, abs(nxh.dist_to(part, sheet, helicoid_xyz(r, th, pitch, start_angle))))
    return worst


# ====================================================================== cylindrical measuring
def _unit(v):
    m = math.sqrt(sum(x * x for x in v))
    return [x / m for x in v]


def _frame(vec):
    a = _unit(vec)
    ref = (1.0, 0.0, 0.0) if abs(a[0]) < 0.9 else (0.0, 1.0, 0.0)
    u = _unit([ref[1] * a[2] - ref[2] * a[1], ref[2] * a[0] - ref[0] * a[2], ref[0] * a[1] - ref[1] * a[0]])
    u = _unit([a[1] * u[2] - a[2] * u[1], a[2] * u[0] - a[0] * u[2], a[0] * u[1] - a[1] * u[0]])   # u = a x (ref x a)
    v = [a[1] * u[2] - a[2] * u[1], a[2] * u[0] - a[0] * u[2], a[0] * u[1] - a[1] * u[0]]
    return a, u, v


def cyl(p, origin=(0, 0, 0), vec=(0, 0, 1)):
    """(r, angle in degrees, z) of point p about the axis (origin, vec). For vec = +Z the angle is from +X."""
    a, u, v = _frame(vec)
    d = [p[i] - origin[i] for i in range(3)]
    z = sum(d[i] * a[i] for i in range(3))
    x = sum(d[i] * u[i] for i in range(3))
    y = sum(d[i] * v[i] for i in range(3))
    return math.hypot(x, y), math.degrees(math.atan2(y, x)), z


def edge_points(edge, n=13):
    props = nxh.UFS.ModlGeneral.AskCurveProps
    return [list(props(edge.Tag, i / (n - 1.0))[0]) for i in range(n)]


def radial_extent(obj, origin=(0, 0, 0), vec=(0, 0, 1), n=13):
    """(r_min, r_max, z_min, z_max) of a body or face about the axis, sampled on its EDGES (n points each).
    Exact where the extreme lies on an edge (a tip cut by a coaxial cylinder, a hub rim); a face bulging
    beyond its edges is not seen - trim the tip by the revolved envelope to make the tip radius a fact."""
    rs, zs = [], []
    for e in obj.GetEdges():
        for p in edge_points(e, n):
            r, _a, z = cyl(p, origin, vec)
            rs.append(r)
            zs.append(z)
    return min(rs), max(rs), min(zs), max(zs)


def angular_gap(face, origin=(0, 0, 0), vec=(0, 0, 1), n=25):
    """Largest angular gap (degrees) between edge sample points of a face about the axis: small = the face
    runs all the way round (hub, shroud, end plane); large = a local face (blade side, tip, root blend)."""
    ang = sorted(cyl(p, origin, vec)[1] for e in face.GetEdges() for p in edge_points(e, n)
                 if cyl(p, origin, vec)[0] > 1e-6)
    if len(ang) < 2:
        return 360.0
    return max([ang[i + 1] - ang[i] for i in range(len(ang) - 1)] + [ang[0] + 360.0 - ang[-1]])


def is_axisymmetric(face, origin=(0, 0, 0), vec=(0, 0, 1), tol=1e-3):
    """True for a face of revolution about the axis by its TYPE: coaxial cylinder / cone / sphere / torus, or a
    plane normal to the axis. (A B-surface that happens to be a surface of revolution is not recognised.)"""
    a = _unit(vec)
    t, pt, d, _rad = nxh.face_data(face)
    par = abs(abs(sum(d[i] * a[i] for i in range(3))) - 1.0) < 1e-6
    if t == nxh.PLANE:
        return par
    if t not in AXISYM_TYPES:
        return False
    on_axis = cyl(pt, origin, vec)[0] < tol
    return on_axis if t == nxh.SPHERE else (par and on_axis)


def face_classes(part, body, origin=(0, 0, 0), vec=(0, 0, 1), faces=None):
    """Face census by congruence: {(type, area, r_min, r_max): count} over the body's faces (or `faces`). In a
    wheel of n identical blades every blade face class occurs n (or 2n, 3n ...) times; hub faces occur once
    (twice for two equal end planes) - pass the faces of blade_groups() to test the blades alone."""
    out = {}
    for f in (faces if faces is not None else body.GetFaces()):
        r0, r1, _z0, _z1 = radial_extent(f, origin, vec, 7)
        key = (nxh.face_data(f)[0], round(nxh.sheet_area(part, [f])[0], 1), round(r0, 1), round(r1, 1))
        out[key] = out.get(key, 0) + 1
    return out


def blade_groups(part, body, origin=(0, 0, 0), vec=(0, 0, 1), full_gap=45.0, mode="auto"):
    """Split the faces of a wheel into the hub and the blades, by topology.

    Hub faces = faces of revolution about the axis (is_axisymmetric) that run all the way round
    (angular_gap < full_gap). Every other face belongs to a blade; faces sharing an edge are one group, so a
    blade with its tip face, edge faces and root blend is ONE group.
    Returns (groups, hub_faces); a group is {"faces", "area", "r_max", "angle"} sorted by angle of its
    largest face.

    mode "full" is the rule above. Vanes that run the full length of the hub cut the hub face into separate
    patches (partial faces), which then tie all blades into ONE group; mode "type" handles that: every face of
    revolution about the axis counts as hub whatever its extent, the blades are the connected sets of the
    other faces, and a partial face of revolution that touches exactly one blade (a tip cut by the envelope)
    is given back to that blade. With "type" the two sides of a vane that is trimmed by the envelope all
    round and has no blend come back as two groups. mode "auto" (default): "full", and "type" when "full"
    returns a single group."""
    full, partial, core = [], [], []
    for f in body.GetFaces():
        if is_axisymmetric(f, origin, vec):
            (full if angular_gap(f, origin, vec) < full_gap else partial).append(f)
        else:
            core.append(f)

    def components(faces):
        tags = {f.Tag: f for f in faces}
        adj = {t: set() for t in tags}
        for e in body.GetEdges():
            fs = [x.Tag for x in e.GetFaces() if x.Tag in tags]
            if len(fs) == 2:
                adj[fs[0]].add(fs[1])
                adj[fs[1]].add(fs[0])
        seen, out = set(), []
        for t in tags:
            if t in seen:
                continue
            stack, comp = [t], []
            seen.add(t)
            while stack:
                x = stack.pop()
                comp.append(tags[x])
                for y in adj[x]:
                    if y not in seen:
                        seen.add(y)
                        stack.append(y)
            out.append(comp)
        return out

    hub = list(full)
    comps = components(core + partial) if mode in ("full", "auto") else []
    if mode == "type" or (mode == "auto" and len(comps) <= 1 and core):
        comps = components(core)
        owner = {f.Tag: i for i, c in enumerate(comps) for f in c}
        for f in partial:
            touching = {owner[x.Tag] for e in f.GetEdges() for x in e.GetFaces() if x.Tag in owner}
            if len(touching) == 1:
                comps[touching.pop()].append(f)
            else:
                hub.append(f)
    groups = []
    for comp in comps:
        areas = [nxh.sheet_area(part, [f])[0] for f in comp]
        big = comp[areas.index(max(areas))]
        pts = [p for e in big.GetEdges() for p in edge_points(e, 7)]
        cx = [sum(p[i] for p in pts) / len(pts) for i in range(3)]
        groups.append({"faces": comp, "area": sum(areas), "r_max": max(radial_extent(f, origin, vec, 7)[1] for f in comp),
                       "angle": cyl(cx, origin, vec)[1]})
    groups.sort(key=lambda g: g["angle"])
    return groups, hub


def blade_count_section(part, body, radius, z0, z1, origin=(0, 0, 0), vec=(0, 0, 1), wall=0.2):
    """Number of blades = number of separate lumps of material on the coaxial cylinder r = radius between the
    axial stations z0 and z1 (a thin tube intersected with a copy of the body; everything is undone).
    Works on parametric and imported bodies, whatever the blade type; choose a radius between hub and tip
    (and below a shroud, if there is one)."""
    a = _unit(vec)
    base = tuple(origin[i] + a[i] * z0 for i in range(3))
    m = nxh.mark("blade count probe", False)
    try:
        _f, tube = nxh.cylinder(part, base, a, 2 * (radius + wall / 2.0), z1 - z0)
        nxh.cylinder(part, base, a, 2 * (radius - wall / 2.0), z1 - z0, op=BOOL.Subtract, target=tube)
        f = nxh.intersect(part, tube, [body], check=False, keep_tool=True)
        return len(f.GetBodies())
    finally:
        nxh.undo_to(m)


def blade_thickness(part, group):
    """Thickness of a thin blade = minimum distance between its two largest faces (pressure and suction side).
    Exact for a Thicken body (offset faces); on a profiled blade it is the thickness at the thin edge."""
    fs = sorted(group["faces"], key=lambda f: -nxh.sheet_area(part, [f])[0])[:2]
    return nxh.min_dist(fs[0], fs[1])


# ====================================================================== building a wheel
def envelope_trim(part, blade, diameter, z0, height, origin=(0, 0, 0), vec=(0, 0, 1)):
    """Cut a blade blank to the tip radius: Intersect with a coaxial cylinder (the simplest revolved envelope)
    that starts z0 along the axis from `origin`. The tip face becomes an exact cylinder of that diameter.
    diameter / height may be formulas. For a shaped envelope use nxf.revolve(..., op=BOOL.Intersect, target=blade)."""
    a = _unit(vec)
    base = tuple(origin[i] + a[i] * z0 for i in range(3))
    f, _b = nxh.cylinder(part, base, a, diameter, height, op=BOOL.Intersect, target=blade)
    return f


def pattern_and_unite(part, hub, blade, blade_feature, count, origin=(0, 0, 0), vec=(0, 0, 1)):
    """Blade set: Pattern Geometry of the finished blade BODY about the axis, then ONE Unite whose tool rule is
    the blade feature + the pattern feature (BodyFeature rule), so the tool set follows the count expression.
    blade_feature = the feature that CREATED the blade body (Thicken, Through Curves ...), not a later cut.
    Returns (pattern feature, unite feature)."""
    pf, _copies = nxf.pattern_geometry(part, [blade], circular=dict(origin=origin, vec=vec, count=count))
    uf = nxh.unite(part, hub, tool_features=[blade_feature, pf])
    return pf, uf


def round_edges(part, blade, radius):
    """Round the leading and trailing edge of a thin (Thicken) blade before it is patterned: Edge Blend on
    the four edges between the two side faces and the two long end faces. radius may be a formula; measured
    on a 3 mm blade: 0.3*thk, 0.45*thk and the full round thk/2 all build clean. Returns the feature."""
    fs = sorted(blade.GetFaces(), key=lambda f: -nxh.sheet_area(part, [f])[0])
    sides = {f.Tag for f in fs[:2]}
    ends = set()
    for f in fs[2:]:
        r0, r1, _z0, _z1 = radial_extent(f, n=7)
        if nxh.face_data(f)[0] == nxh.BSURF and r1 - r0 > 0.5 * (radial_extent(blade, n=7)[1] - radial_extent(blade, n=7)[0]):
            ends.add(f.Tag)
    edges = [e for e in blade.GetEdges()
             if len({x.Tag for x in e.GetFaces()} & sides) == 1 and len({x.Tag for x in e.GetFaces()} & ends) == 1]
    if len(edges) != 4:
        raise RuntimeError("round_edges: expected 4 leading / trailing edges, found %d" % len(edges))
    return nxh.blend(part, edges, radius)


def root_blend(part, unite_feature, radius):
    """Edge Blend on the root edges of ALL blades with one rule: the intersection edges of the Unite feature
    (hub against blade; FeatureIntersectionEdges). The rule is re-evaluated on update, so the blend follows a
    changed blade count. (CreateRuleEdgeFeature([unite]) is the wrong rule: it takes EVERY edge of the blades.)"""
    sc = part.ScCollectors.CreateCollector()
    sc.ReplaceRules([part.ScRuleFactory.CreateRuleFeatureIntersectionEdges([unite_feature])], False)
    b = part.Features.CreateEdgeBlendBuilder(nxh.NULL_FEATURE)
    try:
        b.AddChainset(sc, str(radius))
        b.Tolerance = 0.01
        return b.CommitFeature()
    finally:
        b.Destroy()


def hub_revolve(part, r_bore, r_hub, below, above, name="SK_HUB"):
    """Hub = Revolve of a fully constrained rectangle sketched on the XZ datum plane (r_bore .. r_hub, z from
    -below to +above; all four are formulas). Returns (sketch, sketch status dict, revolve feature, body)."""
    dat = nxh.Datums(part)
    rb, rh, zb, zt = (nxf._num(part, x) for x in (r_bore, r_hub, below, above))
    sk = nxf.new_sketch(part, dat.xz, dat.x, dat.origin, name)
    ls = nxf.hv_polygon(part, sk, [(rb, -zb), (rh, -zb), (rh, zt), (rb, zt)], to3d=lambda u, v: nxh.P(u, 0, v))
    P = nxh.P
    nxf.pdim(sk, dat.z, P(0, 0, 50), ls[1], nxf.A.StartPoint, P(rh / 2, 0, -zb - 4), r_hub)
    nxf.pdim(sk, dat.z, P(0, 0, 50), ls[3], nxf.A.StartPoint, P(rb / 2, 0, zt + 4), r_bore)
    nxf.pdim(sk, dat.x, P(50, 0, 0), ls[0], nxf.A.StartPoint, P(rh + 4, 0, -zb / 2), below)
    nxf.pdim(sk, dat.x, P(50, 0, 0), ls[2], nxf.A.StartPoint, P(rh + 4, 0, zt / 2), above)
    st = nxf.finish_sketch(sk)
    f = nxf.revolve(part, nxh.section_region(part, sk, ((rb + rh) / 2, 0, (zt - zb) / 2)), nxh.axis(part, (0, 0, 0), (0, 0, 1)))
    return sk, st, f, f.GetBodies()[0]


def helicoid_wheel(part, n_blades=5, r_tip=60.0, r_hub=18.0, r_bore=6.0, pitch=120.0, wrap=72.0, thk=3.0,
                   root_r=1.5, hub_margin=6.0, guides="two", blend=True, edge_r=None):
    """Complete thin-blade wheel (propeller / axial fan): named expressions -> hub by Revolve -> radial line ->
    two helices -> Swept helicoid sheet -> Thicken by `thk` -> tip cut by the envelope cylinder -> Pattern
    Geometry of the blade body x n_blades -> one Unite -> root blend on the Unite edges.

    guides: "two" (helix at the root radius + helix at the blank radius, Uniform scaling; 0.0016 mm from the
    true helicoid) or "vector" (one helix, orientation ByVectorDirection along Z; 0.0041 mm).
    edge_r: formula for rounding the leading / trailing edges of the blade before the pattern (None = sharp).
    Expressions created: n_blades, r_tip, r_hub, r_bore, pitch, wrap (unitless degrees), thk, root_r,
    hub_margin, rise (= pitch*wrap/360). Returns a dict of the features and bodies."""
    for name, val, unit in (("n_blades", n_blades, None), ("r_tip", r_tip, "mm"), ("r_hub", r_hub, "mm"),
                            ("r_bore", r_bore, "mm"), ("pitch", pitch, "mm"), ("wrap", wrap, None),
                            ("thk", thk, "mm"), ("root_r", root_r, "mm"), ("hub_margin", hub_margin, "mm")):
        nxh.expr(part, name, val, unit)
    nxh.expr(part, "rise", "pitch*wrap/360", "mm", "axial length of one blade")
    w = {}
    w["hub_sketch"], w["hub_sketch_status"], w["hub_feature"], w["hub"] = hub_revolve(
        part, "r_bore", "r_hub", "hub_margin", "rise+hub_margin")
    w["hub_volume"] = nxh.volume(part, w["hub"])
    # blade blank: from 2 mm inside the hub to 2 mm beyond the tip, so that Unite and the tip cut both bite
    r_in, r_out = "r_hub-2", "r_tip+2"
    w["line_feature"], line = assoc_line(part, (r_in, 0, 0), (r_out, 0, 0), "BLADE_GENERATOR")
    w["helix_outer"], h_out = helix(part, "2*(%s)" % r_out, "pitch", "wrap/360", name="HELIX_TIP")
    sec = feature_section(part, w["line_feature"], line, (nxf._num(part, r_in), 0, 0))
    g_out = feature_section(part, w["helix_outer"], h_out, (nxf._num(part, r_out), 0, 0))
    if guides == "two":
        w["helix_inner"], h_in = helix(part, "2*(%s)" % r_in, "pitch", "wrap/360", name="HELIX_ROOT")
        g_in = feature_section(part, w["helix_inner"], h_in, (nxf._num(part, r_in), 0, 0))
        w["sweep"] = swept(part, [sec], [g_in, g_out], scaling=SO.Uniform)
    else:
        w["sweep"] = swept(part, [sec], [g_out], orientation="vector", vector=(0, 0, 1))
    w["sheet"] = w["sweep"].GetBodies()[0]
    before = list(part.Bodies)
    w["thicken"] = nxf.thicken(part, w["sheet"], "thk/2", "-thk/2")
    w["blade"] = [b for b in nxh.new_bodies(part, before) if b.IsSolidBody][0]
    w["blank_volume"] = nxh.volume(part, w["blade"])
    w["tip_cut"] = envelope_trim(part, w["blade"], "2*r_tip", -nxf._num(part, "hub_margin"), "rise+2*hub_margin")
    w["blade_volume"] = nxh.volume(part, w["blade"])
    if edge_r is not None:
        w["edge_blend"] = round_edges(part, w["blade"], edge_r)
        w["blade_volume_rounded"] = nxh.volume(part, w["blade"])
    w["pattern"], w["unite"] = pattern_and_unite(part, w["hub"], w["blade"], w["thicken"], "n_blades")
    w["body"] = w["hub"]
    w["volume_no_blend"] = nxh.volume(part, w["body"])
    if blend:
        w["root_blend"] = root_blend(part, w["unite"], "root_r")
    return w


# ====================================================================== section and profile sketches
def _val(part, name_or_number):
    """Numeric value of a number or of a NAMED expression (works for degree expressions, unlike nxf._num)."""
    try:
        return float(name_or_number)
    except (TypeError, ValueError):
        return part.Expressions.FindObject(str(name_or_number)).Value


def crescent_section(part, z, chord, stagger, name, k_suction="k_suction", k_pressure="k_pressure"):
    """One closed blade section, fully constrained, in a sketch on a datum plane parallel to XY at height z
    (the blade spans along +Z; the wheel axis is X).

    The section is a crescent of two arcs that meet in sharp leading / trailing edges: chord centred on the Z
    axis, turned `stagger` degrees from the X (axial) direction towards +Y; suction arc of radius
    k_suction x chord and pressure arc of radius k_pressure x chord, both bulging to the same side
    (thickness = difference of the two sagittas, 9 % of the chord for 0.8 / 1.5).
    z, chord, stagger, k_suction, k_pressure are NAMES of expressions (stagger in degrees, 0 < stagger < 90).
    Six dimensions (4 on the chord ends, 2 radii) + 2 coincident ends = DOF 0.
    Returns {"sketch", "plane_feature", "status", "seed" (suction arc, starts at the leading point A), "A", "B",
    "suction_mid", "pressure_mid" (designed 3D points), "thickness"}."""
    dat = nxh.Datums(part)
    zc, c, a = _val(part, z), _val(part, chord), math.radians(_val(part, stagger))
    ks, kp = _val(part, k_suction), _val(part, k_pressure)
    pf, dp = nxf.datum_plane(part, "offset", [dat.xy], z, name="PL_" + name)
    sk = nxf.new_sketch(part, dp, dat.x, nxh.point(part, 0, 0, z), name)
    e, n = (math.cos(a), math.sin(a)), (-math.sin(a), math.cos(a))
    arcs, mids = [], []
    for k in (ks, kp):
        rad = k * c
        h = math.sqrt(rad * rad - c * c / 4.0)
        phi = math.asin(c / (2.0 * rad))
        centre = nxh.P(-n[0] * h, -n[1] * h, zc)
        arcs.append(part.Curves.CreateArc(centre, nxh.V(1, 0, 0), nxh.V(0, 1, 0), rad, a + math.pi / 2 - phi, a + math.pi / 2 + phi))
        mids.append((n[0] * (rad - h), n[1] * (rad - h), zc))
    nxf.add(sk, *arcs, infer=False)
    s_arc, p_arc = arcs
    sk.CreateCoincidentConstraint(nxf.cg(p_arc, nxf.CP.StartVertex), nxf.cg(s_arc, nxf.CP.StartVertex))
    sk.CreateCoincidentConstraint(nxf.cg(p_arc, nxf.CP.EndVertex), nxf.cg(s_arc, nxf.CP.EndVertex))
    A = (c / 2 * e[0], c / 2 * e[1], zc)
    B = (-A[0], -A[1], zc)
    P = nxh.P
    fx, fy = "%s/2*cos(%s)" % (chord, stagger), "%s/2*sin(%s)" % (chord, stagger)
    for assoc, pt in ((nxf.A.StartPoint, A), (nxf.A.EndPoint, B)):
        nxf.pdim(sk, dat.y, P(0, 50, 0), s_arc, assoc, P(pt[0] / 2, pt[1] * 1.3, zc), fx)
        nxf.pdim(sk, dat.x, P(50, 0, 0), s_arc, assoc, P(pt[0] * 1.3, pt[1] / 2, zc), fy)
    nxf.radius_dim(sk, s_arc, P(*mids[0]), P(mids[0][0] * 3, mids[0][1] * 3, zc), "%s*%s" % (k_suction, chord))
    nxf.radius_dim(sk, p_arc, P(*mids[1]), P(-mids[1][0] * 3 - 1, -mids[1][1] * 3 - 1, zc), "%s*%s" % (k_pressure, chord))
    status = nxf.finish_sketch(sk)
    return {"sketch": sk, "plane_feature": pf, "status": status, "seed": s_arc, "A": A, "B": B, "suction_mid": mids[0],
            "pressure_mid": mids[1], "thickness": math.dist(mids[0], mids[1])}


def crescent_points(z, chord, stagger_deg, ks, kp):
    """Designed points of a crescent_section for given VALUES: (A, B, suction mid, pressure mid, thickness)."""
    a = math.radians(stagger_deg)
    e, n = (math.cos(a), math.sin(a)), (-math.sin(a), math.cos(a))
    sag = [k * chord - math.sqrt((k * chord) ** 2 - chord * chord / 4.0) for k in (ks, kp)]
    A = (chord / 2 * e[0], chord / 2 * e[1], z)
    return A, (-A[0], -A[1], z), (n[0] * sag[0], n[1] * sag[0], z), (n[0] * sag[1], n[1] * sag[1], z), sag[0] - sag[1]


def crescent_area(chord, ks, kp):
    seg = [k * k * math.asin(1.0 / (2 * k)) - 0.5 * math.sqrt(k * k - 0.25) for k in (ks, kp)]
    return chord * chord * (seg[0] - seg[1])


def profile_sketch(part, pts, name, seed=None):
    """Closed meridional profile (polygon of straight lines) as a fully constrained sketch on the XZ datum plane,
    for Revolve about Z: hubs, shroud / passage envelopes.

    pts: [(r, z), ...] in order; each coordinate is a number or a formula (expression name). Every vertex gets
    a perpendicular dimension from the Z axis (its radius) and from the X axis (its height); a height that
    evaluates to 0 becomes a point-on-X-axis constraint instead of a zero dimension. DOF 0.
    Returns (sketch, status, section) - the section is the region around `seed` (default: mean of the vertices)."""
    dat = nxh.Datums(part)
    val = [(nxf._num(part, r), nxf._num(part, z)) for r, z in pts]
    sk = nxf.new_sketch(part, dat.xz, dat.x, dat.origin, name)
    n = len(pts)
    P = nxh.P
    ls = [part.Curves.CreateLine(P(val[i][0], 0, val[i][1]), P(val[(i + 1) % n][0], 0, val[(i + 1) % n][1])) for i in range(n)]
    nxf.add(sk, *ls)
    for i, ((fr, fz), (r, z)) in enumerate(zip(pts, val)):
        nxf.pdim(sk, dat.z, P(0, 0, 50), ls[i], nxf.A.StartPoint, P(r / 2.0, 0, z + 2 + i), fr)
        if abs(z) < 1e-9:
            sk.CreatePointOnCurveConstraint(nxf.cg(ls[i], nxf.CP.StartVertex), nxf.cg(dat.x), nxf.help_at(P(r, 0, 0)))
        else:
            nxf.pdim(sk, dat.x, P(50, 0, 0), ls[i], nxf.A.StartPoint, P(r + 2 + i, 0, z / 2.0), fz)
    status = nxf.finish_sketch(sk)
    if seed is None:
        seed = (sum(v[0] for v in val) / n, 0.0, sum(v[1] for v in val) / n)
    return sk, status, nxh.section_region(part, sk, seed)


def arc_sketch(part, plane, z, start, end, radius, name, bulge_left=True):
    """One arc from `start` (x, y) to `end` (x, y) with the given radius in a sketch on a datum plane parallel to
    XY at height z (number): two perpendicular dimensions on each end + the radius = DOF 0. None of the four
    end coordinates may be 0. bulge_left: the arc bows to the left of the direction start -> end.
    Returns (sketch, status, arc)."""
    dat = nxh.Datums(part)
    sx, sy = start
    ex, ey = end
    d = math.hypot(ex - sx, ey - sy)
    h = math.sqrt(radius * radius - d * d / 4.0)
    ux, uy = (ex - sx) / d, (ey - sy) / d
    nx_, ny_ = -uy, ux                                           # left of start -> end
    side = 1.0 if bulge_left else -1.0
    cx, cy = (sx + ex) / 2 - side * nx_ * h, (sy + ey) / 2 - side * ny_ * h
    a_s, a_e = math.atan2(sy - cy, sx - cx), math.atan2(ey - cy, ex - cx)
    first, last = (a_e, a_s) if bulge_left else (a_s, a_e)       # NX arcs run counter-clockwise
    while last <= first:
        last += 2 * math.pi
    sk = nxf.new_sketch(part, plane, dat.x, nxh.point(part, 0, 0, z), name)
    arc = part.Curves.CreateArc(nxh.P(cx, cy, z), nxh.V(1, 0, 0), nxh.V(0, 1, 0), float(radius), first, last)
    nxf.add(sk, arc, infer=False)
    a_start, a_end = (nxf.A.EndPoint, nxf.A.StartPoint) if bulge_left else (nxf.A.StartPoint, nxf.A.EndPoint)
    P = nxh.P
    for assoc, (x, y) in ((a_start, start), (a_end, end)):
        nxf.pdim(sk, dat.y, P(0, 50, 0), arc, assoc, P(x / 2.0, y + 3, z), abs(x))
        nxf.pdim(sk, dat.x, P(50, 0, 0), arc, assoc, P(x + 3, y / 2.0, z), abs(y))
    mid = ((sx + ex) / 2 + side * nx_ * (radius - h), (sy + ey) / 2 + side * ny_ * (radius - h))
    nxf.radius_dim(sk, arc, P(mid[0], mid[1], z), P(mid[0] + 5, mid[1] + 5, z), radius)
    return sk, nxf.finish_sketch(sk), arc


# ====================================================================== changing the count of an imported wheel
def strip_blades(part, body, keep=1, origin=(0, 0, 0), vec=(0, 0, 1)):
    """Imported, parameter-free wheel: Delete Face (heal) on every blade group except `keep` of them. The hub
    face closes over the removed roots.

    First ONE Delete Face for all surplus blades (works on clean bodies). If NX refuses it (on a loose imported
    impeller: "remaining faces cannot close the area"), the blades are deleted one feature at a time; a blade
    that still refuses (e.g. its end tab crosses the seam of a hub face) is kept as the seed instead, as long
    as no more than `keep` blades remain. Returns (feature or list of features, groups that were kept)."""
    groups, _hub = blade_groups(part, body, origin, vec)
    big = max(g["area"] for g in groups)
    blades = [g for g in groups if g["area"] > 0.5 * big]
    f, err = nxh.attempt("delete all surplus blades", nxf.delete_face, part, [x for g in blades[keep:] for x in g["faces"]])
    if not err:
        return f, blades[:keep]
    feats, left = [], len(blades)
    for i in range(len(blades) - 1, -1, -1):                  # last first, so the first blade is the default seed
        if left <= keep:
            break
        groups, _hub = blade_groups(part, body, origin, vec)  # faces are re-numbered after every Delete Face
        cur = sorted([g for g in groups if g["area"] > 0.5 * big], key=lambda g: g["angle"])
        target = min(cur, key=lambda g: abs((g["angle"] - blades[i]["angle"] + 180.0) % 360.0 - 180.0))
        f, e1 = nxh.attempt("delete one blade", nxf.delete_face, part, list(target["faces"]))
        if not e1:
            feats.append(f)
            left -= 1
    groups, _hub = blade_groups(part, body, origin, vec)
    kept = [g for g in groups if g["area"] > 0.5 * big]
    if len(kept) > keep:
        raise RuntimeError("strip_blades: %d blades left, wanted %d (first error: %s)" % (len(kept), keep, err))
    return feats, kept


def repattern(part, body, count, origin=(0, 0, 0), vec=(0, 0, 1)):
    """Hub + ONE blade (after strip_blades) -> a wheel of `count` blades: Pattern Geometry of the whole body
    and one Unite (the hubs coincide). Returns (pattern feature, unite feature)."""
    pf, copies = nxf.pattern_geometry(part, [body], circular=dict(origin=origin, vec=vec, count=count))
    uf = nxh.unite(part, body, tools=copies)
    return pf, uf


def pattern_faces(part, faces, count, origin=(0, 0, 0), vec=(0, 0, 1)):
    """Synchronous Pattern Face: copy the faces of ONE blade (a blade_groups group, root blend included) round
    the axis on the same body - the one-feature alternative to repattern() on an imported wheel (measured:
    same volume, 20 s instead of 45-80 s). The faces must form a closed set on the hub. Returns the feature."""
    b = part.Features.CreatePatternFaceFeatureBuilder(NXOpen.Features.PatternFaceFeature.Null)
    try:
        b.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        nxf._circular(part, b.PatternDefinition, origin, vec, count)
        return b.CommitFeature()
    finally:
        b.Destroy()


# ====================================================================== deliverable
def step_gate(stp, timeout=600):
    """Run the benchmark validity gate (harness/tools/validate_step.py, cadgenbench venv) on a STEP file.

    Interpreter: env CADGENBENCH_PY or C:\\Users\\<user>\\.venvs\\cadgenbench\\Scripts\\python.exe; tool: env
    NX_STEP_GATE or <skills>\\..\\harness\\tools\\validate_step.py. Returns the gate's dict (valid, watertight,
    solids, faces, volume, betti ...) plus "available": True, or {"available": False, "why": ...} when the
    interpreter or the tool is not installed - then rely on nxf.step_roundtrip_check."""
    py = os.environ.get("CADGENBENCH_PY") or os.path.join(os.path.expanduser("~"), ".venvs", "cadgenbench", "Scripts", "python.exe")
    here = os.path.dirname(os.path.abspath(__file__))
    tool = os.environ.get("NX_STEP_GATE") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(here))),
                                                         "harness", "tools", "validate_step.py")
    if not os.path.exists(py) or not os.path.exists(tool):
        return {"available": False, "why": "missing " + (py if not os.path.exists(py) else tool)}
    out = os.path.splitext(stp)[0] + ".gate.json"
    if os.path.exists(out):
        os.remove(out)
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith("PYTHON")}
    try:
        p = subprocess.run([py, tool, stp, "--out", out], capture_output=True, timeout=timeout, env=env,
                           cwd=os.path.dirname(tool))
    except Exception as e:  # noqa: BLE001
        return {"available": False, "why": "gate did not run: " + str(e)[:200]}
    if not os.path.exists(out):
        return {"available": False, "why": "gate wrote no result: " + p.stderr.decode("utf-8", "replace")[-300:]}
    with open(out, "r", encoding="utf-8") as fh:
        res = json.load(fh)
    res["available"] = True
    return res


if __name__ == "__main__":
    # Run as a journal (run_all_examples.ps1 runs every *.py that is not on its skip list): only prove that
    # the module imports under run_journal. The real tests are the blade_*.py journals.
    _out = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
    nxh.write_json(os.path.join(_out, "nxblade.json"),
                   {"result": "PASS", "checks": [{"name": "nxblade imports under run_journal", "ok": True},
                                                 {"name": "helicoid maths: area of a flat annulus sector (pitch -> 0)",
                                                  "ok": abs(helicoid_area(10.0, 20.0, 1e-9, 90.0) - math.pi * 300.0 / 4.0) < 1e-6}],
                    "note": "helper module, not an example: see blade_helicoid.py, blade_sections.py, "
                            "blade_centrifugal.py, blade_edit_count.py"})
