"""Surface construction recipes, verified on NX 2206 batch (run_journal).

Through Curves (open / closed / G1 / start-point repair / preserve shape), Through Curve Mesh,
Swept (1 and 2 guides), Sweep Along Guide, Studio Surface, Ruled, sheet-mode Extrude/Revolve,
Bounded Plane, Fill Surface, N-Sided Surface, and cap + Sew -> solid.

Usage: run_journal surf_build.py -args <output folder>
Writes <output folder>/surf_build.json with every measurement and "result": "PASS"|"FAIL".
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
GU = NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
NULLO = NXOpen.NXObject.Null
TCB = NXOpen.Features.ThroughCurvesBuilder
SHEET, SOLID = GU.FeatureOptions.BodyStyle.Sheet, GU.FeatureOptions.BodyStyle.Solid
res = {"checks": [], "notes": {}}


# ---------------------------------------------------------------- measurement helpers
def sheet_area(part, body):
    """(area, perimeter) of all faces. nxh.mass() is WRONG for sheet bodies (returns perimeter and area x1000)."""
    uc = part.UnitCollection
    mf = part.MeasureManager.NewFaceProperties(uc.FindObject("SquareMilliMeter"), uc.FindObject("MilliMeter"), 0.999999,
                                               list(body.GetFaces()))
    try:
        return mf.Area, mf.Perimeter
    finally:
        mf.Dispose()


def free_edges(body):
    """Open-boundary edges (used by one face). 0 on a closed sheet set / solid."""
    return [e for e in body.GetEdges() if len(e.GetFaces()) == 1]


def dist_to(part, body, xyz):
    """Distance from a coordinate to a body: 0 means the surface passes through the point."""
    pt = part.Points.CreatePoint(nxh.P(*xyz))
    try:
        return nxh.UFS.Modeling.AskMinimumDist(pt.Tag, body.Tag, 0, [0.0, 0.0, 0.0], 0, [0.0, 0.0, 0.0])[0]
    finally:
        nxh.S.UpdateManager.AddToDeleteList(pt)


def normal_at(face, xyz):
    parm, _pnt = nxh.UFS.Modeling.AskFaceParm(face.Tag, [float(v) for v in xyz])
    return list(nxh.UFS.Modeling.AskFaceProps(face.Tag, parm)[5])


def check(name, got, want, tol):
    ok = abs(got - want) <= tol
    res["checks"].append({"name": name, "got": round(got, 4), "want": round(want, 4), "tol": tol, "ok": ok})
    return ok


def start_of(sec):
    _c, p, v = sec.GetStartAndDirection()
    return [round(p.X, 3), round(p.Y, 3), round(p.Z, 3)], [round(v.X, 3), round(v.Y, 3), round(v.Z, 3)]


# ---------------------------------------------------------------- section helper
def string(part, curves=None, edges=None, start=(0, 0, 0), seed=None):
    """ONE section string = one Section object. `start` is a point near the END OF THE SEED where the
    string must start; the direction runs away from it. Check with start_of() before committing."""
    sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
    sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
    fill(sec, part, curves, edges, start, seed)
    return sec


def fill(sec, part, curves=None, edges=None, start=(0, 0, 0), seed=None):
    """Populate a section (also the read-only ones owned by a builder: BoundingCurves, CurveChain, Guide...)."""
    rules = []
    if curves:
        rules.append(part.ScRuleFactory.CreateRuleCurveDumb(list(curves)))
    if edges:
        rules.append(part.ScRuleFactory.CreateRuleEdgeDumb(list(edges)))
    first = seed if seed is not None else (list(curves)[0] if curves else list(edges)[0])
    sec.AddToSection(rules, first, NULLO, NULLO, nxh.P(*start), NXOpen.Section.Mode.Create, False)


# ---------------------------------------------------------------- recipes
def through_curves(part, sections, solid=False, preserve=False, align=None, g1_first=None, g1_last=None):
    """Loft through 2+ section strings. g1_first/g1_last: faces the end section must be tangent to."""
    b = part.Features.CreateThroughCurvesBuilder(NF)
    try:
        b.PreserveShape = preserve          # True keeps sharp corners (one face per segment), needs Parameter alignment
        b.PatchType = TCB.PatchTypes.Multiple
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.BodyPreference = TCB.BodyPreferenceTypes.Solid if solid else TCB.BodyPreferenceTypes.Sheet
        for s in sections:
            b.SectionsList.Append(s)
        b.Alignment.SetSections(list(sections))
        if align is not None:
            b.Alignment.AlignType = align   # GU.AlignmentMethodBuilder.Type.Parameter / ArcLength / ...
        for cont, faces in ((b.FirstSectionContinuity, g1_first), (b.LastSectionContinuity, g1_last)):
            if faces:
                cont.ContinuityType = GU.Continuity.ContinuityTypes.G1
                cont.ConstraintFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


def curve_mesh(part, primaries, crosses):
    b = part.Features.CreateThroughCurveMeshBuilder(NF)
    try:
        b.PositionTolerance = 0.01          # batch default is 0.0254
        b.IntersectionTolerance = 0.01      # batch default is 0.02
        b.TangentTolerance = 0.5
        for s in primaries:
            b.PrimaryCurvesList.Append(s)
        for s in crosses:
            b.CrossCurvesList.Append(s)
        return b.CommitFeature()
    finally:
        b.Destroy()


def swept(part, sections, guides, solid=False, scaling=None):
    """Swept: 1-3 guides, 1+ sections. Two guides need scaling = Uniform or Lateral."""
    b = part.Features.CreateSweptBuilder(NXOpen.Features.Swept.Null)
    try:
        b.G0Tolerance = 0.01
        b.G1Tolerance = 0.5
        for s in sections:
            b.SectionList.Append(s)
        b.AlignmentMethod.SetSections(list(sections))
        for g in guides:
            b.GuideList.Append(g)
        if scaling is not None:
            b.ScalingMethod.ScalingOption = scaling
        b.BodyPreference.BodyType = SOLID if solid else SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


def sweep_along_guide(part, sec_curves, sec_start, guide_curves, guide_start, sheet=False):
    """One section along one guide. Gives analytic faces (planes/cylinders) where Swept gives B-surfaces."""
    b = part.Features.CreateSweepAlongGuideBuilder(NXOpen.Features.SweepAlongGuide.Null)
    try:
        b.Section.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        fill(b.Section, part, curves=sec_curves, start=sec_start)       # Section and Guide are read-only: fill in place
        b.Guide.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        fill(b.Guide, part, curves=guide_curves, start=guide_start)
        b.FirstOffset.RightHandSide = "0"
        b.SecondOffset.RightHandSide = "0"
        b.FeatureOptions.BodyType = SHEET if sheet else SOLID
        b.BooleanOperation.Type = nxh.BOOL.Create
        return b.CommitFeature()
    finally:
        b.Destroy()


def studio_surface(part, sections, guides=()):
    b = part.Features.CreateStudioSurfaceBuilder(NF)
    try:
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.IntersectionTolerance = 0.01
        for s in sections:
            b.SectionList.Append(s)
        b.AlignmentMethod.SetSections(list(sections))
        for g in guides:
            b.GuideList.Append(g)
        b.BodyPreference.BodyType = SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


def extrude_sheet(part, curves, vec, start, end, hp, edges=None):
    """Extrude as a SHEET even when the section is closed (FeatureOptions.BodyType)."""
    b = part.Features.CreateExtrudeBuilder(NF)
    try:
        b.Section = string(part, curves=curves, edges=edges, start=hp)
        b.Direction = nxh.direction(part, vec)
        b.Limits.StartExtend.Value.RightHandSide = str(start)
        b.Limits.EndExtend.Value.RightHandSide = str(end)
        b.FeatureOptions.BodyType = SHEET
        b.BooleanOperation.Type = nxh.BOOL.Create
        return b.CommitFeature()
    finally:
        b.Destroy()


def revolve_sheet(part, curves, hp, origin, vec, a0=0, a1=360):
    b = part.Features.CreateRevolveBuilder(NF)
    try:
        b.Section = string(part, curves=curves, start=hp)
        b.Axis = nxh.axis(part, origin, vec)
        b.Limits.StartExtend.Value.RightHandSide = str(a0)
        b.Limits.EndExtend.Value.RightHandSide = str(a1)
        b.FeatureOptions.BodyType = SHEET
        b.BooleanOperation.Type = nxh.BOOL.Create
        b.Tolerance = 0.01
        return b.CommitFeature()
    finally:
        b.Destroy()


def bounded_plane(part, curves=None, edges=None, hp=(0, 0, 0)):
    """Planar cap from a closed coplanar loop of curves/edges; inner closed loops become holes."""
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        fill(b.BoundingCurves, part, curves, edges, hp)
        return b.CommitFeature()
    finally:
        b.Destroy()


def fill_surface(part, curves=None, edges=None, hp=(0, 0, 0), g1=False, patch=False):
    """Fill Surface (FillHole): closed chain of curves/edges, planar or not. patch=True sews it into the sheet."""
    FHB = NXOpen.Features.FillHoleBuilder
    b = part.Features.FreeformSurfaceCollection.CreateFillHoleBuilder(NXOpen.Features.FillHole.Null)
    try:
        b.Tolerance = 0.01
        # set BEFORE filling the chain: each edge takes the default that is current when it is added
        b.DefaultEdgeContinuity = FHB.ContinuityTypes.G1 if g1 else FHB.ContinuityTypes.G0
        b.CurveChain.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        fill(b.CurveChain, part, curves, edges, hp)
        b.Patch = patch
        return b.CommitFeature()
    finally:
        b.Destroy()


def n_sided(part, curves, hp, triangular=False):
    NSB = NXOpen.Features.NSidedSurfaceBuilder
    b = part.Features.CreateNSidedSurfaceBuilder(NXOpen.Features.NSidedSurface.Null)
    try:
        b.PositionTolerance = 0.01      # all three default to 0.0 in batch -> "Unable to build surface."
        b.TangentTolerance = 0.5
        b.CurvatureTolerance = 0.5
        b.Type = NSB.SurfaceType.TriangularPatch if triangular else NSB.SurfaceType.TrimmedPatch
        b.OuterLoop.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        fill(b.OuterLoop, part, curves=curves, start=hp)
        b.UVOrientation = NSB.UVOrientationType.Area
        if not triangular:
            b.TrimToBoundary = True     # False leaves the untrimmed rectangular patch
        return b.CommitFeature()
    finally:
        b.Destroy()


def sew(part, target, tools, tol=0.01):
    """Sew sheets. A closed set becomes a SOLID. Returns the feature; ALWAYS check IsSolidBody / free edges."""
    b = part.Features.CreateSewBuilder(NF)
    try:
        b.Tolerance = tol
        b.TargetBodies.Add(target)
        for t in tools:
            b.ToolBodies.Add(t)
        return b.Commit()
    finally:
        b.Destroy()


def ruled(part, c1, hp1, c2, hp2):
    """Ruled: the builder's own FirstSection/SecondSection are filled in place."""
    b = part.Features.CreateRuledBuilder(NF)
    try:
        b.PositionTolerance = 0.01
        for sec, c, hp in ((b.FirstSection, c1, hp1), (b.SecondSection, c2, hp2)):
            sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
            fill(sec, part, curves=c, start=hp)
        b.AlignmentMethod.SetSections([b.FirstSection, b.SecondSection])
        b.BodyPreference.BodyType = SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


# ---------------------------------------------------------------- the verified examples
def main():
    part = nxh.new_part(os.path.join(OUT, "surf_build.prt"))
    n = res["notes"]
    cone_half = math.pi * 30 * math.sqrt(1700) / 2          # half frustum R20 -> R10, h 40
    frustum_v = math.pi * 40 / 3 * 700

    # 1 open loft, correct and twisted --------------------------------------------------
    a1 = nxh.arc(part, (0, 0, 0), (1, 0, 0), (0, 1, 0), 20, 0.0, math.pi)
    a2 = nxh.arc(part, (0, 0, 40), (1, 0, 0), (0, 1, 0), 10, 0.0, math.pi)
    s1 = string(part, curves=[a1], start=(20, 0, 0))
    s2 = string(part, curves=[a2], start=(-10, 0, 40))      # wrong end on purpose
    n["s2_wrong"] = start_of(s2)
    s2.ReverseDirection()                                     # repair: both strings now run the same way
    n["s2_reversed"] = start_of(s2)
    body = through_curves(part, [s1, s2]).GetBodies()[0]
    check("loft_open_area", sheet_area(part, body)[0], cone_half, 0.2)
    check("loft_open_free_edges", len(free_edges(body)), 4, 0)

    # 2 closed sections -> solid, start points aligned with SetStartAndDirection ---------
    c1 = nxh.circle(part, (100, 0, 0), 20)
    c2 = nxh.circle(part, (100, 0, 40), 10)
    s1 = string(part, curves=c1, start=(120, 0, 0))
    s2 = string(part, curves=c2, start=(90, 0, 40))          # starts 180 deg away: would give V = 12567, a valid solid
    _c, _p, v = s1.GetStartAndDirection()
    s2.SetStartAndDirection(c2[0], nxh.P(110, 0, 40), nxh.V(v.X, v.Y, v.Z))
    body = through_curves(part, [s1, s2], solid=True).GetBodies()[0]
    check("loft_closed_is_solid", int(body.IsSolidBody), 1, 0)
    check("loft_closed_volume", nxh.volume(part, body), frustum_v, 3.0)

    # 3 polygon sections, sharp corners kept, start corner repaired -----------------------
    q1 = nxh.rect(part, 200, 0, 240, 40, 0.0)
    q2 = nxh.rect(part, 210, 10, 230, 30, 30.0)
    s1 = string(part, curves=q1, start=(200, 0, 0), seed=q1[0])
    s2 = string(part, curves=q2, start=(230, 10, 30), seed=q2[1])     # starts one corner too far (V would be 20000)
    s2.SetStartCurveOfClosedLoop(0, nxh.P(220, 10, 30))               # any point on the wanted start curve
    n["square_s2_fixed"] = start_of(s2)
    body = through_curves(part, [s1, s2], solid=True, preserve=True).GetBodies()[0]
    check("loft_square_volume", nxh.volume(part, body), 28000.0, 0.01)
    check("loft_square_faces", len(body.GetFaces()), 6, 0)

    # 4 G1 to an existing sheet --------------------------------------------------------------
    base = extrude_sheet(part, [nxh.line(part, (300, 0, 0), (340, 0, 0))], (0, -1, 0), 0, 30, (300, 0, 0)).GetBodies()[0]
    edge = [e for e in base.GetEdges() if abs(nxh.bbox(e)[1]) < 1e-6 and abs(nxh.bbox(e)[4]) < 1e-6][0]
    s1 = string(part, edges=[edge], start=(300, 0, 0))
    s2 = string(part, curves=[nxh.line(part, (300, 30, 20), (340, 30, 20))], start=(300, 30, 20))
    body = through_curves(part, [s1, s2], g1_first=base.GetFaces()).GetBodies()[0]
    nz = abs(normal_at(body.GetFaces()[0], (320, 0, 0))[2])
    check("loft_g1_normal_z_at_shared_edge", nz, 1.0, 1e-4)             # G0 gives 0.832
    check("loft_g1_area", sheet_area(part, body)[0], 1514.04, 0.5)      # G0 plane would be 1442.22

    # 5 through curve mesh ---------------------------------------------------------------------
    t0, t1 = math.atan2(15, 20), math.pi - math.atan2(15, 20)
    p1 = nxh.arc(part, (0, 220, -15), (0, 1, 0), (0, 0, 1), 25, t0, t1)
    p2 = nxh.arc(part, (60, 220, -15), (0, 1, 0), (0, 0, 1), 25, t0, t1)
    x1 = nxh.line(part, (0, 200, 0), (60, 200, 0))
    x2 = nxh.line(part, (0, 240, 0), (60, 240, 0))
    cyl_patch = 2 * math.asin(20 / 25) * 25 * 60
    body = curve_mesh(part, [string(part, curves=[p1], start=(0, 200, 0)), string(part, curves=[p2], start=(60, 200, 0))],
                      [string(part, curves=[x1], start=(0, 200, 0)), string(part, curves=[x2], start=(0, 240, 0))]).GetBodies()[0]
    check("mesh_area", sheet_area(part, body)[0], cyl_patch, 0.5)
    check("mesh_apex_on_surface", dist_to(part, body, (30, 220, 10)), 0.0, 0.005)

    # 6 studio surface, same wireframe -----------------------------------------------------------
    p1 = nxh.arc(part, (100, 220, -15), (0, 1, 0), (0, 0, 1), 25, t0, t1)
    p2 = nxh.arc(part, (160, 220, -15), (0, 1, 0), (0, 0, 1), 25, t0, t1)
    x1 = nxh.line(part, (100, 200, 0), (160, 200, 0))
    x2 = nxh.line(part, (100, 240, 0), (160, 240, 0))
    body = studio_surface(part, [string(part, curves=[p1], start=(100, 200, 0)), string(part, curves=[p2], start=(160, 200, 0))],
                          [string(part, curves=[x1], start=(100, 200, 0)), string(part, curves=[x2], start=(100, 240, 0))]).GetBodies()[0]
    check("studio_area", sheet_area(part, body)[0], cyl_patch, 0.5)

    # 7 swept: open section 1 guide; closed section on an arc guide; 2 guides -------------------------
    a = nxh.arc(part, (0, 300, 0), (0, 1, 0), (0, 0, 1), 5, 0.0, math.pi)
    g = nxh.line(part, (0, 305, 0), (50, 305, 0))
    body = swept(part, [string(part, curves=[a], start=(0, 305, 0))], [string(part, curves=[g], start=(0, 305, 0))]).GetBodies()[0]
    check("swept_open_area", sheet_area(part, body)[0], math.pi * 5 * 50, 0.05)
    c = nxh.circle(part, (100, 300, 0), 4, xdir=(0, 1, 0), ydir=(0, 0, 1))
    g = nxh.arc(part, (100, 350, 0), (1, 0, 0), (0, 1, 0), 50, -math.pi / 2, 0.0)
    body = swept(part, [string(part, curves=c, start=(100, 304, 0))], [string(part, curves=[g], start=(100, 300, 0))], solid=True).GetBodies()[0]
    check("swept_solid_volume", nxh.volume(part, body), math.pi * 16 * math.pi / 2 * 50, 8.0)   # B-surface: ~0.15 % low
    sl = nxh.line(part, (200, 300, 0), (200, 320, 0))
    g1 = nxh.line(part, (200, 300, 0), (260, 300, 0))
    g2 = nxh.line(part, (200, 320, 0), (260, 340, 10))
    body = swept(part, [string(part, curves=[sl], start=(200, 300, 0))],
                 [string(part, curves=[g1], start=(200, 300, 0)), string(part, curves=[g2], start=(200, 320, 0))],
                 scaling=GU.ScalingMethodBuilder.ScalingOptions.Uniform).GetBodies()[0]
    check("swept_2guides_mid_on_surface", dist_to(part, body, (230, 315, 2.5)), 0.0, 0.005)
    check("swept_2guides_guide2_on_surface", dist_to(part, body, (230, 330, 5)), 0.0, 0.005)

    # 8 sweep along guide (exact analytic faces) -----------------------------------------------------------
    rc = nxh.polyline(part, [(0, 397, -2), (0, 403, -2), (0, 403, 2), (0, 397, 2)])
    gd = [nxh.line(part, (0, 400, 0), (40, 400, 0)), nxh.arc(part, (40, 420, 0), (1, 0, 0), (0, 1, 0), 20, -math.pi / 2, 0.0)]
    body = sweep_along_guide(part, rc, (0, 397, -2), gd, (0, 400, 0)).GetBodies()[0]
    check("sweep_guide_volume", nxh.volume(part, body), 24 * (40 + math.pi / 2 * 20), 0.01)

    # 9 sheet-mode revolve and extrude ---------------------------------------------------------------------------
    body = revolve_sheet(part, [nxh.line(part, (20, 500, 0), (10, 500, 40))], (20, 500, 0), (0, 500, 0), (0, 0, 1)).GetBodies()[0]
    check("revolve_sheet_area", sheet_area(part, body)[0], 2 * cone_half, 0.01)
    check("revolve_sheet_is_sheet", int(body.IsSolidBody), 0, 0)
    body = extrude_sheet(part, nxh.rect(part, 100, 500, 140, 530, 0.0), (0, 0, 1), 0, 10, (100, 500, 0)).GetBodies()[0]
    check("extrude_closed_as_sheet_area", sheet_area(part, body)[0], 1400.0, 0.01)

    # 10 bounded plane with a hole, fill surface (separate / patched in), n-sided ------------------------------------
    loop = nxh.rect(part, 0, 600, 40, 630, 0.0) + nxh.circle(part, (20, 615, 0), 5)
    plate = bounded_plane(part, curves=loop, hp=(0, 600, 0)).GetBodies()[0]
    check("bounded_plane_with_hole_area", sheet_area(part, plate)[0], 1200 - math.pi * 25, 0.01)
    hole = [e for e in plate.GetEdges() if e.SolidEdgeType == NXOpen.Edge.EdgeType.Circular]
    f = fill_surface(part, edges=hole, hp=(25, 615, 0), g1=True, patch=True)
    check("fill_patch_area_after", sheet_area(part, plate)[0], 1200.0, 0.01)
    check("fill_patch_faces", len(plate.GetFaces()), 2, 0)
    p1 = nxh.arc(part, (100, 620, -15), (0, 1, 0), (0, 0, 1), 25, t0, t1)
    p2 = nxh.arc(part, (160, 620, -15), (0, 1, 0), (0, 0, 1), 25, t0, t1)
    x1 = nxh.line(part, (100, 600, 0), (160, 600, 0))
    x2 = nxh.line(part, (100, 640, 0), (160, 640, 0))
    body = fill_surface(part, curves=[p1, x2, p2, x1], hp=(100, 600, 0)).GetBodies()[0]
    check("fill_nonplanar_area", sheet_area(part, body)[0], cyl_patch, 0.5)
    pts = [(200, 600, 0), (240, 600, 0), (250, 620, 0), (220, 640, 0), (190, 620, 0)]
    body = n_sided(part, nxh.polyline(part, pts), pts[0]).GetBodies()[0]
    check("n_sided_trimmed_area", sheet_area(part, body)[0], 1600.0, 0.05)

    # 11 lofted tube + two bounded-plane caps + sew -> solid ---------------------------------------------------------------
    c1 = nxh.circle(part, (0, 700, 0), 20)
    c2 = nxh.circle(part, (0, 700, 40), 10)
    tube = through_curves(part, [string(part, curves=c1, start=(20, 700, 0)), string(part, curves=c2, start=(10, 700, 40))]).GetBodies()[0]
    check("tube_free_edges_before", len(free_edges(tube)), 2, 0)
    lo = [e for e in tube.GetEdges() if abs(nxh.bbox(e)[5]) < 1e-6]
    hi = [e for e in tube.GetEdges() if abs(nxh.bbox(e)[2] - 40) < 1e-6]
    caps = [bounded_plane(part, edges=lo, hp=(20, 700, 0)).GetBodies()[0], bounded_plane(part, edges=hi, hp=(10, 700, 40)).GetBodies()[0]]
    n_sheets = len(nxh.sheets(part))
    sewn = sew(part, tube, caps).GetBodies()[0]
    check("sew_closed_is_solid", int(sewn.IsSolidBody), 1, 0)
    check("sew_closed_free_edges", len(free_edges(sewn)), 0, 0)
    check("sew_closed_volume", nxh.volume(part, sewn), frustum_v, 3.0)
    check("sew_consumed_3_sheets", n_sheets - len(nxh.sheets(part)), 3, 0)

    # 12 ruled (experimental: recorded, not part of PASS/FAIL) ---------------------------------------------------------------
    m = nxh.mark("ruled", False)
    try:
        r1 = nxh.arc(part, (100, 700, 0), (1, 0, 0), (0, 1, 0), 20, 0.0, math.pi)
        r2 = nxh.arc(part, (100, 700, 40), (1, 0, 0), (0, 1, 0), 10, 0.0, math.pi)
        body = ruled(part, [r1], (120, 700, 0), [r2], (110, 700, 40)).GetBodies()[0]
        n["ruled"] = {"area": sheet_area(part, body)[0], "want": cone_half, "faces": nxh.face_census(body)}
    except Exception as e:  # noqa: BLE001
        n["ruled"] = {"error": str(e)}
        nxh.undo_to(m)

    n["feature_errors"] = nxh.feature_errors(part)
    check("no_feature_errors", len(n["feature_errors"]), 0, 0)
    nxh.save(part)


try:
    main()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res["result"] = "PASS" if "error" not in res and res["checks"] and all(c["ok"] for c in res["checks"]) else "FAIL"
nxh.write_json(os.path.join(OUT, "surf_build.json"), res)
