"""Centrifugal (radial) impeller on NX 2206: blades between a revolved hub surface and a shroud line.

    run_journal.ps1 -Script blade_centrifugal.py -WorkDir <out> -JArgs <out>   ->  <out>\\blade_centrifugal.json

Method: hub = Revolve of a closed meridional sketch (conical hub surface); blade camber sheet = Through Curves
(ruled) between two arc sketches, one below the hub surface and one above the shroud line, the upper one
leaned; Thicken by an expression; trim = Intersect with the revolved passage envelope whose top edge is the
shroud line; Pattern Geometry of the blade body; one Unite; root blend.

C1  sketches DOF 0, hub volume by Pappus, blade blank solid.
C2  wheel: one solid, 7 blades by section and topology, blade tips on the shroud line, thickness, outlet radius.
C3  regeneration: count 7 -> 9, outlet width b2 10 -> 12, thickness 2.5 -> 3, back.
C4  STEP + validity gate.
C5  imported STEP of this impeller: 7 -> 5 blades with Delete Face + Pattern Geometry + Unite.
"""
import math
import os
import sys
import time
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
sys.path.insert(0, os.environ.get("NXBLADE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import nxh  # noqa: E402
import nxf  # noqa: E402
import nxblade as nb  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "blade_centrifugal.log"))
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
N, THK, R_BORE, R_OUT, R_NOSE, H_HUB, H_RIM, B2, R_EYE, R_LE = 7, 2.5, 5.0, 50.0, 12.0, 40.0, 5.0, 10.0, 26.0, 16.0
st = {}


def shroud_z(r, b2=B2):
    """Height of the shroud line at radius r (straight line from (r_out, h_rim + b2) to (r_eye, h_hub))."""
    return H_RIM + b2 + (R_OUT - r) * (H_HUB - H_RIM - b2) / (R_OUT - R_EYE)


def hub_z(r):
    return H_RIM + (R_OUT - r) * (H_HUB - H_RIM) / (R_OUT - R_NOSE)


def tips_on_shroud(part, groups, b2):
    """Every blade has a conical tip face whose edges lie on the shroud line: max |z - shroud_z(r)| over all of them."""
    worst, n = 0.0, 0
    for g in groups:
        cones = [f for f in g["faces"] if nxh.face_data(f)[0] == nxh.CONE]
        n += 1 if cones else 0
        for f in cones:
            for e in f.GetEdges():
                for p in nb.edge_points(e, 7):
                    r, _a, z = nb.cyl(p)
                    worst = max(worst, abs(z - shroud_z(r, b2)))
    return n, worst


def measure(part, body, n, thk, b2, tag):
    groups, hubf = nb.blade_groups(part, body)
    ext = nb.radial_extent(body)
    n_tip, dev = tips_on_shroud(part, groups, b2)
    r_mid = 35.0
    m = {"solids": len(nxh.solids(part)), "errors": nxh.feature_errors(part), "examine": nxh.examine_geometry(part, body),
         "groups": len(groups), "faces_per_blade": sorted(len(g["faces"]) for g in groups), "hub_faces": len(hubf),
         "section_count": nb.blade_count_section(part, body, r_mid, hub_z(r_mid) + 3, shroud_z(r_mid, b2) - 2),
         "tips_on_shroud": n_tip, "tip_deviation": dev, "r_out": ext[1], "z_top": ext[3], "volume": nxh.volume(part, body),
         "thickness": [nb.blade_thickness(part, g) for g in groups],
         "spacing": [round((groups[(i + 1) % len(groups)]["angle"] - groups[i]["angle"]) % 360.0, 3) for i in range(len(groups))]}
    res["notes"][tag] = m
    chk.true(tag + " one solid, no feature errors", m["solids"] == 1 and not m["errors"], m["errors"])
    chk.true(tag + " Examine Geometry clean", all(v == 0 for v in m["examine"].values()), m["examine"])
    chk.true(tag + " blade count by section in the passage = %d and by topology = %d" % (n, n), m["section_count"] == n and m["groups"] == n,
             (m["section_count"], m["groups"]))
    chk.true(tag + " blades identical and evenly spaced", m["faces_per_blade"][0] == m["faces_per_blade"][-1]
             and all(abs(a - 360.0 / n) < 0.01 for a in m["spacing"]), (m["faces_per_blade"], m["spacing"]))
    chk.true(tag + " every blade has a tip face on the shroud cone", m["tips_on_shroud"] == n, m["tips_on_shroud"])
    chk(tag + " blade tips lie on the shroud line (max deviation)", m["tip_deviation"], 0.0, 1e-5)
    chk(tag + " outlet radius", m["r_out"], R_OUT, 1e-6)
    chk(tag + " blade thickness (min over blades)", min(m["thickness"]), thk, 1e-4)
    chk(tag + " blade thickness (max over blades)", max(m["thickness"]), thk, 1e-4)
    return m


def c_build():
    part = nxh.new_part(os.path.join(OUT, "blade_centrifugal.prt"))
    for name, val, unit in (("n_blades", N, None), ("thk", THK, "mm"), ("r_bore", R_BORE, "mm"), ("r_out", R_OUT, "mm"),
                            ("r_nose", R_NOSE, "mm"), ("h_hub", H_HUB, "mm"), ("h_rim", H_RIM, "mm"), ("b2", B2, "mm"),
                            ("r_eye", R_EYE, "mm"), ("r_le", R_LE, "mm"), ("root_r", 1.0, "mm")):
        nxh.expr(part, name, val, unit)
    dat = nxh.Datums(part)
    axis = nxh.axis(part, (0, 0, 0), (0, 0, 1))

    # C1 hub
    sk, sst, sec = nb.profile_sketch(part, [("r_bore", 0), ("r_out", 0), ("r_out", "h_rim"), ("r_nose", "h_hub"), ("r_bore", "h_hub")], "SK_HUB")
    chk.true("C1 hub profile sketch fully constrained", sst["status"] == "WellConstrained" and sst["dof"] == 0, sst)
    hub_f = nxf.revolve(part, sec, axis)
    hub = hub_f.GetBodies()[0]
    v_hub = nxh.volume(part, hub)
    # Pappus by pieces: rim disc + cone frustum + nose disc - bore
    v_exp = (math.pi * R_OUT ** 2 * H_RIM + math.pi * (H_HUB - H_RIM) / 3.0 * (R_OUT ** 2 + R_OUT * R_NOSE + R_NOSE ** 2)
             - math.pi * R_BORE ** 2 * H_HUB)
    chk("C1 hub volume (disc + frustum - bore)", v_hub, v_exp, 1e-3)

    # C1 camber sheet: ruled between two arcs, the upper one leaned
    z_up = H_HUB + 4.0
    sk_lo, st_lo, arc_lo = nb.arc_sketch(part, dat.xy, 0.0, (9.0, 3.0), (54.0, -24.0), 48.0, "SK_CAMBER_HUB")
    _pf, pl_up = nxf.datum_plane(part, "offset", [dat.xy], "h_hub+4", name="PL_ABOVE_SHROUD")
    sk_up, st_up, arc_up = nb.arc_sketch(part, pl_up, z_up, (9.0, 7.0), (55.0, -16.0), 48.0, "SK_CAMBER_SHROUD")
    chk.true("C1 both camber arc sketches fully constrained", st_lo["dof"] == 0 and st_up["dof"] == 0, (st_lo, st_up))
    s_lo = nb.feature_section(part, sk_lo.Feature, arc_lo, (9.0, 3.0, 0.0))
    s_up = nb.feature_section(part, sk_up.Feature, arc_up, (9.0, 7.0, z_up))
    loft = nxf.through_curves(part, [s_lo, s_up])
    sheet = loft.GetBodies()[0]
    chk.true("C1 camber sheet: both arcs' ends on it (not twisted)", max(abs(nxh.dist_to(part, sheet, p)) for p in
             ((9.0, 3.0, 0.0), (54.0, -24.0, 0.0), (9.0, 7.0, z_up), (55.0, -16.0, z_up))) < 1e-4)
    before = list(part.Bodies)
    thicken = nxf.thicken(part, sheet, "thk/2", "-thk/2")
    blade = [b for b in nxh.new_bodies(part, before) if b.IsSolidBody][0]
    v_blank = nxh.volume(part, blade)
    chk("C1 blade blank volume = sheet area x thk (relative)", v_blank / (nxh.sheet_area(part, sheet)[0] * THK), 1.0, 2e-3)

    # trim by the revolved passage envelope: leading edge radius, outlet radius, shroud line, bottom inside the hub
    sk_e, est, sec_e = nb.profile_sketch(part, [("r_le", 1), ("r_out", 1), ("r_out", "h_rim+b2"), ("r_eye", "h_hub"), ("r_le", "h_hub")], "SK_ENVELOPE")
    chk.true("C1 envelope sketch fully constrained", est["status"] == "WellConstrained" and est["dof"] == 0, est)
    nxf.revolve(part, sec_e, axis, op=nxh.BOOL.Intersect, target=blade)
    v_blade = nxh.volume(part, blade)
    chk.true("C1 envelope cut the blank to one blade body", v_blade < v_blank and len(nxh.solids(part)) == 2, (v_blank, v_blade))

    # C2 set
    pf, uf = nb.pattern_and_unite(part, hub, blade, thicken, "n_blades")
    body = hub
    v_plain = nxh.volume(part, body)
    bf, err = nxh.attempt("root blend", lambda: nb.root_blend(part, uf, "root_r"), log=log)
    res["notes"]["root_blend"] = "built" if not err else "NOT BUILT: " + err
    v_nom = nxh.volume(part, body)
    if not err:
        chk.true("C2 root blend added material", v_nom > v_plain, v_nom - v_plain)
    measure(part, body, N, THK, B2, "C2")
    res["notes"]["volumes"] = {"hub": v_hub, "blank": v_blank, "blade": v_blade, "wheel_plain": v_plain, "wheel": v_nom}

    # C3 regeneration
    nxh.set_expr(part, "n_blades", 9)
    nxh.update()
    m9 = measure(part, body, 9, THK, B2, "C3 n_blades 7->9:")
    chk("C3 added volume per blade is independent of the count", (m9["volume"] - v_hub) / 9, (v_nom - v_hub) / N, 0.02)
    nxh.set_expr(part, "n_blades", N)
    nxh.set_expr(part, "b2", 12)
    nxh.set_expr(part, "thk", 3)
    nxh.update()
    measure(part, body, N, 3.0, 12.0, "C3 b2 10->12, thk 2.5->3:")
    nxh.set_expr(part, "b2", B2)
    nxh.set_expr(part, "thk", THK)
    nxh.update()
    chk("C3 back to nominal: volume reproduced (relative)", nxh.volume(part, body) / v_nom, 1.0, 1e-6)
    chk.true("C3 back to nominal: no feature errors", not nxh.feature_errors(part), nxh.feature_errors(part))
    res["features"] = [(f["name"], f["type"]) for f in nxh.feature_table(part)]

    # C4 deliverable
    st["stp"] = nxf.step_export(part, os.path.join(OUT, "blade_centrifugal.step"))
    st["v7"] = v_nom
    gate = nb.step_gate(st["stp"])
    res["notes"]["gate"] = gate
    if gate.get("available"):
        chk.true("C4 STEP passes the validity gate (valid, watertight, 1 solid)",
                 gate.get("valid") and gate.get("watertight") and gate.get("solids") == 1, {k: gate.get(k) for k in ("valid", "watertight", "solids", "errors")})
        chk("C4 STEP volume = NX volume (relative)", gate["volume"] / v_nom, 1.0, 1e-4)
    else:
        rt = nxf.step_roundtrip_check(st["stp"], OUT, "blade_centrifugal", restore=part, part=part)
        chk.true("C4 STEP round trip (gate interpreter not installed)", rt.get("match") and rt.get("healthy"), rt.get("max_rel"))
    # reference for C5: the same model at 5 blades
    nxh.set_expr(part, "n_blades", 5)
    nxh.update()
    st["v5"] = nxh.volume(part, body)
    nxh.close_all()


def c_imported_edit():
    part = nxh.new_part(os.path.join(OUT, "blade_centrifugal_import.prt"))
    body = nxf.step_import(part, st["stp"], os.path.join(OUT, "blade_centrifugal_tmp.prt"))[0]
    groups, hubf = nb.blade_groups(part, body)
    res["notes"]["imported"] = {"faces": len(body.GetFaces()), "groups": len(groups), "faces_per_blade": sorted(len(g["faces"]) for g in groups),
                                "hub_faces": len(hubf), "volume": nxh.volume(part, body)}
    chk.true("C5 imported impeller: 7 blade groups by topology", len(groups) == 7, len(groups))
    t = time.time()
    nb.strip_blades(part, body, keep=1)
    one = {"count": nb.blade_count_section(part, body, 35.0, hub_z(35.0) + 3, shroud_z(35.0) - 2), "examine": nxh.examine_geometry(part, body),
           "faces": len(body.GetFaces()), "sec": round(time.time() - t, 1)}
    res["notes"]["stripped_to_one"] = one
    chk.true("C5 Delete Face on 6 blades: one blade left, body healthy", one["count"] == 1 and all(v == 0 for v in one["examine"].values()), one)
    # Pattern Face on this vane (its outlet end runs out into the rim cylinder face): recorded, then undone
    g1, _h = nb.blade_groups(part, body)
    m = nxh.mark("pattern face", False)
    try:
        nb.pattern_faces(part, g1[0]["faces"], 5)
        gp, _h = nb.blade_groups(part, body)
        res["notes"]["pattern_face"] = {"result": "built", "groups": len(gp), "volume": nxh.volume(part, body),
                                        "count": nb.blade_count_section(part, body, 35.0, hub_z(35.0) + 3, shroud_z(35.0) - 2),
                                        "examine": nxh.examine_geometry(part, body)}
    except Exception as e:  # noqa: BLE001
        res["notes"]["pattern_face"] = {"result": "NOT WORKING", "error": str(e)[:400]}
    try:
        nxh.undo_to(m)
    except Exception:  # noqa: BLE001
        pass
    t = time.time()
    nb.repattern(part, body, 5)
    g5, _h = nb.blade_groups(part, body)
    out = {"solids": len(nxh.solids(part)), "groups": len(g5), "volume": nxh.volume(part, body), "examine": nxh.examine_geometry(part, body),
           "section_count": nb.blade_count_section(part, body, 35.0, hub_z(35.0) + 3, shroud_z(35.0) - 2),
           "spacing": [round((g5[(i + 1) % len(g5)]["angle"] - g5[i]["angle"]) % 360.0, 3) for i in range(len(g5))], "sec": round(time.time() - t, 1)}
    res["notes"]["repatterned_5"] = out
    chk.true("C5 re-pattern x5 + Unite: one solid, 5 blades, evenly spaced", out["solids"] == 1 and out["groups"] == 5 and out["section_count"] == 5
             and all(abs(a - 72.0) < 0.01 for a in out["spacing"]), out)
    chk.true("C5 result: Examine Geometry clean", all(v == 0 for v in out["examine"].values()), out["examine"])
    chk("C5 result = the parametric 5-blade impeller (relative volume)", out["volume"] / st["v5"], 1.0, 1e-4)
    stp = nxf.step_export(part, os.path.join(OUT, "blade_centrifugal_5.step"))
    gate = nb.step_gate(stp)
    res["notes"]["gate_edit"] = gate
    if gate.get("available"):
        chk.true("C5 edited STEP passes the validity gate", gate.get("valid") and gate.get("watertight") and gate.get("solids") == 1,
                 {k: gate.get(k) for k in ("valid", "watertight", "solids", "errors")})
    nxh.close_all()


for name, fn in (("C1-C4", c_build), ("C5", c_imported_edit)):
    try:
        fn()
    except Exception:  # noqa: BLE001
        res.setdefault("errors", {})[name] = traceback.format_exc()
        chk.true(name + " ran without an exception", False, traceback.format_exc()[-400:])
        try:
            nxh.close_all()
        except Exception:  # noqa: BLE001
            pass
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "blade_centrifugal.json"), res)
