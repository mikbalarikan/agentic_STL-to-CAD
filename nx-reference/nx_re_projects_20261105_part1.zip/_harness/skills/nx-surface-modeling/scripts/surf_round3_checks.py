"""Surface recipes, round 3 (NX 2206 batch): parametric lofts, Studio / Curve Mesh continuity, Swept options,
Trim Sheet regions, Section Surface, Face Blend shapes, offsets of quilts.

Parametric loft from associative Line features and from constrained sketches (edit + update), section start
with and without a seed, Studio Surface G1, Curve Mesh G1 on cross boundaries (roles swapped), Swept with
3 guides / scaling / face-normal orientation / filleted corner guide, Trim Sheet with several regions,
Trim and Extend flags, Section Surface (circular, two guides + radius), Face Blend conic and contact curves,
Law Extension miter Blend, N-Sided Trim to Boundary, Offset Surface / Thicken of quilts and tight radii.

Usage: run_journal surf_round3_checks.py -args <output folder>   (needs the nx-journal-core nxh.py)
Writes <output folder>/surf_round3_checks.json ("result", "checks", "notes").
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
# Continuous Auto Dimensioning off BEFORE any sketch is created: with it on (the batch default) GetStatus() reads
# WellConstrained / 0 for any sketch, so the DOF checks below would prove nothing (nx-journal-core section 5).
nxh.S.Preferences.Sketch.ContinuousAutoDimensioning = False
GU =NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
SK = NXOpen.Sketch
TCB = NXOpen.Features.ThroughCurvesBuilder
CT = GU.Continuity.ContinuityTypes
SHEET, SOLID = GU.FeatureOptions.BodyStyle.Sheet, GU.FeatureOptions.BodyStyle.Solid
ONLY_CURVES = NXOpen.Section.AllowTypes.OnlyCurves
chk = nxh.Check()
notes = {}


def trial(name, fn, *a):
    m = nxh.mark("trial " + name, False)
    try:
        fn(*a)
    except Exception:  # noqa: BLE001
        notes[name + "_error"] = traceback.format_exc()[-900:]
        chk.true(name + " ran", False, notes[name + "_error"][-250:])
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass


def attempt(fn, *a, **k):
    """(result, None) or (None, error text); rolls the model back on failure."""
    m = nxh.mark("attempt", False)
    try:
        return fn(*a, **k), None
    except Exception as e:  # noqa: BLE001
        nxh.undo_to(m)
        return None, str(e)


def counts(part):
    return len(nxh.sheets(part)), len(nxh.solids(part))


def start_of(sec):
    _c, p, v = sec.GetStartAndDirection()
    return [round(p.X, 3), round(p.Y, 3), round(p.Z, 3)], [round(v.X, 3), round(v.Y, 3), round(v.Z, 3)]


def describe(part, b):
    d = {"solid": b.IsSolidBody, "faces": len(b.GetFaces()), "free": len(nxh.free_edges(b)), "bbox": nxh.bbox(b),
         "area": round(nxh.sheet_area(part, b)[0], 3)}
    if b.IsSolidBody:
        d["volume"] = round(nxh.volume(part, b), 3)
    return d


# ---------------------------------------------------------------- curve / sketch inputs
def assoc_line(part, p0, p1):
    """Associative Line feature between two smart points (coordinates may be expression formulas)."""
    LB = NXOpen.Features.AssociativeLineBuilder
    b = part.BaseFeatures.CreateAssociativeLineBuilder(NXOpen.Features.AssociativeLine.Null)
    try:
        b.StartPointOptions = LB.StartOption.Point
        b.StartPoint.Value = nxh.point(part, *p0)
        b.EndPointOptions = LB.EndOption.Point
        b.EndPoint.Value = nxh.point(part, *p1)
        b.Associative = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)][0]


def assoc_rect(part, x0, w, h, z):
    """Closed rectangle of 4 associative lines, centred on (x0, 0), on the plane z (all formulas)."""
    c = [(f"{x0}-({w})/2", f"-({h})/2", z), (f"{x0}+({w})/2", f"-({h})/2", z), (f"{x0}+({w})/2", f"({h})/2", z), (f"{x0}-({w})/2", f"({h})/2", z)]
    out = [assoc_line(part, c[i], c[(i + 1) % 4]) for i in range(4)]
    return [f for f, _c in out], [cv for _f, cv in out]


def rect_sketch(part, plane, haxis, origin, name, w, h, z, fw, fh, dat):
    """Rectangle w x h centred on the datum Z axis in a sketch on `plane`; size driven by formulas fw, fh."""
    sb = part.Sketches.CreateSimpleSketchInPlaceBuilder()
    try:
        sb.UseWorkPartOrigin = False
        d = part.Directions.CreateDirection(haxis, NXOpen.Sense.Forward, nxh.UPD)
        xf = part.Xforms.CreateXformByPlaneXDirPoint(plane, d, origin, nxh.UPD, 0.625, False, False)
        sb.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, nxh.UPD)
        sb.HorizontalReference.Value = haxis
        sk = sb.Commit()
    finally:
        sb.Destroy()
    sk.Activate(SK.ViewReorient.FalseValue)
    sk.SetName(name)

    def q(x, y):
        return nxh.P(x, y, z)

    def cg(geom):
        g = SK.ConstraintGeometry()
        g.Geometry = geom
        g.PointType = SK.ConstraintPointType.NotSet
        g.SplineDefiningPointIndex = 0
        return g

    def dg(geom, assoc=None, hp=None):
        g = SK.DimensionGeometry()
        g.Geometry = geom
        g.AssocType = assoc if assoc is not None else SK.AssocType.NotSet
        g.AssocValue = 0
        g.HelpPoint = hp if hp is not None else nxh.P(0, 0, 0)
        g.View = NXOpen.NXObject.Null
        return g

    e = [part.Curves.CreateLine(q(-w / 2, -h / 2), q(w / 2, -h / 2)), part.Curves.CreateLine(q(w / 2, -h / 2), q(w / 2, h / 2)),
         part.Curves.CreateLine(q(w / 2, h / 2), q(-w / 2, h / 2)), part.Curves.CreateLine(q(-w / 2, h / 2), q(-w / 2, -h / 2))]
    for c in e:
        sk.AddGeometry(c, SK.InferConstraintsOption.InferCoincidentConstraints)
    sk.CreateHorizontalConstraint(cg(e[0]))
    sk.CreateHorizontalConstraint(cg(e[2]))
    sk.CreateVerticalConstraint(cg(e[1]))
    sk.CreateVerticalConstraint(cg(e[3]))
    for ref, hp, ln, org, formula in ((dat.y, nxh.P(0, 50, 0), e[1], q(w / 4, -h / 2 - 8), f"({fw})/2"),
                                      (dat.y, nxh.P(0, 50, 0), e[3], q(-w / 4, -h / 2 - 8), f"({fw})/2"),
                                      (dat.x, nxh.P(50, 0, 0), e[0], q(w / 2 + 8, -h / 4), f"({fh})/2"),
                                      (dat.x, nxh.P(50, 0, 0), e[2], q(w / 2 + 8, h / 4), f"({fh})/2")):
        c = sk.CreateDimension(SK.ConstraintType.PerpendicularDim, dg(ref, None, hp), dg(ln, SK.AssocType.StartPoint), org,
                               NXOpen.Expression.Null)
        c.AssociatedExpression.RightHandSide = formula
    sk.Update()
    status, dof = sk.GetStatus()
    n_auto = 0                                            # automatic dimensions = open DOF NX closed by itself (0 expected)
    for c in sk.GetAllConstraintsOfType(SK.ConstraintClass.Dimension, SK.ConstraintType.NoCon):
        ds = getattr(c, "DimensionState", None)
        if ds is not None and ds == type(c).DimensionStateType.Automatic:
            n_auto += 1
    sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
    return sk, e, {"status": str(status), "dof": dof + n_auto, "auto_dims": n_auto}


# ---------------------------------------------------------------- recipes
def through_curves(part, sections, solid=False, preserve=False):
    b = part.Features.CreateThroughCurvesBuilder(NF)
    try:
        b.PreserveShape = preserve
        b.PatchType = TCB.PatchTypes.Multiple
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.BodyPreference = TCB.BodyPreferenceTypes.Solid if solid else TCB.BodyPreferenceTypes.Sheet
        for s in sections:
            b.SectionsList.Append(s)
        b.Alignment.SetSections(list(sections))
        return b.CommitFeature()
    finally:
        b.Destroy()


def set_g1(part, cont, faces):
    cont.ContinuityType = CT.G1
    cont.ConstraintFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)


def studio_surface(part, sections, guides, first=None, last=None, first_guide=None, last_guide=None):
    """first / last = faces the first / last SECTION must be tangent to (G1); first_guide / last_guide likewise."""
    b = part.Features.CreateStudioSurfaceBuilder(NF)
    try:
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.IntersectionTolerance = 0.01
        for s in sections:
            b.SectionList.Append(s)
        b.AlignmentMethod.SetSections(list(sections))
        for g in guides:
            b.GuideList.Append(g)
        if first:
            set_g1(part, b.FirstSectionContinuity, first)
        if last:
            set_g1(part, b.LastSectionContinuity, last)
        if first_guide:
            set_g1(part, b.FirstGuideContinuity, first_guide)
        if last_guide:
            set_g1(part, b.LastGuideContinuity, last_guide)
        b.BodyPreference.BodyType = SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


def curve_mesh(part, primaries, crosses, first_primary=None, last_primary=None, first_cross=None, last_cross=None):
    b = part.Features.CreateThroughCurveMeshBuilder(NF)
    try:
        b.PositionTolerance = 0.01
        b.IntersectionTolerance = 0.01
        b.TangentTolerance = 0.5
        for s in primaries:
            b.PrimaryCurvesList.Append(s)
        for s in crosses:
            b.CrossCurvesList.Append(s)
        for cont, faces in ((b.FirstPrimaryContinuity, first_primary), (b.LastPrimaryContinuity, last_primary),
                            (b.FirstCrossContinuity, first_cross), (b.LastCrossContinuity, last_cross)):
            if faces:
                set_g1(part, cont, faces)
        return b.CommitFeature()
    finally:
        b.Destroy()


def swept(part, sections, guides, solid=False, setup=None):
    """setup(builder) sets ScalingMethod / OrientationMethod / Spine before the commit."""
    b = part.Features.CreateSweptBuilder(NXOpen.Features.Swept.Null)
    try:
        b.G0Tolerance = 0.01
        b.G1Tolerance = 0.5
        for s in sections:
            b.SectionList.Append(s)
        b.AlignmentMethod.SetSections(list(sections))
        for g in guides:
            b.GuideList.Append(g)
        b.BodyPreference.BodyType = SOLID if solid else SHEET
        if setup:
            setup(b)
        return b.CommitFeature()
    finally:
        b.Destroy()


def bounded_plane(part, curves=None, edges=None, hp=(0, 0, 0)):
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.BoundingCurves, curves=curves, edges=edges, help_point=hp)
        return b.CommitFeature()
    finally:
        b.Destroy()


def plane_sheet(part, x0, y0, w=40, h=30, z=0.0):
    return bounded_plane(part, curves=nxh.rect(part, x0, y0, x0 + w, y0 + h, z), hp=(x0, y0, z)).GetBodies()[0]


def sheet_extrude(part, curves, vec, dist, hp):
    return nxh.extrude(part, nxh.section(part, curves=curves, help_point=hp), vec, 0, dist, sheet=True).GetBodies()[0]


def half_cyl(part, x0, y0, r=5, length=50):
    a = nxh.arc(part, (x0, y0, 0), (0, 1, 0), (0, 0, 1), r, 0.0, math.pi)
    return sheet_extrude(part, [a], (1, 0, 0), length, (x0, y0 + r, 0))


def sew(part, target, tools, tol=0.01):
    b = part.Features.CreateSewBuilder(NF)
    try:
        b.Tolerance = tol
        b.TargetBodies.Add(target)
        for t in tools:
            b.ToolBodies.Add(t)
        return b.Commit()
    finally:
        b.Destroy()


def trim_sheet(part, body, region_pts, keep, curve_strings, hp_list):
    """Several region points and several boundary strings in ONE Trim Sheet."""
    TSB = NXOpen.Features.TrimSheetBuilder
    b = part.Features.CreateTrimsheetBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.TargetBodies.Add(body)
        for xyz in region_pts:
            b.Regions.Append(part.CreateRegionPoint(part.Points.CreatePoint(nxh.P(*xyz)), body))
        b.KeepDiscardMethod = TSB.KeepDiscardOption.Keep if keep else TSB.KeepDiscardOption.Discard
        b.ExtendBoundaryObject = True
        for cs, hp in zip(curve_strings, hp_list):
            b.BoundaryObjects.Add(nxh.section(part, curves=cs, help_point=hp))
        return b.Commit()
    finally:
        b.Destroy()


def face_blend(part, faces1, faces2, rev1, rev2, setup):
    FBB = NXOpen.Features.FaceBlendBuilder
    b = part.Features.CreateFaceBlendBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FaceBlendDefineType = FBB.DefiningType.BlendTwoFace
        b.BlendType = FBB.Type.RollingBall
        b.FirstFaceCollector = nxh.collector(part, faces=faces1)
        b.SecondFaceCollector = nxh.collector(part, faces=faces2)
        b.ReverseFirstFaceNormal = rev1
        b.ReverseSecondFaceNormal = rev2
        setup(b, FBB)
        b.TrimInputFacesToBlendFaces = True
        b.SewAllFaces = True
        return b.CommitFeature()
    finally:
        b.Destroy()


def law_extension(part, face, edges, hp, length, angle, miter=None):
    LEB = NXOpen.Features.LawExtensionBuilderEx
    b = part.Features.CreateLawExtensionBuilderEx(NF)
    try:
        b.Type = LEB.Types.Faces
        b.DistanceTolerance = 0.01
        b.BaseProfile.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.BaseProfile, edges=edges, help_point=hp)
        b.Faces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb([face])], False)
        b.LengthLaw.LawType = GU.LawBuilder.Type.Constant
        b.LengthLaw.Value.RightHandSide = str(length)
        b.AngleLaw.LawType = GU.LawBuilder.Type.Constant
        b.AngleLaw.Value.RightHandSide = str(angle)
        if miter is not None:
            b.MiterOption = miter
        return b.CommitFeature()
    finally:
        b.Destroy()


def offset_surface(part, rule, dist, flip=False):
    b = part.Features.CreateOffsetSurfaceBuilder(NF)
    try:
        b.Tolerance = 0.01
        col = part.ScCollectors.CreateCollector()
        col.ReplaceRules([rule], False)
        b.FaceSets.Append(part.FaceSetOffsets.CreateFaceSet(str(dist), col, flip, 0))
        return b.CommitFeature()
    finally:
        b.Destroy()


def thicken(part, body, first, second=0, reverse=False):
    b = part.Features.CreateThickenBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(body)], False)
        b.FirstOffset.RightHandSide = str(first)
        b.SecondOffset.RightHandSide = str(second)
        b.ReverseDirection = reverse
        b.BooleanOperation.Type = nxh.BOOL.Create
        return b.CommitFeature()
    finally:
        b.Destroy()


def prismatoid(w1, h1, w2, h2, height):
    return height / 6.0 * (w1 * h1 + 4 * ((w1 + w2) / 2) * ((h1 + h2) / 2) + w2 * h2)


# ---------------------------------------------------------------- experiments
def t_parametric_assoc(part):
    """Loft between two rectangles of associative Line features; one CreateRuleCurveFeature rule per section."""
    for n, v in (("aw", 40), ("ah", 30), ("aw2", 20), ("ah2", 16), ("az", 30)):
        nxh.expr(part, n, v)
    f1, c1 = assoc_rect(part, 0, "aw", "ah", 0)
    f2, c2 = assoc_rect(part, 0, "aw2", "ah2", "az")
    R = part.ScRuleFactory
    # where does a rule-only section start?
    probe = {}
    for label, hp, seed in (("no_seed_hp_corner_A", (-20, -15, 0), None), ("no_seed_hp_corner_C", (20, 15, 0), None),
                            ("no_seed_hp_far_away", (500, 500, 0), None), ("seed_line0_hp_corner_A", (-20, -15, 0), c1[0]),
                            ("seed_line0_hp_its_other_end", (20, -15, 0), c1[0]), ("seed_line2_hp_corner_C", (20, 15, 0), c1[2])):
        s, err = attempt(lambda: nxh.section(part, rules=[R.CreateRuleCurveFeature(f1)], help_point=hp, seed=seed))
        probe[label] = start_of(s) if s is not None else {"error": err}
    notes["rule_only_section_start"] = probe
    chk.true("seeded rule section starts at the seed end nearest the help point",
             probe["seed_line0_hp_corner_A"][0] == [-20.0, -15.0, 0.0] and probe["seed_line0_hp_its_other_end"][0] == [20.0, -15.0, 0.0],
             probe)
    s1 = nxh.section(part, rules=[R.CreateRuleCurveFeature(f1)], help_point=(-20, -15, 0), seed=c1[0])
    s2 = nxh.section(part, rules=[R.CreateRuleCurveFeature(f2)], help_point=(-10, -8, 30), seed=c2[0])
    body = through_curves(part, [s1, s2], solid=True, preserve=True).GetBodies()[0]
    chk("assoc-line loft: volume", nxh.volume(part, body), prismatoid(40, 30, 20, 16, 30), 0.05)
    nxh.set_expr(part, "aw", 50)
    nxh.set_expr(part, "az", 40)
    nxh.update()
    chk("assoc-line loft after aw 40->50, az 30->40: volume", nxh.volume(part, body), prismatoid(50, 30, 20, 16, 40), 0.05)
    chk("assoc-line loft after edit: top at z = 40", nxh.bbox(body)[5], 40.0, 1e-4)


def t_parametric_sketch(part):
    """Loft between two sketches (CreateRuleCurveFeature([sketch.Feature])), second sketch on a driven datum plane."""
    dat = nxh.Datums(part)
    for n, v in (("sk_w", 40), ("sk_h", 30), ("sk_w2", 20), ("sk_h2", 16), ("sk_z", 30)):
        nxh.expr(part, n, v)
    sk1, e1, st1 = rect_sketch(part, dat.xy, dat.x, dat.origin, "SKT_BASE", 40.0, 30.0, 0.0, "sk_w", "sk_h", dat)
    _fp, dp = nxh.datum_plane(part, (0, 0, "sk_z"), (0, 0, 1), "TOP_PLANE")
    sk2, e2, st2 = rect_sketch(part, dp, dat.x, nxh.point(part, 0, 0, "sk_z"), "SKT_TOP", 20.0, 16.0, 30.0, "sk_w2", "sk_h2", dat)
    notes["sketch_status"] = {"base": st1, "top": st2}
    chk("base sketch fully constrained (dof)", st1["dof"], 0, 0)
    chk("top sketch fully constrained (dof)", st2["dof"], 0, 0)
    R = part.ScRuleFactory
    s1 = nxh.section(part, rules=[R.CreateRuleCurveFeature([sk1.Feature])], help_point=(-20, -15, 0), seed=e1[0])
    s2 = nxh.section(part, rules=[R.CreateRuleCurveFeature([sk2.Feature])], help_point=(-10, -8, 30), seed=e2[0])
    notes["sketch_section_starts"] = [start_of(s1), start_of(s2)]
    body = through_curves(part, [s1, s2], solid=True, preserve=True).GetBodies()[0]
    chk("sketch loft: volume", nxh.volume(part, body), prismatoid(40, 30, 20, 16, 30), 0.05)
    nxh.set_expr(part, "sk_w", 50)
    nxh.set_expr(part, "sk_z", 40)
    nxh.update()
    chk("sketch loft after sk_w 40->50, sk_z 30->40: volume", nxh.volume(part, body), prismatoid(50, 30, 20, 16, 40), 0.05)
    chk("sketch loft after edit: top at z = 40", nxh.bbox(body)[5], 40.0, 1e-4)
    notes["feature_errors_after_sketch_edit"] = nxh.feature_errors(part)


def neighbours(part, x0, y0):
    """Plane sheet A (edge y=y0, z=0) and arc-extruded sheet B (edge y=y0+40, z 10..18), plus S-shaped strings."""
    th = math.asin(20 / 42.5)
    t0 = math.atan2(52.25, 30)
    sa = sheet_extrude(part, [nxh.line(part, (x0, y0, 0), (x0 + 60, y0, 0))], (0, -1, 0), 20, (x0, y0, 0))
    ab = nxh.arc(part, (x0 + 30, y0 + 40, -42.25), (1, 0, 0), (0, 0, 1), 60.25, t0, math.pi - t0)
    sb = sheet_extrude(part, [ab], (0, 1, 0), 20, (x0, y0 + 40, 10))
    ea = [e for e in sa.GetEdges() if abs(nxh.bbox(e)[1] - y0) < 1e-6 and abs(nxh.bbox(e)[4] - y0) < 1e-6][0]
    eb = [e for e in sb.GetEdges() if abs(nxh.bbox(e)[1] - y0 - 40) < 1e-6 and abs(nxh.bbox(e)[4] - y0 - 40) < 1e-6][0]

    def s_string(x):
        c = [nxh.arc(part, (x, y0, 42.5), (0, 1, 0), (0, 0, 1), 42.5, -math.pi / 2, -math.pi / 2 + th),
             nxh.arc(part, (x, y0 + 40, -32.5), (0, 1, 0), (0, 0, 1), 42.5, math.pi / 2, math.pi / 2 + th)]
        return nxh.section(part, curves=c, help_point=(x, y0, 0), seed=c[0])

    pa = [(x0 + 15, y0, 0), (x0 + 30, y0, 0), (x0 + 45, y0, 0)]
    pb = [(x, y0 + 40, -42.25 + math.sqrt(60.25 ** 2 - (x - x0 - 30) ** 2)) for x in (x0 + 15, x0 + 30, x0 + 45)]
    edge_a = lambda: nxh.section(part, edges=[ea], help_point=(x0, y0, 0))            # noqa: E731
    edge_b = lambda: nxh.section(part, edges=[eb], help_point=(x0, y0 + 40, 10))      # noqa: E731
    return sa, sb, edge_a, edge_b, s_string, pa, pb


def t_studio_and_mesh(part):
    out = {}
    # Studio Surface on the same wireframe, four ways
    for i, key in enumerate(("studio_edges_as_sections_g0", "studio_edges_as_sections_g1", "studio_edges_as_guides_g1",
                             "studio_sections_only_g1")):
        x0 = i * 100.0
        sa, sb, edge_a, edge_b, s_string, pa, pb = neighbours(part, x0, 0)
        fa, fb = sa.GetFaces(), sb.GetFaces()
        if key == "studio_edges_as_sections_g0":
            make = lambda: studio_surface(part, [edge_a(), edge_b()], [s_string(x0), s_string(x0 + 60)])                         # noqa: E731
        elif key == "studio_edges_as_sections_g1":
            make = lambda: studio_surface(part, [edge_a(), edge_b()], [s_string(x0), s_string(x0 + 60)], first=fa, last=fb)       # noqa: E731
        elif key == "studio_edges_as_guides_g1":
            make = lambda: studio_surface(part, [s_string(x0), s_string(x0 + 60)], [edge_a(), edge_b()], first_guide=fa, last_guide=fb)  # noqa: E731
        else:
            make = lambda: studio_surface(part, [edge_a(), edge_b()], [], first=fa, last=fb)                                       # noqa: E731
        feat, err = attempt(make)
        if err:
            out[key] = {"error": err}
            continue
        body = feat.GetBodies()[0]
        f = body.GetFaces()[0]
        out[key] = {"dev_first": round(nxh.g1_deviation(fa[0], f, pa), 4), "dev_last": round(nxh.g1_deviation(fb[0], f, pb), 4),
                    "area": round(nxh.sheet_area(part, body)[0], 3)}
    out["studio_g0"] = out["studio_edges_as_sections_g0"]
    good = [k for k in ("studio_edges_as_sections_g1", "studio_edges_as_guides_g1", "studio_sections_only_g1")
            if "error" not in out[k] and max(out[k]["dev_first"], out[k]["dev_last"]) < 0.1]
    out["studio_g1_variants_tangent_at_both_neighbours"] = good
    out["studio_g1"] = out[good[0]] if good else {"dev_first": 99.0, "dev_last": 99.0}
    # Curve Mesh, both role assignments on the SAME neighbours
    x0 = 200.0
    sa, sb, edge_a, edge_b, s_string, pa, pb = neighbours(part, x0, 0)
    m1 = curve_mesh(part, [edge_a(), edge_b()], [s_string(x0), s_string(x0 + 60)],
                    first_primary=sa.GetFaces(), last_primary=sb.GetFaces()).GetBodies()[0]
    m2 = curve_mesh(part, [s_string(x0), s_string(x0 + 60)], [edge_a(), edge_b()],
                    first_cross=sa.GetFaces(), last_cross=sb.GetFaces()).GetBodies()[0]
    for key, body in (("mesh_edges_as_primaries_g1", m1), ("mesh_edges_as_crosses_g1", m2)):
        f = body.GetFaces()[0]
        out[key] = {"dev_at_A": round(nxh.g1_deviation(sa.GetFaces()[0], f, pa), 4),
                    "dev_at_B": round(nxh.g1_deviation(sb.GetFaces()[0], f, pb), 4),
                    "area": round(nxh.sheet_area(part, body)[0], 3)}
    gaps = []
    for fx in (0.25, 0.5, 0.75):
        for fy in (0.25, 0.5, 0.75):
            parm, pnt = nxh.UFS.Modeling.AskFaceParm(m1.GetFaces()[0].Tag, [x0 + 60 * fx, 40 * fy, 5.0])
            gaps.append(nxh.dist_to(part, m2, list(pnt)))
    out["max_gap_between_the_two_meshes"] = round(max(gaps), 4)
    notes["studio_and_mesh"] = out
    chk("studio G1: first section tangent to its neighbour", out["studio_g1"]["dev_first"], 0.0, 0.1)
    chk("studio G1: last section tangent to its neighbour", out["studio_g1"]["dev_last"], 0.0, 0.1)
    chk.true("studio G0: not tangent (> 1 deg)", max(out["studio_g0"]["dev_first"], out["studio_g0"]["dev_last"]) > 1.0, out["studio_g0"])
    chk("mesh, neighbour edges as CROSS strings, G1 on both cross boundaries: tangent at A", out["mesh_edges_as_crosses_g1"]["dev_at_A"], 0.0, 0.1)
    chk("mesh, neighbour edges as CROSS strings, G1 on both cross boundaries: tangent at B", out["mesh_edges_as_crosses_g1"]["dev_at_B"], 0.0, 0.1)


def t_swept_options(part):
    out = {}
    SO = GU.ScalingMethodBuilder.ScalingOptions
    OO = GU.OrientationMethodBuilder.OrientationOptions

    def sec(curves, hp):
        return nxh.section(part, curves=curves, help_point=hp, seed=curves[0])

    # three guides, V-shaped section touching all three
    v = [nxh.line(part, (0, 100, 0), (0, 110, 3)), nxh.line(part, (0, 110, 3), (0, 120, 0))]
    g = [nxh.line(part, (0, 100, 0), (60, 100, 0)), nxh.line(part, (0, 110, 3), (60, 110, 8)), nxh.line(part, (0, 120, 0), (60, 125, 0))]
    body, err = attempt(lambda: swept(part, [sec(v, (0, 100, 0))], [sec([c], (0, c.StartPoint.Y, c.StartPoint.Z)) for c in g]).GetBodies()[0])
    out["three_guides"] = {"error": err} if err else {"ends_on_surface": [round(nxh.dist_to(part, body, p), 4) for p in ((60, 100, 0), (60, 110, 8), (60, 125, 0), (30, 110, 5.5))],
                                                        "faces": len(body.GetFaces())}
    chk.true("swept with 3 guides: every guide end and the middle guide's midpoint lie on the surface",
             not err and max(out["three_guides"]["ends_on_surface"]) < 0.01, out["three_guides"])

    # scaling, one guide
    def scaled(x0, setup):
        c = nxh.circle(part, (x0, 200, 0), 4, xdir=(0, 1, 0), ydir=(0, 0, 1))
        gl = nxh.line(part, (x0, 200, 0), (x0 + 50, 200, 0))
        return swept(part, [sec(c, (x0, 204, 0))], [sec([gl], (x0, 200, 0))], solid=True, setup=setup).GetBodies()[0]

    def constant2(b):
        b.ScalingMethod.ScalingOption = SO.Constant
        b.ScalingMethod.ScaleFactor = 2.0

    def blend12(b):
        b.ScalingMethod.ScalingOption = SO.ByBlendingFunction
        b.ScalingMethod.BlendingFunctionType = GU.ScalingMethodBuilder.BlendingFunctionTypes.Linear
        b.ScalingMethod.StartBlendScaleFactor = 1.0
        b.ScalingMethod.EndBlendScaleFactor = 2.0

    body, err = attempt(scaled, 0.0, constant2)
    out["scale_constant_2"] = {"error": err} if err else {"volume": round(nxh.volume(part, body), 3)}
    chk.true("swept Constant scaling, ScaleFactor 2: R4 -> R8 cylinder", not err and abs(out["scale_constant_2"]["volume"] - math.pi * 64 * 50) < 1.0,
             out["scale_constant_2"])
    body, err = attempt(scaled, 100.0, blend12)
    out["scale_blend_1_to_2"] = {"error": err} if err else {"volume": round(nxh.volume(part, body), 3),
                                                             "want_frustum": round(math.pi * 50 / 3 * (16 + 32 + 64), 3)}
    chk.true("swept ByBlendingFunction 1 -> 2 (Linear): R4 -> R8 frustum",
             not err and abs(out["scale_blend_1_to_2"]["volume"] - math.pi * 50 / 3 * 112) < 2.0, out["scale_blend_1_to_2"])

    # orientation by face normals: straight guide = edge of a twisted ruled face
    def twisted(x0):
        s1 = nxh.section(part, curves=[nxh.line(part, (x0, 300, 0), (x0, 310, 0))], help_point=(x0, 300, 0))
        s2 = nxh.section(part, curves=[nxh.line(part, (x0 + 60, 300, 0), (x0 + 60, 307, 7))], help_point=(x0 + 60, 300, 0))
        face_body = through_curves(part, [s1, s2]).GetBodies()[0]
        edge = [e for e in face_body.GetEdges() if abs(nxh.bbox(e)[1] - 300) < 1e-6 and abs(nxh.bbox(e)[4] - 300) < 1e-6
                and abs(nxh.bbox(e)[5]) < 1e-6][0]
        return face_body, edge

    for i, key in enumerate(("fixed", "face_normals", "vector_z")):
        x0 = i * 100.0
        fb, edge = twisted(x0)
        n0 = nxh.normal_at(fb.GetFaces()[0], (x0, 300, 0))
        n1 = nxh.normal_at(fb.GetFaces()[0], (x0 + 60, 300, 0))
        sl = nxh.line(part, (x0, 300, 0), (x0 + 10 * n0[0], 300 + 10 * n0[1], 10 * n0[2]))

        def setup(b, key=key, fb=fb):
            if key == "face_normals":
                b.OrientationMethod.OrientationOption = OO.ByFaceNormals
                b.OrientationMethod.Faces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(fb.GetFaces()))], False)
            elif key == "vector_z":
                b.OrientationMethod.OrientationOption = OO.ByVectorDirection
                b.OrientationMethod.OrientationVector = nxh.direction(part, (0, 0, 1))

        body, err = attempt(lambda: swept(part, [sec([sl], (x0, 300, 0))], [nxh.section(part, edges=[edge], help_point=(x0, 300, 0))], setup=setup).GetBodies()[0])
        if err:
            out["orientation_" + key] = {"error": err}
            continue
        end_translated = (x0 + 60 + 10 * n0[0], 300 + 10 * n0[1], 10 * n0[2])
        end_along_normal = (x0 + 60 + 10 * n1[0], 300 + 10 * n1[1], 10 * n1[2])
        end_opposite = (x0 + 60 - 10 * n1[0], 300 - 10 * n1[1], -10 * n1[2])
        out["orientation_" + key] = {"n_start": [round(v, 3) for v in n0], "n_end": [round(v, 3) for v in n1],
                                     "gap_to_translated_end": round(nxh.dist_to(part, body, end_translated), 4),
                                     "gap_to_face_normal_end": round(min(nxh.dist_to(part, body, end_along_normal), nxh.dist_to(part, body, end_opposite)), 4)}
    notes["swept_options"] = out
    fx, fn = out.get("orientation_fixed", {}), out.get("orientation_face_normals", {})
    chk.true("swept Fixed orientation on a straight guide: the section is translated", fx.get("gap_to_translated_end", 9) < 0.01, fx)
    chk.true("swept ByFaceNormals: the section follows the face normal along the guide", fn.get("gap_to_face_normal_end", 9) < 0.05, fn)

    # spine + 2 guides
    def with_spine(b):
        b.ScalingMethod.ScalingOption = SO.Uniform
        b.Spine.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.Spine, curves=[nxh.line(part, (0, 400, 0), (60, 400, 0))], help_point=(0, 400, 0))

    sl = nxh.line(part, (0, 400, 0), (0, 420, 0))
    g1 = nxh.line(part, (0, 400, 0), (60, 400, 0))
    g2 = nxh.line(part, (0, 420, 0), (60, 440, 10))
    body, err = attempt(lambda: swept(part, [sec([sl], (0, 400, 0))], [sec([g1], (0, 400, 0)), sec([g2], (0, 420, 0))], setup=with_spine).GetBodies()[0])
    out["two_guides_with_spine"] = {"error": err} if err else {"area": round(nxh.sheet_area(part, body)[0], 3),
                                                                "g2_mid_on": round(nxh.dist_to(part, body, (30, 430, 5)), 4)}
    chk.true("swept with 2 guides + spine builds and contains guide 2", not err and out["two_guides_with_spine"]["g2_mid_on"] < 0.01,
             out["two_guides_with_spine"])

    # corner fillet on the guide: large enough vs smaller than the section half-width (section 6 x 4)
    for i, r in enumerate((20.0, 2.0)):
        x0 = 100.0 + i * 150.0
        rc = nxh.polyline(part, [(x0 - 3, 500, -2), (x0 + 3, 500, -2), (x0 + 3, 500, 2), (x0 - 3, 500, 2)])
        gl = [nxh.line(part, (x0, 500, 0), (x0, 600 - r, 0)),
              nxh.arc(part, (x0, 600 - r, r), (0, 1, 0), (0, 0, 1), r, -math.pi / 2, 0.0),
              nxh.line(part, (x0, 600, r), (x0, 600, 100))]
        body, err = attempt(lambda: swept(part, [sec(rc, (x0 - 3, 500, -2))], [nxh.section(part, curves=gl, help_point=(x0, 500, 0), seed=gl[0])],
                                          solid=True).GetBodies()[0])
        length = (100 - r) + math.pi / 2 * r + (100 - r)
        out[f"filleted_L_guide_R{r:g}"] = {"error": err} if err else {"volume": round(nxh.volume(part, body), 3), "want": round(24 * length, 3),
                                                                        "examine": nxh.examine_geometry(part, body)}
    small = out["filleted_L_guide_R2"]
    chk.true("swept on an L guide with an R2 fillet (< section half-width 3): commits, but Examine Geometry flags the body",
             "error" in small or small["examine"].get("BodyConsistency", 0) > 0 or small["examine"].get("FaceSelfIntersection", 0) > 0, small)
    big = out["filleted_L_guide_R20"]
    chk.true("swept on an L guide with an R20 corner fillet builds (volume = area x length within 0.5 %)",
             "error" not in big and abs(big["volume"] - big["want"]) < 0.005 * big["want"], big)


def t_trim_regions(part):
    out = {}
    # (a) discard the middle strip: the two outer strips survive
    sh = plane_sheet(part, 0, 700)
    l1 = nxh.line(part, (10, 695, 0), (10, 735, 0))
    l2 = nxh.line(part, (30, 695, 0), (30, 735, 0))
    n0 = counts(part)
    f, err = attempt(trim_sheet, part, sh, [(20, 715, 0)], False, [[l1], [l2]], [(10, 695, 0), (30, 695, 0)])
    out["discard_middle_strip"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()], "sheets": [n0[0], counts(part)[0]]}
    # (b) keep two outer strips with two region points
    sh = plane_sheet(part, 100, 700)
    l1 = nxh.line(part, (110, 695, 0), (110, 735, 0))
    l2 = nxh.line(part, (130, 695, 0), (130, 735, 0))
    f, err = attempt(trim_sheet, part, sh, [(105, 715, 0), (135, 715, 0)], True, [[l1], [l2]], [(110, 695, 0), (130, 695, 0)])
    out["keep_two_disjoint_strips"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()]}
    # (c) keep two ADJACENT quadrants (connected result) with two region points
    sh = plane_sheet(part, 200, 700)
    l1 = nxh.line(part, (220, 695, 0), (220, 735, 0))
    l2 = nxh.line(part, (195, 715, 0), (245, 715, 0))
    f, err = attempt(trim_sheet, part, sh, [(210, 707, 0), (230, 707, 0)], True, [[l1], [l2]], [(220, 695, 0), (195, 715, 0)])
    out["keep_two_adjacent_quadrants"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()]}
    # (d) the same result with one feature per cut
    sh = plane_sheet(part, 300, 700)
    l2 = nxh.line(part, (295, 715, 0), (345, 715, 0))
    f, err = attempt(trim_sheet, part, sh, [(310, 707, 0)], True, [[l2]], [(295, 715, 0)])
    out["one_boundary_keep_lower_half"] = {"error": err} if err else describe(part, sh)
    # (e)-(g) the same three cases with BOTH boundary curves in ONE section (one boundary object)
    for i, (key, pts, keep) in enumerate((("one_section_discard_middle_strip", [(420, 715, 0)], False),
                                          ("one_section_keep_two_outer_strips", [(505, 715, 0), (535, 715, 0)], True),
                                          ("one_section_keep_one_outer_strip", [(605, 715, 0)], True))):
        x0 = 400.0 + i * 100.0
        sh = plane_sheet(part, x0, 700)
        both = [nxh.line(part, (x0 + 10, 695, 0), (x0 + 10, 735, 0)), nxh.line(part, (x0 + 30, 695, 0), (x0 + 30, 735, 0))]
        n0 = counts(part)
        f, err = attempt(trim_sheet, part, sh, pts, keep, [both], [(x0 + 10, 695, 0)])
        out[key] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()], "sheets": [n0[0], counts(part)[0]],
                                                "target_after": describe(part, sh)}
    notes["trim_sheet_regions"] = out
    one = out["one_section_keep_one_outer_strip"]
    chk.true("trim sheet, both cutting curves in ONE boundary section: keeping one outer strip gives 10 x 30",
             "error" not in one and abs(one["target_after"]["area"] - 300.0) < 0.05, one)
    two = out["one_section_keep_two_outer_strips"]
    chk.true("trim sheet, ONE boundary section, two region points: both outer strips kept (area 600)",
             "error" not in two and abs(sum(b["area"] for b in two["bodies"]) - 600.0) < 0.05, two)
    d = out["one_section_discard_middle_strip"]
    chk.true("trim sheet, ONE boundary section: discarding the middle strip leaves both outer strips (area 600)",
             "error" not in d and abs(sum(b["area"] for b in d["bodies"]) - 600.0) < 0.05, d)
    sep = out["discard_middle_strip"]
    chk.true("trim sheet with the two curves added as SEPARATE boundary objects honours only one of them (area 300, not 600)",
             "error" not in sep and abs(sum(b["area"] for b in sep["bodies"]) - 300.0) < 0.05, sep)

    # Trim and Extend flags on crossing sheets
    TEB = NXOpen.Features.TrimAndExtendBuilder
    te = {}
    for i, (rt, rtool, arrow) in enumerate(((False, False, "Retain"), (False, True, "Retain"), (True, False, "Retain"), (True, True, "Retain"),
                                            (False, False, "Delete"), (False, True, "Delete"))):
        x0 = i * 100.0
        a = plane_sheet(part, x0, 800)
        up = sheet_extrude(part, [nxh.line(part, (x0 + 15, 800, -10), (x0 + 15, 830, -10))], (0, 0, 1), 20, (x0 + 15, 800, -10))

        def build(a=a, up=up, rt=rt, rtool=rtool, arrow=arrow):
            b = part.Features.TrimFeatureCollection.CreateTrimAndExtendBuilder(NXOpen.Features.TrimAndExtend.Null)
            try:
                b.DistanceTolerance = 0.01
                b.Operation = TEB.OperationType.MakeCorner
                b.TargetSelection.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(a)], False)
                b.ToolSelection.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(up)], False)
                b.ReverseTarget = rt
                b.ReverseTool = rtool
                b.ArrowSideOption = getattr(TEB.ArrowSideType, arrow)
                return b.CommitFeature()
            finally:
                b.Destroy()

        f, err = attempt(build)
        key = f"revTarget={rt} revTool={rtool} arrow={arrow}"
        if err:
            te[key] = {"error": err}
        else:
            bb = nxh.bbox(f.GetBodies()[0])
            te[key] = {"x": [round(bb[0] - x0, 2), round(bb[3] - x0, 2)], "z": [bb[2], bb[5]],
                       "area": round(nxh.sheet_area(part, f.GetBodies()[0])[0], 2)}
    notes["trim_and_extend_flags_crossing_sheets"] = te
    ff, ft, tf = (te.get(f"revTarget={a} revTool={b} arrow=Retain", {}) for a, b in ((False, False), (False, True), (True, False)))
    chk.true("make corner: ReverseTool keeps the other half of the TARGET sheet (x 15..40 -> 0..15)",
             ff.get("x") == [15.0, 40.0] and ft.get("x") == [0.0, 15.0] and ft.get("z") == ff.get("z"), [ff, ft])
    chk.true("make corner: ReverseTarget keeps the other half of the TOOL sheet (z 0..10 -> -10..0)",
             ff.get("z") == [0.0, 10.0] and tf.get("z") == [-10.0, 0.0] and tf.get("x") == ff.get("x"), [ff, tf])


def t_section_surface(part):
    """Section Surface, Circular > two guides + radius (the user's TwoPointRadius type), spine = start guide."""
    SSB = NXOpen.Features.SectionSurfaceBuilderEx
    out = {}
    for i, spine in enumerate(("curve", "vector")):
        y0 = 900.0 + i * 100.0
        g1 = nxh.line(part, (0, y0, 0), (60, y0, 0))
        g2 = nxh.line(part, (0, y0 + 20, 0), (60, y0 + 20, 0))

        def build(g1=g1, g2=g2, y0=y0, spine=spine):
            b = part.Features.CreateSectionSurfaceBuilderEx(NXOpen.Features.SectionSurface.Null)
            try:
                b.Type = SSB.Types.Circular
                b.CircularTypeMode = SSB.CircularType.TwoPointRadius
                b.G0Tolerance = 0.01
                b.G1Tolerance = 0.5
                for s, c, hp in ((b.SectionStartGuide, g1, (0, y0, 0)), (b.SectionEndGuide, g2, (0, y0 + 20, 0))):
                    s.SetAllowedEntityTypes(ONLY_CURVES)
                    nxh.fill_section(part, s, curves=[c], help_point=hp)
                if spine == "curve":
                    b.SpineType = SSB.Spine.ByCurve
                    b.SpineSection.SetAllowedEntityTypes(ONLY_CURVES)
                    nxh.fill_section(part, b.SpineSection, curves=[g1], help_point=(0, y0, 0))
                else:
                    b.SpineType = SSB.Spine.ByVector
                    b.SpineVector = nxh.direction(part, (1, 0, 0))
                b.RadiusLaw.LawType = GU.LawBuilder.Type.Constant
                b.RadiusLaw.Value.RightHandSide = "15"
                b.BodyTypePreference = SSB.BodyType.Sheet
                return b.CommitFeature()
            finally:
                b.Destroy()

        f, err = attempt(build)
        if err:
            out["spine_" + spine] = {"error": err}
            continue
        body = f.GetBodies()[0]
        face = body.GetFaces()[0]
        out["spine_" + spine] = {"area": round(nxh.sheet_area(part, body)[0], 3), "bbox": nxh.bbox(body),
                                 "types": nxh.face_census(body)["types"], "feature": [f.FeatureType, type(f).__name__, f.GetFeatureName()],
                                 "curvature_mid": round(nxh.max_curvature(face, (30, y0 + 10, 0)), 5),
                                 "guides_on_surface": [round(nxh.dist_to(part, body, (30, y0, 0)), 4), round(nxh.dist_to(part, body, (30, y0 + 20, 0)), 4)]}
    notes["section_surface_two_point_radius"] = out
    minor = 2 * math.asin(10 / 15.0) * 15 * 60
    ok = [k for k, v in out.items() if "error" not in v]
    chk.true("section surface (circular, 2 guides + radius 15) builds", bool(ok), out)
    if ok:
        r = out[ok[0]]
        chk.true("section surface passes through both guides", max(r["guides_on_surface"]) < 0.01, r)
        chk("section surface cross-section curvature = 1/15", r["curvature_mid"], 1 / 15.0, 0.002)
        chk.true("section surface area = arc length x 60 (minor %.1f or major %.1f arc)" % (minor, 2 * math.pi * 15 * 60 - minor),
                 min(abs(r["area"] - minor), abs(r["area"] - (2 * math.pi * 15 * 60 - minor))) < 2.0, r["area"])


def t_face_blend_shapes(part):
    out = {}

    def crossing(x0):
        a = plane_sheet(part, x0, 1100)
        up = sheet_extrude(part, [nxh.line(part, (x0 + 20, 1100, -10), (x0 + 20, 1130, -10))], (0, 0, 1), 20, (x0 + 20, 1100, -10))
        return a, up

    def conic_with(o1, o2):
        def conic(b, FBB):
            b.CrossSectionType = FBB.CrossSectionOption.Conic
            cc = b.ConicCrossSection
            cc.FirstOffset.RightHandSide = str(o1)
            cc.SecondOffset.RightHandSide = str(o2)
            cc.Rho.RightHandSide = "0.6"
        return conic

    # asymmetric conic blend: offsets on face 1 (horizontal, 20 available) and face 2 (upright, 10 available)
    for i, (o1, o2) in enumerate(((15, 5), (8, 4), (4, 8))):
        a, up = crossing(i * 100.0)
        f, err = attempt(face_blend, part, a.GetFaces(), up.GetFaces(), False, False, conic_with(o1, o2))
        if err:
            out[f"conic_{o1}_x_{o2}"] = {"error": err}
            continue
        body = f.GetBodies()[0]
        legs = {("horizontal" if abs(nxh.face_data(x)[2][2]) > 0.9 else "upright"): round(nxh.sheet_area(part, [x])[0] / 30.0, 3)
                for x in body.GetFaces() if nxh.face_data(x)[0] == nxh.PLANE}
        out[f"conic_{o1}_x_{o2}"] = {"faces": len(body.GetFaces()), "leg_widths_left": legs, "types": nxh.face_census(body)["types"]}

    c84, c48 = out["conic_8_x_4"], out["conic_4_x_8"]
    chk.true("face blend conic (FirstOffset 8, SecondOffset 4): face 1 is cut back 4 and face 2 by 8 - each offset lands on the OTHER face",
             "error" not in c84 and c84["leg_widths_left"] == {"horizontal": 16.0, "upright": 2.0}
             and "error" not in c48 and c48["leg_widths_left"] == {"horizontal": 12.0, "upright": 6.0}, [c84, c48])
    # contact curves: a line on each sheet where the blend must touch
    a, up = crossing(300.0)
    c1 = nxh.line(part, (332, 1100, 0), (332, 1130, 0))       # on the horizontal sheet, 12 from the corner
    c2 = nxh.line(part, (320, 1100, 6), (320, 1130, 6))       # on the upright, 6 from the corner

    def contact(b, FBB):
        b.CrossSectionType = FBB.CrossSectionOption.Conic
        b.BlendWidthMethod = FBB.WidthMethod.TwoConstraintCurves
        for prop, cv in (("FirstConstraintCurveCollector", c1), ("SecondConstraintCurveCollector", c2)):
            col = part.ScCollectors.CreateCollector()
            col.ReplaceRules([part.ScRuleFactory.CreateRuleCurveDumb([cv])], False)
            setattr(b.ConicCrossSection, prop, col)
        b.ConicCrossSection.Rho.RightHandSide = "0.6"

    f, err = attempt(face_blend, part, a.GetFaces(), up.GetFaces(), False, False, contact)
    if err:
        out["contact_curves_12_and_6"] = {"error": err}
    else:
        body = f.GetBodies()[0]
        planes = sorted(round(nxh.sheet_area(part, [x])[0], 3) for x in body.GetFaces() if nxh.face_data(x)[0] == nxh.PLANE)
        out["contact_curves_12_and_6"] = {"faces": len(body.GetFaces()), "plane_leg_areas": planes, "bbox": nxh.bbox(body)}
    notes["face_blend_shapes"] = out
    cc = out["contact_curves_12_and_6"]
    chk.true("face blend with contact curves 12 and 6 from the corner: sheets cut back exactly to the curves (legs 8x30, 4x30)",
             "error" not in cc and cc["plane_leg_areas"] == [120.0, 240.0], cc)

    # Law Extension, miter Blend, walls leaning inward (course: alert, corners stay open)
    LEB = NXOpen.Features.LawExtensionBuilderEx
    le = {}
    for i, (ang, miter) in enumerate(((110, "Blend"), (110, "Sharp"), (80, "Blend"))):
        sh = plane_sheet(part, i * 100.0, 1200)
        f, err = attempt(law_extension, part, sh.GetFaces()[0], list(sh.GetEdges()), (i * 100.0, 1200, 0), 10, ang, getattr(LEB.MiterOptions, miter))
        le[f"{ang}_{miter}"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()],
                                                           "alerts": list(f.GetFeatureErrorMessages() or [])}
    notes["law_extension_miter"] = le

    # N-Sided, Trim to Boundary on an OPEN loop
    def nsided(curves, hp, trim):
        NSB = NXOpen.Features.NSidedSurfaceBuilder
        b = part.Features.CreateNSidedSurfaceBuilder(NXOpen.Features.NSidedSurface.Null)
        try:
            b.PositionTolerance = 0.01
            b.TangentTolerance = 0.5
            b.CurvatureTolerance = 0.5
            b.Type = NSB.SurfaceType.TrimmedPatch
            b.OuterLoop.SetAllowedEntityTypes(ONLY_CURVES)
            nxh.fill_section(part, b.OuterLoop, curves=curves, help_point=hp)
            b.UVOrientation = NSB.UVOrientationType.Area
            b.TrimToBoundary = trim
            return b.CommitFeature()
        finally:
            b.Destroy()

    ns = {}
    for i, (closed, trim) in enumerate(((False, True), (False, False), (True, True), (True, False))):
        x0 = i * 100.0
        cv = nxh.polyline(part, [(x0, 1300, 0), (x0 + 40, 1300, 0), (x0 + 40, 1330, 0), (x0, 1330, 0)], closed=closed)
        f, err = attempt(nsided, cv, (x0, 1300, 0), trim)
        ns[f"closed={closed} trim={trim}"] = {"error": err} if err else {"area": round(nxh.sheet_area(part, f.GetBodies()[0])[0], 3)}
    notes["n_sided_trim_to_boundary"] = ns
    chk.true("n-sided, closed loop, Trim to Boundary: area = the loop (1200)", abs(ns["closed=True trim=True"].get("area", 0) - 1200.0) < 0.05, ns)


def t_offsets_of_quilts(part):
    out = {}
    R = part.ScRuleFactory

    def l_quilt(x0):
        a = plane_sheet(part, x0, 1400)                                                             # z = 0, x0 .. x0+40
        up = sheet_extrude(part, [nxh.line(part, (x0 + 40, 1400, 0), (x0 + 40, 1430, 0))], (0, 0, 1), 20, (x0 + 40, 1400, 0))
        sew(part, a, [up])
        return a

    for i, flip in enumerate((False, True)):
        q = l_quilt(i * 100.0)
        f, err = attempt(offset_surface, part, R.CreateRuleFaceBody(q), 5, flip)
        out[f"L_quilt_offset_5_flip={flip}"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()]}
    # offsets beyond the radius of curvature
    hc = half_cyl(part, 300, 1410)
    f, err = attempt(offset_surface, part, R.CreateRuleFaceBody(hc), 6, True)
    out["half_cyl_R5_offset_6_inward"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()]}
    hc = half_cyl(part, 400, 1410)
    f, err = attempt(offset_surface, part, R.CreateRuleFaceBody(hc), 4, True)
    out["half_cyl_R5_offset_4_inward"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()]}
    hc = half_cyl(part, 500, 1410)
    f, err = attempt(thicken, part, hc, 6, 0, True)
    out["half_cyl_R5_thicken_6_inward"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()]}
    hc = half_cyl(part, 600, 1410)
    f, err = attempt(thicken, part, hc, 4, 0, True)
    out["half_cyl_R5_thicken_4_inward"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()]}
    # thicken an L quilt both ways
    for i, rev in enumerate((False, True)):
        q = l_quilt(700.0 + i * 100.0)
        f, err = attempt(thicken, part, q, 3, 0, rev)
        out[f"L_quilt_thicken_3_reverse={rev}"] = {"error": err} if err else {"bodies": [describe(part, b) for b in f.GetBodies()]}
    notes["offsets_of_quilts"] = out
    ok4 = out["half_cyl_R5_offset_4_inward"]
    chk.true("offset surface inside the radius (R5, 4 inward) gives R1: area pi x 1 x 50",
             "error" not in ok4 and abs(ok4["bodies"][0]["area"] - math.pi * 50) < 0.05, ok4)
    t4 = out["half_cyl_R5_thicken_4_inward"]
    chk.true("thicken inside the radius (R5, 4 inward): volume pi/2 (25 - 1) 50",
             "error" not in t4 and abs(t4["bodies"][0]["volume"] - math.pi / 2 * 24 * 50) < 0.05, t4)
    vols = sorted(out[k]["bodies"][0].get("volume", 0) for k in ("L_quilt_thicken_3_reverse=False", "L_quilt_thicken_3_reverse=True")
                  if "error" not in out[k])
    notes["L_quilt_thicken_volumes_inside_outside"] = vols
    chk.true("thicken of an L quilt gives one mitred solid on either side (inside 5130, outside 5670 mm3)",
             len(vols) == 2 and abs(vols[0] - (37 * 3 * 30 + 20 * 3 * 30)) < 0.5 and abs(vols[1] - (43 * 3 * 30 + 20 * 3 * 30)) < 0.5, vols)


def main():
    part = nxh.new_part(os.path.join(OUT, "surf_round3_checks.prt"))
    for name, fn in (("parametric_assoc", t_parametric_assoc), ("parametric_sketch", t_parametric_sketch),
                     ("studio_and_mesh", t_studio_and_mesh), ("swept_options", t_swept_options), ("trim_regions", t_trim_regions),
                     ("section_surface", t_section_surface), ("face_blend_shapes", t_face_blend_shapes),
                     ("offsets_of_quilts", t_offsets_of_quilts)):
        trial(name, fn, part)
    nxh.save(part)


res = {}
try:
    main()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res.update(chk.report())
if "error" in res:
    res["result"] = "FAIL"
res["notes"] = notes
nxh.write_json(os.path.join(OUT, "surf_round3_checks.json"), res)
