"""Law Extension option semantics on NX 2206: spine, miter, Faces vs Vector type, laws, opposite side.

    run_journal.ps1 -Script surf_law_extension.py -WorkDir <out> -JArgs <out>   ->  <out>\\surf_law_extension.json

L1  Rim flange on a tapered duct (four inclined planar faces, rim at z = 30), length 10, angle 90:
    spine none / by vector Z  x  miter NotSet / Sharp / Blend / Radius. Measured per case: number of new sheet
    bodies and faces, area, z range of the flange (planar or not), angle between flange and reference face at
    the rim, G1 deviation across the corner edges, free edges, feature errors.
L2  The same matrix on the four edges of ONE planar sheet at 80 / 90 / 110 deg (the case the skill's old
    "Blend leaves four separate walls" sentence came from); reference normal reversed; profile direction reversed.
L3  Vector type: the angle is measured from one direction, not from the face (draft / parting walls); the
    profile direction decides the side.
L4  What a spine does; linear length law; opposite side extension (Symmetric / Asymmetric).
L5  Rim flange sewn to the duct: one sheet, free edges.

The profile DIRECTION matters (side of every angle but 90, side of the Vector type), and body.GetEdges() has no
fixed order between sessions: the edge lists are sorted so that a known edge is the seed.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
GU = NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
LEB = NXOpen.Features.LawExtensionBuilderEx
TCB = NXOpen.Features.ThroughCurvesBuilder
LAW = GU.LawBuilder.Type
ONLY_CURVES = NXOpen.Section.AllowTypes.OnlyCurves
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
notes = res["notes"]


def save_json():
    out = dict(res)
    out.update(chk.report())
    nxh.write_json(os.path.join(OUT, "surf_law_extension.json"), out)


def edge_points(edge, n=5):
    """n points along an edge, ends left out (a corner vertex belongs to three faces)."""
    props = nxh.UFS.ModlGeneral.AskCurveProps
    return [tuple(props(edge.Tag, (i + 1.0) / (n + 1.0))[0]) for i in range(n)]


# ---------------------------------------------------------------- the recipe
def law_extension(part, edges, faces=None, hp=(0, 0, 0), length=10, angle=90, miter=None, miter_radius=None, spine=None,
                  vector=None, length_end=None, opposite=None, opposite_length=None, reverse_normal=False, merge=None, tolerances=True, info=None):
    """Law Extension (LawExtensionBuilderEx). A NEW sheet body (or several: see miter).

    faces      reference faces (Type Faces): the angle is measured from the face, 0 = continue it, 90 = stand on it
    vector     Type Vector: the angle is measured from this direction instead (faces are not used)
    spine      a direction (x, y, z): SpineDefinition by Vector - every cross-section of the flange lies in a plane
               that contains this direction ... see the measured table in references/nxopen-recipes.md
    miter      LEB.MiterOptions.NotSet | Sharp | Blend | Radius (+ miter_radius)
    length_end second value of a Linear length law (length -> length_end along the profile)
    opposite   LEB.OppositeSideExtensionOptions.Symmetric | Asymmetric (+ opposite_length)
    """
    b = part.Features.CreateLawExtensionBuilderEx(NF)
    try:
        if info is not None:
            info["default_tolerances"] = (b.DistanceTolerance, b.AngleTolerance)
        if tolerances:
            b.DistanceTolerance = 0.01
            b.AngleTolerance = 0.5
        b.BaseProfile.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.BaseProfile, edges=list(edges), help_point=hp)
        if vector is not None:
            b.Type = LEB.Types.Vector
            b.Vector = nxh.direction(part, vector)
        else:
            b.Type = LEB.Types.Faces
            b.Faces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        if length_end is None:
            b.LengthLaw.LawType = LAW.Constant
            b.LengthLaw.Value.RightHandSide = str(length)
        else:
            b.LengthLaw.LawType = LAW.Linear
            b.LengthLaw.StartValue.RightHandSide = str(length)
            b.LengthLaw.EndValue.RightHandSide = str(length_end)
        b.AngleLaw.LawType = LAW.Constant
        b.AngleLaw.Value.RightHandSide = str(angle)
        if spine is not None:
            sd = b.SpineDefinition
            sd.Method = GU.SpineDefinitionBuilder.MethodOptions.Vector
            sd.Vector = nxh.direction(part, spine)
        if miter is not None:
            b.MiterOption = miter
        if miter_radius is not None:
            b.MiterRadius.RightHandSide = str(miter_radius)
        if opposite is not None:
            b.OppositeSideExtensionOption = opposite
            if opposite_length is not None:
                b.OppositeSideLengthLaw.LawType = LAW.Constant
                b.OppositeSideLengthLaw.Value.RightHandSide = str(opposite_length)
        if reverse_normal:
            b.IsReferenceFaceNormalReversed = True
        if merge is not None:
            b.MergeFacesIfPossible = merge
        return b.CommitFeature()
    finally:
        b.Destroy()


def through_curves(part, sections, preserve=True):
    b = part.Features.CreateThroughCurvesBuilder(NF)
    try:
        b.PreserveShape = preserve
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.BodyPreference = TCB.BodyPreferenceTypes.Sheet
        for s in sections:
            b.SectionsList.Append(s)
        b.Alignment.SetSections(list(sections))
        return b.CommitFeature()
    finally:
        b.Destroy()


def bounded_plane(part, curves, hp):
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(ONLY_CURVES)
        nxh.fill_section(part, b.BoundingCurves, curves=curves, help_point=hp)
        return b.CommitFeature()
    finally:
        b.Destroy()


def sew(part, target, tools, tol=0.01):
    b = part.Features.CreateSewBuilder(NF)
    try:
        b.Type = NXOpen.Features.SewBuilder.Types.Sheet
        b.Tolerance = tol
        b.TargetBodies.Add(target)
        for t in tools:
            b.ToolBodies.Add(t)
        return b.CommitFeature()
    finally:
        b.Destroy()


# ---------------------------------------------------------------- measurement of one flange
def flange_report(part, new, ref_body=None, rim_edges=None):
    """new = the sheet bodies the feature made."""
    zs, xs, ys = [], [], []
    for bd in new:
        for e in bd.GetEdges():
            for v in e.GetVertices():
                xs.append(v.X)
                ys.append(v.Y)
                zs.append(v.Z)
    faces = [f for bd in new for f in bd.GetFaces()]
    rep = {"bodies": len(new), "faces": len(faces), "area": round(sum(nxh.sheet_area(part, bd)[0] for bd in new), 3),
           "z_min": round(min(zs), 4), "z_max": round(max(zs), 4), "x_range": [round(min(xs), 4), round(max(xs), 4)],
           "y_range": [round(min(ys), 4), round(max(ys), 4)], "free_edges": sum(len(nxh.free_edges(bd)) for bd in new),
           "types": {}}
    for f in faces:
        t = nxh.face_data(f)[0]
        rep["types"][t] = rep["types"].get(t, 0) + 1
    # G1 deviation across every edge shared by two faces of the flange (the corner / mitre edges)
    worst = None
    for bd in new:
        for e in bd.GetEdges():
            fs = e.GetFaces()
            if len(fs) == 2:
                d = nxh.g1_deviation(fs[0], fs[1], edge_points(e, 3))
                worst = d if worst is None else max(worst, d)
    rep["corner_edges_g1_dev_deg"] = None if worst is None else round(worst, 3)
    # angle between the flange and the reference face along the rim (folded into 0..90)
    if ref_body is not None and rim_edges:
        angs = []
        for e in rim_edges:
            for p in edge_points(e, 1):
                fr = nxh.face_at(part, ref_body, p, tol=1e-4)
                fn = [f for f in faces if abs(nxh.dist_to(part, f, p)) < 1e-4]
                if fr and fn:
                    angs.append(round(nxh.g1_deviation(fr[0], fn[0], [p]), 3))
        rep["angle_to_reference_face_deg"] = angs
    return rep


def run_case(part, name, store, fn, ref_body=None, rim_edges=None):
    m = nxh.mark(name, False)
    before = list(part.Bodies)
    try:
        f = fn()
        new = [b for b in nxh.new_bodies(part, before) if not b.IsSolidBody]
        rep = flange_report(part, new, ref_body, rim_edges)
        rep["alerts"] = [str(x) for x in (f.GetFeatureErrorMessages() or [])] if f is not None else ["no feature returned"]
        store[name] = rep
    except Exception as e:  # noqa: BLE001
        store[name] = {"error": str(e)[:300]}
    finally:
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass
    save_json()
    return store[name]


def ok(r):
    return isinstance(r, dict) and "error" not in r


def run():
    part = nxh.new_part(os.path.join(OUT, "surf_law_extension.prt"))
    MO = LEB.MiterOptions
    info = {}

    # ---------------- L1 tapered duct 40 x 30 -> 20 x 16 over 30 mm, rim = the four top edges
    r0 = nxh.rect(part, -20, -15, 20, 15, z=0.0)
    r1 = nxh.rect(part, -10, -8, 10, 8, z=30.0)
    duct = through_curves(part, [nxh.section(part, curves=r0, help_point=(-20, -15, 0), seed=r0[0]),
                                 nxh.section(part, curves=r1, help_point=(-10, -8, 30), seed=r1[0])]).GetBodies()[0]
    rim = [e for e in duct.GetEdges() if all(abs(v.Z - 30.0) < 1e-6 for v in e.GetVertices())]
    # The profile starts on the FIRST edge of the list, at its end nearest the help point - and GetEdges() has no
    # fixed order. Put a known edge first (the rim edge at y = -8) and name the two possible directions:
    rim.sort(key=lambda e: 0 if all(abs(v.Y + 8.0) < 1e-6 for v in e.GetVertices()) else 1)
    RIM_CCW, RIM_CW = (-10, -8, 30), (10, -8, 30)      # start points: counter-clockwise / clockwise seen from +Z
    dfaces = list(duct.GetFaces())
    notes["L1_duct"] = {"faces": len(dfaces), "rim_edges": len(rim), "types": nxh.face_census(duct)["types"]}
    chk.true("L1 duct: 4 planar faces, 4 rim edges", len(dfaces) == 4 and len(rim) == 4, notes["L1_duct"])
    L1 = notes["L1_rim_flange"] = {}
    for sname, spine in (("nospine", None), ("spineZ", (0, 0, 1))):
        for mname, miter, rad in (("default", None, None), ("NotSet", MO.NotSet, None), ("Sharp", MO.Sharp, None), ("Blend", MO.Blend, None), ("Radius3", MO.Radius, 3)):
            run_case(part, sname + "_" + mname, L1,
                     lambda spine=spine, miter=miter, rad=rad: law_extension(part, rim, dfaces, RIM_CCW, 10, 90, miter=miter, miter_radius=rad, spine=spine, info=info),
                     duct, rim)
    notes["builder_defaults"] = info
    rise = 10 * math.sin(math.atan(10 / 30.0))                           # a 10 mm wall at 90 deg to a face that leans 18.43 deg
    ns, nsh, nbl, nno = L1["nospine_Sharp"], L1["nospine_Sharp"], L1["nospine_Blend"], L1["nospine_NotSet"]
    zs, zb, zn, zr, zd = L1["spineZ_Sharp"], L1["spineZ_Blend"], L1["spineZ_NotSet"], L1["spineZ_Radius3"], L1["spineZ_default"]
    chk.true("L1 no spine: the flange stands at 90 deg on EACH inclined face (angle to the reference face 90.0 at all four edges)",
             ok(ns) and all(abs(a - 90.0) < 0.01 for a in ns["angle_to_reference_face_deg"]), ns)
    if ok(ns):
        chk("L1 no spine: so the flange is NOT planar - it rises by 10 x sin(taper) = 3.162 mm above the rim", ns["z_max"] - ns["z_min"], rise, 0.001)
    chk.true("L1 no spine, Sharp: one sheet, 4 faces, mitre creases at the corners (> 10 deg)", ok(nsh) and nsh["bodies"] == 1 and nsh["faces"] == 4 and nsh["corner_edges_g1_dev_deg"] > 10.0, nsh)
    chk.true("L1 no spine, Blend: one sheet, 8 faces (4 walls + 4 corner faces), corners tangent (< 0.1 deg)", ok(nbl) and nbl["bodies"] == 1 and nbl["faces"] == 8
             and nbl["corner_edges_g1_dev_deg"] < 0.1, nbl)
    chk.true("L1 no spine, NotSet: one sheet PER EDGE (4 bodies)", ok(nno) and nno["bodies"] == 4 and nno["faces"] == 4, nno)
    chk.true("L1 spine by vector Z: the flange is PLANAR (every vertex at z = 30.000) with any miter option",
             all(ok(r) and abs(r["z_max"] - 30.0) < 1e-4 and abs(r["z_min"] - 30.0) < 1e-4 for r in (zs, zb, zn)), (zs, zb, zn))
    if ok(zs):
        chk("L1 spine Z + Sharp: one sheet, area exactly 40 x 36 - 20 x 16 = 1120", zs["area"], 1120.0, 0.01)
    chk.true("L1 spine Z + Sharp: 1 body, 4 coplanar faces (0.00 deg across the mitre edges), 8 free edges", ok(zs) and zs["bodies"] == 1 and zs["faces"] == 4
             and zs["corner_edges_g1_dev_deg"] < 0.01 and zs["free_edges"] == 8, zs)
    chk.true("L1 spine Z + Blend: 1 body, 8 faces, rounded corners (area below the mitred 1120)", ok(zb) and zb["bodies"] == 1 and zb["faces"] == 8 and zb["area"] < 1119.0, zb)
    chk.true("L1 spine Z + NotSet: 4 separate bodies, 720 mm2 = 4 rectangles 10 wide (open corners)", ok(zn) and zn["bodies"] == 4 and abs(zn["area"] - 720.0) < 0.01, zn)
    chk.true("L1 the builder default MiterOption behaves as Blend (same bodies, faces, area)", ok(zd) and (zd["bodies"], zd["faces"], zd["area"]) == (zb["bodies"], zb["faces"], zb["area"]), zd)
    chk.true("L1 with the spine the flange no longer stands at 90 deg on the faces (71.57 / 76.87 deg = 90 - taper)",
             ok(zs) and all(abs(a - b) < 0.01 for a, b in zip(sorted(zs["angle_to_reference_face_deg"]),
                                                               [90 - math.degrees(math.atan(10 / 30.0))] * 2 + [90 - math.degrees(math.atan(7 / 30.0))] * 2)),
             zs.get("angle_to_reference_face_deg"))
    chk.true("L1 MiterOptions.Radius (3 mm): the walls stay separate bodies, no error - not a working join here", ok(zr) and zr["bodies"] == 4, zr)

    # ---------------- L2 four edges of ONE planar sheet 40 x 30: when does Blend join?
    sh = bounded_plane(part, nxh.rect(part, 100, 0, 140, 30, 0.0), (100, 0, 0)).GetBodies()[0]
    sf, se = list(sh.GetFaces()), list(sh.GetEdges())
    se.sort(key=lambda e: 0 if all(abs(v.Y) < 1e-6 for v in e.GetVertices()) else 1)          # the edge y = 0 first
    SH_CCW, SH_CW = (100, 0, 0), (140, 0, 0)
    notes["L2_sheet_normal"] = [round(v, 3) for v in nxh.normal_at(sf[0], (120, 15, 0))]
    L2 = notes["L2_planar_sheet"] = {}
    for ang in (80, 90, 110):
        for mname, miter in (("NotSet", MO.NotSet), ("Sharp", MO.Sharp), ("Blend", MO.Blend)):
            run_case(part, "%d_%s" % (ang, mname), L2, lambda ang=ang, miter=miter: law_extension(part, se, sf, SH_CCW, 10, ang, miter=miter), sh, se)
    run_case(part, "80_Blend_reference_normal_reversed", L2, lambda: law_extension(part, se, sf, SH_CCW, 10, 80, miter=MO.Blend, reverse_normal=True), sh, se)
    run_case(part, "110_Blend_reference_normal_reversed", L2, lambda: law_extension(part, se, sf, SH_CCW, 10, 110, miter=MO.Blend, reverse_normal=True), sh, se)
    run_case(part, "80_Blend_profile_direction_reversed", L2, lambda: law_extension(part, se, sf, SH_CW, 10, 80, miter=MO.Blend), sh, se)
    run_case(part, "110_Blend_profile_direction_reversed", L2, lambda: law_extension(part, se, sf, SH_CW, 10, 110, miter=MO.Blend), sh, se)
    run_case(part, "110_Radius2", L2, lambda: law_extension(part, se, sf, SH_CCW, 10, 110, miter=MO.Radius, miter_radius=2), sh, se)
    run_case(part, "90_Sharp_spine_along_the_face_normal", L2, lambda: law_extension(part, se, sf, SH_CCW, 10, 90, miter=MO.Sharp, spine=(0, 0, 1)), sh, se)

    def leans_out(r):
        return r["x_range"][0] < 100.0 - 1e-3 and r["x_range"][1] > 140.0 + 1e-3

    a80, a110 = L2["80_Blend"], L2["110_Blend"]
    out_case, in_case = (a110, a80) if ok(a110) and leans_out(a110) else (a80, a110)
    L2["which_angle_leans_outward_here"] = 110 if out_case is a110 else 80
    chk.true("L2 walls that lean OUTWARD (corner gaps) + Blend: ONE sheet, 8 faces, tangent corner faces (< 0.1 deg)", ok(out_case) and leans_out(out_case)
             and out_case["bodies"] == 1 and out_case["faces"] == 8 and out_case["corner_edges_g1_dev_deg"] < 0.1, out_case)
    chk.true("L2 walls that lean INWARD (they overlap at the corners) + Blend: 4 separate bodies, no error, no alert", ok(in_case) and not leans_out(in_case)
             and in_case["bodies"] == 4 and not in_case["alerts"], in_case)
    chk.true("L2 Sharp joins both ways: 1 body, 4 faces at 80 and at 110 (trimmed where the walls overlap, extended where they gap)",
             all(ok(L2[k]) and L2[k]["bodies"] == 1 and L2[k]["faces"] == 4 for k in ("80_Sharp", "110_Sharp")), (L2["80_Sharp"], L2["110_Sharp"]))
    chk.true("L2 at exactly 90 deg on a flat sheet the walls share their corner edges: one 4-face body with NotSet, Sharp and Blend alike (area 1400)",
             all(ok(L2["90_" + m]) and L2["90_" + m]["bodies"] == 1 and abs(L2["90_" + m]["area"] - 1400.0) < 0.01 for m in ("NotSet", "Sharp", "Blend")),
             [L2["90_" + m] for m in ("NotSet", "Sharp", "Blend")])
    chk.true("L2 NotSet at 80 / 110: one body per edge", all(ok(L2[k]) and L2[k]["bodies"] == 4 for k in ("80_NotSet", "110_NotSet")), (L2["80_NotSet"], L2["110_NotSet"]))
    rv80, rv110 = L2["80_Blend_reference_normal_reversed"], L2["110_Blend_reference_normal_reversed"]
    dr80, dr110 = L2["80_Blend_profile_direction_reversed"], L2["110_Blend_profile_direction_reversed"]
    chk.true("L2 the side an angle leans to is NOT a property of the number: IsReferenceFaceNormalReversed flips it for 80 and for 110 deg "
             "(and Blend joins exactly the outward-leaning one)", ok(rv80) and ok(rv110) and leans_out(rv80) != leans_out(a80) and leans_out(rv110) != leans_out(a110)
             and (rv80["bodies"] == 1) == leans_out(rv80) and (rv110["bodies"] == 1) == leans_out(rv110), (a80, rv80, a110, rv110))
    chk.true("L2 ... and so does the DIRECTION of the profile (same seed edge, started at its other end): 80 and 110 deg swap sides",
             ok(dr80) and ok(dr110) and leans_out(dr80) != leans_out(a80) and leans_out(dr110) != leans_out(a110)
             and (dr80["bodies"] == 1) == leans_out(dr80) and (dr110["bodies"] == 1) == leans_out(dr110), (a80, dr80, a110, dr110))
    nz = notes["L2_sheet_normal"][2]
    chk.true("L2 rule: wall direction = cos(angle) x (profile direction x face normal) + sin(angle) x normal - profile along +X on the edge y = 0 "
             "of a sheet lying at y > 0, normal +Z: angles below 90 lean OUT (as the course says), above 90 lean in",
             nz > 0.99 and ok(a80) and leans_out(a80) and ok(a110) and not leans_out(a110), (notes["L2_sheet_normal"], a80, a110))
    chk.true("L2 spine vector = the normal of the reference face: 'Invalid input data.'", "Invalid input data" in L2["90_Sharp_spine_along_the_face_normal"].get("error", ""),
             L2["90_Sharp_spine_along_the_face_normal"])

    # ---------------- L3 Vector type on the duct rim: the angle is measured from the vector, the faces do not matter
    L3 = notes["L3_vector_type"] = {}
    for ang in (0, 10, 90):
        run_case(part, "vectorZ_angle%d_Sharp" % ang, L3, lambda ang=ang: law_extension(part, rim, None, RIM_CCW, 10, ang, miter=MO.Sharp, vector=(0, 0, 1)), duct, rim)
    for ang in (10, 90):
        run_case(part, "vectorZ_angle%d_Sharp_profile_direction_reversed" % ang, L3,
                 lambda ang=ang: law_extension(part, rim, None, RIM_CW, 10, ang, miter=MO.Sharp, vector=(0, 0, 1)), duct, rim)
    run_case(part, "faces_spineZ_angle90_Sharp_profile_direction_reversed", L3,
             lambda: law_extension(part, rim, dfaces, RIM_CW, 10, 90, miter=MO.Sharp, spine=(0, 0, 1)), duct, rim)
    run_case(part, "faces_nospine_angle90_Sharp_profile_direction_reversed", L3,
             lambda: law_extension(part, rim, dfaces, RIM_CW, 10, 90, miter=MO.Sharp), duct, rim)
    v0, v10, v90 = L3["vectorZ_angle0_Sharp"], L3["vectorZ_angle10_Sharp"], L3["vectorZ_angle90_Sharp"]
    w10, w90 = L3["vectorZ_angle10_Sharp_profile_direction_reversed"], L3["vectorZ_angle90_Sharp_profile_direction_reversed"]
    fs, fn = L3["faces_spineZ_angle90_Sharp_profile_direction_reversed"], L3["faces_nospine_angle90_Sharp_profile_direction_reversed"]
    chk.true("L3 Type Vector Z, angle 0: a wall straight along the vector (z 30 -> 40, no growth in x / y) off the INCLINED faces",
             ok(v0) and abs(v0["z_max"] - 40.0) < 1e-3 and abs(v0["x_range"][1] - 10.0) < 1e-3 and v0["bodies"] == 1, v0)
    if ok(v10):
        chk("L3 Type Vector Z, angle 10, profile counter-clockwise seen from +Z: every wall leans 10 deg OUTWARD off the vector (reach 10 x sin 10 = 1.7365)",
            v10["x_range"][1] - 10.0, 10 * math.sin(math.radians(10)), 1e-3)
        chk("L3 Type Vector Z, angle 10: height 10 x cos 10 = 9.848", v10["z_max"] - 30.0, 10 * math.cos(math.radians(10)), 1e-3)
    if ok(v90):
        chk("L3 Type Vector Z, angle 90 + Sharp (counter-clockwise profile): the same planar rim flange as Faces type + spine Z (area 1120)", v90["area"], 1120.0, 0.01)
    chk.true("L3 Type Vector Z, angle 90: planar, one body, 4 faces", ok(v90) and abs(v90["z_max"] - 30.0) < 1e-4 and v90["bodies"] == 1 and v90["faces"] == 4, v90)
    chk.true("L3 Type Vector: the DIRECTION of the profile decides the side - the same rim taken clockwise leans INWARD at 10 deg (no reach beyond the rim) "
             "and puts the 90 deg flange inside the rim (area below the rim opening 320, not 1120)",
             ok(w10) and w10["x_range"][1] < 10.0 + 1e-3 and abs(w10["z_max"] - 30.0 - 10 * math.cos(math.radians(10))) < 1e-3
             and ok(w90) and w90["x_range"][1] < 10.0 + 1e-3 and w90["area"] < 400.0, (w10, w90))
    chk.true("L3 Type Faces at angle 90 does NOT depend on the profile direction (clockwise: the same planar 1120.0 flange with a spine, the same 1127.39 without)",
             ok(fs) and abs(fs["area"] - 1120.0) < 0.01 and ok(fn) and abs(fn["area"] - L1["nospine_Sharp"]["area"]) < 0.01, (fs, fn))

    # ---------------- L4 what the spine does; laws; opposite side (one edge of the planar sheet: y = 0, x 100..140)
    L4 = notes["L4_spine_laws_opposite_side"] = {}
    e0 = [e for e in se if all(abs(v.Y) < 1e-6 for v in e.GetVertices())]
    OS = LEB.OppositeSideExtensionOptions
    run_case(part, "angle60_no_spine", L4, lambda: law_extension(part, e0, sf, (100, 0, 0), 10, 60), sh, e0)
    run_case(part, "angle60_spine_along_the_edge", L4, lambda: law_extension(part, e0, sf, (100, 0, 0), 10, 60, spine=(1, 0, 0)), sh, e0)
    run_case(part, "angle60_spine_skew_110", L4, lambda: law_extension(part, e0, sf, (100, 0, 0), 10, 60, spine=(1, 1, 0)), sh, e0)
    run_case(part, "duct_spineZ_angle45_Sharp", L4, lambda: law_extension(part, rim, dfaces, RIM_CCW, 10, 45, miter=MO.Sharp, spine=(0, 0, 1)), duct, rim)
    run_case(part, "duct_spineZ_angle45_Sharp_profile_direction_reversed", L4, lambda: law_extension(part, rim, dfaces, RIM_CW, 10, 45, miter=MO.Sharp, spine=(0, 0, 1)), duct, rim)
    run_case(part, "duct_spineZ_angle0_Sharp", L4, lambda: law_extension(part, rim, dfaces, RIM_CCW, 10, 0, miter=MO.Sharp, spine=(0, 0, 1)), duct, rim)
    run_case(part, "constant_10", L4, lambda: law_extension(part, e0, sf, (100, 0, 0), 10, 90), sh, e0)
    run_case(part, "linear_10_to_20", L4, lambda: law_extension(part, e0, sf, (100, 0, 0), 10, 90, length_end=20), sh, e0)
    run_case(part, "opposite_symmetric", L4, lambda: law_extension(part, e0, sf, (100, 0, 0), 10, 90, opposite=OS.Symmetric), sh, e0)
    run_case(part, "opposite_asymmetric_4", L4, lambda: law_extension(part, e0, sf, (100, 0, 0), 10, 90, opposite=OS.Asymmetric, opposite_length=4), sh, e0)
    run_case(part, "reference_normal_reversed", L4, lambda: law_extension(part, e0, sf, (100, 0, 0), 10, 90, reverse_normal=True), sh, e0)
    nsp, sal, ssk = L4["angle60_no_spine"], L4["angle60_spine_along_the_edge"], L4["angle60_spine_skew_110"]
    chk.true("L4 a spine vector along the profile changes nothing (same wall as without a spine)", ok(nsp) and ok(sal) and (nsp["area"], nsp["z_max"], nsp["y_range"]) == (sal["area"], sal["z_max"], sal["y_range"]), (nsp, sal))
    if ok(ssk):
        chk("L4 a skew spine (1,1,0) shears the wall: its rulings lie in planes NORMAL to the spine (the far end moves 3.5355 along the edge)", ssk["x_range"][1] - 140.0, 10 * math.cos(math.radians(60)) * math.sin(math.radians(45)), 1e-3)
        chk("L4 skew spine: the ruling keeps its length and its rise (10 x sin 60 = 8.660)", ssk["z_max"], 10 * math.sin(math.radians(60)), 1e-3)
    d45, d0, d45r = L4["duct_spineZ_angle45_Sharp"], L4["duct_spineZ_angle0_Sharp"], L4["duct_spineZ_angle45_Sharp_profile_direction_reversed"]
    chk.true("L4 spine normal to the rim plane: the angle is then measured IN that plane - 45 deg gives flat strips sheared along the rim "
             "(still planar; 4 strips of 720 x sin 45 one way round, a trimmed 709.12 ring the other way) - use 90 with such a spine",
             ok(d45) and ok(d45r) and abs(d45["z_max"] - 30.0) < 1e-4 and abs(d45r["z_max"] - 30.0) < 1e-4
             and sorted([round(d45["area"], 2), round(d45r["area"], 2)]) == [round(720.0 * math.sin(math.radians(45)), 2), 709.12], (d45, d45r))
    L4["note_duct_spineZ_angle0"] = d0
    c10, l20, osy, oas, rvn = L4["constant_10"], L4["linear_10_to_20"], L4["opposite_symmetric"], L4["opposite_asymmetric_4"], L4["reference_normal_reversed"]
    if ok(l20):
        chk("L4 Linear length law 10 -> 20 on a 40 mm edge: trapezoid area 600", l20["area"], 600.0, 0.01)
        chk("L4 Linear length law: height 20 at the far end", l20["z_max"], 20.0, 1e-3)
    chk.true("L4 Opposite Side Symmetric: the wall grows the same length to the other side (z -10 .. 10, area 800)", ok(osy) and abs(osy["area"] - 800.0) < 0.01 and abs(osy["z_min"] + 10.0) < 1e-3, osy)
    chk.true("L4 Opposite Side Asymmetric + OppositeSideLengthLaw 4: z -4 .. 10, area 560", ok(oas) and abs(oas["area"] - 560.0) < 0.01 and abs(oas["z_min"] + 4.0) < 1e-3, oas)
    chk.true("L4 IsReferenceFaceNormalReversed: the 90 deg wall stands on the other side of the sheet (z 0 .. -10)", ok(rvn) and abs(rvn["z_min"] + 10.0) < 1e-3 and abs(c10["z_max"] - 10.0) < 1e-3, (c10, rvn))

    # ---------------- L5 the planar rim flange kept and sewn to the duct
    before = list(part.Bodies)
    law_extension(part, rim, dfaces, RIM_CCW, 10, 90, miter=MO.Sharp, spine=(0, 0, 1))
    flange = [b for b in nxh.new_bodies(part, before) if not b.IsSolidBody]
    notes["L5_kept"] = flange_report(part, flange, duct, rim)
    n0 = len(nxh.sheets(part))
    sew(part, duct, flange)
    notes["L5_sewn"] = {"sheets_change": len(nxh.sheets(part)) - n0, "faces": len(duct.GetFaces()), "free_edges": len(nxh.free_edges(duct)),
                        "area": round(nxh.sheet_area(part, duct)[0], 3), "examine": nxh.examine_geometry(part, duct)}
    s5 = notes["L5_sewn"]
    chk.true("L5 a Law Extension is a NEW sheet: Sew joins it to the duct (one sheet less, 8 faces, 8 free edges = bottom loop + flange rim)",
             s5["sheets_change"] == -1 and s5["faces"] == 8 and s5["free_edges"] == 8, s5)
    chk("L5 sewn area = duct + flange", s5["area"], 3302.998 + 1120.0, 0.01)
    notes["feature_errors"] = str(nxh.feature_errors(part))
    chk.true("no feature errors in the saved part", not nxh.feature_errors(part), notes["feature_errors"])
    res["features"] = [(x["name"], x["type"]) for x in nxh.feature_table(part)]
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-500:])
save_json()
