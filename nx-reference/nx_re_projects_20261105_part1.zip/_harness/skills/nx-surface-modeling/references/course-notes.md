# Course notes - surface day (condensed)

Source: the user's 6-day NX course, recordings CAD5.4, CAD5.5 (surface creation) and CAD5.6 (Face Blend,
Extend / Trim / Make Corner), CAD3.5 (Extract Geometry) and CAD4.1 (import repair). Timestamps are video
time `[CADx.y hh:mm:ss]`. Full notes: `C:\NX_MCP_WORKSPACE\nx_course\notes\day5b.md`, `day5c.md`, `day4a.md`.
"Probe" = what `scripts/surf_course_checks.py` measured on NX 2206 (mm part, tolerance 0.01).

**Unit trap.** The course sample parts 404 / 405 / 406 / 414 / 328 / 329 are **inch** parts: dialogs show
G0 0.001 in, radii 0.25 in. The user's parts and every journal here are mm with 0.01 mm / 0.5 deg. Never copy
a number from the course without its unit [CAD5.4 00:00:00, CAD5.6 00:00:00].

## The instructor's own decision table [CAD5.4 00:13:23]

| # | Command | His one-liner |
|---|---|---|
| 1 | Ruled | section to section, two sections only, G0 |
| 2 | Through Curves | section to section, many sections, G0 / G1 / G2 at the two ends |
| 3 | Through Curve Mesh | section to section, steered and bounded by guide (cross) curves, continuity on all four sides |
| 4 | N-Sided Surface | surface on a set of curves; the set need not be closed |
| 5 | Fill Surface | surface on a set of curves; the set must be closed |
| 6 | Swept | sections along at most 3 paths |
| 7 | Bounded Plane | surface on a planar loop |

## Method rules

| Rule | Where | Probe |
|---|---|---|
| Section arrows must point the same way and start at corresponding places; otherwise no surface or a twisted one. Fix: double-click the arrow / Reverse Direction. | CAD5.4 00:09:46, 00:16:31, 00:22:32 | Confirmed, and worse: in NXOpen a mismatch usually builds silently (1741 vs 1943 mm2, 12567 vs 29320 mm3). The GUI alert "Cannot create B-surface body by ruled method." was not reproduced. |
| Pick each section at the same end / same corner; the click position sets the start. | CAD5.4 00:22:32 | Confirmed: the start is the seed-curve end nearest the `AddToSection` help point. |
| Select whole sections with the **Connected Curves** rule; Infer Curves gave a partial section. Single Curve for one edge. | CAD5.4 00:21:25, 00:23:03 | In a journal: pass every curve of the string in one rule and check the string with `GetStartAndDirection()`. |
| Alignment ladder for creased lofts: Parameter -> Arc Length -> **By Points** (drag the mismatched point onto its vertex). | CAD5.4 00:12:51, 00:23:43-00:25:53 | Confirmed on rectangle -> triangle: corner ruling 3.54 mm off (Parameter), 3.11 mm off (Arc Length), 0.00 (By Points). |
| Extrude only translates a section; it cannot go section to section. | CAD5.4 00:04:53, 00:47:24 | - |
| Ruled is G0 only; a chain of Ruled patches creases at every shared section; changing alignment does not cure it, change the method. | CAD5.4 00:28:22, 00:43:03 | Confirmed: 43.60 deg crease between two Ruled patches (analytic 43.60); one Through Curves over the same 3 arcs is a single face. |
| Capability ladder Ruled < Through Curves < Through Curve Mesh: "the more parameters you give, the better the surface"; tie everything you can to everything. | CAD5.4 00:13:23, 00:46:12, 00:56:51 | Confirmed by continuity numbers below. |
| G1 / G2 needs an existing neighbour face: build the reference patches first, then the constrained patch between them. Only the first and last section can be constrained. | CAD5.4 00:30:38, 00:33:51 | Confirmed: `ConstraintFaces` must hold the face that owns the section edge. |
| Never judge a surface by eye: Analysis > Reflection, look for lines that break at patch boundaries; re-run after every change. | CAD5.4 00:35:35-00:40:08 | Headless stand-in: normal deviation and curvature across the shared edge (below). Examine Geometry does **not** see creases. |
| Tangent is not joined: G1 patches are still separate sheets until Sew; the sewn body takes the target's colour. | CAD5.4 00:52:25, 00:57:25 | Body counts confirm. |
| Close it into a body when you can (Body Type Solid when sections are closed). | CAD5.4 00:27:01 | Confirmed. |
| A sweep section must be sketched normal to its guide (Sketch > On Path, 0 % arc length). | CAD5.5 00:04:41-00:05:51 | Confirmed: a circle not normal to a 45 deg guide is carried upright, volume 2513.27 instead of 3554.31. |
| Sharp-cornered guide -> Sweep Along Guide; smooth guide -> Swept. Joining the guide into one composite curve does not help. | CAD5.5 00:14:23-00:21:27 | Confirmed: Swept raises "Some curves in Guide sections not tangent continuous"; Sweep Along Guide gives the mitred elbow, volume 4800.000 = area x path length. |
| Closed loop next to existing faces -> Fill Surface (automatic G1), not N-Sided (ignores neighbours, flat). Planar loop -> Bounded Plane. Four corners -> Four Point Surface. | CAD5.5 00:35:39-00:45:03 | See the Fill / N-Sided card. |
| Let the feature sew itself when it can (Fill Surface > Patch into Part; Face Blend > Trim + Sew). | CAD5.5 00:41:09, CAD5.6 00:02:56 | Confirmed for both. |
| Two sheets that must meet: Extend Sheet first, then Trim Sheet each with the other; or Trim and Extend > Make Corner in one feature, target = the free **edges** of the sheet to extend. | CAD5.6 00:18:16-00:21:49 | Confirmed, including the failure text with faces as target. |
| Sheet -> solid: cap every opening (Bounded Plane), Sew everything, check with the Solid Body filter, Measure. | CAD5.6 00:15:23-00:16:52, CAD5.5 00:45:44 | Confirmed (round 1). |
| Import repair: Examine Geometry on the **body** -> Sheet Boundaries shows the leak -> extrude the open edge as a sheet -> Sew. | CAD4.1 00:09:52-00:18:37 | Confirmed: `BodySheetBoundaries` 4 on an open box, 0 after closing. |
| Reset every dialog on entry; try the simple command first, escalate; when a construction fails delete and redo. | throughout | In a journal: set every tolerance and option explicitly (batch defaults differ). |

## Tool cards

### Ruled [CAD5.4 00:06:56]
Two sections only, no Continuity group. Alignment list: Parameter / Arc Length / By Points / Distance / Angle /
Spine Curve / Developable. Body Type Solid when both sections are closed. Use for quick patches and as the
**reference faces** a later Through Curves is made tangent to. Recipe: `nxopen-recipes.md` > Ruled.

### Through Curves [CAD5.4 00:15:10, 00:28:54]
Any number of sections (Add New Section / MMB between them). First / Last Section continuity G0 / G1 / G2, each
non-G0 needs Select Face. Interior sections are smooth inside one feature. Limit: no guide curves - on a
4-sided gap it cannot be tied to the side boundaries (use Curve Mesh). Probe: G0 end 11.31 deg crease; G1 0.00 deg
with edge curvature 1/78 against the neighbour's 1/20; G2 0.00 deg and curvature exactly 1/20.

### Through Curve Mesh [CAD5.4 00:50:53]
Primaries (sections) + crosses (guides); continuity on First / Last Primary and First / Last Cross, each with
its own face pick; no preview while a G1 row has no face. Order used: the two end boundaries as primaries, then
the crosses in sequence across the patch. Probe: with G1 on both primaries the deviation to the neighbours is
0.000 / 0.003 deg; the same wireframe at G0 is 10.87 deg off on both.

### Reflection analysis [CAD5.4 00:35:35]
Analysis > Face Shape > Reflection, Line Images, 32 lines; broken lines at a shared edge = G0, kinked = G1,
flowing = G2. No journal equivalent was found; use `g1_deviation()` and `max_curvature()` from
`surf_course_checks.py`.

### Sew [CAD5.4 00:57:25]
Type Sheet, one target, n tools; "like Unite, for sheets". Closed set -> solid.

### Swept [CAD5.5 00:03:52] and Sweep Along Guide [CAD5.5 00:16:47]
Swept: sections, up to 3 guides, Orientation Fixed, Scaling Constant by default. Section must be normal to the
guide; fails on cornered guides unless the corner radius "rescues" it. Sweep Along Guide: one section, one
guide, mitres sharp corners; navigator name "Sweep".

### Law Extension [CAD5.5 00:22:59]
Type Face: base curve (sketch curve on the sheet or the sheet's edges), reference face, Length Law, Angle Law
(90 = normal to the face, below 90 leans out, above 90 leans in), Miter Blend / Sharp / None. Use: flanges all
round a sheet, mould parting surfaces. GUI alert at 110 deg with Miter Blend: "Miter is not applied between
multiple bodies." Probe: 60 deg -> height 8.660, reach 5.000; 110 deg -> height 9.397, reach -3.420; four edges
with Sharp miter at 90 deg -> one 4-face wall body, area 1400.
Re-measured (`surf_law_extension.py`): the course's rule holds once it is read as LEANING, not as a number -
Miter Blend joins walls that lean outward (corner gaps: one body with tangent corner faces) and leaves walls
that lean inward as separate bodies. In a journal the side an angle leans to depends on the profile start and
the face normal (80 deg leaned inward in one run, outward in the next), so check the bounding box.

### N-Sided Surface [CAD5.5 00:29:16] / Fill Surface [CAD5.5 00:38:13] / Four Point [00:41:42] / Bounded Plane [00:44:19]
N-Sided: loop may be open; raw patch is larger than the loop, Trim to Boundary cuts it only when closed; no
knowledge of neighbours. Fill Surface: closed loop, each face-owned edge defaults to G1, RMB a row -> G0;
Settings > Patch into Part sews it in. Four Point Surface: four corner picks, no settings. Bounded Plane: planar
loop only. Probe results are in `nxopen-recipes.md` > Fill Surface vs N-Sided.

### Offset Surface [CAD5.5 00:46:23] / Thicken [CAD5.5 00:48:16]
Offset Surface: Single Face rule to offset one face; no Snap to Object on the handle. Thicken: the solid
occupies the space **between Offset 1 and Offset 2** along the face normal. Probe: (2, 3) -> 1 mm wall detached
from the face, 1200 mm3; (0, 3) -> 3600; (-2, 3) -> 5 mm wall straddling the face, 6000.

### Face Blend, two-face [CAD5.6 00:00:40-00:15:23]
No shared edge needed: crossing sheets, one solid, or two bodies that do not touch. The blend sits in the
quadrant where the two face arrows meet (double-click to flip). Trim Body to Blend + Sew All Faces (on after
Reset) -> one sheet body; Trim off -> blend added as a third sheet. Width Method Contact Curve (one Curve on
Surface per face, edge to edge) for variable width; Shape Tangent Asymmetric for a 15 x 5 style blend.
Probe: crossing sheets R3 -> one 3-face sheet, area 861.372 (analytic); no-trim -> +1 sheet, originals intact;
two sheets 4.24 mm apart R5 -> one sheet, area 1135.619 (analytic). Contact-curve and asymmetric shapes not probed.

### Extend Sheet / Trim Sheet / Trim and Extend [CAD5.6 00:18:16-00:21:49]
Extend Sheet: edges, Offset limit, the value only has to overshoot the other sheet (40 mm in the demo).
Trim Sheet: target, boundary, region Keep / Discard; each sheet trimmed by the other. Trim and Extend > Make
Corner: target = free edges of the sheet to extend, tool = the face it must reach; faces as target ->
"Unable to perform Boolean."

### Extract Geometry [CAD3.5 00:00:02]
Types Composite Curve / Point / Datum / Sketch / Face / Region of Faces / Body / Mirror Body. Body copy with
**Hide Original** before a risky edit; delete the copy and unhide if it fails. Face -> "Extracted Face" sheet.

## Open in the course (not explained there)
Swept Orientation / Scaling / multi-guide; Through Curves Flow Direction, Preserve Shape, Output Surface
Options; Fill Surface Shape Control; N-Sided Constraint Faces; Trim and Extend arrows and Desired Results;
Sew tolerance. Studio Surface, Patch, Trim Body, Section Surface were announced but are not in these recordings.
Since measured from Siemens' own NX CAST lessons (`option-semantics.md`): Through Curves flow direction,
Preserve Shape and output options, Swept scaling with two / three guides, N-Sided constraint faces (the
"no knowledge of neighbours" behaviour above is the patch WITHOUT them; with them it is tangent, 0.38 deg),
Trim and Extend Until Selected, Section Surface types. Still open: Fill Surface Shape Control, Sew tolerance
beyond the table in SKILL.md.
