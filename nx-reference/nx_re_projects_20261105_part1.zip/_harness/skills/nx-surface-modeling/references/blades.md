# Blades and blade sets (propeller, fan, impeller, turbine wheel) - NX 2206

Everything here is built and measured by four journals in `scripts/`, all through the helper module
`scripts/nxblade.py` (import it next to `nxh` / `nxf`):

| Journal | What it builds | Checks |
|---|---|---|
| `blade_helicoid.py` | thin-blade wheel: Helix + Swept + Thicken, hub by Revolve, Pattern Geometry, Unite, root blend | 54 |
| `blade_sections.py` | profiled blade: Through Curves over 5 closed section sketches, shank, tip cut, wheel of 9 | 34 |
| `blade_centrifugal.py` | radial impeller: ruled camber sheet between hub and shroud, Thicken, revolved envelope, wheel of 7; imported 7 -> 5 | 46 |
| `blade_edit_count.py` | blade count 7 -> 5 on the parametric wheel and on its parameter-free STEP import (body route and Pattern Face) | 21 |

```python
sys.path.insert(0, os.environ.get("NXBLADE_DIR") or r"<nx-surface-modeling>\scripts")
import nxblade as nb
```

Sources: `[community]` = one NX author (4 blade parts, none opens in NX 2206: feature counts, expressions and
pictures only) plus one fully read gear template; `[verified]` = the journals above.

## 1. Classify the blade first

| Blade | Signs | Route |
|---|---|---|
| Thin, constant thickness (propeller, axial fan, inducer, mixer) | "sheet-metal" look, pitch given | A: helicoid sheet + Thicken |
| Profiled (airfoil sections: turbine, compressor, wind turbine, fan with thickness distribution) | chord / twist / thickness per station | B: closed sections + Through Curves as a solid |
| Vane between a hub surface and a shroud line (centrifugal impeller, pump, blower) | meridional view with hub and shroud curves | C: camber sheet through the passage + Thicken + revolved envelope |

In all three: **named expressions first** (count, radii, pitch or stations, thickness, root radius) and every
feature linked to them; **hub = Revolve of a fully constrained meridional sketch**; **one finished blade
body -> Pattern Geometry -> ONE Unite -> root blend**; the tip is **cut by the revolved envelope**, not
left as it falls. `[community]` the collection's blade parts carry almost no named expressions (one part: 4,
one of them unused) - do not copy that.

## 2. Route A - thin blade: Helix + Swept + Thicken `[verified]`

`nb.helicoid_wheel(part, n_blades=5, r_tip=60, r_hub=18, r_bore=6, pitch=120, wrap=72, thk=3, root_r=1.5,
edge_r="0.45*thk")` runs the whole sequence; its steps:

1. Expressions `n_blades, r_tip, r_hub, r_bore, pitch, wrap, thk, root_r, hub_margin, rise = pitch*wrap/360`.
   `wrap` and `n_blades` are unitless (Helix `Turns` = `wrap/360` must be unitless).
2. Hub: `nb.hub_revolve` - rectangle sketch on the XZ plane, 4 dimensions, DOF 0, Revolve about Z.
3. Generator: associative Line from `r_hub-2` to `r_tip+2` on the X axis (`nb.assoc_line`): 2 mm inside the hub
   so that the Unite bites, 2 mm beyond the tip so that the envelope cut is clean.
4. Guides: `nb.helix(part, "2*(r_tip+2)", "pitch", "wrap/360")` and the same at the root radius. The Helix
   feature always runs along absolute +Z from the origin: build the wheel on Z.
5. `nb.swept(part, [section], [g_root, g_tip], scaling=nb.SO.Uniform)` -> sheet (`SKIN`).
6. `nxf.thicken(part, sheet, "thk/2", "-thk/2")` -> the blade blank, symmetric about the helicoid.
7. Tip: `nb.envelope_trim(part, blade, "2*r_tip", z0, height)` = Cylinder with Intersect. The tip face is then an
   exact cylinder and the tip radius can be measured to 1e-9.
8. Leading / trailing edge: `nb.round_edges(part, blade, "0.45*thk")` (before the pattern).
9. Set: `nb.pattern_and_unite(part, hub, blade, thicken_feature, "n_blades")`.
10. Root: `nb.root_blend(part, unite_feature, "root_r")`.

**Swept orientation on a helix guide** - radial line r 16..62, pitch 120, 72 degrees of wrap, distance of
9 x 13 points of the true helicoid from the sheet:

| Orientation | Max deviation | Area (analytic 2536.146) | Use |
|---|---|---|---|
| `Fixed` (the builder default) | **16.573 mm** | 2504.146 | never for a blade: the line is translated, not turned |
| `ByVectorDirection` along the axis, one helix | 0.0041 mm | 2536.115 | one guide is enough |
| two helix guides + `ScalingOption = Uniform` | 0.0016 mm | 2536.073 | default: best, and the root edge is a real helix |

(The Helix curve itself is 0.00024 mm off the analytic helix at tolerance 0.001.)

Measured on the wheel: blade blank volume = helicoid area x thk to 9e-5 relative; thickness (distance between
the two side faces) 3.000000; tip radius 60.000000; one solid 67063.44 mm3 (hub 32572.03); Examine Geometry
clean; STEP passes the benchmark gate with the same volume to 1e-6.
Edge rounding: `0.3*thk`, `0.45*thk`, `0.49*thk` and the full round `thk/2` all commit clean on the 4 edges
between the side faces and the two end faces (at `thk/2` the end faces disappear: 8 faces instead of 10).

`[community]` The one collection part of this type (propeller, D 300 / hub 80 / thickness 4, 6 blades) has
exactly this feature set: Helix 1, Swept 1, Thicken (`= Thickness`), Face Blend + Edge Blend (2 mm on the
4 mm blade), Revolve hub, Unite.

## 3. Route B - profiled blade: sections on station planes + Through Curves `[verified]`

Frame of `blade_sections.py`: blade span along +Z (stations = datum planes `z = st1..st5`), wheel axis X.

1. Per station three expressions: `stN` (distance from the axis), `chordN`, `twN` (stagger from the axial
   direction, degrees). Station 1 just above the hub, the last one **beyond** the tip radius.
2. `nb.crescent_section(part, "stN", "chordN", "twN", "SEC_N")`: datum plane offset `stN` from XY + a sketch
   with two arcs (suction radius `k_suction*chord`, pressure radius `k_pressure*chord`), chord centred on the
   span axis and turned by `twN`. Six dimensions + two coincident ends = DOF 0. Any closed section works as
   long as **every station has the same number of curves in the same order**.
3. `nxf.through_curves(part, sections, solid=True, preserve=True)`: one feature, a SOLID with flat caps
   (closed sections + Body Type Solid). Each section is `nb.feature_section(part, sketch.Feature, seed_arc,
   leading_point)`: same seed curve and the help point at the same end in every station, otherwise the loft
   twists silently. `preserve=True` keeps the sharp leading / trailing edge (2 side faces).
4. Root shank: circle sketch on a plane 2 mm inside the hub, Extrude to 1 mm above station 1, **Unite into the
   blade body** (target = the loft body, so the loft feature still owns the blade).
5. Tip: `nb.envelope_trim(..., vec=(1, 0, 0))`; set: `nb.pattern_and_unite(part, hub, blade, loft, "n_blades",
   vec=(1, 0, 0))`; root: `nb.root_blend`.

Measured: all five sketches WellConstrained / 0; the designed chord ends and arc mid points of stations 1-4
lie on the faces within 2e-3 mm before and after the Unite; thickness at station 3 (suction mid point to the
pressure face) within 2 % of the designed 2.24; loft volume within 2 % of the frustum estimate from the
section areas; tip radius exact; 9 blades by section and by topology; after `chord3 25 -> 28, tw3 43 -> 40`
the new section points are on the faces; count 9 -> 7 -> 9 reproduces the volume to 1e-6.
Clearance rule found the hard way: with 9 blades on a 20 mm hub a 14 mm shank + 2 mm root blend ran into its
neighbour (the face groups merged into one). Keep `2*pi*r_hub/n > shank + 2*root_r`.

`[community]` The collection's wind-turbine blade is this recipe: 4 datum planes at typed offsets, one sketch
per station, 1 Through Curves, a separate Extrude for the root shank. Its end constraints and alignment are
not readable (the part does not open).

## 4. Route C - vane between hub surface and shroud line `[verified]`

`blade_centrifugal.py` (axis Z, conical hub surface from the rim up to the nose):

1. Hub: `nb.profile_sketch(part, [("r_bore", 0), ("r_out", 0), ("r_out", "h_rim"), ("r_nose", "h_hub"),
   ("r_bore", "h_hub")], "SK_HUB")` -> Revolve. `profile_sketch` dimensions every vertex from the Z axis and
   from the X axis (DOF 0); a zero height becomes a point-on-axis constraint.
2. Camber sheet: two arc sketches (`nb.arc_sketch`), one on the XY plane **below the hub surface**, one on a
   datum plane **above the shroud line**, the upper one displaced (lean); `nxf.through_curves(part, [low, up])`
   = a ruled sheet through the whole passage. Its plan-view extent goes beyond the leading-edge and outlet radii.
3. `nxf.thicken(part, sheet, "thk/2", "-thk/2")`.
4. Envelope: `nb.profile_sketch(part, [("r_le", 1), ("r_out", 1), ("r_out", "h_rim+b2"), ("r_eye", "h_hub"),
   ("r_le", "h_hub")], "SK_ENVELOPE")` -> `nxf.revolve(part, section, axis, op=BOOL.Intersect, target=blade)`.
   The top edge of that profile IS the shroud line; its bottom lies inside the hub so that the Unite overlaps.
5. Pattern Geometry + one Unite + root blend as before.

Measured: every blade has a conical tip face whose edges lie on the shroud line within 1e-13; outlet radius
exact; thickness 2.500000 on all 7 blades; one solid, Examine Geometry clean; count 7 -> 9, `b2 10 -> 12`,
`thk 2.5 -> 3` regenerate with the tips on the new shroud line; STEP passes the gate.
A curved (arc or spline) hub profile works the same way with a hand-drawn sketch; only the straight-line
profile helper is provided. Splitter blades, shrouded wheels and fir-tree roots are not covered.

## 5. The set: Pattern Geometry of the body, not Pattern Feature

- **Pattern Geometry** (`nxf.pattern_geometry`, in `nb.pattern_and_unite`) copies the finished blade body:
  one feature, n-1 identical bodies whatever went into the blade (measured copies: volume within 9e-6 of the
  original), count = an expression. Then ONE Unite with the tool rule `BodyFeature([blade_feature,
  pattern_feature])` - `nxh.unite(part, hub, tool_features=[...])` - so the tool set follows the count.
  `blade_feature` is the feature that created the blade body (Thicken, Through Curves), not a later cut.
- **Pattern Feature** replays only the features in its list. Measured: Pattern Feature of the Thicken alone
  (Simple or Variational) copies the **uncut blank** (7607.7 mm3) instead of the finished blade (7125.9 mm3) -
  the tip cut and the edge blend are missing in every copy, and nothing warns. Every later feature of the
  blade would have to be in the list and is then recomputed per instance.
  `[community]` 3 of the 4 collection blade parts (one author) use Pattern Feature; the Variational one is
  saved with 5 failed instances (the per-instance Offset Edge). No collection part uses Pattern Geometry for
  blades; the fully read gear template does (whole body x z, one Unite with a `BodyFeature` tool rule).
- **Root blend with one rule**: `CreateRuleFeatureIntersectionEdges([unite_feature])` = the edges where the
  blades enter the hub. It is re-evaluated on update: 5 -> 7 blades, the blend follows (same added volume per
  blade to 0.01 mm3). `CreateRuleEdgeFeature([unite_feature])` is the wrong rule - it selects every edge of
  the blades, so the "root blend" also rounds tips and edges (volume goes DOWN: 67241 -> 66453).
- Root radius: R1 and R3 on a 4 mm blade, 1.5 on a 3 mm blade, 1.0 on a 2.5 mm vane all built. `[community]`
  values seen: 2 and 3 mm on blades of 4 mm.

## 6. Checks for every blade set `[verified]`

| Check | How |
|---|---|
| one solid, no errors, healthy | `len(nxh.solids(part)) == 1`, `nxh.feature_errors`, `nxh.examine_geometry` all 0 |
| blade count, definition level | `nb.blade_count_section(part, body, r_mid, z0, z1[, vec=axis])`: lumps of material on a coaxial cylinder between hub and tip (a 0.2 mm tube intersected with a copy; undone). The z range must lie in the blade passage (above the hub surface at that radius, below a shroud). |
| blade count, topology | `groups, hub = nb.blade_groups(part, body[, vec=axis])`: hub = faces of revolution that run all the way round; every other face belongs to a blade, connected faces = one blade. `len(groups) == n`, equal face counts and areas, group angles 360/n apart. |
| face census | `nb.face_classes(part, body, faces=[f for g in groups for f in g["faces"]])`: every congruence class occurs n or a multiple of n times (the two sides of a symmetric thin blade are congruent: 2n). |
| tip radius | `nb.radial_extent(body[, vec=axis])[1]` - exact only when the tip was cut by the envelope |
| thickness | `nb.blade_thickness(part, group)` (thin blades: distance between the two largest faces); profiled blades: designed section points on the faces (`nxh.dist_to == 0`) |
| no failed instances | Pattern Geometry: `len(copies) == n - 1`; after the Unite `(volume - hub) / n` is the same at two counts |
| deliverable | `nxf.step_export` then `nb.step_gate(stp)`: valid, watertight, 1 solid (the benchmark gate; falls back to `nxf.step_roundtrip_check` when its interpreter is not installed) |

## 7. Edit recipe: change the blade count

**Parametric model**: set the count expression, `nxh.update()`, re-run the checks. Measured on all three
wheels (5 -> 7 -> 5, 9 -> 7 -> 9, 7 -> 9 -> 7, and 7 -> 5): one solid, even spacing, root blend follows,
nominal volume back to 1e-6.
This only works when the set is Pattern Geometry + Unite by feature rule + blend by intersection rule.

**Imported, parameter-free wheel** (one BREP body): measured 7 -> 5 on the STEP of the helicoid wheel and of
the centrifugal impeller, both with root blends:

1. `groups, hub = nb.blade_groups(part, body)` - check `len(groups)` is the old count and
   `nb.blade_count_section` agrees.
2. `nb.strip_blades(part, body, keep=1)`: ONE Delete Face (heal) on all faces of all blade groups but one
   (54 faces: 26-40 s). The hub closes over the removed roots; Examine Geometry clean; 1 blade left.
3. Re-pattern, either way (both measured on the helicoid wheel, same volume to 1e-9):
   - `nb.repattern(part, body, 5)`: Pattern Geometry of the whole body (hub + 1 blade) x new count about the
     axis, then one Unite (the coincident hubs merge; 30-80 s). Works whatever the blade's footprint is.
   - `nb.pattern_faces(part, groups[0]["faces"], 5)`: synchronous **Pattern Face** of the kept blade's faces
     (root blend included) on the same body - one feature, 20 s. Also worked on the impeller import, whose
     vanes run out into the rim face (volume equal to the body route to 3e-10); NX must be able to close the
     face set on the hub - see the bench case below.
4. Checks: count by section and topology, spacing 360/n, tip radius and thickness kept, one solid, gate.
   Result against the parametric model at 5 blades: volume equal to 5e-7 (helicoid wheel) and within 1e-4
   (impeller, body route).

What does NOT do the job: deleting only the surplus blades (2 of 7) - 5 blades remain at
51.4 / 51.4 / 51.4 / 51.4 / 154.3 degrees. The count is right and the part is wrong. Always strip to one and
re-pattern (or delete all blades but one in the same Delete Face).

**On a foreign, loose body the same steps are less forgiving** `[bench]` (the one blade-count edit of the v0
benchmark run: an OpenCascade-written impeller, 156 faces, edge tolerances up to 0.03 mm, blades ending in a
tab on the rim cylinder; record in that run's plan, shape score 0.99):
- ONE Delete Face for six blades was refused ("remaining faces cannot close the area"); one feature per blade
  removed five; the blade whose end tab crosses the seam of the rim cylinder refused even alone - it was kept
  as the seed instead. `nb.strip_blades` does exactly this fallback (all at once, then blade by blade, a
  refusing blade becomes the seed).
- **Pattern Face failed** there: "The selected faces might be an incomplete set for patterning" (blade ends in
  a tab on the rim cylinder, loose edges). The same layout on our own clean STEP patterned fine, so try it
  inside `nxh.attempt` and fall back to the body route when NX answers with that message.
- Pattern Geometry of the one-blade body + Unite worked, but failed once with "Unable to perform Boolean" on
  the same input and code: wrap it in `nxh.attempt` and retry / check `len(nxh.solids(part)) == 1`.
- When NX cannot do it at all, the run's fallback was rebuilding the face set outside NX. Whatever the route,
  the checks of section 6 decide.

The helpers were then run on a copy of that benchmark input itself (probe journal, not part of the skill)
`[bench]` `[verified]`: `nb.blade_count_section` 7 at three radii; `nb.blade_groups` 7 groups (20 faces, one 18)
with the hub torus recognised although the vanes cut it into 7 patches (mode "type", chosen automatically);
`nb.strip_blades` - the single Delete Face refused, six single ones went through, the refusing blade stayed as
the seed, one-blade body 2836947.380 mm3; `nb.pattern_faces` refused with the message above; `nb.repattern`
x 5 -> one solid, 114 faces, 5 groups at 72.000 deg, 3045811.919 mm3, gate valid and watertight. Both volumes
equal the hand-written NX journal of the benchmark run to the last printed digit. 7.4 minutes in all.

`blade_groups` modes: "full" (hub = faces of revolution that run all the way round) is right for blades that
stand on an uncut hub face; when vanes run the full length of the hub face they cut it into patches and "full"
returns one group - then "type" (every face of revolution about the axis is hub, a partial one that touches
exactly one blade goes back to that blade) separates them. "auto" picks "type" when "full" gives one group.
Not handled: a hub whose faces arrive as plain B-surfaces (type 43; only cylinder, cone, sphere, torus /
revolved and planes normal to the axis are recognised), and a vane trimmed by the envelope all round without
any blend, whose two sides come back as two groups under "type" - count with `blade_count_section` and pair
the groups by angle.

## 8. Twist without stations

A bar or fin of constant section that only twists is one Swept with an angular law - see "Twist" in
`nxopen-recipes.md` (`scripts/swept_twist.py`).
