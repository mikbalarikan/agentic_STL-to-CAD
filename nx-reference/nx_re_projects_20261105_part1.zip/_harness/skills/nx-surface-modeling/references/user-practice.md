# What the user's parts show - surface modelling

Source: 691 dumped parts under `H:\My Drive\111 UP UP UP\` (38 agent-built ones excluded), mined into
`C:\NX_MCP_WORKSPACE\skill_census\extracts`. Counts are feature instances unless stated. Many dumps are
session snapshots of the same part (the fan volute appears 22 times), so "parts" is inflated: Sew is in
83 dumps but 37 distinct part names, Trim Sheet 49 / 12, Thicken 54 / 17, Unsew 28 / 8. The rarer
features are not affected (Through Curves 10 / 10, Law Extension 20 / 20, Trim and Extend 17 / 17).

## Frequencies

| Feature (FeatureType) | Instances | Dumps | Typical neighbours (previous -> next) |
|---|---|---|---|
| Extract Face/Body (EXTRACT_BODY 1342, LINKED_BODY 322, LINKED_FACE 250, EXTRACT_FACE 17) | 1931 | 212 | pattern/instance containers -> `SUBTRACT` 154, `REPLACE_FACE` 144, `UNITE` 140 |
| Sew (SEW) | 355 | 84 | Trim Sheet 106, Bounded Plane/Ruled 45, Trim Body 43, Extend Sheet 39 -> Trim Sheet 73, Edge Blend 72, Unsew 24 |
| Trim Sheet (TRIMMED_SH) | 346 | 49 | Trim Sheet 87, Sew 73, Trim Body 32, Extend Sheet 31 -> Sew 106, Trim Sheet 87, Trim Body 55 |
| Extend Sheet (EXTEND_SHEET) | 294 | 76 | Extend Sheet 78, Trim Body 49, Sew 22 -> Extend Sheet 78, Trim Body 60, Sew 39, Trim and Extend 26 |
| Fit Surface (Plane 223, Cylinder 9, Cone 2, Freeform 1) | 258 | 64 | Fit Surface 152 -> Fit Surface 151, Datum Plane 47, Replace Face 18 |
| Bounded Plane (SKIN) | 127 | 43 | Sketch 27, Extrude 24 -> Sew 45, Trim Body 42 |
| Trim and Extend | 102 | 17 | Trim and Extend 37, Extend Sheet 26, Sew 13 -> Trim and Extend 37, Trim Body 12 |
| Thicken (THICKEN_SHEET) | 88 | 57 | Edge Blend 39, Offset Region 20 -> (next sketch) 40, `SUBTRACT` 7, `UNITE` 5 |
| Law Extension (LAWEXTENSION) | 70 | 21 | Trim Body 16, Law Extension 12, Sweep 7 -> Trim Body 31, Law Extension 12, Sew 7 |
| Unsew | 56 | 28 | Sew 24, Trim Sheet 23 -> Trim Sheet 23, Sew 23 |
| Through Curves (THRU_CURVE) | 41 | 11 | Sketch 11, Trim Sheet 7, Offset Curve in Face 6 -> `UNITE` 10, Trim Sheet 9, Enlarge 7, Sew 5, Shell 5 |
| Sweep Along Guide (SWP104) | 38 | 15 | Sketch 32 -> Pattern Geometry 10, Extend Sheet 7, Replace Face 6 |
| Studio Surface | 37 | 9 | Studio 8, Bridge Curve 6, Delete Face 4 -> Studio 8, Trim Body 7, Extend Sheet 6 |
| Offset Surface (OFFSET) | 33 | 9 | Offset 10, Extend Sheet 7 -> Offset 10, Extend Sheet 5, Untrim 4 |
| Fill Surface (FILL_HOLE) | 32 | 11 | Fill 7, Trim Body 5 -> Fill 7, Sew 7, Trim Sheet 4 |
| Section Surface (SECTION_SURF) | 29 | 6 | Section Surface 16, Law Extension 6 -> Section Surface 16, Curve on Surface 6 |
| Untrim | 24 | 5 | Untrim 10, Offset 4 -> Untrim 10, Sew 6, Extend Sheet 4 |
| Through Curve Mesh | 16 | 6 | Mesh 6, Line 4 -> Mesh 6, Sew 4 |
| Enlarge | 15 | 6 | Through Curves 7, Section Surface 3, Studio 3 -> Trim Sheet 4 |
| Swept (SKIN) | 9 | 7 | curves -> datum/extrude |
| Emboss | 6 | 6 | always Extrude -> Emboss -> Extrude, taper 15 deg |
| Ruled (SKIN) | 5 | 3 | between Bounded Plane / Trim Sheet |
| N-Sided Surface | 2 | 2 | one suppressed with an error |
| Patch Openings | 2 | 1 | Trim and Extend -> Patch Openings -> Sew |

Sheet-mode solids: 77 of 1540 read-back Extrudes are `BodyType = Sheet` (39 dumps; sections `RegionBoundary` 22,
`CurveFeature` 21; next feature a Bounded Plane/Ruled 21 times); 8 of 87 Revolves; 6 of 35 Sweeps Along Guide.

## Settings the user leaves or sets

- **Tolerance 0.01 everywhere**: Sew 268 of 271 (three at 0.001), Trim Sheet 260/260, Extend Sheet 251/251,
  Thicken 85/85, Through Curves `PositionTolerance` 40/40, Fill 29/29, Offset 33/33, Trim and Extend 75/75.
  Tangent / curvature tolerance 0.5.
- **Sew**: `Type = Sheet` always; one target, tools 1 (228), 2 (25), up to 9. Parent lists run to 29
  features: the quilt is grown one sheet at a time.
- **Trim Sheet**: `Keep` 180 / `Discard` 80; boundary an `ScCollector` (faces, 162) or a `Section` (curves, 98),
  both in 20; `ProjectDirectionMethod = FaceNormal` 248, `Vector` 12 (along Y 6, X 6);
  `ExtendBoundaryObject = True` 248; `AllowTargetEdgesAsToolObjects` False 224; 1 region point in 226,
  2 in 33. Targets come from Extrude (325 parent links), Bounded Plane (171), imported Body (84), Unsew (42).
- **Extend Sheet**: `LimitMethod = Offset` 248 of 251 (`UntilSelected` 3); `SurfaceShapeOption = NaturalCurvature`
  251; `SideEdgeShapeOption = Automatic` 245; `BodyOutputOption = ExtendOriginalSheet` 229, `ExtendasNewSheet` 22.
  Edges by `EdgeDumb` (180) or `EdgeTangent` (71); 1 edge in 122. Distances: 19 (42), 28 (36), 5 (30), 2 (24),
  0.5 (22), -0.9 (21); median 5, range -2 to 64; 27 negative.
- **Trim and Extend**: `Operation = MakeCorner` 70 of 75; `ArrowSideOption = Retain`; `CombineOption = True` 72;
  targets and tools by `FaceBody` rule (whole sheet); `ReverseTarget` True 21, `ReverseTool` True 32.
- **Thicken**: First Offset 1.8 (36), 1.5 (23), 2 (5), 3 (4); Second Offset 0 in 87 of 88; `ReverseDirection`
  False 51 / True 34; `ApproximateOffset = True`; `FaceBody` rule 73 (bodies of 18 and 22 faces), single faces 10;
  boolean `Create` 79, `Subtract` 3, `Unite` 3. Parent is an Edge Blend in 57.
- **Bounded Plane**: boundary rules `CurveFeatureChain` (sketch) 22, `EdgeChain` 21 (8 chains), `EdgeTangent` 12,
  `CurveFeatureTangent` 11; curve types Arc+Line 38, Line 34, Spline 15.
- **Through Curves**: 2 sections (38 of 40), 3 (2); `BodyPreference` Sheet 25 / Solid 15; `PatchType = Multiple`;
  `PreserveShape` False 35 / True 5 (all five with Parameter alignment); `AlignType` Parameter 18, ArcLength 12,
  SpineCurve 10; continuity first/last: G0/G1 19, G1/G1 10, G0/G0 8, G1/G0 3, constraint faces by `FaceTangent`
  or `FaceDumb`; `FlowDirection` Perpendicular 22 / NotSpecified 18; rebuild Cubic degree 3, never changed.
  Sections: `CurveFeatureTangent` (sketch) 16, `EdgeTangent` 6-11, `CurveDumb` 3-9; splines 19-22, arc+line 10.
- **Through Curve Mesh**: always Sheet, `Emphasis = Both`, primaries 2 (14), crosses 2 (12) or 3 (4), dumb curves;
  G1 to faces at the primaries in 2.
- **Studio Surface**: always Sheet; 2 sections (32) + 2 guides (29), 6 with no guides; `AlignType` ArcLength 32;
  G1 at first section 27, last section 25, at guides 8-9; `Transition = NormalToEndSections`; splines and arcs.
- **Swept**: 1 section + 1 guide, `OrientationOption = Fixed`, `ScalingOption = Constant`, Solid 5 / Sheet 1,
  `SectionLocation = AnywhereAlongGuides` 5.
- **Sweep Along Guide**: Solid 29 / Sheet 6; `Create` 23 / `Subtract` 12; offsets 0; guide arcs (17) or arc+line (12);
  section from solid edges (`EdgeDumb` x4, 14) or a sketch.
- **Fill Surface**: `DefaultEdgeContinuity` G1 26 / G0 3; `Patch` False 26 / True 3; boundary 2-7 curves as
  `EdgeChain` rules, splines mostly; shape control untouched except 2 with pass-through curves.
- **Offset Surface**: one face set, `OneFeatureForConnectedFaces`, distances .1 (6), 2 (4), 1.5 (3).
- **Law Extension**: constant laws only. (length, angle): (1, 45) 24, (5, 0) 6, (1.5, 90) 5, (0.56, 45) 4,
  (0.56, 90) 4, (1, 90) 4, (3, 45) 4. No builder read-back was captured.
- **Enlarge**: `ExtensionType = Natural`, percent values U/V 0-45 (10, 18, 28, 45), `IsCopy = False`, anchor Center.
- **Untrim**: one face, `Associative = False`, `HideOriginal = False`; 18 parametric, 5 planar faces.
- **Unsew**: by face (`FaceDumb`), 1 face (24) or 5 (21), `OneBodyForConnectedFaces`, `KeepOriginal = False`.
- **Extract**: `Type` Body 506 / Face 212; body copies `Associative + FixAtCurrentTimestamp` 350;
  `ParentPart` WorkPart 361 / OtherPart 357 (WAVE links); `SurfaceType = SameAsOriginal`; `CopyThreads` True 495.
- **Section Surface** (type names as the OLD builder reads them back = the NX 8.5 names; NX 2206 names, inputs
  and verified recipes: `option-semantics.md` section 6. PointRadiusAngleArc = Circular / Radius-Angle-Arc and
  TwoPointRadius = Circular / Two Point Radius are verified there; the EndsApexShoulder read-back shows no
  guides, so it may be a default and not the real type): `Type` EndsApexShoulder 18, PointRadiusAngleArc 9, TwoPointRadius 2;
  spine = sketch curve or edge (arc 21, spline 8); `StartSurface` one face (`FaceTangent` 18); constant laws:
  radius 60 / 30 / 19.3 / 19, angle 10 / 8 / 30 / 25, rho 0.5; `UDegree = Conic`, V cubic; G0 both ends.
- **Fit Surface** (unverified, scan input): `Type` Fitplane 93, Fitcylinder 9, Fitcone 2, Fitfreeform 1;
  `TargetOption = FacetRegion`; `BodyTypePreference = Sheet` 104; `DirectionOption = BestFit`; rejection threshold
  0.1 (22) / 0.07 (11) when not automatic; degree 5, 1 patch; constrained to a vector in 4.
- **Trim Body tools**: `ToolOption` FaceOrPlane 343 / NewPlane 195; `ReverseDirection` True 123. FaceOrPlane
  trims directly follow Extend Sheet 44, Trim Sheet 31, Bounded Plane/Ruled 22, Sew 13, Law Extension 10.

## Solid by surfacing, or solid trimmed by a surface?

- **Sew to solid / thicken** when the whole skin is freeform or rebuilt from scan regions: fan volute,
  A8S chassis patches (a closed sewn block is then `SUBTRACT`ed or `UNITE`d), PLDR shells (mesh patches ->
  Sew -> Unite -> Shell).
- **Trim Body / Replace Face with a sheet** when a prismatic solid needs one shaped face: Law Extension ->
  Trim Body 31, Extend Sheet -> Trim Body 59, Bounded Plane -> Trim Body 43; Replace Face follows
  Linked Face 102 times (WAVE-linked mating surfaces).
- **Closed loft as solid** for simple transition bodies: Through Curves `Solid` -> `UNITE` 10, -> `SHELL` 5.

## Representative trees

1. `LANTURN RE\reverse engineered\Fan_Volute\Fan_Volute\Fan volute BT cad.prt` (117 features)
   `SKETCH > EXTRUDE > SKETCH > EXTRUDE > SKIN > TRIM BODY > ... > SKIN > TRIM BODYx3 > EXTEND_SHEET > SKETCH > EXTRUDE >
   TRIM BODY > TRIMMED_SH > UNSEW > TRIMMED_SH > TRIM BODY > EXTEND_SHEETx2 > TRIMMED_SHx3 > TRIM BODY > SEW > TRIMMED_SH >
   SEW > TRIMMED_SH > SEW > UNSEW > SEW > TRIMMED_SH > EXTEND_SHEET > SEW > BLENDx4 > THICKEN_SHEET > (ribs and bosses by extrude)`
   Reading: the volute skin is made from sheet extrudes and bounded planes, cut to each other and sewn one
   joint at a time, blended as a quilt, and only then given its 1.5 mm wall with one Thicken.
2. `REMAKE AI - DIY\A8S previous project\CAD DATA\C- Chassis - Structural Base\A8S-C06\A8S-C06.prt`
   `BREPx2 > Fit Surface(Cylinder) > EXTEND_SHEETx2 > OFFSET > EXTRUDE > EXTEND_SHEETx3 > TRIM_AND_EXTENDx2 > SKETCH >
   EXTRUDE > SEW > TRIM_AND_EXTEND > SEW > UNITE > BLENDx2 > ... > REPLACE_FACE > OFFSET > EXTEND_SHEET > TRIM BODY > BLEND > UNITE`
   Reading: scan rebuild. A fitted cylinder and its offset are extended past each other, cornered with
   Trim and Extend, closed with an extrude, sewn into a solid block and united with the imported body.
3. `REMAKE AI - DIY\A8S previous project\CAD DATA\C- Chassis - Structural Base\A8S-C07\A8S-C07-01.prt`
   `Fit Surface(Plane)x2 > Geometry Instance > EXTRACT_BODY > EXTEND_SHEET > TRIM_AND_EXTEND > EXTEND_SHEET >
   TRIM_AND_EXTENDx2 > DATUM_PLANE > TRIM BODY > SKIN > SEW > TRIM BODY > REPLACE_FACEx2`
   Reading: fitted planes become a clean corner (extend, make corner), a bounded plane closes it, Sew makes
   the tool, Trim Body / Replace Face put the clean faces onto the solid.
4. `ARCHIVED\PLDR\Assembly_Final.prt`
   `SKETCH > DATUM_PLANEx2 > THRU_CURVE > ... > THRU_CURVE_MESH > DATUM_PLANE > THRU_CURVE_MESHx3 > SEW > ... >
   THRU_CURVE_MESHx2 > SKINx2 > SEW > EXTRUDE > UNITE > SKIN > SEW > MOVE_OBJECT > UNITE > ... > SPLIT BODY > SHELLx2 > ... >
   THRU_CURVE > EXTEND_SHEET > SEW > TRIM BODY > THICKEN_SHEET > UNITE > BLENDx2`
   Reading: an industrial-design shell. Mesh patches on a sketch/datum-plane wireframe are sewn and capped
   into a solid, united, shelled; later details are lofted sheets thickened and united.
5. `ARCHIVED\BTB-55-EDIT-7\BTB-55_edit-2\BTB-55_edit-2\BTB-55\UA24-N_12_stp-1.prt`
   `EXTRUDEx3 > SECTION_SURF > ENLARGE > SECTION_SURFx2 > TRIM BODY > LAWEXTENSIONx3 > SEWx3 > TRIM_AND_EXTENDx2 >
   TRIM BODYx2 > ... > Studio Surface > TRIM BODY > FILL_HOLE > TRIMMED_SH > ... > FILL_HOLE > TRIMMED_SH > SEW > BLEND`
   Reading: class-A style patching on an imported body: section surfaces and law extensions build the
   primary skins, studio surfaces and fill surfaces close the transitions, every patch is trimmed and sewn.
6. `ARCHIVED\I LOUPE\3rd Draft_rev\OpticalHousing_2.8X.prt` (around feature 127)
   `SWP104 > LAWEXTENSION > LAWEXTENSION > TRIM BODY > THICKEN_SHEET (0.5) > UNITE > SUBTRACT > CHAMFER`
   Reading: a lip. Two law extensions (length 0.56 at 45 deg and at 90 deg) off a swept face are trimmed,
   thickened 0.5 and united - a thin feature made from a sheet where a sketch would be awkward.
