# NXOpen recipes - surface modelling (NX 2206, Python, run_journal)

All code assumes `import nxh`, `part = nxh.new_part(...)`, and these aliases:

```python
GU = NXOpen.GeometricUtilities; NF = nxh.NULL_FEATURE; NULLO = NXOpen.NXObject.Null
RF = part.ScRuleFactory; F = part.Features
SHEET, SOLID = GU.FeatureOptions.BodyStyle.Sheet, GU.FeatureOptions.BodyStyle.Solid
```

Runnable, measured versions of every VERIFIED recipe: `scripts/surf_build.py` (result PASS, 30 checks)
and `scripts/surf_edit.py` (PASS, 43 checks). Numbers below are from those runs and the probe journals.

## Status

| Feature | Status | Key measurement (got / expected) |
|---|---|---|
| Through Curves, open sections | VERIFIED | half frustum area 1942.914 / 1942.968 |
| Through Curves, closed -> solid | VERIFIED | volume 29319.96 / 29321.53 (B-surface, -5e-5) |
| Through Curves, 3 sections | VERIFIED | waist and base points on surface, dist 0.0 |
| Through Curves, G1 end constraint | VERIFIED | normal at shared edge (0,0,1); G0 gives (0,-0.555,0.832) |
| Through Curves, PreserveShape polygon | VERIFIED | 6 planar faces, volume 28000.000 / 28000 |
| Section start/direction repair | VERIFIED | twisted 1741 -> 1943; 12567 -> 29320; 20000 -> 28000 |
| Through Curve Mesh | VERIFIED | area 2781.87 / 2781.89, apex on surface |
| Swept, 1 guide, open / closed section | VERIFIED | area 785.398 / 785.398; solid 3941.76 / 3947.84 |
| Swept, 2 sections 1 guide | VERIFIED | 5864.306 / 5864.306 (linear interpolation) |
| Swept, 2 guides | VERIFIED | mid points on surface, dist 0.0 (Uniform and Lateral) |
| Sweep Along Guide solid / sheet | VERIFIED | 1713.982 / 1713.982; 785.398 / 785.398 |
| Studio Surface (2 sections, 0 or 2 guides) | VERIFIED | area 2781.886 / 2781.886 |
| Ruled | VERIFIED | area 1942.96773 / 1942.96775 |
| Extrude / Revolve as sheet | VERIFIED | 1400.0 / 1400; cone 3885.9355 / 3885.9355 |
| Bounded Plane (+ inner hole) | VERIFIED | 1121.4602 / 1121.4602 |
| Fill Surface (planar, hole G1, non-planar) | VERIFIED | 78.5398; patched sheet 1200.0; 2781.886 |
| N-Sided Surface (trimmed, triangular) | VERIFIED | 1600.0 / 1600 (after setting tolerances) |
| Extract Face / Face chain / Body | VERIFIED | 2400; 3200 one body; solid 48000 |
| Offset Surface | VERIFIED | plane z 20 -> 25; R5 -> R6 area 942.478 |
| Extend Sheet | VERIFIED | 942.478 / 942.478; side extension follows the cylinder |
| Law Extension | VERIFIED | 300.0 / 300, height 10 at 90 deg, 7.071 at 45 deg |
| Enlarge | VERIFIED (B-surface only) | V end +25 %: z 40 -> 50; planar face: "Invalid face." |
| Trim Sheet: curves, faces, datum plane, vector | VERIFIED | 450 / 750 / 1121.46 / 392.699 |
| Trim Sheet: two kept regions, curves as separate boundary objects | NOT WORKING | "Invalid retained/discarded regions."; fixed by one Section for all curves (round 3) |
| Trim and Extend, Make Corner (free edges as target) | VERIFIED | upright extended 5 mm to the base, one 2-face body, 1350.0 / 1350; faces as target: "Unable to perform Boolean." |
| Trim and Extend flags (crossing sheets) | VERIFIED (round 3) | `ReverseTool`: target half x 15..40 -> 0..15; `ReverseTarget`: tool half z 0..10 -> -10..0; `ArrowSideOption=Delete` inverts both |
| Parametric loft from associative Line features | VERIFIED (round 3) | 21400.0 -> 33600.0 after width 40->50, height 30->40 (exact) |
| Parametric loft from constrained sketches | VERIFIED (round 3) | both sketches dof 0; 21400.0 -> 33600.0, no feature errors |
| Rule-only section without a seed | VERIFIED (round 3) | start (-20,15,0) for every help point; with a seed: seed end nearest the help point |
| Studio Surface G1, sections only | VERIFIED (round 3) | 0.000 / 0.041 deg to the neighbours (G0: 10.86 / 36.90) |
| Studio Surface G1 with 2 guide strings | PARTIAL (round 3) | one end 0.00 deg, the other 40.97 deg, whichever way the strings are assigned |
| Curve Mesh G1 on the cross boundaries; roles swapped | VERIFIED (round 3) | 0.000 / 0.003 deg; surface identical to the primaries version (max gap 0.000 mm) |
| Swept: 3 guides, scaling, face-normal orientation, spine | VERIFIED (round 3) | guide ends on surface 0.000; 10053.096 / 10053.096; 5864.306 / 5864.306; normal tip 0.000 mm |
| Swept on a filleted L guide | VERIFIED (round 3) | R20: 4591.79 / 4593.98; R2 (< half-width 3): commits, `BodyConsistency` 2 |
| Trim Sheet, several regions | VERIFIED (round 3) | all curves in ONE section: 2 strips kept as 2 bodies (600 mm2); as separate boundary objects only one is honoured |
| Section Surface, circular two guides + radius | VERIFIED (round 3) | area 1313.51 / 1313.56, curvature 0.06667 = 1/15, both guides on the surface |
| Face Blend conic (asymmetric) | VERIFIED (round 3) | offsets (8, 4): face 1 cut back 4, face 2 cut back 8 |
| Face Blend contact curves | VERIFIED (round 3) | sheets trimmed exactly at the curves: legs 8x30 and 4x30 |
| Law Extension miter Blend | VERIFIED where the walls lean outward (round 5 corrects round 3) | corner gaps: ONE body, 4 walls + 4 tangent corner faces (1505.76); walls leaning inward: 4 separate bodies, no error; Sharp joins both ways |
| N-Sided Trim to Boundary | VERIFIED (round 3) | closed 1200.0 (untrimmed 2904); open 3-side loop also 1200.0 (untrimmed 1452) |
| Offset Surface / Thicken of a quilt, tight radius | VERIFIED (round 3) | L quilt 1500 inside / 2100 outside; thicken 5130 / 5670; R5 by 4 ok, by 6 fails (texts below) |
| Through Curves, alignment By Points | VERIFIED | corner ruling 0.00 mm off (Parameter 3.54, Arc Length 3.11) |
| Through Curves, G2 end | VERIFIED | normals 0.00 deg, edge curvature 0.0500 = neighbour 1/20 (G1: 0.0128) |
| Through Curve Mesh, G1 on both primaries | VERIFIED | 0.000 / 0.003 deg to the neighbours (G0: 10.87 deg) |
| Headless continuity check (normals + curvature) | VERIFIED | Ruled chain crease 43.603 / 43.603 deg |
| Face Blend two-face: crossing sheets, no-trim, disjoint bodies | VERIFIED | 861.372 / 861.372; +1 sheet; 1135.619 / 1135.619 |
| Law Extension 60 / 110 deg, 4 edges with Sharp miter | VERIFIED | height 8.660 / 9.397, reach 5.000 / -3.420; one 4-face body 1400 |
| Thicken offset pairs (2,3) (0,3) (-2,3) | VERIFIED | 1200 / 3600 / 6000, z ranges 2..3, 0..3, -2..3 |
| Swept on a sharp-cornered guide | NOT WORKING (by design) | "Some curves in Guide sections not tangent continuous"; Sweep Along Guide 4800.000 |
| Fill Surface per-edge G0 + Patch into Part | VERIFIED | open 5-face box -> solid 48000.0, `BodySheetBoundaries` 4 -> 0 |
| Fill Surface vs N-Sided on a hole in a skin | VERIFIED | Fill 0.00 deg / 0.000 mm; N-Sided 6.2-18.9 deg / 0.43-0.83 mm |
| Four Point Surface | NOT AVAILABLE | no `FourPoint*` builder in NXOpen Python 2206; Fill Surface over 4 lines verified |
| Untrim | VERIFIED | new sheet without the inner loop; plane returns a padded box (409.66) |
| Sew sheets -> sheet; closed -> solid; gaps | VERIFIED | free edges 8 -> 6; solid 29319.96; gap table below |
| Unsew | VERIFIED | 2 bodies back; solid block -> 5-face sheet + 1-face sheet |
| Thicken | VERIFIED | 2400 -> 4200 after `wall_t` 2 -> 3.5; 863.938 / 706.858 / 1570.796 |
| Trim Body with a sheet | VERIFIED | 29752.053 / 29752.053 and 18247.947 other side |
| Replace Face with a sheet face | VERIFIED | 29752.053 / 29752.053 |
| Patch | VERIFIED | 49466.077 / 49466.077; direction by volume test |
| Swept on a helix guide: `Fixed` / `ByVectorDirection` / two helices | VERIFIED (round 4) | 16.573 / 0.0041 / 0.0016 mm from the true helicoid (9 x 13 points) |
| Swept, orientation `ByAngularLaw` (linear, cubic) on a straight guide | VERIFIED (round 4) | volume 2000.03 / 2000; end and mid-length corners on the body at 90, 180, 405 deg; left-hand sense |
| Swept `ByAngularLaw` on a closed circular guide | VERIFIED at 180 deg, INVALID at 405 deg | 180: closed ring, 4 faces, 4995.41 (Pappus 5026.55); 405: commits, `BodyConsistency` 2 |
| Patch Openings (Quilted, NSided, Mesh, Notch, Joggle, ByDeletingEdges) | VERIFIED (round 4) | flat wall: 2 x 50.2655 = pi r^2; cylindrical wall: a type-16 patch on the wall, centre 0.000 off |
| Patch Openings `Extension`; Output `Sew` on faces of a solid | NOT WORKING | "Unable to create all requested patch sheet bodies.  Try a different type."; "Faces to patch cannot be from solid body for sew option." |
| Delete Edge | VERIFIED (round 4) | in place: 721.73 -> 750.0 (inner loop) -> 800.0 (notch), 10 -> 4 edges |
| Parting sheet = extruded edges + Sew; Ribbon Builder | VERIFIED (round 4) | 9600.0, 4 faces, free edges 640.0; Ribbon ring 2314.25 (rounded corners) |
| Split Body by parting sheet + patches, not sewn | VERIFIED (round 4) | core 116489.062 / cavity 192000.000, both exact |
| Blade sets (helicoid, profiled, hub-to-shroud), blade count edit | VERIFIED (round 4) | `references/blades.md` |
| Through Curves options: lofting degree, Normal to End Sections, alignment Distance, Preserve Shape, flow direction, rebuild | VERIFIED (round 5) | degree 1: 3 faces, 28.01 deg crease; end tilt 43.06 -> 0.00 deg; flow Perpendicular 90.00 deg; rebuild 0.0014 mm off the sections |
| Curve Mesh: point as a primary, Emphasis, IntersectionTolerance | VERIFIED (round 5) | 3-edge face, G1 crosses 0.006 deg; Both 0.025 / 0.025, Primary 0 / 0.05, Cross 0.05 / 0 |
| Swept: twist-law tangency, Area Law, three guides, PreserveShapeOption | VERIFIED (round 5) | Linear 14.10 deg off, Cubic 0.11; caps 1000.0 / 600.0; three guides commit with the default scaling |
| Law Extension: spine, miter matrix, Vector type, linear law, opposite side | VERIFIED (round 5) | planar rim flange 1120.0 exact (spine Z or Type Vector, Sharp); no spine 3.162 mm out of plane |
| N-Sided with constraint faces | VERIFIED (round 5) | 16.96 / 18.02 deg without, 0.38 / 0.39 deg with `builder.ConstraintFaces` + G1; still 0.18-0.37 mm off the skin |
| Section Surface: Conic Rho / Shoulder (By Faces, By Apex, By Curves), Cubic Fillet Bridge G1 / G2, Circular Three Point / Two Point Radius / Two Point Slope / Tangent-Tangent-Radius / Radius-Angle-Arc | VERIFIED (round 5) | rho read back 0.5 / 0.4142 / 0.7; R10 fillet 942.478; rho 0.8 + Cubic refused |
| Face Blend TrimmingOption; PropagatePastSharpEdges | VERIFIED (round 5) | Short 0..30, Long 0..50, NotSet -5..55; 2 deg kink crossed with PropagationAngle 3 |
| Face Blend Swept section + Spine; law radius | NOT WORKING with the settings tried (round 5) | "The normal directions of face 1 and face 2 do not work with the blend size specified." |
| Trim and Extend, Until Selected (solid target, sheet edge as tool) | VERIFIED (round 5) | 9600.0 / 14400.0; sheet face as tool: "... intersection gaps." |
| Offset Surface: several sets, StepOption, silent loss of a tight face | VERIFIED (round 5) | 5 / 0 + step: 3 faces with a 5 mm shelf; R5 by 6 next to a plane: face missing, no message |
| Variable Offset, Enlarge copy / Linear / negative, Bridge surface G0-G2, Global Shaping To Point | VERIFIED (round 5) | corners 1 / 1 / 5 / 5; plane and sewn face only as a copy; bridge 0.00 deg both sides; centre raised 5.000 |
| Section Surface Hilite / Five Point / Two Slopes / Center types / Linear, Fit Surface, Emboss | UNVERIFIED | user settings only, see `user-practice.md` |

## Measuring sheets (read first)

```python
def sheet_area(part, body):            # nxh.mass() is wrong on sheets: .Area = perimeter*1000, .Volume = area*1000
    uc = part.UnitCollection
    mf = part.MeasureManager.NewFaceProperties(uc.FindObject("SquareMilliMeter"), uc.FindObject("MilliMeter"),
                                               0.999999, list(body.GetFaces()))
    try:    return mf.Area, mf.Perimeter
    finally: mf.Dispose()

free_edges = lambda body: [e for e in body.GetEdges() if len(e.GetFaces()) == 1]

def dist_to(part, body, xyz):          # 0.0 = the surface passes through xyz
    pt = part.Points.CreatePoint(nxh.P(*xyz))
    return nxh.UFS.Modeling.AskMinimumDist(pt.Tag, body.Tag, 0, [0.0]*3, 0, [0.0]*3)[0]

def normal_at(face, xyz):
    parm, _ = nxh.UFS.Modeling.AskFaceParm(face.Tag, [float(v) for v in xyz])
    return list(nxh.UFS.Modeling.AskFaceProps(face.Tag, parm)[5])
```

Evidence for the trap: a 1942.9 mm2 sheet with perimeter 176.7 reported `mass()["area"] = 176706.9`,
`["volume"] = 1942914.3`. Solids are fine. `nxh.bbox` on a B-surface body is loose (R20 -> 20.136).

## Section strings

```python
def string(part, curves=None, edges=None, start=(0, 0, 0), seed=None):
    sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)          # chaining, distance, angle tolerance
    sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
    fill(sec, part, curves, edges, start, seed)
    return sec

def fill(sec, part, curves=None, edges=None, start=(0, 0, 0), seed=None):
    rules = []
    if curves: rules.append(part.ScRuleFactory.CreateRuleCurveDumb(list(curves)))
    if edges:  rules.append(part.ScRuleFactory.CreateRuleEdgeDumb(list(edges)))
    first = seed if seed is not None else (list(curves)[0] if curves else list(edges)[0])
    sec.AddToSection(rules, first, NULLO, NULLO, nxh.P(*start), NXOpen.Section.Mode.Create, False)
```

- `start` = a point near the end of the seed where the string begins. Measured: arc from (10,0,40) to
  (-10,0,40) with `start=(-10,0,40)` reports start (-10,0,40), direction (0,1,0); after
  `sec.ReverseDirection()` it reports (10,0,40).
- `sec.GetStartAndDirection()` -> `(ICurve, Point3d, Vector3d)`.
- Closed loop of 4 lines started at the wrong corner: `sec.SetStartCurveOfClosedLoop(0, nxh.P(x, y, z))`
  with any point on the wanted first curve; it restored start (210,10,30) and direction (1,0,0).
- Closed loop of two arcs started on the wrong side: `sec.SetStartAndDirection(arc, nxh.P(...), nxh.V(...))`.
- Other members: `ReverseDirectionOfClosedLoop(i)`, `ReverseDirectionOfLoop(i)`, `AlignDirectionOfLoop(point, vector)`.
- The user's sections are selection-intent rules, not dumb lists: `CurveFeatureTangent` / `CurveFeature`
  (sketch curves), `EdgeTangent`, `EdgeChain`. Use `RF.CreateRuleCurveFeature([sketch_feature])` or
  edge rules when the surface must regenerate.

## Through Curves - VERIFIED

```python
TCB = NXOpen.Features.ThroughCurvesBuilder
b = F.CreateThroughCurvesBuilder(NF)
try:
    b.PreserveShape = False                       # True: one face per segment, sharp corners kept
    b.PatchType = TCB.PatchTypes.Multiple         # Single | Multiple | MatchString
    b.PositionTolerance = 0.01; b.TangentTolerance = 0.5
    b.BodyPreference = TCB.BodyPreferenceTypes.Sheet        # Solid needs every section closed
    for s in sections: b.SectionsList.Append(s)
    b.Alignment.SetSections(sections)
    b.Alignment.AlignType = GU.AlignmentMethodBuilder.Type.Parameter   # ArcLength, SpineCurve, Points, Distance, Angle...
    b.FirstSectionContinuity.ContinuityType = GU.Continuity.ContinuityTypes.G1      # G0 | G1 | G2
    b.FirstSectionContinuity.ConstraintFaces.ReplaceRules([RF.CreateRuleFaceDumb(neighbour_faces)], False)
    feat = b.CommitFeature()                      # FeatureType THRU_CURVE, class ThroughCurves
finally:
    b.Destroy()
```

- Closed sections + Solid: 3 faces (2 planar caps + 1 B-surface), 2 edges, no seam edge. Same sections
  + Sheet: 1 face, 2 free edges.
- Three circles R20/R12/R20: solid 27744.03 (Parameter) vs 27744.56 (ArcLength); points on the waist
  circle and base circle are on the surface.
- G1 needs the section to be an edge of the constraint face. Measured G1 loft area 1514.04 vs the flat
  G0 result 1442.22. `LastSectionContinuity` works the same way. `FlowDirection.FlowDirectionType`
  (user: Perpendicular 22 / NotSpecified 18) was left at default.
- PreserveShape False on squares: 2 B-surface side faces, volume 27999.997, bbox overshoot 0.009.
  PreserveShape True: 6 planes, exact.
- Failure mode is silent twist (see Section strings). Always compare area/volume with the expectation.

## Through Curve Mesh - VERIFIED

```python
b = F.CreateThroughCurveMeshBuilder(NF)
try:
    b.PositionTolerance = 0.01; b.IntersectionTolerance = 0.01; b.TangentTolerance = 0.5   # defaults 0.0254 / 0.02
    for s in primaries: b.PrimaryCurvesList.Append(s)       # each primary one string, all the same direction
    for s in crosses:   b.CrossCurvesList.Append(s)         # crosses must meet the primaries within IntersectionTolerance
    feat = b.CommitFeature()                                # THRU_CURVE_MESH
finally:
    b.Destroy()
```

`Emphasis` (Both | Primary | Cross), `BodyPreference`, `FirstPrimaryContinuity` / `LastPrimaryContinuity` /
`FirstCrossContinuity` / `LastCrossContinuity` (same `Continuity` object as Through Curves), `Spine`.
Test: 2 arcs (R25) x 2 lines -> cylindrical patch, area 2781.87 (analytic 2781.89), apex distance 0.0.

## Swept - VERIFIED

```python
b = F.CreateSweptBuilder(NXOpen.Features.Swept.Null)
try:
    b.G0Tolerance = 0.01; b.G1Tolerance = 0.5
    for s in sections: b.SectionList.Append(s)
    b.AlignmentMethod.SetSections(sections)
    for g in guides: b.GuideList.Append(g)                   # 1 to 3
    b.ScalingMethod.ScalingOption = GU.ScalingMethodBuilder.ScalingOptions.Uniform   # REQUIRED with 2 guides (or Lateral)
    b.BodyPreference.BodyType = SHEET                        # SOLID with a closed section
    feat = b.CommitFeature()                                 # FeatureType SKIN, class Swept
finally:
    b.Destroy()
```

- `ScalingOptions`: Constant, ByBlendingFunction, ByAnotherCurve, ByAPoint, ByAreaLaw, ByPerimeterLaw
  (one guide); Uniform, Lateral (two guides). Two guides without it: `NXException: Invalid input scaling method`.
  Three guides need no scaling option (Round 5).
- `OrientationMethod.OrientationOption` (one guide): Fixed (user 6 of 6), ByFaceNormals, ByVectorDirection,
  ByAnotherCurve, ByAPoint, ByAngularLaw, ByForcedDirection. `InterpolationOption` Linear | Cubic | Blend
  for several sections; `SectionLocation` AnywhereAlongGuides | EndsOfGuides.
- Circle R4 along a quarter arc R50 as solid: 3941.76 vs analytic 3947.84 (-0.15 %), faces type 43.
  Two circle sections R4 -> R8 on a line, Linear: 5864.306 exact.

## Sweep Along Guide - VERIFIED

```python
b = F.CreateSweepAlongGuideBuilder(NXOpen.Features.SweepAlongGuide.Null)
try:
    b.Section.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves); fill(b.Section, part, curves=sec_curves, start=p0)
    b.Guide.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves);   fill(b.Guide, part, curves=guide_curves, start=g0)
    b.FirstOffset.RightHandSide = "0"; b.SecondOffset.RightHandSide = "0"
    b.FeatureOptions.BodyType = SOLID
    b.BooleanOperation.Type = nxh.BOOL.Create               # Subtract/Unite + SetTargetBodies([body]) as in Extrude
    feat = b.CommitFeature()                                # FeatureType SWP104, class SweepAlongGuide
finally:
    b.Destroy()
```

`Section` and `Guide` are read-only properties: fill them in place. 6x4 rectangle along line 40 + tangent
arc R20 (90 deg): volume 1713.982 = 24 x (40 + 10 pi), faces 6 planes + 2 cylinders (exact geometry).

## Studio Surface - VERIFIED (sections +/- guides, G0)

```python
b = F.CreateStudioSurfaceBuilder(NF)
try:
    b.PositionTolerance = 0.01; b.TangentTolerance = 0.5; b.IntersectionTolerance = 0.01
    for s in sections: b.SectionList.Append(s)
    b.AlignmentMethod.SetSections(sections)
    for g in guides: b.GuideList.Append(g)
    b.BodyPreference.BodyType = SHEET
    feat = b.CommitFeature()                                 # FeatureType "Studio Surface"
finally:
    b.Destroy()
```

Continuity objects: `FirstSectionContinuity`, `LastSectionContinuity`, `FirstGuideContinuity`,
`LastGuideContinuity` (set as in Through Curves; G1 not probed here). `Transition`: NormalToEndSections
(user 37 of 37) | NormalToAllSections | Cubic | LinearAndBlend | NoEndConstraint.
`F.FreeformSurfaceCollection.CreateStudioSurfaceBuilderEx` also exists (not probed).

## Ruled - VERIFIED

```python
b = F.CreateRuledBuilder(NF)
try:
    b.PositionTolerance = 0.01
    for sec, c, p in ((b.FirstSection, c1, p1), (b.SecondSection, c2, p2)):
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints); fill(sec, part, curves=c, start=p)
    b.AlignmentMethod.SetSections([b.FirstSection, b.SecondSection])
    b.BodyPreference.BodyType = SHEET
    feat = b.CommitFeature()                                 # FeatureType SKIN, class Ruled
finally:
    b.Destroy()
```

Assigning new Section objects to `FirstSection`/`SecondSection` fails at commit with "No profile selected";
fill the builder's own sections.

## Sheet-mode Extrude / Revolve - VERIFIED

`b.FeatureOptions.BodyType = SHEET` on `ExtrudeBuilder` / `RevolveBuilder` (also on SweepAlongGuide).
Closed rectangle as sheet: 4 faces, area 1400 = perimeter x height, 8 free edges. An open section yields
a sheet even with the default (Solid). Revolve also needs `b.Tolerance = 0.01`, `b.Axis = nxh.axis(part, origin, vec)`,
limits in degrees through `b.Limits.StartExtend.Value.RightHandSide`. A line revolved 360 deg gives a true cone (type 17).

## Bounded Plane - VERIFIED

```python
b = F.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
try:
    b.BoundingCurves.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    fill(b.BoundingCurves, part, curves=loop_curves, edges=loop_edges, start=p0)   # outer loop + inner loops in one go
    feat = b.CommitFeature()                                 # FeatureType SKIN, class BoundedPlane
finally:
    b.Destroy()
```

Capping an open loft: pass the free edges at one end (`[e for e in tube.GetEdges() if abs(nxh.bbox(e)[5]) < 1e-6]`).

## Fill Surface (FillHole) - VERIFIED

```python
FHB = NXOpen.Features.FillHoleBuilder
b = F.FreeformSurfaceCollection.CreateFillHoleBuilder(NXOpen.Features.FillHole.Null)
try:
    b.Tolerance = 0.01
    b.CurveChain.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    fill(b.CurveChain, part, edges=hole_edges, start=p0)     # ONE closed loop of edges and/or curves
    b.DefaultEdgeContinuity = FHB.ContinuityTypes.G1         # face-owned edges come out G1 whatever is set here
    # per-edge G0 (needed on sharp edges, else "Some edge cannot have G1 continuity."):
    # items = []
    # for e in hole_edges:
    #     bc = FHB.BorderContinuity(); bc.BorderObject = e; bc.Continuity = FHB.ContinuityTypes.G0; items.append(bc)
    # b.SetBorderTypeItems(items)
    b.Patch = False                                          # True: sewn into the sheet that owns the edges
    feat = b.CommitFeature()                                 # FeatureType FILL_HOLE, name "Fill Surface(n)"
finally:
    b.Destroy()
```

- Hole R5 in a 40x30 sheet: `Patch=False` -> separate sheet 78.540; `Patch=True` -> same body, 2 faces, area 1200.0.
- Four non-planar curves (2 arcs + 2 lines), G0: NX returned the exact cylinder (type 16), area 2781.886.
- Extra edges in the chain: "Unable to handle multiple loops in hole boundary." Select the hole edges by
  type (`e.SolidEdgeType == NXOpen.Edge.EdgeType.Circular`) or position, not by a loose bbox filter.
- `ShapeControlType` (NotSet | Fullness | PassThroughCurves | FitToPoints | FitToFacet), `SelectPassThrougCurves`.

## N-Sided Surface - VERIFIED

```python
NSB = NXOpen.Features.NSidedSurfaceBuilder
b = F.CreateNSidedSurfaceBuilder(NXOpen.Features.NSidedSurface.Null)
try:
    b.PositionTolerance = 0.01; b.TangentTolerance = 0.5; b.CurvatureTolerance = 0.5   # all default to 0.0
    b.Type = NSB.SurfaceType.TrimmedPatch                    # or TriangularPatch (one face per side)
    b.OuterLoop.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves); fill(b.OuterLoop, part, curves=loop, start=p0)
    b.UVOrientation = NSB.UVOrientationType.Area
    b.TrimToBoundary = True                                  # False returns the untrimmed rectangular patch
    feat = b.CommitFeature()
finally:
    b.Destroy()
```

Without the tolerances: `NXException: Unable to build surface.` Pentagon: trimmed 1 face 1600.0; triangular 5 faces 1600.0.
Next to existing faces add the constraint faces (Round 5, "N-Sided with constraint faces") - without them the
patch is creased against its neighbours.

## Extract Face / Body - VERIFIED

```python
EFB = NXOpen.Features.ExtractFaceBuilder
b = F.CreateExtractFaceBuilder(NF)
try:
    b.Type = EFB.ExtractType.Face                            # Face | RegionOfFaces | Body
    b.FaceOption = EFB.FaceOptionType.SingleFace; b.ObjectToExtract.Add(face)
    # several faces -> one sheet: FaceOption = FaceChain; b.FaceChain.ReplaceRules([RF.CreateRuleFaceDumb(faces)], False)
    # whole body: b.Type = Body; b.ExtractBodyCollector.ReplaceRules([RF.CreateRuleBodyDumb([body], True)], False)
    b.Associative = True; b.FixAtCurrentTimestamp = False
    feat = b.CommitFeature()                                 # EXTRACT_FACE / EXTRACT_BODY, class ExtractFace for both
finally:
    b.Destroy()
```

User defaults: body copies `Associative=True, FixAtCurrentTimestamp=True` (350 of 506); `SurfaceType=SameAsOriginal`.

## Offset Surface - VERIFIED

```python
b = F.CreateOffsetSurfaceBuilder(NF)
try:
    b.Tolerance = 0.01
    b.FaceSets.Append(part.FaceSetOffsets.CreateFaceSet("5", nxh.collector(part, faces=faces), False, 0))  # (dist, collector, flip, 0)
    feat = b.CommitFeature()                                 # FeatureType OFFSET, new sheet body
finally:
    b.Destroy()
```

Positive distance follows the face normal: top face of a block z 20 -> 25, flip=True -> 15; cylinder R10 -> R12
(area 2261.947). The distance becomes expression "Set1 D".

## Extend Sheet - VERIFIED

```python
ESB = NXOpen.Features.ExtendSheetBuilder
b = F.TrimFeatureCollection.CreateExtendSheetBuilder(NXOpen.Features.ExtendSheet.Null)
try:
    b.DistanceTolerance = 0.01
    b.LimitMethod = ESB.Limit.Offset                         # or UntilSelected + b.LimitTools
    b.TargetBoundaryEdges.ReplaceRules([RF.CreateRuleEdgeDumb(edges)], False)
    b.Offset.RightHandSide = "10"
    b.SurfaceShapeOption = ESB.SurfaceShape.NaturalCurvature # NaturalTangent | Mirrored
    b.BodyOutputOption = ESB.BodyOutput.ExtendOriginalSheet  # ExtendasNewFace | ExtendasNewSheet
    feat = b.CommitFeature()
finally:
    b.Destroy()
```

Half cylinder R5: end edge +10 -> area pi*5*60; straight edge +3 -> the cylinder keeps curving (lowest z
-2.823 = -5 sin(3/5)). `ExtendasNewSheet` leaves the original and adds a 157.08 mm2 strip body.
The user also uses negative offsets (27 of 251) to pull an edge back.

## Law Extension - VERIFIED (constant laws, Faces type)

```python
LEB = NXOpen.Features.LawExtensionBuilderEx
b = F.CreateLawExtensionBuilderEx(NF)
try:
    b.Type = LEB.Types.Faces                                 # or Vector + b.Vector
    b.DistanceTolerance = 0.01
    b.BaseProfile.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves); fill(b.BaseProfile, part, edges=[edge], start=p0)
    b.Faces.ReplaceRules([RF.CreateRuleFaceDumb([ref_face])], False)
    b.LengthLaw.LawType = GU.LawBuilder.Type.Constant; b.LengthLaw.Value.RightHandSide = "10"
    b.AngleLaw.LawType = GU.LawBuilder.Type.Constant;  b.AngleLaw.Value.RightHandSide = "90"
    feat = b.CommitFeature()                                 # FeatureType LAWEXTENSION, a NEW sheet body
finally:
    b.Destroy()
```

Angle 0 continues the face (x 40 -> 50), 90 stands on the face normal (z 0 -> 10), 45 gives 7.071/7.071.
Expressions "Length Law 1" / "Angle Law 1". Other law types: Linear, Cubic, ByEquation, ByLawCurve, MultiTransition.
Spine, miter, Vector type, linear law and opposite side: Round 5, "Law Extension options".

## Enlarge - VERIFIED on B-surfaces

```python
b = F.CreateEnlargeBuilder(NXOpen.Features.Enlarge.Null)
try:
    b.Face.Value = face
    rp = b.ResizeParameters                                  # percentages of the face's U/V size
    rp.UStart.Expression.RightHandSide = "0"; rp.UEnd.Expression.RightHandSide = "0"
    rp.VStart.Expression.RightHandSide = "0"; rp.VEnd.Expression.RightHandSide = "25"
    feat = b.CommitFeature()                                 # edits the sheet in place (IsCopy False)
finally:
    b.Destroy()
```

Lofted half frustum, V end 25: height 40 -> 50, area 1942.9 -> 2226.2. `ExtensionType` Natural (user 15 of 15) | Linear.
Bounded-plane face: `NXException: Invalid face.` - in place; with `b.IsCopy = True` a plane (and a face of a
sewn sheet) is enlarged as a new sheet (Round 5, "Enlarge options").

## Trim Sheet - VERIFIED (single region)

```python
TSB = NXOpen.Features.TrimSheetBuilder
b = F.CreateTrimsheetBuilder(NF)                             # note the lower-case "sheet"
try:
    b.Tolerance = 0.01
    b.TargetBodies.Add(sheet)
    b.Regions.Append(part.CreateRegionPoint(part.Points.CreatePoint(nxh.P(x, y, z)), sheet))  # point ON the sheet
    b.KeepDiscardMethod = TSB.KeepDiscardOption.Keep         # the region holding the point is kept (or Discard)
    b.ExtendBoundaryObject = True
    b.BoundaryObjects.Add(string(part, curves=[curve], start=p0))                 # curves, or
    # b.BoundaryObjects.Add(nxh.collector(part, faces=tool.GetFaces()))           # faces of another body, or
    # b.BoundaryObjects.Add(nxh.collector(part, datum_planes=[datum_plane]))      # datum plane via CreateRuleFaceDatum
    # along a vector instead of the face normal:
    # b.ProjectionDirection.ProjectDirectionMethod = GU.ProjectionOptions.DirectionType.Vector
    # b.ProjectionDirection.ProjectVector = nxh.direction(part, (0, 0, -1))
    feat = b.Commit()                                        # FeatureType TRIMMED_SH; edits the sheet in place
finally:
    b.Destroy()
```

- 40x30 sheet, line at x=15, point at x=5: Keep -> 450, Discard -> 750. Circle R5 floating 8 mm above:
  Keep inside -> 78.540 (2 free edges), Discard inside -> 1121.460.
- `ExtendBoundaryObject` False (builder default) with a line that stops short: "Cannot imprint selected
  trimming object onto target sheet body."
- `b.BoundaryObjects.Add(datum_plane_object)`: "Invalid trimming objects." Use the collector.
- Two region points + two boundary strings in one feature: "Invalid retained/discarded regions."
  Do two trims, or keep the middle with one Discard per side.
- `ProjectionOptions.DirectionType`: FaceNormal | Vector | CrvPlaneNormal.

## Trim and Extend (Make Corner) - VERIFIED with free edges as target

Course rule [CAD5.6 00:20:35]: the target is the free EDGES of the sheet that must grow, the tool is the sheet
it must reach. `b.TargetSelection.ReplaceRules([RF.CreateRuleEdgeDumb(free_edges_to_extend)], False)`, tool as
below. Upright sheet ending 5 mm above a base sheet: result one body, 2 faces, upright extended to z=0, base cut
at the corner, area 1350.0 (25x30 + 20x30). With `RF.CreateRuleFaceBody(upright)` as target in that same
configuration: `NXException: Unable to perform Boolean.` Faces as target only worked when the sheets already
cross (block below). `ReverseTarget=True` kept the other half of the tool sheet (x 0..20 instead of 20..40);
`ReverseTool` has nothing to flip when the target is an edge to extend. The full flag table for crossing
sheets is in Round 3 (it supersedes the "never obtained" remark below, which came from a symmetric test).

```python
TEB = NXOpen.Features.TrimAndExtendBuilder
b = F.TrimFeatureCollection.CreateTrimAndExtendBuilder(NXOpen.Features.TrimAndExtend.Null)
try:
    b.DistanceTolerance = 0.01
    b.Operation = TEB.OperationType.MakeCorner               # or UntilSelected
    b.TargetSelection.ReplaceRules([RF.CreateRuleFaceBody(target_sheet)], False)
    b.ToolSelection.ReplaceRules([RF.CreateRuleFaceBody(tool_sheet)], False)
    b.ReverseTarget = False; b.ReverseTool = False
    feat = b.CommitFeature()                                 # one body, CombineOption True by default
finally:
    b.Destroy()
```

Target plane z=0 (x 0..40), tool plane x=20 (z -10..10): result one 2-face body, area 900, sheet count -1.
Measured kept sides: (False, False) -> target x 20..40 + tool z 0..10; (ReverseTarget=True) -> target x 20..40 +
tool z -10..0; (ReverseTool=True) -> same as (False, False). The half x 0..20 was never obtained. Check the
bbox and flip, or use two Trim Sheets + Sew when a specific side is required.

## Untrim - VERIFIED

`b = F.CreateUntrimBuilder(NF); b.FacesToUntrim.ReplaceRules([RF.CreateRuleFaceDumb(faces)], False); b.CommitFeature()`.
Non-associative by default (user 24 of 24), creates a new sheet, original untouched. A disc trimmed out of a plane
came back as a 20.24 x 20.24 square (bbox of the face plus margin), not the original 40x30.

## Sew - VERIFIED

```python
b = F.CreateSewBuilder(NF)
try:
    b.Tolerance = 0.01
    b.TargetBodies.Add(target)
    for t in tools: b.ToolBodies.Add(t)
    feat = b.Commit()                                        # FeatureType SEW; result lives in `target`
finally:
    b.Destroy()
```

| Input | tol | Result |
|---|---|---|
| 2 planar sheets sharing an edge | 0.01 | 1 sheet, 2 faces, free edges 8 -> 6 |
| gap 0.005 | 0.01 | sewn |
| gap 0.05 | 0.01 | `NXException: A tool body does not share a common boundary with any other sheet and will not be sewn.` |
| gap 0.05 | 0.1 | sewn; bbox grows +-0.28 (tolerant edge) |
| loft tube + 2 bounded planes | 0.01 | SOLID, 3 faces, volume 29319.96, sheets -3, solids +1 |
| tube + caps, one cap 0.05 off | 0.01 | no exception; SHEET with 1 free edge (the good cap only) |
| same | 0.1 | SOLID, volume 29342.87 (+0.08 %) |

`Type` Sheet | Solid (solid-to-solid sew of coincident faces), `BodyPreference`, `OutputMultipleSheets`.

## Unsew - VERIFIED

```python
USB = NXOpen.Features.UnsewBuilder
b = F.CreateUnsewBuilder(NXOpen.Features.Unsew.Null)
try:
    b.ToolOption = USB.UnsewTool.Face                        # or Edge + b.EdgeCollector
    b.FaceCollector.ReplaceRules([RF.CreateRuleFaceDumb(faces)], False)
    b.Output = USB.UnsewOutput.OneBodyForConnectedFaces
    feat = b.CommitFeature()
finally:
    b.Destroy()
```

On a solid block with the top face selected: the solid is gone, replaced by a 5-face open sheet (area 6400,
4 free edges) and a 1-face sheet (solids -1, sheets +2).

## Thicken - VERIFIED

```python
b = F.CreateThickenBuilder(NF)
try:
    b.Tolerance = 0.01
    b.FaceCollector.ReplaceRules([RF.CreateRuleFaceBody(sheet)], False)     # user: FaceBody 73 of 85
    b.FirstOffset.RightHandSide = "wall_t"; b.SecondOffset.RightHandSide = "0"
    b.ReverseDirection = False
    b.BooleanOperation.Type = nxh.BOOL.Create
    feat = b.CommitFeature()                                 # THICKEN_SHEET; new solid, the sheet remains
finally:
    b.Destroy()
```

Plane 40x30: 2400 at 2, 4200 after `wall_t=3.5` + `nxh.update()`. Half cylinder R5 x 50 by 1: default side
863.938 (R5..R6), `ReverseDirection` 706.858 (R4..R5), offsets (1, -1) 1570.796 (R4..R6). Which side is
"default" follows the face normal - check the volume.

## Trim Body with a sheet - VERIFIED

```python
b = F.CreateTrimBody2Builder(NXOpen.Features.TrimBody2.Null)
try:
    b.Tolerance = 0.01
    b.BooleanTool.ToolOption = GU.BooleanToolBuilder.BooleanToolType.FaceOrPlane
    b.BooleanTool.FacePlaneTool.ToolFaces.FaceCollector.ReplaceRules([RF.CreateRuleFaceBody(tool_sheet)], False)
    b.TargetBodyCollector = nxh.collector(part, bodies=[solid])
    b.BooleanTool.ReverseDirection = False
    feat = b.CommitFeature()                                 # FeatureType "TRIM BODY"
finally:
    b.Destroy()
```

Block 60x40x20 cut by a cylindrical sheet (normal -Z): `ReverseDirection=False` kept the upper part
(18247.947), `True` the lower (29752.053 = analytic). Solid count unchanged, the sheet stays.

## Replace Face with a sheet face - VERIFIED

```python
b = F.CreateReplaceFaceBuilder(NF)
try:
    b.FaceToReplace.ReplaceRules([RF.CreateRuleFaceDumb([top_face])], False)
    b.ReplacementFaces.ReplaceRules([RF.CreateRuleFaceDumb(list(sheet.GetFaces()))], False)
    b.ReverseDirection = True
    b.OffsetDistance.RightHandSide = "0"
    feat = b.CommitFeature()
finally:
    b.Destroy()
```

Volume 29752.053 (same as the trim). With `ReverseDirection=False`, or with `ReplaceFaces` / `ReplacementFace.Value`
instead of the two collectors above: "A face does not intersect properly and its edges cannot adapt."

## Patch - VERIFIED (direction by test)

```python
b = F.CreatePatchBuilder(NF)
try:
    b.Tolerance = 0.01
    b.Target.Value = solid; b.Tool.Value = tool_sheet        # sheet's free edges must lie on the solid's faces
    b.ReverseDirection = reverse
    feat = b.CommitFeature()                                 # FeatureType PATCH; the sheet is consumed
finally:
    b.Destroy()
```

Cup (frustum wall + lid, 1 free edge on the block top): correct flag gives 49466.077 = 48000 + frustum;
the other flag gives a valid 1466 mm3 solid (only the pocket). The correct flag was `True` for a lofted
cup and `False` for a revolved one, so wrap it: commit, compare volume with intent, `undo_to` and flip
(`patch(part, solid, sheet, grow=True)` in `surf_edit.py`).

## Round 2 - recipes from the course checks (`scripts/surf_course_checks.py`, PASS, 60 checks)

### Alignment By Points (Through Curves, Ruled) - VERIFIED

```python
AT = GU.AlignmentMethodBuilder.Type
b.Alignment.SetSections([s1, s2])
b.Alignment.AlignType = AT.Points
pairs = [[(40, 0, 0), (40, 30, 0), (0, 30, 0)],            # points on section 1, in string order
         [(40, 0, 30), (20, 30, 30), (10, 15, 30)]]        # their partners on section 2 (same count)
dims = [b.Alignment.CreateOnPathDimBuilder(s, nxh.P(*p)) for s, pl in zip([s1, s2], pairs) for p in pl]
b.Alignment.SetAlignPoints(dims)                            # organised section by section
```

Rectangle 40x30 -> triangle (base 40, apex above the middle), both strings started at the same base corner.
Distance of the point half-way up the base-corner ruling / the corner-to-apex ruling from the surface:
Parameter 3.536 / 4.781 mm, Arc Length 3.106 / 4.960, By Points 0.000 / 0.000. Volumes 26875.0 / 26940.8 /
26315.2: all three are valid solids, only the point test tells them apart. Other members: `ComputeDefaultPoints()`,
`GetAllPoints()`, `RemoveAllPoints()`, `NumberOfPointsPerSection`. Enum `Type`: Parameter, ArcLength, Points,
Distance, Angle, SpineCurve, Developable, Segments, SplinePoints.

### G2 at a Through Curves end, and the headless continuity check - VERIFIED

```python
b.FirstSectionContinuity.ContinuityType = GU.Continuity.ContinuityTypes.G2      # Free | G0 | G1 | G2 | G3
b.FirstSectionContinuity.ConstraintFaces.ReplaceRules([RF.CreateRuleFaceDumb(neighbour_faces)], False)
b.CurvatureTolerance = 0.5

def g1_deviation(face_a, face_b, points):                   # points ON the shared edge; 0 deg = tangent
    def ang(u, v):
        return math.degrees(math.acos(max(-1.0, min(1.0, abs(sum(a * c for a, c in zip(u, v)))))))
    return max(ang(nxh.normal_at(face_a, p), nxh.normal_at(face_b, p)) for p in points)

def max_curvature(face, xyz):                               # equal on both sides of the edge = G2 there
    parm, _ = nxh.UFS.Modeling.AskFaceParm(face.Tag, [float(v) for v in xyz])
    radii = nxh.UFS.Modeling.AskFaceProps(face.Tag, parm)[6]            # two principal radii, signed
    return max(abs(1.0 / r) if abs(r) > 1e-9 else 0.0 for r in radii)
```

Loft from the straight edge of a cylindrical sheet (R20) to a line 30 mm away:

| End constraint | Normal deviation at the edge | Max curvature of the loft at the edge (neighbour 0.0500) |
|---|---|---|
| G0 | 11.310 deg | 0.0000 (flat) |
| G1 | 0.000 deg | 0.0128 (R78) |
| G2 | 0.000 deg | 0.0500 (R20) |

A flat face reports radii 3.9e8. This pair of numbers is the journal replacement for Reflection analysis.
`nxh.examine_geometry` is not: on two Ruled patches sewn with a 43.6 deg crease `EdgeSmoothness` and
`FaceSmoothness` are both 0.

### Through Curve Mesh with G1 boundaries - VERIFIED

```python
b.FirstPrimaryContinuity.ContinuityType = GU.Continuity.ContinuityTypes.G1
b.FirstPrimaryContinuity.ConstraintFaces.ReplaceRules([RF.CreateRuleFaceDumb(faces_behind_primary_1)], False)
b.LastPrimaryContinuity...   b.FirstCrossContinuity...   b.LastCrossContinuity...       # same pattern
```

Primaries = edges of two existing sheets (a plane and an arc-extruded sheet), crosses = S-shaped two-arc
strings tangent to both. G0: 10.874 deg off both neighbours, area 2634.95. G1 on both primaries: 0.000 and
0.003 deg, area 2661.58. Cross-boundary G1 was not probed.

### Face Blend, two-face - VERIFIED (rolling ball, constant radius)

```python
FBB = NXOpen.Features.FaceBlendBuilder
b = F.CreateFaceBlendBuilder(NF)
try:
    b.Tolerance = 0.01
    b.FaceBlendDefineType = FBB.DefiningType.BlendTwoFace       # BlendThreeFace | BlendFromEdges
    b.BlendType = FBB.Type.RollingBall                          # or Swept
    b.FirstFaceCollector = nxh.collector(part, faces=faces1)    # RW properties: assign collectors
    b.SecondFaceCollector = nxh.collector(part, faces=faces2)
    b.ReverseFirstFaceNormal = False; b.ReverseSecondFaceNormal = False   # choose the quadrant
    b.CrossSectionType = FBB.CrossSectionOption.Circular        # Conic | ConicSymmetric | Curvature(A)symmetric
    b.CircularCrossSection.Radius.RightHandSide = "3"
    b.TrimInputFacesToBlendFaces = True                         # GUI "Trim Body to Blend"
    b.SewAllFaces = True                                        # GUI "Sew All Faces"
    feat = b.CommitFeature()                                    # FeatureType FACE_BLEND
finally:
    b.Destroy()
```

- Crossing sheets (plane z=0, plane x=20), R3, trim + sew: one sheet body, 2 planes + 1 cylinder R3.000,
  area 861.372 = 17x30 + 7x30 + (pi/2)x3x30, tangent to both sheets (0.00 deg), sheet count 2 -> 1.
- Trim and sew off: the blend is added as a third sheet, originals untouched (1200.0).
- Two sheets 4.243 mm apart (no contact), R5: one sheet, area 1135.619 = 15x30 + 15x30 + (pi/2)x5x30.
- The quadrant is where the two (possibly reversed) normals point at each other. A wrong pair raises e.g.
  "The normal direction of face 2 does not work with the blend size specified." or builds in another
  quadrant: loop over the four flag pairs, accept by area / body count, `undo_to` otherwise
  (`face_blend_auto()`). Flags that worked: crossing (False, False), disjoint (False, True).
- `BlendWidthMethod` ForcedConstant | NaturallyVarying | TwoConstraintCurves (GUI Contact Curve) and
  `ConicCrossSection` (offsets, Rho: GUI Tangent Asymmetric) were not probed.

### Law Extension: other angles and a mitred tray - VERIFIED

Angle is measured from the reference face tangent: 60 deg -> the 10 mm wall rises 8.660 and reaches 5.000
outward; 110 deg -> rises 9.397 and leans 3.420 back over the sheet. All four edges of a 40x30 sheet in one
`BaseProfile`, angle 90, `b.MiterOption = LEB.MiterOptions.Sharp` (Blend | Sharp | NotSet | Radius): one new
sheet body with 4 faces, area 1400.0, not joined to the base sheet (8 free edges) - Sew it afterwards.

### Thicken offset pairs - VERIFIED

The solid occupies offset 1 .. offset 2 along the face normal: (2, 3) -> volume 1200, z 2..3, not touching the
sheet; (0, 3) -> 3600, z 0..3; (-2, 3) -> 6000, z -2..3 (40x30 planar sheet).

### Swept: skewed section and sharp guides - VERIFIED

Circle R4 in the YZ plane swept along a line at 45 deg in XY (`OrientationOption` Fixed): volume 2513.274 =
the sheared prism, not the 3554.306 of a true tube - the section is translated, not turned. Guide of two lines
meeting at 90 deg: `NXException: Some curves in Guide sections not tangent continuous`. The same section and
guide through Sweep Along Guide: mitred elbow, 8 faces, volume 4800.000 = 24 x 200.

### Fill Surface vs N-Sided on a hole, Patch into Part - VERIFIED

Hole R8 in a cylindrical skin and hole R6 in a lofted B-surface skin (edges selected from the trimmed face):

| Patch | Normal deviation at the hole edge | Gap to the original surface at the hole centre |
|---|---|---|
| Fill Surface, G1 (default) | 0.000 / 0.000 deg | 0.000 / 0.000 mm (cylinder skin: exact cylinder, type 16) |
| Fill Surface, every edge set to G0 | 0.000 / 0.000 deg | 0.000 / 0.000 mm |
| N-Sided, Trim to Boundary | 6.177 / 18.921 deg | 0.831 / 0.434 mm |

Fill Surface on a hole inside one face returns the underlying surface whatever the continuity setting, so
this test cannot confirm the course's "all-G0 fill is creased like N-Sided". N-Sided also accepts an open
3-curve loop (`TrimToBoundary=False`, untrimmed patch 1468 mm2).
The N-Sided row is the builder WITHOUT constraint faces. With `b.ConstraintFaces` + G1 it is tangent (0.38 /
0.39 deg) but still 0.18-0.37 mm off the skin: Round 5.
Open 5-face box (block with the top face unsewn): `Patch=True` with per-edge G0 -> the same body is a solid,
48000.0; with the default continuity: "Some edge cannot have G1 continuity."

### Examine Geometry - VERIFIED

`nxh.examine_geometry(part, body)` -> `BodySheetBoundaries` = number of open edges: 4 on the open box, 6 on
two sewn sheets, 0 on the closed solid; every other check 0 on these bodies. Use it as the leak detector
before and after a repair (course CAD4.1), not as a continuity check.

### Four Point Surface - NOT AVAILABLE in NXOpen Python 2206

No `CreateFourPointSurfaceBuilder` on `part.Features` or its sub-collections and no `FourPoint*` class in
`NXOpen.Features` / `NXOpen.GeometricUtilities`. Equivalent: four `nxh.line`s -> Fill Surface (non-planar quad:
all four corners at distance 0.000, 4 boundary edges) or Bounded Plane when planar.

### Stale feature alerts

After a commit that failed and was rolled back with `undo_to`, the next feature created keeps the failed
feature's message in `GetFeatureErrorMessages()` even after `nxh.update()` (seen: a good Face Blend carrying
"The normal direction of face 2 ...", a good Bounded Plane carrying "Unable to perform Boolean."). Measure the
geometry before treating such a message as a failure.

## Round 3 - recipes from `scripts/surf_round3_checks.py` (PASS, 38 checks)

### Parametric sections - VERIFIED

```python
R = part.ScRuleFactory
# (a) associative Line features on smart points (formulas), 4 per rectangle
feats, curves = assoc_rect(part, 0, "aw", "ah", "az")            # see the script; curves skill recipe 7b
sec = nxh.section(part, rules=[R.CreateRuleCurveFeature(feats)], help_point=(-20, -15, 0), seed=curves[0])
# (b) a fully constrained sketch (second one on nxh.datum_plane(part, (0, 0, "sk_z"), (0, 0, 1)))
sec = nxh.section(part, rules=[R.CreateRuleCurveFeature([sketch.Feature])], help_point=(-20, -15, 0), seed=sketch_line_0)
```

Rectangle 40x30 at z=0 to rectangle 20x16 at z=30, Through Curves solid with `PreserveShape=True`:
21400.0 mm3 (prismatoid formula) for both inputs. After `aw`/`sk_w` 40 -> 50 and `az`/`sk_z` 30 -> 40 +
`nxh.update()`: 33600.0, top face at z = 40.000, no feature errors. Both sketches DOF 0 with 0 automatic
dimensions (4 lines, 4 coincident corners, 2 H + 2 V, 4 driving dimensions to the datum axes) - read with
Continuous Auto Dimensioning off, which the script now sets before its first sketch (it carries its own
sketch builder; see `nx-journal-core/SKILL.md` "Sketch DOF"), and the same in the part built with it on.
Start of a rule-only section: with `seed=line0` and the help point at either end of line0 the string starts at
that end; with no seed the start was (-20, 15, 0), direction (0,-1,0) for help points at corner A, corner C
and (500, 500, 0) alike - the help point is ignored. Always pass the seed.

### Studio Surface with G1 - VERIFIED without guides, PARTIAL with guides

`b.FirstSectionContinuity` / `b.LastSectionContinuity` (and `FirstGuideContinuity` / `LastGuideContinuity`):
`.ContinuityType = G1`, `.ConstraintFaces.ReplaceRules([RF.CreateRuleFaceDumb(faces)], False)`.
Neighbour edges as the two sections: G0 10.858 / 36.896 deg; G1 without guide strings 0.000 / 0.041 deg.
With the two S-shaped strings as guides and G1 on both sections: 40.970 / 0.003 deg; roles swapped (strings as
sections, edges as guides, G1 on both guides): 0.000 / 40.970 deg. One end is not honoured when guides and
end constraints are combined; the same wireframe in Through Curve Mesh is 0.000 / 0.003 deg.

### Through Curve Mesh: cross-boundary G1 and swapped roles - VERIFIED

`b.FirstCrossContinuity` / `b.LastCrossContinuity` take the same settings. Neighbour edges as crosses and the
S strings as primaries, G1 on both cross boundaries: 0.000 / 0.003 deg, area 2661.578 - the same numbers as
edges-as-primaries, and the two surfaces coincide (max distance over a 3x3 grid 0.000 mm).

### Swept options - VERIFIED

```python
SO = GU.ScalingMethodBuilder.ScalingOptions; OO = GU.OrientationMethodBuilder.OrientationOptions
b.ScalingMethod.ScalingOption = SO.Constant;  b.ScalingMethod.ScaleFactor = 2.0
b.ScalingMethod.ScalingOption = SO.ByBlendingFunction
b.ScalingMethod.BlendingFunctionType = GU.ScalingMethodBuilder.BlendingFunctionTypes.Linear      # or Cubic
b.ScalingMethod.StartBlendScaleFactor = 1.0;  b.ScalingMethod.EndBlendScaleFactor = 2.0
b.OrientationMethod.OrientationOption = OO.ByFaceNormals
b.OrientationMethod.Faces.ReplaceRules([RF.CreateRuleFaceDumb(faces)], False)
b.OrientationMethod.OrientationOption = OO.ByVectorDirection
b.OrientationMethod.OrientationVector = nxh.direction(part, (0, 0, 1))
b.Spine.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves); nxh.fill_section(part, b.Spine, curves=[spine_curve], help_point=p0)
```

- Three guides (three `GuideList.Append`), V-shaped two-line section touching all three: both outer guide
  ends, the middle guide end and its midpoint at distance 0.000; 2 faces.
- Circle R4, line guide 50: `Constant` scale 2 -> 10053.096 (= pi 64 50); blend 1 -> 2 Linear -> 5864.306 (exact frustum).
- Straight guide = edge of a twisted ruled face (normal turns 45 deg along it), section = 10 mm line on the
  start normal. `Fixed`: far end translated (0.000 mm from the translated point, 7.071 from the normal's
  tip). `ByFaceNormals`: 0.000 mm from the normal's tip, 7.046 from the translated point. `ByVectorDirection`
  (Z) on this straight guide: same as Fixed.
- Two guides + `Spine` + `Uniform`: builds, guide 2 midpoint on the surface, area 1832.458 (same as without spine here).
- Rectangle 6x4 along line - R20 arc - line: 4591.793 vs 4593.982 (area x length, -0.05 %), Examine Geometry
  clean. The same with R2: commits, volume 4778.988, but `examine_geometry` -> `BodyConsistency` 2 (the inside
  of the bend self-intersects). The course's "radius must rescue the geometry" = radius > section half-width.
  Sweep Along Guide has no such limit.

### Trim Sheet with several cutting curves / regions - VERIFIED

```python
b.BoundaryObjects.Add(nxh.section(part, curves=[line_1, line_2], help_point=p0))   # ONE section for all curves
for xyz in region_points:
    b.Regions.Append(part.CreateRegionPoint(part.Points.CreatePoint(nxh.P(*xyz)), sheet))
```

40x30 sheet, lines at x=10 and x=30. One section: Discard the middle -> the feature owns 2 sheet bodies
(300 + 300, sheet count +1); Keep with a region point in each outer strip -> the same 2 bodies; Keep one
outer strip -> 300. Two sections added separately: Discard middle leaves only x 30..40 (300) with no error,
Keep two strips raises "Invalid retained/discarded regions." Two adjacent regions (quadrants) keep fine.

### Trim and Extend flags - VERIFIED on crossing sheets (target = faces of sheet z=0, tool = sheet x=15)

| ReverseTarget | ReverseTool | ArrowSideOption | Target part kept (x) | Tool part kept (z) |
|---|---|---|---|---|
| False | False | Retain | 15..40 | 0..10 |
| False | True | Retain | 0..15 | 0..10 |
| True | False | Retain | 15..40 | -10..0 |
| True | True | Retain | 0..15 | -10..0 |
| False | False | Delete | 0..15 | -10..0 |
| False | True | Delete | 15..40 | -10..0 |

(The round-1 "no effect" reading came from a symmetric test where both target halves were 20 wide.)

### Section Surface, circular, two guides + radius - VERIFIED

```python
SSB = NXOpen.Features.SectionSurfaceBuilderEx
b = F.CreateSectionSurfaceBuilderEx(NXOpen.Features.SectionSurface.Null)
try:
    b.Type = SSB.Types.Circular                               # Circular | Conic | Cubic | Linear
    b.CircularTypeMode = SSB.CircularType.TwoPointRadius      # RadiusAngleArc, ThreePoint, TangentRadius, ...
    b.G0Tolerance = 0.01; b.G1Tolerance = 0.5
    for sec, curve, p in ((b.SectionStartGuide, g1, p1), (b.SectionEndGuide, g2, p2)):
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves); nxh.fill_section(part, sec, curves=[curve], help_point=p)
    b.SpineType = SSB.Spine.ByCurve                            # or ByVector + b.SpineVector = nxh.direction(...)
    b.SpineSection.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves); nxh.fill_section(part, b.SpineSection, curves=[g1], help_point=p1)
    b.RadiusLaw.LawType = GU.LawBuilder.Type.Constant; b.RadiusLaw.Value.RightHandSide = "15"
    b.BodyTypePreference = SSB.BodyType.Sheet
    feat = b.CommitFeature()                                   # FeatureType SECTION_SURF, class SectionSurface
finally:
    b.Destroy()
```

Two parallel lines 20 apart, length 60, R15: area 1313.51 (minor arc 2 asin(10/15) x 15 x 60 = 1313.56),
curvature 0.06667 at mid-span, both guides at distance 0.000, B-surface (type 43). Spine by curve and by vector
give the same result. The user's 59 Section Surfaces (12 parts, de-duplicated): read-back type
EndsApexShoulder 46 (spine sketch curve + one start face, no guides - a fillet/bridge-style section built on a
face), PointRadiusAngleArc 9 (start guide on a conical face, radius 19-60, angle 8-30 deg), TwoPointRadius 2
(two spline guides, radius 30). Only the last type is verified here; for the other two see `SlopeControl`,
`StartFace`, `AngleLaw`, `CircularType.RadiusAngleArc`.

### Face Blend: conic and contact curves - VERIFIED

```python
b.CrossSectionType = FBB.CrossSectionOption.Conic
b.ConicCrossSection.FirstOffset.RightHandSide = "8"; b.ConicCrossSection.SecondOffset.RightHandSide = "4"
b.ConicCrossSection.Rho.RightHandSide = "0.6"
# contact curves (GUI Width Method = Contact Curve): one curve lying on each face
b.BlendWidthMethod = FBB.WidthMethod.TwoConstraintCurves
col = part.ScCollectors.CreateCollector(); col.ReplaceRules([RF.CreateRuleCurveDumb([curve_on_face_1])], False)
b.ConicCrossSection.FirstConstraintCurveCollector = col        # and SecondConstraintCurveCollector
```

Crossing planar sheets (horizontal leg 20 wide = face 1, upright leg 10 high = face 2), trim + sew:
offsets (8, 4) leave 16 of the horizontal leg and 2 of the upright; (4, 8) leave 12 and 6 - FirstOffset is the
distance the blend climbs on face 2, SecondOffset on face 1. (15, 5): "Radius is too large for the faces
selected." (15 does not fit on the 10 mm upright). Contact lines 12 from the corner on face 1 and 6 on face 2:
legs left 8 and 4 exactly, 3 faces, one sheet body.

### Law Extension miter, N-Sided Trim to Boundary - measured

- Four edges of a flat sheet, `MiterOptions.Sharp`: one body, 4 faces at 80 and at 110 deg. `MiterOptions.Blend`:
  one body with 4 tangent corner faces where the walls lean OUTWARD (8 faces, 1505.76 at 20 deg out), four
  separate one-face walls (300 / 400 / 400 / 300) where they lean inward, no exception and no feature alert.
  Which of 80 / 110 leans outward depends on the profile direction - and this journal fills the profile with
  `list(sheet.GetEdges())`, whose order is not fixed, so it differs from run to run. (An earlier version of this line said "separate at 110 and at 80"; the
  stored result of that run already shows the 8-face body at 110.) The full matrix with spine and Vector type
  is in Round 5; `MiterOptions.Radius` left the walls separate in every try.
- N-Sided on a 40x30 rectangle: closed loop, `TrimToBoundary=True` 1200.0, False 2904.0 (the untrimmed
  patch); three sides only (open): True 1200.0, False 1452.0.

### Offset Surface and Thicken on quilts and tight radii - VERIFIED

`RF.CreateRuleFaceBody(quilt)` as the face rule. L-shaped quilt (40x30 + 20x30, sewn):
offset 5 to the inside -> one 2-face sheet 1500 (35x30 + 15x30), to the outside (flip) 2100 (45x30 + 25x30).
Thicken 3: inside 5130.0, outside 5670.0, one mitred 8-face solid each.
Half cylinder R5: offset 4 inward -> R1, area 157.08; thicken 4 inward 1884.956. Offset 6 inward:
"The Offset Surface operation is unable to provide a full solution. One or more input faces or vertices could
not be offset. Try Enable Partial Offset." Thicken 6 inward: "Cannot offset face. The offset distance might be
greater than the radius of curvature of the face or the offset face might intersect itself."
Remedy: offset towards the convex side, or keep the value below the smallest concave radius (measure it with
`nxh.max_curvature`), or rebuild / blend the tight region first. `OffsetSurfaceBuilder.PartialOption = True` gave the
same error on the lone half cylinder. When the tight face has neighbours that CAN be offset there is no error
at all - the face is silently left out (Round 5, "Offset Surface options").

## Round 4 - blades, twist, mould repair (`blade_*.py`, `swept_twist.py`, `surf_mould_repair.py`, all PASS)

Blade sets have their own file: `blades.md`. The helper module is `scripts/nxblade.py` (`import nxblade as nb`).

### Swept orientation on a curved guide; twist by angular law - VERIFIED

```python
f = nb.swept(part, [sec], [g_root, g_tip], scaling=nb.SO.Uniform)             # two guides
f = nb.swept(part, [sec], [g_tip], orientation="vector", vector=(0, 0, 1))    # ByVectorDirection
f = nb.swept(part, [sec], [guide], orientation="angular", angles=(0, "twist_end"), solid=True)   # twist; cubic=True
# what nb.swept sets on the SweptBuilder:
om = b.OrientationMethod; OO = GU.OrientationMethodBuilder.OrientationOptions
om.OrientationOption = OO.ByVectorDirection; om.OrientationVector = nxh.direction(part, (0, 0, 1))
om.OrientationOption = OO.ByAngularLaw; law = om.AngularLaw
law.LawType = GU.LawBuilder.Type.Linear                       # or .Cubic
law.StartValue.RightHandSide = "0"; law.EndValue.RightHandSide = "twist_end"     # degrees, formulas allowed
```

- Radial line swept along a helix (pitch 120, 72 deg of wrap, r 16..62), max distance of 9 x 13 points of the
  true helicoid: `Fixed` 16.573 mm (area 2504.15), `ByVectorDirection` along the axis 0.0041 mm (2536.11), two
  helix guides + `Uniform` 0.0016 mm (2536.07); analytic area 2536.15. `Fixed` raises nothing.
- Angular law, 10 x 2 rectangle on a 100 mm straight guide: `SKIN` / class `Swept`, solid, volume 2000.03
  (exact 2000) at 90, 180 and 405 degrees. The feature owns two `Degrees` expressions with the descriptor
  "law value" (start, end); `EndValue.RightHandSide = "twist_end"` links the end to a named expression and an
  edit regenerates (end and mid-length corners back on the body within 1e-3 / 1e-2 mm).
- **Sense**: a positive law angle turns the section by the NEGATIVE angle about the guide direction
  (left-hand rule). Measured at mid length of a 0 -> 90 law: the corner turned -45 deg about the guide is on
  the body (0.0003 mm), the corner turned +45 deg is 4.0 mm off. A symmetric section hides a wrong sense at the
  end (a 10 x 2 rectangle turned +90 and -90 is the same shape): probe at mid length.
- `Cubic` law: same ends, half the angle at mid length, 3t^2 - 2t^3 of it elsewhere (at a quarter of the length
  14.06 deg, not 22.5: corner 0.0007 mm from the body, the linear-law corner 0.093 mm off).
- Closed circular guide (R 40), section normal to it at the start point: 180 deg gives a closed ring - solid,
  4 faces, no end caps, Examine Geometry clean, volume 4995.41 (Pappus 5026.55, -0.6 %: B-surface on an arc
  guide). 405 deg commits as a solid with 6 faces and `BodyConsistency` 2: the two ends overlap 45 deg apart.
  On a closed guide the total twist must map the section onto itself (rectangle: multiples of 180).

### Patch Openings - VERIFIED

```python
POB = NXOpen.Features.PatchOpeningsBuilder
b = part.Features.CreatePatchOpeningsBuilder(NXOpen.Features.PatchOpenings.Null)
try:
    b.Type = POB.Types.Quilted                 # ByDeletingEdges BySuppression Extension Joggle Mesh MoldWizard NSided Notch Quilted
    b.DistanceTolerance = 0.01
    b.Faces.ReplaceRules([RF.CreateRuleFaceTangent(wall_face, [])], False)       # the faces around the openings
    b.Openings.ReplaceRules([RF.CreateRuleEdgeDumb(hole_edges)], False)          # closed edge loops, several holes at once
    b.Output = POB.OutputTypes.SingleFeature   # MultipleFeatures | Sew | SingleFeature
    f = b.CommitFeature()                      # PATCH_OPENINGS; the patches are NEW sheet bodies
finally:
    b.Destroy()
```

Shelled box, two dia 8 holes in the flat top wall, faces = the outer face by tangent rule, openings = the two
hole edges on that face (the settings read from the third-party mould exercises `[community: 1 author]`):

| Type | Result |
|---|---|
| `Quilted`, `NSided`, `Mesh`, `Notch`, `Joggle`, `ByDeletingEdges` | one `PATCH_OPENINGS` feature, 2 planar sheet bodies of 50.2655 = pi r^2 each, product untouched |
| `MoldWizard` | the same two patches as two `Bounded Plane` features (`SKIN`); `CommitFeature()` returns `None` |
| `BySuppression` | no sheet: it SUPPRESSES the hole features of the solid (volume 11510.94 -> 11712.00); `None` returned |
| `Extension` | "Unable to create all requested patch sheet bodies.  Try a different type." |

Output `MultipleFeatures`: two features, one per hole. Output `Sew`: "Faces to patch cannot be from solid body
for sew option." (it sews the patch into a SHEET the faces belong to). Hole in a cylindrical wall (dia 40 tube,
radial dia 8 hole): `Quilted`, `NSided`, `Mesh`, `ByDeletingEdges` all return a patch that IS the wall surface -
face type 16, area 50.5307, hole centre 0.000 mm off the patch (a flat cap would be 0.404 off).
The patch is a separate sheet: sew it, or pass its faces to Split Body together with the parting sheet.

### Delete Edge - VERIFIED

```python
b = part.Features.CreateDeleteEdgeBuilder(NXOpen.Features.DeleteEdge.Null)
try:
    b.SimplyEdges.ReplaceRules([RF.CreateRuleEdgeDumb(edges)], False)
    f = b.CommitFeature()                      # DELETE EDGE, class DeleteEdge; edits the sheet IN PLACE
finally:
    b.Destroy()
```

40 x 20 planar sheet with a 10 x 5 notch in one edge and a dia 6 hole (721.73 mm2, 10 edges): Delete Edge on the
hole loop -> 750.00; on the three notch edges -> 800.00, 4 edges, same body (Untrim would make a new sheet and
give a plane back as a padded box). Why before Extend Sheet: extending the notched edge by 5 without healing
gives 871.73 = the notch stays as a 10 x 10 slot in the extension; after Delete Edge the extension is a clean
40 x 25 (1000.00). Mould use: `nxf.extract_face` of the product's top face (2400 - 2 holes) -> Delete Edge on
the two hole loops (2400.00) -> `nxf.extend_sheet` 10 on all four edges -> 80 x 60 (4800.00), a shut-off / tool
sheet that overshoots.

### Parting sheet off the parting-line edges - VERIFIED

```python
f = nxh.extrude(part, nxh.section(part, edges=[rim_edge]), (1, 0, 0), 0, 30)     # open section -> SHEET body
```

Rim of the open box (4 edges at z 0): extrude the +X and the -X edge outward first (one edge each); then the +Y
and the -Y side with THREE edges each - the rim edge plus the end edges of the two X sheets - so that the
corners are filled; `nxf.sew(part, first, [others])` -> one sheet, 4 faces, area 9600.0 = (60+60) x (40+60) - 60 x 40,
free edges 640.0 = outer loop + the product rim, distance 0 to all four rim edges.
One step instead (`[community]` 1 of 3 exercises): Ribbon Builder -

```python
b = part.Features.CreateRibbonBuilder(NXOpen.Features.Ribbon.Null)
b.DistanceTolerance = 0.01; b.AngleTolerance = 0.5
nxh.fill_section(part, b.Profile, edges=rim_edges, help_point=p0)
b.OffsetView = nxh.direction(part, (0, 0, 1)); b.OffsetDistance.RightHandSide = "10"; b.Angle.RightHandSide = "0"
b.ReverseOffset = False                        # True: the strip goes to the inside of the loop (1599.24)
f = b.CommitFeature()                          # RIBBON_SHEET, class BodyFeature
```

a flat ring 10 wide outside the rim with ROUNDED corners (2314.25 = 2000 + 100 pi), one body. Use it when a
constant-width band is wanted; the extruded-edge sheet when the sheet must reach past a workpiece block.

### Core / cavity split with unsewn sheets - VERIFIED

Workpiece block 100 x 80 x 40 around the product: `nxh.subtract(part, block, [product], keep_tool=True)`
(308489.06), then `nxf.split_body(part, [block], faces=parting_sheet_faces + patch_faces)` - the parting sheet
and the two hole patches as ONE tool, not sewn (as in the exercises) - gives two solids: core side 116489.062
(slab + core + the two hole plugs), cavity side 192000.000, both equal to the analytic values. Without the
patches the block stays connected through the holes.

## Round 5 - option semantics (`surf_loft_options.py`, `surf_law_extension.py`, `surf_nsided.py`, `surf_section_surface.py`, `surf_blend_trim_offset.py`, all PASS)

What each option does and when it matters, with the measured tables: `option-semantics.md`. Here: the calls.
Each journal carries the complete recipe function (`through_curves`, `curve_mesh`, `swept`, `law_extension`,
`n_sided`, `section_surface`, `face_blend`, `offset_surface`) - copy from there.

### Through Curves options - VERIFIED

```python
RT = GU.Rebuild.RebuildTypes; FD = GU.FlowDirection.Type; AT = GU.AlignmentMethodBuilder.Type
b.LoftingSurfaceRebuildData.Degree = 1            # an edge at every interior section; 2 or 3 (default) = one smooth face
b.NormalToEndSections = True                      # free end on a symmetry plane: leaves the section plane at 90 deg
b.FlowDirection.FlowDirectionType = FD.Perpendicular   # NotSpecified | Perpendicular | Isoparametric | IsoCurveU | IsoCurveV | AdjacentEdges
b.Alignment.AlignType = AT.Distance; b.Alignment.AlignVector = nxh.direction(part, (1, 0, 0))
b.LoftingSurfaceRebuildData.RebuildType = RT.Manual; b.LoftingSurfaceRebuildData.Degree = 5      # approximation
b.SectionSurfaceRebuildData.RebuildType = RT.Manual; b.SectionSurfaceRebuildData.Degree = 3
```

`PreserveShape = True` with `AT.ArcLength`: "Preserve Shape can only be used with Parameter or By Points
alignment method." Direction in which the isoparms leave a boundary (to check a flow direction):
`pr = nxh.UFS.Modeling.AskFaceProps(face.Tag, parm)`; `pr[1]`, `pr[2]` are the first derivatives in U and V -
take the one least parallel to the edge (`cross_boundary_direction()` in `surf_loft_options.py`).

### Through Curve Mesh: point primary, emphasis - VERIFIED

```python
pt = part.Points.CreatePoint(nxh.P(*apex))
sec_pt = part.Sections.CreateSection(0.0095, 0.01, 0.5)
sec_pt.AddToSection([RF.CreateRuleCurveDumbFromPoints([pt])], pt, NULLO, NULLO, nxh.P(*apex), NXOpen.Section.Mode.Create, False)
b.PrimaryCurvesList.Append(arc_section); b.PrimaryCurvesList.Append(sec_pt)       # the point is the LAST primary
b.CrossCurvesList.Append(cross_1); b.CrossCurvesList.Append(cross_2)              # both end in the point
b.FirstCrossContinuity.ContinuityType = CT.G1                                     # crosses = EDGES of the neighbour sheets
b.FirstCrossContinuity.ConstraintFaces.ReplaceRules([RF.CreateRuleFaceDumb(neighbour_1_faces)], False)
b.Emphasis = NXOpen.Features.ThroughCurveMeshBuilder.EmphasisType.Primary         # Both | Primary | Cross
b.IntersectionTolerance = 0.1                     # at least the gap between the two curve families
```

Octant of a sphere R30 (one arc + the pole as primaries, two arcs as crosses): 1 face, 3 edges, Examine
Geometry clean. Strings 0.05 apart with tolerance 0.01: "Strings do not intersect within tolerance."

### Swept: area law, twist-law tangency, three guides - VERIFIED

```python
sm = b.ScalingMethod; sm.ScalingOption = SO.ByAreaLaw
sm.AreaLaw.LawType = GU.LawBuilder.Type.Linear
sm.AreaLaw.StartValue.RightHandSide = "1000"; sm.AreaLaw.EndValue.RightHandSide = "600"      # mm2
b.PreserveShapeOption = True                      # batch default True: polygon sections keep their corner edges
```

Circle of area 1000 on a 200 mm line: caps 1000.0 / 600.0, radius sqrt(800 / pi) on the surface at mid length.
Twist 0 -> 90 over 50 mm: the normal of the twisted face at the start, 8 mm from the axis, is 14.10 deg off the
untwisted face with `Linear`, 0.11 deg with `Cubic`. Three guides: no `ScalingOption` needed.

### Law Extension options - VERIFIED

```python
b.Type = LEB.Types.Vector; b.Vector = nxh.direction(part, (0, 0, 1))      # angle from the vector; no faces
# or Type Faces with a spine: rulings in planes normal to the spine
sd = b.SpineDefinition; sd.Method = GU.SpineDefinitionBuilder.MethodOptions.Vector; sd.Vector = nxh.direction(part, (0, 0, 1))
b.MiterOption = LEB.MiterOptions.Sharp                                    # NotSet | Sharp | Blend (default) | Radius
b.LengthLaw.LawType = GU.LawBuilder.Type.Linear
b.LengthLaw.StartValue.RightHandSide = "10"; b.LengthLaw.EndValue.RightHandSide = "20"
b.OppositeSideExtensionOption = LEB.OppositeSideExtensionOptions.Asymmetric      # NotSet | Symmetric | Asymmetric
b.OppositeSideLengthLaw.LawType = GU.LawBuilder.Type.Constant; b.OppositeSideLengthLaw.Value.RightHandSide = "4"
b.IsReferenceFaceNormalReversed = True                                    # the wall stands on the other side
```

Planar flange on the rim of a tapered duct = all rim edges in `BaseProfile` + (`Type Vector` Z, angle 90) or
(`Type Faces`, the duct faces, angle 90, spine vector Z) + `Sharp`: one body, 4 faces, 1120.0 mm2, all vertices
at the rim height.
**Profile direction decides the side** (Type Vector always; Type Faces for every angle but 90): put a known
edge FIRST in the edge list (it is the seed) and the help point at the end where the profile starts -

```python
rim.sort(key=lambda e: 0 if all(abs(v.Y + 8.0) < 1e-6 for v in e.GetVertices()) else 1)   # GetEdges() order is not stable
nxh.fill_section(part, b.BaseProfile, edges=rim, help_point=(-10, -8, 30))     # counter-clockwise seen from +Z
```

Rim counter-clockwise seen from the vector tip: Type Vector leans outward (10 deg: reach 1.7365; 90 deg: 1120.0
outside the rim); clockwise: inward (90 deg: a 328.0 flange inside the rim). Type Faces: wall direction =
cos(angle) x (profile direction x face normal) + sin(angle) x normal. Count `nxh.new_bodies(part, before)` after the commit: `Blend` leaves one body per edge
where the walls lean inward, without any message. Errors: spine = normal of the reference face "Invalid input
data."; spine Z with angle 0 on the rim "Modeler error. Initiating error recovery."

### N-Sided with constraint faces - VERIFIED

```python
b.ConstraintFaces.ReplaceRules([RF.CreateRuleFaceDumb(faces_owning_the_loop)], False)     # the BUILDER's collector
b.Continuity.ContinuityType = GU.Continuity.ContinuityTypes.G1                            # G0 = no effect
b.TangentTolerance = 0.5                          # the G1 residual you get (0.38 deg; 0.1 -> 0.10 deg)
# curvature continuity: b.Type = NSB.SurfaceType.TriangularPatch; ContinuityType = G2; b.MergeFaces = True
```

`b.Continuity.ConstraintFaces` exists too and is ignored. Triangular + faces on a 2-edge loop without
`MergeFaces`: "Unable to build surface."

### Section Surface, all verified types - VERIFIED

```python
SSB = NXOpen.Features.SectionSurfaceBuilderEx
b = F.CreateSectionSurfaceBuilderEx(NXOpen.Features.SectionSurface.Null)
try:
    b.Type = SSB.Types.Conic; b.ConicTypeMode = SSB.ConicType.Rho          # Circular + CircularTypeMode | Cubic + CubicTypeMode | Linear + LinearTypeMode
    b.G0Tolerance = 0.01; b.G1Tolerance = 0.5; b.G2Tolerance = 0.5
    b.SlopeControl = SSB.SlopeControlType.ByFaces                          # ByApex (+ b.ApexCurve) | ByCurves (+ b.StartSlopeCurve, b.EndSlopeCurve)
    for sec, edge, p in ((b.SectionStartGuide, edge_a, pa), (b.SectionEndGuide, edge_b, pb)):
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves); nxh.fill_section(part, sec, edges=[edge], help_point=p)
    b.StartFace.ReplaceRules([RF.CreateRuleFaceDumb([face_a])], False)
    b.EndFace.ReplaceRules([RF.CreateRuleFaceDumb([face_b])], False)
    b.SectionMethodRho = SSB.SectionMethodRhoType.Rho                      # or LeastTension
    b.RhoLaw.LawType = GU.LawBuilder.Type.Constant; b.RhoLaw.Value.RightHandSide = "0.5"
    b.UDegree = SSB.UDegreeType.Conic                                      # Cubic | Quintic: rho <= 0.75
    b.SpineType = SSB.Spine.ByVector; b.SpineVector = nxh.direction(part, (0, 1, 0))     # ALWAYS a spine (or ByCurve + b.SpineSection)
    b.BodyTypePreference = SSB.BodyType.Sheet
    feat = b.CommitFeature()
finally:
    b.Destroy()
```

Other types change only these lines:
- Conic Shoulder: `ConicTypeMode = ConicType.Shoulder`, fill `b.ShoulderCurve` instead of the rho law.
- Cubic Fillet Bridge: `Type = Cubic`, `CubicTypeMode = CubicType.FilletBridge`, guides + faces as above,
  `b.SectionMethodFilletBridge = SSB.SectionMethodFilletBridgeType.Continuity`,
  `b.StartContinuity.ContinuityType = CT.G2`, `b.EndContinuity.ContinuityType = CT.G2`; no spine.
- Circular Three Point: guides + `b.SectionInteriorGuide1`. Two Point Radius: guides + `b.RadiusLaw` (swap the
  guides to get the other arc). Two Point Slope: guides + `b.StartSlopeCurve`. Tangent-Tangent-Radius:
  `StartFace`, `EndFace`, `RadiusLaw`, spine by CURVE, no guides. Radius-Angle-Arc: start guide + `StartFace`
  + `RadiusLaw` + `b.AngleLaw` (degrees).
Check: point where the section crosses the corner diagonal (`AskMinimumDist` of a probe line against the
sheet), `nxh.normal_at` against both faces along the guides, `nxh.max_curvature` (`Corner.report()` in
`surf_section_surface.py`).

### Face Blend options - VERIFIED (trimming, sharp edges)

```python
b.TrimmingOption = FBB.TrimmingMethod.Short       # ToAllFaces (default) | Short | Long | NotSet
b.AddTangentFaces = True                          # default True
b.PropagatePastSharpEdges = True; b.PropagationAngle = 3.0     # float, degrees; default False / 0.5
```

`b.BlendType = FBB.Type.Swept` + `b.Spine = section`, and `b.CircularCrossSection.RadiusOption =
GU.RadiusMethod.Law` (`Constant | Law | Tangency`) with `LawControl` linear: not working here, see
`option-semantics.md` section 7.

### Trim and Extend, Until Selected - VERIFIED

```python
b = F.TrimFeatureCollection.CreateTrimAndExtendBuilder(NXOpen.Features.TrimAndExtend.Null)
try:
    b.DistanceTolerance = 0.01
    b.Operation = TEB.OperationType.UntilSelected
    b.TargetSelection.ReplaceRules([RF.CreateRuleFaceBody(solid)], False)          # what gets trimmed
    b.ToolSelection.ReplaceRules([RF.CreateRuleEdgeDumb(sheet_free_edges)], False)  # EDGES: the tool is extended
    b.ReverseTool = False                         # True (or ArrowSideOption = Delete): keep the other side
    feat = b.CommitFeature()
finally:
    b.Destroy()
```

Legacy builder, same result: `F.CreateTrimExtendBuilder(NF)`, `Type = TrimExtendBuilder.CreationTypes.UntilSelected`,
`TargetCollector`, `ToolCollector`, `Tolerance`, `ArrowSideOption`.

### Offset Surface options, Variable Offset - VERIFIED

```python
for dist, faces, flip in sets:                    # one FaceSet per distance, one feature
    b.FaceSets.Append(part.FaceSetOffsets.CreateFaceSet(str(dist), nxh.collector(part, faces=faces), flip, 0))
b.StepOption = True                               # shelf face between a 0 set and a tangent non-zero set
b.OutputOption = NXOpen.Features.OffsetSurfaceBuilder.OutputOptionType.OneFeatureForEachFace   # | OneFeatureForAllFaces | OneFeatureForConnectedFaces
# after the commit: sum(len(x.GetFaces()) for x in nxh.new_bodies(part, before)) must equal the faces you passed

b = F.CreateVariableOffsetBuilder(NXOpen.Features.VariableOffset.Null)             # NOT nxh.NULL_FEATURE
b.DistanceTolerance = 0.01; b.Face.Value = face; b.IsApplyToAll = False
b.Method = NXOpen.Features.VariableOffsetBuilder.MethodOptions.Linear             # or Cubic
for ex, v in zip((b.OffsetAtA, b.OffsetAtB, b.OffsetAtC, b.OffsetAtD), (1, 1, 5, 5)): ex.RightHandSide = str(v)
feat = b.CommitFeature()                          # VAR_OFFSET_SHEET, a new sheet
```

### Enlarge options, Bridge surface, Global Shaping - VERIFIED

```python
b.ExtensionType = NXOpen.Features.EnlargeBuilder.ExtensionTypes.Linear             # Natural (default) | Linear
b.IsCopy = True                                   # required for planar faces and faces of a sewn sheet
rp.VEnd.Expression.RightHandSide = "-20"          # negative = shrink

b = F.CreateBridgeSurfaceBuilder(NXOpen.Features.BridgeSurface.Null)
b.G0Tolerance = 0.01; b.G1Tolerance = 0.5; b.G2Tolerance = 0.5
b.FirstEdgeSelection.Value = edge_1; b.SecondEdgeSelection.Value = edge_2
b.FirstEdgeContinuity.ContinuityType = CT.G1; b.SecondEdgeContinuity.ContinuityType = CT.G1      # G0 | G1 | G2
feat = b.CommitFeature()                          # BRIDGESRF_SHEET, a new sheet

GSB = NXOpen.Features.GlobalShapingBuilder
b = F.CreateGlobalShapingBuilder(NXOpen.Features.GlobalShaping.Null)
b.DeformationType = GSB.DeformationTypeValues.ToPoint
b.DistanceTolerance = 0.01; b.AngleTolerance = 0.5
b.SheetToDeform.ReplaceRules([RF.CreateRuleFaceBody(sheet)], False)
b.RegionToDeform.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
nxh.fill_section(part, b.RegionToDeform, curves=closed_region_curves, help_point=p0)
b.TargetPointMethod = GSB.PointMethodType.OffsetFromSheet
tp = b.NewTargetPoint(); tp.Point = part.Points.CreatePoint(nxh.P(cx, cy, cz)); tp.Offset.RightHandSide = "5"
b.TargetPointsList.Append(tp)
b.ProjectionDirection = nxh.direction(part, (0, 0, 1))
feat = b.CommitFeature()                          # GLOBAL_SHAPING, the sheet is edited in place
```

### Pole count of a B-surface face - VERIFIED

```python
PSB = NXOpen.Features.PointSetBuilder
m = nxh.mark("poles", False)
b = F.CreatePointSetBuilder(NXOpen.Features.PointSet.Null)
try:
    b.Type = PSB.Types.FacePoints; b.FacePointsBy = PSB.FacePointsType.BSurfacePoles
    b.MultipleFaceCollector.ReplaceRules([RF.CreateRuleFaceDumb([face])], False)
    n = len([e for e in b.CommitFeature().GetEntities() if isinstance(e, NXOpen.Point)])
finally:
    b.Destroy()
nxh.undo_to(m)                                    # the point set is only a probe
```

`b.FacePointsType` is read-only (set `FacePointsBy`); `b.SingleFaceObject.Value = face` raises "A face must be
selected." The heaviness measure for approximated faces: Swept on an arc guide 121 poles at G0Tolerance 0.01,
77 at 0.1.

## Not verified

- **Section Surface**: Conic Hilite / Five Point / Four Point Slope, Cubic Two Slopes, the Circular Center
  types and Tangent Radius, Linear types (Tangent-Tangent between two planes: "Unable to map spine curve to
  guide curves or faces."), depth / skew of the Fillet Bridge, varying rho / radius laws. Not run.
- **Face Blend** swept section and law radius (error text in Round 5), tangency curve, coincident edge.
- **Through Curves** Construction Spline Points / Simple, alignments Angle / Spine Curve / Developable;
  **Curve Mesh** spine; **Swept** `ByLawCurve` area law, perimeter law, `ByAnotherCurve` / `ByAPoint` /
  `ByForcedDirection` orientation; **Variational Sweep** (`CreateVarsweepBuilder`); **Law Extension**
  multi-transition laws, `LaydownCurve`, the isocline + Vector-type undercut fill; **Global Shaping** other
  than To Point; **Bridge** tangent magnitude / edge range; Styled Blend / Corner.
- **Fit Surface** `F.CreateFitSurfaceBuilder(NXOpen.Features.FitSurface.Null)`: needs facet (scan) input through
  `FacetCollector`; `Type` Fitplane | Fitcylinder | Fitcone | Fitsphere | Fitfreeform. Not run.
- **Emboss** `F.CreateEmbossBuilder(NF)`: only `SetRegions([EmbossRegion])` and `Tolerance` are exposed. Not run.
- Studio Surface G1 combined with guide strings (one end stays ~41 deg off), Fill Surface G0 on a multi-face
  hole. (Trim and Extend Until Selected, Law Extension `MiterOptions.Radius` and
  `OffsetSurfaceBuilder.PartialOption` were tried in Round 5: the first works, the other two changed nothing.)
- Patch Openings on an opening that spans several faces or a non-closed (edge) opening with `Limits` /
  `DividingCurves`; Swept laws other than Linear / Cubic (`ByEquation`, `ByLawCurve`); Ribbon at an angle.
