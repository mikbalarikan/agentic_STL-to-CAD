# Option semantics - what each option of the surfacing commands does, and when it matters

NX 2206, headless NXOpen Python. Every number here was measured by a journal in `scripts/` (named in the
section title; all write `<name>.json` with `result` PASS). Sources: `[cast <course> / <lesson>]` = Siemens'
NX CAST 8.5 freeform courses (2012; own words, the option names are the NX 2206 ones), `[verified]` = measured
here. CAST names options and shows pictures; it rarely says when to use one - the "when" column is the
measured consequence. Call sequences: `nxopen-recipes.md`, Round 5.

Contents: 1 Through Curves - 2 Through Curve Mesh - 3 Swept - 4 Law Extension - 5 N-Sided Surface -
6 Section Surface - 7 Face Blend - 8 Trim and Extend, Offset Surface, Variable Offset, Enlarge, Bridge,
Global Shaping - 9 Tolerances - 10 NX 8.5 names in old parts - 11 What CAST does not answer.

## 1. Through Curves (`surf_loft_options.py` T1-T5, 37 checks in the journal)

Test body: four half-circle sections R20 / R14 / R18 / R10, 20 mm apart.

| Option (builder member) | Effect, measured | Use it when |
|---|---|---|
| Lofting degree 1 (`LoftingSurfaceRebuildData.Degree = 1`) | one face PER SPAN and an edge at every interior section: 3 faces, crease 28.01 deg at section 2 (= the angle between the straight spans) | a faceted, ruled span-by-span skin is wanted (reference faces; a 2-section loft is ruled anyway). Never by accident: count the faces. `[cast effa / lofting degree]` |
| Lofting degree 2 / 3 (3 = builder default) | ONE smooth face through all sections (0.000 mm); degree 2 and 3 are different surfaces (area 3145.15 / 3187.08) | default 3 |
| Patch Type `Single` | degree = sections - 1; on 4 sections identical to degree 3 | rarely; with many sections the degree gets high |
| `NormalToEndSections = True` | the surface leaves the first and last section at 90 deg to the section plane: tilt 43.06 / 48.14 deg -> 0.00 / 0.00; seam against the mirrored half 86.12 deg -> 0.00 deg | an end section lies on a symmetry plane and there is no neighbour face to be G1 to (half models). Needs planar end sections. `[cast effa / output surface options]` |
| End continuity G1 / G2 + `ConstraintFaces` | tangent / curvature continuous to the face that owns the end section (see `nxopen-recipes.md`, Round 2) | a neighbour face exists |
| `FlowDirection.FlowDirectionType` | only acts on a G1 / G2 end. Skew constraint edge (26.6 deg off square): `NotSpecified` - isoparms head straight for the other section, 63.43 deg to the edge; `Perpendicular` - 90.00 deg to the edge; `Isoparametric` - along the U/V lines of the constraint face (90.00 here, a plane). G1 held in all three (0.00 deg) | the constraint edge is skew to the loft direction and the isoparms (and later offsets / trims along them) should leave square: `Perpendicular` (the user's habit, 22 of 40 `[mined]`). `[cast effa / continuity group]` |
| Alignment `Parameter` | equal curve counts per section: corner goes to corner (ruling mid 0.003 mm off). Unequal counts: corners do not line up (3.54 mm off, Round 2) | equal curve counts |
| Alignment `ArcLength` | points spaced by arc length over the WHOLE string: on L-strings 30+10 against 10+30 the corners miss each other by 6.31 mm | single smooth strings of different make; fairness. Not for strings with corners |
| Alignment `Points` | the corner pairs are given explicitly: 0.000 mm (Round 2) | unequal curve counts `[cast effa / alignment By Points]` |
| Alignment `Distance` + `Alignment.AlignVector` | rulings lie in planes normal to the vector and the surface is only as long as the SHORTER string: 40 mm string to 20 mm string gives 632.46 mm2 (x 0..20) instead of 948.68 | sections of unequal extent that must be joined "straight across" |
| `PreserveShape = True` | a sharp corner of the sections stays an EDGE (rectangle loft: 4 planar faces, 4 corner edges, Edge Blend R3 builds). Only with `Parameter` or `Points` alignment - with `ArcLength`: "Preserve Shape can only be used with Parameter or By Points alignment method." | an Edge Blend / Chamfer will follow on the corner, or planar faces must stay planar `[cast effa / water tank activity]` |
| `PreserveShape = False` | corners are rounded inside the tolerance: 2 B-surface faces, only 2 of the 4 corner rulings are edges, corner radius 0.020 mm, 0.008 mm off the true corner | one fair face is wanted (styling skins, later Offset / Thicken) |
| Rebuild, lofting direction (`LoftingSurfaceRebuildData.RebuildType = Manual`, `Degree = 5`) | an APPROXIMATION: still one face, now 0.0002 / 0.0014 mm off the interior sections (`Advanced`: 0.0046 / 0.0068; section direction `Manual` degree 3: 0.002-0.003 off every section) | sections of different degree / segmentation give a heavy or wavy surface. Afterwards `dist_to(section)` is no longer 0 - check against the tolerance instead `[cast effz / rebuild options]` |
| Section order | the face normal follows it: the same two sections in the other order give the opposite normal (0, -0.316, 0.949) / (0, 0.316, -0.949) (`surf_blend_trim_offset.py` NO) | fix the section order, not the direction flags of every later Trim Body / Thicken / Patch `[cast effd / Reverse Normal]` |

Not measured: Construction `SplinePoints` / `Simple`, alignments `Angle`, `SpineCurve`, `Segments`, `Developable`.

## 2. Through Curve Mesh (`surf_loft_options.py` M1-M2)

| Option | Effect, measured | Use it when |
|---|---|---|
| A POINT as first or last primary (`CreateRuleCurveDumbFromPoints([point])` in its own Section) | a three-sided patch: 1 face, 3 edges, through the apex (0.000) | a three-sided gap with real boundary curves (nose, corner of a deck) `[cast effa / curve mesh with curves and a point]` |
| ... without constraint faces | only a guess between the three curves: 1.50 mm inside the sphere the three arcs lie on | never for a shape that matters |
| ... `FirstCrossContinuity` / `LastCrossContinuity` = G1 + the neighbour faces | 0.006 deg to both neighbours, 0.41 mm from the sphere | neighbours exist: always |
| ... G2 | tangent and the edge curvature equals the neighbour's (0.03344 against 0.03333; G1 alone 0.0423) | curvature-continuous highlight flow |
| `Emphasis` Both / Primary / Cross | where the surface lies when primaries and crosses do not meet. Middle cross 0.05 mm above the primaries: Both 0.025 / 0.025 mm off (midway), Primary 0.000 on the primaries / 0.050 off the cross, Cross 0.050 / 0.000 | the strings come from a scan or from two independent sketches: give the family that carries the dimensioned shape the emphasis and report the gap to the other `[cast effa / mesh output options]` |
| `IntersectionTolerance` | strings that miss each other by more than it: "Strings do not intersect within tolerance." (0.05 gap at 0.01); 0.1 builds | raise it to the measured gap, not further |
| Continuity on primaries and crosses | 0.000 / 0.003 deg on all four sides (Round 2 and 3) | patch between existing faces |

Not measured: `Spine` (isoparms in planes normal to it; only with planar first / last primaries per CAST), closing a mesh.

## 3. Swept (`surf_loft_options.py` S1-S3, `swept_twist.py`)

| Option | Effect, measured | Use it when |
|---|---|---|
| Twist law `Linear` (`OrientationOption = ByAngularLaw`) | constant twist rate, so the twisted face is NOT tangent to straight neighbours at the ends: 0 -> 90 deg over 50 mm, 14.10 deg off at 8 mm from the axis (= atan(u x rate), analytic 14.11), 17.42 at the corner | a free-ended twisted bar, a constant-pitch band |
| Twist law `Cubic` | zero twist rate at both ends: 0.11 deg off (within the 0.5 deg tolerance), same volume | the twisted piece continues into straight material (strap, handle) `[cast effb / swept with an angle law]` |
| Scaling `ByAreaLaw` (`ScalingMethod.AreaLaw`, Linear 1000 -> 600) | the cross-section AREA follows the law: caps 1000.0 / 600.0 mm2, 800 at mid length (0.0004 mm), volume 159998 against 160000 | ducts, manifolds, exhausts designed to an area progression `[cast effb / area law controlled swept]`. Closed section, one guide. `ByLawCurve` not measured |
| Two guides | need `ScalingOption = Uniform` or `Lateral` ("Invalid input scaling method" otherwise) | - |
| Three guides | NO scaling option needed: the default commits with all three guide ends on the surface; `Uniform` / `Lateral` are accepted and change nothing (same area) | the third guide fixes the section's shear `[cast effb / scaling method]` |
| `PreserveShapeOption` (batch default True) | True: a square section keeps 4 faces and its corner edges; False: 2 faces, corners rounded into one spline section | leave True for polygonal sections; False for one fair face |
| Orientation | `Fixed` only translates the section; on a guide with torsion use `ByVectorDirection` or a second guide (SKILL.md, Settings). `ByAnotherCurve`, `ByAPoint`, `ByForcedDirection`: not measured. The orientation vector must nowhere be tangent to the guide `[cast effb / swept orientation options]` | - |

## 4. Law Extension (`surf_law_extension.py`, 42 checks)

Test bodies: a tapered duct (40 x 30 -> 20 x 16 over 30 mm: four inclined planar faces, rim at z = 30) and one
flat 40 x 30 sheet; length 10.

**What the angle means.** Type `Faces`: measured from the reference face in the plane NORMAL TO THE PROFILE at
each point - 0 continues the face (measured with the profile running as in the direction rule below), 90
stands on it. On the duct, 90 deg gives a wall at 90.0 deg to each
inclined face, so the four walls rise by 10 x sin(taper) = 3.162 mm: **the rim flange is not planar**.
Type `Vector` (`b.Type = Vector; b.Vector = direction`): measured from one direction for the whole profile,
the faces do not matter - 0 = along the vector (z 30 -> 40 straight up off the inclined faces), 10 = every
wall leans 10 deg (reach 1.7365, height 9.848), 90 = normal to the vector. That is the draft / parting-wall
type `[cast efff / how law extensions are developed]`. To which side it leans: the direction rule below.

**Spine** (`b.SpineDefinition.Method = GU.SpineDefinitionBuilder.MethodOptions.Vector; .Vector = direction`):
every ruling of the flange then lies in a plane NORMAL TO THE SPINE instead of normal to the profile.
- Spine = normal of the rim plane (Z), angle 90: the flange is planar (every vertex at z = 30.000) and stands
  71.57 / 76.87 deg on the faces (90 - taper). `[cast etss885 / law extension flange on a duct end]`
- The same planar flange comes from Type `Vector` Z with angle 90 (area 1120.0 both ways) - the simpler route.
- With that spine the angle is measured IN the rim plane: 45 gives flat strips sheared along the rim (area
  720 x sin 45 as four bodies even with Sharp; with the profile the other way round a trimmed 709.12 ring),
  0 ends in "Modeler error. Initiating error recovery." Use 90.
- A spine along the profile changes nothing; a skew spine (1,1,0) shears the wall (far end moves 3.5355 along
  the edge, length and rise unchanged).
- Spine = the normal of the reference face itself: "Invalid input data."

**Miter** (`b.MiterOption`), several edges in one profile:

| MiterOption | Corner gaps (walls lean outward) | Corner overlaps (walls lean inward) | Walls meet exactly (90 deg on a flat sheet; planar rim) |
|---|---|---|---|
| `NotSet` | one body per edge | one body per edge | one body (flat sheet 90 deg: 4 faces, 1400.0); planar duct rim: 4 bodies, 720.0 |
| `Sharp` | ONE body, walls extended to the mitre (10 deg out: 1469.46; 20 deg out: 1536.81) | ONE body, walls trimmed at the mitre (20 deg in: 1263.19; 10 deg in: 1330.54) | one body; planar duct rim: 4 coplanar faces, exactly 40 x 36 - 20 x 16 = 1120.0, 0.00 deg across the mitre lines |
| `Blend` (builder default) | ONE body, 4 walls + 4 tangent corner faces (0.00 deg); 10 deg out: 1453.77, 20 deg out: 1505.76 | **4 separate bodies, no error, no alert** | one body; planar duct rim: 8 faces with rounded corners, 1025.0 |
| `Radius` + `MiterRadius` | walls stayed separate (radius 1 to 12 tried) | separate | - |

Without a spine on the duct: Sharp = one body, 4 faces, 22.5 deg creases at the mitres; Blend = one body,
8 faces, tangent corners; NotSet = 4 bodies.
**Which side an angle leans to is not a property of the number - it follows the profile direction.**
Measured rule, Type Faces: wall direction = cos(angle) x (profile direction x face normal) + sin(angle) x
normal. Flat sheet at y > 0 with normal +Z, profile along +X on its edge y = 0 (counter-clockwise seen from
+Z): 80 deg leans out, 110 leans in - the course's convention. The same seed edge started at its other end
(clockwise), or `IsReferenceFaceNormalReversed`, swaps the two. At exactly 90 deg the direction does not
matter (duct rim clockwise: the same 1120.0 / 1127.39 flanges).
Type Vector: wall direction = cos(angle) x vector + sin(angle) x (profile direction x vector). Rim taken
counter-clockwise seen from the vector tip: 10 deg leans outward, 90 deg is the outward flange (1120.0);
clockwise: 10 deg leans inward and the 90 deg flange lies INSIDE the rim (328.0).
**`body.GetEdges()` has no fixed order between NX sessions**: a profile filled with `edges=list(...)` starts
on whichever edge comes first, so the same journal leaned its walls outward in one run and inward in the
next. Put a known edge first in the list (it becomes the seed) and choose the help point at the end where the
profile must start. Then measure (does the bounding box grow beyond the profile?) and count the bodies after
every Law Extension with more than one edge.
(The earlier text of this skill, "Blend left four separate walls at both 80 and 110 deg", was wrong for the
outward-leaning case: the journal data of that run already shows one 8-face body at 110 deg. The user's
course says the same thing in GUI terms - below 90 leans out and Blend joins, above 90 leans in and NX shows
"Miter is not applied between multiple bodies." `[course CAD5.5 00:22:59]`; in a journal no message appears.)

Other options, measured on one edge: Linear length law 10 -> 20 (`LengthLaw.LawType = Linear`, `StartValue` /
`EndValue`): trapezoid 600.0, height 20 at the far end. `OppositeSideExtensionOption = Symmetric`: the wall
grows the same length to the other side (z -10..10, 800.0); `Asymmetric` + `OppositeSideLengthLaw` 4:
z -4..10, 560.0. `IsReferenceFaceNormalReversed`: the 90 deg wall stands on the other side of the sheet.
`LaydownCurve` (default True), multi-transition laws, the isocline -> Law Extension (Vector) -> Trim Sheet ->
Patch undercut fill `[cast efff / caliper activity]`: not measured.
A Law Extension is always a NEW sheet: Sew joins it (duct + flange: one sheet, 8 faces, 4422.998 mm2).

## 5. N-Sided Surface (`surf_nsided.py`, 29 checks)

Test: a round hole in a cylindrical skin (R8 in R20) and in a lofted B-surface skin (R6), 16 points on the
hole edge; `Trimmed` type unless stated.

| Setting | G1 deviation at the edge (cyl / B-surf) | Gap to the original surface at the hole centre | Edge curvature against the skin |
|---|---|---|---|
| no constraint faces (the old recipe) | 16.96 / 18.02 deg | 0.831 / 0.434 mm | - |
| `b.ConstraintFaces` = the skin face + `b.Continuity.ContinuityType = G1` | **0.38 / 0.39 deg** | 0.375 / 0.182 mm | 0.33 against 0.05 - not matched |
| the same with `TangentTolerance = 0.1` | 0.10 / 0.10 deg | 0.375 / 0.182 mm | - |
| faces put on `b.Continuity.ConstraintFaces` instead | 16.96 / 18.02 (ignored) | as without | - |
| faces + `G0`, or `G1` without faces | 16.96 / 18.02 (no effect, no error) | as without | - |
| faces + `G2` on the Trimmed type | = the G1 result | = G1 | not matched |
| `TriangularPatch` + faces + G1 + `MergeFaces = True` | 0.02 / 0.04 deg, one face | 0.835 / 0.444 mm | - |
| `TriangularPatch` + faces + G2 + `MergeFaces = True` | 0.20 / 0.03 deg | 0.835 / 0.444 mm | 0.0479 against 0.05, 0.0827 against 0.0830 - matched |
| `TriangularPatch` + faces, MergeFaces off (2-edge loop) | "Unable to build surface." | | |
| Fill Surface (reference) | 0.00 / 0.00 deg | 0.000 / 0.000 mm | equal |

Reading
- The "N-Sided is creased next to faces" verdict came from a recipe without constraint faces
  `[cast effb / N-sided surface overview, shape control]`. With `builder.ConstraintFaces` + G1 the Trimmed patch
  is tangent to its neighbours; the residual IS the tangent tolerance (0.5 -> 0.38 deg, 0.1 -> 0.10 deg).
- It is still not the neighbours' surface: 0.18-0.37 mm off inside and no curvature match. For a hole in a
  skin Fill Surface stays the tool (0.000 mm, 0.00 deg).
- Curvature continuity needs the Triangular type with MergeFaces - and its centre is 0.44-0.84 mm off.
- Every variant sews to the skin into one sheet, the creased one too: Sew does not test tangency.
- Repair-patch use (loop of CURVES lying on a face, the face as constraint, `[cast effb / N-sided as a sheet
  repair tool]`): on a cylinder R20, 20 x 20.9 mm loop - no faces 6.43 deg; faces + G1 0.52 deg (0.09 at
  tolerance 0.1) but 0.667 mm off the cylinder in the middle (the unconstrained patch: 0.111); Triangular
  4 faces, 2.16 mm off. `UVOrientation = Vector` along the cylinder axis: "Unable to build surface."; across
  it: on the cylinder in the middle (0.000) but 2.4 deg at the edge. Check the middle of an N-Sided patch
  against what it replaces, not only its edges.
- `CenterControlZ` (Triangular) is not a height in mm: 0.2 / 1 lifted the centre of a 20 mm pentagon into a
  55 mm spike. Left alone it is flat (pentagon: 5 faces, 951.057 mm2).

## 6. Section Surface (`surf_section_surface.py`, 26 checks)

Builder `CreateSectionSurfaceBuilderEx`. A cross-section is a conic, an arc, a cubic or a line between a start
and an end guide, repeated in planes normal to a spine `[cast efff / characteristics of section surfaces]`.
NX 2206 groups the NX 8.5 type names into `Type` Conic / Circular / Cubic / Linear plus a mode
(the menu also lists every combination as its own command, e.g. "Conic - Rho - By Faces"):

| NX 2206 (`Type`, mode, `SlopeControl`) | NX 8.5 name (old builder enum) | Inputs | Result on the test corner |
|---|---|---|---|
| Conic, `ConicType.Rho`, `ByFaces` | Fillet-Rho | start guide + `StartFace`, end guide + `EndFace`, `RhoLaw`, spine | on both guides, 0.00 deg to both faces, crosses the corner diagonal exactly where rho says (0.5 / 0.4142 / 0.7 / 0.8 read back) `[verified]` |
| Conic, Rho, `ByApex` | Ends-Apex-Rho | start guide, end guide, `ApexCurve`, rho, spine - no faces | the same surface as By Faces (area equal to 0.001) `[verified]` |
| Conic, `Shoulder`, `ByApex` | Ends-Apex-Shoulder | start, end, apex, `ShoulderCurve`, spine | passes through the shoulder curve (0.000) `[verified]` |
| Conic, Rho, `ByCurves` | Ends-Slope-Rho | start, end, `StartSlopeCurve`, `EndSlopeCurve`, rho, spine | both slope curves on the apex line = the By Apex surface `[verified]` |
| Conic, `Hilite` / `FivePoint` / `FourPointSlope` | ...-Hilite, Five-Point, Four-Point-Slope | highlight curves; `SectionInteriorGuide1..3` | not run |
| Cubic, `CubicType.FilletBridge` | Fillet-Bridge | start guide + face, end guide + face, `StartContinuity` / `EndContinuity` G1 or G2; NO spine | G1: 0.00 deg both sides; G2: also curvature 0 at the guide = the planar face (G1: 0.159). Not a circle: flatter (G1) or fuller (G2) in the middle `[verified]` |
| Cubic, `TwoSlopes` | Ends-Slope-Cubic | start, end, two slope curves | not run |
| Circular, `ThreePoint` | Three-Point-Arc | start, `SectionInteriorGuide1`, end, spine | exact R10 arc (area 942.478, curvature 0.1) `[verified]` |
| Circular, `TwoPointRadius` | Two-Point-Radius | start, end, `RadiusLaw`, spine | two arcs exist: the ORDER of the guides picks the side (start = edge A: the arc bulging away, 90 deg to both planes; swapped: the tangent fillet) `[verified]` |
| Circular, `TwoPointSlope` | End-Slope-Arc | start, end, `StartSlopeCurve`, spine | R10 fillet `[verified]` |
| Circular, `TangentTangentRadius` | (fillet arc) | `StartFace`, `EndFace`, radius, spine CURVE | R10 fillet tangent to both faces, no guides needed `[verified]` |
| Circular, `RadiusAngleArc` | Point-Radius-Angle-Arc (the user's 9) | start guide + `StartFace`, `RadiusLaw`, `AngleLaw`, spine | starts ON the guide tangent to the face and curls back over it; area = r x angle x length (90 and 45 deg) `[verified]` |
| Circular, `CenterRadius` / `CenterPoint` / `CenterTangent` / `TangentRadius` / `TangentpointTangent` | Circle, Circle-Tangent | - | not run |
| Linear, `TangentTangent` / `PointAngle` | Linear-Tangent | faces / guide + angle | Tangent-Tangent between two planes: "Unable to map spine curve to guide curves or faces." |

Rules, measured
- **Rho** is the fullness: the section crosses the line from the chord middle to the apex at the fraction rho.
  In a 90 deg corner rho = sqrt(2) - 1 = 0.4142 IS the circular fillet (curvature 1/10 everywhere, area of the
  quarter cylinder); 0.5 is a parabola; larger is fuller: flatter at the guides (curvature 0.050 -> 0.009 at
  0.7) and sharper in the middle (0.141 -> 0.330).
- **U degree** (`b.UDegree` Conic / Cubic / Quintic): Conic is the exact conic. Cubic and Quintic are
  approximations with the same shoulder and end tangents (rho 0.7: area 1057.99 against 1056.75; identical at
  rho 0.5). With Cubic / Quintic rho is limited: 0.8 -> "Rho must be between 0.0001 and 0.7500 for non-conic
  cases." `[cast efff / degree settings]`
- **Spine**: `SpineType = ByVector` + `SpineVector`, or `ByCurve` + `SpineSection` (same surface for a straight
  spine). The surface is only as long as the spine: a spine curve from y 15 to 45 under 60 mm guides gives
  y 15..45 and half the area `[cast efff / spine curve and limits]`. Keep it smooth and roughly parallel to
  the guides. A Conic type with NO spine set ended in "Internal error: memory access violation" (development
  run; not in the example journal) - always set one. Fillet Bridge needs none (a vector changes nothing).
- Guides for the By Faces types were edges of the two faces; for the curve-driven types dumb lines.

Which one: two faces, a known fullness -> Conic Rho By Faces; two faces, G2 join -> Cubic Fillet Bridge; two
faces and a radius -> Circular Tangent-Tangent-Radius (or a Face Blend); two edges and the corner line, no
faces yet -> Conic Rho By Apex; section must pass through a third curve -> Conic Shoulder or Circular Three
Point.

## 7. Face Blend between sheets (`surf_blend_trim_offset.py` F1-F3)

R5 between a floor sheet 30 long and a wall sheet 50 long.

| `TrimmingOption` | Blend face runs | Area |
|---|---|---|
| `Short` | y 0..30 - as long as the short input | 235.62 |
| `Long` | y 0..50 - the full long input, full width | 392.70 |
| `ToAllFaces` (builder default) | to 50, but cut by the boundaries of both inputs | 314.16 |
| `NotSet` | untrimmed: overshoots BOTH ends by the radius (y -5..55) | 471.24 |

Independent of `TrimInputFacesToBlendFaces` and `SewAllFaces` (both default True: one 3-face sheet in every
case; both off: the blend is one extra sheet) `[cast effc / trim and sew options]`.

Sharp edges along the blend path - wall with a 2.00 deg kink, first chain = the face before the kink only:
- defaults (`AddTangentFaces` True, `PropagatePastSharpEdges` False, `PropagationAngle` 0.5): with `Short`
  the blend stops at the kink (y 0..30); Add Tangent Faces does not help, 2 deg is not tangent.
- `PropagatePastSharpEdges = True`, `PropagationAngle = 3.0`: the blend crosses the kink - 2 blend faces to
  y 60, on the contact line of the tilted face (0.000 mm). `PropagationAngle = 1.0` (below the kink): stops.
  Use an angle just above the measured mismatch (parting lines) `[cast effc / blend across sharp edges]`.
- Trap: with the default trimming the blend of the first face alone continues along the long wall as ONE
  cylinder on the EXTENSION of that face - it looks complete and is not on the tilted face.

Not working in a journal with the settings tried: `BlendType = Swept` with a `Spine`, and a law radius
(`CircularCrossSection.RadiusOption = GU.RadiusMethod.Law`, `LawControl` linear 3 -> 6) - both end in "The
normal directions of face 1 and face 2 do not work with the blend size specified." for all four normal pairs
(spine on the corner line, on a floor edge, offset in space; `UpdateConstantLawProfiles`, `SetSpineIntoBuilder`
tried). A `Spine` set on a rolling-ball blend is ignored (exact R5). Tangency curve (`TangencyCollector`),
coincident edge (`CoincidentEdgeCollector`), three-face blend between sheets: not run.

## 8. Trim and Extend, Offset Surface, Variable Offset, Enlarge, Bridge, Global Shaping (`surf_blend_trim_offset.py`)

**Trim and Extend, Until Selected** `[cast effc / until selected]`: target = the faces of a SOLID
(`CreateRuleFaceBody(block)`), tool = the free EDGE of a sheet that ends 3 mm inside the block: the tool is
extended and the block is cut right through (40 x 30 x 8 = 9600.0). `ReverseTool` or `ArrowSideOption = Delete`
keep the other side (14400.0); `ReverseTarget` changes nothing; the tool sheet is left as it was. Tool = the
sheet's FACE (no extension): "Intersecting target and tool faces may have problems that cause intersection
gaps." Same three results with the legacy `TrimExtendBuilder` (`Type = UntilSelected`). One feature instead of
Extend Sheet + Trim Body.

**Offset Surface** `[cast effc / offset surface]`: `FaceSets.Append(...)` once per set, each with its distance.
- Sets 3 and 5 on two faces that meet at a corner: one feature, one sheet, floor at 3 and wall at 5, trimmed
  to each other (960.0 mm2).
- Sets 5 and 0 on two TANGENT faces: refused ("... unable to provide a full solution ...") until
  `StepOption = True`: then ONE sheet of 3 faces - offset face at 5, untouched face at 0 and a 5 mm shelf
  face at the tangent edge.
- Trap: sets 5 and 2 (both non-zero) on tangent faces build without a message, with or without StepOption,
  but the offsets are extended to their intersection: the 20 mm plane at 5 survives 1.59 mm wide. Use
  `OutputOption = OneFeatureForEachFace` (two features, two sheets, each at its distance) or a 0 set + step.
- A face that cannot be offset (R5 by 6 towards its axis): alone -> the known error, with and without
  `PartialOption`. **Together with a face that can be offset -> no error, no alert, `GetErrorFaces()` empty,
  and the tight face is simply missing** (1 face from 2; between two walls 2 planes meeting sharp from 3).
  Count the faces after every Offset Surface.

**Variable Offset** (`CreateVariableOffsetBuilder(NXOpen.Features.VariableOffset.Null)`, feature
`VAR_OFFSET_SHEET`) `[cast effc / variable offset]`: one face, `OffsetAtA..D` = a distance at each corner of
its UV box; 1 / 1 / 5 / 5 gives a new sheet 1 and 5 from the source corners and 3 in the middle, on a lofted
face and on a plane. `Method = Cubic`: zero slope at the corners (exactly 5.000 there). Which corner is A:
assign, measure, re-assign.

**Enlarge** `[cast effg / enlarge overview]`: percentages per side of the face's UV box. +25 % along a straight
direction: area x 1.25; along a curved direction `Natural` continues the curvature (1544.13), `Linear`
continues straight (1556.61). A negative value shrinks (-20 %: x 0.8; Natural and Linear alike on NX 2206).
`IsCopy = True`: a new sheet, source unchanged. **A planar face, or a face of a sewn sheet, in place:
"Invalid face." - as a copy both work** (the plane comes back as a B-surface sheet, x 1.25).

**Bridge surface** (`CreateBridgeSurfaceBuilder(NXOpen.Features.BridgeSurface.Null)`, feature `BRIDGESRF_SHEET`)
`[cast effh / bridge]`: `FirstEdgeSelection.Value` / `SecondEdgeSelection.Value` = one edge of each sheet,
`FirstEdgeContinuity.ContinuityType` / `SecondEdgeContinuity`. Two planar sheets 20 mm apart at 60 deg:
G0 / G0 a straight strip (26.6 / 33.4 deg creases); G1 / G1 0.00 deg both sides (builder default); G2 / G2
also curvature 0 at both edges. A new sheet; Sew joins sheet + bridge + sheet into one 3-face sheet.
With side curves use Through Curve Mesh instead. Tangent magnitude, edge range, flow direction: not run.

**Global Shaping, To Point** (`CreateGlobalShapingBuilder(NXOpen.Features.GlobalShaping.Null)`)
`[cast effg / global shaping]`: region = a closed curve on the sheet, target = `b.NewTargetPoint()` with
`.Point` and `.Offset`, appended to `b.TargetPointsList` (setting `b.TargetPoint` alone: "Specify target
point."). Circle R30 on a 100 x 100 sheet, offset 5: the sheet is deformed IN PLACE (one face, feature
`GLOBAL_SHAPING`), centre raised 5.000, unchanged outside the region; works on a planar sheet too. The other
ten deformation types: not run.

## 9. Tolerances of approximating commands (`surf_blend_trim_offset.py` TOL)

Swept of a half circle R6 along a quarter arc R50, against the true torus (25 points; poles read through a
Point Set of B-surface poles):

| G0Tolerance / G1Tolerance | Max deviation | Poles |
|---|---|---|
| 0.01 / 0.5 | 0.0107 mm | 121 |
| 0.01 / 0.05 and 0.01 / 5 | 0.0107 mm | 121 |
| 0.001 / 0.5 | 0.0107 mm | 121 |
| 0.1 / 0.5 and 0.1 / 5 | 0.0401 mm | 77 |

- A Swept on a curved guide is an approximation within the position tolerance; it is never the analytic
  surface (Sweep Along Guide / Revolve are).
- Tightening the tolerance below the part tolerance bought nothing here (0.001 = 0.01); loosening it made the
  face lighter (121 -> 77 poles). `[cast effz / tolerances]` advises never to go tighter than needed and to
  loosen the ANGLE tolerance first when a surface is heavy - on this Swept the angle tolerance had no effect
  at all, the position tolerance decided the pole count. Measure before trusting either knob.
- N-Sided: the tangent tolerance is the G1 residual you get (section 5). Batch defaults read back: Law
  Extension 0.01 / 0.5, Section Surface G0 0.01 / G1 0.5 / G2 0.0, N-Sided 0.0 ("Unable to build surface."),
  Curve Mesh 0.0254 / 0.02 - set them explicitly on every builder.
- CAST parts are converted inch parts with distance tolerance 0.0254: when adding features to such a part keep
  its tolerance instead of forcing 0.01.

## 10. NX 8.5 names you meet in old parts and lessons -> NX 2206

From the NX 2206 menu definition files (label, shown / hidden) and a reflection probe of the builders
(`plans/nxcast-analysis/freeform-curves.nx2206_menu_check.json`). Do not plan a journal on a retired command.

| NX 8.5 (CAST) | NX 2206 | In a journal |
|---|---|---|
| Trimmed Sheet | **Trim Sheet** (feature type `TRIMMED_SH`) | `TrimSheetBuilder` |
| Section (surface) | **Section Surface**; types regrouped Conic / Circular / Cubic / Linear (section 6) | `SectionSurfaceBuilderEx`; the old `SectionSurfaceBuilder` still reads old features with the 8.5 type names |
| Extension (tangential / circular) | "Extension..." still in the menu; practice moved to **Extend Sheet**, Enlarge, **Law Extension** | `ExtendSheetBuilder`, `LawExtensionBuilderEx` |
| Trim and Extend (By Distance, Percentage, Until Selected, Make Corner) | "Trim and Extend" (Until Selected, Make Corner) + "Legacy Trim and Extend" (all four) | `TrimAndExtendBuilder` / `TrimExtendBuilder`; By Distance = Extend Sheet |
| Through Points, From Poles | old dialogs still in the menu | no builder - Fit Surface, or splines + Through Curves |
| From Point Cloud | gone | Fit Surface |
| Quilt | "Quilt..." in the menu | no builder - not scriptable |
| Soft Blend | "Soft Blend (to be retired)" | no builder - Face Blend, Section Surface Fillet Bridge, Styled Blend |
| Fillet (surface) | "Fillet (to be retired)" | Face Blend, Section Surface |
| Transition | "Transition (Legacy)", hidden | no builder - Through Curve Mesh, Fill Surface, Styled Corner |
| Rough Offset | "Rough Offset (Legacy)", hidden | no builder |
| Edit Boundary (remove hole / trim, replace edge) | split: **Untrim**, **Local Untrim and Extend**, **Replace Edge**, Delete Edge | `UntrimBuilder`, `DeleteEdgeBuilder` |
| Change Edge | still present; **Match Edge** is current | `MatchEdgeBuilder` |
| Mirror Body | Mirror Geometry | see `nx-patterns-and-body-ops` |
| Ruled | hidden in the 2206 menu file, the builder works | `RuledBuilder`, or Through Curves with lofting degree 1 |
| Rebuild None / Degree and Tolerance / Auto Fit | same idea | `GU.Rebuild.RebuildTypes` NotSet / Manual / Advanced / KeepParameterization |
| Reverse Normal | still present | no builder found - fix the section order instead |
| Four Point Surface | in the menu | no builder in NXOpen Python - Fill Surface on four lines |

Feature type strings in old parts are ambiguous - read the class: `TRIM_SHT` is **Trim Body** (used on
sheets), `TRIMMED_SH` is Trim Sheet; `SECTION_SURF` is a Section Surface or an OLD Law Extension (its edit
builder then reads empty defaults); `SKIN` is Swept, Ruled, Bounded Plane or a class-less legacy body feature;
`SWP104` is Tube, Sweep Along Guide or a legacy sweep; `OFFSET` in old freeform parts is Offset Face.
755 features of NX 5 - 8.5 vintage in the CAST freeform parts load in NX 2206 with one feature error.

## 11. What CAST does not answer (the skill's own verified text stands)

Sew tolerance and what to do when a sew leaves gaps (the freeform courses use Sew as one click) - SKILL.md
"Tolerances and gaps". Fill Surface, Studio Surface, Extend Sheet, Patch Openings, Delete Edge, Untrim, Unsew:
newer than the course set or Shape Studio only - the recipes in `nxopen-recipes.md` are the only source.
Feature order of a freeform part: never stated; the CAST parts are start states (wireframe + reference faces).
The one finished Siemens skin model runs patch -> Trim Body against the neighbour -> Sew -> Face / Edge Blend
-> Mirror -> Sew, and the tank exercise Sew -> Edge Blend -> Shell `[cast effa / ceramic water tank]` - the
same "blend before the wall" order as the user's Skin -> trim -> sew -> blend -> thicken `[mined]`.
