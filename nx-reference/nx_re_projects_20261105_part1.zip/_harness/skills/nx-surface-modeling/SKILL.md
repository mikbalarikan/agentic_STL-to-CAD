---
name: nx-surface-modeling
description: Build, trim, join and solidify surfaces (sheet bodies) in Siemens NX 2206 journals - Ruled, Through Curves, Curve Mesh, Swept (twist law), Sweep Along Guide, Studio / Section / N-Sided Surface, Bounded Plane, Fill, Bridge, Face Blend between sheets, Extract, Offset Surface, Extend Sheet, Law Extension, Trim Sheet, Trim and Extend, Untrim, Delete Edge, Patch Openings, Sew, Unsew, Thicken, Patch, trim/replace solid faces with a sheet. Also blades: impeller, propeller, fan, turbine and compressor wheels (helicoid blades, profiled blades through section sketches, vanes between hub and shroud, changing the blade count of a parametric or imported wheel) and mould parting / shut-off sheets. Use when a shape cannot be made by extrude/revolve/boolean alone (lofts, swept or freeform skins, blades, sewn shells, thin walls from a skin, a leaking imported body), when sheets must become a solid, when G1/G2 continuity has to be proven, or when a loft comes out twisted, a sew stays open, or a trim keeps the wrong side.
---

# NX surface (sheet-body) modelling

> Data-set note: `[mined]` counts in this skill come from the first extraction (691 part dumps = 653 user files, a few of them repeated session snapshots of the same part). De-duplicated totals for the 639 distinct user parts are in `nx-modeling-strategy/references/user-practice-overview.md`; rankings and proportions agree, absolute counts differ.

Headless NXOpen Python on NX 2206, run through `nx-journal-core/scripts/run_journal.ps1` with the `nxh` helper.
Evidence tags: `[course CADx.y hh:mm]` = the user's NX training course, `[mined]` = the user's 691 dumped
parts, `[verified]` = measured by the journals in `scripts/` (`surf_build.py` 30 checks, `surf_edit.py`
43 checks, `surf_course_checks.py` 60 checks, `surf_round3_checks.py` 38 checks; the last two need the
nx-journal-core `nxh.py`; blades, twist and mould repair: `blade_helicoid.py`, `blade_sections.py`,
`blade_centrifugal.py`, `blade_edit_count.py`, `swept_twist.py`, `surf_mould_repair.py`, with the helper
module `scripts/nxblade.py`; option semantics: `surf_loft_options.py` 37 checks, `surf_law_extension.py` 42,
`surf_nsided.py` 29, `surf_section_surface.py` 26, `surf_blend_trim_offset.py` 47), `[community]` = a
collection of third-party NX parts (author count given; never a rule by itself), `[cast <course> / <lesson>]`
= Siemens' NX CAST 8.5 freeform courses (2012; a rule only where re-measured on NX 2206). Copy recipe
functions from those scripts; call sequences and failure texts are in `references/nxopen-recipes.md`,
**what each option does and when it matters in `references/option-semantics.md`** (also: NX 8.5 command names
in old parts -> NX 2206), the blade recipes in `references/blades.md`, the user's statistics in
`references/user-practice.md`, the course tool cards in `references/course-notes.md`.

**Units.** The course's surface sample parts are inch parts (tolerance 0.001 in, radii 0.25 in); the user's
parts and all recipes here are mm with 0.01 mm / 0.5 deg. Never carry a course number over without its unit.

## Capability ladder (pick the lowest rung that carries all the constraints)

1. **Extrude / Revolve as sheet** - only translates or revolves one section; cannot reach a second, different
   section `[course CAD5.4 00:04:53]`.
2. **Ruled** - exactly two sections, G0 only, no continuity; a chain of Ruled patches creases at every
   shared section `[course CAD5.4 00:28:22]`; measured 43.60 deg between two patches `[verified]`.
3. **Through Curves** - any number of sections, smooth through the interior ones, G0/G1/G2 to neighbour
   faces at the first and last section only `[course CAD5.4 00:28:54, 00:33:51]`. (With lofting degree 1 it is
   a chain of ruled spans with an edge at every section; a free end on a symmetry plane: Normal to End
   Sections - Settings.)
4. **Through Curve Mesh** - sections plus cross curves, continuity on all four boundaries; "the more
   parameters you give, the better the surface", "tie everything you can to everything"
   `[course CAD5.4 00:46:12, 00:56:51]`. Same wireframe: 10.87 deg off the neighbours at G0, 0.00 deg with G1 `[verified]`.

Continuity needs something to be continuous with: build the neighbouring (reference) patches first, then the
constrained patch between them `[course CAD5.4 00:30:38]`.

## Pick the tool

| Need | Tool | Evidence |
|---|---|---|
| Skin through 2+ profiles | **Through Curves** | `[mined]` 41 uses, 38 of 40 with 2 sections, G1 at the last section in 29; closed sections + Solid -> `UNITE` 10 / `SHELL` 5. |
| Skin on a curve grid, 4-sided gap in a skin | **Through Curve Mesh** | `[mined]` 16 uses, always sheet, 2 primaries x 2-3 crosses, then `SEW`. `[course CAD5.4 00:50:53]` the only one that takes the side boundaries and ribs. |
| Two strings, quick patch or reference face | **Ruled** | `[mined]` 5 uses. Exact ruled surface `[verified]`. |
| Loft with section AND guide strings | **Studio Surface** | `[mined]` 37 uses, 2 sections + 2 guides, G1 at sections in 27. Not in the course recordings. |
| Section along a smooth guide, 1-3 guides | **Swept** | `[mined]` 9 uses, 1 section + 1 guide. Section must be normal to the guide `[course CAD5.5 00:04:41]`. |
| Constant section along a path with corners, or any line/arc path | **Sweep Along Guide** | `[mined]` 38 uses, the user's default sweep. Mitres sharp corners `[course CAD5.5 00:16:47]`; exact analytic faces `[verified]`. |
| Flat cap on a closed planar loop | **Bounded Plane** | `[mined]` 127 uses, then `SEW` 45 / `TRIM BODY` 42. `[course CAD5.5 00:44:19]`. |
| Close a non-planar hole next to existing faces | **Fill Surface** | `[mined]` 32 uses, G1 in 26 of 29. `[course CAD5.5 00:38:13]` automatic G1 to the neighbours. |
| Patch on an open or closed curve set | **N-Sided Surface** | `[mined]` 2 uses. WITHOUT constraint faces creased against neighbours (17-18 deg `[verified]`, flat-spotted `[course CAD5.5 00:37:36]`); with `b.ConstraintFaces` + G1 tangent (0.38 deg) but still 0.2-0.7 mm off the surface it replaces `[cast effb / N-sided overview]` `[verified]`. For a hole in a skin Fill Surface stays first choice. |
| Three-sided gap with real boundary curves | **Through Curve Mesh** with a POINT as last primary, G1 on the crosses | `[cast effa / curve mesh with a point]`; 1 face, 3 edges, 0.006 deg to both neighbours `[verified]`. |
| Fillet-like or transition surface with a prescribed cross-section (conic fullness, arc, G2 bridge) between two edges or two faces | **Section Surface** | `[mined]` 29 uses. `[cast efff]`; 10 type / input combinations `[verified]` - table in `references/option-semantics.md` section 6. |
| Close the gap between two sheet edges, G1 / G2, no side curves | **Bridge** surface, then Sew | `[cast effh / bridge]`; 0.00 deg both sides `[verified]`. With side curves: Curve Mesh. |
| Wall whose offset varies across one face | **Variable Offset** (a distance per corner) | `[cast effc / variable offset]`; 1 / 1 / 5 / 5 at the corners `[verified]`. |
| Crown / dome a region of an existing sheet | **Global Shaping**, To Point | `[cast effg]`; centre +5.000, unchanged outside the region, in place `[verified]`. Not for parts from drawings. |
| Fillet between two sheets or two separate bodies | **Face Blend** (two-face) | `[course CAD5.6 00:00:40]`; Trim + Sew gives one sheet in one feature `[verified]`. |
| Copy faces / a body as a starting sheet or a safety copy | **Extract Face / Body** | `[mined]` 1931 instances (1342 body copies, 250 WAVE linked faces). `[course CAD3.5 00:00:39]` work on the copy, never the master. |
| Parallel skin | **Offset Surface** | `[mined]` 33 uses, 0.1-2 mm. |
| Make a sheet reach before a trim / boolean | **Extend Sheet** | `[mined]` 294 uses, Offset limit, natural curvature, 0.5-28 mm. `[course CAD5.6 00:18:16]` only has to overshoot. |
| Flange / parting wall off an edge at an angle | **Law Extension** | `[mined]` 70 uses, (length 1, angle 45) 24x, angle 90 19x, then `TRIM BODY` 31. `[course CAD5.5 00:22:59]`. Flat flange round a rim, draft walls: Type Vector or a spine (Settings). |
| Trim a solid with a sheet that does not reach across it | **Trim and Extend > Until Selected**, tool = the sheet's free EDGES | `[cast effc / until selected]`; 9600.0 exact in one feature `[verified]`. Or Extend Sheet + Trim Body. |
| Grow a B-surface in U/V | **Enlarge** | `[mined]` 15 uses after a loft, before a trim. Not in the course. |
| Cut a sheet by curves, faces, a datum plane | **Trim Sheet** | `[mined]` 346 uses, Keep 180 / Discard 80. `[course CAD5.6 00:19:29]`. |
| Extend one sheet to another and corner them | **Trim and Extend > Make Corner** | `[mined]` 102 uses, 70 of 75 MakeCorner. `[course CAD5.6 00:20:35]` target = free edges. |
| Join sheets; closed set -> solid | **Sew** | `[mined]` 355 uses, tolerance 0.01. `[course CAD5.4 00:57:25]` "like Unite, for sheets". |
| Take faces back off a body | **Unsew** | `[mined]` 56 uses between `SEW` / `TRIMMED_SH`. |
| Sheet -> thin solid | **Thicken** | `[mined]` 88 uses, 1.8 or 1.5 mm, second offset 0. `[course CAD5.5 00:48:16]`. |
| Cut a solid with a skin / re-skin one face | **Trim Body** with a sheet, **Replace Face** | `[mined]` 343 of 538 trim bodies use face/plane tools; Replace Face 1929 uses. `[verified]` both. |
| Weld a sheet into a solid | **Patch** | `[verified]`; not in the mined parts or the course recordings. |
| Recover the untrimmed surface | **Untrim** | `[mined]` 24 uses. New sheet; planes come back as a padded box `[verified]`. |
| Remove a notch or an inner loop from a sheet, in place | **Delete Edge** | `[verified]` 721.7 -> 750 -> 800 mm2, same body. `[community]` 1 author, 18 uses, always before Extend Sheet. |
| Close holes in a wall (mould shut-off, capping an opening of a face set) | **Patch Openings**, Type Quilted, faces by tangent rule + the hole edges | `[verified]` patch = the wall surface (flat or cylindrical), separate sheet bodies. `[community]` 1 author. |
| Parting sheet off a product's parting line | Extrude the edges outward as sheets (open section) + **Sew**; **Ribbon Builder** for a constant-width band | `[verified]` 9600.0 mm2 one sheet; Ribbon 2314.25. `[community]` 1 author, 3 exercises. |
| Constant section that twists along a guide (twisted bar, fin, band) | **Swept**, orientation By Angular Law (start / end angle) | `[verified]` volume exact at 90 / 180 / 405 deg. `[community]` 1 author (405 deg bands). |
| Blade, vane, impeller / propeller / turbine wheel | section "Blades and blade sets" | `[verified]` 4 journals. |

Do NOT reach for surfacing when sketch + extrude/revolve + blends give the shape: surfacing appears in 37
distinct part families of ~690 dumps `[mined]`, mostly scan rebuilds and industrial-design skins.

## Method rules

- **Section arrows and start points must correspond** in every section-to-section command
  `[course CAD5.4 00:09:46, 00:22:32]`. In a journal the start is the end of the seed curve nearest the
  `AddToSection` help point; a mismatch usually builds silently (area 1741 instead of 1943, volume 12567
  instead of 29320, 20000 instead of 28000) `[verified]`. Read back `sec.GetStartAndDirection()`; repair with
  `ReverseDirection()`, `SetStartCurveOfClosedLoop(0, point)`, `SetStartAndDirection(curve, point, vector)`.
- **Select whole sections** - the GUI's Connected Curves rule `[course CAD5.4 00:21:25]`; in a journal put
  every curve of the string in one rule, one `Section` object per string.
- **Alignment ladder for creased lofts: Parameter -> Arc Length -> By Points** `[course CAD5.4 00:23:43]`.
  Rectangle to triangle: a corner ruling is 3.54 mm off (Parameter), 3.11 mm off (Arc Length), 0.00 (By
  Points) `[verified]`. By Points = `Alignment.AlignType = Points` +
  `SetAlignPoints([CreateOnPathDimBuilder(section, Point3d), ...])`, section by section, equal counts.
- **Never judge a surface by eye** - the course uses Analysis > Reflection `[course CAD5.4 00:35:35]`. Headless
  stand-in `[verified]`: `g1_deviation(face_a, face_b, points_on_shared_edge)` (angle between the two normals;
  0 = G1) and `max_curvature(face, point)` on both sides (equal = G2). Measured: G0 end 11.31 deg; G1 end
  0.00 deg but curvature 1/78 against the neighbour's 1/20; G2 end 0.00 deg and exactly 1/20.
  Examine Geometry does **not** see creases (Edge/Face Smoothness 0 on a 43.6 deg crease).
- **Tangent is not joined**: G1 patches are still separate sheets until Sew `[course CAD5.4 00:52:25]`.
- **A sweep section must be normal to its guide** `[course CAD5.5 00:04:41]`: a circle not normal to a 45 deg
  guide is carried upright, volume 2513 instead of 3554 `[verified]`. **Sharp-cornered guide -> Sweep Along
  Guide**: Swept raises "Some curves in Guide sections not tangent continuous"; Sweep Along Guide gives the
  mitred elbow, volume = area x path length exactly `[course CAD5.5 00:16:47]` `[verified]`.
- **Cap choice**: planar loop -> Bounded Plane; hole in a skin -> Fill Surface (G1 to the faces owning the
  edges, patch area and normals match the skin: 0.00 deg, 0.000 mm off); N-Sided needs its constraint faces
  to be tangent at all (17-18 deg crease without, 0.38 deg with) and even then is 0.2-0.4 mm off the original
  surface in the middle `[course CAD5.5 00:35:39-00:40:24]` `[cast effb / N-sided overview]` `[verified]`.
- **Thicken occupies the space between Offset 1 and Offset 2** along the face normal
  `[course CAD5.5 00:48:16]`: (2, 3) = 1 mm wall detached from the face, (0, 3) = 3 mm on the face,
  (-2, 3) = 5 mm straddling it; volumes 1200 / 3600 / 6000 on a 40x30 sheet `[verified]`.
- **Two sheets that must meet**: Extend Sheet so one overshoots, then Trim Sheet each with the other
  `[course CAD5.6 00:18:16-00:20:35]`; or one Trim and Extend > Make Corner whose **target is the free edges**
  of the sheet to extend - with the sheet's faces as target: "Unable to perform Boolean."
  `[course CAD5.6 00:21:10]` `[verified]`. Flags on crossing sheets `[verified]`: `ReverseTarget` keeps the other
  half of the TOOL sheet, `ReverseTool` the other half of the TARGET sheet, `ArrowSideOption = Delete` inverts both.
- **Sheet -> solid routes**: closed sections with Body Type Solid; cap every opening (Bounded Plane) and Sew
  `[course CAD5.6 00:15:23]`; Fill Surface with Patch into Part `[course CAD5.5 00:41:09]`; Thicken; Patch.
  Prove it with `IsSolidBody`, zero free edges, volume, and `nxh.examine_geometry` (`BodySheetBoundaries` 0).
  Siemens' exercises use the same routes, in the order Sew -> Edge Blend -> Shell (blend before the wall, as
  in the user's "blend first, thicken last") `[cast effa / ceramic water tank]`.
- **Leaking imported body**: `nxh.examine_geometry(part, body)` -> `BodySheetBoundaries` = number of open
  edges -> cap (extruded edge sheet, Bounded Plane) -> Sew `[course CAD4.1 00:09:52-00:18:37]` `[verified]`.
- **Core / cavity with plain modelling commands** `[community: 1 author, 3 exercises]` `[verified,
  surf_mould_repair.py]`: a shut-off sheet for every opening (Patch Openings for holes in a wall; for a stepped
  opening a copy of the product face -> Delete Edge -> Extend Sheet), a parting sheet from the parting-line
  edges, workpiece block minus product with the tool kept, then ONE Split Body whose tool is all those sheets
  together, not sewn. Measured: core 116489.062 / cavity 192000.000, both exact. **Delete Edge before Extend
  Sheet**: extending a notched edge keeps the notch as a slot in the extension (871.7 instead of 1000 mm2).

## Course and mined practice: where they agree or differ

- Through Curves with G1 to neighbours: agree (course rule; `[mined]` G1 at an end in 32 of 40).
- Alignment: course teaches By Points for unequal sections; `[mined]` never uses it (Parameter 18,
  Arc Length 12, Spine Curve 10) - the user's sections are mostly single splines or arcs.
- Ruled: course uses it for reference patches; `[mined]` only 5 - the user gets reference faces from sheet
  extrudes and Bounded Planes instead.
- Mesh continuity: course ties all four boundaries; `[mined]` G1 on the primaries in only 2 of 16, crosses never.
  The course's "swapping primaries and crosses gives a worse surface" was not reproduced: both role
  assignments with G1 to the neighbours gave the identical surface (max gap 0.000 mm, same area) `[verified]`.
- Sweeps: agree - Sweep Along Guide 38 vs Swept 9 `[mined]`.
- Fill vs N-Sided: agree - Fill Surface 32 (G1 26) vs N-Sided 2 `[mined]`. Patch into Part: course recommends
  it, the user leaves it off in 26 of 29 and adds a separate Sew.
- Make Corner vs Extend + 2 Trims: both in the course; the user does both (Trim and Extend 102, usually right
  after Extend Sheet; Trim Sheet 346).
- Thicken: course explains both offsets; `[mined]` second offset is 0 in 87 of 88.
- Sew to solid, Bounded Plane caps: agree (Bounded Plane -> Sew 45 times `[mined]`).
- Not in the course but heavy in the user's parts: Studio Surface, Enlarge, Unsew, Untrim, Fit Surface,
  Section Surface, Trim Body / Replace Face with sheets, the Trim Sheet <-> Sew loop.
- Face Blend between sheets is taught in depth; `[mined]` Face Blend has 32 instances, mostly on solids.
- Siemens' NX CAST 8.5 lessons (`[cast]`, 69 freeform parts): the parts are start states - wireframe (three
  quarters dumb curves, a teaching convenience) plus reference faces; saved settings are the plain ones
  (Parameter alignment 22 of 22 lofts, Emphasis Both 9 of 9 meshes, no rebuild). The one finished skin model
  trims every patch with Trim Body against its neighbour, then Sew -> blend -> mirror; the user trims mostly
  with Trim Sheet. Both are fine; the user's habit stays the default for the user's own work. CAST adds no
  rule on sewing gaps, Fill Surface, Studio Surface or Extend Sheet.

## Workflows the user actually runs `[mined]`

1. **Skin -> trim -> sew -> blend -> thicken** (fan volute): sheet extrudes and bounded planes, `TRIM BODY` /
   `EXTEND_SHEET` / `TRIMMED_SH` to size, `SEW` after every trim (Trim Sheet -> Sew 106 times, Sew -> Trim Sheet
   73), `UNSEW` to re-trim one face, `BLEND` on the quilt, then one `THICKEN_SHEET` (1.5). Blend first, thicken
   last: 57 of 88 thickens have an Edge Blend as direct parent.
2. **Fit/offset planes -> extend -> make corner -> cap -> sew -> boolean** (A8S chassis): `EXTEND_SHEET` x2-3,
   `TRIM_AND_EXTEND` x2-3, `TRIM BODY`, bounded-plane caps, `SEW` to a solid, `SUBTRACT`/`UNITE`.
3. **Curves -> Through Curves / Studio / Section Surface -> Enlarge -> Trim Sheet -> Sew** (UA24, watch and
   optical housings), `FILL_HOLE` for leftover openings, `SEW`, `BLEND`.
4. **Solid first, surface as a tool**: `LAWEXTENSION` / `EXTEND_SHEET` / lofted sheet -> `TRIM BODY`
   (Law Extension -> Trim Body 31 times) or `REPLACE_FACE`. Use when only one face is freeform.
5. **Closed loft straight to solid**, then `UNITE` or `SHELL`.

## Blades and blade sets (impeller, propeller, fan, turbine wheel) `[verified]`

Call sequences, measured numbers and the edit recipe: `references/blades.md`. Helper: `scripts/nxblade.py`
(`import nxblade as nb`); complete examples `blade_helicoid.py`, `blade_sections.py`, `blade_centrifugal.py`,
`blade_edit_count.py`.

| Blade | Route |
|---|---|
| Thin, constant thickness (propeller, axial fan) | Helix + **Swept** of a radial line -> **Thicken** `thk/2`, `-thk/2`. Orientation: two helix guides + Uniform scaling (0.0016 mm from the true helicoid) or one helix + `ByVectorDirection` along the axis (0.0041 mm). **Never the default `Fixed`: 16.6 mm off, no error.** |
| Profiled (turbine, compressor, wind turbine) | one closed, fully constrained section sketch per datum plane at a station offset (chord, twist as expressions) -> ONE **Through Curves**, Body Type Solid, same curve order and start point in every section. Root shank = separate Extrude united into the blade body. |
| Vane between hub surface and shroud line (centrifugal impeller) | camber sheet through the whole passage (ruled between a curve below the hub surface and one above the shroud) -> Thicken -> **Intersect with the revolved passage envelope** whose top edge is the shroud line. |

- Named expressions first (count, radii, pitch or stations, thickness, root radius); hub = Revolve of a DOF 0
  meridional sketch. `[community]` the blade parts of the collection (1 author) carry almost none - do not copy that.
- Let the blank reach ~2 mm into the hub and beyond the tip, then **cut the tip with the revolved envelope**
  (Cylinder or Revolve with Intersect): the tip radius becomes a measurable fact.
- **Set = Pattern Geometry of the finished blade BODY** (count = expression) + ONE Unite with
  `tool_features=[blade feature, pattern feature]`. Not Pattern Feature: it replays only the listed features
  (measured: copies of the uncut blank, 7607.7 instead of 7125.9 mm3, no warning); `[community]` the one
  Variational blade pattern in the collection is saved with 5 failed instances.
- **Root blend after the Unite**, edges by `CreateRuleFeatureIntersectionEdges([unite])`: follows the blade
  count on update. (`CreateRuleEdgeFeature([unite])` takes every blade edge - the volume drops.)
- Checks: one solid; blade count by section (`nb.blade_count_section`) and by topology (`nb.blade_groups`,
  even spacing, equal groups); tip radius (`nb.radial_extent`); thickness; Examine Geometry; STEP through the
  validity gate (`nb.step_gate`).
- **Changing the blade count.** Parametric: the count expression (changed and restored on all three wheels:
  5 -> 7, 9 -> 7, 7 -> 9, 7 -> 5).
  Imported body: `nb.strip_blades` (Delete Face, heal, on every blade group but one) -> `nb.repattern`
  (Pattern Geometry of the body x new count, one Unite) or `nb.pattern_faces` (Pattern Face of the kept
  blade's faces); 7 -> 5 on our own STEP gave the parametric 5-blade wheel to 5e-7 in volume either way.
  `[bench]` on the one such edit of the v0 run (a loose foreign impeller) one Delete Face for all blades was
  refused and blade-by-blade worked (`nb.strip_blades` falls back to that), Pattern Face was refused
  ("... incomplete set for patterning"; the same layout on our clean STEP patterned fine), the body route
  worked: try Pattern Face in `nxh.attempt`, fall back to the body route. Run on a copy of that benchmark
  input, the helpers reproduce its NX result unattended (7 groups although the vanes cut the hub face into
  patches, six single Delete Faces, 5 blades at 72 deg, 3045811.919 mm3, gate valid).
  Deleting only the surplus blades leaves the rest at the old pitch (51.4 deg x 4 + 154.3 deg) - right
  count, wrong part.

## Section strings in NXOpen `[verified]`

- `AddToSection(rules, seed, Null, Null, help_point, Mode.Create, False)`; `nxh.section(part, curves=,
  edges=, help_point=, seed=)` builds a new one, `nxh.fill_section(part, sec, ...)` fills an existing one.
- Builder-owned sections must be filled in place: `BoundedPlaneBuilder.BoundingCurves`,
  `FillHoleBuilder.CurveChain`, `SweepAlongGuideBuilder.Section/.Guide`, `NSidedSurfaceBuilder.OuterLoop`,
  `LawExtensionBuilderEx.BaseProfile`, `RuledBuilder.FirstSection/.SecondSection`,
  `SectionSurfaceBuilderEx.SectionStartGuide/.SectionEndGuide/.ApexCurve/.ShoulderCurve/.SpineSection`,
  `GlobalShapingBuilder.RegionToDeform`. List builders
  (`SectionsList`, `PrimaryCurvesList`, `GuideList`...) take `Append(section)` then
  `Alignment.SetSections([...])` for Through Curves / Swept / Studio.
- **`body.GetEdges()` / `GetFaces()` have no fixed order between NX sessions.** A string filled with
  `edges=list(body.GetEdges())` starts on whichever edge comes first: the same journal built a Law Extension
  leaning outward in one run and inward in the next (`surf_law_extension.py`, first regression run). Pick
  the seed edge by geometry and put it first (or pass `seed=`), help point at the end where the string starts.
- **Always pass `seed=` with a rule-only section** (`nxh.section(part, rules=[...], help_point=, seed=)`).
  With a seed the string starts at the seed end nearest the help point; without one the start was the same
  NX-chosen corner for every help point tried, so the help point is ignored and the loft may twist.
- Full circles as two arcs (`nxh.circle`). Dumb curves do not follow expressions. Parametric skins, all
  three measured with an edit + `nxh.update()`:
  - associative Line/Arc features on smart points, one `CreateRuleCurveFeature(features)` rule per section
    (recipe: `nx-curves-and-sketches/references/nxopen-recipes.md` section 7b; `assoc_rect()` in
    `surf_round3_checks.py`): volume 21400.0 -> 33600.0 after width 40 -> 50 and height 30 -> 40, exact;
  - fully constrained sketches, `CreateRuleCurveFeature([sketch.Feature])`, the upper sketch on a datum plane
    at an expression height: same 21400.0 -> 33600.0, no feature errors;
  - edges of features (`loft_h` 40 -> 60 followed).

## Settings that matter

- **Set tolerances explicitly on every builder** `[verified]`: batch defaults are not the part tolerance (Curve
  Mesh 0.0254 / 0.02; N-Sided 0.0 -> "Unable to build surface."). The user's features read 0.01 mm / 0.5 deg `[mined]`.
  Approximating commands (Swept on a curved guide, rebuilt lofts, N-Sided) are only as exact as the tolerance:
  Swept on an arc guide 0.011 mm off the true torus at 0.01, 0.040 at 0.1; tightening to 0.001 changed nothing,
  loosening made the face lighter (121 -> 77 poles); the angle tolerance had no effect there, on N-Sided it is
  the G1 residual. Never tighter than the part tolerance `[cast effz / tolerances]`; in an old part keep the
  part's own tolerance (converted inch parts: 0.0254).
- **N-Sided next to faces** `[verified, surf_nsided.py]`: `b.ConstraintFaces.ReplaceRules([face rule], False)`
  + `b.Continuity.ContinuityType = G1` (the collector on the BUILDER - `b.Continuity.ConstraintFaces` is
  ignored; G0 or no faces: creased, no message). G2 only with `TriangularPatch` + `MergeFaces = True`.
- **Through Curves**: `PatchType=Multiple`, `PreserveShape=False` (35 of 40 `[mined]`; True keeps sharp corners
  and planes, needs Parameter/Points alignment), continuity = `ContinuityType` + `ConstraintFaces` holding the
  face that owns the section edge. G2 also needs `CurvatureTolerance`. Options that change the result
  silently `[cast effa]` `[verified, surf_loft_options.py]` (table: `references/option-semantics.md` 1):
  - `LoftingSurfaceRebuildData.Degree = 1` puts an EDGE at every interior section (4 sections: 3 faces,
    28.01 deg crease); 2 or 3 (default) one smooth face. Count the faces of every loft.
  - `NormalToEndSections = True`: a free end on a symmetry plane leaves at 90 deg (tilt 43 -> 0.00 deg; seam
    to the mirrored half 86 -> 0.00 deg) - no reference face needed for a half model.
  - Decide `PreserveShape` by what comes next: an Edge Blend / Chamfer on a loft corner needs True (the corner
    is an edge; only with Parameter / Points alignment); False rounds corners to R0.02 inside the tolerance.
    Equal curve counts -> Parameter (corner to corner); unequal -> By Points; Arc Length shifts corners (6.3 mm).
  - `FlowDirection` acts only on a G1 / G2 end: `Perpendicular` makes the isoparms leave the edge at 90 deg
    (Not Specified: 63 deg on a skew edge) - the user's habit `[mined]` 22 of 40.
  - Rebuild (`RebuildType = Manual`, degree) is an approximation: 0.0014 mm off the interior sections.
  - The face normal follows the section ORDER: swapping two sections reverses every later direction flag.
- **Through Curve Mesh** `[cast effa]` `[verified]`: `Emphasis` decides where the surface lies when the two
  curve families miss each other (0.05 gap: Both 0.025 / 0.025, Primary 0 / 0.05, Cross 0.05 / 0); the gap
  must be within `IntersectionTolerance` ("Strings do not intersect within tolerance."). A point may be the
  first or last primary (`CreateRuleCurveDumbFromPoints`).
- **Swept** `[verified]`: 1-3 guides (`GuideList`), several sections (`SectionList`). Two guides need
  `ScalingMethod.ScalingOption = Uniform` or `Lateral` (else "Invalid input scaling method"); three guides
  need none (the default commits; Uniform / Lateral change nothing) `[cast effb / scaling method]`. One guide:
  `ByAreaLaw` + `AreaLaw` (Linear 1000 -> 600: cap areas 1000.0 / 600.0, 800 at mid length) for ducts;
  `Constant` + `ScaleFactor` (2.0 turned R4 into R8, volume exact), `ByBlendingFunction` +
  `StartBlendScaleFactor` / `EndBlendScaleFactor` (1 -> 2 Linear = exact frustum). `OrientationMethod.
  OrientationOption`: `Fixed` translates the section along a straight guide; `ByFaceNormals` +
  `OrientationMethod.Faces` keeps it on the face normal (end of the section 0.000 mm from the normal's tip,
  7.05 mm from the translated position); `ByVectorDirection` + `OrientationVector`. `Spine` is a builder-owned section.
  A corner fillet on the guide rescues Swept only when its radius exceeds the section's half-width.
  **On a curved guide `Fixed` only translates the section**: a radial line along a helix is 16.6 mm off the
  helicoid; `ByVectorDirection` along the helix axis (0.004 mm) or a second guide (0.002 mm) turns it.
- **Swept twist** `[verified]`: `OrientationOption = ByAngularLaw`, `AngularLaw.LawType = Linear | Cubic`,
  `StartValue` / `EndValue` in degrees (formulas allowed; the feature owns both as expressions). A positive
  angle is a LEFT-hand rotation about the guide direction - probe a corner at mid length, a symmetric section
  hides the sense at the end. On a closed guide the total twist must map the section onto itself (rectangle:
  180 deg gives a clean ring; 405 deg commits with `BodyConsistency` 2). `nb.swept(..., orientation="angular")`.
  **Linear law = constant twist rate, so the twisted faces are not tangent to straight neighbours at the
  ends** (0 -> 90 deg over 50 mm: 14.1 deg off at 8 mm from the axis); **Cubic = zero rate at both ends**
  (0.11 deg). Twisted piece that continues into straight material -> Cubic `[cast effb / angle law]` `[verified]`.
- **Trim Sheet**: `ExtendBoundaryObject=True` (`[mined]` 248 of 260; batch default False fails on a short tool).
  Put **all cutting curves in ONE boundary Section** (one `BoundaryObjects.Add`): then several region points
  work and a disjoint result comes back as several bodies. Datum planes only through an `ScCollector`.
- **Studio Surface**: G1 through `FirstSectionContinuity` / `LastSectionContinuity` (+ `ConstraintFaces`) worked
  at both ends only without guide strings (0.00 / 0.04 deg); with two guides one end stayed 41 deg off.
  For a guided patch tangent on all sides use Through Curve Mesh.
- **Section Surface** `[cast efff]` `[verified, surf_section_surface.py]`: `CreateSectionSurfaceBuilderEx`;
  `Type` Conic / Circular / Cubic / Linear + a mode (NX 8.5 names such as Fillet-Rho, Ends-Apex-Shoulder map
  onto them - table in `references/option-semantics.md` 6). Most useful:
  Conic + `ConicType.Rho` + `SlopeControl ByFaces` (two guides, two faces, rho; `ByApex` = an apex curve
  instead of the faces; `ConicType.Shoulder` = a curve instead of rho); Cubic + `FilletBridge` (two guides,
  two faces, G1 or G2 per side, no spine); Circular `TangentTangentRadius` (two faces + radius),
  `ThreePoint`, `TwoPointRadius`, `RadiusAngleArc`. Rules:
  rho = fullness, 0.4142 in a 90 deg corner is the circular fillet, 0.5 a parabola; `UDegree` Conic is exact,
  Cubic / Quintic approximate and refuse rho > 0.75; **always set a spine** (`SpineType` ByVector / ByCurve) -
  the sections lie in planes normal to it and the surface is only as long as the spine; Two Point Radius has
  two solutions, the ORDER of the guides picks the arc.
- **Fill Surface**: face-owned edges are G1 whatever `DefaultEdgeContinuity` says; on sharp edges that fails
  with "Some edge cannot have G1 continuity.". Per-edge G0 = `SetBorderTypeItems` with one
  `FillHoleBuilder.BorderContinuity()` (`.BorderObject = edge`, `.Continuity = G0`) per edge; with that and
  `Patch=True` an open box became a solid in one feature `[verified]`.
- **Face Blend**: `FirstFaceCollector` / `SecondFaceCollector`, `ReverseFirstFaceNormal` / `ReverseSecondFaceNormal`
  choose the quadrant, `TrimInputFacesToBlendFaces` + `SewAllFaces` (both default True) give one sheet body.
  Asymmetric: `CrossSectionType = Conic`, `ConicCrossSection.FirstOffset` / `.SecondOffset` / `.Rho` - each
  offset lands on the OTHER face (8, 4 cut face 1 back 4 and face 2 back 8). Variable width:
  `BlendWidthMethod = TwoConstraintCurves` + `ConicCrossSection.First/SecondConstraintCurveCollector`.
  Inputs of unequal length `[cast effc / trim and sew options]` `[verified]`: `TrimmingOption` Short = blend as
  long as the short input, Long = the long one, ToAllFaces (default) = cut by both boundaries, NotSet =
  overshoots both ends by the radius. Blend that dies at a slightly non-tangent edge (parting line, 2 deg
  kink): `PropagatePastSharpEdges = True` + `PropagationAngle` just above the mismatch (3.0 crossed it, 1.0
  did not; Add Tangent Faces does not help). Swept section + spine and law radius: not working in a journal.
- **Law Extension** `[cast etss885, efff]` `[verified, surf_law_extension.py]` (matrix:
  `references/option-semantics.md` 4): Type `Faces` - angle from the reference face in the plane normal to the profile
  (90 stands on it, 0 continues it; other angles lean away from the face or over it depending on the profile
  direction - below); Type `Vector` - angle from one direction, faces irrelevant (draft and
  parting walls). **Rim of inclined faces: without a spine the 90 deg flange stands on each face and is not
  planar** (tapered duct: 3.16 mm out of plane); `SpineDefinition` by Vector (rim-plane normal) + angle 90, or
  Type Vector + 90, gives the flat flange. `MiterOption`: `Sharp` always one body (mitred; flat rim: area
  exact); `Blend` (the default) one body with tangent corner faces ONLY where the walls lean outward - where
  they lean inward it leaves one body per edge with no message; `NotSet` one body per edge; `Radius` did not
  join. **The profile DIRECTION decides the side**: Faces type, wall = cos(angle) x (profile direction x face
  normal) + sin(angle) x normal (profile counter-clockwise seen against the normal: below 90 leans out, above
  90 in; `IsReferenceFaceNormalReversed` or the other direction swaps them; 90 is unaffected); Vector type,
  wall = cos(angle) x vector + sin(angle) x (profile direction x vector) - a rim taken clockwise puts the
  90 deg flange INSIDE the rim (328 instead of 1120 mm2). So fix the direction (Section strings, above) and after every
  multi-edge Law Extension count the new bodies and read the bounding box. Linear length law,
  `OppositeSideExtensionOption` Symmetric / Asymmetric: verified.
- **Offset Surface / Thicken of a quilt**: pass the whole sewn body (`CreateRuleFaceBody`); the inside of a
  corner is trimmed, the outside extended, one body either way. The offset must stay below the smallest
  concave radius (R5: 4 works, 6 fails - texts in Pitfalls). Several `FaceSets` with different distances in
  one feature `[cast effc / offset surface]` `[verified]`: fine on faces that meet at a corner (3 and 5: one
  sheet); a 0 set next to a TANGENT non-zero set needs `StepOption = True` (shelf face, else an error); two
  non-zero sets on tangent faces build but are extended to a far intersection - use
  `OutputOption = OneFeatureForEachFace`.
- **Enlarge** `[cast effg]` `[verified]`: `IsCopy = True` is required for planar faces and for faces of a
  sewn sheet (in place: "Invalid face."); `Natural` follows the curvature, `Linear` continues straight;
  a negative percentage shrinks.
- **Thicken**: `FirstOffset` / `SecondOffset` formulas (named expression), `ReverseDirection` picks the side
  (`[mined]` False 51 / True 34).
- **Extrude/Revolve as sheet**: `FeatureOptions.BodyType = Sheet` (`nxh.extrude(..., sheet=True)`); an open
  section gives a sheet anyway.

## Tolerances and gaps `[verified]`

| Case | Sew tol 0.01 | Sew tol 0.1 |
|---|---|---|
| Two sheets, gap 0.005 | sewn | - |
| Two sheets, gap 0.05 | exception "A tool body does not share a common boundary with any other sheet and will not be sewn." | sewn (tolerant edge, bbox grows ~0.28) |
| Tube + 2 caps, one cap 0.05 off | **no error**: sheet with 1 free edge | solid, volume +0.08 % |

The modelling tolerance can never be 0; hairline gaps between unsewn tangent sheets are inside it
`[course CAD5.4 00:57:58]`. A sew is proven only by `IsSolidBody`, zero free edges and the volume.

## Verify every feature

- Area of a sheet: `nxh.sheet_area(part, body)` -> (area, perimeter). `NewMassProperties` is wrong on sheets
  (the new `nxh.mass` guards this).
- Body kind and count: `body.IsSolidBody`, `len(nxh.sheets(part))`, `len(nxh.solids(part))` before/after
  (the course checks the same thing with the Sheet Body / Solid Body selection filter).
- Open boundary: `nxh.free_edges(body)`; two sheets sewn along one edge 8 -> 6, closed set 0;
  `nxh.examine_geometry(part, body)["BodySheetBoundaries"]` gives the same count.
- Point on surface: `nxh.dist_to(part, body, xyz) == 0`. Tangency / curvature: `g1_deviation`, `max_curvature`.
- `nxh.face_census(body)`: B-surface is type 43; Sweep Along Guide, Revolve, Face Blend give analytic faces.
- **Never pick or rank freeform faces by bounding box.** `nxh.bbox` of a B-surface is loose - an
  R20 loft reports 20.136, and in the acceptance build the inner crown face of a shell reported
  zmax 23.78 against a true 21.0, above the outer face - and tolerant sewn edges inflate it.
  Identify freeform faces by area (`nxh.sheet_area(part, [face])`), by `nxh.dist_to` at a
  designed point, or by `nxh.normal_at`.
- `nxh.feature_errors(part)` empty; but after a rolled-back failed commit the next feature can carry a stale
  alert, so measure before believing it. After an expression edit: `nxh.update()` and re-measure. (Since then `nxh.feature_errors(part)` re-evaluates flagged features with `UpdateManager.LogForUpdate` + update, which drops such stale messages and keeps real errors; the raw read is `nxh.feature_errors(part, recheck=False)`.)

## Pitfalls `[verified]`

- Direction flags depend on the sheet normal (`TrimBody2.BooleanTool.ReverseDirection`,
  `PatchBuilder.ReverseDirection`, `ReplaceFaceBuilder.ReverseDirection`, Face Blend normals): commit, measure,
  undo and flip (`patch()` in `surf_edit.py`, `face_blend_auto()` in `surf_course_checks.py`).
- Never `undo_to` a mark set before a builder was created while that builder is still alive: destroy it first.
- Replace Face to a sheet needed `ReverseDirection=True`; otherwise "A face does not intersect properly and
  its edges cannot adapt."
- Trim Body tool sheets must cross the whole target: extend first (Extend Sheet -> Trim Body 59 times `[mined]`).
- Enlarge in place refuses planar faces and faces of a sewn sheet ("Invalid face."); with `IsCopy = True` both
  work. Fill Surface needs one closed loop ("Unable to handle multiple loops in hole boundary.").
- **Offset Surface drops a face it cannot offset without telling**: R5 offset by 6 towards its axis next to a
  plane -> no error, no alert, `GetErrorFaces()` empty, the result has one face less (`PartialOption` makes no
  difference; only a body where NOTHING can be offset raises the error below). Count the faces of the result.
- Section Surface, Conic type, no spine set: "Internal error: memory access violation" (seen once; the journal
  survived, the run exits 1). Linear Tangent-Tangent between two planes: "Unable to map spine curve to guide
  curves or faces."
- Law Extension with a spine: the spine vector must not be the normal of the reference face ("Invalid input
  data."), and with a spine normal to the rim plane only angle 90 is useful (0: "Modeler error. Initiating
  error recovery.").
- No Four Point Surface builder exists in NXOpen Python on NX 2206; use Fill Surface or Bounded Plane on 4 lines.
- FeatureType names: Extract Body is class `ExtractFace` / `EXTRACT_BODY`; Bounded Plane, Ruled and Swept are
  all `SKIN`; Sweep Along Guide is `SWP104`; Face Blend is `FACE_BLEND`.
- Law Extension, Untrim, Offset Surface, Variable Offset, Bridge and Section Surface create new sheets; Extend
  Sheet, Trim Sheet, Enlarge (unless `IsCopy`) and Global Shaping edit in place.
- Old parts and Siemens lessons use NX 8.5 names and ambiguous type strings (`TRIM_SHT` is Trim Body,
  `SECTION_SURF` may be an old Law Extension, Quilt / Soft Blend / Transition / Rough Offset have no builder):
  mapping table in `references/option-semantics.md` 10.
- Trim Sheet with two cutting curves added as two boundary objects honours only one of them and raises nothing
  (discarding the middle strip left one 10 mm strip instead of two); with two region points it raises
  "Invalid retained/discarded regions.". One Section holding both curves fixes both.
- Swept along a guide whose corner fillet (R2) is smaller than the section half-width (3) commits without
  error but the solid is invalid: `nxh.examine_geometry` reports `BodyConsistency` 2. Run it on every swept solid.
- Offset beyond the radius of curvature: Offset Surface raises "The Offset Surface operation is unable to
  provide a full solution. One or more input faces or vertices could not be offset. Try Enable Partial
  Offset."; Thicken raises "Cannot offset face. The offset distance might be greater than the radius of
  curvature of the face or the offset face might intersect itself." Remedy: offset to the convex side, keep
  the value below the smallest concave radius, or rebuild the tight region before offsetting.
- Face Blend conic with an offset larger than the face it lands on: "Radius is too large for the faces selected."
- Patch Openings types are not interchangeable: `BySuppression` makes no sheet, it suppresses the hole features of
  the solid (and `CommitFeature()` returns `None`); `MoldWizard` returns `None` too but leaves two Bounded Plane
  features; `Extension` on a round hole: "Unable to create all requested patch sheet bodies.  Try a different
  type."; Output `Sew` with faces of a solid: "Faces to patch cannot be from solid body for sew option." Count
  the new sheet bodies after the commit instead of trusting the returned object.
- A thin blade swept with the default orientation looks plausible and is wrong (see Settings, Swept); a blade
  pattern made with Pattern Feature copies the state of the listed features only. Both raise nothing.

## Not verified here

Fit Surface (258 uses, facet input; see `nx-reverse-engineering`) and Emboss: not probed here. Section Surface:
Conic Rho / Shoulder, Cubic Fillet Bridge and five Circular types are verified; Hilite, Five Point, Two Slopes,
the Center types, Linear, depth / skew and varying laws are not. Face Blend with a swept section or a law
radius does not build in a journal with the settings tried; tangency curve and coincident edge not run.
Variational Sweep, Curve Mesh spine, Through Curves Construction Spline Points / Simple, Swept area law by law
curve, Law Extension multi-transition laws and the isocline undercut fill, Global Shaping other than To Point,
N-Sided centre control (`CenterControlZ` is not a height in mm): not run. What Siemens' CAST lessons do not
answer either: sew tolerance and gap repair, Fill Surface, Studio Surface, Extend Sheet - the text here is
this skill's own measurement. Studio Surface G1 together with guide strings, Fill Surface G0 on a multi-face
hole: open. Patch Openings is verified on closed hole loops in one
wall (flat and cylindrical); openings across several faces, `Limits` / `DividingCurves` and the `Extension`
type (error on a round hole) are not. Blades: splitter blades, shrouded wheels, fir-tree roots not covered.
Course claims not reproduced: "Fill Surface with every edge at G0 is as creased as N-Sided" (on a hole inside
one face Fill returned the underlying surface at G0 and G1 alike); "N-Sided Trim to Boundary only cuts a closed
loop" (three sides of a rectangle were trimmed to 1200 mm2 as well). ("Law Extension Miter Blend works below
90 deg" IS reproduced once read as "where the walls lean outward" - Settings, Law Extension.)
