"""Unknown scan -> census -> datum frame -> fit-and-snap table -> rebuild -> signed deviation (NX 2206, headless).

The scan is the L-bracket of nxre.truth_bracket, 1.5 mm triangles (111 022 facets), 0.02 mm noise, turned by
two rotations (17 deg about Z, then 28 deg about X) and shifted (12, -7, 3). Nothing below uses the known
positions of the features: planes, cylinders and the datum frame come from nxre.census; the truth is only
used to CHECK the result.

run_journal.ps1 -Script re_unknown_part.py -WorkDir <dir> -JArgs <out dir>  ->  re_unknown_part.json
"""
import math
import os
import sys
import time
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
sys.path.insert(0, os.environ.get("NXRE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import NXOpen
import nxh
import nxf
import nxre

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "re_unknown_part.log"))
chk = nxh.Check()
res = {"result": "FAIL"}
SIGMA = 0.02


def rot(axis, deg):
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    x, y, z = axis
    return [[c + x * x * (1 - c), x * y * (1 - c) - z * s, x * z * (1 - c) + y * s],
            [y * x * (1 - c) + z * s, c + y * y * (1 - c), y * z * (1 - c) - x * s],
            [z * x * (1 - c) - y * s, z * y * (1 - c) + x * s, c + z * z * (1 - c)]]


def mm(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


RT = mm(rot((1, 0, 0), 28.0), rot((0, 0, 1), 17.0))          # truth: x_scan = RT x_cad + SH
SH = (12.0, -7.0, 3.0)


def to_scan(p):
    return tuple(sum(RT[i][j] * p[j] for j in range(3)) + SH[i] for i in range(3))


def rot_error_deg(R):
    E = mm(R, RT)                                            # identity when R undoes RT
    return math.degrees(math.acos(max(-1.0, min(1.0, (E[0][0] + E[1][1] + E[2][2] - 1) / 2))))


def n_fit_features(part):
    return sum(1 for f in part.Features.GetFeatures() if f.FeatureType.startswith("Fit Surface"))


try:
    part = nxh.new_part(os.path.join(OUT, "re_truth4.prt"))
    truth = nxre.truth_bracket(part)
    cad_area = nxh.mass(part, [truth])["area"]
    nxre.stl_export(part, truth, os.path.join(OUT, "truth_bracket4.stl"))
    nxh.close_all()
    stl = os.path.join(OUT, "scan_unknown.stl")
    n_tri = nxre.make_scan(os.path.join(OUT, "truth_bracket4.stl"), stl, 1.5, SIGMA, transform=to_scan)[1]

    # ------------------------------------------------ 1. describe
    part = nxh.new_part(os.path.join(OUT, "re_unknown_part.prt"))
    scan = nxre.stl_import(part, stl)[0]
    scan.SetName("SCAN")
    res["describe"] = {"facets": scan.GetNumberOfFacets(), "solid": scan.IsSolidBody, "convergent": scan.IsConvergentBody,
                       "bbox": nxh.bbox(scan), "volume": nxh.volume(part, scan), "nx_area": nxh.mass(part, [scan])["area"]}
    chk("facets = STL triangles", scan.GetNumberOfFacets(), n_tri, 0.5)

    # ------------------------------------------------ 2. facet cache: full read against a thinned read
    t = time.time()
    sc_full = nxre.Scan(part, scan)
    t_full = time.time() - t
    t = time.time()
    sc = nxre.Scan(part, scan, every=4)
    t_thin = time.time() - t
    res["scan_cache"] = {"facets": len(sc_full.rows), "full_s": t_full, "full_ms_per_facet": 1000 * t_full / len(sc_full.rows),
                         "every4_rows": len(sc.rows), "every4_s": t_thin, "every4_ms_per_read": 1000 * t_thin / len(sc.rows)}
    chk("full cache holds every facet", len(sc_full.rows), n_tri, 0.5)
    chk("every=4 cache holds a quarter of the facets", len(sc.rows), math.ceil(n_tri / 4), 1.5)
    chk.true("every=4 cache costs about a quarter of the time", t_thin < 0.4 * t_full, res["scan_cache"])
    cen_full = nxre.census(sc_full)
    res["census_full"] = {"planes": len(cen_full["planes"]), "cylinders": len(cen_full["cylinders"]), "noise": cen_full["noise"],
                          "mesh_area": cen_full["mesh_area"]}
    del sc_full

    # ------------------------------------------------ 3. census of the unknown scan
    t = time.time()
    cen = nxre.census(sc)
    res["census_s"] = time.time() - t
    res["census"] = nxre.jsonable(cen)
    P, C = cen["planes"], cen["cylinders"]
    chk("census: number of planes", len(P), 9, 0.5)
    chk("census: noise estimate (true sigma 0.02)", cen["noise"], SIGMA, 0.006)
    chk("census: number of cylinders", len(C), 4, 0.5)
    chk.true("census: cylinder radii 10 / 5 / 4 / 4 and kinds", sorted((round(c["radius"], 1), c["kind"]) for c in C)
             == [(4.0, "hole"), (4.0, "hole"), (5.0, "hole"), (10.0, "boss")], [(c["radius"], c["kind"]) for c in C])
    true_area = [2299.47, 1665.31, 1521.46, 1201.46, 736.0, 736.0, 320.0, 320.0, 314.16]
    res["census_area_ratio"] = [round(p["area"] / a, 3) for p, a in zip(P, true_area)]
    chk.true("census (thinned cache): plane areas within 10 % of the true face areas", all(0.90 < r < 1.10 for r in res["census_area_ratio"]), res["census_area_ratio"])
    chk.true("census on the full cache finds the same 9 planes and 4 cylinders", res["census_full"]["planes"] == 9 and res["census_full"]["cylinders"] == 4, res["census_full"])
    res["area_caveat"] = {"mesh_area": res["census_full"]["mesh_area"], "nx_area": res["describe"]["nx_area"], "cad_area": cad_area,
                          "ratio": res["census_full"]["mesh_area"] / cad_area}
    chk.true("mesh area is larger than the CAD area on a noisy scan (never compare areas)", res["area_caveat"]["ratio"] > 1.01, res["area_caveat"])
    dt = cen["datums"]
    chk.true("census proposes three datum planes", bool(dt) and dt["tertiary"] is not None, dt)

    # ------------------------------------------------ 4. datum frame: census planes, then refined by Fit Surface (no features kept)
    al0 = nxre.alignment(P[dt["primary"]], P[dt["secondary"]], tertiary=P[dt["tertiary"]])
    n0 = n_fit_features(part)
    fitted = {k: nxre.measure_plane(part, P[dt[k]]["rows"]) for k in ("primary", "secondary", "tertiary")}
    chk("measure_plane leaves no Fit Surface feature", n_fit_features(part), n0, 0.5)
    al = nxre.alignment(fitted["primary"], fitted["secondary"], tertiary=fitted["tertiary"])
    res["alignment"] = {"census_only": {"rotation_error_deg": rot_error_deg(al0["R"]), "origin_error_mm": math.dist(al0["origin"], SH)},
                        "fitted": {"rotation_error_deg": rot_error_deg(al["R"]), "origin_error_mm": math.dist(al["origin"], SH),
                                   "axis": al["axis"], "angle_deg": al["angle_deg"], "origin": al["origin"],
                                   "squareness_error_deg": al["squareness_error_deg"],
                                   "plane_rms": {k: v["rms"] for k, v in fitted.items()}}}
    chk("alignment from the census alone: rotation error (deg)", res["alignment"]["census_only"]["rotation_error_deg"], 0.0, 0.02)
    chk("alignment from fitted datum planes: rotation error (deg)", res["alignment"]["fitted"]["rotation_error_deg"], 0.0, 0.02)
    chk("alignment from fitted datum planes: origin error (mm)", res["alignment"]["fitted"]["origin_error_mm"], 0.0, 0.01)
    chk.true("the alignment is a general rotation (axis not a principal axis)", max(abs(x) for x in al["axis"]) < 0.95, al["axis"])
    feats = nxre.apply_alignment(part, [scan], al)
    res["alignment"]["features"] = [f.FeatureType for f in feats]
    chk("apply_alignment: one rotation + one translation", len(feats), 2, 0.5)
    t = time.time()
    old = [(r[3][0], r[0]) for r in sc.rows[::200]]              # cached vertex + facet object before the move
    sc = nxre.Scan(part, scan, every=4)
    res["scan_cache"]["after_move_s"] = time.time() - t
    now = {r[0].FacetIdentifier: r[3][0] for r in sc.rows[::200]}
    worst = max(math.dist(nxre.transform_point(al, p), now[f.FacetIdentifier]) for p, f in old if f.FacetIdentifier in now)
    res["alignment"]["move_object_vs_transform_mm"] = worst
    chk("Move Object put the facets where x' = R (x - origin) predicts (worst of a sample)", worst, 0.0, 1e-6)
    bb = nxh.bbox(scan)
    res["alignment"]["bbox_after"] = bb
    chk("aligned scan bounding box vs 0,0,0 - 60,40,40 (worst side)", max(abs(bb[i] - v) for i, v in enumerate((0, 0, 0, 60, 40, 40))), 0.0, 0.12)

    # residual: the three datum faces against the absolute planes (the "no further Move Object" rule)
    cen = nxre.census(sc)
    P, C, dt = cen["planes"], cen["cylinders"], cen["datums"]
    resid = {}
    for k, ax in (("primary", (0, 0, -1)), ("secondary", (-1, 0, 0)), ("tertiary", (0, -1, 0))):
        mp = nxre.measure_plane(part, P[dt[k]]["rows"])
        resid[k] = {"offset_mm": mp["offset"], "tilt_deg": nxh.angle_deg(mp["normal"], ax), "rms": mp["rms"]}
    res["alignment"]["residual"] = resid
    chk("datum frame residual: worst plane offset (rule: <= 0.01 mm)", max(abs(v["offset_mm"]) for v in resid.values()), 0.0, 0.01)
    chk("datum frame residual: worst plane tilt (rule: <= 0.02 deg)", max(v["tilt_deg"] for v in resid.values()), 0.0, 0.02)

    # ------------------------------------------------ 5. fit-and-snap table straight from the census regions
    def principal(v):
        k = max(range(3), key=lambda i: abs(v[i]))
        return tuple(1.0 if i == k else 0.0 for i in range(3))
    regions = [{"name": "plane %d" % i, "kind": "plane", "rows": p["rows"], "axis": principal(p["normal"])} for i, p in enumerate(P)]
    regions += [{"name": "%s %d" % (c["kind"], i), "kind": "cylinder", "rows": c["rows"], "axis": principal(c["axis"])} for i, c in enumerate(C)]
    n0 = n_fit_features(part)
    t = time.time()
    table, values = nxre.fit_table(part, regions, grid=0.5, tol=0.05, keep=False)
    res["fit_table"] = table
    res["fit_table_s"] = time.time() - t
    chk("fit_table measure-only: Fit Surface features added", n_fit_features(part) - n0, 0, 0.5)
    chk.true("every table value snapped to the 0.5 mm grid within 0.05", all(r["snap_ok"] for r in table), [r for r in table if not r["snap_ok"]])
    chk("fit table: worst |fitted - snapped| (mm)", max(abs(r["fit_minus_snap"]) for r in table), 0.0, 0.02)
    planes_found = sorted((max(range(3), key=lambda i: abs(v["normal"][i])), v["position"]) for k, v in values.items() if "position" in v)
    chk.true("snapped plane positions = truth (x 0 8 60, y 0 40, z 0 8 18 40)",
             planes_found == [(0, 0.0), (0, 8.0), (0, 60.0), (1, 0.0), (1, 40.0), (2, 0.0), (2, 8.0), (2, 18.0), (2, 40.0)], planes_found)
    cyl_found = sorted((v["radius"], tuple(round(x, 3) for x in v["point"])) for v in values.values() if "radius" in v)
    chk.true("snapped cylinders = truth (R4 at 26,10 and 26,30; R5 at y20 z26; R10 at 44,20)",
             cyl_found == [(4.0, (26.0, 10.0, 0.0)), (4.0, (26.0, 30.0, 0.0)), (5.0, (0.0, 20.0, 26.0)), (10.0, (44.0, 20.0, 0.0))], cyl_found)
    chk("fit table: RMS about the snapped geometry = noise (worst row)", max(r["rms_snapped"] for r in table if "rms_snapped" in r), SIGMA, 0.012)
    _t2, _v2 = nxre.fit_table(part, regions[:2], keep=True)
    chk("fit_table keep=True leaves one named constrained fit per region", n_fit_features(part) - n0, 2, 0.5)

    # ------------------------------------------------ 6. rebuild (the snapped values are the truth dimensions) and compare
    body = nxre.truth_bracket(part)
    body.SetName("REBUILT")
    assert not body.IsConvergentBody
    pts = sc.vertices(n=1500)
    region_rows = {r["name"]: r["rows"] for r in regions}
    dev = nxre.signed_deviation(part, body, pts, threshold=3 * cen["noise"], regions=region_rows)
    res["deviation"] = dev
    chk("scan -> CAD: RMS = noise", dev["rms"], SIGMA, 0.006)
    chk("scan -> CAD: signed mean", dev["mean"], 0.0, 0.004)
    chk("scan -> CAD: |d| p95", dev["abs_p95"], 0.04, 0.012)
    chk.true("scan -> CAD: share over 3 x noise below 2 %", dev["share_over"] < 0.02, dev["share_over"])
    lim = 0.75 * cen["noise"]
    off = [k for k, v in dev["regions"].items() if abs(v["mean"]) > lim]
    chk.true("no region has a signed mean above 0.75 x noise", not off, {k: dev["regions"][k]["mean"] for k in off})
    res["volume"] = {"scan": nxh.volume(part, scan), "cad": nxh.volume(part, body), "rel": nxh.volume(part, scan) / nxh.volume(part, body) - 1}
    chk("scan volume vs CAD volume (relative)", res["volume"]["rel"], 0.0, 5e-4)
    # negative test: a CAD body 0.05 mm too high must flag exactly the faces normal to Z
    m = nxh.mark("offset test", False)
    nxf.move_object(part, [body], "delta", (0, 0, 0.05))
    bad = nxre.signed_deviation(part, body, pts, threshold=3 * cen["noise"], regions=region_rows)
    flagged = sorted(k for k, v in bad["regions"].items() if abs(v["mean"]) > lim)
    zplanes = sorted(r["name"] for r in regions if r["kind"] == "plane" and r["axis"] == (0.0, 0.0, 1.0))
    res["deviation_offset_test"] = {"flagged": flagged, "means": {k: v["mean"] for k, v in bad["regions"].items()},
                                    "abs_p95": bad["abs_p95"], "rms": bad["rms"]}
    nxh.undo_to(m)
    chk.true("0.05 mm Z offset of the CAD: the per-region signed mean flags exactly the four Z faces", flagged == zplanes, res["deviation_offset_test"])

    res["tree"] = [x["type"] for x in nxh.feature_table(part)]
    res["feature_errors"] = nxh.feature_errors(part)
    nxh.save(part)
    res.update(chk.report())
except Exception:
    res["error"] = traceback.format_exc()
    res["checks"] = chk.rows
    log(res["error"])
nxh.write_json(os.path.join(OUT, "re_unknown_part.json"), res)
