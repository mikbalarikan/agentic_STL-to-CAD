"""Section curves of a scan, Fit Curve (circle / line / spline) on section points, and the body operations
that work on a convergent body (Move Object, Extract Body, Scale, Split Body, Snip) - NX 2206, headless.

Truth: the L-bracket of nxre.truth_bracket (dia 8 holes at (26,10)/(26,30), dia 20 boss at (44,20)).
Scan: 2.5 mm triangles with 0.02 mm Gaussian noise.

run_journal.ps1 -Script re_sections_fitcurve.py -WorkDir <dir> -JArgs <out dir>  ->  re_sections_fitcurve.json
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
sys.path.insert(0, os.environ.get("NXRE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import NXOpen
import NXOpen.Facet
import NXOpen.Features
import nxh
import nxf
import nxre

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "re_sections_fitcurve.log"))
chk = nxh.Check()
res = {"result": "FAIL"}
NF = NXOpen.Features.Feature.Null
FC = NXOpen.Features.FitCurveBuilder


def curves(f):
    return [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)]


try:
    part = nxh.new_part(os.path.join(OUT, "re_truth2.prt"))
    body = nxre.truth_bracket(part)
    nxre.stl_export(part, body, os.path.join(OUT, "truth_bracket2.stl"))
    nxh.close_all()
    nxre.make_scan(os.path.join(OUT, "truth_bracket2.stl"), os.path.join(OUT, "scan_bracket2.stl"), 2.5, 0.02)

    part = nxh.new_part(os.path.join(OUT, "re_sections_fitcurve.prt"))
    cb = nxre.stl_import(part, os.path.join(OUT, "scan_bracket2.stl"))[0]
    sc = nxre.Scan(part, cb)

    # ------------------------------------------------ 1. Section Curve on the convergent body
    _f, dz4 = nxh.datum_plane(part, (0, 0, 4.3), (0, 0, 1), "DP_Z4")
    _f, dz14 = nxh.datum_plane(part, (0, 0, 14.3), (0, 0, 1), "DP_Z14")
    f4, c4 = nxre.section_curves(part, cb, dz4)
    f14, c14 = nxre.section_curves(part, cb, dz14)
    l4 = sorted(c.GetLength() for c in c4)
    l14 = sorted(c.GetLength() for c in c14)
    res["section_z4"] = {"type": f4.FeatureType, "classes": sorted({type(c).__name__ for c in c4}), "lengths": l4,
                         "truth": [8 * math.pi, 8 * math.pi, 200.0]}
    res["section_z14"] = {"lengths": l14, "truth": [20 * math.pi, 96.0]}
    chk.true("section z=4.3: 3 loops (outline + 2 holes), each ONE spline", len(c4) == 3 and all(isinstance(c, NXOpen.Spline) for c in c4), res["section_z4"])
    chk.true("section z=14.3: 2 loops (boss + wall)", len(c14) == 2, res["section_z14"])
    chk("outline length is inflated by the noise, within 2 %", l4[2] / 200.0, 1.0, 0.02)
    chk.true("raw section length is LONGER than the true one (zig-zag): never dimension from it", l4[2] > 200.0 and l4[0] > 8 * math.pi)

    def inter():
        b = part.Features.CreateIntersectionCurveBuilder(NF)
        try:
            b.Tolerance = 0.01
            b.FirstFace.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(cb)], False)
            b.SecondFace.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDatum([dz4])], False)
            b.Associative = True
            f = b.Commit()
        finally:
            b.Destroy()
        cs = curves(f)
        return {"type": f.FeatureType, "n": len(cs), "total": sum(c.GetLength() for c in cs)}
    v, e = nxh.attempt("intersection", inter, log=log)
    res["intersection_z4"] = v or {"error": e}
    chk.true("Intersection Curve works on the scan too but returns many pieces", bool(v) and v["n"] > 3, res["intersection_z4"])

    # ------------------------------------------------ 2. Fit Curve on points of the section
    def circ(name, z, centre, rad, pred=None, **kw):
        pts = [p for p in sc.slice(2, z) if abs(math.hypot(p[0] - centre[0], p[1] - centre[1]) - rad) < 0.3 and (pred is None or pred(p))]
        f = nxre.fit_curve(part, nxre.points(part, pts, 130), "circle", **kw)
        arc = [c for c in curves(f) if isinstance(c, NXOpen.Arc)][0]
        row = {"type": f.FeatureType, "n_points": min(len(pts), 130), "radius": arc.Radius, "radius_err": arc.Radius - rad,
               "centre_err": math.hypot(arc.CenterPoint.X - centre[0], arc.CenterPoint.Y - centre[1]),
               "sweep_deg": math.degrees(arc.EndAngle - arc.StartAngle), "exprs": [(x.Name, x.RightHandSide) for x in f.GetExpressions()]}
        res[name] = row
        return row

    r = circ("fitcircle_hole1", 4.3, (26, 10), 4.0, reject=0.07)
    chk("fit circle hole: radius error", r["radius_err"], 0.0, 0.02)
    chk("fit circle hole: centre error", r["centre_err"], 0.0, 0.02)
    r = circ("fitcircle_hole1_R4", 4.3, (26, 10), 4.0, reject=0.07, radius=4)
    chk("fit circle with HasRadius: radius exactly 4", r["radius"], 4.0, 1e-9)
    chk("fit circle with HasRadius: centre error", r["centre_err"], 0.0, 0.02)
    r = circ("fitcircle_boss", 14.3, (44, 20), 10.0, reject=0.07)
    chk("fit circle boss: radius error", r["radius_err"], 0.0, 0.02)
    chk("fit circle boss: full circle", r["sweep_deg"], 360.0, 1e-6)
    r = circ("fitarc_boss_150deg", 14.3, (44, 20), 10.0, pred=lambda p: p[0] > 46.5, reject=0.07, closed=False)
    chk("fit arc on a 150 deg segment: radius error", r["radius_err"], 0.0, 0.03)
    chk.true("open arc (IsClosedCurve False) is not a full circle", r["sweep_deg"] < 200.0, r["sweep_deg"])

    pts = [p for p in sc.slice(2, 4.3) if abs(p[1]) < 0.3 and 2 < p[0] < 58]
    f = nxre.fit_curve(part, nxre.points(part, pts, 150), "line", reject=0.1)
    ln = [c for c in curves(f) if isinstance(c, NXOpen.Line)][0]
    a, b = ln.StartPoint, ln.EndPoint
    res["fitline_y0"] = {"start": [a.X, a.Y, a.Z], "end": [b.X, b.Y, b.Z],
                         "angle_deg": math.degrees(math.atan2(abs(b.Y - a.Y), abs(b.X - a.X))), "offset": (a.Y + b.Y) / 2}
    chk("fit line on the y=0 side: direction error (deg)", res["fitline_y0"]["angle_deg"], 0.0, 0.05)
    chk("fit line on the y=0 side: offset", res["fitline_y0"]["offset"], 0.0, 0.02)
    pts = [p for p in sc.slice(2, 14.3) if abs(math.hypot(p[0] - 44, p[1] - 20) - 10) < 0.3 and p[0] > 46 and p[1] > 20]
    pts.sort(key=lambda p: math.atan2(p[1] - 20, p[0] - 44))
    f = nxre.fit_curve(part, nxre.points(part, pts, 100), "spline")
    spl = curves(f)[0]
    res["fitspline"] = {"class": type(spl).__name__, "length": spl.GetLength()}
    chk.true("fit spline returns a Spline", isinstance(spl, NXOpen.Spline), res["fitspline"])

    # targets other than points do not work in batch
    def bad_target(kind):
        b = part.Features.CreateFitCurveBuilder(NXOpen.Features.FitCurve.Null)
        try:
            b.Type = FC.Types.FitCircle
            b.TargetSourceType = getattr(FC.TargetSourceTypes, kind)
            b.Target.Add(min(c4, key=lambda c: c.GetLength()) if kind == "Curve" else cb)
            return b.CommitFeature().FeatureType
        finally:
            b.Destroy()
    res["fitcurve_other_targets"] = {}
    for kind in ("Curve", "FacetBody"):
        v, e = nxh.attempt("target " + kind, bad_target, kind, log=log)
        res["fitcurve_other_targets"][kind] = v or e
    chk.true("Fit Curve with a curve / facet-body target fails headless (use points)",
             all("insufficient" in str(x) for x in res["fitcurve_other_targets"].values()), res["fitcurve_other_targets"])

    # ------------------------------------------------ 3. the fitted circle drives a feature: extrude it as a hole tool
    pts = [p for p in sc.slice(2, 4.3) if abs(math.hypot(p[0] - 26, p[1] - 30) - 4) < 0.3]
    fcirc = nxre.fit_curve(part, nxre.points(part, pts, 130), "circle", reject=0.07, radius=4)
    sec = nxh.section_feature(part, [fcirc], help_point=(30, 30, 4.3))
    fx = nxh.extrude(part, sec, (0, 0, 1), -4.3, 3.7)
    pin = fx.GetBodies()[0]
    res["extrude_of_fit_circle"] = {"solid": pin.IsSolidBody, "volume": nxh.volume(part, pin), "truth": math.pi * 16 * 8}
    chk("extrude of the fitted R4 circle (pin volume)", nxh.volume(part, pin), math.pi * 16 * 8, 0.01)

    # ------------------------------------------------ 4. operations on the convergent body
    ops = res.setdefault("convergent_ops", {})
    bb0 = nxh.bbox(cb)
    f = nxf.move_object(part, [cb], "delta", (100, 0, 0))
    bb1 = nxh.bbox(cb)
    ops["move_delta"] = {"type": f.FeatureType, "dx": bb1[0] - bb0[0], "facets": cb.GetNumberOfFacets()}
    chk("Move Object (delta) on the scan: x shift", bb1[0] - bb0[0], 100.0, 1e-3)
    f = nxf.move_object(part, [cb], "angle", 90, vec=(0, 0, 1), origin=(100, 0, 0))
    bb2 = nxh.bbox(cb)
    ops["move_angle"] = {"bbox": bb2}
    chk("Move Object (angle 90 about Z) on the scan: x extent becomes the old y extent", bb2[3] - bb2[0], bb0[4] - bb0[1], 0.01)
    fe, nb = nxf.extract_body(part, [cb])
    ops["extract_body"] = {"type": fe.FeatureType, "convergent": nb[0].IsConvergentBody, "facets": nb[0].GetNumberOfFacets()}
    chk.true("Extract Body gives a convergent copy", nb[0].IsConvergentBody and nb[0].GetNumberOfFacets() == cb.GetNumberOfFacets(), ops["extract_body"])
    copy = nb[0]
    v0 = nxh.volume(part, copy)
    nxf.scale_body(part, [copy], 2)
    ops["scale"] = {"volume_ratio": nxh.volume(part, copy) / v0}
    chk("Scale Body x2 on the convergent copy: volume ratio", ops["scale"]["volume_ratio"], 8.0, 1e-3)
    copy2 = nxf.extract_body(part, [cb])[1][0]

    # cut the scan at a plane: Trim Body works and leaves an exact planar cap on the mesh
    bbm = nxh.bbox(cb)
    xcut = (bbm[0] + bbm[3]) / 2
    _f, dpt = nxh.datum_plane(part, (xcut, 0, 0), (1, 0, 0), "DP_TRIM")
    v0 = nxh.volume(part, cb)
    ft, _rev = nxf.trim_body(part, cb, datum_plane=dpt)
    types = sorted(nxh.face_data(x)[0] for x in cb.GetFaces())
    bbt = nxh.bbox(cb)
    ops["trim_body_datum_plane"] = {"type": ft.FeatureType, "v0": v0, "v1": nxh.volume(part, cb), "face_types": types, "bbox": bbt,
                                    "solid": cb.IsSolidBody}
    chk.true("Trim Body (datum plane) on the scan: facet face + exact planar cap(s), still solid",
             types.count(67) == 1 and types.count(nxh.PLANE) == len(types) - 1 >= 1 and cb.IsSolidBody, ops["trim_body_datum_plane"])
    chk.true("Trim Body on the scan: one bounding-box side now sits on the plane", min(abs(bbt[0] - xcut), abs(bbt[3] - xcut)) < 0.01, bbt)
    chk.true("Trim Body on the scan removed material", 0.2 * v0 < nxh.volume(part, cb) < 0.8 * v0)
    try:
        ops["facet_count_after_trim"] = cb.GetNumberOfFacets()
    except Exception as e:  # noqa: BLE001
        ops["facet_count_after_trim"] = str(e)       # body-level facet calls fail on the mixed body: use the facet face

    # Split Body (the user's way to cut a scan in two) on a second convergent copy
    def split():
        bbc = nxh.bbox(copy2)
        _f, dps = nxh.datum_plane(part, ((bbc[0] + bbc[3]) / 2 + 0.37, 0, 0), (1, 0, 0), "DP_SPLIT")
        vc = nxh.volume(part, copy2)
        fs, pieces = nxf.split_body(part, [copy2], datum_plane=dps)
        return {"type": fs.FeatureType, "pieces": len(pieces), "convergent": [p.IsConvergentBody for p in pieces],
                "volume_sum_ratio": sum(nxh.volume(part, p) for p in pieces) / vc}
    v, e = nxh.attempt("split body", split, log=log)
    ops["split_body_datum_plane"] = v or {"error": e}
    chk.true("Split Body (datum plane) on a convergent body: 2 pieces", bool(v) and v["pieces"] == 2, ops["split_body_datum_plane"])
    chk("Split Body: the two pieces add up to the original volume", (v or {}).get("volume_sum_ratio"), 1.0, 1e-3)

    def snip():
        target = [b_ for b_ in part.Bodies if b_.IsConvergentBody][-1]
        bb_ = nxh.bbox(target)
        b = part.FacetedBodies.CreateSnipFacetBodyBuilder()
        try:
            b.Type = NXOpen.Facet.SnipFacetBodyBuilder.Types.SnipAtPlane
            b.Bodies.Add(target)
            b.Plane = part.Planes.CreatePlane(nxh.P(0, 0, (bb_[2] + bb_[5]) / 2), nxh.V(0, 0, 1), nxh.UPD)
            b.IsEditCopy = False
            b.Commit()
        finally:
            b.Destroy()
        return {"bbox_before": bb_, "bbox_after": nxh.bbox(target)}
    v, e = nxh.attempt("snip", snip, log=log)
    ops["snip_at_plane"] = v or {"error": e}            # recorded only: no effect / not relied upon

    res["features"] = [(x["name"], x["type"]) for x in nxh.feature_table(part)]
    res["feature_errors"] = nxh.feature_errors(part)
    nxh.save(part)
    res.update(chk.report())
except Exception:
    res["error"] = traceback.format_exc()
    res["checks"] = chk.rows
    log(res["error"])
nxh.write_json(os.path.join(OUT, "re_sections_fitcurve.json"), res)
