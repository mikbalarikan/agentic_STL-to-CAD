"""Scan -> aligned scan -> fitted primitives -> snapped parametric solid -> deviation check (NX 2206, headless).

The scan is the L-bracket of nxre.truth_bracket, meshed at 2.5 mm with 0.02 mm noise and deliberately
rotated 17 deg about Z and shifted (12, -7, 3). The journal
  1. aligns the scan with Fit Surface planes + two Move Object features,
  2. fits 9 planes and 4 cylinders, reads their parameters and snaps them to the 0.5 mm design grid,
  3. rebuilds the part with ordinary features driven by named expressions (raw and snapped values),
  4. compares the rebuilt solid with the truth (volume) and with the scan (max / RMS distance of facet
     vertices to the CAD faces), and shows that a wrong snap is caught by the deviation check,
  5. repeats the base slab by the two surface routes of the user's parts: Replace Face onto fitted planes,
     and Extend Sheet + Trim Sheet (by datum planes on the fits) + Sew of six fitted sheets into a solid.

run_journal.ps1 -Script re_rebuild_compare.py -WorkDir <dir> -JArgs <out dir>  ->  re_rebuild_compare.json
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
sys.path.insert(0, os.environ.get("NXRE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import NXOpen
import NXOpen.Features
import nxh
import nxf
import nxre

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "re_rebuild_compare.log"))
chk = nxh.Check()
res = {"result": "FAIL"}
NF = NXOpen.Features.Feature.Null
SIGMA = 0.02
TH = math.radians(17.0)
SHIFT = (12.0, -7.0, 3.0)


def to_scan(p):
    return (p[0] * math.cos(TH) - p[1] * math.sin(TH) + SHIFT[0], p[0] * math.sin(TH) + p[1] * math.cos(TH) + SHIFT[1], p[2] + SHIFT[2])


def to_cad(p):
    x, y = p[0] - SHIFT[0], p[1] - SHIFT[1]
    return (x * math.cos(TH) + y * math.sin(TH), -x * math.sin(TH) + y * math.cos(TH), p[2] - SHIFT[2])


def angle(u, v):
    a = nxh.angle_deg(u, v)
    return min(a, 180.0 - a)


def plane_fit(part, rows, **kw):
    f = nxre.fit_surface(part, [nxre.rule_facets(part, rows)], "plane", **kw)
    face, d = nxre.fit_face(f, nxh.PLANE)
    return f, face, d


try:
    part = nxh.new_part(os.path.join(OUT, "re_truth3.prt"))
    nxre.stl_export(part, nxre.truth_bracket(part), os.path.join(OUT, "truth_bracket3.stl"))
    nxh.close_all()
    nxre.make_scan(os.path.join(OUT, "truth_bracket3.stl"), os.path.join(OUT, "scan_bracket3.stl"), 2.5, SIGMA, transform=to_scan)

    part = nxh.new_part(os.path.join(OUT, "re_rebuild_compare.prt"))
    cb = nxre.stl_import(part, os.path.join(OUT, "scan_bracket3.stl"))[0]
    cb.SetName("SCAN")

    # ------------------------------------------------ 1. align: plane fits -> rotate -> plane fits -> translate
    sc = nxre.Scan(part, cb)
    reg = nxre.bracket_regions(sc, to_cad)            # a person picks these regions by eye on the tilted scan
    _f, _face, d_wall = plane_fit(part, reg["wall_out"])
    n = d_wall["dir"]
    if n[0] > 0:
        n = [-x for x in n]                           # outward normal of the wall's outer face must become -X
    theta = math.degrees(math.atan2(-n[1], -n[0]))
    res["align"] = {"fitted_rotation_deg": theta, "true_rotation_deg": 17.0}
    chk("alignment: rotation found from the fitted wall plane (deg)", theta, 17.0, 0.03)
    nxf.move_object(part, [cb], "angle", -theta, vec=(0, 0, 1), origin=(0, 0, 0))
    sc = nxre.Scan(part, cb)
    bb = nxh.bbox(cb)
    rough = lambda p: (p[0] - bb[0], p[1] - bb[1], p[2] - bb[2])     # bounding-box corner = rough origin
    reg = nxre.bracket_regions(sc, rough)
    dx = plane_fit(part, reg["wall_out"])[2]["pt"][0]
    dy = plane_fit(part, reg["y0"])[2]["pt"][1]
    dz = plane_fit(part, reg["bottom"])[2]["pt"][2]
    nxf.move_object(part, [cb], "delta", (-dx, -dy, -dz))
    res["align"]["translation"] = [dx, dy, dz]
    sc = nxre.Scan(part, cb)
    reg = nxre.bracket_regions(sc)
    worst = 0.0
    for name, p0, n0 in (("wall_out", (0, 0, 0), (-1, 0, 0)), ("y0", (0, 0, 0), (0, -1, 0)), ("bottom", (0, 0, 0), (0, 0, -1))):
        _f, _face, d = plane_fit(part, reg[name])
        off = sum((d["pt"][i] - p0[i]) * n0[i] for i in range(3))
        res["align"][name] = {"offset_mm": off, "angle_deg": angle(d["dir"], n0)}
        worst = max(worst, abs(off))
        chk("aligned scan: %s plane angle to the datum (deg)" % name, angle(d["dir"], n0), 0.0, 0.03)
    chk("aligned scan: worst datum-face offset (mm)", worst, 0.0, 0.01)
    res["align"]["features"] = [x["type"] for x in nxh.feature_table(part) if x["type"] == "MOVE_OBJECT"]

    # ------------------------------------------------ 2. fit every primitive, read and snap its parameters
    raw, fits = {}, {}
    for key, name, ax in (("x_out", "wall_out", 0), ("x_in", "wall_in", 0), ("x_end", "x60", 0), ("y_a", "y0", 1), ("y_b", "y40", 1),
                          ("z_bot", "bottom", 2), ("z_top", "base_top", 2), ("z_wall", "wall_top", 2), ("z_boss", "boss_top", 2)):
        axis = tuple(1.0 if i == ax else 0.0 for i in range(3))
        f, face, d = plane_fit(part, reg[name], axis=axis, reject=0.1)      # design intent: faces square to the datums
        raw[key] = d["pt"][ax]
        fits[name] = (f, face, d)
    for key, name, axis in (("boss", "boss", (0, 0, 1)), ("hole1", "hole1", (0, 0, 1)), ("hole2", "hole2", (0, 0, 1)), ("wall_hole", "wall_hole", (1, 0, 0))):
        f = nxre.fit_surface(part, [nxre.rule_facets(part, reg[name])], "cylinder", reject=0.1, axis=axis)
        face, d = nxre.fit_face(f, nxh.CYLINDER)
        raw[key + "_r"] = d["radius"]
        if axis[2]:
            raw[key + "_x"], raw[key + "_y"] = d["pt"][0], d["pt"][1]
        else:
            raw[key + "_y"], raw[key + "_z"] = d["pt"][1], d["pt"][2]
    snapped = {k: nxre.snap(v, 0.5, 0.05) for k, v in raw.items()}
    res["parameters"] = {k: {"fitted": raw[k], "snapped": snapped[k][0], "snapped_ok": snapped[k][1]} for k in sorted(raw)}
    truth = {"x_out": 0, "x_in": 8, "x_end": 60, "y_a": 0, "y_b": 40, "z_bot": 0, "z_top": 8, "z_wall": 40, "z_boss": 18,
             "boss_r": 10, "boss_x": 44, "boss_y": 20, "hole1_r": 4, "hole1_x": 26, "hole1_y": 10, "hole2_r": 4, "hole2_x": 26,
             "hole2_y": 30, "wall_hole_r": 5, "wall_hole_y": 20, "wall_hole_z": 26}
    chk("worst fitted parameter error before snapping (mm)", max(abs(raw[k] - truth[k]) for k in truth), 0.0, 0.03)
    chk.true("every parameter snaps to the 0.5 mm grid", all(v[1] for v in snapped.values()), {k: v for k, v in snapped.items() if not v[1]})
    chk("worst parameter error after snapping (mm)", max(abs(snapped[k][0] - truth[k]) for k in truth), 0.0, 1e-9)

    # ------------------------------------------------ 3. rebuild with ordinary features
    def build(p, prefix):
        E = lambda name, val: nxh.expr(part, prefix + name, round(val, 6), "mm").Name
        ln, wd = E("length", p["x_end"] - p["x_out"]), E("width", p["y_b"] - p["y_a"])
        tb, tw = E("base_t", p["z_top"] - p["z_bot"]), E("wall_t", p["x_in"] - p["x_out"])
        ht, bh = E("height", p["z_wall"] - p["z_bot"]), E("boss_h", p["z_boss"] - p["z_top"])
        bd, hd, whd = E("boss_d", 2 * p["boss_r"]), E("hole_d", p["hole1_r"] + p["hole2_r"]), E("wall_hole_d", 2 * p["wall_hole_r"])
        org = (p["x_out"], p["y_a"], p["z_bot"])
        _f, body = nxh.block(part, org, (ln, wd, tb))
        _f, wall = nxh.block(part, org, (tw, wd, ht))
        nxh.unite(part, body, [wall])
        nxh.cylinder(part, (p["boss_x"], p["boss_y"], p["z_top"]), (0, 0, 1), bd, bh, nxh.BOOL.Unite, body)
        for h in ("hole1", "hole2"):
            nxh.cylinder(part, (p[h + "_x"], p[h + "_y"], p["z_bot"]), (0, 0, 1), hd, tb, nxh.BOOL.Subtract, body)
        nxh.cylinder(part, (p["x_out"], p["wall_hole_y"], p["wall_hole_z"]), (1, 0, 0), whd, tw, nxh.BOOL.Subtract, body)
        return body

    pts = sc.vertices(n=700)
    V0 = nxre.BRACKET["volume"]
    m = nxh.mark("raw build", False)
    body = build(raw, "raw_")
    res["rebuild_raw"] = {"volume": nxh.volume(part, body), "volume_err_rel": nxh.volume(part, body) / V0 - 1.0,
                          "scan_dev": nxre.deviation(part, body.GetFaces(), pts)}
    nxh.undo_to(m)
    m = nxh.mark("wrong snap", False)
    wrong = {k: v[0] for k, v in snapped.items()}
    wrong["boss_r"] = 10.5                            # a careless rounding
    body = build(wrong, "bad_")
    res["rebuild_wrong_snap"] = {"scan_dev": nxre.deviation(part, body.GetFaces(), pts)}
    nxh.undo_to(m)
    good = {k: v[0] for k, v in snapped.items()}
    body = build(good, "re_")
    body.SetName("REBUILT")
    inside = nxh.dist_to(part, body, (50.0, 5.0, 7.0))                 # 1 mm below the base top, inside the solid
    outside = nxh.dist_to(part, body, (50.0, 5.0, 9.0))                # 1 mm above it
    res["rebuild_snapped"] = {"volume": nxh.volume(part, body), "volume_err_rel": nxh.volume(part, body) / V0 - 1.0,
                              "scan_dev": nxre.deviation(part, body.GetFaces(), pts), "census": nxh.face_census(body),
                              "signed_dev": nxre.signed_deviation(part, body, pts),
                              "point_1mm_inside": inside, "point_1mm_outside": outside, "body_ok": nxh.body_ok(part, body),
                              "convergent_volume": nxh.volume(part, cb)}
    chk("rebuilt (raw values) volume vs truth, relative", res["rebuild_raw"]["volume_err_rel"], 0.0, 2e-3)
    chk("rebuilt (snapped) volume vs truth", res["rebuild_snapped"]["volume"], V0, 1e-3)
    chk("scan -> rebuilt CAD: RMS deviation = scan noise", res["rebuild_snapped"]["scan_dev"]["rms"], SIGMA, 0.015)
    chk("scan -> rebuilt CAD: max deviation", res["rebuild_snapped"]["scan_dev"]["max"], 0.0, 0.12)
    chk.true("a wrong snap (boss R 10.5) is caught: max deviation ~0.5", res["rebuild_wrong_snap"]["scan_dev"]["max"] > 0.4,
             res["rebuild_wrong_snap"])
    chk("point-to-SOLID distance is signed: 1 mm inside", inside, -1.0, 1e-6)
    chk("point-to-SOLID distance is signed: 1 mm outside", outside, 1.0, 1e-6)
    chk("signed deviation scan -> CAD: mean (no bias)", res["rebuild_snapped"]["signed_dev"]["mean"], 0.0, 0.005)
    chk.true("rebuilt body passes Examine Geometry", res["rebuild_snapped"]["body_ok"])
    # the result is parametric
    nxh.set_expr(part, "re_boss_d", 24)
    nxh.update()
    chk("parametric: boss_d 20 -> 24 changes the volume by pi*(144-100)*10", nxh.volume(part, body) - V0, math.pi * 44 * 10, 1e-3)
    nxh.set_expr(part, "re_boss_d", 20)
    nxh.update()
    chk("parametric: back to nominal", nxh.volume(part, body), V0, 1e-3)

    # ------------------------------------------------ 4. surface route A: rough solid + Replace Face onto the fitted planes
    slab = {"bottom": (2, 0.0, (0, 0, -1)), "base_top": (2, 8.0, (0, 0, 1)), "y0": (1, 0.0, (0, -1, 0)), "y40": (1, 40.0, (0, 1, 0)),
            "x60": (0, 60.0, (1, 0, 0)), "wall_out": (0, 0.0, (-1, 0, 0))}

    def route_replace():
        _f, blk = nxh.block(part, (-1.5 + 200, -1.5, -1.5), (63, 43, 11))      # oversize blank, built 200 mm aside
        nxf.move_object(part, [blk], "delta", (-200, 0, 0))                     # ... then moved over the scan
        used = {}
        for name, (ax, val, nrm) in slab.items():
            face = [x for x in blk.GetFaces() if nxh.face_data(x)[0] == nxh.PLANE and angle(nxh.face_data(x)[2], nrm) < 1
                    and sum(nxh.face_data(x)[2][i] * nrm[i] for i in range(3)) > 0][0]
            target = fits[name][1]
            done = None
            for rev in (False, True):
                mk = nxh.mark("replace", False)
                b = part.Features.CreateReplaceFaceBuilder(NF)
                try:
                    b.FaceToReplace.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb([face])], False)
                    b.ReplacementFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb([target])], False)
                    b.ReverseDirection = rev
                    b.CommitFeature()
                    done = rev
                except Exception as e:  # noqa: BLE001
                    used[name] = str(e)
                finally:
                    b.Destroy()
                if done is not None:
                    break
                nxh.undo_to(mk)
            used[name] = {"reverse": done}
        bbx = nxh.bbox(blk)
        return {"flags": used, "bbox": bbx, "volume": nxh.volume(part, blk)}
    v, e = nxh.attempt("replace face route", route_replace, log=log)
    res["route_replace_face"] = v or {"error": e}
    chk("Replace Face route: slab volume 60x40x8", (v or {}).get("volume"), 19200.0, 20.0)
    if v:
        chk("Replace Face route: worst bounding-box error (mm)", max(abs(v["bbox"][i] - t) for i, t in enumerate((0, 0, 0, 60, 40, 8))), 0.0, 0.02)

    # ------------------------------------------------ 5. surface route B: fit -> Extend Sheet -> Trim Sheet -> Sew
    def route_sheets():
        sheets = {}
        for name, (ax, val, nrm) in slab.items():
            f, face, d = plane_fit(part, reg[name], axis=nrm, reject=0.1)
            sb = f.GetBodies()[0]
            _fd, dp = nxf.datum_plane(part, "offset", [face], 0)           # the user's Fit Surface -> Datum Plane (offset 0)
            nxf.extend_sheet(part, list(sb.GetEdges()), 12)                # overshoot: the sheet must cross its neighbours
            sheets[name] = (sb, ax, d["pt"][ax], dp)
        centre = (30.0, 20.0, 4.0)
        for name, (sb, ax, val, _dp) in sheets.items():
            keep = tuple(val if i == ax else centre[i] for i in range(3))  # a point ON this sheet, inside the slab face
            for other, (_ob, oax, _oval, odp) in sheets.items():
                if oax != ax:
                    log("trim", name, "by", other)
                    nxf.trim_sheet(part, sb, keep, keep=True, datum_plane=odp)
        names = list(sheets)
        out = nxf.sew(part, sheets[names[0]][0], [sheets[k][0] for k in names[1:]], tol=0.01)
        return {"solid": out.IsSolidBody, "free_edges": len(nxh.free_edges(out)), "faces": len(out.GetFaces()),
                "volume": nxh.volume(part, out) if out.IsSolidBody else None, "bbox": nxh.bbox(out)}
    v, e = nxh.attempt("sheet route", route_sheets, log=log)
    res["route_extend_trim_sew"] = v or {"error": e}
    chk.true("Extend + Trim + Sew of six fitted planes gives a closed solid", bool(v) and v["solid"] and v["free_edges"] == 0, res["route_extend_trim_sew"])
    chk("sheet route: slab volume 60x40x8", (v or {}).get("volume"), 19200.0, 20.0)

    res["analysis_manager_deviation_api"] = [n_ for n_ in dir(part.AnalysisManager) if "eviation" in n_]
    res["feature_errors"] = nxh.feature_errors(part)
    res["tree"] = [x["type"] for x in nxh.feature_table(part)]
    nxh.save(part)
    res.update(chk.report())
except Exception:
    res["error"] = traceback.format_exc()
    res["checks"] = chk.rows
    log(res["error"])
nxh.write_json(os.path.join(OUT, "re_rebuild_compare.json"), res)
