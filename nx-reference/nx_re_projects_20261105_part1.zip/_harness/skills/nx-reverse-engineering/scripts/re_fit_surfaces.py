"""Fit Surface on facet regions of an STL scan with known truth (NX 2206, headless).

Builds an L-bracket and a primitives body in NX, exports STL, turns the STL into a scan-like mesh
(2.5 mm triangles, 0.02 mm Gaussian noise), imports it as a convergent body and fits plane / cylinder /
cone / sphere / freeform surfaces on facet regions. Every fit is compared with the true face.

run_journal.ps1 -Script re_fit_surfaces.py -WorkDir <dir> -JArgs <out dir>   ->  <out dir>\\re_fit_surfaces.json
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
sys.path.insert(0, os.environ.get("NXRE_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import NXOpen
import NXOpen.Features
import nxh
import nxre

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "re_fit_surfaces.log"))
chk = nxh.Check()
res = {"result": "FAIL", "fits": {}}
UFS = nxh.UFS
SIGMA = 0.02


def angle(u, v):
    a = nxh.angle_deg(u, v)
    return min(a, 180.0 - a)


def cone(part, origin, d0, d1, h, target):
    b = part.Features.CreateConeBuilder(NXOpen.Features.Cone.Null)
    try:
        b.Type = NXOpen.Features.ConeBuilder.Types.DiametersAndHeight
        b.Axis = nxh.axis(part, origin, (0, 0, 1))
        b.BaseDiameter.RightHandSide = str(d0)
        b.TopDiameter.RightHandSide = str(d1)
        b.Height.RightHandSide = str(h)
        b.BooleanOption.Type = nxh.BOOL.Unite
        b.BooleanOption.SetTargetBodies([target])
        return b.CommitFeature()
    finally:
        b.Destroy()


def sphere(part, centre, d, op, target):
    b = part.Features.CreateSphereBuilder(NXOpen.Features.Sphere.Null)
    try:
        b.Type = NXOpen.Features.SphereBuilder.Types.CenterPointAndDiameter
        b.CenterPoint = nxh.point(part, *centre)
        b.Diameter.RightHandSide = str(d)
        b.BooleanOption.Type = op
        b.BooleanOption.SetTargetBodies([target])
        return b.CommitFeature()
    finally:
        b.Destroy()


try:
    # ------------------------------------------------ 1. truth solids -> STL -> scan-like meshes
    part = nxh.new_part(os.path.join(OUT, "re_truth.prt"))
    bracket = nxre.truth_bracket(part)
    _f, prim = nxh.block(part, (100, 0, 0), (90, 40, 10))
    cone(part, (120, 20, 10), 20, 10, 12, prim)                      # half angle atan(5/12) = 22.620 deg
    sphere(part, (160, 20, 10), 24, nxh.BOOL.Unite, prim)            # R12 dome
    _f, crown = nxh.block(part, (0, 60, 0), (60, 40, 30))
    sphere(part, (30, 80, -75), 200, nxh.BOOL.Intersect, crown)      # top face = R100 sphere patch
    sol = {("bracket" if nxh.bbox(b)[3] < 70 and nxh.bbox(b)[1] < 30 else "crown" if nxh.bbox(b)[1] > 30 else "prim"): b
           for b in nxh.solids(part)}
    chk("truth bracket volume", nxh.volume(part, sol["bracket"]), nxre.BRACKET["volume"], 1e-3)
    for name, body in sol.items():
        size, nerr = nxre.stl_export(part, body, os.path.join(OUT, "truth_%s.stl" % name))
        res.setdefault("stl_export", {})[name] = {"bytes": size, "errors": nerr}
    nxh.save(part)
    nxh.close_all()
    n_tri = {}
    n_tri["bracket"] = nxre.make_scan(os.path.join(OUT, "truth_bracket.stl"), os.path.join(OUT, "scan_bracket.stl"), 2.5, SIGMA)[1]
    n_tri["clean"] = nxre.make_scan(os.path.join(OUT, "truth_bracket.stl"), os.path.join(OUT, "scan_bracket_clean.stl"), 2.5, 0.0)[1]
    n_tri["prim"] = nxre.make_scan(os.path.join(OUT, "truth_prim.stl"), os.path.join(OUT, "scan_prim.stl"), 2.0, SIGMA)[1]
    n_tri["crown"] = nxre.make_scan(os.path.join(OUT, "truth_crown.stl"), os.path.join(OUT, "scan_crown.stl"), 2.0, SIGMA)[1]
    res["scan_triangles"] = n_tri

    # ------------------------------------------------ 2. import: convergent body
    part = nxh.new_part(os.path.join(OUT, "re_fit_surfaces.prt"))
    cb = nxre.stl_import(part, os.path.join(OUT, "scan_bracket.stl"))[0]
    face0 = cb.GetFaces()[0]
    res["import"] = {"convergent": cb.IsConvergentBody, "solid": cb.IsSolidBody, "faces": len(cb.GetFaces()),
                     "edges": len(cb.GetEdges()), "facets": cb.GetNumberOfFacets(), "face_type": nxh.face_data(face0)[0],
                     "volume": nxh.volume(part, cb), "feature": nxh.feature_table(part)[-1]}
    chk.true("import gives one convergent solid body with a single facet face",
             cb.IsConvergentBody and cb.IsSolidBody and len(cb.GetFaces()) == 1 and nxh.face_data(face0)[0] == 67, res["import"])
    chk("facet count = STL triangles", cb.GetNumberOfFacets(), n_tri["bracket"], 0.5)
    chk("convergent body volume vs truth (relative)", nxh.volume(part, cb) / nxre.BRACKET["volume"], 1.0, 5e-4)
    sc = nxre.Scan(part, cb)
    reg = nxre.bracket_regions(sc)
    res["region_facets"] = {k: len(v) for k, v in reg.items()}

    # ------------------------------------------------ 3. planes
    planes = {"base_top": ((0, 0, 8), (0, 0, 1)), "bottom": ((0, 0, 0), (0, 0, -1)), "wall_in": ((8, 0, 0), (1, 0, 0)),
              "wall_out": ((0, 0, 0), (-1, 0, 0)), "wall_top": ((0, 0, 40), (0, 0, 1)), "y0": ((0, 0, 0), (0, -1, 0)),
              "y40": ((0, 40, 0), (0, 1, 0)), "x60": ((60, 0, 0), (1, 0, 0)), "boss_top": ((0, 0, 18), (0, 0, 1))}
    worst_off, worst_ang = 0.0, 0.0
    for name, (p0, n0) in planes.items():
        f = nxre.fit_surface(part, [nxre.rule_facets(part, reg[name])], "plane")
        face, d = nxre.fit_face(f, nxh.PLANE)
        off = sum((d["pt"][i] - p0[i]) * n0[i] for i in range(3))
        ang = angle(d["dir"], n0)
        dev = nxre.deviation(part, [face], sc.vertices(reg[name], 150))
        res["fits"]["plane_" + name] = {"type": f.FeatureType, "bodies": len(f.GetBodies()), "offset_mm": off, "angle_deg": ang,
                                        "area": nxh.sheet_area(part, [face])[0], "scan_dev": dev}
        worst_off, worst_ang = max(worst_off, abs(off)), max(worst_ang, ang)
    chk("9 plane fits: worst offset from the true plane (mm)", worst_off, 0.0, 0.01)
    chk("9 plane fits: worst normal angle (deg)", worst_ang, 0.0, 0.03)
    chk.true("plane fit is one sheet with FeatureType 'Fit Surface(Plane)'",
             all(v["bodies"] == 1 and v["type"] == "Fit Surface(Plane)" for k, v in res["fits"].items() if k.startswith("plane_")))
    # IsSingleSurface: False = one surface per connected island of the selection, True = one surface for all
    two = [r for r in reg["bottom"] if r[1][0] < 15 or r[1][0] > 40]          # two separate patches of the bottom
    m = nxh.mark("islands", False)
    f = nxre.fit_surface(part, [nxre.rule_facets(part, two)], "plane", single=False)
    n_multi = len(f.GetBodies())
    nxh.undo_to(m)
    f = nxre.fit_surface(part, [nxre.rule_facets(part, two)], "plane", single=True)
    face, d = nxre.fit_face(f, nxh.PLANE)
    res["fits"]["plane_two_islands"] = {"bodies_single_false": n_multi, "bodies_single_true": len(f.GetBodies()),
                                        "offset_mm": d["pt"][2], "angle_deg": angle(d["dir"], (0, 0, 1))}
    chk("IsSingleSurface=False: one sheet per island of the selection (2 islands)", n_multi, 2, 0.5)
    chk("IsSingleSurface=True: one sheet through both islands", len(f.GetBodies()), 1, 0.5)
    chk("plane through two islands: offset", d["pt"][2], 0.0, 0.01)
    # normal constrained to Z
    f = nxre.fit_surface(part, [nxre.rule_facets(part, reg["base_top"])], "plane", axis=(0, 0, 1), reject=0.1)
    face, d = nxre.fit_face(f, nxh.PLANE)
    res["fits"]["plane_base_top_axisZ"] = {"dir": d["dir"], "z": d["pt"][2], "exprs": [(e.Name, e.RightHandSide) for e in f.GetExpressions()]}
    chk("constrained plane normal is exactly Z", angle(d["dir"], (0, 0, 1)), 0.0, 1e-9)
    chk("constrained plane height", d["pt"][2], 8.0, 0.01)

    # ------------------------------------------------ 4. cylinders
    cyls = {"boss": ((44, 20, 0), (0, 0, 1), 10.0), "hole1": ((26, 10, 0), (0, 0, 1), 4.0), "hole2": ((26, 30, 0), (0, 0, 1), 4.0),
            "wall_hole": ((0, 20, 26), (1, 0, 0), 5.0)}
    for name, (ap, ad, rad) in cyls.items():
        f = nxre.fit_surface(part, [nxre.rule_facets(part, reg[name])], "cylinder", reject=0.1)
        face, d = nxre.fit_face(f, nxh.CYLINDER)
        row = {"type": f.FeatureType, "radius": d["radius"], "radius_err": d["radius"] - rad, "axis_angle_deg": angle(d["dir"], ad),
               "axis_offset_mm": nxre.axis_dist(d["pt"], ap, ad), "scan_dev": nxre.deviation(part, [face], sc.vertices(reg[name], 150))}
        res["fits"]["cyl_" + name] = row
        chk("cylinder %s radius error" % name, row["radius_err"], 0.0, 0.02)
        chk("cylinder %s axis angle (deg)" % name, row["axis_angle_deg"], 0.0, 0.1)
        chk("cylinder %s axis position error" % name, row["axis_offset_mm"], 0.0, 0.02)
        chk("cylinder %s scan rms about the fit" % name, row["scan_dev"]["rms"], SIGMA, 0.015)
    f = nxre.fit_surface(part, [nxre.rule_facets(part, reg["boss"])], "cylinder", reject=0.1, radius=10, axis=(0, 0, 1))
    face, d = nxre.fit_face(f, nxh.CYLINDER)
    row = {"radius": d["radius"], "axis_angle_deg": angle(d["dir"], (0, 0, 1)), "axis_offset_mm": nxre.axis_dist(d["pt"], (44, 20, 0), (0, 0, 1)),
           "scan_dev": nxre.deviation(part, [face], sc.vertices(reg["boss"], 150)),
           "exprs": [(e.Name, e.RightHandSide) for e in f.GetExpressions()]}
    res["fits"]["cyl_boss_snapped"] = row
    chk("snapped cylinder radius is exactly 10", row["radius"], 10.0, 1e-9)
    chk("snapped cylinder axis is exactly Z", row["axis_angle_deg"], 0.0, 1e-9)
    chk("snapped cylinder still on the scan (rms)", row["scan_dev"]["rms"], SIGMA, 0.015)
    f = nxre.fit_surface(part, [nxre.rule_facets(part, reg["boss"])], "cylinder", reject=0.1, solid=True)
    b0 = f.GetBodies()[0]
    res["fits"]["cyl_boss_solid"] = {"solid": b0.IsSolidBody, "faces": len(b0.GetFaces()), "volume": nxh.volume(part, b0)}
    chk.true("BodyTypePreference Solid gives a solid cylinder", b0.IsSolidBody and len(b0.GetFaces()) == 3)

    # ------------------------------------------------ 5. primitive region rule on the noisy and on a clean mesh
    seed = sc.seed((52, 6, 8), (0, 0, 1))
    n_noisy = len(nxre.region_facets(part, nxre.rule_primitive(part, seed, 5.0)))
    f = nxre.fit_surface(part, [nxre.rule_primitive(part, seed, 5.0)], "plane", reject=0.1)
    face, d = nxre.fit_face(f, nxh.PLANE)
    res["primitive_rule_noisy"] = {"facets": n_noisy, "of": len(reg["base_top"]), "offset_mm": d["pt"][2] - 8.0,
                                   "angle_deg": angle(d["dir"], (0, 0, 1))}
    cbc = nxre.stl_import(part, os.path.join(OUT, "scan_bracket_clean.stl"))[0]
    scc = nxre.Scan(part, cbc)
    regc = nxre.bracket_regions(scc)
    out = {}
    for name, xyz, n, kind in (("base_top", (52, 6, 8), (0, 0, 1), "plane"), ("hole1", (30, 10, 4), (-1, 0, 0), "cylinder"),
                               ("boss", (54, 20, 13), (1, 0, 0), "cylinder")):
        sd = scc.seed(xyz, n)
        out[name] = {"primitive": len(nxre.region_facets(part, nxre.rule_primitive(part, sd, 1.0))),
                     "tangent_30": len(nxre.region_facets(part, nxre.rule_tangent(part, sd, 30.0))), "picked": len(regc[name])}
    res["primitive_rule_clean"] = out
    chk.true("clean mesh: primitive rule takes the whole plane", out["base_top"]["primitive"] >= out["base_top"]["picked"], out["base_top"])
    chk.true("clean mesh: primitive rule takes the whole hole", out["hole1"]["primitive"] >= out["hole1"]["picked"], out["hole1"])
    chk.true("noisy mesh: primitive rule stops early (region smaller than the face)", n_noisy < len(reg["base_top"]), res["primitive_rule_noisy"])
    f = nxre.fit_surface(part, [nxre.rule_primitive(part, scc.seed((30, 10, 4), (-1, 0, 0)), 1.0)], "cylinder")
    face, d = nxre.fit_face(f, nxh.CYLINDER)
    res["fits"]["cyl_hole1_clean_primitive"] = {"radius": d["radius"], "axis_offset_mm": nxre.axis_dist(d["pt"], (26, 10, 0), (0, 0, 1))}
    chk("clean mesh hole radius (chord error only)", d["radius"], 4.0, 0.005)

    # ------------------------------------------------ 6. cone, sphere, freeform
    cp = nxre.stl_import(part, os.path.join(OUT, "scan_prim.stl"))[0]
    sp = nxre.Scan(part, cp)
    cone_rows = sp.pick(lambda c, n: 10.6 < c[2] < 21.4 and abs(nxre.axis_dist(c, (120, 20, 0), (0, 0, 1)) - (10 - (c[2] - 10) * 5 / 12)) < 0.3)
    sph_rows = sp.pick(lambda c, n: c[2] > 10.8 and abs(math.sqrt((c[0] - 160) ** 2 + (c[1] - 20) ** 2 + (c[2] - 10) ** 2) - 12) < 0.3)
    truth_half = math.degrees(math.atan(5 / 12))
    for name, kw in (("cone_free", {}), ("cone_axis_only", {"axis": (0, 0, 1)}), ("cone_axis_and_angle", {"axis": (0, 0, 1), "half_angle": 22.5})):
        f = nxre.fit_surface(part, [nxre.rule_facets(part, cone_rows)], "cone", reject=0.1, **kw)
        face, d = nxre.fit_face(f, nxh.CONE)
        res["fits"][name] = {"half_angle_deg": math.degrees(d["half_angle"]), "truth_half_angle": truth_half,
                             "axis_angle_deg": angle(d["dir"], (0, 0, 1)), "axis_offset_mm": nxre.axis_dist(d["pt"], (120, 20, 0), (0, 0, 1)),
                             "scan_dev": nxre.deviation(part, [face], sp.vertices(cone_rows, 150))}
    r = res["fits"]["cone_free"]
    chk("cone half angle (deg)", r["half_angle_deg"], truth_half, 0.1)
    chk("cone axis angle (deg)", r["axis_angle_deg"], 0.0, 0.1)
    chk("cone axis position error", r["axis_offset_mm"], 0.0, 0.02)
    r = res["fits"]["cone_axis_and_angle"]
    chk("cone with fixed axis + half angle 22.5: still on the scan (rms)", r["scan_dev"]["rms"], SIGMA, 0.015)
    chk.true("cone with ONLY the axis fixed is degenerate (documented trap)", res["fits"]["cone_axis_only"]["scan_dev"]["rms"] > 1.0,
             res["fits"]["cone_axis_only"])
    f = nxre.fit_surface(part, [nxre.rule_facets(part, sph_rows)], "sphere", reject=0.1)
    face, d = nxre.fit_face(f, nxh.SPHERE)
    res["fits"]["sphere"] = {"radius_err": d["radius"] - 12.0, "centre_err": math.dist(d["pt"], (160, 20, 10)),
                             "scan_dev": nxre.deviation(part, [face], sp.vertices(sph_rows, 150))}
    chk("sphere radius error", d["radius"], 12.0, 0.01)
    chk("sphere centre error", res["fits"]["sphere"]["centre_err"], 0.0, 0.01)
    f = nxre.fit_surface(part, [nxre.rule_facets(part, sph_rows)], "sphere", reject=0.1, radius=12)
    face, d = nxre.fit_face(f, nxh.SPHERE)
    chk("snapped sphere radius", d["radius"], 12.0, 1e-9)

    cc = nxre.stl_import(part, os.path.join(OUT, "scan_crown.stl"))[0]
    scr = nxre.Scan(part, cc)
    crown_rows = scr.pick(lambda c, n: c[2] > 17 and n[2] > 0.9)
    for name, kw in (("freeform_deg5x5_1patch", {}), ("freeform_deg3x3", {"degree": (3, 3)}), ("freeform_smooth40", {"smooth": 40})):
        f = nxre.fit_surface(part, [nxre.rule_facets(part, crown_rows)], "freeform", **kw)
        face = f.GetBodies()[0].GetFaces()[0]
        uv = UFS.Modeling.AskFaceUvMinmax(face.Tag)
        devs = []
        for i in range(1, 10):
            for j in range(1, 10):
                p = UFS.Modeling.AskFaceProps(face.Tag, [uv[0] + (uv[1] - uv[0]) * i / 10, uv[2] + (uv[3] - uv[2]) * j / 10])[0]
                devs.append(math.dist(p, (30, 80, -75)) - 100.0)
        res["fits"][name] = {"type": f.FeatureType, "bodies": len(f.GetBodies()), "face_type": nxh.face_data(face)[0],
                             "area": nxh.sheet_area(part, [face])[0], "truth_dev_max": max(abs(x) for x in devs),
                             "truth_dev_rms": math.sqrt(sum(x * x for x in devs) / len(devs)),
                             "scan_dev": nxre.deviation(part, [face], scr.vertices(crown_rows, 150))}
    r = res["fits"]["freeform_deg5x5_1patch"]
    chk.true("freeform fit is one B-surface", r["bodies"] == 1 and r["face_type"] == nxh.BSURF, r)
    chk("freeform (degree 5x5, 1 patch) max deviation from the true R100 sphere", r["truth_dev_max"], 0.0, 0.02)
    chk("freeform scan rms about the fit", r["scan_dev"]["rms"], SIGMA, 0.015)

    res["feature_errors"] = nxh.feature_errors(part)
    chk.true("no feature errors", not res["feature_errors"], res["feature_errors"])
    nxh.save(part)
    res.update(chk.report())
except Exception:
    res["error"] = traceback.format_exc()
    res["checks"] = chk.rows
    log(res["error"])
nxh.write_json(os.path.join(OUT, "re_fit_surfaces.json"), res)
