"""nxre - reverse-engineering helpers for headless NX 2206 journals (convergent bodies, facet regions,
Fit Surface, Fit Curve, scan census, alignment, fit-and-snap table, scan deviation). Verified by
re_fit_surfaces.py, re_sections_fitcurve.py, re_rebuild_compare.py and re_unknown_part.py in this folder.
Needs nxh (and nxf for apply_alignment) from nx-journal-core/scripts.

Import from a journal (run_journal.ps1 sets both variables):
    sys.path.insert(0, os.environ["NXH_DIR"])
    sys.path.insert(0, os.environ["NXRE_DIR"])
    import nxh, nxre
"""
import math
import os
import random
import struct

import NXOpen
import NXOpen.Facet
import NXOpen.Features
import nxh

S, UFS = nxh.S, nxh.UFS
FS = NXOpen.Features.FitSurfaceBuilder
FC = NXOpen.Features.FitCurveBuilder
NF = NXOpen.Features.Feature.Null


# ---------------------------------------------------------------- STL files (pure Python)
def read_stl(path):
    """-> (verts [(x, y, z)], tris [(i, j, k)]) with welded vertices; binary or ASCII STL."""
    data = open(path, "rb").read()
    n = struct.unpack_from("<I", data, 80)[0] if len(data) >= 84 else -1
    tri = []
    if n >= 0 and len(data) == 84 + 50 * n:
        for i in range(n):
            v = struct.unpack_from("<12f", data, 84 + 50 * i)
            tri.append((v[3:6], v[6:9], v[9:12]))
    else:
        pts = [tuple(float(x) for x in ln.split()[1:4]) for ln in data.decode("ascii", "ignore").splitlines()
               if ln.strip().startswith("vertex")]
        tri = [tuple(pts[i:i + 3]) for i in range(0, len(pts), 3)]
    index, verts, tris = {}, [], []
    for t in tri:
        ids = []
        for p in t:
            k = (round(p[0], 4), round(p[1], 4), round(p[2], 4))
            i = index.get(k)
            if i is None:
                i = index[k] = len(verts)
                verts.append((float(p[0]), float(p[1]), float(p[2])))
            ids.append(i)
        if len(set(ids)) == 3:
            tris.append(tuple(ids))
    return verts, tris


def read_stl_triangles(path):
    """Triangles of an STL in FILE order, unwelded: [((x, y, z), (x, y, z), (x, y, z)), ...]."""
    data = open(path, "rb").read()
    n = struct.unpack_from("<I", data, 80)[0] if len(data) >= 84 else -1
    if n >= 0 and len(data) == 84 + 50 * n:
        out = []
        for i in range(n):
            v = struct.unpack_from("<12f", data, 84 + 50 * i)
            out.append((v[3:6], v[6:9], v[9:12]))
        return out
    pts = [tuple(float(x) for x in ln.split()[1:4]) for ln in data.decode("ascii", "ignore").splitlines()
           if ln.strip().startswith("vertex")]
    return [tuple(pts[i:i + 3]) for i in range(0, len(pts) - 2, 3)]


def write_stl(path, verts, tris, header=b"nxre"):
    with open(path, "wb") as fh:
        fh.write(header.ljust(80, b" ")[:80])
        fh.write(struct.pack("<I", len(tris)))
        for a, b, c in tris:
            p, q, r = verts[a], verts[b], verts[c]
            u = (q[0] - p[0], q[1] - p[1], q[2] - p[2])
            v = (r[0] - p[0], r[1] - p[1], r[2] - p[2])
            n = (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
            ln = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2) or 1.0
            fh.write(struct.pack("<12fH", n[0] / ln, n[1] / ln, n[2] / ln, *p, *q, *r, 0))


def subdivide(verts, tris, max_edge):
    """Split every edge longer than max_edge at its midpoint until none is left (mesh stays watertight)."""
    verts = list(verts)
    for _ in range(40):
        mid, changed, out = {}, False, []

        def m(i, j):
            k = (i, j) if i < j else (j, i)
            if k not in mid:
                a, b = verts[i], verts[j]
                if (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2 <= max_edge * max_edge:
                    mid[k] = None
                else:
                    verts.append(((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2))
                    mid[k] = len(verts) - 1
            return mid[k]

        for a, b, c in tris:
            ab, bc, ca = m(a, b), m(b, c), m(c, a)
            k = (ab is not None) + (bc is not None) + (ca is not None)
            if k == 0:
                out.append((a, b, c))
                continue
            changed = True
            if k == 3:
                out += [(a, ab, ca), (ab, b, bc), (ca, bc, c), (ab, bc, ca)]
            elif k == 1:
                if ab is not None:
                    out += [(a, ab, c), (ab, b, c)]
                elif bc is not None:
                    out += [(a, b, bc), (a, bc, c)]
                else:
                    out += [(a, b, ca), (ca, b, c)]
            elif ab is None:
                out += [(a, b, bc), (a, bc, ca), (ca, bc, c)]
            elif bc is None:
                out += [(a, ab, ca), (ab, b, c), (ab, c, ca)]
            else:
                out += [(a, ab, c), (ab, bc, c), (ab, b, bc)]
        tris = out
        if not changed:
            break
    return verts, tris


def make_scan(src, dst, max_edge=2.5, sigma=0.0, seed=1, transform=None):
    """Turn a CAD STL into a scan-like test mesh: dense triangles, Gaussian vertex noise (sigma, mm) and an
    optional rigid transform fn((x, y, z)) -> (x, y, z). Returns (n_vertices, n_triangles)."""
    v, t = read_stl(src)
    v, t = subdivide(v, t, max_edge)
    if sigma > 0:
        rnd = random.Random(seed)
        v = [(x + rnd.gauss(0, sigma), y + rnd.gauss(0, sigma), z + rnd.gauss(0, sigma)) for x, y, z in v]
    if transform:
        v = [transform(p) for p in v]
    write_stl(dst, v, t)
    return len(v), len(t)


# ---------------------------------------------------------------- STL in / out of NX
def stl_export(part, body, path, chord=0.005, max_edge=1000.0):
    """Binary STL of ONE solid body (UF route; the csys argument must be 0). Returns (file size, n errors).
    A non-zero error count was seen on a body with a full sphere face although the file was complete:
    check the re-imported volume instead of trusting the count."""
    if os.path.exists(path):
        os.remove(path)
    h = UFS.Std.OpenBinaryStlFile(path, False, "nx")
    try:
        nerr, _info = UFS.Std.PutSolidInStlFile(h, 0, body.Tag, 0.0, float(max_edge), float(chord))
    finally:
        UFS.Std.CloseStlFile(h)
    return os.path.getsize(path), nerr


def stl_import(part, path, inches=False):
    """STL -> convergent bodies (one per shell; feature 'Convergent Body', class Brep). Returns the new bodies."""
    before = list(part.Bodies)
    b = part.FacetedBodies.CreateSTLImportBuilder()
    try:
        b.File = path
        U = NXOpen.Facet.STLImportBuilder.STLFileUnitsTypes
        b.STLFileUnits = U.Inches if inches else U.Millimeters
        b.FacetBodyType = NXOpen.Facet.STLImportBuilder.FacetBodyTypes.Psm
        b.ShowInformationWindow = False
        b.Commit()
    finally:
        b.Destroy()
    return nxh.new_bodies(part, before)


# ---------------------------------------------------------------- facets and regions
class Scan:
    """Facets of a convergent body cached as rows (facet, centroid, unit normal, (v0, v1, v2)).

    Cost: reading a facet (GetVertices) gets slower as the body gets bigger - 0.07-0.09 ms per facet on a
    46 k-facet body, 0.36 ms on 111 k (40 s for all) - so the total grows about with the square of the
    facet count. Enumerating the facet objects is cheap (3 microseconds each), therefore:
    - Scan(part, body)            reads every facet (fine up to ~100 k facets);
    - Scan(part, body, every=k)   reads every k-th facet only; `every` is kept and census() scales areas by
      it. Plane / cylinder fits, the census and deviation samples work on the thinned cache (a fit on 4000
      facets is as good as on 20 000). Use it for big scans; Scan.slice() then yields fewer section points.
    NX does NOT keep the STL triangle order (facet 1 was triangle 34 240 of the file), so the file cannot
    replace the read. Re-create the cache after the body was moved, split or trimmed."""

    def __init__(self, part, body, every=1):
        self.part, self.body, self.every = part, body, max(1, int(every))
        self.rows = []
        f, k = body.GetFirstFacetOnBody(), 0
        while f is not None:
            if k % self.every == 0:
                a, b, c = f.GetVertices()
                self.rows.append(self._row(f, (a.X, a.Y, a.Z), (b.X, b.Y, b.Z), (c.X, c.Y, c.Z)))
            f = body.GetNextFacet(f)
            k += 1
        self.n_body = k

    @staticmethod
    def _row(f, a, b, c):
        ux, uy, uz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
        vx, vy, vz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
        n = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)
        ln = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2) or 1.0
        return (f, ((a[0] + b[0] + c[0]) / 3, (a[1] + b[1] + c[1]) / 3, (a[2] + b[2] + c[2]) / 3),
                (n[0] / ln, n[1] / ln, n[2] / ln), (a, b, c))

    def seed(self, xyz, normal=None, cos_min=0.9):
        """Facet whose centroid is nearest xyz (and whose normal is within acos(cos_min) of `normal`)."""
        best, bd = None, 1e99
        for f, c, n, _v in self.rows:
            if normal is not None and n[0] * normal[0] + n[1] * normal[1] + n[2] * normal[2] < cos_min:
                continue
            d = (c[0] - xyz[0]) ** 2 + (c[1] - xyz[1]) ** 2 + (c[2] - xyz[2]) ** 2
            if d < bd:
                best, bd = f, d
        return best

    def pick(self, pred):
        """Rows for which pred(centroid, normal) is true - the journal's rectangle / lasso / brush selection."""
        return [r for r in self.rows if pred(r[1], r[2])]

    def slice(self, axis, value):
        """Points where facet edges cross the plane <axis index> = value (mesh section without NX curves)."""
        pts = []
        for _f, _c, _n, vs in self.rows:
            for i in range(3):
                p, q = vs[i], vs[(i + 1) % 3]
                dp, dq = p[axis] - value, q[axis] - value
                if dp * dq < 0:
                    t = dp / (dp - dq)
                    pts.append(tuple(p[k] + t * (q[k] - p[k]) for k in range(3)))
        return pts

    def vertices(self, rows=None, n=600):
        """About n evenly spaced facet vertices (first vertex of every k-th row) for deviation checks."""
        rows = self.rows if rows is None else rows
        return [r[3][0] for r in rows[::max(1, len(rows) // n)]]


def in_box(lo, hi, normal=None, cos_min=0.94):
    """Predicate for Scan.pick: centroid inside the box and (optionally) normal within ~20 deg of `normal`."""
    def pred(c, n):
        if not all(lo[i] <= c[i] <= hi[i] for i in range(3)):
            return False
        return normal is None or n[0] * normal[0] + n[1] * normal[1] + n[2] * normal[2] > cos_min
    return pred


def axis_dist(pt, axis_pt, axis_dir):
    """Distance from pt to the infinite line (axis_pt, unit axis_dir)."""
    w = [pt[i] - axis_pt[i] for i in range(3)]
    k = sum(w[i] * axis_dir[i] for i in range(3))
    return math.sqrt(max(0.0, sum(x * x for x in w) - k * k))


def on_cylinder(axis_pt, axis_dir, radius, tol, lo, hi):
    """Predicate for Scan.pick: centroid within tol of a cylinder and inside the box lo..hi."""
    return lambda c, n: abs(axis_dist(c, axis_pt, axis_dir) - radius) < tol and all(lo[i] <= c[i] <= hi[i] for i in range(3))


def rule_facets(part, rows_or_facets):
    """Selection rule holding exactly these facets (Scan rows or ConvergentFacet objects)."""
    fs = [r[0] if isinstance(r, tuple) else r for r in rows_or_facets]
    return part.FacetSelectionRuleFactory.CreateRuleSingleFacet(fs)


def rule_primitive(part, seed_facet, tol_factor=1.0):
    """Region grown from a seed over one plane / cylinder / cone / sphere (the GUI's primitive region rule).
    Takes the whole face on a clean mesh; stops early on a noisy one (check the facet count)."""
    return part.FacetSelectionRuleFactory.CreateRulePrimitiveFacets(seed_facet, float(tol_factor))


def rule_tangent(part, seed_facet, angle_deg):
    return part.FacetSelectionRuleFactory.CreateRuleTangentFacets(seed_facet, float(angle_deg))


def region_facets(part, rule):
    """The facets a rule selects (for counting / checking a region before fitting)."""
    col = part.FacetCollectorCollection.CreateCollector()
    col.AddRules([rule])
    return col.GetFacets()


# ---------------------------------------------------------------- Fit Surface / Fit Curve
def fit_surface(part, rules, kind="plane", reject=None, radius=None, axis=None, half_angle=None, solid=False,
                degree=None, patches=None, smooth=None, single=True):
    """Fit Surface on a facet region -> feature (FeatureType 'Fit Surface(Plane)' ...).

    kind: plane | cylinder | cone | sphere | freeform.
    reject: automatic point rejection threshold in mm (the user's 0.1 / 0.2 / 0.07); None = keep all points.
    radius: fix the radius (cylinder, sphere) - snapping to the design value. axis: fix the plane normal /
    cylinder or cone axis direction. half_angle: fix the cone half angle in degrees.
    single=True (IsSingleSurface) fits ONE surface through everything selected; with False NX makes one
    surface per connected island of the selection (a selection with stray facets gave 909 sheets)."""
    b = part.Features.CreateFitSurfaceBuilder(NXOpen.Features.FitSurface.Null)
    try:
        b.Type = {"plane": FS.Types.Fitplane, "cylinder": FS.Types.Fitcylinder, "cone": FS.Types.Fitcone,
                  "sphere": FS.Types.Fitsphere, "freeform": FS.Types.Fitfreeform}[kind]
        b.TargetOption = FS.TargetType.FacetRegion
        b.FacetCollector.AddRules(list(rules))
        b.IsSingleSurface = bool(single)
        if reject is not None:
            b.IsAutomatic = True
            b.RejectionThresholdValue.RightHandSide = str(reject)
        if radius is not None:
            b.IsRadius = True
            b.RadiusValue.RightHandSide = str(radius)
        if axis is not None:
            b.IsConstrained = True
            b.VectorConstraint = nxh.direction(part, axis)
        if half_angle is not None:
            b.IsHalfAngle = True
            b.AngleValue.RightHandSide = str(half_angle)
        if solid:
            b.BodyTypePreference = FS.BodyType.Solid
        if degree is not None:
            b.Parameterization.UDegree, b.Parameterization.VDegree = degree
        if patches is not None:
            b.Parameterization.UPatches, b.Parameterization.VPatches = patches
        if smooth is not None:
            b.SmoothFactor = int(smooth)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f


def fit_face(feature, ftype=None):
    """(face, data) of the fitted surface; data = {type, pt, dir, radius, half_angle (cone, radians)}.
    plane: pt on plane, dir = normal | cylinder: pt on axis, dir = axis | cone: pt on axis, radius AT pt |
    sphere: pt = centre."""
    for body in feature.GetBodies():
        for face in body.GetFaces():
            t, pt, d, _box, rad, rd, _nd = UFS.Modeling.AskFaceData(face.Tag)
            if ftype is None or t == ftype:
                return face, {"type": t, "pt": list(pt), "dir": list(d), "radius": abs(rad), "half_angle": rd}
    raise RuntimeError("no face of the requested type in " + feature.GetFeatureName())


def fit_curve(part, points, kind="circle", reject=None, radius=None, closed=True):
    """Fit Curve on NXOpen.Point objects (TargetSourceType SpecifiedPoints - the only target that works in
    batch; curve / face / facet-body targets raise 'insufficient number of fitting points').
    kind: circle | line | spline | ellipse. Returns the feature; curves = feature.GetEntities()."""
    b = part.Features.CreateFitCurveBuilder(NXOpen.Features.FitCurve.Null)
    try:
        b.Type = {"circle": FC.Types.FitCircle, "line": FC.Types.FitLine, "spline": FC.Types.FitSpline,
                  "ellipse": FC.Types.FitEllipse}[kind]
        b.TargetSourceType = FC.TargetSourceTypes.SpecifiedPoints
        for p in points:
            b.Target.Add(p)
        if reject is not None:
            b.CanRejectPointsAutomatically = True
            b.RejectionThreshold.RightHandSide = str(reject)
        if kind == "circle":
            b.IsClosedCurve = bool(closed)
        if radius is not None:
            b.HasRadius = True
            b.Radius.RightHandSide = str(radius)
        b.IsAssociative = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f


def points(part, xyz_list, n=150):
    """NX point objects for about n of the coordinates (targets for fit_curve)."""
    xyz_list = list(xyz_list)
    return [part.Points.CreatePoint(nxh.P(*p)) for p in xyz_list[::max(1, len(xyz_list) // n)]]


def section_curves(part, body, datum_plane, tol=0.01):
    """Section Curve of a (convergent or exact) body with a datum plane -> (feature, [curves]).
    On a convergent body every loop is ONE degree-1 spline through the facet crossings."""
    b = part.Features.CreateSectionCurveBuilder(NF)
    try:
        b.Type = NXOpen.Features.SectionCurveBuilder.PlaneType.Selected
        b.Tolerance = tol
        b.ObjectsToSection.Add(body)
        b.SectionPlanes.Add(datum_plane)
        b.Associative = True
        f = b.Commit()
    finally:
        b.Destroy()
    return f, [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)]


# ---------------------------------------------------------------- deviation
def _signed_stats(ds, pts=None, threshold=None):
    n = len(ds)
    if not n:
        return {"n": 0}
    ab = sorted(abs(d) for d in ds)
    q = lambda f: ab[min(n - 1, int(f * n))]
    out = {"n": n, "min": min(ds), "max": max(ds), "mean": sum(ds) / n, "rms": math.sqrt(sum(d * d for d in ds) / n),
           "abs_p50": q(0.50), "abs_p95": q(0.95), "abs_p99": q(0.99), "abs_max": ab[-1]}
    if pts is not None:
        k = max(range(n), key=lambda i: abs(ds[i]))
        out["worst"] = {"point": [round(x, 4) for x in pts[k]], "deviation": ds[k]}
    if threshold is not None:
        out["threshold"] = threshold
        out["share_over"] = sum(1 for d in ab if d > threshold) / n
    return out


def signed_deviation(part, solid, pts, threshold=None, regions=None):
    """Signed distance of scan points to a SOLID body (UF AskMinimumDist: negative = the point is inside the
    solid, i.e. the CAD is fatter than the scan there).

    -> {n, min, max, mean, rms, abs_p50, abs_p95, abs_p99, abs_max, worst {point, deviation},
        share_over (fraction with |d| > threshold, when a threshold is given),
        regions {name: {n, min, max, mean, rms, abs_p95, ...}}} when regions = {name: Scan rows or points}.
    A region whose signed mean is far from 0 (more than ~0.75 x noise) is an offset face: iterate on it."""
    pts = list(pts)
    ds = [nxh.dist_to(part, solid, p) for p in pts]
    out = _signed_stats(ds, pts, threshold)
    if regions:
        out["regions"] = {}
        for name, rows in regions.items():
            rp = [r[3][0] if (isinstance(r, tuple) and len(r) == 4 and not isinstance(r[0], float)) else r for r in rows]
            rp = rp[::max(1, len(rp) // 150)]
            out["regions"][name] = _signed_stats([nxh.dist_to(part, solid, p) for p in rp], rp, threshold)
    return out


def deviation(part, faces_or_body, pts):
    """Unsigned distance of each point to the nearest of the given faces -> {n, max, rms, mean, p95}.
    Works for sheets and single fitted faces as well as for body.GetFaces() of the rebuilt solid."""
    faces = list(faces_or_body.GetFaces()) if hasattr(faces_or_body, "GetFaces") else list(faces_or_body)
    ds = []
    for p in pts:
        pt = part.Points.CreatePoint(nxh.P(*p))
        try:
            ds.append(min(nxh.min_dist(pt, f) for f in faces))
        finally:
            S.UpdateManager.AddToDeleteList(pt)
    ds.sort()
    n = len(ds)
    if not n:
        return {"n": 0}
    return {"n": n, "max": ds[-1], "rms": math.sqrt(sum(d * d for d in ds) / n), "mean": sum(ds) / n,
            "p50": ds[min(n - 1, int(0.50 * n))], "p95": ds[min(n - 1, int(0.95 * n))], "p99": ds[min(n - 1, int(0.99 * n))]}


def snap(value, grid=0.5, tol=0.05):
    """Design-intent rounding: the nearest multiple of `grid` when the fitted value is within `tol` of it,
    otherwise the value rounded to 0.01. Returns (snapped value, was_snapped)."""
    r = round(value / grid) * grid
    return (round(r, 6), True) if abs(r - value) <= tol else (round(value, 2), False)


# ====================================================================== unknown scans: census, alignment, fit table
def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _unit(a):
    n = math.sqrt(_dot(a, a)) or 1.0
    return (a[0] / n, a[1] / n, a[2] / n)


def _frame(d):
    """Two unit vectors u, v with (u, v, d) right-handed and orthonormal."""
    h = (1.0, 0.0, 0.0) if abs(d[0]) < 0.9 else (0.0, 1.0, 0.0)
    u = _unit(_cross(h, d))
    return u, _cross(d, u)


def tri_area(vs):
    c = _cross([vs[1][i] - vs[0][i] for i in range(3)], [vs[2][i] - vs[0][i] for i in range(3)])
    return 0.5 * math.sqrt(_dot(c, c))


def lsq_plane(pts, d):
    """Least-squares plane through points, d = approximate unit normal (within ~30 deg).
    -> (unit normal on the side of d, offset with normal . x = offset, RMS distance)."""
    u, v = _frame(d)
    n = len(pts)
    su = sv = sw = suu = suv = svv = suw = svw = 0.0
    loc = []
    for p in pts:
        a, b, w = _dot(p, u), _dot(p, v), _dot(p, d)
        loc.append((a, b, w))
        su += a; sv += b; sw += w
        suu += a * a; suv += a * b; svv += b * b; suw += a * w; svw += b * w
    m = [[suu, suv, su], [suv, svv, sv], [su, sv, float(n)]]
    r = [suw, svw, sw]

    def det(q):
        return (q[0][0] * (q[1][1] * q[2][2] - q[1][2] * q[2][1]) - q[0][1] * (q[1][0] * q[2][2] - q[1][2] * q[2][0])
                + q[0][2] * (q[1][0] * q[2][1] - q[1][1] * q[2][0]))
    dd = det(m)
    if abs(dd) < 1e-12:
        return tuple(d), sw / max(1, n), 0.0
    sol = []
    for k in range(3):
        mk = [[r[i] if j == k else m[i][j] for j in range(3)] for i in range(3)]
        sol.append(det(mk) / dd)
    a, b, c = sol
    nrm = _unit([d[i] - a * u[i] - b * v[i] for i in range(3)])
    k = _dot(nrm, d)
    rms = math.sqrt(sum((w - a * x - b * y - c) ** 2 for x, y, w in loc) / n) * k
    return nrm, c * k, rms


def circle_fit(pts2):
    """Algebraic (Kasa) circle fit of 2D points -> (cx, cy, r) or None."""
    n = len(pts2)
    sx = sum(p[0] for p in pts2) / n
    sy = sum(p[1] for p in pts2) / n
    suu = suv = svv = suuu = svvv = suvv = svuu = 0.0
    for x, y in pts2:
        u, v = x - sx, y - sy
        suu += u * u; suv += u * v; svv += v * v
        suuu += u * u * u; svvv += v * v * v; suvv += u * v * v; svuu += v * u * u
    det = suu * svv - suv * suv
    if abs(det) < 1e-12:
        return None
    b1, b2 = 0.5 * (suuu + suvv), 0.5 * (svvv + svuu)
    uc = (b1 * svv - b2 * suv) / det
    vc = (b2 * suu - b1 * suv) / det
    return sx + uc, sy + vc, math.sqrt(uc * uc + vc * vc + (suu + svv) / n)


def _normal_clusters(fs, n_max, cos_tol):
    bins = {}
    for _c, n, a, _r in fs:
        k = (round(n[0] * 20), round(n[1] * 20), round(n[2] * 20))
        bins[k] = bins.get(k, 0.0) + a
    used = [False] * len(fs)
    out = []
    for k, _a in sorted(bins.items(), key=lambda kv: -kv[1]):
        if len(out) >= n_max:
            break
        seed = _unit(k)
        if any(_dot(seed, o["dir"]) > 0.996 for o in out):
            continue
        sx = sy = sz = area = 0.0
        idx = []
        for i, (_c, n, a, _r) in enumerate(fs):
            if not used[i] and _dot(n, seed) > cos_tol:
                sx += n[0] * a; sy += n[1] * a; sz += n[2] * a
                area += a
                idx.append(i)
        if area <= 0:
            continue
        for i in idx:
            used[i] = True
        out.append({"dir": _unit((sx, sy, sz)), "area": area, "idx": idx})
    return out


def _offset_peaks(fs, idx, d, win, min_area, n_max=12, step=0.05):
    h = {}
    for i in idx:
        k = round(_dot(fs[i][0], d) / step)
        h[k] = h.get(k, 0.0) + fs[i][2]
    peaks, taken = [], set()
    for k, _a in sorted(h.items(), key=lambda kv: -kv[1]):
        if k in taken or len(peaks) >= n_max:
            continue
        ks = [j for j in h if abs(j - k) * step <= win and j not in taken]
        area = sum(h[j] for j in ks)
        for j in ks:
            taken.add(j)
        if area >= min_area:
            peaks.append((sum(h[j] * j * step for j in ks) / area, area))
    return peaks


def _cylinder_votes(fs, cand_idx, axis, r_min, r_max, r_step, n_max, max_rms=0.08, min_coverage=0.15, min_sectors=6):
    u, v = _frame(axis)
    cand = []
    for i in cand_idx:
        c, n, a, _r = fs[i]
        if abs(_dot(n, axis)) > 0.12:
            continue
        nu, nv = _dot(n, u), _dot(n, v)
        ln = math.hypot(nu, nv) or 1.0
        cand.append((_dot(c, u), _dot(c, v), _dot(c, axis), nu / ln, nv / ln, a, i))
    votes = {}
    cell = max(0.5, r_step)
    ir0, ir1 = max(1, int(round(r_min / r_step))), int(round(r_max / r_step))
    for cu, cv, _w, nu, nv, a, _i in cand:
        for ir in range(ir0, ir1 + 1):
            r = ir * r_step
            for sg in (1, -1):               # +1 boss: centre = c - r n;  -1 hole: centre = c + r n
                k = (round((cu - sg * r * nu) / cell), round((cv - sg * r * nv) / cell), ir, sg)
                votes[k] = votes.get(k, 0.0) + a
    out, used = [], set()
    for k, _a in sorted(votes.items(), key=lambda kv: -kv[1])[:400]:
        cu0, cv0, r0, sg = k[0] * cell, k[1] * cell, k[2] * r_step, k[3]
        if any(abs(p["_c"][0] - cu0) < 1.6 and abs(p["_c"][1] - cv0) < 1.6 and abs(p["radius"] - r0) < 1.6 and p["_sg"] == sg for p in out):
            continue
        sup = []
        for cu, cv, w, nu, nv, ar, i in cand:
            if i in used:
                continue
            du, dv = cu - cu0, cv - cv0
            dist = math.hypot(du, dv)
            if abs(dist - r0) < 0.6 and dist > 1e-6 and sg * (du * nu + dv * nv) / dist > 0.9:
                sup.append((cu, cv, w, ar, i))
        if len(sup) < 12:
            continue
        fit = circle_fit([(s[0], s[1]) for s in sup])
        if fit is None:
            continue
        sect = set(int((math.degrees(math.atan2(s[1] - fit[1], s[0] - fit[0])) % 360) // 10) for s in sup)
        ws = [_dot(vtx, axis) for s in sup for vtx in fs[s[4]][3][3]]
        area = sum(s[3] for s in sup)
        rms = math.sqrt(sum((math.hypot(s[0] - fit[0], s[1] - fit[1]) - fit[2]) ** 2 for s in sup) / len(sup))
        mid = (min(ws) + max(ws)) / 2
        cov = area / (2 * math.pi * fit[2] * max(1e-6, max(ws) - min(ws)))
        if rms > max_rms or cov < min_coverage or len(sect) < min_sectors or fit[2] < r_min:
            continue
        used.update(s[4] for s in sup)
        out.append({"kind": "boss" if sg > 0 else "hole", "axis": [round(x, 6) for x in axis], "radius": round(fit[2], 4),
                    "point": [round(fit[0] * u[i] + fit[1] * v[i] + mid * axis[i], 4) for i in range(3)],
                    "axial_extent": [round(min(ws), 3), round(max(ws), 3)], "area": round(area, 2), "n": len(sup),
                    "sectors36": len(sect), "rms_centroids": round(rms, 4),
                    "coverage": round(cov, 3),
                    "rows": [fs[s[4]][3] for s in sup], "_c": (fit[0], fit[1]), "_sg": sg})
        if len(out) >= n_max:
            break
    for p in out:
        del p["_c"], p["_sg"]
    return out


def census(scan, plane_min_area=None, win=0.3, r_range=(1.0, 60.0), r_step=0.5, max_dirs=14, max_cylinders=14,
           cylinder_axes=None):
    """Describe an UNKNOWN scan (pure Python on a Scan cache; no NX features).

    -> {"facets", "bbox", "mesh_area", "edge_median", "noise", "directions": [{"dir", "area"}],
        "planes": [{"normal", "offset", "area", "n", "rms", "extent", "rows"}] sorted by area (normal . x = offset,
                    normal outward, refined by a least-squares plane through the facet vertices),
        "cylinders": [{"kind" boss|hole, "axis", "point" (on the axis, mid height), "radius", "axial_extent",
                       "sectors36", "coverage", "rows"}],
        "datums": {"primary", "secondary", "tertiary"} (indices into "planes") or None}
    Planes: facets are clustered by normal (5 deg), then by offset along the cluster direction (peaks of an
    area histogram, +-win). Peaks below plane_min_area (default max(20, 0.4 % of the mesh area)) are dropped.
    Cylinders: centre voting about every plane-cluster direction (or cylinder_axes), then a circle fit on the
    supporting facet centroids - approximate values; the exact ones come from Fit Surface on "rows". Kept when
    the centroid RMS is below max(0.05, 4 x noise), at least 60 deg of the circle is covered and the coverage
    (area / full cylinder area) is at least 0.15; a cylinder whose axis is no plane normal is NOT found.
    noise = median least-squares RMS of the large planes (the scan's sigma normal to a flat face).
    Use jsonable(census) before writing it to a file."""
    w = float(getattr(scan, "every", 1))                 # a thinned cache: every facet stands for `every` facets
    fs = [(r[1], r[2], tri_area(r[3]) * w, r) for r in scan.rows]
    total = sum(f[2] for f in fs)
    lo = [min(v[i] for f in fs for v in f[3][3]) for i in range(3)]
    hi = [max(v[i] for f in fs for v in f[3][3]) for i in range(3)]
    el = sorted(math.dist(f[3][3][0], f[3][3][1]) for f in fs[::max(1, len(fs) // 2000)])
    if plane_min_area is None:
        plane_min_area = max(20.0, 0.004 * total)
    clusters = _normal_clusters(fs, max_dirs, 0.9962)
    planes, in_plane = [], set()
    for c in clusters:
        d = c["dir"]
        for off, area in _offset_peaks(fs, c["idx"], d, win, plane_min_area):
            # members: every facet at this offset whose normal is within 25 deg (noisy normals leave the 5 deg cluster)
            idx = [i for i in range(len(fs)) if i not in in_plane and abs(_dot(fs[i][0], d) - off) <= win and _dot(fs[i][1], d) > 0.9]
            area = sum(fs[i][2] for i in idx)
            if len(idx) < 12 or area < plane_min_area:
                continue
            pts = [v for i in idx[::max(1, len(idx) // 1500)] for v in fs[i][3][3]]
            nrm, o, rms = lsq_plane(pts, d)
            cen = [fs[i][0] for i in idx]
            planes.append({"normal": [round(x, 6) for x in nrm], "offset": round(o, 4), "area": round(area, 2), "n": len(idx),
                           "rms": round(rms, 4), "extent": [[round(min(p[q] for p in cen), 3), round(max(p[q] for p in cen), 3)] for q in range(3)],
                           "rows": [fs[i][3] for i in idx]})
            in_plane.update(idx)
    planes.sort(key=lambda p: -p["area"])
    big = sorted(p["rms"] for p in planes if p["area"] >= 0.25 * planes[0]["area"]) if planes else []
    axes = [tuple(a) for a in cylinder_axes] if cylinder_axes else []
    if not axes:                       # axis candidates = the normals of the accepted planes (up to sign)
        for p in planes:
            if not any(abs(_dot(p["normal"], a)) > 0.996 for a in axes):
                axes.append(tuple(p["normal"]))
    cand_idx = [i for i in range(len(fs)) if i not in in_plane]
    r_hi = min(r_range[1], 0.6 * max(hi[i] - lo[i] for i in range(3)))
    cyl = []
    noise = big[len(big) // 2] if big else 0.02
    for a in axes:
        cyl += _cylinder_votes(fs, cand_idx, a, r_range[0], r_hi, r_step, max_cylinders, max_rms=max(0.05, 4 * noise))
    cyl.sort(key=lambda p: -p["area"])
    datums = None
    if planes:
        p1 = 0
        sec = [i for i, p in enumerate(planes) if abs(_dot(p["normal"], planes[p1]["normal"])) < 0.05]
        if sec:
            p2 = sec[0]
            d1 = planes[p1]["normal"]
            d2 = _unit([planes[p2]["normal"][i] - _dot(planes[p2]["normal"], d1) * d1[i] for i in range(3)])
            d3 = _cross(d1, d2)
            ter = [i for i, p in enumerate(planes) if _dot(p["normal"], d3) < -0.996]
            ter.sort(key=lambda i: -planes[i]["offset"])          # outermost face on the -d3 side
            datums = {"primary": p1, "secondary": p2, "tertiary": ter[0] if ter else None}
    return {"facets": len(fs), "bbox": [round(x, 4) for x in lo + hi], "mesh_area": total, "edge_median": el[len(el) // 2],
            "noise": big[len(big) // 2] if big else None, "plane_min_area": plane_min_area,
            "directions": [{"dir": [round(x, 6) for x in c["dir"]], "area": round(c["area"], 2)} for c in clusters],
            "planes": planes, "cylinders": cyl, "datums": datums}


def jsonable(obj):
    """Copy of a census / fit table without the facet rows (for write_json)."""
    if isinstance(obj, dict):
        return {k: jsonable(v) for k, v in obj.items() if k != "rows"}
    if isinstance(obj, (list, tuple)):
        return [jsonable(v) for v in obj]
    return obj


def axis_angle(R):
    """Rotation matrix (rows) -> (unit axis, angle in degrees), right-handed."""
    tr = R[0][0] + R[1][1] + R[2][2]
    ang = math.acos(max(-1.0, min(1.0, (tr - 1) / 2)))
    ax = (R[2][1] - R[1][2], R[0][2] - R[2][0], R[1][0] - R[0][1])
    s = math.sqrt(_dot(ax, ax))
    if s < 1e-9:
        if ang < 1e-6:
            return (0.0, 0.0, 1.0), 0.0
        m = [[R[i][j] + (1.0 if i == j else 0.0) for j in range(3)] for i in range(3)]      # 180 deg
        j = max(range(3), key=lambda q: m[q][q])
        return _unit((m[0][j], m[1][j], m[2][j])), math.degrees(ang)
    return _unit(ax), math.degrees(ang)


def plane_intersection(p1, p2, p3):
    """Point common to three planes given as {"normal", "offset"}."""
    m = [list(p["normal"]) for p in (p1, p2, p3)]
    r = [p["offset"] for p in (p1, p2, p3)]

    def det(q):
        return (q[0][0] * (q[1][1] * q[2][2] - q[1][2] * q[2][1]) - q[0][1] * (q[1][0] * q[2][2] - q[1][2] * q[2][0])
                + q[0][2] * (q[1][0] * q[2][1] - q[1][1] * q[2][0]))
    d = det(m)
    return tuple(det([[r[i] if j == k else m[i][j] for j in range(3)] for i in range(3)]) / d for k in range(3))


def alignment(primary, secondary, origin=None, tertiary=None, primary_to=(0, 0, -1), secondary_to=(-1, 0, 0)):
    """Rigid transform that puts a scan into its datum frame.

    primary / secondary / tertiary: planes {"normal" (outward), "offset"} from census() or measure_plane().
    The primary normal goes exactly onto primary_to, the secondary normal as close as possible to secondary_to
    (its component square to the primary), and `origin` (a scan-frame point; default = the intersection of the
    three planes) goes to (0, 0, 0).  x_new = R (x - origin).
    -> {"R" (rows), "axis", "angle_deg", "origin", "squareness_error_deg"}."""
    d1 = _unit(primary["normal"])
    n2 = _unit(secondary["normal"])
    d2 = _unit([n2[i] - _dot(n2, d1) * d1[i] for i in range(3)])
    d3 = _cross(d1, d2)
    t1, t2 = _unit(primary_to), _unit(secondary_to)
    t3 = _cross(t1, t2)
    R = [[t1[i] * d1[j] + t2[i] * d2[j] + t3[i] * d3[j] for j in range(3)] for i in range(3)]
    if origin is None:
        if tertiary is None:
            raise ValueError("alignment needs origin= or tertiary=")
        origin = plane_intersection(primary, secondary, tertiary)
    ax, ang = axis_angle(R)
    return {"R": R, "axis": list(ax), "angle_deg": ang, "origin": list(origin),
            "squareness_error_deg": math.degrees(math.acos(max(-1.0, min(1.0, _dot(d1, n2))))) - 90.0}


def apply_alignment(part, bodies, al):
    """Move Object the (convergent) bodies into the datum frame: ONE rotation about the axis through the
    origin point, then one translation. Returns the features. Rebuild nxre.Scan afterwards."""
    import nxf
    feats = []
    o = al["origin"]
    if al["angle_deg"] > 1e-4:
        feats.append(nxf.move_object(part, list(bodies), "angle", al["angle_deg"], vec=tuple(al["axis"]), origin=tuple(o)))
    if max(abs(x) for x in o) > 1e-6:
        feats.append(nxf.move_object(part, list(bodies), "delta", (-o[0], -o[1], -o[2])))
    return feats


def transform_point(al, p):
    q = [p[i] - al["origin"][i] for i in range(3)]
    return tuple(_dot(al["R"][i], q) for i in range(3))


def _thin(rows, n):
    """At most about n rows, evenly spaced (a fit on 4000 facets is as good as on 20 000 and much faster)."""
    return rows if not n or len(rows) <= n else rows[::max(1, len(rows) // n)]


def measure_plane(part, rows, axis=None, reject=0.1, keep=False, n_dev=300, max_facets=4000):
    """Fit Surface plane on facet rows and read it: {"normal" (outward, same side as the facets), "offset",
    "pt", "rms", "max", "n"}. keep=False removes the feature again (undo to a mark): a measurement, no tree entry."""
    m = nxh.mark("measure plane", False)
    rows = _thin(rows, max_facets)
    f = fit_surface(part, [rule_facets(part, rows)], "plane", reject=reject, axis=axis)
    face, d = fit_face(f, nxh.PLANE)
    n = list(d["dir"])
    mean = [sum(r[2][i] for r in rows[::max(1, len(rows) // 200)]) for i in range(3)]
    if _dot(n, mean) < 0:
        n = [-x for x in n]
    dev = deviation(part, [face], [r[3][0] for r in rows[::max(1, len(rows) // n_dev)]])
    out = {"normal": n, "offset": _dot(n, d["pt"]), "pt": d["pt"], "rms": dev["rms"], "max": dev["max"], "n": len(rows)}
    if not keep:
        nxh.undo_to(m)
    return out


def fit_table(part, regions, grid=0.5, tol=0.05, keep=False, reject=0.1, n_dev=300, max_facets=4000):
    """Fit-and-snap table for a list of regions -> (rows for the report, values by name).

    region = {"name", "kind": "plane" | "cylinder", "rows": Scan rows, "axis": design direction or None}
    plane:    free fit (position along axis, tilt to it, RMS) -> fit with the normal fixed to axis -> snap.
    cylinder: free fit (radius, tilt, RMS) -> fit with the snapped radius and the axis fixed -> centre snap.
    Each table row: feature, kind, n_facets, fitted_free, tilt_deg, fitted_constrained, snapped, snap_ok,
    fit_minus_snap, rms_free, rms_constrained, rms_snapped, mean_snapped (signed, about the snapped geometry).
    keep=False ("measure only") undoes every Fit Surface feature after reading it; keep=True leaves the
    constrained fits in the tree, named FIT_<NAME>, with their sheets blanked.
    values[name]: plane {"position", "normal"}; cylinder {"radius", "point", "axis"} with snapped numbers."""
    table, values = [], {}
    for reg in regions:
        name, kind, rows, axis = reg["name"], reg["kind"], _thin(reg["rows"], max_facets), reg.get("axis")
        pts = [r[3][0] for r in rows[::max(1, len(rows) // n_dev)]]
        ft = {"plane": nxh.PLANE, "cylinder": nxh.CYLINDER}[kind]
        m = nxh.mark("fit table " + name, False)
        f0 = fit_surface(part, [rule_facets(part, rows)], kind, reject=reject)
        face, d = fit_face(f0, ft)
        dev0 = deviation(part, [face], pts)
        ax = _unit(axis) if axis is not None else None
        a = nxh.angle_deg(d["dir"], ax) if ax else None
        tilt = min(a, 180.0 - a) if ax else None
        if kind == "plane":
            ref = ax or _unit(d["dir"])
            cu = [sum(p[i] for p in pts) / len(pts) for i in range(3)]
            n = d["dir"]
            free = _dot(cu, ref) + _dot(n, [d["pt"][i] - cu[i] for i in range(3)]) / _dot(n, ref)   # along ref at the region centre
            nxh.undo_to(m)
            m = nxh.mark("fit table c " + name, False)
            con, devc, fc = free, dev0, None
            if ax:
                fc = fit_surface(part, [rule_facets(part, rows)], kind, reject=reject, axis=ax)
                facec, dc = fit_face(fc, ft)
                con = _dot(dc["pt"], ax)
                devc = deviation(part, [facec], pts)
            snapped, ok = snap(con, grid, tol)
            rs = [_dot(p, ref) - snapped for p in pts]
            table.append({"feature": name, "kind": "plane", "n_facets": len(rows), "fitted_free": round(free, 4),
                          "tilt_deg": None if tilt is None else round(tilt, 4), "fitted_constrained": round(con, 4),
                          "snapped": snapped, "snap_ok": ok, "fit_minus_snap": round(con - snapped, 4),
                          "rms_free": round(dev0["rms"], 4), "rms_constrained": round(devc["rms"], 4),
                          "rms_snapped": round(math.sqrt(sum(x * x for x in rs) / len(rs)), 4),
                          "mean_snapped": round(sum(rs) / len(rs), 4)})
            values[name] = {"position": snapped, "normal": list(ref)}
        else:
            r_free = d["radius"]
            r_snap, ok_r = snap(r_free, grid, tol)
            foot0 = [d["pt"][i] - _dot(d["pt"], d["dir"]) * d["dir"][i] for i in range(3)]
            nxh.undo_to(m)
            m = nxh.mark("fit table c " + name, False)
            fc = fit_surface(part, [rule_facets(part, rows)], kind, reject=reject, radius=r_snap, axis=ax)
            facec, dc = fit_face(fc, ft)
            devc = deviation(part, [facec], pts)
            adir = _unit(dc["dir"])
            foot = [dc["pt"][i] - _dot(dc["pt"], adir) * adir[i] for i in range(3)]       # axis point nearest the origin
            sn = [snap(x, grid, tol) for x in foot]
            point = [s[0] for s in sn]
            rs = [axis_dist(p, point, adir) - r_snap for p in pts]
            common = {"n_facets": len(rows), "tilt_deg": None if tilt is None else round(tilt, 4), "rms_free": round(dev0["rms"], 4),
                      "rms_constrained": round(devc["rms"], 4), "rms_snapped": round(math.sqrt(sum(x * x for x in rs) / len(rs)), 4),
                      "mean_snapped": round(sum(rs) / len(rs), 4)}
            table.append(dict({"feature": name + " radius", "kind": "cylinder", "fitted_free": round(r_free, 4),
                               "fitted_constrained": round(dc["radius"], 4), "snapped": r_snap, "snap_ok": ok_r,
                               "fit_minus_snap": round(r_free - r_snap, 4)}, **common))
            for i, lab in enumerate("xyz"):
                if abs(adir[i]) > 0.999:
                    continue                                   # the coordinate along the axis is not a dimension
                table.append({"feature": "%s axis %s" % (name, lab), "kind": "axis position", "fitted_free": round(foot0[i], 4),
                              "fitted_constrained": round(foot[i], 4), "snapped": sn[i][0], "snap_ok": sn[i][1],
                              "fit_minus_snap": round(foot[i] - sn[i][0], 4)})
            values[name] = {"radius": r_snap, "point": point, "axis": list(adir)}
        if keep and fc is not None:
            fc.SetName("FIT_" + name.upper().replace(" ", "_"))
            for b in fc.GetBodies():
                b.Blank()
        else:
            nxh.undo_to(m)
    return table, values


# ---------------------------------------------------------------- test geometry with known truth
BRACKET = {"volume": 60 * 40 * 8 + 8 * 40 * 32 + math.pi * 100 * 10 - 2 * math.pi * 16 * 8 - math.pi * 25 * 8}


def truth_bracket(part):
    """L-bracket: base 60x40x8, wall 8x40x40 at x=0, boss dia 20 x 10 at (44,20), two dia 8 holes at
    (26,10) and (26,30), one dia 10 hole through the wall at y=20, z=26. Volume = BRACKET['volume']."""
    _f, body = nxh.block(part, (0, 0, 0), (60, 40, 8))
    _f, wall = nxh.block(part, (0, 0, 0), (8, 40, 40))
    nxh.unite(part, body, [wall])
    nxh.cylinder(part, (44, 20, 8), (0, 0, 1), 20, 10, nxh.BOOL.Unite, body)
    nxh.cylinder(part, (26, 10, 0), (0, 0, 1), 8, 8, nxh.BOOL.Subtract, body)
    nxh.cylinder(part, (26, 30, 0), (0, 0, 1), 8, 8, nxh.BOOL.Subtract, body)
    nxh.cylinder(part, (0, 20, 26), (1, 0, 0), 10, 8, nxh.BOOL.Subtract, body)
    return body


def bracket_regions(sc, inv=None):
    """Facet rows of every analytic face of the truth bracket in a Scan (inv maps scan coordinates back to
    the bracket frame when the scan was transformed)."""
    inv = inv or (lambda p: p)

    def pk(pred_c):
        return [r for r in sc.rows if pred_c(inv(r[1]))]

    def box(lo, hi):
        return lambda c: all(lo[i] <= c[i] <= hi[i] for i in range(3))

    def cyl(ap, ad, rad, lo, hi):
        return lambda c: abs(axis_dist(c, ap, ad) - rad) < 0.3 and all(lo[i] <= c[i] <= hi[i] for i in range(3))

    def top_pred(c):          # base top without the boss footprint and the hole mouths
        return (box((9, 1, 7.7), (59, 39, 8.3))(c) and math.hypot(c[0] - 44, c[1] - 20) > 11
                and math.hypot(c[0] - 26, c[1] - 10) > 5 and math.hypot(c[0] - 26, c[1] - 30) > 5)

    return {
        "base_top": pk(top_pred),
        "bottom": pk(lambda c: box((1, 1, -0.3), (59, 39, 0.3))(c) and math.hypot(c[0] - 26, c[1] - 10) > 5
                     and math.hypot(c[0] - 26, c[1] - 30) > 5),
        "wall_in": pk(lambda c: box((7.7, 1, 9), (8.3, 39, 39))(c) and math.hypot(c[1] - 20, c[2] - 26) > 6),
        "wall_out": pk(lambda c: box((-0.3, 1, 1), (0.3, 39, 39))(c) and math.hypot(c[1] - 20, c[2] - 26) > 6),
        "wall_top": pk(box((1, 1, 39.7), (7, 39, 40.3))),
        "y0": pk(lambda c: abs(c[1]) < 0.3 and ((1 < c[0] < 59 and 1 < c[2] < 7) or (1 < c[0] < 7 and 1 < c[2] < 39))),
        "y40": pk(lambda c: abs(c[1] - 40) < 0.3 and ((1 < c[0] < 59 and 1 < c[2] < 7) or (1 < c[0] < 7 and 1 < c[2] < 39))),
        "x60": pk(box((59.7, 1, 1), (60.3, 39, 7))),
        "boss_top": pk(lambda c: abs(c[2] - 18) < 0.3 and math.hypot(c[0] - 44, c[1] - 20) < 9),
        "boss": pk(cyl((44, 20, 0), (0, 0, 1), 10, (30, 5, 9), (58, 35, 17))),
        "hole1": pk(cyl((26, 10, 0), (0, 0, 1), 4, (20, 4, 1), (32, 16, 7))),
        "hole2": pk(cyl((26, 30, 0), (0, 0, 1), 4, (20, 24, 1), (32, 36, 7))),
        "wall_hole": pk(cyl((0, 20, 26), (1, 0, 0), 5, (1, 10, 18), (7, 30, 34))),
    }
