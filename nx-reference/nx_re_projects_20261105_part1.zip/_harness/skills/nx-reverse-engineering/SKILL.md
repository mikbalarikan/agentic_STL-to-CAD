---
name: nx-reverse-engineering
description: Reverse engineering inside Siemens NX 2206 with NXOpen Python journals - rebuilding clean, editable CAD from scan data (STL / convergent facet bodies). Covers STL import, aligning the scan with fitted datums and Move Object, selecting facet regions, Fit Surface (plane, cylinder, cone, sphere, freeform) with radius / axis snapping, Section and Intersection curves of the mesh, Fit Curve on mesh points, turning fitted surfaces into a solid (sketches on fitted datums, Replace Face, Extend + Trim + Sew, Thicken), rounding fitted values to design intent, and the signed scan-to-CAD deviation check. Use when the input is an STL, 3D scan, mesh or facet body and the deliverable is a native parametric NX part, when a journal must measure a scan (plane, hole diameter, axis), or when a rebuilt model must be proven against the scan. Not for fully automatic mesh-to-STEP jobs outside NX (use the stl-re-* / stl2step-* skills).
---

# Reverse engineering in NX (scan -> native CAD)

Headless NXOpen Python on NX 2206 (`nx-journal-core`: launcher, `nxh`, `nxf`). Evidence tags: `[mined]` =
the user's 639 distinct parts (132 hold a convergent body, 70 use Fit Surface / Fit Curve / Flattening),
`[verified]` = measured by the journals in `scripts/` on scans with known truth (0.02 mm noise).
Code and numbers: `references/nxopen-recipes.md`; the user's statistics and tree excerpts:
`references/user-practice.md`; helper module: `scripts/nxre.py`.

Downstream steps are not repeated here: sheets (Extend, Trim, Sew, Thicken, Through Curves) are in
`nx-surface-modeling`, splines and section curves in `nx-curves-and-sketches`, face edits (Replace Face, Offset
Region) in `nx-synchronous-modeling`, STL / STEP import in `nx-journal-core/references/import-export.md`.

## The idea

A scan is an **underlay**, not geometry to convert. The user never "surfaces the mesh": he fits a few exact
primitives where the design intent is a plane, cylinder or cone, turns them into datums and faces, and models
the part with ordinary features on top `[mined]`. 31 of his 60 Fit Surface parts contain a single fit; 52
of the 60 contain sketches and 46 extrudes. The result is a native, editable feature tree that happens to
agree with the scan.

## Pick the approach

| Situation | Approach | Evidence |
|---|---|---|
| Prismatic / turned part: planes, holes, bosses, cones | **Fitted primitives -> values -> ordinary features.** Fit, read position / radius / axis, snap to the design grid, build with sketches, extrudes, holes | `[verified]` volume = truth after snapping, scan RMS 0.020 = noise. `[mined]` W1, the dominant pattern |
| A rough solid exists (first-pass extrude) and its faces must land on the scan | **Fit Surface -> Replace Face** (offset 0) | `[mined]` 167 Replace Faces on fits; `[verified]` blank -> within 0.0011 mm |
| Faces at odd angles, no sketchable profile (shell corners, chamfer-like flats) | **Fit planes -> Extend Sheet -> Trim and Extend / Trim Sheet -> Sew -> Trim Body or solid** | `[mined]` 170 Extend Sheet, 110 Trim and Extend, 44 Sew on fits; `[verified]` 6 planes -> solid |
| Thin cylindrical wall or rib | **Fit cylinder -> Thicken -> Unite / Replace Face** | `[mined]` 12 Thickens on fits (drive wheel) |
| Round feature seen in one section; profile curve | **Points on a mesh section -> Fit Curve circle / line -> Extrude / Sweep** | `[mined]` Fit Curve -> Extrude 20; `[verified]` R 3.9968 for 4 |
| Truly freeform skin (fan volute, watch case) | **Splines / sections -> Through Curves / Mesh -> trim -> sew -> thicken** (surface skill); Fit Surface freeform only for a single smooth patch | `[mined]` 3 freeform fits in 639 parts; `[verified]` 0.004 mm on an R100 patch |
| Facets of a watch to cut films | **Splines on the mesh -> Through Curves strip -> Flattening and Forming -> lay out -> DXF** | `[mined]` W6, 156 flattenings |
| Unattended STL -> STEP, no NX history needed, many parts | **Not in NX**: `stl-re-orchestrate` (build123d pipeline with gates), `stl2step-build123d`, `stl2dxf-facet-film` | NX adds: associative fits on the scan, an editable native tree, interactive review by the user |

Do not use Fit Surface freeform to tile a whole part, and do not rebuild a plane / cylinder as a B-surface:
analytic faces are what make holes, offsets and synchronous edits work later.

## Workflow (the order the user follows) `[mined]` + `[verified]`

1. **Import** the STL as a convergent body (`nxre.stl_import`): one body per shell, one facet face (UF type
   67), no edges. Check `IsSolidBody` and the volume; fix units with Scale Body (the user scaled meshes x10).
   Name it, keep it on its own layer; it stays in the part as the reference.
2. **Align** before anything else (journal helpers: `nxre.alignment` + `nxre.apply_alignment`, next
   section). Fit the seating plane and the main axis (cylinder fit or fitted circle),
   make a datum plane / axis / CSYS on them, Move Object the scan onto the absolute datum CSYS, then correct
   with small displacement / angle moves (0.65-1 mm, 8.4 / 16.8 deg in his parts). Journal equivalent
   `[verified]`: plane normal -> rotation angle -> Move Object angle; re-fit three datum faces -> Move Object
   delta; re-fit to prove it (0.00015 mm, 0.005 deg). Rebuild the facet cache after every move.
3. **Fit the primitives of one area in a batch** (201 of 332 plane fits follow another plane fit), each on
   its own facet region, as sheets. Cones (and some cylinders) as solids with a constrained axis when they are
   to be boolean or trim tools.
4. **Turn fits into design values**: read position / radius / axis, snap (section "Snapping"), store as
   named expressions.
5. **Build** by one of the routes of the table: datum plane on the fit (offset 0) -> sketch -> extrude;
   Replace Face; Extend Sheet -> corner -> Sew -> Trim Body. Extend first: a fitted plane sheet only covers
   its facet region.
6. **Finish like any part**: blends, chamfers, holes, synchronous clean-up (Offset Region, Replace Face,
   Delete Face) - see the sibling skills.
7. **Check the deviation** of the rebuilt body against the scan after every stage, not only at the end.

Cutting the scan: the user isolates a region with Split Body (extruded sheet or datum plane) + Delete Body,
never Trim Body `[mined]`; both work `[verified]`. Extract Body first if the full scan is still needed.

## Unknown part: describe -> census -> datum frame -> table -> rebuild -> deviation `[verified]`

When nothing is known about the scan (no drawing, no positions), do not guess regions. `re_unknown_part.py`
runs this chain on a 111 k-facet scan turned by two rotations; every number below is from it.

1. **Describe**: `stl_import`, facet count, `IsSolidBody`, bounding box, volume. Cache with
   `nxre.Scan(part, scan)` (up to ~100 k facets) or `nxre.Scan(part, scan, every=k)` for bigger scans.
2. **Census**: `cen = nxre.census(scan_cache)` (pure Python, seconds) -> `planes` (outward normal, offset,
   area, least-squares RMS, facet `rows`), `cylinders` (boss / hole, axis, point, radius, extent, `rows`),
   `noise` (median plane RMS = the scan's sigma), `bbox`, `mesh_area`, `datums` (proposal: the largest plane,
   the largest plane square to it, the outermost plane square to both). Measured: all 9 planes and 4
   cylinders of the bracket and nothing else, noise 0.0192 for a true 0.02, radii within 0.004 mm. Census
   areas run a few percent low (0.96-1.02 of the true face areas) and its regions include edge facets. Read the
   list as a part description before deciding anything; `nxre.jsonable(cen)` for the report.
3. **Decide the datum frame**: accept or replace the proposed datums (functional seating face first, a
   locating face or axis second). Refine the three planes with `nxre.measure_plane(part, rows)` (a Fit
   Surface that is undone again) and build `al = nxre.alignment(primary, secondary, tertiary=...)`.
   **Rule: no Move Object when the three datum planes are already within 0.01 mm and 0.02 deg of the
   absolute planes**; otherwise `nxre.apply_alignment(part, [scan], al)` - ONE Move Object rotation about a
   general axis through the datum origin plus one translation - then re-cache and re-measure the residual
   (0.00002 mm / 0.005 deg here; rotation recovered to 0.004 deg, origin to 0.003 mm; the moved facets sit
   where `nxre.transform_point(al, p)` predicts to 1e-13 mm).
4. **Fit-and-snap table**: run `census` again on the aligned cache and feed its regions to
   `nxre.fit_table(part, regions, grid, tol)` with the principal axis nearest each normal as design direction.
   It fits free, fits constrained, snaps, and returns report rows (fitted, tilt, constrained, snapped,
   difference, RMS free / constrained / about the snapped geometry) without leaving features in the tree;
   `keep=True` keeps one named constrained fit per region. Accept a snap when `snap_ok` and the RMS about the
   snapped geometry equals the free-fit RMS; investigate every row that does not.
5. **Rebuild** from the snapped values with named expressions and ordinary features (section "Workflow" 5-6).
6. **Signed deviation with percentiles**: `nxre.signed_deviation(part, body, scan.vertices(n=1500),
   threshold=3 * cen["noise"], regions={name: rows})` -> RMS, signed mean, |d| p50 / p95 / p99, worst point,
   share over the threshold, and the same per region.
7. **Iterate** while any region's signed mean exceeds ~0.75 x noise (that face is offset: re-fit it, check its
   snap) or the share over 3 x noise is above a few percent away from unmodelled blends. A CAD body 0.05 mm
   too high flagged exactly the four faces normal to Z and no other region.

## Selecting the facet region `[verified]`

The fit is only as good as the region. Rules come from `part.FacetSelectionRuleFactory` and go into the
builder's own `FacetCollector`.

| Rule | Use | Measured |
|---|---|---|
| explicit list - `nxre.rule_facets(part, scan.pick(pred))` | default in a journal: you decide by position / normal which facets belong to the face (the GUI's rectangle / lasso) | 10 705 facets in one rule, fit in 0.3 s |
| primitive region - `nxre.rule_primitive(part, seed, 1.0)` | clean meshes (CAD exports, good scans): one seed facet grows over the whole plane / cylinder / cone / sphere | clean: whole face. Noise 0.02 mm: 515 of 7699 plane facets, 284 of 1134 hole facets |
| tangent - `nxre.rule_tangent(part, seed, deg)` | smooth regions bounded by sharp edges | clean 30 deg = whole cylinder; noisy: unreliable |

- `nxre.Scan(part, body)` caches every facet (centroid, normal, vertices). Reading a facet costs more the
  bigger the body is: 0.09 ms per facet on 46 k facets (4 s), 0.36 ms on 111 k (40 s) - roughly quadratic
  in the facet count. For larger scans pass `every=k` (reads every k-th facet; census, fits and deviation
  samples work on the thinned cache), or split the scan to the region first. Enumerating facet objects is
  cheap (3 microseconds each); NX does not keep the STL triangle order, so the file cannot replace the read.
- Keep 0.5-1 mm away from edges, blends and neighbouring features; exclude hole mouths and boss footprints
  from a plane region.
- A cylinder region must cover most of the circumference: a 90 deg strip of a hole gave radius -0.013 mm
  (-0.24 mm on a second, 1.5 mm mesh) and the axis 0.013-0.24 mm off. Count the facets before trusting a rule.
- Selecting by normal on a noisy mesh leaves holes and islands in the region; select by position.

## Fit Surface `[verified]`

`nxre.fit_surface(part, rules, kind, reject=None, radius=None, axis=None, half_angle=None, solid=False)` ->
feature `Fit Surface(Plane | Cylinder | Cone | Sphere | Freeform)`; `nxre.fit_face(feature, nxh.PLANE)` ->
face and its parameters.

| Type | Accuracy on a 0.02 mm-noise scan | User setting `[mined]` |
|---|---|---|
| Plane | position <= 0.0005 mm, normal <= 0.010 deg (9 planes, 300-3400 mm2) | 154 of 187 fits; rejection off in 97, on (0.1 / 0.2 / 0.07) in 57 |
| Cylinder | radius -0.002 ... -0.003, axis 0.02-0.06 deg, axis position <= 0.001 mm | rejection on (0.1) in 21 of 23; radius typed in 12 of 23 |
| Cone | half angle 0.014 deg, axis 0.013 deg / 0.003 mm (free fit) | axis constrained in 8 of 8, solid in 6 of 8 |
| Sphere | radius +0.0007, centre 0.001 mm | not used |
| Freeform | max 0.004 mm from the true surface (degree 5 x 5, 1 patch) | 3 uses; degree 5, 1 patch, smoothing 0 |

Settings that matter:
- **`IsSingleSurface = True`** for one surface through everything selected. False makes one surface per
  connected island of the selection (2 patches -> 2 sheets; a ragged selection once gave 909).
- **Rejection threshold** (`IsAutomatic` + `RejectionThresholdValue`): the user's 0.1 mm (0.2 on rough scans,
  0.07 / 0.05 on fine ones). It drops outliers; it does not move a fit on clean regions.
- **`IsRadius` + `RadiusValue`**: fit with the radius fixed to the design value; **`IsConstrained` +
  `VectorConstraint`**: fix the plane normal / the axis (square to the datums, or parallel to an earlier
  fit). Both keep the scan RMS unchanged when the snap is right (0.0198 vs 0.0194).
- **Cone: never constrain the axis alone** - the fit collapsed to a half angle of 89.9 deg (RMS 3.5 mm).
  Fit free, or fix axis and half angle together (`IsHalfAngle` + `AngleValue`).
- **Radii of meshed cylinders read small** by about the chord error (-0.002 ... -0.003 mm at chord 0.005,
  more on coarse or decimated scans): another reason to snap.
- Output extent: plane = bounding rectangle of the region; cylinder / cone = full 360 deg over the region's
  axial length; freeform = the region patch. `BodyTypePreference = Solid` gives a capped solid.
- The fit stays associative to the scan; cached facet objects do not (rebuild `nxre.Scan` after moves).

## Sections and Fit Curve `[verified]`

- Section Curve on the convergent body (`nxre.section_curves(part, scan, datum_plane)`) gives one degree-1
  spline per loop through the facet crossings. It is 0.4-2 % too long on a noisy mesh (200.82 for 200.00):
  never take a dimension from the raw section. A plane that passes through mesh vertices loses loops (1 of
  2 at z = 13.0, both at z = 14.3): shift it slightly and count the loops.
- Intersection Curve works on the scan too but returns hundreds of pieces (126 for 3 loops) - the user uses
  it (9 times) and then trims / sketches over it.
- **Fit Curve works on points only** (`TargetSourceType.SpecifiedPoints`, the user's setting in 39 of 39).
  Get the points with `scan.slice(axis, value)` filtered to the feature, `nxre.points(...)`, then
  `nxre.fit_curve(part, pts, "circle" | "line" | "spline", reject=0.07, radius=None, closed=True)`. Curve,
  face and facet-body targets fail: "Unable to fit curve due to insufficient number of fitting points".
- Measured: hole R 3.9968 for 4 (centre 0.007 mm off), boss R 9.9985 for 10, a 150 deg arc R 9.9983, a
  line 0.003 deg / 0.006 mm; `HasRadius` snaps the radius exactly. The fit is a curve feature: extrude it
  (`nxh.section_feature`) or project it into a sketch (the user: `Fit Curve > POINT > CPROJ > SKETCH`).
- User values `[mined]`: threshold 0.07 (20) / 0.1 (8); arcs for partial features with 0.35-0.45 mm
  extension, lines with 3-70 mm extension so they overshoot; typed radii such as 2.96, `5.80/2`, 15.45.
- Prefer a **cylinder fit over a circle fit** when the wall is visible over some height (axis direction
  comes with it); use the circle fit for thin walls, sheet-metal holes and arcs of blends.

## Snapping to design intent

A fitted 9.9969 radius is a 10 mm radius; a plane at 39.9989 is at 40. Procedure `[verified]`:
1. Fit with the direction constrained where the intent is "square to the datums".
2. `nxre.snap(value, grid=0.5, tol=0.05)`: take the grid value when the fit is within the tolerance,
   otherwise keep the fit rounded to 0.01 and flag it. Choose the grid from the part (0.5 or 1 mm for
   plastic housings and brackets; the user types radii on a 0.05 mm grid: 3.95, 4.45, 3.05, 14.06).
   The tolerance must be larger than the scan noise and smaller than half the grid.
3. Give priority to functional values (standard hole sizes, bearing seats, equal wall thickness, symmetric
   positions) over the scan when they disagree by less than the scan accuracy; a caliper value from the user
   beats both.
4. **Re-check the deviation after snapping.** A correct snap leaves max and RMS unchanged (0.0615 -> 0.0617,
   RMS 0.0200); a wrong one shows at once (boss radius 10.5 instead of 10: max 0.549, p95 0.502).
5. Record every value as fitted -> chosen with the rule used.

Tolerance the user works to `[mined]`: rejection thresholds 0.05-0.2 mm (0.1 typical) and 0.05 mm rounding.
His parts store no deviation result, so nothing tighter can be claimed from them.

## Deviation check `[verified]`

- `nxh.dist_to(part, solid_body, xyz)` is **signed** on a solid: -1.000 one mm inside, +1.000 outside.
  `nxre.signed_deviation(part, solid, scan.vertices(n=700), threshold=None, regions=None)` -> min, max,
  mean, RMS, `abs_p50` / `abs_p95` / `abs_p99`, `worst` (point + value), `share_over` the threshold, and
  `regions[name]` with the same statistics per facet region; about 1.4 ms per point.
- `nxre.deviation(part, faces, pts)` is the unsigned distance to a face list: use it for one fitted sheet
  (pass the region's vertices) or for sheet bodies.
- Reading: RMS ~ scan noise and mean ~ 0 on a correct rebuild (0.0200 / +0.0006). Mean off zero = a face is
  offset; p95 or max far above 3 sigma with a normal RMS = one feature is wrong or missing; large values
  only near edges = blends not modelled yet.
- Also compare volumes: the watertight convergent body measures 31 147.6 against 31 149.0 for the CAD
  (-4.6e-5); a larger gap means missing or extra material. Sample the CAD -> scan direction too when the scan
  is incomplete (faces of the CAD with no scan points near them are unverified, not good).
- State the result with the numbers: n points, max, RMS, signed mean, and the regions excluded.

## Pitfalls `[verified]`

- `body.IsConvergentBody` is a property, `GetNumberOfFacets()` a method; after Trim Body the scan is a mixed
  body (facet face + exact planar caps) and body-level facet calls raise "Function expects a facet topology,
  but input given is a non-facet topology."
- `UFS.Std.PutSolidInStlFile(handle, 0, body.Tag, 0.0, max_edge, chord)`: the csys argument must be `0`.
- The fitted plane sheet is small: Extend Sheet (the user: 5-23 mm) before Trim Body / corners, and trim
  sheets against **datum planes placed on the fits** - trimming against already-trimmed neighbour sheets
  raised "Invalid retained/discarded regions."
- Replace Face onto a fitted sheet needs `ReverseDirection = True` for about half of the faces (3 of 6 here,
  15 of 39 in the user's parts): try, measure, undo, flip.
- Reading facets is the slow step and grows about quadratically with the facet count (4 s for 46 k, 40 s
  for 111 k): cache once, thin with `Scan(..., every=k)`, or cut the scan to the region first.
- **Never compare areas.** The mesh area of a noisy scan is above the CAD area (10 848 against 10 396 mm2,
  +4.4 %, at 0.02 mm noise on 1.5 mm triangles) although the volume agrees to 8e-5. Compare volume and
  signed deviation.
- Every Fit Surface used only to read a value stays in the tree unless it is undone: use
  `nxre.measure_plane` / `nxre.fit_table(keep=False)` (13 regions measured, 0 features left).
- STL export of a body with a cone and a spherical dome reported 1 error although the file was complete:
  verify an export by re-import (closed convergent solid, volume), not by the error count.
- Best Fit Align (`part.FacetedBodies.CreateBestFitAlignBuilder`, scan onto a CAD body) moves the scan but
  stopped at RMS 0.17 mm from a 2 deg / 1.3 mm misalignment (0.68 before, 0.02 reachable): use the datum
  alignment. Detect Primitives and Snip Facet Body at a plane committed without changing the body; Divide
  Facet Face, Deviation Gauge and Flattening and Forming were not probed (`references/nxopen-recipes.md`
  sections 8-9).

## Scripts (each writes `<name>.json` with `"result"`)

| Script | Proves |
|---|---|
| `scripts/nxre.py` | helper module: STL in / out, scan-like test meshes, `Scan`, region rules, `fit_surface`, `fit_curve`, `section_curves`, `census`, `alignment` / `apply_alignment`, `measure_plane`, `fit_table`, `deviation`, `signed_deviation`, `snap`, truth bracket |
| `scripts/re_unknown_part.py` (36 checks) | unknown, rotated, noisy scan end to end: census, datum frame by a general rotation, measure-only fit-and-snap table, signed deviation with percentiles and per-region means, offset detection |
| `scripts/re_fit_surfaces.py` (48 checks) | import, region rules, plane / cylinder / cone / sphere / freeform fits against truth, snapping, traps |
| `scripts/re_sections_fitcurve.py` (27 checks) | sections of the scan, Fit Curve circle / arc / line / spline, extrude of a fitted circle, Move / Extract / Scale / Trim / Split on the convergent body |
| `scripts/re_rebuild_compare.py` (23 checks) | alignment, 13 fits -> 21 snapped parameters -> parametric solid, volume and deviation against truth and scan, wrong-snap detection, Replace Face route, Extend + Trim + Sew route |

Run: `run_journal.ps1 -Script <script> -WorkDir <dir> -JArgs <out dir>`. The launcher sets `NXH_DIR` and
`NXRE_DIR`; in any journal:

```python
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
import nxh, nxf, nxre
```

## Worked examples (real jobs, not part of the regression suite)

`examples/dreame_brush_core_with_bristles/` - a twisted moulded core with bristle tufts rebuilt from two
scans: checking a supplied "reference" CAD against the scan first, twist measured by untwisting the point
cloud, twisted cuts as Swept tools with an angular law, a second scan registered by ICP for the hidden
underside, deviation by zone in both directions. Start with its `README.md`; `REPORT.md` is the delivered report.

`examples/dreame_bottom_cover/` - a large prismatic moulded frame (269 features) rebuilt from one warped,
open 4.8 M-triangle scan: measuring outside NX on the aligned mesh (stacked sections, line / arc fits),
de-warping for measurement only, stepped troughs as an envelope block with one void profile per zone, a
revolved bowl beside a lofted one, a skew-extruded skin, staged builds checked by section overlays, deviation
with named artefact masks. Band not met (p95 0.59 mm); its `README.md` lists the numbers and the traps.
