# Dreame ana fırça çekirdeği (kıllı) — NX 2206 ile parametrik kurulum (2026-10-08)

Kıllı çekirdek taramasından (`dreame_brush_core_with_bristles`) ve taban taramasından (`dreame_brush_base`) ölçü
alınarak NX'te **sıfırdan, feature tabanlı** kurulmuş modeldir: 1 katı çekirdek gövdesi + 54 ayrı kıl demeti gövdesi,
13 tam kısıtlı eskiz, 61 üst düzey feature, 76 adlandırılmış ifade.

**Önce okunması gereken iki şey**

1. **`brush_core_no_bristles CAD.prt` bu çekirdeğin kılsız hali değil, öbür fırçanın çekirdeği.** Kanat sayısı,
   kanal sayısı, flanş çapları ve burulma farklı (aşağıda tablo). Bu yüzden referans geometri olarak alınamadı;
   yalnız kurgu ve kalite ölçütü olarak kullanıldı ve kıllı çekirdek baştan kuruldu. Bu kararı sorup cevap
   beklemeden verdim; istenen "referansa yalnız taban + kıl eklemek" ise ayrıca yapılmalı (bkz. "Açık karar").
2. **Bant durumu** (bu iş için bant verilmedi; önceki işlerdeki plastik bandı ölçüt aldım: p95 ≤ 0,30 / max ≤ 0,80 mm):
   sert yüzeylerde tarama→CAD **p95 = 0,16 mm (karşılandı)**, **max = 1,23 mm (karşılanmadı)** — 645 115 noktanın
   240'ı (%0,04) 0,8 mm'yi aşıyor; nedenleri "Sapma" bölümünde. Kıllar yumuşak olduğu için banda dahil değil
   (p50 0,50 / p95 1,33 mm). CAD yüzeyinin %11'i hiçbir taramada görünmüyor (T-kanal ayakları, kıl delikleri, yuva dipleri).

## Teslim edilenler

| Dosya | İçerik |
|---|---|
| `dreame_brush_core_with_bristles.prt` | NX 2206 parametrik parça: `CORE` gövdesi + 54 `BRISTLE_TUFT` gövdesi |
| `dreame_brush_core_with_bristles.step` | AP242, 55 katı |
| `dreame_brush_core_with_bristles_with_scans.prt` | Aynı parça + katman 10'da kıllı çekirdek taraması (374 k üçgen), katman 11'de taban taraması (223 k üçgen); ikisi de CAD datum çerçevesinde |
| `dreame_brush_core_with_bristles_core.stl`, `_tufts.stl` | Sapma ölçümünde kullanılan CAD mozaikleri |
| `figures/` | Render'lar (CAD / tarama), sapma haritaları, kesit bindirmeleri (siyah = tarama, kırmızı = CAD), ölçüm grafikleri |
| `journal/` | Parçayı baştan kuran NXOpen journal (`build.py`, `nxlib/`), `review.py`, `run.ps1`, deneme journal'ları |
| `analysis/` | Tarama ölçüm ve sapma betikleri (numpy / open3d) |
| `qa/` | `build_checks.json` (63 kontrol), `masters.json`, hizalama matrisleri (`T_bristles.json`, `T_base.json`), ölçüm ve sapma JSON'ları |

Girdi dosyalarına dokunulmadı; hepsi `C:\NX_MCP_WORKSPACE\dreame_brush\in` altındaki kopyalardan okundu.

## Referans CAD ile kıllı tarama: iki ayrı çekirdek

| | `brush_core_no_bristles CAD.prt` (ve içine gömülü 2,9 M üçgenlik tarama) | Kıllı çekirdek taraması |
|---|---|---|
| Tahrik kanadı | 5 | 4 |
| Çekirdek kesiti | 5 kanal, dalgalı profil | 4 T-kanal + 2 küçük oluk + 2 geniş oluk |
| Taban flanşı / göbek diski | r 14,5 / r 13,4 | r 16,45 / r 15,2 |
| Burulma adımı | 326,6 mm/tur (Helix feature) | 225,8 mm/tur (ölçüldü) |
| Toplam boy | 169,8 | 169,75 |

Taban taramasında da iki uç var: flanşı r 16,3 olan (kıllı fırça; bu işte kullanılan) ve r 14,3 olan (kılsız fırça).
Kanıt: `figures/01_referans_ve_killi_tarama_farkli_cekirdek.png`.

**Referansın iki sürümü.** `brush_core_no_bristles CAD.prt` (19 Eylül) 112 adımlı bir ağaç; son gövdesi **katı değil,
178 yüzlü bir sheet**: altı açık (z = 0'da r 14,5 serbest kenar) ve iki helis dikişi dikilmemiş (5 serbest kenar).
`... CAD (1).prt` (2 Ekim) aynı model üzerinde devam etmiş: gövde katıya çevrilmiş (540 yüz), alta halka çanak ve
altıgen yuva eklenmiş. İkisi de 5 kanallı çekirdek; **hiçbiri geometri olarak temel alınmadı.** Referanstan alınan:
kurgu sırası (diskler → kanatlar → silindir → helis boyunca süpürülen kanal takımları → kenar yuvarlatmaları → uç
detayları). Bilgi için: referans gövdenin kendi gömülü taramasına sapması çekirdek boyunca p95 = 0,68 mm
(rulman ucuna doğru artıyor); bu modelin kendi taramasına sapması aynı bölgede p95 = 0,12–0,14 mm. Taramalar ve
parçalar farklı olduğu için birebir karşılaştırma değildir.

### Açık karar (kullanıcıya soruldu, cevap gelmeden A ile ilerlendi)

- **A (yapılan):** kıllı çekirdeği kendi taramasına göre baştan kurmak.
- **B:** referans CAD'i (5 kanallı çekirdek) koruyup yalnız tabanını kapatmak ve kıl sıralarını eklemek. Sonuç
  gerçek kıllı çekirdek olmaz (flanşta ≈ 1,9 mm, kesitte kanal sayısı farkı). İstenirse bu modelin kıl ve taban
  feature'ları referansa da uygulanabilir; ölçüler ifadelerle değişir.

## Koordinat sistemi ve hizalama (Datum CSYS = kıllı tarama datum çerçevesi)

- **Z** = fırça ekseni: tahrik ucundaki göbek diskinin (r 15,2) merkezi → rulman ucundaki yuvanın (r 5,88) merkezi; +Z rulman ucuna.
- **z = 0** = flanşın alt yüzü (taramada parçanın tablaya oturduğu düzlem). **X** = 0 numaralı tahrik kanadının düz kenarının yönü.
- Açılar derece, +Z'den bakınca saat yönünün tersine; burulan özelliklerin açıları `z_core0` yüksekliğinde verilir.

Kıllı tarama (`qa/T_bristles.json`, `qa/m1_align.json`): önceki denemenin matrisi başlangıç alındı, düzlemler ve eksen
yeniden ölçüldü. Kalıntı: çekirdek sırtlarının merkezi 140 mm boyunca eksenden ≤ 0,04 mm; kanat üst düzlemi eksene
0,03° eğik. Tabla düzlemi eksene 0,28°, flanş basamağı 0,21° eğik (düzeltilmedi; flanş yüksekliğinde ±0,08 mm belirsizlik).

Taban taraması (`qa/T_base.json`): yalnız r 16,3'lük uç alındı; çekirdek taramasıyla örtüşen yüzeylerde (göbek diski,
kanatlar, çekirdek kökü) noktadan-düzleme ICP, 36 başlangıç açısından. Örtüşme kalıntısı rms 0,051 mm (0,3 mm içinde
kalan %56'lık pay). İki durum açıkça yazılmalı:
- ICP 180° belirsiz (çekirdek 2 katlı simetrik). Altıgen ve çukur çiftleri için fark etmez; alt yüzdeki tek kabarcık
  (aşağıda) bu yüzden modellenmedi.
- Taban taramasında alt yüzün tamamı (çanak duvarı, halka, altıgen) göbek diskine göre **0,23 mm kaçık**. Kalıp
  yarıları arası kaçıklık ya da tarama içi bozulma olabilir; ayırt edilemedi. Modelde eş merkezli kuruldu; alt yüz
  sapması için taban taraması çanak duvarına göre yanal kaydırıldı (`qa/m7_recentre.json`), kaydırmasız sayı da verildi.

## Feature ağacı (61 üst düzey adım)

| Grup | Feature'lar | Not |
|---|---|---|
| Taban | `SK_BASE` → `BASE` (Revolve) | Flanş + göbek diski + göbek, **alt çanak ve halka profilin içinde**; flanş alt kenar pahı |
| Alt yüz detayları | `PIT_DISH`, `PIT`, `EJECTOR_MARK` (Cylinder-Subtract) + 3 Pattern Feature (2'şer) | Çukur çifti ve itici izi çifti |
| Tahrik kanatları | `SK_BLADE` → `BLADE` (Extrude-Unite) → `BLADE_PATTERN` (4) | Profil teğet kısıtlı: düz kenar, köşe R, dış yay, taç yayı, arka duvar |
| Çekirdek | `CORE_CYLINDER`, `SK_HEX` → `HEX_SOCKET` | Sırtlar analitik silindir yüzü olarak kalır |
| Burulan kesimler | `DP_CORE0` + 2 datum ekseni, `SK_AXIS` (kılavuz); her biri için eskiz → Swept (açısal yasa) → Pattern Geometry → Subtract: `SLOTS` (4), `SMALL_GROOVES` (2), `WIDE_GROOVES` (2), `CENTRE_GROOVES` (2; iki Trim Body ile baş/son) | Kesit bir kez çizilir; açı ve burulma ifadelerden gelir |
| Kenar yuvarlatmaları | `SLOT_MOUTH_BLEND` (8 helis kenar), `SMALL_GROOVE_BLEND` (4), `WIDE_GROOVE_BLEND` (4) | Üçü de kuruldu |
| Rulman ucu | `SK_IDLER_BORE` → `IDLER_BORE` (Revolve-Subtract), `SK_END_CHAMFER` → `END_CHAMFER`, `SK_KEY_NOTCH` → `KEY_NOTCH` | Yuva + delik, 45° pah, anahtar çentiği |
| Kıl delikleri | `SK_TUFT_HOLE` → `TUFT_HOLE_TOOL` (Revolve) → `..._CLOCK` (Move Object) → `..._ROW_2` (Pattern Geometry, 2) → `TUFT_HOLE_TOOLS_ROW_1/2` (Pattern Geometry [Helix], 27'şer) → `TUFT_HOLES` (Subtract) | 54 delik |
| Kıl demetleri | `SK_TUFT` → `TUFT` → `TUFT_CLOCK` → `TUFT_ROW_2` → `TUFTS_ROW_1/2` | 54 ayrı katı; kök, deliği tam doldurur |

Eskizlerin tamamı tam kısıtlı (13/13 `WellConstrained`, DOF 0, otomatik ölçü 0; 87 eskiz ölçüsünün hepsi ifade ya da
ifade formülü). Kesit eskizlerindeki köşe koordinatları sayı değil, ana ifadelerden türeyen formüllerdir.

### Ana ifadeler (tam liste: `qa/masters.json`)

| Bölge | İfadeler |
|---|---|
| Genel | `h_total` 169,75 · `twist_lead` 225,75 (sol el) · `z_core0` 6,5 · `d_core` 14,95 |
| Taban | `d_rim` 32,9 · `h_rim` 3,35 · `d_hub` 30,4 · `z_floor` 4,65 · `d_hub_in` 9,9 · `rim_cham_r/z` 0,8 / 1,3 |
| Alt yüz | `d_recess` 23,0 · `z_recess` 3,7 · `d_boss` 10,0 · `z_boss` 3,47 · `hex_af` 5,8 · `hex_ang` 3,5° · `hex_depth` 6,6 · `pit_r` 7,93 · `pit_ang` 139,5° · `pit_d` 1,5 · `pit_depth` 0,65 · `dish_d` 3,6 · `ej_r` 8,35 · `ej_ang` 46° |
| Kanat | `n_blade` 4 · `blade_edge` 1,14 · `d_blade` 30,3 · `blade_crown_R` 4,95 · `blade_wall` 0,45 · `blade_corner_R` 0,5 |
| T-kanal | `n_slot` 4 · `slot_ang0` 1,1° · `slot_w` 1,25 · `slot_neck_r` 6,05 · `slot_foot_w` 2,2 · `slot_floor_r` 4,88 · `slot_mouth_R` 0,25 |
| Oluklar | `sg_ang0` 59,9° · `sg_R` 0,92 · `sg_floor_r` 6,935 · `vg_ang0` 135,65° · `vg_floor_r` 6,59 · `vg_floor_w` 2,6 · `vg_flank_ang` 13,7° · `ag_R` 1,65 · `ag_floor_r` 6,25 · `z_ag0` 33 · `ag_end_gap` 6,25 |
| Rulman ucu | `d_cbore` 11,75 · `cbore_depth` 1,2 · `d_bore` 8,6 · `bore_depth` 4,95 · `end_cham` 1,05 · `notch_ang` 201,3° · `notch_w` 2,25 · `notch_h` 1,5 |
| Kıllar | `n_tuft` 27 · `tuft_pitch` 4,9 · `tuft_z0` 10,55 · `tuft_ang0` 36,1° · `d_tuft_hole` 2,0 · `tuft_hole_depth` 3,0 · `tuft_lean` 40° · `d_brush` 37,0 · `d_tuft_tip` 3,2 |

Değerler taramanın gürültü tabanına (sırtlarda 0,02–0,03 mm) göre 0,05 mm ızgarasına yuvarlandı; z ve çap değerlerinde
ölçülen ile seçilen arasındaki fark ≤ 0,03 mm. **Ölçek kumpasla doğrulanmadı (yalnız tarama).**

## Tabanda ne değişti

| | Önce | Şimdi |
|---|---|---|
| Referans CAD (19 Eylül) | Alt yüz yok: gövde z = 0'da açık bir sheet | — (başka çekirdek) |
| Reddedilen önceki sonuç | Alt yüz taranmadığı için düz ve kapalı varsayılmış | — |
| Bu model | — | Ø23 × 3,7 derinlikte çanak; ortada Ø10, yüzü z = 3,47 olan halka; içinde AF 5,8 × 6,6 derinlikte altıgen yuva; r 7,93'te iki çukur (Ø1,5, çevresinde Ø3,6 sığ çanak); r 8,35'te iki itici izi; flanş alt kenarında 0,8 × 1,3 pah |

Alt yüzün taban taramasına sapması (131 k nokta; çanak zemini ve duvarı, halka, altıgen duvarları, keçe şeridinin içindeki flanş alnı):

| Hizalama | rms | p50 | p95 | p99 | max | > 0,3 mm |
|---|---|---|---|---|---|---|
| ICP + çanak duvarına göre yanal kaydırma (0,23 mm) | 0,101 | 0,043 | **0,208** | 0,406 | 1,086 | %2,0 |
| Yalnız ICP | 0,131 | 0,065 | 0,258 | 0,406 | 0,855 | %2,7 |

En büyük fark modellenmeyen kabarcıkta (r 8,67, 174°; ≈ Ø2, 0,55 mm yüksek). Altıgen duvarları: p95 0,30 mm.

## Kıllar nasıl modellendi

- **Sayı ve dizilim (ölçülen):** 2 sıra × 27 demet. Kökler z = 10,7 … 138,3; adım 4,909 / 4,903 mm (doğru fit kalıntısı
  0,18 / 0,12 mm) → `tuft_pitch` 4,9, `tuft_z0` 10,55. Sıralar çekirdek burulmasını izliyor; `z_core0`'a indirgenmiş açı
  37,0° ve 215,1° → model 36,1° ve 216,1° (tam 180° aralık; ölçülen 1,9° asimetri = kökte ±0,14 mm, kök saçılımının altında).
- **Delik:** kök genişliği 2,03 mm → `d_tuft_hole` 2,0. **Derinlik (3,0) ve delik ekseninin demet ekseniyle aynı olduğu varsayımdır** (delikler kılla dolu).
- **Yatma:** demetler radyalden rulman ucuna doğru yatık: kökte 41° / 47° (kabuktan kabuğa kayma), kök kesitinin
  uzaması 3,2 / 2,03 → ≈ 50°, uç zarfından ≈ 38° ± 15° yelpaze → `tuft_lean` 40°. Teğetsel yatma (−7 … −10°) modellenmedi.
- **Boy:** uç yarıçapı p98 = 18,3–18,6 mm → `d_brush` 37,0; serbest boy = (d_brush/2 − d_core/2) / cos(tuft_lean) = 14,4 mm.
- **Biçim:** her demet ayrı bir katı: delik içinde ve 1 mm dışına kadar Ø2 silindir, sonra uçta Ø3,2'ye açılan koni.
  **Uç çapı varsayımdır**: gerçek demetler ±15° yelpazelenip r > 16'da tek bir şerit halinde birleşiyor.
- **Süren ifadeler:** `n_tuft`, `tuft_pitch`, `tuft_z0`, `tuft_ang0`, `twist_lead` (helis açısal adımı = 360·tuft_pitch/twist_lead),
  `tuft_lean`, `d_brush`, `d_tuft_hole`, `tuft_hole_depth`, `d_tuft_tip`. Sıra sayısı kurgu gereği 2'dir (ifade değil).
- **Taramaya sapma (yumuşak bölge, banda dahil değil):** tarama→(çekirdek + demetler) p50 0,50 / p95 1,33 mm, %24'ü > 0,8 mm;
  demet yüzeyi→tarama p50 0,45 / p95 1,76 mm (yarıçapa göre medyan 0,31 mm'den uçta 0,86 mm'ye).

## Doğrulama (kurucu tarafından yapıldı — bağımsız QA değildir)

| Kontrol | Sonuç |
|---|---|
| Journal kontrolleri (her feature'dan sonra hacim farkı, gövde sayısı, yüzey üstü nokta, feature hatası) | 63 / 63 geçti |
| Eskizler | 13 / 13 DOF 0, otomatik ölçü 0 |
| Burulmalı Swept'in gerçek helikoitten sapması (nokta sondajı, 4 yükseklik) | ≤ 0,004 mm |
| Examine Geometry (çekirdek + 54 demet) | Tüm sayaçlar 0 |
| Regenerasyon: 12 ana ifade tek tek değiştirildi → güncelle → kontrol → geri al | 12 / 12 hatasız; her seferinde hacim nominale döndü (bağıl 10⁻⁶ içinde) |
| STEP AP242 → NX'e geri okuma | 55 katı, en büyük bağıl hacim farkı 3,0·10⁻⁵, geri okunan 55 gövdede Examine Geometry bulgusu 0 |
| Teslim edilen `.prt` kopyasının yeniden açılıp okunması (as-found) | 61 feature, bastırılmış 0, hatalı 0; 55 katı (çekirdek 26 991,42 mm³, demet başına 84,93 mm³); 76 adlandırılmış ifade |

Regenerasyon testinde değiştirilenler ve ölçülen etki: `twist_lead` 250 (kanal duvarı yeni helisin üstünde, 0,002 mm) ·
`hex_af` 6,0 (ΔV 13,489 = beklenen) · `d_rim` 34 (ΔV 191,82 = beklenen) · `slot_w` 1,5 · `n_tuft` 20 (41 katı, 14 delik
kapandı) · `tuft_pitch` 5,5 (son demet 143,0 mm ötede) · `tuft_lean` 25 · `d_brush` 40 (demet hacmi 95,51 = beklenen) ·
`h_total` 160 · `z_recess` 3,2 · `vg_floor_r` 6,8 · `n_blade` 3. `n_slot`, `n_sg`, `n_vg` ve kenar yuvarlatma yarıçapları
**denenmedi**. İlk koşuda `h_total` 160 hata verdi (orta oluğun bitiş düzlemi mutlak yükseklikteydi); bitiş rulman
ucuna bağlandı (`ag_end_gap`) ve test yeniden koşuldu.

Doğrulanmayanlar: parça NX arayüzünde açılıp gözle incelenmedi (yalnız headless); kumpas ölçüsü yok; sapma ölçümü
tam çözünürlüklü taramanın her 2. üçgeniyle yapıldı; burulma ve kesit ölçüleri 20 MB'lık seyreltilmiş taramadan alındı.

## Sapma (tam çözünürlüklü kıllı tarama, 1,2 M örnek nokta; + = tarama CAD'in dışında)

Noktaların %4,8'i tabla, %41,4'ü kıl bölgesi (r > 7,825, z 6,9–162) olarak ayrıldı; kalan %53,8 sert yüzey.

| Tarama→CAD, sert yüzeyler | n | rms | p50 | p90 | p95 | p99 | max | > 0,3 | > 0,8 |
|---|---|---|---|---|---|---|---|---|---|
| **Tümü** | 645 115 | 0,088 | 0,035 | 0,105 | **0,159** | 0,370 | 1,234 | %1,67 | %0,04 |
| Tahrik ucu (z < 6,5) | 70 754 | 0,116 | 0,038 | – | 0,277 | 0,416 | – | %4,1 | %0,0 |
| Çekirdek z 6,5–30 | 105 608 | 0,094 | 0,035 | – | 0,143 | 0,416 | – | %1,9 | %0,1 |
| Çekirdek z 30–100 | 248 512 | 0,084 | 0,033 | – | 0,134 | 0,380 | – | %1,6 | %0,0 |
| Çekirdek z 100–160 | 181 589 | 0,072 | 0,032 | – | 0,119 | 0,283 | – | %0,9 | %0,0 |
| Rulman ucu (z > 160) | 38 652 | 0,101 | 0,059 | – | 0,197 | 0,296 | – | %1,0 | %0,0 |

0,8 mm'yi aşan 240 nokta: 146'sı kıl deliği ağızlarında (kıl kökleri; çekirdek değil), 87'si göbekteki bir kanal girişinin
yanındaki **modellenmeyen yerel girintide** (z 6,5–10; en büyük fark 1,23 mm, tarama CAD'in içinde), 7'si rulman ucunda
(`qa/dev_final_outliers.json`).

| CAD→tarama (iki taramadan yakın olanı), bölgeye göre | yüzey payı | p50 | p95 | 1 mm içinde tarama yok |
|---|---|---|---|---|
| Sırtlar ve çekirdek dış yüzleri | %32 | 0,035 | 0,106 | %0 |
| Oluklar ve kanal boyunları | %26 | 0,062 | 1,07 | %6 |
| T-kanal ayakları ve kıl deliği dipleri | %22 | 0,52 | 2,27 | %38 |
| Tahrik ucu, üst taraf | %12 | 0,056 | 0,34 | %0 |
| Alt yüz (çanak, halka, altıgen, çukurlar) | %5 | 0,062 | 2,08 | %18 |
| Rulman ucu ve delik | %3 | 0,137 | 2,08 | %18 |

Yani modelin görünen yüzeyleri taramayla 0,1 mm düzeyinde örtüşüyor; kanal içleri, delikler ve yuva dipleri taramada
olmadığı için **doğrulanmamış** sayılmalı, "iyi" değil.

## Bilinen sapmalar, varsayımlar ve sadeleştirmeler

1. **Referans temel alınmadı** (yukarıda); A/B kararı kullanıcıda.
2. **max ≤ 0,8 mm karşılanmadı**: kanal girişindeki yerel girinti (1 / 4 girişte var; hasar, kalıp izi ya da tasarım
   olduğu bilinmiyor) ve alt yüzdeki kabarcık modellenmedi.
3. **Altıgen yuva:** AF ağızda 5,66–5,73, derinde 5,8–5,9 ölçüldü (yalnız 4 yüz görünüyor) → 5,8 alındı; dibi
   görünmüyor, derinlik en derin duvar noktasıdır. Kumpasla doğrulanmalı.
4. **Kıl deliği derinliği, delik yönü, demet uç çapı varsayım**; teğetsel yatma ve sıralar arası 1,9° asimetri modellenmedi.
5. **Orta oluk** (geniş oluğun ortasındaki): taban yarıçapı taramada 6,06–6,47 arasında değişiyor (iki sırada farklı;
   çökme izi olabilir) → sabit 6,25; z = 33'te basamakla başlıyor (taramada 24–36 arası rampa), uçtan 6,25 mm önce bitiyor.
   Geniş oluk simetrik kuruldu (ölçülen yan eğimler 12,0° / 15,5°); rulman ucuna doğru sığlaşması (≈ 0,2–0,3 mm) modellenmedi.
6. **Sırt çapı** boy boyunca 14,91–15,07 (rulman ucunda açılıyor) → sabit Ø14,95.
7. **Tahrik ucu:** kanat üstleri taramada ±0,1 mm çanak → düz; kanat arka duvarının göbek dibindeki kancası, kanat ve
   flanş üst kenar yuvarlatmaları (≈ R0,1–0,3) modellenmedi; flanş yan yüzü hafif fıçı (r 16,37–16,46) → silindir;
   flanş alt kenarı yuvarlak görünüyor → 0,8 × 1,3 pah.
8. **Rulman ucu:** yuva ağzındaki iç yuvarlatma (≈ R0,36) yok; uç halkasında kanal boyunları taramada 0,6–1,0 mm
   görünüyor, modelde 1,25; delik dibi görülen en derin omuzdadır (z 164,8), daha derini bilinmiyor; anahtar çentiği
   kanalla örtüşen dikdörtgen kesim olarak sadeleştirildi.
9. **T-kanal ayağı** düz yanlı ve keskin köşeli; ayak yalnız boyundan görülebildiği için genişliği ±0,1 mm belirsiz.
10. **Alt yüz** eş merkezli kuruldu (taramada 0,23 mm kaçık); flanş alt düzlemi tabla düzleminden alındı, taban
    taramasında keçe şeridi nedeniyle ±0,1 mm'den iyi doğrulanamadı; çukurlar ve itici izleri düz silindir.
11. **Çekirdeğin içi dolu varsayıldı** (iç boşluk bilgisi yok).
12. Kenar yuvarlatmaları kenarları geometriyle seçiyor (kural değil); kanal / oluk sayısı değişirse yeniden seçmek gerekebilir.
13. Feature adları dosyada saklı (61 adımın 60'ı adlı, gövdeler `CORE` / `BRISTLE_TUFT`; teslim dosyasının kopyasından geri okundu); parça arayüzde açılmadığı için gezginde nasıl göründüğü kontrol edilmedi.

## Yeniden kurma

```
powershell -File journal\run.ps1 -Stage z      (journal içindeki yollar C:\NX_MCP_WORKSPACE\dreame_brush'a göredir; ≈ 8,5 dk)
```
Aşamalar: `a` taban ve kanatlar · `b` çekirdek kesimleri · `c` rulman ucu · `d` kıllar · `z` regenerasyon + STEP.
