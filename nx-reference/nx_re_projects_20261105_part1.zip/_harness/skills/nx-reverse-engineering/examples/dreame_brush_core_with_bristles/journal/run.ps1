param([string]$Stage = "z", [int]$Timeout = 1500)
# Runs the build journal up to a stage and prints the check table.   powershell -File run.ps1 -Stage z
$s = 'C:\Users\marya\.claude\skills\nx-journal-core\scripts'
$w = 'C:\NX_MCP_WORKSPACE\dreame_brush'
$t0 = Get-Date
& "$s\run_journal.ps1" -Script "$w\build.py" -WorkDir $w -JArgs "$w\out", $Stage -TimeoutSec $Timeout 2>&1 | Select-Object -Last 3
"elapsed " + [int]((Get-Date) - $t0).TotalSeconds + " s"
python "$w\show.py" "$w\out\build_$Stage.json"
