"""Probe 3: which setting sequence does the Helix layout of Pattern Geometry need?  -> out/probe3.json"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen, NXOpen.Features, NXOpen.GeometricUtilities as GU
import nxh, nxf

OUT = sys.argv[1]
res = {"result": "FAIL", "notes": {}}
N = res["notes"]
Z = (0, 0, 1)
try:
    part = nxh.new_part(os.path.join(OUT, "probe3.prt"))
    dat = nxh.Datums(part)
    nxh.expr(part, "n_tuft", 27, None)
    nxh.expr(part, "tuft_pitch", 4.9, "mm")
    nxh.expr(part, "twist_lead", 225.75, "mm")
    f1, b1 = nxh.cylinder(part, (9.0, 0, 20.0), (1, 0, 0), 2.0, 4.0)
    f2, b2 = nxh.cylinder(part, (-9.0, 0, 20.0), (-1, 0, 0), 2.0, 4.0)

    def helix(bodies, seq, axis):
        before = list(part.Bodies)
        b = part.Features.CreatePatternGeometryBuilder(NXOpen.Features.PatternGeometry.Null)
        try:
            psv = b.PatternService
            psv.PatternType = GU.PatternDefinition.PatternEnum.Helix
            hd = psv.HelixDefinition
            SO = type(hd).SizeOptions
            hd.RotationAxis = axis
            hd.DirectionType = GU.HelixPatternDirectionTypes.Lefthand
            if seq == "plain":
                hd.SizeOption = SO.CountAngleDistance
                hd.CountOfInstances.RightHandSide = "n_tuft"
                hd.AnglePitch.RightHandSide = "360*tuft_pitch/twist_lead"
                hd.DistancePitch.RightHandSide = "tuft_pitch"
            elif seq == "pitch_first":
                hd.SizeOption = SO.CountAngleDistance
                hd.HelixPitch.RightHandSide = "twist_lead"
                hd.CountOfInstances.RightHandSide = "n_tuft"
                hd.AnglePitch.RightHandSide = "360*tuft_pitch/twist_lead"
                hd.DistancePitch.RightHandSide = "tuft_pitch"
            elif seq == "like_probe2":
                for on in ("AngleHelixPitchAndSpan", "AngleHelixPitchAndTurns", "CountAngleDistance"):
                    hd.SizeOption = getattr(SO, on)
                    hd.CountOfInstances.RightHandSide = "n_tuft"
                    hd.AnglePitch.RightHandSide = "360*tuft_pitch/twist_lead"
                    if "Distance" in on:
                        hd.DistancePitch.RightHandSide = "tuft_pitch"
                    else:
                        hd.HelixPitch.RightHandSide = "twist_lead"
            elif seq == "count_pitch_turns":
                hd.SizeOption = SO.CountHelixPitchAndTurns
                hd.CountOfInstances.RightHandSide = "n_tuft"
                hd.HelixPitch.RightHandSide = "twist_lead"
                hd.NumberOfTurns.RightHandSide = "(n_tuft-1)*tuft_pitch/twist_lead"
            state = {k: getattr(hd, k).RightHandSide for k in ("CountOfInstances", "AnglePitch", "DistancePitch", "HelixPitch", "HelixSpan", "NumberOfTurns")}
            for body in bodies:
                b.GeometryToPattern.Add(body)
            f = b.CommitFeature()
        finally:
            b.Destroy()
        return f, nxh.new_bodies(part, before), state

    for seq, bodies, ax in (("plain", [b1], "smart"), ("plain", [b1, b2], "smart"), ("plain", [b1, b2], "datum"), ("pitch_first", [b1, b2], "smart"),
                            ("like_probe2", [b1, b2], "smart"), ("count_pitch_turns", [b1, b2], "smart")):
        key = "%s / %d bodies / %s axis" % (seq, len(bodies), ax)
        m = nxh.mark("try", False)
        try:
            axis = nxh.axis(part, (0, 0, 0), Z) if ax == "smart" else nxf.axis_from(part, dat.z)
            f, nb_, state = helix(bodies, seq, axis)
            cen = []
            for bb in nb_:
                x = nxh.bbox(bb)
                cen.append((round(math.degrees(math.atan2((x[1] + x[4]) / 2, (x[0] + x[3]) / 2)), 2), round((x[2] + x[5]) / 2, 3)))
            cen.sort(key=lambda t: t[1])
            N[key] = {"new_bodies": len(nb_), "first": cen[:3], "last": cen[-2:], "state": state}
        except Exception as ex:
            N[key] = "EXC " + str(ex)[:200]
        nxh.undo_to(m)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "probe3.json"), res)
