﻿"""Probe: twisted Swept of an OFF-AXIS section about the axis line (angular law), subtract from a cylinder,
Pattern Geometry of the tool, and the Helix layout of Pattern Feature.  -> out/probe1.json"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXBLADE_DIR"])
import NXOpen, NXOpen.Features, NXOpen.GeometricUtilities as GU
import nxh, nxf
import nxblade as nb

OUT = sys.argv[1]
res = {"result": "FAIL", "notes": {}}
N = res["notes"]
try:
    part = nxh.new_part(os.path.join(OUT, "probe1.prt"))
    K = 1.5946                       # deg / mm, left-hand
    Z0, Z1 = 6.5, 169.75
    L = Z1 - Z0
    cyl, body = nxh.cylinder(part, (0, 0, Z0), (0, 0, 1), 14.95, L)
    v_cyl = nxh.volume(part, body)
    N["v_cyl"] = v_cyl
    # T-slot-like tool along +X: neck 1.25 wide from r 6.05 out to r 8.2, foot to r 4.88 with half width 1.1
    pts = [(8.2, -0.625, Z0), (8.2, 0.625, Z0), (6.05, 0.625, Z0), (4.88, 1.1, Z0), (4.88, -1.1, Z0), (6.05, -0.625, Z0)]
    cs = nxh.polyline(part, pts)
    area = 0.0
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        area += a[0] * b[1] - b[0] * a[1]
    area = abs(area) / 2
    g = nxh.line(part, (0, 0, Z0), (0, 0, Z1))
    f = nb.swept(part, [nxh.section(part, curves=cs, help_point=pts[0], seed=cs[0])], [nxh.section(part, curves=[g], help_point=(0, 0, Z0), seed=g)],
                 orientation="angular", angles=(0, K * L), solid=True)
    tool = f.GetBodies()[0]
    N["tool_solid"] = bool(tool.IsSolidBody)
    N["tool_volume"], N["area_x_len"] = nxh.volume(part, tool), area * L
    N["tool_examine"] = {k: v for k, v in nxh.examine_geometry(part, tool).items() if v}
    N["tool_faces"] = nxh.face_census(tool)

    def rotz(p, deg):
        a = math.radians(deg)
        return (p[0] * math.cos(a) - p[1] * math.sin(a), p[0] * math.sin(a) + p[1] * math.cos(a))
    probes = {}
    for frac in (0.25, 0.5, 0.75, 1.0):
        zz = Z0 + frac * L
        for name, sgn in (("minus", -1.0), ("plus", 1.0)):
            worst = 0.0
            for p in (pts[2], pts[3], pts[4], (7.0, 0.625)):
                x, y = rotz(p, sgn * K * (zz - Z0))
                worst = max(worst, abs(nxh.dist_to(part, tool, (x, y, zz if frac < 1.0 else zz - 1e-6))))
            probes[f"{name}_{frac}"] = worst
    N["helicoid_probe_max_dist"] = probes
    # subtract
    sub = nxh.subtract(part, body, [tool], keep_tool=True)
    N["v_after_one_slot"] = nxh.volume(part, body)
    N["solids_after_subtract"] = len(nxh.solids(part))
    # pattern geometry of the kept tool: 3 more, then subtract all
    nxh.expr(part, "n_slot", 4, None, "number of slots")
    try:
        pg, nb_ = nxf.pattern_geometry(part, [tool], circular=dict(origin=(0, 0, 0), vec=(0, 0, 1), count="n_slot"))
        N["pattern_geometry"] = [pg.FeatureType, len(nb_)]
    except Exception as e:
        N["pattern_geometry_exc"] = traceback.format_exc()[-800:]
    res["features"] = [(x["name"], x["type"]) for x in nxh.feature_table(part)]
    # helix layout of Pattern Feature
    PAT = GU.PatternDefinition.PatternEnum
    N["pattern_enum"] = nxh.enum_names(PAT)
    b = part.Features.CreatePatternFeatureBuilder(NXOpen.Features.Feature.Null)
    try:
        ps = b.PatternService
        N["ps_dir"] = [n for n in dir(ps) if not n.startswith("_")]
        if hasattr(ps, "HelixDefinition"):
            hd = ps.HelixDefinition
            N["helix_dir"] = [n for n in dir(hd) if not n.startswith("_")]
            N["helix_doc"] = nxh.builder_doc(hd)
    finally:
        b.Destroy()
    nxh.save(part)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "probe1.json"), res)

