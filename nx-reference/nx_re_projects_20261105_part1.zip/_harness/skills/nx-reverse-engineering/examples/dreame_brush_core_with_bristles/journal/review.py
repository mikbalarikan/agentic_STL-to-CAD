"""Review part: a copy of the built part with the two scans (decimated, in the CAD datum frame) as reference bodies.
Layer 10 = with-bristles core scan, layer 11 = base scan (the brush end with the r 16.4 flange).
usage: run_journal review.py -args <out dir>"""
import os, sys, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxre

OUT = sys.argv[1]
NAME = "dreame_brush_core_with_bristles"
res = {"result": "FAIL"}
try:
    src = os.path.join(OUT, NAME + ".prt")
    dst = os.path.join(OUT, NAME + "_with_scans.prt")
    if os.path.exists(dst):
        os.remove(dst)
    shutil.copyfile(src, dst)
    part = nxh.open_part(dst)
    res["cad_solids"] = len(nxh.solids(part))
    res["scans"] = {}
    for layer, fn, nm in ((10, "scan_core_with_bristles_datum.stl", "SCAN_CORE_WITH_BRISTLES"), (11, "scan_base_end_datum.stl", "SCAN_BASE")):
        bodies = nxre.stl_import(part, os.path.join(OUT, fn))
        facets = []
        for i, b in enumerate(bodies):
            b.SetName("%s_%d" % (nm, i + 1))
            try:
                facets.append(b.GetNumberOfFacets())
            except Exception:  # noqa: BLE001
                facets.append(None)
        part.Layers.MoveDisplayableObjects(layer, bodies)
        big = [b for b, n in zip(bodies, facets) if n and n > 1000]
        res["scans"][nm] = {"bodies": len(bodies), "facets_total": sum(f for f in facets if f), "largest": max([f for f in facets if f] or [0]),
                            "bbox_largest": [round(v, 2) for v in nxh.bbox(max(big, key=lambda b: b.GetNumberOfFacets()))] if big else None, "layer": layer}
    res["errors"] = nxh.feature_errors(part)
    res["solids_after"] = len(nxh.solids(part))
    nxh.save(part)
    res["size_mb"] = round(os.path.getsize(dst) / 1e6, 1)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "review.json"), res)
