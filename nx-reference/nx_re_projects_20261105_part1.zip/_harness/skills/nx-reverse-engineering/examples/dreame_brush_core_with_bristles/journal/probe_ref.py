"""Read-only probe of a reference part: feature tree, bodies, face census, free edges, expressions; exports every body as STL.
usage: run_journal -Script probe_ref.py -JArgs <part.prt>,<out dir>,<tag>     (never saves)"""
import os, sys, traceback, json, time
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen, NXOpen.UF
import nxh, nxre

SRC, OUT, TAG = sys.argv[1:4]
UFS = NXOpen.UF.UFSession.GetUFSession()
res = {"result": "FAIL", "part": SRC}
t0 = time.time()


def flush():
    nxh.write_json(os.path.join(OUT, f"probe_{TAG}.json"), res)


try:
    part = nxh.open_part(SRC)
    res["load_status"] = list(nxh.LOAD_STATUS)
    feats = []
    for f in part.Features.GetFeatures():
        row = {"ts": f.Timestamp, "name": f.GetFeatureName(), "type": f.FeatureType, "cls": type(f).__name__, "internal": bool(nxh.is_internal(f)),
               "supp": bool(f.Suppressed)}
        try:
            row["parents"] = [p.GetFeatureName() for p in f.GetParents()]
        except Exception:
            pass
        try:
            ex = []
            for e in f.GetExpressions():
                ex.append(f"{e.Name}={e.RightHandSide}")
            row["expr"] = ex
        except Exception:
            pass
        feats.append(row)
    res["features"] = feats
    res["expressions"] = [{"name": e.Name, "rhs": e.RightHandSide, "value": e.Value if e.Type == "Number" else None, "type": e.Type} for e in part.Expressions]
    flush()
    owners = {}
    for f in part.Features.GetFeatures():
        try:
            for b in f.GetBodies():
                owners.setdefault(b.Tag, []).append(f.GetFeatureName())
        except Exception:
            pass
    bodies = []
    for i, b in enumerate(part.Bodies):
        row = {"i": i, "tag": b.Tag, "solid": bool(b.IsSolidBody), "sheet": bool(b.IsSheetBody), "blanked": bool(b.IsBlanked), "layer": b.Layer,
               "faces": len(b.GetFaces()), "edges": len(b.GetEdges()), "bbox": nxh.bbox(b), "owners": owners.get(b.Tag, [])}
        try:
            row["convergent"] = bool(b.IsConvergentBody)
        except Exception as e:
            row["convergent"] = "EXC " + str(e)[:60]
        try:
            row["name"] = b.Name
            row["color"] = b.Color
        except Exception:
            pass
        if row["convergent"] is True:
            try:
                row["n_facets"] = b.GetNumberOfFacets()
            except Exception as e:
                row["n_facets"] = "EXC " + str(e)[:60]
        else:
            if b.IsSolidBody:
                try:
                    row["volume"] = nxh.volume(part, b)
                except Exception as e:
                    row["volume"] = "EXC " + str(e)[:60]
            try:
                row["area"] = nxh.sheet_area(part, b)[0]
            except Exception as e:
                row["area"] = "EXC " + str(e)[:60]
            fe = nxh.free_edges(b)
            row["free_edges"] = len(fe)
            fl = []
            for e in fe[:60]:
                try:
                    v = e.GetVertices()
                    fl.append({"len": round(e.GetLength(), 4), "type": str(e.SolidEdgeType), "a": [round(v[0].X, 3), round(v[0].Y, 3), round(v[0].Z, 3)],
                               "b": [round(v[1].X, 3), round(v[1].Y, 3), round(v[1].Z, 3)], "bbox": nxh.bbox(e)})
                except Exception as ex:
                    fl.append({"exc": str(ex)[:60]})
            row["free_edge_list"] = fl
            row["census"] = nxh.face_census(b)["types"]
            if len(b.GetFaces()) > 20:
                fr = []
                for f in b.GetFaces():
                    t, pt, d, rad = nxh.face_data(f)
                    fr.append({"type": t, "pt": [round(v, 4) for v in pt], "dir": [round(v, 5) for v in d], "r": round(rad, 4), "bbox": nxh.bbox(f),
                               "area": round(nxh.sheet_area(part, [f])[0], 4)})
                row["face_list"] = fr
        p = os.path.join(OUT, f"{TAG}_body{i}.stl")
        try:
            row["stl"] = list(nxre.stl_export(part, b, p, chord=0.01, max_edge=1.0)) + [os.path.basename(p)]
        except Exception as e:
            row["stl"] = "EXC " + str(e)[:120]
        bodies.append(row)
        res["bodies"] = bodies
        flush()
    # sketches
    sk = []
    for s in part.Sketches:
        try:
            g = s.GetAllGeometry()
            st = s.GetStatus()
            o = s.Origin
            sk.append({"name": s.Name, "n_geom": len(g), "status": str(st[0]), "dof": st[1], "origin": [o.X, o.Y, o.Z],
                       "types": sorted({type(x).__name__ for x in g}), "feature": s.Feature.GetFeatureName() if s.Feature else None})
        except Exception as e:
            sk.append({"name": s.Name, "exc": str(e)[:80]})
    res["sketches"] = sk
    res["seconds"] = time.time() - t0
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
flush()
