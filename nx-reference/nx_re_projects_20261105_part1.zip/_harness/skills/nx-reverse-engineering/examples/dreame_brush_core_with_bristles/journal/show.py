import json, sys
d = json.load(open(sys.argv[1]))
print("RESULT", d["result"])
if d.get("error"):
    print(d["error"][-3000:])
ch = d.get("checks", [])
print("checks: %d, failed: %d" % (len(ch), sum(1 for r in ch if not r["ok"])))
for r in ch:
    if not r["ok"] or "-v" in sys.argv:
        print(("ok   " if r["ok"] else "FAIL ") + r["name"], "| got", r.get("got", ""), "| want", r.get("want", ""), "| tol", r.get("tol", ""), "|", str(r.get("note", ""))[:600])
bad = {k: v for k, v in d.get("sketches", {}).items() if v["dof"] or v["auto_dims"] or v["status"] != "WellConstrained"}
print("sketches:", len(d.get("sketches", {})), "not fully constrained:", bad)
print("log:", d.get("log"))
print("feature errors:", d.get("feature_errors"))
print("notes:", json.dumps(d.get("notes"))[:1500])
for k in ("volume_core", "volume_tufts", "bbox_core", "examine_core", "n_features_top", "step_roundtrip", "stl_core", "stl_tufts"):
    if k in d:
        v = d[k]
        if k == "step_roundtrip":
            v = dict(v)
            ex = v.pop("examine", None) or []
            v["examine_bodies"] = len(ex)
            v["examine_findings"] = sum(sum(x.values()) for x in ex if isinstance(x, dict))
        print(k, ":", v)
if "-f" in sys.argv:
    for f in d.get("features", []):
        print("  ", f)
