"""Dreame main-brush core WITH bristles: native parametric build (NX 2206 journal, headless).

    run_journal build.py -args <out dir> [last stage a|b|c|d|z]

Datum CSYS (= datum frame of the with-bristles core scan, qa/T_bristles.json):
    Z  = brush axis (centre of the drive-end hub disc -> centre of the idler counterbore), +Z towards the idler end
    z0 = underside of the drive-end flange (the face the part stood on when it was scanned)
    X  = direction of the straight edge of pinwheel blade 0
Angles are unitless numbers in degrees, counter-clockwise about +Z seen from +Z; angles of twisted features are
given at z = z_core0 (start of the core). The core twists LEFT-hand: a feature at angle a at z_core0 sits at
a - 360 * (z - z_core0) / twist_lead at height z.

Build order (same idea as the reference part of the sister core: discs -> drive blades -> cylinder -> helical
slot tools -> edge blends -> end details), but as ONE solid from fully constrained sketches and named expressions:
    A  base: revolved flange / hub with the underside recess, hex socket, pits, pinwheel blades (pattern)
    B  core cylinder, twisted tools (T-slot, small groove, wide V groove, its centre groove) -> pattern -> subtract, blends
    C  idler end: counterbore + bore, end round, key notch
    D  bristles: tuft holes (helix pattern) and tuft bodies (separate solids)
    Z  checks, regeneration test, STEP, STL
"""
import os, sys, math, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, os.environ["NXBLADE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\dreame_brush\nxlib")
import NXOpen, NXOpen.UF, NXOpen.Features, NXOpen.GeometricUtilities as GU
import nxh, nxf, nxre
import nxblade as nb
import ps

BOOL = nxh.BOOL
F = ps.FREE
OUT = sys.argv[1]
LAST = sys.argv[2] if len(sys.argv) > 2 else "z"
NAME = "dreame_brush_core_with_bristles"
UFS = NXOpen.UF.UFSession.GetUFSession()
X, Y, Z = (1, 0, 0), (0, 1, 0), (0, 0, 1)
CYL, PLANE = 16, 22


class Ctx:
    def __init__(self, part):
        self.part, self.dat = part, nxh.Datums(part)
        self.M, self.C, self.chk, self.log, self.sk, self.notes = {}, {}, nxh.Check(), [], {}, {}
        self.t0 = time.time()

    def e(self, name, value, comment="", unit="mm"):
        """master expression (a number); unit None = unitless (counts, angles in degrees)"""
        nxh.expr(self.part, name, value, unit, comment)
        self.M[name] = float(value)
        self.C[name] = (comment, unit or "-")
        return float(value)

    def d(self, name, formula, value, comment=""):
        """derived unitless expression (a formula of masters); value = its number for the journal's own maths"""
        nxh.expr(self.part, name, formula, None, comment)
        self.M[name] = float(value)
        return float(value)

    def say(self, msg):
        self.log.append("%6.1fs  %s" % (time.time() - self.t0, msg))

    def sketch(self, plane, name, **kw):
        return ps.Sketch(self.part, self.dat, plane, name, **kw)

    def done(self, S):
        st = S.finish()
        self.sk[S.name] = {"status": st["status"], "dof": st["dof"], "auto_dims": st["auto_dims"], "dims": len(st["dims"])}
        return S

    def vol(self, body):
        return nxh.volume(self.part, body)


# ------------------------------------------------------------------------------------------ small maths
def revolve_volume(verts):
    """Volume of a closed (r, z) polygon turned 360 deg about r = 0."""
    v = 0.0
    n = len(verts)
    for i in range(n):
        r0, z0 = verts[i][0], verts[i][1]
        r1, z1 = verts[(i + 1) % n][0], verts[(i + 1) % n][1]
        v += (r0 * r0 + r0 * r1 + r1 * r1) * (z1 - z0)
    return abs(v) * math.pi / 3.0


def poly_area(pts):
    a = 0.0
    for i in range(len(pts)):
        x0, y0 = pts[i]
        x1, y1 = pts[(i + 1) % len(pts)]
        a += x0 * y1 - x1 * y0
    return abs(a) / 2


def in_poly(x, y, pts):
    c = False
    n = len(pts)
    for i in range(n):
        x0, y0 = pts[i]
        x1, y1 = pts[(i + 1) % n]
        if (y0 > y) != (y1 > y) and x < x0 + (y - y0) * (x1 - x0) / (y1 - y0):
            c = not c
    return c


def area_in_disc(inside, box, R, r_min=0.0, h=0.004):
    """Area of {inside(x, y)} within r_min <= r <= R, midpoint grid over box = (x0, x1, y0, y1)."""
    x0, x1, y0, y1 = box
    nx_, ny_ = int((x1 - x0) / h) + 1, int((y1 - y0) / h) + 1
    n = 0
    for i in range(nx_):
        x = x0 + (i + 0.5) * h
        for j in range(ny_):
            y = y0 + (j + 0.5) * h
            rr = x * x + y * y
            if rr <= R * R and rr >= r_min * r_min and inside(x, y):
                n += 1
    return n * h * h


def rotz(p, deg):
    a = math.radians(deg)
    return (p[0] * math.cos(a) - p[1] * math.sin(a), p[0] * math.sin(a) + p[1] * math.cos(a))


def tw(c, z):
    """rotation (deg) of the twisted core at height z relative to z_core0"""
    return -360.0 * (z - c.M["z_core0"]) / c.M["twist_lead"]


def on_body(c, body, xyz):
    return abs(nxh.dist_to(c.part, body, xyz))


def land_faces(c):
    r = c.M["d_core"] / 2
    out = []
    for f in c.core.GetFaces():
        t, pt, d, rad = nxh.face_data(f)
        if t == CYL and abs(abs(rad) - r) < 1e-4 and abs(pt[0]) < 1e-6 and abs(pt[1]) < 1e-6:
            out.append(f)
    return out


def long_land_edges(c, centre_deg, half_window_deg, min_len=60.0):
    """Helical edges of the land faces whose untwisted angle lies within the window of one of the centres."""
    out, seen = [], set()
    for f in land_faces(c):
        for ed in f.GetEdges():
            if ed.Tag in seen or ed.GetLength() < min_len:
                continue
            seen.add(ed.Tag)
            pts = nxh.edge_points(ed, n=5, ends=False)
            p = pts[len(pts) // 2]
            a = math.degrees(math.atan2(p[1], p[0])) - tw(c, p[2])
            if any(abs((a - c0 + 180.0) % 360.0 - 180.0) < half_window_deg for c0 in centre_deg):
                out.append(ed)
    return out


def stl_many(bodies, path, chord=0.01, max_edge=1.0):
    if os.path.exists(path):
        os.remove(path)
    h = UFS.Std.OpenBinaryStlFile(path, False, "dreame brush")
    try:
        for b in bodies:
            UFS.Std.PutSolidInStlFile(h, 0, b.Tag, 0.0, float(max_edge), float(chord))
    finally:
        UFS.Std.CloseStlFile(h)
    return os.path.getsize(path)


# =========================================================================================== stage A
def stage_a(c):
    """Drive end: flange + hub disc + hub (one revolve with the underside recess), hex socket, pits, pinwheel blades."""
    p, e, M = c.part, c.e, c.M
    e("h_total", 169.75, "overall length: underside of the flange to the idler end face")
    e("twist_lead", 225.75, "lead of the core twist, mm per turn, left-hand")
    e("d_rim", 32.9, "flange (rim) diameter")
    e("h_rim", 3.35, "flange height")
    e("rim_cham_r", 0.8, "flange bottom edge chamfer, radial")
    e("rim_cham_z", 1.3, "flange bottom edge chamfer, axial")
    e("d_hub", 30.4, "hub disc diameter")
    e("z_floor", 4.65, "top of the hub disc = floor between the drive blades")
    e("z_core0", 6.5, "top of the drive blades = start of the twisted core")
    e("d_hub_in", 9.9, "hub cylinder between the blades")
    e("d_recess", 23.0, "underside recess diameter")
    e("z_recess", 3.7, "underside recess floor height")
    e("d_boss", 10.0, "raised ring round the hex socket, diameter")
    e("z_boss", 3.47, "face of the raised ring")
    rr, rh, rhi, rrec, rbo = M["d_rim"] / 2, M["d_hub"] / 2, M["d_hub_in"] / 2, M["d_recess"] / 2, M["d_boss"] / 2
    base = [(0.0, M["z_boss"], None, "z_boss"), (rbo, M["z_boss"], "d_boss/2", None), (rbo, M["z_recess"], None, "z_recess"),
            (rrec, M["z_recess"], "d_recess/2", None), (rrec, 0.0), (rr - M["rim_cham_r"], 0.0, "d_rim/2-rim_cham_r", None),
            (rr, M["rim_cham_z"], "d_rim/2", "rim_cham_z"), (rr, M["h_rim"], None, "h_rim"), (rh, M["h_rim"], "d_hub/2", None),
            (rh, M["z_floor"], None, "z_floor"), (rhi, M["z_floor"], "d_hub_in/2", None), (rhi, M["z_core0"], None, "z_core0"),
            (0.0, M["z_core0"])]
    S = c.sketch("xz", "SK_BASE")
    S.profile(base)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (rr, 1.0)), nxf.axis_from(p, c.dat.z))
    f.SetName("BASE")
    c.core = f.GetBodies()[0]
    c.chk("BASE volume = revolve of the profile", c.vol(c.core), revolve_volume(base), 0.02)
    c.base_profile = base

    # ---- pits and ejector marks on the recess floor (pairs, 180 deg apart)
    e("pit_r", 7.93, "pits in the recess floor: radial position")
    e("pit_ang", 139.5, "pits: angle of the first one, deg", None)
    e("pit_d", 1.5, "pit diameter")
    e("pit_depth", 0.65, "pit depth from the recess floor")
    e("ej_r", 8.35, "ejector marks: radial position")
    e("ej_ang", 46.0, "ejector marks: angle of the first one, deg", None)
    e("ej_d", 2.2, "ejector mark diameter")
    e("ej_depth", 0.3, "ejector mark depth")
    e("dish_d", 3.6, "shallow dish round each pit: diameter")
    e("dish_depth", 0.25, "shallow dish round each pit: depth")
    nxh.expr(p, "n_pair", 2, None, "pits / marks per circle")
    for nm, pre, pos in (("PIT_DISH", "dish", "pit"), ("PIT", "pit", "pit"), ("EJECTOR_MARK", "ej", "ej")):
        v0 = c.vol(c.core)
        f, _ = nxh.cylinder(p, ("%s_r*cos(%s_ang)" % (pos, pos), "%s_r*sin(%s_ang)" % (pos, pos), "z_recess"), Z, "%s_d" % pre, "%s_depth" % pre,
                            op=BOOL.Subtract, target=c.core)
        f.SetName(nm)
        pf = nxf.pattern_circular(p, [f], (0, 0, 0), c.dat.z, "n_pair")
        pf.SetName(nm + "_PATTERN")
        exp_ = 2 * math.pi * (M[pre + "_d"] / 2) ** 2 * M[pre + "_depth"]
        if nm == "PIT":                                             # the dish already took the top of the pit
            exp_ -= 2 * math.pi * (M["pit_d"] / 2) ** 2 * M["dish_depth"]
        c.chk(nm + " x 2 removes two cylinders", v0 - c.vol(c.core), exp_, 0.01)

    # ---- pinwheel drive blades
    e("blade_edge", 1.14, "blade: offset of the straight (driving) edge from the axis plane")
    e("d_blade", 30.3, "blade: diameter of the outer wall")
    e("blade_corner_R", 0.5, "blade: round between the straight edge and the outer wall")
    e("blade_crown_R", 4.95, "blade: crown radius (tangent to the outer wall and to the back wall)")
    e("blade_wall", 0.45, "blade: offset of the back wall from the axis plane")
    nxh.expr(p, "n_blade", 4, None, "number of drive blades")
    rb, ed, r1, Rc, xw = M["d_blade"] / 2, M["blade_edge"], M["blade_corner_R"], M["blade_crown_R"], M["blade_wall"]

    def blade_pts(rin):
        c1 = (math.sqrt((rb - r1) ** 2 - (ed + r1) ** 2), ed + r1)
        cc = (xw + Rc, math.sqrt((rb - Rc) ** 2 - (xw + Rc) ** 2))
        v0_ = (math.sqrt(rin ** 2 - ed ** 2), ed)
        v1_ = (c1[0], ed)
        v2_ = (c1[0] * rb / (rb - r1), c1[1] * rb / (rb - r1))
        v3_ = (cc[0] * rb / (rb - Rc), cc[1] * rb / (rb - Rc))
        v4_ = (xw, cc[1])
        v5_ = (xw, math.sqrt(rin ** 2 - xw ** 2))
        return [v0_, v1_, v2_, v3_, v4_, v5_], c1, cc

    rin = rhi - 0.6                                           # the profile closes INSIDE the hub cylinder (clean unite)
    bv, c1, cc = blade_pts(rin)
    verts = [(bv[0][0], bv[0][1], F, "blade_edge"), (bv[1][0], bv[1][1], F, None), (bv[2][0], bv[2][1], F, F), (bv[3][0], bv[3][1], F, F),
             (bv[4][0], bv[4][1], "blade_wall", F), (bv[5][0], bv[5][1], None, F)]
    arcs = {1: (c1[0], c1[1], "blade_corner_R"), 2: (0.0, 0.0, "d_blade/2"), 3: (cc[0], cc[1], "blade_crown_R"), 5: (0.0, 0.0, "d_hub_in/2-0.6")}
    S = c.sketch("xy", "SK_BLADE")
    cs = S.profile(verts, arcs)
    for a_, b_ in ((0, 1), (1, 2), (2, 3), (3, 4)):
        S.tangent(cs[a_], cs[b_], at=bv[b_])
    for k in (2, 5):
        S.centre_on(cs[k], "h")
        S.centre_on(cs[k], "v")
    c.done(S)
    v0 = c.vol(c.core)
    f = nxh.extrude(p, S.section(None, (bv[0][0], bv[0][1])), Z, "z_floor", "z_core0", op=BOOL.Unite, target=c.core)
    f.SetName("BLADE")
    # expected: blade area outside the hub cylinder (numeric), times the blade height
    def arc_pts(ctr, a, b, n=60):
        r = math.hypot(a[0] - ctr[0], a[1] - ctr[1])
        t0, t1 = math.atan2(a[1] - ctr[1], a[0] - ctr[0]), math.atan2(b[1] - ctr[1], b[0] - ctr[0])
        dt = (t1 - t0 + math.pi) % (2 * math.pi) - math.pi
        return [(ctr[0] + r * math.cos(t0 + dt * i / n), ctr[1] + r * math.sin(t0 + dt * i / n)) for i in range(n)]
    poly = [bv[0]] + arc_pts(c1, bv[1], bv[2]) + arc_pts((0, 0), bv[2], bv[3], 400) + arc_pts(cc, bv[3], bv[4], 400) + [bv[4]] + arc_pts((0, 0), bv[5], bv[0], 200)
    # less the strip of the profile that lies inside the hub cylinder: rin <= r <= rhi between the two straight walls
    n_i, strip = 2000, 0.0
    for i in range(n_i):
        r_ = rin + (rhi - rin) * (i + 0.5) / n_i
        strip += r_ * (math.acos(xw / r_) - math.asin(ed / r_)) * (rhi - rin) / n_i
    a_out = poly_area(poly) - strip
    c.blade_area = a_out
    c.chk("BLADE adds area outside the hub x height", c.vol(c.core) - v0, a_out * (M["z_core0"] - M["z_floor"]), 0.35)
    v1 = c.vol(c.core)
    pf = nxf.pattern_circular(p, [f], (0, 0, 0), c.dat.z, "n_blade")
    pf.SetName("BLADE_PATTERN")
    c.chk("BLADE_PATTERN: four equal blades", c.vol(c.core) - v0, 4 * (v1 - v0), 0.01)
    # ---- core cylinder (the hex socket reaches into it)
    e("d_core", 14.95, "core diameter over the lands")
    v0 = c.vol(c.core)
    f, _ = nxh.cylinder(p, (0, 0, "z_core0"), Z, "d_core", "h_total-z_core0", op=BOOL.Unite, target=c.core)
    f.SetName("CORE_CYLINDER")
    c.chk("CORE_CYLINDER volume", c.vol(c.core) - v0, math.pi * (M["d_core"] / 2) ** 2 * (M["h_total"] - M["z_core0"]), 0.01)

    # ---- hex socket
    e("hex_af", 5.8, "hex socket across flats (scan: 5.7 at the mouth .. 5.9 deeper; not caliper-checked)")
    e("hex_ang", 3.5, "direction of a hex flat normal, deg", None)
    e("hex_depth", 6.6, "hex socket depth from the ring face (deepest wall seen; bottom not scanned)")
    rc = M["hex_af"] / math.sqrt(3.0)
    hexv = []
    for i in range(6):
        a = M["hex_ang"] + 30.0 + 60.0 * i
        x, y = rc * math.cos(math.radians(a)), rc * math.sin(math.radians(a))
        fx = "%shex_af/sqrt(3)*cos(hex_ang+%d)" % ("-" if x < 0 else "", 30 + 60 * i)
        fy = "%shex_af/sqrt(3)*sin(hex_ang+%d)" % ("-" if y < 0 else "", 30 + 60 * i)
        hexv.append((x, y, fx, fy))
    S = c.sketch("xy", "SK_HEX")
    S.profile(hexv)
    c.done(S)
    v0 = c.vol(c.core)
    f = nxh.extrude(p, S.section(None, (hexv[0][0], hexv[0][1])), Z, "z_boss", "z_boss+hex_depth", op=BOOL.Subtract, target=c.core)
    f.SetName("HEX_SOCKET")
    c.chk("HEX_SOCKET removes the hexagonal prism", v0 - c.vol(c.core), math.sqrt(3) / 2 * M["hex_af"] ** 2 * M["hex_depth"], 0.02)

    c.chk.true("one solid after stage A", len(nxh.solids(p)) == 1, len(nxh.solids(p)))


# =========================================================================================== stage B
def stage_b(c):
    """Core cylinder and the twisted cuts."""
    p, e, M = c.part, c.e, c.M
    R = M["d_core"] / 2
    L = M["h_total"] - M["z_core0"]
    c.d("twist_sweep", "360*(h_total+1-z_core0)/twist_lead", 360.0 * (M["h_total"] + 1 - M["z_core0"]) / M["twist_lead"],
        "twist angle over the tool length (tools run 1 mm past the idler end), deg")
    # reference geometry at the start of the core
    fp, c.dp0 = nxf.datum_plane(p, "offset", [c.dat.xy], "z_core0", "DP_CORE0")
    fx, c.dax0 = nxf.datum_axis(p, "point_dir", (0, 0, "z_core0"), X, "DA_CORE0_X")
    fy, c.day0 = nxf.datum_axis(p, "point_dir", (0, 0, "z_core0"), Y, "DA_CORE0_Y")
    c.o0 = nxh.point(p, 0, 0, "z_core0")
    G = c.sketch("xz", "SK_AXIS")
    G.profile([(0.0, M["z_core0"], None, "z_core0"), (0.0, M["h_total"] + 1.0, None, "h_total+1")], closed=False)
    c.done(G)
    c.guide = G

    def core_sketch(name):
        return ps.Sketch(p, c.dat, "xy", name, on=c.dp0, origin=c.o0, hax=c.dax0, vax=c.day0, shift=(0.0, 0.0, M["z_core0"]))

    def guide_sec():
        return nxh.section_feature(p, [c.guide.feature], (0, 0, M["z_core0"]), curves_only=True)

    def twisted_cut(S, help_uv, ang, count, name, a_in, trim_plane=None, keep_xy=None, z_from=None, trim_plane2=None, z_to=None):
        """Swept tool (angular law) -> [Trim Body] -> Pattern Geometry -> Subtract. a_in = tool area inside the core."""
        f = nb.swept(p, [S.section(None, help_uv)], [guide_sec()], orientation="angular",
                     angles=("-%s" % ang, "-%s+twist_sweep" % ang), solid=True)
        f.SetName(name + "_TOOL")
        tool = f.GetBodies()[0]
        if not tool.IsSolidBody:
            raise RuntimeError(name + ": swept tool is not a solid")
        ex = {k: v for k, v in nxh.examine_geometry(p, tool).items() if v}
        c.chk.true(name + " tool: Examine Geometry clean", not ex, ex)
        if trim_plane is not None:
            zz = 100.0
            kp = rotz(keep_xy, M[ang] + tw(c, zz))
            tf, _rev = nxf.trim_body(p, tool, keep_point=(kp[0], kp[1], zz), datum_plane=trim_plane)
            tf.SetName(name + "_TOOL_START")
            if trim_plane2 is not None:
                tf2, _rev2 = nxf.trim_body(p, tool, keep_point=(kp[0], kp[1], zz), datum_plane=trim_plane2)
                tf2.SetName(name + "_TOOL_END")
        pf, copies = nxf.pattern_geometry(p, [tool], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count=count))
        pf.SetName(name + "_TOOLS")
        n = len(copies) + 1
        v0_ = c.vol(c.core)
        sf = nxh.subtract(p, c.core, tool_features=[f, pf])
        sf.SetName(name)
        length = ((z_to if z_to is not None else M["h_total"]) - (z_from if z_from is not None else M["z_core0"]))
        c.chk("%s: %d cuts remove area-in-core x length" % (name, n), v0_ - c.vol(c.core), n * a_in * length, max(0.012 * n * a_in * length, 0.6))
        c.chk.true(name + ": one solid left, tools consumed", len(nxh.solids(p)) == 1, len(nxh.solids(p)))
        return f

    # ---- T-slots
    e("slot_ang0", 1.1, "T-slot: angle of the first slot at z_core0, deg", None)
    e("slot_w", 1.25, "T-slot: neck width")
    e("slot_neck_r", 6.05, "T-slot: radius where the neck ends and the foot starts")
    e("slot_foot_w", 2.2, "T-slot: foot width at the floor")
    e("slot_floor_r", 4.88, "T-slot: floor radius")
    nxh.expr(p, "n_slot", 4, None, "number of T-slots")
    ro = R + 1.0
    w2, fw2 = M["slot_w"] / 2, M["slot_foot_w"] / 2
    sv = [(ro, -w2, "d_core/2+1", "slot_w/2"), (ro, w2, None, "slot_w/2"), (M["slot_neck_r"], w2, "slot_neck_r", None),
          (M["slot_floor_r"], fw2, "slot_floor_r", "slot_foot_w/2"), (M["slot_floor_r"], -fw2, None, "slot_foot_w/2"), (M["slot_neck_r"], -w2, "slot_neck_r", None)]
    S = core_sketch("SK_SLOT")
    S.profile(sv)
    c.done(S)
    spoly = [(v[0], v[1]) for v in sv]
    a_slot = area_in_disc(lambda x, y: in_poly(x, y, spoly), (4.8, R + 0.05, -1.2, 1.2), R)
    c.a_slot = a_slot
    twisted_cut(S, (ro, 0.0), "slot_ang0", "n_slot", "SLOTS", a_slot)
    # the slot follows the twist: probe a neck wall point at three heights
    for zz in (20.0, 90.0, 160.0):
        q = rotz((6.6, w2), M["slot_ang0"] + tw(c, zz))
        c.chk("slot wall on the helix at z = %g" % zz, on_body(c, c.core, (q[0], q[1], zz)), 0.0, 0.006)

    # ---- small grooves
    e("sg_ang0", 59.9, "small groove: angle of the first one at z_core0, deg", None)
    e("sg_R", 0.92, "small groove: radius")
    e("sg_floor_r", 6.935, "small groove: floor radius")
    nxh.expr(p, "n_sg", 2, None, "number of small grooves")
    S = core_sketch("SK_SMALL_GROOVE")
    cu = M["sg_floor_r"] + M["sg_R"]
    S.circle(cu, 0.0, 2 * M["sg_R"], cuf="sg_floor_r+sg_R", df="2*sg_R")
    c.done(S)
    a_sg = area_in_disc(lambda x, y: (x - cu) ** 2 + y * y <= M["sg_R"] ** 2, (cu - 1.0, R + 0.05, -1.0, 1.0), R)
    twisted_cut(S, (M["sg_floor_r"], 0.0), "sg_ang0", "n_sg", "SMALL_GROOVES", a_sg)

    # ---- wide V grooves (flat floor) and their centre groove
    e("vg_ang0", 135.65, "wide groove: angle of the first one at z_core0, deg", None)
    e("vg_floor_r", 6.59, "wide groove: radius of the flat floor")
    e("vg_floor_w", 2.6, "wide groove: width of the flat floor")
    e("vg_flank_ang", 13.7, "wide groove: flank slope against the floor, deg", None)
    nxh.expr(p, "n_vg", 2, None, "number of wide grooves")
    rt = R + 0.6
    vt = M["vg_floor_w"] / 2 + (rt - M["vg_floor_r"]) / math.tan(math.radians(M["vg_flank_ang"]))
    ft = "vg_floor_w/2+(d_core/2+0.6-vg_floor_r)/tan(vg_flank_ang)"
    vv = [(M["vg_floor_r"], -M["vg_floor_w"] / 2, "vg_floor_r", "vg_floor_w/2"), (M["vg_floor_r"], M["vg_floor_w"] / 2, None, "vg_floor_w/2"),
          (rt, vt, "d_core/2+0.6", ft), (rt, -vt, None, ft)]
    S = core_sketch("SK_WIDE_GROOVE")
    S.profile(vv)
    c.done(S)
    vpoly = [(v[0], v[1]) for v in vv]
    a_vg = area_in_disc(lambda x, y: in_poly(x, y, vpoly), (M["vg_floor_r"] - 0.01, R + 0.05, -3.2, 3.2), R)
    twisted_cut(S, (M["vg_floor_r"], 0.0), "vg_ang0", "n_vg", "WIDE_GROOVES", a_vg)

    e("ag_R", 1.65, "centre groove in the wide groove: radius")
    e("ag_floor_r", 6.25, "centre groove: floor radius (scan: 6.06 .. 6.47 along the length)")
    e("z_ag0", 33.0, "centre groove starts at this height (scan: runs in between z 24 and 36)")
    e("ag_end_gap", 6.25, "centre groove ends this far before the idler end face (scan: runs out before the end)")
    fz, dpa = nxf.datum_plane(p, "offset", [c.dat.xy], "z_ag0", "DP_CENTRE_GROOVE_START")
    fz1, dpb = nxf.datum_plane(p, "offset", [c.dat.xy], "h_total-ag_end_gap", "DP_CENTRE_GROOVE_END")
    S = core_sketch("SK_CENTRE_GROOVE")
    ca = M["ag_floor_r"] + M["ag_R"]
    S.circle(ca, 0.0, 2 * M["ag_R"], cuf="ag_floor_r+ag_R", df="2*ag_R")
    c.done(S)
    # what the centre groove still removes below the wide groove's floor / flanks
    a_ag = area_in_disc(lambda x, y: (x - ca) ** 2 + y * y <= M["ag_R"] ** 2 and not in_poly(x, y, vpoly), (M["ag_floor_r"] - 0.01, R + 0.05, -1.7, 1.7), R)
    twisted_cut(S, (M["ag_floor_r"], 0.0), "vg_ang0", "n_vg", "CENTRE_GROOVES", a_ag, trim_plane=dpa, keep_xy=(ca, 0.0), z_from=M["z_ag0"], trim_plane2=dpb, z_to=M["h_total"] - M["ag_end_gap"])

    # ---- edge blends along the helical edges of the lands
    e("slot_mouth_R", 0.25, "round on the T-slot mouths")
    e("sg_edge_R", 0.3, "round on the small-groove shoulders")
    e("vg_edge_R", 1.0, "round where the wide-groove flanks meet the lands")
    half_slot = math.degrees(math.asin(w2 / R))
    half_sg = math.degrees(math.asin(min(1.0, 0.82 / R)))
    half_vg = math.degrees(math.atan2(2.75, 6.95))
    jobs = (("SLOT_MOUTH_BLEND", [M["slot_ang0"] + 90.0 * i for i in range(4)], half_slot + 1.5, "slot_mouth_R", 8),
            ("SMALL_GROOVE_BLEND", [M["sg_ang0"] + 180.0 * i for i in range(2)], half_sg + 2.5, "sg_edge_R", 4),
            ("WIDE_GROOVE_BLEND", [M["vg_ang0"] + 180.0 * i for i in range(2)], half_vg + 3.0, "vg_edge_R", 4))
    c.notes["blends"] = {}
    for name, centres, win, rad, n_exp in jobs:
        eds = long_land_edges(c, centres, win)
        v0_ = c.vol(c.core)
        info = {"edges": len(eds)}
        if len(eds) != n_exp:
            info["result"] = "SKIPPED: expected %d edges" % n_exp
        else:
            m = nxh.mark(name, False)
            try:
                bf = nxh.blend(p, eds, rad)
                bf.SetName(name)
                ex = {k: v for k, v in nxh.examine_geometry(p, c.core).items() if v}
                if ex or len(nxh.solids(p)) != 1:
                    raise RuntimeError("body not clean after the blend: %s" % ex)
                info["result"] = "built"
                info["dV"] = c.vol(c.core) - v0_
            except Exception as ex_:                                   # noqa: BLE001
                nxh.undo_to(m)
                info["result"] = "NOT BUILT: " + str(ex_)[:200]
        c.notes["blends"][name] = info
        c.chk.true(name + " built on %d helical edges" % n_exp, info["result"] == "built", info)
    c.chk.true("no feature errors after stage B", not nxh.feature_errors(p), nxh.feature_errors(p))


# =========================================================================================== stage C
def stage_c(c):
    """Idler end."""
    p, e, M = c.part, c.e, c.M
    e("d_cbore", 11.75, "idler end: counterbore diameter")
    e("cbore_depth", 1.2, "idler end: counterbore depth")
    e("d_bore", 8.6, "idler end: bore diameter")
    e("bore_depth", 4.95, "idler end: bore depth from the end face (deepest shoulder seen in the scan)")
    e("end_cham", 1.05, "idler end: 45 deg chamfer on the outer edge")
    ht, rcb, rbo = M["h_total"], M["d_cbore"] / 2, M["d_bore"] / 2
    ev = [(0.0, ht + 1.0, None, "h_total+1"), (rcb, ht + 1.0, "d_cbore/2", None), (rcb, ht - M["cbore_depth"], None, "h_total-cbore_depth"),
          (rbo, ht - M["cbore_depth"], "d_bore/2", None), (rbo, ht - M["bore_depth"], None, "h_total-bore_depth"), (0.0, ht - M["bore_depth"])]
    S = c.sketch("xz", "SK_IDLER_BORE")
    S.profile(ev)
    c.done(S)
    v0 = c.vol(c.core)
    f = nxf.revolve(p, S.section(None, (rcb, ht)), nxf.axis_from(p, c.dat.z), op=BOOL.Subtract, target=c.core)
    f.SetName("IDLER_BORE")
    c.notes["solids_after_IDLER_BORE"] = [round(c.vol(b), 3) for b in nxh.solids(p)]
    # the slots already removed part of the counterbore ring (their feet reach inside the counterbore radius)
    spoly = [(M["slot_floor_r"], -M["slot_foot_w"] / 2), (M["slot_floor_r"], M["slot_foot_w"] / 2), (M["slot_neck_r"], M["slot_w"] / 2), (9.0, M["slot_w"] / 2),
             (9.0, -M["slot_w"] / 2), (M["slot_neck_r"], -M["slot_w"] / 2)]
    a_sl = area_in_disc(lambda x, y: in_poly(x, y, spoly), (4.8, rcb + 0.02, -1.2, 1.2), rcb)
    exp = math.pi * (rcb ** 2 * M["cbore_depth"] + rbo ** 2 * (M["bore_depth"] - M["cbore_depth"])) - 4 * a_sl * M["cbore_depth"]
    c.chk("IDLER_BORE removes counterbore + bore (less the slot feet)", v0 - c.vol(c.core), exp, 0.6)

    R = M["d_core"] / 2
    ch = M["end_cham"]
    rv = [(R - ch, ht, "d_core/2-end_cham", "h_total"), (R, ht - ch, "d_core/2", "h_total-end_cham"), (R + 1.0, ht - ch, "d_core/2+1", None),
          (R + 1.0, ht + 1.0, None, "h_total+1"), (R - ch, ht + 1.0, None, None)]
    S = c.sketch("xz", "SK_END_CHAMFER")
    S.profile(rv)
    c.done(S)
    v0 = c.vol(c.core)
    f = nxf.revolve(p, S.section(None, (R + 1.0, ht)), nxf.axis_from(p, c.dat.z), op=BOOL.Subtract, target=c.core)
    f.SetName("END_CHAMFER")
    c.notes["solids_after_END_CHAMFER"] = [round(c.vol(b), 3) for b in nxh.solids(p)]
    full = revolve_volume([(R - ch, ht), (R, ht - ch), (R, ht)])                      # uncut ring
    dv = v0 - c.vol(c.core)
    c.chk.true("END_CHAMFER removes material (full ring %.2f less slots and grooves)" % full, 0.6 * full < dv < full + 0.01, dv)
    q = rotz((R - ch / 2, 0.0), 30.0 + tw(c, ht))
    c.chk("END_CHAMFER: point on the chamfer", on_body(c, c.core, (q[0], q[1], ht - ch / 2)), 0.0, 2e-3)

    # ---- key notch beside one slot at the idler end
    e("notch_ang", 201.3, "idler-end key notch: direction of its centre line, deg (it overlaps the neck of the slot it widens)", None)
    e("notch_w", 2.25, "key notch width, measured from inside the slot neck to the far wall")
    e("notch_h", 1.5, "key notch depth from the end face")
    a, w2 = M["notch_ang"], M["notch_w"] / 2
    ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
    nv = []
    for rr_, sg in ((5.0, -1), (5.0, 1), (9.0, 1), (9.0, -1)):
        x, y = rr_ * ca - sg * w2 * sa, rr_ * sa + sg * w2 * ca
        sx = "%g*cos(notch_ang)%snotch_w/2*sin(notch_ang)" % (rr_, "-" if sg > 0 else "+")
        sy = "%g*sin(notch_ang)%snotch_w/2*cos(notch_ang)" % (rr_, "+" if sg > 0 else "-")
        nv.append((x, y, ("-(%s)" % sx) if x < 0 else sx, ("-(%s)" % sy) if y < 0 else sy))
    S = c.sketch("xy", "SK_KEY_NOTCH")
    S.profile(nv)
    c.done(S)
    v0 = c.vol(c.core)
    f = nxh.extrude(p, S.section(None, (nv[0][0], nv[0][1])), Z, "h_total-notch_h", "h_total+1", op=BOOL.Subtract, target=c.core)
    f.SetName("KEY_NOTCH")
    c.notes["solids_after_KEY_NOTCH"] = [(round(c.vol(b), 4), nxh.bbox(b)) for b in nxh.solids(p)]
    dv = v0 - c.vol(c.core)
    ring = (R - rcb) * M["notch_w"] * M["notch_h"]
    c.chk.true("KEY_NOTCH cuts the end ring (at most width x wall x depth = %.2f)" % ring, 0.3 * ring < dv < 1.15 * ring, dv)
    c.chk.true("one solid after stage C, no feature errors", len(nxh.solids(p)) == 1 and not nxh.feature_errors(p), nxh.feature_errors(p))


# =========================================================================================== stage D
def stage_d(c):
    """Bristles: 2 helical rows of tuft holes in the core, and the tufts as separate solids."""
    p, e, M = c.part, c.e, c.M
    nxh.expr(p, "n_tuft", 27, None, "tufts per row")
    M["n_tuft"] = 27
    e("tuft_pitch", 4.9, "tuft spacing along the axis")
    e("tuft_z0", 10.55, "height of the first tuft (centre of its hole mouth on the land)")
    e("tuft_ang0", 36.1, "row angle referred to z_core0 (the rows follow the core twist), deg", None)
    e("d_tuft_hole", 2.0, "tuft hole diameter")
    e("tuft_hole_depth", 3.0, "tuft hole depth along its axis (ASSUMED: the holes are filled with bristles)")
    e("tuft_lean", 40.0, "lean of the tufts from the radial direction towards the idler end, deg", None)
    e("d_brush", 37.0, "diameter over the bristle tips")
    e("d_tuft_tip", 3.2, "tuft diameter at the tip (ASSUMED flare; the scanned tufts splay and merge)")
    seed_ang = M["tuft_ang0"] - 360.0 * (M["tuft_z0"] - M["z_core0"]) / M["twist_lead"]
    c.d("tuft_ang_seed", "tuft_ang0-360*(tuft_z0-z_core0)/twist_lead", seed_ang, "angle of the first tuft at its own height, deg")
    R, ln = M["d_core"] / 2, M["tuft_lean"]
    cs_, sn_ = math.cos(math.radians(ln)), math.sin(math.radians(ln))
    rh, rt, dep, z0 = M["d_tuft_hole"] / 2, M["d_tuft_tip"] / 2, M["tuft_hole_depth"], M["tuft_z0"]
    CL, SL = "cos(tuft_lean)", "sin(tuft_lean)"
    # hole tool: half section turned about its own axis line B -> E (E = 2 mm outside the land)
    B = (R - dep * cs_, z0 - dep * sn_)
    E = (R + 2.0 * cs_, z0 + 2.0 * sn_)
    hv = [(B[0], B[1], "d_core/2-tuft_hole_depth*%s" % CL, "tuft_z0-tuft_hole_depth*%s" % SL),
          (E[0], E[1], "d_core/2+2*%s" % CL, "tuft_z0+2*%s" % SL),
          (E[0] - rh * sn_, E[1] + rh * cs_, "d_core/2+2*%s-d_tuft_hole/2*%s" % (CL, SL), "tuft_z0+2*%s+d_tuft_hole/2*%s" % (SL, CL)),
          (B[0] - rh * sn_, B[1] + rh * cs_, "d_core/2-tuft_hole_depth*%s-d_tuft_hole/2*%s" % (CL, SL), "tuft_z0-tuft_hole_depth*%s+d_tuft_hole/2*%s" % (SL, CL))]
    S = c.sketch("xz", "SK_TUFT_HOLE")
    cs = S.profile(hv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (hv[2][0], hv[2][1])), nxf.axis_from(p, cs[0]))
    f.SetName("TUFT_HOLE_TOOL")
    tool = f.GetBodies()[0]
    c.chk("TUFT_HOLE_TOOL = cylinder d x (depth + 2)", c.vol(tool), math.pi * rh * rh * (dep + 2.0), 1e-3)
    mf = nxf.move_object(p, [tool], "angle", "tuft_ang_seed", vec=Z, origin=(0, 0, 0))
    mf.SetName("TUFT_HOLE_TOOL_CLOCK")
    pf1, cp1 = nxf.pattern_geometry(p, [tool], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="2"))
    pf1.SetName("TUFT_HOLE_TOOL_ROW_2")
    pf2, cp2 = helix_copies(c, tool)
    pf2.SetName("TUFT_HOLE_TOOLS_ROW_1")
    pf3, cp3 = helix_copies(c, cp1[0])
    pf3.SetName("TUFT_HOLE_TOOLS_ROW_2")
    n = 1 + len(cp1) + len(cp2) + len(cp3)
    c.chk.true("54 hole tools", n == 54, n)
    v0 = c.vol(c.core)
    sf = nxh.subtract(p, c.core, tool_features=[f, pf1, pf2, pf3])
    sf.SetName("TUFT_HOLES")
    dv = v0 - c.vol(c.core)
    c.notes["tuft_hole_volume_each"] = dv / 54
    c.chk("TUFT_HOLES: 54 holes of about d^2 pi/4 x depth each", dv, 54 * math.pi * rh * rh * dep, 54 * math.pi * rh * rh * dep * 0.06)
    c.chk.true("one core solid after the tuft holes", len(nxh.solids(p)) == 1, len(nxh.solids(p)))
    # position of the first and the last hole axis of row 1: the hole bottom centre lies on the core body
    for k in (0, 13, 26):
        zz = B[1] + k * M["tuft_pitch"]
        q = rotz((B[0], 0.0), seed_ang - 360.0 * k * M["tuft_pitch"] / M["twist_lead"])
        c.chk("tuft hole %d: bottom centre on the body" % k, on_body(c, c.core, (q[0], q[1], zz)), 0.0, 2e-3)

    # tufts: cylinder in the hole (to 1 mm above the land), then a cone to the tip circle d_brush
    Tt = (M["d_brush"] / 2, z0 + (M["d_brush"] / 2 - R) * sn_ / cs_)
    Mm = (R + 1.0 * cs_, z0 + 1.0 * sn_)
    tv = [(B[0], B[1], "d_core/2-tuft_hole_depth*%s" % CL, "tuft_z0-tuft_hole_depth*%s" % SL),
          (Tt[0], Tt[1], "d_brush/2", "tuft_z0+(d_brush/2-d_core/2)*tan(tuft_lean)"),
          (Tt[0] - rt * sn_, Tt[1] + rt * cs_, "d_brush/2-d_tuft_tip/2*%s" % SL, "tuft_z0+(d_brush/2-d_core/2)*tan(tuft_lean)+d_tuft_tip/2*%s" % CL),
          (Mm[0] - rh * sn_, Mm[1] + rh * cs_, "d_core/2+%s-d_tuft_hole/2*%s" % (CL, SL), "tuft_z0+%s+d_tuft_hole/2*%s" % (SL, CL)),
          (B[0] - rh * sn_, B[1] + rh * cs_, "d_core/2-tuft_hole_depth*%s-d_tuft_hole/2*%s" % (CL, SL), "tuft_z0-tuft_hole_depth*%s+d_tuft_hole/2*%s" % (SL, CL))]
    S = c.sketch("xz", "SK_TUFT")
    cs = S.profile(tv)
    c.done(S)
    f = nxf.revolve(p, S.section(None, (tv[2][0], tv[2][1])), nxf.axis_from(p, cs[0]))
    f.SetName("TUFT")
    tuft = f.GetBodies()[0]
    l_cyl, l_cone = dep + 1.0, (M["d_brush"] / 2 - R) / cs_ - 1.0
    v_t = math.pi * rh * rh * l_cyl + math.pi * l_cone / 3 * (rh * rh + rh * rt + rt * rt)
    c.chk("TUFT volume (cylinder + cone frustum)", c.vol(tuft), v_t, 2e-3)
    c.notes["tuft"] = {"axis_length": l_cyl + l_cone, "free_length": (M["d_brush"] / 2 - R) / cs_, "volume": v_t}
    mf = nxf.move_object(p, [tuft], "angle", "tuft_ang_seed", vec=Z, origin=(0, 0, 0))
    mf.SetName("TUFT_CLOCK")
    pf1, cp1 = nxf.pattern_geometry(p, [tuft], circular=dict(origin=(0, 0, 0), vec=c.dat.z, count="2"))
    pf1.SetName("TUFT_ROW_2")
    pf2, cp2 = helix_copies(c, tuft)
    pf2.SetName("TUFTS_ROW_1")
    pf3, cp3 = helix_copies(c, cp1[0])
    pf3.SetName("TUFTS_ROW_2")
    c.tufts = [tuft] + list(cp1) + list(cp2) + list(cp3)
    c.chk.true("54 tuft bodies + 1 core", len(c.tufts) == 54 and len(nxh.solids(p)) == 55, (len(c.tufts), len(nxh.solids(p))))
    for b in c.tufts:
        b.SetName("BRISTLE_TUFT")
    c.core.SetName("CORE")
    vt = sum(c.vol(b) for b in c.tufts)
    c.chk("all tufts have the seed volume", vt, 54 * v_t, 0.2)
    # no interference: the tuft root fills its hole exactly, so core and tuft only touch
    c.chk.true("no feature errors after stage D", not nxh.feature_errors(p), nxh.feature_errors(p))


def helix_copies(c, body):
    p = c.part
    before = list(p.Bodies)
    b = p.Features.CreatePatternGeometryBuilder(NXOpen.Features.PatternGeometry.Null)
    try:
        psv = b.PatternService
        psv.PatternType = GU.PatternDefinition.PatternEnum.Helix
        hd = psv.HelixDefinition
        hd.RotationAxis = nxh.axis(p, (0, 0, 0), Z)
        hd.DirectionType = GU.HelixPatternDirectionTypes.Lefthand
        hd.SizeOption = type(hd).SizeOptions.CountAngleDistance
        hd.CountOfInstances.RightHandSide = "n_tuft"
        hd.AnglePitch.RightHandSide = "360*tuft_pitch/twist_lead"
        hd.DistancePitch.RightHandSide = "tuft_pitch"
        b.GeometryToPattern.Add(body)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(p, before)


# =========================================================================================== stage Z
def stage_z(c):
    p, M = c.part, c.M
    res = c.res
    ex = nxh.examine_geometry(p, c.core)
    res["examine_core"] = ex
    c.chk.true("Examine Geometry: core clean", not any(ex.values()), {k: v for k, v in ex.items() if v})
    bad = 0
    for b in c.tufts:
        if any(nxh.examine_geometry(p, b).values()):
            bad += 1
    c.chk.true("Examine Geometry: 54 tufts clean", bad == 0, bad)
    res["volume_core"] = c.vol(c.core)
    res["volume_tufts"] = sum(c.vol(b) for b in c.tufts)
    res["bbox_core"] = nxh.bbox(c.core)
    res["face_census_core"] = nxh.face_census(c.core)
    res["mass_props_note"] = "volumes in mm^3"
    nxh.save(p)

    # ---- regeneration test: one master at a time, update, check, back
    v_nom, vt_nom = res["volume_core"], res["volume_tufts"]
    reg = []

    def run(name, new, check):
        old = p.Expressions.FindObject(name).RightHandSide
        row = {"name": name, "from": old, "to": new}
        try:
            nxh.set_expr(p, name, new)
            nxh.update()
            errs = nxh.feature_errors(p)
            row["errors"] = {k: str(v)[:160] for k, v in errs.items()} if errs else {}
            row["solids"] = len(nxh.solids(p))
            row["v_core"] = c.vol(c.core)
            try:
                row["check"] = check()
            except Exception as ex_:                                   # noqa: BLE001
                row["check"] = "EXC " + str(ex_)[:200]
        except Exception as ex_:                                       # noqa: BLE001
            row["exception"] = str(ex_)[:300]
        finally:
            nxh.set_expr(p, name, old)
            nxh.update()
        row["v_back"] = c.vol(c.core)
        row["ok"] = (not row.get("errors")) and "exception" not in row and abs(row["v_back"] - v_nom) < 1e-6 * v_nom and not str(row.get("check", "")).startswith(("EXC", "FAIL"))
        reg.append(row)
        c.chk.true("regen %s %s -> %s: no errors, check ok, volume returns" % (name, old, new), row["ok"], {k: v for k, v in row.items() if k != "name"})

    def near(val, exp, tol):
        return ("ok " if abs(val - exp) <= tol else "FAIL ") + "%.4f (expected %.4f +- %g)" % (val, exp, tol)

    R = M["d_core"] / 2
    w2 = M["slot_w"] / 2
    run("twist_lead", 250, lambda: near(on_body(c, c.core, rotz((6.6, w2), M["slot_ang0"] - 360.0 * (120.0 - M["z_core0"]) / 250.0) + (120.0,)), 0.0, 0.01))
    run("hex_af", 6.0, lambda: near(v_nom - c.vol(c.core), math.sqrt(3) / 2 * (36.0 - M["hex_af"] ** 2) * M["hex_depth"], 0.05))
    run("d_rim", 34, lambda: near(c.vol(c.core) - v_nom, revolve_volume([(17.0 - 0.8, 0.0), (17.0, 1.3), (17.0, M["h_rim"]), (M["d_rim"] / 2, M["h_rim"]), (M["d_rim"] / 2, 1.3), (M["d_rim"] / 2 - 0.8, 0.0)]), 0.05))
    run("slot_w", 1.5, lambda: near(v_nom - c.vol(c.core), 4 * (0.25 * (R - M["slot_neck_r"]) + 0.125 * (M["slot_neck_r"] - M["slot_floor_r"])) * (M["h_total"] - M["z_core0"]), 20.0))
    run("n_tuft", 20, lambda: near(float(len(nxh.solids(p))), 41.0, 0.0) + " ; " + near(c.vol(c.core) - v_nom, 14 * c.notes["tuft_hole_volume_each"], 0.05))
    run("tuft_pitch", 5.5, lambda: near(max(nxh.bbox(b)[5] for b in nxh.solids(p) if b.Tag != c.core.Tag) - max(nxh.bbox(b)[5] for b in [c.tufts[0]]), 26 * 5.5, 0.6))
    run("tuft_lean", 25, lambda: near(c.vol(c.core) + 0.0, v_nom, 30.0))
    run("d_brush", 40, lambda: near(sum(c.vol(b) for b in nxh.solids(p) if b.Tag != c.core.Tag) / 54.0, math.pi * 1.0 * 4.0 + math.pi * ((20.0 - R) / math.cos(math.radians(M["tuft_lean"])) - 1.0) / 3 * (1 + 1.6 + 2.56), 0.05))
    run("h_total", 160, lambda: near(nxh.bbox(c.core)[5], 160.0, 0.2))
    run("z_recess", 3.2, lambda: near(c.vol(c.core) - v_nom, math.pi * (M["d_recess"] ** 2 - M["d_boss"] ** 2) / 4 * 0.5, 0.05))
    run("vg_floor_r", 6.8, lambda: near(1.0 if c.vol(c.core) > v_nom else 0.0, 1.0, 0.0))
    run("n_blade", 3, lambda: near(v_nom - c.vol(c.core), c.blade_area * (M["z_core0"] - M["z_floor"]), 0.4))
    c.tufts = [b for b in nxh.solids(p) if b.Tag != c.core.Tag]
    res["regeneration"] = reg
    res["volume_core_after_regen"] = c.vol(c.core)
    res["volume_tufts_after_regen"] = sum(c.vol(b) for b in c.tufts)
    c.chk("core volume back at nominal after the regeneration test (relative)", res["volume_core_after_regen"] / v_nom, 1.0, 1e-6)
    c.chk("tuft volume back at nominal after the regeneration test (relative)", res["volume_tufts_after_regen"] / vt_nom, 1.0, 1e-6)
    c.chk.true("55 solids, no feature errors at the end", len(nxh.solids(p)) == 55 and not nxh.feature_errors(p), (len(nxh.solids(p)), nxh.feature_errors(p)))
    ex = nxh.examine_geometry(p, c.core)
    c.chk.true("Examine Geometry: core clean after the regeneration test", not any(ex.values()), {k: v for k, v in ex.items() if v})
    nxh.save(p)

    # ---- STL for the deviation maps, STEP AP242 + re-import
    res["stl_core"] = stl_many([c.core], os.path.join(OUT, NAME + "_core.stl"), chord=0.005)
    res["stl_tufts"] = stl_many(c.tufts, os.path.join(OUT, NAME + "_tufts.stl"), chord=0.01)
    stp = os.path.join(OUT, NAME + ".step")
    nxf.step_export(p, stp)
    res["step_size"] = os.path.getsize(stp)
    rt = nxf.step_roundtrip_check(stp, OUT, name="step_roundtrip", restore=p, part=p)
    res["step_roundtrip"] = {k: rt.get(k) for k in ("schema", "solids", "volume", "max_rel", "match", "healthy", "manifold_solid_brep", "examine")}
    c.chk.true("STEP AP242 re-import: 55 solids, volumes match, healthy", bool(rt.get("match")) and bool(rt.get("healthy")) and rt.get("solids") == 55, res["step_roundtrip"])


# =========================================================================================== main
res = {"result": "FAIL", "stage": LAST}
c = None
try:
    part = nxh.new_part(os.path.join(OUT, NAME + ".prt"))
    c = Ctx(part)
    c.res = res
    for key, fn in (("a", stage_a), ("b", stage_b), ("c", stage_c), ("d", stage_d), ("z", stage_z)):
        t = time.time()
        fn(c)
        c.say("stage %s done in %.1f s" % (key, time.time() - t))
        if key == LAST:
            break
    if LAST != "z":
        res["volume_core"] = c.vol(c.core)
        res["bbox_core"] = nxh.bbox(c.core)
        res["examine_core"] = {k: v for k, v in nxh.examine_geometry(part, c.core).items() if v}
        nxh.save(part)
        res["stl_core"] = stl_many([c.core], os.path.join(OUT, NAME + "_core.stl"), chord=0.005)
        if getattr(c, "tufts", None):
            res["stl_tufts"] = stl_many(c.tufts, os.path.join(OUT, NAME + "_tufts.stl"), chord=0.01)
except Exception:
    res["error"] = traceback.format_exc()
if c is not None:
    rep = c.chk.report()
    res.update(rep)
    res["sketches"] = c.sk
    res["masters"] = {k: {"value": v, "comment": c.C.get(k, ("derived", "-"))[0], "unit": c.C.get(k, ("derived", "-"))[1]} for k, v in c.M.items()}
    res["notes"] = c.notes
    res["log"] = c.log
    try:
        res["features"] = [(x["name"], x["type"]) for x in nxh.feature_table(c.part) if not x["type"] == "EXTRACT_BODY"]
        res["n_features_top"] = len(nxh.top_features(c.part)[0])
        res["feature_errors"] = {k: str(v)[:200] for k, v in (nxh.feature_errors(c.part) or {}).items()}
    except Exception:
        res["features_exc"] = traceback.format_exc()[-400:]
    if "error" in res:
        res["result"] = "FAIL"
nxh.write_json(os.path.join(OUT, "build_%s.json" % LAST), res)

