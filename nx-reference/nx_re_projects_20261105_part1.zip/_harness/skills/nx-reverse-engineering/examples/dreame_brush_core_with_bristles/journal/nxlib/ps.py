"""Fully constrained profile sketches on the principal datum planes (NX 2206 journals, legacy sketch solver).

A profile is a chain of vertices in the 2D coordinates of the plane:
    "yz": u = Y, v = Z      "xz": u = X, v = Z      "xy": u = X, v = Y
Every vertex is (u, v[, uf, vf]); uf / vf are the dimension formulas (the distance from the datum axis, a positive
number or an expression formula). Without a formula the absolute coordinate is written as a number.
Segments are lines unless `arcs` names them:  arcs = {i: (cu, cv, radius_formula)} makes segment i (vertex i ->
vertex i + 1) an arc about (cu, cv).

Constraint scheme (generic, gives DOF 0 for any such chain):
  * coincident ends (inferred), Horizontal / Vertical on axis-parallel lines;
  * one distance dimension from the vertical datum axis per group of vertices that vertical lines tie together,
    one from the horizontal datum axis per group tied by horizontal lines (a coordinate of 0 becomes a
    point-on-axis constraint instead of a zero dimension);
  * one radius dimension per arc.
"""
import math

import NXOpen
import nxh
import nxf

P, V = nxh.P, nxh.V
EPS = 1e-7
FREE = "__free__"          # formula marker: this coordinate is NOT dimensioned (another constraint fixes it)


def on(obj):
    """Formula marker: instead of this coordinate's dimension the vertex is put ON a line-like object (a datum
    axis that is not parallel to the sketch axes, e.g. a tilted revolve axis: a vertex that should lie on it must
    lie on it exactly, a rounded coordinate leaves it 1e-4 off and the revolve self-intersects)."""
    return ("on", obj)

PLANES = {
    "yz": dict(plane="yz", h="y", v="z", to3d=lambda u, v: (0.0, u, v), hdir=(0, 1, 0), vdir=(0, 0, 1), n=(1, 0, 0)),
    "xz": dict(plane="xz", h="x", v="z", to3d=lambda u, v: (u, 0.0, v), hdir=(1, 0, 0), vdir=(0, 0, 1), n=(0, 1, 0)),
    "xy": dict(plane="xy", h="x", v="y", to3d=lambda u, v: (u, v, 0.0), hdir=(1, 0, 0), vdir=(0, 1, 0), n=(0, 0, 1)),
}


class _UF:
    def __init__(self, n):
        self.p = list(range(n))

    def find(self, i):
        while self.p[i] != i:
            self.p[i] = self.p[self.p[i]]
            i = self.p[i]
        return i

    def union(self, a, b):
        self.p[self.find(a)] = self.find(b)


def _fmt(x):
    return ("%.4f" % abs(x)).rstrip("0").rstrip(".")


class Sketch:
    """One sketch on a principal datum plane; add any number of profiles / circles, then finish()."""

    def __init__(self, part, dat, plane, name, on=None, origin=None, vax=None, hax=None, shift=(0.0, 0.0, 0.0)):
        """plane: 'yz' / 'xz' / 'xy' = orientation of the sketch. By default it lies on that plane of the Datum
        CSYS. on = a datum plane PARALLEL to it (an offset plane), origin = an NXOpen.Point on it, shift = the 3D
        position of the sketch's (u, v) = (0, 0); vax / hax = other dimension references (a datum axis through a
        bowl centre makes the u dimensions radii)."""
        self.part, self.dat, self.cfg, self.name = part, dat, PLANES[plane], name
        c = self.cfg
        self.shift = tuple(float(t) for t in shift)
        self.sk = nxf.new_sketch(part, on if on is not None else getattr(dat, c["plane"]), getattr(dat, c["h"]),
                                 origin if origin is not None else dat.origin, name)
        self.hax = hax if hax is not None else getattr(dat, c["h"])
        self.vax = vax if vax is not None else getattr(dat, c["v"])
        self.curves = []
        self.loops = []
        self.dbg = []

    def p3(self, u, v):
        q = self.cfg["to3d"](u, v)
        return P(*[float(q[k]) + self.shift[k] for k in range(3)])

    def _vref(self, kind, i, n, segs, verts, closed):
        """(curve, assoc) addressing vertex i."""
        cur = segs[i] if (closed or i < n - 1) else None
        prev = segs[i - 1] if (closed or i > 0) else None
        if cur is not None and cur[0] == "line":
            return cur[1], nxf.A.StartPoint
        if prev is not None and prev[0] == "line":
            return prev[1], nxf.A.EndPoint
        k, obj, flipped = cur if cur is not None else prev
        at_start = (cur is not None)
        if flipped:
            at_start = not at_start
        return obj, (nxf.A.StartPoint if at_start else nxf.A.EndPoint)

    def profile(self, verts, arcs=None, closed=True, ref=False):
        """Add a chain; returns the list of curves (segment order)."""
        part, sk, c = self.part, self.sk, self.cfg
        vs = [tuple(v) + (None,) * (4 - len(v)) for v in verts]
        n = len(vs)
        nseg = n if closed else n - 1
        # an arc is drawn through BOTH of its end points: the given centre only says on which side it lies and
        # roughly how big it is (a measured centre is never exactly equidistant from two computed junctions)
        fixed = {}
        for i, (cu, cv, rf) in (arcs or {}).items():
            a, b = vs[i], vs[(i + 1) % n]
            r = (math.hypot(a[0] - cu, a[1] - cv) + math.hypot(b[0] - cu, b[1] - cv)) / 2
            mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
            dx, dy = b[0] - a[0], b[1] - a[1]
            half = math.hypot(dx, dy) / 2
            h = math.sqrt(max(r * r - half * half, 0.0))
            nx_, ny_ = -dy / (2 * half), dx / (2 * half)
            c1, c2 = (mx + nx_ * h, my + ny_ * h), (mx - nx_ * h, my - ny_ * h)
            cc = c1 if (c1[0] - cu) ** 2 + (c1[1] - cv) ** 2 <= (c2[0] - cu) ** 2 + (c2[1] - cv) ** 2 else c2
            fixed[i] = (cc[0], cc[1], rf)
        arcs = fixed
        segs = []
        for i in range(nseg):
            a, b = vs[i], vs[(i + 1) % n]
            if i in arcs:
                cu, cv, rf = arcs[i]
                r = math.hypot(a[0] - cu, a[1] - cv)
                a0 = math.atan2(a[1] - cv, a[0] - cu)
                a1 = math.atan2(b[1] - cv, b[0] - cu)
                # go the short way round from a to b
                d = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi
                flipped = d < 0
                s, e = (a0, a0 + d) if not flipped else (a0 + d, a0)
                arc = part.Curves.CreateArc(self.p3(cu, cv), V(*[float(t) for t in c["hdir"]]),
                                            V(*[float(t) for t in c["vdir"]]), float(r), float(s), float(e))
                segs.append(("arc", arc, flipped))
            else:
                segs.append(("line", part.Curves.CreateLine(self.p3(a[0], a[1]), self.p3(b[0], b[1]))))
        objs = [s[1] for s in segs]
        # no inferred constraints: inference also ties arc CENTRES that happen to coincide (concentric shells),
        # which over-constrains a chain whose arcs are already fixed by end points + radius
        nxf.add(sk, *objs, infer=False)

        def end_of(k, last):
            """Constraint geometry of the first / last point of segment k (profile direction)."""
            s = segs[k]
            flipped = len(s) > 2 and s[2]
            at_end = last != flipped if s[0] == "arc" else last
            return nxf.cg(s[1], nxf.CP.EndVertex if at_end else nxf.CP.StartVertex)

        for i in range(n):
            prev = i - 1 if i > 0 else (nseg - 1 if closed else None)
            if prev is None or i >= nseg and not closed:
                continue
            sk.CreateCoincidentConstraint(end_of(prev, True), end_of(i % nseg, False))
        ufu, ufv = _UF(n), _UF(n)
        for i in range(nseg):
            if segs[i][0] != "line":
                continue
            a, b = vs[i], vs[(i + 1) % n]
            j = (i + 1) % n
            if abs(a[0] - b[0]) < EPS:
                nxf.vertical(sk, segs[i][1])
                ufu.union(i, j)
            elif abs(a[1] - b[1]) < EPS:
                nxf.horizontal(sk, segs[i][1])
                ufv.union(i, j)
        # one dimension per coordinate class; prefer a vertex that carries a formula
        for axis_i, uf, ref_axis, perp in ((0, ufu, self.vax, 1), (1, ufv, self.hax, 0)):
            groups = {}
            for i in range(n):
                groups.setdefault(uf.find(i), []).append(i)
            for members in groups.values():
                if any(vs[i][2 + axis_i] == FREE for i in members):
                    continue
                withf = [i for i in members if vs[i][2 + axis_i] is not None]
                i = withf[0] if withf else members[0]
                val = vs[i][axis_i]
                geom, assoc = self._vref(None, i, n, segs, vs, closed)
                if isinstance(vs[i][2 + axis_i], tuple):          # ("on", line-like object): the point lies ON it
                    sk.CreatePointOnCurveConstraint(nxf.cg(geom, _cp(assoc)), nxf.cg(vs[i][2 + axis_i][1]),
                                                    nxf.help_at(self.p3(vs[i][0], vs[i][1])))
                    continue
                if abs(val) < EPS and vs[i][2 + axis_i] is None:
                    sk.CreatePointOnCurveConstraint(nxf.cg(geom, _cp(assoc)), nxf.cg(ref_axis), nxf.help_at(self.p3(vs[i][0], vs[i][1])))
                    continue
                formula = vs[i][2 + axis_i] if vs[i][2 + axis_i] is not None else _fmt(val)
                on_axis = self.p3(0.0, vs[i][1]) if axis_i == 0 else self.p3(vs[i][0], 0.0)
                txt = self.p3(vs[i][0] * (0.5 if axis_i == 0 else 1.0), vs[i][1] * (0.5 if axis_i == 1 else 1.0))
                nxf.pdim(sk, ref_axis, on_axis, geom, assoc, txt, formula)
                self.dbg.append("%s%d=%s" % ("uv"[axis_i], i, formula))
        for i, (cu, cv, rf) in arcs.items():
            if rf == FREE:
                continue
            a = vs[i]
            r = math.hypot(a[0] - cu, a[1] - cv)
            b = vs[(i + 1) % n]
            mu, mv = (a[0] + b[0]) / 2 - cu, (a[1] + b[1]) / 2 - cv
            mm = math.hypot(mu, mv) or 1.0
            on = self.p3(cu + mu / mm * r, cv + mv / mm * r)
            nxf.radius_dim(sk, segs[i][1], on, self.p3(cu + mu / mm * r * 0.6, cv + mv / mm * r * 0.6), rf if rf is not None else _fmt(r))
        if ref:
            nxf.to_reference(part, objs)
        else:
            self.curves += objs
            self.loops.append(objs)
        return objs

    # ---- extra constraints for coordinates left FREE
    def centre_on(self, arc, axis):
        """Arc centre on the horizontal ('h') or vertical ('v') datum axis."""
        c = arc.CenterPoint
        self.sk.CreatePointOnCurveConstraint(nxf.cg(arc, nxf.CP.ArcCenter), nxf.cg(self.hax if axis == "h" else self.vax),
                                             nxf.help_at(P(c.X, c.Y, c.Z)))

    def centre_dim(self, arc, axis, formula):
        """Distance of an arc centre from the vertical ('u' coordinate) or horizontal ('v' coordinate) datum axis."""
        c = arc.CenterPoint
        u, v = self.uv(c)
        if axis == "u":
            nxf.pdim(self.sk, self.vax, self.p3(0.0, v), arc, nxf.A.ArcCenter, self.p3(u * 0.5, v), formula)
        else:
            nxf.pdim(self.sk, self.hax, self.p3(u, 0.0), arc, nxf.A.ArcCenter, self.p3(u, v * 0.5), formula)

    def same_centre(self, arc1, arc2):
        """Concentric arcs. Arcs drawn about the same point already got this constraint when they were added
        (inferred coincidence): 'Constraint already exists' is then the expected answer."""
        try:
            self.sk.CreateCoincidentConstraint(nxf.cg(arc1, nxf.CP.ArcCenter), nxf.cg(arc2, nxf.CP.ArcCenter))
        except NXOpen.NXException as ex:
            if "already exists" not in str(ex):
                raise

    def tangent(self, c1, c2, at=None):
        """Tangent constraint; at = (u, v) of the point where the two curves touch (help point)."""
        hp = self.p3(*at) if at is not None else self.p3(0.0, 0.0)
        self.sk.CreateTangentConstraint(nxf.cg(c1), nxf.help_at(hp), nxf.cg(c2), nxf.help_at(hp))

    def uv(self, p):
        c = self.cfg
        q = (p.X - self.shift[0], p.Y - self.shift[1], p.Z - self.shift[2])
        return sum(q[k] * c["hdir"][k] for k in range(3)), sum(q[k] * c["vdir"][k] for k in range(3))

    def circle(self, cu, cv, d, cuf=None, cvf=None, df=None):
        part, sk, c = self.part, self.sk, self.cfg
        arc = part.Curves.CreateArc(self.p3(cu, cv), V(*[float(t) for t in c["hdir"]]), V(*[float(t) for t in c["vdir"]]),
                                    float(d) / 2, 0.0, 2 * math.pi)
        nxf.add(sk, arc, infer=False)
        for axis_i, val, f, ref_axis in ((0, cu, cuf, self.vax), (1, cv, cvf, self.hax)):
            if abs(val) < EPS and f is None:
                sk.CreatePointOnCurveConstraint(nxf.cg(arc, nxf.CP.ArcCenter), nxf.cg(ref_axis), nxf.help_at(self.p3(cu, cv)))
            else:
                on_axis = self.p3(0.0, cv) if axis_i == 0 else self.p3(cu, 0.0)
                nxf.pdim(sk, ref_axis, on_axis, arc, nxf.A.ArcCenter, self.p3(cu * 0.5, cv * 0.5), f if f is not None else _fmt(val))
        nxf.diameter_dim(sk, arc, self.p3(cu + d / 2, cv), self.p3(cu + d, cv + d), df if df is not None else _fmt(d))
        self.curves.append(arc)
        self.loops.append([arc])
        return arc

    def finish(self, strict=True):
        st = nxf.finish_sketch(self.sk)
        self.status = st
        if strict and not (st["status"] == "WellConstrained" and st["dof"] == 0 and st["auto_dims"] == 0):
            raise RuntimeError("sketch %s not fully constrained: %s dof %s auto %s; %d dims %s; log %s" % (
                self.name, st["status"], st["dof"], st["auto_dims"], len(st["dims"]), st["dims"], self.dbg))
        return st

    @property
    def feature(self):
        return self.sk.Feature

    def section(self, loop=None, help_uv=None):
        """Section of one loop (index) or of the whole sketch."""
        q = self.p3(*help_uv) if help_uv else self.p3(0.0, 0.0)
        hp = (q.X, q.Y, q.Z)
        if loop is None:
            return nxh.section_feature(self.part, [self.sk.Feature], hp, curves_only=True)
        cs = self.loops[loop]
        return nxh.section(self.part, curves=cs, help_point=hp)


def _cp(assoc):
    return {nxf.A.StartPoint: nxf.CP.StartVertex, nxf.A.EndPoint: nxf.CP.EndVertex, nxf.A.ArcCenter: nxf.CP.ArcCenter}[assoc]
