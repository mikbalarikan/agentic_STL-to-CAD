"""Export every body of a part as STL (sheets and convergent bodies included). Read-only.
usage: run_journal -Script export_ref.py -JArgs <part.prt>,<out dir>,<tag>[,<body indices comma separated or 'all'>]"""
import os, sys, traceback, time
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen, NXOpen.UF
import nxh, nxre

SRC, OUT, TAG = sys.argv[1:4]
WHICH = sys.argv[4] if len(sys.argv) > 4 else "all"
S = NXOpen.Session.GetSession()
UFS = NXOpen.UF.UFSession.GetUFSession()
res = {"result": "FAIL", "part": SRC, "bodies": []}
t0 = time.time()


def flush():
    nxh.write_json(os.path.join(OUT, f"export_{TAG}.json"), res)


def stl_creator(body, path, chord=0.01):
    if os.path.exists(path):
        os.remove(path)
    c = S.DexManager.CreateStlCreator()
    try:
        c.AutoNormalGen = True
        c.ChordalTol = chord
        c.AdjacencyTol = 0.01
        c.TriangleDisplay = False
        c.OutputFile = path
        c.ExportSelectionBlock.Add(body)
        c.Commit()
    finally:
        c.Destroy()
    return os.path.getsize(path) if os.path.exists(path) else 0


def stl_sheets(body, path, chord=0.01, max_edge=1.0):
    if os.path.exists(path):
        os.remove(path)
    h = UFS.Std.OpenBinaryStlFile(path, False, "nx")
    try:
        r = UFS.Std.PutSheetsInStlFile(h, 0, 0.0, float(max_edge), float(chord), 0.01, 1, [body.Tag])
    finally:
        UFS.Std.CloseStlFile(h)
    return os.path.getsize(path), str(r)[:80]


try:
    part = nxh.open_part(SRC)
    res["open_s"] = time.time() - t0
    try:
        c = S.DexManager.CreateStlCreator()
        res["stlcreator_dir"] = [n for n in dir(c) if not n.startswith("_")]
        c.Destroy()
    except Exception as e:
        res["stlcreator_dir"] = "EXC " + str(e)
    sel = None if WHICH == "all" else {int(v) for v in WHICH.split("+")}
    for i, b in enumerate(part.Bodies):
        if sel is not None and i not in sel:
            continue
        row = {"i": i, "tag": b.Tag, "solid": bool(b.IsSolidBody), "faces": len(b.GetFaces()), "bbox": nxh.bbox(b)}
        try:
            row["convergent"] = bool(b.IsConvergentBody)
        except Exception:
            row["convergent"] = None
        p = os.path.join(OUT, f"{TAG}_body{i}.stl")
        t1 = time.time()
        try:
            if b.IsSolidBody and not row["convergent"]:
                row["stl"] = ["uf_solid"] + list(nxre.stl_export(part, b, p, chord=0.01, max_edge=1.0))
            else:
                try:
                    row["stl"] = ["creator", stl_creator(b, p)]
                except Exception as e:
                    row["creator_exc"] = str(e)[:200]
                    row["stl"] = ["uf_sheets"] + list(stl_sheets(b, p))
        except Exception as e:
            row["stl"] = "EXC " + str(e)[:200]
        row["s"] = time.time() - t1
        res["bodies"].append(row)
        flush()
    res["seconds"] = time.time() - t0
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
flush()
