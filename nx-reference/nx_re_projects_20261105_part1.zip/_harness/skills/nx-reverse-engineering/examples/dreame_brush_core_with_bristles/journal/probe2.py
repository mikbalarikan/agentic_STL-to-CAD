﻿"""Probe 2: sketch on an offset plane (ps.Sketch with local datum axes), Swept from sketch section + sketch guide,
Trim Body of the tool by a datum plane, Move Object rotation by expression, Pattern Geometry with the Helix layout.
-> out/probe2.json"""
import os, sys, math, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXBLADE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\dreame_brush\nxlib")
import NXOpen, NXOpen.Features, NXOpen.GeometricUtilities as GU
import nxh, nxf
import nxblade as nb
import ps

OUT = sys.argv[1]
res = {"result": "FAIL", "notes": {}}
N = res["notes"]
F = ps.FREE
try:
    part = nxh.new_part(os.path.join(OUT, "probe2.prt"))
    dat = nxh.Datums(part)
    for n, v, u in (("z_core0", 6.5, "mm"), ("h_total", 169.75, "mm"), ("d_core", 14.95, "mm"), ("twist_lead", 225.75, "mm"), ("slot_w", 1.25, "mm"),
                    ("slot_neck_r", 6.05, "mm"), ("slot_foot_w", 2.2, "mm"), ("slot_floor_r", 4.88, "mm"), ("slot_ang0", 1.1, None),
                    ("tuft_pitch", 4.9, "mm"), ("tuft_ang_seed", 29.64, None), ("twist_sweep", "360*(h_total+1-z_core0)/twist_lead", None)):
        nxh.expr(part, n, v, u)
    nxh.expr(part, "n_tuft", 27, None)
    cylf, body = nxh.cylinder(part, (0, 0, "z_core0"), (0, 0, 1), "d_core", "h_total-z_core0")
    # offset plane + local axes
    fp, dp = nxf.datum_plane(part, "offset", [dat.xy], "z_core0", "DP_CORE0")
    fx, dax = nxf.datum_axis(part, "point_dir", (0, 0, "z_core0"), (1, 0, 0), "DA_CORE0_X")
    fy, day = nxf.datum_axis(part, "point_dir", (0, 0, "z_core0"), (0, 1, 0), "DA_CORE0_Y")
    o = nxh.point(part, 0, 0, "z_core0")
    S = ps.Sketch(part, dat, "xy", "SK_SLOT", on=dp, origin=o, hax=dax, vax=day, shift=(0.0, 0.0, 6.5))
    ro = 14.95 / 2 + 1.0
    verts = [(ro, -0.625, "d_core/2+1", "slot_w/2"), (ro, 0.625, None, "slot_w/2"), (6.05, 0.625, "slot_neck_r", None), (4.88, 1.1, "slot_floor_r", "slot_foot_w/2"),
             (4.88, -1.1, None, "slot_foot_w/2"), (6.05, -0.625, "slot_neck_r", None)]
    cs = S.profile(verts)
    st = S.finish(strict=False)
    N["sk_slot"] = {k: (v if k != "dims" else len(v)) for k, v in st.items()}
    # guide: sketch line on XZ along Z
    G = ps.Sketch(part, dat, "xz", "SK_AXIS")
    gl = G.profile([(0.0, 6.5, None, "z_core0"), (0.0, 170.75, None, "h_total+1")], closed=False)
    stg = G.finish(strict=False)
    N["sk_axis"] = {k: (v if k != "dims" else len(v)) for k, v in stg.items()}
    f = nb.swept(part, [S.section(0, (ro, 0.0))], [nxh.section_feature(part, [G.feature], (0, 0, 6.5), curves_only=True)],
                 orientation="angular", angles=("-slot_ang0", "-slot_ang0+twist_sweep"), solid=True)
    tool = f.GetBodies()[0]
    N["tool"] = {"solid": bool(tool.IsSolidBody), "vol": nxh.volume(part, tool), "bbox": nxh.bbox(tool)}
    N["swept_expr"] = [(e.Name, e.RightHandSide) for e in f.GetExpressions()]
    # where is the neck corner at mid height?
    K = 360 / 225.75
    def at(p, zz):
        a = math.radians(1.1 - K * (zz - 6.5))
        return (p[0] * math.cos(a) - p[1] * math.sin(a), p[0] * math.sin(a) + p[1] * math.cos(a), zz)
    N["probe_dist"] = {zz: max(abs(nxh.dist_to(part, tool, at(p, zz))) for p in ((6.05, 0.625), (4.88, 1.1), (7.0, -0.625))) for zz in (6.5001, 50.0, 120.0, 170.0)}
    # trim the tool by a datum plane at z = 33 (keep the upper part)
    fpz, dpz = nxf.datum_plane(part, "offset", [dat.xy], "33", "DP_Z33")
    try:
        tf = nxf.trim_body(part, tool, keep_point=at((5.5, 0.0), 100.0), datum_plane=dpz)
        N["trim"] = {"vol": nxh.volume(part, tool), "bbox": nxh.bbox(tool)}
    except Exception:
        N["trim_exc"] = traceback.format_exc()[-600:]
    # Move Object: rotate a seed body about Z by an expression
    cf, seed = nxh.cylinder(part, (9.0, 0, 20.0), (1, 0, 0), 2.0, 4.0)
    try:
        import inspect
        N["move_object_doc"] = (nxf.move_object.__doc__ or "")[:900]
        mf = nxf.move_object(part, [seed], "angle", "tuft_ang_seed", vec=(0, 0, 1), origin=(0, 0, 0))
        N["move"] = {"type": mf.FeatureType if hasattr(mf, "FeatureType") else str(type(mf)), "bbox": nxh.bbox(seed)}
    except Exception:
        N["move_exc"] = traceback.format_exc()[-900:]
    # Pattern Geometry, helix layout
    b = part.Features.CreatePatternGeometryBuilder(NXOpen.Features.PatternGeometry.Null)
    try:
        psv = b.PatternService
        psv.PatternType = GU.PatternDefinition.PatternEnum.Helix
        hd = psv.HelixDefinition
        N["helix_size_options"] = nxh.enum_names(type(hd).SizeOptions) if hasattr(type(hd), "SizeOptions") else nxh.enum_names(hd.SizeOptions)
        N["helix_dir_types"] = nxh.enum_names(GU.HelixPatternDirectionTypes)
        N["helix_defaults"] = {"size": str(hd.SizeOption), "dir": str(hd.DirectionType)}
        hd.RotationAxis = nxh.axis(part, (0, 0, 0), (0, 0, 1))
        hd.DirectionType = GU.HelixPatternDirectionTypes.Lefthand
        opts = N["helix_size_options"]
        N["try"] = {}
        before = list(part.Bodies)
        done = False
        for on in opts:
            try:
                hd.SizeOption = getattr(type(hd).SizeOptions, on)
                hd.CountOfInstances.RightHandSide = "n_tuft"
                if "Angle" in on:
                    hd.AnglePitch.RightHandSide = "360*tuft_pitch/twist_lead"
                if "Distance" in on:
                    hd.DistancePitch.RightHandSide = "tuft_pitch"
                if "Helix" in on or "Pitch" in on.replace("Distance", ""):
                    hd.HelixPitch.RightHandSide = "twist_lead"
                N["try"][on] = "set"
                if "Count" in on and "Angle" in on and "Distance" in on and not done:
                    b.GeometryToPattern.Add(seed)
                    pf = b.CommitFeature()
                    done = True
                    N["try"][on] = "committed"
                    break
            except Exception as ex:
                N["try"][on] = "EXC " + str(ex)[:150]
    finally:
        b.Destroy()
    newb = nxh.new_bodies(part, before)
    N["helix_new_bodies"] = len(newb)
    cen = []
    for bb in [seed] + list(newb):
        x = nxh.bbox(bb)
        cx, cy, cz = (x[0] + x[3]) / 2, (x[1] + x[4]) / 2, (x[2] + x[5]) / 2
        cen.append((round(math.hypot(cx, cy), 3), round(math.degrees(math.atan2(cy, cx)), 2), round(cz, 3)))
    cen.sort(key=lambda t: t[2])
    N["helix_instances_r_theta_z"] = cen[:5] + cen[-2:]
    res["features"] = [(x["name"], x["type"]) for x in nxh.feature_table(part)]
    res["feature_errors"] = nxh.feature_errors(part)
    nxh.save(part)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "probe2.json"), res)

