# Worked example: twisted brush core with bristles, two scans -> native parametric NX part

A real job (2026-10-08, NX 2206 batch), kept as an end-to-end reference for class E work on a part that is
NOT prismatic: a 170 mm moulded core whose section twists along its length, with a stepped drive end, an
underside that only a second scan shows, and two helical rows of soft bristle tufts. The user called the
result a success. `REPORT.md` is the delivered report (Turkish) with every number; this page says what the
example shows and what is reusable.

## Result

| | |
|---|---|
| Model | 1 solid core + 54 separate tuft solids; 61 top-level features, 13 sketches (all DOF 0, 0 automatic dimensions), 76 named expressions |
| Journal checks | 63 / 63 (volume delta after every feature, solid count, point-on-face probes, feature errors) |
| Regeneration | 12 masters changed one at a time, no errors, volume back at nominal within 1e-6 |
| STEP AP242 round trip | 55 solids, largest relative volume difference 3.0e-5, Examine Geometry clean |
| Scan -> CAD, hard surfaces | 645 115 points of the full-resolution scan: RMS 0.088, p50 0.035, **p95 0.159**, p99 0.370, max 1.234 mm |
| Underside against the second scan | p95 0.21 mm |
| Bristle zone (soft, outside any band) | p50 0.50, p95 1.33 mm |
| CAD surface with no scan within 1 mm | 11 % (slot feet, tuft holes, socket and bore bottoms): unverified, and reported as such |
| NX runs | 3 probe journals (5 runs) + 8 build runs (the last full run 8.5 min incl. the regeneration test) |

Verification was done by the builder; there was no independent QA and the part was never opened in the GUI.

## What it shows

1. **Check the "reference" before building on it.** The user asked to take an existing CAD as the base and
   only add the base details and the bristles. Its own embedded scan and the target scan disagreed: 5 drive
   blades / 5 slots / flange r 14.5 / lead 326.6 against 4 / 4 / r 16.45 / 225.8. It was the core of the sister
   brush. Two section plots side by side settled it in minutes (`analysis/b0_baseline.py`, `b3_compare.py`,
   `figures/01_...png`); the user was told at once and the part was rebuilt from its own scan.
   `journal/probe_ref.py` + `export_ref.py` are the read-only inspection of that reference (feature tree, free
   edges of its sheet body, every body out as STL - also sheets and the convergent body).
2. **Measure a twisted part by untwisting it.** `analysis/m2_twist.py`: r(theta) profile per 2 mm slab, shift
   from slab to slab by a WINDOWED cross-correlation (the section is nearly 4-fold symmetric: an unconstrained
   search wraps by 90 deg and returned a wrong rate), linear fit -> -1.5946 deg/mm. Then every core point is
   turned back by its own height and pooled: one sharp 2D section of the whole length
   (`figures/11_...png`), from which slots, grooves and blends are fitted as ordinary 2D primitives
   (`m3_profile.py`, `m3_small.py`, `m3_vgroove.py`). Features that vary along the axis show up as a smear and
   are measured per z band.
3. **Build the twist as tools, not as one twisted profile.** The lands stay ONE analytic cylinder. Each cut
   is a small symmetric sketch drawn once on the plane at the start of the core, swept as a solid with
   Swept / By Angular Law about a sketch line on the axis, copied with Pattern Geometry and subtracted by
   feature rule (`journal/build.py`, `twisted_cut`). The angular position of each family is the START value
   of the law, the twist is one expression (`twist_lead`). Edge Blends on the 16 helical edges are picked
   by their untwisted angle.
4. **Two scans, one frame.** The core scan stood on its drive end, so the underside is missing; a second
   scan shows that end of the assembled brush. It was registered by trimmed point-to-plane ICP on the
   surfaces both scans share, from 36 start clockings (`analysis/m7_base_align.py`). Two honest findings came
   out of it and went into the report instead of being tuned away: the clock is ambiguous by 180 deg (the
   part is 2-fold symmetric), and the whole underside sits 0.23 mm off the hub disc in that scan.
5. **Soft features.** Tuft roots, pitch and row angle are measured in radial shells of the untwisted
   point cloud (`m6_tufts.py`, `figures/12_...png`); lean and length come from the shell-to-shell shift.
   The tufts are separate solids (cylinder in the hole, cone outside), the holes a helix pattern of a
   tool body; depth of the holes and flare of the tufts are stated assumptions.
6. **Deviation in both directions, by zone, with the masks written down** (`analysis/dev.py`,
   `dev_c2s.py`, `dev_outliers.py`): table / bristle zone / hard surfaces; where the points beyond 0.8 mm
   are and why; how much of the CAD no scan sees.

## Files

| Folder | Content |
|---|---|
| `REPORT.md` | the delivered report: alignment, feature tree, masters, what changed at the base, how the bristles are modelled, verification, deviation tables, 13 declared simplifications |
| `result/` | `dreame_brush_core_with_bristles.prt` (NX 2206), `.step` (AP242, 55 solids) |
| `journal/build.py` | the whole build in stages a-d + z (regeneration test, STEP, STL); `run.ps1`, `show.py` run it and print the check table |
| `journal/nxlib/ps.py`, `geo.py` | profile sketches from vertex lists (DOF 0); `ps.tangent(c1, c2, at=)` is the corrected call |
| `journal/probe1-3.py` | the three probes that settled unknown builder behaviour before the build (below) |
| `journal/probe_ref.py`, `export_ref.py`, `review.py` | inspection of the reference part; review part with the scans as convergent bodies on layers 10 / 11 |
| `analysis/` | numpy / open3d scripts: `common.py` (memory-mapped STL, sections, signed closest distance), `m1`-`m8` measurements, `dev*.py`, `ovl.py`, `render.py` |
| `qa/` | `build_checks.json`, `masters.json`, alignment matrices, every measurement and deviation JSON |
| `figures/` | 14 of the 21 report figures, the large ones reduced in size |

Not in the repo: the scans (inputs, 20-320 MB), the review part with scans (20 MB), the CAD tessellations.
They are in `Downloads\dreame_brush_core_with_bristles_nx` and `C:\NX_MCP_WORKSPACE\dreame_brush` on the
machine the job ran on. The sources are kept as they ran: `build.py` and `analysis/common.py` carry those
absolute paths, and the analysis scripts need the `cadgenbench` venv (open3d, pyvista).

## Measured in NX 2206 batch during this job (not yet in the skill texts)

- Swept, `OrientationOption.ByAngularLaw`, straight guide: an OFF-AXIS section turns about the guide.
  0.004 mm from the true helicoid over 163 mm and 260 deg; volume = section area x length to 9e-5. A
  positive law angle is a left-hand twist; a start value `-a` puts a section drawn at 0 at `+a`.
- Law angles and pattern pitches built from lengths (`360*len/lead`) need UNITLESS expressions; with a
  Degrees master the formula is refused ("Dimension mismatch (binary operation)").
- Pattern Feature and Pattern Geometry have a `Helix` layout: `PatternService.HelixDefinition`,
  `SizeOptions.CountAngleDistance`, `GeometricUtilities.HelixPatternDirectionTypes.Lefthand`. Pattern
  Geometry accepts ONE body per helix pattern; with two bodies it answers "The total number of instances
  must be greater than 1."
- `Sketch.CreateTangentConstraint` takes four arguments: geometry, help point, geometry, help point.
- A sketch on an offset plane dimensioned from datum axes created ON that plane, a Trim Body of a tool by
  a datum plane, and Move Object by an angle expression all behave as the skills say.
- `UFS.Std.PutSolidInStlFile` refuses sheet and convergent bodies; `Session.DexManager.CreateStlCreator()`
  writes both (a 2.9 M facet convergent body in 47 s).
- `inspect_part.py` took 95 s on the reference part whose product body is a sheet, and ran into its 25 min
  timeout on the later version of that part, which holds a 540-face solid next to the same 2.9 M facet
  convergent body. A plain feature / body dump (`probe_ref.py`) of the first one took 3 min.
- Three build errors worth recognising: a cut made before the material it reaches into existed removed
  less than its prism (caught by the volume delta); two cuts that nearly touch left a 0.003 mm3 loose
  sliver (caught by the solid count; fixed by making the cuts overlap); a limit given as an absolute height
  failed when the overall-length master was shortened in the regeneration test (tie it to the end face).
