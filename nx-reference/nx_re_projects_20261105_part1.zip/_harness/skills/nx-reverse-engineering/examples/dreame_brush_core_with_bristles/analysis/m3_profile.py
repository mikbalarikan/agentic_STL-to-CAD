"""Numbers of the untwisted core section (pooled points of m2): land radius, 4 slots (centre angle, neck width,
neck end, foot width, floor radius, mouth round), small grooves, V-flats with their centre groove.
Writes qa/m3_profile.json."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import *

d = np.load(os.path.join(QA, "m2_core_pts.npz"))
xu, yu, z, nr = d["xu"].astype(float), d["yu"].astype(float), d["z"].astype(float), d["nr"].astype(float)
r = np.hypot(xu, yu)
out = {}


def rot(a):
    c, s = np.cos(np.radians(a)), np.sin(np.radians(a))
    return xu * c + yu * s, -xu * s + yu * c


def peak(v, lo, hi, bw=0.005):
    """mode of v within [lo, hi] (centre of the densest bin, refined by the local mean)."""
    s = v[(v > lo) & (v < hi)]
    h, e = np.histogram(s, bins=np.arange(lo, hi + bw, bw))
    hs = np.convolve(h, np.ones(5) / 5, mode="same")
    i = int(np.argmax(hs))
    c = 0.5 * (e[i] + e[i + 1])
    w = s[np.abs(s - c) < 0.04]
    return float(w.mean()), int(len(w))


def circ(q, it=10):
    w = np.ones(len(q))
    for _ in range(it):
        A = np.c_[2 * q, np.ones(len(q))] * w[:, None]
        sol, *_ = np.linalg.lstsq(A, (q ** 2).sum(1) * w, rcond=None)
        c = sol[:2]; rad = np.sqrt(sol[2] + c @ c)
        res = np.linalg.norm(q - c, axis=1) - rad
        s = max(1.4826 * np.median(np.abs(res)), 0.005)
        w = 1 / (1 + (res / (2.5 * s)) ** 2)
    k = np.abs(res) < 3 * s
    return c, float(rad), float(np.sqrt((res[k] ** 2).mean())), int(k.sum())


land = (nr > 0.97) & (r > 7.25) & (r < 7.7)
out["land_r"] = {"median": float(np.median(r[land])), "p05": float(np.percentile(r[land], 5)), "p95": float(np.percentile(r[land], 95)),
                 "by_z": {f"{a}-{a+30}": float(np.median(r[land & (z >= a) & (z < a + 30)])) for a in range(8, 158, 30)}}
slots = []
for q in range(4):
    u, v = rot(90.0 * q)
    neck = (u > 6.25) & (u < 7.0) & (np.abs(v) < 1.3)
    vl, nl = peak(v[neck], -0.9, -0.3)
    vr, nrr = peak(v[neck], 0.3, 1.0)
    # wall straightness / taper: line fit v(u) on each wall
    tl = np.polyfit(u[neck & (np.abs(v - vl) < 0.06)], v[neck & (np.abs(v - vl) < 0.06)], 1)
    tr = np.polyfit(u[neck & (np.abs(v - vr) < 0.06)], v[neck & (np.abs(v - vr) < 0.06)], 1)
    vc = 0.5 * (vl + vr)
    fl = (np.abs(v - vc) < 0.8) & (u > 4.6) & (u < 5.15)
    uf, nf = peak(u[fl], 4.6, 5.15)
    # foot width: extent of the floor band along v (2 % .. 98 % of points within 0.05 of the floor)
    fb = (np.abs(u - uf) < 0.05) & (np.abs(v - vc) < 1.8)
    f0, f1 = np.percentile(v[fb], [1.5, 98.5])
    # neck end: lowest u where the wall density is still >= 30 % of the mid-neck density
    def wall_end(vw):
        s = (np.abs(v - vw) < 0.05) & (u > 5.2) & (u < 7.0)
        h, e = np.histogram(u[s], bins=np.arange(5.2, 7.01, 0.05))
        ref = np.median(h[(e[:-1] > 6.3) & (e[:-1] < 6.9)])
        ok = np.where(h >= 0.3 * ref)[0]
        return float(e[ok[0]])
    # mouth round: circle fit of points between the wall and the land
    mouth = []
    for sgn, vw in ((-1, vl), (1, vr)):
        m = (u > 6.95) & (u < 7.6) & (sgn * (v - vw) > -0.03) & (sgn * (v - vw) < 0.45) & (r < 7.44)
        if m.sum() > 200:
            c, rad, rms, n = circ(np.c_[v[m], u[m]])
            mouth.append(round(rad, 3))
    ang = 90.0 * q + np.degrees(np.arctan2(vc, 6.6))
    slots.append({"q": q, "wall_v": [round(vl, 4), round(vr, 4)], "neck_w": round(vr - vl, 4), "centre_v": round(vc, 4), "centre_angle_deg": round(float(ang), 3),
                  "wall_slope_deg": [round(float(np.degrees(np.arctan(tl[0]))), 2), round(float(np.degrees(np.arctan(tr[0]))), 2)],
                  "floor_u": round(uf, 4), "foot_v": [round(float(f0), 3), round(float(f1), 3)], "foot_w": round(float(f1 - f0), 3),
                  "neck_end_u": [round(wall_end(vl), 2), round(wall_end(vr), 2)], "mouth_R": mouth})
out["slots"] = slots
out["slot_mean"] = {k: round(float(np.mean([s[k] for s in slots])), 4) for k in ("neck_w", "floor_u", "foot_w")}
out["slot_mean"]["theta0_deg"] = round(float(np.mean([s["centre_angle_deg"] - 90 * s["q"] for s in slots])), 3)
out["slot_mean"]["neck_end_u"] = round(float(np.mean([np.mean(s["neck_end_u"]) for s in slots])), 3)

# small grooves: search the centre angle near 60 / 240
sg = []
for a0 in (60.0, 240.0):
    u, v = rot(a0)
    m = (np.abs(v) < 0.55) & (u > 6.7) & (u < 7.25) & (nr > 0.8)
    c, rad, rms, n = circ(np.c_[v[m], u[m]])
    ang = a0 + np.degrees(np.arctan2(c[0], c[1]))
    rho = float(np.hypot(*c))
    # shoulder rounds
    sh = []
    for sgn in (-1, 1):
        mm = (sgn * v > 0.75) & (sgn * v < 1.35) & (u > 7.15) & (u < 7.6) & (nr > 0.8)
        if mm.sum() > 200:
            cc, rr, _, _ = circ(np.c_[v[mm], u[mm]])
            sh.append(round(rr, 3))
    sg.append({"angle_deg": round(float(ang), 3), "R": round(rad, 4), "centre_rho": round(rho, 4), "floor_r": round(rho - rad, 4), "rms": round(rms, 4), "n": n, "shoulder_R": sh})
out["small_grooves"] = sg

# V-flats at 135 / 315: lines on both sides, peaks, centre groove
vf = []
for a0 in (135.0, 315.0):
    u, v = rot(a0)
    rowd = {}
    for name, lo, hi in (("left", -2.2, -1.0), ("right", 1.0, 2.2)):
        m = (v > lo) & (v < hi) & (u > 6.4) & (u < 7.1) & (nr > 0.7)
        c = np.polyfit(v[m], u[m], 1)
        res = u[m] - np.polyval(c, v[m])
        k = np.abs(res) < 3 * np.std(res)
        c = np.polyfit(v[m][k], u[m][k], 1)
        rowd[name] = {"slope_deg": round(float(np.degrees(np.arctan(c[0]))), 3), "u_at_v0": round(float(c[1]), 4), "rms": round(float(np.std(u[m][k] - np.polyval(c, v[m][k]))), 4)}
    # where the lines meet the land circle
    rl = out["land_r"]["median"]
    ends = []
    for name in ("left", "right"):
        s, b = np.tan(np.radians(rowd[name]["slope_deg"])), rowd[name]["u_at_v0"]
        # (s v + b)^2 + v^2 = rl^2
        A, B, C = s * s + 1, 2 * s * b, b * b - rl * rl
        roots = np.roots([A, B, C])
        vv = roots[np.argmin(np.abs(roots - (-2.7 if name == "left" else 2.7)))].real
        ends.append(round(float(np.degrees(np.arctan2(vv, s * vv + b))), 3))
    rowd["land_junction_deg_from_axis"] = ends
    # centre groove: floor radius by z band, width, centre
    g = (np.abs(v) < 1.0) & (u > 5.8) & (u < 6.75)
    fl = {}
    for za in range(10, 165, 10):
        mm = g & (np.abs(v) < 0.25) & (z >= za) & (z < za + 10)
        if mm.sum() > 30:
            fl[f"{za}"] = round(float(np.percentile(u[mm], 10)), 3)
    rowd["groove_floor_r_by_z"] = fl
    # groove shape where it is deepest
    mm = g & (z > 45) & (z < 160) & (u < 6.5) & (nr > 0.6)
    rowd["groove_centre_v"] = round(float(np.median(v[mm])), 3)
    zz = z[mm]
    vf.append({"axis_deg": a0, **rowd})
out["v_flats"] = vf
json.dump(out, open(os.path.join(QA, "m3_profile.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
