"""Remaining numbers from the full-resolution with-bristles scan: blade crown / wall (tangent-constrained fit),
blade corner round, top end round, top notch, rim bottom edge, land radius.  qa/m8_misc.json"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import *

T = load_T("T_bristles.json")
k = json.load(open(os.path.join(QA, "m2_twist.json")))["twist_deg_per_mm"]
m = Mesh(apply(T, read_stl(SCAN_BRISTLES_FULL)))
r0 = np.hypot(m.c[:, 0], m.c[:, 1])
out = {}
# ---------------- blade outline (C4 folded wall points)
b = m.sub((m.c[:, 2] > 4.7) & (m.c[:, 2] < 6.45) & (r0 < 15.7) & (r0 > 4.3))
P, idx = b.sample(700_000, seed=1)
N = b.n[idx]
r, th, z = cyl(P)
wall = (np.abs(N[:, 2]) < 0.3) & (z > 4.9) & (z < 6.25)
q = np.floor(((th + 3.0) % 360.0) / 90.0)
tf = np.radians(th - 90.0 * q)
fx, fy = (r * np.cos(tf))[wall], (r * np.sin(tf))[wall]
R_OUT = float(np.median(np.hypot(fx, fy)[(np.degrees(np.arctan2(fy, fx)) > 10) & (np.degrees(np.arctan2(fy, fx)) < 50) & (np.hypot(fx, fy) > 14.7)]))
out["blade_outer_r"] = round(R_OUT, 4)
EDGE = float(np.median(fy[(fx > 7.5) & (fx < 14.0) & (np.abs(fy - 1.14) < 0.3)]))
out["blade_edge_y"] = round(EDGE, 4)
# crown + wall: circle of radius Rc tangent inside to the outer circle and to the line x = xw
sel = (fx > -0.2) & (fx < 9.0) & (fy > 6.6) & (np.hypot(fx, fy) < R_OUT - 0.05)
X, Y = fx[sel], fy[sel]
best = None
for xw in np.arange(0.30, 0.85, 0.02):
    for Rc in np.arange(4.2, 5.4, 0.02):
        cx = xw + Rc
        cy2 = (R_OUT - Rc) ** 2 - cx ** 2
        if cy2 <= 0:
            continue
        cy = np.sqrt(cy2)
        # composite curve: wall line for y < cy, arc for y >= cy (left / upper part of the circle up to the tangency with the outer circle)
        d_arc = np.abs(np.hypot(X - cx, Y - cy) - Rc)
        d_line = np.abs(X - xw)
        d = np.where((Y < cy) & (X < cx), d_line, d_arc)
        ang_t = np.arctan2(cy, cx)                                  # tangency with the outer circle lies on the ray through the centre
        on = ~((np.arctan2(Y - cy, X - cx) < ang_t) & (np.arctan2(Y - cy, X - cx) > -1.2))   # drop points beyond the tangency (they belong to the outer arc)
        e = np.sqrt(np.mean(np.minimum(d[on], 0.5) ** 2))
        if best is None or e < best[0]:
            best = (e, xw, Rc, cx, cy, int(on.sum()))
out["blade_crown_fit"] = {"rms_clipped": round(best[0], 4), "wall_x": round(best[1], 3), "crown_R": round(best[2], 3), "centre": [round(best[3], 3), round(best[4], 3)], "n": best[5]}
# corner round between the straight edge and the outer circle
sel = (fx > 14.2) & (fy > 0.9) & (fy < 2.6) & (np.hypot(fx, fy) < R_OUT - 0.03) & (fy > EDGE + 0.03)
if sel.sum() > 100:
    bestc = None
    for Rk in np.arange(0.15, 1.2, 0.02):
        cyk = EDGE + Rk
        cxk = np.sqrt(max((R_OUT - Rk) ** 2 - cyk ** 2, 0))
        e = np.sqrt(np.mean(np.minimum(np.abs(np.hypot(fx[sel] - cxk, fy[sel] - cyk) - Rk), 0.3) ** 2))
        if bestc is None or e < bestc[0]:
            bestc = (e, Rk)
    out["blade_corner_R"] = {"R": round(bestc[1], 3), "rms": round(bestc[0], 4), "n": int(sel.sum())}
# ---------------- top end
t = m.sub((m.c[:, 2] > 163) & (r0 < 9))
P, idx = t.sample(700_000, seed=2)
N = t.n[idx]
r, th, z = cyl(P)
nr = (N[:, 0] * P[:, 0] + N[:, 1] * P[:, 1]) / np.maximum(r, 1e-9)
ZT = float(np.median(z[(N[:, 2] > 0.97) & (r > 6.15) & (r < 6.75) & (z > 169.3)]))
RL = float(np.median(r[(nr > 0.97) & (r > 7.3) & (r < 7.65) & (z > 164) & (z < 168)]))
out["top_face_z"], out["land_r_near_top"] = round(ZT, 4), round(RL, 4)
sel = (r > 6.4) & (r < RL + 0.1) & (z > 167.6) & (z < ZT + 0.1) & (nr > 0.15) & (N[:, 2] > 0.15)
bestr = None
for Rk in np.arange(0.4, 2.0, 0.02):
    e = np.sqrt(np.mean(np.minimum(np.abs(np.hypot(r[sel] - (RL - Rk), z[sel] - (ZT - Rk)) - Rk), 0.3) ** 2))
    if bestr is None or e < bestr[0]:
        bestr = (e, Rk)
out["end_round_outer"] = {"R": round(bestr[1], 3), "rms": round(bestr[0], 4), "n": int(sel.sum())}
# elliptical alternative: axial extent a, radial extent b of the rounded corner
zs = z[sel & (r > RL - 0.06)]
out["end_round_starts_at_z"] = round(float(np.percentile(zs, 97)), 3) if len(zs) > 20 else None
rs_ = r[sel & (z > ZT - 0.05)]
out["end_round_ends_at_r"] = round(float(np.percentile(rs_, 3)), 3) if len(rs_) > 20 else None
sel = (r > 5.6) & (r < 6.5) & (z > 168.9) & (nr < -0.15) & (N[:, 2] > 0.15)
if sel.sum() > 100:
    RC = float(np.median(r[(nr < -0.95) & (r > 5.6) & (r < 6.2) & (z > 168.7) & (z < 169.3)]))
    bi = None
    for Rk in np.arange(0.1, 1.0, 0.02):
        e = np.sqrt(np.mean(np.minimum(np.abs(np.hypot(r[sel] - (RC + Rk), z[sel] - (ZT - Rk)) - Rk), 0.3) ** 2))
        if bi is None or e < bi[0]:
            bi = (e, Rk)
    out["end_round_inner"] = {"R": round(bi[1], 3), "rms": round(bi[0], 4), "cbore_r": round(RC, 4), "n": int(sel.sum())}
out["cbore_floor_z"] = round(float(np.median(z[(N[:, 2] > 0.95) & (r > 4.6) & (r < 5.6) & (z > 168.0) & (z < 169.0)])), 4)
out["bore_r"] = round(float(np.median(r[(nr < -0.9) & (r > 3.9) & (r < 4.7) & (z > 165.5) & (z < 168.2)])), 4)
bb = (r < 4.1) & (N[:, 2] > 0.8) & (z > 163.5) & (z < 167.5)
out["bore_bottom"] = {"n": int(bb.sum()), "z_median": round(float(np.median(z[bb])), 3) if bb.sum() > 30 else None, "r_range": [round(float(v), 2) for v in np.percentile(r[bb], [2, 98])] if bb.sum() > 30 else None}
# notches of the end ring: occupancy by angle at three heights
ring_gaps = {}
for zc in (169.5, 169.2, 168.9, 168.6):
    s = (r > 6.05) & (r < 7.35) & (np.abs(z - zc) < 0.12)
    h, e = np.histogram(th[s] % 360, bins=np.arange(0, 360.5, 0.5))
    hs = np.convolve(np.r_[h[-4:], h, h[:4]], np.ones(5) / 5, mode="same")[4:-4]
    low = hs < 0.2 * np.median(hs)
    runs = []
    i = 0
    while i < len(low):
        if low[i]:
            j = i
            while j < len(low) and low[j]:
                j += 1
            runs.append([round(float(e[i]), 1), round(float(e[j]), 1)])
            i = j
        else:
            i += 1
    ring_gaps[str(zc)] = [{"from": a, "to": b_, "width_mm": round(float(np.radians(b_ - a) * 6.7), 2), "centre_untwisted": round(float(((a + b_) / 2 - k * (zc - 6.5)) % 360), 1)} for a, b_ in runs if b_ - a > 2]
out["ring_gaps"] = ring_gaps
# floor of the wide notch
wn = (np.abs(((th % 360) - 199 + 180) % 360 - 180) < 9) & (r > 6.0) & (r < 7.4) & (N[:, 2] > 0.8) & (z > 166)
out["wide_notch_floor_z"] = {"n": int(wn.sum()), "median": round(float(np.median(z[wn])), 3) if wn.sum() > 20 else None}
# ---------------- rim bottom edge (chamfer / round) from the core scan
s2 = m.sub((m.c[:, 2] < 1.6) & (r0 > 14.5) & (r0 < 17))
P, idx = s2.sample(300_000, seed=3)
r, th, z = cyl(P)
N = s2.n[idx]
nr = (N[:, 0] * P[:, 0] + N[:, 1] * P[:, 1]) / np.maximum(r, 1e-9)
sel = (nr > 0.2) & (nr < 0.97) & (N[:, 2] < -0.2) & (z > 0.02)
out["rim_bottom_edge"] = {"n": int(sel.sum())}
if sel.sum() > 200:
    out["rim_bottom_edge"].update({"r_range": [round(float(v), 3) for v in np.percentile(r[sel], [3, 97])], "z_range": [round(float(v), 3) for v in np.percentile(z[sel], [3, 97])],
                                   "normal_angle_from_radial_deg_median": round(float(np.degrees(np.arccos(np.clip(np.median(nr[sel]), -1, 1)))), 1)})
json.dump(out, open(os.path.join(QA, "m8_misc.json"), "w"), indent=1)
for a, v in out.items():
    print(a, json.dumps(v))
