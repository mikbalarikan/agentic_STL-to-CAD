"""Bristle tufts: root positions (27 per row), pitch, row angle, root size; lean of the tufts from the shell-to-shell
shift of the periodic row pattern; tip radius. Uses qa/m6_pts.npz. Writes qa/m6_tufts.json, fig/m6_tufts.png."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

k = json.load(open(os.path.join(QA, "m2_twist.json")))["twist_deg_per_mm"]
P = np.load(os.path.join(QA, "m6_pts.npz"))["P"].astype(float)
r, th, z = cyl(P)
tu = (th - k * (z - 6.5)) % 360.0
out = {"twist_deg_per_mm": k}
fig, axs = plt.subplots(2, 3, figsize=(30, 18))
for row, (c0, name) in enumerate(((36.0, "A"), (215.0, "B"))):
    dth = ((tu - c0 + 180) % 360) - 180
    root = (r > 7.85) & (r < 8.45) & (np.abs(dth) < 14) & (z > 6.8) & (z < 150)
    zr, dr = z[root], dth[root]
    h, e = np.histogram(zr, bins=np.arange(6.8, 150.01, 0.1))
    hs = np.convolve(h, np.ones(9) / 9, mode="same")
    # blobs = runs above a threshold
    thr = 0.12 * np.percentile(hs, 95)
    on = hs > thr
    runs = []
    i = 0
    while i < len(on):
        if on[i]:
            j = i
            while j < len(on) and on[j]:
                j += 1
            if (j - i) * 0.1 > 1.0:
                runs.append((e[i], e[j]))
            i = j
        else:
            i += 1
    tufts = []
    for a, b in runs:
        s = (zr >= a) & (zr <= b)
        # centre of the ring = midpoint of robust extents (the ring is hollow in the shell)
        z0, z1 = np.percentile(zr[s], [2, 98]); d0, d1 = np.percentile(dr[s], [2, 98])
        tufts.append({"z": 0.5 * (z0 + z1), "dth": 0.5 * (d0 + d1), "len_z": z1 - z0, "wid_deg": d1 - d0, "n": int(s.sum())})
    zz = np.array([t["z"] for t in tufts]); dd = np.array([t["dth"] for t in tufts])
    ii = np.arange(len(zz))
    pz = np.polyfit(ii, zz, 1)
    out[f"row_{name}"] = {"count": len(tufts), "z_first": round(float(zz[0]), 3), "z_last": round(float(zz[-1]), 3), "pitch_fit": round(float(pz[0]), 4), "z0_fit": round(float(pz[1]), 4),
                         "z_fit_rms": round(float(np.std(zz - np.polyval(pz, ii))), 4), "angle_untwisted_mean": round(float(c0 + dd.mean()), 3),
                         "angle_std": round(float(dd.std()), 3), "angle_trend_deg_per_tuft": round(float(np.polyfit(ii, dd, 1)[0]), 4),
                         "root_len_z_median": round(float(np.median([t["len_z"] for t in tufts])), 3),
                         "root_wid_mm_median": round(float(np.radians(np.median([t["wid_deg"] for t in tufts])) * 8.15), 3),
                         "gaps": np.round(np.diff(zz), 2).tolist()}
    ax = axs[row, 0]
    ax.plot(ii, zz - np.polyval(pz, ii), "k.-"); ax.plot(ii, (dd - dd.mean()) * np.radians(1) * 8.15, "r.-")
    ax.grid(True); ax.set_title(f"row {name}: root residuals: z vs linear fit (black, mm), tangential offset (red, mm)")
    # lean: phase of the z-periodic pattern and mean angle per radial shell
    p = pz[0]
    rs = np.arange(7.9, 17.01, 0.3)
    ph, am, ang, nn = [], [], [], []
    prev_c = dd.mean()
    for r0 in rs:
        s = (r >= r0) & (r < r0 + 0.3) & (np.abs(dth - prev_c) < 16) & (z > 6.8) & (z < 160)
        if s.sum() < 300:
            ph.append(np.nan); am.append(0); ang.append(np.nan); nn.append(int(s.sum())); continue
        cph = np.exp(2j * np.pi * z[s] / p).mean()
        ph.append(np.angle(cph)); am.append(abs(cph)); ang.append(float(np.median(dth[s]))); nn.append(int(s.sum()))
        prev_c = ang[-1]
    ph = np.array(ph); ok = ~np.isnan(ph) & (np.array(am) > 0.15)
    zs = np.full(len(rs), np.nan)
    zs[ok] = np.unwrap(ph[ok]) * p / (2 * np.pi)
    zs -= zs[ok][0]
    rc = rs + 0.15
    fit_ok = ok & (rc < 14.0)
    lz = np.polyfit(rc[fit_ok], zs[fit_ok], 1)
    # tangential shift in the RAW frame: d(theta_raw) = d(theta_u) + k dz ; arc length at radius r
    ang = np.array(ang)
    draw = (ang - ang[fit_ok][0]) + k * zs
    lt = np.polyfit(rc[fit_ok], np.radians(draw[fit_ok]) * rc[fit_ok], 1)
    out[f"row_{name}"].update({"lean_axial_deg": round(float(np.degrees(np.arctan(lz[0]))), 2), "dz_per_dr": round(float(lz[0]), 4),
                               "lean_tangential_deg": round(float(np.degrees(np.arctan(lt[0]))), 2), "pattern_amplitude_by_r": {f"{a:.1f}": round(float(b), 2) for a, b in zip(rc[::3], np.array(am)[::3])},
                               "z_shift_by_r": {f"{a:.1f}": (None if np.isnan(b) else round(float(b), 2)) for a, b in zip(rc[::3], zs[::3])},
                               "raw_angle_shift_deg_by_r": {f"{a:.1f}": (None if np.isnan(b) else round(float(b), 2)) for a, b in zip(rc[::3], draw[::3])}})
    ax = axs[row, 1]
    ax.plot(rc, zs, "k.-", label="axial shift of the row pattern (mm)"); ax.plot(rc, np.radians(draw) * rc, "r.-", label="tangential shift, raw frame (mm)")
    ax.plot(rc, np.array(am) * 5, "b:", label="pattern amplitude x 5")
    ax.grid(True); ax.legend(); ax.set_xlabel("r"); ax.set_title(f"row {name}: lean")
    # tip radius: radial extent of the bristle points in the row sector, per z band
    sec = (np.abs(dth - dd.mean()) < 45) & (r > 9)
    tips = {}
    for za in range(10, 160, 10):
        s = sec & (z >= za) & (z < za + 10)
        if s.sum() > 200:
            tips[str(za)] = [round(float(v), 2) for v in np.percentile(r[s], [90, 98, 99.8])]
    out[f"row_{name}"]["r_p90_p98_p998_by_z"] = tips
    out[f"row_{name}"]["r_tip_p98_all"] = round(float(np.percentile(r[sec & (z > 15) & (z < 150)], 98)), 3)
    out[f"row_{name}"]["z_extent_at_r17"] = [round(float(v), 2) for v in np.percentile(z[sec & (r > 16.5) & (r < 17.5)], [1, 99])]
    ax = axs[row, 2]
    s = sec
    ax.hist2d(z[s], r[s], bins=[np.arange(0, 172, 0.5), np.arange(9, 22, 0.1)], cmap="Greys", norm=matplotlib.colors.LogNorm())
    ax.grid(True, lw=0.3); ax.set_title(f"row {name}: bristle points r vs z")
json.dump(out, open(os.path.join(QA, "m6_tufts.json"), "w"), indent=1)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "m6_tufts.png"), dpi=50); plt.close(fig)
for kk, v in out.items():
    print(kk, json.dumps(v))
