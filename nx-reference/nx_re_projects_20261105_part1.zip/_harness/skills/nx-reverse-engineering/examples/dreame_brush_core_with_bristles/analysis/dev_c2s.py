"""CAD -> scan distance by zone of the core (how much of the model is actually seen by the scans).
usage: dev_c2s.py <tag>   -> qa/dev_<tag>_cad_to_scan.json"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import *

tag = sys.argv[1]
cad = Mesh(read_stl(os.path.join(OUT, "dreame_brush_core_with_bristles_core.stl")))
scan = Mesh(apply(load_T("T_bristles.json"), read_stl(SCAN_BRISTLES_FULL, every=2)))
base = Mesh(np.load(os.path.join(QA, "base_end0_tris_datum.npy")).astype(np.float64))
rb = np.hypot(base.c[:, 0], base.c[:, 1])
base = base.sub((rb < 17.5) & (base.c[:, 2] < 13))
Q, qi = cad.sample(500_000, seed=7)
r, th, z = cyl(Q)
d1, _, _, _ = closest(scene_of(scan), scan, Q)
d2, _, _, _ = closest(scene_of(base), base, Q)
d = np.minimum(d1, d2)
under = (z < 3.72) & (r < 11.6) | ((r < 3.5) & (z < 10.2))
zones = {"lands and outer faces of the core (r >= 7.2, z 7 .. 168)": (r >= 7.2) & (z >= 7) & (z < 168),
         "grooves and slot necks (6.0 <= r < 7.2, z 7 .. 168)": (r >= 6.0) & (r < 7.2) & (z >= 7) & (z < 168),
         "T-slot feet and tuft-hole bottoms (r < 6.0, z 7 .. 164)": (r < 6.0) & (z >= 7) & (z < 164) & ~under,
         "drive end, upper side (z < 7, not the underside)": (z < 7) & ~under,
         "underside: recess, ring, hex socket, pits": under,
         "idler end (z >= 168) and bore": (z >= 168) | ((r < 6.0) & (z >= 164))}
out = {"n": int(len(Q)), "all": stats(d), "unobserved_share_ge_1.0": float((d >= 1.0).mean()), "zones": {}}
for name, m in zones.items():
    s = stats(d[m])
    out["zones"][name] = {"share_of_surface": round(float(m.mean()), 4), "p50": round(s["p50"], 3), "p90": round(s["p90"], 3), "p95": round(s["p95"], 3),
                          "over_0.3": round(s["over_0.3"], 4), "unobserved_ge_1.0": round(float((d[m] >= 1.0).mean()), 4)}
json.dump(out, open(os.path.join(QA, f"dev_{tag}_cad_to_scan.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
