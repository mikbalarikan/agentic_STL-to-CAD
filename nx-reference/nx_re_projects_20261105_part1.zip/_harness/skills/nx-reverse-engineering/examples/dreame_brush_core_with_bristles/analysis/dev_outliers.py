"""Where are the largest hard-surface deviations?  usage: dev_outliers.py <tag>   -> qa/dev_<tag>_outliers.json"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import *

tag = sys.argv[1]
k = json.load(open(os.path.join(QA, "m2_twist.json")))["twist_deg_per_mm"]
z_ = np.load(os.path.join(QA, f"dev_{tag}.npz"))
P, d = z_["P"].astype(float), z_["d"].astype(float)
r, th, z = cyl(P)
tu = (th - k * (z - 6.5)) % 360.0
out = {"n": int(len(d)), "over_0.5": int((np.abs(d) > 0.5).sum()), "over_0.8": int((np.abs(d) > 0.8).sum())}
big = np.abs(d) > 0.5


def near(a, c, w):
    return np.abs((a - c + 180.0) % 360.0 - 180.0) < w


groups = {
    "tuft-hole mouths (bristle roots below the soft-zone radius)": big & (z > 8) & (z < 142) & (near(tu, 36.1, 12) | near(tu, 216.1, 12)) & (r > 6.9),
    "recess beside one slot entry at the hub (z < 10)": big & (z >= 6.5) & (z < 10.5) & (r < 7.6),
    "drive end (z < 6.5)": big & (z < 6.5),
    "wide grooves / centre groove": big & (z >= 10.5) & (near(tu, 135.65, 24) | near(tu, 315.65, 24)),
    "slots (walls, feet, lodged debris)": big & (z >= 10.5) & (near(tu, 1.1, 9) | near(tu, 91.1, 9) | near(tu, 181.1, 9) | near(tu, 271.1, 9)),
    "idler end (z > 163)": big & (z > 163),
}
used = np.zeros(len(d), bool)
rows = {}
for name, m in groups.items():
    m = m & ~used
    used |= m
    rows[name] = {"n_over_0.5": int(m.sum()), "n_over_0.8": int((m & (np.abs(d) > 0.8)).sum()), "max": round(float(np.abs(d[m]).max()), 3) if m.any() else 0.0,
                  "sign": "scan outside CAD" if m.any() and np.median(d[m]) > 0 else "scan inside CAD"}
rest = big & ~used
rows["elsewhere"] = {"n_over_0.5": int(rest.sum()), "n_over_0.8": int((rest & (np.abs(d) > 0.8)).sum()), "max": round(float(np.abs(d[rest]).max()), 3) if rest.any() else 0.0}
out["groups"] = rows
i = int(np.argmax(np.abs(d)))
out["worst_point"] = {"xyz": P[i].round(3).tolist(), "r": round(float(r[i]), 3), "untwisted_angle": round(float(tu[i]), 1), "d": round(float(d[i]), 3)}
json.dump(out, open(os.path.join(QA, f"dev_{tag}_outliers.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
