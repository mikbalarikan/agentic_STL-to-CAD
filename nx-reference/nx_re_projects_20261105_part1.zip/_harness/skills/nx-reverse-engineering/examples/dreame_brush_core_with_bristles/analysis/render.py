"""Renders for the report (cadgenbench venv: pyvista).  usage: render.py <fig dir>
CAD core (grey-blue) + tufts (dark), and the scans in the same frame."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import pyvista as pv
from common import OUT

fig = sys.argv[1]
pv.OFF_SCREEN = True
core = pv.read(os.path.join(OUT, "dreame_brush_core_with_bristles_core.stl"))
tufts = pv.read(os.path.join(OUT, "dreame_brush_core_with_bristles_tufts.stl"))
scan = pv.read(os.path.join(OUT, "scan_core_with_bristles_datum.stl"))
base = pv.read(os.path.join(OUT, "scan_base_end_datum.stl"))
edges = core.extract_feature_edges(feature_angle=30, boundary_edges=False, non_manifold_edges=False, manifold_edges=False)


def shot(name, meshes, pos, up, focal, scale, size=(1900, 1100)):
    pl = pv.Plotter(off_screen=True, window_size=size)
    pl.set_background("white")
    for m, col, kw in meshes:
        pl.add_mesh(m, color=col, specular=0.25, specular_power=12, ambient=0.28, diffuse=0.8, smooth_shading=False, **kw)
    pl.camera.position, pl.camera.focal_point, pl.camera.up = pos, focal, up
    pl.camera.parallel_projection = True
    pl.camera.parallel_scale = scale
    pl.enable_anti_aliasing("ssaa")
    pl.screenshot(os.path.join(fig, name))
    pl.close()


CAD = [(core, "#9fb4c7", {}), (tufts, "#3b4046", {}), (edges, "#2a3138", {"line_width": 1.0})]
CAD_CORE = [(core, "#9fb4c7", {}), (edges, "#2a3138", {"line_width": 1.0})]
SCAN = [(scan, "#c9c2b0", {})]
BASE = [(base, "#c9c2b0", {})]
mid = (0.0, 0.0, 85.0)
# full length, axis horizontal (Z to the right)
for tag, ms in (("cad", CAD), ("scan", SCAN)):
    shot(f"render_side_{tag}.png", ms, (0.0, -400.0, 85.0), (1.0, 0.0, 0.0), mid, 34.0, (2400, 760))
    shot(f"render_iso_{tag}.png", ms, (260.0, -230.0, 250.0), (0.0, 0.0, 1.0), mid, 95.0, (1500, 1700))
    shot(f"render_drive_end_{tag}.png", ms, (60.0, -75.0, 75.0), (0.0, 0.0, 1.0), (0.0, 0.0, 12.0), 24.0)
    shot(f"render_idler_end_{tag}.png", ms, (40.0, -45.0, 215.0), (0.0, 0.0, 1.0), (0.0, 0.0, 160.0), 17.0)
# underside: CAD against the base scan
shot("render_underside_cad.png", CAD_CORE, (25.0, -30.0, -60.0), (0.0, 0.0, -1.0), (0.0, 0.0, 3.0), 21.0)
shot("render_underside_scan.png", BASE, (25.0, -30.0, -60.0), (0.0, 0.0, -1.0), (0.0, 0.0, 3.0), 21.0)
# CAD over the scan (scan translucent)
shot("render_overlay_side.png", [(scan, "#d8b98a", {"opacity": 0.55}), (core, "#3f6fa8", {}), (tufts, "#1d2126", {})], (0.0, -400.0, 85.0), (1.0, 0.0, 0.0), mid, 34.0, (2400, 760))
print("renders written to", fig)
