"""Decimated scans in the CAD datum frame, for the review part and the renders.
out/scan_core_with_bristles_datum.stl  (20 MB decimated scan, table removed, transformed with qa/T_bristles.json)
out/scan_base_end_datum.stl            (20 MB decimated base scan, the r 16.4 brush end only, qa/T_base.json)"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import *

t = apply(load_T("T_bristles.json"), read_stl(SCAN_BRISTLES_20))
c = t.mean(axis=1)
r = np.hypot(c[:, 0], c[:, 1])
keep = ~(((c[:, 2] < 0.3) & (r > 15.3)) | (c[:, 2] < -0.3) | (r > 22.5) | ((c[:, 2] < 7.0) & (r > 17.0)))
write_stl(os.path.join(OUT, "scan_core_with_bristles_datum.stl"), t[keep])
print("core scan:", int(keep.sum()), "of", len(t), "triangles kept")

raw = read_stl(SCAN_BASE_20)
b = apply(load_T("T_base.json"), raw)
c = b.mean(axis=1)
r = np.hypot(c[:, 0], c[:, 1])
keep = (r < 30.0) & (c[:, 2] > -3.0) & (c[:, 2] < 45.0)            # the other brush end lies ~40 mm to the side
write_stl(os.path.join(OUT, "scan_base_end_datum.stl"), b[keep])
print("base scan:", int(keep.sum()), "of", len(b), "triangles kept; bbox", b[keep].reshape(-1, 3).min(0).round(1), b[keep].reshape(-1, 3).max(0).round(1))
