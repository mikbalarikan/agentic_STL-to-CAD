"""Hex socket and floor details of the underside (base scan in the datum frame). qa/m7_hex.json"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import *

m = Mesh(np.load(os.path.join(QA, "base_end0_tris_datum.npy")).astype(np.float64))
m = m.sub((np.hypot(m.c[:, 0], m.c[:, 1]) < 12.5) & (m.c[:, 2] < 14) & (m.c[:, 2] > 2.5))
P, idx = m.sample(1_200_000, seed=5)
N = m.n[idx]
r, th, z = cyl(P)
nz = N[:, 2]
out = {}
clock0 = json.load(open(os.path.join(QA, "m7_underside.json")))["hex_normal_clock_deg_mod60"]
hexd = {}
for z0, z1 in ((3.7, 4.5), (4.5, 5.5), (5.5, 7.0), (7.0, 8.5), (8.5, 10.5)):
    hx = (np.abs(nz) < 0.35) & (r < 4.4) & (z > z0) & (z < z1)
    ang = np.degrees(np.arctan2(-N[hx, 1], -N[hx, 0]))          # outward direction of the wall as seen from the axis (surface normal points to the axis)
    cm = np.degrees(np.angle(np.exp(1j * np.radians(ang * 6)).mean())) / 6.0
    ds, ns = [], []
    for q in range(6):
        a0 = np.radians(cm + 60 * q)
        d = np.array([np.cos(a0), np.sin(a0)])
        sel = (-(N[hx, 0] * d[0] + N[hx, 1] * d[1])) > 0.96
        ns.append(int(sel.sum()))
        ds.append(float(np.median(P[hx][sel, 0] * d[0] + P[hx][sel, 1] * d[1])) if sel.sum() > 25 else None)
    af = [ds[q] + ds[q + 3] for q in range(3) if ds[q] is not None and ds[q + 3] is not None]
    off = [(ds[q] - ds[q + 3]) / 2 for q in range(3) if ds[q] is not None and ds[q + 3] is not None]
    hexd[f"z{z0}-{z1}"] = {"clock_mod60": round(float(cm % 60), 2), "flat_dist": [None if v is None else round(v, 3) for v in ds], "n": ns,
                            "across_flats": [round(v, 3) for v in af], "centre_offset_along_normals": [round(v, 3) for v in off]}
out["hex"] = hexd
# corners: max radius of wall points near the entrance
hx = (np.abs(nz) < 0.35) & (r < 4.4) & (z > 3.7) & (z < 6.0)
out["hex_corner_r_p99"] = round(float(np.percentile(r[hx], 99)), 3)
out["hex_deepest_wall_z_p99.5"] = round(float(np.percentile(z[(np.abs(nz) < 0.35) & (r < 4.0)], 99.5)), 3)
# boss ring around the socket
down = nz < -0.9
out["boss_face_z"] = round(float(np.median(z[down & (r > 3.6) & (r < 4.7) & (z > 3.0) & (z < 3.62)])), 4)
rr = np.arange(4.4, 5.8, 0.05)
zz = [float(np.median(z[down & (np.abs(r - a) < 0.03) & (z > 3.0) & (z < 4.2)])) for a in rr]
out["boss_step_profile"] = {f"{a:.2f}": round(b, 3) for a, b in zip(rr, zz)}
# pits / marks on the floor: local deviation from the floor level 3.70
fl = down & (r > 5.6) & (r < 11.0) & (z > 2.9) & (z < 5.6)
dz = z[fl] - 3.70
x, y = P[fl, 0], P[fl, 1]
feat = []
for name, (cx, cy) in {"pit_A": (-6.0, 5.5), "pit_B": (6.0, -6.0), "mark_A": (6.0, 6.0), "mark_B": (-6.0, -6.2), "pip": (-8.5, 0.7)}.items():
    for _ in range(4):
        s = np.hypot(x - cx, y - cy) < 1.6
        w = np.abs(dz[s]) > 0.12
        if w.sum() < 20:
            break
        cx, cy = float(np.average(x[s][w], weights=np.abs(dz[s][w]))), float(np.average(y[s][w], weights=np.abs(dz[s][w])))
    s = np.hypot(x - cx, y - cy) < 1.8
    rr_ = np.hypot(x[s] - cx, y[s] - cy)
    prof = {f"{a:.1f}": round(float(np.median(dz[s][np.abs(rr_ - a) < 0.1])), 3) for a in np.arange(0.1, 1.8, 0.2) if (np.abs(rr_ - a) < 0.1).sum() > 10}
    feat.append({"name": name, "x": round(cx, 3), "y": round(cy, 3), "r": round(float(np.hypot(cx, cy)), 3), "theta_deg": round(float(np.degrees(np.arctan2(cy, cx)) % 360), 2),
                 "dz_profile_by_radius": prof, "dz_extreme": [round(float(np.percentile(dz[s], 0.5)), 3), round(float(np.percentile(dz[s], 99.5)), 3)]})
out["floor_features"] = feat
json.dump(out, open(os.path.join(QA, "m7_hex.json"), "w"), indent=1)
for k, v in out.items():
    if isinstance(v, dict):
        print(k)
        for a, b in v.items():
            print("   ", a, json.dumps(b))
    elif isinstance(v, list):
        print(k)
        for b in v:
            print("   ", json.dumps(b))
    else:
        print(k, v)
