"""Base scan (end 0 = the r 16.4 brush end) -> datum frame of the core.
Start: end frame of b2 (end plane + rim circle). Clock and fine pose: trimmed point-to-plane ICP against the aligned
with-bristles core scan (overlap: hub disc, pinwheel blades, core root seen between the rubber blades), tried from
36 start clockings. Writes qa/T_base.json, qa/m7_base_align.json."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import open3d as o3d
from common import *

Tb = load_T("T_bristles.json")
tgt = Mesh(apply(Tb, read_stl(SCAN_BRISTLES_FULL, every=2)))
rt = np.hypot(tgt.c[:, 0], tgt.c[:, 1])
# target: hard surfaces of the core near the drive end (no table, no bristles)
tk = (tgt.c[:, 2] > 0.4) & (tgt.c[:, 2] < 14) & (rt < 16.9) & ~((rt > 7.7) & (tgt.c[:, 2] > 6.8))
tgt = tgt.sub(tk)
Pt, it = tgt.sample(500_000, seed=1)
pt = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(Pt)); pt.normals = o3d.utility.Vector3dVector(tgt.n[it])

raw = read_stl(SCAN_BASE_FULL)
m = Mesh(raw)
c0 = np.average(m.c, axis=0, weights=m.a)
w, e = np.linalg.eigh(np.cov((m.c - c0).T, aweights=m.a))
t = (m.c - c0) @ e[:, 2]
T0 = load_T("base_end0_T0.json")
# which side of the split is end 0: the one whose rim circle is centred at the origin of T0
side = t < np.median(t)
q = apply(T0, m.c)
if np.median(np.hypot(q[side, 0], q[side, 1])) > np.median(np.hypot(q[~side, 0], q[~side, 1])):
    side = ~side
src = Mesh(apply(T0, raw[side]))
rs = np.hypot(src.c[:, 0], src.c[:, 1])
# the end-plane of T0 was a low percentile: put the rim end annulus on z = 0 first
ann = (src.n[:, 2] < -0.97) & (rs > 12.3) & (rs < 15.6) & (np.abs(src.c[:, 2]) < 1.0)
z_end = float(np.median(src.c[ann, 2]))
src = Mesh(src.tri - np.array([0, 0, z_end]))
rs = np.hypot(src.c[:, 0], src.c[:, 1])
# source points for the ICP: the part of the base scan that can overlap the core (hub disc wall, gap floor, blades, core root)
sk = (src.c[:, 2] > 3.6) & (src.c[:, 2] < 13.5) & (rs < 15.6)
ssub = src.sub(sk)
Ps, isx = ssub.sample(200_000, seed=2)
print("end plane shift", round(z_end, 3), "source pts", len(Ps), "target pts", len(Pt))


def rotz(a):
    c, s = np.cos(np.radians(a)), np.sin(np.radians(a))
    R = np.eye(4); R[0, 0], R[0, 1], R[1, 0], R[1, 1] = c, -s, s, c
    return R


ps = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(Ps))
est = o3d.pipelines.registration.TransformationEstimationPointToPlane()
cands = []
for a in range(0, 360, 10):
    T = rotz(a)
    for thr in (0.8, 0.4):
        rg = o3d.pipelines.registration.registration_icp(ps, pt, thr, T, est, o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=60))
        T = rg.transformation
    cands.append({"start": a, "fitness": float(rg.fitness), "rmse": float(rg.inlier_rmse), "T": np.array(T).tolist(),
                  "clock": float(np.degrees(np.arctan2(T[1, 0], T[0, 0]))) % 360})
cands.sort(key=lambda c: -c["fitness"])
for c in cands[:10]:
    print(f"start {c['start']:3d}  clock {c['clock']:7.2f}  fitness {c['fitness']:.4f}  rmse {c['rmse']:.4f}")
best = cands[0]
T = np.array(best["T"])
for thr in (0.25, 0.15):
    rg = o3d.pipelines.registration.registration_icp(ps, pt, thr, T, est, o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=80))
    T = np.array(rg.transformation)
print("refined: fitness", rg.fitness, "rmse", rg.inlier_rmse)
# full transform raw base scan -> datum
Tz = np.eye(4); Tz[2, 3] = -z_end
Tfull = T @ Tz @ T0
# residual check: signed distance source -> target mesh on the overlap
sc = scene_of(tgt)
d, sg, tid, qq = closest(sc, tgt, apply(T, Ps))
inl = d < 0.3
res = {"clock_candidates": [{k: v for k, v in c.items() if k != "T"} for c in cands[:12]], "icp_fitness_0.15": float(rg.fitness), "icp_rmse_0.15": float(rg.inlier_rmse),
       "overlap_share_lt_0.3": float(inl.mean()), "overlap_stats_lt_0.3": stats((d * sg)[inl]),
       "tilt_correction_deg": float(np.degrees(np.arccos(min(1.0, T[2, 2])))), "translation": T[:3, 3].tolist(), "z_end_shift": z_end}
json.dump(res, open(os.path.join(QA, "m7_base_align.json"), "w"), indent=1)
json.dump({"T": Tfull.tolist(), "note": "raw base scan (end 0 only) -> datum frame of the core, by ICP on the overlap with the with-bristles scan",
           "end0_side_rule": "split at the median of the PCA long-axis coordinate; end 0 = the side whose rim circle is centred in base_end0_T0"},
          open(os.path.join(QA, "T_base.json"), "w"), indent=1)
np.save(os.path.join(QA, "base_end0_tris_datum.npy"), apply(Tfull, raw[side]).astype(np.float32))
print(json.dumps({k: v for k, v in res.items() if k != "clock_candidates"}, indent=1))
