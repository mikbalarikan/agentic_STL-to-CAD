"""Baseline: reference CAD sheet body against the scan stored inside the reference part (same frame).
Writes qa/b0_baseline.json, fig/b0_rz.png (r-z density of the scan + CAD half sections), fig/b0_sections.png."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

scan = Mesh(read_stl(REF_SCAN))
cad = Mesh(read_stl(REF_CAD))
print("scan tris", len(scan.tri), "cad tris", len(cad.tri))
cs = scene_of(cad)
P, idx = scan.sample(600_000, seed=3)
d, sg, tid, q = closest(cs, cad, P)
# sign by the CAD normal: STL of a sheet body, orientation checked below with the land radius
r, th, z = cyl(P)
s2c = d * sg
out = {"all": stats(s2c)}
bands = {}
for z0, z1 in ((-3, 0), (0, 3.3), (3.3, 4.5), (4.5, 6.5), (6.5, 20), (20, 60), (60, 100), (100, 140), (140, 165), (165, 171)):
    m = (z >= z0) & (z < z1)
    bands[f"z{z0}..{z1}"] = {k: round(v, 4) if isinstance(v, float) else v for k, v in stats(s2c[m]).items()}
    bands[f"z{z0}..{z1}"]["r_p99"] = float(np.percentile(r[m], 99)) if m.any() else None
out["bands"] = bands
core = (z > 8) & (z < 165)
out["core_z8_165"] = stats(s2c[core])
out["core_land_sign_check"] = {"mean_signed_on_r>7.2": float(s2c[core & (r > 7.2)].mean())}
json.dump(out, open(os.path.join(QA, "b0_baseline.json"), "w"), indent=1)
print(json.dumps(out["all"]))
for k, v in bands.items():
    print(k, v)
print("core", out["core_z8_165"])

# r-z density near the base and near the top
fig, axs = plt.subplots(1, 2, figsize=(22, 9))
for ax, (z0, z1, r1) in zip(axs, ((-4, 12, 20), (158, 172, 12))):
    m = (z > z0) & (z < z1) & (r < r1)
    ax.hist2d(r[m], z[m], bins=[int(r1 / 0.04), int((z1 - z0) / 0.04)], cmap="Greys", norm=matplotlib.colors.LogNorm())
    for t in range(0, 360, 30):
        s = rz_segments(cad, t + 7)
        plot_segs(ax, s, colors="r", linewidths=0.4, alpha=0.6)
    ax.set_xlim(0, r1); ax.set_ylim(z0, z1); ax.set_aspect("equal"); ax.grid(True, lw=0.2)
    ax.set_xticks(np.arange(0, r1 + 0.1, 1)); ax.set_yticks(np.arange(np.ceil(z0), z1 + 0.1, 1))
    ax.set_title(f"scan r-z density (grey) + reference CAD half sections every 30 deg (red), z {z0}..{z1}")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "b0_rz.png"), dpi=70); plt.close(fig)

zs = [1.5, 3.9, 5.5, 8, 40, 90, 150, 168, 169.5]
fig, axs = plt.subplots(3, 3, figsize=(24, 24))
for ax, zz in zip(axs.ravel(), zs):
    plot_segs(ax, scan.section(2, zz)[:, :, :2], colors="k", linewidths=0.5)
    plot_segs(ax, cad.section(2, zz)[:, :, :2], colors="r", linewidths=0.6)
    lim = 18 if zz < 7 else 9
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.grid(True, lw=0.2); ax.set_title(f"z = {zz}  (black scan, red reference CAD)")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "b0_sections.png"), dpi=60); plt.close(fig)
print("done")
