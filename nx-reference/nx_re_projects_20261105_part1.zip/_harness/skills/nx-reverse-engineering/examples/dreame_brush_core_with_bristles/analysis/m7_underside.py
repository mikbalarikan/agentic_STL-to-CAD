"""Underside of the drive end from the base scan in the datum frame (qa/base_end0_tris_datum.npy):
end annulus, recess wall and floor, hex socket (across flats, clock, depth), dimples / small features.
Writes qa/m7_underside.json, fig/m7_underside.png."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

m = Mesh(np.load(os.path.join(QA, "base_end0_tris_datum.npy")).astype(np.float64))
m = m.sub((np.hypot(m.c[:, 0], m.c[:, 1]) < 19) & (m.c[:, 2] < 14))
P, idx = m.sample(1_500_000, seed=3)
N = m.n[idx]
r, th, z = cyl(P)
nr = (N[:, 0] * P[:, 0] + N[:, 1] * P[:, 1]) / np.maximum(r, 1e-9)
nz = N[:, 2]
out = {}
med = lambda sel, v: {"median": round(float(np.median(v[sel])), 4), "p05": round(float(np.percentile(v[sel], 5)), 4), "p95": round(float(np.percentile(v[sel], 95)), 4), "n": int(sel.sum())}
down = nz < -0.9
out["end_annulus_z"] = med(down & (r > 12.3) & (r < 15.6) & (np.abs(z) < 1.0), z)
out["end_annulus_z_by_r"] = {f"{a:.1f}": round(float(np.median(z[down & (np.abs(r - a) < 0.25) & (np.abs(z) < 1.2)])), 4) for a in np.arange(11.75, 16.5, 0.5) if (down & (np.abs(r - a) < 0.25) & (np.abs(z) < 1.2)).sum() > 50}
out["recess_wall_r"] = med((nr < -0.85) & (r > 10.8) & (r < 12.4) & (z > 0.8) & (z < 3.0), r)
out["recess_wall_r_by_z"] = {f"{a:.1f}": round(float(np.median(r[(nr < -0.8) & (r > 10.8) & (r < 12.4) & (np.abs(z - a) < 0.2)])), 4) for a in (0.6, 1.0, 1.5, 2.0, 2.5, 3.0)}
out["recess_floor_z"] = med(down & (r > 4.5) & (r < 11.0) & (z > 2.5) & (z < 4.6), z)
out["recess_floor_z_by_r"] = {f"{a:.1f}": round(float(np.median(z[down & (np.abs(r - a) < 0.25) & (z > 2.5) & (z < 4.6)])), 4) for a in np.arange(3.75, 11.5, 0.5) if (down & (np.abs(r - a) < 0.25) & (z > 2.5) & (z < 4.6)).sum() > 50}
# things seen from the side that also exist in the core scan (check of the registration)
out["check_rim_r"] = med((nr > 0.9) & (r > 16.0) & (r < 16.9) & (z > 0.8) & (z < 2.9), r)
out["check_hub_r"] = med((nr > 0.9) & (r > 14.9) & (r < 15.5) & (z > 3.6) & (z < 4.45), r)
out["check_gap_floor_z"] = med((nz > 0.95) & (r > 6) & (r < 14.6) & (z > 4.3) & (z < 5.0), z)
out["check_blade_top_z"] = med((nz > 0.95) & (r > 8) & (r < 14.6) & (z > 6.2) & (z < 6.9), z)
# hex socket: wall points (normal horizontal, pointing to the axis), r < 4.6
hx = (np.abs(nz) < 0.3) & (r < 4.6) & (z > 3.6) & (z < 12)
out["hex_wall_points"] = int(hx.sum())
if hx.sum() > 500:
    # distance of the wall planes from the axis as a function of the normal direction
    na = np.degrees(np.arctan2(N[hx, 1], N[hx, 0])) % 60.0
    h, e = np.histogram(na, bins=np.arange(0, 60.5, 1.0))
    pk = (np.argmax(h) + 0.5)
    # refine the clock: circular mean with period 60
    ang = np.degrees(np.arctan2(N[hx, 1], N[hx, 0]))
    cm = np.degrees(np.angle(np.exp(1j * np.radians(ang * 6)).mean())) / 6.0
    out["hex_normal_clock_deg_mod60"] = round(float(cm % 60), 2)
    flat = []
    for q in range(6):
        a0 = np.radians(cm + 60 * q)
        d = np.array([np.cos(a0), np.sin(a0)])
        sel = hx & ((N[:, 0] * d[0] + N[:, 1] * d[1]) > 0.97)
        if sel.sum() > 30:
            flat.append(round(float(np.median(-(P[sel, 0] * d[0] + P[sel, 1] * d[1]))), 4))
    out["hex_flat_distance_from_axis"] = flat
    out["hex_across_flats"] = round(float(2 * np.mean(flat)), 4) if flat else None
    out["hex_wall_z_range"] = [round(float(v), 3) for v in np.percentile(z[hx], [1, 99])]
    out["hex_wall_r_by_z"] = {f"{a:.0f}": round(float(np.median(np.abs(P[hx & (np.abs(z - a) < 0.5), 0] * np.cos(np.radians(cm)) + P[hx & (np.abs(z - a) < 0.5), 1] * np.sin(np.radians(cm))))), 3)
                              for a in range(4, 12) if (hx & (np.abs(z - a) < 0.5)).sum() > 50}
bot = (r < 4.2) & (nz < -0.8) & (z > 4)
out["hex_bottom_z"] = med(bot, z) if bot.sum() > 100 else None
# boss / ring around the socket on the recess floor?
out["floor_inner_edge_r"] = round(float(np.percentile(r[down & (z > 2.5) & (z < 4.6)], 0.5)), 3)
json.dump(out, open(os.path.join(QA, "m7_underside.json"), "w"), indent=1)
for k, v in out.items():
    print(k, json.dumps(v))

fig, axs = plt.subplots(1, 3, figsize=(39, 13))
ax = axs[0]
s = (z > -1.2) & (z < 12.5)
ax.hist2d(r[s], z[s], bins=[np.arange(0, 18.01, 0.02), np.arange(-1.2, 12.51, 0.02)], cmap="Greys", norm=matplotlib.colors.LogNorm())
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(0, 18.1, 1)); ax.set_yticks(np.arange(-1, 12.6, 0.5)); ax.set_title("base scan, datum frame: r-z density")
ax = axs[1]
s = (nz < -0.3) & (r < 17.5) & (z < 6)
o = np.argsort(-z[s])
sc = ax.scatter(P[s][o, 0], P[s][o, 1], c=z[s][o], s=0.3, cmap="turbo", vmin=-0.3, vmax=4.2)
ax.set_aspect("equal"); ax.set_xlim(-17.5, 17.5); ax.set_ylim(-17.5, 17.5); ax.grid(True, lw=0.3); plt.colorbar(sc, ax=ax, shrink=0.7)
ax.set_xticks(np.arange(-16, 16.1, 2)); ax.set_yticks(np.arange(-16, 16.1, 2)); ax.set_title("underside seen from -Z, colour = z")
ax = axs[2]
s = (nz < -0.6) & (r < 11.3) & (z > 2.6) & (z < 4.4)
o = np.argsort(z[s])
sc = ax.scatter(P[s][o, 0], P[s][o, 1], c=z[s][o], s=0.4, cmap="turbo", vmin=float(np.percentile(z[s], 1)), vmax=float(np.percentile(z[s], 99)))
ax.set_aspect("equal"); ax.set_xlim(-12, 12); ax.set_ylim(-12, 12); ax.grid(True, lw=0.3); plt.colorbar(sc, ax=ax, shrink=0.7)
ax.set_xticks(np.arange(-12, 12.1, 1)); ax.set_yticks(np.arange(-12, 12.1, 1)); ax.set_title("recess floor, colour = z (1..99 %)")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "m7_underside.png"), dpi=50); plt.close(fig)
