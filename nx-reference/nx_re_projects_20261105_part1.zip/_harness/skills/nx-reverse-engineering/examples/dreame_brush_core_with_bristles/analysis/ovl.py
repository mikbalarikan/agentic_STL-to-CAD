"""Section overlays: scan (black) and CAD (red: core, blue: tufts).  usage: ovl.py <tag> [full]
fig/ovl_<tag>_z.png (sections normal to the axis), fig/ovl_<tag>_rz.png (half sections through the axis)"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

tag = sys.argv[1]
full = "full" in sys.argv
cad = Mesh(read_stl(os.path.join(OUT, "dreame_brush_core_with_bristles_core.stl")))
tp = os.path.join(OUT, "dreame_brush_core_with_bristles_tufts.stl")
tufts = Mesh(read_stl(tp)) if os.path.exists(tp) else None
scan = Mesh(apply(load_T("T_bristles.json"), read_stl(SCAN_BRISTLES_FULL if full else SCAN_BRISTLES_20)))
base = Mesh(np.load(os.path.join(QA, "base_end0_tris_datum.npy")).astype(np.float64))

zs = [(1.6, 18), (2.9, 18), (5.6, 18), (12.0, 21), (40.0, 21), (75.0, 21), (110.0, 21), (150.0, 9.5), (166.5, 9.5), (169.2, 9.5)]
fig, axs = plt.subplots(2, 5, figsize=(45, 18))
for ax, (zz, lim) in zip(axs.ravel(), zs):
    if zz < 4.0:
        plot_segs(ax, base.section(2, zz)[:, :, :2], colors="0.55", linewidths=0.5)
    plot_segs(ax, scan.section(2, zz)[:, :, :2], colors="k", linewidths=0.5)
    if tufts is not None:
        plot_segs(ax, tufts.section(2, zz)[:, :, :2], colors="b", linewidths=0.6)
    plot_segs(ax, cad.section(2, zz)[:, :, :2], colors="r", linewidths=0.7)
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.grid(True, lw=0.2)
    ax.set_title(f"z = {zz}  (black: core scan, grey: base scan, red: CAD core, blue: CAD tufts)", fontsize=9)
fig.tight_layout(); fig.savefig(os.path.join(FIG, f"ovl_{tag}_z.png"), dpi=45); plt.close(fig)

fig, axs = plt.subplots(2, 4, figsize=(44, 20))
for j, t in enumerate((20.0, 65.0, 140.0, 250.0)):
    for i, (z0, z1, r1) in enumerate(((-1.0, 12.5, 18.0), (160.0, 171.0, 9.0))):
        ax = axs[i, j]
        if i == 0:
            plot_segs(ax, rz_segments(base, t), colors="0.55", linewidths=0.6)
        plot_segs(ax, rz_segments(scan, t), colors="k", linewidths=0.6)
        if tufts is not None:
            plot_segs(ax, rz_segments(tufts, t), colors="b", linewidths=0.6)
        plot_segs(ax, rz_segments(cad, t), colors="r", linewidths=0.8)
        ax.set_xlim(0, r1); ax.set_ylim(z0, z1); ax.grid(True, lw=0.2); ax.set_title(f"half section at {t:.0f} deg", fontsize=10)
        ax.set_xticks(np.arange(0, r1 + 0.1, 1)); ax.set_yticks(np.arange(np.ceil(z0), z1 + 0.1, 1))
fig.tight_layout(); fig.savefig(os.path.join(FIG, f"ovl_{tag}_rz.png"), dpi=45); plt.close(fig)
print("ok")
