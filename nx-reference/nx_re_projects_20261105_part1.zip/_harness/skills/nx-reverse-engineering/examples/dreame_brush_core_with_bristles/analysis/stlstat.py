"""Quick facts of a binary STL (numpy only, memory-mapped): triangle count, bbox, PCA axes, area.
usage: stlstat.py <file.stl> [...]"""
import sys, json
import numpy as np

DT = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])


def read(path, every=1):
    with open(path, "rb") as f:
        f.seek(80)
        n = int(np.frombuffer(f.read(4), "<u4")[0])
    d = np.memmap(path, DT, mode="r", offset=84, shape=(n,))
    return n, d


for p in sys.argv[1:]:
    n, d = read(p)
    step = max(1, n // 400_000)
    v = np.asarray(d["v"][::step], dtype=np.float64)
    c = v.mean(axis=1)
    nrm = np.cross(v[:, 1] - v[:, 0], v[:, 2] - v[:, 0])
    a = np.linalg.norm(nrm, axis=1) / 2
    lo, hi = v.reshape(-1, 3).min(0), v.reshape(-1, 3).max(0)
    cm = np.average(c, axis=0, weights=a)
    cov = np.cov((c - cm).T, aweights=a)
    w, e = np.linalg.eigh(cov)
    out = {"file": p, "tris": n, "sample_step": step, "bbox_lo": lo.round(3).tolist(), "bbox_hi": hi.round(3).tolist(),
           "size": (hi - lo).round(3).tolist(), "area_est": float(a.sum() * step), "centroid": cm.round(3).tolist(),
           "pca_sigma": np.sqrt(w).round(3).tolist(), "pca_long_axis": e[:, 2].round(4).tolist(),
           "median_edge": float(np.median(np.linalg.norm(v[:, 1] - v[:, 0], axis=1)))}
    print(json.dumps(out))
