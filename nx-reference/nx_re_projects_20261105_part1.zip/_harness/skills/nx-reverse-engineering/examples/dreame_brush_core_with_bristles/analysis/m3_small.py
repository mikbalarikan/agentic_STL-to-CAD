"""Median profile of the small grooves (untwisted, pooled over z) and a fit: bottom arc + straight flanks.
Also the tuft-row root positions in the section. Prints tables; fig/m3_small.png"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

d = np.load(os.path.join(QA, "m2_core_pts.npz"))
xu, yu, z, nr = d["xu"].astype(float), d["yu"].astype(float), d["z"].astype(float), d["nr"].astype(float)
fig, axs = plt.subplots(1, 2, figsize=(24, 9))
res = {}
for j, a0 in enumerate((59.9, 239.9)):
    c, s = np.cos(np.radians(a0)), np.sin(np.radians(a0))
    u, v = xu * c + yu * s, -xu * s + yu * c
    m = (np.abs(v) < 1.8) & (u > 6.6) & (u < 7.7)
    vb = np.arange(-1.8, 1.81, 0.04)
    idx = np.digitize(v[m], vb)
    vc = 0.5 * (vb[:-1] + vb[1:])
    med = np.array([np.median(u[m][idx == i]) if (idx == i).sum() > 8 else np.nan for i in range(1, len(vb))])
    ax = axs[j]
    for (z0, z1), col in zip(((9, 50), (50, 110), (110, 165)), "bgr"):
        mm = m & (z >= z0) & (z < z1)
        ii = np.digitize(v[mm], vb)
        ax.plot(vc, [np.median(u[mm][ii == i]) if (ii == i).sum() > 8 else np.nan for i in range(1, len(vb))], col + "-", lw=0.8, label=f"z {z0}-{z1}")
    ax.plot(vc, med, "k-", lw=1.5, label="all z")
    ax.plot(vc, np.sqrt(7.47 ** 2 - vc ** 2), "k--", lw=0.6)
    ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.legend(); ax.set_title(f"small groove at {a0} deg: median u(v)")
    ax.set_xticks(np.arange(-1.8, 1.81, 0.2)); ax.set_yticks(np.arange(6.6, 7.71, 0.1))
    # numbers: floor, centre, flank slope between 30 % and 70 % depth
    i0 = int(np.nanargmin(med))
    floor = float(np.nanmin(med)); v0 = float(vc[i0])
    lev = floor + np.array([0.3, 0.7]) * (7.44 - floor)
    fl = {}
    for sgn, name in ((-1, "left"), (1, "right")):
        side = (sgn * (vc - v0) > 0.1) & (sgn * (vc - v0) < 1.3)
        vv, uu = vc[side], med[side]
        k = (uu > lev[0]) & (uu < lev[1])
        p = np.polyfit(vv[k], uu[k], 1)
        fl[name] = {"slope_deg_from_tangent": round(float(np.degrees(np.arctan(abs(p[0])))), 2), "v_at_land": round(float((7.44 - p[1]) / p[0]), 3)}
    res[a0] = {"floor_u": round(floor, 4), "centre_v": round(v0, 3), **fl}
    print(a0, res[a0])
    print("  v:", np.round(vc[20:70:2], 2).tolist())
    print("  u:", np.round(med[20:70:2], 3).tolist())
fig.tight_layout(); fig.savefig(os.path.join(FIG, "m3_small.png"), dpi=55); plt.close(fig)
