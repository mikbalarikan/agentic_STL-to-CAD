"""Drive end of the with-bristles core: stepped discs (r-z), pinwheel blades (C4-folded outline at three heights,
line / arc fits), hub between the blades. Writes qa/m4_base.json, fig/m4_base.png.   usage: m4_base.py [full]"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

full = "full" in sys.argv
T = load_T("T_bristles.json")
m = Mesh(apply(T, read_stl(SCAN_BRISTLES_FULL if full else SCAN_BRISTLES_20)))
keep = (m.c[:, 2] < 12) & (np.hypot(m.c[:, 0], m.c[:, 1]) < 24)
m = m.sub(keep)
P, idx = m.sample(1_500_000, seed=4)
N = m.n[idx]
r, th, z = cyl(P)
nr = (N[:, 0] * P[:, 0] + N[:, 1] * P[:, 1]) / np.maximum(r, 1e-9)
nz = N[:, 2]
out = {}


def circ(q, it=10):
    w = np.ones(len(q))
    for _ in range(it):
        A = np.c_[2 * q, np.ones(len(q))] * w[:, None]
        sol, *_ = np.linalg.lstsq(A, (q ** 2).sum(1) * w, rcond=None)
        c = sol[:2]; rad = np.sqrt(sol[2] + c @ c)
        res = np.linalg.norm(q - c, axis=1) - rad
        s = max(1.4826 * np.median(np.abs(res)), 0.005)
        w = 1 / (1 + (res / (2.5 * s)) ** 2)
    k = np.abs(res) < 3 * s
    return c, float(rad), float(np.sqrt((res[k] ** 2).mean())), int(k.sum())


def med(sel, v):
    return {"median": round(float(np.median(v[sel])), 4), "p05": round(float(np.percentile(v[sel], 5)), 4), "p95": round(float(np.percentile(v[sel], 95)), 4), "n": int(sel.sum())}


# radial walls (cylinders) and axial faces
out["rim_r"] = med((nr > 0.95) & (r > 16.0) & (r < 16.9) & (z > 0.6) & (z < 2.9), r)
out["rim_r_by_z"] = {f"{a:.1f}": round(float(np.median(r[(nr > 0.9) & (r > 16.0) & (r < 16.9) & (np.abs(z - a) < 0.25)])), 4) for a in (0.5, 1.0, 1.5, 2.0, 2.5, 3.0)}
out["hub_disc_r"] = med((nr > 0.95) & (r > 14.9) & (r < 15.5) & (z > 3.6) & (z < 4.45), r)
out["hub_step_z"] = med((nz > 0.9) & (r > 15.45) & (r < 16.15) & (z > 2.8) & (z < 3.9), z)
out["gap_floor_z"] = med((nz > 0.97) & (r > 6.0) & (r < 14.6) & (z > 4.3) & (z < 5.0), z)
out["blade_top_z"] = med((nz > 0.97) & (r > 8.0) & (r < 14.6) & (z > 6.2) & (z < 6.8), z)
out["blade_top_z_by_r"] = {f"{a}": round(float(np.median(z[(nz > 0.97) & (np.abs(r - a) < 0.5) & (z > 6.2) & (z < 6.8)])), 4) for a in (8, 9, 10, 11, 12, 13, 14)}
out["hub_inner_r"] = med((nr > 0.9) & (r > 4.6) & (r < 5.4) & (z > 4.8) & (z < 6.3), r)
out["core_root_r"] = med((nr > 0.9) & (r > 7.2) & (r < 7.8) & (z > 6.8) & (z < 9.0), r)
# edge rounds seen in r-z: rim top outer corner, hub disc top corner
for name, (r0, r1, z0, z1) in {"rim_top_corner": (15.9, 16.6, 2.8, 3.5), "hub_top_corner": (14.7, 15.35, 4.2, 4.75), "blade_top_outer_corner": (14.6, 15.3, 6.0, 6.6)}.items():
    s = (r > r0) & (r < r1) & (z > z0) & (z < z1) & (nr > 0.25) & (nr < 0.95) & (nz > 0.25)
    if s.sum() > 150:
        c, rad, rms, n = circ(np.c_[r[s], z[s]])
        out[name] = {"R": round(rad, 3), "c_rz": [round(float(c[0]), 3), round(float(c[1]), 3)], "rms": round(rms, 4), "n": n}

# blades: wall points (|nz| small) at three heights, folded C4 (rotate by -90 q so that every blade is "blade 0")
fig, axs = plt.subplots(1, 3, figsize=(36, 12))
wall = (np.abs(nz) < 0.35) & (z > 4.85) & (z < 6.3) & (r < 15.6) & (r > 4.3)
q = np.floor(((th + 3.0) % 360.0) / 90.0)                     # the straight edges sit just above 0 / 90 / 180 / 270 deg
tf = np.radians(th - 90.0 * q)
xf, yf = r * np.cos(tf), r * np.sin(tf)
ax = axs[0]
for (z0, z1), col in (((4.85, 5.3), "b"), ((5.3, 5.8), "g"), ((5.8, 6.3), "r")):
    s = wall & (z >= z0) & (z < z1)
    ax.plot(xf[s][::3], yf[s][::3], col + ".", ms=0.4, label=f"z {z0}-{z1}")
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.legend(markerscale=20); ax.set_title("pinwheel blade walls, C4-folded, three heights")
ax.set_xticks(np.arange(-2, 16.1, 1)); ax.set_yticks(np.arange(-2, 16.1, 1))
fx, fy = xf[wall], yf[wall]
fz = z[wall]
bl = {}
# straight edge: y ~ 1.14, x 6.5..14
s = (np.abs(fy - 1.14) < 0.35) & (fx > 6.5) & (fx < 14.2)
p = np.polyfit(fx[s], fy[s], 1); resd = fy[s] - np.polyval(p, fx[s]); k = np.abs(resd) < 3 * np.std(resd); p = np.polyfit(fx[s][k], fy[s][k], 1)
bl["edge"] = {"y_at_x10": round(float(np.polyval(p, 10.0)), 4), "slope_deg": round(float(np.degrees(np.arctan(p[0]))), 3), "rms": round(float(np.std(fy[s][k] - np.polyval(p, fx[s][k]))), 4),
              "y_by_z": {f"{a}": round(float(np.median(fy[s & (np.abs(fz - a) < 0.2)])), 4) for a in (5.0, 5.5, 6.0)}}
# outer arc
ang = np.degrees(np.arctan2(fy, fx))
rr = np.hypot(fx, fy)
s = (ang > 8) & (ang < 52) & (rr > 14.6)
c, rad, rms, n = circ(np.c_[fx[s], fy[s]])
bl["outer"] = {"R": round(rad, 4), "c": [round(float(c[0]), 4), round(float(c[1]), 4)], "rms": round(rms, 4), "n": n,
               "r_by_z": {f"{a}": round(float(np.median(rr[s & (np.abs(fz - a) < 0.2)])), 4) for a in (5.0, 5.5, 6.0)}}
# crown arc: beyond the end of the outer arc, r dropping
s = (ang > 58) & (ang < 84) & (rr > 9.5) & (rr < 15.0) & (fx > 1.2)
c2, rad2, rms2, n2 = circ(np.c_[fx[s], fy[s]])
bl["crown"] = {"R": round(rad2, 4), "c": [round(float(c2[0]), 4), round(float(c2[1]), 4)], "rms": round(rms2, 4), "n": n2, "c_rho": round(float(np.hypot(*c2)), 4),
               "c_angle_deg": round(float(np.degrees(np.arctan2(c2[1], c2[0]))), 3)}
# trailing wall: x ~ 0.65, y 5.5 .. 9
s = (fx > 0.0) & (fx < 1.6) & (fy > 5.6) & (fy < 9.0)
p = np.polyfit(fy[s], fx[s], 1); resd = fx[s] - np.polyval(p, fy[s]); k = np.abs(resd) < 2.5 * np.std(resd); p = np.polyfit(fy[s][k], fx[s][k], 1)
bl["wall"] = {"x_at_y7": round(float(np.polyval(p, 7.0)), 4), "slope_deg": round(float(np.degrees(np.arctan(p[0]))), 3), "rms": round(float(np.std(fx[s][k] - np.polyval(p, fy[s][k]))), 4),
              "x_by_z": {f"{a}": round(float(np.median(fx[s & (np.abs(fz - a) < 0.2)])), 4) for a in (5.0, 5.5, 6.0)}}
out["blade"] = bl
ax = axs[1]
s = (z > 4.0) & (z < 7.5) & (r < 17.5) & (r > 3.5)
ax.hist2d(r[s], z[s], bins=[np.arange(3.5, 17.51, 0.02), np.arange(-0.5 + 4.5, 7.51, 0.02)], cmap="Greys", norm=matplotlib.colors.LogNorm())
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_title("r-z density z 4..7.5")
ax = axs[2]
s = (z > -0.6) & (z < 5.0) & (r > 13.5) & (r < 18.5)
ax.hist2d(r[s], z[s], bins=[np.arange(13.5, 18.51, 0.01), np.arange(-0.6, 5.01, 0.01)], cmap="Greys", norm=matplotlib.colors.LogNorm())
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_title("r-z density, rim and hub disc"); ax.set_xticks(np.arange(13.5, 18.51, 0.5)); ax.set_yticks(np.arange(-0.5, 5.01, 0.5))
fig.tight_layout(); fig.savefig(os.path.join(FIG, "m4_base.png"), dpi=50); plt.close(fig)
json.dump(out, open(os.path.join(QA, "m4_base_full.json" if full else "m4_base.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
