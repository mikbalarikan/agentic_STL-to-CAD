"""Zoomed views of the untwisted core section (qa/m2_core_pts.npz): slots in their own frames, grooves, tuft roots.
Writes fig/m3_zoom.png and prints robust numbers per feature."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

d = np.load(os.path.join(QA, "m2_core_pts.npz"))
xu, yu, z, nr = d["xu"].astype(float), d["yu"].astype(float), d["z"].astype(float), d["nr"].astype(float)
r = np.hypot(xu, yu)
th = np.degrees(np.arctan2(yu, xu))


def rot(a):
    c, s = np.cos(np.radians(a)), np.sin(np.radians(a))
    return xu * c + yu * s, -xu * s + yu * c          # coordinates in a frame turned by +a


fig, axs = plt.subplots(3, 4, figsize=(40, 30))
# slots: frame u along the slot axis
for q in range(4):
    u, v = rot(90.0 * q)
    s = (u > 4.3) & (u < 8.0) & (np.abs(v) < 2.2)
    ax = axs[0, q]
    ax.hist2d(v[s], u[s], bins=[np.arange(-2.2, 2.21, 0.01), np.arange(4.3, 8.01, 0.01)], cmap="Greys", norm=matplotlib.colors.LogNorm())
    ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xticks(np.arange(-2, 2.1, 0.5)); ax.set_yticks(np.arange(4.5, 8.1, 0.5))
    ax.set_title(f"slot {q} (frame turned {90*q} deg): across v, radial u")
for j, (name, a, w) in enumerate((("small groove A", 60, 2.0), ("small groove B", 240, 2.0), ("big groove A", 135, 5.0), ("big groove B", 315, 5.0))):
    u, v = rot(a)
    s = (u > 5.0) & (u < 8.2) & (np.abs(v) < w)
    ax = axs[1, j]
    ax.hist2d(v[s], u[s], bins=[np.arange(-w, w + 0.01, 0.01), np.arange(5.0, 8.21, 0.01)], cmap="Greys", norm=matplotlib.colors.LogNorm())
    ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_title(f"{name} (frame turned {a} deg)")
for j, (name, a) in enumerate((("tuft row A", 36), ("tuft row B", 216))):
    u, v = rot(a)
    s = (u > 5.5) & (u < 8.3) & (np.abs(v) < 3)
    ax = axs[2, j]
    sc = ax.scatter(v[s][::3], u[s][::3], c=z[s][::3], s=0.1, cmap="turbo")
    ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_title(f"{name} (frame turned {a} deg), colour z")
    plt.colorbar(sc, ax=ax, shrink=0.6)
# big groove depth vs z
for j, a in enumerate((135, 315)):
    u, v = rot(a)
    ax = axs[2, 2 + j]
    s = (np.abs(v) < 0.4) & (u > 5.6) & (u < 7.6)
    ax.hist2d(z[s], u[s], bins=[np.arange(8, 166, 1.0), np.arange(5.6, 7.61, 0.02)], cmap="Greys", norm=matplotlib.colors.LogNorm())
    ax.grid(True, lw=0.3); ax.set_title(f"big groove at {a} deg: radius of the floor centre line vs z")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "m3_zoom.png"), dpi=45); plt.close(fig)
print("land r: median", np.median(r[(nr > 0.97) & (r > 7.3)]), "p05/p95", np.percentile(r[(nr > 0.97) & (r > 7.3)], [5, 95]))
