"""Datum alignment of the with-bristles core scan.
Start value = matrix of the previous attempt (blade-top plane, hub cylinder, pinwheel clock). Re-measured here:
planes (blade tops, gap floor, hub step, table), axis stations (rim, hub cylinder, core lands along the whole length,
idler counterbore). Then the frame is redefined:
  Z  = axis through the hub cylinder centre and the idler counterbore centre (functional axis, 165 mm base length)
  z0 = table plane under the rim (the part stood on its drive end)  -> same convention as the reference CAD
  clock unchanged (pinwheel blade straight edges parallel to X / Y)
Writes qa/T_bristles.json (raw scan -> datum) and qa/m1_align.json.   usage: m1_align.py [full]"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import *

OLD = os.path.join(DL, r"dreame_brush_core_RE_BAND_NOT_MET_2026-10-01\dreame_brush_core_RE_BAND_NOT_MET_2026-10-01\source\intake\alignment.json")
T0 = np.array(json.load(open(OLD))["matrix_4x4"])
full = "full" in sys.argv
raw = read_stl(SCAN_BRISTLES_FULL if full else SCAN_BRISTLES_20)


def circle_irls(x, y, it=8, c=0.05):
    w = np.ones(len(x))
    for _ in range(it):
        A = np.c_[2 * x, 2 * y, np.ones(len(x))] * w[:, None]
        sol, *_ = np.linalg.lstsq(A, (x * x + y * y) * w, rcond=None)
        cx, cy = sol[0], sol[1]
        r = np.sqrt(sol[2] + cx * cx + cy * cy)
        res = np.hypot(x - cx, y - cy) - r
        s = max(1.4826 * np.median(np.abs(res)), 0.01)
        w = 1.0 / (1.0 + (res / (2.5 * s)) ** 2)
    keep = np.abs(res) < 3 * s
    return cx, cy, r, float(np.sqrt((res[keep] ** 2).mean())), int(keep.sum())


def plane_fit(p, w, it=6):
    keep = np.ones(len(p), bool)
    for _ in range(it):
        c = np.average(p[keep], axis=0, weights=w[keep])
        u, s, vt = np.linalg.svd((p[keep] - c) * np.sqrt(w[keep])[:, None], full_matrices=False)
        n = vt[2] * np.sign(vt[2, 2])
        d = (p - c) @ n
        sg = max(1.4826 * np.median(np.abs(d[keep])), 0.005)
        keep = np.abs(d) < 3 * sg
    return c, n, float(np.sqrt((d[keep] ** 2).mean())), int(keep.sum())


def measure(T, tag):
    m = Mesh(apply(T, raw))
    r, th, z = cyl(m.c)
    nz = m.n[:, 2]
    nr = (m.n[:, 0] * m.c[:, 0] + m.n[:, 1] * m.c[:, 1]) / np.maximum(r, 1e-9)
    out = {}
    # planes; zb = z of the blade-top plane in this frame
    zb = np.median(z[(nz > 0.97) & (r > 8.5) & (r < 14.5) & (z > z.min() + 5.5) & (z < z.min() + 9.5)])
    planes = {"blade_top": (nz > 0.97) & (r > 8.0) & (r < 14.6) & (np.abs(z - zb) < 0.25),
              "gap_floor": (nz > 0.97) & (r > 6.0) & (r < 14.6) & (np.abs(z - (zb - 1.92)) < 0.25),
              "hub_step": (nz > 0.9) & (r > 15.45) & (r < 16.15) & (np.abs(z - (zb - 3.22)) < 0.4),
              "table": (nz > 0.97) & (r > 17.5) & (r < 23.0) & (np.abs(z - (zb - 6.47)) < 0.4)}
    for k, s in planes.items():
        c, n, rms, nk = plane_fit(m.c[s], m.a[s])
        z_at_axis = c[2] - (n[0] * (0 - c[0]) + n[1] * (0 - c[1])) / n[2]
        out[k] = {"z_at_axis": round(float(z_at_axis), 4), "tilt_deg": round(float(np.degrees(np.arccos(min(1, abs(n[2]))))), 4),
                  "normal": n.round(5).tolist(), "rms": round(rms, 4), "n": nk, "area": round(float(m.a[s].sum()), 1)}
    # axis stations
    st = []
    def station(name, sel, r_exp):
        if sel.sum() < 40:
            return
        cx, cy, rr, rms, nk = circle_irls(m.c[sel, 0], m.c[sel, 1])
        st.append({"name": name, "z": round(float(np.average(z[sel])), 2), "cx": round(float(cx), 4), "cy": round(float(cy), 4), "r": round(float(rr), 4), "rms": round(rms, 4), "n": nk})
    station("rim r16.4", (nr > 0.9) & (np.abs(r - 16.44) < 0.4) & (z > zb - 6.0) & (z < zb - 3.8), 16.44)
    station("hub r15.2", (nr > 0.9) & (np.abs(r - 15.2) < 0.3) & (z > zb - 3.0) & (z < zb - 2.1), 15.2)
    for zz in np.arange(10, 156, 10):
        station("land", (nr > 0.9) & (np.abs(r - 7.46) < 0.25) & (np.abs(z - (zb + zz)) < 2.5), 7.46)
    station("cbore r5.93", (nr < -0.9) & (np.abs(r - 5.93) < 0.3) & (z > zb + 162.2) & (z < zb + 163.0), 5.93)
    station("bore r4.28", (nr < -0.8) & (np.abs(r - 4.28) < 0.35) & (z > zb + 158.8) & (z < zb + 161.6), 4.28)
    out["stations"] = st
    lands = [s for s in st if s["name"] == "land"]
    if len(lands) > 3:
        zz = np.array([s["z"] for s in lands])
        ax = np.polyfit(zz, [s["cx"] for s in lands], 1); ay = np.polyfit(zz, [s["cy"] for s in lands], 1)
        out["land_axis"] = {"slope_x": float(ax[0]), "slope_y": float(ay[0]), "tilt_deg": float(np.degrees(np.hypot(ax[0], ay[0]))),
                            "at_z0": [float(np.polyval(ax, zb)), float(np.polyval(ay, zb))], "at_top": [float(np.polyval(ax, zb + 160)), float(np.polyval(ay, zb + 160))],
                            "res_rms": float(np.sqrt(np.mean((np.polyval(ax, zz) - [s["cx"] for s in lands]) ** 2 + (np.polyval(ay, zz) - [s["cy"] for s in lands]) ** 2)))}
    out["zb"] = float(zb)
    out["z_min_max"] = [float(m.lo[:, 2].min()), float(m.hi[:, 2].max())]
    print("==", tag)
    for k in planes:
        print("  ", k, out[k])
    for s in st:
        print("  ", s)
    print("   land axis", out.get("land_axis"))
    return out


res = {"source": os.path.basename(SCAN_BRISTLES_FULL if full else SCAN_BRISTLES_20), "start": measure(T0, "start (previous attempt's frame)")}
# new frame: axis through hub r15.2 centre and counterbore centre
s0 = res["start"]
hub = next(s for s in s0["stations"] if s["name"] == "hub r15.2")
cb = next(s for s in s0["stations"] if s["name"] == "cbore r5.93")
a = np.array([cb["cx"] - hub["cx"], cb["cy"] - hub["cy"], cb["z"] - hub["z"]]); a /= np.linalg.norm(a)
ex = np.array([1.0, 0, 0]) - a[0] * a; ex /= np.linalg.norm(ex)
ey = np.cross(a, ex)
R = np.stack([ex, ey, a])
o = np.array([hub["cx"], hub["cy"], hub["z"]])
o = o - a * (o @ a - 0)                      # point on the axis; z fixed below
T1 = np.eye(4); T1[:3, :3] = R; T1[:3, 3] = -R @ np.array([hub["cx"], hub["cy"], 0.0]) + np.array([0, 0, 0.0])
# keep the axis point: (hub.cx, hub.cy, hub.z) must map to (0, 0, *)
p = R @ np.array([hub["cx"], hub["cy"], hub["z"]])
T1[:3, 3] = [-p[0], -p[1], 0.0]
T = T1 @ T0
mid = measure(T, "axis = hub centre -> counterbore centre (z not set yet)")
T[2, 3] -= mid["table"]["z_at_axis"]         # z = 0 on the table plane under the rim
fin = measure(T, "final datum frame (z = 0 table plane)")
res["final"] = fin
res["axis_tilt_vs_start_deg"] = float(np.degrees(np.arccos(a[2])))
json.dump({"T": T.tolist(), "note": "raw with-bristles scan -> datum frame; Z = hub r15.2 centre -> idler counterbore centre, z0 = table plane, clock from pinwheel blades",
           "source": res["source"]}, open(os.path.join(QA, "T_bristles_full.json" if full else "T_bristles.json"), "w"), indent=1)
json.dump(res, open(os.path.join(QA, "m1_align_full.json" if full else "m1_align.json"), "w"), indent=1)
print("axis tilt vs start (deg):", res["axis_tilt_vs_start_deg"])
