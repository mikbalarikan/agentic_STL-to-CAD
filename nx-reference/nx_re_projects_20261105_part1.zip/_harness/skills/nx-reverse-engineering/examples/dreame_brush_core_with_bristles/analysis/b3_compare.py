"""Evidence figure: the reference CAD (core without bristles) and the with-bristles scan are two different cores.
Writes fig/iki_farkli_cekirdek.png."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

OLD = os.path.join(DL, r"dreame_brush_core_RE_BAND_NOT_MET_2026-10-01\dreame_brush_core_RE_BAND_NOT_MET_2026-10-01\source\intake\alignment.json")
T0 = np.array(json.load(open(OLD))["matrix_4x4"])
T0[2, 3] += 6.47                                   # table at z = 0 as in the reference CAD frame
sb = Mesh(apply(T0, read_stl(SCAN_BRISTLES_20)))
cad = Mesh(read_stl(REF_CAD))
ref_scan = Mesh(read_stl(REF_SCAN, every=3))

fig, axs = plt.subplots(2, 3, figsize=(21, 14))
rows = (("REFERANS CAD  \"brush_core_no_bristles CAD.prt\"  (kırmızı) + içindeki tarama (gri)", cad, ref_scan),
        ("KILLI TARAMA  \"dreame_brush_core_with_bristles\"  (siyah)", None, sb))
for i, (ttl, c, s) in enumerate(rows):
    for j, (zz, lim, what) in enumerate(((5.5, 18, "tahrik kanatları (z = 5,5)"), (40.0, 9.5, "çekirdek kesiti (z = 40)"))):
        ax = axs[i, j]
        if c is not None:
            plot_segs(ax, s.section(2, zz)[:, :, :2], colors="0.6", linewidths=0.8)
            plot_segs(ax, c.section(2, zz)[:, :, :2], colors="r", linewidths=1.2)
        else:
            sg = s.section(2, zz)[:, :, :2]
            rr = np.hypot(sg[:, :, 0], sg[:, :, 1]).max(axis=1)
            plot_segs(ax, sg[rr < lim], colors="k", linewidths=1.0)
        ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.grid(True, lw=0.3); ax.set_title(what, fontsize=13)
    ax = axs[i, 2]
    P, _ = s.sample(500_000, seed=1)
    r, th, z = cyl(P)
    g = (r < 19) & (z > -1) & (z < 9)
    ax.hist2d(r[g], z[g], bins=[int(19 / 0.05), int(10 / 0.05)], cmap="Greys", norm=matplotlib.colors.LogNorm())
    if c is not None:
        for t in range(0, 360, 45):
            plot_segs(ax, rz_segments(c, t + 7), colors="r", linewidths=0.6, alpha=0.7)
    ax.set_xlim(0, 19); ax.set_ylim(-1, 9); ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_xticks(range(0, 20, 2))
    ax.set_title("taban yarı kesiti r–z", fontsize=13); ax.set_xlabel("r (mm)"); ax.set_ylabel("z (mm)")
    axs[i, 0].set_ylabel(ttl, fontsize=11)
axs[0, 0].text(0.02, 0.97, "5 kanat", transform=axs[0, 0].transAxes, va="top", fontsize=16, color="r")
axs[1, 0].text(0.02, 0.97, "4 kanat", transform=axs[1, 0].transAxes, va="top", fontsize=16)
axs[0, 1].text(0.02, 0.97, "5 kanal, dalgalı profil", transform=axs[0, 1].transAxes, va="top", fontsize=16, color="r")
axs[1, 1].text(0.02, 0.97, "4 T-kanal + 4 oluk", transform=axs[1, 1].transAxes, va="top", fontsize=16)
axs[0, 2].text(0.02, 0.97, "flanş r 14,5 / r 13,4", transform=axs[0, 2].transAxes, va="top", fontsize=16, color="r")
axs[1, 2].text(0.02, 0.97, "flanş r 16,4 / r 15,2", transform=axs[1, 2].transAxes, va="top", fontsize=16)
fig.suptitle("Referans CAD ile kıllı tarama aynı çekirdek değil (iki ayrı fırçanın çekirdekleri)", fontsize=17)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "iki_farkli_cekirdek.png"), dpi=70); plt.close(fig)
print("ok")
