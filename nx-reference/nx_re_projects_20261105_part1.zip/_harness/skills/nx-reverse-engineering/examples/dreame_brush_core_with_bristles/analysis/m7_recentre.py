"""Lateral correction of the base-scan registration.
The ICP against the core scan could only use what is visible between the rubber blades (one side of the brush) and
left the underside about 0.2 mm off-centre: recess wall and hex socket show the same one-sided offset.
The base scan is therefore shifted (x, y only, no rotation, no z) so that its own recess-wall circle is centred on
the datum axis. Keeps the ICP result as qa/T_base_icp.json / base_end0_tris_datum_icp.npy and overwrites
qa/T_base.json / base_end0_tris_datum.npy.   Writes qa/m7_recentre.json"""
import sys, os, json, shutil
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import *

src_npy = os.path.join(QA, "base_end0_tris_datum.npy")
icp_npy = os.path.join(QA, "base_end0_tris_datum_icp.npy")
if not os.path.exists(icp_npy):
    shutil.copy(src_npy, icp_npy)
    shutil.copy(os.path.join(QA, "T_base.json"), os.path.join(QA, "T_base_icp.json"))
tri = np.load(icp_npy).astype(np.float64)
m = Mesh(tri)
r = np.hypot(m.c[:, 0], m.c[:, 1])
nr = (m.n[:, 0] * m.c[:, 0] + m.n[:, 1] * m.c[:, 1]) / np.maximum(r, 1e-9)


def circle(sel):
    x, y = m.c[sel, 0], m.c[sel, 1]
    w = m.a[sel].copy()
    for _ in range(8):
        A = np.c_[2 * x, 2 * y, np.ones(len(x))] * w[:, None]
        sol, *_ = np.linalg.lstsq(A, (x * x + y * y) * w, rcond=None)
        cx, cy = sol[0], sol[1]
        rad = np.sqrt(sol[2] + cx * cx + cy * cy)
        res = np.hypot(x - cx, y - cy) - rad
        s = max(1.4826 * np.median(np.abs(res)), 0.01)
        w = m.a[sel] / (1 + (res / (2.5 * s)) ** 2)
    ang = np.degrees(np.arctan2(y - cy, x - cx))
    cov = float((np.histogram(ang, bins=36, range=(-180, 180))[0] > 5).mean())
    return {"cx": round(float(cx), 4), "cy": round(float(cy), 4), "r": round(float(rad), 4), "rms": round(float(np.sqrt(np.average(res ** 2, weights=w))), 4),
            "n": int(sel.sum()), "angular_coverage": round(cov, 2)}


out = {"before": {"recess_wall": circle((nr < -0.85) & (r > 10.8) & (r < 12.1) & (m.c[:, 2] > 0.7) & (m.c[:, 2] < 3.2)),
                  "boss_ring_edge": circle((nr > 0.5) & (r > 4.7) & (r < 5.4) & (m.c[:, 2] > 3.4) & (m.c[:, 2] < 3.75)),
                  "hub_disc_r15.2 (also in the core scan)": circle((nr > 0.9) & (r > 14.9) & (r < 15.5) & (m.c[:, 2] > 3.6) & (m.c[:, 2] < 4.45))}}
c = out["before"]["recess_wall"]
shift = np.array([-c["cx"], -c["cy"], 0.0])
out["shift_applied"] = shift.round(4).tolist()
out["shift_length"] = round(float(np.linalg.norm(shift)), 4)
tri2 = tri + shift
np.save(src_npy, tri2.astype(np.float32))
T = np.array(json.load(open(os.path.join(QA, "T_base_icp.json")))["T"])
T2 = T.copy(); T2[:3, 3] += shift
json.dump({"T": T2.tolist(), "note": "raw base scan (end 0) -> datum frame: ICP on the overlap with the core scan, then a lateral shift that centres the "
           "recess wall of the underside on the datum axis (see m7_recentre.json)"}, open(os.path.join(QA, "T_base.json"), "w"), indent=1)
m = Mesh(tri2)
r = np.hypot(m.c[:, 0], m.c[:, 1])
nr = (m.n[:, 0] * m.c[:, 0] + m.n[:, 1] * m.c[:, 1]) / np.maximum(r, 1e-9)
out["after"] = {"recess_wall": circle((nr < -0.85) & (r > 10.8) & (r < 12.1) & (m.c[:, 2] > 0.7) & (m.c[:, 2] < 3.2)),
                "boss_ring_edge": circle((nr > 0.5) & (r > 4.7) & (r < 5.4) & (m.c[:, 2] > 3.4) & (m.c[:, 2] < 3.75)),
                "hub_disc_r15.2 (also in the core scan)": circle((nr > 0.9) & (r > 14.9) & (r < 15.5) & (m.c[:, 2] > 3.6) & (m.c[:, 2] < 4.45))}
json.dump(out, open(os.path.join(QA, "m7_recentre.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
