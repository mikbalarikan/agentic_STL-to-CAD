"""Bristle tufts, first look: unrolled maps (untwisted angle vs z) of the scan points in radial shells.
fig/m6_shells.png   usage: m6_tufts_view.py [full]"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

full = "full" in sys.argv
T = load_T("T_bristles.json")
k = json.load(open(os.path.join(QA, "m2_twist.json")))["twist_deg_per_mm"]
m = Mesh(apply(T, read_stl(SCAN_BRISTLES_FULL if full else SCAN_BRISTLES_20, every=2 if full else 1)))
P, idx = m.sample(4_000_000, seed=9)
r, th, z = cyl(P)
tu = (th - k * (z - 6.5)) % 360.0
np.savez_compressed(os.path.join(QA, "m6_pts.npz"), P=P.astype(np.float32))
shells = [(7.9, 8.6), (9, 10), (11, 12), (13, 14), (15, 16), (17, 18), (19, 20), (21, 23)]
fig, axs = plt.subplots(2, len(shells), figsize=(6 * len(shells), 36))
for row, (c0, name) in enumerate(((36.0, "row A"), (215.0, "row B"))):
    for j, (r0, r1) in enumerate(shells):
        ax = axs[row, j]
        dth = ((tu - c0 + 180) % 360) - 180
        s = (r >= r0) & (r < r1) & (np.abs(dth) < 60) & (z > 4) & (z < 172)
        ax.plot(dth[s], z[s], "k.", ms=0.3)
        ax.set_xlim(-60, 60); ax.set_ylim(0, 172); ax.grid(True, lw=0.3); ax.set_title(f"{name}: r {r0}-{r1}  (x = untwisted angle - {c0})")
        ax.set_yticks(np.arange(0, 172, 10))
fig.tight_layout(); fig.savefig(os.path.join(FIG, "m6_shells.png"), dpi=40); plt.close(fig)
print("r max of scan points (z 10..160):", np.percentile(r[(z > 10) & (z < 160)], [99, 99.9, 100]))
