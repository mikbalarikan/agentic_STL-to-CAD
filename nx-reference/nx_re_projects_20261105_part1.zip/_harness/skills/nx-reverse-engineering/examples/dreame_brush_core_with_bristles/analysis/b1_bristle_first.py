"""First look at the with-bristles core scan in the datum frame of the previous attempt (used only as a start value).
Writes fig/b1_sections.png and fig/b1_rz.png."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

OLD = os.path.join(DL, r"dreame_brush_core_RE_BAND_NOT_MET_2026-10-01\dreame_brush_core_RE_BAND_NOT_MET_2026-10-01\source\intake\alignment.json")
T0 = np.array(json.load(open(OLD))["matrix_4x4"])
tri = apply(T0, read_stl(SCAN_BRISTLES_20))
m = Mesh(tri)
zs = [-5, -2.6, -1, 2, 30, 80, 140, 160, 162.6]
fig, axs = plt.subplots(3, 3, figsize=(24, 24))
for ax, zz in zip(axs.ravel(), zs):
    plot_segs(ax, m.section(2, zz)[:, :, :2], colors="k", linewidths=0.5)
    lim = 24 if zz < 135 and zz > 1 else 18 if zz < 1 else 10
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.grid(True, lw=0.2); ax.set_title(f"with-bristles scan, old frame z' = {zz}")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "b1_sections.png"), dpi=60); plt.close(fig)

P, idx = m.sample(1_200_000, seed=5)
r, th, z = cyl(P)
fig, axs = plt.subplots(1, 3, figsize=(30, 9))
for ax, (z0, z1, r1) in zip(axs, ((-9, 8, 24), (150, 166, 12), (-9, 166, 26))):
    s = (z > z0) & (z < z1) & (r < r1)
    b = 0.04 if z1 - z0 < 30 else 0.2
    ax.hist2d(r[s], z[s], bins=[int(r1 / b), int((z1 - z0) / b)], cmap="Greys", norm=matplotlib.colors.LogNorm())
    ax.set_xlim(0, r1); ax.set_ylim(z0, z1); ax.set_aspect("equal"); ax.grid(True, lw=0.2)
    if z1 - z0 < 30:
        ax.set_xticks(np.arange(0, r1 + 0.1, 1)); ax.set_yticks(np.arange(np.ceil(z0), z1 + 0.1, 1))
    ax.set_title(f"with-bristles scan r-z density, old frame, z' {z0}..{z1}")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "b1_rz.png"), dpi=60); plt.close(fig)
print("bbox", tri.reshape(-1, 3).min(0).round(2), tri.reshape(-1, 3).max(0).round(2))
