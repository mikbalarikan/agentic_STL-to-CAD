"""Shape of the wide grooves at 135 / 315 deg per z band (untwisted pooled points). fig/m3_vgroove.png"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

d = np.load(os.path.join(QA, "m2_core_pts.npz"))
xu, yu, z, nr = d["xu"].astype(float), d["yu"].astype(float), d["z"].astype(float), d["nr"].astype(float)
bands = [(9, 24), (24, 30), (30, 36), (36, 50), (50, 70), (70, 100), (100, 130), (130, 155), (155, 165)]
fig, axs = plt.subplots(2, 2, figsize=(30, 18))
for j, a0 in enumerate((135.0, 315.0)):
    c, s = np.cos(np.radians(a0)), np.sin(np.radians(a0))
    u, v = xu * c + yu * s, -xu * s + yu * c
    ax = axs[0, j]
    cols = plt.cm.turbo(np.linspace(0, 1, len(bands)))
    for (z0, z1), col in zip(bands, cols):
        m = (z >= z0) & (z < z1) & (np.abs(v) < 3.6) & (u > 5.6) & (u < 7.6) & (nr > 0.3)
        vb = np.arange(-3.6, 3.61, 0.06)
        idx = np.digitize(v[m], vb)
        med = [np.median(u[m][idx == i]) if (idx == i).sum() > 8 else np.nan for i in range(1, len(vb))]
        ax.plot(0.5 * (vb[:-1] + vb[1:]), med, "-", color=col, lw=1.2, label=f"z {z0}-{z1}")
    vv = np.linspace(-3.6, 3.6, 200)
    ax.plot(vv, np.sqrt(7.47 ** 2 - vv ** 2), "k--", lw=0.6, label="land circle r 7.47")
    ax.set_ylim(5.9, 7.6); ax.grid(True, lw=0.3); ax.legend(fontsize=8); ax.set_title(f"wide groove at {a0:.0f} deg: median profile u(v) per z band (not to scale)")
    ax.set_xticks(np.arange(-3.5, 3.6, 0.5)); ax.set_yticks(np.arange(5.9, 7.61, 0.1))
    ax = axs[1, j]
    m = (np.abs(v) < 3.6) & (u > 5.6) & (u < 7.6) & (z > 50) & (z < 150)
    ax.hist2d(v[m], u[m], bins=[np.arange(-3.6, 3.61, 0.01), np.arange(5.6, 7.61, 0.01)], cmap="Greys", norm=matplotlib.colors.LogNorm())
    ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_title("density z 50..150, true scale")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "m3_vgroove.png"), dpi=55); plt.close(fig)
