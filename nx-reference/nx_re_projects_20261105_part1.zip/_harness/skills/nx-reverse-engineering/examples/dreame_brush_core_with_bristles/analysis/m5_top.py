"""Idler (top) end of the with-bristles core: end face, end round, counterbore, bore, notches; blade outline constrained fit.
Writes qa/m5_top.json, fig/m5_top.png.   usage: m5_top.py [full]"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

full = "full" in sys.argv
T = load_T("T_bristles.json")
k = json.load(open(os.path.join(QA, "m2_twist.json")))["twist_deg_per_mm"]
m0 = Mesh(apply(T, read_stl(SCAN_BRISTLES_FULL if full else SCAN_BRISTLES_20)))
m = m0.sub((m0.c[:, 2] > 150) & (np.hypot(m0.c[:, 0], m0.c[:, 1]) < 9))
P, idx = m.sample(900_000, seed=4)
N = m.n[idx]
r, th, z = cyl(P)
nr = (N[:, 0] * P[:, 0] + N[:, 1] * P[:, 1]) / np.maximum(r, 1e-9)
nz = N[:, 2]
out = {}
med = lambda sel, v: {"median": round(float(np.median(v[sel])), 4), "p05": round(float(np.percentile(v[sel], 5)), 4), "p95": round(float(np.percentile(v[sel], 95)), 4), "n": int(sel.sum())}
out["z_max"] = float(z.max()); out["z_p999"] = float(np.percentile(z, 99.9))
out["end_face_z"] = med((nz > 0.97) & (r > 6.2) & (r < 6.9) & (z > 169.3), z)
out["cbore_r"] = med((nr < -0.9) & (r > 5.5) & (r < 6.3) & (z > 168.7) & (z < 169.6), r)
out["cbore_floor_z"] = med((nz > 0.95) & (r > 4.5) & (r < 5.7) & (z > 168.0) & (z < 169.0), z)
out["bore_r"] = med((nr < -0.8) & (r > 3.9) & (r < 4.7) & (z > 165.2) & (z < 168.2), r)
out["bore_deepest_z_seen"] = float(np.percentile(z[(r < 4.6) & (nr < -0.5)], 0.5))
# inner features below the counterbore: anything with r < 4 ?
out["inner_points_r_lt_3.9"] = int(((r < 3.9) & (z > 160)).sum())
# end round: fillet between the land cylinder and the end face (r-z circle fit)
s = (r > 6.3) & (r < 7.6) & (z > 168.0) & (z < 169.95) & (nr > 0.2) & (nz > 0.2)
A = np.c_[2 * r[s], 2 * z[s], np.ones(s.sum())]
sol, *_ = np.linalg.lstsq(A, r[s] ** 2 + z[s] ** 2, rcond=None)
out["end_round"] = {"R": round(float(np.sqrt(sol[2] + sol[0] ** 2 + sol[1] ** 2)), 3), "c_rz": [round(float(sol[0]), 3), round(float(sol[1]), 3)], "n": int(s.sum())}
# notches in the end ring: angular occupancy of the ring r 6.0..7.4 at z 169.0..169.6 (raw theta and untwisted to z = 6.5)
ring = (r > 5.95) & (r < 7.45) & (z > 169.0) & (z < 169.7)
h, e = np.histogram(th[ring] % 360, bins=np.arange(0, 361, 1.0))
gaps = np.where(h < 0.15 * np.median(h))[0]
runs = []
if len(gaps):
    st = gaps[0]; pv = gaps[0]
    for g in gaps[1:]:
        if g != pv + 1:
            runs.append((int(st), int(pv + 1))); st = g
        pv = g
    runs.append((int(st), int(pv + 1)))
out["ring_gaps_deg_raw"] = runs
out["ring_gaps_centre_untwisted"] = [round(float(((a + b) / 2 - k * (169.35 - 6.5)) % 360), 2) for a, b in runs]
out["ring_gap_width_mm"] = [round(float(np.radians(b - a) * 6.7), 2) for a, b in runs]
# depth of the notches: lowest z of ring points inside the gap sectors' flanks -> floor of the notch
nf = {}
for a, b in runs:
    c = (a + b) / 2
    sec = (np.abs(((th % 360) - c + 180) % 360 - 180) < (b - a) / 2 - 1.0) & (r > 5.95) & (r < 7.45) & (nz > 0.8) & (z > 160)
    if sec.sum() > 20:
        nf[f"{c:.0f}"] = round(float(np.median(z[sec])), 3)
out["notch_floor_z"] = nf
json.dump(out, open(os.path.join(QA, "m5_top_full.json" if full else "m5_top.json"), "w"), indent=1)
for a, b in out.items():
    print(a, json.dumps(b))

fig, axs = plt.subplots(1, 4, figsize=(44, 11))
ax = axs[0]
s = z > 160
ax.hist2d(r[s], z[s], bins=[np.arange(0, 9.01, 0.02), np.arange(160, 170.21, 0.02)], cmap="Greys", norm=matplotlib.colors.LogNorm())
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.set_title("idler end r-z density"); ax.set_xticks(np.arange(0, 9.1, 0.5)); ax.set_yticks(np.arange(160, 170.21, 0.5))
for ax, zz in zip(axs[1:], (169.4, 168.9, 166.5)):
    plot_segs(ax, m.section(2, zz)[:, :, :2], colors="k", linewidths=0.8)
    ax.set_xlim(-8.5, 8.5); ax.set_ylim(-8.5, 8.5); ax.grid(True, lw=0.3); ax.set_title(f"section z = {zz}")
    ax.set_xticks(np.arange(-8, 8.1, 1)); ax.set_yticks(np.arange(-8, 8.1, 1))
fig.tight_layout(); fig.savefig(os.path.join(FIG, "m5_top.png"), dpi=45); plt.close(fig)
