"""First look at the base scan: split the two brush ends, find the end-face normal and the disc axis of each,
write a per-end axis frame (qa/base_end<k>_T0.json: raw -> end frame, z = 0 on the outermost end plane, +Z into the brush)
and fig/b2_end<k>.png (r-z density, end-face height map, sections)."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

src = SCAN_BASE_FULL if "full" in sys.argv else SCAN_BASE_20
tri = read_stl(src)
m = Mesh(tri)
# split in two along the PCA long axis of the centroids
c0 = np.average(m.c, axis=0, weights=m.a)
w, e = np.linalg.eigh(np.cov((m.c - c0).T, aweights=m.a))
t = (m.c - c0) @ e[:, 2]
h, edges = np.histogram(t, bins=120, weights=m.a)
mid = np.argmin(h[40:80]) + 40
cut = 0.5 * (edges[mid] + edges[mid + 1])
print("split at t =", round(cut, 2), "areas", round(m.a[t < cut].sum(), 1), round(m.a[t >= cut].sum(), 1))


def circle_fit(x, y):
    A = np.c_[2 * x, 2 * y, np.ones(len(x))]
    sol, *_ = np.linalg.lstsq(A, x * x + y * y, rcond=None)
    cx, cy = sol[0], sol[1]
    return cx, cy, np.sqrt(sol[2] + cx * cx + cy * cy)


res = {}
for k, sel in enumerate((t < cut, t >= cut)):
    s = m.sub(sel)
    # dominant plane normal: area-weighted clustering of normals (antipodal directions kept apart)
    best = None
    rng = np.random.default_rng(1)
    cand = s.n[rng.choice(len(s.n), 4000, p=s.a / s.a.sum())]
    for d in cand[:600]:
        a = s.a[(s.n @ d) > 0.995].sum()
        if best is None or a > best[0]:
            best = (a, d)
    d = best[1]
    for _ in range(5):
        mm = (s.n @ d) > 0.99
        d = np.average(s.n[mm], axis=0, weights=s.a[mm]); d /= np.linalg.norm(d)
    mm = (s.n @ d) > 0.995
    off = s.c[mm] @ d
    hh, ee = np.histogram(off, bins=np.arange(off.min() - 0.05, off.max() + 0.1, 0.05), weights=s.a[mm])
    top = np.argsort(hh)[::-1][:8]
    print(f"end {k}: normal {d.round(4)} area {best[0]:.1f}; plane offsets (area):", [(round(0.5 * (ee[i] + ee[i + 1]), 2), round(hh[i], 1)) for i in sorted(top)])
    # frame: Z = -d (into the brush) if the outward face normal is d
    ez = -d
    ex = np.cross(ez, [0, 0, 1.0]); ex /= np.linalg.norm(ex)
    ey = np.cross(ez, ex)
    R = np.stack([ex, ey, ez])
    q = s.tri @ R.T
    sq = Mesh(q)
    z_out = (sq.c[mm, 2]).min() if False else np.percentile(sq.c[mm, 2], 0.5)
    # axis: circle fit on triangles whose normal is radial (perpendicular to ez) near the end face
    rad = (np.abs(sq.n[:, 2]) < 0.15) & (sq.c[:, 2] < z_out + 6) & (sq.c[:, 2] > z_out + 0.3)
    x, y = sq.c[rad, 0], sq.c[rad, 1]
    cx, cy = np.median(x), np.median(y)
    for _ in range(6):
        rr = np.hypot(x - cx, y - cy)
        r0 = np.percentile(rr, 85)
        keep = np.abs(rr - r0) < 0.6
        cx, cy, r0 = circle_fit(x[keep], y[keep])
    print(f"   rim circle: centre ({cx:.3f}, {cy:.3f}) r {r0:.3f}  n {keep.sum()}  rms {np.std(np.hypot(x[keep]-cx, y[keep]-cy)-r0):.4f}")
    T = np.eye(4); T[:3, :3] = R; T[:3, 3] = [-cx, -cy, -z_out]
    json.dump({"T": T.tolist(), "src": os.path.basename(src), "rim_r": float(r0), "note": "raw base scan -> end frame (start value)"},
              open(os.path.join(QA, f"base_end{k}_T0.json"), "w"), indent=1)
    p = Mesh(apply(T, s.tri))
    P, idx = p.sample(900_000, seed=2)
    r, th, z = cyl(P)
    fig, axs = plt.subplots(1, 3, figsize=(33, 11))
    ax = axs[0]
    g = (r < 22) & (z > -2) & (z < 14)
    ax.hist2d(r[g], z[g], bins=[int(22 / 0.04), int(16 / 0.04)], cmap="Greys", norm=matplotlib.colors.LogNorm())
    ax.set_aspect("equal"); ax.set_xticks(np.arange(0, 22.1, 1)); ax.set_yticks(np.arange(-2, 14.1, 1)); ax.grid(True, lw=0.2); ax.set_title(f"end {k}: r-z density (z=0 outer end plane, +z into the brush)")
    ax = axs[1]
    g = (r < 19) & (z < 9) & (p.n[idx, 2] < -0.3)
    o = np.argsort(-z[g])
    sc = ax.scatter(P[g][o, 0], P[g][o, 1], c=z[g][o], s=0.3, cmap="turbo", vmin=-0.5, vmax=8)
    ax.set_aspect("equal"); ax.set_xlim(-19, 19); ax.set_ylim(-19, 19); ax.grid(True, lw=0.2); plt.colorbar(sc, ax=ax, shrink=0.7); ax.set_title("end face seen from outside (colour = depth z)")
    ax.set_xticks(np.arange(-18, 18.1, 2)); ax.set_yticks(np.arange(-18, 18.1, 2))
    ax = axs[2]
    for zz, col in ((0.6, "k"), (2.0, "b"), (3.5, "g"), (5.0, "r")):
        plot_segs(ax, p.section(2, zz)[:, :, :2], colors=col, linewidths=0.5)
    ax.set_xlim(-19, 19); ax.set_ylim(-19, 19); ax.grid(True, lw=0.2); ax.set_title("sections z = 0.6 k, 2.0 b, 3.5 g, 5.0 r")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, f"b2_end{k}.png"), dpi=55); plt.close(fig)
    res[k] = {"normal": d.tolist(), "rim_r": float(r0)}
print(res)
