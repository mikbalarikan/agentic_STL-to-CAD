"""Underside deviation with the base scan as registered by the ICP alone (before the lateral recentring).
-> qa/dev_final_underside_icp.json"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import *

cad = Mesh(read_stl(os.path.join(OUT, "dreame_brush_core_with_bristles_core.stl")))
cs = scene_of(cad)
out = {}
for tag, fn in (("icp_only", "base_end0_tris_datum_icp.npy"), ("recentred", "base_end0_tris_datum.npy")):
    base = Mesh(np.load(os.path.join(QA, fn)).astype(np.float64))
    rb = np.hypot(base.c[:, 0], base.c[:, 1])
    base = base.sub((rb < 17.5) & (base.c[:, 2] < 13))
    Pb, ib = base.sample(400_000, seed=3)
    Nb = base.n[ib]
    rbp, tb, zb = cyl(Pb)
    under = (Nb[:, 2] < -0.5) & (zb < 4.6) & (rbp < 12.9)
    hexw = (np.abs(Nb[:, 2]) < 0.35) & (rbp < 4.4) & (zb > 3.6) & (zb < 10.3)
    recw = (np.abs(Nb[:, 2]) < 0.5) & (rbp > 10.8) & (rbp < 12.2) & (zb > 0.3) & (zb < 3.6)
    d, sg, _, _ = closest(cs, cad, Pb)
    sd = d * sg
    out[tag] = {"underside faces (r < 12.9)": stats(sd[under]), "hex socket walls": stats(sd[hexw]), "recess wall": stats(sd[recw]), "all three": stats(sd[under | hexw | recw])}
json.dump(out, open(os.path.join(QA, "dev_final_underside_icp.json"), "w"), indent=1)
for tag, v in out.items():
    for a, s in v.items():
        print(tag, "|", a, "|", {k: round(s[k], 3) for k in ("rms", "mean_signed", "p50", "p95", "p99", "max", "over_0.3", "over_0.8")})
