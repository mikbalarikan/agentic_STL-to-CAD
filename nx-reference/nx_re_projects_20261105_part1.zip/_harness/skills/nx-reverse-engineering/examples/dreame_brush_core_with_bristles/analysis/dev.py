"""Scan <-> CAD deviation for the brush core (cadgenbench venv, open3d).

usage: dev.py <tag> [full] [n N]
CAD = out/dreame_brush_core_with_bristles_core.stl (+ _tufts.stl). Scans in the datum frame:
  with-bristles scan (qa/T_bristles.json) -> hard surfaces against the core, bristle zone against core + tufts
  base scan, end 0 (qa/base_end0_tris_datum.npy) -> underside against the core
Sign: + = scan point outside the CAD material.
Writes qa/dev_<tag>.json, fig/dev_<tag>_map.png, fig/dev_<tag>_ends.png"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

args = sys.argv[1:]
tag = args[0]
full = "full" in args
n = int(args[args.index("n") + 1]) if "n" in args else 900_000
CORE = os.path.join(OUT, "dreame_brush_core_with_bristles_core.stl")
TUFTS = os.path.join(OUT, "dreame_brush_core_with_bristles_tufts.stl")
k = json.load(open(os.path.join(QA, "m2_twist.json")))["twist_deg_per_mm"]
R_CORE = 7.475

cad = Mesh(read_stl(CORE))
tufts = Mesh(read_stl(TUFTS)) if os.path.exists(TUFTS) else None
cs = scene_of(cad)
scan = Mesh(apply(load_T("T_bristles.json"), read_stl(SCAN_BRISTLES_FULL if full else SCAN_BRISTLES_20, every=2 if full else 1)))
P, idx = scan.sample(n, seed=11)
N = scan.n[idx]
r, th, z = cyl(P)
# ---- masks
table = ((z < 0.3) & (r > 15.3)) | (z < -0.3) | (r > 22.5) | ((z < 7.0) & (r > 17.0))      # table plane, its fringe, debris beside the flange
soft = (r > R_CORE + 0.35) & (z > 6.9) & (z < 162.0) & ~table          # bristles (and their debris)
hard = ~table & ~soft
d, sg, tid, q = closest(cs, cad, P)
s2c = d * sg
out = {"scan": "full resolution, every 2nd triangle" if full else "20 MB decimated", "n_points": int(n),
       "share": {"table": float(table.mean()), "bristle_zone": float(soft.mean()), "hard": float(hard.mean())},
       "hard_scan_to_cad": stats(s2c[hard])}
zones = {"drive end z < 6.5": hard & (z < 6.5), "core 6.5 .. 30": hard & (z >= 6.5) & (z < 30), "core 30 .. 100": hard & (z >= 30) & (z < 100),
         "core 100 .. 160": hard & (z >= 100) & (z < 160), "idler end z > 160": hard & (z >= 160),
         "lands (r > 7.3, z 8..165)": hard & (r > 7.3) & (z > 8) & (z < 165), "slots and grooves (r < 7.3, z 8..165)": hard & (r <= 7.3) & (z > 8) & (z < 165)}
out["hard_zones"] = {a: {kk: (round(v, 4) if isinstance(v, float) else v) for kk, v in stats(s2c[m]).items()} for a, m in zones.items()}
# bristle zone: against core + tufts
if tufts is not None:
    both = Mesh(np.concatenate([cad.tri, tufts.tri]))
    bs = scene_of(both)
    db, sgb, _, _ = closest(bs, both, P[soft])
    out["bristle_zone_scan_to_core_plus_tufts"] = stats(db * sgb)
    # how much of the tuft surface has scan nearby, and how far the tufts are from the scanned bristles
    Q, qi = tufts.sample(200_000, seed=5)
    ss = scene_of(scan)
    dq, _, _, _ = closest(ss, scan, Q)
    out["tufts_to_scan"] = stats(dq)
    rq = np.hypot(Q[:, 0], Q[:, 1])
    out["tufts_to_scan_by_radius"] = {f"{a}-{a+2}": round(float(np.median(dq[(rq >= a) & (rq < a + 2)])), 3) for a in range(8, 19, 2) if ((rq >= a) & (rq < a + 2)).sum() > 50}
# ---- CAD -> scans (core surface): observed share
base_tri = np.load(os.path.join(QA, "base_end0_tris_datum.npy")).astype(np.float64)
base = Mesh(base_tri)
rb = np.hypot(base.c[:, 0], base.c[:, 1])
base = base.sub((rb < 17.5) & (base.c[:, 2] < 13))
Qc, qci = cad.sample(400_000, seed=7)
ss = scene_of(scan)
sb = scene_of(base)
d1, _, _, _ = closest(ss, scan, Qc)
d2, _, _, _ = closest(sb, base, Qc)
dm = np.minimum(d1, d2)
out["cad_to_scans"] = {"all": stats(dm), "observed_lt_1.0": stats(dm[dm < 1.0]), "unobserved_share_ge_1.0": float((dm >= 1.0).mean())}
# ---- underside against the base scan
Pb, ib = base.sample(400_000, seed=3)
Nb = base.n[ib]
rbp, tb, zb = cyl(Pb)
under = (Nb[:, 2] < -0.5) & (zb < 4.6) & (rbp < 12.9)                    # annulus (inside the felt strip), recess wall / floor, ring, pits
hexw = (np.abs(Nb[:, 2]) < 0.35) & (rbp < 4.4) & (zb > 3.6) & (zb < 10.3)
recw = (np.abs(Nb[:, 2]) < 0.5) & (rbp > 10.8) & (rbp < 12.2) & (zb > 0.3) & (zb < 3.6)
db_, sgb_, _, _ = closest(cs, cad, Pb)
sdb = db_ * sgb_
out["base_scan_to_cad"] = {"underside faces (r < 12.9)": stats(sdb[under]), "hex socket walls": stats(sdb[hexw]), "recess wall": stats(sdb[recw]),
                           "all three": stats(sdb[under | hexw | recw])}
json.dump(out, open(os.path.join(QA, f"dev_{tag}.json"), "w"), indent=1)
np.savez_compressed(os.path.join(QA, f"dev_{tag}.npz"), P=P[hard].astype(np.float32), d=s2c[hard].astype(np.float32))
print(json.dumps({a: out[a] for a in ("share", "hard_scan_to_cad")}, indent=1))
for a, v in out["hard_zones"].items():
    print("  %-40s" % a, {kk: v[kk] for kk in ("n", "rms", "mean_signed", "p50", "p95", "p99", "over_0.3", "over_0.8")})
for a in ("bristle_zone_scan_to_core_plus_tufts", "tufts_to_scan", "tufts_to_scan_by_radius", "cad_to_scans", "base_scan_to_cad"):
    print(a, json.dumps(out.get(a)))

# ---- figures
lim = 0.5
fig, axs = plt.subplots(2, 1, figsize=(26, 14))
m = hard & (z > 6.5) & (r > 4.0)
tu = (th[m] - k * (z[m] - 6.5)) % 360.0
o = np.argsort(np.abs(s2c[m]))
sc = axs[0].scatter(z[m][o], th[m][o] % 360, c=s2c[m][o], s=0.15, cmap="coolwarm", vmin=-lim, vmax=lim)
axs[0].set_xlim(0, 172); axs[0].set_ylim(0, 360); axs[0].set_ylabel("angle (deg)"); axs[0].set_title("core, hard surfaces: signed scan -> CAD distance (mm), unrolled: angle vs z")
plt.colorbar(sc, ax=axs[0], shrink=0.8)
sc = axs[1].scatter(z[m][o], tu[o], c=s2c[m][o], s=0.15, cmap="coolwarm", vmin=-lim, vmax=lim)
axs[1].set_xlim(0, 172); axs[1].set_ylim(0, 360); axs[1].set_xlabel("z (mm)"); axs[1].set_ylabel("untwisted angle (deg)")
axs[1].set_title("same, angle untwisted to z = 6.5 (slots at 1 / 91 / 181 / 271, small grooves 60 / 240, wide grooves 136 / 316, tuft rows 36 / 216)")
plt.colorbar(sc, ax=axs[1], shrink=0.8)
fig.tight_layout(); fig.savefig(os.path.join(FIG, f"dev_{tag}_map.png"), dpi=60); plt.close(fig)

fig, axs = plt.subplots(1, 3, figsize=(39, 13))
m = hard & (z < 6.8) & (N[:, 2] > 0.3)
o = np.argsort(np.abs(s2c[m]))
sc = axs[0].scatter(P[m][o, 0], P[m][o, 1], c=s2c[m][o], s=0.4, cmap="coolwarm", vmin=-lim, vmax=lim)
axs[0].set_title("drive end seen from +Z (blade tops, floor, flange step): scan -> CAD")
m2 = under | hexw | recw
o = np.argsort(np.abs(sdb[m2]))
sc = axs[1].scatter(Pb[m2][o, 0], Pb[m2][o, 1], c=sdb[m2][o], s=0.4, cmap="coolwarm", vmin=-lim, vmax=lim)
axs[1].set_title("underside (base scan) seen from -Z: scan -> CAD")
m3 = hard & (z > 163.5)
o = np.argsort(np.abs(s2c[m3]))
sc = axs[2].scatter(P[m3][o, 0], P[m3][o, 1], c=s2c[m3][o], s=0.8, cmap="coolwarm", vmin=-lim, vmax=lim)
axs[2].set_title("idler end (z > 163.5): scan -> CAD")
for ax, w in zip(axs, (17.5, 13.5, 8.5)):
    ax.set_aspect("equal"); ax.set_xlim(-w, w); ax.set_ylim(-w, w); ax.grid(True, lw=0.3)
    plt.colorbar(sc, ax=ax, shrink=0.7)
fig.tight_layout(); fig.savefig(os.path.join(FIG, f"dev_{tag}_ends.png"), dpi=50); plt.close(fig)
