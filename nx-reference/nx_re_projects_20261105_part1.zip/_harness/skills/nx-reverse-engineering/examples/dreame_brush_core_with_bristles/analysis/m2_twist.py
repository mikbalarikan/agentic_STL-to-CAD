"""Twist of the core and the untwisted cross-section.
Phase of the core section per z slab by circular cross-correlation of r(theta) against the pooled, untwisted profile
(two passes), linear fit phase(z). Then all core points are untwisted and pooled: fig/m2_untwisted.png (density of the
section, z-colour check) and fig/m2_twist.png (phase residual). Writes qa/m2_twist.json and qa/m2_core_pts.npz.
usage: m2_twist.py [full]"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import *

full = "full" in sys.argv
T = load_T("T_bristles.json")
m = Mesh(apply(T, read_stl(SCAN_BRISTLES_FULL if full else SCAN_BRISTLES_20)))
P, idx = m.sample(4_000_000 if full else 3_000_000, seed=7)
N = m.n[idx]
r, th, z = cyl(P)
core = (r < 8.2) & (z > 8) & (z < 166)
P, N, r, th, z = P[core], N[core], r[core], th[core], z[core]
print("core points", len(P))
NB = 720                                    # 0.5 deg bins
Z0 = 6.5                                    # reference height of the untwisted profile (top of the pinwheel blades)


def profile(sel, k):
    """outer envelope r(theta_u): 90th percentile of r per bin of the untwisted angle."""
    tu = (th[sel] - k * (z[sel] - Z0)) % 360.0
    b = (tu / 360.0 * NB).astype(int) % NB
    out = np.full(NB, np.nan)
    o = np.argsort(b)
    bs, rs = b[o], r[sel][o]
    edges = np.searchsorted(bs, np.arange(NB + 1))
    for i in range(NB):
        if edges[i + 1] - edges[i] >= 4:
            out[i] = np.percentile(rs[edges[i]:edges[i + 1]], 90)
    return out


def xcorr_shift(a, ref, win=12.0):
    """shift (deg) of profile a against ref, searched only within +-win (the section is nearly 4-fold symmetric)."""
    a0 = np.where(np.isnan(a), np.nanmedian(a), a) - np.nanmedian(a)
    r0 = np.where(np.isnan(ref), np.nanmedian(ref), ref) - np.nanmedian(ref)
    a0, r0 = np.clip(a0, -1.5, 0.3), np.clip(r0, -1.5, 0.3)
    f = np.fft.irfft(np.fft.rfft(a0) * np.conj(np.fft.rfft(r0)), NB)
    w = int(win / 360.0 * NB)
    cand = np.r_[np.arange(0, w + 1), np.arange(NB - w, NB)]
    i = int(cand[np.argmax(f[cand])])
    y0, y1, y2 = f[(i - 1) % NB], f[i], f[(i + 1) % NB]
    d = 0.5 * (y0 - y2) / (y0 - 2 * y1 + y2) if (y0 - 2 * y1 + y2) != 0 else 0.0
    s = (i + d) * 360.0 / NB
    return (s + 180) % 360 - 180


k = -1.597                                  # start value (previous attempt); re-fitted below
slabs = np.arange(10, 164, 2.0)
for it in range(3):
    # slab-to-slab tracking in the frame untwisted with the current k: every step is a small shift
    profs = [profile(np.abs(z - zc) < 1.0, k) for zc in slabs]
    ph = [0.0]
    for a, b in zip(profs[:-1], profs[1:]):
        ph.append(ph[-1] + xcorr_shift(b, a))
    ph = np.array(ph)
    c = np.polyfit(slabs, ph, 1)
    print(f"pass {it}: k = {k:.5f} deg/mm, residual slope {c[0]:+.5f}, phase rms {np.std(ph - np.polyval(c, slabs)):.3f} deg, range {ph.min():.2f}..{ph.max():.2f}")
    k = k + c[0]
# absolute check against the pooled profile (no drift accumulation)
ref = profile(np.ones(len(z), bool), k)
ph = np.array([xcorr_shift(profile(np.abs(z - zc) < 1.0, k), ref, win=8.0) for zc in slabs])
c = np.polyfit(slabs, ph, 1)
print(f"pooled check: residual slope {c[0]:+.6f} deg/mm, phase rms {np.std(ph - np.polyval(c, slabs)):.3f} deg, range {ph.min():.2f}..{ph.max():.2f}")
k = k + c[0]
res = {"twist_deg_per_mm": float(k), "pitch_mm_per_rev": float(360.0 / abs(k)), "hand": "left" if k < 0 else "right", "z_ref": Z0,
       "phase_residual_deg": [float(v) for v in ph - np.polyval(c, slabs)], "slabs": slabs.tolist(), "phase_rms_deg": float(np.std(ph - np.polyval(c, slabs))),
       "source": "full" if full else "20MB"}
# quadratic term (is the twist constant?)
c2 = np.polyfit(slabs, ph, 2)
res["quadratic_deg_per_mm2"] = float(c2[0])
res["total_twist_deg_over_163.3"] = float(k * 163.3)
json.dump(res, open(os.path.join(QA, "m2_twist_full.json" if full else "m2_twist.json"), "w"), indent=1)
print(json.dumps({a: b for a, b in res.items() if a not in ("phase_residual_deg", "slabs")}))

tu = np.radians(th - k * (z - Z0))
xu, yu = r * np.cos(tu), r * np.sin(tu)
np.savez_compressed(os.path.join(QA, "m2_core_pts.npz"), xu=xu.astype(np.float32), yu=yu.astype(np.float32), z=z.astype(np.float32),
                    nr=((N[:, 0] * P[:, 0] + N[:, 1] * P[:, 1]) / np.maximum(r, 1e-9)).astype(np.float32),
                    nz=N[:, 2].astype(np.float32), k=k)
fig, axs = plt.subplots(1, 3, figsize=(36, 12))
ax = axs[0]
ax.hist2d(xu, yu, bins=[np.arange(-8.5, 8.51, 0.02)] * 2, cmap="Greys", norm=matplotlib.colors.LogNorm())
ax.set_aspect("equal"); ax.grid(True, lw=0.2); ax.set_xticks(np.arange(-8, 8.1, 1)); ax.set_yticks(np.arange(-8, 8.1, 1))
ax.set_title(f"untwisted core section, all z 8..166 pooled (twist {k:.4f} deg/mm, ref z = {Z0})")
ax = axs[1]
s = np.random.default_rng(0).choice(len(xu), 400_000, replace=False)
sc = ax.scatter(xu[s], yu[s], c=z[s], s=0.05, cmap="turbo")
ax.set_aspect("equal"); ax.grid(True, lw=0.2); plt.colorbar(sc, ax=ax, shrink=0.7); ax.set_title("same, colour = z (smear = twist error or taper)")
ax = axs[2]
ax.plot(slabs, ph - np.polyval(c, slabs), "k.-"); ax.grid(True); ax.set_xlabel("z"); ax.set_ylabel("phase residual (deg)")
ax.set_title(f"phase residual after linear twist; rms {res['phase_rms_deg']:.3f} deg")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "m2_untwisted_full.png" if full else "m2_untwisted.png"), dpi=60); plt.close(fig)
