"""Quick multi-view render of an STL (cadgenbench venv: pyvista).
usage: view.py <in.stl> <out.png> [axis x y z] [edges]"""
import sys
import numpy as np
import pyvista as pv

src, out = sys.argv[1:3]
args = sys.argv[3:]
pv.OFF_SCREEN = True
m = pv.read(src)
if m.n_cells > 600_000:
    m = m.decimate_pro(1 - 600_000 / m.n_cells)
c = np.array(m.center)
pts = np.asarray(m.points) - c
w, e = np.linalg.eigh(np.cov(pts[:: max(1, len(pts) // 200000)].T))
ax = e[:, 2]
if "axis" in args:
    i = args.index("axis")
    ax = np.array([float(v) for v in args[i + 1:i + 4]])
ax = ax / np.linalg.norm(ax)
u = np.cross(ax, [1.0, 0, 0])
if np.linalg.norm(u) < 0.2:
    u = np.cross(ax, [0, 1.0, 0])
u /= np.linalg.norm(u)
v = np.cross(ax, u)
L = m.length
views = [("side u", u, ax), ("side v", v, ax), ("side -u", -u, ax), ("side -v", -v, ax), ("end +axis", ax, u), ("end -axis", -ax, u),
         ("iso +", 0.6 * ax + 0.6 * u + 0.5 * v, ax), ("iso -", -0.6 * ax + 0.6 * u - 0.5 * v, ax)]
pl = pv.Plotter(off_screen=True, shape=(2, 4), window_size=(2800, 1500))
for k, (name, d, up) in enumerate(views):
    pl.subplot(k // 4, k % 4)
    pl.set_background("white")
    pl.add_mesh(m, color="#b8c4cf", specular=0.2, ambient=0.25, diffuse=0.8, smooth_shading=False)
    if "edges" in args:
        ed = m.extract_feature_edges(feature_angle=30, boundary_edges=True, non_manifold_edges=False, manifold_edges=False)
        pl.add_mesh(ed, color="#202020", line_width=1.0)
    d = np.array(d, float) / np.linalg.norm(d)
    pl.camera.position = tuple(c + d * L * 1.2)
    pl.camera.focal_point = tuple(c)
    pl.camera.up = tuple(up)
    pl.camera.parallel_projection = True
    pl.camera.parallel_scale = L * (0.2 if name.startswith("end") else 0.52)
    pl.add_text(name, font_size=10, color="black")
pl.screenshot(out)
print("saved", out, "axis", ax.round(4).tolist())
