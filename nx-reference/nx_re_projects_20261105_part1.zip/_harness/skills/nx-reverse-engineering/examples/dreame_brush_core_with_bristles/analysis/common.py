"""Scan analysis helpers for the Dreame brush core (frame = Datum CSYS of the reference CAD:
Z = brush axis, z = 0 the underside of the drive-end disc of the reference model, core towards +Z)."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
import json
import numpy as np

WS = r"C:\NX_MCP_WORKSPACE\dreame_brush"
AN = os.path.join(WS, "an")
OUT = os.path.join(WS, "out")
FIG = os.path.join(WS, "fig")
QA = os.path.join(WS, "qa")
DL = r"C:\Users\marya\Downloads"
SCAN_BRISTLES_20 = os.path.join(DL, "dreame_brush_core_with_bristles_decimated_20MB.stl")
SCAN_BRISTLES_FULL = os.path.join(DL, r"dreame_brush_core_with_bristles (1)\dreame_brush_core_with_bristles.stl")
SCAN_BASE_20 = os.path.join(DL, "dreame_brush_base_decimated_20MB.stl")
SCAN_BASE_FULL = os.path.join(DL, "dreame_brush_base.stl")
REF_SCAN = os.path.join(OUT, "a_body0.stl")       # convergent body stored in the reference part (core without bristles), CAD frame
REF_CAD = os.path.join(OUT, "a_body5.stl")        # product sheet body of the reference part

DT = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])


def read_stl(path, every=1):
    """(n, 3, 3) float64 triangles of a binary STL; memory-mapped read, optional thinning."""
    with open(path, "rb") as f:
        f.seek(80)
        n = int(np.frombuffer(f.read(4), "<u4")[0])
    d = np.memmap(path, DT, mode="r", offset=84, shape=(n,))
    return np.asarray(d["v"][::every], dtype=np.float64)


def write_stl(path, tri):
    tri = np.asarray(tri, np.float32)
    d = np.zeros(len(tri), DT)
    d["v"] = tri
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    d["n"] = n / np.maximum(np.linalg.norm(n, axis=1), 1e-20)[:, None]
    with open(path, "wb") as f:
        f.write(b"dreame_brush".ljust(80, b" "))
        f.write(np.uint32(len(tri)).tobytes())
        f.write(d.tobytes())


def apply(T, p):
    """4x4 transform on (..., 3) points."""
    T = np.asarray(T, float)
    return p @ T[:3, :3].T + T[:3, 3]


def load_T(name):
    return np.array(json.load(open(os.path.join(QA, name)))["T"], float)


class Mesh:
    def __init__(self, tri):
        self.tri = tri
        self.c = tri.mean(axis=1)
        nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        a = np.linalg.norm(nrm, axis=1)
        self.n = nrm / np.maximum(a, 1e-12)[:, None]
        self.a = a / 2
        self.lo = tri.min(axis=1)
        self.hi = tri.max(axis=1)

    def sub(self, mask):
        return Mesh(self.tri[mask])

    def section(self, axis, value, box=None):
        """Segments (m, 2, 3) where the plane axis=value cuts the mesh."""
        m = (self.lo[:, axis] <= value) & (self.hi[:, axis] >= value)
        if box is not None:
            for ax, (a0, a1) in box.items():
                m &= (self.hi[:, ax] >= a0) & (self.lo[:, ax] <= a1)
        return plane_cut(self.tri[m], np.eye(3)[axis], value)

    def cut(self, normal, d):
        """Segments where the plane normal . p = d cuts the mesh."""
        normal = np.asarray(normal, float)
        s = self.tri @ normal - d
        m = (s.min(axis=1) <= 0) & (s.max(axis=1) >= 0)
        return plane_cut(self.tri[m], normal, d)

    def sample(self, n, seed=0, mask=None):
        rng = np.random.default_rng(seed)
        a = self.a if mask is None else np.where(mask, self.a, 0.0)
        idx = rng.choice(len(a), size=n, p=a / a.sum())
        u, v = rng.random(n), rng.random(n)
        f = u + v > 1
        u[f], v[f] = 1 - u[f], 1 - v[f]
        t = self.tri[idx]
        return t[:, 0] + (t[:, 1] - t[:, 0]) * u[:, None] + (t[:, 2] - t[:, 0]) * v[:, None], idx


def plane_cut(t, normal, value):
    d = t @ np.asarray(normal, float) - value
    segs = []
    for i, j, k in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
        s = (d[:, i] * d[:, j] < 0) & (d[:, i] * d[:, k] < 0)
        if not s.any():
            continue
        ti, di, dj, dk = t[s], d[s, i], d[s, j], d[s, k]
        p1 = ti[:, i] + (ti[:, j] - ti[:, i]) * (di / (di - dj))[:, None]
        p2 = ti[:, i] + (ti[:, k] - ti[:, i]) * (di / (di - dk))[:, None]
        segs.append(np.stack([p1, p2], axis=1))
    if not segs:
        return np.zeros((0, 2, 3))
    return np.concatenate(segs)


def cyl(p):
    """r, theta (deg, -180..180), z of points."""
    return np.hypot(p[..., 0], p[..., 1]), np.degrees(np.arctan2(p[..., 1], p[..., 0])), p[..., 2]


def rz_segments(mesh, theta_deg):
    """Half-plane section at angle theta: (m, 2, 2) segments in (r, z), only the side r > 0."""
    t = np.radians(theta_deg)
    e = np.array([np.cos(t), np.sin(t), 0.0])
    nrm = np.array([-np.sin(t), np.cos(t), 0.0])
    s = mesh.cut(nrm, 0.0)
    if not len(s):
        return np.zeros((0, 2, 2))
    r = s @ e
    keep = (r > 0).all(axis=1)
    return np.stack([r[keep], s[keep][:, :, 2]], axis=2)


def plot_segs(ax, segs2, **kw):
    from matplotlib.collections import LineCollection
    lc = LineCollection(segs2, **{"linewidths": 0.6, "colors": "k", **kw})
    ax.add_collection(lc)
    ax.set_aspect("equal")
    ax.autoscale()


def scene_of(mesh):
    import open3d as o3d
    v = mesh.tri.reshape(-1, 3).astype(np.float32)
    f = np.arange(len(v), dtype=np.uint32).reshape(-1, 3)
    s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(v), o3d.core.Tensor(f))
    return s


def closest(scene, mesh, pts):
    """distance, sign (+ = on the normal side of the nearest triangle), triangle id, closest point."""
    import open3d as o3d
    r = scene.compute_closest_points(o3d.core.Tensor(pts.astype(np.float32)))
    q = r["points"].numpy().astype(np.float64)
    tid = r["primitive_ids"].numpy()
    d = pts - q
    dist = np.linalg.norm(d, axis=1)
    sign = np.sign(np.einsum("ij,ij->i", d, mesh.n[tid]))
    sign[sign == 0] = 1.0
    return dist, sign, tid, q


def stats(d):
    a = np.abs(np.asarray(d))
    if not len(a):
        return {"n": 0}
    return {"n": int(len(a)), "rms": float(np.sqrt((a ** 2).mean())), "mean_signed": float(np.mean(d)), "p50": float(np.percentile(a, 50)),
            "p90": float(np.percentile(a, 90)), "p95": float(np.percentile(a, 95)), "p99": float(np.percentile(a, 99)), "max": float(a.max()),
            "over_0.3": float((a > 0.3).mean()), "over_0.8": float((a > 0.8).mean())}
