"""Probe: revolve about a tilted axis - what makes 'Unable to create revolved body'?"""
import os, sys, traceback, math
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\dreame_cover\nxlib")
import NXOpen
import nxh, nxf
import ps, geo

OUT = sys.argv[1]
res = {"result": "FAIL", "log": []}
try:
    part = nxh.new_part(os.path.join(OUT, "probe2.prt"))
    dat = nxh.Datums(part)
    ax0 = (169.66, -20.68, 0.0)
    ta = math.radians(30.0)
    dA = (math.sin(ta), 0.0, math.cos(ta))
    _fp, pl = nxh.datum_plane(part, ax0, (0, 1, 0), "PL")
    _fv, axv = nxf.datum_axis(part, "point_dir", ax0, (0, 0, 1), "AXV")
    o = nxh.point(part, *ax0)

    def loc(rad, h):
        return (h * math.sin(ta) + rad * math.cos(ta), h * math.cos(ta) - rad * math.sin(ta))

    t = 1.8
    A1, RA1, A2, RA2 = (-29.715, 3.958), 43.705, (3.472, -2.188), 10.225
    JA = geo.circ_circ(A1, RA1, A2, RA2, (12.3, -7.5))
    JAo = geo.circ_circ(A1, RA1 + t, A2, RA2 + t, (13.8, -8.6))
    ht = 10.5
    it, ot = geo.circ_at_v(A1, RA1, ht, +1), geo.circ_at_v(A1, RA1 + t, ht, +1)
    cases = {
        "rect": ([(5, -3), (9, -3), (9, 4), (5, 4)], {}),
        "rect_on_axis": ([(0, -3), (9, -3), (9, 4), (0, 4)], {}),
        "full": ([(it, ht), JA, (A2[0], A2[1] - RA2), (0.0, A2[1] - RA2), (0.0, A2[1] - RA2 - t), (A2[0], A2[1] - RA2 - t), JAo, (ot, ht)],
                 {0: A1, 1: A2, 5: A2, 6: A1}),
        "full_off_axis": ([(it, ht), JA, (A2[0], A2[1] - RA2), (0.3, A2[1] - RA2), (0.3, A2[1] - RA2 - t), (A2[0], A2[1] - RA2 - t), JAo, (ot, ht)],
                          {0: A1, 1: A2, 5: A2, 6: A1}),
        "lines_only": ([(it, ht), JA, (A2[0], A2[1] - RA2), (0.0, A2[1] - RA2), (0.0, A2[1] - RA2 - t), (A2[0], A2[1] - RA2 - t), JAo, (ot, ht)], {}),
    }
    for name, (mer, arcs) in cases.items():
        for axis_kind in ("nxh.axis", "datum"):
            m = nxh.mark(name, False)
            try:
                S = ps.Sketch(part, dat, "xz", "SK_" + name, on=pl, origin=o, vax=axv, shift=ax0)
                S.profile([loc(*q) for q in mer], {k: loc(*v) + (None,) for k, v in arcs.items()})
                st = S.finish(strict=False)
                if axis_kind == "nxh.axis":
                    ax = nxh.axis(part, ax0, dA)
                else:
                    _f, da = nxf.datum_axis(part, "point_dir", ax0, dA, "AXT_" + name)
                    ax = nxf.axis_from(part, da)
                f = nxf.revolve(part, S.section(), ax, -90, 90)
                b = f.GetBodies()[0]
                res["log"].append("%s / %s: OK volume %.2f bbox %s (sketch %s dof %s)" % (name, axis_kind, nxh.volume(part, b), [round(v, 2) for v in nxh.bbox(b)], st["status"], st["dof"]))
            except Exception as ex:  # noqa: BLE001
                res["log"].append("%s / %s: FAILED %s" % (name, axis_kind, str(ex)[:120]))
            nxh.undo_to(m)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "probe2.json"), res)
