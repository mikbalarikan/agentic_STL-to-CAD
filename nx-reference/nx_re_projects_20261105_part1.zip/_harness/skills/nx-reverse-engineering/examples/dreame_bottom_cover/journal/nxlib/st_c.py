"""Stage C - bowl end: end block, cells, two revolved bowl shells, fins, bowl voids, conical deck."""
import math

import nxh
import nxf
import ps
import geo

BOOL = nxh.BOOL
X, Y, Z = (1, 0, 0), (0, 1, 0), (0, 0, 1)


def run(c):
    p, e, M, dat = c.part, c.e, c.M, c.dat
    e("end_x", 192.6, "end face of the bowl end")
    e("end_bot", 14.8, "underside of the end block")
    e("plate_t", 1.85, "bottom plate thickness")
    e("deck_und", 1.2, "underside of the deck below the flange plane")
    e("fr_x", 173.33, "front plane of the end block at the flange plane")
    e("fr_k", 0.172, "front plane: dx per dz (leans back towards the top)", None)
    e("eb_y0", 76.5, "end block, rail side")
    e("eb_y1", 11.3, "end block, hook side")
    xe, zb = M["end_x"], -M["end_bot"]
    ztop = 3.3

    def xf(z):
        return M["fr_x"] + M["fr_k"] * z

    # ---- END_BLOCK (side profile, extruded across)
    S = c.sketch("xz", "SK_END_BLOCK")
    blk = [(xf(zb), zb, None, "end_bot"), (xe, zb, "end_x", None), (xe, ztop), (xf(ztop), ztop)]
    S.profile(blk)
    c.done(S)
    f = c.extrude(S, Y, "-eb_y0", "-eb_y1", "END_BLOCK")
    eb = f.GetBodies()[0]
    c.chk("END_BLOCK volume", c.vol(eb), geo.area(blk) * (M["eb_y0"] - M["eb_y1"]), 0.5)
    # ---- in front of the cells the rail side of the block is open above the bottom plate
    S = c.sketch("yz", "SK_RAIL_POCKET")
    S.profile([(-M["eb_y0"] - 1.0, zb + M["plate_t"], None, "end_bot-plate_t"), (-66.5, zb + M["plate_t"]), (-66.5, 12.0), (-M["eb_y0"] - 1.0, 12.0)])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, X, 150.0, 175.0, "RAIL_POCKET", BOOL.Subtract, eb)
    c.chk.true("RAIL_POCKET cut", c.vol(eb) < v0 - 100, v0 - c.vol(eb))
    # ---- back wall of the rail runs on behind bowl B (thin wall, outer face = back face of the channel wall)
    e("bw_t", 1.5, "back wall thickness behind bowl B")
    e("bw_x1", 182.2, "back wall ends at the rail-end housing")
    cy, Ro = -M["ch_cy"], M["ch_R"] + M["ch_t"]
    Ri = Ro - M["bw_t"]
    bw = [(-M["fl_y"], 0.0, "fl_y", None), (cy - Ri, 0.0), (geo.circ_at_v((cy, 0), Ri, zb, -1), zb, None, "end_bot"),
          (geo.circ_at_v((cy, 0), Ro, zb, -1), zb), (geo.circ_at_v((cy, 0), Ro, -M["fl_t"], -1), -M["fl_t"], None, "fl_t"), (-M["fl_y"], -M["fl_t"])]
    S = c.sketch("yz", "SK_BACK_WALL")
    S.profile(bw, {1: (cy, 0.0, None), 3: (cy, 0.0, None)})
    c.done(S)
    c.extrude(S, X, "rail_x1-0.5", "bw_x1", "BACK_WALL", BOOL.Unite, eb)
    # ---- cells: one cavity open at the end face, bounded by the back wall on the rail side
    e("cell_x0", 175.0, "inner end of the cells")
    e("cell_y1", 12.5, "cell cavity, hook side")
    zp, zd = zb + M["plate_t"], -M["deck_und"]
    S = c.sketch("yz", "SK_CELLS")
    S.profile([(geo.circ_at_v((cy, 0), Ri, zp, -1), zp, None, "end_bot-plate_t"), (-M["cell_y1"], zp, "cell_y1", None),
               (-M["cell_y1"], zd, None, "deck_und"), (geo.circ_at_v((cy, 0), Ri, zd, -1), zd)], {3: (cy, 0.0, None)})
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, X, "cell_x0", "end_x+1", "CELLS", BOOL.Subtract, eb)
    c.chk.true("CELLS cut", c.vol(eb) < v0 - 5000, v0 - c.vol(eb))

    # ---- bowl B: vertical axis, meridian of two arcs
    e("bB_x", 169.2, "bowl B axis")
    e("bB_y", 56.2, "bowl B axis from the hook-side datum")
    e("bowl_t", 1.8, "bowl shell thickness")
    e("rim_z", 0.3, "bowl rim above the flange plane")
    t, zr = M["bowl_t"], M["rim_z"]
    _fa, axB_d = nxf.datum_axis(p, "point_dir", ("bB_x", "-bB_y", 0), Z, "AXIS_BOWL_B")
    _fp, plB = nxh.datum_plane(p, ("bB_x", "-bB_y", 0), Y, "PLANE_BOWL_B")
    oB = nxh.point(p, "bB_x", "-bB_y", 0)
    axB = nxh.axis(p, ("bB_x", "-bB_y", 0), Z)
    C1, R1, C2, R2 = (4.70, -1.05), 12.57, (2.98, 2.105), 15.99
    J = geo.circ_circ(C1, R1, C2, R2, (12.9, -10.4))
    Jo = geo.circ_circ(C1, R1 + t, C2, R2 + t, (14.2, -11.6))
    r_it = geo.circ_at_v(C1, R1, zr, +1)
    r_ot = geo.circ_at_v(C1, R1 + t, zr, +1)
    z_c = C2[1] - R2                                   # floor of the bowl at the arc centre radius
    r_bo = geo.circ_at_v(C2, R2 + t, zb, +1)
    shB = (M["bB_x"], -M["bB_y"], 0.0)

    def sk_b(name):
        return ps.Sketch(p, dat, "xz", name, on=plB, origin=oB, vax=axB_d, shift=shB)

    S = sk_b("SK_BOWL_B_SHELL")
    shell = [(r_it, zr, None, "rim_z"), J, (C2[0], z_c), (0.0, z_c), (0.0, zb, None, "end_bot"), (r_bo, zb), Jo, (r_ot, zr)]
    S.profile(shell, {0: C1 + ("12.57",), 1: C2 + ("15.99",), 5: C2 + ("15.99+bowl_t",), 6: C1 + ("12.57+bowl_t",)})
    c.done(S)
    f = nxf.revolve(p, S.section(), axB, -90, 90, BOOL.Unite, eb)
    f.SetName("BOWL_B_SHELL")
    c.say("bowl B shell done")

    # ---- hook-side corner behind bowl A: a curved skin whose straight generators run at an angle to X in plan
    # (measured 17.5 deg); built as block - tray - underside tool + skin, then faced on the hook-side datum
    e("hf_R", 29.57, "curved hook-side floor: radius of the underside")
    e("hf_t", 1.8, "curved hook-side floor: thickness")
    e("hf_cy", 19.85, "curved hook-side floor: arc centre from the hook-side datum at x = rail_x1")
    e("hf_skew", 0.3154, "curved hook-side floor: dy/dx of its generators in plan", None)
    e("hk_wall_t", 1.75, "hook-side wall thickness at the end block")
    k = M["hf_skew"]
    nk = math.hypot(1.0, k)
    dsk = (1.0 / nk, -k / nk, 0.0)
    Lsk = (xe - M["rail_x1"]) * nk
    fc = (-M["hf_cy"], zb + M["hf_R"])
    Rf, Rfi = M["hf_R"], M["hf_R"] - M["hf_t"]
    _fpl, plh = nxh.datum_plane(p, ("rail_x1", 0, 0), X, "PLANE_HOOK_FLOOR")
    oh = nxh.point(p, "rail_x1", 0, 0)

    def sk_h(name):
        return ps.Sketch(p, dat, "yz", name, on=plh, origin=oh, shift=(M["rail_x1"], 0.0, 0.0))

    S = c.sketch("yz", "SK_HOOK_BLOCK")
    S.profile([(-M["eb_y1"] - 0.2, zb, None, "end_bot"), (0.0, zb), (0.0, M["rim_z"], None, "rim_z"), (-M["eb_y1"] - 0.2, M["rim_z"])])
    c.done(S)
    c.extrude(S, X, "rail_x1", "end_x", "HOOK_BLOCK", BOOL.Unite, eb)
    S = c.sketch("xy", "SK_TRAY")
    S.profile([(176.2, -M["eb_y1"]), (190.3, -M["eb_y1"]), (190.3, -M["hk_wall_t"], None, "hk_wall_t"), (176.2, -M["hk_wall_t"])])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, Z, -20.0, 1.0, "TRAY", BOOL.Subtract, eb)
    c.chk.true("TRAY cut", c.vol(eb) < v0 - 500, v0 - c.vol(eb))
    S = sk_h("SK_HOOK_UNDERSIDE")
    S.profile([(fc[0], zb, "hf_cy", "end_bot"), (geo.circ_at_v(fc, Rf, 0.6, +1), 0.6), (10.5, 0.6), (10.5, -20.0), (fc[0], -20.0)], {0: fc + ("hf_R",)})
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, dsk, 0.0, Lsk + 1.0, "HOOK_UNDERSIDE", BOOL.Subtract, eb)
    c.chk.true("HOOK_UNDERSIDE cut", c.vol(eb) < v0 - 500, v0 - c.vol(eb))
    S = sk_h("SK_HOOK_SKIN")
    S.profile([(fc[0], zb, "hf_cy", "end_bot"), (geo.circ_at_v(fc, Rf, M["rim_z"], +1), M["rim_z"], None, "rim_z"),
               (geo.circ_at_v(fc, Rfi, M["rim_z"], +1), M["rim_z"]), (fc[0], fc[1] - Rfi)], {0: fc + ("hf_R",), 2: fc + ("hf_R-hf_t",)})
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, dsk, 0.0, Lsk, "HOOK_SKIN", BOOL.Unite, eb)
    c.chk.true("HOOK_SKIN added", c.vol(eb) > v0 + 200, c.vol(eb) - v0)
    S = c.sketch("yz", "SK_HOOK_FACE")
    S.profile([(0.0, -20.0), (11.0, -20.0), (11.0, 2.0), (0.0, 2.0)])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, X, "rail_x1", "end_x+1", "HOOK_FACE", BOOL.Subtract, eb)
    c.say("HOOK_FACE removed %.1f" % (v0 - c.vol(eb)))

    # ---- bowl A: plan sections are circles whose centre drifts with the depth (oblique cone with a rounded
    #      floor); on the hook side the wall leaves the circle along its tangent to the corner at x = hw_x
    e("hw_x", 158.3, "hook-side wall of bowl A starts here")
    hwx = M["hw_x"]
    LEV = [  # z, centre x, centre y, radius, y of the hook-side wall at hw_x
        (zr, 172.14, -20.75, 13.84, -3.5), (-4.0, 170.82, -20.75, 12.52, -4.3), (-8.0, 169.75, -20.90, 11.10, -5.3),
        (-11.0, 169.18, -20.90, 9.37, -7.5), (-13.0, 169.27, -20.90, 6.28, -9.0), (-13.6, 169.30, -20.90, 3.60, -9.4)]

    e("hk_x", 163.6, "centre of the hook-side arc of bowl A")
    e("hk_dr", 2.2, "hook-side arc radius minus the bowl radius of the same level")
    xh = M["hk_x"]
    outer_secs, void_secs, sk_top, sk_bot = [], [], None, None
    for k, (z, cx, cyA, r, yw) in enumerate(LEV):
        _f, pl = nxh.datum_plane(p, (0, 0, z), Z, "PLANE_BOWL_A_%d" % k)
        S = ps.Sketch(p, dat, "xy", "SK_BOWL_A_%d" % k, on=pl, origin=nxh.point(p, 0, 0, z), shift=(0.0, 0.0, z))
        rh = r + M["hk_dr"]
        ch = (xh, yw - rh)                                   # hook-side circle, tangent to the wall line y = yw
        # outer skin (index 0): wall line, hook-side arc, two bowl arcs, two closing lines
        R, RH = r + t, rh + t
        I2 = geo.circ_circ(ch, RH, (cx, cyA), R, (cx + 0.3 * R, cyA + R))
        S.profile([(hwx, yw + t), (xh, yw + t), I2, (cx + R, cyA), (cx, cyA - R), (hwx, cyA - R)],
                  {1: ch + (None,), 2: (cx, cyA, None), 3: (cx, cyA, None)})
        # void (index 1)
        I1 = geo.circ_circ(ch, rh, (cx, cyA), r, (cx + 0.3 * r, cyA + r))
        S.profile([(hwx, yw), (xh, yw), I1, (cx + r, cyA), (cx, cyA - r), (cx, cyA - R - 1.0), (hwx - 1.0, cyA - R - 1.0), (hwx - 1.0, yw)],
                  {1: ch + (None,), 2: (cx, cyA, None), 3: (cx, cyA, None)})
        c.done(S)
        outer_secs.append(S.section(0, (hwx, yw + t)))
        void_secs.append(S.section(1, (hwx, yw)))
        if k == 0:
            sk_top = S
        sk_bot = S
    f = nxf.through_curves(p, outer_secs, solid=True, preserve=True)
    f.SetName("BOWL_A_SKIN")
    skin = f.GetBodies()[0]
    c.say("bowl A skin loft: volume %.1f, faces %d" % (c.vol(skin), len(skin.GetFaces())))
    nxh.unite(p, eb, [skin]).SetName("UNITE_BOWL_A")
    v0 = c.vol(eb)
    c.extrude(sk_bot, Z, zb - LEV[-1][0], 0, "BOWL_A_FLOOR", BOOL.Unite, eb, loop=0)
    c.say("bowl A floor added %.1f" % (c.vol(eb) - v0))

    # ---- hook side: thick wall in front of bowl A (outer face = the snap-tab arc), curved floor up to the end
    hw = [(0.0, -2.0), (-4.6, -12.8), (-8.5, zb + 0.2), (-11.0, zb + 0.2), (-11.0, -6.0), (-4.0, -6.0), (-3.0, -2.0)]
    S = c.sketch("yz", "SK_HOOK_WALL")
    S.profile(hw)
    c.done(S)
    c.extrude(S, X, "hw_x", "rail_x1", "HOOK_WALL", BOOL.Unite, eb)
    c.say("hook wall and floor added")

    # ---- fins between the bottom plate and the deck
    S = c.sketch("yz", "SK_FINS")
    for yc in (-69.2, -56.0, -45.3, -31.8, -21.2):
        S.profile([(yc - 0.5, zb + M["plate_t"] - 0.4), (yc + 0.5, zb + M["plate_t"] - 0.4), (yc + 0.5, -M["deck_und"] + 0.4),
                   (yc - 0.5, -M["deck_und"] + 0.4)])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, X, "cell_x0", "end_x", "FINS", BOOL.Unite, eb)
    c.chk.true("FINS added", c.vol(eb) > v0 + 300, c.vol(eb) - v0)

    # ---- bowl voids
    S = sk_b("SK_BOWL_B_VOID")
    void = [(0.0, z_c), (C2[0], z_c), J, (r_it, zr, None, "rim_z"), (r_it, 12.0), (0.0, 12.0)]
    S.profile(void, {1: C2 + ("15.99",), 2: C1 + ("12.57",)})
    c.done(S)
    v0 = c.vol(eb)
    nxf.revolve(p, S.section(), axB, -100, 100, BOOL.Subtract, eb).SetName("BOWL_B_VOID")
    c.chk.true("BOWL_B_VOID cut", c.vol(eb) < v0 - 1000, v0 - c.vol(eb))
    f = nxf.through_curves(p, void_secs, solid=True, preserve=True)
    f.SetName("BOWL_A_VOID_TOOL")
    tool = f.GetBodies()[0]
    c.say("bowl A void loft: volume %.1f" % c.vol(tool))
    v0 = c.vol(eb)
    nxh.subtract(p, eb, [tool]).SetName("BOWL_A_VOID")
    c.chk.true("BOWL_A_VOID cut", c.vol(eb) < v0 - 1000, v0 - c.vol(eb))
    v0 = c.vol(eb)
    c.extrude(sk_top, Z, 0, 12.0, "BOWL_A_VOID_TOP", BOOL.Subtract, eb, loop=1)
    c.say("BOWL_A_VOID_TOP removed %.1f" % (v0 - c.vol(eb)))
    c.say("bowl voids done")

    # ---- deck: two cones (one per bowl), a cap plane over the ridge, the end step
    def cone_cut(name, ax_xy, k, z0, rmax):
        r_rim = (zr - z0) / k
        _f, pl = nxh.datum_plane(p, (ax_xy[0], ax_xy[1], 0), Y, "PLANE_" + name)
        _f2, dax = nxf.datum_axis(p, "point_dir", (ax_xy[0], ax_xy[1], 0), Z, "AXIS_" + name)
        S = ps.Sketch(p, dat, "xz", "SK_" + name, on=pl, origin=nxh.point(p, ax_xy[0], ax_xy[1], 0), vax=dax, shift=(ax_xy[0], ax_xy[1], 0.0))
        S.profile([(0.0, zr), (r_rim, zr), (rmax, z0 + k * rmax), (rmax, 12.0), (0.0, 12.0)])
        c.done(S)
        v0 = c.vol(eb)
        nxf.revolve(p, S.section(), nxh.axis(p, (ax_xy[0], ax_xy[1], 0), Z), 0, 360, BOOL.Subtract, eb).SetName(name)
        c.chk.true(name + " cut", c.vol(eb) < v0 - 50, v0 - c.vol(eb))

    cone_cut("DECK_CONE_B", (168.51, -56.41), 0.3601, -6.0705, 31.0)
    cone_cut("DECK_CONE_A", (173.51, -20.85), 0.3338, -3.7761, 27.0)
    S = c.sketch("xz", "SK_DECK_CAP")
    S.profile([(170.0, 1.936 + 0.1087 * (170.0 - 180.0)), (190.0, 1.936 + 0.1087 * 10.0), (190.0, 12.0), (170.0, 12.0)])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, Y, "-eb_y0-1", "-eb_y1+1", "DECK_CAP", BOOL.Subtract, eb)
    c.chk.true("DECK_CAP cut", c.vol(eb) < v0 - 10, v0 - c.vol(eb))
    e("step_x", 189.5, "end strip of the deck starts here")
    e("strip_z", 0.21, "end strip above the flange plane")
    S = c.sketch("xz", "SK_DECK_STEP")
    S.profile([(M["step_x"], M["strip_z"], "step_x", "strip_z"), (xe + 1.0, M["strip_z"]), (xe + 1.0, 12.0), (M["step_x"], 12.0)])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, Y, "-eb_y0-1", "-eb_y1+1", "DECK_STEP", BOOL.Subtract, eb)
    c.chk.true("DECK_STEP cut", c.vol(eb) < v0 - 10, v0 - c.vol(eb))

    # ---- flat deck on the hook side of bowl A
    e("flat_z", 0.345, "flat deck beside bowl A above the flange plane")
    S = c.sketch("yz", "SK_FLAT_DECK")
    S.profile([(-20.7, M["flat_z"], None, "flat_z"), (-M["eb_y1"] + 0.2, M["flat_z"]), (-M["eb_y1"] + 0.2, 12.0), (-20.7, 12.0)])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, X, 150.0, "end_x+1", "FLAT_DECK", BOOL.Subtract, eb)
    c.say("FLAT_DECK removed %.1f" % (v0 - c.vol(eb)))
    # ---- end catch outside the hook-side wall, with its slot
    S = c.sketch("yz", "SK_CATCH")
    S.profile([(-0.5, -2.05), (3.0, -2.05), (3.0, 0.53), (-0.5, 0.53)])
    c.done(S)
    c.extrude(S, X, 163.0, 175.5, "CATCH", BOOL.Unite, eb)
    S = c.sketch("xy", "SK_CATCH_SLOT")
    S.profile([(164.6, 0.6), (173.9, 0.6), (173.9, 1.7), (164.6, 1.7)])
    c.done(S)
    c.extrude(S, Z, 0.0, 1.0, "CATCH_SLOT", BOOL.Subtract, eb)
    # ---- flange end with its corner
    e("fl_corner_r", 6.5, "corner radius of the flange at the bowl end")
    rc = M["fl_corner_r"]
    fe = [(M["bw_x1"] - 0.5, -M["fl_y"]), (xe - rc, -M["fl_y"], None, "fl_y"), (xe, -M["fl_y"] + rc, "end_x", None), (xe, cy - M["ch_R"] + 0.5),
          (M["bw_x1"] - 0.5, cy - M["ch_R"] + 0.5)]
    S = c.sketch("xy", "SK_FLANGE_END")
    S.profile(fe, {1: (xe - rc, -M["fl_y"] + rc, "fl_corner_r")})
    c.done(S)
    c.extrude(S, Z, "-fl_t", 0, "FLANGE_END", BOOL.Unite, eb)

    # ---- the rail flange runs on to the end: nothing above the flange plane outside the channel edge
    S = c.sketch("yz", "SK_FLANGE_LEVEL")
    S.profile([(-M["fl_y"] - 1.0, 0.0), (cy - M["ch_R"], 0.0), (cy - M["ch_R"], 12.0), (-M["fl_y"] - 1.0, 12.0)])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, X, 150.0, "end_x+1", "FLANGE_LEVEL", BOOL.Subtract, eb)
    c.say("FLANGE_LEVEL removed %.1f" % (v0 - c.vol(eb)))
    # ---- trims: in front of the inclined front plane (between the bowls), below the bottom plate
    S = c.sketch("xz", "SK_FRONT_TRIM")
    S.profile([(xf(zb - 1.0), zb - 1.0), (xf(5.0), 5.0), (150.0, 5.0), (150.0, zb - 1.0)])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, Y, -66.5, -33.0, "FRONT_TRIM", BOOL.Subtract, eb)
    c.chk.true("FRONT_TRIM cut", c.vol(eb) < v0 - 10, v0 - c.vol(eb))
    # ---- front edge of the floor under bowl A (diagonal in plan)
    S = c.sketch("xy", "SK_FRONT_TRIM_A")
    S.profile([(150.0, -34.0), (xf(zb), -34.0), (xf(zb), -27.0), (165.0, -10.0), (150.0, -10.0)])
    c.done(S)
    v0 = c.vol(eb)
    c.extrude(S, Z, zb - 1.0, -12.4, "FRONT_TRIM_A", BOOL.Subtract, eb)
    c.say("FRONT_TRIM_A removed %.1f" % (v0 - c.vol(eb)))

    # ---- lip under the front edge of the end block (the rail foot turns the corner)
    e("lip_w", 1.6, "width of the front lip"); e("lip_y1", 28.0, "front lip ends beside bowl A")
    S = c.sketch("xz", "SK_FRONT_LIP")
    S.profile([(xf(zb), zb + 0.4), (xf(zb) + M["lip_w"], zb + 0.4), (xf(zb) + M["lip_w"], -M["foot_z"], None, "foot_z"), (xf(zb), -M["foot_z"])])
    c.done(S)
    c.extrude(S, Y, "-lip_y", "-lip_y1", "FRONT_LIP", BOOL.Unite, eb)

    c.end = eb
    nxh.unite(p, c.body, [eb]).SetName("UNITE_END")
    c.chk("solids after the bowl end", len(nxh.solids(p)), 1, 0)
    c.say("stage C: body %.1f mm3" % c.vol(c.body))
