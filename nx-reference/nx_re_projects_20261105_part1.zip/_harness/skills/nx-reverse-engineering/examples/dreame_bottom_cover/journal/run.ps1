param([string]$Stage = "z", [int]$Timeout = 1500)
# Build the part headless and print the verdict of the journal's own JSON.
$ws = "C:\NX_MCP_WORKSPACE\dreame_cover"
$out = "$ws\out"
New-Item -ItemType Directory -Force $out | Out-Null
Remove-Item "$out\build.json" -ErrorAction SilentlyContinue
$r = & "C:\Users\marya\.claude\skills\nx-journal-core\scripts\run_journal.ps1" -Script "$ws\build.py" -WorkDir $out -JArgs $out, $Stage -TimeoutSec $Timeout
$r | Select-Object -Last 12
if (Test-Path "$out\build.json") {
    $j = Get-Content "$out\build.json" -Raw | ConvertFrom-Json
    "RESULT: " + $j.result + "   stage: " + $j.stage
    if ($j.error) { $j.error }
    $j.log
    $bad = @($j.checks | Where-Object { -not $_.ok })
    "checks: " + @($j.checks).Count + "  failed: " + $bad.Count
    $bad | ForEach-Object { "  FAIL " + ($_ | ConvertTo-Json -Compress) }
    $j.sketches.PSObject.Properties | Where-Object { $_.Value.status -ne "WellConstrained" -or $_.Value.dof -ne 0 } | ForEach-Object { "  SKETCH " + $_.Name + " " + ($_.Value | ConvertTo-Json -Compress) }
    $j.solids | ForEach-Object { "  solid " + ($_ | ConvertTo-Json -Compress) }
} else { "no build.json" }
