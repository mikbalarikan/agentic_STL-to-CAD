"""Probe: profile-sketch helper (lines + arcs, DOF 0), rail extrude, STL export."""
import os, sys, traceback, time
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, r"C:\NX_MCP_WORKSPACE\dreame_cover\nxlib")
import NXOpen
import nxh, nxf, nxre
import ps

OUT = sys.argv[1]
res = {"result": "FAIL", "log": []}
t0 = time.time()
try:
    part = nxh.new_part(os.path.join(OUT, "probe1.prt"))
    dat = nxh.Datums(part)
    for n, v in (("fl_y", 83.7), ("fl_t", 1.9), ("ch_R", 18.1), ("ch_cy", 55.75), ("ch_t", 2.05), ("lip_y", 67.3),
                 ("foot_z", 16.25), ("foot_y", 69.45), ("step_z", 15.0), ("step_y", 71.15), ("rail_x0", 21.0), ("rail_x1", 170.0)):
        nxh.expr(part, n, v, "mm")
    import math
    cy, R, t = -55.75, 18.1, 2.05
    z_lip = -math.sqrt(R * R - (67.3 - 55.75) ** 2)
    z_bk = -math.sqrt((R + t) ** 2 - (71.15 - 55.75) ** 2)
    y_bk = cy - math.sqrt((R + t) ** 2 - 1.9 ** 2)
    S = ps.Sketch(part, dat, "yz", "SK_RAIL")
    F = ps.FREE
    cs = S.profile([
        (-83.7, 0.0, "fl_y", None),          # 0 flange top outer
        (cy - R, 0.0, F, None),              # 1 flange top inner = arc top (u follows the arc)
        (-67.3, z_lip, "lip_y", F),          # 2 lip top (v follows the arc)
        (-67.3, -16.25, None, "foot_z"),     # 3
        (-69.45, -16.25, "foot_y", None),    # 4
        (-69.45, -15.0, None, "step_z"),     # 5
        (-71.15, -15.0, "step_y", None),     # 6
        (-71.15, z_bk, None, F),             # 7 back arc bottom
        (y_bk, -1.9, F, "fl_t"),             # 8 back arc top on the flange underside
        (-83.7, -1.9, None, None),           # 9
    ], arcs={1: (cy, 0.0, "ch_R"), 7: (cy, 0.0, "ch_R+ch_t")})
    S.centre_on(cs[1], "h")
    S.centre_dim(cs[1], "u", "ch_cy")
    S.same_centre(cs[7], cs[1])
    st = S.finish(strict=False)
    res["sketch"] = st
    res["log"].append("sketch %s" % st)
    f = nxh.extrude(part, S.section(), (1, 0, 0), "rail_x0", "rail_x1")
    body = nxh.solids(part)[0]
    vol = nxh.volume(part, body)
    res["volume"] = vol
    res["bbox"] = nxh.bbox(body)
    # regeneration: channel radius 18.1 -> 19, back
    nxh.set_expr(part, "ch_R", 19.0); nxh.update()
    res["volume_R19"] = nxh.volume(part, body)
    nxh.set_expr(part, "ch_R", 18.1); nxh.update()
    res["volume_back"] = nxh.volume(part, body)
    res["errors"] = nxh.feature_errors(part)
    res["stl"] = nxre.stl_export(part, body, os.path.join(OUT, "probe1.stl"), chord=0.01)
    nxh.save(part)
    res["sketch_api"] = [n for n in dir(S.sk) if n.startswith("Create")]
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
res["seconds"] = round(time.time() - t0, 1)
nxh.write_json(os.path.join(OUT, "probe1.json"), res)
