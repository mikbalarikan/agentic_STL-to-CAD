"""Review part: a copy of the rebuilt part with the scan (decimated, in the CAD datum frame) as a reference body."""
import os, sys, shutil, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
import NXOpen
import nxh, nxre

OUT = sys.argv[1]
res = {"result": "FAIL"}
try:
    src = os.path.join(OUT, "dreame_mop_bottom_cover.prt")
    dst = os.path.join(OUT, "dreame_mop_bottom_cover_with_scan.prt")
    if os.path.exists(dst):
        os.remove(dst)
    shutil.copyfile(src, dst)
    part = nxh.open_part(dst)
    n_solid0 = len(nxh.solids(part))
    bodies = nxre.stl_import(part, os.path.join(OUT, "scan_datum_frame_137k.stl"))
    res["scan_bodies"] = len(bodies)
    res["scan_facets"] = []
    for i, b in enumerate(bodies):
        b.SetName("SCAN_REFERENCE_%d" % (i + 1))
        try:
            res["scan_facets"].append(b.GetNumberOfFacets())
        except Exception:  # noqa: BLE001
            res["scan_facets"].append(None)
    part.Layers.MoveDisplayableObjects(10, bodies)
    res["scan_bbox"] = [[round(v, 2) for v in nxh.bbox(b)] for b in bodies if (b.GetNumberOfFacets() if b.IsConvergentBody else 0) > 1000]
    res["cad_solids"] = n_solid0
    res["errors"] = nxh.feature_errors(part)
    nxh.save(part)
    res["size_mb"] = round(os.path.getsize(dst) / 1e6, 1)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "review.json"), res)
