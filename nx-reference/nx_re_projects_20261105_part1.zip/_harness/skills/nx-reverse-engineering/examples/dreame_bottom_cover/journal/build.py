"""Dreame mop-module bottom cover: parametric rebuild on the scan datum frame (NX 2206 journal, headless).

run_journal build.py -args <out dir> [last stage]

Datum CSYS = datum frame of the scan (intake/alignment.json):
    XY plane  = top flange face (z = 0), material below (-Z); the latch tongues stand up in +Z
    XZ plane  = outer face of the hook-side wall (y = 0), the part lies in -Y
    YZ plane  = outer face of the grille end (x = 0), the part lies in +X
Master expressions hold positive magnitudes (distances from those planes).
"""
import os, sys, math, time, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
sys.path.insert(0, os.environ["NXRE_DIR"])
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])) if False else r"C:\NX_MCP_WORKSPACE\dreame_cover", "nxlib"))
import NXOpen
import nxh, nxf, nxre
import ps, geo

BOOL = nxh.BOOL
F = ps.FREE
OUT = sys.argv[1]
LAST = sys.argv[2] if len(sys.argv) > 2 else "z"
NAME = "dreame_mop_bottom_cover"


class Ctx:
    def __init__(self, part):
        self.part, self.dat = part, nxh.Datums(part)
        self.M, self.chk, self.log, self.sk = {}, nxh.Check(), [], {}
        self.t0 = time.time()

    def e(self, name, value, comment="", unit="mm"):
        nxh.expr(self.part, name, value, unit, comment)
        self.M[name] = float(value)
        return float(value)

    def say(self, msg):
        self.log.append("%6.1fs  %s" % (time.time() - self.t0, msg))

    def sketch(self, plane, name):
        return ps.Sketch(self.part, self.dat, plane, name)

    def done(self, S):
        st = S.finish()
        self.sk[S.name] = {"status": st["status"], "dof": st["dof"], "auto_dims": st["auto_dims"], "dims": len(st["dims"])}
        return S

    def extrude(self, S, vec, start, end, name, op=None, target=None, loop=None, hp=None):
        f = nxh.extrude(self.part, S.section(loop, hp), vec, start, end, op=op, target=target)
        f.SetName(name)
        return f

    def vol(self, body):
        return nxh.volume(self.part, body)


X, Y, Z = (1, 0, 0), (0, 1, 0), (0, 0, 1)


# =========================================================================================== stage A
def stage_a(c):
    """Rail (flange + channel wall + foot), hook-side beam with bead, four snap tabs."""
    p, e, M = c.part, c.e, c.M
    # ---- RAIL
    e("fl_y", 83.7, "flange outer edge from the hook-side datum")
    e("fl_t", 1.9, "flange thickness")
    e("ch_R", 18.1, "channel wall, radius of the concave face (centre on the flange plane)")
    e("ch_cy", 55.75, "channel arc centre from the hook-side datum")
    e("ch_t", 2.05, "channel wall thickness")
    e("lip_y", 67.3, "inner lip face of the rail foot")
    e("foot_z", 16.25, "underside of the rail foot")
    e("foot_y", 69.45, "outer face of the rail foot")
    e("step_z", 14.95, "underside of the step behind the foot (= underside of the ledge)")
    e("step_y", 71.15, "back face of the step")
    e("rail_x0", 20.9, "rail profile starts at the grille-end block")
    e("rail_x1", 170.8, "rail profile ends at the front of the end block")
    cy, R, t = -M["ch_cy"], M["ch_R"], M["ch_t"]
    z_lip = geo.circ_at_u((cy, 0), R, -M["lip_y"], -1)
    z_bk = geo.circ_at_u((cy, 0), R + t, -M["step_y"], -1)
    y_bk = geo.circ_at_v((cy, 0), R + t, -M["fl_t"], -1)
    rail = [(-M["fl_y"], 0.0, "fl_y", None), (cy - R, 0.0, F, None), (-M["lip_y"], z_lip, "lip_y", F),
            (-M["lip_y"], -M["foot_z"], None, "foot_z"), (-M["foot_y"], -M["foot_z"], "foot_y", None),
            (-M["foot_y"], -M["step_z"], None, "step_z"), (-M["step_y"], -M["step_z"], "step_y", None),
            (-M["step_y"], z_bk, None, F), (y_bk, -M["fl_t"], F, "fl_t"), (-M["fl_y"], -M["fl_t"], None, None)]
    arcs = {1: (cy, 0.0, "ch_R"), 7: (cy, 0.0, "ch_R+ch_t")}
    S = c.sketch("yz", "SK_RAIL")
    cs = S.profile(rail, arcs)
    S.centre_on(cs[1], "h")
    S.centre_dim(cs[1], "u", "ch_cy")
    S.same_centre(cs[7], cs[1])
    c.done(S)
    f = c.extrude(S, X, "rail_x0", "rail_x1", "RAIL")
    c.rail = f.GetBodies()[0]
    c.chk("RAIL volume", c.vol(c.rail), geo.area(rail, arcs) * (M["rail_x1"] - M["rail_x0"]), 0.05)
    c.rail_profile = (rail, arcs)

    # ---- BEAM (hook side)
    e("bm_x0", 19.3, "beam starts inside the grille-end block")
    e("bm_x1", 176.0, "beam ends beside bowl A")
    e("bm_h", 6.45, "beam depth below the flange plane")
    e("bm_top", 0.375, "inner land of the beam top above the flange plane")
    e("tab_Ro", 15.0, "snap tab: radius of the outer face, tangent to the hook-side datum face")
    e("tab_cz", 3.0, "snap tab: depth of the outer arc centre")
    y2 = geo.circ_at_v((-M["tab_Ro"], -M["tab_cz"]), M["tab_Ro"], -M["bm_h"], +1)
    beam = [(0.0, 0.0), (0.0, -M["tab_cz"], None, "tab_cz"), (y2, -M["bm_h"], None, "bm_h"), (-4.67, -M["bm_h"]),
            (-3.60, -2.60), (-3.46, M["bm_top"], None, "bm_top"), (-1.25, M["bm_top"]), (-0.85, 0.0)]
    S = c.sketch("yz", "SK_BEAM")
    S.profile(beam)
    c.done(S)
    f = c.extrude(S, X, "bm_x0", "bm_x1", "BEAM")
    c.beam = f.GetBodies()[0]
    c.chk("BEAM volume", c.vol(c.beam), geo.area(beam) * (M["bm_x1"] - M["bm_x0"]), 0.05)

    # ---- BEAD on the beam top
    e("bead_x0", 40.9, "bead start")
    e("bead_x1", 155.5, "bead end")
    e("bead_r", 0.6, "bead crest radius")
    bc = (-1.645, 0.6)
    bead = [(-2.45, M["bm_top"]), (bc[0] - 0.6 * math.cos(math.radians(28.6)), bc[1] + 0.6 * math.sin(math.radians(28.6))),
            (bc[0] + 0.6 * math.cos(math.radians(18.5)), bc[1] + 0.6 * math.sin(math.radians(18.5))), (-1.23, 0.0), (-1.23, -0.3), (-2.45, -0.3)]
    S = c.sketch("yz", "SK_BEAD")
    S.profile(bead, {1: (bc[0], bc[1], "bead_r")})
    c.done(S)
    v0 = c.vol(c.beam)
    c.extrude(S, X, "bead_x0", "bead_x1", "BEAD", BOOL.Unite, c.beam)
    c.chk.true("BEAD adds material", c.vol(c.beam) > v0 + 20, c.vol(c.beam) - v0)

    # ---- SNAP TAB (one body with its window, then copies)
    e("tab_xc", 49.3, "centre of the first snap tab")
    e("tab_w", 7.8, "snap tab width")
    e("tab_pitch", 28.2, "snap tab pitch")
    c.e("tab_n", 4, "number of snap tabs", None)
    e("tab_win_w", 3.8, "window in the snap tab")
    oc, Ro = (-M["tab_Ro"], -M["tab_cz"]), M["tab_Ro"]
    t1 = geo.line_circ((-6.885, -14.229), -164.34, oc, Ro, (-4.3, -13.5))
    ic, ir = geo.circle3((-9.80, -13.70), (-7.0, -10.3), (-4.67, -M["bm_h"]))      # inner (hook) face of the cheeks
    tab = [(0.0, -M["tab_cz"], None, "tab_cz"), (t1[0], t1[1]), (-9.70, -14.85), (-9.80, -13.70), (-4.67, -M["bm_h"], None, "bm_h"),
           (-4.0, -4.5), (-0.5, -4.5)]
    S = c.sketch("yz", "SK_TAB")
    S.profile(tab, {0: (oc[0], oc[1], "tab_Ro"), 3: (ic[0], ic[1], None)})
    c.done(S)
    f = c.extrude(S, X, "tab_xc-tab_w/2", "tab_xc+tab_w/2", "TAB")
    tabf = f
    tabb = f.GetBodies()[0]
    wc = (-7.0, -9.5)
    win = [(-4.45, -M["bm_h"], None, "bm_h"), (-4.45, -9.5), (wc[0] + 2.55 * math.cos(math.radians(-71.7)), wc[1] + 2.55 * math.sin(math.radians(-71.7))),
           (-9.80, -13.70), (-10.5, -13.70), (-10.5, -M["bm_h"])]
    S = c.sketch("yz", "SK_TAB_WINDOW")
    S.profile(win, {1: (wc[0], wc[1], "2.55")})
    c.done(S)
    v0 = c.vol(tabb)
    c.extrude(S, X, "tab_xc-tab_win_w/2", "tab_xc+tab_win_w/2", "TAB_WINDOW", BOOL.Subtract, tabb)
    c.chk.true("TAB_WINDOW removes material", c.vol(tabb) < v0 - 5, v0 - c.vol(tabb))
    v_tab = c.vol(tabb)
    pf, copies = nxf.pattern_geometry(p, [tabb], linear=dict(xdir=X, nx="tab_n", px="tab_pitch"))
    pf.SetName("TAB_PATTERN")
    c.chk("tab bodies", len(copies) + 1, 4, 0)
    v0 = c.vol(c.beam)
    uf = nxh.unite(p, c.beam, tool_features=[tabf, pf])
    uf.SetName("UNITE_TABS")
    c.chk.true("tabs united", c.vol(c.beam) > v0 + 3 * v_tab * 0.5, c.vol(c.beam) - v0)
    c.say("stage A: rail %.1f mm3, beam+tabs %.1f mm3" % (c.vol(c.rail), c.vol(c.beam)))


# =========================================================================================== stage B
def void_chain(chain, arcs, top=1.5):
    """Closed 'void' profile: the surface chain (left to right) closed over the top at z = top."""
    verts = list(chain) + [(chain[-1][0], top), (chain[0][0], top)]
    return verts, dict(arcs)


def stage_b(c):
    """Grille end (x 0 .. ge_x): envelope block, stepped twin troughs, corner cell, tunnels, hump pockets."""
    p, e, M = c.part, c.e, c.M
    e("ge_x", 20.9, "length of the grille-end block")
    e("ge_bot", 14.95, "underside of the grille-end block")
    e("ge_hook_y", 0.25, "hook-side wall of the grille end stands out of the datum face")
    e("hump_z", 8.15, "top of the centre hump")
    hz, bot = -M["hump_z"], -M["ge_bot"]
    # ---- envelope
    c1, r1 = (-18.2, 6.95), 22.68                 # hook-side underside, upper arc
    c2, r2 = (-14.56, bot + 16.27), 16.27         # lower arc, tangent to the underside
    c3, r3 = (-65.57, -3.56), 14.83               # rail-side outer wall of the corner cell
    e2 = (M["ge_hook_y"], geo.circ_at_u(c1, r1, M["ge_hook_y"], -1))
    e3 = geo.circ_circ(c1, r1, c2, r2, (-11.2, -14.6))
    e5 = (geo.circ_at_v(c3, r3, bot, -1), bot)
    env = [(-M["fl_y"], 0.0, "fl_y", None), (M["ge_hook_y"], 0.0, "ge_hook_y", None), e2, e3, (c2[0], bot, None, "ge_bot"), e5,
           (c3[0] - r3, c3[1]), (c3[0] - r3, -M["fl_t"], None, "fl_t"), (-M["fl_y"], -M["fl_t"])]
    S = c.sketch("yz", "SK_GE_ENVELOPE")
    S.profile(env, {2: (c1[0], c1[1], None), 3: (c2[0], c2[1], None), 5: (c3[0], c3[1], None)})
    c.done(S)
    f = c.extrude(S, X, 0, "ge_x", "GE_BLOCK")
    ge = f.GetBodies()[0]
    c.chk("GE_BLOCK volume", c.vol(ge), geo.area(env, {2: c1 + (None,), 3: c2 + (None,), 5: c3 + (None,)}) * M["ge_x"], 0.2)
    # hook-side block on top of the envelope (x 10.2 .. 19.3) and its outer face on the datum
    e("ge_hx", 10.2, "start of the hook-side block of the grille end")
    e("hb_top", 0.67, "top of the hook-side block above the flange plane")
    S = c.sketch("yz", "SK_GE_HOOK_BLOCK")
    S.profile([(-6.6, -0.3), (0.0, -0.3), (0.0, M["hb_top"], None, "hb_top"), (-6.6, M["hb_top"])])
    c.done(S)
    c.extrude(S, X, "ge_hx", "bm_x0", "GE_HOOK_BLOCK", BOOL.Unite, ge)
    S = c.sketch("yz", "SK_GE_HOOK_FACE")
    S.profile([(0.0, -17.0), (0.6, -17.0), (0.6, 1.0), (0.0, 1.0)])
    c.done(S)
    v0 = c.vol(ge)
    c.extrude(S, X, "ge_hx", "ge_x+1", "GE_HOOK_FACE", BOOL.Subtract, ge)
    c.chk.true("GE_HOOK_FACE cut", c.vol(ge) < v0 - 5, v0 - c.vol(ge))

    # ---- underside: sunken pad under the deep trough floor (before the troughs are cut into it)
    e("pad_z", 16.6, "underside of the sunken pad")
    e("pad_x0", 6.9, "start of the sunken pad")
    pad = [(-67.0, bot + 0.3), (-67.0, bot), (-62.2, -M["pad_z"], None, "pad_z"), (-50.3, -M["pad_z"]), (-44.6, bot), (-44.6, bot + 0.3)]
    S = c.sketch("yz", "SK_GE_PAD")
    S.profile(pad)
    c.done(S)
    v0 = c.vol(ge)
    c.extrude(S, X, "pad_x0", "ge_x", "GE_PAD", BOOL.Unite, ge)
    c.chk.true("GE_PAD added", c.vol(ge) > v0 + 100, c.vol(ge) - v0)

    # ---- trough voids, rail side: four x-zones
    e("ge_x1", 1.0, "end wall thickness"); e("ge_x2", 3.8, "zone step 2"); e("ge_x3", 7.6, "zone step 3"); e("ge_x4", 13.4, "zone step 4")
    e("ge_f1", 13.65, "rail-side trough floor, zones 1-2"); e("ge_f3", 15.15, "rail-side trough floor, zone 3")
    e("ge_f4", 15.4, "rail-side trough floor, zone 4"); e("ge_fh", 13.7, "hook-side trough floor")
    ym = -38.0                                    # middle of the hump: rail-side and hook-side voids meet here

    def rail_zone(name, x0, x1, wall, a1, floor, a2, lead=None):
        """wall: ('L', point, angle) or ('A', centre, radius); a1 / a2: (centre, radius); floor: (z, formula)."""
        fz, ff = floor
        ch, arcs = [], {}
        if wall[0] == "L":
            p0 = geo.line_at_v(wall[1], wall[2], 0.0)
            j = geo.line_circ(wall[1], wall[2], a1[0], a1[1], lead)
            if lead is not None and isinstance(lead, tuple) and len(lead) == 3:
                pass
            ch += [(p0[0], 0.0), (j[0], j[1])]
        else:
            p0 = (wall[1][0] - wall[2], 0.0)
            j = geo.circ_circ(wall[1], wall[2], a1[0], a1[1], lead)
            ch += [(p0[0], 0.0), (j[0], j[1])]
            arcs[0] = (wall[1][0], wall[1][1], None)
        arcs[len(ch) - 1] = (a1[0][0], a1[0][1], None)
        ch.append((geo.circ_at_v(a1[0], a1[1], fz, -1), fz, None, ff))
        ch.append((geo.circ_at_v(a2[0], a2[1], fz, +1), fz))
        arcs[len(ch) - 1] = (a2[0][0], a2[0][1], None)
        ch.append((geo.circ_at_v(a2[0], a2[1], hz, +1), hz, None, "hump_z"))
        ch.append((ym, hz))
        verts, arcs = void_chain(ch, arcs)
        S = c.sketch("yz", "SK_" + name)
        S.profile(verts, arcs)
        c.done(S)
        v0 = c.vol(ge)
        c.extrude(S, X, x0, x1, name, BOOL.Subtract, ge)
        c.chk.true(name + " cut", c.vol(ge) < v0 - 50, v0 - c.vol(ge))

    # zone 1 has a chamfer at the flange edge: wall line through (-69.75, -3.957) at -63.88 deg, lead-in at -36.42 deg
    w1 = ((-69.75, -3.957), -63.88)
    a11, a12 = ((-55.933, -0.154), 14.109), ((-55.415, -0.354), 13.974)
    lead0 = geo.line_at_v((-71.95, -0.379), -36.42, 0.0)
    lead1 = geo.line_line((-71.95, -0.379), -36.42, w1[0], w1[1])
    j1 = geo.line_circ(w1[0], w1[1], a11[0], a11[1], (-68.2, -7.2))
    f1 = -M["ge_f1"]
    ch = [(lead0[0], 0.0), lead1, j1, (geo.circ_at_v(a11[0], a11[1], f1, -1), f1, None, "ge_f1"), (geo.circ_at_v(a12[0], a12[1], f1, +1), f1),
          (geo.circ_at_v(a12[0], a12[1], hz, +1), hz, None, "hump_z"), (ym, hz)]
    verts, arcs = void_chain(ch, {2: a11[0] + (None,), 4: a12[0] + (None,)})
    S = c.sketch("yz", "SK_GE_RAIL_Z1")
    S.profile(verts, arcs)
    c.done(S)
    v0 = c.vol(ge)
    c.extrude(S, X, "ge_x1", "ge_x2", "GE_RAIL_Z1", BOOL.Subtract, ge)
    c.chk.true("GE_RAIL_Z1 cut", c.vol(ge) < v0 - 50, v0 - c.vol(ge))
    rail_zone("GE_RAIL_Z2", "ge_x2", "ge_x3", ("L", (-70.75, -5.125), -62.94), ((-59.870, -4.458), 9.673), (-M["ge_f1"], "ge_f1"),
              ((-51.714, -3.660), 10.517), lead=(-68.8, -9.0))
    rail_zone("GE_RAIL_Z3", "ge_x3", "ge_x4", ("L", (-70.75, -5.125), -62.94), ((-56.111, -0.269), 15.315), (-M["ge_f3"], "ge_f3"),
              ((-54.923, -0.751), 14.770), lead=(-69.1, -8.3))
    rail_zone("GE_RAIL_Z4", "ge_x4", "ge_x+1", ("A", (-56.06, 0.0), 17.18), ((-60.439, -4.411), 11.002), (-M["ge_f4"], "ge_f4"),
              ((-50.964, -4.226), 11.210), lead=(-67.2, -13.1))

    # ---- trough voids, hook side: three x-zones
    fh = -M["ge_fh"]
    ha, hr = (-19.992, 8.308), 23.016                 # hook-side wall of the trough (zones 1-2)
    yin, ztop = -1.81, -M["fl_t"]                     # inner face and top of the thin hook-side wall
    wtop = (yin, geo.circ_at_u(ha, hr, yin, -1))
    # zone 1
    a1 = ((-20.784, 0.264), 14.765)
    zp = -13.05
    ch = [(ym, hz, None, "hump_z"), (geo.circ_at_v(a1[0], a1[1], hz, -1), hz), (geo.circ_at_v(a1[0], a1[1], fh, -1), fh, None, "ge_fh"),
          (-16.53, fh), (-14.65, zp), (geo.circ_at_v(ha, hr, zp, +1), zp), wtop, (yin, ztop, None, "fl_t"), (1.0, ztop)]
    verts, arcs = void_chain(ch, {1: a1[0] + (None,), 5: ha + (None,)})
    S = c.sketch("yz", "SK_GE_HOOK_Z1")
    S.profile(verts, arcs)
    c.done(S)
    v0 = c.vol(ge)
    c.extrude(S, X, "ge_x1", "ge_x2", "GE_HOOK_Z1", BOOL.Subtract, ge)
    c.chk.true("GE_HOOK_Z1 cut", c.vol(ge) < v0 - 50, v0 - c.vol(ge))
    # zone 2
    l2 = ((-31.9, -11.256), -44.81)
    ramp = ((-12.3, -13.165), 32.38)
    ch = [(ym, hz, None, "hump_z"), geo.line_at_v(l2[0], l2[1], hz), geo.line_at_v(l2[0], l2[1], fh) + (None, "ge_fh"),
          geo.line_at_v(ramp[0], ramp[1], fh), geo.line_circ(ramp[0], ramp[1], ha, hr, (-12.3, -13.2)), wtop, (yin, ztop, None, "fl_t"), (1.0, ztop)]
    verts, arcs = void_chain(ch, {4: ha + (None,)})
    S = c.sketch("yz", "SK_GE_HOOK_Z2")
    S.profile(verts, arcs)
    c.done(S)
    v0 = c.vol(ge)
    c.extrude(S, X, "ge_x2", "ge_hx", "GE_HOOK_Z2", BOOL.Subtract, ge)
    c.chk.true("GE_HOOK_Z2 cut", c.vol(ge) < v0 - 50, v0 - c.vol(ge))
    # zone 3 (beside the hook-side block)
    a3, b3 = ((-21.164, -0.231), 13.788), ((-22.366, 1.249), 15.840)
    up = ((-6.861, -2.748), 65.22)
    ch = [(ym, hz, None, "hump_z"), (geo.circ_at_v(a3[0], a3[1], hz, -1), hz), (geo.circ_at_v(a3[0], a3[1], fh, -1), fh, None, "ge_fh"),
          (geo.circ_at_v(b3[0], b3[1], fh, +1), fh), geo.line_circ(up[0], up[1], b3[0], b3[1], (-8.0, -5.2)),
          geo.line_at_v(up[0], up[1], M["hb_top"]) + (None, "hb_top")]
    verts, arcs = void_chain(ch, {1: a3[0] + (None,), 3: b3[0] + (None,)})
    S = c.sketch("yz", "SK_GE_HOOK_Z3")
    S.profile(verts, arcs)
    c.done(S)
    v0 = c.vol(ge)
    c.extrude(S, X, "ge_hx", "ge_x+1", "GE_HOOK_Z3", BOOL.Subtract, ge)
    c.chk.true("GE_HOOK_Z3 cut", c.vol(ge) < v0 - 50, v0 - c.vol(ge))

    # ---- end wall (x 0 .. ge_x1): lower top with the hump
    e("ge_wall_z", 10.4, "top of the end wall below the flange plane")
    wz = -M["ge_wall_z"]
    rs, hs, hk = ((-69.178, -5.064), -62.26), ((-44.629, -9.225), 49.46), ((-3.637, -7.916), 44.25)
    hump_r = geo.line_at_v(hs[0], hs[1], hz)
    hump_l = geo.line_at_v(hs[0], hs[1], wz)
    ch = [geo.line_at_v(rs[0], rs[1], 0.0), geo.line_at_v(rs[0], rs[1], wz) + (None, "ge_wall_z"), hump_l, hump_r + (None, "hump_z"),
          (-32.5, hz), (-32.5 + (hump_r[0] - hump_l[0]), wz), geo.line_at_v(hk[0], hk[1], wz), geo.line_at_u(hk[0], hk[1], yin),
          (yin, -3.8), (1.0, -3.8)]
    verts, arcs = void_chain(ch, {})
    S = c.sketch("yz", "SK_GE_END_WALL")
    S.profile(verts, arcs)
    c.done(S)
    v0 = c.vol(ge)
    c.extrude(S, X, -1, "ge_x1", "GE_END_WALL", BOOL.Subtract, ge)
    c.chk.true("GE_END_WALL cut", c.vol(ge) < v0 - 20, v0 - c.vol(ge))

    # ---- corner cell: open tube from the end face
    e("cell_x", 7.6, "depth of the corner cell from the end face")
    zr, zf = -3.33, -13.02
    ow, iw = ((-76.973, -8.540), -60.57), ((-70.599, -8.396), -59.49)
    cell = [geo.line_at_v(ow[0], ow[1], zr), geo.line_at_v(iw[0], iw[1], zr), geo.line_at_v(iw[0], iw[1], zf), geo.line_at_v(ow[0], ow[1], zf)]
    S = c.sketch("yz", "SK_GE_CORNER_CELL")
    S.profile(cell)
    c.done(S)
    v0 = c.vol(ge)
    c.extrude(S, X, -1, "cell_x", "GE_CORNER_CELL", BOOL.Subtract, ge)
    c.chk("GE_CORNER_CELL volume", v0 - c.vol(ge), geo.area(cell) * M["cell_x"], 0.5)

    # ---- underside: two tunnels
    e("tun_r", 1.3, "tunnel radius")
    tz, tr = -13.4, M["tun_r"]
    slope = -0.1365                                      # dy/dx of the tunnel axes (7.8 deg to X)
    S = c.sketch("yz", "SK_GE_TUNNELS")
    for yc in (-38.19 - slope * 2.0, -33.74 - slope * 2.0):     # axis positions at x = 0
        S.profile([(yc - tr, -17.5), (yc - tr, tz), (yc + tr, tz), (yc + tr, -17.5)], {1: (yc, tz, "tun_r")})
    c.done(S)
    n = math.hypot(1.0, slope)
    v0 = c.vol(ge)
    c.extrude(S, (1.0 / n, slope / n, 0.0), -1.5, 22.5, "GE_TUNNELS", BOOL.Subtract, ge)
    c.chk.true("GE_TUNNELS cut", c.vol(ge) < v0 - 50, v0 - c.vol(ge))

    # ---- hump pockets
    e("pocket_z", 10.0, "floor of the hump pockets")
    S = c.sketch("xy", "SK_GE_POCKETS")
    for x0, x1, y0, y1 in ((0.85, 2.80, -42.2, -34.1), (3.80, 6.85, -40.6, -36.1), (8.05, 11.10, -40.6, -36.1), (12.35, 15.10, -38.9, -34.3),
                           (16.45, 19.10, -38.9, -34.3)):
        S.profile([(x0, y0), (x1, y0), (x1, y1), (x0, y1)])
    c.done(S)
    v0 = c.vol(ge)
    c.extrude(S, Z, "-pocket_z", -7.0, "GE_POCKETS", BOOL.Subtract, ge)
    c.chk.true("GE_POCKETS cut", c.vol(ge) < v0 - 40, v0 - c.vol(ge))

    # ---- join the three main bodies
    c.body = ge
    nxh.unite(p, ge, [c.rail]).SetName("UNITE_RAIL")
    nxh.unite(p, ge, [c.beam]).SetName("UNITE_BEAM")
    c.chk("solids after the grille end", len(nxh.solids(p)), 1, 0)
    c.say("stage B: body %.1f mm3" % c.vol(ge))


import st_c
import st_d

STAGES = [("a", stage_a), ("b", stage_b), ("c", st_c.run), ("d", st_d.run)]


def export_stl(c, path):
    """All solid bodies of the part into one binary STL."""
    import struct
    tris = []
    for i, b in enumerate(nxh.solids(c.part)):
        tmp = path[:-4] + "_body%d.stl" % i          # the STL writer wants the .stl extension
        nxre.stl_export(c.part, b, tmp, chord=0.01)
        with open(tmp, "rb") as fh:
            fh.seek(80)
            n = struct.unpack("<I", fh.read(4))[0]
            tris.append((n, fh.read(n * 50)))
        os.remove(tmp)
    with open(path, "wb") as fh:
        fh.write(b"dreame_mop_bottom_cover NX rebuild".ljust(80, b" "))
        fh.write(struct.pack("<I", sum(n for n, _ in tris)))
        for _, d in tris:
            fh.write(d)
    return sum(n for n, _ in tris)


def census(c):
    part = c.part
    feats = list(part.Features.GetFeatures())
    types = {}
    for f in feats:
        types[f.FeatureType] = types.get(f.FeatureType, 0) + 1
    try:
        top = len(nxh.top_features(part))
    except Exception:  # noqa: BLE001
        top = None
    return {"features": len(feats), "top_level": top, "types": types, "sketches": len(c.sk),
            "sketches_fully_constrained": sum(1 for v in c.sk.values() if v["status"] == "WellConstrained" and v["dof"] == 0 and v["auto_dims"] == 0),
            "sketch_dimensions": sum(v["dims"] for v in c.sk.values()), "named_expressions": len(c.M)}


def regen_test(c):
    """Change one master at a time, update, measure, change back. Runs AFTER the part was saved and exported."""
    part, body = c.part, c.body
    v_nom = c.vol(body)
    rows = []
    for name, new in (("fl_t", 2.2), ("ch_t", 2.3), ("tab_pitch", 27.6), ("tab_w", 8.6), ("bowl_t", 2.1), ("rib_t", 1.8), ("rec_d", 0.8),
                      ("hump_z", 8.6), ("ge_f1", 13.2), ("plate_t", 2.2), ("rim_z", 0.5), ("web_pitch", 7.8), ("bB_y", 56.8), ("hf_t", 2.2)):
        old = c.M[name]
        row = {"master": name, "nominal": old, "test": new}
        try:
            nxh.set_expr(part, name, new)
            nxh.update()
            row["errors_changed"] = len(nxh.feature_errors(part))
            row["volume_changed"] = round(c.vol(body), 3)
            row["solids_changed"] = len(nxh.solids(part))
            if name == "tab_pitch":      # outer face of the last tab: x = tab_xc + 3 * pitch + tab_w / 2
                xs = [nxh.bbox(f)[3] for f in body.GetFaces() if nxh.bbox(f)[2] < -9.0 and nxh.bbox(f)[4] > -11.0 and nxh.bbox(f)[1] > -11.0
                      and 120.0 < nxh.bbox(f)[0] < 150.0]
                row["last_tab_xmax"] = round(max(xs), 3) if xs else None
                row["last_tab_xmax_expected"] = round(c.M["tab_xc"] + 3 * new + c.M["tab_w"] / 2, 3)
        except Exception as ex:  # noqa: BLE001
            row["exception"] = str(ex)[:200]
        try:
            nxh.set_expr(part, name, old)
            nxh.update()
            row["errors_back"] = len(nxh.feature_errors(part))
            row["volume_back"] = round(c.vol(body), 3)
        except Exception as ex:  # noqa: BLE001
            row["exception_back"] = str(ex)[:200]
        # a pattern pitch moves the copies without changing the volume: there the proof is the bounding box of the body
        moved = abs(row.get("volume_changed", v_nom) - v_nom) > 0.05 or name.endswith("_pitch")
        row["ok"] = ("exception" not in row and "exception_back" not in row and row.get("errors_changed") == 0 and row.get("errors_back") == 0
                     and moved and abs(row.get("volume_back", 0) - v_nom) < 1e-3 * v_nom and row.get("solids_changed") == 3)
        rows.append(row)
    return {"nominal_volume": round(v_nom, 3), "rows": rows, "passed": sum(1 for r in rows if r["ok"]), "of": len(rows)}


def main():
    res = {"result": "FAIL"}
    c = None
    try:
        part = nxh.new_part(os.path.join(OUT, NAME + ".prt"))
        c = Ctx(part)
        for key, fn in STAGES:
            if key > LAST:
                break
            fn(c)
            res["stage"] = key
        errs = nxh.feature_errors(part)
        c.chk.true("no feature errors", not errs, errs)
        final = LAST >= "z"
        if final:
            c.body.SetName("FRAME")
            for i, b in enumerate(getattr(c, "sliders", [])):
                b.SetName("LATCH_SLIDER_%d" % (i + 1))
            c.chk.true("frame passes Examine Geometry", nxh.body_ok(part, c.body), nxh.examine_geometry(part, c.body))
            for i, b in enumerate(getattr(c, "sliders", [])):
                c.chk.true("slider %d passes Examine Geometry" % (i + 1), nxh.body_ok(part, b))
        res["solids"] = [{"volume": round(c.vol(b), 3), "bbox": [round(v, 3) for v in nxh.bbox(b)], "faces": len(b.GetFaces())}
                         for b in nxh.solids(part)]
        res["stl_triangles"] = export_stl(c, os.path.join(OUT, NAME + ".stl"))
        if final:
            res["census"] = census(c)
            res["face_census"] = nxh.face_census(c.body)
        nxh.save(part)
        if final:
            stp = os.path.join(OUT, NAME + ".step")
            nxf.step_export(part, stp)
            rt = nxf.step_roundtrip_check(stp, OUT, restore=part, part=part)
            res["step_roundtrip"] = {k: rt.get(k) for k in ("match", "max_rel", "per_body", "healthy", "restored", "examine")}
            res["examine_native"] = [nxh.examine_geometry(part, b) for b in nxh.solids(part)]
            c.chk.true("STEP round trip matches", bool(rt.get("match")), rt.get("per_body"))
            res["regeneration"] = regen_test(c)
            c.chk("regeneration tests passed", res["regeneration"]["passed"], res["regeneration"]["of"], 0)
        res.update(c.chk.report())
    except Exception:
        res["error"] = traceback.format_exc()
        if c is not None:
            res["checks_so_far"] = c.chk.rows
    if c is not None:
        res["log"], res["sketches"], res["masters"] = c.log, c.sk, c.M
    nxh.write_json(os.path.join(OUT, "build.json"), res)


main()
