"""2D geometry helpers (pure Python) shared by the journal: intersections and profile areas."""
import math


def circ_at_v(c, r, v, side):
    """u of the circle (centre c, radius r) at height v; side = -1 left / +1 right of the centre."""
    d = r * r - (v - c[1]) ** 2
    if d < 0:
        raise ValueError("circle does not reach v=%s" % v)
    return c[0] + side * math.sqrt(d)


def circ_at_u(c, r, u, side):
    """v of the circle at abscissa u; side = -1 below / +1 above the centre."""
    d = r * r - (u - c[0]) ** 2
    if d < 0:
        raise ValueError("circle does not reach u=%s" % u)
    return c[1] + side * math.sqrt(d)


def line_pt(p, ang_deg, t):
    a = math.radians(ang_deg)
    return (p[0] + t * math.cos(a), p[1] + t * math.sin(a))


def line_at_v(p, ang_deg, v):
    a = math.radians(ang_deg)
    t = (v - p[1]) / math.sin(a)
    return (p[0] + t * math.cos(a), v)


def line_at_u(p, ang_deg, u):
    a = math.radians(ang_deg)
    t = (u - p[0]) / math.cos(a)
    return (u, p[1] + t * math.sin(a))


def line_line(p1, a1, p2, a2):
    d1 = (math.cos(math.radians(a1)), math.sin(math.radians(a1)))
    d2 = (math.cos(math.radians(a2)), math.sin(math.radians(a2)))
    det = d1[0] * (-d2[1]) - (-d2[0]) * d1[1]
    bx, by = p2[0] - p1[0], p2[1] - p1[1]
    t = (bx * (-d2[1]) - (-d2[0]) * by) / det
    return (p1[0] + t * d1[0], p1[1] + t * d1[1])


def line_circ(p, ang_deg, c, r, near):
    """Intersection of a line with a circle nearest to the point `near`; tangent miss -> foot point."""
    a = math.radians(ang_deg)
    d = (math.cos(a), math.sin(a))
    w = (p[0] - c[0], p[1] - c[1])
    b = 2 * (w[0] * d[0] + w[1] * d[1])
    cq = w[0] ** 2 + w[1] ** 2 - r * r
    disc = b * b - 4 * cq
    if disc < 0:
        ts = [-b / 2]
    else:
        ts = [(-b + math.sqrt(disc)) / 2, (-b - math.sqrt(disc)) / 2]
    cand = [(p[0] + t * d[0], p[1] + t * d[1]) for t in ts]
    return min(cand, key=lambda q: (q[0] - near[0]) ** 2 + (q[1] - near[1]) ** 2)


def circ_circ(c1, r1, c2, r2, near):
    dx, dy = c2[0] - c1[0], c2[1] - c1[1]
    d = math.hypot(dx, dy)
    a = (r1 * r1 - r2 * r2 + d * d) / (2 * d)
    h = math.sqrt(max(r1 * r1 - a * a, 0.0))
    mx, my = c1[0] + dx * a / d, c1[1] + dy * a / d
    cand = [(mx - dy * h / d, my + dx * h / d), (mx + dy * h / d, my - dx * h / d)]
    return min(cand, key=lambda q: (q[0] - near[0]) ** 2 + (q[1] - near[1]) ** 2)


def circle3(p1, p2, p3):
    """Centre and radius of the circle through three points."""
    ax, ay = p1
    bx, by = p2
    cx, cy = p3
    d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d
    uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d
    return (ux, uy), math.hypot(ax - ux, ay - uy)


def area(verts, arcs=None, n=400):
    """Signed-free area of a closed chain with arc segments (same conventions as ps.Sketch.profile)."""
    arcs = arcs or {}
    pts = []
    m = len(verts)
    for i in range(m):
        a, b = verts[i], verts[(i + 1) % m]
        pts.append((a[0], a[1]))
        if i in arcs:
            cu, cv = arcs[i][0], arcs[i][1]
            r = math.hypot(a[0] - cu, a[1] - cv)
            a0 = math.atan2(a[1] - cv, a[0] - cu)
            a1 = math.atan2(b[1] - cv, b[0] - cu)
            d = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi
            for k in range(1, n):
                t = a0 + d * k / n
                pts.append((cu + r * math.cos(t), cv + r * math.sin(t)))
    s = 0.0
    for i in range(len(pts)):
        x0, y0 = pts[i]
        x1, y1 = pts[(i + 1) % len(pts)]
        s += x0 * y1 - x1 * y0
    return abs(s) / 2
