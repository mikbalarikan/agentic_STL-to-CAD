"""Stage D - rail underside: rib silhouette blocks with ledge, bays, rib combs, grille grid, latch housings;
flange details (recesses, windows, pad) and the two latch sliders (separate bodies)."""
import math

import nxh
import nxf
import ps
import geo

BOOL = nxh.BOOL
X, Y, Z = (1, 0, 0), (0, 1, 0), (0, 0, 1)


def run(c):
    p, e, M, dat = c.part, c.e, c.M, c.dat
    body = c.body
    bot = -M["ge_bot"]
    cy, R, t = -M["ch_cy"], M["ch_R"], M["ch_t"]
    cw = (cy, 0.0)
    c3, r3 = (-65.57, -3.56), 14.83                    # outer edge of the ribs = outer wall of the corner cell
    e("ledge_z", 13.0, "top of the ledge under the rail")
    e("x_mid", 95.95, "symmetry plane of the rail underside")
    zl = -M["ledge_z"]
    Rm = R + t / 2.0                                    # mid surface of the channel wall: profiles end inside the wall

    # ---- rib silhouette (flange underside / outer arc / ledge underside), three runs + the rail-end housing
    sil = [(c3[0] - r3, -M["fl_t"], None, "fl_t"), (c3[0] - r3, c3[1]), (geo.circ_at_v(c3, r3, bot, -1), bot, None, "ge_bot"), (-70.5, bot),
           (geo.circ_at_v(cw, Rm, -12.2, -1), -12.2), (geo.circ_at_v(cw, Rm, -M["fl_t"], -1), -M["fl_t"])]
    S = c.sketch("yz", "SK_RIB_SILHOUETTE")
    S.profile(sil, {1: c3 + (None,), 4: cw + (None,)})
    c.done(S)
    e("comb1_x1", 45.0, "end of the first rib comb"); e("grid_x0", 79.0, "grille block start"); e("grid_x1", 112.9, "grille block end")
    e("comb2_x0", 146.8, "start of the second rib comb"); e("housing_x1", 191.5, "end of the rail-end housing")
    for name, x0, x1 in (("RIB_BLOCK_1", "ge_x", "comb1_x1"), ("RIB_BLOCK_GRID", "grid_x0", "grid_x1"), ("RIB_BLOCK_2", "comb2_x0", "housing_x1")):
        v0 = c.vol(body)
        c.extrude(S, X, x0, x1, name, BOOL.Unite, body)
        c.chk.true(name + " added", c.vol(body) > v0 + 500, c.vol(body) - v0)

    # ---- bays: open pockets between flange and ledge, behind the channel wall
    bay = [(-82.0, -M["fl_t"], None, "fl_t"), (geo.circ_at_v(cw, R + t, -M["fl_t"], -1), -M["fl_t"]), (geo.circ_at_v(cw, R + t, zl, -1), zl, None, "ledge_z"),
           (-82.0, zl)]
    S = c.sketch("yz", "SK_BAY")
    S.profile(bay, {1: cw + (None,)})
    c.done(S)
    e("bay1_x0", 8.3, "first bay starts behind the corner cell"); e("bay1_x1", 43.4, "")
    e("bayg_x0", 80.4, ""); e("bayg_x1", 111.4, ""); e("bay2_x0", 148.2, ""); e("bay2_x1", 182.2, "")
    for name, x0, x1 in (("BAY_1", "bay1_x0", "bay1_x1"), ("BAY_GRID", "bayg_x0", "bayg_x1"), ("BAY_2", "bay2_x0", "bay2_x1")):
        v0 = c.vol(body)
        c.extrude(S, X, x0, x1, name, BOOL.Subtract, body)
        c.chk.true(name + " cut", c.vol(body) < v0 - 500, v0 - c.vol(body))

    # ---- rail-end housing: a cell open at the end face (outer wall follows the rib outline)
    e("hs_wall_t", 1.3, "outer wall of the rail-end housing")
    ri = r3 - M["hs_wall_t"]
    cell = [(geo.circ_at_v(cw, R + t, -M["fl_t"], -1), -M["fl_t"], None, "fl_t"), (geo.circ_at_v(cw, R + t, zl, -1), zl, None, "ledge_z"),
            (geo.circ_at_v(c3, ri, zl, -1), zl), (c3[0] - ri, c3[1]), (c3[0] - ri, -M["fl_t"])]
    S = c.sketch("yz", "SK_HOUSING_CELL")
    S.profile(cell, {0: cw + (None,), 2: c3 + (None,)})
    c.done(S)
    v0 = c.vol(body)
    c.extrude(S, X, "bay2_x1+hs_wall_t", "end_x+1", "HOUSING_CELL", BOOL.Subtract, body)
    c.chk.true("HOUSING_CELL cut", c.vol(body) < v0 - 300, v0 - c.vol(body))

    # ---- ribs: one per comb, patterned
    rib = [(c3[0] - r3, -M["fl_t"] + 0.2), (geo.circ_at_v(cw, R + t - 0.2, -M["fl_t"] + 0.2, -1), -M["fl_t"] + 0.2),
           (geo.circ_at_v(cw, R + t - 0.2, zl - 0.2, -1), zl - 0.2), (geo.circ_at_v(c3, r3, zl - 0.2, -1), zl - 0.2), (c3[0] - r3, c3[1])]
    S = c.sketch("yz", "SK_RIB")
    S.profile(rib, {1: cw + (None,), 3: c3 + (None,)})
    c.done(S)
    e("rib_t", 1.4, "rib thickness")
    c.e("rib_n", 3, "ribs per comb", None)
    for name, xc, pitch in (("RIB_1", 16.9, 9.35), ("RIB_2", 156.3, 8.9)):
        e(name.lower() + "_x", xc, "first rib of the comb")
        e(name.lower() + "_pitch", pitch, "rib pitch")
        v0 = c.vol(body)
        f = c.extrude(S, X, "%s_x-rib_t/2" % name.lower(), "%s_x+rib_t/2" % name.lower(), name, BOOL.Unite, body)
        dv = c.vol(body) - v0
        pf = nxf.pattern_linear(p, [f], X, "rib_n", "%s_pitch" % name.lower())
        pf.SetName(name + "_PATTERN")
        c.chk(name + " pattern volume", c.vol(body) - v0, 3 * dv, 0.02 * 3 * dv)

    # ---- fifth snap hook at the start of the beam (short, solid)
    S = c.sketch("yz", "SK_HOOK_5")
    S.profile([(-0.2, -0.2), (-0.2, -6.0), (-1.5, -10.0), (-4.0, -13.0), (-7.6, -14.25), (-8.0, -12.0), (-5.5, -8.0), (-4.0, -4.0), (-3.5, -0.2)])
    c.done(S)
    v0 = c.vol(body)
    c.extrude(S, X, 21.0, 25.5, "HOOK_5", BOOL.Unite, body)
    c.chk.true("HOOK_5 added", c.vol(body) > v0 + 100, c.vol(body) - v0)

    # ---- grille grid: three vertical webs (pattern) and two horizontal fins
    web = [(-76.2, -M["fl_t"] + 0.2), (-76.2, zl - 0.2), (-71.0, zl - 0.2), (-74.8, -M["fl_t"] + 0.2)]
    S = c.sketch("yz", "SK_GRID_WEB")
    S.profile(web)
    c.done(S)
    e("web_x", 87.9, "first web of the grille grid"); e("web_pitch", 8.05, "web pitch"); e("web_t", 0.8, "web thickness")
    v0 = c.vol(body)
    f = c.extrude(S, X, "web_x-web_t/2", "web_x+web_t/2", "GRID_WEB", BOOL.Unite, body)
    dv = c.vol(body) - v0
    nxf.pattern_linear(p, [f], X, "rib_n", "web_pitch").SetName("GRID_WEB_PATTERN")
    c.chk("GRID_WEB pattern volume", c.vol(body) - v0, 3 * dv, 0.02 * 3 * dv)
    S = c.sketch("yz", "SK_GRID_FINS")
    S.profile([(-76.3, -5.8), (-74.5, -5.8), (-74.5, -4.7), (-76.3, -4.7)])
    S.profile([(-76.3, -9.9), (-73.0, -9.9), (-73.0, -8.8), (-76.3, -8.8)])
    c.done(S)
    v0 = c.vol(body)
    c.extrude(S, X, "bayg_x0-0.2", "bayg_x1+0.2", "GRID_FINS", BOOL.Unite, body)
    c.chk.true("GRID_FINS added", c.vol(body) > v0 + 30, c.vol(body) - v0)

    # ---- foot pads under the rail foot (rough in the scan: most likely stuck-on felt pads; kept as features so
    #      that they can be suppressed)
    e("pad_x", 30.7, "first foot pad"); e("pad_len", 14.0, "foot pad length"); e("pad_pitch", 58.3, "foot pad pitch")
    e("pad_bot", 17.2, "underside of the foot pads")
    S = c.sketch("yz", "SK_FOOT_PAD")
    S.profile([(-73.6, -M["foot_z"] + 0.3), (-M["lip_y"] - 0.6, -M["foot_z"] + 0.3), (-M["lip_y"] - 0.6, -M["pad_bot"], None, "pad_bot"), (-73.6, -M["pad_bot"]),
               (-73.6, -M["step_z"] + 0.0)][:4])
    c.done(S)
    v0 = c.vol(body)
    f = c.extrude(S, X, "pad_x", "pad_x+pad_len", "FOOT_PAD", BOOL.Unite, body)
    dv = c.vol(body) - v0
    nxf.pattern_linear(p, [f], X, "rib_n", "pad_pitch").SetName("FOOT_PAD_PATTERN")
    c.chk("FOOT_PAD pattern volume", c.vol(body) - v0, 3 * dv, 0.05 * 3 * dv)

    # ---- latch housing 1 (skirt, box, button bump) as one tool body, mirrored for latch 2
    e("skirt_z", 8.4, "underside of the skirt and of the latch box")
    zs = -M["skirt_z"]
    S = c.sketch("yz", "SK_LATCH_SKIRT")
    S.profile([(-80.3, -M["fl_t"] + 0.2), (-79.4, -M["fl_t"] + 0.2), (-79.4, zs, None, "skirt_z"), (-80.3, zs)])
    c.done(S)
    fsk = c.extrude(S, X, 43.5, 80.3, "LATCH_SKIRT")
    lb = fsk.GetBodies()[0]
    S = c.sketch("yz", "SK_LATCH_BOX")
    S.profile([(-80.3, -M["fl_t"] + 0.2), (-80.3, -6.3), (-79.4, zs, None, "skirt_z"), (-72.5, zs), (-74.9, -M["fl_t"] + 0.2)])
    c.done(S)
    c.extrude(S, X, 53.3, 72.7, "LATCH_BOX", BOOL.Unite, lb)
    S = c.sketch("yz", "SK_LATCH_BUMP")
    S.profile([(-M["fl_y"], -M["fl_t"] + 0.2), (-80.0, -M["fl_t"] + 0.2), (-80.0, -6.0), (-M["fl_y"], -6.0)])
    c.done(S)
    c.extrude(S, X, 60.5, 69.2, "LATCH_BUMP", BOOL.Unite, lb)
    _fm, plm = nxh.datum_plane(p, ("x_mid", 0, 0), X, "PLANE_MID")
    mf, copies = nxf.mirror_geometry(p, [lb], plm)
    mf.SetName("LATCH_HOUSING_MIRROR")
    v0 = c.vol(body)
    nxh.unite(p, body, [lb] + list(copies)).SetName("UNITE_LATCH_HOUSINGS")
    c.chk.true("latch housings united", c.vol(body) > v0 + 1500, c.vol(body) - v0)

    # ---- flange details
    e("rec_len", 6.4, "flange recess length"); e("rec_w", 2.0, "flange recess width"); e("rec_d", 0.5, "flange recess depth")
    e("rec_y", 80.45, "flange recesses from the hook-side datum")
    S = c.sketch("xy", "SK_FLANGE_RECESSES")
    hl, hw, yc = M["rec_len"] / 2 - M["rec_w"] / 2, M["rec_w"] / 2, -M["rec_y"]
    for xc in (29.6, 43.9, 84.4, 105.8, 152.1, 173.5):
        S.profile([(xc - hl, yc - hw), (xc + hl, yc - hw), (xc + hl + hw, yc), (xc + hl, yc + hw), (xc - hl, yc + hw), (xc - hl - hw, yc)],
                  {1: (xc + hl, yc, None), 2: (xc + hl, yc, None), 4: (xc - hl, yc, None), 5: (xc - hl, yc, None)})
    c.done(S)
    v0 = c.vol(body)
    c.extrude(S, Z, "-rec_d", 1.0, "FLANGE_RECESSES", BOOL.Subtract, body)
    c.chk.true("FLANGE_RECESSES cut", c.vol(body) < v0 - 20, v0 - c.vol(body))
    # tongue windows and button pockets, both latches in one sketch each
    xm = M["x_mid"]
    S = c.sketch("xy", "SK_LATCH_WINDOWS")
    for sgn in (1, -1):
        xa, xb = sorted((xm + sgn * (54.3 - xm), xm + sgn * (63.7 - xm)))
        S.profile([(xa, -78.3), (xb, -78.3), (xb, -75.2), (xa, -75.2)])
    c.done(S)
    v0 = c.vol(body)
    c.extrude(S, Z, "-skirt_z-1", 1.0, "LATCH_WINDOWS", BOOL.Subtract, body)
    c.chk.true("LATCH_WINDOWS cut", c.vol(body) < v0 - 200, v0 - c.vol(body))
    S = c.sketch("xy", "SK_BUTTON_POCKETS")
    for sgn in (1, -1):
        xa, xb = sorted((xm + sgn * (64.2 - xm), xm + sgn * (68.4 - xm)))
        S.profile([(xa, -82.6), (xb, -82.6), (xb, -79.2), (xa, -79.2)])
    c.done(S)
    v0 = c.vol(body)
    c.extrude(S, Z, -5.0, 1.0, "BUTTON_POCKETS", BOOL.Subtract, body)
    c.chk.true("BUTTON_POCKETS cut", c.vol(body) < v0 - 50, v0 - c.vol(body))
    # grille-end: recess in the flange and the raised pad
    S = c.sketch("xy", "SK_GE_FLANGE_RECESS")
    S.profile([(-1.0, -78.85), (3.7, -78.85), (3.7, -73.9), (-1.0, -73.9)])
    c.done(S)
    v0 = c.vol(body)
    c.extrude(S, Z, "-fl_t", 1.0, "GE_FLANGE_RECESS", BOOL.Subtract, body)
    c.chk.true("GE_FLANGE_RECESS cut", c.vol(body) < v0 - 20, v0 - c.vol(body))
    S = c.sketch("xy", "SK_FLANGE_PAD")
    S.profile([(11.7, -78.5), (19.5, -78.5), (19.5, -75.0), (11.7, -75.0)])
    c.done(S)
    c.extrude(S, Z, -0.2, 0.4, "FLANGE_PAD", BOOL.Unite, body)

    # ---- latch sliders: separate moulded parts in the real assembly, kept as separate bodies
    tongue = [(0.0, -8.6), (0.0, 7.0), (0.9, 8.2), (3.5, 8.2), (5.9, 5.3), (6.1, 4.5), (5.8, 3.5), (4.0, 2.6), (3.6, 2.2), (3.6, -8.6)]
    block = [(-3.5, -14.3), (15.0, -14.3), (15.0, -8.5), (-3.5, -8.5)]
    e("latch_x", 58.0, "back of the first latch tongue")
    sliders = []
    for k, sgn in ((1, 1), (2, -1)):
        x0 = xm + sgn * (M["latch_x"] - xm)
        S = c.sketch("xz", "SK_SLIDER_%d_TONGUE" % k)
        S.profile([(x0 + sgn * u, v) for u, v in tongue])
        c.done(S)
        ft = c.extrude(S, Y, -78.2, -75.9, "SLIDER_%d_TONGUE" % k)
        sb = ft.GetBodies()[0]
        S = c.sketch("xz", "SK_SLIDER_%d_BLOCK" % k)
        S.profile([(x0 + sgn * u, v) for u, v in block])
        c.done(S)
        c.extrude(S, Y, -78.0, -73.6, "SLIDER_%d_BLOCK" % k, BOOL.Unite, sb)
        sliders.append(sb)
    c.sliders = sliders
    c.chk("solids after stage D (frame + 2 sliders)", len(nxh.solids(p)), 3, 0)
    c.say("stage D: frame %.1f mm3, sliders %.1f / %.1f mm3" % (c.vol(body), c.vol(sliders[0]), c.vol(sliders[1])))
