# Dreame mop modülü alt kapağı — NX 2206 ile parametrik yeniden kurulum (2026-10-08)

Taramadan (`dreame_mop_assembly_bottom_cover.stl`) ölçü alınarak, NX'te **sıfırdan, feature tabanlı** kurulmuş
modeldir. Yüzey sarma / dilim-dilim ekstrüzyon yoktur: gövde eskiz + Extrude / Revolve / Through Curves / Pattern /
Mirror feature'larından oluşur ve adlandırılmış ifadelerle (expression) sürülür.

**Bant durumu (plastik, p95 ≤ 0,30 / max ≤ 0,80 mm): KARŞILANMADI.** Maskeli tarama→CAD p95 = 0,59 mm
(warp'ı alınmış tarama) / 0,93 mm (ham tarama). Ayrıntı "Doğrulama" ve "Bilinen sapmalar" bölümlerinde.

## Teslim edilenler

| Dosya | İçerik |
|---|---|
| `dreame_mop_bottom_cover.prt` | NX 2206 parametrik parça: `FRAME` gövdesi + 2 ayrı `LATCH_SLIDER` gövdesi |
| `dreame_mop_bottom_cover.step` | AP242, 3 katı (çerçeve + 2 mandal sürgüsü) |
| `dreame_mop_bottom_cover_with_scan.prt` | Aynı parça + katman 10'da tarama (137 k üçgen, CAD datum çerçevesinde) — NX'te üst üste inceleme için |
| `dreame_mop_bottom_cover_cad.stl` | Sapma ölçümünde kullanılan CAD mozaiği |
| `figures/` | Render'lar, sapma haritaları, kesit bindirmeleri (siyah = tarama, kırmızı = CAD) |
| `journal/` | Parçayı baştan kuran NXOpen journal (`build.py`, `nxlib/`), `run.ps1` |
| `analysis/` | Tarama ölçüm betikleri (kesit, doğru/yay fit, sapma) |
| `qa/` | `build_checks.json` (61 kontrol), `deviation_*.json`, `masters.json` (109 ifade) |

## Koordinat sistemi (Datum CSYS = önceki çalışmanın `run/intake/alignment.json` datumu)

- XY düzlemi = üst flanş yüzü (z = 0), malzeme −Z'de; mandal dilleri +Z'de.
- XZ düzlemi = kanca tarafı duvarının dış yüzü (y = 0), parça −Y'de.
- YZ düzlemi = ızgara ucu dış yüzü (x = 0), parça +X'te.

Parça **düz** kuruldu: taramadaki flanş sehimi (kase ucuna doğru ≈ 1,1 mm + burulma) tasarım niyeti sayılmadı.
Ölçüler, bu sehim bir polinom alanıyla geri alınmış tarama kopyasından okundu (`qa/warp_field.json`).

## Feature ağacı (269 feature; 71 eskiz, 68 Extrude, 4 Revolve, 2 Through Curves, 4 Pattern Feature, 1 Pattern Geometry, 1 Mirror Geometry, 7 boolean, 14 datum)

| Grup | Feature'lar | Not |
|---|---|---|
| Ray | `SK_RAIL` → `RAIL` | Flanş + kanal duvarı (R18,1 iç bükey, merkez flanş düzleminde) + ayak; tek profil, x 20,9 → 170,8 |
| Kanca tarafı kirişi | `BEAM`, `BEAD`, `TAB` + `TAB_WINDOW` → `TAB_PATTERN` (4 adet, adım 28,2) → `UNITE_TABS`, `HOOK_5` | Tırnak dış yüzü R15, kiriş dış yüzüne teğet |
| Izgara ucu (x 0–20,9) | `GE_BLOCK` zarfı, `GE_PAD`, 4 ray-tarafı + 3 kanca-tarafı oluk boşluğu (`GE_RAIL_Z1..4`, `GE_HOOK_Z1..3`), `GE_END_WALL`, `GE_CORNER_CELL`, `GE_TUNNELS`, `GE_POCKETS` | Oluklar x boyunca basamaklı; her bölgenin kendi doğru + yay + taban profili |
| Kase ucu | `END_BLOCK`, `RAIL_POCKET`, `BACK_WALL`, `CELLS`, `FINS`, `BOWL_B_SHELL`/`BOWL_B_VOID` (dönel, dik eksen, 2 yaylı meridyen), `BOWL_A_SKIN`/`BOWL_A_VOID_TOOL` (6 plan kesitinden Through Curves), `DECK_CONE_A/B`, `DECK_CAP`, `DECK_STEP`, `FLAT_DECK`, `FRONT_TRIM(_A)`, `FRONT_LIP`, `FLANGE_END`, `CATCH` | Kase B dönel yüzey; kase A'nın plan kesitleri derinlikle merkezi kayan daireler (eğik koni + yuvarlak taban) |
| Kanca tarafı köşesi | `HOOK_BLOCK`, `TRAY`, `HOOK_UNDERSIDE`, `HOOK_SKIN`, `HOOK_FACE`, `HOOK_WALL` | Eğri taban, planı X'e 17,5° açılı doğrultuda ekstrüde (ölçülen) |
| Ray altı | `RIB_BLOCK_1/GRID/2`, `BAY_1/GRID/2`, `RIB_1/2` + pattern (3'er), `GRID_WEB` + pattern, `GRID_FINS`, `HOUSING_CELL`, `FOOT_PAD` + pattern, mandal yuvası (`LATCH_SKIRT/BOX/BUMP`) + `LATCH_HOUSING_MIRROR` | Mandal yuvası x = 95,95 simetri düzlemine göre aynalı |
| Flanş detayları | `FLANGE_RECESSES` (6), `LATCH_WINDOWS`, `BUTTON_POCKETS`, `GE_FLANGE_RECESS`, `FLANGE_PAD` | |
| Mandal sürgüleri | `SLIDER_n_TONGUE` + `SLIDER_n_BLOCK` | **Ayrı gövdeler** (gerçekte ayrı gri parça); taramada görünen kısım |

Eskizlerin tamamı tam kısıtlı (71/71 `WellConstrained`, DOF 0, otomatik ölçü 0; 772 eskiz ölçüsü). 109 adlandırılmış
ana ifade var (`qa/masters.json`): ör. `fl_t` 1,9 · `ch_R` 18,1 · `ch_t` 2,05 · `tab_pitch` 28,2 · `tab_w` 7,8 ·
`hump_z` 8,15 · `bowl_t` 1,8 · `plate_t` 1,85 · `rib_t` 1,4 · `web_pitch` 8,05 · `end_x` 192,6. Değerler taramanın
gürültü tabanına (0,04 mm) göre 0,05 mm ızgarasına yuvarlandı. Ölçek kumpasla doğrulanmadı (yalnız tarama).

## Doğrulama (kurucu tarafından yapıldı — bağımsız QA değildir)

| Kontrol | Sonuç |
|---|---|
| Journal kontrolleri (hacim, kesme/ekleme farkları, gövde sayısı, feature hatası) | 61 / 61 geçti, feature hatası yok |
| Examine Geometry (NX, yerel gövdeler) | 3 gövde de temiz (tüm sayaçlar 0) |
| Regenerasyon: 14 ana ifade tek tek değiştirildi → güncelle → geri al | 14 / 14 hatasız; hacim nominale döndü; `tab_pitch` 27,6'da son tırnak x = 136,0 (beklenen 136,0) |
| STEP gidiş-dönüş (NX'e geri okuma) | 3 katı, hacim farkı ≤ 9·10⁻⁶ |
| STEP — OCP `BRepCheck_Analyzer` | 3 katı da geçerli |
| STEP — NX Examine Geometry (geri okunan çerçeve) | **96 "face intersection" bulgusu** (yerel gövdede 0); çözülmedi |

Tarama ↔ CAD sapması (400 k üçgenlik hizalı çalışma kopyası, 800 k örnek nokta; + = tarama CAD'in dışında):

| | rms | p50 | p90 | p95 | p99 | > 0,3 mm | > 0,8 mm |
|---|---|---|---|---|---|---|---|
| Tarama→CAD, warp alınmış, artefaktlar maskeli (%5,1) | 0,308 | 0,084 | 0,432 | **0,595** | 1,231 | %19,1 | %2,7 |
| Tarama→CAD, warp alınmış, maskesiz | 0,442 | 0,093 | 0,550 | 1,042 | 1,892 | %22,7 | %6,6 |
| Tarama→CAD, **ham** (yalnız rijit hizalı), maskeli | 0,442 | 0,188 | – | 0,929 | 1,298 | %36,5 | %9,3 |
| CAD→tarama (tüm CAD yüzeyi) | 0,443 | 0,076 | 0,605 | 1,064 | 1,897 | %19,4 | %7,6 |

Maskelenenler yalnız tek yüzeyli tarama artefaktlarıdır: kanca kirişinin üstündeki/dışındaki levha, ray ayağının
altındaki levha ve açıklık kenarlarındaki "perde" (önceki intake kartındaki a–d). CAD yüzeyinin %2,5'i taramada
görünmüyor (mandal yuvası içleri, hücre içleri).

Önceki build123d sonucu (it3, kendi protokolü: ham tam çözünürlük + ICP): rms 0,496 / p50 0,186 / p95 1,066 /
> 0,8 mm %8,8. Protokoller aynı değil (burada ICP yok, maskeler farklı), birebir karşılaştırma değildir.

## Bilinen sapmalar ve sadeleştirmeler

1. **Bant karşılanmadı.** En büyük kalan farklar x 160–192 (kase ucu): kase A'nın kanca tarafı geçişi ve taban
   pahı (alt seviyelerde ≈ 1–2 mm), kase B ile ray kanalı arasındaki geçiş (model: basamak; gerçek: yumuşak geçiş,
   derinde ≈ 1,5 mm), güverte yüzeyi (iki koni + düzlem; yer yer ±0,3–0,5 mm).
2. **Kenar radyüsleri / pahlar modellenmedi** (flanş kenarları, tırnak kökleri vb. ≈ R0,3–1). Edge Blend yok.
3. **Kalıp çıkma açıları** yalnız profilde ölçülen yerlerde var (kiriş iç yüzü, uç blok ön düzlemi); genel draft yok.
4. **Mandal yuvaları** taramada kapalı göründüğü için dolu kutu olarak modellendi; iç boşlukları bilinmiyor.
   Sürgüler basitleştirilmiş ayrı gövdelerdir; flanş üstündeki iki küçük kubbe modellenmedi.
5. **Ayak pedleri** (z −17,2; taramada pürüzlü, büyük olasılıkla yapıştırma keçe) feature olarak eklendi
   (`FOOT_PAD` + pattern) — istenmezse bastırılabilir.
6. Izgara ucu 4. bölge duvarının ray kanalına rampalı geçişi (x 20,9–25), 5. kancanın ayrıntısı, ray ucu yuvasının
   iç rafı ve tepsi ön duvarı basitleştirildi.
7. Eskiz ölçülerinin çoğu (772 ölçü) ölçülmüş sayı olarak girildi; yalnız ana boyutlar 109 adlandırılmış ifadeye
   bağlı. Profil köşe koordinatları ifade değil sayıdır.
8. Sapma ölçümü 400 k'lık çalışma kopyasında yapıldı (tam çözünürlüğe göre p95 0,02 mm fark, intake kaydı),
   242 MB'lık özgün tarama üzerinde yeniden koşulmadı.

## Yeniden kurma

```
powershell -File journal\run.ps1 -Stage z      (journal içindeki yollar C:\NX_MCP_WORKSPACE\dreame_cover'a göredir)
```
