"""Residual map of the two-cone deck model; test a capping plane over the ridge."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import least_squares
from common import AN

Q = np.load(os.path.join(AN, "deck_pts.npy"))
S = Q[(Q[:, 2] > 0.45) & (Q[:, 0] < 189.0) & (Q[:, 0] > 172) & (Q[:, 1] < -14) & (Q[:, 1] > -75.5)]


def model(p, q):
    ax, ay, ka, za, bx, by, kb, zb, c0, c1, c2 = p
    zA = za + ka * np.hypot(q[:, 0] - ax, q[:, 1] - ay)
    zB = zb + kb * np.hypot(q[:, 0] - bx, q[:, 1] - by)
    zC = c0 + c1 * (q[:, 0] - 180.0) + c2 * (q[:, 1] + 37.0)
    return np.minimum(np.minimum(zA, zB), zC)


p0 = (173.536, -21.128, 0.3464, -3.916, 166.614, -56.179, 0.4099, -7.750, 2.0, 0.12, 0.0)
r = least_squares(lambda p: model(p, S) - S[:, 2], p0, loss="soft_l1", f_scale=0.05)
e = model(r.x, S) - S[:, 2]
print("two cones + cap plane:", np.round(r.x, 4))
print(f"  rms {np.sqrt((e**2).mean()):.3f} p95 {np.percentile(np.abs(e),95):.3f} max {np.abs(e).max():.3f} share>0.3 {np.mean(np.abs(e)>0.3):.4f}")
p = r.x
print(f"  cone A: axis ({p[0]:.2f},{p[1]:.2f}) slope {p[2]:.4f} ({np.degrees(np.arctan(p[2])):.2f} deg) z0 {p[3]:.3f} -> r(z=0.3) {(0.3-p[3])/p[2]:.2f}")
print(f"  cone B: axis ({p[4]:.2f},{p[5]:.2f}) slope {p[6]:.4f} ({np.degrees(np.arctan(p[6])):.2f} deg) z0 {p[7]:.3f} -> r(z=0.3) {(0.3-p[7])/p[6]:.2f}")
print(f"  cap: z = {p[8]:.3f} + {p[9]:.4f} (x-180) + {p[10]:.4f} (y+37)")
fig, axs = plt.subplots(1, 2, figsize=(16, 16))
for ax, (ttl, ee) in zip(axs, (("two cones only", model(np.r_[r.x[:8], 99, 0, 0], S) - S[:, 2]), ("two cones + cap plane", e))):
    sc = ax.scatter(S[:, 0], S[:, 1], c=ee, s=1, cmap="coolwarm", vmin=-0.5, vmax=0.5)
    ax.set_aspect("equal"); ax.set_title(ttl + " (model - scan)"); ax.grid(True, lw=0.2)
    ax.set_xticks(np.arange(172, 191, 2)); ax.set_yticks(np.arange(-76, -12, 2)); ax.tick_params(labelsize=7)
plt.colorbar(sc, ax=axs, shrink=0.4)
fig.savefig(os.path.join(AN, "deck_res.png"), dpi=70)
