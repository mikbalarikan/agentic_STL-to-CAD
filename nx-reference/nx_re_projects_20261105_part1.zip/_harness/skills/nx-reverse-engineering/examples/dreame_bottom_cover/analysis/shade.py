"""Hill-shaded height maps of a region, seen from +Z and from -Z. usage: shade.py <out.png> x0 x1 y0 y1 [res] [cad.stl]"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LightSource
from common import load, read_stl, Mesh

out = sys.argv[1]
x0, x1, y0, y1 = [float(v) for v in sys.argv[2:6]]
res = float(sys.argv[6]) if len(sys.argv) > 6 else 0.1
m, _ = load(True)
if len(sys.argv) > 7:
    m = Mesh(read_stl(sys.argv[7]))
mask = (m.hi[:, 0] > x0) & (m.lo[:, 0] < x1) & (m.hi[:, 1] > y0) & (m.lo[:, 1] < y1)
area = (x1 - x0) * (y1 - y0)
P, idx = m.sample(int(min(6e6, max(1.5e6, area / res ** 2 * 40))), seed=2, mask=mask)
s = (P[:, 0] > x0) & (P[:, 0] < x1) & (P[:, 1] > y0) & (P[:, 1] < y1)
P = P[s]
nx, ny = int((x1 - x0) / res), int((y1 - y0) / res)
ix = np.clip(((P[:, 0] - x0) / res).astype(int), 0, nx - 1)
iy = np.clip(((P[:, 1] - y0) / res).astype(int), 0, ny - 1)
flat = iy * nx + ix
o = np.argsort(P[:, 2])
top = np.full(ny * nx, np.nan); top[flat[o]] = P[o, 2]
bot = np.full(ny * nx, np.nan); bot[flat[o[::-1]]] = P[o[::-1], 2]
ls = LightSource(azdeg=315, altdeg=45)
w, h = x1 - x0, y1 - y0
sc = min(20.0 / w, 9.0 / h)
fig, axs = plt.subplots(2, 1, figsize=(w * sc + 2, 2 * h * sc + 1.5))
for ax, (ttl, hm, sgn) in zip(axs, (("seen from +Z (top = flange side)", top, 1), ("seen from -Z (underside)", bot, -1))):
    g = hm.reshape(ny, nx)
    f = np.where(np.isnan(g), np.nanmin(g) - 3, g)
    rgb = ls.shade(sgn * f, cmap=plt.cm.turbo, vert_exag=2.0, dx=res, dy=res, blend_mode="soft", vmin=np.nanmin(sgn * g), vmax=np.nanmax(sgn * g))
    rgb[np.isnan(g)] = (1, 1, 1, 1)
    ax.imshow(rgb, origin="lower", extent=[x0, x1, y0, y1], interpolation="nearest")
    step = 1 if max(w, h) <= 40 else 2 if max(w, h) <= 80 else 5
    ax.set_xticks(np.arange(np.ceil(x0 / step) * step, x1 + 1e-6, step)); ax.set_yticks(np.arange(np.ceil(y0 / step) * step, y1 + 1e-6, step))
    ax.tick_params(labelsize=6); ax.grid(True, lw=0.15, color="k", alpha=0.3); ax.set_title(ttl, fontsize=9)
fig.tight_layout(); fig.savefig(out, dpi=110)
print("saved", out)
