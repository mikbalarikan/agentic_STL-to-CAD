"""Per-z circle fits of the bowl plan contours (centre drift = tilt, residual = non-circular)."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import AN


def cfit(q):
    A = np.c_[2 * q, np.ones(len(q))]
    sol, *_ = np.linalg.lstsq(A, (q ** 2).sum(1), rcond=None)
    c = sol[:2]; r = np.sqrt(sol[2] + c @ c)
    for _ in range(25):
        v = q - c; d = np.linalg.norm(v, axis=1)
        J = np.c_[-v / d[:, None], -np.ones(len(q))]
        dl, *_ = np.linalg.lstsq(J, -(d - r), rcond=None)
        c = c + dl[:2]; r = r + dl[2]
    res = np.linalg.norm(q - c, axis=1) - r
    return c, r, res


def ellfit(q, c0):
    """Axis-aligned ellipse (x-cx)^2/a^2 + (y-cy)^2/b^2 = 1, algebraic."""
    A = np.c_[q[:, 0] ** 2, q[:, 1] ** 2, q[:, 0], q[:, 1]]
    sol, *_ = np.linalg.lstsq(A, np.ones(len(q)), rcond=None)
    A_, B_, C_, D_ = sol
    cx, cy = -C_ / (2 * A_), -D_ / (2 * B_)
    k = 1 + A_ * cx ** 2 + B_ * cy ** 2
    return cx, cy, np.sqrt(k / A_), np.sqrt(k / B_)


for nm in ("B", "A"):
    Q = np.load(os.path.join(AN, f"bowl{nm}_skin.npy"))
    print(f"bowl {nm}")
    for z in np.arange(-1, -13.6, -1.0):
        s = np.abs(Q[:, 2] - z) < 0.12
        q = Q[s, :2]
        if len(q) < 50:
            continue
        c, r, res = cfit(q)
        th = np.degrees(np.arctan2(q[:, 1] - c[1], q[:, 0] - c[0]))
        ex, ey, ea, eb = ellfit(q, c)
        print(f"  z={z:5.1f}: circle c=({c[0]:7.3f},{c[1]:7.3f}) r={r:6.3f} rms={np.sqrt((res**2).mean()):.3f} max={np.abs(res).max():.3f} "
              f"theta {th.min():.0f}..{th.max():.0f} | ellipse c=({ex:.2f},{ey:.2f}) a={ea:.2f} b={eb:.2f}")
