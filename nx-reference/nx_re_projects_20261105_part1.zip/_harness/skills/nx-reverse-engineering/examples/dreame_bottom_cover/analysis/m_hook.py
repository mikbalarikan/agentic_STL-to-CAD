"""Hook-side corner of the bowl end: curved floor (underside and top), tray rim, flat deck, end catch."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from pw import env, report
from fit import pts, level, line, circle, show, mesh

for x0, x1 in ((174, 178), (180, 184), (186, 190)):
    EB = env(0, x0, x1, -24.0, 0.8, "bot", zlim=(-17, 2))
    print(f"--- x {x0}..{x1} underside")
    report("underside", EB, [-23.0, -19.0, -1.2], "FA")
    report("underside 2 arcs", EB, [-23.0, -19.0, -9.0, -1.2], "FAA")
P = pts(0, 184, 190, 5, (-26, 3, -16, 2))
show("floor top surface arc (x 184..190)", circle(P, (-18.0, 10.0), 23.0, 290, 335, band=0.5))
show("floor underside arc (x 184..190)", circle(P, (-18.0, 10.0), 24.6, 285, 335, band=0.5))
print("hook outer wall y (z -3..-0.5)", level(P, 0, -0.6, 0.6, -3.0, -0.5))
print("hook wall inner y (z -3..-0.5)", level(P, 0, -2.4, -0.9, -3.0, -0.5))
print("hook wall top z", level(P, 1, -1.6, -0.2, -0.2, 0.9))
print("tray inner wall y (y -12.6..-10.6)", level(P, 0, -12.8, -10.4, -4.0, -0.5))
print("flat deck z (y -20..-13)", level(P, 1, -19.5, -13.5, 0.1, 0.6))
m = mesh()
# end catch: up-facing faces at y > 0.4
s = (m.c[:, 1] > 0.5) & (m.c[:, 0] > 150) & (m.n[:, 2] > 0.8) & (m.c[:, 2] > -1) & (m.c[:, 2] < 1.2)
print("catch top faces: x", m.c[s, 0].min().round(2), m.c[s, 0].max().round(2), "y", m.c[s, 1].min().round(2), m.c[s, 1].max().round(2),
      "z median", np.median(m.c[s, 2]).round(3))
s = (m.c[:, 1] > 0.5) & (m.c[:, 0] > 150) & (m.n[:, 2] < -0.8) & (m.c[:, 2] > -4)
print("catch underside faces: x", m.c[s, 0].min().round(2), m.c[s, 0].max().round(2), "z median", np.median(m.c[s, 2]).round(3))
s = (m.c[:, 1] > 2.0) & (m.c[:, 0] > 150) & (m.n[:, 1] > 0.8)
print("catch outer face y median", np.median(m.c[s, 1]).round(3), "x", m.c[s, 0].min().round(2), m.c[s, 0].max().round(2), "z", m.c[s, 2].min().round(2), m.c[s, 2].max().round(2))
# beam end / hook wall outer face along x at z=-2
for x in (158, 162, 166, 170, 174, 178, 184, 190):
    Q = pts(0, x - 0.5, x + 0.5, 3, (-14, 4, -16, 2))
    print(f"x={x}: outer y at z=-1.5: {level(Q, 0, -1.2, 1.0, -2.2, -0.8)}  top z near y=-2.5: {level(Q, 1, -3.2, -1.8, -0.5, 1.5)}")
