"""Rail profile (flange + channel wall + foot), plain stations away from ribs/ledges/latches."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from fit import pts, line, circle, level, show

LIM = (-86, -64, -19, 2)
sets = {"48-52": (48, 52), "74-77": (74, 77), "114-117": (114, 117), "139-143": (139, 143)}
for nm, (x0, x1) in sets.items():
    P = pts(0, x0, x1, 9, LIM)
    print(f"--- x {nm}  n={len(P)}")
    print(" flange top z", level(P, 1, -83, -75, -0.3, 0.3))
    print(" flange under z", level(P, 1, -83, -81, -2.3, -1.5))
    print(" flange outer y", level(P, 0, -84.5, -83.3, -1.5, -0.4))
    show(" concave arc", circle(P, (-56, 0), 18, 180, 232, band=0.5))
    show(" concave arc upper", circle(P, (-56, 0), 18, 180, 205, band=0.4))
    show(" concave arc lower", circle(P, (-56, 0), 18, 205, 232, band=0.4))
    show(" back arc", circle(P, (-56, 0), 20, 186, 222, band=0.5))
    print(" lip face y", level(P, 0, -67.8, -66.9, -16, -14.2))
    print(" foot bottom z", level(P, 1, -69.0, -67.6, -16.6, -15.9))
    print(" foot step face y", level(P, 0, -69.9, -69.0, -16.1, -15.2))
    print(" step z", level(P, 1, -71.0, -69.7, -15.3, -14.7))
    print(" back step face y", level(P, 0, -71.6, -70.9, -14.8, -13.3))
# all plain stations together for the final profile
P = np.concatenate([pts(0, a, b, 9, LIM) for a, b in sets.values()])
np.save(os.path.join(os.path.dirname(__file__), "rail_pts.npy"), P)
# concave face: sample y at z levels
print("concave face y(z):")
for z in np.arange(-0.5, -14.0, -0.5):
    s = (np.abs(P[:, 1] - z) < 0.08) & (P[:, 0] > -75) & (P[:, 0] < -66.5)
    # concave face is the max-y cluster at this z
    ys = P[s, 0]
    if len(ys):
        top = ys[ys > ys.max() - 0.25]
        back = ys[ys < ys.max() - 1.0]
        print(f"  z={z:6.2f} concave y={np.median(top):8.3f}  back y={np.median(back[back > back.max() - 0.25]) if len(back) else float('nan'):8.3f}")
