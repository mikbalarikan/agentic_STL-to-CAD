"""Section plots. usage: sec.py <out.png> <axis x|y|z> <v1,v2,...> [lim a0 a1 b0 b1] [raw] [cols N] [avg W]

Each value gets its own panel; 'avg W' overlays sections at value +-W/2 in 5 steps (to see along-axis constancy).
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.ticker import MultipleLocator
from common import load

args = sys.argv[1:]
out, axn, vals = args[0], args[1], [float(v) for v in args[2].split(",")]
axis = "xyz".index(axn)
lim = None
raw = "raw" in args
cols = 1
avg = 0.0
major = None
if "lim" in args:
    i = args.index("lim")
    lim = [float(v) for v in args[i + 1:i + 5]]
if "cols" in args:
    cols = int(args[args.index("cols") + 1])
if "avg" in args:
    avg = float(args[args.index("avg") + 1])
if "major" in args:
    major = float(args[args.index("major") + 1])
m, _ = load(dewarped=not raw)
o = [i for i in range(3) if i != axis]
rows = int(np.ceil(len(vals) / cols))
if lim:
    w, h = lim[1] - lim[0], lim[3] - lim[2]
else:
    w, h = m.hi[:, o[0]].max() - m.lo[:, o[0]].min(), m.hi[:, o[1]].max() - m.lo[:, o[1]].min()
scale = min(22.0 / (w * cols), 14.0 / (h * rows))
fig, axs = plt.subplots(rows, cols, figsize=(max(6, w * cols * scale + 1), max(3, h * rows * scale + 0.6 * rows)), squeeze=False)
if major is None:
    major = 1 if max(w, h) <= 30 else 2 if max(w, h) <= 60 else 5 if max(w, h) <= 120 else 10
for k, v in enumerate(vals):
    ax = axs[k // cols][k % cols]
    box = None
    if lim:
        box = {o[0]: (lim[0], lim[1]), o[1]: (lim[2], lim[3])}
    if avg:
        for dv, col in zip(np.linspace(-avg / 2, avg / 2, 5), ("tab:blue", "tab:cyan", "k", "tab:orange", "tab:red")):
            s = m.section(axis, v + dv, box)
            ax.add_collection(LineCollection(s[:, :, o], linewidths=0.5, colors=col))
    else:
        s = m.section(axis, v, box)
        ax.add_collection(LineCollection(s[:, :, o], linewidths=0.7, colors="k"))
    ax.set_aspect("equal")
    if lim:
        ax.set_xlim(lim[0], lim[1]); ax.set_ylim(lim[2], lim[3])
    else:
        ax.autoscale()
    ax.xaxis.set_major_locator(MultipleLocator(major)); ax.yaxis.set_major_locator(MultipleLocator(major))
    ax.xaxis.set_minor_locator(MultipleLocator(major / 5 if major in (5, 10) else major / 2))
    ax.yaxis.set_minor_locator(MultipleLocator(major / 5 if major in (5, 10) else major / 2))
    ax.grid(True, which="major", lw=0.4, color="0.6"); ax.grid(True, which="minor", lw=0.2, color="0.85")
    ax.tick_params(labelsize=7)
    ax.set_title(f"{axn} = {v:g}{' +-%g' % (avg / 2) if avg else ''}   ({'xyz'[o[0]]} horiz, {'xyz'[o[1]]} vert)", fontsize=9)
fig.tight_layout()
fig.savefig(out, dpi=100)
print("saved", out)
