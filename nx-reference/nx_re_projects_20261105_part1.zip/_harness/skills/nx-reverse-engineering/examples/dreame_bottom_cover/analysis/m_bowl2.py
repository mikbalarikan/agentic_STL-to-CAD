"""Transition rail cylinder -> bowl B revolve; bowl A straight part; clean meridians."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, AN

m, _ = load(True)
P, idx = m.sample(2_500_000, seed=5, mask=(m.c[:, 0] > 140))
N = m.n[idx]
RAIL_C = (-55.84, -0.09, 17.99)       # y, z, r of the rail concave arc


def polar(ax):
    v = P[:, :2] - np.asarray(ax)
    r = np.linalg.norm(v, axis=1)
    th = np.degrees(np.arctan2(v[:, 1], v[:, 0]))
    inward = -(N[:, 0] * v[:, 0] + N[:, 1] * v[:, 1]) / np.maximum(r, 1e-9)
    return r, th, inward


def inner(rr):
    lo = np.percentile(rr, 8)
    return np.median(rr[rr < lo + 0.5])


fig, axs = plt.subplots(1, 2, figsize=(22, 9))
for k, (nm, ax, thr) in enumerate((("B", (169.30, -56.32), (-100, 95)), ("A", (169.33, -20.39), (-95, 110)))):
    r, th, inward = polar(ax)
    base = (r < 21) & (inward > 0.1) & (N[:, 2] > -0.05)
    for z, col in zip((-1.5, -4, -6, -8, -10, -11.5, -12.5, -13.3), plt.cm.turbo(np.linspace(0, 1, 8))):
        sz = base & (np.abs(P[:, 2] - z) < 0.12)
        ts, rs = [], []
        for t in np.arange(thr[0], thr[1], 3.0):
            st = sz & (th >= t) & (th < t + 3)
            if st.sum() > 6:
                ts.append(t + 1.5); rs.append(inner(r[st]))
        axs[k].plot(ts, rs, "-", color=col, lw=1.2, label=f"z={z}")
        if nm == "B":
            # rail cylinder seen from this axis: y = cy - sqrt(R^2 - (z - cz)^2)
            ycyl = RAIL_C[0] - np.sqrt(RAIL_C[2] ** 2 - (z - RAIL_C[1]) ** 2)
            tt = np.arange(-100, -45, 1.0)
            axs[k].plot(tt, (ax[1] - ycyl) / np.cos(np.radians(tt + 90)), ":", color=col, lw=0.8)
    axs[k].set_title(f"bowl {nm}: inner radius vs theta about ({ax[0]}, {ax[1]})  (dotted: rail R18 cylinder)")
    axs[k].set_ylim(4, 20); axs[k].grid(True, lw=0.3); axs[k].legend(fontsize=7); axs[k].set_xticks(np.arange(-100, 111, 10))
    axs[k].set_yticks(np.arange(4, 20.5, 0.5), minor=True); axs[k].grid(True, which="minor", lw=0.15)
fig.tight_layout(); fig.savefig(os.path.join(AN, "bowl_rtheta.png"), dpi=80); plt.close(fig)

# clean meridians over the theta range where the bowl is a revolve
for nm, ax, (t0, t1) in (("B", (169.30, -56.32), (-40, 45)), ("A", (169.33, -20.39), (-45, 45))):
    r, th, inward = polar(ax)
    base = (r < 21) & (inward > 0.1) & (N[:, 2] > -0.05) & (th > t0) & (th < t1)
    rows = []
    for z in np.arange(-0.4, -14.4, -0.2):
        sz = base & (np.abs(P[:, 2] - z) < 0.06)
        if sz.sum() > 30:
            per = []
            for t in np.arange(t0, t1, 8.0):
                st = sz & (th >= t) & (th < t + 8)
                if st.sum() > 6:
                    per.append(inner(r[st]))
            if len(per) >= 4:
                rows.append((np.median(per), z, np.std(per)))
    rows = np.array(rows)
    np.save(os.path.join(AN, f"bowl{nm}_meridian.npy"), rows)
    print(f"bowl {nm} meridian ({len(rows)} pts): theta spread median {np.median(rows[:, 2]):.3f} max {rows[:, 2].max():.3f}")
    for q in rows[::5]:
        print(f"   r={q[0]:7.3f} z={q[1]:6.2f} sd={q[2]:.3f}")
