"""Beam (hook side), bead and snap tab profiles."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from fit import pts, line, circle, level, show

LIM = (-12, 4, -17, 3)
P = np.concatenate([pts(0, a, b, 7, LIM) for a, b in ((58, 71), (86, 99), (114, 127), (142, 152))])
print("beam plain stations, n =", len(P))
print(" outer face y (z -3..-0.6)", level(P, 0, -0.25, 0.3, -3.0, -0.6))
show(" outer face line", line(P, (0.02, -0.5), (0.02, -3.3), band=0.15, margin=0.2))
show(" outer face lower", line(P, (0.0, -3.8), (-0.3, -6.0), band=0.15, margin=0.2))
print(" top outer z (y -0.8..-0.2)", level(P, 1, -0.8, -0.2, -0.3, 0.3))
print(" top inner z (y -3.1..-2.4)", level(P, 1, -3.1, -2.45, 0.0, 0.7))
print(" bead top z (y -1.8..-1.4)", level(P, 1, -1.8, -1.35, 0.8, 1.5))
show(" bead inner flank", line(P, (-2.25, 0.45), (-2.0, 1.0), band=0.12, margin=0.05))
show(" bead outer flank", line(P, (-1.05, 0.95), (-0.95, 0.15), band=0.12, margin=0.05))
show(" bead top arc", circle(P, (-1.6, 0.7), 0.5, 20, 160, band=0.15))
show(" inner face upper", line(P, (-3.45, 0.0), (-3.5, -2.3), band=0.15, margin=0.2))
show(" inner face lower", line(P, (-3.7, -3.0), (-4.6, -6.0), band=0.15, margin=0.2))
print(" bottom z", level(P, 1, -4.2, -0.8, -6.8, -6.0))
print(" inner bottom corner y (z -6.2..-5.9)", level(P, 0, -5.2, -4.3, -6.3, -6.0))
# without bead: x 27..38
P2 = pts(0, 27, 38, 7, LIM)
print("beam x 27..38 (no bead)")
print(" top z by y:", [(y, level(P2, 1, y - 0.2, y + 0.2, -0.4, 0.8)) for y in (-3.0, -2.5, -2.0, -1.5, -1.0, -0.5)])
# bead x extent: top-most point z>0.9 near y=-1.6 along x
from fit import mesh
m = mesh()
s = (m.c[:, 1] > -1.9) & (m.c[:, 1] < -1.3) & (m.c[:, 2] > 0.95) & (m.c[:, 2] < 1.5) & (m.n[:, 2] > 0.7)
print("bead top faces x range:", m.c[s, 0].min().round(2), m.c[s, 0].max().round(2), "z median", np.median(m.c[s, 2]).round(3))
# beam x extent: bottom faces z ~ -6.4
s = (m.c[:, 1] > -4) & (m.c[:, 1] < -0.5) & (np.abs(m.c[:, 2] + 6.4) < 0.15) & (m.n[:, 2] < -0.9)
xs = np.sort(m.c[s, 0])
print("beam bottom faces x range:", xs.min().round(2), xs.max().round(2))
gaps = np.flatnonzero(np.diff(xs) > 1.0)
print("  gaps (tabs) at:", [(xs[g].round(2), xs[g + 1].round(2)) for g in gaps])
# tab profile, stations inside tabs away from the window
T = np.concatenate([pts(0, a, b, 5, LIM) for a, b in ((45.6, 47.0), (51.4, 53.0))])
print("tab profile (side cheeks), n =", len(T))
show(" tab outer arc", circle(T, (-12, -3), 12.5, 290, 358, band=0.4))
show(" tab inner arc", circle(T, (-12, -3), 10.0, 290, 350, band=0.4))
show(" tab outer lower line", line(T, (-4.5, -13.6), (-9.3, -14.75), band=0.2, margin=0.2))
show(" tab inner upper line", line(T, (-4.5, -6.5), (-4.5, -9.3), band=0.2, margin=0.2))
show(" tab tip face", line(T, (-9.85, -13.7), (-9.7, -14.7), band=0.2, margin=0.1))
show(" tab hook top line", line(T, (-6.5, -12.1), (-9.6, -13.5), band=0.2, margin=0.2))
np.save(os.path.join(os.path.dirname(__file__), "tab_pts.npy"), T)
np.save(os.path.join(os.path.dirname(__file__), "beam_pts.npy"), P)
