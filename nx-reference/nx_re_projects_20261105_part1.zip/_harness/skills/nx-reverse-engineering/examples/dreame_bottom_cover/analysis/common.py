"""Scan analysis helpers for the Dreame bottom cover (datum frame of run/intake/alignment.json).

Frame: z=0 top flange plane (+Z out of the flange, material below), y=0 hook-side wall outer face
(part at y<0), x=0 grille end face (part at x>0).
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
import numpy as np

SRC = r"C:\Users\marya\Downloads\dreame_mop_assembly_bottom_cover"
WS = r"C:\NX_MCP_WORKSPACE\dreame_cover"
AN = os.path.join(WS, "an")
ALIGNED = os.path.join(SRC, r"run\intake\aligned_work.stl")
CACHE = os.path.join(AN, "mesh_cache.npz")


def read_stl(path):
    with open(path, "rb") as f:
        f.seek(80)
        n = int(np.frombuffer(f.read(4), "<u4")[0])
        dt = np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")])
        d = np.frombuffer(f.read(n * 50), dt, count=n)
    return d["v"].astype(np.float64)          # (n, 3, 3)


def warp_terms(x, y):
    xs = x / 100.0
    return np.stack([xs ** i * (y / 100.0) ** j for i in range(4) for j in range(2)], axis=1)


def warp_dterms(x, y):
    """d/dx and d/dy of the warp terms."""
    xs, ys = x / 100.0, y / 100.0
    dx = np.stack([(i * xs ** (i - 1) if i else 0 * xs) * ys ** j / 100.0 for i in range(4) for j in range(2)], axis=1)
    dy = np.stack([xs ** i * (j * ys ** (j - 1) if j else 0 * ys) / 100.0 for i in range(4) for j in range(2)], axis=1)
    return dx, dy


def fit_warp(tri):
    """Smooth field dz(x, y) of the top flange (designed flat, z = 0)."""
    c = tri.mean(axis=1)
    nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    a = np.linalg.norm(nrm, axis=1)
    n = nrm / np.maximum(a, 1e-12)[:, None]
    a = a / 2
    rail = (n[:, 2] > 0.95) & (c[:, 1] > -83) & (c[:, 1] < -75) & (np.abs(c[:, 2]) < 1.6)
    beam = (n[:, 2] > 0.95) & (c[:, 1] > -1) & (c[:, 1] < -0.1) & (np.abs(c[:, 2]) < 1.6)
    sel = rail | beam
    X = warp_terms(c[sel, 0], c[sel, 1])
    z, w = c[sel, 2], a[sel]
    keep = np.ones(len(z), bool)
    for _ in range(4):
        sw = np.sqrt(w[keep])
        coef, *_ = np.linalg.lstsq(X[keep] * sw[:, None], z[keep] * sw, rcond=None)
        r = z - X @ coef
        s = np.sqrt(np.average(r[keep] ** 2, weights=w[keep]))
        keep = np.abs(r) < max(3 * s, 0.08)
    return coef, float(s), int(keep.sum())


def dewarp_points(p, coef):
    """Undo the bow: sections rotate with the local slope (plate bending), not a pure z shear."""
    p = np.asarray(p, float)
    q = p.copy()
    x, y, z = p[..., 0].ravel(), p[..., 1].ravel(), p[..., 2].ravel()
    dz = warp_terms(x, y) @ coef
    dtx, dty = warp_dterms(x, y)
    sx, sy = dtx @ coef, dty @ coef
    q[..., 0] = (x + z * sx).reshape(p.shape[:-1])
    q[..., 1] = (y + z * sy).reshape(p.shape[:-1])
    q[..., 2] = (z - dz).reshape(p.shape[:-1])
    return q


class Mesh:
    def __init__(self, tri):
        self.tri = tri
        self.c = tri.mean(axis=1)
        nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        a = np.linalg.norm(nrm, axis=1)
        self.n = nrm / np.maximum(a, 1e-12)[:, None]
        self.a = a / 2
        self.lo = tri.min(axis=1)
        self.hi = tri.max(axis=1)

    def section(self, axis, value, box=None):
        """Segments (m, 2, 3) where the plane axis=value cuts the mesh."""
        m = (self.lo[:, axis] <= value) & (self.hi[:, axis] >= value)
        if box is not None:
            for ax, (a0, a1) in box.items():
                m &= (self.hi[:, ax] >= a0) & (self.lo[:, ax] <= a1)
        t = self.tri[m]
        d = t[:, :, axis] - value
        segs = []
        for i, j, k in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
            # vertex i on one side, j and k on the other
            s = (d[:, i] * d[:, j] < 0) & (d[:, i] * d[:, k] < 0)
            if not s.any():
                continue
            ti, di, dj, dk = t[s], d[s, i], d[s, j], d[s, k]
            p1 = ti[:, i] + (ti[:, j] - ti[:, i]) * (di / (di - dj))[:, None]
            p2 = ti[:, i] + (ti[:, k] - ti[:, i]) * (di / (di - dk))[:, None]
            segs.append(np.stack([p1, p2], axis=1))
        if not segs:
            return np.zeros((0, 2, 3))
        return np.concatenate(segs)

    def sample(self, n, seed=0, mask=None):
        rng = np.random.default_rng(seed)
        a = self.a if mask is None else np.where(mask, self.a, 0.0)
        idx = rng.choice(len(a), size=n, p=a / a.sum())
        u, v = rng.random(n), rng.random(n)
        f = u + v > 1
        u[f], v[f] = 1 - u[f], 1 - v[f]
        t = self.tri[idx]
        return t[:, 0] + (t[:, 1] - t[:, 0]) * u[:, None] + (t[:, 2] - t[:, 0]) * v[:, None], idx


def load(dewarped=True):
    if os.path.exists(CACHE):
        z = np.load(CACHE)
        tri, coef = z["tri"], z["coef"]
    else:
        tri = read_stl(ALIGNED)
        coef, s, nk = fit_warp(tri)
        np.savez(CACHE, tri=tri, coef=coef)
        json.dump({"coef": coef.tolist(), "rms": s, "n": nk}, open(os.path.join(AN, "warp.json"), "w"), indent=1)
    if dewarped:
        tri = dewarp_points(tri, coef)
    return Mesh(tri), coef


def plot_section(ax, segs, axis, **kw):
    from matplotlib.collections import LineCollection
    o = [i for i in range(3) if i != axis]
    lc = LineCollection(segs[:, :, o], **{"linewidths": 0.6, "colors": "k", **kw})
    ax.add_collection(lc)
    ax.set_aspect("equal")
    ax.autoscale()
    return o
