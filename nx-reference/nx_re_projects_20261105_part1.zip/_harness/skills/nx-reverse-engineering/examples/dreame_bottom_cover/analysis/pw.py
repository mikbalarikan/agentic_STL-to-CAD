"""Piecewise line / arc fit of a single-valued section envelope z(u).

env(axis, v0, v1, u0, u1, side, lim_v) -> (u, z) of the top ('top') or bottom ('bot') envelope of stacked sections.
fit(u, z, breaks, kinds) -> list of primitives; kinds: 'L' line, 'F' flat (horizontal), 'A' arc.
Junctions are the intersections of consecutive primitives (nearest to the break).
"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from fit import pts


def env(axis, v0, v1, u0, u1, side="top", zlim=(-19, 4), n=7, du=0.1, ucoord=0):
    P = pts(axis, v0, v1, n, (u0, u1, zlim[0], zlim[1]) if ucoord == 0 else None, step=0.05)
    u, z = P[:, 0], P[:, 1]
    b = np.floor((u - u0) / du).astype(int)
    nb = int((u1 - u0) / du) + 1
    out = []
    for i in range(nb):
        s = b == i
        if s.sum() < 2:
            continue
        zz = z[s]
        if side == "top":
            ref = zz.max(); pick = zz[zz > ref - 0.12]
        else:
            ref = zz.min(); pick = zz[zz < ref + 0.12]
        out.append((u0 + (i + 0.5) * du, np.median(pick)))
    return np.array(out)


def _circ(q):
    A = np.c_[2 * q, np.ones(len(q))]
    sol, *_ = np.linalg.lstsq(A, (q ** 2).sum(1), rcond=None)
    c = sol[:2]; r = np.sqrt(max(sol[2] + c @ c, 1e-9))
    for _ in range(40):
        v = q - c; d = np.linalg.norm(v, axis=1)
        J = np.c_[-v / d[:, None], -np.ones(len(q))]
        dl, *_ = np.linalg.lstsq(J, -(d - r), rcond=None)
        c = c + dl[:2]; r = r + dl[2]
    return c, r, np.linalg.norm(q - c, axis=1) - r


def fit(E, breaks, kinds, trim=0.25):
    prims = []
    for k, kind in enumerate(kinds):
        a, b = breaks[k], breaks[k + 1]
        s = (E[:, 0] >= a + trim) & (E[:, 0] <= b - trim)
        q = E[s]
        if len(q) < 4:
            prims.append({"kind": kind, "n": len(q)}); continue
        if kind == "F":
            z0 = float(np.median(q[:, 1]))
            prims.append({"kind": "F", "z": z0, "rms": float(np.sqrt(((q[:, 1] - z0) ** 2).mean())), "n": len(q)})
        elif kind == "L":
            c = q.mean(0); _, sv, vt = np.linalg.svd(q - c); d = vt[0]
            if d[0] < 0:
                d = -d
            r = (q - c) @ np.array([-d[1], d[0]])
            prims.append({"kind": "L", "p": c, "d": d, "ang": float(np.degrees(np.arctan2(d[1], d[0]))), "rms": float(np.sqrt((r ** 2).mean())), "n": len(q)})
        else:
            c, r, res = _circ(q)
            prims.append({"kind": "A", "c": c, "r": float(r), "rms": float(np.sqrt((res ** 2).mean())), "n": len(q),
                          "concave_up": bool(c[1] > q[:, 1].mean())})
    return prims


def _inter(p1, p2, near):
    """Intersection point of two primitives nearest to u = near."""
    def as_line(p):
        if p["kind"] == "F":
            return np.array([0.0, p["z"]]), np.array([1.0, 0.0])
        return p["p"], p["d"]
    if p1["kind"] != "A" and p2["kind"] != "A":
        a, da = as_line(p1); b, db = as_line(p2)
        M = np.c_[da, -db]
        if abs(np.linalg.det(M)) < 1e-9:
            return None
        t = np.linalg.solve(M, b - a)
        return a + da * t[0]
    if p1["kind"] == "A" and p2["kind"] == "A":
        c1, r1, c2, r2 = p1["c"], p1["r"], p2["c"], p2["r"]
        d = np.linalg.norm(c2 - c1)
        if d < 1e-9 or d > r1 + r2 or d < abs(r1 - r2):
            # tangent-ish: closest point between the circles
            e = (c2 - c1) / max(d, 1e-9)
            return (c1 + e * r1 * np.sign(r1 + r2 - d if d > abs(r1 - r2) else 1) + c2 - e * r2 * 1) / 2 if d > abs(r1 - r2) else c1 + e * (r1 if r1 > r2 else -r1)
        a = (r1 ** 2 - r2 ** 2 + d ** 2) / (2 * d)
        h = np.sqrt(max(r1 ** 2 - a ** 2, 0))
        m = c1 + (c2 - c1) * a / d
        n = np.array([-(c2 - c1)[1], (c2 - c1)[0]]) / d
        cand = [m + n * h, m - n * h]
        return min(cand, key=lambda p: abs(p[0] - near))
    arc, ln = (p1, p2) if p1["kind"] == "A" else (p2, p1)
    a, da = as_line(ln)
    w = a - arc["c"]
    bq = 2 * (w @ da); cq = w @ w - arc["r"] ** 2
    disc = bq * bq - 4 * cq
    if disc < 0:
        t = -bq / 2            # tangent / near miss: foot of the centre on the line
        return a + da * t
    ts = [(-bq + np.sqrt(disc)) / 2, (-bq - np.sqrt(disc)) / 2]
    cand = [a + da * t for t in ts]
    return min(cand, key=lambda p: abs(p[0] - near))


def report(name, E, breaks, kinds):
    prims = fit(E, breaks, kinds)
    print(f"== {name}  ({len(E)} envelope points)")
    for k, p in enumerate(prims):
        a, b = breaks[k], breaks[k + 1]
        if "rms" not in p:
            print(f"   [{a:7.2f},{b:7.2f}] {p['kind']} too few points"); continue
        if p["kind"] == "F":
            print(f"   [{a:7.2f},{b:7.2f}] flat  z={p['z']:.3f}  rms={p['rms']:.3f}")
        elif p["kind"] == "L":
            print(f"   [{a:7.2f},{b:7.2f}] line  through ({p['p'][0]:.3f},{p['p'][1]:.3f}) angle {p['ang']:.2f} deg  rms={p['rms']:.3f}")
        else:
            print(f"   [{a:7.2f},{b:7.2f}] arc   c=({p['c'][0]:.3f},{p['c'][1]:.3f}) r={p['r']:.3f} {'concave-up' if p['concave_up'] else 'convex-up'} rms={p['rms']:.3f}")
    js = []
    for k in range(len(prims) - 1):
        if "rms" in prims[k] and "rms" in prims[k + 1]:
            j = _inter(prims[k], prims[k + 1], breaks[k + 1])
            js.append(j)
            if j is not None:
                print(f"   junction {k}/{k+1}: ({j[0]:.3f}, {j[1]:.3f})")
    return prims, js
