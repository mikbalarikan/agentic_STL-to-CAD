"""Grille end: outer walls, corner cell cavity, underside arcs, flange details."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from fit import pts, line, circle, level, show

P = pts(0, 1.5, 6.5, 7, (-86, -62, -17, 1.5))
show("corner outer wall arc (about the channel centre?)", circle(P, (-55.75, 0.0), 24.7, 184, 214, band=0.5))
show("corner outer wall arc, free", circle(P, (-60.0, -2.0), 20.5, 180, 220, band=0.6))
show("corner outer wall lower line", line(P, (-78.6, -9.5), (-76.6, -13.0), band=0.25))
show("corner outer wall upper line", line(P, (-80.4, -2.3), (-80.2, -5.5), band=0.25))
print("cell cavity roof z", level(P, 1, -78, -74, -3.6, -3.0))
print("cell cavity floor z", level(P, 1, -74, -69, -13.3, -12.7))
show("cell cavity outer wall", line(P, (-78.3, -5.5), (-75.5, -11.5), band=0.3))
show("cell cavity inner wall", line(P, (-72.2, -5.0), (-68.5, -11.5), band=0.3))
print("underside z (y -70..-45)", level(P, 1, -70, -45, -15.3, -14.6))
print("flange underside z", level(P, 1, -83, -81, -2.2, -1.6))
print("flange outer y", level(P, 0, -84.3, -83.3, -1.5, -0.4))
# hook-side wall and underside, x 1.5..9.5
H = pts(0, 1.5, 9.5, 9, (-20, 2, -16.5, 0))
print("hook wall outer y", level(H, 0, 0.0, 0.6, -4.5, -2.3))
print("hook wall inner y", level(H, 0, -2.2, -1.4, -5.2, -2.3))
print("hook wall top z", level(H, 1, -1.5, 0.0, -2.2, -1.6))
show("hook underside arc (centre guess of the top arc)", circle(H, (-17.73, 5.13), 21.2, 285, 325, band=0.5))
show("hook underside arc, lower part", circle(H, (-17.73, 5.13), 21.0, 268, 290, band=0.5))
show("hook top arc", circle(H, (-17.73, 5.13), 19.1, 290, 328, band=0.4))
print("hook underside flat z (y -30..-14)", level(H, 1, -30, -14, -15.3, -14.6))
# x 11..20: hook block
B = pts(0, 11.0, 20.0, 9, (-20, 3, -16.5, 2))
print("block top z (y -4.5..-0.5), x 11..13.5:", level(pts(0, 11.0, 13.5, 5, (-20, 3, -16.5, 2)), 1, -4.5, -0.5, 0.0, 1.0))
print("block top z (y -4..-1), x 14.5..19:", level(pts(0, 14.5, 19.0, 5, (-20, 3, -16.5, 2)), 1, -4.0, -1.0, 0.0, 1.2))
show("block inner arc", circle(B, (-22.27, 1.47), 15.87, 300, 358, band=0.5))
show("block inner upper line", line(B, (-7.6, -4.8), (-5.9, -0.8), band=0.25))
show("block underside arc", circle(B, (-17.73, 5.13), 21.2, 285, 330, band=0.6))
# end wall x 0.2..0.8
W = pts(0, 0.25, 0.75, 3, (-86, 2, -17, 1))
print("end wall top z hook trough", level(W, 1, -28, -8, -10.8, -10.0))
print("end wall top z rail trough", level(W, 1, -62, -48, -10.8, -10.0))
show("end wall rail slope", line(W, (-72.5, -1.0), (-66.5, -9.5), band=0.3))
show("end wall hook slope", line(W, (-5.5, -9.6), (-2.0, -6.0), band=0.3))
show("end wall hump side rail", line(W, (-45.2, -10.0), (-44.0, -8.5), band=0.25, margin=0.1))
show("end wall hump side hook", line(W, (-31.9, -8.6), (-30.9, -10.1), band=0.25, margin=0.1))
# tunnels
for x in (2.0, 10.0, 19.0):
    T = pts(0, x - 0.4, x + 0.4, 3, (-44, -30, -15.2, -11.5))
    for g in ((-38.4 - 0.1375 * (x - 0.9) + 0.38, "A"), (-33.95 - 0.1375 * (x - 0.9) + 0.38, "B")):
        r = circle(T, (g[0], -13.7), 1.5, 20, 160, band=0.35)
        show(f"tunnel {g[1]} at x={x}", r)
