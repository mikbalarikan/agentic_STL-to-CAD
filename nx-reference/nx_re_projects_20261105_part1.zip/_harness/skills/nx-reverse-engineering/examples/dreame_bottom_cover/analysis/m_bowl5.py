"""Bowl A: general cone fit; bowl B / A meridian fits by circle / ellipse; thickness of the skins."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from scipy.optimize import least_squares
from common import AN


def cone_res(p, Q):
    ax, ay, tx, ty, r0, k = p               # axis point at z=0, axis slope, radius at h=0, dr/dh
    d = np.array([tx, ty, 1.0]); d /= np.linalg.norm(d)
    w = Q - np.array([ax, ay, 0.0])
    h = w @ d
    rad = np.linalg.norm(w - np.outer(h, d), axis=1)
    return (rad - (r0 + k * h)) / np.sqrt(1 + k * k)


A = np.load(os.path.join(AN, "bowlA_skin.npy"))
for zlo, zhi in ((-10, -1), (-9, -2), (-11, -0.6)):
    Q = A[(A[:, 2] > zlo) & (A[:, 2] < zhi)]
    best = None
    for start in ((169.3, -20.4, 0, 0, 16, 0.6), (171.5, -20.3, 0.25, 0.05, 14, 0.4), (170, -20.5, -0.1, 0.1, 15, 0.5)):
        r = least_squares(cone_res, start, args=(Q,), loss="soft_l1", f_scale=0.1)
        if best is None or r.cost < best.cost:
            best = r
    p = best.x
    res = cone_res(p, Q)
    print(f"A cone z[{zlo},{zhi}]: axis at z=0 ({p[0]:.3f},{p[1]:.3f}) slope ({p[2]:.4f},{p[3]:.4f}) "
          f"tilt {np.degrees(np.arctan(np.hypot(p[2], p[3]))):.2f} deg az {np.degrees(np.arctan2(p[3], p[2])):.0f}, r0={p[4]:.3f} dr/dh={p[5]:.4f} "
          f"(half angle {np.degrees(np.arctan(p[5])):.2f}) rms={np.sqrt((res**2).mean()):.3f} p95={np.percentile(np.abs(res), 95):.3f} n={len(Q)}")
# vertical-axis cone for comparison
Q = A[(A[:, 2] > -10) & (A[:, 2] < -1)]
r = least_squares(lambda p: cone_res(np.r_[p[:2], 0, 0, p[2:]], Q), (169.3, -20.4, 16, 0.6), loss="soft_l1", f_scale=0.1)
res = cone_res(np.r_[r.x[:2], 0, 0, r.x[2:]], Q)
print(f"A vertical cone: axis ({r.x[0]:.3f},{r.x[1]:.3f}) r0={r.x[2]:.3f} dr/dh={r.x[3]:.4f} (half angle {np.degrees(np.arctan(r.x[3])):.2f}) rms={np.sqrt((res**2).mean()):.3f} p95={np.percentile(np.abs(res), 95):.3f}")


def circ_res(p, R, Z):
    rc, zc, rad = p
    return np.hypot(R - rc, Z - zc) - rad


def ell_res(p, R, Z):
    rc, zc, a, b = p
    # approximate distance: scaled algebraic
    t = np.arctan2((Z - zc) / b, (R - rc) / a)
    return np.hypot(R - (rc + a * np.cos(t)), Z - (zc + b * np.sin(t)))


for nm in ("B", "A"):
    M = np.load(os.path.join(AN, f"bowl{nm}_mer_vertical.npy"))
    R, Z = M[:, 0], M[:, 1]
    print(f"bowl {nm} meridian (vertical axis) {len(M)} rows; r range {R.min():.2f}..{R.max():.2f}")
    for zlo, zhi in ((-13.8, -0.5), (-10, -0.5), (-13.8, -9)):
        s = (Z >= zlo) & (Z <= zhi)
        c = least_squares(circ_res, (0.0, 0.0, 17.0), args=(R[s], Z[s]))
        print(f"   circle z[{zlo},{zhi}]: centre r={c.x[0]:.3f} z={c.x[1]:.3f} R={c.x[2]:.3f} rms={np.sqrt((c.fun**2).mean()):.4f} max={np.abs(c.fun).max():.3f}")
    e = least_squares(ell_res, (0.0, 0.0, 17.0, 14.5), args=(R, Z))
    print(f"   ellipse: centre r={e.x[0]:.3f} z={e.x[1]:.3f} a={e.x[2]:.3f} b={e.x[3]:.3f} rms={np.sqrt((e.fun**2).mean()):.4f} max={np.abs(e.fun).max():.3f}")
    for zlo, zhi in ((-10, -1),):
        s = (Z >= zlo) & (Z <= zhi)
        k = np.polyfit(Z[s], R[s], 1)
        print(f"   line z[{zlo},{zhi}]: r = {k[0]:.4f} z + {k[1]:.3f}  rms={np.sqrt(((np.polyval(k, Z[s]) - R[s])**2).mean()):.4f}")
