"""Hook-side floor at the bowl end: skewed cylinder?  Find the skew direction and the profile z(y')."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from scipy.optimize import minimize_scalar
from common import AN
from pw import fit as pwfit, report

z = np.load(os.path.join(AN, "hmap.npz"))
ext, res = z["ext"], float(z["res"])
X0 = 170.8
for which in ("bot", "top"):
    h = z[which]
    ys = ext[2] + (np.arange(h.shape[0]) + 0.5) * res
    xs = ext[0] + (np.arange(h.shape[1]) + 0.5) * res
    XX, YY = np.meshgrid(xs, ys)
    if which == "bot":
        s = (XX > 171.5) & (XX < 192.2) & (YY > -21.0) & (YY < -2.2) & np.isfinite(h) & (h < -2.0)
    else:   # tray floor seen from above
        s = (XX > 183.0) & (XX < 189.5) & (YY > -10.2) & (YY < -3.0) & np.isfinite(h) & (h < -1.5)
    P = np.c_[XX[s], YY[s], h[s]]
    print(f"{which}: {len(P)} cells")

    def scatter(k):
        yp = P[:, 1] + k * (P[:, 0] - X0)
        o = np.argsort(yp)
        b = np.floor((yp - yp.min()) / 0.4).astype(int)
        tot, n = 0.0, 0
        for i in np.unique(b):
            v = P[b == i, 2]
            if len(v) > 8:
                tot += np.var(v) * len(v); n += len(v)
        return tot / n
    r = minimize_scalar(scatter, bounds=(0.0, 0.8), method="bounded")
    k = r.x
    print(f"  best skew dy/dx = {k:.4f} ({np.degrees(np.arctan(k)):.2f} deg to X), in-bin sd {np.sqrt(r.fun):.3f}; sd at k=0: {np.sqrt(scatter(0.0)):.3f}")
    yp = P[:, 1] + k * (P[:, 0] - X0)
    E = []
    for y0 in np.arange(yp.min(), yp.max(), 0.4):
        v = P[(yp >= y0) & (yp < y0 + 0.4), 2]
        if len(v) > 8:
            E.append((y0 + 0.2, np.median(v)))
    E = np.array(E)
    np.save(os.path.join(AN, f"hookfloor_{which}.npy"), E)
    print("  profile y' range", E[:, 0].min().round(2), E[:, 0].max().round(2))
    report(f"  {which} one arc", E, [E[:, 0].min(), E[:, 0].max()], "A")
    mid = (E[:, 0].min() + E[:, 0].max()) / 2
    report(f"  {which} two arcs", E, [E[:, 0].min(), mid, E[:, 0].max()], "AA")
    for yq in np.arange(-20, 8.1, 4):
        i = np.argmin(np.abs(E[:, 0] - yq))
        print(f"     y'={E[i, 0]:6.2f} z={E[i, 1]:7.3f}")
