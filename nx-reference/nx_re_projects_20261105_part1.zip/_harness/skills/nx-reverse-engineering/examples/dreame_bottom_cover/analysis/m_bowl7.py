"""Bowl A as a revolve about an axis tilted 30 deg in XZ: meridian, comparison with bowl B's meridian."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import least_squares, minimize
from common import AN
from m_bowl6 import rh, spread, A

Q = A[(A[:, 2] > -13.8) & (A[:, 2] < -0.5)]
fig, ax = plt.subplots(figsize=(12, 10))
MB = np.load(os.path.join(AN, "bowlB_mer_vertical.npy"))
ax.plot(MB[:, 0], MB[:, 1], "k.-", ms=3, label="bowl B meridian (vertical axis)")
for tilt, col in ((25.0, "tab:blue"), (30.0, "tab:red"), (35.0, "tab:green")):
    tx = np.tan(np.radians(tilt))
    r = minimize(lambda p: spread((p[0], p[1], tx), Q, ty=0.0), (169.7, -20.7), method="Nelder-Mead", options={"xatol": 0.003, "fatol": 1e-9})
    rad, h = rh(Q, r.x[0], r.x[1], tx, 0.0)
    rows = []
    for hh in np.arange(h.min() + 0.2, h.max() - 0.1, 0.2):
        s = np.abs(h - hh) < 0.1
        if s.sum() > 20:
            rows.append((np.median(rad[s]), hh, rad[s].std(), s.sum()))
    rows = np.array(rows)
    np.save(os.path.join(AN, f"bowlA_mer_tilt{int(tilt)}.npy"), rows)
    R, H = rows[:, 0], rows[:, 1]
    ax.plot(R, H, ".-", color=col, ms=3, label=f"bowl A, axis tilt {tilt:.0f} deg at ({r.x[0]:.2f},{r.x[1]:.2f}) sd {np.sqrt(r.fun):.3f}")
    print(f"tilt {tilt}: axis at z=0 ({r.x[0]:.3f},{r.x[1]:.3f}) sd {np.sqrt(r.fun):.4f}; h range {H.min():.2f}..{H.max():.2f}; rad range {R.min():.2f}..{R.max():.2f}")
    for hlo, hhi in ((H.min(), H.max()), (H.min() + 4, H.max() - 0.5), (H.min(), H.min() + 4)):
        s = (H >= hlo) & (H <= hhi)
        c = least_squares(lambda p: np.hypot(R[s] - p[0], H[s] - p[1]) - p[2], (4.0, 0.0, 12.0))
        print(f"   circle h[{hlo:.1f},{hhi:.1f}]: centre rad={c.x[0]:.3f} h={c.x[1]:.3f} R={c.x[2]:.3f} rms={np.sqrt((c.fun**2).mean()):.4f} max={np.abs(c.fun).max():.3f}")
ax.set_aspect("equal"); ax.grid(True, lw=0.3); ax.legend(); ax.set_xlabel("radius from axis"); ax.set_ylabel("height along axis")
ax.set_xticks(np.arange(0, 20, 1)); ax.set_yticks(np.arange(-18, 8, 1))
fig.tight_layout(); fig.savefig(os.path.join(AN, "bowl_meridians.png"), dpi=80)
