"""Overview: datum check, warp, height maps from above and below."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, AN

raw, coef = load(dewarped=False)
m, _ = load(dewarped=True)
print("faces", len(m.tri), "bbox raw", raw.lo.min(0).round(2), raw.hi.max(0).round(2))
print("bbox dewarped", m.lo.min(0).round(2), m.hi.max(0).round(2))
print("warp coef", np.round(coef, 4))


def plane_stats(mesh, mask, axis, name):
    c, a = mesh.c[mask], mesh.a[mask]
    v = c[:, axis]
    med = np.average(v, weights=a)
    r = v - med
    print(f"{name}: n={mask.sum()} area={a.sum():.1f} mean={med:.4f} rms={np.sqrt(np.average(r**2, weights=a)):.4f} "
          f"p02={np.percentile(v, 2):.3f} p98={np.percentile(v, 98):.3f}")


for nm, mesh in (("raw", raw), ("dewarped", m)):
    c, n = mesh.c, mesh.n
    plane_stats(mesh, (n[:, 2] > 0.97) & (np.abs(c[:, 2]) < 1.5) & (c[:, 1] < -75), 2, nm + " rail top z")
    plane_stats(mesh, (n[:, 2] > 0.97) & (np.abs(c[:, 2]) < 1.5) & (c[:, 1] > -1.2), 2, nm + " beam top z")
    plane_stats(mesh, (n[:, 1] > 0.97) & (c[:, 1] > -1.0) & (c[:, 0] > 30) & (c[:, 0] < 150), 1, nm + " hook wall y")
    plane_stats(mesh, (n[:, 0] < -0.97) & (c[:, 0] < 1.0), 0, nm + " grille end x")
    plane_stats(mesh, (n[:, 0] > 0.97) & (c[:, 0] > 190), 0, nm + " bowl end x")
    plane_stats(mesh, (n[:, 1] < -0.97) & (c[:, 1] < -82), 1, nm + " rail outer y")

# height maps
P, idx = m.sample(4_000_000, seed=1)
res = 0.2
x0, x1, y0, y1 = -2, 197, -90, 4
nx, ny = int((x1 - x0) / res), int((y1 - y0) / res)
ix = np.clip(((P[:, 0] - x0) / res).astype(int), 0, nx - 1)
iy = np.clip(((P[:, 1] - y0) / res).astype(int), 0, ny - 1)
top = np.full((ny, nx), np.nan)
bot = np.full((ny, nx), np.nan)
flat = iy * nx + ix
o = np.argsort(P[:, 2])
tt = np.full(ny * nx, np.nan); tt[flat[o]] = P[o, 2]           # last write = max z
bb = np.full(ny * nx, np.nan); bb[flat[o[::-1]]] = P[o[::-1], 2]  # last write = min z
top, bot = tt.reshape(ny, nx), bb.reshape(ny, nx)
np.savez(os.path.join(AN, "hmap.npz"), top=top, bot=bot, ext=np.array([x0, x1, y0, y1]), res=res)
for nm, h, vmin, vmax in (("top", top, -16, 2), ("bot", bot, -18, 0), ("top_fine", top, -1.5, 0.6), ("thick", top - bot, 0, 6)):
    fig, ax = plt.subplots(figsize=(24, 12))
    im = ax.imshow(h, origin="lower", extent=[x0, x1, y0, y1], cmap="turbo", vmin=vmin, vmax=vmax, interpolation="nearest")
    ax.set_xticks(np.arange(0, 200, 10)); ax.set_yticks(np.arange(-90, 5, 10))
    ax.grid(True, lw=0.3, color="w", alpha=0.6)
    ax.set_title(f"{nm}: {'max z seen from +Z' if 'top' in nm else 'min z seen from -Z' if nm == 'bot' else 'top - bottom'} (de-warped)")
    plt.colorbar(im, ax=ax, shrink=0.6)
    fig.tight_layout(); fig.savefig(os.path.join(AN, f"hmap_{nm}.png"), dpi=70); plt.close(fig)
print("done")
