"""Deck (roof) of the bowl end: height map with contours + tests of simple surface models."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, AN

m, _ = load(True)
P, idx = m.sample(1_500_000, seed=7, mask=(m.c[:, 0] > 150))
N = m.n[idx]
up = (N[:, 2] > 0.6) & (P[:, 2] > -0.6) & (P[:, 0] > 160) & (P[:, 1] > -84.5) & (P[:, 1] < 4.5)
Q = P[up]
np.save(os.path.join(AN, "deck_pts.npy"), Q)
fig, ax = plt.subplots(figsize=(13, 20))
sc = ax.scatter(Q[:, 0], Q[:, 1], c=Q[:, 2], s=0.6, cmap="turbo", vmin=-0.5, vmax=3.0)
ax.tricontour(Q[::7, 0], Q[::7, 1], Q[::7, 2], levels=np.arange(0.0, 3.01, 0.25), colors="k", linewidths=0.4)
ax.set_aspect("equal"); ax.set_xticks(np.arange(160, 196, 2)); ax.set_yticks(np.arange(-84, 6, 2)); ax.grid(True, lw=0.2)
ax.tick_params(labelsize=7)
plt.colorbar(sc, ax=ax, shrink=0.5); ax.set_title("up-facing faces near the top, bowl end (z colour, contours every 0.25)")
fig.tight_layout(); fig.savefig(os.path.join(AN, "deck_map.png"), dpi=75); plt.close(fig)

# model tests on the sloped deck (z > 0.45 and x < 189.3)
S = Q[(Q[:, 2] > 0.5) & (Q[:, 0] < 189.2) & (Q[:, 0] > 172) & (Q[:, 1] < -14) & (Q[:, 1] > -76)]
print("sloped deck points", len(S))
# 1. plane
Aa = np.c_[S[:, 0], S[:, 1], np.ones(len(S))]
c, *_ = np.linalg.lstsq(Aa, S[:, 2], rcond=None)
print("plane z = %.4f x + %.4f y + %.3f  rms %.3f" % (c[0], c[1], c[2], np.sqrt(((Aa @ c - S[:, 2]) ** 2).mean())))
# 2. cylinder with axis along y: z = f(x) only
for deg in (1, 2):
    k = np.polyfit(S[:, 0], S[:, 2], deg)
    print(f"z = poly{deg}(x): rms {np.sqrt(((np.polyval(k, S[:, 0]) - S[:, 2])**2).mean()):.3f}", np.round(k, 4))
# 3. cones about each bowl axis
for nm, axy in (("B", (169.19, -56.18)), ("A", (169.99, -20.74))):
    r = np.hypot(S[:, 0] - axy[0], S[:, 1] - axy[1])
    k = np.polyfit(r, S[:, 2], 1)
    res = np.polyval(k, r) - S[:, 2]
    print(f"cone about {nm}: z = {k[0]:.4f} r + {k[1]:.3f} rms {np.sqrt((res**2).mean()):.3f}")
# 4. two planes split at the ridge line y = -37: per side a plane
for nm, s in (("rail side y<-37", S[:, 1] < -37.0), ("hook side y>-37", S[:, 1] > -37.0)):
    q = S[s]
    Aa = np.c_[q[:, 0], q[:, 1], np.ones(len(q))]
    c, *_ = np.linalg.lstsq(Aa, q[:, 2], rcond=None)
    res = Aa @ c - q[:, 2]
    print(f"plane {nm}: z = {c[0]:.4f} x + {c[1]:.4f} y + {c[2]:.3f}  rms {np.sqrt((res**2).mean()):.3f} p95 {np.percentile(np.abs(res),95):.3f} n={len(q)}")
# 5. four planes: split also at the bowl axes y = -56.2, -20.7
for y0, y1 in ((-76, -56.2), (-56.2, -37), (-37, -20.7), (-20.7, -14)):
    q = S[(S[:, 1] > y0) & (S[:, 1] < y1)]
    if len(q) < 50:
        continue
    Aa = np.c_[q[:, 0], q[:, 1], np.ones(len(q))]
    c, *_ = np.linalg.lstsq(Aa, q[:, 2], rcond=None)
    res = Aa @ c - q[:, 2]
    print(f"plane y[{y0},{y1}]: z = {c[0]:.4f} x + {c[1]:.4f} y + {c[2]:.3f}  rms {np.sqrt((res**2).mean()):.3f} p95 {np.percentile(np.abs(res),95):.3f} n={len(q)}")
# flat levels
for nm, s in (("end strip x>189.8", (Q[:, 0] > 189.9) & (Q[:, 0] < 192.3) & (Q[:, 1] > -74) & (Q[:, 1] < -14)),
              ("rail flange x 150..180 y<-76", (Q[:, 0] < 180) & (Q[:, 1] < -76) & (Q[:, 1] > -83)),
              ("hook deck x184..192 y -20..-12", (Q[:, 0] > 184) & (Q[:, 1] > -20) & (Q[:, 1] < -12))):
    z = Q[s, 2]
    print(f"level {nm}: median {np.median(z):.3f} p10 {np.percentile(z,10):.3f} p90 {np.percentile(z,90):.3f} n={len(z)}")
