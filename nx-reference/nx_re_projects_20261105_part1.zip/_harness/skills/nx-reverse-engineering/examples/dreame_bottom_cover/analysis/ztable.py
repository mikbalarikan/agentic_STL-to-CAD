"""Text table of the height maps. usage: ztable.py top|bot x0 x1 dx y0 y1 dy"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import AN

which = sys.argv[1]
x0, x1, dx, y0, y1, dy = [float(v) for v in sys.argv[2:8]]
z = np.load(os.path.join(AN, "hmap.npz"))
h, ext, res = z[which], z["ext"], float(z["res"])
xs = np.arange(x0, x1 + 1e-9, dx)
ys = np.arange(y1, y0 - 1e-9, -dy)
print("y\\x   " + " ".join(f"{x:6.1f}" for x in xs))
for y in ys:
    row = []
    for x in xs:
        i, j = int((y - ext[2]) / res), int((x - ext[0]) / res)
        w = h[max(i - 1, 0):i + 2, max(j - 1, 0):j + 2]
        v = np.nanmedian(w) if np.isfinite(w).any() else np.nan
        row.append("   .  " if np.isnan(v) else f"{v:6.2f}")
    print(f"{y:6.1f} " + " ".join(row))
