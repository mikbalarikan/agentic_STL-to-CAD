"""Scan <-> CAD deviation (run with the cadgenbench venv: needs open3d).

usage: dev.py <cad.stl> <tag> [box x0 x1 y0 y1 z0 z1] [raw] [n N]
Writes an/dev_<tag>.json and an/dev_<tag>_{top,bot}.png (signed scan->CAD distance, + = scan outside the CAD).
The scan is the datum-aligned working copy, de-warped unless 'raw'.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import open3d as o3d
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import load, read_stl, AN, Mesh

args = sys.argv[1:]
cad_path, tag = args[0], args[1]
raw = "raw" in args
box = None
if "box" in args:
    i = args.index("box")
    box = [float(v) for v in args[i + 1:i + 7]]
n = int(args[args.index("n") + 1]) if "n" in args else 400_000

scan, _ = load(dewarped=not raw)
cad = Mesh(read_stl(cad_path))


def scene_of(mesh):
    v = mesh.tri.reshape(-1, 3).astype(np.float32)
    f = np.arange(len(v), dtype=np.uint32).reshape(-1, 3)
    s = o3d.t.geometry.RaycastingScene()
    s.add_triangles(o3d.core.Tensor(v), o3d.core.Tensor(f))
    return s


def closest(scene, mesh, pts):
    r = scene.compute_closest_points(o3d.core.Tensor(pts.astype(np.float32)))
    q = r["points"].numpy().astype(np.float64)
    tid = r["primitive_ids"].numpy()
    d = pts - q
    dist = np.linalg.norm(d, axis=1)
    sign = np.sign(np.einsum("ij,ij->i", d, mesh.n[tid]))
    sign[sign == 0] = 1.0
    return dist, sign, tid


def stats(d):
    a = np.abs(d)
    if not len(a):
        return {"n": 0}
    return {"n": int(len(a)), "rms": float(np.sqrt((a ** 2).mean())), "mean_signed": float(d.mean()), "p50": float(np.percentile(a, 50)),
            "p90": float(np.percentile(a, 90)), "p95": float(np.percentile(a, 95)), "p99": float(np.percentile(a, 99)), "max": float(a.max()),
            "over_0.3": float((a > 0.3).mean()), "over_0.8": float((a > 0.8).mean())}


def inbox(p):
    if box is None:
        return np.ones(len(p), bool)
    return ((p[:, 0] >= box[0]) & (p[:, 0] <= box[1]) & (p[:, 1] >= box[2]) & (p[:, 1] <= box[3]) & (p[:, 2] >= box[4]) & (p[:, 2] <= box[5]))


def artefact(p):
    """Scan points that are scanner artefacts (single zero-thickness sheets, no second surface), not part geometry:
    A = sheet above / outside the hook-side beam, B = sheet under the rail foot and webbing across the opening edges."""
    x, y, z = p[:, 0], p[:, 1], p[:, 2]
    a = ((y > -6.5) & (z > 1.3) & (x < 192)) | ((y > 0.5) & (x < 162.5)) | ((y > -0.2) & (z > 0.6) & (x < 162.5))
    pads = np.zeros(len(p), bool)
    for x0 in (30.7, 89.0, 147.3):
        pads |= (x > x0 - 1.5) & (x < x0 + 15.5) & (y > -74.2) & (y < -66.9) & (z > -17.7)
    b = ((z < -16.45) & ~pads) | ((x > 21.5) & (x < 170.3) & (y > -66.9) & (y < -5.2) & (z < -14.9))
    b |= (x < 27.5) & (y > -44.0) & (z < -15.12)          # sheet under the hook-side half of the grille end
    return a | b


cs, ss = scene_of(cad), scene_of(scan)
P, idx = scan.sample(n, seed=11)
keep0 = inbox(P)
art = artefact(P)
P_all, idx_all = P[keep0], idx[keep0]
d, sg, _ = closest(cs, cad, P_all)
s2c_all = d * sg
m_ok = ~art[keep0]
P, s2c = P_all[m_ok], s2c_all[m_ok]
Q, qidx = cad.sample(max(50_000, n // 2), seed=13)
Q = Q[inbox(Q)]
d2, _, _ = closest(ss, scan, Q)
# CAD points whose nearest scan point is far are unobserved (hidden pockets, occluded faces): report them apart
out = {"cad": cad_path, "scan": "raw" if raw else "de-warped", "box": box, "scan_to_cad": stats(s2c), "scan_to_cad_unmasked": stats(s2c_all),
       "artefact_share": float(art[keep0].mean()), "cad_to_scan": stats(d2), "cad_to_scan_observed_lt_1.5": stats(d2[d2 < 1.5]),
       "cad_unobserved_share": float((d2 >= 1.5).mean()),
       "cad_bbox": [cad.lo.min(0).round(3).tolist(), cad.hi.max(0).round(3).tolist()]}
# per x band
bands = {}
for x0 in range(0, 200, 20):
    s = (P[:, 0] >= x0) & (P[:, 0] < x0 + 20)
    if s.sum() > 100:
        st = stats(s2c[s])
        bands[f"x{x0}-{x0+20}"] = {k: round(st[k], 3) for k in ("rms", "p95", "max", "over_0.3")}
out["scan_to_cad_by_x"] = bands
json.dump(out, open(os.path.join(AN, f"dev_{tag}.json"), "w"), indent=1)
print(json.dumps({k: out[k] for k in ("scan_to_cad", "scan_to_cad_unmasked", "artefact_share", "cad_to_scan", "cad_to_scan_observed_lt_1.5", "cad_unobserved_share")}, indent=1))
for k, v in bands.items():
    print(k, v)
np.savez_compressed(os.path.join(AN, f"dev_{tag}.npz"), P=P.astype(np.float32), d=s2c.astype(np.float32), Q=Q.astype(np.float32), d2=d2.astype(np.float32))

N = scan.n[idx_all][m_ok]
lim = 1.0
ext = box if box is not None else [-3, 197, -88, 6, -20, 10]
fig, axs = plt.subplots(3, 1, figsize=(22, 30 * (ext[3] - ext[2]) / (ext[1] - ext[0]) + 4))
for ax, (ttl, sel) in zip(axs, (("scan faces seen from +Z (normal up)", N[:, 2] > 0.2), ("scan faces seen from -Z (normal down)", N[:, 2] < -0.2),
                                ("CAD -> scan distance (CAD points; unsigned)", None))):
    if sel is not None:
        o = np.argsort(np.abs(s2c[sel]))
        sc = ax.scatter(P[sel][o, 0], P[sel][o, 1], c=s2c[sel][o], s=0.6, cmap="coolwarm", vmin=-lim, vmax=lim)
    else:
        o = np.argsort(d2)
        sc = ax.scatter(Q[o, 0], Q[o, 1], c=d2[o], s=0.6, cmap="viridis", vmin=0, vmax=lim)
    ax.set_aspect("equal"); ax.set_xlim(ext[0], ext[1]); ax.set_ylim(ext[2], ext[3]); ax.set_title(ttl)
    ax.set_xticks(np.arange(np.ceil(ext[0] / 10) * 10, ext[1], 10)); ax.set_yticks(np.arange(np.ceil(ext[2] / 10) * 10, ext[3], 10)); ax.grid(True, lw=0.2)
    plt.colorbar(sc, ax=ax, shrink=0.7)
fig.tight_layout(); fig.savefig(os.path.join(AN, f"dev_{tag}.png"), dpi=60); plt.close(fig)
