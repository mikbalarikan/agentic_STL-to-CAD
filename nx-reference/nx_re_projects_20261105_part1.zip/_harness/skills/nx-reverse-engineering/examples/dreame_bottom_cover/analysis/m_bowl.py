"""Bowls: are they surfaces of revolution about a vertical axis?  r(theta, z) maps of the concave skins."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import minimize
from common import load, AN

m, _ = load(True)
P, idx = m.sample(1_500_000, seed=3, mask=(m.c[:, 0] > 150))
N = m.n[idx]


def concave(axis_xy, th0, th1, zlo=-14.2, zhi=-0.4, rmax=20.0):
    v = P[:, :2] - np.asarray(axis_xy)
    r = np.linalg.norm(v, axis=1)
    th = np.degrees(np.arctan2(v[:, 1], v[:, 0]))
    inward = -(N[:, 0] * v[:, 0] + N[:, 1] * v[:, 1]) / np.maximum(r, 1e-9)
    s = (r < rmax) & (th >= th0) & (th <= th1) & (P[:, 2] >= zlo) & (P[:, 2] <= zhi) & (inward > 0.15) & (N[:, 2] > -0.05)
    return s, r, th


def spread(axis_xy, th0, th1, zb=np.arange(-13.0, -0.9, 0.5), thb=12):
    s, r, th = concave(axis_xy, th0, th1)
    tot, k = 0.0, 0
    for z in zb:
        sz = s & (np.abs(P[:, 2] - z) < 0.15)
        meds = []
        for t in np.linspace(th0, th1, thb + 1)[:-1]:
            st = sz & (th >= t) & (th < t + (th1 - th0) / thb)
            if st.sum() > 8:
                rr = r[st]
                # innermost surface = the concave skin: take the low cluster
                lo = np.percentile(rr, 10)
                meds.append(np.median(rr[rr < lo + 0.6]))
        if len(meds) >= 4:
            tot += np.var(meds)
            k += 1
    return tot / max(k, 1)


for nm, ax0, (th0, th1) in (("A", (168.9, -20.3), (-75, 75)), ("B", (169.7, -56.3), (-80, 70))):
    res = minimize(lambda a: spread(a, th0, th1), ax0, method="Nelder-Mead", options={"xatol": 0.02, "fatol": 1e-5, "maxiter": 120})
    ax = res.x
    print(f"bowl {nm}: axis prior {ax0} spread {spread(ax0, th0, th1):.4f} -> fitted ({ax[0]:.2f}, {ax[1]:.2f}) spread {res.fun:.4f} (sd {np.sqrt(res.fun):.3f} mm)")
    s, r, th = concave(ax, th0 - 15, th1 + 15)
    fig, axs = plt.subplots(1, 2, figsize=(20, 8))
    sc = axs[0].scatter(th[s], P[s, 2], c=r[s], s=0.3, cmap="turbo", vmin=4, vmax=18)
    axs[0].set_xlabel("theta deg"); axs[0].set_ylabel("z"); axs[0].set_title(f"bowl {nm} r(theta, z) about ({ax[0]:.2f},{ax[1]:.2f})")
    plt.colorbar(sc, ax=axs[0])
    cols = plt.cm.viridis(np.linspace(0, 1, 9))
    for i, t in enumerate(np.linspace(th0, th1, 9)):
        st = s & (np.abs(th - t) < 4)
        axs[1].scatter(r[st], P[st, 2], s=0.4, color=cols[i], label=f"{t:.0f}")
    axs[1].set_aspect("equal"); axs[1].grid(True, lw=0.3); axs[1].legend(markerscale=20, fontsize=7); axs[1].set_xlabel("r"); axs[1].set_title("meridians by theta")
    axs[1].set_xticks(np.arange(0, 21, 1)); axs[1].set_yticks(np.arange(-15, 2, 1))
    fig.tight_layout(); fig.savefig(os.path.join(AN, f"bowl{nm}_map.png"), dpi=80); plt.close(fig)
    # meridian table per theta sector
    for t in np.linspace(th0, th1, 7):
        st = s & (np.abs(th - t) < 5)
        row = []
        for z in (-1, -3, -5, -7, -9, -11, -12, -13):
            sz = st & (np.abs(P[:, 2] - z) < 0.15)
            if sz.sum() > 5:
                rr = r[sz]; lo = np.percentile(rr, 10)
                row.append(f"{np.median(rr[rr < lo + 0.6]):6.2f}")
            else:
                row.append("   -- ")
        print(f"  theta {t:6.1f}: " + " ".join(row))
