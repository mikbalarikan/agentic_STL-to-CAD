"""Bowl A: tilted-axis revolve, tilt constrained to the XZ plane; meridian in axis coordinates."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from scipy.optimize import least_squares, minimize
from common import AN

A = np.load(os.path.join(AN, "bowlA_skin.npy"))


def frame(ax, ay, tx, ty):
    d = np.array([tx, ty, 1.0]); d /= np.linalg.norm(d)
    return np.array([ax, ay, 0.0]), d


def rh(Q, ax, ay, tx, ty):
    o, d = frame(ax, ay, tx, ty)
    w = Q - o
    h = w @ d
    return np.linalg.norm(w - np.outer(h, d), axis=1), h


def spread(p, Q, ty=None, nb=45):
    ax, ay, tx = p[:3]
    t_y = p[3] if ty is None else ty
    rad, h = rh(Q, ax, ay, tx, t_y)
    b = np.clip(((h - h.min()) / (h.max() - h.min() + 1e-9) * nb).astype(int), 0, nb - 1)
    tot = 0.0
    for i in range(nb):
        s = b == i
        if s.sum() > 20:
            c = np.polyfit(h[s], rad[s], 1)
            tot += np.mean((rad[s] - np.polyval(c, h[s])) ** 2)
    return tot / nb


Q = A[(A[:, 2] > -13.6) & (A[:, 2] < -0.6)]
r_free = minimize(lambda p: spread(p, Q), (170.26, -20.84, 0.2547, 0.0589), method="Nelder-Mead", options={"xatol": 0.003, "fatol": 1e-9, "maxiter": 2000})
print("free tilt:", np.round(r_free.x, 4), "sd", round(float(np.sqrt(r_free.fun)), 4),
      "tilt deg", round(float(np.degrees(np.arctan(np.hypot(r_free.x[2], r_free.x[3])))), 2))
r_xz = minimize(lambda p: spread(p, Q, ty=0.0), (170.26, -20.84, 0.2547), method="Nelder-Mead", options={"xatol": 0.003, "fatol": 1e-9, "maxiter": 2000})
print("XZ tilt only:", np.round(r_xz.x, 4), "sd", round(float(np.sqrt(r_xz.fun)), 4), "tilt deg", round(float(np.degrees(np.arctan(r_xz.x[2]))), 2))
for tilt in (12.0, 14.0, 15.0, 16.0):
    tx = np.tan(np.radians(tilt))
    r = minimize(lambda p: spread((p[0], p[1], tx), Q, ty=0.0), (170.26, -20.84), method="Nelder-Mead", options={"xatol": 0.003, "fatol": 1e-9})
    print(f"tilt {tilt}: axis at z=0 ({r.x[0]:.3f},{r.x[1]:.3f}) sd {np.sqrt(r.fun):.4f}")
    if tilt == 15.0:
        best = (r.x[0], r.x[1], tx, 0.0)
rad, h = rh(Q, *best)
rows = []
for hh in np.arange(h.min() + 0.2, h.max() - 0.1, 0.2):
    s = np.abs(h - hh) < 0.1
    if s.sum() > 20:
        rows.append((np.median(rad[s]), hh, rad[s].std(), s.sum()))
rows = np.array(rows)
np.save(os.path.join(AN, "bowlA_mer_tilt15.npy"), rows)
print("meridian in axis frame (tilt 15 deg in XZ):")
for q in rows[::4]:
    print(f"   rad={q[0]:7.3f} h={q[1]:7.2f} sd={q[2]:.3f} n={int(q[3])}")
R, H = rows[:, 0], rows[:, 1]
for hlo, hhi in ((-10, -1.5), (-9, -2)):
    s = (H >= hlo) & (H <= hhi)
    k = np.polyfit(H[s], R[s], 1)
    print(f"line h[{hlo},{hhi}]: rad = {k[0]:.4f} h + {k[1]:.3f} (half angle {np.degrees(np.arctan(k[0])):.2f}) rms={np.sqrt(((np.polyval(k, H[s]) - R[s])**2).mean()):.4f}")


def circ_res(p, R, Z):
    return np.hypot(R - p[0], Z - p[1]) - p[2]


for hlo, hhi in ((-14.5, -10.5), (-14.5, -11.5)):
    s = (H >= hlo) & (H <= hhi)
    c = least_squares(circ_res, (2.0, -4.0, 9.5), args=(R[s], H[s]))
    print(f"arc h[{hlo},{hhi}]: centre rad={c.x[0]:.3f} h={c.x[1]:.3f} R={c.x[2]:.3f} rms={np.sqrt((c.fun**2).mean()):.4f}")
