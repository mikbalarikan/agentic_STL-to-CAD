"""Rail channel wall: arcs of the concave face and the back face; candidates with design constraints."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from fit import circle, line, show

P = np.load(os.path.join(os.path.dirname(__file__), "rail_pts.npy"))
# concave face points: for each z band the max-y cluster
C, B = [], []
for z in np.arange(-0.4, -13.8, -0.1):
    s = (np.abs(P[:, 1] - z) < 0.05) & (P[:, 0] > -77) & (P[:, 0] < -66.5)
    q = P[s]
    if not len(q):
        continue
    ymax = q[:, 0].max()
    C.append(q[q[:, 0] > ymax - 0.2])
    if z < -2.3:
        b = q[q[:, 0] < ymax - 1.2]
        if len(b):
            bm = b[:, 0].max()
            B.append(b[b[:, 0] > bm - 0.2])
C, B = np.concatenate(C), np.concatenate(B)
print("concave pts", len(C), "back pts", len(B))


def cfit(Q, label, zlo, zhi, fix_r=None, tangent_vertical_at=None):
    s = (Q[:, 1] >= zlo) & (Q[:, 1] <= zhi)
    q = Q[s]
    A = np.c_[2 * q, np.ones(len(q))]
    sol, *_ = np.linalg.lstsq(A, (q ** 2).sum(1), rcond=None)
    c = sol[:2]
    r = np.sqrt(sol[2] + c @ c)
    for _ in range(30):
        v = q - c
        d = np.linalg.norm(v, axis=1)
        J = np.c_[-v / d[:, None], -np.ones(len(q))]
        dl, *_ = np.linalg.lstsq(J, -(d - r), rcond=None)
        c = c + dl[:2]
        r = r + dl[2]
    res = np.linalg.norm(q - c, axis=1) - r
    print(f"{label} z[{zlo},{zhi}]: c=({c[0]:.3f},{c[1]:.3f}) r={r:.3f} rms={np.sqrt((res**2).mean()):.4f} max={np.abs(res).max():.3f} n={len(q)}")
    return c, r


def cfit_cz(Q, label, zlo, zhi, cz):
    """Circle with the centre height fixed (tangent vertical at z = cz)."""
    s = (Q[:, 1] >= zlo) & (Q[:, 1] <= zhi)
    q = Q[s]
    cy, r = -55.0, 18.0
    for _ in range(50):
        v = q - np.array([cy, cz])
        d = np.linalg.norm(v, axis=1)
        J = np.c_[-v[:, 0] / d, -np.ones(len(q))]
        dl, *_ = np.linalg.lstsq(J, -(d - r), rcond=None)
        cy += dl[0]
        r += dl[1]
    res = np.linalg.norm(q - np.array([cy, cz]), axis=1) - r
    print(f"{label} z[{zlo},{zhi}] cz={cz}: cy={cy:.3f} r={r:.3f} (top y={cy - r:.3f}) rms={np.sqrt((res**2).mean()):.4f} max={np.abs(res).max():.3f}")
    return cy, r


cfit(C, "concave free", -13.6, -0.6)
cfit(C, "concave free upper", -7, -0.6)
cfit(C, "concave free lower", -13.6, -7)
for cz in (0.0, -0.5, -1.0, -1.9):
    cfit_cz(C, "concave", -13.6, -0.6, cz)
cfit(B, "back free", -12.8, -2.5)
for cz in (0.0, -1.0, -1.9):
    cfit_cz(B, "back", -12.8, -2.5, cz)
# straight + arc alternative: upper straight line?
for zlo, zhi in ((-3, -0.5), (-13.5, -10)):
    s = (C[:, 1] >= zlo) & (C[:, 1] <= zhi)
    q = C[s]
    a, b = np.polyfit(q[:, 1], q[:, 0], 1)
    print(f"concave line z[{zlo},{zhi}]: y = {a:.4f} z + {b:.3f}  angle from vertical {np.degrees(np.arctan(a)):.2f} deg rms={np.sqrt(((np.polyval([a, b], q[:, 1]) - q[:, 0])**2).mean()):.4f}")
# wall thickness along the arc: distance of back pts from the concave circle
c, r = cfit(C, "concave (for thickness)", -13.6, -0.6)
d = np.linalg.norm(B - c, axis=1) - r
for z0 in np.arange(-3, -13, -1.0):
    s = (B[:, 1] < z0) & (B[:, 1] >= z0 - 1)
    if s.any():
        print(f"  back z[{z0-1:.0f},{z0:.0f}] thickness {np.median(d[s]):.3f}")
np.save(os.path.join(os.path.dirname(__file__), "rail_concave.npy"), C)
np.save(os.path.join(os.path.dirname(__file__), "rail_back.npy"), B)
