"""Section overlay CAD (red) on scan (black). usage: ovl.py <cad.stl> <out.png> <axis> <v1,v2,..> [lim a0 a1 b0 b1] [cols N] [major M] [raw]"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.ticker import MultipleLocator
from common import load, read_stl, Mesh

args = sys.argv[1:]
cad_path, out, axn, vals = args[0], args[1], args[2], [float(v) for v in args[3].split(",")]
axis = "xyz".index(axn)
lim = [float(v) for v in args[args.index("lim") + 1:args.index("lim") + 5]] if "lim" in args else None
cols = int(args[args.index("cols") + 1]) if "cols" in args else 1
major = float(args[args.index("major") + 1]) if "major" in args else None
scan, _ = load(dewarped="raw" not in args)
cad = Mesh(read_stl(cad_path))
o = [i for i in range(3) if i != axis]
rows = int(np.ceil(len(vals) / cols))
if lim:
    w, h = lim[1] - lim[0], lim[3] - lim[2]
else:
    w, h = scan.hi[:, o[0]].max() - scan.lo[:, o[0]].min(), scan.hi[:, o[1]].max() - scan.lo[:, o[1]].min()
scale = min(22.0 / (w * cols), 14.0 / (h * rows))
fig, axs = plt.subplots(rows, cols, figsize=(max(6, w * cols * scale + 1), max(3, h * rows * scale + 0.6 * rows)), squeeze=False)
if major is None:
    major = 1 if max(w, h) <= 30 else 2 if max(w, h) <= 60 else 5 if max(w, h) <= 120 else 10
for k, v in enumerate(vals):
    ax = axs[k // cols][k % cols]
    box = {o[0]: (lim[0], lim[1]), o[1]: (lim[2], lim[3])} if lim else None
    s = scan.section(axis, v, box)
    ax.add_collection(LineCollection(s[:, :, o], linewidths=0.7, colors="k"))
    # nudge the CAD cut off exact face positions
    c = cad.section(axis, v + 1e-4, box)
    ax.add_collection(LineCollection(c[:, :, o], linewidths=0.8, colors="r", alpha=0.85))
    ax.set_aspect("equal")
    if lim:
        ax.set_xlim(lim[0], lim[1]); ax.set_ylim(lim[2], lim[3])
    else:
        ax.autoscale()
    ax.xaxis.set_major_locator(MultipleLocator(major)); ax.yaxis.set_major_locator(MultipleLocator(major))
    ax.xaxis.set_minor_locator(MultipleLocator(major / 5 if major in (5, 10) else major / 2))
    ax.yaxis.set_minor_locator(MultipleLocator(major / 5 if major in (5, 10) else major / 2))
    ax.grid(True, which="major", lw=0.4, color="0.6"); ax.grid(True, which="minor", lw=0.2, color="0.85")
    ax.tick_params(labelsize=7)
    ax.set_title(f"{axn} = {v:g}  ({'xyz'[o[0]]} horiz, {'xyz'[o[1]]} vert)  black scan / red CAD", fontsize=9)
fig.tight_layout()
fig.savefig(out, dpi=100)
print("saved", out)
