"""Renders for the report (cadgenbench venv: pyvista). usage: render.py <cad.stl> <scan.stl> <out dir>"""
import sys, os
import numpy as np
import pyvista as pv

cad_path, scan_path, out = sys.argv[1:4]
pv.OFF_SCREEN = True
cad = pv.read(cad_path)
scan = pv.read(scan_path)
views = {
    "iso_top": ((-0.55, -0.75, 0.62), (0, 0, 1)),
    "iso_bowl_end": ((0.75, -0.55, 0.62), (0, 0, 1)),
    "iso_underside": ((-0.5, -0.7, -0.68), (0, 0, -1)),
    "iso_underside_rail": ((0.35, -0.85, -0.55), (0, 0, -1)),
}
c = np.array(cad.center)
L = cad.length
for name, (d, up) in views.items():
    for tag, mesh, col in (("cad", cad, "#9fb4c7"), ("scan", scan, "#c9c2b0")):
        pl = pv.Plotter(off_screen=True, window_size=(1800, 1100))
        pl.set_background("white")
        pl.add_mesh(mesh, color=col, smooth_shading=False, specular=0.25, specular_power=12, ambient=0.25, diffuse=0.8,
                    show_edges=False, split_sharp_edges=True, feature_angle=30)
        if tag == "cad":
            edges = cad.extract_feature_edges(feature_angle=28, boundary_edges=False, non_manifold_edges=False, manifold_edges=False)
            pl.add_mesh(edges, color="#30383f", line_width=1.0)
        dv = np.array(d, float) / np.linalg.norm(d)
        pl.camera.position = tuple(c + dv * L * 1.15)
        pl.camera.focal_point = tuple(c)
        pl.camera.up = up
        pl.camera.parallel_projection = True
        pl.camera.parallel_scale = L * 0.36
        pl.enable_anti_aliasing("ssaa")
        pl.screenshot(os.path.join(out, f"render_{name}_{tag}.png"))
        pl.close()
print("renders written to", out)
