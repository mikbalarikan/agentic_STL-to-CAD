"""Deck = two cones (one per bowl) meeting in a crest; fit each cone with a free vertical axis."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from scipy.optimize import least_squares
from common import AN

Q = np.load(os.path.join(AN, "deck_pts.npy"))
S = Q[(Q[:, 2] > 0.45) & (Q[:, 0] < 189.0) & (Q[:, 0] > 172) & (Q[:, 1] < -14) & (Q[:, 1] > -75.5)]


def res(p, q, tilted=False):
    cx, cy, k, z0 = p[:4]
    r = np.hypot(q[:, 0] - cx, q[:, 1] - cy)
    return (z0 + k * r - q[:, 2]) / np.sqrt(1 + k * k)


out = {}
for nm, sel, start in (("B", (S[:, 1] < -44) & (S[:, 1] > -72), (169.2, -56.2, 0.4, -6.0)),
                       ("A", (S[:, 1] > -31), (170.0, -20.7, 0.4, -6.0))):
    q = S[sel]
    r = least_squares(res, start, args=(q,), loss="soft_l1", f_scale=0.05)
    e = res(r.x, q)
    cx, cy, k, z0 = r.x
    print(f"cone {nm} free axis: ({cx:.3f},{cy:.3f}) slope {k:.4f} ({np.degrees(np.arctan(k)):.2f} deg) z0 {z0:.3f}; radius at z=0: {-z0/k:.3f}, at z=0.3: {(0.3-z0)/k:.3f} rms {np.sqrt((e**2).mean()):.3f} p95 {np.percentile(np.abs(e),95):.3f} n={len(q)}")
    out[nm] = r.x
    # axis fixed at the bowl axis
    fx = (169.19, -56.18) if nm == "B" else None
    if fx:
        r2 = least_squares(lambda p: res((fx[0], fx[1], p[0], p[1]), q), (0.4, -6.0), loss="soft_l1", f_scale=0.05)
        e = res((fx[0], fx[1], r2.x[0], r2.x[1]), q)
        print(f"   axis fixed at bowl axis {fx}: slope {r2.x[0]:.4f} ({np.degrees(np.arctan(r2.x[0])):.2f} deg) z0 {r2.x[1]:.3f} radius at z=0 {-r2.x[1]/r2.x[0]:.3f} rms {np.sqrt((e**2).mean()):.3f} p95 {np.percentile(np.abs(e),95):.3f}")
# combined model min(coneA, coneB) on all sloped points
zA = out["A"][3] + out["A"][2] * np.hypot(S[:, 0] - out["A"][0], S[:, 1] - out["A"][1])
zB = out["B"][3] + out["B"][2] * np.hypot(S[:, 0] - out["B"][0], S[:, 1] - out["B"][1])
e = np.minimum(zA, zB) - S[:, 2]
print(f"min(coneA, coneB) on all sloped deck points: rms {np.sqrt((e**2).mean()):.3f} p95 {np.percentile(np.abs(e),95):.3f} max {np.abs(e).max():.3f} n={len(S)}")
bad = np.abs(e) > 0.3
print("  share > 0.3:", round(float(bad.mean()), 4), " bbox of bad:", S[bad].min(0).round(1), S[bad].max(0).round(1))
# where is the step down to the end strip, and the bowl rims (inner edge of the deck)?
for y in (-70, -62, -56, -50, -44, -37, -30, -25, -20):
    q = Q[(np.abs(Q[:, 1] - y) < 0.4) & (Q[:, 2] > 0.6)]
    q2 = Q[(np.abs(Q[:, 1] - y) < 0.4) & (Q[:, 0] > 180)]
    hi = q2[q2[:, 2] > q2[:, 2].max() - 0.15]
    print(f"  y={y}: sloped deck x from {q[:, 0].min():.2f} to {q[:, 0].max():.2f}; z max {q2[:, 2].max():.2f} at x {np.median(hi[:, 0]):.2f}")
