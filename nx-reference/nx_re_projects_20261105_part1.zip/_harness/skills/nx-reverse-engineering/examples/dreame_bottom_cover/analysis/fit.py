"""2D profile fitting on stacked scan sections (de-warped datum frame)."""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from common import load

_M = None


def mesh():
    global _M
    if _M is None:
        _M = load(dewarped=True)[0]
    return _M


def pts(axis, v0, v1, n=7, lim=None, step=0.15):
    """Points of n sections axis in [v0, v1], resampled along the segments; returns (k, 2) in the two other axes
    plus the list of those axes. lim = (a0, a1, b0, b1) window in the 2D coordinates."""
    m = mesh()
    o = [i for i in range(3) if i != axis]
    box = None if lim is None else {o[0]: (lim[0], lim[1]), o[1]: (lim[2], lim[3])}
    out = []
    for v in np.linspace(v0, v1, n):
        s = m.section(axis, float(v), box)[:, :, o]
        if not len(s):
            continue
        d = s[:, 1] - s[:, 0]
        L = np.linalg.norm(d, axis=1)
        k = np.maximum(1, np.ceil(L / step).astype(int))
        for kk in np.unique(k):
            sel = k == kk
            t = (np.arange(kk) + 0.5) / kk
            out.append((s[sel, 0][:, None, :] + d[sel][:, None, :] * t[None, :, None]).reshape(-1, 2))
    P = np.concatenate(out) if out else np.zeros((0, 2))
    if lim is not None:
        P = P[(P[:, 0] >= lim[0]) & (P[:, 0] <= lim[1]) & (P[:, 1] >= lim[2]) & (P[:, 1] <= lim[3])]
    return P


def line(P, p0, p1, band=0.3, margin=0.3, it=4):
    """Refine the line through p0-p1 with the points within 'band' of it (between the ends minus margin).
    Returns dict: a point c, unit direction d, angle (deg from +a axis), rms, n, and the offset form n.x = h."""
    p0, p1 = np.asarray(p0, float), np.asarray(p1, float)
    d = (p1 - p0) / np.linalg.norm(p1 - p0)
    c = (p0 + p1) / 2
    half = np.linalg.norm(p1 - p0) / 2 - margin
    b = band
    for k in range(it):
        nrm = np.array([-d[1], d[0]])
        t = (P - c) @ d
        r = (P - c) @ nrm
        s = (np.abs(t) <= half) & (np.abs(r) <= b)
        if s.sum() < 5:
            return {"n": int(s.sum())}
        Q = P[s]
        cc = Q.mean(0)
        u, sv, vt = np.linalg.svd(Q - cc)
        dd = vt[0]
        if dd @ d < 0:
            dd = -dd
        # keep the centre at the same parameter along the guess
        c = cc + dd * ((c - cc) @ dd)
        d = dd
        b = max(band / 3, 3 * sv[1] / np.sqrt(len(Q)))
    nrm = np.array([-d[1], d[0]])
    r = (P[s] - c) @ nrm
    return {"c": c, "d": d, "ang": float(np.degrees(np.arctan2(d[1], d[0]))), "rms": float(np.sqrt((r ** 2).mean())),
            "n": int(s.sum()), "nrm": nrm, "h": float(c @ nrm)}


def circle(P, c0, r0, a0, a1, band=0.3, it=6, fix_r=None):
    """Refine a circle near centre c0 / radius r0 using points within band of it and polar angle in [a0, a1] deg
    (angle of the point about the current centre)."""
    c, r = np.asarray(c0, float), float(r0)
    b = band
    s = None
    for k in range(it):
        v = P - c
        rr = np.linalg.norm(v, axis=1)
        ang = np.degrees(np.arctan2(v[:, 1], v[:, 0])) % 360.0
        if a0 <= a1:
            sa = (ang >= a0) & (ang <= a1)
        else:
            sa = (ang >= a0) | (ang <= a1)
        s = sa & (np.abs(rr - r) <= b)
        if s.sum() < 8:
            return {"n": int(s.sum())}
        Q = P[s]
        # geometric fit (Gauss-Newton) from the algebraic start
        A = np.c_[2 * Q, np.ones(len(Q))]
        sol, *_ = np.linalg.lstsq(A, (Q ** 2).sum(1), rcond=None)
        cc = sol[:2]
        rr2 = np.sqrt(sol[2] + cc @ cc)
        for _ in range(20):
            v = Q - cc
            dist = np.linalg.norm(v, axis=1)
            if fix_r is None:
                J = np.c_[-v / dist[:, None], -np.ones(len(Q))]
                res = dist - rr2
                dlt, *_ = np.linalg.lstsq(J, -res, rcond=None)
                cc = cc + dlt[:2]
                rr2 = rr2 + dlt[2]
            else:
                rr2 = fix_r
                J = -v / dist[:, None]
                res = dist - rr2
                dlt, *_ = np.linalg.lstsq(J, -res, rcond=None)
                cc = cc + dlt[:2]
        c, r = cc, rr2
        b = max(band / 3, 0.1)
    v = P[s] - c
    res = np.linalg.norm(v, axis=1) - r
    ang = np.degrees(np.arctan2(v[:, 1], v[:, 0])) % 360.0
    return {"c": c, "r": float(r), "rms": float(np.sqrt((res ** 2).mean())), "n": int(s.sum()),
            "a": (float(ang.min()), float(ang.max()))}


def level(P, axis2, a0, a1, b0, b1):
    """Median level of the coordinate axis2 (0 or 1) of points inside the window [a0,a1]x[b0,b1]."""
    s = (P[:, 0] >= a0) & (P[:, 0] <= a1) & (P[:, 1] >= b0) & (P[:, 1] <= b1)
    if s.sum() < 3:
        return None
    v = P[s, axis2]
    return float(np.median(v)), float(v.std()), int(s.sum())


def show(name, r):
    if "c" not in r:
        print(f"{name}: too few points ({r.get('n')})")
    elif "r" in r:
        print(f"{name}: circle c=({r['c'][0]:.3f}, {r['c'][1]:.3f}) r={r['r']:.3f} rms={r['rms']:.3f} n={r['n']} arc {r['a'][0]:.0f}..{r['a'][1]:.0f}")
    else:
        print(f"{name}: line through ({r['c'][0]:.3f}, {r['c'][1]:.3f}) ang={r['ang']:.2f} deg rms={r['rms']:.3f} n={r['n']}")
