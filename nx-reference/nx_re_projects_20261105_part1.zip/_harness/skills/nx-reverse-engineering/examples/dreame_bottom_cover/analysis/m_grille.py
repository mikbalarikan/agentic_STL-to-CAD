"""Grille end (x 0..20.6): trough profiles per x-zone, top and underside."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from pw import env, report
from fit import pts, level

# ---- rail-side trough, top surface
Z = {"R1 x1.4-3.0": (1.4, 3.0), "R2 x4.2-7.0": (4.2, 7.0), "R3 x8.2-12.4": (8.2, 12.4), "R4 x14-20": (14.0, 20.0)}
E = {k: env(0, a, b, -74.5, -42.0, "top") for k, (a, b) in Z.items()}
report("R1 top", E["R1 x1.4-3.0"], [-72.6, -71.3, -68.2, -60.3, -51.0, -43.8, -42.2], "LLAFAF")
report("R2 top", E["R2 x4.2-7.0"], [-73.2, -68.3, -62.6, -48.6, -42.2], "LAFA")
report("R3 top", E["R3 x8.2-12.4"], [-73.2, -68.3, -58.8, -52.6, -42.2], "LAFA")
report("R4 top", E["R4 x14-20"], [-73.8, -65.5, -61.3, -53.0, -42.2], "AAFA")
# ---- hook-side trough, top surface
H = {"H1 x1.4-3.0": (1.4, 3.0), "H2 x4.2-9.4": (4.2, 9.4), "H3 x11-20": (11.0, 20.0)}
EH = {k: env(0, a, b, -44.0, 0.6, "top") for k, (a, b) in H.items()}
report("H1 top", EH["H1 x1.4-3.0"], [-43.4, -42.4, -34.3, -32.9, -25.6, -16.6, -14.6, -12.4, -1.9, 0.2], "AFFAFAFAF")
report("H2 top", EH["H2 x4.2-9.4"], [-42.0, -34.6, -29.2, -13.0, -11.6, -1.9, 0.2], "FLFLAF")
report("H3 top", EH["H3 x11-20"], [-40.2, -32.6, -24.6, -18.4, -5.4, -0.2], "FAFAF")
# ---- underside
EB = env(0, 14.0, 20.0, -78.0, 1.0, "bot")
report("bottom x14-20", EB, [-76.5, -75.0, -67.2, -62.2, -50.0, -44.6, -41.4, -37.0, -35.6, -32.4, -13.5, -1.0], "AFAFAFAAAFA")
EB1 = env(0, 1.4, 6.0, -78.0, 1.0, "bot")
report("bottom x1.4-6", EB1, [-80.0, -76.3, -75.0, -40.5, -37.0, -35.6, -32.4, -13.5, -0.3], "LAFAAAFA")
# ---- levels along x (zone boundaries): top envelope along x at chosen y
for y, nm in ((-56.0, "rail trough floor"), (-21.0, "hook trough floor"), (-64.5, "rail wall"), (-8.0, "hook wall"), (-38.0, "hump")):
    Ex = env(1, y - 0.4, y + 0.4, -0.5, 23.0, "top", n=3)
    dz = np.abs(np.diff(Ex[:, 1]))
    steps = Ex[1:][dz > 0.25]
    print(f"steps along x at y={y} ({nm}):", [(round(float(u), 2), round(float(z), 2)) for u, z in steps])
