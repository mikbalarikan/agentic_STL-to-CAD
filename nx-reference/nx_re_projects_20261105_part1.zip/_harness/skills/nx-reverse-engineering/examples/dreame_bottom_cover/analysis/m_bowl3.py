"""Surface-of-revolution fit with a free (tilted) axis for the two bowls; meridian fit by arcs."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
from scipy.optimize import minimize, least_squares
from common import load, AN

m, _ = load(True)
P, idx = m.sample(2_500_000, seed=5, mask=(m.c[:, 0] > 140))
N = m.n[idx]


def skin_points(ax, t0, t1, zlo=-14.0, zhi=-0.5):
    """Inner (concave) skin points: innermost cluster per (theta, z) cell about a vertical axis guess."""
    v = P[:, :2] - np.asarray(ax)
    r = np.linalg.norm(v, axis=1)
    th = np.degrees(np.arctan2(v[:, 1], v[:, 0]))
    inward = -(N[:, 0] * v[:, 0] + N[:, 1] * v[:, 1]) / np.maximum(r, 1e-9)
    base = (r < 20.5) & (inward > 0.1) & (N[:, 2] > -0.05) & (th > t0) & (th < t1) & (P[:, 2] > zlo) & (P[:, 2] < zhi)
    ti = ((th - t0) / 4.0).astype(int)
    zi = ((P[:, 2] - zlo) / 0.25).astype(int)
    key = ti * 1000 + zi
    keep = np.zeros(len(P), bool)
    ids = np.where(base)[0]
    order = ids[np.argsort(key[ids])]
    ks = key[order]
    cuts = np.flatnonzero(np.diff(ks)) + 1
    for grp in np.split(order, cuts):
        if len(grp) < 5:
            continue
        rr = r[grp]
        lo = np.percentile(rr, 8)
        keep[grp[rr < lo + 0.35]] = True
    return P[keep], N[keep]


def axis_frame(p):
    x0, y0, tx, ty = p
    d = np.array([tx, ty, 1.0]); d /= np.linalg.norm(d)
    return np.array([x0, y0, 0.0]), d


def rh(Q, p):
    o, d = axis_frame(p)
    w = Q - o
    h = w @ d
    rad = np.linalg.norm(w - np.outer(h, d), axis=1)
    return rad, h


def cost(p, Q, nb=40):
    rad, h = rh(Q, p)
    b = np.clip(((h - h.min()) / (h.max() - h.min() + 1e-9) * nb).astype(int), 0, nb - 1)
    tot = 0.0
    for i in range(nb):
        s = b == i
        if s.sum() > 20:
            # remove the local slope inside the bin
            c = np.polyfit(h[s], rad[s], 1)
            tot += np.mean((rad[s] - np.polyval(c, h[s])) ** 2)
    return tot / nb


for nm, ax0, (t0, t1) in (("B", (169.30, -56.32), (-40, 48)), ("A", (169.33, -20.39), (-70, 45))):
    Q, Nq = skin_points(ax0, t0, t1)
    print(f"bowl {nm}: skin points {len(Q)}")
    r0 = minimize(lambda p: cost(np.r_[p, 0, 0], Q), ax0, method="Nelder-Mead", options={"xatol": 0.01, "fatol": 1e-7})
    print(f"   vertical axis: ({r0.x[0]:.3f}, {r0.x[1]:.3f})  sd {np.sqrt(r0.fun):.4f}")
    r1 = minimize(lambda p: cost(p, Q), np.r_[r0.x, 0, 0], method="Nelder-Mead", options={"xatol": 0.005, "fatol": 1e-8, "maxiter": 800})
    o, d = axis_frame(r1.x)
    print(f"   tilted axis: at z=0 ({r1.x[0]:.3f}, {r1.x[1]:.3f}) dx/dz={r1.x[2]:.4f} dy/dz={r1.x[3]:.4f} "
          f"(tilt {np.degrees(np.arctan(np.hypot(r1.x[2], r1.x[3]))):.2f} deg toward azimuth {np.degrees(np.arctan2(r1.x[3], r1.x[2])):.0f})  sd {np.sqrt(r1.fun):.4f}")
    np.save(os.path.join(AN, f"bowl{nm}_skin.npy"), Q)
    for label, p in (("vertical", np.r_[r0.x, 0, 0]), ("tilted", r1.x)):
        rad, h = rh(Q, p)
        rows = []
        for hh in np.arange(-13.8, -0.4, 0.2):
            s = np.abs(h - hh) < 0.1
            if s.sum() > 20:
                rows.append((np.median(rad[s]), hh, rad[s].std()))
        rows = np.array(rows)
        np.save(os.path.join(AN, f"bowl{nm}_mer_{label}.npy"), rows)
        print(f"   {label} meridian: {len(rows)} rows, median in-bin sd {np.median(rows[:, 2]):.3f}")
