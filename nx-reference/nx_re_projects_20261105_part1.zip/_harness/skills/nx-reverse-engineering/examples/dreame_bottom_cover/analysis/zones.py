"""Overlay of YZ sections of several x-zones in one plot. usage: zones.py <out.png> "a:b,c:d,..." y0 y1 z0 z1"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.ticker import MultipleLocator
from fit import mesh

out = sys.argv[1]
zones = [tuple(float(v) for v in z.split(":")) for z in sys.argv[2].split(",")]
lim = [float(v) for v in sys.argv[3:7]]
axis = "xyz".index(sys.argv[7]) if len(sys.argv) > 7 else 0
m = mesh()
o = [i for i in range(3) if i != axis]
w, h = lim[1] - lim[0], lim[3] - lim[2]
sc = min(23.0 / w, 13.0 / h)
fig, ax = plt.subplots(figsize=(w * sc + 1, h * sc + 1))
cols = ["k", "tab:red", "tab:blue", "tab:green", "tab:orange", "tab:purple", "tab:brown", "tab:cyan"]
for k, (a, b) in enumerate(zones):
    for v in np.linspace(a, b, 3):
        s = m.section(axis, float(v), {o[0]: (lim[0], lim[1]), o[1]: (lim[2], lim[3])})
        ax.add_collection(LineCollection(s[:, :, o], linewidths=0.6, colors=cols[k % len(cols)], label=f"{'xyz'[axis]} {a:g}..{b:g}" if v == a else None))
ax.set_aspect("equal"); ax.set_xlim(lim[0], lim[1]); ax.set_ylim(lim[2], lim[3])
major = 1 if max(w, h) <= 40 else 2 if max(w, h) <= 100 else 5
ax.xaxis.set_major_locator(MultipleLocator(major)); ax.yaxis.set_major_locator(MultipleLocator(major))
ax.xaxis.set_minor_locator(MultipleLocator(major / 2)); ax.yaxis.set_minor_locator(MultipleLocator(major / 2))
ax.grid(True, which="major", lw=0.4, color="0.6"); ax.grid(True, which="minor", lw=0.2, color="0.85")
ax.tick_params(labelsize=7); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(out, dpi=100)
print("saved", out)
