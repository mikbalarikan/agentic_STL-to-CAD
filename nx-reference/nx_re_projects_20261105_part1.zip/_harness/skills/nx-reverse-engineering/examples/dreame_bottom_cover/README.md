# Worked example: Dreame mop-module bottom cover, real scan -> native parametric NX part

A class E job (rebuild from scan) on a REAL moulded part, done 2026-10-07/08 on NX 2206 batch and accepted
by the user ("harika kalite onaylandı"). It is a reference, not part of the regression suite: the sources
are a snapshot exactly as they ran, with their work-folder paths hard-coded. `REPORT.md` is the delivered
report (Turkish); this page says what the example shows and what is reusable.

| | |
|---|---|
| Part | injection-moulded open frame, scan extents about 195 x 89 x 26 mm: rail with channel wall, hook-side beam with 4 snap tabs, grille end with stepped twin troughs, bowl end with two scoop bowls, cells and fins, rib combs, two latch housings |
| Scan | 4.84 M triangles, open mesh (93 166 open edges), noise 0.038 mm rms, flange bowed about 1.1 mm, several single-sheet artefacts |
| Earlier attempts | three build123d iterations outside NX (station extrusions, then a feature tree); their own QA gave scan-to-CAD p95 1.74 mm (it2) and 1.07 mm (it3) under a different protocol (raw full-resolution scan + ICP). Rejected by the user as not clean / not parametric |
| This build | 269 features in one journal run: 71 sketches, 68 Extrude, 4 Revolve, 2 Through Curves, 4 Pattern Feature, 1 Pattern Geometry, 1 Mirror Geometry, 7 booleans; frame = one solid, two latch sliders kept as separate bodies |

## Measured result (`qa/`)

| Check | Value |
|---|---|
| Journal checks (volume deltas, cut / add proofs, solid count, feature errors) | 61 / 61 |
| Sketches | 71 / 71 `WellConstrained`, DOF 0, 0 automatic dimensions; 772 dimensions, 109 named master expressions |
| Regeneration (14 masters changed one at a time, update, back) | 14 / 14 without a feature error, volume back to nominal; `tab_pitch` 28.2 -> 27.6 moved the last tab to x = 136.0 as computed |
| Examine Geometry, native bodies | all counters 0 on the three solids |
| STEP AP242 round trip into NX | 3 solids, volumes within 9e-6 |
| STEP in OCP (`BRepCheck_Analyzer`) | 3 solids valid |
| Examine Geometry on the RE-IMPORTED frame | **96 face-intersection findings** (native body: 0) - not resolved |

Scan <-> CAD, 800 000 samples of the 400 k-triangle aligned working copy (+ = scan outside the CAD):

| | rms | p50 | p90 | p95 | p99 | > 0.3 | > 0.8 |
|---|---|---|---|---|---|---|---|
| scan -> CAD, de-warped scan, artefacts masked (5.1 %) | 0.308 | 0.084 | 0.432 | 0.595 | 1.231 | 19.1 % | 2.7 % |
| scan -> CAD, de-warped, no mask | 0.442 | 0.093 | 0.550 | 1.042 | 1.892 | 22.7 % | 6.6 % |
| scan -> CAD, raw scan (rigid alignment only), masked | 0.442 | 0.188 | - | 0.929 | 1.298 | 36.5 % | 9.3 % |
| CAD -> scan, whole CAD surface | 0.443 | 0.076 | 0.605 | 1.064 | 1.897 | 19.4 % | 7.6 % |

The plastic band of the job (p95 <= 0.30, max <= 0.80 mm) is **not met**. Largest remaining clusters: bowl
end, x 160 - 192 (hook-side run-out and floor round of bowl A, the step between the rail channel and bowl
B, the deck). No edge blends and no general draft are modelled. The check was run by the builder on the
decimated working copy - not an independent QA and not on the full-resolution scan.

## What is in the folder

| Path | Content |
|---|---|
| `result/dreame_mop_bottom_cover.prt` | the parametric part (bodies `FRAME`, `LATCH_SLIDER_1`, `LATCH_SLIDER_2`) |
| `result/dreame_mop_bottom_cover.step` | AP242, 3 solids |
| `result/dreame_mop_bottom_cover_with_scan.prt` | the same part + the scan (137 k facets, CAD datum frame) on layer 10 |
| `result/dreame_mop_bottom_cover_cad.stl` | tessellation the deviation was measured on |
| `REPORT.md` | delivered report: feature tree by group, masters, checks, every known deviation and simplification |
| `figures/` | renders of CAD and scan, deviation maps, section overlays (black scan, red CAD) |
| `qa/` | `build_checks.json` (checks, sketch states, regeneration rows, STEP round trip), `deviation_*.json`, `masters.json`, `warp_field.json` |
| `journal/build.py` | the journal: context class, stage A (rail, beam, bead, tabs), stage B (grille end), final checks |
| `journal/nxlib/st_c.py`, `st_d.py` | stage C (bowl end, hook-side corner), stage D (rail underside, flange details, sliders) |
| `journal/nxlib/ps.py`, `geo.py` | job-local helpers: fully constrained line / arc profile sketches, 2D intersections |
| `journal/run.ps1`, `review.py` | launcher that prints the verdict of `build.json`; the review part with the scan |
| `journal/probe1.py`, `probe2.py` | sketch helper + extrude + regeneration; what makes a revolve about a tilted axis fail |
| `analysis/` | scan measurement outside NX: `common.py` (STL reader, de-warp, slicer), `overview.py` (height maps), `sec.py` / `zones.py` (sections), `fit.py` / `pw.py` (line / arc / piecewise fits), `m_*.py` (one measurement script per region), `ovl.py` (CAD over scan), `dev.py` (signed deviation with artefact masks), `render.py` |

Not copied: the scan. Original `Downloads\dreame_mop_assembly_bottom_cover\dreame_mop_assembly_bottom_cover.stl`
(242 MB, sha256 `0484a9d5...f73f72`); the scripts read the datum-aligned 400 k working copy of the earlier
run, `run\intake\aligned_work.stl` (sha256 `42ebca3f...7afd`), whose frame is `run\intake\alignment.json`.

## What it shows (where it departs from the workflow in `../../SKILL.md`)

1. **Measure outside NX.** 400 k facets are far beyond what `nxre.Scan` reads in reasonable time, so every
   number came from numpy on the aligned STL: sections stacked over a station range, then line / circle /
   piecewise fits (`fit.py`, `pw.py`). Fit rms on clean faces was 0.004 - 0.04 mm.
2. **Take the bow out for measuring only.** A cubic-by-linear field z(x, y) fitted to the flange top
   (`common.fit_warp`); sections rotate with the local slope. The CAD is flat; the raw-scan row above shows
   what the bow costs.
3. **Find the intent per region before modelling it** - this took most of the time and decided the features:
   - rail channel wall: one arc R 18.1 centred on the flange plane (rms 0.03);
   - grille end: an envelope block with one "void" profile per x-zone (4 on the rail side, 3 on the hook
     side), each line + arc + floor + arc;
   - bowl B: surface of revolution about a vertical axis, meridian of two arcs (rms 0.018 on the wall arc);
   - bowl A: NOT a revolve (vertical axis sd 0.34, tilted axis no clear optimum). Its plan sections are
     circles whose centre drifts with depth, so it is a Through Curves loft through six plan sections;
   - deck: two cones about the bowl axes cut by a cap plane (min of the three);
   - hook-side corner: a curved skin whose straight generators run 17.5 deg to X in plan - found from the
     straight height contours, built as an Extrude along a skew vector.
4. **Build in stages, each run from scratch** (1.5 - 4 min for everything): stage -> STL of all solids ->
   section overlays -> correct numbers -> next stage. Thin shells were made as shell solid united first,
   then the void subtracted, so later additions (fins, walls) are trimmed by the void.
5. **Deviation with named artefact masks** (`dev.py: artefact`): single zero-thickness sheets only, each
   described by a box predicate, and both masked and unmasked rows reported.

## Traps met in this job

- `Sketch.AddGeometry` with inferred coincidence also ties arc CENTRES that happen to coincide: a chain with
  concentric arcs fixed by end points + radius became `OverConstrained`. `ps.Sketch.profile` adds curves
  without inference and creates the end-point coincidences itself.
- A measured arc centre is never equidistant from two computed junctions: draw every arc through BOTH end
  points and let the given centre only choose the side (`ps.Sketch.profile`), otherwise one end stays open
  (2 DOF).
- A 180 deg arc given by end points + centre is ambiguous - the flange recesses removed half the expected
  volume until each end arc was split at its apex.
- Revolve about a TILTED axis: "Unable to create revolved body from the specified section, axis and
  parameters" when the on-axis vertices are held by rounded coordinate dimensions (`journal/probe2.py`:
  0.3 mm off the axis works, on the axis fails). Put them on the datum axis with a point-on-curve
  constraint (`ps.on(axis)`).
- `nxh.bbox` of a body with tilted-revolve faces is padded by millimetres (z -19.5 reported where the profile
  geometry reaches about -15.7 by calculation): no position checks from it there.
- STL export (`nxre.stl_export`): a file name ending in `.tmp` was not found afterwards, the same call with a
  name ending in `.stl` wrote the file.
- Pattern pitch does not change the volume: prove a pitch regeneration by a position, not by a volume.
- A straight tangent line from a wall corner to a bowl circle looked like the intent and was 1.3 - 2 mm
  off; the section overlay showed a second arc. Check every assumed transition against a plan section.

Reasoned but NOT observed: a sketch on an offset plane whose dimensions refer to the absolute datum axes
should be solved against those axes, not against the local origin its coordinates were drawn from. The
bowl sketches therefore take a datum axis through their own origin as reference (`vax=`); the revolve
failure that prompted this had the on-axis cause above, so the effect itself was never seen.

## Re-running

The journal and the scripts expect `C:\NX_MCP_WORKSPACE\dreame_cover\` (`build.py`, `run.ps1`, `nxlib\`,
`an\` = `analysis/`) and the scan under `C:\Users\marya\Downloads\dreame_mop_assembly_bottom_cover\`:

```
powershell -File C:\NX_MCP_WORKSPACE\dreame_cover\run.ps1 -Stage z        # a, b, c, d = stop after that stage
python an\overview.py                                                      # once: mesh cache, warp field, height maps
python an\ovl.py out\dreame_mop_bottom_cover.stl o.png x 50,115 lim -86 -64 -19 2 cols 2
~\.venvs\cadgenbench\Scripts\python an\dev.py out\dreame_mop_bottom_cover.stl tag n 800000 [raw]
```

`ps.py` and `geo.py` are job-local: they are exercised by this build only (71 sketches) and are not in
`nxf` or its self-test. `common.py` carries this part's paths and its warp model.
