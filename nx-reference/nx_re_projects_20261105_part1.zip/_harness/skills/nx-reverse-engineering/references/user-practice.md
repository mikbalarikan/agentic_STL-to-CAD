# Reverse engineering in the user's own parts (mined, read-only)

Source: `C:\NX_MCP_WORKSPACE\skill_census\extracts_dedup\` (639 distinct user parts; `by_class\*.jsonl`,
`sequences.txt`, `parts_index.tsv`). Counts are instances / parts. Everything here is `[mined]`.

## 1. How much of it there is

| Item | Count |
|---|---|
| Parts holding at least one **Convergent Body** (scan / mesh import, class `Brep`, name "Convergent Body") | 132 parts, 1394 bodies; 95 parts hold exactly one, a few hold 22-44 (multi-shell watch meshes) |
| Parts with Fit Surface, Fit Curve or Flattening and Forming | 70 (Fit Surface 60, Fit Curve 19, Flattening 10) |
| `FitSurface` | 394 / 60 - Plane 332 / 54, Cylinder 39 / 14, Cone 20 / 5, Freeform 3 / 3, Sphere 0 |
| `FitCurve` | 54 / 19 - circle 31, line 8 (15 more are suppressed copies in one linked part) |
| `FlatteningAndForming` | 156 / 10 (all in the "Watch David STL to CAD" sessions) |
| `StudioSpline` | 330 / 28, of which 314 in the watch sessions |
| Projects | `REMAKE AI - DIY\A8S previous project` (18 parts), `REMAKE AI - DIY\OOMWOO_CAD\01_SOURCED_reverse-engineered` (18), `Watch - Indsutrial Design` (16), `Watch David STL to CAD` (12), `ARCHIVED\RemakeAI` (3), `LANTURN RE\reverse engineered` (1) |

Fits per part: 31 of the 60 parts have **one** Fit Surface (a datum for alignment or a sketch plane); the
heavy rebuilds have 10-88 (`Circle_004_obj.prt` 88, `Circle_003_obj.prt` 44, `A8S-C01.prt` 33,
`A8S-U05-2.prt` 24). A Fit Surface part is otherwise an ordinary feature model: 52 of 60 contain sketches,
46 extrudes, 46 datum planes, 37 Trim Body, 34 booleans, 31 edge blends, 30 Replace Face, 27 Offset Region,
24 Extend Sheet, 19 Sew, 18 Trim and Extend.

## 2. Fit Surface settings (187 builder read-backs)

| Setting | Values |
|---|---|
| `Type` | Fitplane 154, Fitcylinder 23, Fitcone 8, Fitfreeform 2 |
| `TargetOption` | **FacetRegion 187 of 187** (facets picked on the convergent body; never a point set or colour region) |
| Parent | Convergent Body in 386 of 394 (the rest: linked face / body) |
| `IsAutomatic` (point rejection) | plane: off 97, on 57 - cylinder: on 21 of 23 - cone: on 6 of 8 - freeform: off |
| `Rejection Threshold` | **0.1** (71), 0.2 (41), 0.07 (13), 0.05 (3), 0.08 (1) mm |
| `IsRadius` + `Radius` (cylinder) | on in 12 of 23: 3, 3, 3.95, 4.45, 62.1, 14.06, 3.75, 3.65, 18.7, 3.05, 6.4, 14.8 - typed values on a 0.05 mm grid, not raw fits |
| `IsConstrained` + `VectorConstraint` | plane 4 of 154, cylinder 6 of 23, **cone 8 of 8**; mostly +Z or -Z of the datum, a few along a previously fitted axis |
| `BodyTypePreference` | Sheet 179, Solid 8 (cones 6, cylinders 2 - the solid is used directly as a boolean / trim tool) |
| `IsSingleSurface` | True 125, False 62 |
| `IsClosed` | True 172 (full cylinder / cone), False 15 |
| `DirectionOption` | BestFit 187 |
| Freeform `Parameterization` | degree 5 x 5, 1 x 1 patch (one fit 4 x 1), `SmoothFactor` 0 (one fit 40) |

Neighbours in the tree: 201 of 332 plane fits follow another plane fit (the planes of one region are fitted
in a batch before anything is built on them). After a plane fit comes `DATUM_PLANE` 39, `EXTEND_SHEET` 28,
`REPLACE_FACE` 22, `DATUM_CSYS` 13; after a cylinder fit `THICKEN_SHEET` 7, `OFFSET_REGION` 6,
`EXTEND_SHEET` 3, `DATUM_AXIS` 2; after a cone fit `TRIM BODY` 9.

What consumes a fitted surface (features whose parents include a Fit Surface):

| Consumer | Count | Typical value |
|---|---|---|
| Extend Sheet | 170 / 16 | offset 5 (37), 1 (13), 23 (11), 14.5, 13, 7.8 ... "enough to overshoot" |
| Replace Face | 167 / 15 | offset 0 in 165; `ReverseDirection` True in 15 of 39 |
| Trim and Extend | 110 / 14 | make corner between two fitted planes |
| Trim Body | 65 / 18 | plane offset 0 in 30 |
| Trim Sheet | 59 / 11 | |
| Datum Plane | 52 / 29 | offset 0 in 29 (a datum ON the fitted plane) |
| Sew | 44 / 12 | |
| Datum CSYS | 40 / 19 | sketch planes on the fit |
| Boolean | 38 / 10 | fitted solids / thickened fits |
| Extract Face / Body | 19 / 5 | copy before trimming |
| Extrude | 17 / 6 | |
| Thicken | 12 / 4 | first offset 1, -0.6, 2, 1.2, 3.2; second 0 |
| Offset Surface | 10 / 7 | |

## 3. Fit Curve settings (39 read-backs)

- `TargetSourceType` **SpecifiedPoints 39 of 39**; the targets are points picked on the mesh (22-28 points
  typical, up to 897). No fit uses a curve, face or facet-body target.
- `Type` FitCircle 31, FitLine 8; `Degree` 3, `Segments` 1 (spline type unused), `IsAssociative` True.
- `CanRejectPointsAutomatically` True 28 of 39; threshold **0.07** (20), 0.1 (8).
- Circles: `IsClosedCurve` True 10 (full circle), False 21 (arc); `HasRadius` True 12 with typed radii
  2, 2.96, `5.80/2`, 15.45, 13.35, 42.3 (again the 0.05 mm grid; `5.80/2` is a caliper diameter).
- Arcs and lines are lengthened with `Extender` ByValue: 0.35-0.45 mm on arcs, 3.4-73.5 mm on lines, so the
  fitted piece overshoots its neighbours and can be trimmed.
- What follows: `EXTRUDE` 20 (circle or arc -> cylinder / cut), `SWP104` (Sweep Along Guide) 6 for lines,
  `POINT` / `CPROJ` (centre point, projection into a sketch) 4.

## 4. Scan handling

| Operation on the convergent body | Count | Reading |
|---|---|---|
| Move Object | 26 / 8 | alignment. Several have the scan plus one or two Datum CSYS as parents and no expression (a CSYS-to-CSYS move); the rest are small corrections: displacement 0.65, 0.9, 1 mm, angle 8.4, 16.8 deg |
| Split Body | 11 / 10 | tool = an extruded sheet (9) or a datum CSYS plane (2); followed by Delete Body (8) - isolate the region to work on |
| Intersection Curve | 9 / 5 | scan x datum plane / offset surface, then trimmed curves, Fit Surface or Extrude |
| Scale | 4 / 4 | factor 10 (two parts) and 86 (two parts): size / unit correction of the imported mesh |
| Sketch with the scan as parent | 23 / 18 | profiles drawn over the mesh |
| Trim Body | 0 | never on the scan itself (Split Body + Delete Body instead) |

`SectionCurve` (74 / 21) is **not** a scan tool in these parts: its objects are faces of the rebuilt solid
(`ObjectsToSection` Face 59, Body 1; no convergent parent). Sections of the scan are made with Intersection
Curve or by sketching. Section settings when used: `Type` Selected, associative, datum plane or section
plane, plane offset 0 in 30.

## 5. Workflows (feature-tree excerpts)

**W1 - one datum fit, then an ordinary feature model over the scan** (31 parts have a single fit)

`A8S-H05.prt`: `DATUM_CSYS > BREP > Fit Surface(Plane) > DATUM_PLANE > Fit Curve > POINT > CPROJ > Fit Curve >
DATUM_CSYSx2 > SKETCH > EXTRUDEx3 > BLEND > OFFSET_IN_FACE > DIVIDE_FACE > OFFSET_REGION > REPLACE_FACEx2 > UNITE`
- plane fit gives the sketch plane, a fitted circle gives the centre, the part is sketched and extruded,
synchronous edits finish it.

`Nautilus_Case.prt`: `BREP > DATUM_PLANE > SKETCH > Fit Surface(Plane) > DATUM_PLANE > EXTRUDE > ... > INTERSECT >
REPLACE_FACE > SKETCH > EXTRUDE > REPLACE_FACEx3 > UNITE > ... > CHAMFER > REPLACE_FACE > BLEND ...`

**W2 - align the scan first**

`OOM-P02 Submission.prt`: `BREP > Fit Surface(Plane) > DATUM_PLANE > Fit Surface(Cylinder) > POINT > CPROJ >
Fit Surface(Cylinder) > DATUM_AXIS > DATUM_CSYSx2 > SCALE > MOVE_OBJECTx2`
`OOM-P01 Khalid.prt`: `BREPx2 > Fit Surface(Cylinder) > DATUM_AXIS > DATUM_CSYS > Fit Surface(Plane) > DATUM_PLANE >
DATUM_CSYS > MOVE_OBJECTx2 > Fit Surface(Cylinder) > POINT > DATUM_AXIS > MOVE_OBJECTx3 > EXTRUDEx2 > UNITE > CYLINDER > ...`
`OOM-B02.prt`: `BREPx2 > Fit Surface(Plane) > DATUM_PLANE > Fit Curve > POINT > CPROJ > DATUM_CSYS > MOVE_OBJECTx3 > ...`
- a plane (the seating face) and a cylinder or circle (the functional axis) define a datum CSYS on the scan;
Move Object carries the scan onto the absolute CSYS; further small Move Objects correct it.

**W3 - fitted planes become the faces** (the bulk of the 332 plane fits)

`A8S-U01.prt`: `BREPx2 > OFFSET_REGION > Fit Surface(Plane) > EXTEND_SHEET > Fit Surface(Plane) > EXTEND_SHEET >
TRIM_AND_EXTENDx2 > Fit Surface(Plane) > EXTEND_SHEET > TRIM_AND_EXTENDx4 > SEW > TRIM BODY > MIRROR_FACE > CHAMFER >
Fit Surface(Plane)x2 > EXTEND_SHEETx2 > TRIM_AND_EXTENDx2 > SEW > TRIM BODY > MIRROR_FACE ...`
- fit, extend, corner the sheets pairwise, sew them to one tool quilt, Trim Body the solid with it.

`A8S-C07-01.prt`: `... Fit Surface(Plane) > REPLACE_FACE > Fit Surface(Plane) > REPLACE_FACE > ... > Fit Surface(Plane)x3 >
Geometry Instance > EXTRACT_BODY > EXTEND_SHEET > TRIM_AND_EXTENDx3 > TRIM BODY > SKIN > SEW > EXTEND_SHEET > TRIM BODY > BLENDx12`
`Circle_004_obj.prt`: `BREPx44 > DATUM_PLANE > SKETCH > EXTRACT_STRING > EXTRUDE > Fit Surface(Plane)x5 > REPLACE_FACEx2 >
Fit Surface(Plane)x39 > REPLACE_FACEx39 > Mirror Feature > ... > Fit Surface(Plane)x43 > REPLACE_FACEx36`
- a rough extruded solid, then every facet-flat of the watch bezel is fitted and the solid's face is
replaced by it (88 fits, 75 Replace Face).

**W4 - fitted cylinders and cones**

`OOM-W01.prt` (drive wheel): `... Fit Surface(Cylinder) > THICKEN_SHEET > REPLACE_FACEx2 > Delete Body >
Fit Surface(Cylinder)x2 > THICKEN_SHEET > REPLACE_FACE > ... > Fit Surface(Cylinder) > THICKEN_SHEET > DELETE FACE > UNITE`
- a fitted cylinder sheet is thickened into a wall / rib and united, or used as the Replace Face target.
Cones are fitted as solids with the axis constrained and used by Trim Body (cone -> `TRIM BODY` 9 times).

**W5 - curve driven** (Fit Curve -> Extrude 20, -> Sweep Along Guide 6)

`A8S-C07-02.prt`: `BREP > DATUM_PLANE > SKETCH > EXTRUDEx2 > SHELL > UNITE > BLEND > Fit Curvex2 > CPROJ > SKETCH > EXTRUDE > ...`
`2SUBD.017_obj.prt`: `... > REPLACE_FACE > Fit Curvex2 > SWP104x2 > TRIM_AND_EXTEND > DATUM_PLANE > TRIM BODY > SKIN > SEW`
- lines fitted to mesh points, extended by value, swept into sheets; circles fitted and extruded.

**W6 - watch facets flattened to DXF** (`Watch David STL to CAD`, 10 parts)

`336235.prt`: `BREP > SKETCH > EXTRUDE > SPLINEx2 > THRU_CURVE > MOVE_OBJECT > SPLINEx3 > THRU_CURVE > EXTRUDE >
TRIM BODY > Delete Body > MOVE_OBJECT > ... > Flattening and Forming > MOVE_OBJECT > Flattening and Forming > MOVE_OBJECT ...`
- Studio Splines through points picked on the mesh (`ThroughPoints`, degree 5, 4-29 points; 240 of 314 have
  no parent feature), two splines (87 of 89 Through Curves have 2 sections, sheet body, tolerance 0.01 / 0.5)
  lofted into one developable strip per facet, strips trimmed by extruded sheets;
- `Flattening and Forming` (`Type` Calculation, source faces of the loft, a source origin point and direction)
  per strip, each followed by a Move Object that lays the flat piece out (146 of 156), then a sketch of the
  outline; the DXF export is not a feature;
- the scan itself is cut with Split Body (extruded sheet) + Delete Body; `Watch_STL_to_DXF_RV2..6` also fit
  circles (22-28 points, threshold 0.07, arcs extended 0.35-0.45) and extrude them.

`Fan volute BT cad.prt` (LANTURN RE) and `PART3_3D.prt` (fan, OOMWOO) are skin rebuilds: sketches and splines ->
`SKIN` / `THRU_CURVE_MESH` -> `EXTEND_SHEET` -> `TRIMMED_SH` -> `SEW` -> `BLEND` -> `THICKEN_SHEET`, with one or two
plane fits as datums; see `nx-surface-modeling` workflow 1.

## 6. What the data does not show

- How far the rebuilt faces sit from the scan: no deviation feature or measurement is stored in the parts.
  The only tolerance evidence is the rejection threshold (0.05-0.2 mm) and the 0.05 mm rounding of typed radii.
- Facet selection method (brush, rectangle, primitive region): the `FacetCollector` read-back is empty.
- Which Move Object motion type was used (the builder read-back has no motion option).
