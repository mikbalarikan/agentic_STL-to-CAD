# Reverse engineering in NX 2206: NXOpen recipes and measurements

All code below runs headless through `nx-journal-core/scripts/run_journal.ps1`; the helpers named `nxre.*`
are in `scripts/nxre.py`, `nxh.*` / `nxf.*` in `nx-journal-core/scripts`. Evidence = the three journals in
`scripts/` (`re_fit_surfaces.py` 48 checks, `re_sections_fitcurve.py` 27 checks, `re_rebuild_compare.py`
23 checks, `re_unknown_part.py` 36 checks). Test scans were made from NX solids with known dimensions: exported to STL, subdivided to
2-2.5 mm triangles and given 0.02 mm Gaussian vertex noise (`nxre.make_scan`); the "clean" variant has no noise.

## Status

| Item | Status | Key measurement |
|---|---|---|
| STL export of a solid (UF) | VERIFIED | 1222 triangles at chord 0.005; re-imported volume 31147.58 vs 31149.03 (-4.6e-5, noisy mesh) |
| STL import -> convergent body | VERIFIED | 46 472 triangles -> 46 472 facets, 1 body, 1 face (UF type 67), 0 edges, solid, 0.5 s for 111 k facets |
| Facet access and caching | VERIFIED | `GetVertices()`: 4.2 s for 46 k facets (0.09 ms each), 39-40 s for 111 k (0.35-0.36 ms each): about quadratic. `Scan(every=4)` on 111 k: 9.7 s. `Vertex0/1/2` + `GetUnitNormal()`: 154 s for 111 k |
| Census of an unknown scan (`nxre.census`) | VERIFIED | 9 of 9 planes, 4 of 4 cylinders, nothing spurious; noise 0.0192 for 0.02; 1.3 s on 28 k rows |
| General alignment (`nxre.alignment` + `apply_alignment`) | VERIFIED | two-rotation pose recovered to 0.004 deg / 0.003 mm with ONE axis-angle Move Object + one translation; residual 0.00002 mm / 0.005 deg |
| Measure-only fits (`measure_plane`, `fit_table`) | VERIFIED | 13 regions, 22 table rows, 0 features left; all values snap to truth |
| Signed deviation with percentiles and regions | VERIFIED | RMS 0.0201, p95 0.038, p99 0.052, 0.26 % over 3 sigma; a 0.05 mm offset flags exactly the 4 offset faces |
| Best Fit Align (scan to CAD body) | PARTIAL | RMS 0.683 -> 0.169 mm, does not reach the 0.02 noise level |
| Detect Primitives | NOT WORKING as tried | commits, convergent body still has 1 face |
| Region = explicit facet list (`CreateRuleSingleFacet`) | VERIFIED | regions of 537-10 705 facets, fit time 0.03-0.3 s |
| Region = primitive rule (`CreateRulePrimitiveFacets`) | VERIFIED on a clean mesh, PARTIAL on a noisy one | clean: whole plane 8884, whole hole 1134 facets; noisy: 515 of 7699 plane facets |
| Region = tangent rule (`CreateRuleTangentFacets`) | PARTIAL | tolerance in degrees; clean mesh 30 deg = whole cylinder, noisy mesh stops early |
| Fit Surface, plane | VERIFIED | 9 planes: offset error <= 0.0005 mm, normal <= 0.010 deg (noise 0.02 mm) |
| Fit Surface, cylinder | VERIFIED | radius error -0.0016 ... -0.0031, axis 0.02-0.06 deg, axis position <= 0.0011 mm |
| Fit Surface, snapped radius / fixed axis | VERIFIED | radius exactly 10, axis exactly Z, scan RMS about the fit unchanged (0.0198) |
| Fit Surface, cone | VERIFIED (free fit, axis + half angle); axis-only constraint NOT WORKING | half angle 22.606 vs 22.620 deg; axis-only gave 89.87 deg, RMS 3.5 mm |
| Fit Surface, sphere | VERIFIED | radius +0.0007, centre 0.0010 mm; snapped radius exact |
| Fit Surface, freeform | VERIFIED | degree 5 x 5 one patch: max 0.0039 mm from the true R100 sphere; degree 3 x 3: 0.016 |
| Fit Surface, solid output | VERIFIED | cylinder -> 3-face solid |
| Section Curve on the scan | VERIFIED | one degree-1 spline per loop; loops lost when the plane passes through mesh vertices |
| Intersection Curve on the scan | VERIFIED (many pieces) | 126 splines for 3 loops |
| Fit Curve on points: circle, arc, line, spline | VERIFIED | hole R 3.9968 (-0.0032), centre 0.007 mm; line 0.003 deg / 0.006 mm |
| Fit Curve on a curve / face / facet body target | NOT WORKING | "Unable to fit curve due to insufficient number of fitting points" |
| Alignment by fitted planes + Move Object (rotation about Z) | VERIFIED | 17.0001 deg found for a true 17; datum faces within 0.00015 mm / 0.005 deg afterwards |
| Feature rebuild from fitted + snapped values | VERIFIED | volume = truth to 1e-12; scan RMS 0.0200, max 0.062 mm |
| Signed deviation scan -> solid | VERIFIED | 1 mm inside = -1.000000, 1 mm outside = +1.000000; mean over 705 vertices +0.0006 |
| Replace Face onto fitted planes | VERIFIED | 63 x 43 x 11 blank -> bbox within 0.0011 mm of 60 x 40 x 8, volume 19 199.79 |
| Extend Sheet + Trim Sheet + Sew of fitted planes | VERIFIED | 6 sheets -> solid, 0 free edges, volume 19 199.79 |
| Move Object, Extract Body, Scale Body on a convergent body | VERIFIED | shift 100.000, copy keeps 46 472 facets, x2 scale = volume x 8.000 |
| Trim Body, Split Body on a convergent body (datum plane) | VERIFIED | trim: facet face + exact planar caps, still solid; split: 2 convergent pieces, volumes add to 1.000000 |
| Snip Facet Body at a plane | NOT WORKING as tried | committed without error, body unchanged |
| Divide Facet Face, Deviation Checking / Gauge, Flattening and Forming | NOT PROBED | builders exist (see the end) |

## 1. STL out and in

```python
# export one solid body (UF). csys argument: pass 0 (None and Tag.Null fail)
h = UFS.Std.OpenBinaryStlFile(path, False, "header")
nerr, info = UFS.Std.PutSolidInStlFile(h, 0, body.Tag, 0.0, 1000.0, 0.005)   # min edge (unused), max edge, chord tol
UFS.Std.CloseStlFile(h)
```
- `nerr` was 1 on a body with a full spherical dome although the file was complete and imported as a closed
  convergent solid: judge the export by re-import (volume), not by the count.
- `S.DexManager.CreateStlCreator()` also exists (`OutputFile`, `ChordalTol`, `AdjacencyTol`,
  `ExportSelectionBlock` = a `SelectObjectList`); not needed.

```python
b = part.FacetedBodies.CreateSTLImportBuilder()
b.File = path
b.STLFileUnits = NXOpen.Facet.STLImportBuilder.STLFileUnitsTypes.Millimeters      # or Inches
b.FacetBodyType = NXOpen.Facet.STLImportBuilder.FacetBodyTypes.Psm                # convergent
b.ShowInformationWindow = False
b.Commit(); b.Destroy()
bodies = nxh.new_bodies(part, before)          # Commit returns nothing useful
```
The result: feature `Convergent Body(n)` (FeatureType `BREP`, class `Brep`); `body.IsConvergentBody` is a
**property**; `body.GetNumberOfFacets()`; one `Face` of UF type 67 (no point / direction / radius data), no
edges; `IsSolidBody` True when the mesh is watertight, and then `nxh.volume` works. A wrong unit choice shows
as a bounding box 25.4x off: fix with `nxf.scale_body` (the user scaled meshes by 10 and 86).

## 2. Facets and regions

```python
col = part.FacetCollectorCollection.CreateCollector()
col.AddRules([part.FacetSelectionRuleFactory.CreateRuleBodyFacets([body])])
for f in col.GetFacets():                      # NXOpen.ConvergentFacet
    a, b, c = f.GetVertices()                  # 3 Point3d in ONE call - fast
```
`nxre.Scan(part, body, every=1)` caches (facet, centroid, normal, vertices) by walking `GetFirstFacetOnBody` /
`GetNextFacet`; `scan.pick(pred)` returns the rows whose
centroid / normal satisfy a predicate, `scan.seed(xyz, normal)` the facet nearest a point, `scan.slice(axis,
value)` the mesh / plane crossing points. Other members: `f.GetAdjacentFacet(0..2)`, `f.OwningFace`,
`f.FacetIdentifier`, `f.GetUnitNormal()`, `f.GetPlaneEquation()`; `body.GetFirstFacetOnBody()` /
`body.GetNextFacet(f)` enumerate without a collector (3000 facets in < 10 ms).

Rules of `part.FacetSelectionRuleFactory` (each returns a rule for `FacetCollector.AddRules`):

| Rule | Behaviour measured |
|---|---|
| `CreateRuleSingleFacet([facets])` | exactly these facets - the journal's rectangle / lasso; 10 705 facets pass in one rule |
| `CreateRulePrimitiveFacets(seed, factor)` | grows over one plane / cylinder / cone / sphere. Clean mesh: the whole face for any factor 1-100 (plane 8884, hole 1134, boss 4200). Noisy mesh (0.02 mm): 515 of 7699 plane facets, 284 of 1134 hole facets, whole boss; the factor (1-100) changes nothing above 5 |
| `CreateRuleTangentFacets(seed, deg)` | angle between neighbours; clean: 0.05 = whole plane, 30 = whole cylinder; noisy: 1-2 facets below 15, partial at 30 |
| `CreateRuleBodyFacets([bodies])`, `CreateRuleFaceFacets([faces])` | everything of a body / convergent face |
| `CreateRuleFloodFillFacets`, `CreateRuleFillBoundary`, `CreateRuleFineBrushFacets`, `CreateRuleRoughBrushFacets`, `CreateRuleColorRegionFacets`, `CreateRuleWithinCurves` | exist, not probed |

A fit on the partial primitive region of the noisy plane was still good (0.04 deg, 0.0002 mm), on the partial
hole region not (radius -0.013, axis 0.013 mm; on a 1.5 mm mesh -0.24 mm): for cylinders make sure the region
covers most of the circumference - count the facets (`nxre.region_facets`) or pick them yourself.

A greedy walk over `GetAdjacentFacet` towards a target point gets stuck (ended 6-57 mm away): do not use it
to find seeds; use `Scan.seed`.

## 3. Fit Surface

```python
FS = NXOpen.Features.FitSurfaceBuilder
b = part.Features.CreateFitSurfaceBuilder(NXOpen.Features.FitSurface.Null)
b.Type = FS.Types.Fitplane            # Fitcylinder | Fitcone | Fitsphere | Fitfreeform
b.TargetOption = FS.TargetType.FacetRegion
b.FacetCollector.AddRules([rule])     # builder-owned collector
b.IsSingleSurface = True              # one surface through everything selected
b.IsAutomatic = True; b.RejectionThresholdValue.RightHandSide = "0.1"     # point rejection (optional)
b.IsRadius = True;    b.RadiusValue.RightHandSide = "10"                  # fix the radius (cylinder, sphere)
b.IsConstrained = True; b.VectorConstraint = nxh.direction(part, (0, 0, 1))   # fix normal / axis
b.IsHalfAngle = True; b.AngleValue.RightHandSide = "22.5"                 # fix the cone half angle
b.BodyTypePreference = FS.BodyType.Solid                                  # closed primitive as a solid
b.Parameterization.UDegree, b.Parameterization.VDegree = 5, 5            # freeform; UPatches / VPatches
feature = b.CommitFeature(); b.Destroy()
```
= `nxre.fit_surface(part, rules, kind, reject=, radius=, axis=, half_angle=, solid=, degree=, patches=, smooth=)`.
FeatureType is `Fit Surface(Plane)`, `Fit Surface(Cylinder)`, `Fit Surface(Cone)`, `Fit Surface(Sphere)`,
`Fit Surface(Freeform)`; class `FitSurface`. Expressions created: `Rejection Threshold`, `Radius`, the angle.

Reading the result (`nxre.fit_face(feature, nxh.PLANE)` -> face, data) with `UFS.Modeling.AskFaceData`:
plane -> point on the plane + normal; cylinder -> point on the axis + axis + radius; cone -> point on the
axis, radius AT that point, half angle in radians (7th value); sphere -> centre + radius; freeform -> a
B-surface (type 43), evaluate it with `AskFaceUvMinmax` + `AskFaceProps`.

Measured on the noisy scan (sigma 0.02 mm, regions picked as explicit facet lists):

| Fit | Result vs truth | Scan RMS about the fit |
|---|---|---|
| 9 planes (313-3379 mm2) | offset -0.0005 ... +0.0002 mm, normal 0.0003-0.010 deg | 0.019-0.022 |
| boss cylinder R10 | R 9.99686, axis 0.024 deg, axis position 0.0009 mm | 0.0194 |
| holes R4 (x2), wall hole R5 | R 3.99823 / 3.99843 / 4.99823, axis 0.035-0.061 deg, position 0.0006-0.0011 | 0.019-0.021 |
| boss with `IsRadius` 10 + axis Z | R 10.000000, axis 0.000 deg, position 0.0009 | 0.0198 |
| clean mesh, hole R4, primitive rule | R 3.99776 (the chord error of the tessellation), axis exact | - |
| cone, free | half angle 22.606 deg (true 22.620), axis 0.013 deg / 0.0028 mm | 0.0182 |
| cone, axis Z + half angle 22.5 | axis position 0.0005 mm | 0.0186 |
| cone, axis Z only | half angle 89.87 deg, axis 0.37 mm off | **3.50** |
| sphere R12 | R 12.00074, centre 0.0010 mm | 0.0177 |
| freeform 5 x 5, 1 patch, on an R100 sphere patch 60 x 40 | max 0.0039, RMS 0.0014 mm from the true sphere | 0.0189 |
| freeform 3 x 3 | max 0.0159, RMS 0.0085 | 0.0196 |
| freeform 5 x 5, smooth factor 40 | as 5 x 5 | 0.0189 |

Behaviour and traps:
- **Radii come out small**: the vertices of a faceted cylinder lie on it but the triangles cut inside, and
  subdivided / decimated meshes put vertices on the chords: -0.002 ... -0.003 mm here at chord 0.005.
- **`IsSingleSurface`**: True = one surface through all selected facets; False = one surface per connected
  island of the selection (two bottom patches -> 2 sheets; a selection with stray facets gave 909 sheets in
  one feature). Always set it explicitly.
- **Sheet extent**: a plane sheet covers the bounding rectangle of the region (no more), a cylinder / cone
  the full 360 deg over the axial extent of the region (`IsClosed` True), a sphere the full sphere, a freeform
  the region's bounding patch. Extend before trimming (Extend Sheet, natural curvature).
- **Rejection** (`IsAutomatic`) changed nothing measurable at 0.02 mm noise (threshold 0.05-0.1); it is for
  outliers (edges, blends, dirt) inside the region.
- The fit is **associative** to the convergent body (feature parent `Convergent Body`): after a Move Object
  inserted earlier it regenerates. Facet objects cached before a move / trim are stale - rebuild `nxre.Scan`.
- `TargetOption` also has `Object` (`TargetObject` = facet body / point set) and `ColorRegion`; not probed.

## 4. Section curves and Fit Curve

```python
b = part.Features.CreateSectionCurveBuilder(NF)
b.Type = NXOpen.Features.SectionCurveBuilder.PlaneType.Selected
b.Tolerance = 0.01
b.ObjectsToSection.Add(convergent_body); b.SectionPlanes.Add(datum_plane); b.Associative = True
f = b.Commit(); b.Destroy()                      # f.GetEntities() -> one Spline per closed loop
```
= `nxre.section_curves(part, body, datum_plane)`. Measured: plane z = 4.3 through the bracket base -> 3
splines (outline 200.82 for a true 200.00, hole loops 25.38 / 25.41 for 25.13); z = 14.3 -> 2 loops (64.11 /
97.52 for 62.83 / 96.00). The loops are zig-zag polylines through the noisy facet crossings: 0.4-2 % too
long, so **never dimension from a raw section** - fit it. A plane through mesh vertices (z = 13 on a mesh
with vertices at z = 13) returned 1 of 2 loops: move the plane a fraction of a millimetre and count loops.
Intersection Curve (`FirstFace` = `CreateRuleFaceBody(scan)`, `SecondFace` = `CreateRuleFaceDatum([dp])`,
`Tolerance` 0.01) works too but returns 126 pieces for the same 3 loops.

```python
FC = NXOpen.Features.FitCurveBuilder
b = part.Features.CreateFitCurveBuilder(NXOpen.Features.FitCurve.Null)
b.Type = FC.Types.FitCircle                       # FitLine | FitSpline | FitEllipse
b.TargetSourceType = FC.TargetSourceTypes.SpecifiedPoints
for p in point_objects: b.Target.Add(p)           # NXOpen.Point objects
b.CanRejectPointsAutomatically = True; b.RejectionThreshold.RightHandSide = "0.07"
b.IsClosedCurve = True                            # full circle; False = arc over the points
b.HasRadius = True; b.Radius.RightHandSide = "4"  # snap
b.IsAssociative = True
f = b.CommitFeature(); b.Destroy()                # f.GetEntities() -> Arc / Line / Spline
```
= `nxre.fit_curve(part, points, kind, reject=, radius=, closed=)`; points from `nxre.points(part,
scan.slice(2, 4.3)-filtered, n)`. FeatureType `Fit Curve`, class `FitCurve`.

| Fit (130-150 points from the mesh slice) | Result |
|---|---|
| circle on the R4 hole | R 3.99679 (-0.0032), centre 0.0071 mm off |
| same with `HasRadius` 4 | R 4.000000, centre 0.0073 mm off |
| circle on the R10 boss | R 9.99846, centre 0.0027 mm off, full 360 deg arc |
| arc on 150 deg of the boss, `IsClosedCurve` False | R 9.99830, centre 0.0065 mm off, sweep 148.8 deg |
| line on the y = 0 side | direction 0.0032 deg, offset 0.0056 mm |
| spline (degree 3, 1 segment) on a quarter of the boss | Spline feature |

- Targets `Curve`, `Face`, `FacetBody`, `ChainedPoints`, `Infer` all raise "Unable to fit curve due to
  insufficient number of fitting points" in batch (section spline or convergent body added to `Target`).
- The fitted circle is a normal curve feature: `nxh.section_feature(part, [fit_feature])` -> Extrude gave the
  exact pin volume pi*16*8 = 402.1239.
- The user lengthens fitted arcs and lines with `b.Extender` (`StartExtensionOption` / `EndExtensionOption`
  ByValue, `StartValue` / `EndValue`); not exercised here.

## 5. Aligning the scan

Verified sequence (`re_rebuild_compare.py`, scan rotated 17 deg about Z and shifted (12, -7, 3)):
1. Fit a plane on a face that must be square to a datum (the wall): its normal gives the rotation,
   `atan2` -> 17.0001 deg.
2. `nxf.move_object(part, [scan], "angle", -17.0001, vec=(0, 0, 1), origin=(0, 0, 0))`.
3. Rebuild the facet cache, fit the three datum faces, read their offsets (9.4289, -10.2021, 3.0001) and
   `nxf.move_object(part, [scan], "delta", (-dx, -dy, -dz))`.
4. Check: re-fit the three faces -> offsets <= 0.00015 mm, angles <= 0.005 deg.

The user does the same thing with a datum CSYS built on a fitted plane + a fitted cylinder axis and one
Move Object (CSYS to CSYS), followed by small displacement / angle corrections (`references/user-practice.md`
W2). The general case (any pose) is section 9.

## 6. Rebuild and compare

Feature route (preferred for prismatic parts): read every fitted plane position and cylinder axis / radius,
`nxre.snap(value, 0.5, 0.05)` each to the design grid, create named expressions, build with Block / Cylinder /
booleans (or sketches and extrudes). Measured on the bracket:

| | Volume vs truth 31 149.0264 | Scan -> CAD deviation (705 vertices) |
|---|---|---|
| fitted values unrounded | -3.3e-5 relative | max 0.0615, RMS 0.0200 |
| snapped to 0.5 mm | 0 (2e-16) | max 0.0617, RMS 0.0200, signed mean +0.0006 |
| boss radius snapped wrongly to 10.5 | - | **max 0.549, p95 0.502, RMS 0.157** |

Largest raw parameter error before snapping 0.0031 mm (a radius); all 21 parameters snapped to truth.
The snapped model is parametric: `re_boss_d` 20 -> 24 changed the volume by pi*44*10 = 1382.3008 exactly.

Deviation check:
```python
d = nxh.dist_to(part, solid_body, xyz)       # SIGNED for a solid: -1.000 one mm inside, +1.000 one mm outside
nxre.signed_deviation(part, solid, pts)      # {min, max, mean, rms}
nxre.deviation(part, faces, pts)             # unsigned, to a face list (single fitted sheet, or body.GetFaces())
```
Sample 500-1000 facet vertices (`scan.vertices(n=700)`): about 1 s. Expected on a correct rebuild: RMS = the
scan noise, max = 3 sigma + local form error, signed mean ~ 0. A systematic sign (mean far from 0) means a
face is offset; a p95 that jumps while the RMS barely moves means one feature is wrong.

Surface routes on the same fitted planes (the base slab 60 x 40 x 8):
- **Replace Face**: an oversize blank (63 x 43 x 11), `ReplaceFaceBuilder` with `FaceToReplace` = the blank
  face and `ReplacementFaces` = the fitted face (dumb face rules), commit; when it raises, undo and set
  `ReverseDirection = True` (needed for 3 of 6 faces here; the user's parts have True in 15 of 39). Result
  bbox (0.0001, 0.0003, 0.0, 60.0004, 39.9989, 8.0001), volume 19 199.79.
- **Fit -> datum plane on the fit -> Extend Sheet 12 -> Trim Sheet -> Sew**: `nxf.datum_plane(part, "offset",
  [fit_face], 0)`; `nxf.extend_sheet(part, sheet.GetEdges(), 12)`; `nxf.trim_sheet(part, sheet, keep_point,
  keep=True, datum_plane=other_dp)` for the four neighbours, keep_point ON the sheet; `nxf.sew` -> solid, 6
  faces, 0 free edges, volume 19 199.79. Trimming a sheet with the neighbouring *sheets* instead of datum
  planes failed with "Invalid retained/discarded regions." (a 5 mm extension did not reach the neighbour, and
  already-trimmed tools no longer cross the whole target).

## 7. Operations on the convergent body

| Operation | Call | Result |
|---|---|---|
| Move Object | `nxf.move_object(part, [scan], "delta" / "angle", ...)` | bbox shift 100.000; facet count unchanged |
| Extract Body | `nxf.extract_body(part, [scan])` | convergent copy, 46 472 facets |
| Scale Body | `nxf.scale_body(part, [copy], 2)` | volume x 8.000 |
| Trim Body, datum plane | `nxf.trim_body(part, scan, datum_plane=dp)` | 31 147.6 -> 15 578.0; faces = facet face + exact planar caps (types 67, 22, 22); still solid. Afterwards `body.GetNumberOfFacets()` raises "Function expects a facet topology, but input given is a non-facet topology." - the body is mixed |
| Split Body, datum plane | `nxf.split_body(part, [copy], datum_plane=dp)` | 2 convergent pieces, volumes add to 1.000000. One attempt on a x2-scaled copy at its exact bounding-box mid-plane raised "The tool and target do not form a complete intersection or have a touch condition which will result in a region with zero wall thickness." (cause not isolated; the plane 0.37 mm off the middle of an unscaled copy worked) |
| Snip at plane | `part.FacetedBodies.CreateSnipFacetBodyBuilder()`, `Type = SnipAtPlane`, `Bodies.Add`, `Plane` | no error, body unchanged - not usable as tried |

## 8. Builders that exist but were not probed

`part.FacetedBodies`: `CreateBestFitAlignBuilder`, `CreateMultiPatchAlignmentBuilder`, `CreateDecimateFacetBodyBuilder`,
`CreateSubdivideFacetBodyBuilder`, `CreateSmoothFacetBodyBuilder`, `CreateFillHoleBuilder`, `CreateSewFacetBodyBuilder`,
`CreateFacetFeatureExtractionBuilder`, `CreateFacetCurvatureBuilder`.
`part.FacetedBodies.FacetModelingCollection`: `CreateDetectPrimitivesBuilder` (`FacetSelection`, `CurvatureSensitivity`,
`BlendFactor`, colours per primitive type), `CreateDivideFacetFaceBuilder` (`Type` ByRegion / ByCurves, `FacetCollector`),
`CreateCleanupFacetBodyBuilder`, `CreateRemeshFacetBodyBuilder`, `CreateMeshFromCloudBuilder`, `CreatePaintFacetBodyBuilder`,
`CreateReplaceMeshWithFaceBuilder`, `CreateConvertFacetBodyBuilder`.
`part.Features`: `CreateRapidSurfaceBuilder`, `CreateRefitFaceBuilder`, `CreateSnipSurfaceBuilder`,
`FreeformSurfaceCollection.CreateFlatteningAndFormingBuilder`. `part.AnalysisManager.CreateDeviationCheckingObject`.
Most `Facet` builders state the licence `studio_free_form`; Fit Surface, Fit Curve and the facet rules ran
with the licences of this seat.

## 9. Unknown scans: census, alignment, fit table (`re_unknown_part.py`)

Test: the bracket scan at 1.5 mm (111 022 facets, 0.02 mm noise) turned 17 deg about Z, then 28 deg about X,
shifted (12, -7, 3). No feature position is given to the code.

**Facet cache cost.** `GetVertices()` is the only expensive call and it gets slower with the size of the body:

| Body | Call | Time |
|---|---|---|
| 46 472 facets | `Scan(part, body)` | 4.2 s (0.09 ms per facet; 0.07 ms in a 3000-facet loop) |
| 111 022 facets | `Scan(part, body)` | 38.9-40.2 s (0.35-0.36 ms per facet) |
| 111 022 facets | `Scan(part, body, every=4)` | 9.7 s (27 756 rows) |
| 111 022 facets | enumerate only (`GetFirstFacetOnBody` / `GetNextFacet`) | 0.33 s |

2.4x the facets cost 9x the time, so do not extrapolate linearly (the earlier "90 s per million" was wrong);
thin the cache or split the scan. Not usable as shortcuts: the STL file (NX reorders the facets - facet 1 was
triangle 34 240), `GetPlaneEquation()` (slower than `GetVertices()`). Not tried: the JT facet model
(`UFS.Facet.AskModelsOfSolid(body.Tag)` returns one model tag; `AskVerticesOfFacet(model, id)`).

**Census** - `cen = nxre.census(scan_cache)`; pure Python, 1.3 s on 28 k rows, 3-5 s on 111 k.
1. facets clustered by normal (5 deg, area weighted) -> candidate directions;
2. per direction an area histogram of the offsets (0.05 mm bins, +-0.3 mm window) -> plane peaks; members
   are re-collected with a 25 deg normal tolerance (noisy normals fall out of a 5 deg cluster: without this
   the areas read 30 % low); peaks under max(20 mm2, 0.4 % of the mesh area) are dropped (tangent strips of
   cylinders); a least-squares plane through the member vertices gives normal, offset and RMS;
3. `noise` = median RMS of the planes with at least a quarter of the largest area;
4. cylinders: for every plane normal as axis, the facets that belong to no plane and are square to the axis
   vote for (centre, radius, boss / hole); a circle fit on the supporters gives centre and radius; kept when
   RMS <= max(0.05, 4 x noise), coverage >= 0.15, at least 60 deg of arc;
5. `datums`: largest plane, largest plane square to it, outermost plane on the remaining side.

Measured (thinned cache, every=4): 9 planes with areas 0.96-1.02 of the true faces, plane RMS 0.018-0.026,
noise 0.0192; cylinders R 9.9971 boss, 4.9973 / 3.9962 / 3.9968 holes, each with 36 of 36 sectors; no false
entry. The full cache gives the same 9 + 4. Limits: cylinders whose axis is not a plane normal are not found
(pass `cylinder_axes=`); cones, spheres and blends are not classified (they stay unassigned); planes closer
than 0.3 mm merge; only tested on this one part.

**Alignment** - `al = nxre.alignment(primary, secondary, tertiary=..., primary_to=(0, 0, -1),
secondary_to=(-1, 0, 0))` with planes {"normal", "offset"} from the census or from `nxre.measure_plane`.
The primary normal goes exactly onto `primary_to`, the secondary onto `secondary_to` as far as squareness
allows, the common point of the three planes to the origin: x_new = R (x - origin). `al` holds `R`, the
equivalent `axis` / `angle_deg`, `origin`, `squareness_error_deg`. `nxre.apply_alignment(part, [scan], al)` =
`nxf.move_object(..., "angle", angle, vec=axis, origin=origin)` + `nxf.move_object(..., "delta", -origin)`.

| | Rotation error | Origin error |
|---|---|---|
| from census planes only (no NX fit) | 0.0049 deg | 0.0026 mm |
| from `measure_plane` on the three datum regions | 0.0044 deg | 0.0029 mm |

The single Move Object rotation was about the axis (-0.851, 0.127, -0.510) by 32.667 deg; sampled facets
landed within 3e-14 mm of `nxre.transform_point(al, p)`; afterwards the three datum faces measured 0.00002 mm
and 0.005 deg from the absolute planes (rule for "aligned": 0.01 mm, 0.02 deg). The census planes are good
enough to align; the fitted ones are not better at this noise level.

**Measure-only fits.** `nxre.measure_plane(part, rows)` and `nxre.fit_table(part, regions, grid, tol,
keep=False)` set an invisible undo mark, fit, read the face, measure the deviation and undo to the mark: the
tree is unchanged (0 features for 13 regions; `keep=True` leaves one constrained fit per region, named
`FIT_<NAME>`, sheet blanked). Facet objects cached before the mark stay valid across the undo. Regions are
thinned to 4000 facets (a `CreateRuleSingleFacet` rule with 14 000 facets took 2-8 s per fit); 13 regions
took 70 s.

`fit_table` rows on the aligned scan (census regions, design direction = nearest principal axis):

| feature | fitted free | tilt deg | constrained | snapped | RMS free | RMS snapped |
|---|---|---|---|---|---|---|
| plane (bottom) | 0.0000 | 0.0001 | 0.0000 | 0 | 0.0198 | 0.0198 |
| plane (wall inner) | 8.0028 | 0.0066 | 8.0028 | 8 | 0.0192 | 0.0190 |
| plane (side y+) | 40.0004 | 0.0064 | 40.0004 | 40 | 0.0297 | 0.0299 |
| boss radius | 9.9972 | 0.0295 | 10 (fixed) | 10 | 0.0195 | 0.0193 |
| boss axis x / y | 43.9976 / 19.9973 | | 44.0013 / 20.0029 | 44 / 20 | | |
| hole radius | 3.9971 | 0.0165 | 4 (fixed) | 4 | 0.0206 | 0.0207 |

All 22 rows snapped, worst |fitted - snapped| 0.0029 mm. The narrow side faces read RMS 0.024-0.030 because
census regions reach to the edges; pick by position 0.5-1 mm inside when a face needs a cleaner number.

**Signed deviation.** `nxre.signed_deviation(part, body, pts, threshold=3 * noise, regions={name: rows})` on
1542 vertices: RMS 0.0201, mean +0.0007, |d| p50 0.0136, p95 0.0382, p99 0.0518, max 0.0664, 0.26 % over
0.0576; region means -0.0019 ... +0.0055 (limit 0.75 x noise = 0.0144). With the CAD body moved 0.05 mm in Z
the four Z faces read +0.049, -0.049, -0.041, -0.041 and no other region passed the limit, while the global
RMS only rose to 0.043 - the per-region mean is the sensitive indicator.

**Area.** Mesh area 10 848.0 (the NX area of the convergent body is the same number) against CAD 10 395.6:
+4.35 %, while the volumes differ by -8.0e-5. Do not compare areas of a noisy scan.

**Best Fit Align** (one attempt): `b = part.FacetedBodies.CreateBestFitAlignBuilder()`;
`b.MobileObjects.Add(scan)`; `b.SourceObjects.Add(scan)`; `b.DestinationObjects.Add(cad_body)`;
`b.GlobalSearch = False`; `b.Commit()` returns the body, moves the scan, adds no feature. A scan 2 deg /
(1, -0.6, 0.8) mm off went from RMS 0.683 to 0.169 (p95 0.354): a rough pre-alignment at best.
`FitConstraints` offers Free, HoldToLine, HoldToPlane, OnlyRotation, OnlyTranslation, RotationAroundLine,
RotationAroundPoint, TranslationAlongDirection, TranslationInPlane (not exercised).

**Detect Primitives** (one attempt): `FacetModelingCollection.CreateDetectPrimitivesBuilder()`,
`FacetSelection.Add(scan)`, `Commit()` -> no error, the body still has one face.
