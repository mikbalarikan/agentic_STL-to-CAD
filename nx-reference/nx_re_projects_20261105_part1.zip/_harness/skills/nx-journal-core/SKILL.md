---
name: nx-journal-core
description: Foundation for driving Siemens NX 2206 with headless NXOpen Python journals - launching run_journal, the verified helper modules (nxh core + measurement, nxf feature helpers, nxa assembly helpers), builder lifecycle, selection-intent rules, named expressions, undo/rollback, measurement-based verification, inspecting and safely editing an existing part (inspect_part.py), editing in the middle of a history (insert point, reorder, replace feature, feature groups, suppress by expression, conditional expressions), reading a .prt without NX (prt_text.py), STEP/STL import-export. Read this first for ANY NX modelling task that goes beyond the certified nx-mcp tools (anything other than sketch-rectangle-extrude), then the feature-family skill it points to.
---

# NX journals: the core workflow

The certified `nx-mcp` tools cover only create part / sketch line-rectangle / extrude / export.
Every real modelling task is done by **writing an NXOpen Python journal and running it headless**.
This skill is the common base; the feature knowledge lives in the sibling skills:

| Task | Skill |
|---|---|
| Plan a part: which approach, which features, in what order | `nx-modeling-strategy` |
| Sketches, datum planes/axes, splines, projected / intersection / offset curves, sections | `nx-curves-and-sketches` |
| Revolve, Shell, Draft, Rib, blends, chamfers, holes, threads, extrude options | `nx-solid-features` |
| Mirror Geometry, patterns, Trim/Split Body, booleans, Tube/Sweep, extract/WAVE | `nx-patterns-and-body-ops` |
| Through Curves, Swept, Fill, Trim Sheet, Sew, Thicken, Patch | `nx-surface-modeling` |
| Offset Region, Replace Face, Move/Delete/Resize Face, Make Parallel..., editing imported bodies | `nx-synchronous-modeling` |
| Components, constraints, top-down WAVE links, interference, motion checks | `nx-assemblies` |
| Rebuilding CAD on a scan (STL / convergent body): Fit Surface, Fit Curve, alignment, deviation | `nx-reverse-engineering` |
| Tab, Flange, flat pattern, DXF | `nx-sheet-metal` |
| 2D drawings: sheets, base / projected / section / detail views, dimensions, parts list, PDF | `nx-drafting` |

## 1. Run a journal

```powershell
& <this skill>\scripts\run_journal.ps1 -Script C:\NX_MCP_WORKSPACE\job\build.py `
    -WorkDir C:\NX_MCP_WORKSPACE\job -JArgs C:\NX_MCP_WORKSPACE\job\out -TimeoutSec 900
```
- NX 2206 batch (`run_journal.exe`, embedded Python 3.10). **No `-nx` switch** on 2206.
- The launcher clears the capture-plugin variables for the child only, sets `NXH_DIR` (and
  `NXRE_DIR`, `NXD_DIR`, `NXBLADE_DIR`, `NXSM_DIR`, `NXW_DIR` for the helper modules of the sibling skills), enforces
  a timeout and kills only its own child. Never kill NX by process name - other sessions may be
  running NX.
- Work on local disk (`C:\NX_MCP_WORKSPACE\<job>`), not inside Google Drive; copy deliverables
  out at the end. Start-up costs ~20 s, so put a whole build (or several experiments) in one journal.
- Tracebacks appear in the launcher output under "Syntax errors"; the journal should also write
  its own log + JSON result file, because stdout from NX is unreliable. The launcher's `exit N` is
  **not** a success signal: journals that finished correctly sometimes end with `exit 1` (and a
  failed one can end with 0). The verdict is the `"result"` field of the JSON your journal wrote.
- `__file__` is not reliable under run_journal: get folders from `sys.argv[1:]` or environment.

## 2. Journal skeleton

```python
import os, sys, traceback
sys.path.insert(0, os.environ.get("NXH_DIR", r"<this skill>\scripts"))
import NXOpen, NXOpen.Features
import nxh

OUT = sys.argv[1]
res = {"result": "FAIL"}
try:
    part = nxh.new_part(os.path.join(OUT, "bracket.prt"))
    nxh.expr(part, "wall", 2.5, "mm", "nominal wall")          # master dimensions first
    ...                                                         # features, each verified
    assert not nxh.feature_errors(part)
    nxh.save(part)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "result.json"), res)
```
Two helper modules live in `scripts/` (both verified; `nxh_selftest.py` / `nxf_selftest.py` re-prove them):
- **`nxh.py`** - the core: parts, expressions, smart points / directions / axes, datum planes,
  dumb curves, sections (`section`, `section_region`, `section_feature`, `fill_section`),
  collectors, face/edge finders (`faces`, `edges`, `face_info`, `hole_census` = holes vs bosses
  vs blends of an imported body), measurement (`volume`, `mass`, `sheet_area`, `free_edges`,
  `min_dist`, `dist_to`, `normal_at`, `g1_deviation`, `max_curvature`, `examine_geometry`,
  `body_ok`), `Check` (accumulates measured checks -> PASS/FAIL), block / cylinder / extrude /
  guarded unite-subtract-intersect / blend, `attempt()` (rollback on failure),
  `feature_errors()`, `builder_doc()` (API docs from inside NX), `top_features()` /
  `is_internal()` (history steps without pattern instances and hole child rows),
  `user_expressions()` / `user_named()` (names a person typed, not NX's own),
  `face_mid_normal()` (outward normal of any face, also curved ones), `wall_partners()` /
  `wall_thickness()` (the face on the other side of a thin wall), and the tools for editing in the
  middle of a tree: `insert_after()` (insert point with roll forward and checks), `reorder()`,
  `suppress_status()` (suppressed / by expression / failed / rolled back / by parent),
  `rolled_back()`, `history_mode()`, `legacy_note()`.
- **`nxf.py`** - feature helpers consolidated from the family skills: sketches with constraints
  and dimensions (and a DOF read-out that is real: section 5, "Sketch DOF"), datum planes, revolve, shell, draft, rib, holes (simple / counterbored /
  countersunk / threaded at tap-drill diameter, chamfers inside the hole, depth by value /
  through / until selected / until next; `tap_drill("M10")`), chamfer, edge treatment with a
  fallback (`blend_chains`, `break_edges`), helix, pattern along a path / with increments, mirror geometry,
  patterns, trim / split, synchronous edits (offset region, move / replace / delete / resize
  face, divide face, pull face, face finder, dimension-driven edits, blend census / replace blend),
  surfaces (through curves, bounded plane, sew, thicken), tree tools (suppress by expression,
  replace feature, internal sketches, measurement expressions, expression import), feature-copy
  tools (`copy_check`, `add_to_pattern`, pattern stagger / frame / clocking), draft types, STEP
  export / import / round trip. Index: `references/nxf-helpers.md`. Call these instead of re-typing
  recipe code; read the family skill for WHEN and WHY, and for anything `nxf` does not cover.

## 3. Rules that apply to every feature

1. **Builder lifecycle**: `b = part.Features.CreateXBuilder(Null)` -> configure -> `CommitFeature()`
   -> `b.Destroy()` in `finally`. Passing an existing feature instead of `Null` gives its edit builder.
2. **Floats only** in `Point3d` / `Vector3d` (ints raise `TypeError`).
3. **Named expressions drive everything that is a design dimension**; feature values are set
   with `.RightHandSide = "name or formula"`. See `references/expressions-and-update.md` for the
   function/unit traps (degrees, `arctan2(x, y)`, unitless copies). Keep the drawing's own
   numbers as the masters and put the arithmetic in the dimension: `d_bore = 50` and the profile
   radius `d_bore/2`, a stacked height `t_flange+h_barrel` - never a precomputed 25 or 90
   `[community: 8 of 14 authors type such arithmetic into the field; verified: flanged_housing.py]`.
4. **Objects, not names**: pass faces/edges/bodies you found by geometry (`nxh.faces`,
   `nxh.edges`, `face_data`), never display-name strings; re-query after every feature - tags of
   faces and edges change when topology changes.
5. **Every mutation sits behind an undo mark** (`nxh.attempt` or `nxh.mark` + `nxh.undo_to`), so a
   failed attempt leaves the model as it was.
6. **Verify by measurement after every feature** (section 5). NX fails silently.
7. **Create only in the work part.** In an assembly session, measuring and editing expressions
   works on any loaded part, but creating features in a part that is not the work part fails
   ("Creating an interpart section is not allowed.", "Internal error") or lands in the assembly:
   `nxa.set_work(component)` first, `nxa.set_work(None)` to return `[verified]`.
8. **Never modify the user's source files.** Open copies; a part opened from the user's project
   folder is closed without saving. Before editing a part somebody else built, run
   `scripts/inspect_part.py` on the copy and follow `references/existing-parts.md` (state table by
   tag, suppressed tail, product body, broken links, probing faces; its section 5 says what a
   feature count and an expression count of somebody else's part really contain; section 8 maps
   the legacy feature names of old parts to today's commands).
9. **A feature that belongs earlier in the history goes there through the insert point**, not on
   top: `with nxh.insert_after(part, earlier_feature): ...` (blends that a later Shell must pick
   up: wall constant, closed-form volume; made after the Shell they are refused or leave sharp
   inside corners). It rolls forward, keeps suppressed features suppressed and UNDOES an insertion
   that breaks a later feature. Reorder, Replace Feature, feature groups and switches:
   `references/existing-parts.md` section 7 `[cast efme, efmf]` `[verified: edit_in_the_middle.py]`.
   On the user's hybrid parts the default stays "add at the end".
10. **Edge Blend overflow**: a builder made in a journal has the three overflow switches OFF, the
   dialog has them ON. So a blend the dialog makes can be refused headless with "Unable to
   terminate the blend faces..." (R10 beside an R3 on a 12 mm wide face). `nxh.blend(...,
   overflow=True)` / `nxf.edge_blend(..., overflow=True)` set the dialog's values and the blend
   commits - rolled onto the neighbouring edge, with a crease there: measure it. The DEFAULT of
   `nxh.blend` / `nxf.edge_blend` stays off, because the refusal is what the checks of this skill
   set rely on (a pattern copy whose blend would run past the plate end is dropped and reported;
   with the switches on an R500 blend on a 20 mm edge commits). The fallback helpers
   `nxf.blend_chains` / `nxf.break_edges` use both: a refused blend is tried again with the
   dialog's values BEFORE the radius is reduced (`overflow="retry"`, their default), kept only if
   the body stays valid, and flagged in the report (`"blend, overflow"`)
   `[verified, nxf_selftest copies group and blend overflow switches]`.

## 4. Selection intent (collectors and sections)

Features take **rules**, not raw object lists. Rules live in `part.ScRuleFactory`; faces, edges
and bodies go into an `ScCollector`, curves into a `Section`.

| Want | Rule |
|---|---|
| exactly these faces / edges / bodies / curves | `CreateRuleFaceDumb([..])`, `CreateRuleEdgeDumb([..])`, `CreateRuleBodyDumb([..], True)`, `CreateRuleCurveDumb([..])` |
| a face and everything tangent to it | `CreateRuleFaceTangent(seed, [])` |
| all faces of a feature (e.g. an extracted/linked face) | `CreateRuleFaceFeature([feature])` |
| a datum plane used as a face | `CreateRuleFaceDatum([datumPlane])` |
| a chain of blend faces / all blends of a body | `CreateRuleFaceConnectedBlend(seed)` / `CreateRuleFaceAllBlend(body)` |
| all curves of a sketch or curve feature (stays associative) | `CreateRuleCurveFeature([sketch.Feature])` |
| ONE closed region of a multi-loop sketch | `CreateRuleRegionBoundary(sketch, curves, Point3d seed, 0.01)` - `nxh.section_region`; the seed point only picks the region at creation, the feature regenerates correctly when the region later moves or resizes |
| tangent edge chain | `CreateRuleEdgeTangent(seed, Edge.Null, False, 0.5, False, False)` |
| the outline of a face set (shared edges dropped): "the foot of this pad" | `CreateRuleOuterEdgesOfFaces([top] + sides)` - pad top + its four walls gave the four foot edges; `CreateRuleEdgeBoundary([face])` = the edges of one face `[cast etmd885]` `[verified]` |

- Dumb rules are fine for one-shot builds; **feature rules keep the model associative** (a sketch
  that gains a curve still drives the extrude). The user's own parts use `RegionBoundary` /
  curve-feature rules for sections and dumb rules for single faces.
- The other side of that: a whole-sketch rule takes in EVERY active curve added later. A centre
  line drawn across the profile afterwards gave "Selected objects will result in a self
  intersecting section" and the body was gone; make such curves reference curves
  (`nxf.to_reference`) or use a region rule `[cast eskb]` `[verified]`.
- It takes in every active POINT as well (`nxh.section` allows `CurvesAndPoints`). A sketch that
  holds a Point besides its closed profile - a centre point, hole positions - gives "Cannot
  extrude. The section and direction may be incompatible." with `nxh.section_feature`, on any
  plane and with either sketch solver. Each of these gave the full volume: make the point a
  reference point (`nxf.to_reference(part, [point])`; the points `nxf.sketch_anchor` adds already
  are), `nxh.section_feature(part, [sk.Feature], curves_only=True)` (the section then accepts
  curves only), or select the profile itself - `nxh.section_region(part, sk, seed, curves=lines)`
  / `nxh.section(part, curves=lines)`; `nxf.sketch_rect_centered` and `nxf.hv_polygon` return
  those lines `[verified, nxf_selftest.py sketch group, nxh_selftest.py]`.
- `nxh.collector(part, faces=..., edges=..., bodies=..., datum_planes=...)` and
  `nxh.section(part, curves=..., edges=...)` wrap the common cases. Section details (help point,
  start curve and direction, several loops, region selection) are in `nx-curves-and-sketches`.
- One `Section` may hold several closed loops: inner loops become holes.
- Some builders own their section/collector (read-only property): fill it in place, never assign.

## 5. Verification (do it after every feature)

| Check | How | Catches |
|---|---|---|
| Volume vs analytic expectation | `nxh.volume(part, body)` (accuracy 0.999999) | wrong direction, failed cut, failed shell |
| Solid-body count | `len(nxh.solids(part))` | boolean that silently left the tool body |
| Face census / face position | `nxh.face_census(body)`, `nxh.faces(...)`, `nxh.face_data(face)` | missing blend, wrong face moved |
| Sheet bodies | area via `MeasureManager.NewFaceProperties`, free edges (edges with one face) | open quilt, failed sew (`nxh.mass` is for solids only) |
| Feature health | `nxh.feature_errors(part)` after `nxh.update()` | failed features. NX re-attaches the message of a rolled-back failed attempt to the NEXT feature created; `feature_errors` re-evaluates flagged features (`UpdateManager.LogForUpdate` + update), which clears such stale messages and keeps real errors |
| Parametric claim | change the expression, `nxh.update()`, re-measure, change back | dead dimensions |
| Sketch fully constrained | `nxf.finish_sketch(sk)` -> `status` `WellConstrained`, `dof` 0, `auto_dims` 0 - on a sketch made with `nxf.new_sketch` (see "Sketch DOF" below) | a sketch NX closed with automatic dimensions: bare `GetStatus()` says 0 for anything |
| Deliverable | STEP re-read in OCP: one solid, same volume and bbox | empty or partial export |

"No exception" proves nothing. A failed Shell leaves the solid block; a twisted loft is a valid
solid of half the volume; a constraint reports Solved on the wrong face.

**Sketch DOF: `GetStatus()` = `WellConstrained`, 0 is not proof by itself.** A batch session on
this PC starts with the session preference Continuous Auto Dimensioning ON
(`Session.Preferences.Sketch.ContinuousAutoDimensioning` reads True). A sketch created in that
state gets one automatic dimension for every degree of freedom nobody constrained, at `Update()`,
and `Sketch.GetStatus()` then answers `(WellConstrained, 0)` whatever is in it `[verified,
nxf_selftest.py sketch group]`:

| Sketch content, no dimension typed | bare `GetStatus()`, preference on | real DOF (`nxf`, preference off) |
|---|---|---|
| one free point | WellConstrained, 0 | UnderConstrained, **2** |
| one free line / circle | 0 / 0 | 4 / 3 |
| H/V rectangle, no dimension / two of four positions dimensioned | 0 / 0 | 4 / 2 |
| point -> on the X axis -> + one dimension | 0, 0, 0 | 2, 1, 0 |

- The sketch takes the setting over **when it is created** (builder `Commit`) and keeps it:
  switching the preference afterwards - before `Activate`, before the geometry, before `Update` -
  changes nothing for that sketch, in either direction (8 orders probed; both directions are
  checks of the self-test).
- `nxf.new_sketch` therefore switches the preference off before it creates the sketch
  (`nxf.auto_dimensioning_off()`; session setting, the next NX session starts ON again). Make
  sketches with `nxf.new_sketch`; before any other sketch builder (sketch on path, your own
  `SimpleSketchInPlaceBuilder`) call `nxf.auto_dimensioning_off()` first.
- `nxf.sketch_status` / `nxf.finish_sketch` report the real count also for a sketch that was
  created with the preference on: the automatic dimensions (`DimensionState == Automatic`, no
  expression) are counted back in - `nxf.auto_dimensions(sk)`, key `auto_dims` in the
  `finish_sketch` result - and the status becomes `UnderConstrained`.
- Never quote a bare `sk.GetStatus()` as "fully constrained", and do not trust a DOF 0 that was
  read before this switch existed (older build reports). When the claim matters, show the
  countdown: read the DOF after each group of constraints and compare it with the hand count
  (curve DOF minus constraints); a read-out that is 0 from the first step on is the trap, not a
  result.
- The example journals that carry their own copy of the sketch builder now switch the preference
  off before their first sketch and were run again `[verified]`: `nx-solid-features`
  `molded_tray.py` (31 checks) and `course_checks.py` (28), `nx-surface-modeling`
  `surf_round3_checks.py` (38), `nx-sheet-metal` `sheet_metal_commands.py` (63, sketch on path),
  `nx-modeling-strategy` `examples/enclosure_half_and_knob` (157 + 64) - same PASS counts and
  the same measured values as before. Every sketch they call fully constrained is: DOF 0 with
  0 automatic dimensions, in the new parts and in the parts built with the preference on (typed
  dimensions leave nothing for NX to auto-dimension). The free rib line of `molded_tray.py` shows
  the trap side by side: built with the preference on `WellConstrained`, 0, 4 automatic
  dimensions; built with it off `UnderConstrained`, 4, none - the rib is identical (2174.664 mm3).
- Siemens' own training parts show the same trap: 10 of 32 "well constrained" sketches of the
  sketching course are held by automatic dimensions (raw 54 % DOF 0, real 38 %) `[cast, measured by
  the curves package]` - quote a DOF statistic only with `auto_dims` separated.
- **A part you did not create** (or created earlier): `inspect_part.py` and `dump_part.py` report
  per sketch the bare `status` / `dof` plus `auto_dims` and `real_dof` = dof + auto_dims (a
  property read, nothing is solved or saved); the one-page summary flags `AUTO-DIMS=n (real dof
  n)`. Fully constrained means `real_dof` 0.

**Two sketch solvers: `nxf.legacy_solver(sk)`.** A sketch in a new part of a batch session is
solved by the legacy solver (`Sketch.UsesLegacySolver` True: template, sheet metal template and
blank parts, all three sketch builders, also after save and reopen). A part that was modelled in
the NX 2206 user interface is different: its 28 sketches were all new-solver sketches and so was
every sketch a journal added to it. The sketch plane has nothing to do with it - principal planes,
30 / 45 degree datum planes and chamfer faces behave alike, point in the plane or 1 mm off it
`[verified, nxf_selftest.py sketch group "inclined plane"; group newsolver on a UI-modelled part]`.
In a new-solver sketch:
- A smart point (`nxh.point`) takes ONE constraint or dimension. The second reference to it - a
  second `pdim`, Midpoint, Coincident, PointOnCurve, 36 of 36 combinations - raises
  `NXException: Invalid object type`. Being the sketch origin does not count; the datum CSYS
  origin, a point feature and points of the sketch itself take any number. So anything that needs
  several references to one external point (a centred rectangle: four dimensions) goes through
  `nxf.sketch_anchor(part, sk, point)`: one reference point of the sketch, coincident with the
  external point, DOF 0, left out of whole-sketch sections. `nxf.sketch_rect_centered` and
  `nxf.sketch_circle` do this themselves; in a legacy sketch they add nothing. For your own
  constraints call `sketch_anchor` BEFORE the first one and reference what it returns.
- `sk.Update()` does not re-solve the active sketch (status `NotEvaluated`, a line stayed at 40
  under a dimension of 13); `sk.LocalUpdate()` does. `nxf.finish_sketch` calls it, so its status is
  the solved one; without it a sketch drawn off size reads `InconsistentlyConstrained`.
- A batch session cannot make a new-solver sketch in a new part, so `nxf_selftest.py` proves the
  anchor path with `force=True` on a legacy sketch and runs the real thing (group `newsolver`) only
  when `NXF_NEW_SOLVER_PART` names a part modelled in the user interface (a copy is opened).

**Choosing the expected value**
- Exact (tolerance 1e-3 mm3 or better): prisms, cylinders, Pappus for revolves, and the volume
  **delta** of a single added or removed feature (boss, rib, hole, groove, pocket) even on a
  complicated body. Prefer deltas - they stay exact after drafts and blends.
- No closed form (blends meeting at drafted corners, shells of blended bodies, freeform faces):
  do not invent a number. Check the body by its exact parts - point-on-face probes
  (`nxh.dist_to(part, face, xyz) == 0` at a designed coordinate), `nxh.normal_at` for wall angles,
  `nxh.min_dist(outer_face, inner_face)` for wall thickness - and give the total volume a stated
  tolerance against your best estimate (typically 1e-4 relative).
- Round trip: after the regeneration test, nominal values must reproduce the nominal volume to 1e-6 relative.

**Position checks**: `nxh.bbox` is exact on analytic geometry built in NX but padded on
B-surfaces, sewn/tolerant edges, imported bodies and faces bounded by offset curves (0.003-0.2 mm,
more on toroidal bodies). Pick with a ~0.01 tolerance on imports; for faces made by the rim idiom
(Offset Curve in Face + Divide Face + Offset Region: tongue and groove walls) the padding reaches
0.035-0.10, so `nxh.faces(..., at=..., tol=0.01)` finds nothing - select with
`nxh.face_at(part, body, xyz)` (point probe) and prove positions with `dist_to` / `normal_at`.
A planar wall created by Offset Region on a divided face can report UF type 20 (`nxh.EXTRUDED`),
blends on drafted neighbours type 23 (`nxh.BLEND`): find such faces by position, not by type.

**Unique picks**: `body.GetFaces()` / `GetEdges()` return objects in a different order in
different NX sessions, so `nxh.faces(...)[0]` on a query that matches two faces picks a different
one from run to run (measured: a 2.9 x 0.5 mm sliver taken instead of the plate bottom in half the
runs - the journal passed, then failed, with no change). Tighten the query until it is unique
(`at=`, `radius=`, `face_at`) and wrap it: `nxh.one(nxh.faces(body, ftype=nxh.PLANE,
normal=(0, 0, -1), at=(2, 0.0)), "bottom")` raises with the count and the bounding boxes of the
matches instead of silently taking the wrong one. `[verified]`
The same holds for EDGES and for sections built from them: `nxh.section(part, edges=list(face.GetEdges()))`
starts on whichever edge comes first in this session, so a profile direction - and with it the side
a Law Extension leans to, or the twist of a loft - can flip between two runs of the same journal
`[verified by the surfaces package]`. Select the edges by geometry, put the start edge first or pass
`seed=`, and give the help point at its start end (`nxh.fill_section` docstring).

**Two builders to treat with care** `[verified by the surfaces package]`: a Conic Section Surface
without a spine crashes NX 2206 - run a builder you have not used before in its own NX process, so
that a crash costs one probe and not the whole build; Offset Surface silently DROPS a face it cannot
offset - compare the face count of the result with the input.

**Body health and deliverable**: `nxh.body_ok(part, body)` (Analysis > Examine Geometry: finds
open edges and corrupt faces, not creases - use `nxh.g1_deviation` for continuity);
`nxf.step_export` then `nxf.step_roundtrip_check` re-imports the STEP into a scratch part and
compares solid count and volume (expect 1e-5 relative; the bounding box of a re-import is padded).

**Other NX sessions**: several headless NX processes can run side by side (each ~0.4 GB). Never
stop a `run_journal` you did not start; keep each job in its own work folder.

## 6. Finding the API without documentation

- `nxh.builder_doc(builder)` -> docstring of every property/method (types, enum classes).
- `nxh.enum_names(EnumClass)`; `dir()` on any object.
- Factories: most are `part.Features.Create<Name>Builder`; others live on sub-collections
  (`part.Features.DesignFeatureCollection.CreateRibBuilder`, `FreeformSurfaceCollection`,
  `SynchronousEdgeCollection`, `SheetmetalManager`, `TrimFeatureCollection`...).
- **Read back a real feature**: `scripts/dump_part.py` dumps every feature of an existing part
  with all its builder settings - the fastest way to learn how a command is configured is to dump
  a part where the user (or NX interactively) made that feature.
- Try unknowns inside `nxh.attempt(...)` and record the exact NX error text; stop after ~4
  attempts and report rather than guessing.

## 7. References
- `references/expressions-and-update.md` - expression functions, units, update, interpart links,
  conditional / Boolean / String expressions, measurement expressions, suppress-by-expression
  (and its one-way parent / child trap), export and import.
- `references/import-export.md` - STEP export/import settings that actually produce geometry,
  STL import, reading existing parts, colours, materials.
- `references/existing-parts.md` - inspecting and safely extending a part somebody else built;
  section 7 editing in the middle of the tree (insert point, Reorder, Replace Feature, groups,
  internal sketches), section 8 names you meet in old parts, section 9 the offline reader.
- `references/nxf-helpers.md` - index of the feature helpers (`nxf`) and assembly helpers (`nxa`).
- `scripts/`: `run_journal.ps1` (launcher), `nxh.py`, `nxf.py`, `nxa.py` (helpers) with
  `nxh_selftest.py` / `nxf_selftest.py` / `nxa_selftest.py`, `inspect_part.py` (as-found report),
  `dump_part.py` (every feature's builder settings), `edit_in_the_middle.py` (insert point,
  reorder, groups and switches on a reopened part, 46 checks), `prt_text.py` (what is in a `.prt`
  WITHOUT NX: feature types and counts, expressions, components; no order, no settings) with
  `prt_text_selftest.py`, `run_all_examples.ps1` (regression over all
  example journals of all nx-* skills - run it after changing a helper or upgrading NX; it waits
  for free memory before each NX launch: `-MinFreeMB 700`).
