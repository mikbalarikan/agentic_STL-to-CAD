# Working on a part somebody else built

Measured on copies of the user's real production parts (a smart-watch housing with 88 features
and a small enclosure with 105; all 14 added edit steps were correct on first execution once the
points below were respected). Tags: `[verified]` acceptance build 4, `[mined]` user's parts.

## 1. Copy, then inspect - before any edit
```powershell
Copy-Item "<user part>.prt" C:\NX_MCP_WORKSPACE\job\work.prt          # never edit or save the original
& run_journal.ps1 -Script inspect_part.py -JArgs C:\NX_MCP_WORKSPACE\job\work.prt,C:\NX_MCP_WORKSPACE\job\out
```
`inspect_part.py` writes `<name>_asfound.txt` (one page) and `.json`: what could not be loaded,
every body (solid / sheet, blanked, layer, volume, owner features, Examine Geometry, holes and
blends), the feature tree with suppression and messages, link status, sketches, named expressions.
`dump_part.py` adds the builder settings of every feature when you need to know how a feature was made.

What the report counts (section 5 has the reasons; `[verified]` on 12 third-party parts against a
pure-read census: expression total, user-named count, top-level and internal rows, sketches and
dimension counts all equal):
- `features` / "FEATURE TREE" = **top-level history steps only**. Rows NX keeps inside another
  feature (`Feature.IsInternal`) are counted per type under `internal_features` and not listed;
  an internal row that carries an error is still named.
- `n_expressions` is read before anything is measured; `named_expressions` holds only names a
  person typed (`nxh.user_named`).
- `sketches` = sketches a person drew, with the real number of dimension objects; pattern / mirror
  instance copies are only counted (`sketch_instance_copies`).
- `status` / `dof` of a sketch are the bare `GetStatus()` answer. `auto_dims` counts the automatic
  dimensions NX put in (Continuous Auto Dimensioning; they are in `dimensions`, not in
  `expressions`) and `real_dof` = `dof` + `auto_dims`. `WellConstrained`, dof 0 with `auto_dims`
  4 is a free line, not a constrained one (summary: `AUTO-DIMS=4 (real dof 4)`) `[verified:
  the same one-line rib sketch built with the preference on reads 0 / auto 4, built with it off
  UnderConstrained 4 / auto 0; seven fully dimensioned sketches read auto 0 either way]`.
  `dump_part.py` writes the same two keys.

Read it for these facts, and write them into the plan:
- **Missing parts**: `nxh.open_part` fills `nxh.LOAD_STATUS` (e.g. a component "left unloaded").
  Linked features whose source is missing are **broken links**: `nxh.link_status(f)["broken"]`.
  They keep their frozen geometry and survive regeneration; they cannot be re-evaluated, and
  opening their edit builder crashes ("Error during part conversion" / memory access violation).
  The flag does not see ORPHANS - links whose parent part was renamed or is missing (55 of 298
  links in one measured set): no flag, no feature error, frozen geometry. On a part with linked
  features run `nxw.link_health(part)` (`nx-assemblies/scripts/nxw.py`, `NXW_DIR` is set by the
  launcher): five states - live, parent_unloaded, orphan, broken_accepted, broken_new.
- **Which body is the product.** A real part holds several solids and sheets: tool bodies, halves,
  blanked leftovers. No flag says which one is "the part". Indicators, in this order: unblanked,
  solid, on the work layer, owned by the latest features, largest volume; a body consumed by a
  later Delete Body is scrap. State your choice and its uncertainty; ask when two candidates remain.
- **The suppressed tail.** The user leaves abandoned attempts suppressed at the end of the tree
  (4 % of all features, 15-27 % in some parts `[mined]`). Leave them alone.
- **As-found errors.** Record features that already carry errors; they are not yours to fix.

## 2. Rules for editing
1. **Add, do not restructure.** Append features in the user's style (see `nx-modeling-strategy`
   section 5); do not reorder, rename, re-constrain or unsuppress.
2. **New features land after the last ACTIVE feature**, in front of the suppressed tail, and the
   tail is renumbered (Replace Face(59) became Replace Face(71)). So compare states by **tag**:
   `before = nxh.feature_state(part)` ... `nxh.state_diff(before, nxh.feature_state(part))` must
   show only your additions. A by-name comparison reports the whole tail as changed.
3. **Do not roll the tree by hand** (`MakeCurrentFeature()` to the first and the last feature to
   "replay" it): on one of the user's parts that unsuppressed a whole abandoned tail (11 new
   errors, a body grew from 1185 to 1738 mm3). On four small test trees the same rolling kept every
   user-suppressed feature suppressed `[verified]`, so the cause on the real part is not isolated -
   which is the reason to roll only through `nxh.insert_after` (section 7): it records every
   suppression code first and restores it afterwards. To force a regeneration without rolling,
   change an early expression, `nxh.update()`, restore it, `nxh.update()` - states and volumes come
   back identical. While a tree is rolled back, `Feature.Suppressed` is True for everything behind
   the insert point: `nxh.suppress_status(f)` tells "rolled back" (16) from "suppressed" (1).
4. **Pick faces by probing, with measured coordinates.** `nxh.face_at(part, body, xyz)` is the
   reliable selector among hundreds of faces; take the coordinates from `nxh.face_data(face)[1]`
   or an edge vertex, not from a rounded report. Real bodies have split coplanar faces
   (`nxh.faces(..., at=)` returns several) and padded bounding boxes.
5. **Every edit proves it changed only what it should**: the edited body's volume delta equals the
   feature's own contribution; every other body's volume is unchanged to 1e-9; body count
   unchanged; `state_diff` clean; `nxh.body_ok` on the edited body.
6. **Expected volume next to blends and chamfers**: a native Chamfer or Edge Blend feature beside
   the moved face is re-evaluated and follows, exactly like a recognised blend on a dumb body. For
   a pocket floor moved by d the delta is (footprint of the whole pocket) x d, not the flat area
   alone `[verified: pi x 10.5^2 x 0.3 = 103.908, not 85.963]`.
7. **Drive your additions with named expressions** even though the user's part has none; do not
   rename or re-link the user's `p##` expressions.

## 3. How robust is the history? Test before promising a change upstream
Changing an ORIGINAL early dimension shows how brittle a hybrid tree is `[verified]`:
- watch housing: base width +1 mm broke four later Move Face / Delete Body features and collapsed
  the body; an early blend radius +0.5 broke eleven features. Everything upstream of the long
  Move Face chain is effectively frozen.
- small enclosure: cylinder diameter, shell thickness and blend radius changes regenerated cleanly;
  one sketch diameter change broke one later Edge Blend ("Referenced edge does not exist").
Do the test on a scratch copy (change, `update()` with AcceptAll, list `state_diff`, restore) and
report which features fail. If the requested change breaks the tree, propose a synchronous edit
at the END of the tree instead (that is how the user makes such changes) rather than repairing
the history.

## 4. Deliverables from multi-body parts
- STEP export writes only the **visible** solids: a part with 5 solids, 2 of them blanked, gave a
  STEP with 3. Compare the round trip against the unblanked solids, per body, not against all.
- Volume agreement of a re-import on real tolerant geometry is ~1e-5 to 5e-5 relative; use 1e-4.
- Deliver the edited copy under a new name next to a short change list (features added, expressions
  added, checks). Never overwrite the user's file.

## 5. Counting features and expressions of a part you did not build
Three traps that inflated the statistics of 75 third-party parts and of the user's own parts
`[community: 75 opened parts of 6 authors]` `[verified: probe on NX 2206]`:

**Internal rows.** `part.Features.GetFeatures()` returns every row, also the ones NX keeps inside
another feature: 1 517 of 2 741 rows (55 %) in those parts; in 10 parts more than half. Filter on
`Feature.IsInternal` (`nxh.is_internal(f)`, `nxh.top_features(part)`) before counting, listing or
comparing tree sizes. Internal rows are:

| Row type | What it is |
|---|---|
| `SIMPLE HOLE`, `CBORE_HOLE`, `CSUNK_HOLE` | child of ONE Hole feature (`HOLE PACKAGE`, class `HolePackage`), one row per hole POINT, by form: simple / counterbored / countersunk. Not legacy hole commands |
| `SYMBOLIC_THREAD` (internal) | child of a THREADED Hole feature, one per point, next to its `SIMPLE HOLE`. A top-level `SYMBOLIC_THREAD` is a Thread feature: only `IsInternal` tells the two apart |
| `Instance Feature`, `IDENTICAL INSTANCE OUTPUT`, `MASTER SNAPSHOT BODY` | instances and output bodies of Pattern Feature / Mirror Feature |
| `HOLE PACKAGE`, `EXTRUDE`, `BLEND`, `UNITE`, `SWP104` ... flagged internal | the copy of that feature inside a pattern / mirror instance: any type can occur as an internal row |
| `EXTRACT_STRING`, `EXTRACT_FACE`, `EXTRACT_DATUM_AXIS` / `_PLANE` | linked-curve / face / datum objects of a pattern, mirror or sketch reference |
| `DATUM_CSYS`, `SKETCH` (internal) | the CSYS of a sketch; the sketch inside its Extrude; sketch copies of pattern instances |

Count holes by the `HolePackage` class and hole POSITIONS by the child rows.

**Type strings shared by several commands.** `Feature.FeatureType` does not identify the command:

| Type string | Commands | Tell them apart by |
|---|---|---|
| `SWP104` | Revolve, Tube, Sweep Along Guide | the NXOpen class (`Revolve`, `Tube`, `SweepAlongGuide`) |
| `SKIN` | Ruled, Swept, Bounded Plane | the class (`Ruled`, `Swept`, `BoundedPlane`) |
| `OFFSET` | Offset Surface, Offset Face | the class; in raw part data the parameter record (`PARTIAL_OFFSET_SHEET_parms` = Offset Surface, `OFFSET_PARMS` = Offset Face) |
| `SYMBOLIC_THREAD` | Thread feature, or the child of a threaded Hole | `IsInternal` |
| `HOLE PACKAGE` | every hole type and form | the edit builder: read `Type` and `GeneralHoleForm` FIRST - the eight diameter / depth properties show a value under every type |

Use `type(feature).__name__` (the `cls` column of `inspect_part.py` and `dump_part.py`).

**Expression names nobody typed.** Besides `p12`, NX itself writes `p12_x` / `_y` / `_z` (point
coordinates), `p8_CircularPattern_pattern_Circular_Dir_count`, `Pattern_p12`, `ASSO_BLEND_3`,
`Sheet_Metal_*`, `SM_Validation_*`. A test of "not `p<digits>`" calls all of them user-named: it
listed 270 such names in 30 of 75 reports, and it turned the user's own figure into 117 parts
with named expressions where 47 of 577 have any. Use `nxh.user_named(name)` /
`nxh.user_expressions(part)`.

**A builder can leave an expression behind.** Opening and destroying a `ResizeBlendBuilder` (the
blend test inside `nxh.hole_census`) left one system expression (`p<n>=5`) in the part per call
`[verified]`: an expression count taken after the body census was too high by one per solid
body in 71 of 75 reports. `nxh.hole_census` now deletes it again; `nxh.volume`, `mass`,
`sheet_area`, `examine_geometry`, `min_dist`, `dist_to`, `bbox` add none `[verified]`. Still:
count expressions first, before any builder is opened on the part.

Sketch rows: a Pattern / Mirror instance of a sketch is an extra `part.Sketches` entry with status
`NotEvaluated`, no dimension and a meaningless DOF (35 of 344 rows); and
`len(sketch.GetAllExpressions())` is not the dimension count - count
`sketch.GetAllConstraintsOfType(ConstraintClass.Dimension, ConstraintType.NoCon)`.

## 6. House-style caveats seen on real trees
The statistics in `nx-modeling-strategy` are averages. Individual parts differ: both test parts
had well-constrained sketches (7 of 8) although 63 % of all the user's sketches are not, and the
watch housing used Move Face for 2-5 mm whole-body resizing, not only for 0.1-3 mm tweaks. Read
the part in front of you; the as-found report is the authority.

## 7. Editing in the middle of the tree: insert point, Reorder, Replace Feature

Rule 1 of section 2 ("add, do not restructure") stays the default on the user's hybrid parts. This
section is the method for the other case: a PARAMETRIC part (your own, or one built from a drawing)
where the change belongs earlier in the history - blends that a later Shell must pick up, a detail
that every copy of an existing pattern must get, a base that has to become sketch-driven
`[cast efme / Blend the edges of a drill housing; efmf / Reorder features, Replace features]`.
All of it `[verified]` in `scripts/edit_in_the_middle.py` (46 checks), `nxh_selftest.py` and the
`tree` group of `nxf_selftest.py`.

### 7.1 Insert point: make an earlier feature current, build there, roll forward
```python
with nxh.insert_after(part, block_feature) as ip:      # the tree is rolled back to block_feature
    early = nxh.solids(part)[0]                        # RE-QUERY: the body is in its early state
    nxh.blend(part, vertical_edges(early), "r_corner") # lands directly after block_feature
ip.report   # {"added": ["Edge Blend(2)"], "changed": [], "gone": [], "errors": {}, "resuppressed": []}
```
Measured on a block 80 x 60 x 30 with Shell 2 (open top) and a floor hole: blend R8 inserted before
the Shell -> outer corners R8, inner corners R6, wall 2.000 behind the blend (`nxh.wall_thickness`),
volume = closed form to 1e-6; `r_corner` 5 -> inner R3. The same blend made AFTER the Shell is
refused at R8 ("Unable to terminate the blend face...") and at R1.5 leaves sharp inside corners.

What happens, and what the helper does about it:
- While rolled back, every later feature reads `Suppressed = True`. `nxh.suppress_status(f)["code"]`
  tells why a feature is inactive: 0 active, 1 suppressed by a person, 2 by its suppress expression,
  4 failed in the last update, 16 rolled back (17 = 1 + 16), 64 suppressed because its parent is.
  `nxh.rolled_back(part)` lists what waits behind the insert point; `nxh.current_feature(part)` is
  the insert point (in a normal part: the LAST feature, also when that one is suppressed).
- The new feature takes the next timestamp; everything behind it is renumbered (`Shell(2)` becomes
  `Shell(3)`, timestamp + 1). Tags stay: compare with `nxh.feature_state` / `state_diff`.
- Roll forward = make the old current feature current again, with the update failure action
  AcceptAll. Without AcceptAll a later feature that cannot rebuild raises "Update undo happened."
  and the tree stays rolled back. `insert_after` sets it, rolls forward, re-suppresses anything a
  person had suppressed if the roll woke it, and fills `ip.report`.
- **A later feature that breaks is the real risk.** On a copy of Siemens' drill housing (Shell with
  8 removed faces) a blend inserted before the Shell worked on 2 of 8 tried edges; on 4 the Shell
  failed with "This operation cannot produce multiple bodies." - the body was then the UNSHELLED
  solid (306 185 instead of 24 711 mm3) and the Shell read code 4; once a blend committed with an
  error of its own and the part came out with 43 faces and 5 % less volume. So with `check=True`
  (default) the insertion is undone and `RuntimeError` carries the report whenever a later feature
  changed, disappeared or reports an error; `check=False` keeps the state for inspection.
- Checks after a clean report, as for any feature: volume against the closed form or the expected
  delta, the wall or face the change was for (`wall_thickness`, face census), `body_ok`, and that
  `nxh.rolled_back(part)` is empty.

A detail for every copy of an existing pattern: `nxf.add_to_pattern(part, pattern, seed, make_detail)`
(insert point at the seed, add the new feature to the pattern's INPUT, roll forward), then
`nxf.copy_check` `[verified, nxf_selftest copies group]`.

### 7.2 Reorder Feature
`nxh.reorder(part, [features], target, after=True)` moves features (in their order) directly after /
before `target` and regenerates. It changes the MODEL, not just the list: the lug of the example moved
before the Shell is hollowed by it (wall 2, open to the cavity, closed-form volume), moved back it is
solid again. A move before something the feature references is refused - "Cannot reorder. Feature
to be reordered is being referenced." - and nothing changes. `state_diff` stays clean (only names and
timestamps move). Use it to repair an order (a Shell that should not hollow a pad; a hole that must
come before a Mirror Geometry so that the copy gets it), never on the user's hybrid trees.
An in-process copy at an earlier stage: `nxf.extract_body_before(part, [body], feature)` (Extract Body
fixed at its timestamp, reordered before `feature`: the blank before the holes).

### 7.3 Replace Feature
`nxf.replace_feature(part, old, new, tolerance=None)` puts `new` in the place of `old` and re-attaches
the features that referenced old's faces and edges, by geometric match. `new` must exist before
the dependents: create it at the insert point. Measured: a Block replaced by an Extrude of the same
size - blend and hole kept, volume unchanged, and the Extrude's `base_h` 30 -> 40 then drives the
part; a 80 mm block replaced by a 100 mm one with the default tolerance 1.0 - the Edge Blend on the
four vertical edges was DELETED without any message (two of its edges had moved 20 mm); with
`tolerance=25` it was kept and followed. The helper therefore compares the tree by tag and undoes
the replacement when anything but `old` is gone. Mapping by hand (`SetMatchingForParent`) ended in
"Cannot finish operation" at the commit in the one attempt made: treat it as not available.

### 7.4 Feature groups and switches
- `grp = nxf.feature_group(part, [lug, lug_blend], "LUG")` - a top-level `FSET` row after its
  members; `grp.Name`, `grp.GetMembers()`, `grp.NewAddMembers([f], False)` / `NewRemoveMembers`.
  A group functions as ONE feature for Pattern / Mirror Feature and for suppression.
- `grp.SetGroupActive(True)`: every feature created from now on becomes a member (measured: a hole
  drilled into the lug); `SetGroupActive(False)` ends it (`part.Features.ActiveGroup` is None again).
- One switch for the whole group: `nxf.suppress_by_expression(part, [grp], "with_lug")` with a
  Boolean expression `with_lug` - members go and come back together, round trip exact.
- **Without a group or a shared expression the rule is one-way** `[verified]`: a child (the blend
  on a pad) whose PARENT alone carries the suppress expression goes down with it (code 64) and
  stays suppressed when the parent returns - the pad came back without its blends, no message. The
  same holds for `SuppressFeatures([parent])` / `UnsuppressFeatures([parent])`. Cure for a part in
  that state: `part.Features.UnsuppressFeatures([child])`. Prevention: group the set, or
  `nxf.suppress_by_expression(part, [parent, child, ...])` (one shared expression).
  `[cast efmf / Suppress features with an expression]` teaches the group; the "child follows its
  parent" half of that lesson holds in NX 2206 only on the way down.

### 7.5 Internal and external sketches
39 % of the sketches in Siemens' parts are internal to their feature (one tree row instead of two)
`[cast]`. `nxf.sketch_internal(extrude)` / `nxf.sketch_internal(extrude, False)` switch it. Make the
sketch external before a second feature uses it: headless NX 2206 does NOT stop a second feature
from being built on an internal sketch - it commits and the sketch stays hidden inside the first
feature with two children - and making a shared sketch internal raises "Parent sketch is referenced
by other objects." `[verified]`. A whole-sketch section (`nxh.section_feature`) takes in every active
curve added later: a centre line across the profile gave "Selected objects will result in a self
intersecting section" and the body was gone; convert such curves with `nxf.to_reference(part, [curve])`
while the sketch is active `[cast eskb]` `[verified]`. An active sketch POINT is taken in too and gives
"Cannot extrude. The section and direction may be incompatible.": make it a reference point the same
way, or pass `curves_only=True` to `nxh.section_feature`, or use a region rule `[verified]`.

A sketch you ADD to a part that was modelled in the NX user interface is a new-solver sketch
(`nxf.legacy_solver(sk)` False), unlike every sketch of a new batch part. There a smart point
(`nxh.point`) accepts one constraint or dimension only - the second raises "Invalid object type" - and
`sk.Update()` does not re-solve the active sketch. `nxf.sketch_rect_centered`, `nxf.sketch_circle` and
`nxf.finish_sketch` handle both; for your own constraints on an external point use
`nxf.sketch_anchor(part, sk, point)` first (SKILL.md section 5, "Two sketch solvers") `[verified on a
241-feature part modelled in the user interface: rectangle + circle on a 45 degree wall face, DOF 0,
follows the centre expressions]`.

### 7.6 Modelling mode
`nxh.history_mode(part)` is False for a part saved in history-free mode (a 2012-era mode; one of the
Siemens synchronous-course parts opens that way in NX 2206). Such a part has no history to insert
into; `inspect_part.py` prints a warning line. Do not convert it unasked.

## 8. Names you meet in old parts

Parts saved by NX 8.5 and older contain features of commands that no longer exist in the menus. In
1,375 Siemens training parts (NX 5 ... NX 8.5) opened in NX 2206 they all loaded and updated; a third
of the feature-modelling parts contain some `[cast, mined dump]`. **Read them, leave them, never
imitate them.** Most have no edit builder (a factory of another class handed such a feature returns
a wrong builder or an access violation), but their expressions keep their descriptors (`Diameter`,
`Depth`, `Positioning Dimension ...`), so a VALUE can still be changed through
`feature.GetExpressions()`. When the shape or position must change, rebuild with today's command.
`inspect_part.py` marks them `[L]` and lists them with this mapping (`nxh.LEGACY_TYPES`,
`nxh.legacy_note(feature)`).

| Type string (class) | What it is | Use today |
|---|---|---|
| `INSTANCE`, `INSTANCE_SET`, `LINEAR_ISET`, `CIRCULAR_ISET`, `TRANSFORM_ISET` | Instance Array, the feature pattern before NX 8: seed set, array, one row per instance | Pattern Feature (Linear / Circular) |
| `MIRROR_SET` | Mirror Feature as old releases wrote it (still has an edit builder) | Mirror Feature |
| `SWP104` / `EXTRUDE` as plain `BodyFeature` or `Feature` | pre-NX 5 Extruded / Revolved Body ("Extruded(3)") | Extrude / Revolve (current ones are class `Extrude`, `Revolve`, `Tube`, `SweepAlongGuide`) |
| `BOSS` | cylinder, optionally tapered, united on a planar face by positioning dimensions | Extrude of a sketch circle with the Boolean and the draft inside |
| `RECT_PAD` | rectangular pad with corner radius and taper | Extrude (Unite) + Edge Blend + Draft |
| `RECT_POCKET`, `CYL_POCKET` | pocket with corner / floor radius and taper | Extrude (Subtract) + Edge Blend + Draft; a round one: Hole, flat bottom |
| `RECT_SLOT`, `U_SLOT`, `BALL_END_SLOT` | slots of the Slot command | Extrude (Subtract) of an obround sketch; ball end: Tube along the slot line |
| `RECT_GROOVE`, `BALL_END_GROOVE` | grooves on a cylindrical face | Groove, or Revolve (Subtract) of the groove profile |
| `SIMPLE HOLE`, `CBORE_HOLE`, `CSUNK_HOLE`, `TAPER_HOLE` as TOP-LEVEL rows (class `Hole` / `BodyFeature`) | the Hole command before NX 6, one feature per hole, placed by positioning dimensions | Hole (`HOLE PACKAGE`, class `HolePackage`). The same strings as INTERNAL rows are the per-point children of a current Hole: section 5 |
| `SYMBOLIC_THREAD` (top-level), `THREADS` | Thread on a cylinder: symbolic / detailed, old command | a threaded Hole; Thread for an external thread |
| `CHAMFER` as plain `BodyFeature` | old Chamfer | Chamfer |
| `TAPER`, `HOLLOW` | the old Draft and the old Shell | Draft, Shell |
| `EXTRACT_STRING` | linked curve object of an old sketch reference / pattern | nothing to do: an internal helper row |
| `UDF`, `UDF_DEF` | User Defined Feature instance / definition | Feature Group + Copy / Paste, or a template part |
| `PART_MODULE_REFERENCES` / `_WORK` / `_OUTPUT`, `LINKED_PART_MODULE` | Part Modules: sections of one part with declared inputs and outputs | separate parts with WAVE links (`nx-assemblies`) |
| `FSET` | Feature Group | Feature Group (current; listed because old parts are full of them) |
| `SIMPLIFY` | Simplify Body | Delete Face on an Extract Body copy (`nx-synchronous-modeling`) |
| fixed (non-associative) datum planes and axes | datums without parents | one Datum CSYS + relative datum planes |

Counts in the 1,375 parts: `INSTANCE` 2 793, old `SWP104` 1 291, `TRANSFORM_ISET` 454, `BOSS` 338,
`EXTRACT_STRING` 294, `LINEAR_ISET` 244, `CIRCULAR_ISET` 194, `INSTANCE_SET` 137, old `CHAMFER`
134, `RECT_POCKET` 105, `SYMBOLIC_THREAD` 66, `RECT_PAD` 43, `RECT_SLOT` 34, `THREADS` 31,
`UDF` 13 + 13. Not legacy although they look it: `META` is the class-neutral type of Unite /
Subtract / Intersect, `BREP` a parameter-less body.

## 9. What is in a part without opening NX (`scripts/prt_text.py`)

```powershell
python <this skill>\scripts\prt_text.py C:\job\bracket.prt              # one page
python <this skill>\scripts\prt_text.py C:\job\bracket.prt --json b.json
```
```python
import prt_text                      # stdlib only; also importable inside a journal
s = prt_text.read_part(path)         # s["feature_types"], s["expressions"], s["components"], s["checks"]
```
A read-only reader of the `.prt` container (the file is opened "rb"; SHA-256 identical before and
after `[verified]`), no NX process, no licence, well under a second per part. Use it to triage a
folder, to decide which parts are worth opening, and to answer counting questions.

| It gives, exactly | It does not give |
|---|---|
| every feature row with its type string: count per type, ALL rows including the internal ones (pattern instances, hole children) | the ORDER of the features (records are in file order, not timestamp order) |
| every expression: name, formula text, comment; type and unit where NX stored them as text (Number, Boolean, String) | builder settings: limits, booleans, selection rules, sketch constraints |
| which names a person typed (same test as `nxh.user_named`) | suppression state, feature errors |
| number of component instances, the part files referenced, reference set names | geometry (the Parasolid data is not decoded), volumes |
| the NX version that saved the file, the record layout | whether the part still updates |

- `s["checks"]["features"]` must read `ok` (every feature record of the file was decoded) before a
  count is quoted.
- Measured against NXOpen on two parts built and saved by NX 2206 (`scripts/prt_text_selftest.py`,
  22 checks): row count 17 = 17 and the count per type identical (including `Instance Feature` x 3,
  `IDENTICAL INSTANCE OUTPUT` x 3, `SIMPLE HOLE`, `MASTER SNAPSHOT BODY` of one pattern), all 33
  expression names and formula texts equal, comment split off, Boolean / String typed, 2 component
  instances and the referenced file of an assembly. An interpart link reads as the placeholder
  `interpart0` - exactly what `Expression.RightHandSide` says in NX too.
- Two record layouts are decoded: NX 9 and later (var-int), and NX 8.5 and older (fixed-width
  records behind an object-offset table, three variants). The second cannot be produced with NX 2206;
  it stands on the feature count being identical to NX on 1,370 of 1,375 old parts, and the copy
  shipped here gives the same output as the mining run on 150 of 150 of them. Pass copies of other
  parts to the self-test (`-JArgs <out>,<copy.prt>`) to see their decode check.
- For order, settings and state: `inspect_part.py` / `dump_part.py` on a copy.
