# Expressions, update and regeneration (NX 2206, verified)

## Creating and editing
```python
mm  = part.UnitCollection.FindObject("MilliMeter")
deg = part.UnitCollection.FindObject("Degrees")
part.Expressions.CreateWithUnits("wall=2.5 // nominal wall", mm)     # named, with comment
part.Expressions.CreateWithUnits("n_holes=6", None)                  # None = unitless
part.Expressions.FindObject("wall").RightHandSide = "3"              # edit
e = part.Expressions.CreateSystemExpressionWithUnits("wall*2", mm)   # anonymous, for smart points
```
`nxh.expr(part, name, formula, unit, comment)` / `nxh.set_expr` wrap these.

- Feature parameters are expressions too: `builder.SomeValue.RightHandSide = "wall"` links the
  feature to the named expression. Pass **formulas as strings**; never bake numbers you computed
  in Python when the value should follow a master dimension.
- A feature's own expressions: `feature.GetExpressions()`; each has `e.GetDescriptor()`
  (e.g. `"Thickness"`, `"End Limit"`, `"Radius 1"`) - the reliable way to find "the thickness of
  Shell(7)" in an existing part.
- Expression **names are case-insensitive**: `snap_zc` and `snap_zC` collide ("already exists").
- **Never address a system expression by its p-number**: the numbers differ from session to
  session and shift when features are inserted. Reach it through its feature and descriptor, and
  give every master a comment (`nxh.expr(..., comment)`) `[cast eexa / User created expressions]`.
  Named drivers are a taught practice, not only a house rule: 20 % of Siemens' modelling parts and
  nearly all parts of the expression courses carry them `[cast, 121 models]`.

## Conditional, Boolean, String and Integer expressions
All `[verified]` in `scripts/edit_in_the_middle.py` (section 6) `[cast eexa / Conditional expressions]`:
```python
X = part.Expressions
X.CreateWithUnits("slot_end=if (n_holes==6) (105) else if (n_holes==5) (150) else if (n_holes==4) (195) else (45)", deg)
X.CreateExpression("Boolean", "with_lug=true")                      # .BooleanValue
X.CreateExpression("Boolean", "many_holes=n_holes>4 && with_lug")   # comparison, &&, ||, ! (not)
X.CreateExpression("String", 'material="ABS"')                      # .StringValue
X.CreateExpression("String", 'size_text=if (many_holes) ("M"+"8") else ("M6")')   # + joins strings
X.CreateExpression("Integer", "n_rib=3")                            # .IntegerValue; "n=2.5" -> Datatype error
X.FindObject("wall").RightHandSide = 'if (material=="PA12") (1.6) else (2)'       # a string decides a dimension
```
- Every `if` needs its `else`; `else if` is two words (`elseif`: syntax error); brackets round the
  condition and round each result; no blank is needed between `)` and `else`. Upper-case `IF ... ELSE`
  is accepted by NX 2206 as well.
- Operators measured: `==`, `!=`, `>`, `>=`, `<`, `<=`, `&&`, `||`, `!`; nesting works.
- `X.CreateExpression(type, "name=rhs")` types: `Number`, `Integer`, `Boolean`, `String`, `Point`
  (`Point(1,2,3)`), `Vector`, `List` (`{1,2,3}`, read with `nth(2, lst)`); `format("%d holes", n)`
  builds a string from numbers.
- In an export file typed expressions carry a prefix: `(Boolean) with_lug=true`, `(String) material="ABS"`.
- This is how one master part holds configurations: a material name or a size class decides wall,
  radius and hole size; Booleans switch optional features (next section).

## Measurements as expressions
`f, e = nxf.measure_length(part, [edge])` / `nxf.measure_distance(part, face_a, face_b)` create a
measurement FEATURE (`LENGTH MEASUREMENT`, `DISTANCE MEASUREMENT`) whose expression (system name,
`e.IsMeasurementExpression`) follows the geometry and can drive other dimensions:
`nxh.expr(part, "feed_x", "floor(%s)/2" % e.Name)` - block length 80 -> 91.6: measurement 91.6,
`feed_x` 45.5 `[verified, nxf_selftest tree group]` `[cast eexa / Measurement expressions: an oil-feed
hole placed at half a measured length]`. Use it where a dimension must be DERIVED from the model; keep
it rare - a formula between named masters is easier to read than a dependency on a face. An exported
`.exp` file writes a measurement as a plain number: leave such lines out of an import `[cast eexb]`.

## Functions and units
| Works | Does not work / trap |
|---|---|
| `arccos`, `arctan`, `arctan2`, `sqrt`, `min`, `max` (variadic), `ceiling`, `floor`, `round`, `pi()`, `mod` | `acos`, `atan`, `atan2`, `fmod` ("Invalid legacy function") |
| `if (n==4) (a) else if (n==6) (b) else (c)` (nested ok, piecewise laws ok) | - |
| trig arguments are **degrees** | `arctan2` takes **(x, y)**: `arctan2(-30, 30)` = 135 |
| `sqrt(mm^2)`, mm x unitless | `mod(-30,360)` = -30; use `a-360*floor(a/360)` |

- A mm expression may not evaluate to `mm/mm^2` etc. ("Dimension error"). `x/1` stays mm, so
  `max(3, a + 24*s*r/1)` fails with "Dimension mismatch (binary operation)". Route the maths
  through **unitless copies**: `r_n = r/1` created with unit `None`. A unitless formula assigned to
  a mm expression is fine.
- **Degree expressions are silently converted to radians inside some products** (`beta*tan(x)`).
  Do angle arithmetic on unitless copies (`x_n = angle_expr`, unit `None`).
- Some builders crash when an expression *name* is passed where a number string is expected
  (DraftBuilder angle: "memory access violation"). Pattern: commit with a number, then set
  `...ItemValue.RightHandSide` / the feature expression to a unitless copy of the master.

## Update and regeneration testing
```python
S.UpdateManager.SetDefaultUpdateFailureAction(NXOpen.Update.FailureOption.AcceptAll)
errs = S.UpdateManager.DoUpdate(S.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "regen"))
bad = nxh.feature_errors(part)        # scan every feature: ErrorList alone came back empty
```
- Without `AcceptAll` a failing update just reports "Update undo happened" and nothing changes.
- A failed feature can leave plausible geometry (a failed Shell leaves the solid block). **Always
  re-measure volume / faces after an update**, do not rely on the error list.
- Regeneration test for a parametric part: for each master dimension set 2-3 values spanning the
  intended range, `update()`, check `feature_errors` is empty and the measured result matches
  the analytic expectation, then set the nominal back and check the round trip returns the
  original volume to 1e-6 relative.

## Interpart (assembly-driven) expressions
- In a component: `CreateWithUnits('wheel_dia="ASSY_NAME"::wheel_dia // linked', mm)` (the source
  part must be loaded). Editing the assembly expression + `DoUpdate` regenerates the component.
- After a reopen the components are **partially loaded** and do not follow: `DoUpdate` +
  `DoInterpartUpdate` + `DoUpdate` alone changes nothing on a partially loaded linked part
  (measured twice). Call `part.LoadThisPartFully()` on the linked parts and their sources - the
  load itself applies the pending change - then update. Interpart expressions held by the
  (fully loaded) assembly update as soon as the source expression is set.
- Simpler than loading afterwards: open with partial loading OFF - `nxh.open_part(path, full=True)`
  (restores the session options). Children follow their WAVE parents and interpart sources after
  a reopen only then; the load option "Load Interpart Data" loads no parent in NX 2206
  `[verified by the assemblies package: nx-assemblies/scripts/link_health.py]`.
- A STEP import changes the session's load options (Components To Load came back `NotSet`; an
  assembly opened afterwards arrived without its components and without a message).
  `nxf.step_import` / `step_roundtrip_check` now save and restore them `[verified, nxf_selftest step]`.
- An interpart expression follows the source part's EXPRESSIONS, not the component's PLACEMENT:
  a boss positioned by interpart expressions stayed put when the source component was moved in
  the assembly. Geometry that must follow placement needs a WAVE link (see `nx-assemblies`).
- Links are stored as `name=name_0` plus `name_0="ASSY"::name`.

## Suppress by expression (configurations in one master part)
```python
b = part.Expressions.CreateSuppressByExpressionBuilder()
b.SuppressAction = NXOpen.SuppressByExpressionBuilder.ExpressionAction.CreateEach
b.FeatureList.Add(feature)            # then Commit(), Destroy()
tag = UFS.ModlGeneral.AskSuppressExpTag(feature.Tag)   # the created expression
```
Set that expression's RHS to a master flag (`is_wide`). `SetSuppressExpTag` with an existing
shared expression raises "Invalid expression".
`nxf.suppress_by_expression(part, features, formula, shared=True)` wraps this: `shared=True` uses
`ExpressionAction.CreateShared` (ONE expression for the whole list), `shared=False` `CreateEach`;
`DeleteEach` / `DeleteShared` remove it again. A Feature Group in the list counts as one feature and
takes its members along.
- **Give the switch to the whole set.** A child without its own expression goes down with its
  parent (status code 64) and does NOT come back when the parent returns - it stays suppressed
  until `part.Features.UnsuppressFeatures([child])` `[verified: a pad came back without its blends,
  twice in a row; scripts/edit_in_the_middle.py section 5]`. Siemens' lesson says a child follows
  its parent `[cast efmf / Suppress features with an expression]`; on NX 2206 that is true only on
  the way down. One shared expression over parent and children, or a Feature Group suppressed as
  one, makes the round trip exact (measured both ways, four switches in a row).
- Typical driver: `if (length > 200) (1) else (0)` on the group "rib + its blend" `[cast efmf]`.
- The created expression is the feature's "Suppression Status": 1 = active, 0 = suppressed. Its
  right-hand side may be a number, the name of a **Boolean expression** (TRUE = active) or an
  **if / else of Booleans** - all work headless on NX 2206 `[verified:
  nx-curves-and-sketches/scripts/law_curve_gear.py, four switch states of a chamfer and a blend]`:
  ```python
  part.Expressions.CreateExpression("Boolean", "use_chamfer=true")
  part.Expressions.CreateExpression("Boolean", "use_fillet=false")
  part.Expressions.CreateExpression("Boolean",
      "chamfer_decider=if (use_chamfer == true && use_fillet == true) (false) else (use_chamfer)")
  e = NXOpen.TaggedObjectManager.GetTaggedObject(UFS.ModlGeneral.AskSuppressExpTag(feature.Tag))
  e.RightHandSide = "chamfer_decider"
  ```
  This is how optional features (chamfer OR fillet, with / without a keyway) are switched in one
  master part (`[community]` seen in one author's gear template and in the Siemens reuse-library
  fasteners, `DETAIL_SUP_STATUS = !SYMBOL_SUP_STATUS`).
- `NXOpen.Utilities` cannot be imported under run_journal: turn a UF tag into an object with
  `NXOpen.TaggedObjectManager.GetTaggedObject(tag)`.

## Export / import of expressions
`part.Expressions.ExportToFile(NXOpen.ExpressionCollection.ExportMode.WorkPart, path,
NXOpen.ExpressionCollection.SortType.AlphaNum)` writes `[MilliMeter]name=formula // comment`
(appends `.exp` when missing). Filter out the `p##` rows before re-importing per part.

Import: `nxf.import_expressions(part, path, replace=True)` (`ExpressionCollection.ImportFromFile`
with `ImportMode.Replace`; `DontReplace` keeps existing names). One line per expression, order
free, UTF-8: `[mm]box_len=120 //overall length`, unitless `n_cav=4`, typed `(Boolean) with_lid=true`.
With Replace a line may also name a SYSTEM expression: `[mm]p0=box_len` re-wires the Block's length
to the new master, so a part that was built with typed numbers is parametrised in one step -
measured: named masters created with their comments, `p0` / `p1` re-wired, body 80 -> 120 long, no
message `[verified, nxf_selftest tree group]` `[cast eexb / Export and import expressions]`. The
p-names must be read from THIS part first (`feature.GetExpressions()`); a large jump of a value can
flip sketch dimensions to their other solution - check the volume after the import.
