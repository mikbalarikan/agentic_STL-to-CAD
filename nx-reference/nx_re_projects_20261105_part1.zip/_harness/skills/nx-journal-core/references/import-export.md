# Import, export and inspection (NX 2206, verified)

## STEP export
```python
b = S.DexManager.CreateStepCreator()
try:
    b.ExportAs = NXOpen.StepCreator.ExportAsOption.Ap242      # or Ap214 / Ap242ED2
    b.InputFile = part.FullPath       # empty by default -> "No parts in current input file"
    b.OutputFile = dest               # keep the final file NAME: NX writes it into the STEP header
    b.LayerMask = "1-256"             # default "" -> a 2 kB STEP with no geometry
    b.ObjectTypes.Solids = True       # all ObjectTypes default to False
    b.FileSaveFlag = False
    b.ProcessHoldFlag = True
    b.BsplineTol = 0.001
    b.Commit()
finally:
    b.Destroy()
```
- With `ProcessHoldFlag = True` the file of a single part is complete when `Commit()` returns.
  Large assemblies translate in a separate `step214ug.exe` and queue one at a time: if the
  output is missing, wait for that process instead of re-exporting. Exporting an assembly opened
  straight from Google Drive left an idle translator that blocked the queue - export from local copies.
- Verify the STEP: it must contain `MANIFOLD_SOLID_BREP`; then re-import it into a scratch part
  (below, or `nxf.step_roundtrip_check`) and compare solid count and volume with the NX
  measurement. Expect agreement to ~1e-5 relative on blended bodies (exact on analytic ones);
  the re-imported bounding box is padded by a few microns, so do not compare boxes exactly.
  Outside NX the same check can be done with OCP / build123d if that Python environment is at hand.
- **Only visible (unblanked) solids are exported**: a part with 5 solids, 2 of them blanked, gave
  a STEP with 3. Blank tool bodies before exporting a deliverable, and compare the round trip
  against the unblanked solids (`nxf.step_roundtrip_check` reports per body and skips blanked ones).
- An **assembly** STEP re-imports as components named `<part>_stp` (no bodies in the work part);
  `nxf.instance_solids` / `nxa.step_roundtrip` walk them. The imported components stay loaded in
  the session - check each assembly STEP once per session.
- A WAVE-linked body is a solid of the in-context part: unless it was consumed by a boolean,
  blanked, or kept out of the reference set, the part's STEP carries a duplicate of the neighbour.
- Run `run_journal` with the workspace as working directory or `ugstep214.log` lands in the
  current directory. The translator log is named after the output file.
- Assemblies: component instance names = part names (duplicates for repeated parts); body names
  survive as `MANIFOLD_SOLID_BREP` names.
- After `ExportFlatPatternBuilder` (sheet metal DXF) a STEP export in the same regenerated part
  crashed run_journal: export STEP first.

## STEP import into the work part
The importer must match the file's schema (read `FILE_SCHEMA` in the header):
- **AP242 file** -> `S.DexManager.CreateStep242Importer()`: `ImportTo =
  NXOpen.Step242Importer.ImportToOption.WorkPart`, `ObjectTypes.Solids = True`, `InputFile`,
  `OutputFile` (a throwaway .prt path), `FileOpenFlag = False`, `ProcessHoldFlag = True`. No
  settings file needed. The 214 importer refuses such a file: "The file selected to import is a
  STEP242 file and cannot be imported using this command."
- **AP214 / AP203 file** -> `S.DexManager.CreateStep214Importer()`: it imports **nothing**
  (silently) unless both `SettingsFile = <NX>\STEP214UG\step214ug.def` and `OutputFile` are set;
  then `ImportTo = ImportToOption.WorkPart`, `ObjectTypes.Solids = True`, `ProcessHoldFlag = True`.

`Commit()` returns `None` - diff `part.Bodies` before/after (`nxh.new_bodies`) to find the new
bodies. `nxf.step_import(part, path, scratch_prt)` picks the importer from the header.
Imported bodies appear in the tree as unparameterised `BREP` features: run the health check and
edit them with synchronous modelling (see `nx-synchronous-modeling`). A fresh import reports its
bounding box padded by ~0.0025 mm per side: pick faces with a 0.01 tolerance.

## STL import
No DexManager STL importer. `part.FacetedBodies.CreateSTLImportBuilder()` (`NXOpen.Facet`):
`File`, `STLFileUnits = Millimeters`, `FacetBodyType = FacetBodyTypes.Psm` -> convergent bodies in
`part.Bodies`, one per STL shell. `GetCommittedObjects()` returns objects whose Layer/Name cannot
be set - diff `part.Bodies` and set Layer/Name/Colour on those. 4.8 M facets import in ~2 min.

## Reading an existing part (learn before you edit)
- `scripts/dump_part.py` (run with `run_journal.ps1`, args `<list.txt> <out_dir>`) writes for each
  part the ordered feature tree, every feature's expressions with descriptors, sketches (status,
  DOF, constraints), bodies, and a **reflective read-back of each feature's edit builder** - the
  exact settings the designer used. It never saves. Use it before modifying a user's part and to
  discover which builder properties a feature type really uses.
- Edit builders are obtained by passing the feature to the same factory that creates it:
  `part.Features.CreateShellBuilder(shell_feature)`; read the properties, `Destroy()` without
  committing.
- `feature.GetParents()` / `GetChildren()` give the dependency graph; `feature.Timestamp` the order.
- Loading: set `S.Parts.LoadOptions.ComponentsToLoad = getattr(NXOpen.LoadOptions.LoadComponents, "None")`
  to open an assembly file without its components (fast structural reads).
- Never save a part opened from the user's project folders; copy it to the workspace first if it
  must be changed.

## Colours, attributes, materials
- Colour: `part.Colors.Find("Medium Azure").Handle` + `S.DisplayManager.NewDisplayModification()`
  (`ApplyToAllFaces`, `NewColor`, `Apply(objs)`).
- Hide helper curves: `NewLayer = 255` + `part.Layers.SetState(255, NXOpen.Layer.State.Hidden)`.
- Body attribute title `MATERIAL` is reserved (NXException); use e.g. `MATERIAL_GRADE`.
- `part.MaterialManager.PhysicalMaterials.LoadFromNxmatmllibrary(name)` knows `Steel`,
  `AISI_Steel_4340`, `AISI_Steel_1005`, `Iron_Cast_G25`, `AISI_SS_304-Annealed`, `AISI_310_SS`,
  `AISI_410_SS`, `Nylon`; not `AISI_Steel_1045`, `AISI_SS_304`, `Rubber`, `Neoprene`, `Polyurethane`.
