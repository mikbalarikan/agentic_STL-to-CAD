# nxf / nxa - feature and assembly helper index (NX 2206, verified)

`scripts/nxf.py` is the shared feature layer on top of `scripts/nxh.py`; `scripts/nxa.py` (last
section) is the assembly layer on top of both. Call these helpers instead of copying recipe code
into a journal; read the owning skill's recipe when you need an option the helper does not expose.

```python
import os, sys
sys.path.insert(0, os.environ["NXH_DIR"])        # set by run_journal.ps1
import nxh, nxf

part = nxh.new_part(os.path.join(OUT, "tray.prt"))
_f, body = nxh.block(part, (0, 0, 0), (80, 60, 30))
nxf.draft_faces(part, walls, (0, 0, -1), 2.0, stationary_faces=top)
nxf.edge_blend(part, [(corner_edges, "r_corner"), (floor_loop, "r_floor")])
nxf.shell(part, body, nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1)), "wall_t")
assert abs(nxh.volume(part, body) - expected) < 0.01          # measure after every feature
```

Conventions (all helpers):
- dimensions are numbers or expression formula strings (`"wall_t"`, `"2*r"`), except where the
  table says NUMBER;
- faces / edges / bodies are objects found by geometry (`nxh.faces`, `nxh.edges`), re-queried after
  every feature; edge arguments also take an `ScCollector` (`nxf.tangent_edges`); face arguments of
  the synchronous helpers also take `nxf.rule_faces(...)`;
- every builder is destroyed in `finally`, so a helper can be wrapped in `nxh.attempt(...)`;
- no helper measures for you: "Check" below is what `scripts/nxf_selftest.py` measured (506 checks,
  `"result": "PASS"`), `scripts/nxh_selftest.py` (80) and, for the assembly section,
  `scripts/nxa_selftest.py` (146 checks, PASS);
  re-run them after any change to `nxh.py`, `nxf.py` or `nxa.py`:
  `run_journal.ps1 -Script nxf_selftest.py -WorkDir <out> -JArgs <out>` (about 30 s each; add group
  names after `<out>` to run a subset: `sketch datum solid_a solid_b bodies sync tree copies surface step`, or
  `constraints topdown` for nxa).

Directions: where a helper takes a vector (`extrude_ex(vec=)`, `hole(vector=)`, `pull_face(vec=)`,
`swept(axis=)`, `pattern_circular(vec=)`) it also takes an OBJECT - a datum axis or linear edge, a datum
plane or planar face (its normal), a cylindrical face (its axis) - and the feature then FOLLOWS that object
(`extrude_ex(..., reverse=True)` flips it). Measured: extrude along the normal of a datum plane at 30 deg,
z extent 17.321; plane turned to 45 deg: 14.142; 4 holes patterned about a datum axis; a hole drilled along
a datum axis. Use it for inclined ports and for a bolt circle about an inclined port axis.

`nxh` additions used with these helpers: `nxh.face_mid_normal(face)` (point on the face and OUTWARD normal,
also on curved faces and faces with a hole in the middle), `nxh.hole_census` (now right for axes inclined
to X, Y, Z: length along the axis, coverage by angular wrap), `nxh.top_features`, `nxh.user_expressions`.
Skill-local helper modules, reachable from any journal through the launcher's environment variables:
`nxre.py` (`NXRE_DIR`, reverse engineering), `nxd.py` (`NXD_DIR`, drafting), `nxblade.py` (`NXBLADE_DIR`,
blades and impellers: `nx-surface-modeling`), the sheet-metal example modules (`NXSM_DIR`), `nxw.py`
(`NXW_DIR`, WAVE links: `link_datum` / `link_sketch` / `link_edges` / `link_arc_centre` / `mirror_link`,
`link_health` with five states, `relink`, `open_for_linked_edit`: `nx-assemblies`; it stays a module of
that skill and runs in the regression as its own self-test).
`nxh.open_part(path, full=True)` opens with partial loading off (components follow their sources);
`nxa.new_component` makes the assembly the work part first (NX creates the component under the WORK
part); `nxf.step_import` restores the session's load options.

Constants: `nxf.A` (Sketch.AssocType), `nxf.CP` (Sketch.ConstraintPointType), `nxf.BOOL`, `nxf.BT`,
`nxf.GU`, `nxf.MT` (PlaneTypes.MethodType), `nxf.SOLID` / `nxf.SHEET`, `nxf.MOTION`, `nxf.ET`.

## Sketches - recipe owner: `nx-curves-and-sketches`

| Function | Purpose | Check in the self-test (measured) |
|---|---|---|
| `auto_dimensioning_off()` | switch the session preference Continuous Auto Dimensioning off (batch default: ON); returns the old value. A sketch takes the setting over when it is CREATED. Called by `new_sketch`, `sketch_status`, `finish_sketch` - call it yourself before any other sketch builder | one free point, bare `GetStatus()`: `WellConstrained`, 0 in a sketch created with the preference on; `UnderConstrained`, 2 with it off |
| `auto_dimensions(sk)` | number of automatic dimensions NX added to a sketch created with the preference on (= its open DOF); 0 for a `new_sketch` sketch | point 2, line 4, circle 3, H/V rectangle 4, + two dimensions 2; 0 in the same five sketches made by `new_sketch` |
| `new_sketch(part, plane, haxis, origin, name=None)` | sketch on a datum plane or planar face, left active; switches Continuous Auto Dimensioning off first | rectangle + circle on datum XY: `WellConstrained`, DOF 0; region extrude 20858.407; preference forced on before the call: off after it, free point DOF 2 |
| `cg(geom, pt=None, idx=0)` | ConstraintGeometry for `sk.Create*Constraint` | coincident arc centre -> DOF 0 |
| `dg(geom, assoc=None, hp=None)` | DimensionGeometry for dimensions | used by `pdim` / `diameter_dim`: DOF 0 |
| `help_at(p)` | help point for point-on-curve / tangent constraints | face sketch with point-on-curve: DOF 0 |
| `add(sk, *curves, infer=True)` | attach `part.Curves.*` geometry (infer = coincident ends) | 5 curves, DOF 0 |
| `horizontal(sk, *lines)` / `vertical(sk, *lines)` | H / V constraints | solved line angle to the X reference 0.0 / 90.0 deg on a 30 deg plane |
| `pdim(sk, ref, ref_help, geom, assoc, origin, formula)` | perpendicular distance dimension, expression driven | `w` 60 -> 80: volume 28858.407 |
| `diameter_dim(sk, arc, on_arc, origin, formula)` | diameter dimension | bore driven by `bore_d`, DOF 0 |
| `radius_dim(sk, arc, on_arc, origin, formula)` | radius dimension | face sketch DOF 0, cut volume 28662.058 |
| `sketch_to3d(sk)` | `(u, v) -> Point3d` from the sketch origin / orientation | point lies on the 30 deg plane (0.0), length kept (12.2066) |
| `hv_polygon(part, sk, pts, to3d=None)` | closed H/V polygon with constraints; returns the lines | rectangle, DOF 0 after four `pdim` |
| `sketch_status(sk)` | `(status name, dof)` - the REAL count: automatic dimensions of a sketch created with Continuous Auto Dimensioning on are counted back in (`UnderConstrained`, dof + auto) | DOF 0 before finish; countdown free point 2 -> on the X axis 1 -> + one dimension 0; sketch created with the preference on: 2 / 4 / 3 / 4 / 2 where bare `GetStatus()` says 0 |
| `finish_sketch(sk)` | solve (a new-solver sketch with `LocalUpdate()` first), leave; `{"status", "dof", "auto_dims", "n_geom", "dims"}` | `WellConstrained`, 0, `auto_dims` 0; one free point: `UnderConstrained`, 2; new solver, rectangle drawn off size: `WellConstrained`, 0, lines at 30 / 50 |
| `sketch_circle(part, sk, centre, diameter)` | circle coincident with an NXOpen.Point (datum origin, `nxh.point`, linked arc-centre point - also out of the plane), diameter driven; adds no DOF. Any plane; in a new-solver sketch through `sketch_anchor` | DOF 0; hole axis follows the point 100 -> 120; on a linked point 3 mm out of plane: DOF 0, recess follows (nxa); on a chamfer face (normal 0, -0.7068, 0.7075): axis parallel to the normal, through the point |
| `sketch_rect_centered(part, sk, centre, width, height)` | H/V rectangle centred on a point: four line -> point dimensions of width/2, height/2; returns the lines `[bottom, right, top, left]`. Any plane; in a new-solver sketch the dimensions go to `sketch_anchor` | DOF 0, WellConstrained; 20 x 10 with D6 hole 858.628; xmin 90 -> 105 after `cx` 120 / `rw` 30; volume 1358.628; chamfer face and datum plane on it, point = sketch origin: DOF 0, 225.863 -> 345.863 after `ic_x` +5 / `ic_w` 30; point 1 mm off the plane: DOF 0 |
| `legacy_solver(sk)` | True = legacy sketch solver (every new part of a batch session), False = the solver of parts modelled in the NX 2206 user interface: there a smart point takes ONE constraint or dimension ("Invalid object type" on the second) and `sk.Update()` does not re-solve | new parts: True; UI-modelled part: False, second `pdim` to one smart point refused |
| `sketch_anchor(part, sk, point, force=False)` | the point a sketch may reference any number of times for an external point: `point` itself in a legacy sketch; in a new-solver sketch ONE reference point (named `nxf.ANCHOR`) coincident with it, reused on the next call | forced on a legacy chamfer-face sketch: rectangle + circle on it DOF 0, 6 objects, whole-sketch Extrude 225.863, follows `ic_x`; new solver, 45 degree plane: DOF 0, 225.863 -> 345.863 -> 225.863, no feature error |
| `sketch_lines(part, plane, haxis, origin, segments, name=None)` | unconstrained line sketch (rib sections, tube paths) | rib +2052.0; tube 1413.717 |

## Datums - recipe owner: `nx-curves-and-sketches`

| Function | Purpose | Check (measured) |
|---|---|---|
| `datum_plane(part, kind, geom, value=None, name=None, flip=False)` -> `(feature, DatumPlane)` | kinds `offset`, `angle`, `three_points`, `bisector`, `coincident`, `tangent`, `on_curve` | offset z 15 -> 22 by expression; from face z 25; angle: n.z = cos 30; three points: n parallel (0,-1,1); bisector x 30; coincident z 20; tangent 10.0 from the cylinder axis; on curve 25 % -> x 15; `flip` reverses the normal only |
| `datum_axis(part, kind, a, b=None, name=None)` -> `(feature, DatumAxis)` | kinds `point_dir`, `two_points`, `face_axis`, `intersection` | origin x 70 / dir Y; dir (1,1,0); cylinder axis x 100 / dir Z; plane intersection z 22 / dir X |

(A fixed plane from origin + normal is `nxh.datum_plane`.)

## Solid features - recipe owner: `nx-solid-features`

| Function | Purpose and rule | Check (measured) |
|---|---|---|
| `axis_from(part, obj)` | Axis from a datum axis, line, linear edge or cylindrical face. Only the LINE is reliable, the origin is NX's anchor: use `nxh.axis(part, origin, vec)` when the origin matters (Cylinder base) | revolve about datum Z 2552.544; groove about a shaft face; template datum Z: origin (0,0,0), cylinder z 0..20 (acceptance build 3 measured z = -91 on another datum axis) |
| `revolve(part, sec, ax, start=0, end=360, op=None, target=None, sheet=False, offset=None)` | tolerance 0.01 set; open profile is capped unless `sheet`; `offset` = thin wall | 4712.389; 180 deg 2552.544; sheet area 2980.376; Subtract groove 1394.867; thin wall 11675.393 |
| `extrude_ex(part, sec, vec, start=0, end=None, op, target, symmetric, through_all, until, until_next, thin, draft, sheet, origin, reverse=False)` | the options `nxh.extrude` lacks; symmetric `end` is the TOTAL length; `vec` may be an object (associative direction, see "Directions") | z -2.5; through all 2000; until face 1000; until next 1000; thin wall 1440; draft 5 deg 3660.251; sheet area 300 |
| `shell(part, body, removed_faces, thickness, inward=True, alternate=())` | `inward=True` = `DefaultThicknessFlip=True`: wall grows into the body | inward 24832; alternate floor 29088; outward 28032 (outside 84); closed hollow 33344; L bracket 20000 |
| `draft_faces(part, faces, pull, angle, stationary_faces=None, stationary_datum=None, link=None)` -> `(feature, expression)` | positive angle = section shrinks along +pull from the stationary reference; angle NUMBER, `link` = unitless expression | 5 deg 133251.982; linked 3 deg 137495.497, edited to 7 deg 129071.883 (wall 7.000 deg); datum pivot 144068.888 |
| `draft_body(part, faces, parting_plane, pull, angle)` | two-sided draft, widest at the parting plane; degree expression allowed | 147326.409; width 80.786 |
| `rib(part, body, sketch, help_point, thickness, reverse=None, draft_deg=None)` | perpendicular rib from an open SKETCH profile; `reverse=None` tries both directions | +2052.0 for cap normal +Z and -Z (forced `True` fails on -Z); draft 2 deg +2911.889 |
| `gusset_rib(part, body, datums, plane_origin, plane_normal, a, b, toward, thickness, info=None, plane=None)` | parallel rib; material goes to `line x sketch normal`, so the line is ordered from `toward`. Principal normal (X / Y / Z): offset datum plane (formula), end points may be formulas, sketch dimensioned to the datum axes (DOF 0) | +4400.0 for plane normals Y, -Y, X, Z; DOF 0, WellConstrained; end-point expression 45 -> 35: 3300.0; plane expression 320 -> 310: rib face at x 308; zero coordinates (point-on-axis): +4400.0, DOF 0; `plane=` an existing datum plane (offset from another body's / a linked face; `plane_origin`, `plane_normal` = None): +4400.0, DOF 0, rib follows the plane 820 -> 810 |
| `tangent_edges(part, seed)` | collector with the tangent edge chain | chain blend == two-chainset blend (140960.980) |
| `edge_blend(part, chainsets, variable=(), setback=None, stop_short=())` | several radii in one feature; variable radius; corner setback; stop short (percent of edge length) | 140960.980, 18 faces; variable removed 297.581; stop short 364.823; setback 4 expressions, 4298.88 vs 3480.83 |
| `blend_chains(part, chains, radius, smaller=(0.5,), chamfer=True, prefer_chamfer=False, overflow="retry")` -> report per chain | edge treatment chain by chain, each behind its own undo mark: blend at `radius` -> the same blend with the dialog's overflow switches (`overflow="retry"`, default; kept only if the body stays valid, flagged `"blend, overflow"`) -> smaller radius -> edge by edge -> chamfer (`chamfer=<size>` for its own offset). `overflow=False` = the strict ladder without overflow. A chain may be a callable that returns the edges when its turn comes. One refused blend never loses the others; nothing raises - read the report | 4 vertical edges R3: "blend"; R6 on the top of a 4 high boss: refused ("Unable to apply blend. Try reducing the radius value."), built as "blend, smaller" at `(6)*0.5`; R10 on an 8 x 8 boss with no smaller size: "chamfer" 1, removed 8.000; no feature error left (these three with `overflow=False`). Default retry: R10 beside an R3 on a 12 mm face, refused plain, built as "blend, overflow" at 10 with the same body as `edge_blend(overflow=True)` (839.69 removed), body valid; an R4 that fits stays "blend" |
| `break_edges(part, body, radius, convex=True, concave=True, min_length=0.0, smaller=(0.5,), chamfer=True, prefer_chamfer=False, overflow="retry")` -> report | the general drawing note (all edges R0.5, break edges 0.3 x 45, fillets R2 TYP): all sharp edges in ONE feature, else edge by edge with the fallback of `blend_chains`; reports the edges it could not treat (mid point, length, kind) | block, 12 edges R1, one feature: volume = rounded box, 0 sharp edges left; pocket floor edges only (`convex=False, min_length=6, prefer_chamfer=True`): 4 chamfered, material added; block with a 0.3 high pad: one feature refused -> edge by edge, 16 of 20 treated, 4 reported (`overflow=False`); with the default retry 18 of 20 treated, body valid |
| `sharp_edges(part, body, convex=True, concave=True, min_length=0.0)` / `edge_convexity(part, edge)` | sharp edges by kind ('convex' = outside edge, 'concave' = inside corner; tangent edges are 'smooth' and left out) | block with a pocket: 16 convex, 8 concave; `min_length=6` drops the four 5 mm corners |
| `face_blend(part, faces1, faces2, radius)` | rolling-ball blend on a convex edge (both normals reversed) | removed 206.018 |
| `chamfer(part, edges, first, second=None, angle=None)` | symmetric / two offsets / offset + angle | 60.0 / 120.0 / 77.942 |
| `hole(part, body, points, diameter, depth=None, tip=0, vector=None, cbore=None, csink=None, start_extension=False, until=None, until_next=False, start_chamfer=None, end_chamfer=None)` | HolePackage general hole; `vector` points INTO the material, None = face normal; cbore / csink through, or blind with `depth` measured from the start face. `until=face or datum plane` = depth Until Selected (a port bore that ends in the main bore), `until_next=True` = Until Next. `start_chamfer` / `end_chamfer` = radial offset or (offset, angle) of a chamfer made INSIDE the hole feature (ring dia = d + 2 x offset; angle from the start face; end chamfer on through holes) - measured in `nx-solid-features/scripts/hole_variants.py`: blind dia 6 x 10 + chamfer 1 = 310.204, through a 30 plate + both chamfers 0.5 = 853.204, blind cbore 866.507, blind csink 597.769, until a dia 14 cross-bore face + chamfer 326.145, all equal to the closed form. `start_extension`: False on a planar start face (True cuts a channel above it), **True when the start face is curved or inclined** - otherwise the material above the start plane stays (or NX raises "Holes were not created.") | blind 282.743; 118 deg tip 299.732; through x2 1130.973; cbore 1049.166; csink 780.428; face normal 157.080; Point input 251.327. On a D40 cylinder: crest, simple 281.148 (False and True), cbore True 1712.927; 8 mm off the crest: cbore True 1592.222 = analytic, cbore False 1554.657 (incomplete, no error), simple True 280.664 |
| `threaded_hole(part, body, points, size, thread_depth=None, hole_depth=None, vector=None, standard="Metric Coarse", start_extension=False, through=False, until=None, until_next=False, start_chamfer=None, end_chamfer=None, chamfer_angle=45, tip=None, tap_drill=None)` | ONE Hole feature with a symbolic thread: the cylinder is at **tap-drill** diameter. `size` "M10" / "M10x1.5" or the exact NX string. Depth: `hole_depth` (+ `thread_depth`) blind, `through=True`, `until=face`, `until_next=True`. `start_chamfer` / `end_chamfer`: True = 45 deg up to the nominal diameter, or a chamfer DIAMETER (the helper always writes it: the builder default is 10 for every size). `tap_drill`: None = NX table, number / formula or `"iso"` = override (M12: NX 10.3, ISO 10.2). `start_extension` as for `hole` | M6 x 1.0: 304.356; on the cylinder crest with start extension 303.587. `hole_variants.py` (156 checks): M10 blind 20 = 1183.203 (dia 8.5 cylinder + 118 deg tip), with start chamfer 1191.155 and a ring of dia 10.0; M8 through + both chamfers 1097.647; until a datum plane 703.848 / a cross-bore face 651.410 / next 651.410; 20 sizes M1.6 - M36: cylinder = table value, ring = nominal; child rows `SIMPLE HOLE` + `SYMBOLIC_THREAD` per point; STEP passes the validity gate |
| `thread_spec(size)` / `tap_drill(size)` / `ISO_COARSE` | metric callout -> nominal, pitch, ISO 2306 tap drill, NX size string (`"M10"` -> 8.5, `"M12"` -> 10.2, `"M10x1.25"` -> 8.75 = D - P). Use `tap_drill` for the cylinder a drawing's "M10" stands for when the hole is modelled another way | checked against NX's own thread table for 20 coarse sizes: equal except M3.5, M12, M14, M27, M30, M36 (NX 3.0, 10.3, 12.1, 24.077, 26.59, 32.103) |

## Sweeps, copies and body operations - recipe owner: `nx-patterns-and-body-ops`

| Function | Purpose and rule | Check (measured) |
|---|---|---|
| `tube(part, outer, inner="0", curves=None, feature=None)` -> `(feature, body)` | tangent-continuous path; path section filled in place | 1278.878; sketch path 1413.717 |
| `sweep_along_guide(part, profile, guide, hp_profile, hp_guide, op=None, target=None)` -> `(feature, body)` | closed profile -> solid, analytic faces | 1953.982; Unite 4480.0 |
| `plane_from_datum(part, datum_plane, offset="0")` | smart plane for mirror / trim "new plane" | trim 36000 -> 24000 by expression |
| `mirror_geometry(part, bodies, datum_plane, offset="0")` -> `(feature, bodies)` | mirrored body copies (snapshot: mirror last) | copy 22429.204, centroid x -15; united 44858.407; offset 5 -> centroid -5 |
| `mirror_feature(part, features, datum_plane)` | replay features on the other side | 61000.0; mirrored boss top on the surface |
| `pattern_linear(part, features, xdir, nx, px, ydir=None, ny=None, py=None, variational=False, increments=None)` | count includes the original. `increments=[(master expression, formula[, multiply])]` = Pattern Increment: instance k gets master + formula x k | 5 x 2 holes 58172.567; count 5 -> 3: 6 holes; variational 3 holes; increment on a cylinder diameter: 6, 7, 8, 9, 10 -> step 0.5, count 3: 6, 6.5, 7 |
| `pattern_circular(part, features, origin, vec, count, span="360", pitch=None, variational=False, increments=None)` | count + span, or count + pitch | 58549.558, 6 holes; pitch 30: 3 holes, third at 60 deg |
| `pattern_along(part, features, path_features, start_curve, start_xyz, count, percent="100", variational=True, fixed_orientation=False)` | Pattern Feature Along a path (sketch, curve feature, linked curve); copies turn with the path unless `fixed_orientation`; Variational needed when the seed makes its own body | line 60 + quarter arc R30, count 6: 6 solids equal to the seed, pitch 21.425 = path / 5, last copy 6 x 8 (default) / 8 x 6 (fixed) |
| `feature_group(part, features, name)` | Feature Group (type `FSET`); pass `[group]` to a pattern or mirror to copy the set as a unit | group [boss, hole] patterned x 4: 4 bosses, 4 holes |
| `feature_intersection_edges(part, features)` | collector with the rule Feature Intersection Edges: a blend on the Unite of pattern-geometry tools follows the tool count. Body-making / boolean features only: a pattern feature in the list is refused, and the seed of a Pattern FEATURE gives the seed's root only (there: blend inside the pattern set) | Pattern Geometry + one Unite + blend on the rule: 3 blended roots -> count 5: 5; `[tool, pattern geometry]` refused ("Third parameter is invalid") |
| `pattern_geometry(part, bodies, linear=None, circular=None)` -> `(feature, bodies)` | body copies; boolean them with `tool_features=[source, pattern]` | 3 copies, subtract 13000.0; circular 3 copies, x 170 |
| `trim_body(part, body, keep_point=None, reverse=False, datum_plane=, plane=, sheet=, faces=)` -> `(feature, reverse used)` | `keep_point` = bounding-box test + retry reversed | 32000 (reverse False); far side 16000 (reverse True); sheet tool 33699.978 |
| `split_body(part, bodies, datum_plane=, plane=, sheet=, faces=)` -> `(feature, pieces)` | solid count +1 per cut | 19200 + 28800 |
| `delete_body(part, bodies)` | Delete Body feature | solid count back, 19200 kept |
| `move_object(part, objs, kind, value, vec, origin)` | `distance` / `angle` / `delta` | xmin 25; y 806, z 7; rotated xmax 30; volume 6000 |
| `extract_body(part, bodies, fix_at_timestamp=True)` -> `(feature, bodies)` | frozen or live body copy | frozen 8000; live 6429.204 |
| `scale_body(part, bodies, factor, about=(0, 0, 0))` | uniform scale | ratio 1.061208; xmax 20.4 |

## Synchronous modelling - recipe owner: `nx-synchronous-modeling`

| Function | Purpose and rule | Check (measured) |
|---|---|---|
| `rule_faces(part, kind, arg)` | one face rule: `dumb`, `tangent`, `connected_blend`, `all_blend`, `feature`, `datum`, `body`, `boss_pocket` | tangent loop +1: 51805.310; connected blend R5: 45592.182; all blends deleted: 48000; feature link follows 27 -> 31; datum + offset 67200; body +1: 57288; boss moved, y +25 |
| `offset_region(part, faces, distance, reverse=False)` | positive = outward = adds material (a hole shrinks) | +5: 60000; -3: 40800; hole wall +1: 46994.690; reverse: 36000 |
| `pull_face(part, faces, vec, distance)` | Pull Face: the face is translated and its own side walls are made longer (or a pocket of its outline is cut) - use it where Move Face / Offset Region would have to extend inclined or blended neighbours. Faces, or a region-boundary rule | top +5: 60000.0, top at z 25; top -3: 40800.0 |
| `label_chamfer(part, chamfer_faces, face1, face2)` | tell NX that faces of a parameter-less body are a chamfer between two faces, so that an edit of a neighbour carries it at its size | 5 x 5 chamfer, Offset Region +3 of the face above: 54700.0 (carried). Unlabelled: 54700 when NX recognises the chamfer itself (made in the same session), 53920 when it does not |
| `move_face(part, faces, vec=None, distance=None, angle=None, origin=(0, 0, 0), points=None)` | distance / angle about an axis / point to point | 60000; 10 deg 56463.695; hole to (40, +25), volume kept |
| `replace_face(part, faces, replacement, offset=0, offset_reverse=False, reverse=False, accept=None)` | onto a datum plane, faces, or a rule. `reverse` = `ReverseDirection`: False for a datum plane or a same-direction face, **True for a MATING face (opposed normals)**; `reverse=None` tries both (optional `accept()` check) | 62400; offset 2: 67200; offset reversed 57600; linked face 64800 -> 74400; mating face (-Z): reverse False raises "A face does not intersect properly and its edges cannot adapt.", reverse True 62400.0, reverse None 62400.0 |
| `delete_face(part, faces, heal=True)` | heal closes the wound; `heal=False` leaves a sheet | hole healed 47845.487; one sheet body |
| `resize_face(part, faces, diameter)` | new diameter of cylindrical faces | hole 10 -> 16: 43824.248; also on a BREP 43978.761 |
| `resize_blend(part, faces, radius)` | new blend radius | R3 -> R5: 43549.558 |
| `divide_face_offset(part, face, edges, distance)` -> `(feature, flip used)` | offset-in-face divide; BOTH offset directions are tried and the one that divides the face is kept. The flag follows the seed edge, not the loop type - it is informational only; find the new region by position / area | inner region 1500.0, boss 52500; hole edge: annulus 122.616 (pi*39 = 122.522, spline offset) |
| `divide_face_by_plane(part, faces, datum_plane)` | divide by a datum plane (through a collector) | 2 top faces, 800.0 |
| `remove_parameters(part, bodies)` | bodies -> BREP features | 1 BREP, volume kept 46429.204 |
| `move_face(..., finder=None, cut_paste=False)` | `finder="offset"` takes the inner partner faces of a thin wall along (Face Finder); `cut_paste=True` = Move option Cut and Paste with heal and paste | shelled box, outer wall +5 with `finder="offset"`: dV 760 = 5 x wall section, wall 2.000; alone: dV 4000, wall 7.000; hole cut and pasted 15 along X, volume kept |
| `find_related(recognition, relations)` | the Face Finder for any synchronous builder: `<Name>Enabled = True` AND `Recognize<Name>(True)` after the rules are in the collector (`offset`, `coplanar`, `equal_diameter`, ...). Returns the face count - check it | coplanar: both boss tops rise (dV 600); equal diameter: both holes resized |
| `resize_face(part, faces, diameter, finder=None)` | `finder="equal_diameter"`: every hole of that size | two dia 6 holes -> dia 8 |
| `delete_face(part, faces, heal=True, cap=None)` | `cap=` face or datum plane when the neighbours cannot close the wound | block wall deleted, cap at x = 70: 56000 |
| `delete_holes(part, faces_or_body, max_diameter)` | Delete Face type Hole with the size filter - simplified copies (use on an `extract_body` copy) | dia 4, 10, 14 -> only 14 left on the copy, the original keeps three |
| `blend_census(part, body)` -> `{"recognised": {r: n}, "unrecognised": [faces]}` | which rounds NX accepts as blends; the others are stretched by a neighbouring face edit and refused by Resize Blend | R4 recognised, a conic B-surface blend listed as unrecognised |
| `replace_blend(part, faces, radius=None)` | Replace Blend: unrecognised blend faces -> true rolling-ball blends (inherit the fitted radius, or set one) | conic 5 / 3.33 -> R5: 48000 - K 25 20 - ...; then `resize_blend` 3 works |
| `label_notch_blend(part, faces)` | label a fillet NX does not recognise (radius = whole step height) so that Resize Blend works | R50 notch -> R30: 1219314.2; unlabelled: "The change failed." |
| `optimize_face(part, body, tolerance=0.01)` -> `(faces before, after)` | merge split faces / simplify surface types; strips parameters; does not make a blend recognised | top split by Divide Face: 7 -> 6 faces |
| `linear_dimension(part, origin_edge, measure_edge, faces, value, axis="X", plane=None)` | Linear Dimension: a TARGET distance, stored and editable. Needs `GetDimension()` and the OrientXpress plane (both inside) | 60 -> 70 along X; expression set to `dim_len` = 66; Y 40 -> 45; Z 20 -> 26 |
| `radial_dimension(part, faces, value, diameter=True, finder=None)` | Radial Dimension: target diameter / radius | dia 10 -> 14; stored value edited to 12 |
| `angular_dimension(part, origin_face, measure_face, faces, value, alternative=False)` | Angular Dimension: target angle between two planar faces (reading = angle between the outward normals) | wall to 100 deg from the top: wedge 0.5 x 20 x 20 tan 10 x 40 removed |

## Organising and editing a tree - recipe owner: `nx-journal-core` (`references/existing-parts.md` section 7)

| Function | Purpose and rule | Check (measured) |
|---|---|---|
| `nxh.insert_after(part, feature, check=True)` (context manager) | insert point: roll back to `feature`, build, roll forward, restore suppression, report; undoes an insertion that breaks a later feature | blend R8 before a Shell: inner R6, wall 2.000, closed-form volume; a bore that makes a later Subtract miss: refused, tree as before |
| `nxh.suppress_status(f)`, `nxh.rolled_back(part)`, `nxh.current_feature(part)` | why a feature is inactive: 1 person, 2 expression, 4 failed, 16 rolled back, 64 parent | inside the insert point the Shell reads 16, a suppressed blend 17 |
| `nxh.reorder(part, features, target, after=True)` | Reorder Feature + regenerate; refuses a move before a referenced feature | Shell before the pad: pad solid, 28823.416; back: first volume |
| `nxh.wall_partners(faces, wall=None, tol=0.01, max_wall=None)`, `nxh.wall_thickness(face)` | the face on the other side of a thin wall; thickness behind a face | 18 of 19 faces of a shelled box: one partner at 2.000; rim: none |
| `nxh.history_mode(part)`, `nxh.legacy_note(feature)`, `nxh.LEGACY_TYPES` | history-free parts; legacy feature types -> today's command | used by `inspect_part.py` |
| `nxh.edge_points(edge, n=13, ends=True)` | n points along an edge / curve; `ends=False` leaves the vertices out | 60 mm edge: 0, 15 .. 60; without ends 10 .. 50 |
| `nxh.pole_count(part, face)` | poles of a B-surface face (Point Set, undone again) | a conic blend face: poles counted, no feature left |
| `nxh.curve_quality(curve, n=200)`, `nxh.curve_frame(curve, t)` | the curvature comb as numbers: inflections, curvature peaks, `r_min`, end curvatures, torsion - check guides and sections before a loft | quarter arc R10: 0 inflections, 0 peaks, r_min 10, planar |
| `nxh.join_angle(c1, t1, c2, t2)`, `nxh.planarity(curves)`, `nxh.max_dev(part, curve, pts)` | tangent angle at a join (0 = G1), out-of-plane distance, distance of points from a curve | 0 / 90 deg; 0 / 7; 2.000 |
| `sketch_uv(sk, pt)` (was `_sketch_uv`), `sketch_rect_centered` on a SKETCH point | sketch coordinates of a 3D point; a point that is geometry of the sketch is dimensioned as `StartPoint` | rectangle centred on a free sketch point: accepted, DOF 2 (the point) |
| `divide_face_by_curves(part, faces, curves=, curve_features=, extend=False, vector=None)` | Divide Face by curves with the projection SET to the face normal (the builder default, curve-plane normal, divides along the wrong lines without an error) | diagonal line on a 60 x 40 top: 900 + 1500; short line with `extend`: 600 + 1800 |
| `suppress_by_expression(part, features, formula=None, shared=True)` | Suppress by Expression, one shared expression (or one each); a group counts as one feature | lug + blend on `if (length > 200) (1) else (0)`: 340 active, 150 gone, 340 back |
| `replace_feature(part, old, new, tolerance=None, delete_original=True)` | Replace Feature with automatic geometric match; undone when a dependent would be lost | Block -> Extrude: volume kept, `base_h` 40 drives it; 80 -> 100 mm base: refused at tolerance 1, kept at 25 |
| `sketch_internal(feature, internal=True)` | make the feature's sketch internal / external | one top-level row less / back |
| `to_reference(part, curves, reference=True)` | sketch curves (and sketch POINTS) -> reference geometry (sketch active) | a centre line across a whole-sketch profile: reference = fine, active = Extrude fails; a sketch point besides the profile: active = "Cannot extrude", reference = 1000.0 |
| `nxh.section_feature(part, features, help_point, curves_only=False)` | whole-sketch section; takes in every ACTIVE curve and POINT. `curves_only=True`: the section accepts curves only | 20 x 10 profile + one active point: "Cannot extrude. The section and direction may be incompatible."; `curves_only=True` 1000.0; `nxh.section_region(curves=lines)` 1000.0 |
| `measure_length(part, edges)`, `measure_distance(part, a, b)` -> `(feature, expression)` | associative measurement features whose expression can drive formulas | 80 -> 91.6; `floor(len)/2` = 45.5 |
| `import_expressions(part, path, replace=True)` | expression text file; Replace also re-wires `p` expressions | masters created, `p0=box_len`, body 120 long |

## Feature copies and draft types (from the packages that measured them)

| Function | Purpose and rule | Check (measured) |
|---|---|---|
| `copy_check(part, n, seed_delta, body=, v_base=, copies=, seed_faces=, count_faces=)` -> `{"ok", "problems", ...}` | THE check after every Pattern / Mirror Feature: volume = base + n x seed, signature-face count, no instance message | 4 bosses ok; asked for 5: not ok, "volume delta ..." |
| `add_to_pattern(part, pattern, seed, make_detail)` | a detail for every copy of an EXISTING pattern: insert point at the seed, add to the pattern's input, roll forward | root blend added to a 4 x boss pattern: 4 blended bosses, order boss, blend, pattern |
| `pattern_linear(..., stagger=None, frame_only=False)` | `stagger="row"` / `"column"`; `frame_only` = boundary instances only | 4 x 4: 12 holes frame only; staggered rows start at x 20 |
| `pattern_feature(part, features, layout, variational=False)` | free layout callback on the pattern service | used with `nxf._linear` |
| `pattern_clock(part, pattern, i, j, delta1=0, delta2=0)` | move ONE instance of an existing pattern | instance [2][0] + 5: x = 10, 30, 55, 70 |
| `scale_axisymmetric(part, bodies, along, other, origin, vec)` | Scale Body with two factors | 1.1 along Z, 1.05 across: volume x 1.21275 |
| `unite_remove_region(part, target, tool, tool_face, keep=False)` | Unite that removes (or keeps) one region of the tool | post overshooting a plate: stub below removed |
| `extract_body_before(part, bodies, before)` | in-process copy: Extract Body reordered before a feature | the blank before the holes: 48000 |
| `sketch_on_path(part, path_rules, seed, start_xyz, percent=0)`, `variational_sweep(part, sketch, help_point, op, target)` | sketch normal to an edge path; its curves swept along that path | 2 x 3 lip along a 60 mm edge: + 360 |
| `draft_parting(part, faces, pull, above, below=None, parting_datum=, parting_faces=)` | Draft both sides of a parting reference, one or two angles | 7 / 10 deg about z = 10: two prismatoids |
| `draft_edges(part, [(edges, angle)], pull)`, `draft_parting_edges(part, edges, pull, angle, plane)` | Draft From Edges / To Parting Edges | bottom edges stay, 5 deg; below a parting line 3 deg: 143269.95 |
| `draft_body(..., match=None, extreme=False, true_draft=False)` | match type removes the ledge at an off-centre parting plane | no match 11 faces 148953.554; FromEdges 10 faces 149952.088 |
| `split_edges(body)`, `divide_faces_by_sheet(part, faces, sheet)` | parting line: edges between coplanar faces; Divide Face by a sheet | 4 edges at z = 10 |
| `shell(..., pierce=None)`, `extrude_ex(..., single_offset=None)` | Shell `TgtPierceOption`; Extrude with the closed profile offset (Single-Sided) | pocket 5 inside the edges of a face: 50 x 30 x 8 with `-5` |
| `edge_blend(..., overflow=False)`, `nxh.blend(..., overflow=False)`, `nxh.blend_overflow(builder, overflow)` | `overflow=True` sets the three overflow switches as in the dialog (a journal's builder has them off - the helpers' default, so that a blend that does not fit is refused); a dict sets single builder properties | R10 beside R3 on a 12 mm top: refused by default, commits with `overflow=True` (839.694 removed, valid body); `{"MoveSharpEdge": True}` commits a different body |

## Surfaces - recipe owner: `nx-surface-modeling`

| Function | Purpose and rule | Check (measured) |
|---|---|---|
| `through_curves(part, sections, solid=False, preserve=False, align=None, g1_first=None, g1_last=None)` | loft; section starts must correspond (twist = valid but wrong body) | sheet area 1942.914 (1942.968), 4 free edges; solid 29319.959 (29321.531); preserve square frustum 28000.0, 6 faces; G1: normal z 1.0, area 1514.040 |
| `swept(part, sections, guides, solid=False, scaling=None, axis=None)` | 1-3 guides; B-surface result. `axis=(x, y, z)` = orientation By Vector Direction: **needed on a helix or any 3D guide**, else the section rolls about the path | area 785.398; solid 3941.755 (3947.842, 0.15 % low); two guides on surface 0.0; 4 x 2 wire on a helix with `axis=(0, 0, 1)`: volume ratio 1.000 +- 0.001, both end sections 4 wide; without: end section no longer 4 wide |
| `helix(part, diameter, pitch, turns, right_hand=True)` | constant helix along +Z from the origin, starts at (d/2, 0, 0); guide for `tube` (round wire) or `swept(axis=)` | length = turns x sqrt((pi d)^2 + p^2); quarter-turn point (0, +d/2, p/4), left hand (0, -d/2, p/4) |
| `bounded_plane(part, curves=None, edges=None, hp=(0, 0, 0))` | planar sheet, inner loops = holes | 1121.460 |
| `fill_surface(part, curves=None, edges=None, hp=(0, 0, 0), g1=False, patch=False)` | fill a closed chain, optional patch into the sheet | patched 1200.0, 2 faces; non-planar 2781.886 |
| `sew(part, target, tools, tol=0.01)` -> body | closed set becomes a solid; caller checks | solid, 0 free edges, 29319.959, 3 sheets consumed; open pair 6 free edges |
| `thicken(part, body, first, second=0, reverse=False)` | sheet -> new solid spanning second..first, both measured the same way along the normal (both sides = `(1, -1)`; `(1, 1)` is a zero-thickness error) | 2400 -> 4200 by expression; both sides 1570.796; reversed 706.858 |
| `extend_sheet(part, edges, dist, as_new_sheet=False)` | natural-curvature extension | 942.478; new sheet 157.080, original unchanged |
| `trim_sheet(part, body, region_xyz, keep=True, curves=, faces=, datum_plane=, hp=, vec=)` | region point = keep / discard side | line 450; circle hole 1121.460; datum plane 450; faces 450; vector projection 392.699 |
| `offset_surface(part, faces, dist, flip=False)` | new offset sheet | on z = 25 (0.0), area 2400; half cylinder +1: 942.478; flipped 628.319 |
| `extract_face(part, faces, associative=True)` | sheet copy of faces | 2400; two faces 3200, 6 free edges; non-associative 2400 |

## STEP - recipe owner: `nx-journal-core` (`references/import-export.md`)

| Function | Purpose and rule | Check (measured) |
|---|---|---|
| `step_dir()` | `<NX>\STEP214UG` | directory exists |
| `step_schema(path)` | `AP242` / `AP214` / `AP203` from the file header | both exported files identified |
| `step_export(part, dest, ap242=True, save=True, timeout=180)` | saves the part (the translator reads the file), exports solids, waits for the file | AP242 and AP214: 1 `MANIFOLD_SOLID_BREP` each |
| `step_import(part, path, scratch_prt)` -> bodies | AP242 -> `Step242Importer` without settings file; AP214 / AP203 -> `Step214Importer` + `step214ug.def`. An ASSEMBLY STEP arrives as components: returns `[]`, read them with `instance_solids`; raises when nothing arrives | 1 body each, volume 46274.690 = source; imported BREP edited (offset region +2: 50902.159); assembly: 2 instances (nxa self-test) |
| `instance_solids(part, load=True)` -> rows | leaf component instances with their unblanked solids that are members of the component's reference set (what an assembly STEP writes); loads partially loaded prototypes | piece part: 0 rows; assembly: PCB at (13, 5, 3) 1 solid, BASE 2 solids (base + the cover kept in MODEL; the linked copy and the excluded cover are skipped) |
| `step_roundtrip_check(stp, out_dir, name="stepcheck", restore=None, part=None, bodies=None, rel_tol=1e-4)` -> dict | re-import into a scratch part and compare per body (sorted volumes, relative tolerance) with `bodies`, or with the UNBLANKED solids of `part` (only visible solids are exported), or with every leaf instance of an assembly; `match`, `per_body`, `max_rel`, `blanked_skipped`, `instances`, `healthy`, `restored` | 1 solid, 46274.690, match, examine all 0, work part restored; 3 solids with 1 blanked: STEP has 2, `blanked_skipped` 1, match; `bodies=[1 of 2]`: match False; `rel_tol=1e-9` on blocks: match |

## Assemblies (`nxa.py`) - recipe owner: `nx-assemblies`

`import nxh, nxf, nxa`. Constraint helpers take `(component, geometry)` pairs; the geometry is the
PROTOTYPE object (found with `nxh.faces(body_of(comp.Prototype), ...)`, `nxa.circ_edge`) or its
occurrence. Constants: `nxa.T` (constraint types), `nxa.AL` (alignment), `nxa.IDENT`.

| Function | Purpose and rule | Check in `nxa_selftest.py` (measured) |
|---|---|---|
| `new_assembly(path)` | assembly part from `assembly-mm-template.prt`; save it before interpart expressions | used for both test assemblies |
| `add_component(assy, path, name, origin=(0,0,0), r=None, refset="MODEL")` | add near the final place, roughly oriented | origin x 135; with `rot("x", 20)`: z axis (0, -sin 20, cos 20); free part DOF 6 |
| `rot(axis, deg)`, `to_nx(r)`, `frame(comp)`, `to_assy(comp, xyz)`, `axis_of(comp, k=2)` | orientation matrix, component frame read-back, part -> assembly coordinates | head centre z = 40 + 30 cos 20 |
| `components(assy)` | `{name: Component}` (after a reopen) | PLATE found; `["BASE", "PCB"]` after reopen |
| `occ(comp, obj)` / `circ_edge(body, centre, radius)` | occurrence of a prototype object (raises when not in the reference set); the one FULL circular edge at a centre | used by every constraint; min_dist between occurrences 140.0; `circ_edge` on a slot's half arc raises |
| `arc_edge(body, centre, radius, tol=1e-3, near=None)` | circular edge by true centre + radius, full circle or PARTIAL arc (slot end); `near` picks among several. Concentric accepts a partial arc | half arc length 15.708; same edge as `circ_edge` on a full rim; Concentric on the half arc: Solved, pin at (20, 115, -20), DOF [1, 0] |
| `constrain(assy, ctype, refs, align=None, expr=None, name=None, fix_hint=None, check=True)` | one constraint, one Solve, raises unless `Solved`; `fix_hint=1` keeps the second reference's part still | both free: NX moved the SECOND component; with `fix_hint=1` it moved 0.0 |
| `fix(assy, comp)` | ground | Solved, `IsFixed`, DOF [0, 0] |
| `touch` / `align(assy, moving, target)` | planar faces opposed / flush | origin z -20, DOF [1, 2]; z -25, DOF [1, 2] |
| `concentric(assy, moving, target)` | circular edges: coaxial and coplanar | origin (20, 30, -20), axis +Z, DOF [1, 0] |
| `center_axis(assy, moving, target)` | cylinder faces, infer centre / axis | origin (80, 30), DOF [1, 1] |
| `align_lock(assy, moving, target)` | edges: rigid; cylinder faces: no spin | DOF [0, 0]; DOF [0, 1] |
| `distance(assy, moving, target, expr)` | expression-driven gap (0 without an expression) | gap 5.0 -> 12.0 by `lift` |
| `angle(assy, moving, target, expr)` | expression-driven angle on a pivoted part | 40.0 -> 70.0 deg by `swing`, DOF [0, 0] |
| `parallel` / `perpendicular(assy, moving, target)` | square a part up | axis z 1.0, DOF [1, 3]; axis z 0.0, DOF [2, 3] |
| `center22(assy, part_a, part_b, slot_a, slot_b)` | the part's two faces centred in the slot's two | wheel mid-plane x 140.0, DOF [1, 2]; + `center_axis`: (15, 28), DOF [1, 0] |
| `flip(assy, c)` | Reverse Last Constraint | pin z -20 -> 40, axis -Z, and back |
| `status_name(c)`, `dof(comp)`, `enum_name(cls, v)` | solver status text; [rot, trans] freedom left | asserted after every joint |
| `drag(assy, comp, translation=, spin=)` | Move Component freedom test; blocked directions do not move | blocked slide 0.0 mm; free spin 25.0 deg |
| `move_component(assy, comp, translation)` | translate + update (moves a fixed part too) | cube x 45; PCB x 13 |
| `new_component(assy, path, name)` / `set_work(comp)` | in-context part at the origin; Make Work Part (`None` = back to the assembly) | work part = new part, display part = assembly |
| `interpart_expr(part, name, source, source_name=None, unit="mm")` | `name = "source"::name`; stored as `name = name_0` + the link `name_0`; values only | 6.0, follows the master 6 -> 7; `boss_d_0` is the interpart link |
| `exclude_from_model(part, bodies)` | take link copies / construction bodies out of the MODEL reference set (part = work part). The assembly STEP then omits them; the STEP of the piece part alone does not follow MODEL (delete / blank construction solids, check with `step_roundtrip_check(bodies=...)`) | link sheet in MODEL: Clearance reports BASE / PCB Touch at a real gap of 3.0 (SimpleInterference: NoInterference); after the removal: no pair |
| `wave_link(wp, source_occurrence, kind="body" or "face", fix_ts, pos_indep, associative, keep_out_of_model=True)` -> `(feature, bodies)` | associative linked body / face in assembly coordinates; by default the copy is removed from MODEL (no false clearance results, not in the assembly STEP, no occurrence in the assembly). LINKED_BODY > OFFSET_REGION > SUBTRACT is identical with the tool link in or out of MODEL: 5640.917 at creation, 5495.477 after pcb_len 66 + move, both variants | LINKED_FACE sheet on z = 3; LINKED_BODY volume 3817.381 = source, xmin 10 -> 13 after the component move |
| `link_curve(wp, curve)` | WAVE-linked composite curve (`LINKED_CURVE`) from a curve of another part - a skeleton part's path or centre line; `curve` is the object in its own part. Path for `nxf.pattern_along` | skeleton without a solid, driven line 60: 4 links at pitch 20; skeleton edited to 90: pitch 30, link not broken (both components at the assembly origin) |
| `arc_centre_points(wp, body, radius=None)` | **position from linked geometry**: associative points at the centres of the circular edges of a linked sheet; they follow source edits AND component moves (an interpart expression does not see the placement) | 2 points, first (20, 15, 3); bosses (20,15),(60,35) -> hole_x 14: (24,15) -> PCB moved +3: (27,15),(63,35) while the interpart `hole_x` stays 14 |
| `offset_point(part, point, vec, formula)` | associative point at a formula distance from a (linked) point along a direction | (24, 15, 3); follows hole_x and the component move: x 31; its own expression 4 -> 6: x 33 |
| recipe: `nxf.datum_plane(wp, "offset", [linked_sheet.GetFaces()[0]], formula)` | plane offset from a LINKED face; + is the source's outward normal | x 72 (10 + 60 + 2); component moved: 75; pcb_len 66: 81 |
| recipe: `nxf.sketch_circle(wp, sk, linked_point, d)` (= `sk.CreateCoincidentConstraint(nxf.cg(arc, nxf.CP.ArcCenter), nxf.cg(linked_point))`) | sketch geometry tied to a linked point, also when it lies out of the sketch plane | DOF 0 with the point 3 mm above the plane; recess axis (60, 35) -> (63, 35) after the move -> (59, 35) after hole2_x 46 |
| `cylinder_at_point(wp, point, vec, diameter, height, op=None, target=None)` | cylinder on an associative point (`nxf.hole` also takes these points) | 2 bosses +169.646; pilot holes via `nxf.hole` -25.133 |
| `load_fully(objs, update=True)` | after a reopen: `LoadThisPartFully()` on every linked part, then update | reopened parts not fully loaded; both loaded; PCB edit hole_x 18 reaches the base: boss (31, 15) |
| `clearance_set(assy, name, zone=0.0)` / `run_clearance(cs)` | Clearance Analysis over all components; Hard = overlap, Touch = contact | CUBE / PLATE Hard; line-to-line pin / plate Touch; far cube in no pair |
| `simple_interference(assy, body_a, body_b)` | one pair, overlap volumes | `InterferenceExists` 200.000; `NoInterference` |
| `step_roundtrip(assy, stp, out_dir, name="asmcheck", rel_tol=1e-4)` | assembly STEP AP242 export + re-import + per-instance comparison | imports as an assembly, 2 instances, 3 solids, match (max rel 2e-16), healthy, PCB instance at x 13, work part restored |

## Which part must be the work part (display part = assembly) - measured in `nxa_selftest.py`

Work part = the assembly, target = a component's part (fully loaded):

| Call on the component's part | Result |
|---|---|
| `nxh.volume`, `nxh.dist_to`, `nxh.face_at`, `nxh.feature_errors`, `nxh.body_ok` / `examine_geometry`, `nxh.bbox`, `nxh.faces` | work: 7138.230, 5.0, 1 face, `{}`, True |
| `nxh.expr` (create), `nxh.set_expr` + `nxh.update()` | work: 3.0 created, 2 -> 2.5 edited (also how a reopened assembly's source part is edited) |
| `nxh.block(part, ...)`, `nxh.datum_plane`, `nxf.datum_plane` | NO error, but the feature is created in the WORK part (the Block's `OwningPart` was the assembly) |
| `nxh.extrude` of a section, `nxf.hole` (anything with a Section) | "Creating an interpart section is not allowed." |
| `nxh.blend`, `nxf.offset_region` (collectors of the other part's faces / edges) | "Internal error" |
| `nxh.Datums(part)` | "No object found with this name" |

Rule: **measuring and expression edits work on any loaded part; creating geometry needs
`nxa.set_work(component)` first** (and `nxa.set_work(None)` before assembly-level work: constraints,
Clearance Analysis, STEP of the assembly). While a component is the work part its whole part is shown
(reference set Entire), so `FindOccurrence` finds bodies that are not in MODEL; check occurrences after
`set_work(None)`.

## Not in nxf (use the owning skill's recipe)

Curve Mesh, Studio Surface, N-sided, Ruled, Law Extension, Enlarge, Untrim, Unsew, Patch, Make Corner
(`nx-surface-modeling`); three-face blend, conic / G2 blend, ApexRangeChamfer, groove, Thread feature,
neck chamfer / relief of holes (`nx-solid-features`); helix by law or along a path, mirror curve,
pattern instance delete / suppress, general / reference patterns, increments in the second pattern direction, bounding body,
Mirror Body feature, Split Body with an extrude / revolve tool
(`nx-patterns-and-body-ops`, `scripts/round3_checks.py` and `course_checks.py`); component patterns,
reference sets, constraint limits, arrangements (`nx-assemblies`); Delete Face new-plane cap and blend type, Copy / Paste / Mirror /
Pattern Face, Move / Offset Edge, Make Coplanar etc., Resize Chamfer / Hole, Reorder Blends
(`nx-synchronous-modeling`); projected / intersection / offset curves, splines, sketch
fillet / offset / project, datum CSYS, point feature (`nx-curves-and-sketches`).
