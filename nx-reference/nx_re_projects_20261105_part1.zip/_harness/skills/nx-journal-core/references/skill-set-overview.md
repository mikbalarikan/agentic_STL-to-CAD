# NX modelling skills - overview

Built 2026-10-04 for Siemens NX 2206 driven by headless NXOpen Python journals. Every rule in
these skills carries its evidence: `[mined]` (the user's own parametric parts), `[course ...]`
(the 6-day NX course) or `[verified]` (measured in NX 2206 batch).

> Private material: the `references/user-practice*.md` files name the user's projects and part
> paths, and the course notes are derived from a purchased course. Keep this folder out of any
> public push or pull request.

## The skills
| Skill | Use it for | Verified example journals |
|---|---|---|
| `nx-journal-core` | entry point: launcher, helper modules `nxh` (core + measurement), `nxf` (85 feature helpers), `nxa` (43 assembly helpers), `inspect_part.py`, `dump_part.py`, verification rules, STEP/STL, editing existing parts | 3 self-tests, 517 checks |
| `nx-modeling-strategy` | planning: job classes, base-shape choice, feature order, sketch and parameter policy, the user's house style, worked plans and complete example builds | journals of the 5 acceptance tests |
| `nx-curves-and-sketches` | constrained sketches, datum planes / axes, section rules, splines, bridge, project / intersection / offset curves, helix, text | 7 journals, 167 checks |
| `nx-solid-features` | Revolve, Shell, Draft, Draft Body, Rib, blends, chamfers, holes (threaded at tap-drill diameter, chamfers inside the hole), threads, grooves, extrude options, housings of revolution with ports | 8 journals, 388 checks |
| `nx-patterns-and-body-ops` | Mirror Geometry, patterns, Trim / Split / Delete Body, booleans, Move Object, Scale, Tube / Sweep, extract and WAVE bodies | 6 journals, 301 checks |
| `nx-surface-modeling` | Through Curves, Curve Mesh, Swept, Studio / Section Surface, Fill, Bounded Plane, Trim Sheet, Extend, Sew, Thicken, Patch, Face Blend, continuity checks | 10 journals, 377 checks (helper `nxblade.py`) |
| `nx-synchronous-modeling` | Offset Region, Replace / Move / Delete / Resize Face, Make Parallel and the other relate commands, Mirror / Pattern / Copy Face, imported-body repair and rework | 6 journals, 245 checks |
| `nx-assemblies` | components, constraints by remaining motion, DOF, top-down WAVE design, interpart expressions, reference sets, clearance and interference | 4 journals, 139 checks |
| `nx-reverse-engineering` | rebuilding CAD on scans: STL import, census of an unknown scan, alignment, Fit Surface / Fit Curve, snapping to design values, signed scan-to-CAD deviation (helper `nxre.py`) | 4 journals, 134 checks |
| `nx-sheet-metal` | Tab, Flange, Contour Flange, Normal Cutout, Unbend / Rebend, Convert to Sheet Metal, Flat Pattern, DXF | 4 journals, 343 checks |
| `nx-drafting` | drawing sheets, base / projected / section / detail views, associative dimensions with tolerances, parts list with balloons, PDF / DXF export (helper `nxd.py`) | 2 journals, 63 checks |

Regression: `nx-journal-core/scripts/run_all_examples.ps1` runs all 54 example journals (about
2 670 measured checks; the last full run took about 40 minutes with other NX sessions on the machine) -
run it after changing a helper or upgrading NX. It skips the helper modules and waits for free memory
before each NX launch (`-MinFreeMB`, default 700).

## Where the knowledge came from
1. **The user's parts.** 4 935 `.prt` files (4 153 unique) under the project folder were opened
   read-only in NX batch. 894 are parametric, 2 142 have parameters removed, 921 are empty or
   assembly-only. 763 parametric parts were dumped feature by feature, including the settings of
   every feature read back from its edit builder; statistics use the 639 distinct user parts
   (46 631 features). Summary: `nx-modeling-strategy/references/user-practice-overview.md`.
2. **The course.** 26 recordings (about 22 hours, Turkish) transcribed with Whisper and sampled as
   contact sheets plus targeted full-resolution frames; twelve sets of notes. Two recordings have
   no audio and were read from frames. The course folder holds videos only - no exercise parts.
   Summary: `nx-modeling-strategy/references/course-method.md`; per-family cards in each skill's
   `references/course-notes.md`.
3. **NX 2206.** Every recipe was created by a journal and confirmed by measurement; commands that
   could not be made to work headless are listed as such with the exact error text.

## Acceptance tests
Fresh agents that had only these skill files built real jobs (journals, plans and results are in
`nx-modeling-strategy/examples/`): a drafted / shelled / ribbed enclosure half with mirror and
rim lip, a turned knob, an imported bracket reworked with synchronous edits, a surfaced grip, a
top-down two-part enclosure around a PCB assembly, and extensions of two of the user's real
production parts on copies. Their defect reports were folded back into the skills, and a final
confirmation test on two new jobs (a top-down battery dock, a rebuild of an unknown noisy scan)
needed 5 NX runs in total, one of them caused by a skill gap (the comparable earlier job: 10).

## Known limits (stated in the skills as NOT WORKING / not verified)
Synchronous Edit Cross Section (batch), linear sketch pattern, Trim Curve with bounding OBJECTS,
Emboss, Delete Body keep mode, symbolic Thread as a pattern seed, Mirror Assembly, Fit Curve on
non-point targets, Replace Feature with a hand-made parent map, parts-list attribute columns and
thread callouts in drawings. Each skill's status table lists what is VERIFIED, PARTIAL and NOT
WORKING with the exact error text.

Taken OFF this list on 2026-10-06 (measured on NX 2206 while working the NX CAST findings):
- synchronous Linear / Radial / Angular Dimension: they commit once `GetDimension()` is called
  before the commit (`nxf.linear_dimension` ...; `nx-synchronous-modeling`);
- Face Finder from a journal: flag + `Recognize<Name>(True)` (`nxf.find_related`);
- Draft, type Parting Edge (`nxf.draft_parting_edges`; `nx-solid-features`);
- Trim Curve with a bounding PLANE (associative through a smart plane) works; with bounding
  objects it still fails, and a region point that is not on the curve trims nothing without an
  error (`nx-curves-and-sketches`).

## Working data (outside this folder)
`C:\NX_MCP_WORKSPACE\skill_census` (census, dumps, statistics), `...\nx_course` (transcripts,
contact sheets, notes), `...\skill_probe` (probe journals), `...\skill_accept*` (acceptance builds),
`...\skill_regress_installed` (last full regression, run from the installed copy: 37 of 37 PASS; drafting 2 of 2 in `...\skill_regress_final3`).
