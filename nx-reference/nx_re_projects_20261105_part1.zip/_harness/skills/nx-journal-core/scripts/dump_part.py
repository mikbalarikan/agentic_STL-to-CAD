"""Read-only deep dump of parametric NX parts: ordered feature tree, feature
expressions with descriptors, sketches, and a reflective read-back of each
feature's edit builder. Never saves.
usage: run_journal.ps1 -Script dump_part.py -JArgs <list.txt>,<out_dir>
list.txt holds one absolute .prt path per line; output is <out_dir>/<md5-of-path>.json.
Progress is tracked in <out_dir>/progress.jsonl so a restart resumes; a part
that crashed NX once is retried without builder read-back, twice -> skipped.
"""
import hashlib
import json
import os
import sys
import time
import traceback

import NXOpen
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.UF

S = NXOpen.Session.GetSession()
UFS = NXOpen.UF.UFSession.GetUFSession()

SKIP_BUILDER = {"SketchFeature", "DatumCsys", "Brep", "DatumPlaneFeature", "DatumAxisFeature", "PointFeature",
                "MeasureMaster", "Feature", "BodyFeature"}
ALIAS = {"EdgeBlend": ["CreateEdgeBlendBuilder"], "AOCS": ["CreateOffsetCurveInFaceBuilder", "CreateAocsBuilder"],
         "BooleanFeature": ["CreateBooleanBuilderUsingCollector", "CreateBooleanBuilder"],
         "Divideface": ["CreateDividefaceBuilder"], "TrimBody2": ["CreateTrimBody2Builder"],
         "Mirror": ["CreateMirrorBuilder"], "AdmMoveFace": ["CreateAdmMoveFaceBuilder"],
         "AdmOffsetRegion": ["CreateAdmOffsetRegionBuilder"], "ApexRangeChamfer": ["CreateChamferBuilder"],
         "Chamfer": ["CreateChamferBuilder"], "Thread": ["CreateThreadBuilder"],
         "PatternFeature": ["CreatePatternFeatureBuilder"], "PatternGeometry": ["CreatePatternGeometryBuilder"],
         "CompositeCurve": ["CreateCompositeCurveBuilder"], "ExtractFace": ["CreateExtractFaceBuilder"],
         "Geomcopy": ["CreateGeomcopyBuilder"], "ProjectCurve": ["CreateProjectCurveBuilder"],
         "MoveObject": [], "InstanceFeature": [], "Tube": ["CreateTubeBuilder"]}
SKIP_ATTR = {"Tag", "IsOccurrence", "Prototype", "OwningPart", "OwningComponent", "JournalIdentifier", "Null",
             "ParentFeatureInternal", "PatchSolutionFlag", "PatchSurfaceFilename", "SurroundingPatchSurfaceFilename",
             "PreviewBuilder"}
MAX_PER_CLASS = 8
MAX_DEPTH = 3
MAX_LIST = 12
_ENUM_MAP = {}


def r6(v):
    return round(float(v), 6)


def _scan_enum(c, depth):
    for an in dir(c):
        if an.startswith("_"):
            continue
        try:
            a = getattr(c, an)
        except Exception:  # noqa: BLE001
            continue
        if isinstance(a, type):
            if depth < 2:
                _scan_enum(a, depth + 1)
        elif type(a).__name__.endswith("MemberType"):
            try:
                _ENUM_MAP.setdefault(type(a).__name__, {})[a.value] = an
            except Exception:  # noqa: BLE001
                pass


def build_enum_map():
    for mod in (NXOpen, NXOpen.Features, NXOpen.GeometricUtilities):
        for cn in dir(mod):
            if cn.startswith("_"):
                continue
            try:
                c = getattr(mod, cn)
            except Exception:  # noqa: BLE001
                continue
            if isinstance(c, type):
                _scan_enum(c, 0)


def is_enum(v):
    return type(v).__name__.endswith("MemberType")


def enum_name(v):
    """NXOpen enum value -> 'Member' (falls back to the int)."""
    try:
        return _ENUM_MAP.get(type(v).__name__, {}).get(v.value, str(v.value))
    except Exception:  # noqa: BLE001
        return str(v)


def build_factory_index(part):
    idx = {}
    owners = [("", part.Features)]
    for n in dir(part.Features):
        if n.startswith("_"):
            continue
        try:
            a = getattr(part.Features, n)
        except Exception:  # noqa: BLE001
            continue
        if not callable(a) and type(a).__module__.startswith("NXOpen") and (n.endswith("Collection") or n.endswith("Manager")):
            owners.append((n, a))
    for oname, o in owners:
        for n in dir(o):
            if n.startswith("Create") and n.endswith("Builder"):
                idx.setdefault(n.lower(), (oname, o, n))
    return idx


def find_factories(idx, cls):
    names = list(ALIAS.get(cls, []))
    names.append("Create" + cls + "Builder")
    if cls.startswith("Adm"):
        names.append("Create" + cls[3:] + "Builder")
    out = []
    for n in names:
        hit = idx.get(n.lower())
        if hit and hit not in out:
            out.append(hit)
    return out


def tagged(v):
    d = {"_t": type(v).__name__}
    try:
        d["jid"] = v.JournalIdentifier
    except Exception:  # noqa: BLE001
        pass
    return d


def geom_hist(objs):
    ft = {}
    for o in objs[:200]:
        try:
            if isinstance(o, NXOpen.Face):
                k = enum_name(o.SolidFaceType)
            elif isinstance(o, NXOpen.Edge):
                k = enum_name(o.SolidEdgeType)
            else:
                continue
            ft[k] = ft.get(k, 0) + 1
        except Exception:  # noqa: BLE001
            pass
    return ft


def rules_of(obj):
    out = []
    try:
        res = obj.GetRules()
        rules = res[0] if isinstance(res, tuple) else res
        for r in rules:
            try:
                out.append(enum_name(r.Type))
            except Exception:  # noqa: BLE001
                out.append(type(r).__name__)
    except Exception:  # noqa: BLE001
        pass
    return out


def val(v, depth):
    if v is None or isinstance(v, (bool, int, str)):
        return v
    if isinstance(v, float):
        return r6(v)
    tn = type(v).__name__
    if is_enum(v):
        return enum_name(v)
    if isinstance(v, (list, tuple)):
        return [val(x, depth + 1) for x in list(v)[:MAX_LIST]]
    if tn in ("Point3d", "Vector3d"):
        return [r6(v.X), r6(v.Y), r6(v.Z)]
    if tn == "Matrix3x3":
        return [r6(getattr(v, a)) for a in ("Xx", "Xy", "Xz", "Yx", "Yy", "Yz", "Zx", "Zy", "Zz")]
    if isinstance(v, NXOpen.Expression):
        d = {"_t": "Expression"}
        try:
            d["name"], d["rhs"] = v.Name, v.RightHandSide
            d["value"] = r6(v.Value)
            d["units"] = v.Units.Name if v.Units else None
        except Exception:  # noqa: BLE001
            pass
        return d
    if tn == "Section":
        d = {"_t": "Section"}
        try:
            data = v.GetSectionData()
            d["n_data"] = len(data)
            d["rules"] = [rules_of(sd) for sd in data[:MAX_LIST]]
        except Exception as e:  # noqa: BLE001
            d["err"] = str(e)[:80]
        try:
            res = v.GetOutputCurves()
            d["n_curves"] = len(res)
            d["curve_types"] = sorted({type(c).__name__ for c in res})
        except Exception:  # noqa: BLE001
            pass
        return d
    if tn == "ScCollector":
        d = {"_t": "ScCollector", "rules": rules_of(v)}
        try:
            objs = v.GetObjects()
            d["n"] = len(objs)
            d["types"] = sorted({type(o).__name__ for o in objs})
            g = geom_hist(objs)
            if g:
                d["geom"] = g
        except Exception:  # noqa: BLE001
            pass
        return d
    if tn == "Direction":
        try:
            return {"_t": tn, "vec": val(v.Vector, depth), "origin": val(v.Origin, depth)}
        except Exception:  # noqa: BLE001
            return {"_t": tn}
    if tn == "Point":
        try:
            return {"_t": tn, "xyz": val(v.Coordinates, depth)}
        except Exception:  # noqa: BLE001
            return {"_t": tn}
    if tn == "Axis":
        try:
            return {"_t": tn, "vec": val(v.DirectionVector, depth), "origin": val(v.Point.Coordinates, depth)}
        except Exception:  # noqa: BLE001
            return {"_t": tn}
    if tn == "Plane":
        try:
            return {"_t": tn, "normal": val(v.Normal, depth), "origin": val(v.Origin, depth)}
        except Exception:  # noqa: BLE001
            return {"_t": tn}
    if tn.startswith("Select") and hasattr(v, "Value"):
        try:
            x = v.Value
            return {"_t": tn, "value": tagged(x) if x is not None else None}
        except Exception:  # noqa: BLE001
            return {"_t": tn}
    if tn.startswith("Select") and hasattr(v, "GetArray"):
        try:
            arr = v.GetArray()
            d = {"_t": tn, "n": len(arr), "types": sorted({type(o).__name__ for o in arr})}
            g = geom_hist(list(arr))
            if g:
                d["geom"] = g
            return d
        except Exception:  # noqa: BLE001
            return {"_t": tn}
    if isinstance(v, NXOpen.NXObject) and not tn.endswith("Builder"):
        return tagged(v)
    mod = type(v).__module__ or ""
    if not mod.startswith("NXOpen"):
        return str(v)[:80]
    if hasattr(v, "Length") and hasattr(v, "GetContents"):
        try:
            items = v.GetContents()
            return {"_t": tn, "n": len(items), "items": [val(x, depth + 1) for x in items[:MAX_LIST]]}
        except Exception as e:  # noqa: BLE001
            return {"_t": tn, "err": str(e)[:80]}
    if depth >= MAX_DEPTH:
        return {"_t": tn}
    return reflect(v, depth + 1)


def reflect(obj, depth):
    d = {"_t": type(obj).__name__}
    for n in dir(obj):
        if n.startswith("_") or n in SKIP_ATTR:
            continue
        try:
            a = getattr(obj, n)
        except Exception as e:  # noqa: BLE001
            s = str(e)
            if "not" not in s.lower():
                d[n] = "ERR " + s[:60]
            continue
        if callable(a):
            continue
        try:
            d[n] = val(a, depth)
        except Exception as e:  # noqa: BLE001
            d[n] = "ERR " + str(e)[:60]
    return d


def builder_dump(idx, f, cls):
    for oname, owner, name in find_factories(idx, cls):
        b = None
        try:
            b = getattr(owner, name)(f)
        except Exception:  # noqa: BLE001
            continue
        try:
            d = reflect(b, 0)
            d["_factory"] = (oname + "." if oname else "") + name
            return d
        except Exception as e:  # noqa: BLE001
            return {"_factory": name, "err": str(e)[:120]}
        finally:
            try:
                b.Destroy()
            except Exception:  # noqa: BLE001
                pass
    return None


def feature_rows(part, idx, with_builders, mark):
    rows = []
    per_class = {}
    for f in part.Features.GetFeatures():
        cls = type(f).__name__
        row = {"ts": f.Timestamp, "type": f.FeatureType, "cls": cls}
        try:
            # internal = pattern / mirror instance, hole child row (SIMPLE HOLE, CBORE_HOLE, CSUNK_HOLE,
            # SYMBOLIC_THREAD), linked-curve object, sketch CSYS: filter on it before counting features
            row["internal"] = bool(f.IsInternal)
        except Exception:  # noqa: BLE001
            pass
        try:
            row["fname"] = f.GetFeatureName()
            row["name"] = f.Name
            row["suppressed"] = f.Suppressed
        except Exception:  # noqa: BLE001
            pass
        try:
            row["parents"] = [p.GetFeatureName() for p in f.GetParents()]
        except Exception:  # noqa: BLE001
            pass
        try:
            row["n_children"] = len(f.GetChildren())
        except Exception:  # noqa: BLE001
            pass
        try:
            ex = []
            for e in f.GetExpressions():
                try:
                    desc = e.GetDescriptor()
                except Exception:  # noqa: BLE001
                    desc = ""
                ex.append({"n": e.Name, "rhs": e.RightHandSide, "desc": desc})
            row["exprs"] = ex[:30]
        except Exception:  # noqa: BLE001
            pass
        try:
            errs = list(f.GetFeatureErrorMessages() or [])
            if errs:
                row["errors"] = [x[:160] for x in errs[:3]]
        except Exception:  # noqa: BLE001
            pass
        try:
            row["n_bodies"] = len(f.GetBodies())
            row["n_faces"] = len(f.GetFaces())
        except Exception:  # noqa: BLE001
            pass
        if with_builders and cls not in SKIP_BUILDER and not row.get("suppressed"):
            k = per_class.get(cls, 0)
            if k < MAX_PER_CLASS:
                per_class[cls] = k + 1
                mark(f"B {row.get('fname')}")
                try:
                    bd = builder_dump(idx, f, cls)
                    if bd is not None:
                        row["builder"] = bd
                except Exception as e:  # noqa: BLE001
                    row["builder_err"] = str(e)[:120]
        rows.append(row)
    return rows


def sketch_rows(part):
    out = []
    for sk in part.Sketches:
        d = {"name": sk.Name}
        try:
            st, dof = sk.GetStatus()
            d["status"], d["dof"] = enum_name(st) if is_enum(st) else str(st), dof
        except Exception:  # noqa: BLE001
            pass
        try:
            geo = sk.GetAllGeometry()
            types = {}
            for g in geo:
                types[type(g).__name__] = types.get(type(g).__name__, 0) + 1
            d["geom"] = types
        except Exception:  # noqa: BLE001
            pass
        try:
            dims, n_auto = [], 0
            for c in sk.GetAllConstraintsOfType(NXOpen.Sketch.ConstraintClass.Dimension, NXOpen.Sketch.ConstraintType.NoCon):
                try:
                    ds = getattr(c, "DimensionState", None)
                    if ds is not None and ds == type(c).DimensionStateType.Automatic:
                        n_auto += 1
                except Exception:  # noqa: BLE001
                    pass
                try:
                    e = c.AssociatedExpression
                    dims.append(f"{e.Name}={e.RightHandSide}")
                except Exception:  # noqa: BLE001
                    pass
            d["dims"] = dims[:40]
            # automatic dimensions close open DOF without constraining anything: real DOF = dof + auto_dims
            d["auto_dims"] = n_auto
            if "dof" in d:
                d["real_dof"] = d["dof"] + n_auto
            cons = {}
            for c in sk.GetAllConstraintsOfType(NXOpen.Sketch.ConstraintClass.Geometric, NXOpen.Sketch.ConstraintType.NoCon):
                k = enum_name(c.ConstraintType)
                cons[k] = cons.get(k, 0) + 1
            d["constraints"] = cons
        except Exception:  # noqa: BLE001
            pass
        try:
            d["feature"] = sk.Feature.GetFeatureName() if sk.Feature else None
        except Exception:  # noqa: BLE001
            pass
        out.append(d)
    return out


def body_rows(part):
    out = []
    for b in part.Bodies:
        d = {"solid": b.IsSolidBody, "layer": b.Layer, "name": b.Name}
        try:
            d["bbox"] = [round(v, 3) for v in UFS.ModlGeneral.AskBoundingBox(b.Tag)]
        except Exception:  # noqa: BLE001
            pass
        try:
            ft = {}
            faces = b.GetFaces()
            for fc in faces:
                k = enum_name(fc.SolidFaceType)
                ft[k] = ft.get(k, 0) + 1
            d["n_faces"], d["face_types"] = len(faces), ft
        except Exception:  # noqa: BLE001
            pass
        out.append(d)
    return out[:60]


def dump(path, out_dir, with_builders, mark):
    part, st = S.Parts.OpenBaseDisplay(path)
    st.Dispose()
    idx = build_factory_index(part)
    rep = {"path": path, "units": enum_name(part.PartUnits)}
    rep["features"] = feature_rows(part, idx, with_builders, mark)
    mark("sketches")
    rep["sketches"] = sketch_rows(part)
    rep["bodies"] = body_rows(part)
    ex = []
    for e in part.Expressions:
        try:
            ex.append({"n": e.Name, "rhs": e.RightHandSide, "type": e.Type, "units": e.Units.Name if e.Units else None})
        except Exception:  # noqa: BLE001
            pass
    rep["expressions"] = ex[:400]
    try:
        root = part.ComponentAssembly.RootComponent
        rep["children"] = [c.DisplayName for c in root.GetChildren()][:60] if root else []
    except Exception:  # noqa: BLE001
        pass
    return rep


def main(argv):
    lst, out_dir = argv[0], argv[1]
    os.makedirs(out_dir, exist_ok=True)
    prog = os.path.join(out_dir, "progress.jsonl")
    with open(lst, "r", encoding="utf-8-sig") as fh:
        paths = [p.strip() for p in fh if p.strip()]
    starts, done = {}, set()
    if os.path.exists(prog):
        with open(prog, encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except Exception:  # noqa: BLE001
                    continue
                if r["status"] == "START":
                    starts[r["path"]] = starts.get(r["path"], 0) + 1
                elif r["status"] in ("DONE", "ERR"):
                    done.add(r["path"])
    lo = S.Parts.LoadOptions
    try:
        lo.ComponentsToLoad = getattr(NXOpen.LoadOptions.LoadComponents, "None")
        lo.UsePartialLoading = True
    except Exception:  # noqa: BLE001
        pass
    build_enum_map()
    pf = open(prog, "a", encoding="utf-8")

    def put(row):
        pf.write(json.dumps(row) + "\n")
        pf.flush()
        os.fsync(pf.fileno())

    for p in paths:
        if p in done:
            continue
        n = starts.get(p, 0)
        if n >= 2:
            put({"path": p, "status": "ERR", "error": "crashed twice"})
            continue
        put({"path": p, "status": "START"})
        t0 = time.time()
        key = hashlib.md5(p.encode("utf-8")).hexdigest()[:12]

        def mark(what, _p=p):
            pf.write(json.dumps({"path": _p, "status": "AT", "at": what}) + "\n")
            pf.flush()

        try:
            rep = dump(p, out_dir, n == 0, mark)
            rep["sec"] = round(time.time() - t0, 1)
            rep["with_builders"] = n == 0
            json.dump(rep, open(os.path.join(out_dir, key + ".json"), "w", encoding="utf-8"))
            put({"path": p, "status": "DONE", "key": key, "sec": rep["sec"]})
        except Exception as e:  # noqa: BLE001
            put({"path": p, "status": "ERR", "error": str(e)[:200], "tb": traceback.format_exc()[-500:]})
        try:
            S.Parts.CloseAll(NXOpen.BasePart.CloseModified.CloseModified, None)
        except Exception:  # noqa: BLE001
            pass
    put({"path": "__END__", "status": "END"})
    pf.close()


if __name__ == "__main__":
    main(sys.argv[1:])
