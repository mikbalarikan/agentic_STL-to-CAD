"""nxa - NX assembly helpers for headless NXOpen journals (NX 2206, run_journal).

    import os, sys
    sys.path.insert(0, os.environ["NXH_DIR"])
    import nxh, nxf, nxa

Ported from the verified journals of the nx-assemblies skill (constraints_basics.py, topdown_wave.py,
clearance_check.py) and from acceptance build 3 (acc3_lib.py); every function is exercised by
scripts/nxa_selftest.py with a measured check. Read nx-assemblies/SKILL.md for WHICH constraint to use.

Rules encoded here:
  * constraint references are OCCURRENCES (comp.FindOccurrence(prototype object)); the helpers take
    (component, prototype-or-occurrence geometry) pairs and convert;
  * fix the ground first; with both parts free the solver moves the SECOND reference's component unless
    fix_hint is set; Distance / Angle are 0 without an expression;
  * "Solved" is asserted by constrain(), but Solved is not "correct": assert frame(comp) / axis_of(comp) / dof(comp);
  * WAVE links and interpart expressions only follow while the parts are FULLY loaded (load_fully after a reopen).
"""
import math
import os

import NXOpen
import NXOpen.Assemblies
import NXOpen.Features
import NXOpen.Positioning
import nxh
import nxf

S, UPD = nxh.S, nxh.UPD
PZ = NXOpen.Positioning
T = PZ.Constraint.Type                # T.Fix / Touch / Concentric / AlignLock / Distance / Angle / Parallel / Perpendicular / Center22
AL = PZ.Constraint.Alignment          # AL.CoAlign / ContraAlign / InferAlign
NA = NXOpen.Assemblies
IDENT = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]
ASSEMBLY_TEMPLATE = "assembly-mm-template.prt"


# ====================================================================== frames
# verified in nx-assemblies/scripts/constraints_basics.py
def rot(axis, deg):
    """3x3 rotation (rows) about 'x' / 'y' / 'z': columns = the rotated axes. Use as r in add_component."""
    c, s = math.cos(math.radians(deg)), math.sin(math.radians(deg))
    if axis == "x":
        return [[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]]
    if axis == "y":
        return [[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]]
    return [[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]]


def to_nx(r):
    """NXOpen.Matrix3x3 for a component: NX rows = component X/Y/Z axes in assembly coordinates = columns of r."""
    m = NXOpen.Matrix3x3()
    m.Xx, m.Xy, m.Xz = r[0][0], r[1][0], r[2][0]
    m.Yx, m.Yy, m.Yz = r[0][1], r[1][1], r[2][1]
    m.Zx, m.Zy, m.Zz = r[0][2], r[1][2], r[2][2]
    return m


def frame(comp):
    """(origin, R) of a component, R columns = component axes in assembly coordinates: p_assy = origin + R * p_part."""
    p, m = comp.GetPosition()
    return [p.X, p.Y, p.Z], [[m.Xx, m.Yx, m.Zx], [m.Xy, m.Yy, m.Zy], [m.Xz, m.Yz, m.Zz]]


def to_assy(comp, xyz):
    """Part coordinates of a component -> assembly coordinates."""
    o, r = frame(comp)
    return [o[i] + sum(r[i][k] * xyz[k] for k in range(3)) for i in range(3)]


def axis_of(comp, k=2):
    """Component axis k (0 X, 1 Y, 2 Z) in assembly coordinates - assert it after every constraint."""
    _o, r = frame(comp)
    return [r[i][k] for i in range(3)]


def enum_name(cls, value):
    """Name of an NXOpen enum value (str() of these enums gives a number)."""
    for n in nxh.enum_names(cls):
        try:
            if getattr(cls, n) == value:
                return n
        except Exception:  # noqa: BLE001
            pass
    return str(value)


# ====================================================================== components
def new_assembly(path):
    """New assembly part from assembly-mm-template.prt (no Datum CSYS); it becomes the work + display part.
    Save it once (nxh.save) before interpart expressions refer to it."""
    return nxh.new_part(path, ASSEMBLY_TEMPLATE)


# verified in nx-assemblies/scripts/constraints_basics.py (add)
def add_component(assy, path, name, origin=(0, 0, 0), r=None, refset="MODEL"):
    """Add a saved part file as a component at origin with orientation r (rot(...) or a 3x3 list, default
    identity). Place it NEAR its final position and roughly oriented: the solver takes the nearest solution.
    A body that is not in the reference set is invisible in the assembly. Returns the Component
    (comp.Prototype is its Part)."""
    comp, st = assy.ComponentAssembly.AddComponent(path, refset, name, nxh.P(*origin), to_nx(r or IDENT), -1)
    st.Dispose()
    return comp


def components(assy):
    """{name: Component} of the top-level components (use after reopening an assembly)."""
    root = assy.ComponentAssembly.RootComponent
    return {c.Name: c for c in root.GetChildren()} if root is not None else {}


# verified in nx-assemblies/scripts/constraints_basics.py (occ)
def occ(comp, obj):
    """Occurrence of a prototype body / face / edge / datum in the component - what constraints, WAVE links
    and nxh.min_dist need. None means the object is not in the component's reference set: raises."""
    o = comp.FindOccurrence(obj)
    if o is None:
        raise RuntimeError("%s: no occurrence of %s (not in the reference set?)" % (comp.Name, obj))
    return o


# verified in nx-assemblies/scripts/constraints_basics.py (circ_edge)
def circ_edge(body, centre, radius, tol=1e-3):
    """The ONE full circular edge of a prototype body with this centre and radius (part coordinates,
    bounding-box test). Raises unless exactly one matches - 'Solved' on the wrong edge is the classic error.
    FULL circles only: for the half arc at the end of a slot use arc_edge()."""
    hits = []
    for e in body.GetEdges():
        if e.SolidEdgeType != NXOpen.Edge.EdgeType.Circular:
            continue
        bb = nxh.bbox(e)
        c = [(bb[i] + bb[i + 3]) / 2 for i in range(3)]
        r = max(bb[i + 3] - bb[i] for i in range(3)) / 2
        if abs(r - radius) < tol and all(abs(c[i] - centre[i]) < tol for i in range(3)):
            hits.append(e)
    if len(hits) != 1:
        raise RuntimeError("%d circular edges at %s r %s" % (len(hits), centre, radius))
    return hits[0]


def _curve_props(tag, t):
    """UF_MODL_ask_curve_props (point, tangent, principal normal, binormal, torsion, radius of curvature)."""
    for m in dir(nxh.UFS):
        mod = getattr(nxh.UFS, m, None)
        if not m.startswith("_") and hasattr(mod, "AskCurveProps"):
            return mod.AskCurveProps(tag, t)
    raise RuntimeError("no AskCurveProps in NXOpen.UF")


# verified in nxa_selftest (Concentric on the half-arc edge of a slot)
def arc_edge(body, centre, radius, tol=1e-3, near=None):
    """A circular edge - FULL circle or PARTIAL arc (the end of a slot, a blend edge) - of a prototype body by
    its true centre and radius (UF curve evaluation, part coordinates). circ_edge() only sees full circles.
    Several edges can share centre and radius (a circle split in two halves): near=(x, y, z) picks the one
    whose mid point is closest; otherwise exactly one must match.
    Concentric accepts a partial arc edge: measured, a pin made Concentric to a slot's half-arc edge solved
    onto the arc's centre and plane."""
    hits = []
    for e in body.GetEdges():
        if e.SolidEdgeType != NXOpen.Edge.EdgeType.Circular:
            continue
        r_ = _curve_props(e.Tag, 0.5)
        pt, pn, rad = list(r_[0]), list(r_[2]), r_[5]
        c = [pt[i] + pn[i] * rad for i in range(3)]
        if abs(rad - radius) < tol and all(abs(c[i] - centre[i]) < tol for i in range(3)):
            hits.append((e, pt))
    if near is not None and hits:
        hits.sort(key=lambda h: sum((h[1][i] - near[i]) ** 2 for i in range(3)))
        return hits[0][0]
    if len(hits) != 1:
        raise RuntimeError("%d arc edges at %s r %s" % (len(hits), centre, radius))
    return hits[0][0]


# verified in nx-assemblies/scripts/constraints_basics.py (MoveComponent), topdown_wave.py
def move_component(assy, comp, translation):
    """Translate a component (ComponentAssembly.MoveComponent) and update. Fix is NOT a lock: this moves a
    fixed component too - never move the ground. Linked geometry in other parts follows after the update."""
    assy.ComponentAssembly.MoveComponent(comp, NXOpen.Vector3d(*[float(x) for x in translation]), to_nx(IDENT))
    return nxh.update()


# ====================================================================== constraints
# verified in nx-assemblies/scripts/constraints_basics.py (Session)
class Session:
    """One Assembly Constraints dialog session (= one Apply); move=True is a Move Component session."""

    def __init__(self, assy, move=False):
        self.assy, self.move = assy, move

    def __enter__(self):
        ca = self.assy.ComponentAssembly
        self.pos = ca.Positioner
        self.pos.ClearNetwork()
        self.pos.PrimaryArrangement = ca.ActiveArrangement
        if self.move:
            self.pos.BeginMoveComponent()
        else:
            self.pos.BeginAssemblyConstraints()
        self.net = self.pos.EstablishNetwork()
        self.net.MoveObjectsState = True
        self.net.NetworkArrangementsMode = PZ.ComponentNetwork.ArrangementsMode.Existing
        if not self.move:
            self.net.DisplayComponent = NXOpen.Assemblies.Component.Null
        return self

    def __exit__(self, *exc):
        self.pos.ClearNetwork()
        S.UpdateManager.AddToDeleteList(self.net)
        S.UpdateManager.DoUpdate(nxh.mark("positioner", False))
        if self.move:
            self.pos.EndMoveComponent()
        else:
            self.pos.EndAssemblyConstraints()
        return False


def status_name(c):
    """Solver status of a constraint as text ('Solved', ...)."""
    return enum_name(PZ.Constraint.SolverStatus, c.GetConstraintStatus())


def _ref(comp, geom):
    if geom is comp:
        return geom
    try:
        if geom.IsOccurrence:
            return geom
    except Exception:  # noqa: BLE001
        pass
    return occ(comp, geom)


# verified in nx-assemblies/scripts/constraints_basics.py (constrain)
def constrain(assy, ctype, refs, align=None, expr=None, name=None, fix_hint=None, check=True):
    """Create and solve ONE constraint (one Solve per constraint). Returns the constraint.

    refs: [(component, geometry, uses_axis)] - geometry is a prototype object or its occurrence (or the
    component itself for Fix); uses_axis=True uses the axis of a cylindrical face. The first reference is the
    part meant to move; with both parts free NX moves the SECOND one unless fix_hint=1 (index of the reference
    that must stay). expr: value for Distance / Angle as text (number, formula or expression name of the
    ASSEMBLY); without it the value is 0. check=True raises unless the status is 'Solved' - still assert the
    component's frame afterwards (Solved on the wrong face is possible)."""
    with Session(assy) as s:
        c = s.pos.CreateConstraint(True)
        c.ConstraintType = ctype
        if align is not None:
            c.ConstraintAlignment = align
        made = [c.CreateConstraintReference(comp, _ref(comp, geom), uses_axis, False, False) for comp, geom, uses_axis in refs]
        if fix_hint is not None:
            made[fix_hint].SetFixHint(True)
        if expr is not None:
            c.SetExpression(str(expr))
        s.net.AddConstraint(c)
        if name:
            c.SetName(name)
        s.net.Solve()
    if check and status_name(c) != "Solved":
        raise RuntimeError("constraint %s not solved: %s" % (name or enum_name(T, ctype), status_name(c)))
    return c


def fix(assy, comp, name=None):
    """Fix (ground) a component - do this first for the part that is stationary in reality. DOF 0/0."""
    return constrain(assy, T.Fix, [(comp, comp, False)], name=name)


def touch(assy, moving, target, name=None, fix_hint=None):
    """Touch two planar faces (face on face, normals opposed). moving / target = (component, face). Leaves 1 rot + 2 trans."""
    return constrain(assy, T.Touch, [moving + (False,), target + (False,)], name=name, fix_hint=fix_hint)


def align(assy, moving, target, name=None, fix_hint=None):
    """Align two planar faces flush (normals the same way) = Touch + CoAlign. Leaves 1 rot + 2 trans."""
    return constrain(assy, T.Touch, [moving + (False,), target + (False,)], align=AL.CoAlign, name=name, fix_hint=fix_hint)


def concentric(assy, moving, target, name=None, fix_hint=None):
    """Concentric on two CIRCULAR EDGES: coaxial AND coplanar, so the edge picked sets the axial seat
    (pin shoulder edge on hole rim edge). Leaves 1 rot. If the part lands end for end: flip(assy, c)."""
    return constrain(assy, T.Concentric, [moving + (False,), target + (False,)], name=name, fix_hint=fix_hint)


def center_axis(assy, moving, target, name=None, fix_hint=None):
    """Touch Align > Infer Centre/Axis on two cylindrical faces: coaxial, free to slide and spin (1 rot + 1 trans)."""
    return constrain(assy, T.Touch, [moving + (True,), target + (True,)], name=name, fix_hint=fix_hint)


def align_lock(assy, moving, target, name=None, fix_hint=None):
    """Align/Lock. Two cylindrical FACES -> axes aligned, no spin (0 rot + 1 trans); two circular EDGES ->
    rigid (0 / 0), the constraint for a pin, spacer or fastener."""
    ax = isinstance(moving[1], NXOpen.Face)
    return constrain(assy, T.AlignLock, [moving + (ax,), target + (ax,)], name=name, fix_hint=fix_hint)


def distance(assy, moving, target, expr, name=None, fix_hint=None):
    """Distance between two faces, driven by expr (text: number, formula or assembly expression name).
    Unsigned: the part stays on the side where it was when the constraint was made."""
    return constrain(assy, T.Distance, [moving + (False,), target + (False,)], expr=expr, name=name, fix_hint=fix_hint)


def angle(assy, moving, target, expr, name=None, fix_hint=None):
    """Angle between two planar faces, driven by expr (degrees, unsigned 0..180; the branch is the one nearest
    to the pose at creation). Needs a pivot (e.g. Concentric) to be meaningful."""
    return constrain(assy, T.Angle, [moving + (False,), target + (False,)], expr=expr, name=name, fix_hint=fix_hint)


def parallel(assy, moving, target, name=None, fix_hint=None):
    """Parallel planar faces (squares a part up; 1 rot + 3 trans left)."""
    return constrain(assy, T.Parallel, [moving + (False,), target + (False,)], name=name, fix_hint=fix_hint)


def perpendicular(assy, moving, target, name=None, fix_hint=None):
    """Perpendicular planar faces (2 rot + 3 trans left)."""
    return constrain(assy, T.Perpendicular, [moving + (False,), target + (False,)], name=name, fix_hint=fix_hint)


def center22(assy, part_a, part_b, slot_a, slot_b, name=None):
    """Center 2 to 2: the mid-plane of the part's two faces on the mid-plane of the slot's two faces (wheel in
    fork, clip in groove). Order: the PART's two (component, face) pairs first, then the slot's. Add
    center_axis afterwards; do not remove the axial freedom twice."""
    return constrain(assy, T.Center22, [part_a + (False,), part_b + (False,), slot_a + (False,), slot_b + (False,)], name=name)


# verified in nx-assemblies/scripts/constraints_basics.py (FlipAlignment)
def flip(assy, c):
    """Reverse Last Constraint: FlipAlignment + Solve (a concentric pin turns end for end)."""
    with Session(assy) as s:
        c.FlipAlignment()
        s.net.Solve()
    return c


# verified in nx-assemblies/scripts/constraints_basics.py (dof)
def dof(comp):
    """[rotational, translational] degrees of freedom left (Show Degrees of Freedom). A limited DOF counts as free."""
    d = comp.GetDegreesOfFreedom()
    return [d.NumRotational, d.NumTranslational]


# verified in nx-assemblies/scripts/constraints_basics.py (drag, spin_about)
def drag(assy, comp, translation=(0.0, 0.0, 0.0), spin=None):
    """Move Component drag on a (constrained) component - the freedom test. A blocked direction simply does
    not move (no exception). spin=(point_on_axis, 'x'|'y'|'z', degrees) turns about a line instead of
    translating. Returns (distance moved, angle turned in degrees)."""
    f0 = frame(comp)
    rotation = None
    if spin is not None:
        pt, ax, deg = spin
        r = rot(ax, deg)
        rc = [sum(r[i][k] * pt[k] for k in range(3)) for i in range(3)]
        translation = [pt[i] - rc[i] for i in range(3)]
        rotation = rot(ax, -deg)            # DragByTransform rotates about the origin and reads the matrix transposed
    with Session(assy, move=True) as s:
        s.net.SetMovingGroup([comp])
        s.net.BeginDrag()
        v = NXOpen.Vector3d(*[float(x) for x in translation])
        if rotation is None:
            s.net.DragByTranslation(v)
        else:
            s.net.DragByTransform(v, to_nx(rotation))
        s.net.EndDrag()
        s.net.ResetDisplay()
        s.net.ApplyToModel()
        s.net.Solve()
    f1 = frame(comp)
    dp = math.sqrt(sum((a - b) ** 2 for a, b in zip(f0[0], f1[0])))
    tr = sum(sum(f0[1][i][k] * f1[1][i][k] for i in range(3)) for k in range(3))
    return dp, math.degrees(math.acos(max(-1.0, min(1.0, (tr - 1.0) / 2.0))))


# ====================================================================== top-down: in-context parts, links
# verified in nx-assemblies/scripts/topdown_wave.py (new_component)
def new_component(assy, path, name):
    """Assemblies > New Component: an empty model part created as a child of the assembly at the absolute
    origin (reference set MODEL). Returns the Component; make it the work part with set_work(comp).
    NX creates the component under the WORK part: when a component is still the work part (after
    set_work(comp)) the new one would become ITS child and not be found under `assy`. So the helper makes
    `assy` the work part first (it stays the work part afterwards). A sub-assembly as parent: pass that part
    as `assy` while it is the displayed part."""
    if os.path.exists(path):
        os.remove(path)
    if S.Parts.Work is None or S.Parts.Work.Tag != assy.Tag:
        if S.Parts.Display is not None and S.Parts.Display.Tag == assy.Tag:
            set_work(None)                             # the displayed assembly becomes the work part again
    fn = S.Parts.FileNew()
    fn.TemplateFileName = nxh.TEMPLATE
    fn.UseBlankTemplate = False
    fn.ApplicationName = "ModelTemplate"
    fn.Units = NXOpen.Part.Units.Millimeters
    fn.TemplateType = NXOpen.FileNewTemplateType.Item
    fn.TemplatePresentationName = "Model"
    fn.NewFileName = path
    fn.MasterFileName = ""
    fn.MakeDisplayedPart = False
    fn.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    b = assy.AssemblyManager.CreateNewComponentBuilder()
    try:
        b.ReferenceSet = NXOpen.Assemblies.CreateNewComponentBuilder.ComponentReferenceSetType.Model
        b.NewComponentName = name
        b.ReferenceSetName = "MODEL"
        b.NewFile = fn
        b.Commit()
    finally:
        b.Destroy()
    leaf = os.path.splitext(os.path.basename(path))[0].lower()
    for c in assy.ComponentAssembly.RootComponent.GetChildren():
        if c.DisplayName.lower() == leaf or c.Name == name:
            return c
    raise RuntimeError("new component not found")


# verified in nx-assemblies/scripts/topdown_wave.py (set_work)
def set_work(comp):
    """Make Work Part: features are created in the component's part while the assembly stays displayed
    (so neighbours can be linked). set_work(None) returns to the assembly. Returns the work Part."""
    if comp is None:
        comp = NXOpen.Assemblies.Component.Null
    st = S.Parts.SetWorkComponent(comp, NXOpen.PartCollection.RefsetOption.Entire,
                                  NXOpen.PartCollection.WorkComponentOption.Visible)
    try:
        st.Dispose()
    except Exception:  # noqa: BLE001
        pass
    return S.Parts.Work


# verified in acceptance build 5 and nxa_selftest (false Touch before / after)
def exclude_from_model(part, bodies):
    """Take bodies out of the part's MODEL reference set (the part must be the WORK part).

    The MODEL set collects every new body automatically - also LINKED_FACE sheets and linked bodies. Left in
    it, a link copy (even blanked) is part of the component in the assembly: Clearance Analysis reports a
    false Touch between the source component and the designed part (measured: real gap 3.0, SimpleInterference
    'NoInterference', Clearance 'Touch'; gone after the removal), and the copy is exported in the ASSEMBLY
    STEP (which writes exactly the component's reference set). The STEP of the piece part ALONE does not
    follow MODEL: a linked copy outside MODEL was still exported, and of two identical coincident solids
    only one arrived - so delete or blank construction solids before a piece-part export and verify with
    nxf.step_roundtrip_check(bodies=[the product bodies]). Removing a body changes neither its
    feature nor later booleans / Replace Face that use it; afterwards it has no occurrence in the assembly.
    Returns the number of bodies removed."""
    bodies = list(bodies)
    sets = [rs for rs in part.GetAllReferenceSets() if rs.Name == "MODEL"]
    if not sets or not bodies:
        return 0
    sets[0].RemoveObjectsFromReferenceSet(bodies)
    return len(bodies)


# verified in nx-assemblies/scripts/topdown_wave.py (wave_link) and acceptance builds 3 and 5
def wave_link(wp, source_occurrence, kind="body", fix_ts=False, pos_indep=False, associative=True, keep_out_of_model=True):
    """WAVE Geometry Linker into the work part wp. source_occurrence = occ(comp, body or face) of ANOTHER
    component of the displayed assembly. kind 'body' -> LINKED_BODY (a solid copy), 'face' -> LINKED_FACE (a
    sheet with the face's edges, e.g. hole rims).

    Defaults = follows source geometry, features added later, and the component's position.
    fix_ts=True ignores later source features; pos_indep=True puts the copy at the SOURCE PART coordinates and
    ignores component moves; associative=False is a frozen snapshot.
    The copy sits in ASSEMBLY coordinates of wp (wp's component is at the origin for a new_component part).
    Use the result as a tool: nxf.offset_region(wp, nxf.rule_faces(wp, "body", copy), clear) + nxh.subtract,
    or nxf.replace_face(wp, wall, nxf.rule_faces(wp, "feature", [feature]), reverse=...).
    keep_out_of_model=True (default) removes the copy from wp's MODEL reference set right away
    (exclude_from_model): the copy is construction geometry, not part of the product - in MODEL it gives false
    Touch / Hard results in Clearance Analysis and is exported in the assembly STEP. Measured: a linked body
    taken out of MODEL before LINKED_BODY > OFFSET_REGION > SUBTRACT gives the same result as one left in
    MODEL and follows the source dimension and the component move the same way. The price: a copy that is
    not in MODEL has no occurrence in the assembly (comp.FindOccurrence(copy) is None) - measure it in the
    part (nxh.volume(wp, copy), nxh.bbox(copy)). Pass False only when the copy itself must be seen as part
    of the component. Returns (feature, new bodies).

    More on the linked copy: nxf.datum_plane(wp, "offset", [sheet.GetFaces()[0]], formula) works - the linked
    face keeps the SOURCE's outward normal, so + is away from the source body; sketch geometry can be tied
    to a linked point directly (nxf.sketch_circle(wp, sk, linked_point, d), or
    sk.CreateCoincidentConstraint(nxf.cg(arc, nxf.CP.ArcCenter), nxf.cg(linked_point))) even when the point
    lies out of the sketch plane."""
    EF, WT = NXOpen.Features.ExtractFaceBuilder, NXOpen.Features.WaveLinkBuilder.Types
    before = list(wp.Bodies)
    b = wp.BaseFeatures.CreateWaveLinkBuilder(nxh.NULL_FEATURE)
    try:
        b.Type = WT.BodyLink if kind == "body" else WT.FaceLink
        ef = b.ExtractFaceBuilder
        ef.ParentPart = EF.ParentPartType.OtherPart
        for o in (b, ef):
            o.Associative = associative
            o.FixAtCurrentTimestamp = fix_ts
            o.MakePositionIndependent = pos_indep
        ef.HideOriginal = False
        ef.InheritDisplayProperties = False
        if kind == "body":
            ef.ExtractBodyCollector.ReplaceRules([wp.ScRuleFactory.CreateRuleBodyDumb([source_occurrence], True)], False)
        else:
            ef.FaceOption = EF.FaceOptionType.SingleFace
            ef.ObjectToExtract.Add(source_occurrence)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    new = nxh.new_bodies(wp, before)
    if keep_out_of_model:
        exclude_from_model(wp, new)
    return f, new


# verified in nx-patterns-and-body-ops/scripts/community_checks.py (C7, skeleton part) and nxa_selftest
def link_curve(wp, curve):
    """WAVE-linked composite curve in the work part wp from a curve of ANOTHER loaded part of the displayed
    assembly (a skeleton part: path, centre line, layout sketch). `curve` is the curve object in its own
    part (the prototype, e.g. a line of the skeleton's sketch). Associative, not fixed at a timestamp: an
    edit of the skeleton moves it (measured: a driven line 60 -> 90, a Pattern Along on the link followed).
    Returns the feature (type LINKED_CURVE; its curves: feature.GetEntities()). Use it as the path of
    nxf.pattern_along(wp, feats, [feature], feature.GetEntities()[0], start_xyz, count) or as a section.
    Measured with both components at the assembly origin; a skeleton component placed elsewhere is not."""
    b = wp.BaseFeatures.CreateWaveLinkBuilder(nxh.NULL_FEATURE)
    try:
        b.Type = NXOpen.Features.WaveLinkBuilder.Types.CurveLink
        cc = b.CompositeCurveBuilder
        cc.ParentPart = NXOpen.Features.CompositeCurveBuilder.PartType.OtherPart
        for o in (b, cc):
            o.Associative = True
            o.FixAtCurrentTimestamp = False
        cc.MakePositionIndependent = False
        sec = cc.Section
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
        sec.AddToSection([wp.ScRuleFactory.CreateRuleCurveDumb([curve])], curve, NXOpen.NXObject.Null, NXOpen.NXObject.Null,
                         nxh.P(0, 0, 0), NXOpen.Section.Mode.Create, False)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in acceptance build 3 (build_base: associative arc-centre points on a linked face)
def arc_centre_points(wp, body, radius=None, tol=1e-3):
    """POSITION FROM LINKED GEOMETRY: one associative point at the centre of every circular edge of `body`
    (normally the sheet of a LINKED_FACE: the hole rims of a neighbour's face), optionally only edges of this
    radius. part.Points.CreatePoint(edge, UPD) gives a smart point that follows BOTH an edit of the source's
    hole position AND a move of the source component. An interpart expression of the hole coordinate does
    not see the component placement - use this for bosses, pilot holes and stand-offs under a neighbour.
    Feed the points to nxf.hole(wp, body, points, ...) or cylinder_at_point(). Returns the points sorted by
    (x, y, z)."""
    pts = []
    for e in body.GetEdges():
        if e.SolidEdgeType != NXOpen.Edge.EdgeType.Circular:
            continue
        if radius is not None:
            bb = nxh.bbox(e)
            if abs(max(bb[i + 3] - bb[i] for i in range(3)) / 2 - radius) > tol:
                continue
        pts.append(wp.Points.CreatePoint(e, UPD))
    return sorted(pts, key=lambda q: (round(q.Coordinates.X, 6), round(q.Coordinates.Y, 6), round(q.Coordinates.Z, 6)))


# verified in nxa_selftest (follows the source hole, the component move and its own expression)
def offset_point(part, point, vec, formula):
    """Associative point at `formula` (mm, expression text or number) from an existing NXOpen.Point along
    the direction vec (normalised) - e.g. a boss 4 mm beside a linked hole centre. It follows the base point
    (and so a linked source's edits and component moves) and the expression. Returns the NXOpen.Point."""
    n = math.sqrt(sum(float(x) * float(x) for x in vec))
    mm = part.UnitCollection.FindObject("MilliMeter")
    sc = []
    for x in vec:
        e = part.Expressions.CreateSystemExpressionWithUnits("(%s)*(%.12g)" % (formula, float(x) / n), mm)
        sc.append(part.Scalars.CreateScalarExpression(e, NXOpen.Scalar.DimensionalityType.NotSet, UPD))
    off = part.Offsets.CreateOffsetRectangular(sc[0], sc[1], sc[2], UPD)
    return part.Points.CreatePoint(off, point, UPD)


# verified in acceptance build 3 (bosses on arc-centre points)
def cylinder_at_point(wp, point, vec, diameter, height, op=None, target=None):
    """Cylinder whose base centre is an associative NXOpen.Point (arc_centre_points, nxh.point): it follows
    the point. vec = axis direction from the point. Returns (feature, body) like nxh.cylinder."""
    b = wp.Features.CreateCylinderBuilder(nxh.NULL_FEATURE)
    try:
        b.Type = NXOpen.Features.CylinderBuilder.Types.AxisDiameterAndHeight
        b.Axis = wp.Axes.CreateAxis(point, nxh.direction(wp, vec), UPD)
        b.Diameter.RightHandSide = str(diameter)
        b.Height.RightHandSide = str(height)
        op = nxh.BOOL.Create if op is None else op
        b.BooleanOption.Type = op
        b.BooleanOption.SetTargetBodies([target] if op != nxh.BOOL.Create else [NXOpen.Body.Null])
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, (f.GetBodies()[0] if op == nxh.BOOL.Create else target)


# verified in nx-assemblies/scripts/topdown_wave.py and acceptance build 3 (link_exprs)
def interpart_expr(part, name, source, source_name=None, unit="mm"):
    """Interpart expression in `part`: name = "source"::source_name. source = a Part (its file leaf name is
    used) or that name as text; the source must be SAVED (named) and loaded. One master set in the assembly,
    linked into each part. It carries VALUES only - not the placement of a component (see arc_centre_points).
    NX stores it as two expressions: name = name_0, and name_0 holding the link (IsInterpartExpression True,
    GetInterpartExpressionNames() == [source, source_name]). Returns the expression `name` (use it in formulas)."""
    leaf = source if isinstance(source, str) else source.Leaf
    return part.Expressions.CreateWithUnits('%s="%s"::%s' % (name, leaf, source_name or name), nxh.units(part)[unit])


# verified in nx-assemblies/scripts/topdown_wave.py (reopen table) and acceptance build 3 (main_reopen)
def load_fully(objs, update=True):
    """After reopening an assembly its components are PARTIALLY loaded (IsFullyLoaded False, no features) and
    a partially loaded part does not follow its WAVE sources or interpart expressions - DoUpdate and
    DoInterpartUpdate change nothing. Call this with every part (or component) that owns or feeds a link, then
    edit. Returns the names of the parts that had to be loaded."""
    done = []
    for o in objs:
        p = o.Prototype if isinstance(o, NXOpen.Assemblies.Component) else o
        if not p.IsFullyLoaded:
            p.LoadThisPartFully().Dispose()
            done.append(p.Name)
    if update:
        nxh.update()
    return done


# ====================================================================== clearance, interference
# verified in nx-assemblies/scripts/clearance_check.py
def clearance_set(assy, name, zone=0.0):
    """Clearance Analysis set over all components (exact). zone = clearance zone in mm (an Expression is
    created; a float argument to NX raises TypeError). Run it with run_clearance()."""
    b = assy.AssemblyManager.CreateClearanceAnalysisBuilder(NA.ClearanceSet.Null)
    try:
        b.ClearanceSetName = name
        b.CalculationMethod = NA.ClearanceAnalysisBuilder.CalculationMethodType.Exact
        b.ClearanceBetween = NA.ClearanceAnalysisBuilder.ClearanceBetweenEntity.Components
        b.TotalCollectionCount = NA.ClearanceAnalysisBuilder.NumberOfCollections.One
        b.CollectionOneRange = NA.ClearanceAnalysisBuilder.CollectionRange.AllObjects
        mm = assy.UnitCollection.FindObject("MilliMeter")
        b.SetDefaultClearanceZone(assy.Expressions.CreateSystemExpressionWithUnits(str(zone), mm))
        return b.Commit()
    finally:
        b.Destroy()


# verified in nx-assemblies/scripts/clearance_check.py
def run_clearance(cs):
    """Analyse a clearance set -> [{"pair": [name, name], "type": "Hard" | "Touch" | "Soft" | ...}], sorted.
    Hard = the solids OVERLAP (investigate every one); Touch = line-to-line contact; Soft = inside the zone."""
    cs.PerformAnalysis(NA.ClearanceSet.ReanalyzeOutOfDateExcludedPairs.FalseValue)
    out = []
    a = b = NXOpen.DisplayableObject.Null
    for _ in range(cs.GetNumberOfInterferences()):
        nxt = cs.GetNextInterference(a, b)
        a, b = nxt[0], nxt[1]
        if a is None or b is None:
            break
        data = cs.GetInterferenceData(a, b)
        out.append({"pair": sorted([a.Name, b.Name]), "type": enum_name(NA.ClearanceSet.InterferenceType, data[0])})
    return sorted(out, key=lambda r: r["pair"])


# verified in nx-assemblies/scripts/clearance_check.py
def simple_interference(assy, body_a, body_b):
    """One pair of bodies (occurrences): ('InterferenceExists' | 'OnlyEdgesOrFacesInterfere' | 'NoInterference',
    [overlap volumes]). The temporary interference solids are deleted. nxh.min_dist is 0 for touching AND
    for overlapping bodies - never use it alone."""
    import NXOpen.GeometricAnalysis as GA
    si = assy.AnalysisManager.CreateSimpleInterferenceObject()
    try:
        si.InterferenceType = GA.SimpleInterference.InterferenceMethod.InterferenceSolid
        si.FirstBody.Value = body_a
        si.SecondBody.Value = body_b
        r = si.PerformCheck()
        vols = []
        if r == GA.SimpleInterference.Result.InterferenceExists:
            for obj in si.GetInterferenceResults():
                vols.append(nxh.volume(assy, obj))
                nxh.UFS.Obj.DeleteObject(obj.Tag)
        return enum_name(GA.SimpleInterference.Result, r), vols
    finally:
        si.Destroy()


# ====================================================================== deliverable
# verified in acceptance build 3 (assembly STEP export + step_probe.py walker)
def step_roundtrip(assy, stp, out_dir, name="asmcheck", rel_tol=1e-4):
    """Export the ASSEMBLY to STEP AP242 (structure is kept: one product per component, instances for repeated
    parts) and re-import it: nxf.step_export + nxf.step_roundtrip_check(part=assy, restore=assy).

    The assembly must be the work part (set_work(None)); it and its components are saved. Returns the check
    dict: require r["match"] (every leaf instance's solids agree in volume within rel_tol), r["healthy"],
    and compare r["instances"] (name, part, origin, solids, volume) with the component positions."""
    set_work(None)
    nxf.step_export(assy, stp)
    return nxf.step_roundtrip_check(stp, out_dir, name, restore=assy, part=assy, rel_tol=rel_tol)
