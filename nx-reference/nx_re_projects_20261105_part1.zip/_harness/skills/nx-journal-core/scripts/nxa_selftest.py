"""Self-test of nxa.py (NX 2206, run_journal): every public function is called at least once on a small assembly
built here and the result is MEASURED (component frame, axis, DOF, gap, linked geometry position, volumes, STEP).

    run_journal.ps1 -Script nxa_selftest.py -WorkDir <out> -JArgs <out> -TimeoutSec 1500
    (optional: -JArgs <out>,<group> runs only 'constraints' or 'topdown')

Writes <out>/nxa_selftest.json: {"result": "PASS" | "FAIL", "checks": [...], "uncovered": [...], "errors": {...}}.
"""
import functools
import math
import os
import sys
import traceback
import types

sys.path.insert(0, os.environ.get("NXH_DIR", os.path.dirname(os.path.abspath(sys.argv[0]))))
import NXOpen  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402
import nxa  # noqa: E402

OUT = sys.argv[1]
ONLY = {g for a in sys.argv[2:] for g in a.split(",") if g} or None
S, BOOL = nxh.S, nxh.BOOL
log = nxh.Log(os.path.join(OUT, "nxa_selftest.log"))
chk = nxh.Check()
res = {"result": "FAIL", "errors": {}, "notes": {}}

PUBLIC = sorted(n for n, o in vars(nxa).items() if isinstance(o, types.FunctionType) and not n.startswith("_")
                and o.__module__ == "nxa")
CALLED = set()


def _trace(name, fn):
    @functools.wraps(fn)
    def w(*a, **k):
        CALLED.add(name)
        return fn(*a, **k)
    return w


for _n in PUBLIC:
    setattr(nxa, _n, _trace(_n, getattr(nxa, _n)))


def ck(name, got, want, tol=1e-6):
    if got is None:
        chk.true(name, False, "got None, want %s" % want)
        log("FAIL", name, "got None")
        return False
    ok = chk(name, got, want, tol)
    log("PASS" if ok else "FAIL", name, "got", round(float(got), 6), "want", round(float(want), 6), "tol", tol)
    return ok


def ct(name, cond, note=""):
    ok = chk.true(name, cond, note)
    log("PASS" if ok else "FAIL", name, note)
    return ok


def case(label, fn):
    try:
        fn()
    except Exception:  # noqa: BLE001
        tb = traceback.format_exc()
        res["errors"][label] = tb
        ct(label + ": no exception", False, tb.strip().splitlines()[-1][:300])


def flush():
    out = dict(res)
    out.update(chk.report())
    out["uncovered"] = sorted(set(PUBLIC) - CALLED)
    nxh.write_json(os.path.join(OUT, "nxa_selftest.json"), out)
    return out


def group(name, fn):
    if ONLY and name not in ONLY:
        return
    log("==== group", name)
    try:
        nxh.close_all()
        fn()
    except Exception:  # noqa: BLE001
        tb = traceback.format_exc()
        res["errors"]["group " + name] = tb
        ct("group %s: no exception" % name, False, tb.strip().splitlines()[-1][:300])
    flush()


def solid(part, name=None):
    for b in part.Bodies:
        if b.IsSolidBody and (name is None or b.Name == name):
            return b
    raise RuntimeError("%s: no solid %s" % (part.Name, name))


def one(faces, what):
    if len(faces) != 1:
        raise RuntimeError("%d faces match %s" % (len(faces), what))
    return faces[0]


def plane(body, normal, coord):
    return one(nxh.faces(body, ftype=nxh.PLANE, normal=normal, at=coord), (normal, coord))


def cyl_at(body, radius, xy):
    return one([f for f in nxh.faces(body, ftype=nxh.CYLINDER, radius=radius)
                if abs(nxh.face_data(f)[1][0] - xy[0]) < 1e-4 and abs(nxh.face_data(f)[1][1] - xy[1]) < 1e-4], (radius, xy))


def cyl_axes(body, radius):
    return sorted({(round(nxh.face_data(f)[1][0], 4) + 0.0, round(nxh.face_data(f)[1][1], 4) + 0.0)
                   for f in nxh.faces(body, ftype=nxh.CYLINDER, radius=radius)})


def build_parts():
    paths = {}

    def start(name):
        paths[name] = os.path.join(OUT, "nxa_%s.prt" % name)
        return nxh.new_part(paths[name])

    p = start("plate")           # 100 x 60 x 10, holes D10 through Z at (20,30) and (80,30)
    _f, b = nxh.block(p, (0, 0, 0), (100, 60, 10))
    for x in (20, 80):
        nxh.cylinder(p, (x, 30, 0), (0, 0, 1), 10, 10, op=BOOL.Subtract, target=b)
    nxh.save(p)
    p = start("pin")             # shank D10 z 0..30, head D16 z 30..35
    _f, b = nxh.cylinder(p, (0, 0, 0), (0, 0, 1), 10, 30)
    nxh.cylinder(p, (0, 0, 30), (0, 0, 1), 16, 5, op=BOOL.Unite, target=b)
    nxh.save(p)
    p = start("fork")            # 40 x 30 x 40, slot x 10..30 above z 10, cross hole D8 along X at y 15 z 28
    _f, b = nxh.block(p, (0, 0, 0), (40, 30, 40))
    nxh.block(p, (10, 0, 10), (20, 30, 30), op=NXOpen.Features.Feature.BooleanType.Subtract, target=b)
    nxh.cylinder(p, (0, 15, 28), (1, 0, 0), 8, 40, op=BOOL.Subtract, target=b)
    nxh.save(p)
    p = start("wheel")           # D24 x 14 along X, bore D8
    _f, b = nxh.cylinder(p, (0, 0, 0), (1, 0, 0), 24, 14)
    nxh.cylinder(p, (0, 0, 0), (1, 0, 0), 8, 14, op=BOOL.Subtract, target=b)
    nxh.save(p)
    p = start("link")            # 80 x 20 x 8, holes D10 through Z at (10,10) and (70,10)
    _f, b = nxh.block(p, (0, 0, 0), (80, 20, 8))
    for x in (10, 70):
        nxh.cylinder(p, (x, 10, 0), (0, 0, 1), 10, 8, op=BOOL.Subtract, target=b)
    nxh.save(p)
    p = start("cube")
    nxh.block(p, (0, 0, 0), (20, 20, 20))
    nxh.save(p)
    p = start("slot")            # 60 x 30 x 10 with a through slot: half arcs R5 at (20,15) and (40,15)
    _f, b = nxh.block(p, (0, 0, 0), (60, 30, 10))
    for x in (20, 40):
        nxh.cylinder(p, (x, 15, 0), (0, 0, 1), 10, 10, op=BOOL.Subtract, target=b)
    nxh.block(p, (20, 10, 0), (20, 10, 10), op=NXOpen.Features.Feature.BooleanType.Subtract, target=b)
    nxh.save(p)
    p = start("pcb")             # board pcb_len x 40 x 1.6, holes D3 at (hole_x, 10) and (hole2_x, 30)
    nxh.expr(p, "hole_x", 10)
    nxh.expr(p, "hole2_x", 50)
    nxh.expr(p, "pcb_len", 60)
    _f, b = nxh.block(p, (0, 0, 0), ("pcb_len", 40, 1.6))
    nxh.cylinder(p, ("hole_x", 10, 0), (0, 0, 1), 3, 1.6, op=BOOL.Subtract, target=b)
    nxh.cylinder(p, ("hole2_x", 30, 0), (0, 0, 1), 3, 1.6, op=BOOL.Subtract, target=b)
    b.SetName("BOARD")
    nxh.save(p)
    return paths


# ============================================================================ bottom-up: constraints
def g_constraints():
    paths = build_parts()
    assy = nxa.new_assembly(os.path.join(OUT, "nxa_asm.prt"))
    nxh.expr(assy, "lift", 5, comment="pin shoulder above the plate")
    nxh.expr(assy, "swing", 40, "deg", "link angle")
    plate = nxa.add_component(assy, paths["plate"], "PLATE")
    plate_b = solid(plate.Prototype)
    hole1, hole2 = cyl_at(plate_b, 5, (20, 30)), cyl_at(plate_b, 5, (80, 30))
    top = plane(plate_b, (0, 0, 1), (2, 10))
    side = plane(plate_b, (0, -1, 0), (1, 0))
    e_top1 = nxa.circ_edge(plate_b, (20, 30, 10), 5)
    st = {}

    def pin(name, at=(35, 42, 40)):
        c = nxa.add_component(assy, paths["pin"], name, at, nxa.rot("x", 20))
        if "pin" not in st:
            b = solid(c.Prototype)
            st["pin"] = {"shank": one(nxh.faces(b, ftype=nxh.CYLINDER, radius=5), "shank"), "shoulder": plane(b, (0, 0, -1), (2, 30)),
                         "cap": plane(b, (0, 0, 1), (2, 35)), "e_sh": nxa.circ_edge(b, (0, 0, 30), 5)}
        return c

    def c_fix():
        c = nxa.fix(assy, plate, "FIX_PLATE")
        ct("fix: status Solved", nxa.status_name(c) == "Solved", nxa.status_name(c))
        ct("fix: IsFixed and DOF [0, 0]", plate.IsFixed and nxa.dof(plate) == [0, 0], nxa.dof(plate))
        ck("frame: fixed plate origin z", nxa.frame(plate)[0][2], 0.0)
        ct("components: lookup by name", nxa.components(assy)["PLATE"].Tag == plate.Tag)
    case("fix", c_fix)

    def c_add():
        p = pin("P_TILT", (135, 42, 40))
        o, _r = nxa.frame(p)
        ck("add_component: origin x", o[0], 135.0)
        z = nxa.axis_of(p)
        ck("add_component + rot('x', 20): axis z.y", z[1], -math.sin(math.radians(20)), 1e-9)
        ck("add_component + rot('x', 20): axis z.z", z[2], math.cos(math.radians(20)), 1e-9)
        ck("to_assy: head centre (0, 0, 30) in assembly z", nxa.to_assy(p, (0, 0, 30))[2], 40 + 30 * math.cos(math.radians(20)), 1e-9)
        ck("dof: free component", sum(nxa.dof(p)), 6, 0)
    case("add_component / frames", c_add)

    def c_concentric():
        p = pin("P_CONC")
        g = st["pin"]
        c = nxa.concentric(assy, (p, g["e_sh"]), (plate, e_top1), "CONC")
        o = nxa.frame(p)[0]
        ck("concentric: origin x", o[0], 20.0)
        ck("concentric: origin y", o[1], 30.0)
        ck("concentric: shoulder edge seated on the hole rim (origin z)", o[2], -20.0)
        ck("concentric: axis +Z", nxa.axis_of(p)[2], 1.0, 1e-9)
        ct("concentric: DOF [1, 0]", nxa.dof(p) == [1, 0], nxa.dof(p))
        dp, _da = nxa.drag(assy, p, (0, 0, 7))
        ck("drag: blocked slide moves 0 mm", dp, 0.0, 1e-6)
        _dp, da = nxa.drag(assy, p, spin=((20, 30, 0), "z", 25))
        ck("drag: free spin turns 25 deg", da, 25.0, 1e-6)
        nxa.flip(assy, c)
        ck("flip: pin turned end for end (origin z)", nxa.frame(p)[0][2], 40.0)
        ck("flip: axis -Z", nxa.axis_of(p)[2], -1.0, 1e-9)
        nxa.flip(assy, c)
        ck("flip back: origin z", nxa.frame(p)[0][2], -20.0)
    case("concentric / flip / drag", c_concentric)

    def c_axis_distance():
        p = pin("P_LIFT", (95, 45, 50))
        g = st["pin"]
        nxa.center_axis(assy, (p, g["shank"]), (plate, hole2), "LIFT_AXIS")
        ck("center_axis: origin x", nxa.frame(p)[0][0], 80.0)
        ck("center_axis: origin y", nxa.frame(p)[0][1], 30.0)
        ct("center_axis: DOF [1, 1]", nxa.dof(p) == [1, 1], nxa.dof(p))
        c = nxa.distance(assy, (p, g["shoulder"]), (plate, top), "lift", "LIFT_DISTANCE")
        gap = lambda: nxh.min_dist(nxa.occ(p, g["shoulder"]), nxa.occ(plate, top))  # noqa: E731
        ck("distance: face gap = lift (5)", gap(), 5.0)
        nxh.set_expr(assy, "lift", 12)
        nxh.update()
        ck("distance: expression 5 -> 12", gap(), 12.0)
        ck("distance: pin still on the hole axis", nxa.frame(p)[0][0], 80.0)
        ct("distance: status Solved after the edit", nxa.status_name(c) == "Solved", nxa.status_name(c))
    case("center_axis / distance", c_axis_distance)

    def c_planar():
        g = None
        p = pin("P_TOUCH")
        g = st["pin"]
        nxa.touch(assy, (p, g["shoulder"]), (plate, top), "TOUCH")
        ck("touch: shoulder on the plate top (origin z)", nxa.frame(p)[0][2], -20.0)
        ck("touch: axis +Z", nxa.axis_of(p)[2], 1.0, 1e-9)
        ct("touch: DOF [1, 2]", nxa.dof(p) == [1, 2], nxa.dof(p))
        p = pin("P_ALIGN")
        nxa.align(assy, (p, g["cap"]), (plate, top), "ALIGN")
        ck("align: cap flush with the plate top (origin z)", nxa.frame(p)[0][2], -25.0)
        ct("align: DOF [1, 2]", nxa.dof(p) == [1, 2], nxa.dof(p))
        p = pin("P_PAR")
        nxa.parallel(assy, (p, g["cap"]), (plate, top), "PARALLEL")
        ck("parallel: |axis z|", abs(nxa.axis_of(p)[2]), 1.0, 1e-9)
        ct("parallel: DOF [1, 3]", nxa.dof(p) == [1, 3], nxa.dof(p))
        p = pin("P_PERP")
        nxa.perpendicular(assy, (p, g["cap"]), (plate, top), "PERPENDICULAR")
        ck("perpendicular: axis z", nxa.axis_of(p)[2], 0.0, 1e-9)
        ct("perpendicular: DOF [2, 3]", nxa.dof(p) == [2, 3], nxa.dof(p))
    case("touch / align / parallel / perpendicular", c_planar)

    def c_align_lock():
        g = st["pin"]
        p = pin("P_LOCK_EDGE")
        nxa.align_lock(assy, (p, g["e_sh"]), (plate, e_top1), "LOCK_EDGE")
        ck("align_lock(edges): origin z", nxa.frame(p)[0][2], -20.0)
        ct("align_lock(edges): rigid, DOF [0, 0]", nxa.dof(p) == [0, 0], nxa.dof(p))
        p = pin("P_LOCK_AXIS")
        nxa.align_lock(assy, (p, g["shank"]), (plate, hole1), "LOCK_AXIS")
        ck("align_lock(faces): origin x", nxa.frame(p)[0][0], 20.0)
        ct("align_lock(faces): slides only, DOF [0, 1]", nxa.dof(p) == [0, 1], nxa.dof(p))
    case("align_lock", c_align_lock)

    def c_arc_edge():
        g = st["pin"]
        slot = nxa.add_component(assy, paths["slot"], "SLOT", (0, 100, 0))
        nxa.fix(assy, slot, "FIX_SLOT")
        sb = solid(slot.Prototype)
        _o, err = nxh.attempt("circ_edge on a half arc", nxa.circ_edge, sb, (20, 15, 10), 5)
        ct("circ_edge: a slot's half arc is not a full circle (raises)", err is not None, err)
        e = nxa.arc_edge(sb, (20, 15, 10), 5)
        ck("arc_edge: half arc found, length pi * 5", e.GetLength(), math.pi * 5, 1e-6)
        ct("arc_edge: also finds a full circle (plate hole rim)", nxa.arc_edge(plate_b, (20, 30, 10), 5).Tag == e_top1.Tag)
        ct("arc_edge(near=): picks the nearest of several", nxa.arc_edge(sb, (40, 15, 10), 5, near=(45, 15, 10)).Tag != e.Tag)
        p = pin("P_SLOT", (25, 118, 40))
        c = nxa.concentric(assy, (p, g["e_sh"]), (slot, e), "PIN_IN_SLOT_END")
        if nxa.axis_of(p)[2] < 0:
            nxa.flip(assy, c)
        o = nxa.frame(p)[0]
        ct("Concentric on a HALF-ARC edge: Solved", nxa.status_name(c) == "Solved", nxa.status_name(c))
        ck("Concentric on a half-arc edge: pin on the arc centre (x)", o[0], 20.0)
        ck("Concentric on a half-arc edge: pin on the arc centre (y)", o[1], 115.0)
        ck("Concentric on a half-arc edge: seated on the arc plane (origin z)", o[2], -20.0)
        ct("Concentric on a half-arc edge: DOF [1, 0]", nxa.dof(p) == [1, 0], nxa.dof(p))
    case("arc_edge / Concentric on a partial arc", c_arc_edge)

    def c_order():
        g = st["pin"]
        a, b = pin("P_FIRST", (200, 0, 0)), pin("P_SECOND", (240, 30, 20))
        fb = nxa.frame(b)
        nxa.center_axis(assy, (a, g["shank"]), (b, g["shank"]), "ORDER_AB")
        moved_second = math.dist(fb[0], nxa.frame(b)[0]) > 1e-6 or abs(nxa.axis_of(b)[2] - fb[1][2][2]) > 1e-9
        res["notes"]["both_free.second_reference_moved"] = moved_second
        a, b = pin("P_HINT_MOVE", (200, 80, 0)), pin("P_HINT_STAY", (240, 110, 20))
        fb = nxa.frame(b)
        nxa.center_axis(assy, (a, g["shank"]), (b, g["shank"]), "ORDER_HINT", fix_hint=1)
        ck("fix_hint=1: the second reference's component did not move", math.dist(fb[0], nxa.frame(b)[0]), 0.0, 1e-9)
        ct("both free without a hint: NX moved the SECOND component", moved_second)
    case("which component moves", c_order)

    def c_center22():
        fork = nxa.add_component(assy, paths["fork"], "FORK", (120, 0, 0))
        nxa.fix(assy, fork, "FIX_FORK")
        wheel = nxa.add_component(assy, paths["wheel"], "WHEEL", (150, 50, 60), nxa.rot("z", 30))
        wb, fb = solid(wheel.Prototype), solid(fork.Prototype)
        c = nxa.center22(assy, (wheel, plane(wb, (-1, 0, 0), (0, 0))), (wheel, plane(wb, (1, 0, 0), (0, 14))),
                         (fork, plane(fb, (1, 0, 0), (0, 10))), (fork, plane(fb, (-1, 0, 0), (0, 30))), "WHEEL_CENTRED")
        ck("center22: wheel mid-plane on the fork mid-plane (x)", nxa.to_assy(wheel, (7, 0, 0))[0], 140.0)
        ct("center22: DOF [1, 2]", nxa.dof(wheel) == [1, 2], nxa.dof(wheel))
        bore = one(nxh.faces(wb, ftype=nxh.CYLINDER, radius=4), "bore")
        fhole = one(nxh.faces(fb, ftype=nxh.CYLINDER, radius=4)[:1], "fork hole")
        nxa.center_axis(assy, (wheel, bore), (fork, fhole), "WHEEL_ON_AXIS")
        ctr = nxa.to_assy(wheel, (7, 0, 0))
        ck("center22 + center_axis: wheel centre y", ctr[1], 15.0)
        ck("center22 + center_axis: wheel centre z", ctr[2], 28.0)
        ct("center22 + center_axis: only the spin is left, DOF [1, 0]", nxa.dof(wheel) == [1, 0], nxa.dof(wheel))
        ct("center22: status", nxa.status_name(c) == "Solved", nxa.status_name(c))
    case("center22", c_center22)

    def c_angle():
        link = nxa.add_component(assy, paths["link"], "LINK", (10, 70, 30), nxa.rot("z", 10))
        lb = solid(link.Prototype)
        cc = nxa.concentric(assy, (link, nxa.circ_edge(lb, (10, 10, 0), 5)), (plate, e_top1), "LINK_PIVOT")
        if nxa.axis_of(link)[2] < 0:
            nxa.flip(assy, cc)
        ck("angle: link lies on the plate (pivot z)", nxa.to_assy(link, (10, 10, 0))[2], 10.0)
        ck("angle: link upright", nxa.axis_of(link)[2], 1.0, 1e-9)
        nxa.angle(assy, (link, plane(lb, (0, -1, 0), (1, 0))), (plate, side), "swing", "LINK_SWING")

        def measured():
            y = nxa.axis_of(link, 1)
            return nxh.angle_deg([-v for v in y], (0, -1, 0))
        ck("angle: face normals 40 deg apart", measured(), 40.0, 1e-6)
        nxh.set_expr(assy, "swing", 70)
        nxh.update()
        ck("angle: expression 40 -> 70", measured(), 70.0, 1e-6)
        ct("angle: pivot + angle leave DOF [0, 0]", nxa.dof(link) == [0, 0], nxa.dof(link))
    case("angle", c_angle)

    def c_clearance():
        cube = nxa.add_component(assy, paths["cube"], "CUBE", (40, 20, 9.5))
        nxa.move_component(assy, cube, (5, 0, 0))
        ck("move_component: +5 in X", nxa.frame(cube)[0][0], 45.0)
        r, vols = nxa.simple_interference(assy, nxa.occ(cube, solid(cube.Prototype)), nxa.occ(plate, plate_b))
        ct("simple_interference: cube sunk 0.5 into the plate -> InterferenceExists", r == "InterferenceExists", r)
        ck("simple_interference: overlap volume 20 x 20 x 0.5", sum(vols), 200.0, 1e-4)
        far = nxa.add_component(assy, paths["cube"], "CUBE_FAR", (40, 200, 0))
        r2, _v = nxa.simple_interference(assy, nxa.occ(far, solid(far.Prototype)), nxa.occ(plate, plate_b))
        ct("simple_interference: separate bodies -> NoInterference", r2 == "NoInterference", r2)
        ck("min_dist between occurrences: 140 mm gap", nxh.min_dist(nxa.occ(far, solid(far.Prototype)), nxa.occ(plate, plate_b)), 140.0)
        rows = nxa.run_clearance(nxa.clearance_set(assy, "NXA_CLR", 0.0))
        res["notes"]["clearance"] = rows
        ct("clearance: CUBE / PLATE reported Hard", any(x["pair"] == ["CUBE", "PLATE"] and x["type"] == "Hard" for x in rows),
           [x for x in rows if "CUBE" in x["pair"]])
        ct("clearance: CUBE_FAR in no pair", not any("CUBE_FAR" in x["pair"] for x in rows))
        ct("clearance: line-to-line pin in the hole is Touch, not Hard",
           any(x["pair"] == ["PLATE", "P_LOCK_EDGE"] and x["type"] == "Touch" for x in rows),
           [x for x in rows if "P_LOCK_EDGE" in x["pair"]])
    case("clearance / interference", c_clearance)
    res["notes"]["constraints.enum_name"] = nxa.enum_name(nxa.T, nxa.T.Concentric)
    nxh.save(assy)


# ============================================================================ top-down: in-context part, links
def g_topdown():
    pcb_path = os.path.join(OUT, "nxa_pcb.prt")
    if not os.path.exists(pcb_path):
        build_parts()
        nxh.close_all()
    asm_path = os.path.join(OUT, "nxa_td_asm.prt")
    assy = nxa.new_assembly(asm_path)
    nxh.expr(assy, "boss_d", 6, comment="boss diameter (master)")
    nxh.save(assy)                                   # interpart expressions need a named source
    pcb_c = nxa.add_component(assy, pcb_path, "PCB", (10, 5, 3))
    pcb = pcb_c.Prototype
    board = solid(pcb, "BOARD")
    st = {}

    def c_new_component():
        base_c = nxa.new_component(assy, os.path.join(OUT, "nxa_td_base.prt"), "BASE")
        wp = nxa.set_work(base_c)
        ct("new_component + set_work: work part is the new part, display part the assembly",
           wp.Name.lower() == "nxa_td_base" and S.Parts.Display.Tag == assy.Tag, wp.Name)
        ck("new_component: placed at the absolute origin", sum(abs(v) for v in nxa.frame(base_c)[0]), 0.0)
        e = nxa.interpart_expr(wp, "boss_d", assy)
        ck("interpart_expr: value from the assembly", e.Value, 6.0)
        link = wp.Expressions.FindObject(e.RightHandSide)
        ct("interpart_expr: stored as boss_d = boss_d_0, boss_d_0 is the interpart link",
           e.RightHandSide == "boss_d_0" and link.IsInterpartExpression, [e.RightHandSide, [str(x) for x in link.GetInterpartExpressionNames()]])
        nxa.set_work(None)
        nxh.set_expr(assy, "boss_d", 7)
        nxh.update()
        ck("interpart_expr: follows the master expression 6 -> 7", e.Value, 7.0)
        nxh.set_expr(assy, "boss_d", 6)
        nxh.update()
        wp = nxa.set_work(base_c)
        # a component is the WORK part now: new_component must still put the new one under the assembly
        n_top = len(nxa.components(assy))
        extra_c = nxa.new_component(assy, os.path.join(OUT, "nxa_td_extra.prt"), "EXTRA")
        ct("new_component while a component is the work part: the new one is a child of the ASSEMBLY, not of that component",
           len(nxa.components(assy)) == n_top + 1 and extra_c.Parent.Tag == assy.ComponentAssembly.RootComponent.Tag
           and len(base_c.GetChildren()) == 0, [len(nxa.components(assy)), len(base_c.GetChildren())])
        assy.ComponentAssembly.RemoveComponent(extra_c)                 # keep the rest of the test as it was
        nxh.update()
        wp = nxa.set_work(base_c)
        _f, base = nxh.block(wp, (5, 0, -2), (70, 50, 2))
        st.update(base_c=base_c, wp=wp, base=base)
    case("new_component / set_work / interpart_expr", c_new_component)

    def bosses():
        return cyl_axes(st["base"], 3.0)

    def c_links():
        wp, base = st["wp"], st["base"]
        bottom = one(nxh.faces(board, ftype=nxh.PLANE, normal=(0, 0, -1)), "pcb bottom")
        f_lf, sheets = nxa.wave_link(wp, nxa.occ(pcb_c, bottom), kind="face", keep_out_of_model=False)
        # the link sheet is in MODEL: Clearance Analysis sees it as part of BASE and reports a false Touch
        nxa.set_work(None)
        rows = nxa.run_clearance(nxa.clearance_set(assy, "TD_BEFORE", 0.0))
        gap = nxh.min_dist(nxa.occ(st["base_c"], base), nxa.occ(pcb_c, board))
        si, _v = nxa.simple_interference(assy, nxa.occ(st["base_c"], base), nxa.occ(pcb_c, board))
        res["notes"]["link_sheet_in_MODEL"] = {"clearance": rows, "min_dist": gap, "simple_interference": si}
        ck("link sheet in MODEL: real gap base - PCB", gap, 3.0)
        ct("link sheet in MODEL: SimpleInterference says NoInterference", si == "NoInterference", si)
        ct("link sheet in MODEL: Clearance Analysis reports a FALSE BASE / PCB pair", any(x["pair"] == ["BASE", "PCB"] for x in rows), rows)
        nxa.set_work(st["base_c"])
        ck("exclude_from_model: sheets removed", nxa.exclude_from_model(wp, sheets), 1, 0)
        nxa.set_work(None)
        rows = nxa.run_clearance(nxa.clearance_set(assy, "TD_AFTER", 0.0))
        res["notes"]["link_sheet_out_of_MODEL"] = rows
        ct("exclude_from_model: the false BASE / PCB pair is gone", not any(x["pair"] == ["BASE", "PCB"] for x in rows), rows)
        nxa.set_work(st["base_c"])
        ct("wave_link(face): LINKED_FACE sheet", f_lf.FeatureType == "LINKED_FACE" and not sheets[0].IsSolidBody, f_lf.FeatureType)
        ck("wave_link(face): at the occurrence position (z = 3)", nxh.dist_to(wp, sheets[0], (40, 25, 3)), 0.0)
        pts = nxa.arc_centre_points(wp, sheets[0], radius=1.5)
        ck("arc_centre_points: one point per hole rim", len(pts), 2, 0)
        ck("arc_centre_points: first hole x (10 + hole_x)", pts[0].Coordinates.X, 20.0)
        ck("arc_centre_points: first hole y", pts[0].Coordinates.Y, 15.0)
        ck("arc_centre_points: z of the linked face", pts[0].Coordinates.Z, 3.0)
        v0 = nxh.volume(wp, base)
        for q in pts:
            nxa.cylinder_at_point(wp, q, (0, 0, -1), "boss_d", 3.5, BOOL.Unite, base)
        ck("cylinder_at_point: two bosses D6 from the PCB down to the base (delta)", nxh.volume(wp, base) - v0, 2 * math.pi * 9 * 3, 1e-3)
        ct("bosses under the PCB holes", bosses() == [(20.0, 15.0), (60.0, 35.0)], bosses())
        v0 = nxh.volume(wp, base)
        nxf.hole(wp, base, pts, 2, depth=4, vector=(0, 0, -1))
        ck("nxf.hole on the linked points: two pilot holes D2 x 4", v0 - nxh.volume(wp, base), 2 * math.pi * 4, 1e-3)
        f_lb, linked = nxa.wave_link(wp, nxa.occ(pcb_c, board), kind="body")
        ct("wave_link(body): LINKED_BODY solid", f_lb.FeatureType == "LINKED_BODY" and linked[0].IsSolidBody, f_lb.FeatureType)
        ck("wave_link(body): volume = source", nxh.volume(wp, linked[0]), nxh.volume(pcb, board), 1e-6)
        ck("wave_link(body): placed at the occurrence (xmin 10)", nxh.bbox(linked[0])[0], 10.0)
        e = nxa.interpart_expr(wp, "hole_x", pcb)
        ck("interpart_expr from the PCB part: hole_x", e.Value, 10.0)
        # default keep_out_of_model=True: the linked body is NOT in MODEL and still works as a boolean tool
        cavity = lambda L: (L + 0.4) * 40.4 * 2.0 - 2 * math.pi * 1.3 ** 2 * 2.0  # noqa: E731
        covers = {}
        for tag, out_of_model in (("in MODEL", False), ("out of MODEL", True)):       # LINKED_BODY > OFFSET_REGION > SUBTRACT
            _f, cover = nxh.block(wp, (5, 0, 2.5), (70, 50, 3))
            _f2, tool = nxa.wave_link(wp, nxa.occ(pcb_c, board), kind="body", keep_out_of_model=out_of_model)
            nxf.offset_region(wp, nxf.rule_faces(wp, "body", tool[0]), 0.2)
            nxh.subtract(wp, cover, [tool[0]])
            ck("linked body %s: Offset Region + Subtract (cover volume)" % tag, nxh.volume(wp, cover), 10500 - cavity(60), 1e-3)
            covers[tag] = cover
        nxa.exclude_from_model(wp, [covers["out of MODEL"]])                           # keep the duplicate cover out of the product
        cover = covers["in MODEL"]
        # positions and planes derived from linked geometry
        nxh.expr(wp, "pt_off", 4)
        nxh.expr(wp, "gap", 2)
        q = nxa.offset_point(wp, pts[0], (1, 0, 0), "pt_off")
        ck("offset_point: 4 mm in +X from the linked hole centre (x)", q.Coordinates.X, 24.0)
        ck("offset_point: y, z unchanged", q.Coordinates.Y + q.Coordinates.Z, 18.0)
        end = one(nxh.faces(board, ftype=nxh.PLANE, normal=(1, 0, 0)), "pcb end face")
        _fe, end_sheets = nxa.wave_link(wp, nxa.occ(pcb_c, end), kind="face")
        _fd, dp = nxf.datum_plane(wp, "offset", [end_sheets[0].GetFaces()[0]], "gap")
        ck("datum_plane offset from a LINKED face: + is the source's outward normal (x = 10 + 60 + 2)", dp.Origin.X, 72.0)
        D = nxh.Datums(wp)
        sk = nxf.new_sketch(wp, D.xy, D.x, D.origin, "SK_ON_LINKED_POINT")
        nxf.sketch_circle(wp, sk, pts[1], 4)
        r = nxf.finish_sketch(sk)
        ck("sketch circle coincident with a linked point 3 mm out of the sketch plane: DOF", r["dof"], 0, 0)
        v0 = nxh.volume(wp, base)
        nxh.extrude(wp, nxh.section_feature(wp, [sk.Feature]), (0, 0, -1), 1.5, 2, BOOL.Subtract, base)
        ck("recess D4 x 0.5 under the linked hole (delta)", v0 - nxh.volume(wp, base), math.pi * 4 * 0.5, 1e-3)
        ct("recess axis on the linked hole", cyl_axes(base, 2.0) == [(60.0, 35.0)], cyl_axes(base, 2.0))
        st.update(linked=linked[0], hole_x=e, sheet=sheets[0], q=q, dp=dp, cover=cover, cavity=cavity, covers=covers)
    case("wave_link / arc_centre_points / cylinder_at_point", c_links)

    def c_follow():
        wp = st["wp"]
        nxa.set_work(pcb_c)
        nxh.set_expr(pcb, "hole_x", 14)
        nxh.update()
        nxa.set_work(st["base_c"])
        nxh.update()
        ct("source hole moved 10 -> 14: boss follows the linked rim", bosses() == [(24.0, 15.0), (60.0, 35.0)], bosses())
        ck("interpart expression follows the value too", st["hole_x"].Value, 14.0)
        nxa.set_work(None)
        nxa.move_component(assy, pcb_c, (3, 0, 0))
        nxh.update()
        ck("move_component: PCB origin x", nxa.frame(pcb_c)[0][0], 13.0)
        ct("PCB COMPONENT moved +3: bosses follow (arc-centre points)", bosses() == [(27.0, 15.0), (63.0, 35.0)], bosses())
        ck("PCB component moved: linked body follows (xmin 13)", nxh.bbox(st["linked"])[0], 13.0)
        ck("PCB component moved: the interpart expression does NOT see it (still 14)", st["hole_x"].Value, 14.0)
        ck("offset_point follows the source hole and the component move (x = 13 + 14 + 4)", st["q"].Coordinates.X, 31.0)
        ck("datum plane on the linked face follows the component move (x 75)", st["dp"].Origin.X, 75.0)
        ct("sketch on the linked point follows the component move (recess axis)", cyl_axes(st["base"], 2.0) == [(63.0, 35.0)],
           cyl_axes(st["base"], 2.0))
        nxh.set_expr(wp, "pt_off", 6)
        nxa.set_work(pcb_c)
        nxh.set_expr(pcb, "hole2_x", 46)
        nxh.set_expr(pcb, "pcb_len", 66)
        nxh.update()
        nxa.set_work(None)
        nxh.update()
        vols = {"work part = assembly": {k: round(nxh.volume(wp, b), 4) for k, b in st["covers"].items()}}
        nxa.set_work(st["base_c"])
        nxh.update()
        vols["work part = designed part"] = {k: round(nxh.volume(wp, b), 4) for k, b in st["covers"].items()}
        # PCB at x 13..79 grown by 0.2 now leaves the cover (x 5..75): the cavity is an open slot 12.8..75
        want66 = 10500 - ((75 - 12.8) * 40.4 * 2.0 - 2 * math.pi * 1.3 ** 2 * 2.0)
        vols["want"] = round(want66, 4)
        res["notes"]["subtract_chain_after_pcb_len_66"] = vols
        nxa.set_work(None)
        ct("out of MODEL = no occurrence in the assembly (default linked copy, excluded cover); bodies in MODEL have one",
           st["base_c"].FindOccurrence(st["linked"]) is None and st["base_c"].FindOccurrence(st["covers"]["out of MODEL"]) is None
           and st["base_c"].FindOccurrence(st["covers"]["in MODEL"]) is not None and st["base_c"].FindOccurrence(st["base"]) is not None)
        ck("offset_point follows its own expression 4 -> 6", st["q"].Coordinates.X, 33.0)
        ck("datum plane on the linked face follows the source dimension pcb_len 60 -> 66 (x 81)", st["dp"].Origin.X, 81.0)
        ct("sketch on the linked point follows the source dimension hole2_x 50 -> 46", cyl_axes(st["base"], 2.0) == [(59.0, 35.0)],
           cyl_axes(st["base"], 2.0))
        ct("bosses follow hole2_x too", bosses() == [(27.0, 15.0), (59.0, 35.0)], bosses())
        ck("LINKED_BODY > OFFSET_REGION > SUBTRACT follows pcb_len 60 -> 66 and the move (tool link in MODEL)",
           nxh.volume(wp, st["covers"]["in MODEL"]), want66, 1e-3)
        ck("the same chain with the tool link taken OUT of MODEL first: identical", nxh.volume(wp, st["covers"]["out of MODEL"]),
           want66, 1e-3)
        ck("solids in the designed part: base, two covers and the first linked copy", len(nxh.solids(wp)), 4, 0)
        res["notes"]["topdown.feature_errors"] = nxh.feature_errors(wp)
    case("links follow source edits and component moves", c_follow)

    def c_work_part():
        """What works on a component's part while the ASSEMBLY is the work part (display part = assembly)."""
        nxa.set_work(None)
        wp, base = st["wp"], st["base"]
        m = {}

        def t(label, fn):
            mk = nxh.mark("probe " + label, False)
            try:
                m[label] = "ok: %s" % (fn(),)
            except Exception as e:  # noqa: BLE001
                m[label] = "ERR " + str(e)[:200]
            try:
                nxh.undo_to(mk)
            except Exception:  # noqa: BLE001
                pass
        v_true = nxh.volume(wp, base)
        t("measure: nxh.volume", lambda: round(nxh.volume(wp, base), 4))
        t("measure: nxh.dist_to", lambda: round(nxh.dist_to(wp, base, (40, 25, 5)), 6))
        t("measure: nxh.face_at", lambda: len(nxh.face_at(wp, base, (40, 25, 0))))
        t("measure: nxh.feature_errors", lambda: nxh.feature_errors(wp))
        t("measure: nxh.body_ok (Examine Geometry)", lambda: nxh.body_ok(wp, base))
        t("edit: nxh.set_expr + update on an existing expression", lambda: (nxh.set_expr(wp, "gap", 2.5), nxh.update(),
                                                                          wp.Expressions.FindObject("gap").Value)[2])
        t("create: nxh.expr", lambda: nxh.expr(wp, "probe_e", 3).Value)
        t("create: nxh.block", lambda: [nxh.block(wp, (200, 0, 0), (5, 5, 5))[1].OwningPart.Name, "work part " + S.Parts.Work.Name])
        t("create: nxh.datum_plane", lambda: round(nxh.datum_plane(wp, (0, 0, 9), (0, 0, 1))[1].Origin.Z, 3))
        t("lookup: nxh.Datums(part)", lambda: type(nxh.Datums(wp).xy).__name__)
        t("create: nxf.datum_plane offset from a body face", lambda: round(nxf.datum_plane(
            wp, "offset", [nxh.faces(base, ftype=nxh.PLANE, normal=(0, 0, -1))[0]], 1)[1].Origin.Z, 3))
        t("create: nxh.extrude of a section", lambda: nxh.extrude(wp, nxh.section(wp, curves=nxh.rect(wp, 200, 0, 210, 10, 0.0),
                                                                                     help_point=(200, 0, 0)), (0, 0, 1), 0, 5).FeatureType)
        t("create: nxh.blend (edge collector)", lambda: nxh.blend(wp, nxh.edges_at(base, 2, -2.0)[:1], 0.5).FeatureType)
        t("create: nxf.offset_region (face collector)", lambda: nxf.offset_region(
            wp, nxh.faces(base, ftype=nxh.PLANE, normal=(0, 0, -1)), 1).FeatureType)
        t("create: nxf.hole", lambda: round(v_true - (nxf.hole(wp, base, [(40, 25, 0)], 2, 1, vector=(0, 0, -1)), nxh.volume(wp, base))[1], 4))
        res["notes"]["work_part_matrix (work part = assembly, target = component part)"] = m
        ck("non-work part: nxh.volume is right", float(m["measure: nxh.volume"].split(": ")[1]) if m["measure: nxh.volume"].startswith("ok") else None,
           v_true, 1e-3)
        ct("non-work part: nxh.dist_to is right (5.0)", m["measure: nxh.dist_to"] == "ok: 5.0", m["measure: nxh.dist_to"])
        ct("non-work part: nxh.face_at finds the face", m["measure: nxh.face_at"] == "ok: 1", m["measure: nxh.face_at"])
        ct("non-work part: Examine Geometry runs", m["measure: nxh.body_ok (Examine Geometry)"] == "ok: True",
           m["measure: nxh.body_ok (Examine Geometry)"])
        ct("non-work part: expressions can be created and edited", m["create: nxh.expr"] == "ok: 3.0"
           and m["edit: nxh.set_expr + update on an existing expression"] == "ok: 2.5", m["create: nxh.expr"])
        ct("non-work part: a Block asked for in the component's part is created in the WORK part (the assembly)",
           m["create: nxh.block"].startswith("ok: ['nxa_td_asm'"), m["create: nxh.block"])
        ct("non-work part: features with a section are refused ('Creating an interpart section is not allowed.')",
           "interpart section" in m["create: nxf.hole"] and "interpart section" in m["create: nxh.extrude of a section"], m["create: nxf.hole"])
        ct("non-work part: features with a collector are refused (blend, offset region)",
           m["create: nxh.blend (edge collector)"].startswith("ERR") and m["create: nxf.offset_region (face collector)"].startswith("ERR"),
           m["create: nxh.blend (edge collector)"])
        ct("non-work part: nxh.Datums(part) fails", m["lookup: nxh.Datums(part)"].startswith("ERR"), m["lookup: nxh.Datums(part)"])
        ck("non-work part: probes rolled back (base volume unchanged)", nxh.volume(wp, base), v_true, 1e-6)
        ck("non-work part: nothing left behind in the assembly part", len(list(assy.Bodies)), 0, 0)
    case("work-part requirements", c_work_part)
    nxa.set_work(None)
    nxh.save(assy)

    def c_reopen():
        nxh.close_all()
        a2 = nxh.open_part(asm_path)
        comps = nxa.components(a2)
        ct("components after reopen", sorted(comps) == ["BASE", "PCB"], sorted(comps))
        pcb2, wp2 = comps["PCB"].Prototype, comps["BASE"].Prototype
        res["notes"]["reopen.fully_loaded_before"] = {"pcb": pcb2.IsFullyLoaded, "base": wp2.IsFullyLoaded}
        ct("reopened components are partially loaded", not wp2.IsFullyLoaded, res["notes"]["reopen.fully_loaded_before"])
        loaded = nxa.load_fully([comps["PCB"], comps["BASE"]])
        res["notes"]["reopen.load_fully"] = loaded
        ct("load_fully: both parts fully loaded", pcb2.IsFullyLoaded and wp2.IsFullyLoaded and "nxa_td_base" in [n.lower() for n in loaded], loaded)
        base2 = max(nxh.solids(wp2), key=lambda b: nxh.volume(wp2, b))
        ct("reopened: bosses as saved", cyl_axes(base2, 3.0) == [(27.0, 15.0), (59.0, 35.0)], cyl_axes(base2, 3.0))
        nxh.set_expr(pcb2, "hole_x", 18)
        nxh.update()
        ct("after load_fully a PCB edit (hole_x 18) reaches the base", cyl_axes(base2, 3.0) == [(31.0, 15.0), (59.0, 35.0)],
           cyl_axes(base2, 3.0))
        st.update(assy=a2, comps=comps)
    case("reopen / load_fully", c_reopen)

    def c_step():
        a2, comps = st["assy"], st["comps"]
        stp = os.path.join(OUT, "nxa_td_asm.stp")
        wp2 = comps["BASE"].Prototype
        part_stp = os.path.join(OUT, "nxa_td_base.stp")
        nxf.step_export(wp2, part_stp)
        n_part = open(part_stp, errors="ignore").read().count("MANIFOLD_SOLID_BREP")
        res["notes"]["step.base_part"] = {"solids_in_part": len(nxh.solids(wp2)), "manifold_solid_brep": n_part,
                                           "sheets_in_part": len(nxh.sheets(wp2))}
        rb = nxf.step_roundtrip_check(part_stp, OUT, "nxa_rt_base", restore=a2, part=wp2)
        st["rb"] = {"volumes": [round(v, 3) for v in rb["volumes"]], "expected": [round(v, 3) for v in rb["expected"]],
                    "match": rb["match"], "part_solids": sorted(round(nxh.volume(wp2, b), 3) for b in nxh.solids(wp2)),
                    "blanked": [b.IsBlanked for b in nxh.solids(wp2)], "layers": [b.Layer for b in nxh.solids(wp2)]}
        r = nxa.step_roundtrip(a2, stp, OUT, "nxa_rt")
        res["notes"]["step_roundtrip"] = {k: r[k] for k in ("schema", "manifold_solid_brep", "assembly", "solids", "volume", "instances",
                                                            "expected", "per_body", "max_rel", "match", "healthy", "restored")}
        ct("step_roundtrip: the STEP imports as an assembly (components, not bodies)", r["assembly"] is True, r["bodies"])
        ck("step_roundtrip: leaf instances", len(r["instances"]), 2, 0)
        res["notes"]["step.base_part"]["roundtrip"] = st.get("rb")
        ck("assembly STEP writes only reference-set members (PCB 1 + BASE: base and the cover kept in MODEL)", r["solids"], 3, 0)
        ct("step_roundtrip: every body agrees with the model within 1e-4", r["match"] is True, r["per_body"])
        ct("step_roundtrip: Examine Geometry clean", r["healthy"], r["examine"])
        pcb_row = [i for i in r["instances"] if "pcb" in i[1].lower()]
        ck("step_roundtrip: PCB instance position x kept (13)", pcb_row[0][2][0] if pcb_row else None, 13.0)
        ct("step_roundtrip: work part restored to the assembly", r["restored"] and S.Parts.Work.Tag == a2.Tag)
    case("assembly STEP round trip", c_step)

    def c_link_curve():
        # skeleton part without a solid: a driven line, WAVE-linked into the next part and used as a pattern path
        nxh.close_all()
        a3 = nxa.new_assembly(os.path.join(OUT, "nxa_lc_asm.prt"))
        nxh.save(a3)
        skel_c = nxa.new_component(a3, os.path.join(OUT, "nxa_lc_skeleton.prt"), "SKELETON")
        link_c = nxa.new_component(a3, os.path.join(OUT, "nxa_lc_links.prt"), "LINKS")
        skel, lp = skel_c.Prototype, link_c.Prototype
        nxa.set_work(skel_c)
        nxh.expr(skel, "path_len", 60)
        D = nxh.Datums(skel)
        sk = nxf.new_sketch(skel, D.xy, D.x, D.origin, "SKEL_PATH")
        ln = nxh.line(skel, (0, 0, 0), (60, 0, 0))
        nxf.add(sk, ln)
        nxf.horizontal(sk, ln)
        sk.CreateCoincidentConstraint(nxf.cg(ln, nxf.CP.StartVertex), nxf.cg(D.origin))
        nxf.pdim(sk, D.y, nxh.P(0, 0, 0), ln, nxf.A.EndPoint, nxh.P(30, 10, 0), "path_len")
        ck("link_curve: skeleton sketch DOF", nxf.finish_sketch(sk)["dof"], 0, 0)
        nxa.set_work(link_c)
        lf = nxa.link_curve(lp, [c for c in sk.GetAllGeometry() if isinstance(c, NXOpen.Line)][0])
        ct("link_curve: LINKED_CURVE, not broken", lf.FeatureType == "LINKED_CURVE" and nxh.link_status(lf).get("broken") is False,
           [lf.FeatureType, nxh.link_status(lf)])
        f1, link = nxh.block(lp, (-4, -3, 0), (8, 6, 3))
        nxf.pattern_along(lp, [f1], [lf], lf.GetEntities()[0], (0, 0, 0), "4")

        def xs():
            x0 = nxh.mass(lp, [link])["centroid"][0]
            return sorted(round(nxh.mass(lp, [s])["centroid"][0] - x0, 3) for s in nxh.solids(lp))
        ct("link_curve + pattern_along: 4 links at pitch 20 along the linked line", xs() == [0.0, 20.0, 40.0, 60.0], xs())
        nxa.set_work(None)
        nxh.set_expr(skel, "path_len", 90)
        nxh.update()
        ct("link_curve: an edit of the skeleton (60 -> 90) moves the links to pitch 30",
           xs() == [0.0, 30.0, 60.0, 90.0] and not nxh.feature_errors(lp), [xs(), nxh.feature_errors(lp)])
    case("link_curve (skeleton part)", c_link_curve)


try:
    os.makedirs(OUT, exist_ok=True)
    for name, fn in (("constraints", g_constraints), ("topdown", g_topdown)):
        group(name, fn)
    if not ONLY:
        missing = sorted(set(PUBLIC) - CALLED)
        ct("coverage: every public nxa function was exercised (%d)" % len(PUBLIC), not missing, missing)
except Exception:  # noqa: BLE001
    res["errors"]["fatal"] = traceback.format_exc()
    chk.true("no fatal exception", False)
final = flush()
log("RESULT", final["result"], "checks", len(final["checks"]), "failed", [c["name"] for c in final["checks"] if not c["ok"]])
