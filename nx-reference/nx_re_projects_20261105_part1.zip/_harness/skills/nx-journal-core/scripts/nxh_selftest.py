import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import nxh  # noqa: E402

OUT = sys.argv[1]
res = {}
chk = nxh.Check()
try:
    part = nxh.new_part(os.path.join(OUT, "nxh_selftest.prt"))
    f, body = nxh.block(part, (0, 0, 0), (60, 40, 20))
    chk("block volume", nxh.volume(part, body), 48000.0, 1e-6)
    # sheet extrude of a closed rectangle
    sec = nxh.section(part, curves=nxh.rect(part, 100, 0, 130, 20, 0.0), help_point=(100, 0, 0))
    before = list(part.Bodies)
    nxh.extrude(part, sec, (0, 0, 1), 0, 10, sheet=True)
    sh = nxh.new_bodies(part, before)[0]
    chk.true("sheet body", not sh.IsSolidBody)
    area, per = nxh.sheet_area(part, sh)
    chk("sheet area", area, 2 * (30 + 20) * 10, 1e-4)
    chk("mass() on sheet -> area", nxh.mass(part, [sh])["area"], 1000.0, 1e-4)
    chk("free edges of open tube sheet", len(nxh.free_edges(sh)), 8, 0)
    chk("dist to top face plane", nxh.dist_to(part, body, (30, 20, 25)), 5.0, 1e-6)
    top = nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1)), "top face")
    n = nxh.normal_at(top, (30, 20, 20))
    chk("normal z", n[2], 1.0, 1e-9)
    amb, err = nxh.attempt("ambiguous query", nxh.one, nxh.faces(body, ftype=nxh.PLANE), "any planar face")
    chk.true("one() refuses a query with 6 matches", amb is None and "got 6" in str(err), err)
    # disjoint unite must raise through the guard
    _f2, far = nxh.block(part, (200, 0, 0), (10, 10, 10))
    out, err = nxh.attempt("disjoint unite", nxh.unite, part, body, [far])
    chk.true("disjoint unite refused", out is None and err is not None, err)
    chk("solids after refused unite", len(nxh.solids(part)), 2, 0)
    # overlapping unite passes
    _f3, near = nxh.block(part, (50, 0, 0), (20, 40, 20))
    nxh.unite(part, body, [near])
    chk("united volume", nxh.volume(part, body), 70 * 40 * 20, 1e-6)
    chk("min_dist bodies", nxh.min_dist(body, far), 130.0, 1e-6)
    import NXOpen
    v_before = nxh.volume(part, body)
    nxh.block(part, (0, 0, 15), (10, 10, 5), NXOpen.Features.Feature.BooleanType.Subtract, body)
    chk("block subtract", v_before - nxh.volume(part, body), 500.0, 1e-6)
    _f5, pin = nxh.cylinder(part, (30, 20, 10), (0, 0, 1), 6, 30)
    nxh.unite(part, body, tool_features=[_f5])
    chk("unite by feature rule: solids", len(nxh.solids(part)), 2, 0)
    hc = nxh.hole_census(part, body)
    res["hole_census"] = {k: (len(v) if isinstance(v, list) else v) for k, v in hc.items()}
    chk("hole census: bosses found (the united pin)", len(hc["bosses"]), 1, 0)
    f6, _b = nxh.cylinder(part, (10, 30, 0), (0, 0, 1), 8, 20, nxh.BOOL.Subtract, body)
    hc = nxh.hole_census(part, body)
    chk("hole census: one hole", len(hc["holes"]), 1, 0)
    chk("hole census: diameter", hc["holes"][0]["diameter"], 8.0, 1e-6)
    eg = nxh.examine_geometry(part, body)
    res["examine_solid"] = eg
    chk.true("examine geometry healthy solid", nxh.body_ok(part, body), eg)
    eg2 = nxh.examine_geometry(part, sh)
    res["examine_sheet"] = eg2
    chk.true("open sheet has boundaries", eg2.get("BodySheetBoundaries", 0) > 0, eg2)
    ev = nxh.edges(body, lambda b: abs(b[5] - b[2] - 20) < 1e-6)
    bad, err = nxh.attempt("deliberately failing blend", nxh.blend, part, ev[:1], 500)
    chk.true("failing blend rolled back", bad is None and err is not None, err)
    _f7, _b7 = nxh.block(part, (300, 0, 0), (5, 5, 5), nxh.BOOL.Create)
    res["stale_raw"] = nxh.feature_errors(part, recheck=False)
    res["errors"] = nxh.feature_errors(part)
    chk.true("stale message cleared by recheck", not res["errors"], res["errors"])
    # names a person typed against NX's own name patterns; expressions are read BEFORE measuring
    system = ["p12", "p12_x", "p7_z", "p8_CircularPattern_pattern_Circular_Dir_count", "Pattern_p12", "ASSO_BLEND_3",
              "Sheet_Metal_Bend_Radius", "SM_Validation_MIN_WEB_LENGTH"]
    typed = ["wall_t", "d_bore", "BODY_EXTRUDE_END", "alpha", "D_Out", "pitch", "p", "plate_w", "ASSO_BLEND", "Pattern"]
    chk.true("user_named: system names rejected", not any(nxh.user_named(n) for n in system), [n for n in system if nxh.user_named(n)])
    chk.true("user_named: typed names accepted", all(nxh.user_named(n) for n in typed), [n for n in typed if not nxh.user_named(n)])
    nxh.expr(part, "wall_t", 2.5, "mm")
    pt = nxh.point(part, "wall_t", 0, 0)                               # makes system expressions for its coordinates
    n_before = len([e for e in part.Expressions])
    chk.true("user_expressions: only the typed one", [e.Name for e in nxh.user_expressions(part)] == ["wall_t"],
             [e.Name for e in nxh.user_expressions(part)])
    nxh.volume(part, body)
    nxh.hole_census(part, body)                                        # its ResizeBlendBuilder used to leave p<n>=5 behind
    chk("volume + hole_census leave no stray expression", len([e for e in part.Expressions]) - n_before, 0, 0)
    # top-level history steps against all rows: a 3-point hole pattern has internal child rows
    import nxf
    n_all0 = len(part.Features.GetFeatures())
    nxf.hole(part, body, [(40, 5, 20), (50, 5, 20), (60, 5, 20)], 3, depth=4, vector=(0, 0, -1))
    top_rows, n_internal = nxh.top_features(part)
    n_all = len(part.Features.GetFeatures())
    res["rows"] = {"all": n_all, "top": len(top_rows), "internal": n_internal}
    chk("top_features: one Hole feature added 1 top-level row", len([f for f in top_rows if f.FeatureType == "HOLE PACKAGE"]), 1, 0)
    chk("top_features: 3 internal SIMPLE HOLE rows", len([f for f in part.Features.GetFeatures() if f.FeatureType == "SIMPLE HOLE" and nxh.is_internal(f)]), 3, 0)
    chk("top_features: top + internal = all rows", len(top_rows) + n_internal, n_all, 0)
    chk.true("top_features: 4 rows were added for one feature", n_all - n_all0 == 4, n_all - n_all0)
    # boolean with a SHEET target: the result is one sheet per remaining piece and must pass the guard
    _f8, frame_blk = nxh.block(part, (400, 0, 0), (40, 40, 10))
    nxh.block(part, (410, 10, 0), (20, 20, 10), NXOpen.Features.Feature.BooleanType.Subtract, frame_blk)      # through window
    before = list(part.Bodies)
    nxf.bounded_plane(part, curves=nxh.rect(part, 390, -10, 450, 50, 5.0), hp=(390, -10, 5))
    cut_sheet = nxh.new_bodies(part, before)[0]
    nxh.subtract(part, cut_sheet, [frame_blk], keep_tool=True)                                               # check=True (default)
    pieces = [s for s in nxh.sheets(part) if nxh.bbox(s)[0] > 380]
    areas = sorted(round(nxh.sheet_area(part, s)[0], 4) for s in pieces)
    chk.true("subtract, sheet target minus a kept solid: passes the guard, window patch 400 + outer frame 2000", areas == [400.0, 2000.0], areas)
    chk("subtract, sheet target: the kept solid tool is unchanged", nxh.volume(part, frame_blk), 12000.0, 1e-6)
    _f9, miss = nxh.block(part, (600, 0, 20), (10, 10, 10))
    out, err = nxh.attempt("sheet minus a solid that misses it", nxh.subtract, part, max(pieces, key=lambda s: nxh.sheet_area(part, s)[0]), [miss],
                           keep_tool=True)
    chk.true("subtract, sheet target: a tool that misses the sheet is still refused", out is None and err is not None, err)
    res["sheet_target_miss_error"] = err
    # hole_census on axes inclined to X, Y, Z: an oblique through hole, an oblique boss, a half-round groove
    c60, s60 = 0.5, math.sqrt(3.0) / 2.0
    _f10, slab = nxh.block(part, (700, 0, 0), (60, 40, 20))
    nxh.cylinder(part, (715, 20, -10 * s60), (c60, 0, s60), 8, 50, nxh.BOOL.Subtract, slab)               # through, 60 deg to the plate
    nxh.cylinder(part, (760, 10, -10 * s60), (0, c60, s60), 8, 50, nxh.BOOL.Subtract, slab)               # axis in the end face: half groove
    nxh.cylinder(part, (748, 30, 10), (0, -c60, s60), 10, 20, nxh.BOOL.Unite, slab)                       # inclined boss sticking out
    hc = nxh.hole_census(part, slab)
    res["inclined_census"] = {k: [{"d": round(h["diameter"], 3), "axis": [round(v, 4) for v in h["axis"]], "length": round(h["length"], 3),
                                   "coverage": round(h["coverage"], 3)} for h in hc[k]] for k in ("holes", "bosses", "partial")}
    inc = [h for h in hc["holes"] if abs(h["diameter"] - 8.0) < 1e-6]
    chk.true("hole_census, inclined axis: the oblique through hole is a HOLE (full wrap), not 'partial'", len(inc) == 1 and inc[0]["coverage"] > 0.99,
             res["inclined_census"])
    if inc:
        chk("hole_census, inclined axis: axis direction (0.5, 0, 0.866)", abs(sum(a * b for a, b in zip(inc[0]["axis"], (c60, 0, s60)))), 1.0, 1e-6)
        chk("hole_census, inclined axis: length = t / sin 60 + d / tan 60", inc[0]["length"], 20 / s60 + 8 * c60 / s60, 0.05)
    chk.true("hole_census, inclined axis: the united inclined cylinder is a BOSS", [round(h["diameter"], 3) for h in hc["bosses"]] == [10.0],
             res["inclined_census"]["bosses"])
    # face_mid_normal: point ON the face and OUTWARD normal, also where the UV middle is in a hole of the face
    _f11, fm = nxh.block(part, (800, 0, 0), (40, 30, 20))
    nxh.cylinder(part, (820, 15, 0), (0, 0, 1), 10, 20, nxh.BOOL.Subtract, fm)                           # hole through the middle
    nxh.cylinder(part, (808, 8, 20), (0, 0, 1), 6, 5, nxh.BOOL.Unite, fm)                                # boss on top
    ftop = nxh.one(nxh.faces(fm, ftype=nxh.PLANE, normal=(0, 0, 1), at=(2, 20.0)), "top with the hole")
    p, n = nxh.face_mid_normal(ftop)
    chk.true("face_mid_normal: top face with a hole in its middle - the point is ON the face, normal +Z",
             abs(p[2] - 20) < 1e-9 and math.hypot(p[0] - 820, p[1] - 15) > 5.0 and abs(n[2] - 1.0) < 1e-9, [p, n])
    p, n = nxh.face_mid_normal(nxh.one(nxh.faces(fm, ftype=nxh.PLANE, normal=(0, 0, -1)), "bottom"))
    chk("face_mid_normal: bottom face normal -Z", n[2], -1.0, 1e-9)
    p, n = nxh.face_mid_normal(nxh.one(nxh.faces(fm, ftype=nxh.CYLINDER, radius=5.0), "hole wall"))
    chk("face_mid_normal: hole wall - outward from the material = towards the hole axis",
        (n[0] * (p[0] - 820) + n[1] * (p[1] - 15)) / 5.0, -1.0, 1e-6)
    p, n = nxh.face_mid_normal(nxh.one(nxh.faces(fm, ftype=nxh.CYLINDER, radius=3.0), "boss wall"))
    chk("face_mid_normal: boss wall - away from the boss axis", (n[0] * (p[0] - 808) + n[1] * (p[1] - 8)) / 3.0, 1.0, 1e-6)
    half = [h for h in hc["partial"] if abs(h["diameter"] - 8.0) < 1e-6]
    chk.true("hole_census, inclined axis: the half-round groove in the end face is 'partial' (half wrap)",
             len(half) == 1 and abs(half[0]["coverage"] - 0.5) < 0.02, res["inclined_census"]["partial"])

    # whole-sketch section: an ACTIVE sketch point besides the closed profile is taken in (section() allows points)
    dat = nxh.Datums(part)
    skp = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "SK_WITH_POINT")
    prof = nxf.hv_polygon(part, skp, [(900, 0), (920, 0), (920, 10), (900, 10)])
    nxf.add(skp, part.Points.CreatePoint(nxh.P(910, 5, 0)), infer=False)
    nxf.finish_sketch(skp)
    out, err = nxh.attempt("whole sketch with a point", lambda: nxh.extrude(part, nxh.section_feature(part, [skp.Feature]), (0, 0, 1), 0, 5))
    res["section_feature_with_point_error"] = err
    chk.true("section_feature: a sketch with an active Point besides its profile - Extrude is refused", out is None and "Cannot extrude" in str(err), err)
    fp = nxh.extrude(part, nxh.section_feature(part, [skp.Feature], curves_only=True), (0, 0, 1), 0, 5)
    chk("section_feature(curves_only=True): the point is left out, 20 x 10 x 5", nxh.volume(part, fp.GetBodies()[0]), 1000.0, 1e-6)
    fp = nxh.extrude(part, nxh.section_region(part, skp, (910, 5, 0), curves=prof), (0, 0, 1), 0, 5)
    chk("section_region(curves=profile lines): the point is left out", nxh.volume(part, fp.GetBodies()[0]), 1000.0, 1e-6)

    # ---- editing in the middle of the tree: insert point, suppression flags, reorder, wall partners (own parts)
    def vedges(b):
        return nxh.edges(b, lambda bb: abs(bb[0] - bb[3]) < 1e-3 and abs(bb[1] - bb[4]) < 1e-3 and bb[5] - bb[2] > 1.0)

    def the_body(p):
        return nxh.solids(p)[0]

    pt2 = nxh.new_part(os.path.join(OUT, "nxh_selftest_tree.prt"))
    fb, b2 = nxh.block(pt2, (0.0, 0.0, 0.0), (80, 60, 30))
    fmid = nxh.blend(pt2, vedges(b2)[:1], 4)                              # an abandoned attempt in the MIDDLE of the tree
    pt2.Features.SuppressFeatures([fmid])
    fsh = nxf.shell(pt2, the_body(pt2), nxh.faces(the_body(pt2), ftype=nxh.PLANE, at=(2, 30.0)), 2)
    fh, _b = nxh.cylinder(pt2, (40, 30, 0), (0, 0, 1), 10, 2, nxh.BOOL.Subtract, the_body(pt2))
    ftail, _b = nxh.cylinder(pt2, (20, 30, 0), (0, 0, 1), 6, 2, nxh.BOOL.Subtract, the_body(pt2))   # a suppressed TAIL
    pt2.Features.SuppressFeatures([ftail])
    nxh.update()
    v_sharp = 80 * 60 * 30 - 76 * 56 * 28 - math.pi * 25 * 2
    chk("insert point: start state (sharp shelled box with a floor hole)", nxh.volume(pt2, the_body(pt2)), v_sharp, 1e-6)
    chk.true("history_mode: a new part is in history mode", nxh.history_mode(pt2) is True)
    chk.true("current_feature: the last feature of the tree, although it is suppressed", nxh.current_feature(pt2).Tag == ftail.Tag,
             nxh.current_feature(pt2).GetFeatureName())
    chk.true("suppress_status: active 0, suppressed by a person 1", (nxh.suppress_status(fsh)["code"], nxh.suppress_status(fmid)["code"]) == (0, 1),
             [nxh.suppress_status(fsh), nxh.suppress_status(fmid)])
    chk("rolled_back: nothing in a normal part", len(nxh.rolled_back(pt2)), 0, 0)
    with nxh.insert_after(pt2, fb) as ip:
        inside = {"shell": nxh.suppress_status(fsh), "mid": nxh.suppress_status(fmid), "n_rolled": len(nxh.rolled_back(pt2)),
                  "flag": bool(fsh.Suppressed), "v": nxh.volume(pt2, the_body(pt2)), "current": nxh.current_feature(pt2).Tag == fb.Tag}
        fnew = nxh.blend(pt2, vedges(the_body(pt2)), 8)
    res["insert_inside"] = {k: (v if not isinstance(v, dict) else v["code"]) for k, v in inside.items()}
    res["insert_report"] = ip.report
    chk.true("insert_after: inside, the Shell reads Suppressed although nobody suppressed it (code 16 = rolled back)",
             inside["flag"] and inside["shell"]["code"] == 16 and inside["shell"]["rolled_back"] and not inside["shell"]["suppressed"], inside["shell"])
    chk.true("insert_after: inside, a feature a person suppressed reads 17 (1 + 16)", inside["mid"]["code"] == 17, inside["mid"])
    chk("insert_after: inside, 4 features wait behind the insert point", inside["n_rolled"], 4, 0)
    chk("insert_after: inside, the body is the plain block again", inside["v"], 144000.0, 1e-6)
    chk.true("insert_after: inside, the current feature is the insert point", inside["current"])
    chk.true("insert_after: report - exactly one feature added, nothing changed / gone / in error",
             len(ip.report["added"]) == 1 and not ip.report["changed"] and not ip.report["gone"] and not ip.report["errors"], ip.report)
    v_round = (80 * 60 - (4 - math.pi) * 64) * 30 - (76 * 56 - (4 - math.pi) * 36) * 28 - math.pi * 25 * 2
    chk("insert_after: blend R8 inserted BEFORE the Shell - closed-form volume (inner corners R6)", nxh.volume(pt2, the_body(pt2)), v_round, 1e-6)
    o8 = [f for f in nxh.faces(the_body(pt2), ftype=nxh.CYLINDER, radius=8.0) if nxh.bbox(f)[0] > 40 and nxh.bbox(f)[1] > 30][0]
    chk("wall_thickness: 2.000 behind the outer corner blend (the Shell offset the new blend)", nxh.wall_thickness(o8), 2.0, 1e-6)
    pr = nxh.wall_partners([o8])
    chk.true("wall_partners: the partner of the R8 corner is the R6 corner", len(pr) == 1 and abs(abs(nxh.face_data(pr[0])[3]) - 6.0) < 1e-6, len(pr))
    chk.true("insert_after: the two user-suppressed features are still suppressed (code 1), the others active",
             [nxh.suppress_status(f)["code"] for f in (fmid, fsh, fh, ftail)] == [1, 0, 0, 1], [nxh.suppress_status(f)["code"] for f in (fmid, fsh, fh, ftail)])
    chk.true("insert_after: the new feature sits right after the insert point; later ones are renumbered",
             fnew.Timestamp == fb.Timestamp + 1 and fsh.Timestamp == fb.Timestamp + 3, [fb.Timestamp, fnew.Timestamp, fsh.Timestamp, fsh.GetFeatureName()])
    chk.true("current_feature: back at the end of the tree", nxh.current_feature(pt2).Tag == ftail.Tag)
    # an insertion that breaks a later feature is undone: a through bore where the floor hole will be cut
    state0 = nxh.feature_state(pt2)
    msg = ""
    try:
        with nxh.insert_after(pt2, fb):
            nxh.cylinder(pt2, (40, 30, 0), (0, 0, 1), 30, 30, nxh.BOOL.Subtract, the_body(pt2))
    except RuntimeError as e:
        msg = str(e)
    res["insert_refused"] = msg[:400]
    chk.true("insert_after: an insertion that breaks a later feature raises and is undone", "undone" in msg, msg[:200])
    d0 = nxh.state_diff(state0, nxh.feature_state(pt2))
    chk.true("insert_after: after the refusal the tree is as before (by tag)", not d0["added"] and not d0["changed"] and not d0["gone"], d0)
    chk("insert_after: after the refusal the volume is as before", nxh.volume(pt2, the_body(pt2)), v_round, 1e-6)
    # an exception inside the block undoes too
    try:
        with nxh.insert_after(pt2, fb):
            nxh.blend(pt2, nxh.edges(the_body(pt2), lambda bb: abs(bb[2] - bb[5]) < 1e-6 and abs(bb[2]) < 1e-6), 3)
            raise ValueError("stop")
    except ValueError:
        pass
    chk("insert_after: an exception inside the block leaves the part as it was", nxh.volume(pt2, the_body(pt2)), v_round, 1e-6)
    chk("insert_after: ... and not rolled back", len(nxh.rolled_back(pt2)), 0, 0)
    # reorder: a Shell moved before the pad no longer hollows the pad
    pt3 = nxh.new_part(os.path.join(OUT, "nxh_selftest_reorder.prt"))
    fb3, b3 = nxh.block(pt3, (0.0, 0.0, 0.0), (80, 60, 30))
    fpad, _b = nxh.block(pt3, (20.0, 20.0, 30.0), (20, 20, 10), op=nxh.BOOL.Unite, target=b3)
    fs3 = nxf.shell(pt3, the_body(pt3), nxh.faces(the_body(pt3), ftype=nxh.PLANE, at=(2, 0.0)), 2)
    padv = [e for e in vedges(the_body(pt3)) if nxh.bbox(e)[5] > 39.0 and nxh.bbox(e)[2] > 29.0 and nxh.bbox(e)[0] in (20.0, 40.0) and nxh.bbox(e)[1] in (20.0, 40.0)]
    fbl3 = nxh.blend(pt3, padv, 1)
    v_hollow_pad = nxh.volume(pt3, the_body(pt3))
    st3 = nxh.feature_state(pt3)
    errs = nxh.reorder(pt3, fs3, fpad, after=False)
    chk.true("reorder: Shell before the pad - no feature error", not errs, errs)
    chk("reorder: the pad is solid now", nxh.volume(pt3, the_body(pt3)), (80 * 60 * 30 - 76 * 56 * 28) + 20 * 20 * 10 - 4 * (1 - math.pi / 4) * 10, 1e-6)
    chk.true("reorder: order by timestamp is block, shell, pad, blend", [f.Tag for f in sorted((fb3, fpad, fs3, fbl3), key=lambda f: f.Timestamp)] ==
             [fb3.Tag, fs3.Tag, fpad.Tag, fbl3.Tag])
    d3 = nxh.state_diff(st3, nxh.feature_state(pt3))
    chk.true("reorder: state_diff by tag is clean (only names / timestamps moved)", not d3["added"] and not d3["changed"] and not d3["gone"], d3)
    _r, why = nxh.attempt("blend before its pad", nxh.reorder, pt3, fbl3, fpad, False)
    res["reorder_refused"] = why
    chk.true("reorder: a feature cannot go before what it references", _r is None and "referenced" in str(why), why)
    nxh.reorder(pt3, fs3, fbl3, after=True)
    chk("reorder: back after the blend - the first volume again", nxh.volume(pt3, the_body(pt3)), v_hollow_pad, 1e-6)
    # edge_points / pole_count
    pt4 = nxh.new_part(os.path.join(OUT, "nxh_selftest_points.prt"))
    _f, b4 = nxh.block(pt4, (0.0, 0.0, 0.0), (60, 40, 20))
    e60 = nxh.one(nxh.edges(b4, lambda bb: abs(bb[3] - bb[0] - 60) < 1e-6 and bb[1] == 0 and bb[2] == 0 and bb[4] == 0 and bb[5] == 0), "edge along x")
    pts = nxh.edge_points(e60, 5)
    chk.true("edge_points: 5 points with the ends, 15 apart", len(pts) == 5 and sorted(round(p[0], 6) for p in pts) == [0.0, 15.0, 30.0, 45.0, 60.0], pts)
    pts = nxh.edge_points(e60, 5, ends=False)
    chk.true("edge_points: ends=False leaves the vertices out (10 .. 50)", sorted(round(p[0], 6) for p in pts) == [10.0, 20.0, 30.0, 40.0, 50.0], pts)
    EB = NXOpen.Features.EdgeBlendBuilder
    bb4 = pt4.Features.CreateEdgeBlendBuilder(nxh.NULL_FEATURE)
    try:                                                                  # a conic-section blend is a B-surface face
        bb4.AddChainset(nxh.collector(pt4, edges=vedges(b4)[:1]), EB.Section.Conic, EB.Conic.BoundaryPlusCenter, EB.Rhotype.Relative, "5", "3.33", "0.6")
        bb4.Tolerance = 0.01
        bb4.CommitFeature()
    finally:
        bb4.Destroy()
    bs = nxh.faces(b4, ftype=nxh.BSURF)
    n_feat = len(pt4.Features.GetFeatures())
    n_poles = nxh.pole_count(pt4, bs[0]) if bs else None
    res["pole_count"] = n_poles
    chk.true("pole_count: a B-surface blend face has poles (>= 4)", n_poles is not None and n_poles >= 4, n_poles)
    chk("pole_count: the helper leaves no feature behind", len(pt4.Features.GetFeatures()), n_feat, 0)
    # curve measurement (from the curves package's curvekit)
    arc = nxh.arc(pt4, (100, 0, 0), (1, 0, 0), (0, 1, 0), 10.0, 0.0, math.pi / 2)
    ln1 = nxh.line(pt4, (110, 0, 0), (110, -30, 0))                       # tangent to the arc at its start
    ln2 = nxh.line(pt4, (100, 10, 0), (100, 40, 0))                       # square to the arc at its end
    q = nxh.curve_quality(arc)
    res["curve_quality_arc"] = {k: q[k] for k in ("inflections", "peaks", "k_max", "r_min", "torsion_max", "length")}
    chk.true("curve_quality: quarter arc R10 - no inflection, no peak, r_min 10, planar, length 5 pi",
             q["inflections"] == 0 and q["peaks"] == 0 and abs(q["r_min"] - 10) < 1e-6 and q["torsion_max"] < 1e-9
             and abs(q["length"] - 5 * math.pi) < 1e-6, res["curve_quality_arc"])
    chk("curve_frame: a line has curvature 0", nxh.curve_frame(ln1, 0.5)["k"], 0.0, 1e-12)
    chk("join_angle: arc start and the tangent line", nxh.join_angle(arc, 0.0, ln1, 0.0), 0.0, 1e-6)
    chk("join_angle: arc end and a line square to it", nxh.join_angle(arc, 1.0, ln2, 0.0), 90.0, 1e-6)
    chk("planarity: arc + lines in z = 0", nxh.planarity([arc, ln1, ln2]), 0.0, 1e-9)
    ln3 = nxh.line(pt4, (100, 0, 0), (100, 0, 7))
    chk("planarity: with a line 7 out of the plane", nxh.planarity([arc, ln1, ln3]), 7.0, 1e-9)
    chk("max_dev: points on the arc / one 2 off", nxh.max_dev(pt4, arc, [(110, 0, 0), (100, 10, 0), (100 + 12 * math.sqrt(0.5), 12 * math.sqrt(0.5), 0)]), 2.0, 1e-6)
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("no exception", False)
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "nxh_selftest.json"), res)
