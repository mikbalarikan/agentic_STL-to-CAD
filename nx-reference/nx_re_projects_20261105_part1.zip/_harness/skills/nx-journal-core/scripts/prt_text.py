r"""prt_text.py - what is in an NX part, WITHOUT opening NX (read-only utility of nx-journal-core).

Stdlib only; runs under any Python 3.8+ (also inside a journal).  Never writes to a part file
(parts are opened "rb" only), needs no licence and no NX process, takes well under a second per part.

    python prt_text.py bracket.prt                  # one-page summary on stdout
    python prt_text.py bracket.prt --json out.json  # the summary as JSON
    python prt_text.py bracket.prt --full           # the complete record (class vocabulary, strings ...)

    import prt_text
    s = prt_text.read_part(r"C:\job\bracket.prt")   # the summary dict
    s["feature_types"]   {"EXTRUDE": 4, "BLEND": 2, ...}     exact counts, internal rows included
    s["expressions"]     [{"name", "rhs", "type", "unit", "comment", "user_named"}, ...]
    s["components"]      number of component instances (0 = a piece part), s["referenced_parts"]

What it gives exactly: every feature record with its type string (counts per type, user-given feature
names), every expression with its formula text (type and unit where NX stored them as text), the number
of component instances and the part files referenced, reference sets, the NX version that saved the file.
What it does NOT give: the ORDER of the features (records are in file order, not timestamp order), any
builder setting (limits, booleans, selection rules), geometry (the Parasolid data is not decoded), sketch
constraints, suppression state. For those open the part: inspect_part.py / dump_part.py.
Use it to triage a folder of parts, to choose which ones are worth opening, and to check a claim such as
"this part has no named expression" in seconds. `s["checks"]` says whether every feature record and
expression object of the file was decoded; trust the counts only when it reads ok.

Two record layouts are decoded: the var-int layout of NX 9 and later (calibrated on 241 parts, NX 9 ...
NX 2506, and re-proven on parts saved by NX 2206 in prt_text_selftest.py) and the fixed-width layout of
NX 8.5 and older behind an object-offset table (three FEATURE_RECORD variants: NX 5-7.5, NX 8.0, NX 8.5;
feature count identical to NX on 1,370 of 1,375 old parts that were also opened in NX 2206).
"""
_FORMAT_NOTES = r"""

What an NX part is on disk (measured on 241 parts, NX 9 ... NX 2506)
---------------------------------------------------------------------
* container  : "SPLMSSTR" (NX 11+; a flat directory of named streams) or an
               OLE2 compound file (NX 10 and older).  Both hold the same stream
               names: UG_PART/UG_PART, UG_PART/ExternalReferences, part/attrs
               (XML), part/arrangements (XML), qafmetadata (XML), images/preview,
               FastLoad/* (NX 1899+), KF_DATA/* (some NX 10 parts).
* UG_PART    : a section table and 4-5 "OM" object-model sections plus the
               Parasolid partition/deltas (the only zlib-compressed bytes).
               OM sections, identified by their second class:
                 RM  (RM_part)  display / base data: views, layers, ref sets, bodies
                 CM  (CM_part)  modelling history: one FEATURE_RECORD per feature
                 ESS (ESS_part) every expression, binary record: name + rhs text
                 OCC (OCC_part) assembly occurrences (components)
                 IM  (IM::InstanceManager) Knowledge Fusion rules = the expressions
                     as text "(Number [mm]) p26: 10;"
* OM section : header, module table, CLASS TABLE (one name per class), optional
               field table, then ONE INSTANCE COUNT PER CLASS, then object data.
               OM version 10 (NX 11+) uses var-ints, version 8 (NX 10) fixed ints.
               => exact "how many objects of class X does this part hold".
* strings    : stored uncompressed as  <len+2> text NUL  (len is a var-int).
"""
import argparse
import collections
import datetime
import json
import os
import re
import struct
import sys
import time
import zlib
import xml.etree.ElementTree as ET

# --------------------------------------------------------------------------- containers

CFB_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
ENDCHAIN, FREE = 0xFFFFFFFE, 0xFFFFFFFF


def read_splm(d):
    """SPLMSSTR: magic, 17 bytes, 'HEADER', u32 n, n x (u32 len, name, u64 off, u64 size)."""
    p = d.find(b"HEADER", 0, 64)
    if p < 0:
        raise ValueError("SPLMSSTR without HEADER")
    (n,) = struct.unpack_from("<I", d, p + 6)
    q = p + 10
    out = {}
    for _ in range(n):
        (ln,) = struct.unpack_from("<I", d, q)
        q += 4
        name = d[q:q + ln].decode("utf-8", "replace")
        q += ln
        off, size = struct.unpack_from("<QQ", d, q)
        q += 16
        if not name.endswith("/"):
            out[name[len("/Root"):] if name.startswith("/Root/") else name] = d[off:off + size]
    return out


def read_cfb(d):
    """Minimal OLE2 compound file reader -> {"/storage/stream": bytes}."""
    ssz = 1 << struct.unpack_from("<H", d, 30)[0]
    msz = 1 << struct.unpack_from("<H", d, 32)[0]
    (_nfat, dirstart, _x, cutoff, minifat_start, _nmf, difat_start, _nd) = struct.unpack_from("<8I", d, 44)

    def sect(i):
        return d[(i + 1) * ssz:(i + 2) * ssz]

    difat = list(struct.unpack_from("<109I", d, 76))
    s, guard = difat_start, 0
    while s not in (ENDCHAIN, FREE) and guard < 100000:
        vals = struct.unpack("<%dI" % (ssz // 4), sect(s).ljust(ssz, b"\xff"))
        difat += vals[:-1]
        s = vals[-1]
        guard += 1
    fat = []
    for s in difat:
        if s in (FREE, ENDCHAIN):
            continue
        fat += struct.unpack("<%dI" % (ssz // 4), sect(s).ljust(ssz, b"\xff"))

    def chain(s):
        out, seen = [], 0
        while s < len(fat) and s not in (ENDCHAIN, FREE) and seen <= len(fat):
            out.append(sect(s))
            s = fat[s]
            seen += 1
        return b"".join(out)

    dirb = chain(dirstart)
    ents = []
    for i in range(0, len(dirb) - 127, 128):
        e = dirb[i:i + 128]
        nl = struct.unpack_from("<H", e, 64)[0]
        size = struct.unpack_from("<Q", e, 120)[0]
        if ssz == 512:
            size &= 0xFFFFFFFF
        ents.append(dict(name=e[:max(nl - 2, 0)].decode("utf-16le", "replace"), typ=e[66],
                         left=struct.unpack_from("<I", e, 68)[0], right=struct.unpack_from("<I", e, 72)[0],
                         child=struct.unpack_from("<I", e, 76)[0],
                         start=struct.unpack_from("<I", e, 116)[0], size=size))
    if not ents:
        return {}
    root = ents[0]
    ministream = chain(root["start"])[:root["size"]]
    mf = chain(minifat_start)
    minifat = struct.unpack("<%dI" % (len(mf) // 4), mf) if mf else ()

    def minichain(s, size):
        out, seen = [], 0
        while s < len(minifat) and s not in (ENDCHAIN, FREE) and seen <= len(minifat):
            out.append(ministream[s * msz:(s + 1) * msz])
            s = minifat[s]
            seen += 1
        return b"".join(out)[:size]

    res = {}
    stack = [(root["child"], "")]
    seen = set()
    while stack:
        idx, prefix = stack.pop()
        if idx == FREE or idx >= len(ents) or (idx, prefix) in seen:
            continue
        seen.add((idx, prefix))
        e = ents[idx]
        stack.append((e["left"], prefix))
        stack.append((e["right"], prefix))
        p = prefix + "/" + e["name"]
        if e["typ"] == 2:
            res[p] = minichain(e["start"], e["size"]) if e["size"] < cutoff else chain(e["start"])[:e["size"]]
        elif e["typ"] == 1:
            stack.append((e["child"], p))
    return res


def read_streams(d):
    if d[:8] == b"SPLMSSTR":
        return "SPLMSSTR", read_splm(d)
    if d[:8] == CFB_MAGIC:
        return "OLE2", read_cfb(d)
    raise ValueError("unknown container, first bytes %s" % d[:8].hex())


# --------------------------------------------------------------------------- OM sections

def rv(b, q):
    """Raw OM var-int: 0xxxxxxx | 100x.. 2 bytes | 101x.. 3 | 110x.. 4 | 111x.. 1+4."""
    x = b[q]
    if x < 0x80:
        return x, q + 1
    if x < 0xA0:
        return ((x & 0x1F) << 8) | b[q + 1], q + 2
    if x < 0xC0:
        return ((x & 0x1F) << 16) | (b[q + 1] << 8) | b[q + 2], q + 3
    if x < 0xE0:
        return ((x & 0x1F) << 24) | (b[q + 1] << 16) | (b[q + 2] << 8) | b[q + 3], q + 4
    return struct.unpack_from(">I", b, q + 1)[0], q + 5


def rvn(b, q):
    """Var-int as the number it stands for.

    Measured: the ONE-byte form stores n+1 (0 = null), the multi-byte forms store n.
    (92 modules -> 0x5d, 208 modules -> 80 d0; string 'p1' -> 04, a 136-byte
    string -> 80 89; FEATURE_RECORD objects == decoded records only with this rule.)
    """
    v, q2 = rv(b, q)
    return (v - 1 if q2 == q + 1 else v), q2


def rstr(b, q):
    """Class / module / field name: <n> then n bytes (no NUL)."""
    ln, q = rvn(b, q)
    return b[q:q + ln], q + ln


IDENT = re.compile(rb"[A-Za-z_][A-Za-z0-9_]{2,}")
OM_MAGIC = re.compile(rb"OM\x01\x01\x00\x00\x00([\x07-\x0c])\x00\x00\x00.", re.S)


def parse_om(ug, m0):
    """Parse one OM section whose 'OM' magic is at ug[m0]. Returns dict or raises."""
    total = struct.unpack_from(">I", ug, m0 - 4)[0]
    sec = ug[m0:m0 + total]
    ver = struct.unpack_from(">I", sec, 4)[0]
    q = 4 + 8 + 7
    (ln,) = struct.unpack_from("<I", sec, q)
    q += 4
    platform = sec[q:q + ln].decode("latin1")
    q += ln
    (ln,) = struct.unpack_from("<I", sec, q)
    q += 4
    partname = sec[q:q + ln].decode("utf-8", "replace")
    q += ln
    classes, fields = [], []
    if ver >= 9:
        h = struct.unpack_from("<9I", sec, q)
        q += 36
        ncls = h[3]
        nmod, q = rvn(sec, q)
        mods = []
        for _ in range(nmod):
            nm, q = rstr(sec, q)
            _c, q = rv(sec, q)
            if not nm.startswith(b"UGS::"):
                raise ValueError("module table out of step at %d" % q)
            mods.append(nm.decode("latin1"))
        for _ in range(ncls):
            mi, q = rvn(sec, q)
            nm, q = rstr(sec, q)
            _a, q = rv(sec, q)
            _b, q = rv(sec, q)
            q += 8
            if not nm.startswith(b"UGS::"):
                raise ValueError("class table out of step at %d" % q)
            classes.append([nm.decode("latin1"), mods[mi] if 0 <= mi < len(mods) else "?", 0])
        # optional field table: n, n x (var-int, name, var-int).  Its presence is not
        # flagged in the header, so it is recognised by its identifier-like names.
        try:
            nf, q1 = rvn(sec, q)
            ok = nf >= 1
            tmp = []
            for _ in range(nf):
                _t, q1 = rv(sec, q1)
                nm, q1 = rstr(sec, q1)
                _a, q1 = rv(sec, q1)
                if not IDENT.fullmatch(nm):
                    ok = False
                    break
                tmp.append(nm.decode("latin1"))
            if ok:
                q, fields = q1, tmp
        except (IndexError, struct.error):
            pass
        for c in classes:
            c[2], q = rvn(sec, q)
    else:
        h = struct.unpack_from("<8I", sec, q)
        q += 32
        ncls = h[3]
        q += 2 * ncls
        for _ in range(ncls):
            q += 1
            (ln,) = struct.unpack_from("<H", sec, q)
            mod = sec[q + 2:q + 2 + ln]
            q += 2 + ln + 4
            (ln,) = struct.unpack_from("<H", sec, q)
            nm = sec[q + 2:q + 2 + ln]
            q += 2 + ln + 4
            classes.append([nm.decode("latin1"), mod.decode("latin1"), 0])
        if sec[q:q + 7] == b"opt_att":
            q += 7
            (nf,) = struct.unpack_from("<I", sec, q)
            q += 4
            for _ in range(nf):
                q += 1
                for k in range(3):
                    (ln,) = struct.unpack_from("<H", sec, q)
                    if k == 2:
                        fields.append(sec[q + 2:q + 2 + ln].decode("latin1"))
                    q += 2 + ln + (4 if k == 0 else 0)
                q += 4
        cnt = struct.unpack_from("<%dI" % ncls, sec, q)
        q += 4 * ncls
        for c, n in zip(classes, cnt):
            c[2] = n
    if any(c[2] < 0 or c[2] > 50_000_000 for c in classes):
        raise ValueError("implausible instance counts")
    kind = "?"
    for nm, _m, _n in classes[:4]:
        if nm.endswith("_part"):
            kind = nm[5:-5]
        elif nm == "UGS::IM::InstanceManager":
            kind = "IM"
    return dict(kind=kind, om_version=ver, offset=m0, length=total, platform=platform, partname=partname,
                n_tagged_objects=h[0], classes=classes, fields=fields, data=sec[q:], sec=sec)


def om_sections(ug):
    out, errs = [], []
    for m in OM_MAGIC.finditer(ug):
        try:
            out.append(parse_om(ug, m.start()))
        except Exception as e:  # noqa: BLE001 - record and go on
            errs.append("OM@%d: %s: %s" % (m.start(), type(e).__name__, e))
    return out, errs


# --------------------------------------------------------------------------- strings

_TEXT_RUN = {}


def om_strings(buf, minlen=2, maxlen=4000, u32=False):
    """All length-prefixed  text NUL  records (UTF-8, no control bytes except \t \n \r).

    Prefix forms: 1 byte = len+2 ; 2 bytes = len+1 (text of ~126 bytes and more) ;
    u32=True also accepts a 4-byte little-endian len+1 (OM version 8 = NX 10, IM section).
    """
    key = (minlen, maxlen)
    if key not in _TEXT_RUN:
        _TEXT_RUN[key] = re.compile(rb"[\x09\x0a\x0d\x20-\x7e\x80-\xf4]{%d,%d}\x00" % (minlen, maxlen))
    out = []
    for m in _TEXT_RUN[key].finditer(buf):
        s, e = m.start(), m.end() - 1
        # the text may be preceded by other printable bytes: take the first start
        # whose length prefix fits (= the longest text)
        # measured: 1-byte prefix = len+2 ; 2-byte prefix (text >= ~126 bytes) = len+1
        hit = None
        if u32 and s >= 4 and struct.unpack_from("<I", buf, s - 4)[0] == e - s + 1:
            hit = s
        for k in range(s, e - minlen + 1):
            if hit is not None:
                break
            ln = e - k + 2
            if ln < 0x80:
                if k >= 1 and buf[k - 1] == ln:
                    hit = k
                    break
            elif ln < 0x2000 and k >= 2:
                ln -= 1
                if buf[k - 2] == (0x80 | (ln >> 8)) and buf[k - 1] == (ln & 0xFF):
                    hit = k
                    break
        if hit is None:
            continue
        try:
            t = buf[hit:e].decode("utf-8")
        except UnicodeDecodeError:
            continue
        out.append((hit, t))
    return out


# --------------------------------------------------------------------------- expressions

EXPR = re.compile(r"\((\w+)(?: \[([^\]]*)\])?\) ([^:\s][^:]*?): (.*)\Z", re.S)
# system-generated names: p12, p12_x (point coordinates), Pattern_p12 (Pattern Feature)
SYSNAME = re.compile(r"(Pattern_)?p\d+(_[xyz])?\Z")
NUM = re.compile(r"[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?\Z")
FUNC = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(")
IDREF = re.compile(r"[A-Za-z_][A-Za-z0-9_']*(?:\.[A-Za-z_][A-Za-z0-9_]*)?")
INTERPART = re.compile(r'"([^"]+)"::([A-Za-z_][A-Za-z0-9_\']*)')
NOT_REF = {"if", "else", "true", "false", "pi", "e"}


def classify_rhs(typ, rhs):
    """constant | formula ; plus references, functions, flags."""
    r = (rhs or "").strip()
    info = dict(kind="formula", refs=[], funcs=[], interpart=[], has_if=False)
    if re.fullmatch(r'"[^"]*"', r):
        info["kind"] = "constant"
        return info
    if NUM.fullmatch(r) or r.upper() in ("TRUE", "FALSE"):
        info["kind"] = "constant"
        return info
    info["interpart"] = ["%s::%s" % m for m in INTERPART.findall(r)]
    nostr = re.sub(r'"[^"]*"(::[A-Za-z_][A-Za-z0-9_\']*)?', '""', r)
    info["has_if"] = bool(re.search(r"\bif\s*\(", nostr, re.I))
    info["funcs"] = sorted(set(f for f in FUNC.findall(nostr) if f.lower() not in ("if", "else")))
    refs = []
    for tok in IDREF.findall(nostr):
        base = tok.split(".")[0]
        if base in info["funcs"] or base.lower() in NOT_REF:
            continue
        refs.append(tok)
    info["refs"] = sorted(set(refs))
    return info


def expressions_from_im(im):
    """Knowledge Fusion rule text of the IM section -> list of expression dicts."""
    out, other = [], []
    for _off, t in om_strings(im["data"], minlen=6, maxlen=8000, u32=im["om_version"] < 9):
        if not t.startswith("("):
            continue
        m = EXPR.match(t)
        if not m:
            continue
        typ, unit, name, rest = m.group(1), m.group(2), m.group(3), m.group(4)
        if typ == "Child":
            other.append(dict(type=typ, name=name, text=rest.strip()))
            continue
        # rest = "<rhs>; " [ "// comment\n" ]
        comment = None
        k = rest.rfind(";")
        rhs, tail = (rest[:k], rest[k + 1:]) if k >= 0 else (rest, "")
        tail = tail.strip()
        if tail.startswith("//"):
            comment = tail[2:].strip()
        info = classify_rhs(typ, rhs)
        out.append(dict(name=name, type=typ, unit=unit, rhs=rhs.strip(), comment=comment,
                        system_name=bool(SYSNAME.match(name)), kind=info["kind"], refs=info["refs"],
                        funcs=info["funcs"], interpart=info["interpart"], has_if=info["has_if"]))
    return out, other


# EXP_expression record of the ESS section:
#   04 <len> name 00   ( 06 <pool index> | 04 <len> rhs 00 | 00 )   ff ( 00 | 01 <n+1> <n refs> )  0a ...
ESS_REC = re.compile(
    rb"\x04([\x03-\x7f])([\x20-\x7e\x80-\xf4]+?)\x00"
    rb"(?:\x06([\x00-\x7f]|[\x80-\x9f][\s\S])|\x04((?:[\x03-\x7f]|[\x80-\x9f][\s\S]))([^\x00]*)\x00|(\x00))"
    rb"\xff[\x00\x01]", re.S)


def expressions_from_ess(ess):
    """Binary EXP_expression records of the ESS section: name + rhs text.

    The rhs is inline text, or an index into a string pool (a run of <len> text 00
    strings near the start of the object data, preceded by its count), or absent
    (interpart link).  Returns (list, pool_ok).
    """
    data = ess["data"]
    recs = []
    for m in ESS_REC.finditer(data):
        name = m.group(2)
        if m.group(1)[0] != len(name) + 2:
            continue
        try:
            name = name.decode("utf-8")
        except UnicodeDecodeError:
            continue
        if m.group(6) is not None:
            recs.append([m.start(), name, None, -1])
        elif m.group(3) is not None:
            idx, _ = rvn(m.group(3), 0)          # 0-based pool index
            recs.append([m.start(), name, None, idx])
        else:
            ln, _ = rvn(m.group(4), 0)           # text + NUL
            rhs = m.group(5)
            if ln != len(rhs) + 1:
                continue
            recs.append([m.start(), name, rhs.decode("utf-8", "replace"), None])
    pool, pool_ok = [], None
    need = max([r[3] + 1 for r in recs if r[3] is not None and r[3] >= 0], default=0)
    if need and recs:
        head = data[:recs[0][0]]
        runs, cur = [], []
        for off, t in om_strings(head, minlen=1):
            n = len(t.encode("utf-8"))
            start = off - (1 if n + 2 < 0x80 else 2)
            if cur and start == cur[-1][2]:
                cur.append((start, t, off + n + 1))
            else:
                if cur:
                    runs.append(cur)
                cur = [(start, t, off + n + 1)]
        if cur:
            runs.append(cur)
        pool_ok = False
        for run in reversed(runs):
            s0 = run[0][0]
            n1 = head[s0 - 1] - 1 if s0 >= 1 and head[s0 - 1] < 0x80 else -1
            n2 = (((head[s0 - 2] & 0x1F) << 8) | head[s0 - 1]) if s0 >= 2 and 0x80 <= head[s0 - 2] < 0xA0 else -1
            if len(run) >= need and len(run) in (n1, n2):
                pool = [t for _s, t, _e in run]
                pool_ok = True
                break
    out = []
    for _off, name, rhs, idx in recs:
        if rhs is None and idx is not None and idx >= 0:
            rhs = pool[idx] if pool_ok and idx < len(pool) else None
        out.append(dict(name=name, rhs_raw=rhs, pool_index=idx, no_rhs_text=(idx == -1)))
    return out, pool_ok


# --------------------------------------------------------------------------- features

# object reference: ff = null, 1 byte, 8x + 1 byte, 9x/ax/bx + 2 bytes, f0 + 1, f1 + 2
_V = rb"(?:\xff|[\x00-\x7f]|[\x80-\x8f][\s\S]|[\x90-\xbf][\s\S]{2}|[\xc0-\xdf][\s\S]{3}|\xf0[\s\S]|\xf1[\s\S]{2})"
# FEATURE_RECORD:  ... 01 04 01 <8-byte tolerance> ff ff <ref> <ref> <ref> <ref>
#                  ( 03 <len> TYPE 00 | 03 02 00 = empty text | 00 = no text )
#                  <index of the feature's parameter class in this section's class table> ...
FEAT_REC = re.compile(rb"\x01\x04\x01[\s\S]{8}\xff\xff" + _V + _V + _V + _V +
                      rb"(?:\x03([\x03-\x7f])([\x20-\x7e]{1,125})\x00|\x03\x02\x00|\x00)")
# a user-given feature name is a NAMREC written immediately before its record:
#   03 <len> NAME 00 02 <v> 01 04 01 ...
FEAT_NAME = re.compile(rb"\x03([\x03-\x7f])([\x20-\x7e\x80-\xf4]{1,125})\x00\x02" + _V + rb"\Z")


# Records that carry NO type text: NX derives the type from the parameter class.
# Mapping measured against NX 2206 feature censuses (tier A + 150 other parts, see README).
# A typeless class that is not listed stays visible as "<class>".
TYPELESS = {
    "REPLACEFACE_PARMS": "REPLACE_FACE",
    "DIVIDEFACE_PARMS": "DIVIDE_FACE",
    "ICURVES_parms": "INTERSECTION_CURVES",
    "ModlCurve::ExtractCurvesParms": "LINKED_CURVE/EXTRACTED_CURVE",   # NX reports either, by link state
    "ModlSurface::LawExtensionParms": "LAWEXTENSION",
    "ModlFeature::AFBParms": "AESTHETIC_BLEND",
    "ModlFeature::PatternFaceParameters": "Pattern Face Feature",
    "DD_uniform_scale_body_parms": "SCALE",
    "DD_non_uni_scale_body_parms": "SCALE",
    "ModlDirectDB::ReorderBlendsParms": "Reorder Blends",
    "DFO_REBLEND_PARMS": "RESIZE_BLEND",
    "ModlDirectDB::CoaxialParms": "Coaxial",
    "ModlDirectDB::ParallelParms": "Parallel",
}


def feature_records(cm):
    """One dict per FEATURE_RECORD found, in file order (NOT timestamp order).

    type        : feature-type text NX stores in the record (what NXOpen
                  Feature.FeatureType returns); None when the record has none
    parms_class : class of the feature's parameter object (always present)
    name        : user-given feature name, or None
    """
    data = cm["data"]
    cls = [c[0] for c in cm["classes"]]
    cnt = [c[2] for c in cm["classes"]]
    out = []
    for m in FEAT_REC.finditer(data):
        if m.group(1) is not None and m.group(1)[0] != len(m.group(2)) + 2:
            continue
        typ = m.group(2).decode("ascii") if m.group(1) is not None else None
        try:
            idx, _ = rvn(data, m.end())          # 0-based index into this section's class table
        except IndexError:
            continue
        if not (0 <= idx < len(cls)):
            if typ is None:
                continue  # not a feature record: the class index must name a class with instances
            pc = "?%d" % idx
        else:
            pc = cls[idx][5:]
        name = None
        nm = FEAT_NAME.search(data[max(0, m.start() - 140):m.start()])
        if nm and nm.group(1)[0] == len(nm.group(2)) + 2:
            try:
                name = nm.group(2).decode("utf-8")
            except UnicodeDecodeError:
                name = nm.group(2).decode("latin1")
        out.append(dict(type=typ, parms_class=pc, name=name))
    return out



# --------------------------------------------------------------------------- fixed-int OM (NX 8.5 and older)
#
# Measured on the NX CAST 8.5 library (parts saved by NX 6 ... NX 8.5, OM version 8):
# the object data of a section starts with ONE u32 OFFSET PER OBJECT (offset from the section
# start), objects are stored grouped by class in class-table order, all integers are fixed
# width little-endian, a string is  <tag 03|04> <u32 len incl. NUL> text NUL.
#   FEATURE_RECORD : u16 u16 | u32 ref (next feature in the chain) | ff ff | u32 | u32 |
#                    8-byte tolerance | 6 x u32 ref | 03 <u32 len> TYPE 00 (or 00 = no text) |
#                    u16 index of the parameter class in this section's class table
#   EXP_expression : u16 u16 | 04 <u32 len> name 00 (or 00 = unnamed) |
#                    04 <u32 len> rhs 00 (or 00 = no text) | ff ff ff ff 00 ff ff | u32 | flags | value

def fixed_objects(sec):
    """-> [(class name without 'UGS::', class index, object bytes, object index)] or None when the
    section does not start with a valid object-offset table (then it is the var-int flavour)."""
    data, full = sec["data"], sec["sec"]
    q = len(full) - len(data)
    classes = sec["classes"]
    n = sum(c[2] for c in classes)
    if n == 0 or 4 * n > len(data):
        return None
    offs = struct.unpack_from("<%dI" % n, data, 0)
    if any(o < q or o > len(full) for o in offs) or any(a > b for a, b in zip(offs, offs[1:])):
        return None
    out, i = [], 0
    for ci, (nm, _m, cnt) in enumerate(classes):
        short = nm[5:] if nm.startswith("UGS::") else nm
        for _ in range(cnt):
            end = offs[i + 1] if i + 1 < n else len(full)
            out.append((short, ci, full[offs[i]:end], i))
            i += 1
    return out


def _fstr(b, q, tags=(3, 4)):
    """tagged fixed string at b[q] -> (text or None, next q) ; raises ValueError when absent."""
    if q >= len(b):
        raise ValueError("eof")
    if b[q] == 0:
        return None, q + 1
    if b[q] not in tags or q + 5 > len(b):
        raise ValueError("no string tag")
    (ln,) = struct.unpack_from("<I", b, q + 1)
    if ln < 1 or q + 5 + ln > len(b) or b[q + 5 + ln - 1] != 0:
        raise ValueError("bad string length")
    raw = b[q + 5:q + 5 + ln - 1]
    try:
        t = raw.decode("utf-8")
    except UnicodeDecodeError:
        t = raw.decode("latin1")
    return t, q + 5 + ln


_FTYPE = re.compile(rb"\x03([\s\S]{4})([\x20-\x7e]{1,125})\x00")
_FNAME = re.compile(rb"\x03([\s\S]{4})([\x20-\x7e\x80-\xf4]{1,125})\x00")
_ANCH8 = re.compile(rb"\xcd(?:\x00){3}[\x00-\x20](?:\x00){3}[\s\S]{7}[\x3e\x3f\x40]")
_ANCH7 = re.compile(rb"(?:\x00){2}[\x00-\x20](?:\x00){3}\xcd(?:\x00)[\s\S]{7}[\x3e\x3f\x40]")


def _pstr(b, q):
    """type text at b[q]: 03 <u32 len> TEXT NUL [zero padding] -> (text, next q); NX 8.0 pads the
    text with 4 more zero bytes that are counted in len. Raises ValueError when there is no text."""
    if q + 5 > len(b) or b[q] != 3:
        raise ValueError("no string tag")
    (ln,) = struct.unpack_from("<I", b, q + 1)
    if ln < 2 or ln > 140 or q + 5 + ln > len(b):
        raise ValueError("bad string length")
    raw = b[q + 5:q + 5 + ln]
    k = raw.find(bytes(1))
    if k < 1 or any(raw[k:]) or not (1 <= ln - k <= 8):
        raise ValueError("not a padded string")
    if not all(32 <= c < 127 for c in raw[:k]):
        raise ValueError("type text")
    return raw[:k].decode("ascii"), q + 5 + ln


def feature_records_fixed(cm, objs):
    """FEATURE_RECORD objects of a fixed-int CM section.
      u16 u16 | u32 next | ff ff  or  an attribute / name block (the user-given feature name is its
      tag-03 string, written just before the anchor) |
      OM 8 (NX 8.0 / 8.5): ANCHOR = u32 0xcd, u32 | 8-byte tolerance | 6 x u32 ref | TYPE | u16 class index
      OM 7 (NX 5 ... 7.5): ANCHOR = u16 0, u32, u16 0xcd | 8-byte tolerance | 1 (or 3) x u32 ref | TYPE | u16
      TYPE = 03 <u32 len> TEXT 00 [NX 8.0: + zero padding counted in len], or 00 when there is no text.
    The parameter classes are embedded sub-objects here: they have NO instance count of their own."""
    cls = [c[0] for c in cm["classes"]]
    bad_cls = ("UGS::OM::RootObject", "UGS::CM_part", "UGS::FEATURE_RECORD")
    v8 = cm["om_version"] >= 8
    anchor = _ANCH8 if v8 else _ANCH7
    after = (24,) if v8 else (4, 12, 8)

    def class_at(b, q):
        if q + 2 > len(b):
            return None
        (i,) = struct.unpack_from("<H", b, q)
        return i if (0 <= i < len(cls) and cls[i] not in bad_cls) else None

    out = []
    for nm, _ci, b, oi in objs:
        if nm != "FEATURE_RECORD":
            continue
        typ, idx, how, name = None, None, None, None
        m = anchor.search(b, 8, 600)
        if m:
            for mm in _FNAME.finditer(b, 8, m.start()):
                if struct.unpack("<I", mm.group(1))[0] == len(mm.group(2)) + 1 and m.start() - mm.end() <= 8:
                    try:
                        name = mm.group(2).decode("utf-8")
                    except UnicodeDecodeError:
                        name = mm.group(2).decode("latin1")
            for o in after:                      # 1. type text at the expected place
                try:
                    t, q = _pstr(b, m.end() + o)
                except (ValueError, struct.error):
                    continue
                i = class_at(b, q)
                if i is not None:
                    typ, idx, how = t, i, "std"
                    break
        if idx is None:                          # 2. first type-like text followed by a class index
            start = m.end() if m else 18
            for q in range(start, min(len(b) - 7, start + 400)):
                if b[q] != 3:
                    continue
                try:
                    t, q2 = _pstr(b, q)
                except (ValueError, struct.error):
                    continue
                i = class_at(b, q2)
                if i is not None:
                    typ, idx, how = t, i, "search"
                    break
        if idx is None and m:                    # 3. no type text: 00 + class index
            for o in after:
                q = m.end() + o
                if q < len(b) and b[q] == 0:
                    i = class_at(b, q + 1)
                    if i is not None:
                        idx, how = i, "typeless"
                        break
        if idx is None:
            continue
        nxt = struct.unpack_from("<I", b, 4)[0] if len(b) >= 8 else 0xFFFFFFFF
        out.append(dict(type=typ or None, parms_class=cls[idx][5:], name=name, obj=oi,
                        next=None if nxt == 0xFFFFFFFF else nxt, decode=how))
    return out


def expressions_from_ess_fixed(objs):
    out, unnamed, bad = [], 0, 0
    for nm, _ci, b, _oi in objs:
        if nm != "EXP_expression":
            continue
        try:
            name, q = _fstr(b, 4, tags=(4,))
            if name is None:
                unnamed += 1
                continue
            rhs, idx = None, None
            if q < len(b) and b[q] == 6:
                (idx,) = struct.unpack_from("<I", b, q + 1)
            else:
                rhs, q = _fstr(b, q, tags=(4,))
            out.append(dict(name=name, rhs_raw=rhs, pool_index=idx, no_rhs_text=(rhs is None and idx is None)))
        except (ValueError, struct.error):
            bad += 1
    return out, unnamed, bad


_FNAME = re.compile(rb"\x03([\s\S]{4})([\x20-\x7e\x80-\xf4]{1,125})\x00")


def object_names(objs, classes):
    """{class: [first tagged string of each object]} for the listed classes (reference sets,
    sketches, layer categories ... carry their name as their first string)."""
    res = {}
    for nm, _ci, b, _oi in objs:
        if nm not in classes:
            continue
        for m in _FNAME.finditer(b[:300]):
            if struct.unpack("<I", m.group(1))[0] == len(m.group(2)) + 1:
                try:
                    res.setdefault(nm, []).append(m.group(2).decode("utf-8"))
                except UnicodeDecodeError:
                    res.setdefault(nm, []).append(m.group(2).decode("latin1"))
                break
    return res


# --------------------------------------------------------------------------- named objects

# NAMREC (object name record), written just before the object it names:
#   a7 01 66 <ref> 03 <len> NAME 00 02 <first bytes of the named object>
NAMED = re.compile(rb"\xa7\x01\x66" + _V + rb"\x03([\x03-\x7f])([\x20-\x7e\x80-\xf4]{1,125})\x00\x02([\s\S]{4})")
LAYER_CAT_DEFAULTS = {"ALL", "SOLIDS", "SHEETS", "SKETCHES", "CURVES", "DATUMS"}


def named_objects(sec):
    """[(name, signature)] : signature = 4 bytes that follow the name record; objects
    of one kind share it inside one part (used only to group, never as a type code)."""
    out = []
    for m in NAMED.finditer(sec["data"]):
        if m.group(1)[0] != len(m.group(2)) + 2:
            continue
        try:
            nm = m.group(2).decode("utf-8")
        except UnicodeDecodeError:
            nm = m.group(2).decode("latin1")
        out.append((nm, m.group(3).hex()))
    return out


def group_named(objs):
    """Group RM names by signature and label the groups that can be recognised."""
    groups = collections.OrderedDict()
    for nm, sig in objs:
        groups.setdefault(sig, []).append(nm)
    res = dict(layer_categories=[], reference_sets=[], sketches=[], other=[])
    for sig, names in groups.items():
        s = set(names)
        if len(s & LAYER_CAT_DEFAULTS) >= 2:
            res["layer_categories"] += names
        elif "MODEL" in s or "BODY" in s and len(s) <= 6:
            res["reference_sets"] += names
        elif sum(1 for n in names if re.fullmatch(r"SKETCH_\d+", n)) * 2 >= len(names):
            res["sketches"] += names
        else:
            res["other"] += names
    return res


# --------------------------------------------------------------------------- misc text

# "NX 2412.4001", "NX 10.0.0.24", "NX Student Edition 2506.3001", "UG 18", "V0.1"
VERSION_STR = re.compile(r"(NX( [A-Za-z]+){0,3} ?\d|UG ?\d|Unigraphics|V\d)")


def audit_trail(sec):
    """Version strings (order of first appearance), save timestamps, user names."""
    strs = om_strings(sec["data"][:400000], minlen=4, maxlen=200, u32=sec["om_version"] < 9)
    vers = [(off, t) for off, t in strs if VERSION_STR.match(t) and len(t) < 120]
    if not vers:
        return [], [], []
    data = sec["data"]
    times = []
    j = vers[-1][0]
    end = min(len(data), j + 60000)
    last_t = 0
    now = int(time.time()) + 86400
    while j < end - 5:
        if data[j] == 0xE0:
            t = struct.unpack_from(">I", data, j + 1)[0]
            if 631152000 <= t <= now and t >= last_t:  # 1990 .. today, non-decreasing
                times.append(t)
                last_t = t
                j += 5
                # an entry is <time> <random id> ...: skip the id so it is not read as a time
                x = data[j]
                j += 5 if x >= 0xE0 else 4 if x >= 0xC0 else 3 if x >= 0xA0 else 2 if x >= 0x80 else 1
                # entries are contiguous (12-40 bytes apart): stop at the first large gap
                end = min(len(data), j + 160)
                continue
        j += 1
    lo, hi = vers[0][0], vers[-1][0] + 400
    users = []
    near = [(o + lo, t) for o, t in om_strings(data[lo:hi], minlen=2, maxlen=60, u32=sec["om_version"] < 9)]
    for off, t in near:
        if lo < off < hi and re.fullmatch(r"[\w.\-@ ]{2,40}", t) and not VERSION_STR.match(t) and t not in users:
            users.append(t)
    return [t for _o, t in vers], times, users[:8]


def parse_attrs(xml_bytes):
    out = []
    try:
        root = ET.fromstring(xml_bytes.rstrip(b"\x00"))
    except ET.ParseError as e:
        return out, "part/attrs XML parse error: %s" % e
    for el in root.iter():
        if el.tag.endswith("Attribute"):
            a = el.attrib
            typ = next((v for k, v in a.items() if k.endswith("}type")), "")
            out.append(dict(title=a.get("utf8title", a.get("title")), value=a.get("utf8value", a.get("value")),
                            type=typ.replace("AttributeType", ""), owner=a.get("owner"),
                            category=a.get("utf8category") or a.get("category")))
    return out, None


def parse_extref(b):
    """ExternalReferences stream: file names / paths this part refers to, save times."""
    names = []
    for m in re.finditer(rb"[\x20-\x7e\x80-\xf4]{4,400}", b):
        try:
            t = m.group(0).decode("utf-8")
        except UnicodeDecodeError:
            t = m.group(0).decode("latin1")
        if re.search(r"\.prt\b", t, re.I) or re.match(r"[A-Za-z]:\\", t) or t.startswith("\\\\") or t.startswith("@DB"):
            t = t.strip()
            if t not in names:
                names.append(t)
    times = []
    for m in re.finditer(rb"\xe0([\s\S]{4})", b):
        t = struct.unpack(">I", m.group(1))[0]
        if 631152000 <= t <= 1830297600:
            times.append(t)
    return names, times


def iso(t):
    return datetime.datetime.fromtimestamp(t, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def zlib_members(buf):
    """(offset, compressed_len, plain) of every zlib member (Parasolid transmit files)."""
    out, i = [], 0
    while True:
        i = buf.find(b"\x78", i)
        if i < 0 or i + 2 > len(buf):
            break
        if buf[i + 1] in (0x01, 0x5E, 0x9C, 0xDA):
            o = zlib.decompressobj()
            try:
                pl = o.decompress(buf[i:])
                if o.eof and pl:
                    cl = len(buf) - i - len(o.unused_data)
                    out.append((i, cl, pl))
                    i += cl
                    continue
            except zlib.error:
                pass
        i += 1
    return out


def namespace_of(cls):
    """'ModlFeature::ChamferParms' -> 'ModlFeature' ; flat legacy names -> '(legacy)'."""
    parts = cls.split("::")
    return "::".join(parts[:-1]) if len(parts) >= 2 else "(legacy)"


# --------------------------------------------------------------------------- one part

def analyse(path, key=None, meta=None):
    rec = dict(key=key, src=path, errors=[], not_recovered=[])
    if meta:
        rec.update(meta)
    with open(path, "rb") as fh:
        d = fh.read()
    rec["bytes"] = len(d)
    kind, S = read_streams(d)
    rec["container"] = kind
    rec["streams"] = {k: len(v) for k, v in sorted(S.items())}
    ugk = [k for k in S if k.endswith("UG_PART/UG_PART")]
    if not ugk:
        rec["errors"].append("no UG_PART/UG_PART stream")
        return rec, {}
    ug = S[ugk[0]]

    # ---- OM sections, class vocabulary with instance counts
    secs, errs = om_sections(ug)
    rec["errors"] += errs
    by = {}
    for s in secs:
        by.setdefault(s["kind"], s)
    rec["om_version"] = secs[0]["om_version"] if secs else None
    rec["om_sections"] = [dict(kind=s["kind"], offset=s["offset"], bytes=s["length"], classes=len(s["classes"]),
                               classes_with_instances=sum(1 for c in s["classes"] if c[2]),
                               objects=sum(c[2] for c in s["classes"]), tagged_objects=s["n_tagged_objects"])
                          for s in secs]
    rec["platform"] = secs[0]["platform"] if secs else None
    rec["internal_partname"] = secs[0]["partname"] if secs else None
    vocab, declared = {}, {}
    for s in secs:
        v = {}
        zero = []
        for nm, _mod, n in s["classes"]:
            short = nm[5:] if nm.startswith("UGS::") else nm
            if n > 0:
                v[short] = n
            else:
                zero.append(short)
        vocab[s["kind"]] = v
        declared[s["kind"]] = zero
    rec["vocabulary"] = vocab                      # {section: {class: instance count}}
    rec["vocabulary_declared_only"] = declared     # classes in the table with 0 instances (base classes)
    ns = collections.defaultdict(lambda: [0, 0])
    for _sk, v in vocab.items():
        for nm, n in v.items():
            e = ns[namespace_of(nm)]
            e[0] += 1
            e[1] += n
    rec["vocabulary_namespaces"] = {k: dict(classes=v[0], objects=v[1])
                                    for k, v in sorted(ns.items(), key=lambda kv: -kv[1][1])}
    rec["class_fields"] = {s["kind"]: s["fields"] for s in secs if s["fields"]}

    # ---- features
    cm = by.get("CM")
    fixed = {k: fixed_objects(v) for k, v in by.items()} if (secs and secs[0]["om_version"] < 9) else {}
    rec["om_flavour"] = "fixed-int" if any(v is not None for v in fixed.values()) else "var-int"
    if cm:
        if fixed.get("CM") is not None:
            fr = feature_records_fixed(cm, fixed["CM"])
            rec["feature_record_layout"] = "fixed-int"
            if len(fr) < vocab.get("CM", {}).get("FEATURE_RECORD", 0):
                # some NX 8.x parts keep the object-offset table but write var-int records
                fr2 = feature_records(cm)
                if len(fr2) > len(fr):
                    fr = fr2
                    rec["feature_record_layout"] = "var-int"
        else:
            fr = feature_records(cm)
            rec["feature_record_layout"] = "var-int"
        n_cls = vocab.get("CM", {}).get("FEATURE_RECORD", 0)
        for f in fr:
            f["type_resolved"] = f["type"] or TYPELESS.get(f["parms_class"], "<%s>" % f["parms_class"])
        # the DELETE record is NX's internal "deleted features" holder, not a feature
        feats = [f for f in fr if f["type"] != "DELETE"]
        rec["feature_record_objects"] = n_cls
        rec["feature_records_decoded"] = len(fr)
        rec["n_features"] = len(feats)
        rec["features_in_file_order"] = feats
        # fixed-int flavour: the first reference of a record points to the next record of a chain;
        # the chains are kept as "feature_chains" (order to be checked against NX)
        if rec["feature_record_layout"] == "fixed-int":
            byobj = {f["obj"]: f for f in feats}
            targets = {f["next"] for f in feats if f.get("next") is not None}
            heads = [f for f in feats if f["obj"] not in targets]
            chains = []
            for h in heads:
                ch, seen, cur = [], set(), h
                while cur is not None and cur["obj"] not in seen:
                    seen.add(cur["obj"])
                    ch.append(cur["type_resolved"])
                    cur = byobj.get(cur.get("next"))
                chains.append(ch)
            rec["feature_chains"] = chains
        rec["feature_types"] = dict(collections.Counter(f["type_resolved"] for f in feats).most_common())
        rec["feature_parms_classes"] = dict(collections.Counter(f["parms_class"] for f in feats).most_common())
        rec["feature_names"] = [dict(name=f["name"], type=f["type_resolved"]) for f in feats if f["name"]]
        # self-check: every FEATURE_RECORD object of the class table must have been decoded
        rec["feature_decode_check"] = ("ok" if len(fr) == n_cls else
                                       "incomplete: %d records decoded vs %d FEATURE_RECORD objects" % (len(fr), n_cls))
    else:
        rec["errors"].append("no CM section")

    # ---- expressions
    # The ESS section holds every NX expression (name + rhs text).  The IM section
    # holds the same expressions as Knowledge Fusion text WITH type and unit, but
    # (a) not all of them (unit-less constants such as pattern counts are missing)
    # and (b) also KF rules that are not NX expressions.  So: set = ESS, text = IM.
    im, ess = by.get("IM"), by.get("ESS")
    im_list, kf_other = ([], [])
    if im:
        im_list, kf_other = expressions_from_im(im)
    else:
        rec["not_recovered"].append("no IM (Knowledge Fusion) section: expression type/unit text absent")
    ess_list, pool_ok = ([], None)
    if ess and fixed.get("ESS") is not None:
        ess_list, n_unnamed, n_bad = expressions_from_ess_fixed(fixed["ESS"])
        pool_ok = None
        rec["expressions_unnamed_internal"] = n_unnamed
        rec["expression_record_layout"] = "fixed-int"
        if n_bad:
            try:
                alt, alt_pool = expressions_from_ess(ess)
            except Exception:  # noqa: BLE001
                alt, alt_pool = [], None
            if len(alt) > len(ess_list):
                ess_list, pool_ok, n_bad = alt, alt_pool, 0
                rec["expression_record_layout"] = "var-int"
        if n_bad:
            rec["errors"].append("ESS fixed: %d EXP_expression objects not decoded" % n_bad)
    elif ess:
        try:
            ess_list, pool_ok = expressions_from_ess(ess)
        except Exception as e:  # noqa: BLE001
            rec["errors"].append("ESS parse: %s: %s" % (type(e).__name__, e))
    im_by = {}
    for e in im_list:
        im_by.setdefault(e["name"], e)
    allx, seen = [], set()
    for e in ess_list:
        nm = e["name"]
        if nm in seen:
            continue
        seen.add(nm)
        rhs = e["rhs_raw"]
        comment = None
        if rhs is not None and "//" in rhs:
            rhs, comment = rhs.split("//", 1)
            comment = comment.strip()
        i = im_by.get(nm)
        if i is not None:
            x = dict(i)
            x["source"] = "ESS+IM"
            x["rhs_ess"] = rhs.strip() if rhs is not None else None
            if x["comment"] is None and comment:
                x["comment"] = comment
        else:
            if rhs is not None:
                info = classify_rhs("Number", rhs)
            else:
                info = dict(kind="interpart-link" if e["no_rhs_text"] else "undecoded",
                            refs=[], funcs=[], interpart=[], has_if=False)
            x = dict(name=nm, type=None, unit=None, rhs=rhs.strip() if rhs is not None else None,
                     comment=comment, system_name=bool(SYSNAME.match(nm)), kind=info["kind"],
                     refs=info["refs"], funcs=info["funcs"], interpart=info["interpart"],
                     has_if=info["has_if"], source="ESS", rhs_ess=rhs.strip() if rhs is not None else None)
        allx.append(x)
    kf_only = [e for e in im_list if e["name"] not in seen]
    if not ess_list and im_list and not vocab.get("ESS", {}).get("EXP_expression", 0):
        pass  # no expressions; IM entries are KF rules only
    rec["expressions"] = allx
    rec["kf_rules_not_expressions"] = [dict(name=e["name"], type=e["type"], unit=e["unit"], rhs=e["rhs"]) for e in kf_only]
    rec["kf_child_rules"] = kf_other
    n_rhs_agree = sum(1 for x in allx if x["source"] == "ESS+IM" and x["rhs_ess"] is not None
                      and x["rhs_ess"].rstrip("; ") == x["rhs"].rstrip("; "))
    n_both = sum(1 for x in allx if x["source"] == "ESS+IM" and x["rhs_ess"] is not None)
    rec["expression_counts"] = dict(
        total=len(allx), with_type_and_unit=sum(1 for x in allx if x["source"] == "ESS+IM"),
        ess_only=sum(1 for x in allx if x["source"] == "ESS"),
        im_text_rules=len(im_list), kf_rules_not_expressions=len(kf_only),
        exp_expression_objects=vocab.get("ESS", {}).get("EXP_expression", 0),
        ess_pool_decoded=pool_ok, rhs_ess_vs_im_agree=n_rhs_agree, rhs_ess_vs_im_compared=n_both,
        named=sum(1 for e in allx if not e["system_name"]),
        formulas=sum(1 for e in allx if e["kind"] == "formula"),
        constants=sum(1 for e in allx if e["kind"] == "constant"),
        undecoded_rhs=sum(1 for e in allx if e["kind"] == "undecoded"),
        with_if=sum(1 for e in allx if e["has_if"]),
        interpart=sum(1 for e in allx if e["interpart"] or e["kind"] == "interpart-link"),
        with_comment=sum(1 for e in allx if e["comment"]))
    rec["expression_units"] = dict(collections.Counter(e["unit"] or "" for e in allx if e["type"]).most_common())
    rec["expression_types"] = dict(collections.Counter(e["type"] or "?" for e in allx).most_common())

    # ---- save history
    hist = {}
    for s in secs:
        vers, times, users = audit_trail(s)
        hist[s["kind"]] = dict(versions=vers, n_times=len(times),
                               first=iso(times[0]) if times else None, last=iso(times[-1]) if times else None,
                               users=users, entries=vocab.get(s["kind"], {}).get("OM::SaveAuditTrailEntry", 0))
    rec["save_history"] = hist
    allv = []
    for s in secs:
        for t in hist[s["kind"]]["versions"]:
            if t not in allv:
                allv.append(t)
    rec["nx_versions_in_order"] = hist.get("RM", {}).get("versions", [])
    rec["nx_versions_all_sections"] = allv
    # one summary: each section keeps its own trail; take the value most sections agree on
    good = [hist[k] for k in ("RM", "ESS", "OCC", "CM") if k in hist and hist[k]["n_times"] >= 2]

    def mode(vals):
        c = collections.Counter(v for v in vals if v is not None)
        if not c:
            return None
        top = max(c.values())
        return max(v for v, n in c.items() if n == top)
    users = []
    for k in hist:
        for u in hist[k]["users"]:
            if u not in users:
                users.append(u)
    rmv_ = hist.get("RM", {}).get("versions", [])
    rec["save_summary"] = dict(latest_version=rmv_[0].strip() if rmv_ else (allv[0].strip() if allv else None),
                               last_save_utc=mode([h["last"] for h in good]),
                               first_save_utc=mode([h["first"] for h in good]),
                               n_saves=mode([h["n_times"] for h in good]),
                               users=users, sections_used=len(good))

    # ---- xml / other streams
    for k, v in S.items():
        if k.endswith("part/attrs"):
            rec["attributes"], err = parse_attrs(v)
            if err:
                rec["errors"].append(err)
        elif k.endswith("part/arrangements"):
            rec["arrangements_xml"] = v.rstrip(b"\x00").decode("utf-8", "replace").strip()[:4000]
        elif k.endswith("UG_PART/ExternalReferences"):
            names, times = parse_extref(v)
            rec["external_reference_names"] = names
        elif "/KF_DATA/" in k:
            rec.setdefault("kf_data_streams", {})[k] = v.rstrip(b"\x00").decode("utf-8", "replace")[:1500]

    # ---- parasolid (the only compressed data): schema / modeller version only
    ps = []
    for _off, cl, pl in zlib_members(ug):
        if pl[:2] == b"PS":
            m = re.search(rb"TRANSMIT FILE ?(\([a-z]+\))? created by modeller version (\d+)", pl[:200])
            ps.append(dict(kind=(m.group(1) or b"").decode() if m else "?",
                           modeller=m.group(2).decode() if m else None,
                           plain_bytes=len(pl), compressed_bytes=cl))
    rec["parasolid_streams"] = ps

    # ---- named objects (NAMREC) of the RM section, components, units, material
    rm = by.get("RM")
    if rm and fixed.get("RM") is not None:
        on = object_names(fixed["RM"], {"Assy::ReferenceSet", "SKETCH_new_sketch", "LAYER_category"})
        rec["named_objects_rm"] = dict(layer_categories=on.get("LAYER_category", []),
                                       reference_sets=on.get("Assy::ReferenceSet", []),
                                       sketches=on.get("SKETCH_new_sketch", []), other=[])
        if not on:                               # var-int records behind an offset table
            objs = named_objects(rm)
            if objs:
                rec["named_objects_rm"] = group_named(objs)
    elif rm:
        objs = named_objects(rm)
        rec["named_objects_rm"] = group_named(objs)
        rec["named_object_records"] = dict(decoded=len(objs), namrec_objects=vocab["RM"].get("NAMREC", 0))
    own = (rec.get("internal_partname") or "").lower()
    refs = [n for n in rec.get("external_reference_names", []) if n.lower().endswith(".prt")]
    rec["referenced_part_files"] = [n for n in refs if n.lower() != own and os.path.basename(n.replace("\\", "/")).lower() != own]
    occ = vocab.get("OCC", {})
    rec["assembly"] = dict(
        component_instances=max(0, occ.get("OCC_part_occurrence", 0) - 1),   # minus the root occurrence
        occ_classes={k: v for k, v in occ.items() if not k.startswith("OM::") and k != "OCC_part"})
    eu = rec.get("expression_units", {})
    n_mm = sum(v for k, v in eu.items() if k and re.fullmatch(r"mm(\^\d)?", k))
    n_in = sum(v for k, v in eu.items() if k and re.fullmatch(r"in(\^\d)?", k))
    rec["units_guess"] = "mm" if n_mm > n_in else "inch" if n_in > n_mm else None
    rmv = vocab.get("RM", {})
    rec["counts_from_classes"] = dict(
        solid_body_objects=rmv.get("Solid::Body", 0), faces=rmv.get("Solid::Face", 0),
        edges=rmv.get("Solid::Edge", 0), reference_sets=rmv.get("Assy::ReferenceSet", 0),
        layer_categories=rmv.get("LAYER_category", 0), sketches=vocab.get("CM", {}).get("SKETCH_PARMS", 0),
        materials=rmv.get("PHYS_material", 0), named_objects=rmv.get("NAMREC", 0),
        drawing_sheets=rmv.get("DRAWINGS_drawing", 0), dimensions=sum(v for k, v in rmv.items() if k.startswith("Annot::") and k.endswith("Dimension")),
        sketch_constraints=sum(v for k, v in rmv.items() if k.startswith("CS2_") and "constraint" in k))
    mats = [a["value"] for a in rec.get("attributes", []) if a.get("title") in ("NX_Material", "Material", "MATERIAL")]
    rec["material_attribute"] = mats[0] if mats else None

    # ---- strings per section (returned separately for the corpus-wide filter)
    strings = {}
    for s in secs:
        strings[s["kind"]] = [t for _o, t in om_strings(s["data"], minlen=3, maxlen=400, u32=s["om_version"] < 9)]
    return rec, strings


# Expression names NX writes itself (the same test as nxh.user_named, repeated here because this module
# must import without NX): p12, p12_x, p8_CircularPattern_..., Pattern_p12, ASSO_BLEND_3, Sheet_Metal_*, SM_Validation_*
_SYSTEM_EXPR_NAME = re.compile(r"^(p\d+(_\w+)?|Pattern_.*|ASSO_BLEND_\d+|Sheet_Metal_\w+|SM_Validation_\w+)$")


def summarise(rec):
    """The part of an analyse() record that is exact and useful when planning: a plain dict."""
    ex = []
    for e in rec.get("expressions", []):
        kind = e.get("kind")
        if e.get("rhs") and re.fullmatch(r"interpart\d+", e["rhs"].strip()):
            kind = "interpart-link"          # NX 9+ writes the link as a placeholder; the source part is in referenced_parts
        ex.append(dict(name=e["name"], rhs=e.get("rhs"), type=e.get("type"), unit=e.get("unit"), comment=e.get("comment"),
                       kind=kind, user_named=not _SYSTEM_EXPR_NAME.match(e["name"])))
    counts = rec.get("expression_counts", {})
    n_link = sum(1 for e in ex if e["kind"] == "interpart-link")
    named_rm = rec.get("named_objects_rm") or {}
    n_obj, n_dec = rec.get("feature_record_objects"), rec.get("feature_records_decoded")
    exp_obj = counts.get("exp_expression_objects")
    return dict(
        path=rec.get("src"), bytes=rec.get("bytes"), container=rec.get("container"),
        saved_by=(rec.get("save_summary") or {}).get("latest_version"),
        last_save_utc=(rec.get("save_summary") or {}).get("last_save_utc"),
        record_layout=rec.get("feature_record_layout"), units_guess=rec.get("units_guess"),
        n_features=rec.get("n_features"), feature_types=rec.get("feature_types", {}),
        feature_names=rec.get("feature_names", []),
        n_expressions=len(ex), n_user_named=sum(1 for e in ex if e["user_named"]),
        n_formulas=sum(1 for e in ex if e["kind"] == "formula"), n_conditional=counts.get("with_if"),
        n_interpart=max(counts.get("interpart") or 0, n_link), expressions=ex,
        components=(rec.get("assembly") or {}).get("component_instances", 0),
        referenced_parts=rec.get("referenced_part_files", []),
        reference_sets=named_rm.get("reference_sets", []), sketch_names=named_rm.get("sketches", []),
        counts=rec.get("counts_from_classes", {}),
        checks=dict(features=rec.get("feature_decode_check"),
                    feature_records="%s of %s decoded" % (n_dec, n_obj),
                    expressions_undecoded_rhs=counts.get("undecoded_rhs"),
                    expression_objects_in_file=exp_obj, errors=rec.get("errors", []),
                    not_recovered=rec.get("not_recovered", [])),
        limits="no feature order, no builder settings, no geometry, no suppression state: open the part for those")


def read_part(path):
    """Summary dict of one .prt, read without NX (see the module docstring). Raises on an unreadable file."""
    rec, _strings = analyse(path, key=os.path.basename(path))
    return summarise(rec)


def report(s):
    """One-page text of a read_part() summary."""
    L = ["OFFLINE READ (no NX)  %s" % s["path"],
         "saved by %s  %s  container %s  records %s  units (guess) %s" % (s["saved_by"], s["last_save_utc"], s["container"],
                                                                         s["record_layout"], s["units_guess"]),
         "features %s (all rows, internal ones included; file order is NOT the tree order)" % s["n_features"],
         "  " + ", ".join("%s %d" % kv for kv in s["feature_types"].items())]
    if s["feature_names"]:
        L.append("  named by a person: " + ", ".join("%s [%s]" % (f["name"], f["type"]) for f in s["feature_names"][:30]))
    L.append("expressions %d, user-named %d, formulas %d, conditional %s, interpart %s"
             % (s["n_expressions"], s["n_user_named"], s["n_formulas"], s["n_conditional"], s["n_interpart"]))
    for e in [e for e in s["expressions"] if e["user_named"]][:60]:
        L.append("  %s = %s%s%s" % (e["name"], e["rhs"], ("  [%s]" % e["unit"]) if e["unit"] else "",
                                    ("  // " + e["comment"]) if e["comment"] else ""))
    L.append("components %d%s" % (s["components"], ("  referenced parts: " + ", ".join(s["referenced_parts"][:20])) if s["referenced_parts"] else ""))
    if s["reference_sets"]:
        L.append("reference sets: " + ", ".join(str(x) for x in s["reference_sets"][:20]))
    c = s["checks"]
    L.append("decode check: features %s (%s); expressions without formula text %s; errors %s"
             % (c["features"], c["feature_records"], c["expressions_undecoded_rhs"], c["errors"] or "none"))
    L.append("NOT in this read: " + s["limits"])
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description="What is in an NX part, without opening NX (read-only).")
    ap.add_argument("part", help="path of a .prt file")
    ap.add_argument("--json", help="write the summary as JSON to this file")
    ap.add_argument("--full", action="store_true", help="print the complete record (class vocabulary, strings) as JSON")
    args = ap.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass
    rec, strings = analyse(args.part, key=os.path.basename(args.part))
    if args.full:
        rec["strings"] = strings
        print(json.dumps(rec, ensure_ascii=False, indent=1))
        return 0
    s = summarise(rec)
    if args.json:
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(s, fh, ensure_ascii=False, indent=1)
    print(report(s))
    return 0


if __name__ == "__main__":
    sys.exit(main())
