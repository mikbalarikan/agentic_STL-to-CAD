"""Editing a parametric part "in the middle" of its history (NX 2206, headless) - the worked example of
references/existing-parts.md section 7.

A small shelled housing with a lug is built, saved, closed and opened again like somebody else's part. Then:

  1  as-found: history mode, nothing rolled back, tree state by tag, volume
  2  INSERT POINT: corner blends R8 are added BEFORE the existing Shell (nxh.insert_after) - the Shell offsets
     them (inner radius 6, wall 2 all round, closed-form volume); the later features are only renumbered
  3  REORDER: the lug moved before the Shell is hollowed by it, moved back it is solid again (two different
     models, both measured); a move before a referenced feature is refused
  4  FEATURE GROUP: lug + its blend as a named group; the ACTIVE group collects the next feature (a hole in the
     lug); one Boolean expression suppresses the whole group and brings it back
  5  the one-way rule: a child without its own suppress expression goes down with its parent and does not
     come back (measured), so the set gets one shared expression or is grouped
  6  CONDITIONAL / STRING / BOOLEAN expressions holding configurations: the wall follows a material name

Usage:  run_journal edit_in_the_middle.py -args <output folder>
Writes <output folder>/edit_in_the_middle.json  with "result": "PASS" | "FAIL" and the list of checks.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import NXOpen  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
K = 1.0 - math.pi / 4.0
chk = nxh.Check()
res = {"result": "FAIL", "measured": {}}


def flush():
    out = dict(res)
    out.update(chk.report())
    nxh.write_json(os.path.join(OUT, "edit_in_the_middle.json"), out)


def vedges(body, zmin=1.0):
    return nxh.edges(body, lambda b: abs(b[0] - b[3]) < 1e-3 and abs(b[1] - b[4]) < 1e-3 and b[5] - b[2] > zmin)


def box(t, r):
    """Open-top box 80 x 60 x 30, wall t, vertical corners r outside and r - t inside, dia 10 hole in the floor."""
    outer = (80 * 60 - 4 * K * r * r) * 30
    inner = (80 - 2 * t) * (60 - 2 * t) * (30 - t) - 4 * K * max(r - t, 0.0) ** 2 * (30 - t)
    return outer - inner - math.pi * 25 * t


LUG = 20 * 20 * 10 - 2 * K * 9 * 10                       # solid lug with two R3 corners


def by_type(part, cls_name):
    return [f for f in nxh.top_features(part)[0] if type(f).__name__ == cls_name]


try:
    # ---------------------------------------------------------------- the "existing part"
    path = os.path.join(OUT, "housing_asbuilt.prt")
    part = nxh.new_part(path)
    nxh.expr(part, "wall", 2, "mm", "nominal wall")
    fb, body = nxh.block(part, (0.0, 0.0, 0.0), (80, 60, 30))
    nxf.shell(part, body, nxh.faces(body, ftype=nxh.PLANE, at=(2, 30.0)), "wall")
    nxh.cylinder(part, (40, 30, 0), (0, 0, 1), 10, "wall", nxh.BOOL.Subtract, nxh.solids(part)[0])
    flug, _b = nxh.block(part, (80.0, 20.0, 0.0), (20, 20, 10), op=nxh.BOOL.Unite, target=nxh.solids(part)[0])
    nxh.blend(part, [e for e in vedges(nxh.solids(part)[0]) if nxh.bbox(e)[0] > 99.0], 3)
    chk("as built: sharp shelled box + lug", nxh.volume(part, nxh.solids(part)[0]), box(2, 0) + LUG, 1e-6)
    nxh.save(part)
    nxh.close_all()

    # ---------------------------------------------------------------- 1. open it again, as found
    part = nxh.open_part(path)
    body = nxh.solids(part)[0]
    chk.true("1 as found: history mode, nothing rolled back, no errors",
             nxh.history_mode(part) and not nxh.rolled_back(part) and not nxh.feature_errors(part))
    top = nxh.top_features(part)[0]
    res["measured"]["tree_as_found"] = [f.GetFeatureName() for f in top]
    f_block = [f for f in top if f.FeatureType == "BLOCK"][0]
    f_lug = [f for f in top if f.FeatureType == "BLOCK"][1]
    f_shell = [f for f in top if f.FeatureType == "SHELL"][0]
    f_hole = [f for f in top if f.FeatureType == "CYLINDER"][0]
    f_lugblend = [f for f in top if f.FeatureType == "BLEND"][0]
    chk("1 as found: volume", nxh.volume(part, body), box(2, 0) + LUG, 1e-6)
    state0 = nxh.feature_state(part)
    shell_name0, shell_ts0 = f_shell.GetFeatureName(), f_shell.Timestamp

    # ---------------------------------------------------------------- 2. insert point: blends before the Shell
    nxh.expr(part, "r_corner", 8, "mm", "outer corner radius")
    with nxh.insert_after(part, f_block) as ip:
        early = nxh.solids(part)[0]                                   # the body in its EARLY state: a plain block
        chk("2 inside the insert point the body is the plain block", nxh.volume(part, early), 144000.0, 1e-6)
        f_corner = nxh.blend(part, vedges(early), "r_corner")
    res["measured"]["insert_report"] = ip.report
    chk.true("2 insert: exactly one feature added, nothing changed / gone / in error",
             len(ip.report["added"]) == 1 and not ip.report["changed"] and not ip.report["gone"] and not ip.report["errors"], ip.report)
    body = nxh.solids(part)[0]
    chk("2 insert: closed-form volume (Shell picked the radii up: inner R6)", nxh.volume(part, body), box(2, 8) + LUG, 1e-6)
    o8 = nxh.faces(body, ftype=nxh.CYLINDER, radius=8.0)
    chk("2 insert: four outer R8 corner faces", len(o8), 4, 0)
    chk("2 insert: four inner R6 corner faces", len(nxh.faces(body, ftype=nxh.CYLINDER, radius=6.0)), 4, 0)
    chk("2 insert: wall behind an outer corner blend = 2.000", nxh.wall_thickness(o8[0]), 2.0, 1e-6)
    chk.true("2 insert: the Shell was renumbered (name and timestamp + 1), its tag is the same",
             f_shell.GetFeatureName() != shell_name0 and f_shell.Timestamp == shell_ts0 + 1 and f_shell.Tag in state0,
             [shell_name0, f_shell.GetFeatureName()])
    chk.true("2 insert: the new blend sits directly after the Block", f_corner.Timestamp == f_block.Timestamp + 1)
    nxh.set_expr(part, "r_corner", 5)
    nxh.update()
    chk("2 insert: r_corner 5 -> the shelled part follows (inner R3)", nxh.volume(part, nxh.solids(part)[0]), box(2, 5) + LUG, 1e-6)
    nxh.set_expr(part, "r_corner", 8)
    nxh.update()

    # ---------------------------------------------------------------- 3. reorder: lug before / after the Shell
    v_solid_lug = nxh.volume(part, nxh.solids(part)[0])
    errs = nxh.reorder(part, [f_lug, f_lugblend], f_shell, after=False)
    chk.true("3 reorder: lug + its blend before the Shell - no feature error", not errs, errs)
    lug_cavity = 20 * 16 * 6 - 2 * K * 1 * 6                          # the Shell now hollows the lug too (inner R1)
    chk("3 reorder: the lug is HOLLOW now (wall 2, open to the cavity)", nxh.volume(part, nxh.solids(part)[0]), box(2, 8) + LUG - lug_cavity, 1e-6)
    chk.true("3 reorder: order is Block, corner blend, lug, lug blend, Shell, hole",
             [f.Tag for f in sorted((f_block, f_corner, f_lug, f_lugblend, f_shell, f_hole), key=lambda f: f.Timestamp)] ==
             [f_block.Tag, f_corner.Tag, f_lug.Tag, f_lugblend.Tag, f_shell.Tag, f_hole.Tag])
    _r, why = nxh.attempt("lug blend before the lug", nxh.reorder, part, f_lugblend, f_lug, False)
    chk.true("3 reorder: a feature cannot be moved before one it references", _r is None and "referenced" in str(why), why)
    errs = nxh.reorder(part, [f_lug, f_lugblend], f_hole, after=True)
    chk("3 reorder: moved back after the hole - the solid lug again", nxh.volume(part, nxh.solids(part)[0]), v_solid_lug, 1e-6)
    d = nxh.state_diff(state0, nxh.feature_state(part))
    chk.true("3 after insert + two reorders the tree differs from as-found by the one added blend only",
             [a[0] for a in d["added"]] == [f_corner.GetFeatureName()] and not d["changed"] and not d["gone"], d)

    # ---------------------------------------------------------------- 4. feature group, active group, one switch
    grp = nxf.feature_group(part, [f_lug, f_lugblend], "LUG")
    chk.true("4 group: a FeatureGroup named LUG with the two members", type(grp).__name__ == "FeatureGroup" and grp.Name == "LUG"
             and [m.Tag for m in grp.GetMembers()] == [f_lug.Tag, f_lugblend.Tag], [grp.Name, len(grp.GetMembers())])
    grp.SetGroupActive(True)
    chk.true("4 group: it is the active group", part.Features.ActiveGroup is not None and part.Features.ActiveGroup.Tag == grp.Tag)
    f_lughole, _b = nxh.cylinder(part, (90, 30, 0), (0, 0, 1), 6, 10, nxh.BOOL.Subtract, nxh.solids(part)[0])
    grp.SetGroupActive(False)
    chk.true("4 group: the hole made while the group was active is a member", f_lughole.Tag in [m.Tag for m in grp.GetMembers()], len(grp.GetMembers()))
    chk.true("4 group: no active group any more", part.Features.ActiveGroup is None)
    v_with = box(2, 8) + LUG - math.pi * 9 * 10
    chk("4 group: volume with the drilled lug", nxh.volume(part, nxh.solids(part)[0]), v_with, 1e-6)
    part.Expressions.CreateExpression("Boolean", "with_lug=true")
    e_sup = nxf.suppress_by_expression(part, [grp], "with_lug")
    res["measured"]["group_suppress_expression"] = e_sup.Name + "=" + e_sup.RightHandSide
    part.Expressions.FindObject("with_lug").RightHandSide = "false"
    nxh.update()
    chk("4 group: with_lug = false -> lug, blend and hole are gone", nxh.volume(part, nxh.solids(part)[0]), box(2, 8), 1e-6)
    chk.true("4 group: all three members read suppressed", all(m.Suppressed for m in grp.GetMembers()))
    part.Expressions.FindObject("with_lug").RightHandSide = "true"
    nxh.update()
    chk("4 group: with_lug = true -> all three are back", nxh.volume(part, nxh.solids(part)[0]), v_with, 1e-6)
    chk.true("4 group: no feature error after the round trip", not nxh.feature_errors(part), nxh.feature_errors(part))

    # ---------------------------------------------------------------- 5. the one-way parent / child rule
    f_pad, _b = nxh.block(part, (30.0, 60.0, 0.0), (20, 10, 10), op=nxh.BOOL.Unite, target=nxh.solids(part)[0])
    f_padblend = nxh.blend(part, [e for e in vedges(nxh.solids(part)[0]) if nxh.bbox(e)[1] > 69.0], 3)
    PAD = 20 * 10 * 10 - 2 * K * 9 * 10
    chk("5 pad with two blended corners added", nxh.volume(part, nxh.solids(part)[0]), v_with + PAD, 1e-6)
    part.Expressions.CreateExpression("Boolean", "with_pad=true")
    nxf.suppress_by_expression(part, [f_pad], "with_pad")              # the PARENT only
    part.Expressions.FindObject("with_pad").RightHandSide = "false"
    nxh.update()
    codes_off = [nxh.suppress_status(f)["code"] for f in (f_pad, f_padblend)]
    chk.true("5 parent switched off: parent code 2 (by expression), child code 64 (by parent)", codes_off == [2, 64], codes_off)
    part.Expressions.FindObject("with_pad").RightHandSide = "true"
    nxh.update()
    codes_on = [nxh.suppress_status(f)["code"] for f in (f_pad, f_padblend)]
    res["measured"]["parent_child_codes"] = {"off": codes_off, "on": codes_on}
    chk.true("5 parent switched on again: the CHILD STAYS SUPPRESSED (code 64)", codes_on == [0, 64], codes_on)
    chk("5 ... the pad came back without its blends", nxh.volume(part, nxh.solids(part)[0]), v_with + 2000.0, 1e-6)
    part.Features.UnsuppressFeatures([f_padblend])
    nxh.update()
    chk("5 cure for this state: unsuppress the child by hand", nxh.volume(part, nxh.solids(part)[0]), v_with + PAD, 1e-6)
    grp2 = nxf.feature_group(part, [f_pad, f_padblend], "PAD")
    for f in (f_pad,):                                                 # drop the parent-only expression, switch the GROUP instead
        b = part.Expressions.CreateSuppressByExpressionBuilder()
        try:
            b.SuppressAction = NXOpen.SuppressByExpressionBuilder.ExpressionAction.DeleteEach
            b.FeatureList.Add(f)
            b.Commit()
        finally:
            b.Destroy()
    nxf.suppress_by_expression(part, [grp2], "with_pad")
    for val, want in (("false", v_with), ("true", v_with + PAD), ("false", v_with), ("true", v_with + PAD)):
        part.Expressions.FindObject("with_pad").RightHandSide = val
        nxh.update()
        chk("5 grouped pad, with_pad = %s" % val, nxh.volume(part, nxh.solids(part)[0]), want, 1e-6)

    # ---------------------------------------------------------------- 6. conditional, string and Boolean expressions
    X = part.Expressions
    X.CreateExpression("String", 'material="ABS"')
    X.FindObject("wall").RightHandSide = 'if (material=="PA12") (1.6) else (2)'
    nxh.update()
    chk("6 wall = if (material==\"PA12\") (1.6) else (2): ABS -> 2", X.FindObject("wall").Value, 2.0, 1e-9)
    X.FindObject("material").RightHandSide = '"PA12"'
    nxh.update()
    chk("6 material PA12 -> wall 1.6", X.FindObject("wall").Value, 1.6, 1e-9)
    chk("6 ... and the Shell, the inner corners and the floor hole follow", nxh.volume(part, nxh.solids(part)[0]),
        box(1.6, 8) + LUG - math.pi * 9 * 10 + PAD, 1e-6)
    X.FindObject("material").RightHandSide = '"ABS"'
    nxh.update()
    chk("6 back to ABS: the nominal volume again", nxh.volume(part, nxh.solids(part)[0]), v_with + PAD, 1e-6)
    nxh.expr(part, "n_holes", 6, None, "number of holes")
    e_slot = X.CreateWithUnits("slot_end=if (n_holes==6) (105) else if (n_holes==5) (150) else if (n_holes==4) (195) else (45)",
                               part.UnitCollection.FindObject("Degrees"))
    got = {}
    for n in (6, 5, 4, 3):
        nxh.set_expr(part, "n_holes", n)
        nxh.update()
        got[n] = e_slot.Value
    chk.true("6 if / else if / else chain: 6 -> 105, 5 -> 150, 4 -> 195, other -> 45", got == {6: 105.0, 5: 150.0, 4: 195.0, 3: 45.0}, got)
    syntax = {}
    for label, text in (("joined 'elseif'", "t1=if (n_holes==6) (1) elseif (n_holes==5) (2) else (3)"), ("no else branch", "t2=if (n_holes==6) (1)")):
        try:
            X.CreateWithUnits(text, None)
            syntax[label] = "accepted"
        except Exception as e:  # noqa: BLE001
            syntax[label] = str(e)[:80]
    res["measured"]["if_syntax_refused"] = syntax
    chk.true("6 'elseif' in one word and an if without else are syntax errors", all("syntax" in v for v in syntax.values()), syntax)
    eb = X.CreateExpression("Boolean", "many_holes=n_holes>4 && with_lug")
    es = X.CreateExpression("String", 'size_text=if (many_holes) ("M"+"8") else ("M6")')
    nxh.set_expr(part, "n_holes", 6)
    nxh.update()
    chk.true("6 Boolean from a comparison and &&; String from an if with concatenation", eb.BooleanValue is True and es.StringValue == "M8",
             [eb.BooleanValue, es.StringValue])
    bad, why = nxh.attempt("Integer 2.5", X.CreateExpression, "Integer", "n_bad=2.5")
    chk.true("6 an Integer expression refuses 2.5", bad is None, why)

    chk.true("end: no feature error, one solid, nothing rolled back",
             not nxh.feature_errors(part) and len(nxh.solids(part)) == 1 and not nxh.rolled_back(part), nxh.feature_errors(part))
    chk.true("end: Examine Geometry clean", nxh.body_ok(part, nxh.solids(part)[0]))
    edited = os.path.join(OUT, "housing_edited.prt")
    if os.path.exists(edited):                                 # a second run into the same folder
        os.remove(edited)
    part.SaveAs(edited)
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("no exception", False, traceback.format_exc()[-400:])
flush()
try:
    nxh.close_all()
except Exception:  # noqa: BLE001
    pass
