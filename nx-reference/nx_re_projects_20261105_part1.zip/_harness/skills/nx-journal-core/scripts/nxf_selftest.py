"""Self-test of nxf.py (NX 2206, run_journal): every public function is called at least once on small test
geometry and the result is MEASURED (analytic volume, face position, DOF, solid count, free edges, STEP round trip).

    run_journal.ps1 -Script nxf_selftest.py -WorkDir <out> -JArgs <out> -TimeoutSec 1500
    (optional: -JArgs <out>,<group>,<group> runs only those groups)

Writes <out>/nxf_selftest.json: {"result": "PASS" | "FAIL", "checks": [...], "uncovered": [...], "errors": {...}}.
Groups (one part each, so one failing helper does not hide the others): sketch, datum, solid_a, solid_b, bodies,
sync, tree, copies, surface, step, newsolver. Inside a group every case is wrapped: an exception is recorded as a failed check and rolled back.
Group newsolver (sketch helpers in a NEW-solver sketch) needs a part that was modelled in the NX user interface:
set the environment variable NXF_NEW_SOLVER_PART to its path before the launch (a copy is opened, never saved).
Without it the group writes a note and no check.
"""
import functools
import math
import os
import shutil
import sys
import traceback
import types

sys.path.insert(0, os.environ.get("NXH_DIR", os.path.dirname(os.path.abspath(sys.argv[0]))))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402

OUT = sys.argv[1]
ONLY = {g for a in sys.argv[2:] for g in a.split(",") if g} or None
P, V, BOOL = nxh.P, nxh.V, nxh.BOOL
K = 1.0 - math.pi / 4.0            # area removed by a unit-radius fillet on a 90 deg edge
AUTO_DIM_AT_START = bool(nxh.S.Preferences.Sketch.ContinuousAutoDimensioning)   # before any nxf helper touched it
log = nxh.Log(os.path.join(OUT, "nxf_selftest.log"))
chk = nxh.Check()
res = {"result": "FAIL", "errors": {}, "notes": {}}

# ---- call tracing: which public nxf functions were really exercised
PUBLIC = sorted(n for n, o in vars(nxf).items() if isinstance(o, types.FunctionType) and not n.startswith("_")
                and o.__module__ == "nxf")
CALLED = set()


def _trace(name, fn):
    @functools.wraps(fn)
    def w(*a, **k):
        CALLED.add(name)
        return fn(*a, **k)
    return w


for _n in PUBLIC:
    setattr(nxf, _n, _trace(_n, getattr(nxf, _n)))


def ck(name, got, want, tol=1e-3):
    if got is None:
        chk.true(name, False, "got None, want %s" % want)
        log("FAIL", name, "got None")
        return False
    ok = chk(name, got, want, tol)
    log("PASS" if ok else "FAIL", name, "got", round(float(got), 5), "want", round(float(want), 5), "tol", tol)
    return ok


def ct(name, cond, note=""):
    ok = chk.true(name, cond, note)
    log("PASS" if ok else "FAIL", name, note)
    return ok


def case(label, fn):
    m = nxh.mark("case " + label, False)
    try:
        fn()
    except Exception:  # noqa: BLE001
        tb = traceback.format_exc()
        res["errors"][label] = tb
        ct(label + ": no exception", False, tb.strip().splitlines()[-1][:300])
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass


def flush():
    out = dict(res)
    out.update(chk.report())
    out["uncovered"] = sorted(set(PUBLIC) - CALLED)
    nxh.write_json(os.path.join(OUT, "nxf_selftest.json"), out)
    return out


def group(name, fn):
    if ONLY and name not in ONLY:
        return
    log("==== group", name)
    try:
        part = nxh.new_part(os.path.join(OUT, "nxf_%s.prt" % name))
        fn(part)
        res["notes"][name + ".feature_errors"] = nxh.feature_errors(part)
        res["notes"][name + ".solids"] = len(nxh.solids(part))
        nxh.save(part)
    except Exception:  # noqa: BLE001
        tb = traceback.format_exc()
        res["errors"]["group " + name] = tb
        ct("group %s: no exception" % name, False, tb.strip().splitlines()[-1][:300])
    flush()


def vertical_edges(body, h):
    return nxh.edges(body, lambda b: abs(b[5] - b[2] - h) < 1e-3 and abs(b[0] - b[3]) < 1e-3 and abs(b[1] - b[4]) < 1e-3)


def top_of(body):
    return nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1))


def side_walls(body):
    return [f for f in body.GetFaces() if nxh.face_data(f)[0] == nxh.PLANE and abs(nxh.face_data(f)[2][2]) < 0.7]


def rounded_box_volume(a, b, c, r):
    a, b, c = a - 2 * r, b - 2 * r, c - 2 * r
    return a * b * c + 2 * r * (a * b + b * c + a * c) + math.pi * r * r * (a + b + c) + 4.0 / 3.0 * math.pi * r ** 3


# ============================================================================ sketch
def g_sketch(part):
    dat = nxh.Datums(part)
    vol = lambda b: nxh.volume(part, b)  # noqa: E731
    for n, v in (("w", 60), ("h", 40), ("bore_d", 20)):
        nxh.expr(part, n, v)
    st = {}

    def c_datum_plane_sketch():
        sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "SK_PLATE")
        ls = nxf.hv_polygon(part, sk, [(-30, -20), (30, -20), (30, 20), (-30, 20)])
        circ = part.Curves.CreateArc(P(0, 0, 0), V(1, 0, 0), V(0, 1, 0), 10.0, 0.0, 2 * math.pi)
        nxf.add(sk, circ, infer=False)
        sk.CreateCoincidentConstraint(nxf.cg(circ, nxf.CP.ArcCenter), nxf.cg(dat.origin))
        hx, hy = P(50, 0, 0), P(0, 50, 0)
        nxf.pdim(sk, dat.y, hy, ls[1], nxf.A.StartPoint, P(15, -28, 0), "w/2")
        nxf.pdim(sk, dat.y, hy, ls[3], nxf.A.StartPoint, P(-15, -28, 0), "w/2")
        nxf.pdim(sk, dat.x, hx, ls[0], nxf.A.StartPoint, P(38, -10, 0), "h/2")
        nxf.pdim(sk, dat.x, hx, ls[2], nxf.A.StartPoint, P(38, 10, 0), "h/2")
        nxf.diameter_dim(sk, circ, P(10, 0, 0), P(20, 20, 0), "bore_d")
        name, dof = nxf.sketch_status(sk)
        ck("sketch_status.dof_before_finish", dof, 0, 0)
        r = nxf.finish_sketch(sk)
        res["notes"]["sketch1"] = r
        ct("new_sketch+hv_polygon+pdim+diameter_dim: WellConstrained", r["status"] == "WellConstrained", r["status"])
        ck("finish_sketch.dof (datum-plane sketch)", r["dof"], 0, 0)
        f = nxh.extrude(part, nxh.section_region(part, sk, (25, 15, 0)), (0, 0, 1), 0, 10)
        st["body"] = f.GetBodies()[0]
        ck("sketch.region_extrude.volume", vol(st["body"]), (2400 - math.pi * 100) * 10, 0.01)
        nxh.set_expr(part, "w", 80)
        nxh.update()
        ck("sketch.pdim_drives_width (w 60->80)", vol(st["body"]), (3200 - math.pi * 100) * 10, 0.01)
    case("sketch on datum plane", c_datum_plane_sketch)

    def c_face_sketch():
        body = st["body"]
        sk = nxf.new_sketch(part, top_of(body)[0], dat.x, dat.origin, "SK_TOP")
        hole = part.Curves.CreateArc(P(20, 0, 10), V(1, 0, 0), V(0, 1, 0), 2.5, 0.0, 2 * math.pi)
        nxf.add(sk, hole, infer=False)
        sk.CreatePointOnCurveConstraint(nxf.cg(hole, nxf.CP.ArcCenter), nxf.cg(dat.x), nxf.help_at(P(20, 0, 10)))
        nxf.pdim(sk, dat.y, P(0, 50, 0), hole, nxf.A.ArcCenter, P(10, 12, 10), "20")
        nxf.radius_dim(sk, hole, P(22.5, 0, 10), P(25, -12, 10), "2.5")
        r = nxf.finish_sketch(sk)
        res["notes"]["sketch2"] = r
        ck("finish_sketch.dof (face sketch: help_at + radius_dim)", r["dof"], 0, 0)
        nxh.extrude(part, nxh.section(part, curves=[hole], help_point=(22.5, 0, 10)), (0, 0, -1), 0, 10, BOOL.Subtract, body)
        ck("sketch.face_sketch_cut.volume", vol(body), (3200 - math.pi * 100 - math.pi * 6.25) * 10, 0.01)
    case("sketch on face", c_face_sketch)

    def c_to3d_and_hv():
        _f, dp = nxf.datum_plane(part, "angle", [dat.xy, dat.x], 30)
        sk = nxf.new_sketch(part, dp, dat.x, dat.origin, "SK_ANGLED")
        to3d = nxf.sketch_to3d(sk)
        p, o, n = to3d(7, 10), dp.Origin, dp.Normal
        ck("sketch_to3d: point lies on the 30 deg plane", abs((p.X - o.X) * n.X + (p.Y - o.Y) * n.Y + (p.Z - o.Z) * n.Z), 0.0, 1e-9)
        ck("sketch_to3d: |(7,10)| preserved", math.sqrt(p.X ** 2 + p.Y ** 2 + p.Z ** 2), math.sqrt(149.0), 1e-9)
        a = part.Curves.CreateLine(to3d(0, 0), to3d(12, 1))
        b = part.Curves.CreateLine(to3d(12, 1), to3d(13, 9))
        nxf.add(sk, a, b)
        nxf.horizontal(sk, a)
        nxf.vertical(sk, b)
        nxf.finish_sketch(sk)
        da = (a.EndPoint.X - a.StartPoint.X, a.EndPoint.Y - a.StartPoint.Y, a.EndPoint.Z - a.StartPoint.Z)
        db = (b.EndPoint.X - b.StartPoint.X, b.EndPoint.Y - b.StartPoint.Y, b.EndPoint.Z - b.StartPoint.Z)
        ck("horizontal(): line parallel to the X reference", nxh.angle_deg(da, (1, 0, 0)) % 180.0, 0.0, 1e-6)
        ck("vertical(): line perpendicular to the X reference", nxh.angle_deg(db, (1, 0, 0)), 90.0, 1e-6)
    case("sketch_to3d / horizontal / vertical", c_to3d_and_hv)

    def c_centred():
        nxh.expr(part, "cx", 100)
        nxh.expr(part, "rw", 20)
        pt = nxh.point(part, "cx", 60, 0)
        sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "SK_CENTRED")
        nxf.sketch_rect_centered(part, sk, pt, "rw", 10)
        nxf.sketch_circle(part, sk, pt, 6)
        r = nxf.finish_sketch(sk)
        res["notes"]["sketch_centred"] = r
        ck("sketch_rect_centered + sketch_circle: DOF", r["dof"], 0, 0)
        ct("sketch_rect_centered + sketch_circle: WellConstrained", r["status"] == "WellConstrained", r["status"])
        b = nxh.extrude(part, nxh.section_feature(part, [sk.Feature]), (0, 0, 1), 0, 5).GetBodies()[0]
        ck("sketch_rect_centered 20 x 10 with a D6 hole: volume", vol(b), (200 - math.pi * 9) * 5, 0.01)
        ck("sketch_rect_centered: centred on the point (xmin 90)", nxh.bbox(b)[0], 90.0, 1e-6)
        nxh.set_expr(part, "cx", 120)
        nxh.set_expr(part, "rw", 30)
        nxh.update()
        ck("sketch_rect_centered: follows the point and the width expression (xmin 105)", nxh.bbox(b)[0], 105.0, 1e-6)
        ck("sketch_circle: hole follows the point (axis x 120)", nxh.face_data(nxh.faces(b, ftype=nxh.CYLINDER)[0])[1][0], 120.0, 1e-6)
        ck("sketch_rect_centered: volume after the edit", vol(b), (300 - math.pi * 9) * 5, 0.01)
    case("sketch_rect_centered / sketch_circle", c_centred)

    def c_centred_on_sketch_point():
        sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "SK_ON_SKETCH_POINT")
        sp = part.Points.CreatePoint(P(200, 60, 0))
        nxf.add(sk, sp, infer=False)                                    # a point that is geometry OF the sketch
        u, v = nxf.sketch_uv(sk, sp)
        ct("sketch_uv: (u, v) of a 3D point in the sketch; sketch_to3d is its inverse", abs(u - 200) < 1e-9 and abs(v - 60) < 1e-9
           and abs(nxf.sketch_to3d(sk)(u, v).X - 200) < 1e-9, [u, v])
        ls = nxf.sketch_rect_centered(part, sk, sp, 20, 10)
        r = nxf.finish_sketch(sk)
        res["notes"]["sketch_rect_on_sketch_point"] = r
        ct("sketch_rect_centered: centre given as a SKETCH point - the four dimensions are accepted (was refused)", len(ls) == 4 and r["dof"] == 2, r)
        b = nxh.extrude(part, nxh.section(part, curves=ls), (0, 0, 1), 0, 5).GetBodies()[0]
        ck("sketch_rect_centered on a sketch point: 20 x 10 x 5 centred on it (xmin 190)", nxh.bbox(b)[0], 190.0, 1e-6)
        ck("sketch_rect_centered on a sketch point: volume", vol(b), 1000.0, 0.01)
    case("sketch_rect_centered on a sketch point / sketch_uv", c_centred_on_sketch_point)

    def c_centred_inclined():
        # The plane a failure of sketch_rect_centered was reported on: a chamfer face with normal (0, -0.7075, 0.7068)
        # (asymmetric 10 / 10.01 chamfer), and a datum plane at offset 0 on it; the smart point is also the sketch
        # origin. The plane is not the cause (the sketch solver is: group newsolver) - here, legacy solver, it must
        # behave as on the XY plane.
        _f, blk = nxh.block(part, (0, 300, 0), (60, 40, 40))
        e = nxh.one(nxh.edges(blk, lambda b: abs(b[1] - 300) < 1e-6 and abs(b[4] - 300) < 1e-6 and abs(b[2] - 40) < 1e-6
                              and abs(b[5] - 40) < 1e-6), "block edge y 300 / z 40")
        nxf.chamfer(part, [e], 10, second=10.01)
        face = nxh.one([f for f in blk.GetFaces() if nxh.face_data(f)[0] == nxh.PLANE and abs(nxh.face_data(f)[2][1]) > 0.5
                        and abs(nxh.face_data(f)[2][2]) > 0.5], "chamfer face")
        n = tuple(nxh.face_data(face)[2])
        bb = nxh.bbox(face)
        c = ((bb[0] + bb[3]) / 2, (bb[1] + bb[4]) / 2, (bb[2] + bb[5]) / 2)
        note = res["notes"]["inclined"] = {"normal": list(n), "centre": list(c)}
        ct("inclined plane: normal is (0, +-0.7068, +-0.7075) or (0, +-0.7075, +-0.7068), no principal direction",
           abs(n[0]) < 1e-9 and 0.70 < abs(n[1]) < 0.71 and 0.70 < abs(n[2]) < 0.71 and abs(abs(n[1]) - abs(n[2])) > 1e-4, n)
        nxh.expr(part, "ic_x", c[0])
        nxh.expr(part, "ic_w", 20)
        pt = nxh.point(part, "ic_x", c[1], c[2])
        hole = math.pi * 1.5 ** 2

        def check_body(tag, b, x, w, with_hole=True):
            bx = nxh.bbox(b)
            ck("%s: volume (%g x 6%s) x 2" % (tag, w, " - D3 hole" if with_hole else ""), vol(b), (w * 6 - (hole if with_hole else 0)) * 2, 0.01)
            ck("%s: centred on the point along X (%g)" % (tag, x), (bx[0] + bx[3]) / 2, x, 1e-6)
            ck("%s: width along X (%g)" % (tag, w), bx[3] - bx[0], w, 1e-6)
            if with_hole:
                _t, ap, ad, _r = nxh.face_data(nxh.faces(b, ftype=nxh.CYLINDER)[0])
                d = (ap[0] - x, ap[1] - c[1], ap[2] - c[2])
                along = sum(d[i] * n[i] for i in range(3))
                ck("%s: hole axis parallel to the plane normal" % tag, abs(sum(ad[i] * n[i] for i in range(3))), 1.0, 1e-9)
                ck("%s: hole axis passes through the point" % tag, math.sqrt(sum((d[i] - along * n[i]) ** 2 for i in range(3))), 0.0, 1e-6)

        def edit_and_back(tag, b, with_hole=True):
            nxh.set_expr(part, "ic_x", c[0] + 5)
            nxh.set_expr(part, "ic_w", 30)
            nxh.update()
            check_body(tag + ", after ic_x +5 / ic_w 30", b, c[0] + 5, 30, with_hole)
            nxh.set_expr(part, "ic_x", c[0])
            nxh.set_expr(part, "ic_w", 20)
            nxh.update()

        _df, dp = nxf.datum_plane(part, "offset", [face], 0)
        for label, plane in (("chamfer face", face), ("datum plane offset 0 on the face", dp)):
            sk = nxf.new_sketch(part, plane, dat.x, pt, "SK_INCL_" + label.split()[0].upper())
            ct("inclined, %s: a new part of a batch session gives a legacy-solver sketch" % label, nxf.legacy_solver(sk) is True)
            nxf.sketch_rect_centered(part, sk, pt, "ic_w", 6)
            nxf.sketch_circle(part, sk, pt, 3)
            ct("inclined, %s: sketch_anchor in a legacy sketch is the point itself" % label, nxf.sketch_anchor(part, sk, pt).Tag == pt.Tag)
            r = note[label] = nxf.finish_sketch(sk)
            ct("inclined, %s: sketch_rect_centered + sketch_circle on a smart point: WellConstrained, DOF 0, nothing added (5 objects)" % label,
               r["status"] == "WellConstrained" and r["dof"] == 0 and r["auto_dims"] == 0 and r["n_geom"] == 5, r)
            b = nxh.extrude(part, nxh.section_feature(part, [sk.Feature]), n, 0, 2).GetBodies()[0]
            check_body("inclined, " + label, b, c[0], 20)
            edit_and_back("inclined, " + label, b)

        # the point 1 mm OFF the plane, sketch origin elsewhere: its projection is the centre
        off = nxh.point(part, "ic_x", c[1] + n[1], c[2] + n[2])
        sk = nxf.new_sketch(part, dp, dat.x, dat.origin, "SK_INCL_OFF_PLANE")
        uv_on, uv_off = nxf.sketch_uv(sk, pt), nxf.sketch_uv(sk, off)
        ct("inclined: sketch_uv of a point 1 mm off the plane = sketch_uv of its foot point",
           abs(uv_on[0] - uv_off[0]) < 1e-9 and abs(uv_on[1] - uv_off[1]) < 1e-9, [uv_on, uv_off])
        ls = nxf.sketch_rect_centered(part, sk, off, "ic_w", 6)
        r = note["point off the plane"] = nxf.finish_sketch(sk)
        ct("inclined, point 1 mm off the plane: WellConstrained, DOF 0", r["status"] == "WellConstrained" and r["dof"] == 0, r)
        b = nxh.extrude(part, nxh.section_region(part, sk, c, curves=ls), n, 0, 2).GetBodies()[0]
        check_body("inclined, point off the plane (region rule on the returned lines)", b, c[0], 20, with_hole=False)

        # the anchor path that a new-solver sketch takes, forced here: one REFERENCE point carries every reference
        sk = nxf.new_sketch(part, face, dat.x, pt, "SK_INCL_ANCHOR")
        an = nxf.sketch_anchor(part, sk, pt, force=True)
        ct("sketch_anchor(force=True): a point of the sketch named nxf.ANCHOR, not the smart point",
           isinstance(an, NXOpen.Point) and an.Tag != pt.Tag and an.Name == nxf.ANCHOR and an.Tag in {g.Tag for g in sk.GetAllGeometry()}, an.Name)
        ct("sketch_anchor: the second call returns the same anchor", nxf.sketch_anchor(part, sk, pt, force=True).Tag == an.Tag)
        ct("sketch_anchor: a point of the sketch is its own anchor", nxf.sketch_anchor(part, sk, an).Tag == an.Tag)
        nxf.sketch_rect_centered(part, sk, an, "ic_w", 6)
        nxf.sketch_circle(part, sk, an, 3)
        ck("sketch_anchor: still one anchor after two helpers", len([g for g in sk.GetAllGeometry() if g.Name == nxf.ANCHOR]), 1, 0)
        r = note["anchor"] = nxf.finish_sketch(sk)
        ct("sketch_anchor: rectangle + circle on the anchor: WellConstrained, DOF 0, 6 objects",
           r["status"] == "WellConstrained" and r["dof"] == 0 and r["n_geom"] == 6, r)
        b = nxh.extrude(part, nxh.section_feature(part, [sk.Feature]), n, 0, 2).GetBodies()[0]
        check_body("sketch_anchor: whole-sketch section (the anchor is a reference point)", b, c[0], 20)
        edit_and_back("sketch_anchor: the anchor follows the smart point", b)

        # an ACTIVE point besides the profile: the whole-sketch rule takes it in
        sk = nxf.new_sketch(part, face, dat.x, pt, "SK_INCL_ACTIVE_POINT")
        ls = nxf.sketch_rect_centered(part, sk, pt, "ic_w", 6)
        u, v = nxf.sketch_uv(sk, pt)
        nxf.add(sk, part.Points.CreatePoint(nxf.sketch_to3d(sk)(u + 4, v + 1)), infer=False)
        r = nxf.finish_sketch(sk)
        ck("active point besides the profile: the free point is the only open DOF", r["dof"], 2, 0)
        f, err = nxh.attempt("whole sketch with an active point", lambda: nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature]), n, 0, 2))
        note["active point error"] = err
        ct("nxh.section_feature on a sketch with an ACTIVE point: Extrude is refused", f is None and "Cannot extrude" in str(err), err)
        f = nxf.extrude_ex(part, nxh.section_feature(part, [sk.Feature], curves_only=True), n, 0, 2)
        ck("nxh.section_feature(curves_only=True): the point is left out", vol(f.GetBodies()[0]), 240.0, 0.01)
        f = nxf.extrude_ex(part, nxh.section_region(part, sk, c, curves=ls), n, 0, 2)
        ck("nxh.section_region(curves=lines): the point is left out", vol(f.GetBodies()[0]), 240.0, 0.01)
    case("sketch_rect_centered / sketch_circle on an inclined plane, sketch_anchor", c_centred_inclined)

    def c_dof_readout():
        # Is "DOF 0" a real answer? A sketch CREATED with Continuous Auto Dimensioning on (what a batch session
        # starts with) gets every open degree of freedom closed by an automatic dimension at Update(), and
        # GetStatus() says WellConstrained / 0 with no constraint in it at all. The helpers must report the real count.
        pref = nxh.S.Preferences.Sketch
        NOINF = NXOpen.Sketch.InferConstraintsOption.InferNoConstraints
        note = res["notes"]["dof_readout"] = {"session_started_with_auto_dimensioning": AUTO_DIM_AT_START, "rows": []}

        def sketch_created_with_preference_on(name):
            """What a journal gets that does not go through nxf.new_sketch: the same builder, preference left on."""
            pref.ContinuousAutoDimensioning = True
            sb = part.Sketches.CreateSimpleSketchInPlaceBuilder()
            try:
                sb.UseWorkPartOrigin = False
                d = part.Directions.CreateDirection(dat.x, NXOpen.Sense.Forward, nxh.UPD)
                xf = part.Xforms.CreateXformByPlaneXDirPoint(dat.xy, d, dat.origin, nxh.UPD, 0.625, False, False)
                sb.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, nxh.UPD)
                sb.HorizontalReference.Value = dat.x
                sk = sb.Commit()
            finally:
                sb.Destroy()
            sk.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
            sk.SetName(name)
            return sk

        def geometry(kind, sk, x0):
            """Unconstrained test geometry; returns the DOF counted by hand."""
            if kind == "point":
                sk.AddGeometry(part.Points.CreatePoint(P(x0 + 5.0, 7.0, 0.0)), NOINF)
                return 2
            if kind == "line":
                sk.AddGeometry(part.Curves.CreateLine(P(x0, 5.0, 0.0), P(x0 + 20.0, 12.0, 0.0)), NOINF)
                return 4
            if kind == "circle":
                sk.AddGeometry(part.Curves.CreateArc(P(x0 + 10.0, 10.0, 0.0), V(1, 0, 0), V(0, 1, 0), 4.0, 0.0, 2 * math.pi), NOINF)
                return 3
            ls = nxf.hv_polygon(part, sk, [(x0, 5.0), (x0 + 30.0, 5.0), (x0 + 30.0, 25.0), (x0, 25.0)])
            if kind == "rect_hv":                                # 4 lines, coincident corners, H/V: 4 edge positions left
                return 4
            nxf.pdim(sk, dat.y, P(0.0, 50.0, 0.0), ls[3], nxf.A.StartPoint, P(x0 / 2, -8.0, 0.0), str(x0))
            nxf.pdim(sk, dat.x, P(50.0, 0.0, 0.0), ls[0], nxf.A.StartPoint, P(x0 - 6.0, 2.0, 0.0), "5")
            return 2                                             # rect_hv_2dims: two of the four positions dimensioned

        x0 = 300.0
        for kind in ("point", "line", "circle", "rect_hv", "rect_hv_2dims"):
            row = {"kind": kind}
            # (a) the trap: the sketch is created with the preference ON, then read with the raw API
            sk = sketch_created_with_preference_on("SK_TRAP_" + kind.upper())
            want = row["dof_by_count"] = geometry(kind, sk, x0)
            sk.Update()
            raw = sk.GetStatus()
            row["raw_GetStatus_pref_on"] = [raw[0] == NXOpen.Sketch.Status.WellConstrained, raw[1]]
            ct("trap, %s: raw GetStatus() with the preference ON says WellConstrained / 0 (real DOF %d)" % (kind, want),
               raw[0] == NXOpen.Sketch.Status.WellConstrained and raw[1] == 0, row["raw_GetStatus_pref_on"])
            ck("auto_dimensions, %s: one automatic dimension per open DOF" % kind, nxf.auto_dimensions(sk), want, 0)
            # (b) the helpers on that same sketch: preference off again, automatic dimensions counted back in
            name, dof = nxf.sketch_status(sk)
            ct("sketch_status, %s: switches the preference off" % kind, not pref.ContinuousAutoDimensioning)
            ck("sketch_status, %s: real DOF of a sketch created with the preference on" % kind, dof, want, 0)
            ct("sketch_status, %s: UnderConstrained" % kind, name == "UnderConstrained", name)
            r = row["finish_sketch_pref_was_on"] = nxf.finish_sketch(sk)
            ck("finish_sketch, %s: real DOF of a sketch created with the preference on" % kind, r["dof"], want, 0)
            ck("finish_sketch, %s: auto_dims" % kind, r["auto_dims"], want, 0)
            x0 += 100.0
            # (c) the normal path: new_sketch switches the preference off before it creates the sketch
            pref.ContinuousAutoDimensioning = True               # the state a fresh batch session is in
            sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "SK_REAL_" + kind.upper())
            ct("new_sketch, %s: switches Continuous Auto Dimensioning off" % kind, not pref.ContinuousAutoDimensioning)
            pref.ContinuousAutoDimensioning = True               # too late to matter: the sketch already exists
            geometry(kind, sk, x0)
            r = row["finish_sketch"] = nxf.finish_sketch(sk)
            ck("finish_sketch, %s: DOF = hand count (sketch created by new_sketch)" % kind, r["dof"], want, 0)
            ck("finish_sketch, %s: no automatic dimension was created" % kind, r["auto_dims"], 0, 0)
            ct("finish_sketch, %s: UnderConstrained" % kind, r["status"] == "UnderConstrained", r["status"])
            note["rows"].append(row)
            x0 += 100.0

        # the countdown: free point 2 -> on the X axis 1 -> + one dimension 0
        sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "SK_COUNTDOWN")
        pt = part.Points.CreatePoint(P(x0 + 5.0, 7.0, 0.0))
        sk.AddGeometry(pt, NOINF)
        trace = []
        for step, want in (("free point", 2), ("point on the X axis", 1), ("+ distance from the Y axis", 0)):
            if want == 1:
                sk.CreatePointOnCurveConstraint(nxf.cg(pt), nxf.cg(dat.x), nxf.help_at(P(x0 + 5.0, 0.0, 0.0)))
            elif want == 0:
                nxf.pdim(sk, dat.y, P(0.0, 50.0, 0.0), pt, nxf.A.StartPoint, P(x0 / 2, -8.0, 0.0), str(x0 + 5.0))
            sk.Update()
            name, dof = nxf.sketch_status(sk)
            trace.append([step, name, dof])
            ck("countdown: %s -> DOF %d" % (step, want), dof, want, 0)
        note["countdown"] = trace
        r = nxf.finish_sketch(sk)
        ct("countdown: finished sketch WellConstrained / 0, no automatic dimension",
           r["status"] == "WellConstrained" and r["dof"] == 0 and r["auto_dims"] == 0, r)
        ct("auto_dimensioning_off: returns False when it is already off", nxf.auto_dimensioning_off() is False)
    case("DOF read-out (Continuous Auto Dimensioning)", c_dof_readout)


# ============================================================================ datum
def g_datum(part):
    dat = nxh.Datums(part)
    nxh.expr(part, "dp_off", 15)
    nxh.expr(part, "dp_ang", 30, "deg")
    _f, blk = nxh.block(part, (0, 0, 0), (60, 40, 20))
    _f, cyl = nxh.cylinder(part, (100, 0, 0), (0, 0, 1), 20, 30)
    cyl_face = nxh.faces(cyl, ftype=nxh.CYLINDER)[0]
    top = top_of(blk)[0]
    fx0 = nxh.faces(blk, ftype=nxh.PLANE, normal=(-1, 0, 0))[0]
    fx1 = nxh.faces(blk, ftype=nxh.PLANE, normal=(1, 0, 0))[0]
    keep = {}

    def par(n, v):
        m = math.sqrt(sum(x * x for x in v))
        return abs(n.X * v[0] + n.Y * v[1] + n.Z * v[2]) / m

    def c_offset():
        _f, dp = nxf.datum_plane(part, "offset", [dat.xy], "dp_off", "DP_OFF")
        keep["dp_off"] = dp
        ck("datum_plane.offset(datum, expr).z", dp.Origin.Z, 15.0, 1e-6)
        nxh.set_expr(part, "dp_off", 22)
        nxh.update()
        ck("datum_plane.offset follows the expression", dp.Origin.Z, 22.0, 1e-6)
        _f, dp2 = nxf.datum_plane(part, "offset", [top], 5)
        ck("datum_plane.offset(face, 5).z", dp2.Origin.Z, 25.0, 1e-6)
        _f, dp3 = nxf.datum_plane(part, "offset", [top], 5, flip=True)
        res["notes"]["datum_plane.flip"] = {"origin_z": dp3.Origin.Z, "normal_z": dp3.Normal.Z, "unflipped_normal_z": dp2.Normal.Z}
        ck("datum_plane.flip=True reverses the NORMAL", dp3.Normal.Z, -dp2.Normal.Z, 1e-9)
    case("datum plane offset", c_offset)

    def c_angle():
        _f, dp = nxf.datum_plane(part, "angle", [dat.xy, dat.x], "dp_ang")
        ck("datum_plane.angle 30: |n.z| = cos 30", abs(dp.Normal.Z), math.cos(math.radians(30)), 1e-6)
        ck("datum_plane.angle 30: n.x = 0", dp.Normal.X, 0.0, 1e-9)
    case("datum plane angle", c_angle)

    def c_assoc_direction():
        # a direction taken from an OBJECT follows that object (inclined ports, bolt circles about a port axis)
        nxh.expr(part, "tilt", 30, "deg")
        _f, tp = nxf.datum_plane(part, "angle", [dat.xy, dat.x], "tilt")
        f1 = nxf.extrude_ex(part, nxh.section(part, curves=nxh.rect(part, 200, -5, 210, 5, 0.0), help_point=(200, -5, 0)), tp, start=0, end=20)
        b1 = f1.GetBodies()[0]
        ck("extrude_ex(vec=datum plane): along the plane normal, z extent 20 cos 30", nxh.bbox(b1)[5] - nxh.bbox(b1)[2], 20 * math.cos(math.radians(30)), 1e-3)
        f2 = nxf.extrude_ex(part, nxh.section(part, curves=nxh.rect(part, 230, -5, 240, 5, 0.0), help_point=(230, -5, 0)), tp, start=0, end=20, reverse=True)
        b2 = f2.GetBodies()[0]
        ck("extrude_ex(reverse=True): the opposite way", nxh.bbox(b2)[2] + nxh.bbox(b2)[5], -(nxh.bbox(b1)[2] + nxh.bbox(b1)[5]), 1e-3)
        ck("_num evaluates a Degrees expression name", nxf._num(part, "tilt"), 30.0, 1e-9)
        nxh.set_expr(part, "tilt", 45)
        nxh.update()
        ck("extrude_ex(vec=datum plane): follows the plane, tilt 45 -> z extent 20 cos 45", nxh.bbox(b1)[5] - nxh.bbox(b1)[2], 20 * math.cos(math.radians(45)), 1e-3)
        _fa, ax = nxf.datum_axis(part, "point_dir", (300, 0, 0), (0, 0, 1))
        _f, disc = nxh.cylinder(part, (300, 0, 0), (0, 0, 1), 60, 10)
        fh, _ = nxh.cylinder(part, (320, 0, 0), (0, 0, 1), 6, 10, BOOL.Subtract, disc)
        nxf.pattern_circular(part, [fh], None, ax, 4)
        ck("pattern_circular(vec=datum axis): 4 holes about the datum axis", len(nxh.faces(disc, ftype=nxh.CYLINDER, radius=3.0)), 4, 0)
        ck("pattern_circular(vec=datum axis): second hole at 90 deg", nxh.dist_to(part, disc, (300, 23, 5)), 0.0, 1e-6)
        v0 = nxh.volume(part, disc)
        nxf.hole(part, disc, [(300, 0, 0)], 4, depth=5, vector=ax)
        ck("hole(vector=datum axis): drilled along the axis from the bottom face", v0 - nxh.volume(part, disc), math.pi * 4 * 5, 1e-3)
    case("associative directions (extrude_ex / pattern_circular / hole)", c_assoc_direction)

    def c_three_points():
        pts = [nxh.point(part, 0, 0, 30), nxh.point(part, 10, 0, 30), nxh.point(part, 0, 10, 40)]
        _f, dp = nxf.datum_plane(part, "three_points", pts)
        ck("datum_plane.three_points: n || (0,-1,1)", par(dp.Normal, (0, -1, 1)), 1.0, 1e-6)
    case("datum plane three points", c_three_points)

    def c_bisector():
        _f, dp = nxf.datum_plane(part, "bisector", [fx0, fx1])
        ck("datum_plane.bisector.x", dp.Origin.X, 30.0, 1e-6)
        ck("datum_plane.bisector: n || X", par(dp.Normal, (1, 0, 0)), 1.0, 1e-6)
    case("datum plane bisector", c_bisector)

    def c_coincident():
        _f, dp = nxf.datum_plane(part, "coincident", [top])
        ck("datum_plane.coincident.z", dp.Origin.Z, 20.0, 1e-6)
    case("datum plane coincident", c_coincident)

    def c_tangent():
        _f, dp = nxf.datum_plane(part, "tangent", [cyl_face])
        o, n = dp.Origin, dp.Normal
        ck("datum_plane.tangent: distance from the cylinder axis", abs((o.X - 100) * n.X + o.Y * n.Y), 10.0, 1e-5)
    case("datum plane tangent", c_tangent)

    def c_on_curve():
        edge = [e for e in blk.GetEdges() if abs(nxh.bbox(e)[1]) < 1e-6 and abs(nxh.bbox(e)[4]) < 1e-6
                and abs(nxh.bbox(e)[2]) < 1e-6 and abs(nxh.bbox(e)[5]) < 1e-6][0]
        _f, dp = nxf.datum_plane(part, "on_curve", [edge], 25)
        ck("datum_plane.on_curve 25 %: x", dp.Origin.X, 15.0, 1e-4)
        ck("datum_plane.on_curve: n || edge", par(dp.Normal, (1, 0, 0)), 1.0, 1e-6)
    case("datum plane on curve", c_on_curve)

    def c_axes():
        _f, ax = nxf.datum_axis(part, "point_dir", ("dp_off+48", 0, 0), (0, 1, 0))
        ck("datum_axis.point_dir.origin_x", ax.Origin.X, 70.0, 1e-6)
        ck("datum_axis.point_dir: dir || Y", par(ax.Direction, (0, 1, 0)), 1.0, 1e-6)
        _f, ax = nxf.datum_axis(part, "two_points", (0, 0, 40), (10, 10, 40))
        ck("datum_axis.two_points: dir || (1,1,0)", par(ax.Direction, (1, 1, 0)), 1.0, 1e-6)
        _f, ax = nxf.datum_axis(part, "face_axis", cyl_face)
        ck("datum_axis.face_axis.origin_x", ax.Origin.X, 100.0, 1e-6)
        ck("datum_axis.face_axis: dir || Z", par(ax.Direction, (0, 0, 1)), 1.0, 1e-6)
        _f, ax = nxf.datum_axis(part, "intersection", keep["dp_off"], dat.xz)
        ck("datum_axis.intersection.z", ax.Origin.Z, 22.0, 1e-6)
        ck("datum_axis.intersection: dir || X", par(ax.Direction, (1, 0, 0)), 1.0, 1e-6)
    case("datum axes", c_axes)


# ============================================================================ solid features A
def pappus(poly_rz):
    """Volume of a closed (r, z) polygon revolved 360 deg about the z axis."""
    a = cx = 0.0
    n = len(poly_rz)
    for i in range(n):
        (r0, z0), (r1, z1) = poly_rz[i], poly_rz[(i + 1) % n]
        cr = r0 * z1 - r1 * z0
        a += cr
        cx += (r0 + r1) * cr
    a *= 0.5
    return abs(2.0 * math.pi * cx / (6.0 * a) * a)


def g_solid_a(part):
    D = nxh.Datums(part)
    vol = lambda b: nxh.volume(part, b)  # noqa: E731

    def c_revolve():
        crv = nxh.polyline(part, [(10, 0, 0), (20, 0, 0), (20, 0, 5), (10, 0, 5)])
        f = nxf.revolve(part, nxh.section(part, curves=crv, help_point=(10, 0, 0)), nxh.axis(part, (0, 0, 0), (0, 0, 1)))
        ck("revolve.360.volume", vol(f.GetBodies()[0]), math.pi * 300 * 5, 1e-3)
        crv = nxh.polyline(part, [(30, 0, 0), (35, 0, 0), (35, 0, 5), (30, 0, 5)])
        f = nxf.revolve(part, nxh.section(part, curves=crv, help_point=(30, 0, 0)), nxf.axis_from(part, D.z), 0, 180)
        ck("revolve+axis_from(datum axis).180.volume", vol(f.GetBodies()[0]), math.pi * 325 * 5 / 2, 1e-3)
        o = nxf.axis_from(part, D.z).Origin
        res["notes"]["axis_from(datum Z).Origin"] = [o.X, o.Y, o.Z]
        ck("axis_from(datum axis): origin lies on the axis line (x)", o.X, 0.0, 1e-9)
        ck("axis_from(datum axis): origin lies on the axis line (y)", o.Y, 0.0, 1e-9)
        o2 = part.Axes.CreateAxis(nxh.point(part, 0, 0, 7), part.Directions.CreateDirection(D.z, NXOpen.Sense.Forward, nxh.UPD),
                                  nxh.UPD).Origin
        ck("axis with an explicit point (docstring route): origin z", o2.Z, 7.0, 1e-9)
        cb = part.Features.CreateCylinderBuilder(nxh.NULL_FEATURE)
        try:
            cb.Type = NXOpen.Features.CylinderBuilder.Types.AxisDiameterAndHeight
            cb.Axis = nxf.axis_from(part, D.z)
            cb.Diameter.RightHandSide = "10"
            cb.Height.RightHandSide = "20"
            cb.BooleanOption.Type = BOOL.Create
            cb.BooleanOption.SetTargetBodies([NXOpen.Body.Null])
            bbc = nxh.bbox(cb.CommitFeature().GetBodies()[0])
        finally:
            cb.Destroy()
        res["notes"]["cylinder on axis_from(datum Z): bbox"] = bbc
        ck("axis_from(datum axis) as a Cylinder axis: the body is ON the axis line (x centre)", (bbc[0] + bbc[3]) / 2, 0.0, 1e-6)
        ln = [nxh.line(part, (10, 0, 20), (20, 0, 50))]
        f = nxf.revolve(part, nxh.section(part, curves=ln, help_point=(10, 0, 20)), nxh.axis(part, (0, 0, 0), (0, 0, 1)), sheet=True)
        ck("revolve.sheet.area", nxh.sheet_area(part, f.GetBodies()[0])[0], math.pi * 30 * math.hypot(10, 30), 0.01)
        _fc, shaft = nxh.cylinder(part, (200, 0, 0), (0, 0, 1), 40, 30)
        v0 = vol(shaft)
        crv = nxh.polyline(part, [(217, 0, 10), (221, 0, 10), (221, 0, 14), (217, 0, 14)])
        nxf.revolve(part, nxh.section(part, curves=crv, help_point=(217, 0, 10)),
                    nxf.axis_from(part, nxh.faces(shaft, ftype=nxh.CYLINDER, radius=20.0)[0]), 0, 360, BOOL.Subtract, shaft)
        ck("revolve.Subtract groove, axis_from(cylinder face)", v0 - vol(shaft), math.pi * (400 - 289) * 4, 1e-3)
        nxh.expr(part, "rv_wall", 2)
        thin = [nxh.line(part, (320, 0, 0), (320, 0, 30)), nxh.line(part, (320, 0, 30), (330, 0, 40))]
        f = nxf.revolve(part, nxh.section(part, curves=thin, help_point=(320, 0, 0)), nxh.axis(part, (300, 0, 0), (0, 0, 1)),
                        offset=(0, "rv_wall"))
        t = 2.0
        sq = t / math.sqrt(2.0)
        ck("revolve.offset=(0, wall) thin wall from an open profile", vol(f.GetBodies()[0]),
           pappus([(20, 0), (20, 30), (30, 40), (30 - sq, 40 + sq), (20 - t, 30 + t * (math.sqrt(2.0) - 1.0)), (20 - t, 0)]), 0.01)
    case("revolve", c_revolve)

    def c_shell():
        _f, b = nxh.block(part, (0, 100, 0), (80, 60, 30))
        nxf.shell(part, b, top_of(b), 2)
        ck("shell.inward.volume", vol(b), 144000 - 76 * 56 * 28, 1e-3)
        ck("shell.inward keeps the outside size", nxh.bbox(b)[3] - nxh.bbox(b)[0], 80.0, 1e-6)
        _f, b = nxh.block(part, (0, 200, 0), (80, 60, 30))
        nxf.shell(part, b, top_of(b), 2, alternate=[(nxh.faces(b, ftype=nxh.PLANE, normal=(0, 0, -1)), 3)])
        ck("shell.alternate_floor_3.volume", vol(b), 144000 - 76 * 56 * 27, 1e-3)
        _f, b = nxh.block(part, (0, 300, 0), (80, 60, 30))
        nxf.shell(part, b, top_of(b), 2, inward=False)
        ck("shell.outward.volume", vol(b), 84 * 64 * 32 - 144000, 1e-3)
        ck("shell.outward grows the outside", nxh.bbox(b)[3] - nxh.bbox(b)[0], 84.0, 1e-6)
        _f, b = nxh.block(part, (100, 300, 0), (80, 60, 30))
        nxf.shell(part, b, [], 2)
        ck("shell.no removed face -> closed hollow body", vol(b), 144000 - 76 * 56 * 26, 1e-3)
    case("shell", c_shell)

    def frustum(a_deg, h=30.0):
        g = h * math.tan(math.radians(a_deg))
        return h / 6.0 * (4800 + 4 * (80 - g) * (60 - g) + (80 - 2 * g) * (60 - 2 * g))

    def c_draft():
        _f, b = nxh.block(part, (0, 400, 0), (80, 60, 30))
        bottom = nxh.faces(b, ftype=nxh.PLANE, normal=(0, 0, -1))
        f, e = nxf.draft_faces(part, side_walls(b), (0, 0, 1), 5, stationary_faces=bottom)
        ck("draft_faces.+5 from bottom along +Z shrinks the top", vol(b), frustum(5), 0.01)
        ck("draft_faces.top width", nxh.bbox(top_of(b)[0])[3], 80 - 30 * math.tan(math.radians(5)), 1e-3)
        nxh.expr(part, "draft_a", 3, "deg")
        nxh.expr(part, "draft_n", "draft_a", None)
        _f, b2 = nxh.block(part, (0, 500, 0), (80, 60, 30))
        f, e = nxf.draft_faces(part, side_walls(b2), (0, 0, -1), 2, stationary_faces=top_of(b2), link="draft_n")
        ck("draft_faces.link to a unitless expression (3 deg)", vol(b2), frustum(3), 0.01)
        nxh.set_expr(part, "draft_a", 7)
        nxh.update()
        ck("draft_faces.expression edit 3 -> 7 deg", vol(b2), frustum(7), 0.01)
        n = nxh.face_data(side_walls(b2)[0])[2]
        ck("draft_faces.wall angle", math.degrees(math.asin(abs(n[2]))), 7.0, 1e-4)
        _f, b3 = nxh.block(part, (100, 400, 0), (80, 60, 30))
        _fp, mid = nxh.datum_plane(part, (0, 0, 15), (0, 0, 1), "PIVOT")
        nxf.draft_faces(part, side_walls(b3), (0, 0, 1), 5, stationary_datum=mid)
        g = 15 * math.tan(math.radians(5))
        want = (15 / 6.0 * (4800 + 4 * (80 - g) * (60 - g) + (80 - 2 * g) * (60 - 2 * g))
                + 15 / 6.0 * (4800 + 4 * (80 + g) * (60 + g) + (80 + 2 * g) * (60 + 2 * g)))
        ck("draft_faces.stationary_datum pivots about the plane", vol(b3), want, 0.01)
    case("draft_faces", c_draft)

    def c_draft_body():
        _f, b = nxh.block(part, (0, 600, 0), (80, 60, 30))
        plane = nxh.datum_plane(part, (0, 600, 15), (0, 0, 1), "PARTING")[1]
        nxf.draft_body(part, side_walls(b), plane, (0, 0, 1), 3)
        g = 15 * math.tan(math.radians(3))
        want = 2 * 15 / 6.0 * (4800 + 4 * (80 + g) * (60 + g) + (80 + 2 * g) * (60 + 2 * g))
        ck("draft_body.3deg.volume", vol(b), want, 0.01)
        ck("draft_body.widest at the parting plane", nxh.bbox(b)[3], 80 + g, 1e-3)
    case("draft_body", c_draft_body)

    def c_rib():
        _f, b = nxh.block(part, (0, 700, 0), (80, 60, 30))
        nxf.shell(part, b, top_of(b), 2)
        _fp, plane = nxh.datum_plane(part, (0, 700, 20), (0, 0, 1), "RIB_CAP")
        sk = nxf.sketch_lines(part, plane, D.x, D.origin, [((20, 730, 20), (60, 730, 20))], "SK_RIB")
        v0, n0 = vol(b), len(nxh.solids(part))
        f = nxf.rib(part, b, sk, (20, 730, 20), 1.5)
        ck("sketch_lines+rib.added volume (76 x 1.5 x 18)", vol(b) - v0, 76 * 1.5 * 18, 0.01)
        ck("rib.solid count unchanged", len(nxh.solids(part)), n0, 0)
        ct("rib.feature type", f.FeatureType == "RIB", f.FeatureType)
        # the other cap-plane normal: which ReverseRibDirection works is found by rib() itself
        _f, b2 = nxh.block(part, (100, 700, 0), (80, 60, 30))
        nxf.shell(part, b2, top_of(b2), 2)
        _fp, plane2 = nxh.datum_plane(part, (0, 700, 20), (0, 0, -1), "RIB_CAP_DOWN")
        sk2 = nxf.sketch_lines(part, plane2, D.x, D.origin, [((120, 730, 20), (160, 730, 20))], "SK_RIB2")
        forced = {}
        for rev in (True, False):
            m = nxh.mark("forced rib", False)
            try:
                nxf.rib(part, b2, sk2, (120, 730, 20), 1.5, reverse=rev)
                forced[str(rev)] = "ok"
            except NXOpen.NXException as e:
                forced[str(rev)] = str(e)
            nxh.undo_to(m)
        res["notes"]["rib.forced_reverse_plane_normal_-Z"] = forced
        v0 = vol(b2)
        nxf.rib(part, b2, sk2, (120, 730, 20), 1.5)
        ck("rib.reverse=None finds the working direction (cap normal -Z)", vol(b2) - v0, 76 * 1.5 * 18, 0.01)
        ct("rib.exactly one forced direction works", sorted(forced.values()).count("ok") == 1, forced)
        _f, b3 = nxh.block(part, (200, 700, 0), (80, 60, 30))
        nxf.shell(part, b3, top_of(b3), 2)
        sk3 = nxf.sketch_lines(part, plane, D.x, D.origin, [((220, 730, 20), (260, 730, 20))], "SK_RIB3")
        v0 = vol(b3)
        nxf.rib(part, b3, sk3, (220, 730, 20), 1.5, draft_deg=2)
        ck("rib.draft_deg=2 from the cap", vol(b3) - v0, (1.5 + 18 * math.tan(math.radians(2))) * 18 * 76, 0.01)
    case("rib", c_rib)

    def c_gusset():
        _f, b = nxh.block(part, (0, 800, 0), (60, 40, 45))
        removed = [nxh.faces(b, ftype=nxh.PLANE, normal=n)[0] for n in ((1, 0, 0), (0, 0, 1), (0, 1, 0), (0, -1, 0))]
        nxf.shell(part, b, removed, 5)
        ck("shell.four faces removed -> L bracket", vol(b), 20000.0, 0.01)
        nxf.gusset_rib(part, b, D, (0, 820, 0), (0, 1, 0), (5, 820, 45), (60, 820, 5), (10, 820, 10), 4)
        ck("gusset_rib.added volume (0.5 x 40 x 55 x 4)", vol(b) - 20000.0, 4400.0, 0.01)
        _f, b2 = nxh.block(part, (100, 800, 0), (60, 40, 45))
        removed = [nxh.faces(b2, ftype=nxh.PLANE, normal=n)[0] for n in ((1, 0, 0), (0, 0, 1), (0, 1, 0), (0, -1, 0))]
        nxf.shell(part, b2, removed, 5)
        nxf.gusset_rib(part, b2, D, (0, 820, 0), (0, -1, 0), (160, 820, 5), (105, 820, 45), (110, 820, 10), 4)
        ck("gusset_rib.other plane normal + other line order", vol(b2) - 20000.0, 4400.0, 0.01)
        # plane normal X (datum Y as horizontal reference), end points and plane position from expressions
        for n_, v_ in (("gus_x", 320), ("gus_h", 45), ("gus_len", 60)):
            nxh.expr(part, n_, v_)
        _f, bx = nxh.block(part, (300, 800, 0), (40, 60, 45))
        removed = [nxh.faces(bx, ftype=nxh.PLANE, normal=n)[0] for n in ((0, 1, 0), (0, 0, 1), (1, 0, 0), (-1, 0, 0))]
        nxf.shell(part, bx, removed, 5)
        ck("gusset_rib.X: L bracket in the YZ plane", vol(bx), 20000.0, 0.01)
        info = {}
        nxf.gusset_rib(part, bx, D, ("gus_x", 0, 0), (1, 0, 0), (320, 805, "gus_h"), (320, "800+gus_len", 5), (320, 810, 10), 4,
                       info=info)
        ck("gusset_rib.plane normal X: added volume", vol(bx) - 20000.0, 4400.0, 0.01)
        ck("gusset_rib.plane normal X: sketch DOF", info["dof"], 0, 0)
        ct("gusset_rib.plane normal X: sketch WellConstrained", info["status"] == "WellConstrained", info["status"])
        nxh.set_expr(part, "gus_h", 35)
        nxh.set_expr(part, "gus_x", 310)
        nxh.update()
        ck("gusset_rib.end-point expression 45 -> 35", vol(bx) - 20000.0, 0.5 * 30 * 55 * 4, 0.01)
        ck("gusset_rib.plane expression 320 -> 310: rib side face at x = 308", nxh.dist_to(part, bx, (308, 830, 12)), 0.0, 1e-6)
        # plane normal Z
        _f, bz = nxh.block(part, (400, 800, 0), (60, 45, 40))
        removed = [nxh.faces(bz, ftype=nxh.PLANE, normal=n)[0] for n in ((1, 0, 0), (0, 1, 0), (0, 0, 1), (0, 0, -1))]
        nxf.shell(part, bz, removed, 5)
        ck("gusset_rib.Z: L bracket in the XY plane", vol(bz), 20000.0, 0.01)
        info = {}
        nxf.gusset_rib(part, bz, D, (0, 0, 20), (0, 0, -1), (405, 845, 20), (460, 805, 20), (410, 810, 20), 4, info=info)
        ck("gusset_rib.plane normal Z: added volume", vol(bz) - 20000.0, 4400.0, 0.01)
        ck("gusset_rib.plane normal Z: sketch DOF", info["dof"], 0, 0)
        # plane normal Y with end points ON the datum axes (zero coordinates -> point-on-axis constraints)
        _f, floor = nxh.block(part, (0, 900, -5), (60, 40, 5))
        _f, upright = nxh.block(part, (-5, 900, -5), (5, 40, 50))
        nxh.unite(part, floor, [upright])
        v0 = vol(floor)
        info = {}
        nxf.gusset_rib(part, floor, D, (0, 920, 0), (0, 1, 0), (0, 920, 40), (55, 920, 0), (5, 920, 5), 4, info=info)
        ck("gusset_rib.plane normal Y, zero coordinates: added volume", vol(floor) - v0, 0.5 * 40 * 55 * 4, 0.01)
        ck("gusset_rib.plane normal Y, zero coordinates: sketch DOF", info["dof"], 0, 0)
        # plane= an existing datum plane offset from a face of ANOTHER body (the linked-face case)
        nxh.expr(part, "gus_off", 20)
        _f, ref = nxh.block(part, (500, 790, 0), (10, 10, 10))
        _f, bp = nxh.block(part, (500, 800, 0), (60, 40, 45))
        removed = [nxh.faces(bp, ftype=nxh.PLANE, normal=n)[0] for n in ((1, 0, 0), (0, 0, 1), (0, 1, 0), (0, -1, 0))]
        nxf.shell(part, bp, removed, 5)
        _f, dpl = nxf.datum_plane(part, "offset", [nxh.faces(ref, ftype=nxh.PLANE, normal=(0, 1, 0))[0]], "gus_off")
        info = {}
        nxf.gusset_rib(part, bp, D, None, None, (505, 820, 45), (560, 820, 5), (510, 820, 10), 4, info=info, plane=dpl)
        ck("gusset_rib.plane=<datum plane offset from another body's face>: added volume", vol(bp) - 20000.0, 4400.0, 0.01)
        ck("gusset_rib.plane=: sketch DOF", info["dof"], 0, 0)
        nxh.set_expr(part, "gus_off", 10)
        nxh.update()
        ck("gusset_rib.plane=: rib follows the plane (side face at y 808)", nxh.dist_to(part, bp, (520, 808, 8)), 0.0, 1e-6)
        ck("gusset_rib.plane=: volume unchanged after the move", vol(bp) - 20000.0, 4400.0, 0.01)
    case("gusset_rib", c_gusset)


# ============================================================================ solid features B
def g_solid_b(part):
    vol = lambda b: nxh.volume(part, b)  # noqa: E731
    area = 80 * 60 - 4 * K * 64
    c = (0.5 - math.pi / 4 * (1 - 4 / (3 * math.pi))) / K
    removed_top = K * 25 * (2 * 64 + 2 * 44) + K * 25 * 2 * math.pi * (8 - c * 5)

    def c_blend():
        _f, b1 = nxh.block(part, (0, 0, 0), (80, 60, 30))
        nxf.edge_blend(part, [(vertical_edges(b1, 30), 8), (nxh.edges_at(b1, 2, 30.0), 5)])
        ck("edge_blend.two chainsets (R8 vertical + R5 top)", vol(b1), area * 30 - removed_top, 0.5)
        ck("edge_blend.face count", nxh.face_census(b1)["faces"], 18, 0)
        _f, b2 = nxh.block(part, (100, 0, 0), (80, 60, 30))
        nxf.edge_blend(part, [(vertical_edges(b2, 30), 8)])
        seed = nxh.edges(b2, lambda q: abs(q[2] - 30) < 1e-3 and abs(q[5] - 30) < 1e-3)[0]
        nxf.edge_blend(part, [(nxf.tangent_edges(part, seed), 5)])
        ck("tangent_edges: chain blend == two-chainset blend", vol(b2), vol(b1), 1e-6)
    case("edge_blend chainsets", c_blend)

    def top_edge_y(b, y):
        return nxh.edges(b, lambda q: abs(q[2] - 30) < 1e-3 and abs(q[5] - 30) < 1e-3 and abs(q[1] - y) < 1e-3 and abs(q[4] - y) < 1e-3)[0]

    def c_blend_variable():
        _f, b3 = nxh.block(part, (200, 0, 0), (80, 60, 30))
        e = top_edge_y(b3, 0)
        nxf.edge_blend(part, [([e], 2)], variable=[(e, 0, 2), (e, 100, 6)])
        ck("edge_blend.variable 2 -> 6: removed", 144000 - vol(b3), K * 80 * (4 + 12 + 36) / 3, 0.15)
    case("edge_blend variable", c_blend_variable)

    def c_blend_stop_short():
        _f, b = nxh.block(part, (0, 100, 0), (80, 60, 30))
        e = top_edge_y(b, 100)
        nxf.edge_blend(part, [([e], 5)], stop_short=[(e, True, 15)])
        ck("edge_blend.stop_short 15 %: removed", 144000 - vol(b), K * 25 * 80 * 0.85, 0.15)
    case("edge_blend stop short", c_blend_stop_short)

    def c_blend_setback():
        _f, b = nxh.block(part, (100, 100, 0), (80, 60, 30))
        corner = (180, 160, 30)

        def three():
            return [e for e in b.GetEdges() if any(abs(p.X - corner[0]) < 1e-6 and abs(p.Y - corner[1]) < 1e-6
                                                   and abs(p.Z - corner[2]) < 1e-6 for p in e.GetVertices())]
        m = nxh.mark("plain", False)
        nxf.edge_blend(part, [(three(), 10)])
        plain = 144000 - vol(b)
        nxh.undo_to(m)
        f = nxf.edge_blend(part, [(three(), 10)], setback=(corner, 15))
        sb = 144000 - vol(b)
        res["notes"]["setback"] = {"plain_removed": plain, "setback_removed": sb}
        ck("edge_blend.setback: 1 radius + 3 setback expressions", len(f.GetExpressions()), 4, 0)
        ct("edge_blend.setback removes more than the plain corner", sb > plain + 100, "%.3f vs %.3f" % (sb, plain))
    case("edge_blend setback", c_blend_setback)

    def c_face_blend():
        _f, b4 = nxh.block(part, (300, 0, 0), (80, 60, 30))
        nxf.face_blend(part, top_of(b4), nxh.faces(b4, ftype=nxh.PLANE, normal=(1, 0, 0)), 4)
        ck("face_blend.R4: removed", 144000 - vol(b4), K * 16 * 60, 0.15)
    case("face_blend", c_face_blend)

    def c_chamfer():
        _f, b5 = nxh.block(part, (400, 0, 0), (80, 60, 30))
        ve = vertical_edges(b5, 30)
        v = vol(b5)
        nxf.chamfer(part, [ve[0]], 2)
        ck("chamfer.symmetric 2: removed", v - vol(b5), 60.0, 0.01)
        v = vol(b5)
        nxf.chamfer(part, [ve[1]], 2, second=4)
        ck("chamfer.two offsets 2 x 4: removed", v - vol(b5), 120.0, 0.01)
        v = vol(b5)
        nxf.chamfer(part, [ve[2]], 3, angle=30)
        ck("chamfer.offset 3 + angle 30: removed", v - vol(b5), 3 * 3 * math.tan(math.radians(30)) / 2 * 30, 0.01)
    case("chamfer", c_chamfer)

    def c_edge_treatment():
        # census: convex / concave / smooth
        _f, eb = nxh.block(part, (0, 900, 0), (40, 30, 20))
        nxh.block(part, (10, 910, 15), (20, 10, 5), NXOpen.Features.Feature.BooleanType.Subtract, eb)      # pocket 20 x 10 x 5
        se = nxf.sharp_edges(part, eb)
        ck("sharp_edges: block with a pocket - convex edges (12 + 4 rim)", sum(1 for _e, k in se if k == "convex"), 16, 0)
        ck("sharp_edges: concave edges (4 floor + 4 corner)", sum(1 for _e, k in se if k == "concave"), 8, 0)
        ck("sharp_edges(min_length=6): the four 5 mm pocket corners drop out", len(nxf.sharp_edges(part, eb, convex=False, min_length=6.0)), 4, 0)
        # blend_chains: three chains, the third needs the fallback
        _f, bb_ = nxh.block(part, (100, 900, 0), (40, 30, 20))
        nxh.block(part, (110, 905, 20), (10, 10, 4), NXOpen.Features.Feature.BooleanType.Unite, bb_)        # boss 10 x 10 x 4
        nxh.block(part, (130, 905, 20), (8, 8, 4), NXOpen.Features.Feature.BooleanType.Unite, bb_)          # boss 8 x 8 x 4
        v0 = vol(bb_)
        boss_top = lambda: [e for e in bb_.GetEdges() if abs(nxh.bbox(e)[2] - 24) < 1e-6 and abs(nxh.bbox(e)[5] - 24) < 1e-6  # noqa: E731
                            and nxh.bbox(e)[3] < 121]
        rep = nxf.blend_chains(part, [vertical_edges(bb_, 20), (boss_top, 6)], 3, smaller=(0.5,), overflow=False)
        res["notes"]["blend_chains"] = [{k_: v for k_, v in r.items() if k_ != "untreated_edges"} for r in rep]
        ct("blend_chains: chain 1 (4 vertical edges) blended at the requested radius", rep[0]["built"] == "blend" and rep[0]["treated"] == 4, rep[0]["built"])
        ct("blend_chains: chain 2 (R6 on the top of a 4 high boss) refused, built at half the radius",
           rep[1]["built"] == "blend, smaller" and rep[1]["size"] == "(6)*0.5", [rep[1]["built"], rep[1]["size"], rep[1]["errors"]])
        v1 = vol(bb_)
        ct("blend_chains: both chains removed material (4 x R3 x 20 = 154.5 and the boss top)", v0 - v1 > 4 * (1 - math.pi / 4) * 9 * 20 + 10.0, v0 - v1)
        boss2 = [e for e in vertical_edges(bb_, 4) if 129 < nxh.bbox(e)[0] < 139]
        rep = nxf.blend_chains(part, [boss2], 10, smaller=(), chamfer=1, overflow=False)
        res["notes"]["blend_chains.chamfer"] = [{k_: v for k_, v in r.items() if k_ != "untreated_edges"} for r in rep]
        ct("blend_chains: blend R10 on an 8 x 8 boss refused, no smaller size allowed -> chamfer 1 built instead",
           rep[0]["built"] == "chamfer" and rep[0]["size"] == "1" and rep[0]["untreated"] == 0, [rep[0]["built"], rep[0]["size"], rep[0]["errors"]])
        ck("blend_chains: chamfer 1 on the four 4 mm boss edges removed 4 x 0.5 x 4", v1 - vol(bb_), 8.0, 1e-3)
        ct("blend_chains: nothing left behind by the refused attempts", not nxh.feature_errors(part), nxh.feature_errors(part))
        # break_edges: everything in one feature
        _f, b1 = nxh.block(part, (200, 900, 0), (40, 30, 20))
        rep = nxf.break_edges(part, b1, 1)
        res["notes"]["break_edges.block"] = rep
        ct("break_edges: block, 12 convex edges, one feature", rep["mode"] == "one feature" and rep["candidates"] == 12 and rep["treated"] == 12, rep)
        ck("break_edges: block with R1 on all edges = rounded box", vol(b1), rounded_box_volume(40, 30, 20, 1), 0.01)
        ck("break_edges: no sharp edge left", len(nxf.sharp_edges(part, b1)), 0, 0)
        # break_edges: concave only, as a chamfer
        _f, b2 = nxh.block(part, (300, 900, 0), (40, 30, 20))
        nxh.block(part, (310, 910, 15), (20, 10, 5), NXOpen.Features.Feature.BooleanType.Subtract, b2)
        v0 = vol(b2)
        rep = nxf.break_edges(part, b2, 1, convex=False, min_length=6.0, prefer_chamfer=True)
        res["notes"]["break_edges.concave_chamfer"] = rep
        ct("break_edges(convex=False, min_length=6, prefer_chamfer): the 4 pocket floor edges chamfered", rep["candidates"] == 4 and rep["treated"] == 4, rep)
        ct("break_edges: material ADDED in the concave corners", vol(b2) > v0 + 20.0, vol(b2) - v0)
        # break_edges: one feature refused -> edge by edge, the impossible edges are reported, the others are done
        _f, b3 = nxh.block(part, (400, 900, 0), (40, 30, 20))
        nxh.block(part, (410, 905, 20), (10, 10, 0.3), NXOpen.Features.Feature.BooleanType.Unite, b3)       # a 0.3 high pad
        v0 = vol(b3)
        rep = nxf.break_edges(part, b3, 1, concave=False, chamfer=False, overflow=False)
        res["notes"]["break_edges.edge_by_edge"] = rep
        ct("break_edges: a 0.3 high pad makes the one-feature blend fail -> edge by edge", rep["mode"] == "edge by edge", rep["mode"])
        ct("break_edges: the 12 block edges are blended all the same, the pad edges are reported untreated",
           rep["treated"] >= 12 and len(rep["untreated"]) >= 4 and vol(b3) < v0 - 50.0, [rep["treated"], len(rep["untreated"]), v0 - vol(b3)])
    case("blend_chains / break_edges / sharp_edges", c_edge_treatment)

    def c_holes():
        _f, hb = nxh.block(part, (0, 300, 0), (100, 60, 20))
        n0 = len(nxh.solids(part))

        def cut(name, want, fn, tol=0.05):
            v0 = vol(hb)
            fn()
            ck(name, v0 - vol(hb), want, tol)
        tip = math.pi * 9 * (3 / math.tan(math.radians(59))) / 3
        cut("hole.simple blind 6 x 10, flat", math.pi * 9 * 10, lambda: nxf.hole(part, hb, [(10, 310, 20)], 6, 10, vector=(0, 0, -1)))
        cut("hole.simple blind, 118 deg tip", math.pi * 9 * 10 + tip, lambda: nxf.hole(part, hb, [(25, 310, 20)], 6, 10, tip=118, vector=(0, 0, -1)))
        cut("hole.through, two points, one feature", 2 * math.pi * 9 * 20,
            lambda: nxf.hole(part, hb, [(40, 310, 20), (40, 330, 20)], 6, vector=(0, 0, -1)))
        cut("hole.counterbore 6.6 / 11 x 6", math.pi * 5.5 ** 2 * 6 + math.pi * 3.3 ** 2 * 14,
            lambda: nxf.hole(part, hb, [(55, 310, 20)], 6.6, cbore=(11, 6), vector=(0, 0, -1)))
        cut("hole.countersink 6.6 / 12 x 90", math.pi * 2.7 / 3 * (36 + 19.8 + 10.89) + math.pi * 3.3 ** 2 * 17.3,
            lambda: nxf.hole(part, hb, [(70, 310, 20)], 6.6, csink=(12, 90), vector=(0, 0, -1)))
        cut("hole.vector=None drills normal to the face", math.pi * 6.25 * 8, lambda: nxf.hole(part, hb, [(10, 340, 20)], 5, 8))
        cut("threaded_hole.M6 x 1.0 (tap drill 5, depth 15, 118 tip)",
            math.pi * 6.25 * 15 + math.pi * 6.25 * (2.5 / math.tan(math.radians(59))) / 3,
            lambda: nxf.threaded_hole(part, hb, [(85, 310, 20)], "M6 x 1.0", 9, 15, vector=(0, 0, -1)))
        cut("hole.NXOpen.Point input", math.pi * 4 * 20, lambda: nxf.hole(part, hb, [nxh.point(part, 25, 340, 20)], 4, vector=(0, 0, -1)))
        tip66 = math.pi * 3.3 ** 2 * (3.3 / math.tan(math.radians(59))) / 3
        cut("hole.counterbore BLIND: depth 14 from the start face, 118 deg tip", math.pi * 5.5 ** 2 * 6 + math.pi * 3.3 ** 2 * 8 + tip66,
            lambda: nxf.hole(part, hb, [(60, 340, 20)], 6.6, depth=14, tip=118, cbore=(11, 6), vector=(0, 0, -1)))
        ch65 = math.pi * 0.5 / 3 * (9 + 7.5 + 6.25) - math.pi * 6.25 * 0.5           # 45 deg chamfer dia 5 -> dia 6
        cut("threaded_hole.M6 blind 12 + start chamfer to the nominal diameter, tap drill from nxf.tap_drill",
            math.pi * 6.25 * 12 + math.pi * 6.25 * (2.5 / math.tan(math.radians(59))) / 3 + ch65,
            lambda: nxf.threaded_hole(part, hb, [(80, 340, 20)], "M6", 9, 12, vector=(0, 0, -1), start_chamfer=True,
                                      tap_drill=nxf.tap_drill("M6")))
        ck("tap_drill: M10 -> 8.5", nxf.tap_drill("M10"), 8.5, 1e-9)
        ct("thread_spec: M12 -> NX size string and ISO tap drill", nxf.thread_spec("M12")["nx_size"] == "M12 x 1.75"
           and nxf.thread_spec("M12")["tap_drill"] == 10.2, nxf.thread_spec("M12"))
        try:
            nxf.hole(part, hb, [(40, 345, 20)], 6.6, csink=(12, 90), start_chamfer=1)
            ct("hole.countersink with a start chamfer is refused", False)
        except ValueError as e:
            ct("hole.countersink with a start chamfer is refused", True, e)
        ck("hole.solid count unchanged", len(nxh.solids(part)), n0, 0)
    case("holes", c_holes)

    def c_holes_curved():
        big = 20.0

        def column(r, y0, z_lo=None, z_hi=None, n=500):
            """Volume inside the cylinder (axis X, radius 20) of a vertical column of radius r whose axis is y0 off
            the cylinder axis, between z_lo and z_hi (None = the cylinder surface on that side)."""
            tot = 0.0
            for i in range(n):
                rho = (i + 0.5) * r / n
                for j in range(n):
                    y = y0 + rho * math.sin((j + 0.5) * 2 * math.pi / n)
                    surf = math.sqrt(big * big - y * y)
                    top = surf if z_hi is None else min(z_hi, surf)
                    bot = -surf if z_lo is None else max(z_lo, -surf)
                    if top > bot:
                        tot += (top - bot) * rho
            return tot * (r / n) * (2 * math.pi / n)
        _f, cyl = nxh.cylinder(part, (0, 800, 0), (1, 0, 0), 40, 120)
        n0 = len(nxh.solids(part))

        def removed(fn):
            v0 = vol(cyl)
            fn()
            return v0 - vol(cyl)
        # ---- start point on the CREST: the face is normal to the hole axis there
        ck("hole.simple blind, start on the crest of a cylinder (start_extension False)",
           removed(lambda: nxf.hole(part, cyl, [(15, 800, 20)], 6, 10, vector=(0, 0, -1))), column(3, 0, 10), 0.03)
        ck("hole.simple blind on the crest, start_extension=True: same volume",
           removed(lambda: nxf.hole(part, cyl, [(30, 800, 20)], 6, 10, vector=(0, 0, -1), start_extension=True)), column(3, 0, 10), 0.03)
        ck("hole.counterbore on the crest, start_extension=True",
           removed(lambda: nxf.hole(part, cyl, [(50, 800, 20)], 6.6, cbore=(11, 6), vector=(0, 0, -1), start_extension=True)),
           column(5.5, 0, 14) + column(3.3, 0, None, 14), 0.03)
        ck("threaded_hole on the crest, start_extension=True",
           removed(lambda: nxf.threaded_hole(part, cyl, [(70, 800, 20)], "M6 x 1.0", 9, 15, vector=(0, 0, -1), start_extension=True)),
           column(2.5, 0, 5) + math.pi * 6.25 * (2.5 / math.tan(math.radians(59))) / 3, 0.03)
        # ---- start point OFF the crest (8 mm from the axis plane): the start face is inclined to the hole axis
        zs = math.sqrt(big * big - 64.0)
        out = {}
        for label, kw in (("simple", dict(diameter=6, depth=10)), ("cbore", dict(diameter=6.6, cbore=(11, 6)))):
            m = nxh.mark("no start extension " + label, False)
            try:
                d = removed(lambda: nxf.hole(part, cyl, [(90, 808, zs)], vector=(0, 0, -1), **kw))
                out[label] = "committed, removed %.4f" % d
            except NXOpen.NXException as e:
                out[label] = str(e)
            nxh.undo_to(m)
        res["notes"]["hole.off_crest_without_start_extension"] = out
        full = removed(lambda: nxf.hole(part, cyl, [(90, 808, zs)], 6.6, cbore=(11, 6), vector=(0, 0, -1), start_extension=True))
        ck("hole.counterbore on an inclined cylindrical start face, start_extension=True", full,
           column(5.5, 8, zs - 6) + column(3.3, 8, None, zs - 6), 0.03)
        short = float(out["cbore"].split()[-1]) if out["cbore"].startswith("committed") else None
        ct("hole.counterbore on an inclined start face WITHOUT start_extension: refused or incomplete (material left above the start plane)",
           "Holes were not created" in out["cbore"] or (short is not None and short < full - 10.0), out)
        if short is not None:
            ck("hole.counterbore without start_extension: removed only up to the start plane", short,
               column(5.5, 8, zs - 6, zs) + column(3.3, 8, None, zs - 6), 0.05)
        ck("hole.simple blind on an inclined cylindrical start face, start_extension=True (cuts up to the surface)",
           removed(lambda: nxf.hole(part, cyl, [(108, 808, zs)], 6, 10, vector=(0, 0, -1), start_extension=True)),
           column(3, 8, zs - 10), 0.03)
        ck("holes on a cylinder: solid count unchanged", len(nxh.solids(part)), n0, 0)
    case("holes on a curved start face", c_holes_curved)

    length = 50 + math.pi * 20 / 2

    def l_path(x0):
        return [nxh.line(part, (x0, 500, 0), (x0, 550, 0)),
                nxh.arc(part, (x0 + 20, 550, 0), (1, 0, 0), (0, 1, 0), 20.0, math.pi / 2, math.pi)]

    def c_tube():
        nxh.expr(part, "tube_d", 6)
        f, body = nxf.tube(part, "tube_d", "tube_d-2", curves=l_path(0))
        ck("tube.volume (D6 / d4 along line + arc)", vol(body), math.pi * (9 - 4) * length, 0.01)
        D = nxh.Datums(part)
        sk = nxf.sketch_lines(part, D.xy, D.x, D.origin, [((300, 500, 0), (300, 550, 0))], "SK_TUBE_PATH")
        f, body = nxf.tube(part, 6, feature=sk.Feature)
        ck("tube.path = curve feature (sketch), solid rod", vol(body), math.pi * 9 * 50, 0.01)
    case("tube", c_tube)

    def c_sweep():
        prof = nxh.polyline(part, [(97, 500, -2), (103, 500, -2), (103, 500, 2), (97, 500, 2)])
        f, body = nxf.sweep_along_guide(part, prof, l_path(100), (97, 500, -2), (100, 500, 0))
        ct("sweep_along_guide.solid", body.IsSolidBody)
        ck("sweep_along_guide.volume (6 x 4 section)", vol(body), 24 * length, 0.01)
        _f, base = nxh.block(part, (200, 500, 0), (20, 20, 10))
        prof = nxh.polyline(part, [(207, 508, 10), (213, 508, 10), (213, 512, 10), (207, 512, 10)])
        f, body = nxf.sweep_along_guide(part, prof, [nxh.line(part, (210, 510, 10), (210, 510, 30))], (207, 508, 10), (210, 510, 10),
                                        BOOL.Unite, base)
        ck("sweep_along_guide.Unite onto a target", vol(base), 4000 + 24 * 20, 0.01)
    case("sweep_along_guide", c_sweep)

    def c_extrude():
        sec = nxh.section(part, curves=nxh.rect(part, 0, 600, 20, 610, 0.0), help_point=(0, 600, 0))
        f = nxf.extrude_ex(part, sec, (0, 0, 1), end=5, symmetric=True)
        bb = nxh.bbox(f.GetBodies()[0])
        ck("extrude_ex.symmetric: zmin", bb[2], -2.5, 1e-6)
        ck("extrude_ex.symmetric: volume", vol(f.GetBodies()[0]), 20 * 10 * 5, 1e-3)
        _f, b6 = nxh.block(part, (100, 600, 0), (40, 40, 20))
        sec = nxh.section(part, curves=nxh.rect(part, 110, 610, 120, 620, 40.0), help_point=(110, 610, 40))
        nxf.extrude_ex(part, sec, (0, 0, -1), op=BOOL.Subtract, target=b6, through_all=True)
        ck("extrude_ex.through_all: removed", 32000 - vol(b6), 2000.0, 1e-3)
        _f, b7 = nxh.block(part, (200, 600, 0), (40, 40, 20))
        _f, lid = nxh.block(part, (200, 600, 30), (40, 40, 5))
        target = nxh.faces(lid, ftype=nxh.PLANE, normal=(0, 0, -1))[0]
        sec = nxh.section(part, curves=nxh.rect(part, 210, 610, 220, 620, 20.0), help_point=(210, 610, 20))
        nxf.extrude_ex(part, sec, (0, 0, 1), op=BOOL.Unite, target=b7, until=target)
        ck("extrude_ex.until face: added", vol(b7) - 32000, 1000.0, 1e-3)
        v = vol(b7)
        sec = nxh.section(part, curves=nxh.rect(part, 225, 625, 235, 635, 20.0), help_point=(225, 625, 20))
        nxf.extrude_ex(part, sec, (0, 0, 1), op=BOOL.Unite, target=b7, until_next=True)
        ck("extrude_ex.until_next: added", vol(b7) - v, 1000.0, 1e-3)
        crv = [nxh.line(part, (300, 600, 0), (340, 600, 0)), nxh.line(part, (340, 600, 0), (340, 630, 0))]
        f = nxf.extrude_ex(part, nxh.section(part, curves=crv, help_point=(300, 600, 0)), (0, 0, 1), 0, 10, thin=(0, 2))
        ck("extrude_ex.thin wall from an open L: volume", vol(f.GetBodies()[0]), (40 + 30 + 2) * 2 * 10, 1e-3)
        sec = nxh.section(part, curves=nxh.rect(part, 500, 600, 520, 610, 0.0), help_point=(500, 600, 0))
        f = nxf.extrude_ex(part, sec, (0, 0, 1), 0, 5, sheet=True)
        ct("extrude_ex.sheet=True: closed section gives a sheet", not f.GetBodies()[0].IsSolidBody)
        ck("extrude_ex.sheet=True: area", nxh.sheet_area(part, f.GetBodies()[0])[0], 2 * (20 + 10) * 5, 1e-3)
    case("extrude_ex", c_extrude)

    def c_extrude_draft():
        sec = nxh.section(part, curves=nxh.rect(part, 400, 600, 420, 620, 0.0), help_point=(400, 600, 0))
        f = nxf.extrude_ex(part, sec, (0, 0, 1), 0, 10, draft=5)
        g = 10 * math.tan(math.radians(5))
        ck("extrude_ex.draft 5: volume (shrinks along +vec)", vol(f.GetBodies()[0]),
           10 / 6.0 * (400 + 4 * (20 - g) ** 2 + (20 - 2 * g) ** 2), 0.01)
    case("extrude_ex draft", c_extrude_draft)


# ============================================================================ copies and body operations
def g_bodies(part):
    d = nxh.Datums(part)
    vol = lambda b: nxh.volume(part, b)  # noqa: E731

    def c_mirror_geometry():
        _, body = nxh.block(part, (0, 0, 0), (30, 40, 20))
        nxh.cylinder(part, (15, 20, 0), (0, 0, 1), 10, 20, BOOL.Subtract, body)
        half = 30 * 40 * 20 - math.pi * 25 * 20
        n0 = len(nxh.solids(part))
        fm, copies = nxf.mirror_geometry(part, [body], d.yz)
        ck("mirror_geometry.new bodies", len(copies), 1, 0)
        m = nxh.mass(part, copies)
        ck("mirror_geometry.copy volume", m["volume"], half, 1e-3)
        ck("mirror_geometry.copy centroid x", m["centroid"][0], -15.0, 1e-3)
        nxh.unite(part, body, tool_features=[fm])
        ck("mirror_geometry + unite: volume", vol(body), 2 * half, 1e-3)
        ck("mirror_geometry + unite: solid count", len(nxh.solids(part)), n0, 0)
        _, blk2 = nxh.block(part, (10, 50, 0), (10, 10, 10))
        _fm, cp = nxf.mirror_geometry(part, [blk2], d.yz, offset=5)
        ck("mirror_geometry.offset=5: plane at x=5", nxh.mass(part, cp)["centroid"][0], -5.0, 1e-3)
    case("mirror_geometry", c_mirror_geometry)

    def c_patterns():
        for name, val in (("nx", 5), ("ny", 2), ("nc", 6)):
            nxh.expr(part, name, val, None)
        v0 = 100 * 60 * 10
        _, plate = nxh.block(part, (-50, 100, 0), (100, 60, 10))
        sec = nxh.section(part, curves=nxh.rect(part, 20, 125, 30, 135, 10.0), help_point=(20, 125, 10))
        f_boss = nxh.extrude(part, sec, (0, 0, 1), 0, 5, BOOL.Unite, plate)
        nxf.mirror_feature(part, [f_boss], d.yz)
        ck("mirror_feature.volume (boss on both sides)", vol(plate), v0 + 2 * 500, 1e-3)
        ck("mirror_feature.mirrored boss top at x < 0", nxh.dist_to(part, plate, (-25, 130, 15)), 0.0, 1e-6)
        v1 = v0 + 1000
        hv = math.pi * 9 * 10
        f_hole, _ = nxh.cylinder(part, (-40, 110, 0), (0, 0, 1), 6, 10, BOOL.Subtract, plate)
        nxf.pattern_linear(part, [f_hole], (1, 0, 0), "nx", 20, (0, 1, 0), "ny", 40)
        ck("pattern_linear.5 x 2 holes: volume", vol(plate), v1 - 10 * hv, 1e-2)
        ck("pattern_linear.hole faces", len(nxh.faces(plate, ftype=nxh.CYLINDER, radius=3.0)), 10, 0)
        nxh.set_expr(part, "nx", 3)
        nxh.update()
        ck("pattern_linear.count expression 5 -> 3", len(nxh.faces(plate, ftype=nxh.CYLINDER, radius=3.0)), 6, 0)
        v2 = v1 - 6 * hv
        sec2 = nxh.section(part, curves=nxh.circle(part, (12, 130, 0), 2.0), help_point=(14, 130, 0))
        f_cut = nxh.extrude(part, sec2, (0, 0, 1), 0, 10, BOOL.Subtract, plate)
        nxf.pattern_circular(part, [f_cut], (0, 130, 0), (0, 0, 1), "nc")
        ck("pattern_circular.6 over 360: volume", vol(plate), v2 - 6 * math.pi * 4 * 10, 1e-2)
        ck("pattern_circular.hole faces", len(nxh.faces(plate, ftype=nxh.CYLINDER, radius=2.0)), 6, 0)
        _, p2 = nxh.cylinder(part, (200, 130, 0), (0, 0, 1), 60, 10)
        f_c, _ = nxh.cylinder(part, (220, 130, 0), (0, 0, 1), 4, 10, BOOL.Subtract, p2)
        nxf.pattern_circular(part, [f_c], (200, 130, 0), (0, 0, 1), 3, pitch=30)
        ck("pattern_circular.pitch=30, count 3: hole faces", len(nxh.faces(p2, ftype=nxh.CYLINDER, radius=2.0)), 3, 0)
        ck("pattern_circular.pitch: third hole at 60 deg",
           nxh.dist_to(part, p2, (200 + 20 * math.cos(math.radians(60)) + 2, 130 + 20 * math.sin(math.radians(60)), 5)), 0.0, 1e-4)
        f_v, _ = nxh.cylinder(part, (185, 115, 0), (0, 0, 1), 3, 10, BOOL.Subtract, p2)
        nxf.pattern_linear(part, [f_v], (0, 1, 0), 3, 10, variational=True)
        ck("pattern_linear.variational=True: hole faces", len(nxh.faces(p2, ftype=nxh.CYLINDER, radius=1.5)), 3, 0)
    case("mirror_feature / patterns", c_patterns)

    def c_pattern_more():
        # Pattern Increment: instance k gets master + step * k
        nxh.expr(part, "n_inc", 5, None)
        nxh.expr(part, "inc_step", 1)
        _, plate = nxh.block(part, (0, 500, 0), (140, 40, 10))
        f, _ = nxh.cylinder(part, (20, 520, 0), (0, 0, 1), 6, 10, BOOL.Subtract, plate)
        master = [e for e in f.GetExpressions() if abs(e.Value - 6.0) < 1e-9][0]
        nxf.pattern_linear(part, [f], (1, 0, 0), "n_inc", 25, increments=[(master, "inc_step")])

        def dias():
            return [round(abs(nxh.face_data(c)[3]) * 2, 4) for c in sorted(nxh.faces(plate, ftype=nxh.CYLINDER), key=lambda c: nxh.face_data(c)[1][0])]
        ct("pattern_linear.increments: diameters 6, 7, 8, 9, 10", dias() == [6.0, 7.0, 8.0, 9.0, 10.0], dias())
        nxh.set_expr(part, "inc_step", 0.5)
        nxh.set_expr(part, "n_inc", 3)
        nxh.update()
        ct("pattern_linear.increments: step 0.5 and count 3 by expression -> 6, 6.5, 7", dias() == [6.0, 6.5, 7.0], dias())
        # a blend on the rule 'feature intersection edges' of ONE Unite follows the tool count (body-copy route)
        nxh.expr(part, "n_boss", 3, None)
        _, pl2 = nxh.block(part, (0, 560, 0), (140, 40, 10))
        f_tool = nxh.extrude(part, nxh.section(part, curves=nxh.circle(part, (20, 580, 9), 6.0), help_point=(26, 580, 9)), (0, 0, 1), 0, 9)
        f_pg, _copies = nxf.pattern_geometry(part, [f_tool.GetBodies()[0]], linear=dict(xdir=(1, 0, 0), nx="n_boss", px=30))
        f_un = nxh.unite(part, pl2, tool_features=[f_tool, f_pg])
        nxf.edge_blend(part, [(nxf.feature_intersection_edges(part, [f_un]), 2)])

        def roots():
            return len([x for x in pl2.GetFaces() if nxh.face_data(x)[0] not in (nxh.PLANE, nxh.CYLINDER)])
        ck("feature_intersection_edges([Unite of a pattern]): root blend on all 3 bosses", roots(), 3, 0)
        nxh.set_expr(part, "n_boss", 5)
        nxh.update()
        ck("feature_intersection_edges: count 3 -> 5, the blend follows (5 blended roots)", roots(), 5, 0)
        ck("feature_intersection_edges: 5 bosses", len(nxh.faces(pl2, ftype=nxh.CYLINDER, radius=6.0)), 5, 0)
        _r, err = nxh.attempt("rule with a pattern feature", nxf.feature_intersection_edges, part, [f_tool, f_pg])
        ct("feature_intersection_edges: a Pattern Geometry feature in the list is refused", err is not None and "invalid" in err, err)
        # Feature Group patterned as a unit
        _, pl3 = nxh.block(part, (0, 620, 0), (140, 40, 10))
        fa, _ = nxh.cylinder(part, (15, 640, 10), (0, 0, 1), 8, 5, BOOL.Unite, pl3)
        fb, _ = nxh.cylinder(part, (15, 640, 0), (0, 0, 1), 3, 15, BOOL.Subtract, pl3)
        grp = nxf.feature_group(part, [fa, fb], "BOSS_WITH_HOLE")
        ct("feature_group: type FSET", grp.FeatureType == "FSET", grp.FeatureType)
        nxf.pattern_linear(part, [grp], (1, 0, 0), 4, 30)
        ck("feature_group patterned as a unit: 4 bosses", len(nxh.faces(pl3, ftype=nxh.CYLINDER, radius=4.0)), 4, 0)
        ck("feature_group patterned as a unit: 4 holes", len(nxh.faces(pl3, ftype=nxh.CYLINDER, radius=1.5)), 4, 0)
        # Pattern Along a sketch path (line 60 + quarter arc R30): the seed makes its own body
        nxh.expr(part, "n_along", 6, None)
        pitch = (60.0 + math.pi * 15.0) / 5
        for y0, fixed, want in ((700.0, False, [6.0, 8.0]), (800.0, True, [8.0, 6.0])):
            sk = nxf.new_sketch(part, d.xy, d.x, d.origin)
            path = [nxh.line(part, (0, y0, 0), (60, y0, 0)), nxh.arc(part, (60, y0 + 30, 0), (1, 0, 0), (0, 1, 0), 30.0, -math.pi / 2, 0.0)]
            nxf.add(sk, *path)
            nxf.finish_sketch(sk)
            f1, _seed = nxh.block(part, (-4, y0 - 3, 0), (8, 6, 3))
            nxf.pattern_along(part, [f1], [sk.Feature], path[0], (0, y0, 0), "n_along", fixed_orientation=fixed)
            links = sorted([s for s in nxh.solids(part) if abs(vol(s) - 144.0) < 1e-6 and y0 - 10 < nxh.bbox(s)[1] < y0 + 40],
                           key=lambda s: nxh.mass(part, [s])["centroid"][0])
            tag = "fixed_orientation" if fixed else "default orientation"
            ck("pattern_along (%s): 6 separate solids equal to the seed" % tag, len(links), 6, 0)
            xs = [nxh.mass(part, [s])["centroid"][0] for s in links[:3]]
            ck("pattern_along (%s): pitch = path length / (count - 1)" % tag, xs[2] - xs[1], pitch, 1e-3)
            last = nxh.bbox(links[-1])
            size = [round(last[3] - last[0], 3), round(last[4] - last[1], 3)]
            ct("pattern_along (%s): last copy is %s x %s in XY" % (tag, want[0], want[1]), size == want, size)
    case("pattern increments / intersection edges / feature group / pattern_along", c_pattern_more)

    def c_pattern_geometry():
        nxh.expr(part, "n_slot", 4, None)
        _, plate = nxh.block(part, (0, 200, 0), (100, 30, 5))
        f_tool, tool = nxh.block(part, (10, 205, -1), (5, 20, 7))
        f_pg, copies = nxf.pattern_geometry(part, [tool], linear=dict(xdir=(1, 0, 0), nx="n_slot", px=15))
        ck("pattern_geometry.linear copies", len(copies), 3, 0)
        nxh.subtract(part, plate, tool_features=[f_tool, f_pg])
        ck("pattern_geometry + subtract: volume", vol(plate), 15000 - 4 * 500, 1e-3)
        _, hub = nxh.cylinder(part, (200, 200, 0), (0, 0, 1), 40, 10)
        f_lug, lug = nxh.block(part, (218, 197, 0), (12, 6, 10))
        f_pg2, lugs = nxf.pattern_geometry(part, [lug], circular=dict(origin=(200, 200, 0), vec=(0, 0, 1), count=4))
        ck("pattern_geometry.circular copies", len(lugs), 3, 0)
        ck("pattern_geometry.circular copy position (-X lug)", min(nxh.bbox(c)[0] for c in lugs), 170.0, 1e-3)
    case("pattern_geometry", c_pattern_geometry)

    def c_trim():
        nxh.expr(part, "cut2", 45)
        _, a = nxh.block(part, (0, 300, 0), (60, 40, 20))
        _, dp = nxh.datum_plane(part, (40, 300, 0), (1, 0, 0), "DP_CUT")
        f, rev = nxf.trim_body(part, a, keep_point=(5, 320, 10), datum_plane=dp)
        ck("trim_body.datum plane, keep near side: volume", vol(a), 40 * 40 * 20, 1e-3)
        ct("trim_body.reverse not needed for the -normal side", rev is False, rev)
        _, a2 = nxh.block(part, (0, 400, 0), (60, 40, 20))
        f, rev2 = nxf.trim_body(part, a2, keep_point=(55, 420, 10), datum_plane=dp)
        ck("trim_body.keep far side: volume", vol(a2), 20 * 40 * 20, 1e-3)
        ct("trim_body.reverse used for the +normal side", rev2 is True, rev2)
        _, b = nxh.block(part, (0, 500, 0), (60, 40, 20))
        nxf.trim_body(part, b, plane=nxf.plane_from_datum(part, d.yz, "cut2"))
        ck("plane_from_datum + trim_body(plane=): volume", vol(b), 45 * 40 * 20, 1e-3)
        nxh.set_expr(part, "cut2", 30)
        nxh.update()
        ck("plane_from_datum offset expression 45 -> 30", vol(b), 30 * 40 * 20, 1e-3)
        _, c = nxh.block(part, (0, 600, 0), (60, 40, 20))
        arc = nxh.arc(part, (30, 550, 0), (1, 0, 0), (0, 1, 0), 80.0, math.radians(60), math.radians(120))
        before = list(part.Bodies)
        nxh.extrude(part, nxh.section(part, curves=[arc], help_point=(30, 630, 0)), (0, 0, 1), -5, 25)
        sheet = nxh.new_bodies(part, before)[0]
        nxf.trim_body(part, c, keep_point=(30, 605, 10), sheet=sheet)
        area = 2 * (15 * math.sqrt(80 ** 2 - 30 ** 2) + 3200 * math.asin(30 / 80.0)) - 3000
        ck("trim_body.sheet tool with keep_point: volume", vol(c), area * 20, 0.05)
    case("trim_body", c_trim)

    def c_split_delete():
        _, blk = nxh.block(part, (0, 700, 0), (60, 40, 20))
        _, dp = nxh.datum_plane(part, (0, 700, 8), (0, 0, 1), "DP_SPLIT")
        n0 = len(nxh.solids(part))
        f, pieces = nxf.split_body(part, [blk], datum_plane=dp)
        ck("split_body.solids added", len(nxh.solids(part)) - n0, 1, 0)
        vs = sorted(vol(p) for p in pieces)
        ck("split_body.lower piece", vs[0], 19200.0, 1e-3)
        ck("split_body.upper piece", vs[1], 28800.0, 1e-3)
        upper = max(pieces, key=lambda p: nxh.bbox(p)[2])
        lower = min(pieces, key=lambda p: nxh.bbox(p)[2])
        nxf.delete_body(part, [upper])
        ck("delete_body.solid count back", len(nxh.solids(part)), n0, 0)
        ck("delete_body.kept volume", vol(lower), 60 * 40 * 8, 1e-3)
    case("split_body / delete_body", c_split_delete)

    def c_move_scale_extract():
        nxh.expr(part, "mv", 25)
        nxh.expr(part, "shrink", 1.02, None)
        _, m1 = nxh.block(part, (0, 800, 0), (10, 20, 30))
        nxf.move_object(part, [m1], "distance", "mv", vec=(1, 0, 0))
        ck("move_object.distance: xmin", nxh.bbox(m1)[0], 25.0, 1e-4)
        nxf.move_object(part, [m1], "delta", (5, 6, 7))
        ck("move_object.delta: zmin", nxh.bbox(m1)[2], 7.0, 1e-4)
        ck("move_object.delta: ymin", nxh.bbox(m1)[1], 806.0, 1e-4)
        nxf.move_object(part, [m1], "angle", 90, vec=(0, 0, 1), origin=(30, 806, 0))
        ck("move_object.angle 90 about Z through its corner: xmax", nxh.bbox(m1)[3], 30.0, 1e-4)
        ck("move_object.volume unchanged", vol(m1), 6000.0, 1e-3)
        _, sb = nxh.block(part, (10, 900, 0), (10, 20, 30))
        nxf.scale_body(part, [sb], "shrink")
        ck("scale_body.volume ratio", vol(sb) / 6000.0, 1.02 ** 3, 1e-6)
        ck("scale_body.xmax (about the origin)", nxh.bbox(sb)[3], 20.4, 1e-4)
        _, src = nxh.block(part, (100, 900, 0), (20, 20, 20))
        f1, frozen = nxf.extract_body(part, [src], fix_at_timestamp=True)
        f2, live = nxf.extract_body(part, [src], fix_at_timestamp=False)
        nxh.cylinder(part, (110, 910, 0), (0, 0, 1), 10, 20, BOOL.Subtract, src)
        nxh.update()
        ck("extract_body.frozen copy keeps the old shape", vol(frozen[0]), 8000.0, 1e-3)
        ck("extract_body.live copy follows the source", vol(live[0]), 8000 - math.pi * 25 * 20, 1e-3)
    case("move_object / scale_body / extract_body", c_move_scale_extract)


# ============================================================================ synchronous modelling
def g_sync(part):
    vol = lambda b: nxh.volume(part, b)  # noqa: E731
    HOLE = math.pi * 25 * 20
    CORNERS = 4 * (9 - math.pi * 9 / 4) * 20
    row = [0]

    def blk(hole=False, blends=False):
        y = 100 * row[0]
        row[0] += 1
        _, b = nxh.block(part, (0, y, 0), (60, 40, 20))
        if hole:
            nxh.cylinder(part, (30, y + 20, 0), (0, 0, 1), 10, 20, BOOL.Subtract, b)
        if blends:
            nxh.blend(part, vertical_edges(b, 20), 3)
        return b, y

    def cyl(b, r):
        return nxh.faces(b, ftype=nxh.CYLINDER, radius=r)

    def c_offset_region():
        nxh.expr(part, "or_d", 5)
        b, y = blk()
        nxf.offset_region(part, top_of(b), "or_d")
        ck("offset_region.+5 on the top = outward, adds material", vol(b), 60000.0, 0.01)
        nxh.set_expr(part, "or_d", -3)
        nxh.update()
        ck("offset_region.expression -> -3 removes material", vol(b), 40800.0, 0.01)
        b, y = blk(hole=True)
        nxf.offset_region(part, nxf.rule_faces(part, "dumb", cyl(b, 5.0)), 1)
        ck("offset_region.+1 on a hole wall makes the hole SMALLER (dia 8)", vol(b), 48000 - math.pi * 16 * 20, 0.01)
        b, y = blk()
        nxf.offset_region(part, top_of(b), 5, reverse=True)
        ck("offset_region.reverse=True: +5 goes inward", vol(b), 36000.0, 0.01)
    case("offset_region", c_offset_region)

    def c_move_face():
        b, y = blk()
        nxf.move_face(part, top_of(b), vec=(0, 0, 1), distance=5)
        ck("move_face.distance +Z 5", vol(b), 60000.0, 0.01)
        b, y = blk()
        nxf.move_face(part, top_of(b), vec=(1, 0, 0), angle=10, origin=(0, y, 20))
        ck("move_face.angle 10 deg about the X edge", vol(b), 48000 + 60 * 800 * math.tan(math.radians(10)), 0.05)
        b, y = blk(hole=True)
        nxf.move_face(part, cyl(b, 5.0), points=((30, y + 20, 0), (40, y + 25, 0)))
        p = nxh.face_data(cyl(b, 5.0)[0])[1]
        ck("move_face.points: hole axis x", p[0], 40.0, 1e-4)
        ck("move_face.points: hole axis y", p[1], y + 25.0, 1e-4)
        ck("move_face.points: volume unchanged", vol(b), 48000 - HOLE, 0.01)
    case("move_face", c_move_face)

    def c_replace_face():
        b, y = blk()
        _, dz26 = nxh.datum_plane(part, (0, 0, 26), (0, 0, 1))
        nxf.replace_face(part, top_of(b), dz26)
        ck("replace_face.top -> datum plane z=26", vol(b), 62400.0, 0.01)
        b, y = blk()
        nxf.replace_face(part, top_of(b), nxf.rule_faces(part, "datum", dz26), offset=2)
        ck("replace_face.rule_faces('datum') + offset 2", vol(b), 67200.0, 0.01)
        b, y = blk()
        nxf.replace_face(part, top_of(b), dz26, offset=2, offset_reverse=True)
        ck("replace_face.offset 2, offset_reverse", vol(b), 57600.0, 0.01)
        b, y = blk()
        _, above = nxh.block(part, (-10, y - 10, 26), (80, 60, 5))
        mating = nxh.faces(above, ftype=nxh.PLANE, normal=(0, 0, -1))
        m = nxh.mark("opposed, reverse False", False)
        try:
            nxf.replace_face(part, top_of(b), mating)
            outcome = "committed, volume %.3f" % vol(b)
            wrong = abs(vol(b) - 62400.0) > 1.0
        except NXOpen.NXException as e:
            outcome, wrong = str(e), True
        nxh.undo_to(m)
        res["notes"]["replace_face.opposed_normals_reverse_False"] = outcome
        ct("replace_face.opposed normals: reverse=False fails or gives a wrong body", wrong, outcome)
        nxf.replace_face(part, top_of(b), mating, reverse=True)
        ck("replace_face.reverse=True onto a MATING face (normal -Z)", vol(b), 62400.0, 0.01)
        b, y = blk()
        _, above = nxh.block(part, (-10, y - 10, 26), (80, 60, 5))
        nxf.replace_face(part, top_of(b), nxh.faces(above, ftype=nxh.PLANE, normal=(0, 0, -1)), reverse=None)
        ck("replace_face.reverse=None finds the direction (mating face)", vol(b), 62400.0, 0.01)
        b, y = blk()
        nxf.replace_face(part, top_of(b), dz26, reverse=None, accept=lambda: abs(vol(b) - 62400.0) < 0.01)
        ck("replace_face.reverse=None + accept() on a datum plane", vol(b), 62400.0, 0.01)
        nxh.expr(part, "src_h", 27)
        _, source = nxh.block(part, (100, y, 0), (60, 40, "src_h"))
        b, y = blk()
        link = nxf.extract_face(part, top_of(source))
        nxf.replace_face(part, top_of(b), nxf.rule_faces(part, "feature", [link]))
        ck("replace_face.rule_faces('feature') on an extracted face (z=27)", vol(b), 60 * 40 * 27, 0.01)
        nxh.set_expr(part, "src_h", 31)
        nxh.update()
        ck("replace_face.linked face follows the source (z=31)", vol(b), 60 * 40 * 31, 0.01)
    case("replace_face", c_replace_face)

    def c_delete_face():
        b, y = blk(hole=True, blends=True)
        nxf.delete_face(part, cyl(b, 5.0))
        ck("delete_face.heal: hole removed", vol(b), 48000 - CORNERS, 0.01)
        nxf.delete_face(part, nxf.rule_faces(part, "all_blend", b))
        ck("delete_face.rule_faces('all_blend'): sharp block", vol(b), 48000.0, 0.01)
        b, y = blk(hole=True)
        n_sheets = len(nxh.sheets(part))
        nxf.delete_face(part, cyl(b, 5.0), heal=False)
        ck("delete_face.heal=False leaves a sheet body", len(nxh.sheets(part)) - n_sheets, 1, 0)
    case("delete_face", c_delete_face)

    def c_resize():
        nxh.expr(part, "hole_d", 16)
        b, y = blk(hole=True, blends=True)
        nxf.resize_face(part, cyl(b, 5.0), "hole_d")
        ck("resize_face.hole dia 10 -> 16", vol(b), 48000 - math.pi * 64 * 20 - CORNERS, 0.01)
        nxf.resize_blend(part, cyl(b, 3.0), 5)
        ck("resize_blend.R3 -> R5", vol(b), 48000 - math.pi * 64 * 20 - 4 * (25 - math.pi * 25 / 4) * 20, 0.01)
        b3, y = blk()
        nxh.blend(part, list(b3.GetEdges()), 3)
        seed = nxh.faces(b3, ftype=nxh.CYLINDER)[0]
        nxf.resize_blend(part, nxf.rule_faces(part, "connected_blend", seed), 5)
        ck("resize_blend.rule_faces('connected_blend') -> R5 everywhere", vol(b3), rounded_box_volume(60, 40, 20, 5), 0.05)
    case("resize_face / resize_blend", c_resize)

    def c_rules():
        b, y = blk(blends=True)
        seed = nxh.faces(b, ftype=nxh.PLANE, normal=(1, 0, 0))[0]
        nxf.offset_region(part, nxf.rule_faces(part, "tangent", seed), 1)
        ck("rule_faces('tangent'): whole wall loop +1", vol(b), (62 * 42 - (4 - math.pi) * 16) * 20, 0.05)
        b, y = blk()
        nxh.cylinder(part, (30, y + 20, 20), (0, 0, 1), 12, 8, BOOL.Unite, b)
        nxf.move_face(part, nxf.rule_faces(part, "boss_pocket", cyl(b, 6.0)[0]), vec=(0, 1, 0), distance=5)
        ck("rule_faces('boss_pocket'): boss moved +Y 5", nxh.face_data(cyl(b, 6.0)[0])[1][1], y + 25.0, 1e-3)
        ck("rule_faces('boss_pocket'): volume unchanged", vol(b), 48000 + math.pi * 36 * 8, 0.01)
        b, y = blk()
        nxf.offset_region(part, nxf.rule_faces(part, "body", b), 1)
        ck("rule_faces('body'): every face +1", vol(b), 62 * 42 * 22, 0.01)
    case("rule_faces", c_rules)

    def c_divide():
        b, y = blk()
        t = top_of(b)[0]
        f, flip = nxf.divide_face_offset(part, t, list(t.GetEdges()), 5)
        res["notes"]["divide_face_offset.flip_used"] = flip
        inner = [x for x in top_of(b) if nxh.bbox(x)[0] > 1]
        ck("divide_face_offset.inner region found", len(inner), 1, 0)
        ck("divide_face_offset.inner region is 50 x 30", nxh.sheet_area(part, inner)[0], 1500.0, 0.01)
        nxf.offset_region(part, inner, 3)
        ck("divide_face_offset + offset_region: boss volume", vol(b), 48000 + 50 * 30 * 3, 0.01)
        b, y = blk(hole=True)
        t = top_of(b)[0]
        ring = [e for e in t.GetEdges() if e.SolidEdgeType == NXOpen.Edge.EdgeType.Circular]
        f, flip2 = nxf.divide_face_offset(part, t, ring, 3)
        res["notes"]["divide_face_offset.flip_used_inner_loop"] = flip2
        tops = top_of(b)
        ck("divide_face_offset.inner loop (hole edge): two top faces", len(tops), 2, 0)
        ck("divide_face_offset.inner loop: annulus R5..R8 lies inside the face",
           min(nxh.sheet_area(part, [x])[0] for x in tops), math.pi * (64 - 25), 0.2)   # offset of a circle is a spline (r 8.002)
        b, y = blk()
        _, dx20 = nxh.datum_plane(part, (20, 0, 0), (1, 0, 0))
        nxf.divide_face_by_plane(part, top_of(b), dx20)
        tops = top_of(b)
        ck("divide_face_by_plane.two top faces", len(tops), 2, 0)
        small = min(tops, key=lambda x: nxh.sheet_area(part, [x])[0])
        ck("divide_face_by_plane.small region is 20 x 40", nxh.sheet_area(part, [small])[0], 800.0, 0.01)
    case("divide_face", c_divide)

    def c_remove_parameters():
        b, y = blk(hole=True)
        nxf.remove_parameters(part, [b])
        types_ = [f.FeatureType for f in part.Features.GetFeatures()]
        ck("remove_parameters.one BREP feature in the tree", types_.count("BREP"), 1, 0)
        ck("remove_parameters.volume unchanged", vol(b), 48000 - HOLE, 0.01)
        nxf.resize_face(part, cyl(b, 5.0), 16)
        ck("remove_parameters.BREP still editable (resize hole)", vol(b), 48000 - math.pi * 64 * 20, 0.01)
    case("remove_parameters", c_remove_parameters)

    def c_pull_label():
        b, y = blk()                                                    # 60 x 40 x 20
        nxf.pull_face(part, top_of(b), (0, 0, 1), 5)
        ck("pull_face.top +5 along +Z: volume + 60 x 40 x 5", vol(b), 48000.0 + 12000.0, 0.01)
        ck("pull_face: top now at z = 25", nxh.bbox(b)[5], 25.0, 1e-6)
        res["notes"]["pull_face.faces_after"] = len(b.GetFaces())
        b, y = blk()
        nxf.pull_face(part, top_of(b), (0, 0, 1), -3)
        ck("pull_face.top -3: volume - 60 x 40 x 3", vol(b), 48000.0 - 7200.0, 0.01)
        # Label Chamfer: a dumb 5 x 5 chamfer is carried by an Offset Region of its neighbour only when labelled
        b, y = blk()
        nxf.chamfer(part, nxh.edges(b, lambda bb: abs(bb[0] - 60) < 1e-6 and abs(bb[3] - 60) < 1e-6 and abs(bb[2] - 20) < 1e-6 and abs(bb[5] - 20) < 1e-6), 5)
        nxf.remove_parameters(part, [b])
        ck("label_chamfer.base: block with a parameter-less 5 x 5 chamfer", vol(b), 48000.0 - 12.5 * 40, 0.01)
        cham = [f for f in b.GetFaces() if nxh.face_data(f)[0] == nxh.PLANE and abs(nxh.face_data(f)[2][0] - math.sqrt(0.5)) < 1e-4
                and abs(nxh.face_data(f)[2][2] - math.sqrt(0.5)) < 1e-4]
        side = nxh.faces(b, ftype=nxh.PLANE, normal=(1, 0, 0))[0]
        m = nxh.mark("unlabelled", False)
        nxf.offset_region(part, top_of(b), 3)
        unlabelled = vol(b)
        nxh.undo_to(m)
        res["notes"]["label_chamfer.unlabelled_volume"] = unlabelled      # 54700 here (NX recognises a chamfer made in this session); 53920 on a body where it does not
        ct("label_chamfer.without the label: either carried (54700) or stretched (53920)", min(abs(unlabelled - 54700.0), abs(unlabelled - 53920.0)) < 0.01, unlabelled)
        fl = nxf.label_chamfer(part, cham, top_of(b)[0], side)
        res["notes"]["label_chamfer.feature"] = [fl.FeatureType, fl.GetFeatureName()]
        nxf.offset_region(part, top_of(b), 3)
        ck("label_chamfer.with the label the 5 x 5 chamfer is carried up", vol(b), (60 * 23 - 12.5) * 40, 0.01)
    case("pull_face / label_chamfer", c_pull_label)

    def shelled():
        b, y = blk(blends=True)                                         # 60 x 40 x 20, R3 on the vertical edges
        nxf.shell(part, b, top_of(b), 2)
        nxf.remove_parameters(part, [b])
        outer = nxh.one([f for f in nxh.faces(b, ftype=nxh.PLANE, normal=(1, 0, 0)) if nxh.bbox(f)[0] > 59.9], "outer +X wall")
        return b, outer

    def c_thin_wall():
        b, outer = shelled()
        v0 = vol(b)
        ps = nxh.wall_partners([outer])
        ck("wall_partners.outer wall of a shelled box has ONE partner", len(ps), 1, 0)
        ck("wall_thickness.2.000 behind the outer wall", nxh.wall_thickness(outer), 2.0, 1e-6)
        ck("wall_partners.wall=3 finds nothing on a 2 mm wall", len(nxh.wall_partners([outer], wall=3.0)), 0, 0)
        rim = nxh.one([f for f in top_of(b) if abs(nxh.bbox(f)[2] - 20) < 1e-6], "rim")
        ct("wall_partners.the rim of the open box has no partner", nxh.wall_partners([rim]) == [] and nxh.wall_thickness(rim) is None)
        nxf.move_face(part, [outer], vec=(1, 0, 0), distance=5, finder="offset")
        ck("move_face.finder='offset': inner partner taken along, dV = 5 x (40 x 20 - 36 x 18)", vol(b) - v0, 5 * (800 - 648), 0.01)
        ck("move_face.finder='offset': wall still 2.000", nxh.wall_thickness(outer), 2.0, 1e-6)
        b, outer = shelled()
        v0 = vol(b)
        nxf.move_face(part, [outer] + nxh.wall_partners([outer]), vec=(1, 0, 0), distance=5)
        ck("move_face.faces + nxh.wall_partners(faces): same dV as the finder", vol(b) - v0, 5 * (800 - 648), 0.01)
        b, outer = shelled()
        v0 = vol(b)
        nxf.move_face(part, [outer], vec=(1, 0, 0), distance=5)
        ck("move_face.outer wall ALONE: dV = 5 x 40 x 20 (the wall got thicker)", vol(b) - v0, 4000.0, 0.01)
        ck("wall_thickness.7.000 after moving the outer wall alone", nxh.wall_thickness(outer), 7.0, 1e-6)
    case("thin wall: partners / face finder", c_thin_wall)

    def c_finder_cut_cap():
        b, y = blk()
        nxh.block(part, (5.0, y + 5.0, 20.0), (10, 10, 8), op=BOOL.Unite, target=b)
        nxh.block(part, (45.0, y + 25.0, 20.0), (10, 10, 8), op=BOOL.Unite, target=b)
        nxh.cylinder(part, (30, y + 10, 0), (0, 0, 1), 6, 20, BOOL.Subtract, b)
        nxh.cylinder(part, (30, y + 30, 0), (0, 0, 1), 6, 20, BOOL.Subtract, b)
        nxf.remove_parameters(part, [b])
        v0 = vol(b)
        tops = [f for f in top_of(b) if abs(nxh.bbox(f)[2] - 28) < 1e-6]
        nxf.move_face(part, [tops[0]], vec=(0, 0, 1), distance=3, finder="coplanar")
        ck("move_face.finder='coplanar': both boss tops rise, dV = 2 x 100 x 3", vol(b) - v0, 600.0, 0.01)
        v0 = vol(b)
        nxf.resize_face(part, [cyl(b, 3.0)[0]], 8, finder="equal_diameter")
        ck("resize_face.finder='equal_diameter': both dia 6 holes become dia 8", vol(b) - v0, -2 * math.pi * (16 - 9) * 20, 0.01)
        b, y = blk(hole=True)
        nxf.remove_parameters(part, [b])
        v0 = vol(b)
        n_sheets = len(nxh.sheets(part))
        nxf.move_face(part, cyl(b, 5.0), vec=(1, 0, 0), distance=15, cut_paste=True)
        ck("move_face.cut_paste: volume unchanged", vol(b), v0, 0.01)
        ck("move_face.cut_paste: hole axis now at x = 45", nxh.face_data(cyl(b, 5.0)[0])[1][0], 45.0, 1e-6)
        ck("move_face.cut_paste: no sheet left behind", len(nxh.sheets(part)), n_sheets, 0)
        b, y = blk()
        wall = nxh.one(nxh.faces(b, ftype=nxh.PLANE, normal=(1, 0, 0)), "wall x = 60")
        _f, why = nxh.attempt("delete a block wall", nxf.delete_face, part, [wall])
        ct("delete_face.a block wall cannot heal", _f is None and "cannot close" in str(why), why)
        _, cap = nxh.datum_plane(part, (70, 0, 0), (1, 0, 0))
        nxf.delete_face(part, [wall], cap=cap)
        ck("delete_face.cap=datum plane x = 70: the neighbours run up to the cap", vol(b), 56000.0, 0.01)
        b, y = blk()
        for x, d in ((10, 4), (25, 10), (45, 14)):
            nxh.cylinder(part, (x, y + 20, 0), (0, 0, 1), d, 20, BOOL.Subtract, b)
        _fx, copies = nxf.extract_body(part, [b])
        c = copies[0]
        nxf.delete_holes(part, c, 10)
        ck("delete_holes.<= 10 on an Extract Body copy: only the dia 14 hole is left", vol(c), 48000 - math.pi * 49 * 20, 0.01)
        ck("delete_holes.the original body keeps its three holes", vol(b), 48000 - math.pi * (4 + 25 + 49) * 20, 0.01)
    case("face finder / cut and paste / cap / holes by size", c_finder_cut_cap)

    def c_blend_tools():
        EB = NXOpen.Features.EdgeBlendBuilder
        b, y = blk()
        ve = sorted(vertical_edges(b, 20), key=lambda e: (nxh.bbox(e)[0], nxh.bbox(e)[1]))
        bb = part.Features.CreateEdgeBlendBuilder(nxh.NULL_FEATURE)
        try:                                                            # conic section 5 / 3.33, rho 0.6: a B-surface blend
            bb.AddChainset(nxh.collector(part, edges=ve[:1]), EB.Section.Conic, EB.Conic.BoundaryPlusCenter, EB.Rhotype.Relative, "5", "3.33", "0.6")
            bb.Tolerance = 0.01
            bb.CommitFeature()
        finally:
            bb.Destroy()
        nxh.blend(part, ve[3:], 4)
        nxf.remove_parameters(part, [b])
        bs = nxh.faces(b, ftype=nxh.BSURF)
        ck("blend_census.test body: one B-surface (conic) blend face", len(bs), 1, 0)
        long_edge = [e for e in bs[0].GetEdges() if e.GetLength() > 19][0]
        ct("edge_convexity.long edge of a B-surface blend is 'smooth'", nxf.edge_convexity(part, long_edge) == "smooth", nxf.edge_convexity(part, long_edge))
        n_expr = len([e for e in part.Expressions])
        bc = nxf.blend_census(part, b)
        ct("blend_census.the R4 blend is recognised, the conic one is listed as unrecognised",
           bc["recognised"] == {4.0: 1} and [f.Tag for f in bc["unrecognised"]] == [bs[0].Tag], [bc["recognised"], len(bc["unrecognised"])])
        ck("blend_census.leaves no stray expression", len([e for e in part.Expressions]) - n_expr, 0, 0)
        _f, why = nxh.attempt("resize an unrecognised blend", nxf.resize_blend, part, bs, 3)
        ct("resize_blend.refuses the B-surface blend", _f is None, why)
        nxf.replace_blend(part, bs, 5)
        ck("replace_blend.radius 5: the corner is a true R5 blend", vol(b), 48000 - K * 25 * 20 - K * 16 * 20, 0.01)
        ct("replace_blend.NX now recognises both blends", nxf.blend_census(part, b) == {"recognised": {4.0: 1, 5.0: 1}, "unrecognised": []})
        nxf.resize_blend(part, cyl(b, 5.0), 3)
        ck("replace_blend -> resize_blend 3", vol(b), 48000 - K * 9 * 20 - K * 16 * 20, 0.01)
        # Optimize Face: a top face split by Divide Face is merged again
        b, y = blk()
        _, dx20 = nxh.datum_plane(part, (20, 0, 0), (1, 0, 0))
        nxf.divide_face_by_plane(part, top_of(b), dx20)
        nxf.remove_parameters(part, [b])
        n0, n1 = nxf.optimize_face(part, b)
        ct("optimize_face.7 faces (split top) -> 6", (n0, n1) == (7, 6), (n0, n1))
        ck("optimize_face.volume unchanged", vol(b), 48000.0, 0.01)
        # notch blend: a fillet whose radius is the whole step height
        _, s1 = nxh.block(part, (0, 100 * row[0], 0), (100, 100, 100))
        y = 100 * row[0]
        row[0] += 2
        nxh.block(part, (0.0, float(y), 100.0), (40, 100, 50), op=BOOL.Unite, target=s1)
        inner = [e for e in s1.GetEdges() if abs(nxh.bbox(e)[0] - 40) < 1e-3 and abs(nxh.bbox(e)[3] - 40) < 1e-3
                 and abs(nxh.bbox(e)[2] - 100) < 1e-3 and abs(nxh.bbox(e)[5] - 100) < 1e-3]
        nxh.blend(part, inner, 50)
        nxf.remove_parameters(part, [s1])
        FIL = lambda r: (r * r - math.pi * r * r / 4) * 100  # noqa: E731
        ck("label_notch_blend.base: R50 fillet over the whole 50 mm step", vol(s1), 1.2e6 + FIL(50), 0.1)
        notch = nxh.faces(s1, ftype=nxh.CYLINDER, radius=50.0)
        _f, why = nxh.attempt("resize the unlabelled notch", nxf.resize_blend, part, notch, 30)
        ct("label_notch_blend.without the label Resize Blend fails", _f is None and "change failed" in str(why), why)
        nxf.label_notch_blend(part, notch)
        nxf.resize_blend(part, nxh.faces(s1, ftype=nxh.CYLINDER, radius=50.0), 30)
        ck("label_notch_blend.labelled: Resize Blend R30", vol(s1), 1.2e6 + FIL(30), 0.1)
    case("blend census / replace blend / optimize face / notch", c_blend_tools)

    def c_dimensions():
        def edge(b, y, x, z):
            return nxh.one([e for e in b.GetEdges() if abs(nxh.bbox(e)[0] - x) < 1e-6 and abs(nxh.bbox(e)[3] - x) < 1e-6
                            and abs(nxh.bbox(e)[2] - z) < 1e-6 and abs(nxh.bbox(e)[5] - z) < 1e-6], "edge x=%s z=%s" % (x, z))
        b, y = blk(hole=True)
        nxf.remove_parameters(part, [b])
        wall = nxh.one(nxh.faces(b, ftype=nxh.PLANE, normal=(1, 0, 0)), "wall x = 60")
        fl = nxf.linear_dimension(part, edge(b, y, 0, 20), edge(b, y, 60, 20), [wall], 70, axis="X")
        ck("linear_dimension.length 60 -> TARGET 70 along X", vol(b), 56000 - HOLE, 0.01)
        res["notes"]["linear_dimension.feature"] = [fl.FeatureType, fl.GetFeatureName(), fl.GetExpressions()[0].GetDescriptor()]
        ct("linear_dimension.a 'Linear Dimension' feature with one expression", "Linear Dimension" in fl.GetFeatureName()
           and len(fl.GetExpressions()) >= 1, res["notes"]["linear_dimension.feature"])
        nxh.expr(part, "dim_len", 66, "mm", "overall length")
        fl.GetExpressions()[0].RightHandSide = "dim_len"
        nxh.update()
        ck("linear_dimension.stored value driven by a named expression: 66", vol(b), 66 * 800 - HOLE, 0.01)
        fr = nxf.radial_dimension(part, cyl(b, 5.0), 14)
        ck("radial_dimension.hole dia 10 -> TARGET dia 14", vol(b), 66 * 800 - math.pi * 49 * 20, 0.01)
        fr.GetExpressions()[0].RightHandSide = "12"
        nxh.update()
        ck("radial_dimension.stored value edited to 12", vol(b), 66 * 800 - math.pi * 36 * 20, 0.01)
        b, y = blk()
        nxf.remove_parameters(part, [b])
        top, wall = top_of(b)[0], nxh.one(nxh.faces(b, ftype=nxh.PLANE, normal=(1, 0, 0)), "wall x = 60")
        nxf.angular_dimension(part, top, wall, [wall], 100)
        ck("angular_dimension.wall leaned to 100 deg from the top: wedge 0.5 x 20 x 20 tan 10 x 40 removed",
           vol(b), 48000 - 0.5 * 20 * 20 * math.tan(math.radians(10)) * 40, 0.01)
        w2 = [f for f in b.GetFaces() if nxh.face_data(f)[0] == nxh.PLANE and nxh.face_data(f)[2][0] > 0.9][0]
        ck("angular_dimension.angle between the outward normals of top and wall", nxh.angle_deg(nxh.face_data(top_of(b)[0])[2], nxh.face_data(w2)[2]), 100.0, 1e-6)
        # the other two axes
        b, y = blk()
        nxf.remove_parameters(part, [b])
        e_y0 = nxh.one([e for e in b.GetEdges() if abs(nxh.bbox(e)[1] - y) < 1e-6 and abs(nxh.bbox(e)[4] - y) < 1e-6 and abs(nxh.bbox(e)[2] - 20) < 1e-6 and abs(nxh.bbox(e)[5] - 20) < 1e-6], "y0 top edge")
        e_y1 = nxh.one([e for e in b.GetEdges() if abs(nxh.bbox(e)[1] - y - 40) < 1e-6 and abs(nxh.bbox(e)[4] - y - 40) < 1e-6 and abs(nxh.bbox(e)[2] - 20) < 1e-6 and abs(nxh.bbox(e)[5] - 20) < 1e-6], "y1 top edge")
        nxf.linear_dimension(part, e_y0, e_y1, nxh.faces(b, ftype=nxh.PLANE, normal=(0, 1, 0)), 45, axis="Y")
        ck("linear_dimension.axis Y: width 40 -> 45", vol(b), 60 * 45 * 20, 0.01)
        e_z0 = nxh.one([e for e in b.GetEdges() if abs(nxh.bbox(e)[2]) < 1e-6 and abs(nxh.bbox(e)[5]) < 1e-6 and abs(nxh.bbox(e)[0]) < 1e-6 and abs(nxh.bbox(e)[3]) < 1e-6], "bottom edge x0")
        e_z1 = nxh.one([e for e in b.GetEdges() if abs(nxh.bbox(e)[2] - 20) < 1e-6 and abs(nxh.bbox(e)[5] - 20) < 1e-6 and abs(nxh.bbox(e)[0]) < 1e-6 and abs(nxh.bbox(e)[3]) < 1e-6], "top edge x0")
        nxf.linear_dimension(part, e_z0, e_z1, top_of(b), 26, axis="Z")
        ck("linear_dimension.axis Z: height 20 -> 26", vol(b), 60 * 45 * 26, 0.01)
    case("linear / radial / angular dimension", c_dimensions)

    def c_divide_by_curves():
        b, y = blk()
        ln = nxh.line(part, (0, y + 10, 20), (60, y + 20, 20))             # across the top, on the face
        nxf.divide_face_by_curves(part, top_of(b), curves=[ln])
        areas = sorted(round(nxh.sheet_area(part, [f])[0], 3) for f in top_of(b))
        ct("divide_face_by_curves.the top is divided ALONG the line (projection = face normal): 900 + 1500", areas == [900.0, 1500.0], areas)
        b, y = blk()
        short = nxh.line(part, (20, y + 10, 20), (40, y + 10, 20))         # stops short of both edges
        nxf.divide_face_by_curves(part, top_of(b), curves=[short], extend=True)
        areas = sorted(round(nxh.sheet_area(part, [f])[0], 3) for f in top_of(b))
        ct("divide_face_by_curves.extend=True: a short line is run on to the boundary: 600 + 1800", areas == [600.0, 1800.0], areas)
    case("divide_face_by_curves", c_divide_by_curves)


# ============================================================================ tree: organising and editing
def g_tree(part):
    vol = lambda: nxh.volume(part, nxh.solids(part)[0])  # noqa: E731

    def c_suppress():
        fb, body = nxh.block(part, (0.0, 0.0, 0.0), (80, 60, 30))
        flug, body = nxh.block(part, (80.0, 20.0, 0.0), (20, 20, 10), op=BOOL.Unite, target=body)
        fbl = nxh.blend(part, [e for e in vertical_edges(nxh.solids(part)[0], 10) if nxh.bbox(e)[0] > 99.0], 3)
        v_full = vol()
        ck("suppress_by_expression.base: block + lug with two R3 blends", v_full, 144000 + 4000 - 2 * K * 9 * 10, 0.01)
        nxh.expr(part, "length", 340, "mm", "driving length")
        e = nxf.suppress_by_expression(part, [flug, fbl], "if (length > 200) (1) else (0)")
        ct("suppress_by_expression.shared: ONE expression on both features",
           nxh.UFS.ModlGeneral.AskSuppressExpTag(flug.Tag) == nxh.UFS.ModlGeneral.AskSuppressExpTag(fbl.Tag) == e.Tag)
        ck("suppress_by_expression.length 340: active", vol(), v_full, 0.01)
        nxh.set_expr(part, "length", 150)
        nxh.update()
        ck("suppress_by_expression.length 150: lug and blend gone", vol(), 144000.0, 0.01)
        ct("suppress_status.by_expression", nxh.suppress_status(flug)["by_expression"] and nxh.suppress_status(fbl)["by_expression"],
           [nxh.suppress_status(flug)["code"], nxh.suppress_status(fbl)["code"]])
        nxh.set_expr(part, "length", 340)
        nxh.update()
        ck("suppress_by_expression.length 340 again: both back", vol(), v_full, 0.01)
        ct("suppress_by_expression.no feature error", not nxh.feature_errors(part), nxh.feature_errors(part))
        # one expression per feature
        fh, _ = nxh.cylinder(part, (40, 30, 0), (0, 0, 1), 10, 30, BOOL.Subtract, nxh.solids(part)[0])
        es = nxf.suppress_by_expression(part, [fh], shared=False)
        ct("suppress_by_expression.shared=False returns a list", isinstance(es, list) and len(es) == 1, es)
        part.Expressions.CreateExpression("Boolean", "with_bore=false")
        es[0].RightHandSide = "with_bore"
        nxh.update()
        ck("suppress_by_expression.Boolean expression FALSE: bore suppressed", vol(), v_full, 0.01)
        part.Expressions.FindObject("with_bore").RightHandSide = "true"
        nxh.update()
        ck("suppress_by_expression.Boolean TRUE: bore active", vol(), v_full - math.pi * 25 * 30, 0.01)
    case("suppress_by_expression", c_suppress)

    def c_replace():
        fb, body = nxh.block(part, (0.0, 200.0, 0.0), (80, 60, 30))
        fbl = nxh.blend(part, vertical_edges(body, 30), 5)
        fh, _ = nxh.cylinder(part, (40, 230, 0), (0, 0, 1), 10, 30, BOOL.Subtract, body)
        v0 = nxh.volume(part, body)
        nxh.expr(part, "base_h", 30, "mm", "height of the base")
        def at_y(y0):
            return [s for s in nxh.solids(part) if abs(nxh.bbox(s)[1] - y0) < 1e-6]

        with nxh.insert_after(part, fb) as ip:                          # the new base must exist BEFORE the dependents
            fx = nxh.extrude(part, nxh.section(part, curves=nxh.rect(part, 0.0, 200.0, 80.0, 260.0)), (0, 0, 1), 0, "base_h")
        ct("insert_after.the new base was inserted cleanly", len(ip.report["added"]) == 1 and not ip.report["changed"], ip.report)
        r = nxf.replace_feature(part, fb, fx)
        ct("replace_feature.only the replaced Block is gone", len(r["gone"]) == 1 and "Block" in r["gone"][0], r)
        ck("replace_feature.one body left in that place", len(at_y(200.0)), 1, 0)
        ck("replace_feature.block -> extrude of the same size: blend and hole kept, volume unchanged", nxh.volume(part, at_y(200.0)[0]), v0, 0.01)
        nxh.set_expr(part, "base_h", 40)
        nxh.update()
        ck("replace_feature.the new base drives the part: height 40", nxh.volume(part, at_y(200.0)[0]), (80 * 60 - 4 * K * 25) * 40 - math.pi * 25 * 30, 0.01)
        ct("replace_feature.no feature error", not nxh.feature_errors(part), nxh.feature_errors(part))
        # a replacement of another size: unmatched dependents are refused unless the tolerance covers the shift
        fb, body = nxh.block(part, (0.0, 400.0, 0.0), (80, 60, 30))
        nxh.blend(part, vertical_edges(body, 30), 5)
        v0 = nxh.volume(part, body)
        with nxh.insert_after(part, fb):
            fx, _b2 = nxh.block(part, (0.0, 400.0, 0.0), (100, 60, 30))
        _r, why = nxh.attempt("replace with default tolerance", nxf.replace_feature, part, fb, fx)
        ct("replace_feature.default tolerance 1: the blend would be lost -> refused and undone", _r is None and "lost" in str(why), why)
        ct("replace_feature.refused: the old base is still there", abs(nxh.volume(part, body) - v0) < 0.01 and len(at_y(400.0)) == 2, len(at_y(400.0)))
        nxf.replace_feature(part, fb, fx, tolerance=25)
        ck("replace_feature.tolerance 25: one body left", len(at_y(400.0)), 1, 0)
        ck("replace_feature.tolerance 25: blend kept on the 100 mm base", nxh.volume(part, at_y(400.0)[0]), (100 * 60 - 4 * K * 25) * 30, 0.01)
    case("replace_feature", c_replace)

    def c_sketch_internal():
        dat = nxh.Datums(part)
        o = nxh.point(part, 200, 0, 0)
        sk = nxf.new_sketch(part, dat.xy, dat.x, o, name="SK_INT")
        nxf.sketch_rect_centered(part, sk, o, 40, 30)
        st = nxf.finish_sketch(sk)
        ct("to_reference.base sketch fully constrained", st["status"] == "WellConstrained" and st["dof"] == 0, st)
        fext = nxh.extrude(part, nxh.section_feature(part, [sk.Feature]), (0, 0, 1), 0, 10)
        body = fext.GetBodies()[0]
        n_top = len(nxh.top_features(part)[0])
        nxf.sketch_internal(fext)
        ct("sketch_internal.the sketch row is internal, one top-level row less", nxh.is_internal(sk.Feature) and len(nxh.top_features(part)[0]) == n_top - 1)
        nxf.sketch_internal(fext, False)
        ct("sketch_internal.external again", not nxh.is_internal(sk.Feature) and len(nxh.top_features(part)[0]) == n_top)
        # whole-sketch section: an added ACTIVE curve breaks the Extrude, a reference curve does not
        sk.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
        ln = part.Curves.CreateLine(P(170, 0, 0), P(230, 0, 0))
        nxf.add(sk, ln, infer=False)
        nxf.to_reference(part, [ln])
        sk.Update()
        sk.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
        nxh.update()
        ct("to_reference.a REFERENCE centre line leaves the whole-sketch Extrude alone", not nxh.feature_errors(part) and abs(nxh.volume(part, body) - 12000.0) < 0.01)
        sk.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
        nxf.to_reference(part, [ln], reference=False)
        sk.Update()
        sk.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
        nxh.update()
        errs = nxh.feature_errors(part)
        ct("to_reference.the same line ACTIVE: the Extrude fails (self intersecting section)", any("self intersecting" in str(v) for v in errs.values()), errs)
        sk.Activate(NXOpen.Sketch.ViewReorient.FalseValue)
        nxf.to_reference(part, [ln])
        sk.Update()
        sk.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
        nxh.update()
        ct("to_reference.reference again: the Extrude is healthy again", not nxh.feature_errors(part), nxh.feature_errors(part))
    case("sketch_internal / to_reference", c_sketch_internal)

    def c_measure_import():
        fb, body = nxh.block(part, (0.0, 600.0, 0.0), (80, 60, 30))
        edge = nxh.one([e for e in body.GetEdges() if abs(nxh.bbox(e)[3] - nxh.bbox(e)[0] - 80) < 1e-6 and abs(nxh.bbox(e)[1] - 600) < 1e-6
                        and abs(nxh.bbox(e)[4] - 600) < 1e-6 and abs(nxh.bbox(e)[2]) < 1e-6 and abs(nxh.bbox(e)[5]) < 1e-6], "length edge")
        fm, em = nxf.measure_length(part, [edge])
        ct("measure_length.a 'Length Measurement' feature with a measurement expression", fm.FeatureType == "LENGTH MEASUREMENT" and em.IsMeasurementExpression,
           [fm.FeatureType, em.Name])
        ck("measure_length.value 80", em.Value, 80.0, 1e-9)
        h = nxh.expr(part, "feed_x", "floor(%s)/2" % em.Name, "mm", "half of the measured length, whole mm")
        sysx = [x for x in fb.GetExpressions() if abs(x.Value - 80) < 1e-9][0]
        sysx.RightHandSide = "91.6"
        nxh.update()
        ck("measure_length.the expression follows the geometry: 91.6", em.Value, 91.6, 1e-9)
        ck("measure_length.a formula on it follows: floor(91.6)/2", h.Value, 45.5, 1e-9)
        fx0 = nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(-1, 0, 0)), "x0")
        fx1 = nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(1, 0, 0)), "x1")
        fd, ed = nxf.measure_distance(part, fx0, fx1)
        ck("measure_distance.between the two end faces", ed.Value, 91.6, 1e-9)
        path = os.path.join(OUT, "nxf_tree_import.exp")
        names = [x.Name for x in fb.GetExpressions()]
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("[mm]box_len=120 //overall length\n[mm]box_wid=box_len/2 //half the length\nn_cav=4\n(Boolean) with_lid=true\n")
            fh.write("[mm]%s=box_len\n[mm]%s=box_wid\n" % (sysx.Name, [n for n in names if n != sysx.Name][0]))
        msgs = nxf.import_expressions(part, path)
        ct("import_expressions.clean import", msgs == [], msgs)
        ck("import_expressions.named master created", part.Expressions.FindObject("box_len").Value, 120.0, 1e-9)
        ct("import_expressions.the system expression of the Block is re-wired to it", sysx.RightHandSide == "box_len", sysx.RightHandSide)
        ck("import_expressions.the body follows: 120 long", nxh.bbox(body)[3], 120.0, 1e-6)
        ct("import_expressions.typed line (Boolean)", part.Expressions.FindObject("with_lid").BooleanValue is True)
    case("measure / import expressions", c_measure_import)


# ============================================================================ copies, draft types, blend overflow
def g_copies(part):
    vol = lambda b: nxh.volume(part, b)  # noqa: E731
    tan = lambda a: math.tan(math.radians(a))  # noqa: E731

    def prismatoid(a1, b1, a2, b2, h):
        return h / 6.0 * (a1 * b1 + a2 * b2 + (a1 + a2) * (b1 + b2))

    def zcyl(b, r):
        return [f for f in nxh.faces(b, ftype=nxh.CYLINDER, radius=r) if abs(abs(nxh.face_data(f)[2][2]) - 1) < 1e-6]

    def xedge(b, y, z):
        return nxh.one([e for e in b.GetEdges() if abs(nxh.bbox(e)[1] - y) < 1e-6 and abs(nxh.bbox(e)[4] - y) < 1e-6
                        and abs(nxh.bbox(e)[2] - z) < 1e-6 and abs(nxh.bbox(e)[5] - z) < 1e-6], "edge along x at y=%s z=%s" % (y, z))

    def c_overflow():
        # 12 mm wide top: R3 on the front edge leaves it flat from y = 3; R10 on the back edge needs it from y = 2
        def body():
            _, b = nxh.block(part, (0, -100 * (1 + len(made)), 0), (40, 12, 20))
            made.append(b)
            y = nxh.bbox(b)[1]
            nxh.blend(part, [xedge(b, y, 20)], 3)
            return b, y
        made = []
        b, y = body()
        v0 = vol(b)
        _f, why = nxh.attempt("no overflow", nxf.edge_blend, part, [([xedge(b, y + 12, 20)], 10)])
        ct("edge_blend.default (overflow off, a fresh builder): the R10 that overflows the R3 is refused", _f is None and "terminate" in str(why), why)
        nxf.edge_blend(part, [([xedge(b, y + 12, 20)], 10)], overflow=True)
        ct("edge_blend.overflow=True (the dialog's three switches): the same blend commits, valid body", vol(b) < v0 - 100 and nxh.body_ok(part, b), v0 - vol(b))
        res["notes"]["edge_blend.overflow_removed"] = v0 - vol(b)
        b, y = body()
        _f, why = nxh.attempt("nxh.blend no overflow", nxh.blend, part, [xedge(b, y + 12, 20)], 10)
        ct("nxh.blend.default: refused", _f is None, why)
        v0 = vol(b)
        nxh.blend(part, [xedge(b, y + 12, 20)], 10, overflow=True)
        ck("nxh.blend.overflow=True: commits with the same body as edge_blend", v0 - vol(b), res["notes"]["edge_blend.overflow_removed"], 1e-6)
        m = nxh.mark("move sharp edge only", False)
        b, y = body()
        v0 = vol(b)
        nxh.blend(part, [xedge(b, y + 12, 20)], 10, overflow={"MoveSharpEdge": True})
        res["notes"]["edge_blend.move_sharp_edge_removed"] = v0 - vol(b)
        ct("nxh.blend.overflow={'MoveSharpEdge': True}: commits too, with a DIFFERENT body (the R10 keeps its shape and cuts into the R3)",
           abs((v0 - vol(b)) - res["notes"]["edge_blend.overflow_removed"]) > 5, [v0 - vol(b), res["notes"]["edge_blend.overflow_removed"]])
        b, y = body()
        rep = nxf.blend_chains(part, [[xedge(b, y + 12, 20)]], 10, overflow=False)
        ct("blend_chains(overflow=False): the R10 is refused and the R5 fallback is built", rep[0]["built"] == "blend, smaller" and not rep[0]["overflow"], rep[0]["built"])
        # the default "retry": the refused R10 is tried again with the dialog's switches BEFORE the radius is halved
        b, y = body()
        v0 = vol(b)
        rep = nxf.blend_chains(part, [[xedge(b, y + 12, 20)]], 10)
        res["notes"]["blend_chains.retry"] = [{k_: v for k_, v in r.items() if k_ != "untreated_edges"} for r in rep]
        ct("blend_chains default (overflow='retry'): the refused R10 is built at the requested radius with overflow",
           rep[0]["built"] == "blend, overflow" and rep[0]["size"] == "10" and rep[0]["overflow"] is True, [rep[0]["built"], rep[0]["size"], rep[0]["errors"]])
        ck("blend_chains retry: same body as edge_blend(overflow=True)", v0 - vol(b), res["notes"]["edge_blend.overflow_removed"], 1e-6)
        ct("blend_chains retry: body valid, nothing left behind by the refused first attempt", nxh.body_ok(part, b) and not nxh.feature_errors(part), nxh.feature_errors(part))
        # a blend that fits is not touched by the retry (no overflow flag)
        b, y = body()
        rep = nxf.blend_chains(part, [[xedge(b, y + 12, 20)]], 4)
        ct("blend_chains retry: a blend that fits (R4) is built plain, overflow not used", rep[0]["built"] == "blend" and rep[0]["overflow"] is False, rep[0]["built"])
        # break_edges with the retry: the 0.3 high pad case no longer needs the edge-by-edge route if overflow can make it
        _f, b4 = nxh.block(part, (0, -900, 0), (40, 30, 20))
        nxh.block(part, (10, -895, 20), (10, 10, 0.3), NXOpen.Features.Feature.BooleanType.Unite, b4)
        v0 = vol(b4)
        rep = nxf.break_edges(part, b4, 1, concave=False, chamfer=False)
        res["notes"]["break_edges.retry"] = {k_: v for k_, v in rep.items()}
        ct("break_edges default (retry): body valid and at least the 12 block edges treated",
           nxh.body_ok(part, b4) and rep["treated"] >= 12 and vol(b4) < v0 - 50.0, [rep["mode"], rep["overflow"], rep["treated"], len(rep["untreated"]), v0 - vol(b4)])
    case("blend overflow switches", c_overflow)

    def c_copy_check():
        _, plate = nxh.block(part, (0, 0, 0), (160, 60, 10))
        v_base = vol(plate)
        f1, _b = nxh.cylinder(part, (20, 30, 10), (0, 0, 1), 16, 12, BOOL.Unite, plate)
        v_boss = vol(plate) - v_base
        fp = nxf.pattern_linear(part, [f1], (1, 0, 0), 4, 25)
        r = nxf.copy_check(part, 4, v_boss, plate, v_base, seed_faces=1, count_faces=lambda: len(zcyl(plate, 8.0)))
        ct("copy_check.4 bosses: volume, face count and messages agree", r["ok"], r["problems"])
        r = nxf.copy_check(part, 5, v_boss, plate, v_base)
        ct("copy_check.asked for 5 where 4 exist: not ok, says why", not r["ok"] and "volume delta" in r["problems"][0], r["problems"])
        root = nxh.one(nxh.edges(plate, lambda b: abs(b[2] - 10) < 1e-6 and abs(b[5] - 10) < 1e-6 and abs(b[0] - 12) < 1e-4 and abs(b[3] - 28) < 1e-4), "root edge")
        with nxh.insert_after(part, f1):
            v_before = vol(plate)
        det = nxf.add_to_pattern(part, fp, f1, lambda: nxh.blend(part, [root], 3))
        fbl = det[0]
        with nxh.insert_after(part, fbl):                               # the blended seed alone
            v_seed = vol(plate) - v_base
        blends = lambda: len([f for f in plate.GetFaces() if nxh.face_data(f)[0] not in (nxh.PLANE, nxh.CYLINDER)])  # noqa: E731
        r = nxf.copy_check(part, 4, v_seed, plate, v_base, seed_faces=1, count_faces=blends)
        ct("add_to_pattern.root blend added to the INPUT of the existing pattern: 4 blended bosses", r["ok"] and v_seed > v_boss + 1, r["problems"])
        ct("add_to_pattern.tree order: boss, blend, pattern", f1.Timestamp < fbl.Timestamp < fp.Timestamp, [f1.Timestamp, fbl.Timestamp, fp.Timestamp])
        res["notes"]["add_to_pattern.v_before"] = v_before
    case("copy_check / add_to_pattern", c_copy_check)

    def c_pattern_options():
        def grid(y0, **kw):
            _, plate = nxh.block(part, (0, y0, 0), (120, 100, 5))
            fh = nxf.hole(part, plate, [(10.0, y0 + 10.0, 5.0)], 4, vector=(0, 0, -1))
            fh = fh[0] if isinstance(fh, (tuple, list)) else fh
            return plate, fh, kw
        plate, fh, _k = grid(200)
        nxf.pattern_linear(part, [fh], (1, 0, 0), 4, 20, (0, 1, 0), 4, 20, frame_only=True)
        ck("pattern_linear.frame_only: 12 of the 4 x 4 holes", len(zcyl(plate, 2.0)), 12, 0)
        plate, fh, _k = grid(400)
        nxf.pattern_linear(part, [fh], (1, 0, 0), 4, 20, (0, 1, 0), 4, 20, stagger="row")
        rows = {}
        for c in zcyl(plate, 2.0):
            rows.setdefault(round(nxh.face_data(c)[1][1] - 400, 3), []).append(round(nxh.face_data(c)[1][0], 3))
        ct("pattern_linear.stagger='row': 16 holes, every second row shifted by half a pitch",
           sum(len(v) for v in rows.values()) == 16 and min(rows[10.0]) == 10.0 and min(rows[30.0]) == 20.0, {k: sorted(v) for k, v in rows.items()})
        plate, fh, _k = grid(600)
        fp = nxf.pattern_feature(part, [fh], lambda ps: nxf._linear(part, ps, (1, 0, 0), 4, 20))
        errs = nxf.pattern_clock(part, fp, 2, 0, 5)
        xs = sorted(round(nxh.face_data(c)[1][0], 3) for c in zcyl(plate, 2.0))
        ct("pattern_feature + pattern_clock.instance [2][0] moved by 5: x = 10, 30, 55, 70", xs == [10.0, 30.0, 55.0, 70.0] and not errs, [xs, errs])
    case("pattern stagger / frame / clocking", c_pattern_options)

    def c_scale_unite_extract():
        _f, a = nxh.block(part, (0, 800, 0), (40, 30, 20))
        nxf.scale_axisymmetric(part, [a], 1.1, 1.05, origin=(20, 815, 0), vec=(0, 0, 1))
        bb = nxh.bbox(a)
        ck("scale_axisymmetric.volume x 1.1 x 1.05^2", vol(a) / 24000.0, 1.1 * 1.05 ** 2, 1e-6)
        ct("scale_axisymmetric.22 high, 42 x 31.5 across", abs(bb[5] - 22) < 1e-4 and abs(bb[3] - bb[0] - 42) < 1e-4 and abs(bb[4] - bb[1] - 31.5) < 1e-4, bb)
        _f, plate = nxh.block(part, (0, 900, 0), (60, 40, 10))
        _f, post = nxh.cylinder(part, (30, 920, -8), (0, 0, 1), 12, 30)       # overshoots: 8 below the plate, 12 above
        bot = nxh.one(nxh.faces(post, ftype=nxh.PLANE, normal=(0, 0, -1)), "post bottom")
        nxf.unite_remove_region(part, plate, post, bot)
        ck("unite_remove_region.the stub below the plate is removed in the Unite: plate + 12 high post", vol(plate), 24000 + math.pi * 36 * 12, 1e-3)
        ck("unite_remove_region.nothing below z = 0", nxh.bbox(plate)[2], 0.0, 1e-6)
        _f, blk2 = nxh.block(part, (0, 1000, 0), (60, 40, 20))
        h1, _b = nxh.cylinder(part, (15, 1020, 0), (0, 0, 1), 8, 20, BOOL.Subtract, blk2)
        nxh.cylinder(part, (45, 1020, 0), (0, 0, 1), 8, 20, BOOL.Subtract, blk2)
        v_fin = vol(blk2)
        fe, new = nxf.extract_body_before(part, [blk2], h1)
        ck("extract_body_before.the copy is the BLANK before the first hole", vol(new[0]), 48000.0, 1e-6)
        ck("extract_body_before.the original keeps its holes", vol(blk2), v_fin, 1e-6)
        ct("extract_body_before.the extract sits before the hole in the tree", fe.Timestamp < h1.Timestamp)
    case("scale axisymmetric / unite with region / extract before", c_scale_unite_extract)

    def c_varsweep():
        _, b = nxh.block(part, (0, 1100, 0), (60, 40, 20))
        v0 = vol(b)
        path = xedge(b, 1100, 20)
        sk = nxf.sketch_on_path(part, [part.ScRuleFactory.CreateRuleEdgeDumb([path])], path, (0, 1100, 20))
        for c in nxh.polyline(part, [(0, 1100, 20), (0, 1102, 20), (0, 1102, 23), (0, 1100, 23)]):
            nxf.add(sk, c, infer=False)
        sk.Update()
        sk.Deactivate(NXOpen.Sketch.ViewReorient.FalseValue, NXOpen.Sketch.UpdateLevel.Model)
        f = nxf.variational_sweep(part, sk, (0, 1100, 20), BOOL.Unite, b)
        ck("variational_sweep.2 x 3 lip (sketch on path) along a 60 mm edge, united: + 360", vol(b) - v0, 360.0, 1e-3)
        res["notes"]["variational_sweep.type"] = f.FeatureType
    case("sketch_on_path / variational_sweep", c_varsweep)

    def c_drafts():
        def walls(b):
            return [f for f in b.GetFaces() if nxh.face_data(f)[0] == nxh.PLANE and abs(nxh.face_data(f)[2][2]) < 0.7]
        _f, dz = nxh.datum_plane(part, (0, 0, 10), (0, 0, 1))
        _, b = nxh.block(part, (0, 1200, 0), (80, 60, 30))
        nxf.draft_parting(part, walls(b), (0, 0, 1), 7, 10, parting_datum=dz)
        want = prismatoid(80, 60, 80 - 40 * tan(7), 60 - 40 * tan(7), 20) + prismatoid(80, 60, 80 - 20 * tan(10), 60 - 20 * tan(10), 10)
        ck("draft_parting.7 deg above / 10 deg below a parting plane at z = 10: two prismatoids", vol(b), want, 1e-2)
        _, b = nxh.block(part, (0, 1300, 0), (80, 60, 30))
        nxf.draft_parting(part, walls(b), (0, 0, 1), 5, parting_datum=dz)
        want = prismatoid(80, 60, 80 - 40 * tan(5), 60 - 40 * tan(5), 20) + prismatoid(80, 60, 80 - 20 * tan(5), 60 - 20 * tan(5), 10)
        ck("draft_parting.one angle, both sides (symmetric 5)", vol(b), want, 1e-2)
        _, b = nxh.block(part, (0, 1400, 0), (80, 60, 30))
        bottom = [e for e in b.GetEdges() if abs(nxh.bbox(e)[2]) < 1e-6 and abs(nxh.bbox(e)[5]) < 1e-6]
        nxf.draft_edges(part, [(bottom, 5)], (0, 0, 1))
        res["notes"]["draft_edges.volume"] = vol(b)
        ck("draft_edges.the four bottom edges stay, the walls lean 5 deg: prismatoid 30 high", vol(b),
           prismatoid(80, 60, 80 - 60 * tan(5), 60 - 60 * tan(5), 30), 1e-2)
        ck("draft_edges.the bottom keeps 80 x 60", nxh.sheet_area(part, nxh.faces(b, ftype=nxh.PLANE, normal=(0, 0, -1)))[0], 4800.0, 1e-4)
        _, b = nxh.block(part, (0, 1500, 0), (80, 60, 30))
        before = list(part.Bodies)
        nxf.bounded_plane(part, curves=nxh.rect(part, -10, 1490, 90, 1570, 10.0), hp=(-10, 1490, 10))
        sheet = nxh.new_bodies(part, before)[0]
        nxf.divide_faces_by_sheet(part, walls(b), sheet)
        pe = nxf.split_edges(b)
        ck("divide_faces_by_sheet + split_edges.a parting line of four edges at z = 10", len(pe), 4, 0)
        nxf.draft_parting_edges(part, pe, (0, 0, -1), 3, dz)
        ck("draft_parting_edges.pull -Z, 3 deg: the part below the parting line is drafted, above it unchanged", vol(b),
           96000 + prismatoid(80, 60, 80 - 20 * tan(3), 60 - 20 * tan(3), 10), 1e-2)
        vols = {}
        for i, match in enumerate((None, "FromEdges")):
            _, b = nxh.block(part, (0, 1600 + 100 * i, 0), (80, 60, 30))
            nxf.draft_body(part, walls(b), dz, (0, 0, 1), 4, match=match)
            vols[str(match)] = (vol(b), len(b.GetFaces()))
        res["notes"]["draft_body.match"] = vols
        ct("draft_body.no match type: a ledge at the off-centre parting plane (11 faces)", vols["None"][1] == 11, vols)
        ct("draft_body.match='FromEdges': the two sides meet, no ledge (10 faces), more volume", vols["FromEdges"][1] == 10 and vols["FromEdges"][0] > vols["None"][0] + 100, vols)
    case("draft types", c_drafts)

    def c_shell_offset():
        _, b = nxh.block(part, (0, 1800, 0), (80, 60, 30))
        nxf.shell(part, b, top_of(b), 2, pierce=False)
        ck("shell.pierce=False on a box with sharp edges: the plain shell", vol(b), 144000 - 76 * 56 * 28, 1e-6)
        _, b = nxh.block(part, (0, 1900, 0), (60, 40, 20))
        top = top_of(b)[0]
        used = None
        for sign in ("-5", "5"):
            m = nxh.mark("single offset", False)
            nxf.extrude_ex(part, nxh.section(part, edges=list(top.GetEdges()), help_point=(0, 1900, 20)), (0, 0, -1), 0, 8, BOOL.Subtract, b, single_offset=sign)
            if abs(48000 - vol(b) - 50 * 30 * 8) < 1e-3:
                used = sign
                break
            nxh.undo_to(m)
        res["notes"]["extrude_ex.single_offset_sign_inward"] = used
        ct("extrude_ex.single_offset: a 50 x 30 x 8 pocket 5 inside the edges of the top face, no sketch", used is not None, used)
    case("shell pierce / extrude single offset", c_shell_offset)



# ============================================================================ surfaces
def g_surface(part):
    vol = lambda b: nxh.volume(part, b)  # noqa: E731
    area = lambda b: nxh.sheet_area(part, b)[0]  # noqa: E731
    cone_half = math.pi * 30 * math.sqrt(1700) / 2
    frustum_v = math.pi * 40 / 3 * 700

    def plane_sheet(x0, y0, w=40, h=30):
        return nxf.bounded_plane(part, curves=nxh.rect(part, x0, y0, x0 + w, y0 + h, 0.0), hp=(x0, y0, 0)).GetBodies()[0]

    def half_cyl(x0, y0, r=5, length=50):
        a = nxh.arc(part, (x0, y0, 0), (0, 1, 0), (0, 0, 1), r, 0.0, math.pi)
        before = list(part.Bodies)
        nxh.extrude(part, nxh.section(part, curves=[a], help_point=(x0, y0 + r, 0)), (1, 0, 0), 0, length, sheet=True)
        return nxh.new_bodies(part, before)[0]

    def c_loft():
        a1 = nxh.arc(part, (0, 0, 0), (1, 0, 0), (0, 1, 0), 20, 0.0, math.pi)
        a2 = nxh.arc(part, (0, 0, 40), (1, 0, 0), (0, 1, 0), 10, 0.0, math.pi)
        body = nxf.through_curves(part, [nxh.section(part, curves=[a1], help_point=(20, 0, 0)),
                                         nxh.section(part, curves=[a2], help_point=(10, 0, 40))]).GetBodies()[0]
        ck("through_curves.sheet: half-cone area", area(body), cone_half, 0.2)
        ck("through_curves.sheet: free edges", len(nxh.free_edges(body)), 4, 0)
        c1 = nxh.circle(part, (100, 0, 0), 20)
        c2 = nxh.circle(part, (100, 0, 40), 10)
        body = nxf.through_curves(part, [nxh.section(part, curves=c1, help_point=(120, 0, 0)),
                                         nxh.section(part, curves=c2, help_point=(110, 0, 40))], solid=True).GetBodies()[0]
        ct("through_curves.solid: IsSolidBody", body.IsSolidBody)
        ck("through_curves.solid: frustum volume", vol(body), frustum_v, 3.0)
        q1 = nxh.rect(part, 200, 0, 240, 40, 0.0)
        q2 = nxh.rect(part, 210, 10, 230, 30, 30.0)
        body = nxf.through_curves(part, [nxh.section(part, curves=q1, help_point=(200, 0, 0)),
                                         nxh.section(part, curves=q2, help_point=(210, 10, 30))], solid=True, preserve=True,
                                  align=nxf.GU.AlignmentMethodBuilder.Type.Parameter).GetBodies()[0]
        ck("through_curves.preserve=True square frustum: volume", vol(body), 28000.0, 0.01)
        ck("through_curves.preserve=True: one face per side", len(body.GetFaces()), 6, 0)
    case("through_curves", c_loft)

    def c_loft_g1():
        before = list(part.Bodies)
        nxh.extrude(part, nxh.section(part, curves=[nxh.line(part, (300, 0, 0), (340, 0, 0))], help_point=(300, 0, 0)),
                    (0, -1, 0), 0, 30, sheet=True)
        base = nxh.new_bodies(part, before)[0]
        edge = [e for e in base.GetEdges() if abs(nxh.bbox(e)[1]) < 1e-6 and abs(nxh.bbox(e)[4]) < 1e-6][0]
        s1 = nxh.section(part, edges=[edge], help_point=(300, 0, 0))
        s2 = nxh.section(part, curves=[nxh.line(part, (300, 30, 20), (340, 30, 20))], help_point=(300, 30, 20))
        body = nxf.through_curves(part, [s1, s2], g1_first=base.GetFaces()).GetBodies()[0]
        ck("through_curves.g1_first: |normal z| at the shared edge", abs(nxh.normal_at(body.GetFaces()[0], (320, 0, 0))[2]), 1.0, 1e-4)
        ck("through_curves.g1_first: area", area(body), 1514.04, 0.5)
    case("through_curves G1", c_loft_g1)

    def c_swept():
        a = nxh.arc(part, (0, 100, 0), (0, 1, 0), (0, 0, 1), 5, 0.0, math.pi)
        g = nxh.line(part, (0, 105, 0), (50, 105, 0))
        body = nxf.swept(part, [nxh.section(part, curves=[a], help_point=(0, 105, 0))],
                         [nxh.section(part, curves=[g], help_point=(0, 105, 0))]).GetBodies()[0]
        ck("swept.open section along a line: area", area(body), math.pi * 5 * 50, 0.05)
        c = nxh.circle(part, (100, 100, 0), 4, xdir=(0, 1, 0), ydir=(0, 0, 1))
        g = nxh.arc(part, (100, 150, 0), (1, 0, 0), (0, 1, 0), 50, -math.pi / 2, 0.0)
        body = nxf.swept(part, [nxh.section(part, curves=c, help_point=(100, 104, 0))],
                         [nxh.section(part, curves=[g], help_point=(100, 100, 0))], solid=True).GetBodies()[0]
        ck("swept.solid=True circle along an arc: volume (B-surface, ~0.15 % low)", vol(body), math.pi * 16 * math.pi / 2 * 50, 8.0)
        sl = nxh.line(part, (200, 100, 0), (200, 120, 0))
        g1 = nxh.line(part, (200, 100, 0), (260, 100, 0))
        g2 = nxh.line(part, (200, 120, 0), (260, 140, 10))
        body = nxf.swept(part, [nxh.section(part, curves=[sl], help_point=(200, 100, 0))],
                         [nxh.section(part, curves=[g1], help_point=(200, 100, 0)), nxh.section(part, curves=[g2], help_point=(200, 120, 0))],
                         scaling=nxf.GU.ScalingMethodBuilder.ScalingOptions.Uniform).GetBodies()[0]
        ck("swept.two guides + Uniform scaling: surface passes through guide 2", nxh.dist_to(part, body, (230, 130, 5)), 0.0, 0.005)
    case("swept", c_swept)

    def c_swept_helix():
        dia, pitch, turns = 30.0, 8.0, 4.0
        turn = math.sqrt((math.pi * dia) ** 2 + pitch ** 2)
        fh = nxf.helix(part, dia, pitch, turns)
        crv = list(fh.GetEntities())
        ck("helix: length = turns x sqrt((pi d)^2 + p^2)", sum(c.GetLength() for c in crv), turns * turn, 0.02)
        ck("helix: starts at (d/2, 0, 0)", nxh.dist_to(part, crv[0], (dia / 2, 0, 0)), 0.0, 1e-4)
        ck("helix: right hand - after a quarter turn at (0, +d/2, p/4)", nxh.dist_to(part, crv[0], (0, dia / 2, pitch / 4)), 0.0, 1e-2)
        tang = (0.0, math.pi * dia / turn, pitch / turn)                    # helix tangent at its start
        radial, across, start = (1.0, 0.0, 0.0), (0.0, -tang[2], tang[1]), (dia / 2, 0.0, 0.0)

        def pt(a, b_):
            return tuple(start[i] + a * radial[i] + b_ * across[i] for i in range(3))

        def wire(axis):                                                     # 4 (radial) x 2 section normal to the helix
            f = nxf.swept(part, [nxh.section(part, curves=nxh.polyline(part, [pt(-2, -1), pt(2, -1), pt(2, 1), pt(-2, 1)]), help_point=pt(-2, -1))],
                          [nxh.section(part, curves=crv, help_point=start)], solid=True, axis=axis)
            body = f.GetBodies()[0]
            caps = sorted(round(nxh.bbox(x)[3] - nxh.bbox(x)[0], 3) for x in body.GetFaces() if nxh.face_data(x)[0] == nxh.PLANE)
            return body, caps
        body, caps = wire((0, 0, 1))
        ck("swept.axis=(0, 0, 1) on a helix: volume = section x helix length (ratio)", vol(body) / (8.0 * turns * turn), 1.0, 1e-3)
        ct("swept.axis: both end sections keep the 4 mm radial width", len(caps) == 2 and all(abs(c - 4.0) < 1e-3 for c in caps), caps)
        _body2, caps2 = wire(None)
        ct("swept without axis on a helix: the section ROLLS (an end section is no longer 4 wide radially)",
           max(abs(c - 4.0) for c in caps2) > 0.1, caps2)
        fl = nxf.helix(part, dia, pitch, 1, right_hand=False)
        ck("helix.right_hand=False: after a quarter turn at (0, -d/2, p/4)", nxh.dist_to(part, fl.GetEntities()[0], (0, -dia / 2, pitch / 4)), 0.0, 1e-2)
    case("helix / swept axis", c_swept_helix)

    def c_bounded_fill():
        loop = nxh.rect(part, 0, 200, 40, 230, 0.0) + nxh.circle(part, (20, 215, 0), 5)
        plate = nxf.bounded_plane(part, curves=loop, hp=(0, 200, 0)).GetBodies()[0]
        ck("bounded_plane.rectangle with a hole: area", area(plate), 1200 - math.pi * 25, 0.01)
        hole = [e for e in plate.GetEdges() if e.SolidEdgeType == NXOpen.Edge.EdgeType.Circular]
        nxf.fill_surface(part, edges=hole, hp=(25, 215, 0), g1=True, patch=True)
        ck("fill_surface.patch=True closes the hole: area", area(plate), 1200.0, 0.01)
        ck("fill_surface.patched sheet has two faces", len(plate.GetFaces()), 2, 0)
        t0, t1 = math.atan2(15, 20), math.pi - math.atan2(15, 20)
        p1 = nxh.arc(part, (100, 220, -15), (0, 1, 0), (0, 0, 1), 25, t0, t1)
        p2 = nxh.arc(part, (160, 220, -15), (0, 1, 0), (0, 0, 1), 25, t0, t1)
        x1 = nxh.line(part, (100, 200, 0), (160, 200, 0))
        x2 = nxh.line(part, (100, 240, 0), (160, 240, 0))
        body = nxf.fill_surface(part, curves=[p1, x2, p2, x1], hp=(100, 200, 0)).GetBodies()[0]
        ck("fill_surface.non-planar loop of curves: area", area(body), 2 * math.asin(20 / 25) * 25 * 60, 0.5)
    case("bounded_plane / fill_surface", c_bounded_fill)

    def c_sew():
        c1 = nxh.circle(part, (0, 300, 0), 20)
        c2 = nxh.circle(part, (0, 300, 40), 10)
        tube = nxf.through_curves(part, [nxh.section(part, curves=c1, help_point=(20, 300, 0)),
                                         nxh.section(part, curves=c2, help_point=(10, 300, 40))]).GetBodies()[0]
        lo = [e for e in tube.GetEdges() if abs(nxh.bbox(e)[5]) < 1e-6]
        hi = [e for e in tube.GetEdges() if abs(nxh.bbox(e)[2] - 40) < 1e-6]
        caps = [nxf.bounded_plane(part, edges=lo, hp=(20, 300, 0)).GetBodies()[0],
                nxf.bounded_plane(part, edges=hi, hp=(10, 300, 40)).GetBodies()[0]]
        n_sheets = len(nxh.sheets(part))
        sewn = nxf.sew(part, tube, caps)
        ct("sew.closed set -> solid", sewn.IsSolidBody)
        ck("sew.free edges", len(nxh.free_edges(sewn)), 0, 0)
        ck("sew.volume", vol(sewn), frustum_v, 3.0)
        ck("sew.three sheets consumed", n_sheets - len(nxh.sheets(part)), 3, 0)
        a = plane_sheet(100, 300)
        c = plane_sheet(140.005, 300)
        joined = nxf.sew(part, a, [c])
        ck("sew.open pair stays a sheet: free edges 8 -> 6", len(nxh.free_edges(joined)), 6, 0)
    case("sew", c_sew)

    def c_thicken_offset_extract():
        nxh.expr(part, "wall_t", 2)
        sh = plane_sheet(0, 400)
        solid = nxf.thicken(part, sh, "wall_t").GetBodies()[0]
        ck("thicken.40 x 30 x 2", vol(solid), 2400.0, 0.01)
        nxh.set_expr(part, "wall_t", 3.5)
        nxh.update()
        ck("thicken.expression 2 -> 3.5", vol(solid), 4200.0, 0.01)
        hc = half_cyl(100, 410)
        ck("thicken.half cylinder both sides (1, -1)", vol(nxf.thicken(part, hc, 1, -1).GetBodies()[0]), math.pi / 2 * 20 * 50, 0.01)
        hc = half_cyl(100, 440)
        ck("thicken.reverse=True goes inward", vol(nxf.thicken(part, hc, 1, 0, True).GetBodies()[0]), math.pi / 2 * 9 * 50, 0.01)
        _f, blk = nxh.block(part, (200, 400, 0), (60, 40, 20))
        off = nxf.offset_surface(part, top_of(blk), 5).GetBodies()[0]
        ck("offset_surface.+5 from the top: passes through z=25", nxh.dist_to(part, off, (230, 420, 25)), 0.0, 1e-6)
        ck("offset_surface.area", area(off), 2400.0, 0.01)
        hc = half_cyl(300, 410)
        ck("offset_surface.half cylinder +1: area", area(nxf.offset_surface(part, hc.GetFaces(), 1).GetBodies()[0]), math.pi * 6 * 50, 0.01)
        hc = half_cyl(300, 440)
        ck("offset_surface.flip=True: inward (R4)", area(nxf.offset_surface(part, hc.GetFaces(), 1, flip=True).GetBodies()[0]),
           math.pi * 4 * 50, 0.01)
        side = nxh.faces(blk, ftype=nxh.PLANE, normal=(1, 0, 0))[0]
        ck("extract_face.associative=False: area", area(nxf.extract_face(part, top_of(blk), associative=False).GetBodies()[0]), 2400.0, 0.01)
        ck("extract_face.one face: area", area(nxf.extract_face(part, top_of(blk)[0]).GetBodies()[0]), 2400.0, 0.01)
        two = nxf.extract_face(part, [top_of(blk)[0], side]).GetBodies()[0]
        ck("extract_face.two faces, one body: area", area(two), 3200.0, 0.01)
        ck("extract_face.two faces: free edges", len(nxh.free_edges(two)), 6, 0)
    case("thicken / offset_surface / extract_face", c_thicken_offset_extract)

    def c_extend_trim():
        hc = half_cyl(0, 520)
        nxf.extend_sheet(part, nxh.edges(hc, lambda b: abs(b[0] - 50) < 1e-6 and abs(b[3] - 50) < 1e-6), 10)
        ck("extend_sheet.end edge +10: area", area(hc), math.pi * 5 * 60, 0.01)
        hc = half_cyl(0, 560)
        n_sh = len(nxh.sheets(part))
        f = nxf.extend_sheet(part, nxh.edges(hc, lambda b: abs(b[0] - 50) < 1e-6 and abs(b[3] - 50) < 1e-6), 10, as_new_sheet=True)
        ck("extend_sheet.as_new_sheet: original unchanged", area(hc), math.pi * 5 * 50, 0.01)
        ck("extend_sheet.as_new_sheet: one more sheet body", len(nxh.sheets(part)) - n_sh, 1, 0)
        ck("extend_sheet.as_new_sheet: extension area", area(f.GetBodies()[0]), math.pi * 5 * 10, 0.01)
        sh = plane_sheet(100, 500)
        nxf.trim_sheet(part, sh, (105, 515, 0), True, curves=[nxh.line(part, (115, 495, 0), (115, 535, 0))], hp=(115, 495, 0))
        ck("trim_sheet.line, keep the left 15 mm: area", area(sh), 450.0, 0.01)
        sh = plane_sheet(200, 500)
        nxf.trim_sheet(part, sh, (220, 515, 0), False, curves=nxh.circle(part, (220, 515, 8), 5), hp=(225, 515, 8))
        ck("trim_sheet.circle projected, discard inside: area", area(sh), 1200 - math.pi * 25, 0.01)
        sh = plane_sheet(300, 500)
        _df, dp = nxh.datum_plane(part, (315, 500, 0), (1, 0, 0))
        nxf.trim_sheet(part, sh, (305, 515, 0), True, datum_plane=dp)
        ck("trim_sheet.datum plane: area", area(sh), 450.0, 0.01)
        sh = plane_sheet(400, 500)
        before = list(part.Bodies)
        nxh.extrude(part, nxh.section(part, curves=[nxh.line(part, (415, 495, -5), (415, 535, -5))], help_point=(415, 495, -5)),
                    (0, 0, 1), 0, 10, sheet=True)
        tool = nxh.new_bodies(part, before)[0]
        nxf.trim_sheet(part, sh, (405, 515, 0), True, faces=tool.GetFaces())
        ck("trim_sheet.faces of another sheet: area", area(sh), 450.0, 0.01)
        hc = half_cyl(500, 510)
        nxf.trim_sheet(part, hc, (510, 510, 5), True, curves=[nxh.line(part, (525, 500, 20), (525, 520, 20))], hp=(525, 500, 20),
                       vec=(0, 0, -1))
        ck("trim_sheet.vec= projection onto a half cylinder: area", area(hc), math.pi * 5 * 25, 0.01)
    case("extend_sheet / trim_sheet", c_extend_trim)


# ============================================================================ STEP
def g_step(part):
    HOLE = math.pi * 25 * 20
    _, b = nxh.block(part, (0, 0, 0), (60, 40, 20))
    nxh.cylinder(part, (30, 20, 0), (0, 0, 1), 10, 20, BOOL.Subtract, b)
    nxh.blend(part, vertical_edges(b, 20), 3)
    v_src = nxh.volume(part, b)
    ck("step.source volume", v_src, 48000 - HOLE - 4 * (9 - math.pi * 9 / 4) * 20, 0.01)
    s242 = os.path.join(OUT, "nxf_step_ap242.stp")
    s214 = os.path.join(OUT, "nxf_step_ap214.stp")
    ct("step_dir exists", os.path.isdir(nxf.step_dir()), nxf.step_dir())

    def c_export():
        nxf.step_export(part, s242)
        txt = open(s242, errors="ignore").read()
        ck("step_export.AP242: MANIFOLD_SOLID_BREP count", txt.count("MANIFOLD_SOLID_BREP"), 1, 0)
        ct("step_schema.AP242 file", nxf.step_schema(s242) == "AP242", nxf.step_schema(s242))
        nxf.step_export(part, s214, ap242=False)
        txt = open(s214, errors="ignore").read()
        ck("step_export.AP214: MANIFOLD_SOLID_BREP count", txt.count("MANIFOLD_SOLID_BREP"), 1, 0)
        ct("step_schema.AP214 file", nxf.step_schema(s214) == "AP214", nxf.step_schema(s214))
    case("step_export", c_export)

    def c_import():
        tgt = nxh.new_part(os.path.join(OUT, "nxf_step_target.prt"))
        new = nxf.step_import(tgt, s242, os.path.join(OUT, "nxf_step_scratch242.prt"))
        ck("step_import.AP242 (Step242Importer): bodies", len(new), 1, 0)
        ck("step_import.AP242: volume == source", nxh.volume(tgt, new[0]), v_src, 0.01)
        new2 = nxf.step_import(tgt, s214, os.path.join(OUT, "nxf_step_scratch214.prt"))
        ck("step_import.AP214 (Step214Importer + step214ug.def): bodies", len(new2), 1, 0)
        ck("step_import.AP214: volume == source", nxh.volume(tgt, new2[0]), v_src, 0.01)
        nxf.offset_region(tgt, top_of(new[0]), 2)
        ck("step_import.imported BREP is editable (offset region +2)", nxh.volume(tgt, new[0]), v_src * 22 / 20, 0.05)
        r = nxf.step_roundtrip_check(s242, OUT, "nxf_rt", restore=tgt, part=part)
        ct("step_roundtrip_check.part=: match within rel_tol 1e-4", r["match"] is True and r["max_rel"] < 1e-6, r["per_body"])
        ct("step_roundtrip_check: a piece part is not an assembly", r["assembly"] is False and r["instances"] == [])
        res["notes"]["step_roundtrip_check"] = r
        ck("step_roundtrip_check.solids", r["solids"], 1, 0)
        ck("step_roundtrip_check.volume", r["volume"], v_src, 0.01)
        ct("step_roundtrip_check.healthy (Examine Geometry all 0)", r["healthy"], r["examine"])
        ct("step_roundtrip_check.restore puts the work part back", r["restored"], r.get("restore_error", ""))
        ct("step_roundtrip_check.session work part is the caller's", nxh.S.Parts.Work.Tag == tgt.Tag)
    case("step_import / step_roundtrip_check", c_import)

    def c_multi():
        multi = nxh.new_part(os.path.join(OUT, "nxf_step_multi.prt"))
        bodies = [nxh.block(multi, (30 * i, 0, 0), (10, 10, 10 * (i + 1)))[1] for i in range(3)]
        bodies[2].Blank()
        stp = os.path.join(OUT, "nxf_step_multi.stp")
        nxf.step_export(multi, stp)
        ck("step_export: a blanked solid is NOT exported (3 solids, 1 blanked)", open(stp, errors="ignore").read().count("MANIFOLD_SOLID_BREP"), 2, 0)
        ck("instance_solids: a piece part has no instances", len(nxf.instance_solids(multi)), 0, 0)
        r = nxf.step_roundtrip_check(stp, OUT, "nxf_rt_multi", restore=multi, part=multi)
        res["notes"]["step_roundtrip_check.multi"] = {k: r[k] for k in ("solids", "volumes", "expected", "per_body", "max_rel", "match",
                                                                        "blanked_skipped", "restored")}
        ck("step_roundtrip_check.multi-body: solids", r["solids"], 2, 0)
        ck("step_roundtrip_check.multi-body: blanked_skipped", r["blanked_skipped"], 1, 0)
        ct("step_roundtrip_check.multi-body: compared with the UNBLANKED solids -> match", r["match"] is True, r["per_body"])
        ck("step_roundtrip_check.multi-body: per-body volume 2", r["per_body"][1]["got"], 2000.0, 0.01)
        r2 = nxf.step_roundtrip_check(stp, OUT, "nxf_rt_multi2", restore=multi, bodies=[bodies[0]])
        ct("step_roundtrip_check.bodies=[one of two exported]: count mismatch -> match False", r2["match"] is False, r2["expected"])
        r3 = nxf.step_roundtrip_check(stp, OUT, "nxf_rt_multi3", restore=multi, bodies=bodies[:2], rel_tol=1e-9)
        ct("step_roundtrip_check.bodies= + rel_tol=1e-9 on analytic blocks -> match", r3["match"] is True, r3["max_rel"])
        # the STEP importer must not leak into the session's load options (an assembly opened later lost its components)
        lo = nxh.S.Parts.LoadOptions
        lo.ComponentsToLoad = NXOpen.LoadOptions.LoadComponents.All
        tmp = nxh.new_part(os.path.join(OUT, "nxf_step_loadopt.prt"))
        got = nxf.step_import(tmp, stp, os.path.join(OUT, "nxf_step_loadopt_scratch.prt"))
        ck("step_import.two solids arrive", len(got), 2, 0)
        ct("step_import.the session load option Components To Load is unchanged by the import (All)",
           lo.ComponentsToLoad == NXOpen.LoadOptions.LoadComponents.All, str(lo.ComponentsToLoad))
    case("step multi-body / blanked", c_multi)


# ============================================================================ new sketch solver (optional)
def g_newsolver(part):
    """Sketch helpers in a NEW-solver sketch. A batch session cannot make one in a new part (every builder gives a
    legacy sketch there), so this group needs a part that was modelled in the NX user interface: set the environment
    variable NXF_NEW_SOLVER_PART to its path. A COPY is opened and never saved. Without the variable the group is
    skipped (a note, no check); the anchor mechanics are covered in group sketch with force=True."""
    src = os.environ.get("NXF_NEW_SOLVER_PART", "")
    note = res["notes"]["new_solver"] = {"NXF_NEW_SOLVER_PART": src}
    if not src or not os.path.isfile(src):
        note["skipped"] = "NXF_NEW_SOLVER_PART is not set to an existing part"
        log("group newsolver skipped:", note["skipped"])
        return
    work = os.path.join(OUT, "nxf_newsolver_copy.prt")
    shutil.copy2(src, work)
    ext = nxh.open_part(work)
    dat = nxh.Datums(ext)
    errors0 = len(nxh.feature_errors(ext))
    _f, dp = nxf.datum_plane(ext, "angle", [dat.xy, dat.x], 45)
    probe = nxf.new_sketch(ext, dp, dat.x, dat.origin, "NS_PROBE")
    legacy = nxf.legacy_solver(probe)
    q = nxf.sketch_to3d(probe)(0, 10)                               # a point of the inclined plane, 10 mm up the slope
    nxf.finish_sketch(probe)
    note["legacy"] = legacy
    if legacy:
        note["skipped"] = "the part gives legacy-solver sketches: not a part modelled in the NX user interface"
        log("group newsolver skipped:", note["skipped"])
        return
    for n_, v_ in (("ns_x", 40), ("ns_w", 20)):
        nxh.expr(ext, n_, v_)
    vol = lambda b: nxh.volume(ext, b)  # noqa: E731

    def smart():
        return nxh.point(ext, "ns_x", q.Y, q.Z)                     # on the 45 deg plane through the X axis

    def c_limit():
        pt = smart()
        sk = nxf.new_sketch(ext, dp, dat.x, pt, "NS_LIMIT")
        to3d = nxf.sketch_to3d(sk)
        u, v = nxf.sketch_uv(sk, pt)
        ls = nxf.hv_polygon(ext, sk, [(u - 10, v - 3), (u + 10, v - 3), (u + 10, v + 3), (u - 10, v + 3)], to3d)
        nxf.pdim(sk, ls[1], to3d(u + 10, v), pt, None, to3d(u + 5, v), "10")
        msg = ""
        try:
            nxf.pdim(sk, ls[3], to3d(u - 10, v), pt, None, to3d(u - 5, v), "10")
        except NXOpen.NXException as e:
            msg = str(e)
        note["second dimension to one smart point"] = msg or "accepted"
        ct("new solver: the SECOND dimension to one smart point is refused ('Invalid object type') - why sketch_anchor exists",
           "Invalid object type" in msg, msg or "accepted")
        nxf.finish_sketch(sk)
    case("new solver: one reference per smart point", c_limit)

    def c_helpers():
        pt = smart()
        sk = nxf.new_sketch(ext, dp, dat.x, pt, "NS_HELPERS")
        m = sk.Orientation.Element
        n = (m.Zx, m.Zy, m.Zz)
        ls = nxf.sketch_rect_centered(ext, sk, pt, "ns_w", 6)
        nxf.sketch_circle(ext, sk, pt, 3)
        an = nxf.sketch_anchor(ext, sk, pt)
        ct("new solver: the helpers went through ONE anchor - a reference point named nxf.ANCHOR",
           an.Tag != pt.Tag and an.Name == nxf.ANCHOR and len([g for g in sk.GetAllGeometry() if g.Name == nxf.ANCHOR]) == 1, an.Name)
        r = note["helpers"] = nxf.finish_sketch(sk)
        ct("new solver, 45 deg plane: sketch_rect_centered + sketch_circle on a smart point: WellConstrained, DOF 0, 6 objects",
           r["status"] == "WellConstrained" and r["dof"] == 0 and r["auto_dims"] == 0 and r["n_geom"] == 6, r)
        b = nxh.extrude(ext, nxh.section_feature(ext, [sk.Feature]), n, 0, 2).GetBodies()[0]
        hole = math.pi * 1.5 ** 2
        for x, w in ((40, 20), (47, 30), (40, 20)):
            nxh.set_expr(ext, "ns_x", x)
            nxh.set_expr(ext, "ns_w", w)
            nxh.update()
            bx = nxh.bbox(b)
            ck("new solver: whole-sketch extrude, ns_x %g / ns_w %g: volume" % (x, w), vol(b), (w * 6 - hole) * 2, 0.01)
            ck("new solver: ns_x %g: centred on the point along X" % x, (bx[0] + bx[3]) / 2, x, 1e-6)
            ck("new solver: ns_w %g: width along X" % w, bx[3] - bx[0], w, 1e-6)
        ct("new solver: the sketch is still WellConstrained / 0 after the edits", nxf.sketch_status(sk) == ("WellConstrained", 0), nxf.sketch_status(sk))
        ck("new solver: no new feature error", len(nxh.feature_errors(ext)), errors0, 0)
        u, v = nxf.sketch_uv(sk, pt)
        seed = nxf.sketch_to3d(sk)(u + 8, v + 2)                    # inside the rectangle, outside the circle
        f = nxf.extrude_ex(ext, nxh.section_region(ext, sk, (seed.X, seed.Y, seed.Z), curves=ls), n, 0, 2)
        ck("new solver: region rule seeded between rectangle and circle: the same volume", vol(f.GetBodies()[0]), (20 * 6 - hole) * 2, 0.01)
    case("new solver: sketch_rect_centered + sketch_circle on a smart point", c_helpers)

    def c_late():
        pt = smart()
        sk = nxf.new_sketch(ext, dp, dat.x, dat.origin, "NS_LATE")
        to3d = nxf.sketch_to3d(sk)
        u, v = nxf.sketch_uv(sk, pt)
        ln = ext.Curves.CreateLine(to3d(u - 10, v), to3d(u + 10, v))
        nxf.add(sk, ln)
        sk.CreatePointOnCurveConstraint(nxf.cg(pt), nxf.cg(ln), nxf.help_at(to3d(u, v)))
        msg = ""
        try:
            nxf.sketch_rect_centered(ext, sk, pt, 20, 6)
        except RuntimeError as e:
            msg = str(e)
        ct("new solver: a smart point that already carries a constraint -> sketch_anchor raises a RuntimeError that says so",
           "already references" in msg, msg)
        nxf.finish_sketch(sk)
    case("new solver: sketch_anchor after a direct reference", c_late)

    def c_solve():
        pt = smart()
        sk = nxf.new_sketch(ext, dp, dat.x, dat.origin, "NS_SOLVE")
        to3d = nxf.sketch_to3d(sk)
        u, v = nxf.sketch_uv(sk, pt)
        an = nxf.sketch_anchor(ext, sk, pt)
        ls = nxf.hv_polygon(ext, sk, [(u - 8, v - 4), (u + 11, v - 4), (u + 11, v + 7), (u - 8, v + 7)], to3d)      # drawn off size
        for ln, mid, f in ((ls[1], (u + 11, v), 10), (ls[3], (u - 8, v), 10), (ls[0], (u, v - 4), 3), (ls[2], (u, v + 7), 3)):
            nxf.pdim(sk, ln, to3d(*mid), an, nxf.A.StartPoint, to3d(u, v), str(f))
        r = note["solve"] = nxf.finish_sketch(sk)
        ct("new solver: finish_sketch solves a sketch drawn off size (LocalUpdate): WellConstrained, DOF 0",
           r["status"] == "WellConstrained" and r["dof"] == 0, r)
        ck("new solver: finish_sketch: the right line moved to its dimension (x = ns_x + 10)", ls[1].StartPoint.X, 50.0, 1e-6)
        ck("new solver: finish_sketch: the left line moved to its dimension (x = ns_x - 10)", ls[3].StartPoint.X, 30.0, 1e-6)
    case("new solver: finish_sketch solves", c_solve)

    def c_origin():
        sk = nxf.new_sketch(ext, dp, dat.x, dat.origin, "NS_ORIGIN")
        nxf.sketch_rect_centered(ext, sk, dat.origin, 20, 6)
        nxf.sketch_circle(ext, sk, dat.origin, 3)
        r = note["datum origin"] = nxf.finish_sketch(sk)
        ct("new solver: datum CSYS origin as centre (through an anchor too): WellConstrained, DOF 0, 6 objects",
           r["status"] == "WellConstrained" and r["dof"] == 0 and r["n_geom"] == 6, r)
    case("new solver: datum CSYS origin as centre", c_origin)


try:
    os.makedirs(OUT, exist_ok=True)
    for name, fn in (("sketch", g_sketch), ("datum", g_datum), ("solid_a", g_solid_a), ("solid_b", g_solid_b),
                     ("bodies", g_bodies), ("sync", g_sync), ("tree", g_tree), ("copies", g_copies), ("surface", g_surface),
                     ("step", g_step), ("newsolver", g_newsolver)):
        group(name, fn)
    if not ONLY:
        missing = sorted(set(PUBLIC) - CALLED)
        ct("coverage: every public nxf function was exercised (%d)" % len(PUBLIC), not missing, missing)
except Exception:  # noqa: BLE001
    res["errors"]["fatal"] = traceback.format_exc()
    chk.true("no fatal exception", False)
final = flush()
log("RESULT", final["result"], "checks", len(final["checks"]), "failed", [c["name"] for c in final["checks"] if not c["ok"]])
