"""nxh - small, verified NXOpen helper layer for headless NX journals (NX 2206, run_journal).

Import from a journal with:
    import sys; sys.path.insert(0, r"<dir of this file>"); import nxh

Everything here was exercised on NX 2206 batch. The helpers follow the house rules:
builders are create -> configure -> commit -> Destroy() in finally; positions and
vectors are floats; results are verified by measurement, never by "no exception".
"""
import json
import math
import os
import re
import time

import NXOpen
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.UF

S = NXOpen.Session.GetSession()
UFS = NXOpen.UF.UFSession.GetUFSession()
UPD = NXOpen.SmartObject.UpdateOption.WithinModeling
BOOL = NXOpen.GeometricUtilities.BooleanOperation.BooleanType
NULL_FEATURE = NXOpen.Features.Feature.Null
TEMPLATE = "model-plain-1-mm-template.prt"

# UF face type codes returned by face_data(). A plane that came out of a face-offset / divide
# operation can report EXTRUDED, and blend faces on drafted or freeform neighbours report BLEND:
# identify such faces by position (dist_to, normal_at), not by type alone.
CYLINDER, CONE, SPHERE, REVOLVED, EXTRUDED, PLANE, BLEND, BSURF, OFFSET = 16, 17, 18, 19, 20, 22, 23, 43, 65
TORUS = REVOLVED


# ---------------------------------------------------------------- basics
def P(x, y, z):
    return NXOpen.Point3d(float(x), float(y), float(z))


def V(x, y, z):
    return NXOpen.Vector3d(float(x), float(y), float(z))


def mark(name="step", visible=True):
    vis = NXOpen.Session.MarkVisibility.Visible if visible else NXOpen.Session.MarkVisibility.Invisible
    return S.SetUndoMark(vis, name)


def undo_to(m):
    S.UndoToMark(m, None)


def attempt(label, fn, *args, log=None, **kw):
    """Run fn; on any exception roll the model back to before the call and return (None, error text).

    fn must Destroy() its own builders in a finally block BEFORE this rollback happens (all nxh
    feature helpers do): undoing past a live builder destroys it and a later Destroy() raises
    "Object no longer exists"."""
    m = mark("try " + label, False)
    try:
        return fn(*args, **kw), None
    except Exception as e:  # noqa: BLE001
        try:
            undo_to(m)
        except Exception:  # noqa: BLE001
            pass
        if log:
            log(f"  ! {label}: {e}")
        return None, str(e)


class Log:
    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        open(path, "w", encoding="utf-8").close()

    def __call__(self, *parts):
        line = time.strftime("%H:%M:%S ") + " ".join(str(p) for p in parts)
        with open(self.path, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")


def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=1, default=str)


# ---------------------------------------------------------------- parts
def new_part(path, template=TEMPLATE, tol=0.01):
    """New mm part from an NX template; becomes the work + display part."""
    if os.path.exists(path):
        os.remove(path)
    b = S.Parts.FileNew()
    try:
        b.TemplateFileName = template
        b.Units = NXOpen.Part.Units.Millimeters
        b.NewFileName = path
        b.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
        b.Commit()
    finally:
        b.Destroy()
    part = S.Parts.Work
    try:
        part.Preferences.Modeling.DistanceToleranceData = tol
    except Exception:  # noqa: BLE001
        pass
    return part


LOAD_STATUS = []      # filled by open_part: [(part name, reason)] for everything NX could not load


def open_part(path, full=False):
    """Open a part as display part. Missing components / linked parts do not raise: they are
    listed in nxh.LOAD_STATUS - read it, a "part left unloaded" explains broken links later.
    full=True: open with partial loading OFF and Components To Load = All (both restored afterwards) -
    for a session that edits linked parts: components then follow their WAVE sources and interpart
    expressions with a plain update. With the batch default (partial loading on) they keep their saved
    shape whatever is edited, and "Load Interpart Data" loads no parent in NX 2206."""
    if full:
        lo = S.Parts.LoadOptions
        old = (lo.UsePartialLoading, lo.ComponentsToLoad)
        lo.UsePartialLoading = False
        lo.ComponentsToLoad = NXOpen.LoadOptions.LoadComponents.All
        try:
            return open_part(path)
        finally:
            lo.UsePartialLoading, lo.ComponentsToLoad = old
    part, st = S.Parts.OpenBaseDisplay(path)
    LOAD_STATUS.clear()
    try:
        for i in range(st.NumberUnloadedParts):
            LOAD_STATUS.append((st.GetPartName(i), st.GetStatusDescription(i)))
    except Exception:  # noqa: BLE001
        pass
    st.Dispose()
    return part


def save(part):
    part.Save(NXOpen.BasePart.SaveComponents.TrueValue, NXOpen.BasePart.CloseAfterSave.FalseValue).Dispose()


def close_all():
    S.Parts.CloseAll(NXOpen.BasePart.CloseModified.CloseModified, None)


def units(part):
    uc = part.UnitCollection
    return {"mm": uc.FindObject("MilliMeter"), "deg": uc.FindObject("Degrees"), None: None}


def expr(part, name, formula, unit="mm", comment=""):
    """Named expression. unit: 'mm', 'deg' or None (unitless)."""
    text = f"{name}={formula}" + (f" // {comment}" if comment else "")
    return part.Expressions.CreateWithUnits(text, units(part)[unit])


def set_expr(part, name, formula):
    part.Expressions.FindObject(name).RightHandSide = str(formula)


def update(visible_name="update"):
    """Regenerate; AcceptAll so a failing feature is reported instead of silently undone."""
    S.UpdateManager.SetDefaultUpdateFailureAction(NXOpen.Update.FailureOption.AcceptAll)
    return S.UpdateManager.DoUpdate(mark(visible_name))


def _scan_errors(part):
    out, flagged = {}, []
    for f in part.Features.GetFeatures():
        try:
            msgs = list(f.GetFeatureErrorMessages() or [])
        except Exception:  # noqa: BLE001
            msgs = []
        if msgs:
            out[f.GetFeatureName()] = msgs
            flagged.append(f)
    return out, flagged


def feature_errors(part, recheck=True):
    """{feature name: [messages]} for every feature that reports an error.

    NX leaves a STALE message behind after a failed CommitFeature that was rolled back: the text
    reappears on whichever feature is created next (even an unrelated one, even in another part),
    and neither ClearErrorList nor a plain update removes it. Measured cure: log the flagged
    feature for update and regenerate it - a stale message disappears, a real error stays. With
    recheck=True (default) this function does exactly that before reporting."""
    out, flagged = _scan_errors(part)
    if out and recheck:
        for f in flagged:
            try:
                S.UpdateManager.LogForUpdate(f)
            except Exception:  # noqa: BLE001
                pass
        update("recheck feature errors")
        out, _ = _scan_errors(part)
    return out


def feature_state(part):
    """{feature Tag: (name, type, suppressed, error messages)} - the state table for before/after
    comparisons on an existing part. Keyed by TAG, not by name: new features are inserted after the
    last ACTIVE feature, in front of a suppressed tail, and the tail is renumbered (Replace Face(59)
    becomes Replace Face(71)), so a by-name comparison reports every tail feature as changed."""
    out = {}
    for f in part.Features.GetFeatures():
        try:
            msgs = tuple(f.GetFeatureErrorMessages() or [])
        except Exception:  # noqa: BLE001
            msgs = ()
        out[f.Tag] = (f.GetFeatureName(), f.FeatureType, bool(f.Suppressed), msgs)
    return out


def state_diff(before, after):
    """Changes between two feature_state() tables: {"changed": [...], "gone": [...], "added": [...]}.
    A change of the NAME alone (renumbering) is not reported; suppression or messages are."""
    changed = [{"before": before[k], "after": after[k]} for k in before
               if k in after and before[k][2:] != after[k][2:]]
    return {"changed": changed, "gone": [before[k] for k in before if k not in after],
            "added": [after[k] for k in after if k not in before]}


def link_status(feature):
    """WAVE / linked feature status without opening its edit builder (which crashes on a link whose
    source part is missing): {"broken": bool, "source": tag or 0}. A broken link keeps its frozen
    geometry and survives regeneration.
    "broken" means: made non-associative, or its source object deleted. It does NOT see an ORPHAN -
    a link whose parent part was renamed or is missing (55 of 298 links in one measured set): no flag,
    no feature error, frozen geometry. For the five states (live, parent_unloaded, orphan,
    broken_accepted, broken_new) use nxw.link_health(part) of the nx-assemblies skill:
    sys.path.insert(0, os.environ["NXW_DIR"]); import nxw  (the launcher sets NXW_DIR)."""
    out = {}
    try:
        out["broken"] = bool(UFS.Wave.IsLinkBroken(feature.Tag))
    except Exception as e:  # noqa: BLE001
        out["broken"] = "? " + str(e)[:60]
    try:
        out["source"] = UFS.Wave.AskLinkSource(feature.Tag, False)
    except Exception:  # noqa: BLE001
        out["source"] = None
    return out


def feature_table(part):
    return [{"ts": f.Timestamp, "name": f.GetFeatureName(), "type": f.FeatureType, "cls": type(f).__name__,
             "suppressed": f.Suppressed} for f in part.Features.GetFeatures()]


def is_internal(feature):
    """True for a row NX keeps inside another feature: pattern / mirror instances and their output
    bodies, the SIMPLE HOLE / CBORE_HOLE / CSUNK_HOLE / SYMBOLIC_THREAD children of a Hole feature,
    linked-curve objects, the datum CSYS of a sketch. Such rows are not history steps a person made
    (55 % of all rows in 75 third-party parts): count and list features without them."""
    try:
        return bool(feature.IsInternal)
    except Exception:  # noqa: BLE001
        return False


def top_features(part):
    """(top-level features in tree order, number of internal rows) - the history a person sees."""
    allf = list(part.Features.GetFeatures())
    top = [f for f in allf if not is_internal(f)]
    return top, len(allf) - len(top)


# Feature types of commands that NX no longer offers (found in 1,375 parts saved by NX 5 ... NX 8.5 and
# opened in NX 2206): they open, update and can be suppressed, most keep their expressions with descriptors,
# but they have NO edit builder - a factory of another class handed such a feature returns a wrong builder
# or an access violation. Read them, leave them, and when their shape must change rebuild with the modern
# command. {type string: (what it is, what to use today)}
LEGACY_TYPES = {
    "BOSS": ("Boss: a cylinder (optionally tapered) united on a planar face, placed by positioning dimensions",
             "Extrude of a circle with the Boolean inside, or Hole's counterpart: a sketch point + Extrude; draft inside the Extrude"),
    "RECT_POCKET": ("rectangular Pocket with corner / floor radius and taper", "Extrude (Subtract) of a sketch rectangle + Edge Blend + Draft"),
    "CYL_POCKET": ("cylindrical Pocket", "Hole (General, flat bottom) or Extrude (Subtract) of a circle"),
    "RECT_PAD": ("rectangular Pad with corner radius and taper", "Extrude (Unite) of a sketch rectangle + Edge Blend + Draft"),
    "RECT_SLOT": ("rectangular Slot", "Extrude (Subtract) of an obround sketch"),
    "U_SLOT": ("U-shaped Slot", "Extrude (Subtract) of an obround sketch + Edge Blend at the floor"),
    "BALL_END_SLOT": ("ball-end Slot", "Tube / Sweep of a circle along the slot line, subtracted"),
    "RECT_GROOVE": ("rectangular Groove on a cylindrical face", "Groove (still offered) or Revolve (Subtract) of the groove profile"),
    "BALL_END_GROOVE": ("ball-end Groove", "Groove or Revolve (Subtract)"),
    "INSTANCE": ("one instance of an Instance Array (the pre-NX 8 feature pattern)", "Pattern Feature"),
    "INSTANCE_SET": ("the set object of an Instance Array", "Pattern Feature"),
    "LINEAR_ISET": ("rectangular Instance Array", "Pattern Feature, Linear"),
    "CIRCULAR_ISET": ("circular Instance Array", "Pattern Feature, Circular"),
    "TRANSFORM_ISET": ("the seed set of an Instance Array (the features that are copied)", "Pattern Feature"),
    "MIRROR_SET": ("Mirror Feature as NX 8.5 and older wrote it (this one still has its edit builder)", "Mirror Feature"),
    "TAPER": ("Taper (the old draft)", "Draft"),
    "TAPER_HOLE": ("tapered hole of the old Hole command", "Hole (General, Tapered)"),
    "HOLLOW": ("Hollow (the old shell)", "Shell"),
    "THREADS": ("detailed Thread of the old command", "Thread, or a threaded Hole"),
    "UDF": ("instance of a User Defined Feature", "Feature Group + Copy / Paste, a template part, or rebuild the features"),
    "UDF_DEF": ("definition of a User Defined Feature", "a template part"),
    "PART_MODULE_REFERENCES": ("Part Module: its reference group", "WAVE links between separate parts"),
    "PART_MODULE_WORK": ("Part Module: its work group", "WAVE links between separate parts"),
    "PART_MODULE_OUTPUT": ("Part Module: its output group", "WAVE links between separate parts"),
    "LINKED_PART_MODULE": ("linked Part Module", "WAVE links between separate parts"),
    "SIMPLIFY": ("Simplify Body", "Delete Face on an Extract Body copy"),
}
# Types a current command also writes: legacy only when the row is a plain BodyFeature / Feature (no builder class)
LEGACY_WHEN_UNTYPED = {
    "SWP104": ("pre-NX 5 Extruded / Revolved Body", "Extrude / Revolve (current ones are class Extrude / Revolve / Tube / SweepAlongGuide)"),
    "EXTRUDE": ("pre-NX 5 Extruded Body", "Extrude"),
    "CHAMFER": ("old Chamfer", "Chamfer"),
    "SIMPLE HOLE": ("hole of the pre-NX 6 Hole command (when it is a TOP-LEVEL row)", "Hole (HolePackage)"),
    "CBORE_HOLE": ("counterbored hole of the old Hole command (top-level row)", "Hole (HolePackage), Counterbored"),
    "CSUNK_HOLE": ("countersunk hole of the old Hole command (top-level row)", "Hole (HolePackage), Countersunk"),
    "SYMBOLIC_THREAD": ("Symbolic Thread on a cylinder (top-level row)", "Thread (Symbolic) still exists; on a hole use a threaded Hole"),
}


def legacy_note(feature):
    """None for a feature a current command makes, else (what it is, what to use today) - see LEGACY_TYPES.
    Legacy features open and update in NX 2206; do not imitate them and do not open an edit builder on them."""
    t = feature.FeatureType
    if t in LEGACY_TYPES:
        return LEGACY_TYPES[t]
    if t in LEGACY_WHEN_UNTYPED and type(feature).__name__ in ("BodyFeature", "Feature", "Hole") and not is_internal(feature):
        if t == "SYMBOLIC_THREAD":
            return None                                   # still a current command; only listed for the mapping
        return LEGACY_WHEN_UNTYPED[t]
    return None


# ---------------------------------------------------------------- editing in the middle of the tree
# Codes of UF_MODL_ask_suppress_feature as measured on NX 2206 (bit flags; several can be set):
#   0 active            1 suppressed by a person          2 suppressed by its suppress expression
#   4 inactive because the feature FAILED in the last update (a Shell that could not be rebuilt)
#   16 rolled back: the feature lies after the current feature (insert point)   17 = 1 + 16
#   64 suppressed because a PARENT is suppressed by expression
SUPPRESSED, SUPPRESSED_BY_EXPRESSION, FAILED, ROLLED_BACK, SUPPRESSED_BY_PARENT = 1, 2, 4, 16, 64


def suppress_status(feature):
    """Why a feature is inactive: {"code", "suppressed", "by_expression", "failed", "rolled_back", "by_parent"}.

    Feature.Suppressed is True for ALL of these, also for every feature after the insert point of a
    rolled-back tree - so `Suppressed` alone cannot tell an abandoned (user-suppressed) feature from
    one that is merely waiting behind the current feature. This reads the flags behind it."""
    c = int(UFS.Modeling.AskSuppressFeature(feature.Tag))
    return {"code": c, "suppressed": bool(c & SUPPRESSED), "by_expression": bool(c & SUPPRESSED_BY_EXPRESSION),
            "failed": bool(c & FAILED), "rolled_back": bool(c & ROLLED_BACK), "by_parent": bool(c & SUPPRESSED_BY_PARENT)}


def current_feature(part):
    """The feature the tree is rolled to (new features are created right after it). In a part that
    is not rolled back this is the LAST feature of the tree, also when that one is suppressed."""
    return part.CurrentFeature


def rolled_back(part):
    """Features that are inactive only because they lie after the current feature (insert point).
    Empty for a part in its normal state; non-empty means somebody left the part rolled back."""
    return [f for f in part.Features.GetFeatures() if suppress_status(f)["rolled_back"]]


def history_mode(part):
    """True = history mode (the normal feature tree), False = history-free mode (a 2012-era mode some
    old parts are SAVED in: features are not recorded as a history). Check before editing a foreign part."""
    return bool(part.Preferences.Modeling.GetHistoryMode())


class insert_after:
    """Insert point: make `feature` current, create features there, roll forward again - with the checks.

        with nxh.insert_after(part, block_feature) as ip:        # everything after it is rolled back
            body = nxh.solids(part)[0]                           # RE-QUERY: the body is in its early state
            nxh.blend(part, vertical_edges(body), 8)             # lands right after block_feature
        ip.report   # {"added": [...], "changed": [...], "gone": [...], "errors": {...}, "resuppressed": [...]}

    On leaving the block the tree is rolled forward to the feature that was current before (the last
    one), with the update failure action AcceptAll, then:
      * features a person had suppressed (code 1) are suppressed again if the roll forward woke them
        (not seen on own test parts - rolling keeps them suppressed - but seen once on a user part);
      * `report` = nxh.state_diff of the tree by TAG plus nxh.feature_errors: `added` must be exactly
        the new features; `changed` lists later features that broke (a Shell that fails on the new
        blend shows up here with its message, and the body is then the UNSHELLED solid);
      * check=True (default): when anything changed, disappeared or carries an error the whole
        insertion is undone and RuntimeError is raised with the report. check=False keeps the result
        for inspection (undo with nxh.undo_to(ip.mark)).
    An exception inside the block also undoes everything. Later features are RENUMBERED (Shell(3)
    becomes Shell(4)) and their timestamps shift by the number of inserted features: keep feature
    objects or tags, never names. Verify the geometry afterwards as for any feature (volume,
    wall thickness, face census): "no error" is not proof."""

    def __init__(self, part, feature, check=True):
        self.part, self.feature, self.check = part, feature, check
        self.report, self.mark = None, None

    def __enter__(self):
        p = self.part
        self.before = feature_state(p)
        self.codes = {f.Tag: suppress_status(f)["code"] for f in p.Features.GetFeatures()}
        self.end = p.CurrentFeature
        self.mark = mark("insert after " + self.feature.GetFeatureName())
        S.UpdateManager.SetDefaultUpdateFailureAction(NXOpen.Update.FailureOption.AcceptAll)
        self.feature.MakeCurrentFeature()
        return self

    def __exit__(self, etype, evalue, tb):
        p = self.part
        if etype is not None:
            try:
                undo_to(self.mark)
            except Exception:  # noqa: BLE001
                pass
            return False
        S.UpdateManager.SetDefaultUpdateFailureAction(NXOpen.Update.FailureOption.AcceptAll)
        try:
            self.end.MakeCurrentFeature()
            update("roll forward")
        except Exception as e:  # noqa: BLE001
            undo_to(self.mark)
            raise RuntimeError("insert_after: roll forward failed and was undone (%s)" % str(e)[:200])
        woke = [f for f in p.Features.GetFeatures()
                if (self.codes.get(f.Tag, 0) & SUPPRESSED) and not (suppress_status(f)["code"] & SUPPRESSED)]
        if woke:
            p.Features.SuppressFeatures(woke)
            update("re-suppress")
        errors = feature_errors(p)
        diff = state_diff(self.before, feature_state(p))
        self.report = {"added": [a[0] for a in diff["added"]], "changed": diff["changed"], "gone": [g[0] for g in diff["gone"]],
                       "errors": errors, "resuppressed": [f.GetFeatureName() for f in woke]}
        if self.check and (errors or diff["changed"] or diff["gone"]):
            undo_to(self.mark)
            raise RuntimeError("insert_after: the insertion broke the tree and was undone: %s" % str(self.report)[:600])
        return False


def reorder(part, features, target, after=True):
    """Reorder Feature: move `features` (one or a list, kept in their order) directly after / before
    `target`. NX refuses a move that would put a feature before something it references ("Cannot
    reorder. Feature to be reordered is being referenced." - nothing changes). Regenerates and returns
    nxh.feature_errors(part); names and timestamps of everything in between are renumbered, tags stay
    (nxh.state_diff stays clean). The result is a different MODEL (a Shell moved before a pad no longer
    hollows the pad): measure it."""
    feats = [features] if isinstance(features, NXOpen.Features.Feature) else list(features)
    rt = NXOpen.Features.FeatureCollection.ReorderType
    part.Features.ReorderFeature(feats, target, rt.After if after else rt.Before)
    update("reorder")
    return feature_errors(part)


# Expression names NX writes itself (nobody typed them): p12, p12_x / _y / _z (point coordinates),
# p8_CircularPattern_pattern_Circular_Dir_count and other p<n>_<suffix> names, Pattern_p12...,
# ASSO_BLEND_3, Sheet_Metal_Bend_Radius ..., SM_Validation_... . Derived from 10 402 expressions of
# 241 third-party parts and re-checked on the user's 639 parts (loose test: 117 parts "with named
# expressions"; this test: 47).
SYSTEM_EXPR_NAME = re.compile(r"^(p\d+(_\w+)?|Pattern_.*|ASSO_BLEND_\d+|Sheet_Metal_\w+|SM_Validation_\w+)$")


def user_named(name):
    """True when an expression name was typed by a person (not one of NX's own name patterns)."""
    return not SYSTEM_EXPR_NAME.match(name)


def user_expressions(part):
    """Expressions whose names a person typed. Count expressions BEFORE opening any builder on the
    part: a builder can leave a system expression behind after Destroy() (ResizeBlendBuilder did,
    one per call; MeasureManager measurements, Examine Geometry and the UF queries add none)."""
    return [e for e in part.Expressions if user_named(e.Name)]


# ---------------------------------------------------------------- smart objects
def point(part, x, y, z):
    """Associative point; each coordinate may be a number or an expression formula string."""
    mm = units(part)["mm"]
    sc = []
    for f in (x, y, z):
        e = part.Expressions.CreateSystemExpressionWithUnits(str(f), mm)
        sc.append(part.Scalars.CreateScalarExpression(e, NXOpen.Scalar.DimensionalityType.NotSet, UPD))
    return part.Points.CreatePoint(sc[0], sc[1], sc[2], UPD)


def direction(part, vec, origin=(0, 0, 0)):
    return part.Directions.CreateDirection(P(*origin), V(*vec), UPD)


def axis(part, origin, vec):
    return part.Axes.CreateAxis(point(part, *origin), direction(part, vec), UPD)


def datum_plane(part, origin, normal, name=None):
    """Fixed-position associative datum plane feature; returns (feature, DatumPlane object)."""
    p0 = point(part, *origin)
    d = direction(part, normal)
    b = part.Features.CreateDatumPlaneBuilder(NULL_FEATURE)
    try:
        pl = b.GetPlane()
        pl.SetMethod(NXOpen.PlaneTypes.MethodType.PointDir)
        pl.SetGeometry([p0, d])
        pl.Evaluate()
        f = b.CommitFeature()
    finally:
        b.Destroy()
    if name:
        f.SetName(name)
    return f, f.DatumPlane


class Datums:
    """Principal planes/axes of the template's Datum Coordinate System."""

    def __init__(self, part):
        self.csys = [f for f in part.Features.GetFeatures() if f.FeatureType == "DATUM_CSYS"][0]
        pre = self.csys.JournalIdentifier
        f = part.Datums.FindObject
        self.xy, self.yz, self.xz = f(f"{pre} XY plane"), f(f"{pre} YZ plane"), f(f"{pre} XZ plane")
        self.x, self.y, self.z = f(f"{pre} X axis"), f(f"{pre} Y axis"), f(f"{pre} Z axis")
        self.origin = self.csys.FindObject("POINT 1")


# ---------------------------------------------------------------- curves and selection
def line(part, a, b):
    return part.Curves.CreateLine(P(*a), P(*b))


def polyline(part, pts, closed=True):
    n = len(pts)
    last = n if closed else n - 1
    return [line(part, pts[i], pts[(i + 1) % n]) for i in range(last)]


def rect(part, x0, y0, x1, y1, z=0.0):
    return polyline(part, [(x0, y0, z), (x1, y0, z), (x1, y1, z), (x0, y1, z)])


def arc(part, centre, xdir, ydir, r, a0, a1):
    """Arc in the plane spanned by xdir/ydir; angles in radians from xdir towards ydir."""
    return part.Curves.CreateArc(P(*centre), V(*xdir), V(*ydir), float(r), float(a0), float(a1))


def circle(part, centre, r, xdir=(1, 0, 0), ydir=(0, 1, 0)):
    """Full circle as two 180 degree DUMB arcs: a dumb 0..2pi `Curves.CreateArc` was unreliable in
    sections. (A sketch circle and an associative full-circle Arc feature are single arcs and work.)"""
    return [arc(part, centre, xdir, ydir, r, 0.0, math.pi), arc(part, centre, xdir, ydir, r, math.pi, 2 * math.pi)]


def fill_section(part, sec, curves=None, edges=None, help_point=(0, 0, 0), seed=None, rules=None):
    """Add rules to a Section. Use this directly for builder-OWNED sections (read-only properties
    such as BoundedPlaneBuilder.BoundingCurves, RibBuilder.Section, SweepAlongGuideBuilder.Section):
    they must be filled in place, never replaced.

    help_point decides where a section string STARTS (the end of the seed curve nearest to it):
    mismatched starts between loft sections give a valid but twisted surface.

    EDGE ORDER: body.GetEdges() / face.GetEdges() have no fixed order between NX sessions (the same
    trap nxh.one() documents for faces). The default seed is the FIRST edge / curve of the list, so with
    edges=list(body.GetEdges()) the profile direction can flip from run to run (measured: the same journal
    gave the opposite profile direction, and a Law Extension leaning to the other side, in two runs).
    Where direction matters, pick the edges by geometry, put the start edge first or pass seed=, and give
    the help point at its start end.
    """
    rules = list(rules or [])
    if curves:
        rules.append(part.ScRuleFactory.CreateRuleCurveDumb(list(curves)))
    if edges:
        rules.append(part.ScRuleFactory.CreateRuleEdgeDumb(list(edges)))
    if seed is None:
        seed = (list(curves)[0] if curves else list(edges)[0]) if (curves or edges) else NXOpen.NXObject.Null
    sec.AddToSection(rules, seed, NXOpen.NXObject.Null, NXOpen.NXObject.Null, P(*help_point),
                     NXOpen.Section.Mode.Create, False)
    return sec


def section(part, curves=None, edges=None, help_point=(0, 0, 0), seed=None, rules=None):
    """New Section from dumb curves and/or body edges and/or ready-made selection-intent rules.

    When only `rules` are given, pass `seed=` (the curve the string should start on) for lofts and
    sweeps: without a seed the help point is IGNORED and the start is NX's choice (measured: the
    same corner for three different help points), so the surface may twist. With a seed the string
    starts at the seed end nearest the help point.
    Edges taken from GetEdges() come in a different order in different sessions: see fill_section
    (EDGE ORDER) - select by geometry and pass seed= when the direction of the section matters."""
    sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
    sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
    sec.AllowSelfIntersection(False)
    return fill_section(part, sec, curves, edges, help_point, seed, rules)


def section_region(part, sketch, seed_point, curves=None):
    """ONE closed region of a sketch: the area around seed_point (the user's own habit: 58 % of extrudes)."""
    curves = curves if curves is not None else [g for g in sketch.GetAllGeometry() if isinstance(g, NXOpen.Curve)]
    rule = part.ScRuleFactory.CreateRuleRegionBoundary(sketch, curves, P(*seed_point), 0.01)
    return section(part, help_point=seed_point, rules=[rule])


def section_feature(part, features, help_point=(0, 0, 0), curves_only=False):
    """All curves of sketch / curve features; stays associative when the sketch gains or loses curves.

    "All" means every ACTIVE object of the sketch, POINTS included (section() allows CurvesAndPoints): a
    sketch that holds an active Point besides its closed profile - a centre point, hole positions - gives
    "Cannot extrude. The section and direction may be incompatible." (measured with nxh.extrude and
    nxf.extrude_ex, on the XY datum plane and on a chamfer face, both sketch solvers). Any one of these
    cures it, each gave the full volume:
      * curves_only=True - the section then accepts curves only and the rule skips the points;
      * make the point a reference point while the sketch is active: nxf.to_reference(part, [point])
        (nxf.sketch_anchor points already are);
      * select the profile instead of the sketch: section_region(part, sk, seed, curves=lines) or
        section(part, curves=lines).
    An active curve that is not part of the profile (a centre line) is taken in as well, with either
    setting: see nxf.to_reference."""
    rule = part.ScRuleFactory.CreateRuleCurveFeature(list(features))
    if not curves_only:
        return section(part, help_point=help_point, rules=[rule])
    sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
    sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    sec.AllowSelfIntersection(False)
    return fill_section(part, sec, help_point=help_point, rules=[rule])


def collector(part, faces=None, edges=None, bodies=None, datum_planes=None):
    """ScCollector with dumb rules (explicit object lists)."""
    sc = part.ScCollectors.CreateCollector()
    rules = []
    if faces:
        rules.append(part.ScRuleFactory.CreateRuleFaceDumb(list(faces)))
    if edges:
        rules.append(part.ScRuleFactory.CreateRuleEdgeDumb(list(edges)))
    if bodies:
        try:
            rules.append(part.ScRuleFactory.CreateRuleBodyDumb(list(bodies), True))
        except Exception:  # noqa: BLE001
            rules.append(part.ScRuleFactory.CreateRuleBodyDumb(list(bodies)))
    if datum_planes:
        rules.append(part.ScRuleFactory.CreateRuleFaceDatum(list(datum_planes)))
    sc.ReplaceRules(rules, False)
    return sc


# ---------------------------------------------------------------- measurement
def bbox(obj):
    """[xmin, ymin, zmin, xmax, ymax, zmax] of a body, face or edge.

    Exact for analytic geometry built in NX. PADDED (0.003 - 0.2 mm, more on toroidal bodies) on
    B-surfaces, tolerant/sewn edges, freshly imported bodies and faces bounded by offset curves:
    use a tolerance of ~0.01 for picking there, and prove positions with dist_to() / normal_at()."""
    return [round(v, 4) for v in UFS.ModlGeneral.AskBoundingBox(obj.Tag)]


def face_data(face):
    """(type, point, dir, radius). Plane: dir = outward normal. Cylinder: point on axis, dir = axis."""
    t, pt, d, _box, rad, _rd, _nd = UFS.Modeling.AskFaceData(face.Tag)
    return t, list(pt), list(d), rad


def face_info(part, face, blend_builder=None):
    """One face as a dict: UF type, point, dir, radius, norm_dir (-1 = concave, e.g. a hole wall;
    +1 = convex, e.g. a boss or pin), area, and - when a ResizeBlendBuilder is passed - whether NX
    recognises it as a blend and with which radius."""
    t, pt, d, _box, rad, _rd, nd = UFS.Modeling.AskFaceData(face.Tag)
    row = {"face": face, "type": t, "pt": list(pt), "dir": list(d), "radius": abs(rad), "norm_dir": nd,
           "area": sheet_area(part, [face])[0], "is_blend": False}
    if blend_builder is not None:
        try:
            isb = blend_builder.IsBlendFace([face])
            row["is_blend"] = bool(isb[0]) if isinstance(isb, (list, tuple)) else bool(isb)
            if row["is_blend"]:
                row["blend_radius"] = blend_builder.GetBlendFaceRadius(face)
        except Exception:  # noqa: BLE001
            pass
    return row


def _axial_range(face, origin, d, n=32):
    """(min, max) position along the axis (origin, unit d) of the face's edge points."""
    lo, hi = float("inf"), float("-inf")
    for e in face.GetEdges():
        for i in range(n + 1):
            p = UFS.ModlGeneral.AskCurveProps(e.Tag, i / float(n))[0]
            s = sum((p[k] - origin[k]) * d[k] for k in range(3))
            lo, hi = min(lo, s), max(hi, s)
    return lo, hi


def _angular_span(face, axial_length):
    """Angle (rad) a cylindrical face wraps about its axis, from its UV box: of the two parameter
    ranges the one that is NOT the axial length is the angle. The axial range comes back in metres
    on NX 2206 (27.713 mm reads 0.0277), so both scalings are compared."""
    u0, u1, v0, v1 = UFS.Modeling.AskFaceUvMinmax(face.Tag)
    du, dv = abs(u1 - u0), abs(v1 - v0)

    def off(x):
        return min(abs(x - axial_length), abs(x - axial_length / 1000.0))
    ang = dv if off(du) < off(dv) else du
    return math.radians(ang) if ang > 2.0 * math.pi + 1e-6 else ang


def hole_census(part, body, min_coverage=0.95):
    """Census of a body's cylindrical holes and blends.

    Returns {"holes": [{"diameter", "axis", "point", "length", "faces"}...], "blends": {radius: count},
             "bosses": [...]}. A hole = concave cylinder faces (norm_dir -1) that NX does not
    recognise as blends, grouped by axis and radius (a split hole wall is one hole). On imported
    bodies most cylinders are blends - never select "all cylinders of radius r" without this filter.
    Through or blind is NOT decided here: look at the faces at the two ends of the hole.

    min_coverage: a real hole or boss wraps (nearly) the full circle. Concave fillets that NX does
    not recognise as blends and large concave inner walls of a shelled body are partial cylinders;
    entries whose face area is below min_coverage x (2 pi r L) are reported under "partial"
    instead of "holes" / "bosses" (pass 0 to keep everything).

    The blend test needs a ResizeBlendBuilder, and that builder leaves its radius expression
    (`p<n>=5`) in the part even after Destroy(): one stray expression per call (measured). It is
    deleted again here, so the call leaves the expression list as it found it.

    Axis inclined to X, Y, Z (an inclined port): the bounding box no longer gives the length, so
    the length is the extent of the face's edge points projected on the axis, and the coverage is
    the angular span of the face(s) about the axis / 360 deg (an obliquely cut through hole wraps
    the full circle although its area is well below pi d L)."""
    expr_before = {e.Tag for e in part.Expressions}
    rb = part.Features.CreateResizeBlendBuilder(NULL_FEATURE)
    holes, bosses, blends = {}, {}, {}
    try:
        for f in body.GetFaces():
            r = face_info(part, f, rb)
            if r["is_blend"]:
                k = round(r.get("blend_radius", r["radius"]), 3)
                blends[k] = blends.get(k, 0) + 1
                continue
            if r["type"] != CYLINDER:
                continue
            d = r["dir"]
            sgn = -1.0 if (d[0], d[1], d[2]) < (0.0, 0.0, 0.0) else 1.0
            d = [sgn * v for v in d]
            k = sum(p * q for p, q in zip(r["pt"], d))
            foot = [p - k * q for p, q in zip(r["pt"], d)]            # axis point nearest the origin
            key = (round(r["radius"], 3),) + tuple(round(v, 3) for v in d) + tuple(round(v, 2) for v in foot)
            tgt = holes if r["norm_dir"] < 0 else bosses
            e = tgt.setdefault(key, {"diameter": 2 * r["radius"], "axis": d, "point": foot, "length": 0.0,
                                     "faces": [], "area": 0.0, "concave": r["norm_dir"] < 0})
            if max(abs(v) for v in d) > 1.0 - 1e-9:                   # principal axis: the box is exact
                bb = bbox(f)
                ext = sum(abs(d[i]) * (bb[i + 3] - bb[i]) for i in range(3))
                e["length"] = max(e["length"], ext)
            else:                                                     # inclined axis
                lo, hi = _axial_range(f, foot, d)
                e["lo"], e["hi"] = min(e.get("lo", lo), lo), max(e.get("hi", hi), hi)
                e["length"] = e["hi"] - e["lo"]
                e["angle"] = e.get("angle", 0.0) + _angular_span(f, hi - lo)
            e["faces"].append(f)
            e["area"] += r["area"]
    finally:
        rb.Destroy()
        for e in [x for x in part.Expressions if x.Tag not in expr_before]:
            try:
                part.Expressions.Delete(e)
            except Exception:  # noqa: BLE001
                pass
    partial = []
    for group in (holes, bosses):
        for k in list(group):
            e = group[k]
            full = math.pi * e["diameter"] * e["length"]
            if "angle" in e:
                e["coverage"] = min(1.0, e["angle"] / (2.0 * math.pi))
            else:
                e["coverage"] = e["area"] / full if full > 1e-9 else 0.0
            if e["coverage"] < min_coverage:
                partial.append(group.pop(k))
    return {"holes": sorted(holes.values(), key=lambda h: h["diameter"]),
            "bosses": sorted(bosses.values(), key=lambda h: h["diameter"]),
            "partial": sorted(partial, key=lambda h: h["diameter"]), "blends": blends}


def solids(part):
    return [b for b in part.Bodies if b.IsSolidBody]


def sheets(part):
    return [b for b in part.Bodies if not b.IsSolidBody]


def sheet_area(part, body_or_faces):
    """(area, perimeter) of a body's faces or of a face list - the ONLY correct area for sheet bodies."""
    fs = list(body_or_faces.GetFaces()) if hasattr(body_or_faces, "GetFaces") else list(body_or_faces)
    uc = part.UnitCollection
    mf = part.MeasureManager.NewFaceProperties(uc.FindObject("SquareMilliMeter"), uc.FindObject("MilliMeter"), 0.999999, fs)
    try:
        return mf.Area, mf.Perimeter
    finally:
        mf.Dispose()


def mass(part, bodies):
    """Volume / area / centroid of SOLID bodies at accuracy 0.999999 (the default 0.99 is only good to 1e-4).

    NewMassProperties returns garbage for sheet bodies (perimeter and area x1000), so sheets are
    measured with sheet_area() and reported with volume 0.
    """
    bodies = list(bodies)
    if bodies and not any(b.IsSolidBody for b in bodies):
        return {"volume": 0.0, "area": sum(sheet_area(part, b)[0] for b in bodies), "centroid": None}
    bodies = [b for b in bodies if b.IsSolidBody]
    uc = part.UnitCollection
    un = [uc.FindObject(u) for u in ("SquareMilliMeter", "CubicMilliMeter", "Kilogram", "MilliMeter", "Newton")]
    mb = part.MeasureManager.NewMassProperties(un, 0.999999, bodies)
    try:
        c = mb.Centroid
        return {"volume": mb.Volume, "area": mb.Area, "centroid": [round(c.X, 4), round(c.Y, 4), round(c.Z, 4)]}
    finally:
        mb.Dispose()


def free_edges(body):
    """Open-boundary edges (used by one face): 0 on a solid or a closed quilt."""
    return [e for e in body.GetEdges() if len(e.GetFaces()) == 1]


def min_dist(a, b):
    """Minimum distance between two objects (bodies, faces, edges, curves, points).

    Point against a SOLID is signed: a point 0.5 mm inside the material returns -0.5 (useful as an
    inside/outside probe). Two bodies that touch and two that overlap both return 0.0, so this is
    not an interference test."""
    return UFS.Modeling.AskMinimumDist(a.Tag, b.Tag, 0, [0.0, 0.0, 0.0], 0, [0.0, 0.0, 0.0])[0]


def dist_to(part, obj, xyz):
    """Distance from a coordinate to a FACE (or sheet body): 0 means the surface passes through
    the point. Pass a face, not a solid body: for a point inside a solid the body-level result is
    not a surface distance (a probe 6 mm inside returned -6), so it cannot prove where a wall is.
    To find the face at a designed point: [f for f in body.GetFaces() if dist_to(part, f, xyz) < 1e-6]."""
    pt = part.Points.CreatePoint(P(*xyz))
    try:
        return min_dist(pt, obj)
    finally:
        S.UpdateManager.AddToDeleteList(pt)


def normal_at(face, xyz):
    """Unit face normal at the point of the face nearest to xyz (works on B-surfaces)."""
    parm, _pnt = UFS.Modeling.AskFaceParm(face.Tag, [float(v) for v in xyz])
    return list(UFS.Modeling.AskFaceProps(face.Tag, parm)[5])


def face_mid_normal(face, eps=1e-3):
    """(point, outward unit normal) at the middle of a face - for "all faces that look along +Z" on
    curved, drafted or freeform faces, where face_data() gives an axis and not a normal.

    The point is the middle of the face's UV box; when that lies in a hole of the face or outside
    its trimmed outline (an L-shaped or ring face) the UV box is scanned for a point that is on the
    face. The normal is made OUTWARD by a containment probe (a point eps along it must not be
    inside the solid), so it does not depend on the sense NX stores for the surface. For a sheet
    body the stored normal is returned as it is."""
    u0, u1, v0, v1 = UFS.Modeling.AskFaceUvMinmax(face.Tag)
    grid = [(0.5, 0.5)] + [(a / 8.0, b / 8.0) for a in (1, 3, 5, 7) for b in (1, 3, 5, 7)] + \
           [(a / 16.0, b / 16.0) for a in range(1, 16, 2) for b in range(1, 16, 2)]
    pt = nrm = None
    for a, b in grid:
        pr = UFS.Modeling.AskFaceProps(face.Tag, [u0 + a * (u1 - u0), v0 + b * (v1 - v0)])
        pt, nrm = list(pr[0]), list(pr[5])
        if UFS.Modeling.AskPointContainment(pt, face.Tag) == 1:
            break
    body = face.GetBody()
    if body.IsSolidBody:
        q = [pt[i] + eps * nrm[i] for i in range(3)]
        if UFS.Modeling.AskPointContainment(q, body.Tag) == 1:          # the stored normal points into the material
            nrm = [-x for x in nrm]
    return pt, nrm


def edge_points(edge, n=13, ends=True):
    """n points along an edge or curve, evenly spaced in its parameter. ends=True includes both end
    points (extent and radius sampling); ends=False leaves them out (a corner vertex belongs to three
    faces: use it when the points must identify ONE face or lie strictly inside the edge)."""
    props = UFS.ModlGeneral.AskCurveProps
    if ends:
        return [list(props(edge.Tag, i / (n - 1.0))[0]) for i in range(n)]
    return [list(props(edge.Tag, (i + 1.0) / (n + 1.0))[0]) for i in range(n)]


# curve measurement - from nx-curves-and-sketches/scripts/curvekit.py (frame, curve_quality, join_angle,
# planarity, max_dev), re-run in nxh_selftest
def _unit(a):
    n = math.sqrt(sum(x * x for x in a))
    return [x / n for x in a] if n > 0 else [0.0, 0.0, 0.0]


def curve_frame(curve, t):
    """Frenet data of a curve or edge at the normalised parameter t (0 = start, 1 = end):
    {"t", "point", "tangent", "normal", "binormal", "torsion", "radius", "k"}. k is the curvature in 1/mm,
    0 on a straight piece (AskCurveProps answers radius 3.937e8 for a line, so every radius above 1e8 mm
    counts as straight). The binormal turns over where the curve changes the side it bends to."""
    r = UFS.ModlGeneral.AskCurveProps(curve.Tag, float(t))
    rad = abs(float(r[5]))
    k = 0.0 if rad < 1e-9 or rad > 1e8 else 1.0 / rad
    return {"t": float(t), "point": list(r[0]), "tangent": _unit(list(r[1])), "normal": list(r[2]), "binormal": list(r[3]),
            "torsion": float(r[4]), "radius": rad, "k": k}


def curve_quality(curve, n=200, k_min=1e-7):
    """The curvature comb of a curve as numbers (n + 1 samples in the parameter) - check guide and section
    splines with it BEFORE a loft or sweep.

    inflections : places where the curve changes the side it bends to. A fair guide or section has exactly
                  the inflections the design calls for - usually 0, an S-curve 1.
    peaks       : interior local maxima of the curvature (each one is a visible "knuckle").
    k_max, r_min: largest curvature and the radius there (r_min must exceed an offset / wall / tube radius);
                  t_k_max where.
    k_end       : curvature at the two ends (compare with the neighbour for G2).
    torsion_max : 0 for a planar curve. Also "inflection_t", "peak_t", "length"."""
    rows = [curve_frame(curve, i / float(n)) for i in range(n + 1)]
    ks = [r["k"] for r in rows]
    k_max = max(ks)
    infl, last, where = 0, None, []
    for r in rows:
        if r["k"] < k_min:
            continue
        if last is not None and sum(a * b for a, b in zip(last["binormal"], r["binormal"])) < 0:
            infl += 1
            where.append(round((last["t"] + r["t"]) / 2, 4))
        last = r
    eps = 1e-6 * k_max if k_max > 0 else 0.0
    peaks = [rows[i]["t"] for i in range(1, n) if ks[i] > k_min and ks[i] > ks[i - 1] + eps and ks[i] > ks[i + 1] + eps]
    return {"inflections": infl, "inflection_t": where, "peaks": len(peaks), "peak_t": [round(t, 4) for t in peaks],
            "k_max": k_max, "r_min": (1.0 / k_max if k_max > 0 else None), "t_k_max": rows[ks.index(k_max)]["t"],
            "k_end": [ks[0], ks[-1]], "torsion_max": max(abs(r["torsion"]) for r in rows), "length": curve.GetLength()}


def join_angle(c1, t1, c2, t2):
    """Angle in degrees between the tangents of two curves / edges at the given parameters (0 or 1 = an
    end), folded to 0..90: 0 = tangent continuous, whichever way the two curves run."""
    a = angle_deg(curve_frame(c1, t1)["tangent"], curve_frame(c2, t2)["tangent"])
    return min(a, 180.0 - a)


def planarity(curves, n=20):
    """Largest distance of sampled points of the curves from the plane through three of them (0 = planar)."""
    pts = [curve_frame(c, i / float(n))["point"] for c in curves for i in range(n + 1)]
    p0, nrm = pts[0], None
    for i in range(1, len(pts)):
        a = [x - y for x, y in zip(pts[i], p0)]
        for j in range(i + 1, len(pts)):
            b = [x - y for x, y in zip(pts[j], p0)]
            c = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
            ln = math.sqrt(sum(x * x for x in c))
            if ln > 1e-6 * max(1.0, math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(x * x for x in b))):
                nrm = [x / ln for x in c]
                break
        if nrm:
            break
    if nrm is None:
        return 0.0
    return max(abs(sum((p[k] - p0[k]) * nrm[k] for k in range(3))) for p in pts)


def max_dev(part, curve, pts):
    """Largest distance of the coordinates pts from the curve (0 = the curve passes through all of them)."""
    return max(dist_to(part, curve, p) for p in pts)


def pole_count(part, face):
    """Number of poles of a B-surface face - the measure of how heavy a freeform face is (compare before
    and after a rebuild / refit, or between two ways of building the same surface). Read through a Point
    Set feature (Face Points, B-Surface Poles) that is undone again: the part is left as it was."""
    psb = NXOpen.Features.PointSetBuilder
    m = mark("pole count", False)
    b = part.Features.CreatePointSetBuilder(NXOpen.Features.PointSet.Null)
    try:
        b.Type = psb.Types.FacePoints
        b.FacePointsBy = psb.FacePointsType.BSurfacePoles
        b.MultipleFaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb([face])], False)
        f = b.CommitFeature()
        n = len([e for e in f.GetEntities() if isinstance(e, NXOpen.Point)])
    finally:
        b.Destroy()
    undo_to(m)
    return n


def face_samples(face, n=3, eps=1e-3):
    """[(point, outward unit normal)] at the cells of an n x n grid over the face's UV box; grid points
    that fall off the trimmed face (holes, L shapes) are dropped. For a sheet body the stored normal."""
    u0, u1, v0, v1 = UFS.Modeling.AskFaceUvMinmax(face.Tag)
    body = face.GetBody()
    out = []
    for i in range(n):
        for j in range(n):
            pr = UFS.Modeling.AskFaceProps(face.Tag, [u0 + (i + 0.5) / n * (u1 - u0), v0 + (j + 0.5) / n * (v1 - v0)])
            pt, nrm = list(pr[0]), list(pr[5])
            if UFS.Modeling.AskPointContainment(pt, face.Tag) != 1:
                continue
            if body.IsSolidBody and UFS.Modeling.AskPointContainment([pt[k] + eps * nrm[k] for k in range(3)], body.Tag) == 1:
                nrm = [-x for x in nrm]
            out.append((pt, nrm))
    return out


def _wall_scan(faces, wall, tol, max_wall, samples):
    faces = [faces] if isinstance(faces, NXOpen.Face) else list(faces)
    found, thick = {}, {}
    for f in faces:
        body = f.GetBody()
        others = [g for g in body.GetFaces() if g.Tag != f.Tag]
        for pt, n in face_samples(f, samples):
            hits = []
            for g in others:
                try:
                    parm, q = UFS.Modeling.AskFaceParm(g.Tag, pt)           # foot point on g's surface
                except Exception:  # noqa: BLE001
                    continue
                q = list(q)
                dv = [q[k] - pt[k] for k in range(3)]
                d = math.sqrt(sum(x * x for x in dv))
                if d < 1e-6 or (max_wall is not None and d > max_wall) or (wall is not None and abs(d - wall) > tol):
                    continue
                if sum(dv[k] * n[k] for k in range(3)) / d > -0.996:         # not straight behind the point (5 deg)
                    continue
                if UFS.Modeling.AskPointContainment(q, g.Tag) not in (1, 3):  # foot point is off the trimmed face
                    continue
                ng = list(UFS.Modeling.AskFaceProps(g.Tag, parm)[5])
                if abs(sum(ng[k] * n[k] for k in range(3))) < 0.996:         # the two surfaces are not parallel there
                    continue
                if UFS.Modeling.AskPointContainment([(pt[k] + q[k]) / 2.0 for k in range(3)], body.Tag) != 1:
                    continue                                                 # no material in between (a cavity)
                hits.append((d, g))
            if hits:
                dmin = min(h[0] for h in hits)
                thick[f.Tag] = min(thick.get(f.Tag, dmin), dmin)
                for d, g in hits:
                    if d <= dmin + tol:
                        found[g.Tag] = g
    own = {f.Tag for f in faces}
    return [g for t, g in found.items() if t not in own], thick


def wall_partners(faces, wall=None, tol=0.01, max_wall=None, samples=3):
    """Faces on the OTHER side of a thin wall from `faces` (one face or a list): the inner partner of an
    outer wall of a shelled / thin-walled body, the floor above a bottom face, the inner corner blend
    behind an outer one. Put them in the move set of a synchronous edit, otherwise the wall changes
    thickness: `nxf.move_face(part, faces + nxh.wall_partners(faces), vec=..., distance=...)`.

    A partner is found from sample points on each face (grid `samples` x `samples`): the nearest face
    straight behind the point through MATERIAL whose surface is parallel there (offset face, opposite
    outward normal). wall=<thickness> keeps only partners at that distance (+- tol); max_wall drops
    anything farther away (use it on real parts so that a rib or a far wall is not taken for a partner).
    Works on planar, cylindrical and drafted walls and on blends; a face with no material-backed
    parallel face behind it (the rim of an open box) returns nothing. Faces already in `faces` are not
    returned. Measured: every face of a shelled, corner-blended box gets exactly its partner at 2.000."""
    return _wall_scan(faces, wall, tol, max_wall, samples)[0]


def wall_thickness(face, max_wall=None, samples=3):
    """Smallest wall thickness measured behind the sample points of a face (see wall_partners), or None
    when no parallel face lies behind it through material. Read it before and after a face edit."""
    return _wall_scan(face, None, 0.01, max_wall, samples)[1].get(face.Tag)


def examine_geometry(part, body, distance=0.01, angle=0.5):
    """Analysis > Examine Geometry on ONE body -> {check name: number of failed objects}.

    A healthy solid gives 0 everywhere; an open (leaking) body gives BodySheetBoundaries > 0.
    Use it on every imported body before editing and on every final body before export."""
    import NXOpen.GeometricAnalysis as GA
    eg = part.AnalysisManager.CreateExamineGeometryObject()
    try:
        eg.SetAllChecks()
        eg.CheckCriteriaDistance = distance
        eg.CheckCriteriaAngle = angle
        eg.ObjectsToExamine.Add(body)
        eg.Examine()
        out = {}
        for n in ("ObjectTiny", "ObjectMisaligned", "BodyDataStructures", "BodyConsistency", "BodyFaceIntersections",
                  "BodySheetBoundaries", "FaceSmoothness", "FaceSelfIntersection", "FaceSpikesCuts", "EdgeSmoothness",
                  "EdgeTolerances"):
            try:
                out[n] = len(eg.GetFailedObjects(getattr(GA.ExamineGeometry.Check, n)))
            except Exception:  # noqa: BLE001
                pass
        return out
    finally:
        eg.Destroy()


def body_ok(part, body):
    """True when Examine Geometry reports no failed object for the body."""
    return all(v == 0 for v in examine_geometry(part, body).values())


def angle_deg(u, v):
    """Angle between two vectors in degrees (0..180)."""
    du = math.sqrt(sum(x * x for x in u))
    dv = math.sqrt(sum(x * x for x in v))
    c = max(-1.0, min(1.0, sum(x * y for x, y in zip(u, v)) / (du * dv)))
    return math.degrees(math.acos(c))


def g1_deviation(face_a, face_b, points):
    """Max angle (deg) between the two faces' tangent planes at points on their common boundary.
    0 = tangent (G1); a crease shows as degrees. The headless stand-in for Reflection analysis
    (Examine Geometry does NOT report creases).

    The normals of two sheets may point to opposite sides (a base sheet with normal -Z joined to
    a loft with +Z is still tangent), so the angle is folded into 0..90."""
    worst = 0.0
    for p in points:
        a = angle_deg(normal_at(face_a, p), normal_at(face_b, p))
        worst = max(worst, min(a, 180.0 - a))
    return worst


def max_curvature(face, xyz):
    """Largest principal curvature (1/mm) of a face at the point nearest xyz.
    Equal values on both sides of a shared edge = curvature continuous (G2) there."""
    parm, _p = UFS.Modeling.AskFaceParm(face.Tag, [float(v) for v in xyz])
    radii = list(UFS.Modeling.AskFaceProps(face.Tag, parm)[6])
    return max(abs(1.0 / r) if abs(r) > 1e-9 else 0.0 for r in radii)


def new_bodies(part, before):
    """Bodies that appeared since `before = list(part.Bodies)` (imports, pattern geometry, splits)."""
    tags = {b.Tag for b in before}
    return [b for b in part.Bodies if b.Tag not in tags]


class Check:
    """Accumulates measured checks; `result` is PASS only if every check passed.

        chk = nxh.Check(); chk("shell volume", nxh.volume(part, body), 24832.0, 0.01); res.update(chk.report())
    """

    def __init__(self):
        self.rows = []

    def __call__(self, name, got, want, tol=1e-3):
        if got is None:
            self.rows.append({"name": name, "got": None, "want": want, "tol": tol, "ok": False})
            return False
        ok = abs(float(got) - float(want)) <= tol
        self.rows.append({"name": name, "got": round(float(got), 6), "want": round(float(want), 6), "tol": tol, "ok": ok})
        return ok

    def true(self, name, cond, note=""):
        self.rows.append({"name": name, "ok": bool(cond), "note": str(note)})
        return bool(cond)

    def report(self):
        return {"result": "PASS" if self.rows and all(r["ok"] for r in self.rows) else "FAIL", "checks": self.rows}


def volume(part, body):
    return mass(part, [body])["volume"]


def face_census(body):
    """{face type code: count} plus totals, the quickest structural fingerprint of a body."""
    out = {}
    for f in body.GetFaces():
        t = face_data(f)[0]
        out[t] = out.get(t, 0) + 1
    return {"faces": len(body.GetFaces()), "edges": len(body.GetEdges()), "types": out}


def face_at(part, body, xyz, tol=1e-6):
    """Faces of the body that pass through the point - the most reliable selector on a real part
    with hundreds of faces, and for faces made by sync edits or the rim idiom (their bounding
    boxes are padded by up to 0.1 mm). Use MEASURED coordinates (face_data(face)[1], an edge
    vertex, a point computed from measured values), not numbers rounded in a report: a wall
    "at y = -7.685" is missed when it really sits at -7.6846."""
    return [f for f in body.GetFaces() if abs(dist_to(part, f, xyz)) < tol]


def bodies_report(part):
    """Every body of the part with what is needed to tell the product body from tools and scrap:
    solid / sheet, blanked, layer, volume, bounding box, face count, and the features that own it."""
    owners = {}
    for f in part.Features.GetFeatures():
        try:
            for b in f.GetBodies():
                owners.setdefault(b.Tag, []).append(f.GetFeatureName())
        except Exception:  # noqa: BLE001
            pass
    rows = []
    for b in part.Bodies:
        row = {"body": b, "tag": b.Tag, "solid": b.IsSolidBody, "blanked": b.IsBlanked, "layer": b.Layer,
               "faces": len(b.GetFaces()), "bbox": bbox(b), "features": owners.get(b.Tag, [])[-4:]}
        try:
            row["volume"] = volume(part, b) if b.IsSolidBody else 0.0
        except Exception:  # noqa: BLE001
            row["volume"] = None
        rows.append(row)
    return rows


def faces(body, ftype=None, normal=None, at=None, radius=None, tol=1e-3, ntol=1e-4):
    """Filter faces by UF type, outward normal / axis direction, a coordinate test and radius.

    at: (axis_index, value) tests the face bounding box is flat at that coordinate (planes), e.g. (2, 30.0)
    ntol: per-component tolerance on the normal; drafted walls are not exactly axis-aligned, so pass
    e.g. ntol=0.1 (about 5 degrees) to find "the +X wall" of a drafted body.
    """
    out = []
    for f in body.GetFaces():
        t, _pt, d, rad = face_data(f)
        if ftype is not None and t != ftype:
            continue
        if normal is not None and not all(abs(a - b) < ntol for a, b in zip(d, normal)):
            continue
        if radius is not None and abs(abs(rad) - radius) > tol:
            continue
        if at is not None:
            bb = bbox(f)
            i, v = at
            if abs(bb[i] - v) > tol or abs(bb[i + 3] - v) > tol:
                continue
        out.append(f)
    return out


def edges(body, pred):
    """Edges whose bounding box satisfies pred(bbox)."""
    return [e for e in body.GetEdges() if pred(bbox(e))]


def edges_at(body, axis_index, value, tol=1e-3):
    """Edges lying entirely in the plane <axis> = value."""
    return edges(body, lambda b: abs(b[axis_index] - value) < tol and abs(b[axis_index + 3] - value) < tol)


def one(objs, what="object"):
    """The single match of a query, or an error that says how many matched and where they are.

    body.GetFaces() / GetEdges() come back in a different order in different NX sessions, so
    `faces(...)[0]` on a query that matches two objects picks a different one from run to run
    (measured: a 2.9 x 0.5 mm sliver face taken instead of the plate bottom in 4 of 8 runs).
    Tighten the query (at=, radius=, face_at) until it is unique and wrap it in one()."""
    objs = list(objs)
    if len(objs) != 1:
        where = []
        for o in objs[:6]:
            try:
                where.append([round(x, 3) for x in bbox(o)])
            except Exception:
                where.append(str(o))
        raise RuntimeError("%s: expected exactly 1 match, got %d %s" % (what, len(objs), where))
    return objs[0]


# ---------------------------------------------------------------- primitive / swept features
def block(part, origin, size, op=None, target=None):
    """Block; size entries may be formulas, the ORIGIN is numeric only (a block whose position must
    follow expressions is an extruded sketch, or a block followed by Move Object). With op (Features.Feature.BooleanType.Unite / Subtract /
    Intersect) and target it is used as a tool on that body.

    BlockFeatureBuilder silently IGNORES BooleanOption on NX 2206 - the boolean must be set with
    SetBooleanOperationAndTarget (Cylinder / Sphere / Cone honour BooleanOption)."""
    b = part.Features.CreateBlockFeatureBuilder(NULL_FEATURE)
    try:
        b.Type = NXOpen.Features.BlockFeatureBuilder.Types.OriginAndEdgeLengths
        b.SetOriginAndLengths(P(*origin), str(size[0]), str(size[1]), str(size[2]))
        if op is not None and target is not None:
            fbt = NXOpen.Features.Feature.BooleanType
            for name in ("Unite", "Subtract", "Intersect"):          # accept nxh.BOOL.* as well
                if op == getattr(BOOL, name):
                    op = getattr(fbt, name)
            b.SetBooleanOperationAndTarget(op, target)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, (target if (op is not None and target is not None) else f.GetBodies()[0])


def cylinder(part, origin, vec, diameter, height, op=None, target=None):
    b = part.Features.CreateCylinderBuilder(NULL_FEATURE)
    try:
        b.Type = NXOpen.Features.CylinderBuilder.Types.AxisDiameterAndHeight
        b.Axis = axis(part, origin, vec)
        b.Diameter.RightHandSide = str(diameter)
        b.Height.RightHandSide = str(height)
        op = BOOL.Create if op is None else op
        b.BooleanOption.Type = op
        b.BooleanOption.SetTargetBodies([target] if op != BOOL.Create else [NXOpen.Body.Null])
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, (f.GetBodies()[0] if op == BOOL.Create else target)


def extrude(part, sec, vec, start, end, op=None, target=None, origin=(0, 0, 0), sheet=False):
    """Extrude a section. op: BOOL.Create / Unite / Subtract / Intersect. start/end may be formulas.
    sheet=True forces a sheet body even for a closed section."""
    b = part.Features.CreateExtrudeBuilder(NULL_FEATURE)
    try:
        b.Section = sec
        b.Direction = direction(part, vec, origin)
        b.Limits.StartExtend.Value.RightHandSide = str(start)
        b.Limits.EndExtend.Value.RightHandSide = str(end)
        if sheet:
            b.FeatureOptions.BodyType = NXOpen.GeometricUtilities.FeatureOptions.BodyStyle.Sheet
        op = BOOL.Create if op is None else op
        b.BooleanOperation.Type = op
        if op != BOOL.Create:
            b.BooleanOperation.SetTargetBodies([target])
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f


def unite(part, target, tools=None, check=True, tool_features=None, keep_tool=False):
    return _boolean(part, target, tools, NXOpen.Features.Feature.BooleanType.Unite, check, tool_features, keep_tool)


def subtract(part, target, tools=None, check=True, tool_features=None, keep_tool=False):
    return _boolean(part, target, tools, NXOpen.Features.Feature.BooleanType.Subtract, check, tool_features, keep_tool)


def intersect(part, target, tools=None, check=True, tool_features=None, keep_tool=False):
    return _boolean(part, target, tools, NXOpen.Features.Feature.BooleanType.Intersect, check, tool_features, keep_tool)


def _boolean(part, target, tools, op, check=True, tool_features=None, keep_tool=False):
    """Boolean feature with the silent-failure guard: NX raises nothing when a Unite's bodies do
    not overlap or a Subtract splits the target - the feature simply owns several bodies.

    tools: explicit tool bodies. tool_features: features whose bodies are the tools (BodyFeature
    rule) - use it for Mirror Geometry / Pattern Geometry results so the tool set follows a
    changing copy count. keep_tool=True leaves the tool bodies in the part.

    A SHEET body as the target is legitimate (sheet minus solid = the sheet trimmed by the solid;
    Intersect = the part of the sheet inside it) and the result is one sheet body PER remaining
    piece, so the "feature owns several bodies" test does not apply there. For a sheet target the
    guard checks instead that the feature owns at least one body and that the sheet area changed
    (an untouched sheet means the tool missed it)."""
    tools = list(tools or [])
    n0 = len(solids(part))
    sheet_target = not target.IsSolidBody
    area0 = sheet_area(part, target)[0] if (check and sheet_target) else None
    b = part.Features.CreateBooleanBuilderUsingCollector(NXOpen.Features.BooleanFeature.Null)
    try:
        b.Tolerance = 0.01
        b.Operation = op
        b.Targets.Add(target)
        if tool_features:
            sc = part.ScCollectors.CreateCollector()
            sc.ReplaceRules([part.ScRuleFactory.CreateRuleBodyFeature(list(tool_features), True,
                                                                      NXOpen.DisplayableObject.Null)], False)
            b.ToolBodyCollector = sc
        else:
            b.ToolBodyCollector = collector(part, bodies=tools)
        if keep_tool:
            b.CopyTools = True
            b.RetainTool = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    if check:
        n1 = len(solids(part))
        problems = []
        if sheet_target:
            pieces = [b for b in f.GetBodies() if not b.IsSolidBody]
            area1 = sum(sheet_area(part, b)[0] for b in pieces)
            if not pieces:
                problems.append("feature owns no sheet body")
            elif abs(area1 - area0) <= 1e-6 * max(1.0, area0):
                problems.append(f"sheet area unchanged ({area0:.4f}): the tool did not cut the sheet")
        elif len(f.GetBodies()) != 1:
            problems.append(f"feature owns {len(f.GetBodies())} bodies")
        if not tool_features and not keep_tool and n1 != n0 - len(tools):
            problems.append(f"solids {n0} -> {n1}, expected {n0 - len(tools)}")
        if tool_features and not keep_tool and n1 >= n0:
            problems.append(f"solids {n0} -> {n1}, no tool body was consumed")
        if problems:
            raise RuntimeError("boolean did not merge cleanly (" + "; ".join(problems) +
                               ") - bodies disjoint, only touching, or the target was split")
    return f


def blend_overflow(builder, overflow=True):
    """Set the overflow switches of an EdgeBlendBuilder. A builder created in a journal has ALL of them off,
    the Edge Blend dialog has the three on - so a blend that the dialog makes is refused headless with
    'Unable to terminate the blend faces...' as soon as it is wider than the face it rolls on.

    overflow=True   RollOverSmoothEdge, RollOntoEdge, MoveSharpEdge = True (the dialog's defaults)
    overflow=False  leave the builder as created (all off): the blend must fit, otherwise it is refused
    overflow=dict   builder properties to set, e.g. {"MoveSharpEdge": True} or {"OverlapOption": ...}
    Measured (12 mm wide top, R3 on one edge, R10 on the other): off -> refused; Roll Onto Edges or all three ->
    the R10 runs through the tangent edge of the R3 and meets the far face with a crease; Move Sharp Edges
    alone -> the R10 keeps its full shape and cuts into the R3. A blend that only commits thanks to these
    switches is NOT tangent everywhere: check it (nxh.g1_deviation, volume)."""
    if overflow is True:
        overflow = {"RollOverSmoothEdge": True, "RollOntoEdge": True, "MoveSharpEdge": True}
    for k, v in (overflow or {}).items():
        setattr(builder, k, v)


def blend(part, edge_list, radius, overflow=False):
    """Edge Blend of one edge set with one radius. overflow: see blend_overflow - False (default) = the
    builder as created, all overflow switches off: a blend that does not fit its faces is REFUSED;
    True = the Edge Blend dialog's defaults: such a blend commits, rolled onto the neighbouring edge.
    The default stays False because journals of this skill set rely on the refusal (fallback to a smaller
    radius; a pattern instance whose blend would run past the plate end is dropped and reported; with True
    an R500 blend on a 20 mm edge commits). Pass overflow=True when the drawing's blend is refused with
    'Unable to terminate the blend faces...' although the dialog would make it - and check the result."""
    b = part.Features.CreateEdgeBlendBuilder(NULL_FEATURE)
    try:
        blend_overflow(b, overflow)
        b.AddChainset(collector(part, edges=edge_list), str(radius))
        b.Tolerance = 0.01
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f


def builder_doc(builder, names=None):
    """Docstrings of a builder's properties/methods - the offline API reference inside NX."""
    cls = type(builder)
    out = {}
    for n in dir(cls):
        if n.startswith("_") or (names and n not in names):
            continue
        try:
            out[n] = (getattr(cls, n).__doc__ or "").strip()[:700]
        except Exception:  # noqa: BLE001
            pass
    return out


def enum_names(enum_cls):
    return [n for n in dir(enum_cls) if not n.startswith("_") and n != "ValueOf"]
