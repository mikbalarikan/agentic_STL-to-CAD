"""As-found report of an existing NX part - run this BEFORE editing anything a person built.
Read-only: never saves, never rolls the model, never unsuppresses.

usage: run_journal.ps1 -Script inspect_part.py -JArgs <part.prt>,<out_dir>
writes <out_dir>/<part name>_asfound.json and <part name>_asfound.txt (one-page summary)

What it answers: what could not be loaded; which bodies exist and which is probably the product
(solid, unblanked, owned by late features); the feature tree with suppression and messages, keyed
by tag; imported / linked features and whether the links are broken; sketches and their constraint
status; user-named expressions; holes, bosses and blends of each solid; Examine Geometry.
For the builder settings of every feature use dump_part.py.
"""
import os
import re
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import NXOpen  # noqa: E402
import nxh  # noqa: E402

PNAME = re.compile(r"^p\d+$")                       # kept for callers; the name test is nxh.user_named
LINK_TYPES =("LINKED_BODY", "LINKED_FACE", "LINKED_CURVE", "LINKED_SKETCH", "LINKED_DATUM", "LINKED_POINT")


def messages(f):
    out = {}
    for label, name in (("error", "GetFeatureErrorMessages"), ("warning", "GetFeatureWarningMessages"),
                        ("info", "GetFeatureInformationalMessages")):
        try:
            v = list(getattr(f, name)() or [])
            if v:
                out[label] = v
        except Exception:  # noqa: BLE001
            pass
    return out


def feature_rows(part):
    """(top-level rows, internal summary). Internal rows (Feature.IsInternal: pattern / mirror
    instances, hole child rows, linked-curve objects, sketch CSYS) are counted by type, not listed;
    an internal row that carries an error is kept in the summary so a failed instance is not lost."""
    rows = []
    internal = {"count": 0, "types": {}, "suppressed": 0, "with_errors": []}
    for f in part.Features.GetFeatures():
        if nxh.is_internal(f):
            internal["count"] += 1
            internal["types"][f.FeatureType] = internal["types"].get(f.FeatureType, 0) + 1
            internal["suppressed"] += 1 if f.Suppressed else 0
            m = messages(f)
            if m.get("error"):
                internal["with_errors"].append({"ts": f.Timestamp, "name": f.GetFeatureName(), "error": m["error"]})
            continue
        r = {"tag": f.Tag, "ts": f.Timestamp, "name": f.GetFeatureName(), "type": f.FeatureType,
             "cls": type(f).__name__, "suppressed": bool(f.Suppressed)}
        try:                                                 # WHY it is inactive: 1 person, 2 expression, 4 failed, 16 rolled back, 64 parent
            st = nxh.suppress_status(f)
            if st["code"]:
                r["inactive"] = st["code"]
                r["why"] = "+".join(k for k in ("suppressed", "by_expression", "failed", "rolled_back", "by_parent") if st[k])
        except Exception:  # noqa: BLE001
            pass
        leg = nxh.legacy_note(f)
        if leg:
            r["legacy"] = leg[0]
            r["use_today"] = leg[1]
        r.update(messages(f))
        try:
            r["parents"] = [p.GetFeatureName() for p in f.GetParents()]
        except Exception:  # noqa: BLE001
            pass
        if f.FeatureType in LINK_TYPES or "Linked" in r["name"]:
            r["link"] = nxh.link_status(f)
        rows.append(r)
    return rows, internal


def auto_dimensions(sk):
    """Number of automatic dimensions in a sketch (DimensionState == Automatic) = the degrees of
    freedom NX closed by itself; same count as nxf.auto_dimensions. A property read, no solve."""
    n = 0
    for c in sk.GetAllConstraintsOfType(NXOpen.Sketch.ConstraintClass.Dimension, NXOpen.Sketch.ConstraintType.NoCon):
        st = getattr(c, "DimensionState", None)
        if st is not None and st == type(c).DimensionStateType.Automatic:
            n += 1
    return n


def sketch_rows(part):
    """(sketches a person drew, number of pattern / mirror instance copies skipped). An instance
    copy is owned by an internal "Pattern Feature ... / Instance[i][j]" row and reports status
    NotEvaluated, no dimension and no expression. A sketch INTERNAL to its Extrude is a real one
    (well or under constrained) and stays in the list.
    "status" / "dof" are the bare GetStatus() answer; "auto_dims" is the number of automatic
    dimensions and "real_dof" = dof + auto_dims - a sketch is fully constrained only when that is 0."""
    out, copies = [], 0
    for sk in part.Sketches:
        d = {"name": sk.Name}
        try:
            st, dof = sk.GetStatus()
            names = [n for n in nxh.enum_names(NXOpen.Sketch.Status) if getattr(NXOpen.Sketch.Status, n) == st]
            d["status"], d["dof"] = (names[0] if names else str(st)), dof
            owner = sk.Feature
            if d["status"] == "NotEvaluated" and (owner is None or nxh.is_internal(owner)
                                                  or "Instance[" in owner.GetFeatureName()):
                copies += 1
                continue
            d["feature"] = owner.GetFeatureName() if owner else None
            d["suppressed"] = bool(owner.Suppressed) if owner else None
            d["curves"] = len(sk.GetAllGeometry())
            d["dimensions"] = len(sk.GetAllConstraintsOfType(NXOpen.Sketch.ConstraintClass.Dimension,
                                                              NXOpen.Sketch.ConstraintType.NoCon))
            d["expressions"] = len(sk.GetAllExpressions())
            # Automatic dimensions (Continuous Auto Dimensioning) close open degrees of freedom without
            # constraining anything: GetStatus() then says WellConstrained / 0. Read only, nothing is solved.
            d["auto_dims"] = auto_dimensions(sk)
            d["real_dof"] = dof + d["auto_dims"]
        except Exception as e:  # noqa: BLE001
            d["error"] = str(e)[:100]
        out.append(d)
    return out, copies


def body_rows(part):
    rows = []
    for r in nxh.bodies_report(part):
        b = r.pop("body")
        if b.IsSolidBody:
            try:
                r["examine"] = {k: v for k, v in nxh.examine_geometry(part, b).items() if v}
            except Exception as e:  # noqa: BLE001
                r["examine"] = "EXC " + str(e)[:80]
            try:
                hc = nxh.hole_census(part, b)
                r["holes"] = [{"d": round(h["diameter"], 4), "axis": [round(v, 4) for v in h["axis"]],
                               "point": [round(v, 4) for v in h["point"]], "length": round(h["length"], 4)}
                              for h in hc["holes"]]
                r["bosses"] = len(hc["bosses"])
                r["partial_cylinders"] = len(hc["partial"])
                r["blends"] = {str(k): v for k, v in sorted(hc["blends"].items())}
            except Exception as e:  # noqa: BLE001
                r["census"] = "EXC " + str(e)[:80]
            r["face_types"] = nxh.face_census(b)["types"]
        else:
            try:
                r["area"] = nxh.sheet_area(part, b)[0]
                r["free_edges"] = len(nxh.free_edges(b))
            except Exception:  # noqa: BLE001
                pass
        rows.append(r)
    return rows


def likely_product(bodies):
    """Heuristic only: the largest unblanked solid on a visible layer. State it as a guess."""
    cand = [b for b in bodies if b["solid"] and not b["blanked"] and b.get("volume")]
    return max(cand, key=lambda b: b["volume"])["tag"] if cand else None


def summary(res):
    L = []
    L.append(f"AS-FOUND  {res['path']}")
    L.append(f"units {res['units']}  tolerance {res.get('tolerance')}  features {len(res['features'])}"
             f"  suppressed {sum(1 for f in res['features'] if f['suppressed'])}"
             f"  with errors {sum(1 for f in res['features'] if f.get('error'))}")
    it = res.get("internal_features") or {}
    if it.get("count"):
        L.append(f"internal rows (not history steps, not listed): {it['count']}  "
                 + ", ".join(f"{k} {v}" for k, v in sorted(it["types"].items(), key=lambda kv: -kv[1])))
        for e in it.get("with_errors", [])[:10]:
            L.append(f"  internal row with error: {e['ts']} {e['name']}: {e['error'][0][:90]}")
    if res.get("history_mode") is False:
        L.append("MODELLING MODE: HISTORY-FREE - this part is saved without a feature history; new features are not "
                 "recorded as a tree. Ask before converting it (Preferences.Modeling.SetHistoryMode).")
    rb = [f for f in res["features"] if "rolled_back" in f.get("why", "")]
    if rb:
        L.append(f"ROLLED BACK: the current feature is {res.get('current_feature')}; {len(rb)} later features are inactive "
                 "only because of that ([R] below), not suppressed.")
    legacy = [f for f in res["features"] if f.get("legacy")]
    if legacy:
        kinds = {}
        for f in legacy:
            kinds.setdefault(f["type"], [0, f["legacy"], f["use_today"]])[0] += 1
        L.append("LEGACY FEATURES (open and update, most have no edit builder - read, do not edit or imitate; to change one, rebuild it):")
        for t, (n, what, today) in sorted(kinds.items(), key=lambda kv: -kv[1][0]):
            L.append(f"  {n} x {t}: {what} -> today: {today}")
    if res["not_loaded"]:
        L.append("NOT LOADED: " + "; ".join(f"{n} ({why})" for n, why in res["not_loaded"]))
    if res.get("components"):
        L.append("components: " + ", ".join(res["components"]))
    L.append("")
    L.append("BODIES (tag, solid, blanked, layer, volume, faces, last owner features)")
    for b in res["bodies"]:
        mark = "  <- probably the product body" if b["tag"] == res["likely_product_body"] else ""
        L.append(f"  {b['tag']}  {'solid' if b['solid'] else 'sheet'}  {'BLANKED' if b['blanked'] else 'shown'}  L{b['layer']}"
                 f"  V={b.get('volume')}  faces={b['faces']}  {b['features']}{mark}")
        if b.get("examine"):
            L.append(f"      Examine Geometry: {b['examine']}")
        if b.get("holes"):
            L.append("      holes: " + ", ".join(f"d{h['d']} L{h['length']}" for h in b["holes"][:12]))
        if b.get("blends"):
            L.append(f"      blends by radius: {b['blends']}")
    L.append("")
    links = [f for f in res["features"] if f.get("link")]
    if links:
        L.append("LINKED FEATURES (a broken link keeps frozen geometry)")
        for f in links:
            L.append(f"  {f['name']}  broken={f['link'].get('broken')}  suppressed={f['suppressed']}")
        L.append("")
    imported = [f for f in res["features"] if f["cls"] == "Brep"]
    if imported:
        L.append("PARAMETER-LESS BODIES (imported / removed parameters): " + ", ".join(f["name"] for f in imported[:12]))
        L.append("")
    L.append("FEATURE TREE, top-level steps only (ts name [S = suppressed by a person, E = by expression, P = because its parent is,")
    L.append("              F = failed, R = rolled back, L = legacy feature] messages)")
    flag = (("suppressed", "S"), ("by_expression", "E"), ("by_parent", "P"), ("failed", "F"), ("rolled_back", "R"))
    for f in res["features"]:
        msg = "; ".join(f"{k}: {v[0][:90]}" for k, v in f.items() if k in ("error", "warning", "info"))
        why = f.get("why", "").split("+")
        marks = "".join(c for k, c in flag if k in why) or ("S" if f["suppressed"] else "")
        marks += "L" if f.get("legacy") else ""
        L.append(f"  {f['ts']:4d} {f['name']}{(' [' + marks + ']') if marks else ''}{('  ' + msg) if msg else ''}")
    L.append("")
    L.append("SKETCHES: " + "; ".join(f"{s['name']} {s.get('status')} dof={s.get('dof')} dims={s.get('dimensions')}"
                                      + (f" AUTO-DIMS={s['auto_dims']} (real dof {s.get('real_dof')})" if s.get("auto_dims") else "")
                                      + (" [S]" if s.get("suppressed") else "") for s in res["sketches"]))
    if any(s.get("auto_dims") for s in res["sketches"]):
        L.append("  (AUTO-DIMS = automatic dimensions: each hides one open degree of freedom behind a 'dof=0')")
    if res.get("sketch_instance_copies"):
        L.append(f"  ({res['sketch_instance_copies']} pattern / mirror instance copies of sketches not listed)")
    L.append(f"EXPRESSIONS: {res['n_expressions']} total, {res.get('n_named_expressions', 0)} user-named: "
             f"{res['named_expressions'] or 'none'}")
    L.append("")
    L.append("RULES FOR EDITING THIS PART: work on a copy; add features, do not reorder or unsuppress unless asked;")
    L.append("new features land after the last ACTIVE feature (a suppressed tail is renumbered);")
    L.append("compare nxh.feature_state before/after with nxh.state_diff; a feature that must go EARLIER in the tree:")
    L.append("nxh.insert_after (it rolls forward, re-checks suppression and undoes an insertion that breaks a later feature).")
    return "\n".join(L)


def main(argv):
    path, out_dir = argv[0], argv[1]
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(path))[0]
    res = {"path": path}
    try:
        part = nxh.open_part(path)
        res["not_loaded"] = list(nxh.LOAD_STATUS)
        res["units"] = "mm" if part.PartUnits == NXOpen.BasePart.Units.Millimeters else "inch"
        try:
            res["tolerance"] = part.Preferences.Modeling.DistanceToleranceData
        except Exception:  # noqa: BLE001
            res["tolerance"] = None
        try:
            root = part.ComponentAssembly.RootComponent
            res["components"] = [c.DisplayName for c in root.GetChildren()] if root else []
        except Exception:  # noqa: BLE001
            res["components"] = []
        # Expressions FIRST: the blend test of nxh.hole_census opened a ResizeBlendBuilder per solid
        # body, and each left one system expression behind - read last, this total was too high in
        # 71 of 75 reports (hole_census now removes it again; reading first stays the safe order).
        ex = [e for e in part.Expressions]
        res["n_expressions"] = len(ex)
        named = [e for e in ex if nxh.user_named(e.Name)]
        res["n_named_expressions"] = len(named)
        res["named_expressions"] = [f"{e.Name}={e.RightHandSide}" for e in named][:80]
        try:
            res["history_mode"] = nxh.history_mode(part)
            res["current_feature"] = nxh.current_feature(part).GetFeatureName()
        except Exception:  # noqa: BLE001
            pass
        res["features"], res["internal_features"] = feature_rows(part)
        res["n_features_all_rows"] = len(res["features"]) + res["internal_features"]["count"]
        res["sketches"], res["sketch_instance_copies"] = sketch_rows(part)
        res["bodies"] = body_rows(part)
        res["likely_product_body"] = likely_product(res["bodies"])
        res["result"] = "OK"
        with open(os.path.join(out_dir, base + "_asfound.txt"), "w", encoding="utf-8") as fh:
            fh.write(summary(res))
    except Exception:  # noqa: BLE001
        res["result"] = "ERROR"
        res["error"] = traceback.format_exc()
    nxh.write_json(os.path.join(out_dir, base + "_asfound.json"), res)
    try:
        nxh.close_all()
    except Exception:  # noqa: BLE001
        pass


if __name__ == "__main__":
    main(sys.argv[1:])
