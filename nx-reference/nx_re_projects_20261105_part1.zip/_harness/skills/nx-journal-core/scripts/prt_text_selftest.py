"""Self-test of prt_text.py (the offline .prt reader): two small parts are built and saved by NX 2206 here -
a piece part and an assembly of it - then read back WITHOUT NX (prt_text.read_part on the files) and compared
with what NXOpen said about them before they were closed.

  piece part   block, hole pattern (internal rows), blend, sketch + extrude, a named feature group; named,
               conditional, Boolean and String expressions, one with a comment
  assembly     two instances of the piece part, one interpart expression

Checked: feature count and count per type (all rows), expression names and formula text, the user-named test,
component instances and the referenced part file, the decode self-check, the NX version string, that reading
does not touch the file (SHA-256 before / after) and the command line (--json).
The fixed-width record layout of NX 8.5 and older cannot be produced with NX 2206; it was proven on the 1,375
old parts named in the module docstring. Extra arguments = paths of COPIES of other parts: each is read and its
decode check is reported (not compared with NX).

Usage:  run_journal prt_text_selftest.py -args <output folder> [<copy of another part> ...]
Writes <output folder>/prt_text_selftest.json  with "result": "PASS" | "FAIL".
"""
import hashlib
import json
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.dirname(os.path.abspath(sys.argv[0])))
import nxh  # noqa: E402
import nxf  # noqa: E402
import nxa  # noqa: E402
import prt_text  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
EXTRA = [a for a in sys.argv[2:] if a.lower().endswith(".prt")]
chk = nxh.Check()
res = {"result": "FAIL", "measured": {}}


def sha(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def norm(text):
    return "".join(str(text).split())


def truth(part):
    """What NXOpen says: rows per type (ALL rows), expressions {name: rhs}, user-named names."""
    types = {}
    for f in part.Features.GetFeatures():
        types[f.FeatureType] = types.get(f.FeatureType, 0) + 1
    ex = {e.Name: e.RightHandSide for e in part.Expressions}
    return {"n_features": sum(types.values()), "types": types, "expressions": ex,
            "user_named": sorted(n for n in ex if nxh.user_named(n))}


try:
    # ------------------------------------------------------------------ the piece part
    p_piece = os.path.join(OUT, "offline_piece.prt")
    part = nxh.new_part(p_piece)
    nxh.expr(part, "plate_len", 80, "mm", "overall length")
    nxh.expr(part, "plate_t", 12, "mm")
    nxh.expr(part, "n_holes", 4, None)
    part.Expressions.CreateWithUnits("hole_d=if (n_holes>4) (5) else (6.6)", part.UnitCollection.FindObject("MilliMeter"))
    part.Expressions.CreateExpression("Boolean", "with_boss=true")
    part.Expressions.CreateExpression("String", 'material="S235"')
    fb, body = nxh.block(part, (-40.0, -40.0, 0.0), ("plate_len", "plate_len", "plate_t"))
    fh = nxf.hole(part, body, [(25.0, 0.0, 12.0)], "hole_d")
    fh = fh[0] if isinstance(fh, (tuple, list)) else fh
    nxf.pattern_circular(part, [fh], (0.0, 0.0, 0.0), (0.0, 0.0, 1.0), "n_holes")
    nxh.blend(part, nxh.edges(body, lambda b: abs(b[0] - b[3]) < 1e-6 and abs(b[1] - b[4]) < 1e-6 and b[5] - b[2] > 11), 6)
    dat = nxh.Datums(part)
    sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, name="SK_BOSS")
    nxf.sketch_circle(part, sk, dat.origin, 20)
    nxf.finish_sketch(sk)
    fboss = nxh.extrude(part, nxh.section_feature(part, [sk.Feature]), (0, 0, 1), "plate_t", "plate_t+8", nxh.BOOL.Unite, body)
    nxf.feature_group(part, [sk.Feature, fboss], "BOSS")
    nxh.update()
    t_piece = truth(part)
    chk.true("piece part built without feature error", not nxh.feature_errors(part), nxh.feature_errors(part))
    nxh.save(part)
    nxh.close_all()

    # ------------------------------------------------------------------ the assembly
    p_assy = os.path.join(OUT, "offline_assy.prt")
    assy = nxa.new_assembly(p_assy)
    nxa.add_component(assy, p_piece, "PIECE_A", origin=(0, 0, 0))
    nxa.add_component(assy, p_piece, "PIECE_B", origin=(100, 0, 0))
    nxh.save(assy)
    piece = [p for p in nxh.S.Parts if p.Leaf.lower() == "offline_piece"][0]
    nxa.interpart_expr(assy, "len_from_piece", piece, "plate_len")
    nxh.update()
    t_assy = truth(assy)
    n_comp = len(nxa.components(assy))
    nxh.save(assy)
    nxh.close_all()

    # ------------------------------------------------------------------ read both files without NX
    h0 = {p: sha(p) for p in (p_piece, p_assy)}
    s = prt_text.read_part(p_piece)
    a = prt_text.read_part(p_assy)
    res["measured"]["piece"] = {k: s[k] for k in ("saved_by", "container", "record_layout", "n_features", "feature_types", "n_expressions",
                                                  "n_user_named", "components", "reference_sets", "checks")}
    res["measured"]["assembly"] = {k: a[k] for k in ("n_features", "feature_types", "n_expressions", "components", "referenced_parts", "checks")}
    res["measured"]["nx_piece"] = {"n_features": t_piece["n_features"], "types": t_piece["types"], "n_expressions": len(t_piece["expressions"])}
    chk.true("reading leaves both files byte-identical (SHA-256)", h0 == {p: sha(p) for p in (p_piece, p_assy)})
    chk.true("piece: saved by NX 2206, var-int records", "2206" in str(s["saved_by"]) and s["record_layout"] == "var-int", [s["saved_by"], s["record_layout"]])
    chk.true("piece: decode self-check ok", s["checks"]["features"] == "ok" and not s["checks"]["errors"], s["checks"])
    chk("piece: feature rows = NXOpen GetFeatures() (internal rows included)", s["n_features"], t_piece["n_features"], 0)
    chk.true("piece: count per feature type identical to NXOpen", s["feature_types"] == t_piece["types"],
             {"offline": s["feature_types"], "nx": t_piece["types"]})
    chk.true("piece: the pattern's internal rows are in the count (more than one hole-type row)",
             sum(v for k, v in s["feature_types"].items() if "HOLE" in k) > 1, s["feature_types"])
    chk.true("piece: the feature group name BOSS is read", any(f["name"] == "BOSS" for f in s["feature_names"]), s["feature_names"])
    off = {e["name"]: e["rhs"] for e in s["expressions"]}
    chk.true("piece: the same expression names as NXOpen", sorted(off) == sorted(t_piece["expressions"]),
             sorted(set(off) ^ set(t_piece["expressions"])))
    wrong = [n for n in t_piece["expressions"] if n in off and norm(off[n]) != norm(t_piece["expressions"][n].split("//")[0])]
    chk.true("piece: every formula text equals NXOpen's RightHandSide (without its // comment)", not wrong,
             [(n, off[n], t_piece["expressions"][n]) for n in wrong][:6])
    chk.true("piece: the comment of plate_len is read as a separate field",
             [e["comment"] for e in s["expressions"] if e["name"] == "plate_len"] == ["overall length"])
    chk.true("piece: user-named = nxh.user_named", sorted(e["name"] for e in s["expressions"] if e["user_named"]) == t_piece["user_named"],
             [sorted(e["name"] for e in s["expressions"] if e["user_named"]), t_piece["user_named"]])
    chk.true("piece: the conditional formula is there as typed", norm(off.get("hole_d", "")) == norm("if (n_holes>4) (5) else (6.6)"), off.get("hole_d"))
    typed = {e["name"]: e["type"] for e in s["expressions"]}
    chk.true("piece: Boolean and String expressions carry their type", typed.get("with_boss") == "Boolean" and typed.get("material") == "String",
             [typed.get("with_boss"), typed.get("material")])
    res["measured"]["comment_of_plate_len"] = [e["comment"] for e in s["expressions"] if e["name"] == "plate_len"]
    chk("piece: no component", s["components"], 0, 0)
    chk("assembly: component instances = NXOpen", a["components"], n_comp, 0)
    chk("assembly: two instances", a["components"], 2, 0)
    chk.true("assembly: the piece part file is among the referenced parts", any("offline_piece" in r.lower() for r in a["referenced_parts"]), a["referenced_parts"])
    aoff = {e["name"]: e for e in a["expressions"]}
    res["measured"]["assembly_expressions"] = {"offline": {n: e["rhs"] for n, e in aoff.items()}, "nx": t_assy["expressions"]}
    chk.true("assembly: the interpart expression is read; its link shows as the placeholder interpart<n>",
             "len_from_piece" in aoff and a["n_interpart"] == 1 and any(e["kind"] == "interpart-link" for e in a["expressions"]),
             [res["measured"]["assembly_expressions"], a["n_interpart"]])
    chk("assembly: feature rows = NXOpen", a["n_features"], t_assy["n_features"], 0)
    # command line
    js = os.path.join(OUT, "offline_piece_summary.json")
    rc = prt_text.main([p_piece, "--json", js])
    back = json.load(open(js, encoding="utf-8"))
    chk.true("command line: --json writes the same summary", rc == 0 and back["feature_types"] == s["feature_types"] and back["n_expressions"] == s["n_expressions"])
    text = prt_text.report(s)
    chk.true("report(): one page that names the limits", "NOT in this read" in text and "BLOCK" in text, text[:200])
    with open(os.path.join(OUT, "offline_piece_report.txt"), "w", encoding="utf-8") as fh:
        fh.write(text)
    for p in EXTRA:
        try:
            x = prt_text.read_part(p)
            res["measured"].setdefault("extra", {})[os.path.basename(p)] = {"saved_by": x["saved_by"], "record_layout": x["record_layout"],
                                                                           "n_features": x["n_features"], "checks": x["checks"]}
        except Exception as e:  # noqa: BLE001
            res["measured"].setdefault("extra", {})[os.path.basename(p)] = "ERR " + str(e)[:200]
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("no exception", False, traceback.format_exc()[-400:])
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "prt_text_selftest.json"), res)
try:
    nxh.close_all()
except Exception:  # noqa: BLE001
    pass
