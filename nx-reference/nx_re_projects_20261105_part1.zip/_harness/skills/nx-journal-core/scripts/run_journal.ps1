param(
    [Parameter(Mandatory=$true)][string]$Script,
    [string[]]$JArgs = @(),
    [string]$WorkDir = "C:\NX_MCP_WORKSPACE",
    [int]$TimeoutSec = 900,
    [string]$NxBin = "C:\Program Files\Siemens\NX2206\NXBIN"
)
# Runs one NXOpen Python journal headless (batch NX, no GUI) in a child process.
# - NX 2206 run_journal rejects the -nx switch: do not pass it.
# - The session-capture plugin variables are cleared for the child only.
# - WorkDir is where NX drops translator logs (ugstep214.log ...).
# - On timeout only the child started here is killed. Never kill NX by process name.
New-Item -ItemType Directory -Force $WorkDir | Out-Null
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = Join-Path $NxBin "run_journal.exe"
$a = '"' + $Script + '"'
if ($JArgs.Count -gt 0) { $a += ' -args ' + (($JArgs | ForEach-Object { '"' + $_ + '"' }) -join ' ') }
$psi.Arguments = $a
$psi.WorkingDirectory = $WorkDir
$psi.UseShellExecute = $false
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$psi.EnvironmentVariables.Remove("UGII_CUSTOM_DIRECTORY_FILE")
$psi.EnvironmentVariables.Remove("UGII_STARTUP_MACRO")
if (-not $psi.EnvironmentVariables.ContainsKey("NXH_DIR")) { $psi.EnvironmentVariables["NXH_DIR"] = $PSScriptRoot }
# helper modules of sibling skills (import nxre after putting NXRE_DIR on sys.path)
$reDir = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "nx-reverse-engineering\scripts"
if ((-not $psi.EnvironmentVariables.ContainsKey("NXRE_DIR")) -and (Test-Path $reDir)) { $psi.EnvironmentVariables["NXRE_DIR"] = $reDir }
$dDir = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "nx-drafting\scripts"
if ((-not $psi.EnvironmentVariables.ContainsKey("NXD_DIR")) -and (Test-Path $dDir)) { $psi.EnvironmentVariables["NXD_DIR"] = $dDir }
$blDir = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "nx-surface-modeling\scripts"
if ((-not $psi.EnvironmentVariables.ContainsKey("NXBLADE_DIR")) -and (Test-Path (Join-Path $blDir "nxblade.py"))) { $psi.EnvironmentVariables["NXBLADE_DIR"] = $blDir }
$smDir = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "nx-sheet-metal\scripts"
if ((-not $psi.EnvironmentVariables.ContainsKey("NXSM_DIR")) -and (Test-Path $smDir)) { $psi.EnvironmentVariables["NXSM_DIR"] = $smDir }
$wDir = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "nx-assemblies\scripts"
if ((-not $psi.EnvironmentVariables.ContainsKey("NXW_DIR")) -and (Test-Path (Join-Path $wDir "nxw.py"))) { $psi.EnvironmentVariables["NXW_DIR"] = $wDir }
$ckDir = Join-Path (Split-Path (Split-Path $PSScriptRoot)) "nx-curves-and-sketches\scripts"
if ((-not $psi.EnvironmentVariables.ContainsKey("NXCK_DIR")) -and (Test-Path (Join-Path $ckDir "curvekit.py"))) { $psi.EnvironmentVariables["NXCK_DIR"] = $ckDir }
$p = [System.Diagnostics.Process]::Start($psi)
$errTask = $p.StandardError.ReadToEndAsync()
$outTask = $p.StandardOutput.ReadToEndAsync()
if (-not $p.WaitForExit($TimeoutSec * 1000)) {
    try { $p.Kill() } catch {}
    "TIMEOUT after $TimeoutSec s (killed pid $($p.Id))"
}
$outTask.Result
$e = $errTask.Result
if ($e) { "--- stderr ---"; $e }
"exit " + $p.ExitCode
