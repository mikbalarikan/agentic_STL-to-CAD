param(
    [string]$SkillsRoot = (Split-Path (Split-Path $PSScriptRoot)),
    [string]$OutRoot = "C:\NX_MCP_WORKSPACE\skill_regress",
    [string[]]$Only = @(),          # skill folder names to restrict to, e.g. nx-solid-features
    [int]$TimeoutSec = 900,
    [int]$MinFreeMB = 700,          # wait before each NX launch while less memory than this is available (0 = no check)
    [int]$MemWaitSec = 900          # give up waiting after this long and launch anyway (a message says so)
)
# Regression: runs every example journal of the nx-* skills headless and tabulates
# the "result" field each one writes to <OutRoot>\<skill>\<script>.json.
# One NX process at a time. Use after changing nxh.py or after an NX upgrade.
# Helper modules (not examples) are skipped; each NX launch waits for free memory first.
$launcher = Join-Path $PSScriptRoot "run_journal.ps1"
$skip = @("nxh.py", "nxf.py", "nxa.py", "nxre.py", "nxd.py", "nxblade.py", "dump_part.py", "inspect_part.py", "prt_text.py")
function Wait-FreeMemory {
    if ($MinFreeMB -le 0) { return }
    $waited = 0
    while ($true) {
        try { $mb = [int](Get-Counter '\Memory\Available MBytes' -ErrorAction Stop).CounterSamples[0].CookedValue } catch { return }
        if ($mb -ge $MinFreeMB) { return }
        if ($waited -ge $MemWaitSec) { "  memory: $mb MB free after waiting $waited s - launching anyway"; return }
        "  memory: $mb MB free (under $MinFreeMB) - waiting 30 s"
        Start-Sleep -Seconds 30
        $waited += 30
    }
}
$rows = @()
Get-ChildItem -LiteralPath $SkillsRoot -Directory -Filter "nx-*" | Sort-Object Name | ForEach-Object {
    $skill = $_.Name
    if ($Only.Count -gt 0 -and $Only -notcontains $skill) { return }
    $sdir = Join-Path $_.FullName "scripts"
    if (-not (Test-Path $sdir)) { return }
    Get-ChildItem -LiteralPath $sdir -Filter *.py | Where-Object { $skip -notcontains $_.Name } | Sort-Object Name | ForEach-Object {
        $out = Join-Path $OutRoot $skill
        New-Item -ItemType Directory -Force $out | Out-Null
        $json = Join-Path $out ($_.BaseName + ".json")
        if (Test-Path $json) { Remove-Item -LiteralPath $json -Force }
        Wait-FreeMemory
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $log = & $launcher -Script $_.FullName -WorkDir $out -JArgs $out -TimeoutSec $TimeoutSec
        $exit = ($log | Select-Object -Last 1)
        $result = "NO JSON"; $n = ""
        if (Test-Path $json) {
            try {
                $d = Get-Content -LiteralPath $json -Raw -Encoding utf8 | ConvertFrom-Json
                $result = [string]$d.result
                if ($d.checks) {
                    # checks is a list of {name, ok, ...} or a dict name -> {ok, ...}
                    $c = if ($d.checks -is [pscustomobject]) { @($d.checks.PSObject.Properties | ForEach-Object { $_.Value }) } else { @($d.checks) }
                    $n = "$(@($c | Where-Object { $_.ok }).Count)/$($c.Count)"
                }
            } catch { $result = "BAD JSON" }
        }
        $rows += [pscustomobject]@{ skill = $skill; script = $_.Name; result = $result; checks = $n; exit = $exit; sec = [int]$sw.Elapsed.TotalSeconds }
        "{0,-28} {1,-28} {2,-8} {3,-8} {4,-8} {5,4}s" -f $skill, $_.Name, $result, $n, $exit, [int]$sw.Elapsed.TotalSeconds
    }
}
$rows | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $OutRoot "summary.json") -Encoding utf8
"PASS {0} of {1}" -f @($rows | Where-Object { $_.result -eq "PASS" }).Count, $rows.Count
