"""nxf - NX feature helpers for headless NXOpen journals (NX 2206, run_journal).

    import os, sys
    sys.path.insert(0, os.environ["NXH_DIR"])
    import nxh, nxf

One callable per modelling command, ported from the verified example journals of the nx-* skills
(the provenance comment above each function names the script it was measured in). Every function
is exercised by scripts/nxf_selftest.py with a measured check; references/nxf-helpers.md is the
index. House rules, as in nxh:
  * builders are create -> configure -> commit -> Destroy() in finally;
  * every dimension may be a number or an expression formula string ("wall_t", "2*r") unless the
    docstring says NUMBER ONLY;
  * objects (faces, edges, bodies, datum planes) are passed, never names;
  * nothing is cached in module state - re-query faces/edges after every feature;
  * "no exception" proves nothing: measure after each call (nxh.volume, nxh.faces, nxh.dist_to).
"""
import math
import os
import re
import time

import NXOpen
import NXOpen.Features
import NXOpen.GeometricUtilities
import nxh

P, V, UPD, S, UFS, BOOL = nxh.P, nxh.V, nxh.UPD, nxh.S, nxh.UFS, nxh.BOOL
NULL = NXOpen.NXObject.Null
NF = nxh.NULL_FEATURE
GU = NXOpen.GeometricUtilities
SK = NXOpen.Sketch
A = SK.AssocType                      # A.StartPoint / EndPoint / ArcCenter / Midpoint ... for dimensions
CP = SK.ConstraintPointType           # CP.StartVertex / EndVertex / ArcCenter ... for constraints
MT = NXOpen.PlaneTypes.MethodType
BT = NXOpen.Features.Feature.BooleanType
PAT = GU.PatternDefinition.PatternEnum
SPACE = GU.PatternSpacing.SpacingType
SOLID = GU.FeatureOptions.BodyStyle.Solid
SHEET = GU.FeatureOptions.BodyStyle.Sheet
MOTION = GU.ModlMotion.Options
ET = GU.Extend.ExtendType


def _collector(part, objs, kind):
    """ScCollector from a list of faces / edges / bodies, or the collector itself when one is passed."""
    if isinstance(objs, NXOpen.ScCollector):
        return objs
    return nxh.collector(part, **{kind: list(objs)})


def _mid(obj):
    bb = nxh.bbox(obj)
    return ((bb[0] + bb[3]) / 2, (bb[1] + bb[4]) / 2, (bb[2] + bb[5]) / 2)


def _num(part, f):
    """Current numeric value of a number or an expression formula (evaluated through a temporary expression).
    The formula may be a length, an angle (a Degrees expression name) or unitless: the units are tried in turn."""
    try:
        return float(f)
    except (TypeError, ValueError):
        pass
    last = None
    for unit in ("mm", "deg", None):
        try:
            e = part.Expressions.CreateSystemExpressionWithUnits(str(f), nxh.units(part)[unit])
        except NXOpen.NXException as ex:                       # "Dimension error": wrong unit for this formula
            last = ex
            continue
        v = e.Value
        try:
            part.Expressions.Delete(e)
        except Exception:  # noqa: BLE001
            pass
        return v
    raise last


def _direction(part, vec, origin=(0, 0, 0), reverse=False):
    """NXOpen.Direction for a builder. vec = (x, y, z): a FIXED vector. vec = an object: an ASSOCIATIVE direction
    that follows the object - a datum axis or linear edge (along it), a datum plane or planar face (its
    normal), a cylindrical face (its axis); reverse=True flips it. An NXOpen.Direction is passed through."""
    if isinstance(vec, NXOpen.Direction):
        return vec
    if isinstance(vec, (tuple, list)):
        return nxh.direction(part, vec, origin)
    return part.Directions.CreateDirection(vec, NXOpen.Sense.Reverse if reverse else NXOpen.Sense.Forward, UPD)


# ====================================================================== sketches
# verified in nxf_selftest (sketch group, "DOF read-out": free point 0 with the preference on, 2 with it off)
def auto_dimensioning_off():
    """Switch the SESSION preference Continuous Auto Dimensioning off; returns the value it had.

    A batch session starts with it ON (measured on this PC). In a sketch created while it is on, NX closes
    every open degree of freedom with an automatic dimension at Update() and Sketch.GetStatus() answers
    (WellConstrained, 0) whatever is in the sketch - one free point with no constraint included - so "DOF 0"
    proves nothing. With it off the read-out counts only what was really constrained (free point 2, point
    on an axis 1, + one dimension 0).
    A sketch takes the setting over WHEN IT IS CREATED (builder Commit) and keeps it: switching the
    preference afterwards - before Activate, before the geometry, before Update - changes nothing for that
    sketch, in either direction (measured). So new_sketch() calls this before its builder; call it
    yourself before creating a sketch with any other builder (sketch on path, raw SimpleSketchInPlaceBuilder).
    For a sketch that was created with it on, sketch_status() / finish_sketch() count the automatic
    dimensions back in (auto_dimensions). It is a session setting: nothing is written into the part by the
    switch itself, and the next NX session starts with the default again."""
    pr = S.Preferences.Sketch
    was = bool(pr.ContinuousAutoDimensioning)
    if was:
        pr.ContinuousAutoDimensioning = False
    return was


# verified in nxf_selftest (sketch group, "DOF read-out": point 2, line 4, circle 3, H/V rectangle 4, + 2 dimensions 2)
def auto_dimensions(sk):
    """Number of AUTOMATIC dimensions in a sketch (DimensionState == Automatic): what Continuous Auto
    Dimensioning added at Update() to close the degrees of freedom nobody constrained. They carry no
    expression and drive nothing. Each one stands for one open degree of freedom, so the real DOF of a sketch
    is GetStatus() dof + auto_dimensions(sk). 0 for every sketch created with the preference off."""
    n = 0
    for c in sk.GetAllConstraintsOfType(SK.ConstraintClass.Dimension, SK.ConstraintType.NoCon):
        st = getattr(c, "DimensionState", None)
        if st is not None and st == type(c).DimensionStateType.Automatic:
            n += 1
    return n


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py (S1, S2)
def new_sketch(part, plane, haxis, origin, name=None):
    """Sketch on a DatumPlane or a planar Face; the sketch is left ACTIVE (add geometry, then finish_sketch).

    haxis: DatumAxis or linear Edge used as horizontal reference (e.g. nxh.Datums(part).x).
    origin: an NXOpen.Point (Datums.origin, nxh.point(...)); it is projected onto the plane.
    Geometry is created in ABSOLUTE coordinates with part.Curves.* and attached with add().
    Switches Continuous Auto Dimensioning off for the session first (auto_dimensioning_off): the sketch
    takes that setting over at creation, so the DOF read by sketch_status / finish_sketch is a real count.
    Returns the NXOpen.Sketch (its feature is sketch.Feature)."""
    auto_dimensioning_off()
    sb = part.Sketches.CreateSimpleSketchInPlaceBuilder()
    try:
        sb.UseWorkPartOrigin = False
        d = part.Directions.CreateDirection(haxis, NXOpen.Sense.Forward, UPD)
        xf = part.Xforms.CreateXformByPlaneXDirPoint(plane, d, origin, UPD, 0.625, False, False)
        sb.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
        sb.HorizontalReference.Value = haxis
        sk = sb.Commit()
    finally:
        sb.Destroy()
    sk.Activate(SK.ViewReorient.FalseValue)
    if name:
        sk.SetName(name)
        sk.Feature.SetName(name)
    return sk


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py
def cg(geom, pt=None, idx=0):
    """ConstraintGeometry for sk.Create*Constraint. pt: nxf.CP.ArcCenter / StartVertex / EndVertex (None = the curve)."""
    g = SK.ConstraintGeometry()
    g.Geometry = geom
    g.PointType = pt if pt is not None else CP.NotSet
    g.SplineDefiningPointIndex = idx
    return g


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py
def dg(geom, assoc=None, hp=None):
    """DimensionGeometry for sk.CreateDimension. assoc: nxf.A.StartPoint / EndPoint / ArcCenter (None = the curve);
    hp: a Point3d on the object near the wanted end (needed for datum axes and long references)."""
    d = SK.DimensionGeometry()
    d.Geometry = geom
    d.AssocType = assoc if assoc is not None else A.NotSet
    d.AssocValue = 0
    d.HelpPoint = hp if hp is not None else P(0, 0, 0)
    d.View = NULL
    return d


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py (S2 point-on-curve)
def help_at(p):
    """ConstraintGeometryHelp at Point3d p - the third argument of CreatePointOnCurveConstraint / tangent constraints."""
    h = SK.ConstraintGeometryHelp()
    h.Type = SK.ConstraintGeometryHelpType.Point
    h.Point = p
    h.Parameter = 0.0
    return h


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py
def add(sk, *curves, infer=True):
    """Attach curves made with part.Curves.* to the active sketch. infer=True adds coincident constraints
    between touching end points (use it for chained lines); infer=False for circles and isolated curves."""
    opt = SK.InferConstraintsOption.InferCoincidentConstraints if infer else SK.InferConstraintsOption.InferNoConstraints
    for c in curves:
        sk.AddGeometry(c, opt)


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py (hv constraints of S1)
def horizontal(sk, *lines):
    """Horizontal constraint on each line (parallel to the sketch horizontal reference)."""
    for ln in lines:
        sk.CreateHorizontalConstraint(cg(ln))


def vertical(sk, *lines):
    """Vertical constraint on each line."""
    for ln in lines:
        sk.CreateVerticalConstraint(cg(ln))


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py
def pdim(sk, ref, ref_help, geom, assoc, origin, formula):
    """Perpendicular distance from a line-like reference (datum axis, line, projected edge) to a point of geom.

    ref_help: Point3d ON the reference; assoc: which point of geom (A.StartPoint, A.ArcCenter ...);
    origin: Point3d where the dimension text sits (any point, it also decides nothing geometric);
    formula: expression text. Returns the dimension constraint (.AssociatedExpression is its expression).
    geom may be a point outside the sketch (assoc None). 'Invalid object type' on the SECOND dimension to one
    smart point means a new-solver sketch (legacy_solver): dimension to sketch_anchor(part, sk, point) instead."""
    c = sk.CreateDimension(SK.ConstraintType.PerpendicularDim, dg(ref, None, ref_help), dg(geom, assoc), origin,
                           NXOpen.Expression.Null)
    c.AssociatedExpression.RightHandSide = str(formula)
    return c


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py
def diameter_dim(sk, arc, on_arc, origin, formula):
    """Diameter dimension of a circle/arc. on_arc: Point3d on the arc; origin: text position."""
    c = sk.CreateDiameterDimension(dg(arc, None, on_arc), origin, NXOpen.Expression.Null)
    c.AssociatedExpression.RightHandSide = str(formula)
    return c


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py
def radius_dim(sk, arc, on_arc, origin, formula):
    """Radius dimension of an arc/circle."""
    c = sk.CreateRadialDimension(dg(arc, None, on_arc), origin, NXOpen.Expression.Null)
    c.AssociatedExpression.RightHandSide = str(formula)
    return c


def sketch_to3d(sk):
    """Function (u, v) -> Point3d mapping sketch coordinates to absolute, from sk.Origin / sk.Orientation."""
    o, m = sk.Origin, sk.Orientation.Element
    return lambda u, v: P(o.X + u * m.Xx + v * m.Yx, o.Y + u * m.Xy + v * m.Yy, o.Z + u * m.Xz + v * m.Yz)


# verified in the acceptance builds (acc_lib.hv_polygon: enclosure + knob, 221 checks)
def hv_polygon(part, sk, pts, to3d=None):
    """Closed polygon of alternating horizontal / vertical lines with coincident corners and H/V constraints.

    pts: 2D sketch coordinates in order; to3d(u, v) -> Point3d (default: sketch_to3d(sk)).
    Leaves one DOF per independent edge position: add pdim() for each. Returns the lines in order
    (line i runs pts[i] -> pts[i+1])."""
    to3d = to3d or sketch_to3d(sk)
    n = len(pts)
    ls = [part.Curves.CreateLine(to3d(*pts[i]), to3d(*pts[(i + 1) % n])) for i in range(n)]
    add(sk, *ls)
    for i, ln in enumerate(ls):
        if abs(pts[i][1] - pts[(i + 1) % n][1]) < 1e-9:
            horizontal(sk, ln)
        else:
            vertical(sk, ln)
    return ls


def sketch_uv(sk, pt):
    """(u, v) sketch coordinates of the projection of an NXOpen.Point / Point3d onto the sketch plane - the
    inverse of sketch_to3d(sk)(u, v). Use it to place sketch geometry relative to a point given in 3D (a hinge
    point, a linked arc centre, the start of a path)."""
    c = pt.Coordinates if isinstance(pt, NXOpen.Point) else pt
    o, m = sk.Origin, sk.Orientation.Element
    d = (c.X - o.X, c.Y - o.Y, c.Z - o.Z)
    return d[0] * m.Xx + d[1] * m.Xy + d[2] * m.Xz, d[0] * m.Yx + d[1] * m.Yy + d[2] * m.Yz


_sketch_uv = sketch_uv                                   # the old private name, kept for existing journals


def _in_sketch(sk, obj):
    try:
        return obj.Tag in {g.Tag for g in sk.GetAllGeometry()}
    except Exception:  # noqa: BLE001
        return False


def _point_assoc(sk, pt):
    """AssocType a dimension needs for the point `pt`: a point that is GEOMETRY OF THE SKETCH must be addressed
    as StartPoint (with NotSet the dimension is refused); a datum CSYS origin, a smart or linked point takes None."""
    return A.StartPoint if _in_sketch(sk, pt) else None


# verified in nxf_selftest (sketch group, "inclined plane" and "new solver")
def legacy_solver(sk):
    """True when the sketch is solved by the LEGACY solver, False for the solver NX 2206 uses interactively
    (Sketch.UsesLegacySolver). The sketch plane and the builder have no say in it; the part has. Measured:
    every new part of a batch session is legacy (template, sheet metal template, blank part; all three sketch
    builders; also after save / close / reopen); a part that was modelled in the NX 2206 user interface held
    28 new-solver sketches out of 28 and every sketch a journal added to it was new-solver too - until all of
    its features were deleted, then a new sketch was legacy again. Sketch.UpgradeUponActivation = True did not
    convert a legacy sketch in batch. What differs for a journal in a NEW-solver sketch:
      * a smart point (nxh.point) can be referenced by ONE constraint or dimension. The second reference - any
        kind: CreateDimension, Midpoint, Coincident, PointOnCurve, 36 of 36 combinations - raises
        'Invalid object type'. Being the sketch origin does not count as a reference. The datum CSYS origin, a
        point FEATURE and a point of the sketch itself take any number. Use sketch_anchor.
      * sk.Update() does not re-solve the active sketch (a line stayed at 40 under a dimension of 13;
        GetStatus() says NotEvaluated). sk.LocalUpdate() does; finish_sketch() calls it.
    The plane makes no difference. Legacy: principal planes, datum planes at 30 / 45 degrees and chamfer faces
    behave alike, with the point in the plane or up to 1 mm off it (no refusal in 744 trial sketches). New solver:
    the same refusal on the XY and YZ datum planes, on a 45 degree wall face and on a datum plane on that face."""
    try:
        return bool(sk.UsesLegacySolver)
    except Exception:  # noqa: BLE001
        return True


ANCHOR = "NXF_ANCHOR"       # name of the reference points sketch_anchor() adds


# verified in nxf_selftest (sketch group, "inclined plane" and "new solver")
def sketch_anchor(part, sk, point, force=False):
    """The point that constraints and dimensions of the ACTIVE sketch `sk` may reference for `point` as often
    as they like. In a legacy-solver sketch, and for a point of the sketch itself, that is `point`: it is
    returned unchanged and nothing is added. In a NEW-solver sketch (legacy_solver), where the second reference
    to a smart point is refused with 'Invalid object type', it adds ONE sketch point at the projection of
    `point`, makes it coincident with `point` (the single reference a smart point allows), converts it to a
    REFERENCE point and names it nxf.ANCHOR; that sketch point is returned. It adds no DOF, follows `point`
    and - being reference geometry - is left out of a whole-sketch section (nxh.section_feature), which an
    ACTIVE sketch point is not. Calling it again for the same point returns the same anchor (found by name
    and position), so several helpers share one external point. force=True makes the anchor in a legacy
    sketch as well.
    Every external point gets an anchor in a new-solver sketch, the datum CSYS origin included: a smart point
    that is the sketch origin is reported as owned by the sketch's datum CSYS, so the two cannot be told apart.
    Code that collects 'the points of the sketch' (hole positions) must skip objects named nxf.ANCHOR.
    Raises RuntimeError when the smart point is already referenced once by a constraint of this sketch: call
    sketch_anchor() BEFORE the first constraint on that point and reference the anchor instead."""
    if _in_sketch(sk, point) or (legacy_solver(sk) and not force):
        return point
    p = sketch_to3d(sk)(*sketch_uv(sk, point))
    for g in sk.GetAllGeometry():
        if isinstance(g, NXOpen.Point) and g.Name == ANCHOR:
            c = g.Coordinates
            if abs(c.X - p.X) + abs(c.Y - p.Y) + abs(c.Z - p.Z) < 1e-6:
                return g
    sp = part.Points.CreatePoint(p)
    add(sk, sp, infer=False)
    try:
        sk.CreateCoincidentConstraint(cg(sp), cg(point))
    except NXOpen.NXException as ex:
        raise RuntimeError("sketch_anchor: %s - this new-solver sketch already references the point once; "
                           "create the anchor before the first constraint on it" % ex) from ex
    to_reference(part, [sp])
    sp.SetName(ANCHOR)
    return sp

# verified in nxf_selftest (sketch group) and nxa_selftest (circle on a linked arc-centre point)
def sketch_circle(part, sk, centre, diameter):
    """Fully constrained circle in the ACTIVE sketch: centre coincident with `centre`, an NXOpen.Point (datum
    CSYS origin, nxh.point, a sketch point, or a linked arc-centre point from nxa.arc_centre_points - the point
    may lie OUT of the sketch plane, its projection is used), diameter driven by a formula. Adds no DOF: the
    circle follows the point. Returns the arc.
    Works on any plane (measured on principal planes, datum planes at 30 / 45 degrees, chamfer faces, with the
    point up to 1 mm off the plane). In a NEW-solver sketch (legacy_solver) a smart point takes one reference
    only, so the circle is tied to sketch_anchor(part, sk, centre) - a reference point coincident with
    `centre`, the same one for every helper called on that centre; in a legacy sketch nothing is added."""
    anchor = sketch_anchor(part, sk, centre)
    u, v = _sketch_uv(sk, centre)
    to3d, m = sketch_to3d(sk), sk.Orientation.Element
    r = _num(part, diameter) / 2.0
    arc = part.Curves.CreateArc(to3d(u, v), V(m.Xx, m.Xy, m.Xz), V(m.Yx, m.Yy, m.Yz), r, 0.0, 2 * math.pi)
    add(sk, arc, infer=False)
    sk.CreateCoincidentConstraint(cg(arc, CP.ArcCenter), cg(anchor))
    diameter_dim(sk, arc, to3d(u + r, v), to3d(u + 2 * r, v + 2 * r), diameter)
    return arc


# verified in nxf_selftest (sketch group)
def sketch_rect_centered(part, sk, centre, width, height):
    """Fully constrained rectangle in the ACTIVE sketch, centred on `centre` (an NXOpen.Point, see
    sketch_circle): width along the sketch horizontal, height along the vertical, both formulas. Four H/V
    lines (hv_polygon) and four perpendicular dimensions line -> point of width/2 or height/2: no DOF left,
    the rectangle follows the point and the two expressions. Returns the lines [bottom, right, top, left] -
    the profile for nxh.section_region(part, sk, seed, curves=lines) or nxh.section(part, curves=lines).
    The plane does not matter (inclined datum planes and chamfer faces measured, point in or off the plane).
    The SOLVER does: the four dimensions are four references to `centre`, and a new-solver sketch
    (legacy_solver: every sketch of a part modelled in the NX user interface) refuses the second one to a smart
    point with 'Invalid object type'. There the dimensions go to sketch_anchor(part, sk, centre) instead - one
    reference point coincident with `centre`, DOF still 0, not part of a whole-sketch section; call
    sketch_anchor(part, sk, centre) to get it. In a legacy sketch nothing is added."""
    anchor = sketch_anchor(part, sk, centre)
    u, v = _sketch_uv(sk, centre)
    to3d = sketch_to3d(sk)
    w, h = _num(part, width) / 2.0, _num(part, height) / 2.0
    ls = hv_polygon(part, sk, [(u - w, v - h), (u + w, v - h), (u + w, v + h), (u - w, v + h)], to3d)
    assoc = _point_assoc(sk, anchor)                      # a point of this sketch needs StartPoint
    for ln, mid, f in ((ls[1], (u + w, v), width), (ls[3], (u - w, v), width), (ls[0], (u, v - h), height),
                       (ls[2], (u, v + h), height)):
        pdim(sk, ln, to3d(*mid), anchor, assoc, to3d((u + mid[0]) / 2, (v + mid[1]) / 2), "(%s)/2" % f)
    return ls


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py (status_of)
def sketch_status(sk):
    """(status name, dof). GetStatus() returns an int-like enum (str() gives '3'), so it is mapped by comparison.
    A fully constrained sketch is ('WellConstrained', 0). Call sk.Update() first: the status is the one of
    the last solve.
    The answer is a REAL count: Continuous Auto Dimensioning is switched off for the sketches that follow
    (auto_dimensioning_off), and for a sketch that was created while it was on - where GetStatus() says
    (WellConstrained, 0) whatever is in it - the automatic dimensions are counted back in:
    ('UnderConstrained', dof + auto_dimensions(sk))."""
    auto_dimensioning_off()
    st, dof = sk.GetStatus()
    name = [n for n in nxh.enum_names(SK.Status) if getattr(SK.Status, n) == st]
    n_auto = auto_dimensions(sk)
    if n_auto:
        return "UnderConstrained", dof + n_auto
    return (name[0] if name else str(st)), dof


# verified in nx-curves-and-sketches/scripts/sketch_recipes.py (finish)
def finish_sketch(sk):
    """Solve, read the status, leave the sketch. Returns {"status", "dof", "auto_dims", "n_geom", "dims"};
    assert status == "WellConstrained" and dof == 0 for a design sketch.
    dof counts the degrees of freedom that are really open: one free point gives ('UnderConstrained', 2),
    not 0 (see sketch_status). auto_dims is 0 for a sketch made by new_sketch(); it is the number of automatic
    dimensions NX added when the sketch was created with Continuous Auto Dimensioning on.
    A new-solver sketch (legacy_solver) is solved with LocalUpdate() first: Update() alone leaves it as drawn,
    and a dimension whose value differs from the drawn geometry then reads 'InconsistentlyConstrained'."""
    auto_dimensioning_off()
    if not legacy_solver(sk):
        sk.LocalUpdate()
    sk.Update()
    try:
        sk.CalculateStatus()
    except Exception:  # noqa: BLE001
        pass
    status, dof = sketch_status(sk)
    n_auto = auto_dimensions(sk)
    sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
    return {"status": status, "dof": dof, "auto_dims": n_auto, "n_geom": len(sk.GetAllGeometry()),
            "dims": [f"{e.Name}={e.RightHandSide}" for e in sk.GetAllExpressions()]}


# verified in nx-solid-features/scripts/molded_tray.py (sketch_with_lines)
def sketch_lines(part, plane, haxis, origin, segments, name=None):
    """Unconstrained sketch holding plain lines [((x,y,z), (x,y,z)), ...] - the quick section for rib() ("a
    linear section must be from a sketch"). Returns the finished (inactive) sketch."""
    sk = new_sketch(part, plane, haxis, origin, name)
    for a, b in segments:
        sk.AddGeometry(nxh.line(part, a, b), SK.InferConstraintsOption.InferNoConstraints)
    sk.Update()
    sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
    return sk


# ====================================================================== datums
_PLANE_KINDS = {"offset": MT.Distance, "angle": MT.Angle, "three_points": MT.ThreePoints, "bisector": MT.Center,
                "coincident": MT.Coincident, "tangent": MT.Tangent, "on_curve": MT.Frenet}


# verified in nx-curves-and-sketches/scripts/datum_recipes.py (D1-D8)
def datum_plane(part, kind, geom, value=None, name=None, flip=False):
    """Associative datum plane. Returns (feature, DatumPlane).

    kind / geom / value:
      "offset"        [datum plane or planar face]   offset formula (0 = on the face; + along its normal)
      "angle"         [plane, datum axis or edge]    angle formula in degrees about that axis
      "three_points"  [point, point, point]          nxh.point(...) objects
      "bisector"      [face, face]                   mid plane of two parallel faces
      "coincident"    [planar face]
      "tangent"       [cylindrical face]             ONE object only ([cyl, plane] is 'Datum plane undefinable')
      "on_curve"      [edge or curve]                percent of the curve length; the plane is normal to the curve
    flip=True reverses the plane NORMAL only (the position stays). For a fixed plane from origin + normal use
    nxh.datum_plane()."""
    b = part.Features.CreateDatumPlaneBuilder(NF)
    try:
        pl = b.GetPlane()
        pl.SetUpdateOption(UPD)
        pl.SetMethod(_PLANE_KINDS[kind])
        pl.SetGeometry(list(geom))
        pl.SetFlip(flip)
        if kind == "on_curve":
            pl.SetPercent(True)
        if value is not None:
            pl.Expression.RightHandSide = str(value)
        pl.Evaluate()
        f = b.CommitFeature()
    finally:
        b.Destroy()
    if name:
        f.SetName(name)
    return f, f.DatumPlane


# verified in nx-curves-and-sketches/scripts/datum_recipes.py (A1-A4)
def datum_axis(part, kind, a, b=None, name=None):
    """Associative datum axis. Returns (feature, DatumAxis).

    kind: "point_dir"    a = (x, y, z) origin (formulas allowed), b = (dx, dy, dz)
          "two_points"   a, b = (x, y, z)
          "face_axis"    a = cylindrical face (its axis)
          "intersection" a, b = two datum planes / planar faces"""
    AX = NXOpen.Features.DatumAxisBuilder
    bld = part.Features.CreateDatumAxisBuilder(NF)
    try:
        bld.IsAssociative = True
        if kind == "point_dir":
            bld.Type = AX.Types.PointAndDir
            bld.Point = nxh.point(part, *a)
            bld.Vector = nxh.direction(part, b)
        elif kind == "two_points":
            bld.Type = AX.Types.TwoPoints
            bld.Point1 = nxh.point(part, *a)
            bld.Point2 = nxh.point(part, *b)
        elif kind == "face_axis":
            bld.Type = AX.Types.CurveOrFaceAxis
            bld.CurveOrFace.Value = a
        elif kind == "intersection":
            bld.Type = AX.Types.Intersection
            bld.Object1.Value = a
            bld.Object2.Value = b
        else:
            raise ValueError("datum_axis kind: " + str(kind))
        f = bld.CommitFeature()
    finally:
        bld.Destroy()
    if name:
        f.SetName(name)
    return f, f.DatumAxis


# ====================================================================== solid features
# verified in nx-solid-features/scripts/revolve_examples.py
def axis_from(part, obj):
    """NXOpen.Axis from a datum axis, a line, a linear edge or a cylindrical face (its own axis).

    Only the DIRECTION LINE is reliable: the axis is created with Point.Null, so its origin is the anchor NX
    keeps for that object, which need not be where you expect. Measured: the datum CSYS Z axis of a fresh
    template part gives origin (0, 0, 0) (a Cylinder on it spans z 0..20), but in acceptance build 3 the same
    call on a datum axis put a Cylinder at z = -91 (x, y right). So use axis_from where only the line matters
    (Revolve, pattern axis, Move Object / Move Face rotation). When the origin matters (Cylinder / Cone base
    point) give it explicitly: nxh.axis(part, origin, vec), or
    part.Axes.CreateAxis(point, part.Directions.CreateDirection(obj, NXOpen.Sense.Forward, UPD), UPD)
    with point = nxh.point(part, x, y, z) or any associative NXOpen.Point."""
    d = part.Directions.CreateDirection(obj, NXOpen.Sense.Forward, UPD)
    return part.Axes.CreateAxis(NXOpen.Point.Null, d, UPD)


# verified in nx-solid-features/scripts/revolve_examples.py
def revolve(part, sec, ax, start=0, end=360, op=None, target=None, sheet=False, offset=None):
    """Revolve a section about an NXOpen.Axis (nxh.axis / axis_from). start/end in degrees (formulas allowed).

    Tolerance is set to 0.01 (batch default 0). An OPEN profile turned 360 deg is capped into a solid unless
    sheet=True. offset=(start, end) gives a thin wall from an open or closed profile. op: BOOL.Create /
    Unite / Subtract / Intersect with target. Returns the feature (body: f.GetBodies()[0] for Create)."""
    b = part.Features.CreateRevolveBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.Section = sec
        b.Axis = ax
        b.Limits.StartExtend.Value.RightHandSide = str(start)
        b.Limits.EndExtend.Value.RightHandSide = str(end)
        op = BOOL.Create if op is None else op
        b.BooleanOperation.Type = op
        if op != BOOL.Create:
            b.BooleanOperation.SetTargetBodies([target])
        if sheet:
            b.FeatureOptions.BodyType = SHEET
        if offset is not None:
            b.Offset.Option = GU.Type.NonsymmetricOffset
            b.Offset.StartOffset.RightHandSide = str(offset[0])
            b.Offset.EndOffset.RightHandSide = str(offset[1])
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-solid-features/scripts/detail_features.py (extrude limits) + recipes "Extrude: limits, thin wall"
def extrude_ex(part, sec, vec, start=0, end=None, op=None, target=None, symmetric=False, through_all=False,
               until=None, until_next=False, thin=None, draft=None, sheet=False, origin=(0, 0, 0), reverse=False,
               single_offset=None):
    """Extrude with the options nxh.extrude does not have. Returns the feature.

    vec                 (x, y, z) = fixed vector; or an OBJECT for an associative direction that follows it: a
                        datum axis / linear edge, a datum plane / planar face (its normal), a cylindrical face
                        (its axis), an NXOpen.Direction. reverse=True flips an object direction. Use it for
                        inclined ports and bosses: the feature turns with the datum plane it is sketched on.
    symmetric=True      `end` is the TOTAL length, centred on the section plane (5 -> -2.5 .. +2.5)
    through_all=True    end limit Through All (cuts)
    until=face          end limit Until Selected (a face or datum plane)
    until_next=True     end limit Until Next
    thin=(a, b)         thin wall: offsets of the profile (works on OPEN profiles: (0, 2) -> 2 mm wall, solid)
    single_offset=d     the CLOSED profile itself is offset by d before it is extruded (Offset = Single-Sided): a
                        pocket 5 inside the edges of a face without a sketch. Which sign goes inward depends on
                        the section: measure the volume and flip the sign if it grew the wrong way.
    draft=angle         draft from the profile; positive shrinks the section along vec (degrees)
    sheet=True          sheet body even for a closed section"""
    b = part.Features.CreateExtrudeBuilder(NF)
    try:
        b.Section = sec
        b.Direction = _direction(part, vec, origin, reverse)
        op = BOOL.Create if op is None else op
        b.BooleanOperation.Type = op
        if op != BOOL.Create:
            b.BooleanOperation.SetTargetBodies([target])
        if symmetric:
            b.Limits.SymmetricOption = True
            b.Limits.EndExtend.Value.RightHandSide = str(end)
        else:
            b.Limits.StartExtend.Value.RightHandSide = str(start)
            if through_all:
                b.Limits.EndExtend.TrimType = ET.ThroughAll
            elif until is not None:
                b.Limits.EndExtend.TrimType = ET.UntilSelected
                b.Limits.EndExtend.Target = until
            elif until_next:
                b.Limits.EndExtend.TrimType = ET.UntilNext
            else:
                b.Limits.EndExtend.Value.RightHandSide = str(end)
        if thin is not None:
            b.Offset.Option = GU.Type.NonsymmetricOffset
            b.Offset.StartOffset.RightHandSide = str(thin[0])
            b.Offset.EndOffset.RightHandSide = str(thin[1])
        if single_offset is not None:
            b.Offset.Option = GU.Type.SingleOffset
            b.Offset.EndOffset.RightHandSide = str(single_offset)
        if draft is not None:
            b.Draft.DraftOption = GU.SimpleDraft.SimpleDraftType.SimpleFromProfile
            b.Draft.FrontDraftAngle.RightHandSide = str(draft)
        if sheet:
            b.FeatureOptions.BodyType = SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-solid-features/scripts/molded_tray.py
def shell(part, body, removed_faces, thickness, inward=True, alternate=(), pierce=None):
    """Shell a solid. removed_faces: faces that become openings ([] = closed hollow body).
    pierce=True / False sets TgtPierceOption ("shelf face at tangent edge": how a removed face is opened whose
    edge is TANGENT to its neighbour); None leaves the builder default.

    inward=True  -> DefaultThicknessFlip=True (builder default, the user's habit): the wall grows INTO the body,
                    the outside size stays. inward=False adds the wall outside.
    alternate: [(faces, thickness formula), ...] - other thickness on those walls (ItemFlipFlag follows inward,
    otherwise the alternate wall goes the other way).
    b.Body is mandatory ('Invalid shell data') and Tolerance defaults to 0. A wall thicker than the part fails
    silently on update: check the volume dropped. Returns the feature."""
    b = part.Features.CreateShellBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.Body = body
        if removed_faces:
            b.RemovedFacesCollector = _collector(part, removed_faces, "faces")
        b.DefaultThickness.RightHandSide = str(thickness)
        b.DefaultThicknessFlip = bool(inward)
        if pierce is not None:
            b.TgtPierceOption = bool(pierce)
        for faces, t in alternate:
            ecs = part.CreateExpressionCollectorSet(nxh.collector(part, faces=faces), str(t), "MilliMeter", 0)
            ecs.ItemFlipFlag = bool(inward)
            b.FaceThicknesses.Append(ecs)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-solid-features/scripts/molded_tray.py (+ sign table in nx-solid-features recipes)
def draft_faces(part, faces, pull, angle, stationary_faces=None, stationary_datum=None, link=None):
    """Face draft from a stationary face (list of connected faces) or a stationary datum plane (pivot).
    ONE-sided (references method Stationary Face). Both sides of a parting reference, with one or two angles:
    draft_parting; edges that must stay: draft_edges; a parting line of edges: draft_parting_edges.

    Sign rule: a positive angle makes the cross-section SHRINK along +pull from the stationary reference
    (stationary bottom + pull +Z + 5 deg -> the top gets smaller; stationary top + pull -Z -> the bottom shrinks).
    angle: NUMBER ONLY (an expression name here crashes the commit). To drive it by an expression pass
    link="name" where name is a UNITLESS expression (nxh.expr(part, "draft_n", "draft_a", None)); a degree
    expression raises 'Dimension error'. Returns (feature, angle expression)."""
    DB = NXOpen.Features.DraftBuilder
    b = part.Features.CreateDraftBuilder(NF)
    try:
        b.TypeOfDraft = DB.Type.Face
        b.AngleTolerance = 0.1
        b.DistanceTolerance = 0.01
        b.Direction = nxh.direction(part, pull)
        b.DraftReferencesMethod = DB.DraftReferencesMethods.StationaryFace
        rf = part.ScRuleFactory
        rule = rf.CreateRuleFaceDumb(list(stationary_faces)) if stationary_faces else rf.CreateRuleFaceDatum([stationary_datum])
        b.StationaryReference.ReplaceRules([rule], False)
        ecs = part.CreateExpressionCollectorSet(nxh.collector(part, faces=list(faces)), str(float(angle)), "Degrees", 0)
        b.FaceSetAngleExpressionList.Append(ecs)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    e = f.GetExpressions()[0]
    if link:
        e.RightHandSide = str(link)
        nxh.update()
    return f, e


# verified in nx-solid-features/scripts/course_checks.py (c_draft_body)
def draft_body(part, faces, parting_plane, pull, angle, match=None, extreme=False, true_draft=False):
    """Two-sided draft about a parting DatumPlane: the extreme (top/bottom) edges stay and the body gets WIDER
    towards the parting plane, each side tapering away from it. angle: number or the name of a DEGREE expression
    (unlike draft_faces); only positive angles work; the sign of pull does not matter.
    match: None | "FromEdges" | "TangentToFace" | "ToIsocline" (scope All) - with a match type the faces of the
    two sides MEET at an off-centre parting plane (the shorter side gets steeper); without it a ledge stays.
    extreme=True: ExtremeFacePointOverridesStationary; true_draft=True: method True Draft instead of Isocline.
    Returns the feature."""
    DBB = NXOpen.Features.DraftBodyBuilder
    b = part.Features.CreateDraftBodyBuilder(NF)
    try:
        b.Type = DBB.Types.Faces
        b.Tolerance = 0.01
        b.PartingObject.Value = parting_plane
        b.DrawDirection = nxh.direction(part, pull)
        b.FacesToDraft.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        b.DraftAngle.RightHandSide = str(angle)
        if match:
            b.MatchType = getattr(DBB.MatchingType, match)
            b.MatchScope = DBB.MatchingScope.All
        if extreme:
            b.ExtremeFacePointOverridesStationary = True
        if true_draft:
            b.DraftMethod = DBB.Method.TrueDraft
        return b.CommitFeature()
    finally:
        b.Destroy()


def _rib(part, body, sketch, help_point, perpendicular, thickness, reverse, draft_deg):
    RB = NXOpen.Features.RibBuilder
    b = part.Features.DesignFeatureCollection.CreateRibBuilder(NXOpen.Features.Rib.Null)
    try:
        b.TargetBody.ReplaceRules([part.ScRuleFactory.CreateRuleBodyDumb([body], True)], False)
        sec = b.Section
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        sec.AddToSection([part.ScRuleFactory.CreateRuleCurveFeature([sketch.Feature])], NULL, NULL, NULL,
                         P(*help_point), NXOpen.Section.Mode.Create, False)
        b.RibType = RB.RibTypes.PerpendiculartoSectionPlane if perpendicular else RB.RibTypes.ParalleltoSectionPlane
        b.RibThickness.RightHandSide = str(thickness)
        b.RibThicknessOffsetOption = RB.RibThicknessOffsetOptions.Symmetric
        b.ReverseRibDirection = bool(reverse)
        b.CombineRibWithTarget = True
        if draft_deg is not None:
            b.RibDraftOption = RB.RibDraftOptions.FromCap
            b.DraftAngle.RightHandSide = str(draft_deg)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-solid-features/scripts/molded_tray.py (rib, rib_try)
def rib(part, body, sketch, help_point, thickness, reverse=None, draft_deg=None):
    """Rib 'Perpendicular to Section Plane' from an OPEN sketch profile (the sketch plane is the rib cap; the
    open ends are extended to the walls).

    The section MUST be a sketch (dumb curves: 'A linear section must be from a sketch') - use sketch_lines().
    help_point: a point on the profile. A rib that points away from the material fails with 'The target cannot
    properly cap the open profile smart volume': reverse=None tries ReverseRibDirection True, then False
    (rolling back in between); pass True/False to force it. draft_deg: draft from the cap (thickness holds at
    the cap). Returns the feature; check the volume grew and the part is still one solid."""
    if reverse is not None:
        return _rib(part, body, sketch, help_point, True, thickness, reverse, draft_deg)
    last = None
    for rev in (True, False):
        m = nxh.mark("rib attempt", False)
        try:
            return _rib(part, body, sketch, help_point, True, thickness, rev, draft_deg)
        except NXOpen.NXException as e:
            last = e
            nxh.undo_to(m)
    raise last


# verified in nx-solid-features/scripts/course_checks.py (gusset_rib) + acceptance build 3 (offset plane, pdim route)
def gusset_rib(part, body, datums, plane_origin, plane_normal, a, b, toward, thickness, info=None, plane=None):
    """Rib 'Parallel to Section Plane' (gusset) from ONE open line a-b lying in the plane (origin, normal).

    Direction rule: the material grows towards (line direction) x (sketch normal); ReverseRibDirection has NO
    effect for this rib type. So `toward` is any point on the wanted side (e.g. the inside corner) and the
    helper draws the line in the direction that puts the rib there (it reads the sketch's own normal, so the
    sign of plane_normal does not matter). The thickness is symmetric about the plane.

    Principal plane normal (+/-X, +/-Y or +/-Z) - the associative route:
      * the plane is a datum plane OFFSET from the datum YZ / XZ / XY plane by plane_origin[k] (k = the normal's
        axis), which may be a formula ("gus_x");
      * the horizontal reference is the datum Y axis for a +/-X plane and the datum X axis otherwise (a
        reference parallel to the normal raises 'Vectors are parallel.');
      * the coordinates of a and b may be formulas; the line is dimensioned to the datum axes with four pdim
        (a zero coordinate becomes a point-on-axis constraint) -> the sketch is fully constrained (DOF 0) and
        the rib follows the expressions.
    Any other normal: a fixed datum plane and an unconstrained line (numbers only).
    plane=<existing DatumPlane or planar Face> (e.g. nxf.datum_plane("offset", [linked face], "gap")): the
    sketch goes on that plane and the rib follows it; plane_origin / plane_normal are then ignored (pass
    None). The sketch is fully constrained when that plane's normal is principal.
    datums: nxh.Datums(part). info: optional dict that receives {"status", "dof", "sketch", "plane"}.
    Returns the rib feature. (nxf.rib takes the caller's sketch, so its plane is already the caller's choice.)"""
    if plane is None:
        n = [float(x) for x in plane_normal]
    elif isinstance(plane, NXOpen.Face):
        n = list(nxh.face_data(plane)[2])
    else:
        n = [plane.Normal.X, plane.Normal.Y, plane.Normal.Z]
    k = max(range(3), key=lambda i: abs(n[i]))
    principal = all(abs(n[i]) < 1e-9 for i in range(3) if i != k)
    fa, fb = list(a), list(b)
    va, vb = [_num(part, x) for x in fa], [_num(part, x) for x in fb]
    if principal:
        haxis = datums.y if k == 0 else datums.x
        if plane is None:
            base = (datums.yz, datums.xz, datums.xy)[k]
            off = plane_origin[k]
            if base.Normal.X + base.Normal.Y + base.Normal.Z < 0:
                off = "-(%s)" % off
            plane = datum_plane(part, "offset", [base], off)[1]
    else:
        haxis = datums.y if abs(n[0]) > 0.9 * math.sqrt(sum(x * x for x in n)) else datums.x
        if plane is None:
            plane = nxh.datum_plane(part, [_num(part, x) for x in plane_origin], n)[1]
    sk = new_sketch(part, plane, haxis, datums.origin)
    m = sk.Orientation.Element
    nz = (m.Zx, m.Zy, m.Zz)
    d = [q - p for p, q in zip(va, vb)]
    side = (d[1] * nz[2] - d[2] * nz[1], d[2] * nz[0] - d[0] * nz[2], d[0] * nz[1] - d[1] * nz[0])
    if sum(s_ * (_num(part, t) - p) for s_, t, p in zip(side, toward, va)) < 0:
        fa, fb, va, vb = fb, fa, vb, va
    ln = part.Curves.CreateLine(P(*va), P(*vb))
    sk.AddGeometry(ln, SK.InferConstraintsOption.InferNoConstraints)
    if principal:
        axes = (datums.x, datums.y, datums.z)
        on_axis = (P(50, 0, 0), P(0, 50, 0), P(0, 0, 50))
        u, v = [i for i in range(3) if i != k]
        for assoc, vertex, pf, pv in ((A.StartPoint, CP.StartVertex, fa, va), (A.EndPoint, CP.EndVertex, fb, vb)):
            for i, j in ((u, v), (v, u)):                  # coordinate i = distance from the datum axis j
                if abs(pv[i]) < 1e-9:
                    sk.CreatePointOnCurveConstraint(cg(ln, vertex), cg(axes[j]), help_at(P(*pv)))
                else:
                    pdim(sk, axes[j], on_axis[j], ln, assoc, P(*pv), str(pf[i]) if pv[i] > 0 else "-(%s)" % pf[i])
    r = finish_sketch(sk)
    if info is not None:
        info.update({"status": r["status"], "dof": r["dof"], "sketch": sk, "plane": plane})
    return _rib(part, body, sk, va, False, thickness, False, None)


# verified in nx-solid-features/scripts/detail_features.py (tangent_edges)
def tangent_edges(part, seed):
    """ScCollector with the whole tangent-continuous edge chain through one seed edge (selection intent
    'Tangent Curves'); accepted wherever edge lists are (edge_blend chainsets, chamfer)."""
    sc = part.ScCollectors.CreateCollector()
    sc.ReplaceRules([part.ScRuleFactory.CreateRuleEdgeTangent(seed, NXOpen.Edge.Null, False, 0.5, False, False)], False)
    return sc


# verified in nx-patterns-and-body-ops/scripts/community_checks.py (C2) and nxf_selftest
def feature_intersection_edges(part, features):
    """ScCollector with the rule 'Feature Intersection Edges': the edges where these features meet the rest of the
    body - e.g. the root edge of every tool united by ONE Unite. The rule is re-evaluated at every update, so a
    blend built on it follows a changing tool count (an explicit edge list does not: new instances stay
    unblended, without an error).
    The body-copy route it serves (measured 3 -> 5 bosses, 5 blended roots): tool body -> pattern_geometry ->
    nxh.unite(part, target, tool_features=[f_tool, f_pattern]) -> edge_blend on feature_intersection_edges(part,
    [that Unite]). Accepted features: body-making and boolean features (Extrude, Unite ...). A Pattern Feature
    or Pattern Geometry feature in the list raises "Third parameter is invalid", and the SEED of a Pattern
    Feature gives the seed's own root only (measured: 1 of 5) - for Pattern Feature put the blend INTO the
    pattern set instead: pattern_linear(part, [f_boss, f_blend], ...).
    Accepted wherever edge lists are: edge_blend(part, [(feature_intersection_edges(part, [f_unite]), "r")])."""
    sc = part.ScCollectors.CreateCollector()
    sc.ReplaceRules([part.ScRuleFactory.CreateRuleFeatureIntersectionEdges(list(features))], False)
    return sc


# verified in detail_features.py (chainsets, variable) and course_checks.py (setback, stop short)
def edge_blend(part, chainsets, variable=(), setback=None, stop_short=(), overflow=False):
    """Edge blend, ONE feature with several radii.

    chainsets:  [(edge list or ScCollector, radius), ...]
    variable:   [(edge, percent along the edge, radius), ...] variable-radius points (linear law between them)
    setback:    (corner_xyz, distance) for three blended edges meeting in that vertex (adds 3 expressions)
    stop_short: [(edge, from_start, percent)] - the blend stops `percent` of the EDGE LENGTH before that end
    overflow:   what happens when the blend is wider than the face it rolls on (see nxh.blend_overflow).
                False (default) = all overflow switches off, which is what a builder made in a journal has:
                a blend that does not fit is refused with 'Unable to terminate the blend faces...' - also one
                the Edge Blend dialog would make. True = the dialog's defaults (the three switches ON): the
                blend commits, rolled onto the neighbouring edge (a crease there - check it). Or a dict of
                builder properties. The default is NOT the dialog's because existing journals rely on the
                refusal (see nxh.blend).
    Blend before Shell, biggest radii first. Returns the feature."""
    b = part.Features.CreateEdgeBlendBuilder(NF)
    try:
        b.Tolerance = 0.01
        nxh.blend_overflow(b, overflow)
        first_edges = None
        for edges, radius in chainsets:
            if first_edges is None and not isinstance(edges, NXOpen.ScCollector):
                first_edges = list(edges)
            b.AddChainset(_collector(part, edges, "edges"), str(radius))
        for edge, pct, radius in variable:
            b.AddVariablePointData(edge, str(pct), str(radius), "3.333333", "0.6", NXOpen.Point.Null, False, False)
        if setback:
            if first_edges is None:
                raise ValueError("edge_blend: setback needs the first chainset as an edge list, not a collector")
            corner, dist = setback
            ev = []
            for e in first_edges[0].GetBody().GetEdges():
                for i, p in enumerate(e.GetVertices()):
                    if abs(p.X - corner[0]) < 1e-6 and abs(p.Y - corner[1]) < 1e-6 and abs(p.Z - corner[2]) < 1e-6:
                        ev.append((e, i == 0))
            b.AddSetbackData([e for e, _s in ev], [s for _e, s in ev], [str(dist)] * len(ev))
        for edge, from_start, pct in stop_short:
            b.AddStopshortData(edge, from_start, str(pct))
        return b.CommitFeature()
    finally:
        b.Destroy()


def _edge_frame(edge, eps=1e-3):
    """(mid point, in-face unit directions d1, d2) of an edge with two faces, or None. d_i lies in face i,
    is perpendicular to the edge and points from the edge INTO face i."""
    fs = edge.GetFaces()
    if len(fs) != 2:
        return None
    pr = UFS.ModlGeneral.AskCurveProps(edge.Tag, 0.5)           # (point, tangent, normal, binormal, torsion, radius)
    p, t = list(pr[0]), list(pr[1])
    ds = []
    for f in fs:
        n = nxh.normal_at(f, p)
        d = [n[1] * t[2] - n[2] * t[1], n[2] * t[0] - n[0] * t[2], n[0] * t[1] - n[1] * t[0]]
        ln = math.sqrt(sum(x * x for x in d))
        if ln < 1e-9:
            return None
        d = [x / ln for x in d]
        sign = 0.0
        for step in (10.0, 50.0, 200.0):                        # larger steps only when the first finds no side:
            for s in (1.0, -1.0):                               # which way stays on the TRIMMED face
                q = [p[i] + s * step * eps * d[i] for i in range(3)]
                _parm, on = UFS.Modeling.AskFaceParm(f.Tag, q)  # foot point on the surface (curved faces)
                if UFS.Modeling.AskPointContainment(list(on), f.Tag) == 1:
                    sign = s
                    break
            if sign != 0.0:                                     # (a B-surface face reports "on the boundary"
                break                                           # within its edge tolerance: 0.01 was too close)
        if sign == 0.0:
            return None
        ds.append([sign * x for x in d])
    return p, ds[0], ds[1]


# verified in nxf_selftest (edge treatment)
def edge_convexity(part, edge, eps=1e-3):
    """'convex' (material inside the corner: an outside edge), 'concave' (an inside corner), 'smooth' (the two
    faces are tangent along the edge: a blend boundary, a split face) or None (not an edge of two faces).
    Decided by geometry at the edge mid point: the bisector of the two in-face directions points into the
    material on a convex edge and into the open on a concave one."""
    fr = _edge_frame(edge, eps)
    if fr is None:
        return None
    p, d1, d2 = fr
    b = [d1[i] + d2[i] for i in range(3)]
    ln = math.sqrt(sum(x * x for x in b))
    if ln < 0.035:                                              # faces within 2 degrees of tangent
        return "smooth"
    q = [p[i] + 10.0 * eps * b[i] / ln for i in range(3)]
    return "convex" if UFS.Modeling.AskPointContainment(q, edge.GetBody().Tag) == 1 else "concave"


# verified in nxf_selftest (edge treatment)
def sharp_edges(part, body, convex=True, concave=True, min_length=0.0):
    """Edges of the body that are sharp (not tangent), filtered by kind and length: [(edge, 'convex' | 'concave')].
    The input of break_edges(); also a quick census - a part modelled from a drawing that shows blends should
    have few sharp edges left."""
    out = []
    for e in body.GetEdges():
        if e.GetLength() < min_length:
            continue
        k = edge_convexity(part, e)
        if (k == "convex" and convex) or (k == "concave" and concave):
            out.append((e, k))
    return out


def _try_feature(fn):
    """Run fn() behind an undo mark; on an exception roll back and return (None, message)."""
    m = nxh.mark("edge treatment", False)
    try:
        return fn(), None
    except Exception as e:  # noqa: BLE001
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass
        return None, str(e).strip().splitlines()[0][:160] if str(e).strip() else type(e).__name__


def _edge_list(spec):
    """Edges of a chain spec (an Edge, a list of edges, an ScCollector, or a callable returning one of these);
    returns (object for the feature, list of edges or None when they cannot be listed)."""
    if callable(spec):
        spec = spec()
    if isinstance(spec, NXOpen.Edge):
        return [spec], [spec]
    if isinstance(spec, NXOpen.ScCollector):
        try:
            return spec, [o for o in spec.GetObjects() if isinstance(o, NXOpen.Edge)]
        except Exception:  # noqa: BLE001
            return spec, None
    return list(spec), list(spec)


def _overflow_modes(overflow):
    """Overflow settings to try in order for one blend size: "retry" = switches off, then the dialog's values."""
    return [False, True] if overflow == "retry" else [overflow]


def _blend_checked(part, obj, r, overflow, body):
    """Edge blend of one chain; a blend that only commits WITH overflow is kept only if the body stays valid
    (raises otherwise, so the caller's undo mark removes it and the next fallback is tried)."""
    f = edge_blend(part, [(obj, r)], overflow=overflow)
    if overflow and body is not None and not nxh.body_ok(part, body):
        raise RuntimeError("edge blend with overflow gave an invalid body")
    return f


def _treat_chain(part, spec, radius, smaller, chamfer_size, prefer_chamfer=False, overflow="retry"):
    sizes = [str(radius)] + ["(%s)*%s" % (radius, k) for k in smaller]
    row = {"built": None, "size": None, "treated": 0, "untreated": 0, "features": [], "errors": [], "overflow": False}

    def note(err):
        if err and err not in row["errors"]:
            row["errors"].append(err)

    obj, edges = _edge_list(spec)
    row["edges"] = len(edges) if edges is not None else None
    try:
        body = edges[0].GetBody() if edges else None
    except Exception:  # noqa: BLE001 - an edge consumed by an earlier chain's blend: the attempts below report it
        body = None

    def blend(o, v):                                           # v = (size, overflow setting)
        return _blend_checked(part, o, v[0], v[1], body)

    def cham(o, v):
        return chamfer(part, o, v[0])
    cham_sizes = sizes if chamfer_size is True else ([str(chamfer_size)] if chamfer_size else [])
    blend_vars = [(r, o) for r in sizes for o in _overflow_modes(overflow)]
    cham_vars = [(r, None) for r in cham_sizes]
    plan = ([("chamfer", cham, cham_vars)] if prefer_chamfer else []) + [("blend", blend, blend_vars)]
    if not prefer_chamfer:
        plan.append(("chamfer", cham, cham_vars))

    def label(kind, v, szs):
        return kind + (", smaller" if v[0] != szs[0][0] else "") + (", overflow" if v[1] else "")
    # 1 the whole chain: requested size (overflow off, then on), then the smaller ones
    kind, fn, szs = plan[0]
    for v in szs:
        f, err = _try_feature(lambda: fn(_edge_list(spec)[0], v))
        if f is not None:
            row.update(built=label(kind, v, szs), size=v[0], treated=row["edges"], features=[f.GetFeatureName()],
                       overflow=bool(v[1]))
            return row
        note(err)
    # 2 edge by edge with the first kind, then the other kind on what is left
    left = list(edges or [])
    for kind, fn, szs in plan:
        if not left or not szs:
            continue
        if len(left) == (row["edges"] or 0) and kind != plan[0][0]:
            for v in szs:                                      # the other kind on the whole chain first
                f, err = _try_feature(lambda: fn(list(left), v))
                if f is not None:
                    row.update(built=label(kind, v, szs), size=v[0], treated=len(left), features=[f.GetFeatureName()],
                               overflow=bool(v[1]))
                    return row
                note(err)
        if len(left) < 2 and kind == plan[0][0]:
            continue                                           # a single edge was already tried as the chain
        still = []
        for e in left:
            done = False
            for v in szs:
                f, err = _try_feature(lambda: fn([e], v))
                if f is not None:
                    row["features"].append(f.GetFeatureName())
                    row["treated"] += 1
                    row["size"] = row["size"] or v[0]
                    row["overflow"] = row["overflow"] or bool(v[1])
                    done = True
                    break
                note(err)
            if not done:
                still.append(e)
        if len(still) < len(left):
            row["built"] = (row["built"] + " + " if row["built"] else "") + kind + ", edge by edge"
        left = still
    row["untreated"] = len(left)
    row["untreated_edges"] = left
    return row


# verified in nxf_selftest (edge treatment)
def blend_chains(part, chains, radius, smaller=(0.5,), chamfer=True, prefer_chamfer=False, overflow="retry"):
    """Edge treatment for a list of edge chains ONE BY ONE, each behind its own undo mark, so one refused blend
    never loses the others. Use it for the blends and chamfers a drawing shows: an edge break of any kind is
    worth more than none (benchmark: a sharp edge where the truth is blended costs surface score at volume
    IoU 1.000, and a chamfer recovers nearly all of it).

    chains: each item an Edge, a list of edges, an ScCollector (tangent_edges(part, seed)), a CALLABLE returning
    one of these (use it when earlier chains change the topology: the edges are then looked up when their turn
    comes), or a tuple (item, radius) with its own radius.
    Fallback order per chain:  1 Edge Blend of the whole chain at `radius`, overflow switches off;  1b the same
    blend with the Edge Blend dialog's overflow switches on (overflow="retry", the default);  2 the same two
    steps at radius x each factor of `smaller`;  3 the edges one at a time (same sizes, same two steps);
    4 Chamfer (symmetric) - chamfer=True: same sizes, chamfer=<size>: that offset, chamfer=False: never -
    whole chain, then edge by edge.
    prefer_chamfer=True starts with the chamfer (a note "break edges 0.5 x 45") and falls back to a blend.
    overflow: "retry" (default) - a builder made in a journal has every overflow switch off and refuses blends
    the dialog makes ("Unable to terminate the blend faces"), so a refused blend is tried again with the
    dialog's values BEFORE the radius is reduced: the drawing's radius rolled onto the neighbouring edge is
    closer to the drawing than half the radius. Such a blend is kept only if the body is still valid
    (nxh.body_ok), and the row says so: "built" ends in ", overflow" and "overflow" is True - look at that
    place (a crease or a moved edge, see nxh.blend_overflow). False - never use overflow (the old behaviour:
    refused -> smaller size / chamfer). True or a dict of builder properties - always on.
    Returns one dict per chain: {"built": "blend" | "blend, overflow" | "blend, smaller" | "blend, edge by
    edge" | "chamfer" ... | None, "size": the formula used, "overflow": bool, "edges", "treated", "untreated",
    "features": [names], "errors": [NX texts], "untreated_edges": [...]}. Nothing raises: read the report,
    then check nxh.feature_errors(part)."""
    out = []
    for item in chains:
        spec, r = (item[0], item[1]) if (isinstance(item, tuple) and len(item) == 2) else (item, radius)
        out.append(_treat_chain(part, spec, r, tuple(smaller), chamfer, prefer_chamfer, overflow))
    return out


# verified in nxf_selftest (edge treatment)
def break_edges(part, body, radius, convex=True, concave=True, min_length=0.0, smaller=(0.5,), chamfer=True,
                prefer_chamfer=False, overflow="retry"):
    """Break ALL sharp edges of a body - the general drawing note ("all edges R0.5", "break sharp edges 0.3 x 45",
    "fillets R2 TYP") - with the fallback of blend_chains.

    Candidates: sharp_edges(body, convex, concave, min_length) - convex = outside edges, concave = inside
    corners (a note about fillets usually means the concave ones, a deburr note the convex ones).
    1 all candidates in ONE feature at `radius` (the corners come out as proper vertex blends), then at the
    smaller sizes - each size with the overflow switches off and then, overflow="retry" (default), with the
    dialog's overflow values (kept only if the body stays valid);  2 if that is refused: edge by edge through
    blend_chains (blend, overflow, smaller, chamfer), so the edges that can be treated are, and the rest is
    reported. overflow=False: never use overflow (the old behaviour).
    Returns {"candidates", "mode": "one feature" | "edge by edge", "size", "overflow": bool, "treated",
    "untreated": [{"mid", "length", "kind"}], "features", "errors"}. Make it the LAST feature and compare the
    volume before / after."""
    chamfer_fn = globals()["chamfer"]                           # the parameter `chamfer` hides the function
    cand = sharp_edges(part, body, convex, concave, min_length)
    rep = {"candidates": len(cand), "convex": sum(1 for _e, k in cand if k == "convex"),
           "concave": sum(1 for _e, k in cand if k == "concave"), "mode": None, "size": None, "overflow": False,
           "treated": 0, "untreated": [], "features": [], "errors": []}
    if not cand:
        return rep
    edges = [e for e, _k in cand]
    kinds = {e.Tag: k for e, k in cand}
    sizes = [str(radius)] + ["(%s)*%s" % (radius, k) for k in smaller]
    for r in sizes:
        for o in ([None] if prefer_chamfer else _overflow_modes(overflow)):
            f, err = _try_feature((lambda: chamfer_fn(part, edges, r)) if prefer_chamfer
                                  else (lambda: _blend_checked(part, edges, r, o, body)))
            if f is not None:
                rep.update(mode="one feature", size=r, treated=len(edges), features=[f.GetFeatureName()],
                           overflow=bool(o))
                return rep
            if err and err not in rep["errors"]:
                rep["errors"].append(err)
    info = {}
    for e in edges:                                            # remember where each edge is before the body changes
        bb = nxh.bbox(e)
        info[e.Tag] = {"mid": [round((bb[i] + bb[i + 3]) / 2, 3) for i in range(3)], "length": round(e.GetLength(), 3), "kind": kinds[e.Tag]}
    rep["mode"] = "edge by edge"
    for row in blend_chains(part, [[e] for e in edges], radius, smaller, chamfer, prefer_chamfer, overflow):
        rep["treated"] += row["treated"] or 0
        rep["features"] += row["features"]
        rep["size"] = rep["size"] or row["size"]
        rep["overflow"] = rep["overflow"] or bool(row.get("overflow"))
        for err in row["errors"]:
            if err not in rep["errors"]:
                rep["errors"].append(err)
        for e in row.get("untreated_edges", []):
            rep["untreated"].append(info.get(e.Tag, {}))
    return rep


# verified in nx-solid-features/scripts/detail_features.py
def face_blend(part, faces1, faces2, radius):
    """Rolling-ball blend between two face sets of one solid, for a CONVEX edge: both face normals are reversed
    so they point at the blend centre (into the material). Returns the feature."""
    b = part.Features.CreateFaceBlendBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FirstFaceCollector = nxh.collector(part, faces=list(faces1))
        b.SecondFaceCollector = nxh.collector(part, faces=list(faces2))
        b.ReverseFirstFaceNormal = True
        b.ReverseSecondFaceNormal = True
        b.CircularCrossSection.Radius.RightHandSide = str(radius)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-solid-features/scripts/detail_features.py
def chamfer(part, edges, first, second=None, angle=None):
    """Chamfer. first only -> symmetric; second -> two offsets; angle -> offset + angle (other leg = first * tan(angle)).
    edges: list or ScCollector. Which face gets `first` on asymmetric chamfers is NX's choice: measure. Returns the feature."""
    CB = NXOpen.Features.ChamferBuilder
    b = part.Features.CreateChamferBuilder(NF)
    try:
        if second is not None:
            b.Option = CB.ChamferOption.TwoOffsets
        elif angle is not None:
            b.Option = CB.ChamferOption.OffsetAndAngle
        else:
            b.Option = CB.ChamferOption.SymmetricOffsets
        b.Method = CB.OffsetMethod.EdgesAlongFaces
        b.FirstOffset = str(first)
        if second is not None:
            b.SecondOffset = str(second)
        if angle is not None:
            b.Angle = str(angle)
        b.Tolerance = 0.01
        b.SmartCollector = _collector(part, edges, "edges")
        return b.CommitFeature()
    finally:
        b.Destroy()


def _hole_package(part, body, points, configure, vector, start_extension=False):
    pts = [p if isinstance(p, NXOpen.Point) else nxh.point(part, *p) for p in points]
    h = part.Features.CreateHolePackageBuilder(NXOpen.Features.HolePackage.Null)
    try:
        configure(h)
        h.Tolerance = 0.01
        h.StartExtensionEnabled = bool(start_extension)
        h.BooleanOperation.Type = BOOL.Subtract
        h.BooleanOperation.SetTargetBodies([body])
        h.HolePosition.AddToSection([part.ScRuleFactory.CreateRuleCurveDumbFromPoints(pts)], NULL, NULL, NULL,
                                    P(0, 0, 0), NXOpen.Section.Mode.Create, False)
        if vector is not None:
            h.ProjectionDirection.ProjectDirectionMethod = GU.ProjectionOptions.DirectionType.Vector
            h.ProjectionDirection.ProjectVector = _direction(part, vector)      # (x, y, z), or an object: associative
        return h.CommitFeature()
    finally:
        h.Destroy()


def _hole_limit(h, depth_expr, depth, until, until_next):
    """Depth limit of a hole builder: until=face/datum plane -> Until Selected, until_next -> Until Next,
    depth=None -> Through Body, else Value written into depth_expr."""
    HPB = NXOpen.Features.HolePackageBuilder
    if until is not None:
        h.HoleDepthLimitOption = HPB.HoleDepthLimitOptions.UntilSelected
        h.UntilSelectedTarget.Value = until
    elif until_next:
        h.HoleDepthLimitOption = HPB.HoleDepthLimitOptions.UntilNext
    elif depth is None:
        h.HoleDepthLimitOption = HPB.HoleDepthLimitOptions.ThroughBody
    else:
        h.HoleDepthLimitOption = HPB.HoleDepthLimitOptions.Value
        depth_expr.RightHandSide = str(depth)


def _offset_angle(v):
    """chamfer argument -> (offset, angle): 0.5 -> ("0.5", "45"); (0.5, 30) -> ("0.5", "30")."""
    if isinstance(v, (tuple, list)):
        return str(v[0]), str(v[1])
    return str(v), "45"


# verified in nx-solid-features/scripts/detail_features.py (cfg_simple / cfg_cbore / cfg_csink) and
# nx-solid-features/scripts/hole_variants.py (blind cbore / csink, until, start / end chamfer)
def hole(part, body, points, diameter, depth=None, tip=0, vector=None, cbore=None, csink=None, start_extension=False,
         until=None, until_next=False, start_chamfer=None, end_chamfer=None):
    """Hole (HolePackage, General Hole) at one or more points; ONE feature for all points.

    points: [(x, y, z), ...] (formulas allowed -> associative points) or NXOpen.Point / sketch points, lying ON
    the start face. vector: drilling direction INTO the material, e.g. (0, 0, -1); None = normal to the face
    under the point. depth=None -> Through Body; else blind to `depth` with tip angle `tip` (0 = flat, 118 = drill).
    until=<face or datum plane> -> depth Until Selected (a port bore that must end in the main bore: pass the
    bore face); until_next=True -> Until Next. Both ignore `depth` and make no tip.
    cbore=(diameter, depth) / csink=(diameter, included angle): through, or blind with `depth` = hole depth
    measured from the START face (it includes the counterbore) and tip angle `tip`.
    start_chamfer / end_chamfer: chamfer made INSIDE the hole feature (one feature, it follows the hole when the
    point moves and is copied by a pattern): a radial offset, or (offset, angle). The mouth ring diameter is
    diameter + 2 x offset; the angle is measured from the start FACE (axial height = offset x tan(angle); 45
    = symmetric). end_chamfer needs a hole that leaves the body (through). Measured on SIMPLE holes; until /
    until_next and the chamfers are not measured on counterbored holes (a countersink takes no chamfer).
    start_extension -> StartExtensionEnabled. Rule: start point on a PLANAR face normal to the hole -> False
    (True cuts a channel above the start face); start face NOT planar or inclined to the hole axis (the point
    lies on a cylinder, a blend, a drafted or freeform face) -> True. Without it the hole starts at the plane
    through the start point and the material above that plane stays: measured on a D40 cylinder, start point
    8 mm off the crest, counterbore 11 x 6: 1554.657 removed instead of 1592.222 (an incomplete counterbore,
    no error); acceptance build 5 got 'Holes were not created.' in the same situation. With True the hole is
    cut up to the surface and matches the analytic volume. The depth is measured from the start point either
    way. Returns the feature."""
    HPB = NXOpen.Features.HolePackageBuilder
    if csink and (start_chamfer or end_chamfer):
        raise ValueError("a countersunk hole takes no start / end chamfer: the countersink is the mouth")
    if end_chamfer and (depth is not None or until is not None or until_next):
        raise ValueError("end_chamfer needs a through hole (depth=None)")

    def cfg(h):
        h.Type = HPB.Types.GeneralHole
        if cbore:
            h.GeneralHoleForm = HPB.HoleForms.Counterbored
            h.GeneralCounterboreDiameter.RightHandSide = str(cbore[0])
            h.GeneralCounterboreDepth.RightHandSide = str(cbore[1])
            h.GeneralCounterboreHoleDiameter.RightHandSide = str(diameter)
            _hole_limit(h, h.GeneralCounterboreHoleDepth, depth, until, until_next)
        elif csink:
            h.GeneralHoleForm = HPB.HoleForms.Countersink
            h.GeneralCountersinkDiameter.RightHandSide = str(csink[0])
            h.GeneralCountersinkAngle.RightHandSide = str(csink[1])
            h.GeneralCountersinkHoleDiameter.RightHandSide = str(diameter)
            _hole_limit(h, h.GeneralCountersinkHoleDepth, depth, until, until_next)
        else:
            h.GeneralHoleForm = HPB.HoleForms.Simple
            h.GeneralSimpleHoleDiameter.RightHandSide = str(diameter)
            _hole_limit(h, h.GeneralSimpleHoleDepth, depth, until, until_next)
        through = depth is None and until is None and not until_next
        if not ((cbore or csink) and through):     # through cbore / csink: tip not set (the verified property set)
            h.GeneralTipAngle.RightHandSide = str(tip)
        if start_chamfer:
            h.CustomStartChamferEnabled = True
            h.CustomStartChamferOffset.RightHandSide, h.CustomStartChamferAngle.RightHandSide = _offset_angle(start_chamfer)
        if end_chamfer:
            h.CustomEndChamferEnabled = True
            h.CustomEndChamferOffset.RightHandSide, h.CustomEndChamferAngle.RightHandSide = _offset_angle(end_chamfer)
    return _hole_package(part, body, points, cfg, vector, start_extension)


# ISO metric coarse threads: nominal -> (NX "Metric Coarse" ThreadSize string, pitch, tap drill ISO 2306).
# NX's own table (RadialEngage 0.75) gives the same tap drill except M3.5 3.0, M12 10.3, M14 12.1, M27 24.077,
# M30 26.59, M36 32.103 (measured on NX 2206: nx-solid-features/scripts/hole_variants.py).
ISO_COARSE = {
    "M1.6": ("M1.6 x 0.35", 0.35, 1.25), "M2": ("M2 x 0.4", 0.4, 1.6), "M2.5": ("M2.5 x 0.45", 0.45, 2.05),
    "M3": ("M3 x 0.5", 0.5, 2.5), "M3.5": ("M3.5 x 0.6", 0.6, 2.9), "M4": ("M4 x 0.7", 0.7, 3.3),
    "M5": ("M5 x 0.8", 0.8, 4.2), "M6": ("M6 x 1.0", 1.0, 5.0), "M8": ("M8 x 1.25", 1.25, 6.8),
    "M10": ("M10 x 1.5", 1.5, 8.5), "M12": ("M12 x 1.75", 1.75, 10.2), "M14": ("M14 x 2", 2.0, 12.0),
    "M16": ("M16 x 2", 2.0, 14.0), "M18": ("M18 x 2.5", 2.5, 15.5), "M20": ("M20 x 2.5", 2.5, 17.5),
    "M22": ("M22 x 2.5", 2.5, 19.5), "M24": ("M24 x 3", 3.0, 21.0), "M27": ("M27 x 3", 3.0, 24.0),
    "M30": ("M30 x 3.5", 3.5, 26.5), "M36": ("M36 x 4", 4.0, 32.0)}
_THREAD_RE = re.compile(r"^\s*M\s*(\d+(?:\.\d+)?)\s*(?:[xX]\s*(\d+(?:\.\d+)?))?\s*$")


def thread_spec(size):
    """Metric thread callout -> {"nominal", "pitch", "tap_drill", "nx_size", "coarse"}.

    Accepts "M10", "M10x1.5", "M10 x 1.5", "M10x1.25". Coarse pitch (or none given): the ISO_COARSE row.
    Fine pitch: tap drill = nominal - pitch (the ISO rule), nx_size None - pass the exact NX string and
    standard="Metric Fine" to threaded_hole. Raises ValueError for anything that is not an M callout."""
    m = _THREAD_RE.match(str(size))
    if not m:
        raise ValueError("not a metric thread callout: %r" % (size,))
    nominal = float(m.group(1))
    key = "M%g" % nominal
    pitch = float(m.group(2)) if m.group(2) else None
    row = ISO_COARSE.get(key)
    if row and (pitch is None or abs(pitch - row[1]) < 1e-9):
        return {"nominal": nominal, "pitch": row[1], "tap_drill": row[2], "nx_size": row[0], "coarse": True}
    if pitch is None:
        raise ValueError("no ISO coarse row for %s: give the pitch (M%gx<pitch>)" % (key, nominal))
    return {"nominal": nominal, "pitch": pitch, "tap_drill": round(nominal - pitch, 3), "nx_size": None, "coarse": False}


def tap_drill(size):
    """Tap-drill diameter of a metric thread callout ("M10" -> 8.5, "M12" -> 10.2, "M10x1.25" -> 8.75).
    This is the diameter of the cylinder a drawing's threaded hole has in CAD: never the nominal diameter."""
    return thread_spec(size)["tap_drill"]


# verified in nx-solid-features/scripts/detail_features.py (cfg_thread) and hole_variants.py (all options)
def threaded_hole(part, body, points, size, thread_depth=None, hole_depth=None, vector=None, standard="Metric Coarse",
                  start_extension=False, through=False, until=None, until_next=False, start_chamfer=None,
                  end_chamfer=None, chamfer_angle=45, tip=None, tap_drill=None):
    """Threaded hole (HolePackage with a SYMBOLIC thread) at one or more points; ONE feature.

    The geometry is a plain cylinder at TAP-DRILL diameter (M10 -> dia 8.5), not at the nominal diameter; the
    thread is a symbolic child row. This is what a drawing callout "M10" means in a CAD model and in a STEP.
    size: "M10" / "M10x1.5" (resolved through thread_spec to NX's "M10 x 1.5") or the exact NX ThreadSize string
    of `standard` ("M6 x 1.0", "M8 x 1", ...; table: UGII\\modeling_standards\\NX_Thread_Standard.xml).
    Depth, one of: hole_depth (+ thread_depth) = blind, depth to the cylinder bottom, 118 deg tip beyond it
    (tip=0 flat); through=True; until=<face or datum plane> (Until Selected); until_next=True. Without
    thread_depth the thread runs the full length.
    start_chamfer / end_chamfer: True = 45 deg chamfer up to the NOMINAL diameter (the ring a drawing shows
    around a tapped hole), or a chamfer DIAMETER (number / formula). The helper always writes the diameter:
    the builder default is 10 for every size (measured: a dia 10 countersink on an M2 hole, no chamfer at all
    on M12 and larger, no error). chamfer_angle is measured from the start face (45 = symmetric).
    end_chamfer needs a hole that leaves the body (through=True).
    tap_drill: None = NX's table value at 75 % engagement; a number / formula, or "iso" for the ISO 2306 value
    of thread_spec, switches RadialEngageOption to "Custom" and sets TapDrillDiameter (M12: NX 10.3, ISO 10.2).
    Editing the tap-drill expression of a table-driven hole AFTER the commit is ignored - set it here.
    start_extension: as for hole() - True when the start face is not planar. Returns the feature."""
    HPB = NXOpen.Features.HolePackageBuilder
    spec = None
    try:
        spec = thread_spec(size)
    except ValueError:
        pass
    nx_size = spec["nx_size"] if spec and spec["nx_size"] and standard == "Metric Coarse" else size
    blind = not through and until is None and not until_next
    if blind and hole_depth is None:
        raise ValueError("threaded_hole: give hole_depth, or through=True / until=face / until_next=True")
    if end_chamfer and not through:
        raise ValueError("threaded_hole: end_chamfer needs through=True")
    if tap_drill == "iso":
        if spec is None:
            raise ValueError("threaded_hole: tap_drill='iso' needs a metric callout, got %r" % (size,))
        tap_drill = spec["tap_drill"]

    def chamfer_dia(v):
        if v is True:
            if spec is None:
                raise ValueError("threaded_hole: start/end_chamfer=True needs a metric callout; pass the diameter")
            return str(spec["nominal"])
        return str(v)

    def cfg(h):
        h.Type = HPB.Types.ThreadedHole
        h.ThreadStandard = standard
        h.ThreadSize = nx_size
        if tap_drill is None:
            h.RadialEngageOption = "0.75"
        else:
            h.RadialEngageOption = "Custom"
            h.TapDrillDiameter.RightHandSide = str(tap_drill)
        _hole_limit(h, h.ThreadedHoleDepth, None if through else hole_depth, until, until_next)
        if thread_depth is not None:
            h.ThreadDepth.RightHandSide = str(thread_depth)
        elif blind:
            h.ThreadDepth.RightHandSide = str(hole_depth)
        else:
            h.ThreadLengthOption = HPB.ThreadLengthOptions.Full
        if tip is not None and blind:
            h.ThreadedTipAngle.RightHandSide = str(tip)
        if start_chamfer:
            h.ThreadedStartChamferEnabled = True
            h.ThreadedStartChamferDiameter.RightHandSide = chamfer_dia(start_chamfer)
            h.ThreadedStartChamferAngle.RightHandSide = str(chamfer_angle)
        if end_chamfer:
            h.ThreadedEndChamferEnabled = True
            h.ThreadedEndChamferDiameter.RightHandSide = chamfer_dia(end_chamfer)
            h.ThreadedEndChamferAngle.RightHandSide = str(chamfer_angle)
    return _hole_package(part, body, points, cfg, vector, start_extension)


def _fill_owned(part, sec, curves, feature, help_point):
    sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    rf = part.ScRuleFactory
    if feature is not None:
        rule = rf.CreateRuleCurveFeature([feature], NXOpen.DisplayableObject.Null, rf.CreateRuleOptions())
    else:
        rule = rf.CreateRuleCurveDumb(list(curves))
    sec.AddToSection([rule], NULL, NULL, NULL, P(*help_point), NXOpen.Section.Mode.Create, False)


# verified in nx-patterns-and-body-ops/scripts/sweeps_and_links.py
def tube(part, outer, inner="0", curves=None, feature=None):
    """Tube along a tangent-continuous path (no sharp vertex). Path = dumb curves, or all curves of a curve
    feature (helix, sketch). PathSection is builder-owned (filled in place); Tolerance default raises
    'Tolerance error'. Returns (feature, body)."""
    before = list(part.Bodies)
    b = part.Features.CreateTubeBuilder(NXOpen.Features.Tube.Null)
    try:
        _fill_owned(part, b.PathSection, curves, feature, (0, 0, 0))
        b.OuterDiameter.RightHandSide = str(outer)
        b.InnerDiameter.RightHandSide = str(inner)
        b.Tolerance = 0.01
        b.OutputOption = NXOpen.Features.TubeBuilderOutput.MultipleSegments
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(part, before)[0]


# verified in nx-patterns-and-body-ops/scripts/sweeps_and_links.py
def sweep_along_guide(part, profile, guide, hp_profile, hp_guide, op=None, target=None):
    """Sweep Along Guide: one profile along one guide (curve lists). Closed planar profile -> solid, open ->
    sheet; sharp guide corners are mitred; faces stay analytic (Swept gives B-surfaces). Section and Guide are
    builder-owned. hp_*: a point at the start end of each string. Returns (feature, body)."""
    before = list(part.Bodies)
    b = part.Features.CreateSweepAlongGuideBuilder(NXOpen.Features.SweepAlongGuide.Null)
    try:
        _fill_owned(part, b.Section, profile, None, hp_profile)
        _fill_owned(part, b.Guide, guide, None, hp_guide)
        b.FirstOffset.RightHandSide = "0"
        b.SecondOffset.RightHandSide = "0"
        op = BOOL.Create if op is None else op
        b.BooleanOperation.Type = op
        if op != BOOL.Create:
            b.BooleanOperation.SetTargetBodies([target])
        f = b.CommitFeature()
    finally:
        b.Destroy()
    nb = nxh.new_bodies(part, before)
    return f, (nb[0] if nb else target)


# ====================================================================== copies and body operations
# verified in nx-patterns-and-body-ops/scripts/mirror_and_pattern.py, trim_split_boolean.py
def plane_from_datum(part, datum_plane, offset="0"):
    """Smart NXOpen.Plane = datum plane (or planar face) + offset formula - what Mirror Geometry and the
    'new plane' tool of Trim/Split Body take (they do not accept the DatumPlane object itself)."""
    pl = part.Planes.CreatePlane(P(0, 0, 0), V(0, 0, 1), UPD)
    pl.SetMethod(MT.Distance)
    pl.SetGeometry([datum_plane])
    pl.SetFlip(False)
    pl.SetReverseSide(False)
    pl.Expression.RightHandSide = str(offset)
    pl.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    pl.Evaluate()
    return pl


# verified in nx-patterns-and-body-ops/scripts/mirror_and_pattern.py (symmetric_half)
def mirror_geometry(part, bodies, datum_plane, offset="0"):
    """Mirror Geometry: associative mirrored COPIES of whole bodies about a datum plane (+ offset).

    The copy is a snapshot of the source at this point of the tree: mirror LAST. Unite the copies with
    nxh.unite(part, body, tool_features=[feature]). Returns (feature, new bodies)."""
    before = list(part.Bodies)
    b = part.Features.CreateGeomcopyBuilder(NF)
    try:
        b.Type = NXOpen.Features.GeomcopyBuilder.TransformTypes.Mirror
        b.MirrorPlane = plane_from_datum(part, datum_plane, offset)
        for body in bodies:
            b.GeometryToInstance.Add(body)
        b.Associative = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(part, before)


# verified in nx-patterns-and-body-ops/scripts/mirror_and_pattern.py (patterns)
def mirror_feature(part, features, datum_plane):
    """Mirror Feature: replays features on the other side of a DatumPlane (they must land on the same body).
    Factory needs NXOpen.Features.Mirror.Null. Returns the feature."""
    b = part.Features.CreateMirrorBuilder(NXOpen.Features.Mirror.Null)
    try:
        b.PatternService.PatternType = PAT.Mirror
        md = b.PatternService.MirrorDefinition
        md.PlaneOption = GU.MirrorPattern.PlaneOptions.Existing
        md.ExistingPlane.Value = datum_plane
        b.FeatureList.Add(list(features))
        return b.CommitFeature()
    finally:
        b.Destroy()


def _linear(part, ps, xdir, nx, px, ydir=None, ny=None, py=None):
    ps.PatternType = PAT.Linear
    rd = ps.RectangularDefinition
    rd.XDirection = nxh.direction(part, xdir)
    rd.XSpacing.SpaceType = SPACE.Offset
    rd.XSpacing.NCopies.RightHandSide = str(nx)
    rd.XSpacing.PitchDistance.RightHandSide = str(px)
    if ydir is not None:
        rd.UseYDirectionToggle = True
        rd.YDirection = nxh.direction(part, ydir)
        rd.YSpacing.SpaceType = SPACE.Offset
        rd.YSpacing.NCopies.RightHandSide = str(ny)
        rd.YSpacing.PitchDistance.RightHandSide = str(py)


def _circular(part, ps, origin, vec, count, span="360", pitch=None):
    ps.PatternType = PAT.Circular
    cd = ps.CircularDefinition
    if isinstance(vec, NXOpen.Axis):
        cd.RotationAxis = vec
    elif isinstance(vec, (tuple, list)):
        cd.RotationAxis = nxh.axis(part, origin, vec)
    else:                                                       # datum axis, linear edge, cylindrical face: associative
        cd.RotationAxis = axis_from(part, vec)
    cd.AngularSpacing.NCopies.RightHandSide = str(count)
    if pitch is None:
        cd.AngularSpacing.SpaceType = SPACE.Span
        cd.AngularSpacing.SpanAngle.RightHandSide = str(span)
    else:
        cd.AngularSpacing.SpaceType = SPACE.Offset
        cd.AngularSpacing.PitchAngle.RightHandSide = str(pitch)


def _pattern_feature(part, features, layout, variational, increments=None):
    METHOD = NXOpen.Features.PatternFeatureBuilder.PatternMethodOptions
    b = part.Features.CreatePatternFeatureBuilder(NF)
    try:
        layout(b.PatternService)
        b.PatternMethod = METHOD.Variational if variational else METHOD.Simple
        b.FeatureList.Add(list(features))
        for inc in (increments or ()):
            OP = GU.PatternIncrementItem.OperationEnum
            master, formula = inc[0], inc[1]
            lst = b.PatternService.PatternIncrementsBuilder.IncrementsListInDirection1
            item = lst.CreatePatternIncrementItem(master)
            item.IncrementExpression.RightHandSide = str(formula)
            item.Operation = OP.Multiply if (len(inc) > 2 and inc[2]) else OP.Add
            lst.List.Append(item)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-patterns-and-body-ops/scripts/mirror_and_pattern.py (patterns: linear nx x ny)
def pattern_linear(part, features, xdir, nx, px, ydir=None, ny=None, py=None, variational=False, increments=None,
                   stagger=None, frame_only=False):
    """Pattern Feature, linear layout: nx instances at pitch px along xdir (the count INCLUDES the original),
    optionally ny x py along ydir. Counts must be unitless expressions (nxh.expr(part, "n", 5, None)).
    The instances must land on the body. variational=True re-evaluates each instance.
    stagger="row" / "column": every second row (column) is shifted by half a pitch; frame_only=True: only the
    instances on the boundary of the grid (4 x 4 -> 12). One instance moved afterwards: pattern_clock.
    increments=[(master expression, formula[, multiply])]: Pattern Increment along direction 1 - instance k
    gets master + formula x k (multiply=True: master x formula ^ k). master is an NXOpen.Expression of a seed
    feature (f.GetExpressions(), or a sketch dimension's .AssociatedExpression - then the sketch feature must be
    in `features`); the formula may name an expression. Returns the feature."""
    def layout(ps):
        _linear(part, ps, xdir, nx, px, ydir, ny, py)
        if stagger:
            st = GU.RectangularPattern.StaggerOptions
            ps.RectangularDefinition.StaggerType = st.Row if str(stagger).lower() == "row" else st.Column
        if frame_only:
            ps.FrameOnlyToggle = True
    return _pattern_feature(part, features, layout, variational, increments)


# verified in nx-patterns-and-body-ops/scripts/mirror_and_pattern.py (patterns: circular)
def pattern_circular(part, features, origin, vec, count, span="360", pitch=None, variational=False, increments=None):
    """Pattern Feature, circular layout about the axis (origin, vec): `count` instances over `span` degrees
    (360 = evenly round, the user's habit), or at `pitch` degrees each when pitch is given.
    vec may also be an OBJECT - a datum axis, a linear edge, a cylindrical face or an NXOpen.Axis: the pattern
    then turns about that object and follows it (origin is ignored): a bolt circle about an inclined port axis.
    increments: as for pattern_linear. Returns the feature."""
    return _pattern_feature(part, features, lambda ps: _circular(part, ps, origin, vec, count, span, pitch), variational, increments)


# verified in nx-patterns-and-body-ops/scripts/community_checks.py (C7) and nxf_selftest (pattern_along)
def pattern_along(part, features, path_features, start_curve, start_xyz, count, percent="100", variational=True,
                  fixed_orientation=False):
    """Pattern Feature Along a path: `count` instances spread over `percent` of the path length (Count and Span;
    pitch = path length x percent / 100 / (count - 1), measured along the curve).

    path_features: the feature(s) that own the path curves - a sketch feature (sketch.Feature), an associative
    curve feature, a linked composite curve (nxa.link_curve); start_curve + start_xyz: the curve of the path the
    pattern starts on and a point at its start end. The seed should sit at the start of the path.
    By default the copies TURN with the path; fixed_orientation=True keeps the seed's orientation.
    variational=True is required when the seed makes its own body (Simple is refused there). Returns the feature."""
    METHOD = NXOpen.Features.PatternFeatureBuilder.PatternMethodOptions
    b = part.Features.CreatePatternFeatureBuilder(NF)
    try:
        ps = b.PatternService
        ps.PatternType = PAT.AlongPath
        sec = ps.AlongPathDefinition.XPath                      # builder-owned: fill in place
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        sec.AddToSection([part.ScRuleFactory.CreateRuleCurveFeature(list(path_features))], start_curve, NULL, NULL,
                         P(*start_xyz), NXOpen.Section.Mode.Create, False)
        sp = ps.AlongPathDefinition.XOnPathSpacing
        sp.SpaceType = SPACE.Span
        sp.NCopies.RightHandSide = str(count)
        sp.OnPathSpanDistance.IsPercentUsed = True
        sp.OnPathSpanDistance.Expression.RightHandSide = str(percent)
        if fixed_orientation:
            ps.PatternOrientation.AlongOrientationOption = GU.PatternOrientation.Enum.Fixed
        b.PatternMethod = METHOD.Variational if variational else METHOD.Simple
        b.FeatureList.Add(list(features))
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-patterns-and-body-ops/scripts/community_checks.py (C2, C3) and nxf_selftest
def feature_group(part, features, name):
    """Feature Group of `features` (the UF call is the working route). A group can be mirrored or patterned as a
    unit: pass [group] to mirror_feature / pattern_*. Returns the group feature (type FSET)."""
    UFS.Modeling.CreateSetOfFeature(name, [f.Tag for f in features], len(features), 1)
    return [f for f in part.Features.GetFeatures() if f.FeatureType == "FSET"][-1]


# ====================================================================== organising and editing a tree
# verified in nxf_selftest (tree group) and nx-journal-core/scripts/edit_in_the_middle.py
def suppress_by_expression(part, features, formula=None, shared=True):
    """Suppress by Expression: give `features` (a list; a Feature Group counts as ONE feature and takes its
    members along) a "Suppression Status" expression - 1 / TRUE = active, 0 / FALSE = suppressed.

    shared=True  -> ONE expression for all of them (ExpressionAction.CreateShared); returns it.
    shared=False -> one expression per feature (CreateEach); returns the list.
    formula: right-hand side to set, e.g. "if (length > 200) (1) else (0)" or the name of a Boolean
    expression; None leaves it at 1.
    Give EVERY feature of the set the expression (or group them): a child without one goes down with its
    parent but does NOT come back when the parent returns - it stays suppressed until it is unsuppressed
    by hand (measured: status code 64, a lug came back without its blend). Returns the expression(s)."""
    feats = [features] if isinstance(features, NXOpen.Features.Feature) else list(features)
    ea = NXOpen.SuppressByExpressionBuilder.ExpressionAction
    b = part.Expressions.CreateSuppressByExpressionBuilder()
    try:
        b.SuppressAction = ea.CreateShared if shared else ea.CreateEach
        for f in feats:
            b.FeatureList.Add(f)
        b.Commit()
    finally:
        b.Destroy()
    exprs, seen = [], set()
    for f in feats:
        t = UFS.ModlGeneral.AskSuppressExpTag(f.Tag)
        if t and t not in seen:
            seen.add(t)
            exprs.append(NXOpen.TaggedObjectManager.GetTaggedObject(t))
    if formula is not None:
        for e in exprs:
            e.RightHandSide = str(formula)
        nxh.update("suppress by expression")
    return exprs[0] if shared and exprs else exprs


# verified in nxf_selftest (tree group) and nx-journal-core/scripts/edit_in_the_middle.py
def replace_feature(part, old, new, tolerance=None, delete_original=True, allow_lost=()):
    """Replace Feature: put `new` in the place of `old` and re-attach everything that referenced old's faces
    and edges to the matching geometry of `new` (automatic geometric match). The use: swap the base under
    existing detail features - a primitive or an imported body by a sketch-driven one - without rebuilding
    them. `new` must already exist BEFORE the dependents (create it at the insert point: nxh.insert_after).

    tolerance: MappingTolerance in mm (NX default 1.0). Geometry of `new` farther than this from the old
    edge / face is NOT matched - and a dependent whose parents stay unmatched is DELETED without a message
    (a blend on four edges was dropped when two of them had moved 20 mm; with tolerance 25 it was kept and
    followed). So the tree is compared by tag: if anything other than `old` (and allow_lost) is gone, or a
    feature carries an error, the replacement is undone and RuntimeError says what was lost.
    Returns {"gone": [...names], "errors": {...}}."""
    before = nxh.feature_state(part)
    expected = {old.Tag} | {f.Tag for f in allow_lost}              # read the tags BEFORE `old` is deleted
    m = nxh.mark("replace feature")
    b = part.Features.CreateReplaceFeatureBuilder()
    try:
        b.SelectFeature.Add(old)
        b.ReplacementFeature.Add(new)
        b.DoAutomaticGeomMatch = True
        b.DeleteOriginalFeature = bool(delete_original)
        if tolerance is not None:
            b.MappingTolerance = float(tolerance)
        b.UpdateMap()
        b.AutomatchMap()
        b.Commit()
    finally:
        b.Destroy()
    nxh.update("replace feature")
    after = nxh.feature_state(part)
    diff = nxh.state_diff(before, after)
    lost =[v[0] for k, v in before.items() if k not in after and k not in expected]
    errors = nxh.feature_errors(part)
    if lost or errors or diff["changed"]:
        nxh.undo_to(m)
        raise RuntimeError("replace_feature undone: dependents lost %s, changed %s, errors %s - raise `tolerance` or "
                           "map by hand" % (lost, [c["after"][0] for c in diff["changed"]], errors))
    return {"gone": [g[0] for g in diff["gone"]], "errors": errors}


# verified in nxf_selftest (tree group)
def sketch_internal(feature, internal=True):
    """Make the sketch of `feature` (an Extrude, Revolve ...) internal to it - one row in the tree instead of
    two - or external again. External FIRST whenever a second feature is going to use the sketch: NX does not
    stop a journal from building a second feature on an internal sketch (it commits, the sketch stays hidden
    inside the first feature with two children), and making a shared sketch internal raises 'Parent sketch
    is referenced by other objects.' Returns None."""
    if internal:
        feature.MakeSketchInternal()
    else:
        feature.MakeSketchExternal()
    nxh.update("sketch internal / external")


# verified in nxf_selftest (tree group)
def to_reference(part, curves, reference=True):
    """Convert sketch curves to reference (construction) curves, or back to active. Call while the sketch is
    ACTIVE. A feature whose section is the WHOLE sketch (nxh.section_feature / CreateRuleCurveFeature) takes
    in every active curve that is added later - a centre line then gives 'Selected objects will result in a
    self intersecting section' and the body is gone; reference curves are ignored by the section.
    Sketch POINTS are accepted too: an active point besides the profile makes the whole-sketch Extrude fail
    ('Cannot extrude. The section and direction may be incompatible.'), a reference point does not."""
    b = part.Sketches.CreateConvertToFromReferenceBuilder()
    try:
        for c in curves:
            b.InputObjects.Add(c)
        ot = NXOpen.ConvertToFromReferenceBuilder.OutputType
        b.OutputState = ot.Reference if reference else ot.Active
        b.Commit()
    finally:
        b.Destroy()


# verified in nxf_selftest (tree group)
def measure_length(part, edges_or_curves, unit="mm"):
    """Associative length measurement as a FEATURE ('Length Measurement'): returns (feature, expression).
    The expression (system name p<n>, IsMeasurementExpression) follows the geometry and may be used in
    formulas - `nxh.expr(part, "feed_x", "floor(%s)/2" % e.Name)` - so a dimension can be DERIVED from the
    model instead of typed twice. Find it again through the feature, never by its p-number."""
    objs = list(edges_or_curves)
    sc = part.ScCollectors.CreateCollector()
    rf = part.ScRuleFactory
    edges = [o for o in objs if isinstance(o, NXOpen.Edge)]
    curves = [o for o in objs if not isinstance(o, NXOpen.Edge)]
    sc.ReplaceRules(([rf.CreateRuleEdgeDumb(edges)] if edges else []) + ([rf.CreateRuleCurveDumb(curves)] if curves else []), False)
    m = part.MeasureManager.NewLength(nxh.units(part)[unit], sc)
    f = m.CreateFeature()
    return f, f.GetExpressions()[0]


# verified in nxf_selftest (tree group)
def measure_distance(part, obj1, obj2, unit="mm"):
    """Associative minimum-distance measurement between two objects (faces, edges, datum planes, points) as a
    FEATURE ('Distance Measurement'): returns (feature, expression). Use like measure_length."""
    m = part.MeasureManager.NewDistance(nxh.units(part)[unit], NXOpen.MeasureManager.MeasureType.Minimum, obj1, obj2)
    f = m.CreateFeature()
    return f, f.GetExpressions()[0]


# verified in nxf_selftest (tree group)
def import_expressions(part, path, replace=True):
    """Import an expression text file: one line per expression, `[mm]name=formula //comment`, unitless lines
    without the bracket, typed ones as `(Boolean) flag=true`; order is free, UTF-8. replace=True (Replace
    Existing) overwrites expressions of the same name - also system ones, so `[mm]p0=box_len` re-wires a
    feature parameter to a named master in one step; replace=False keeps existing ones. Regenerates.
    Returns the list of NX messages (empty = clean); raises when NX reports that nothing was imported."""
    im = NXOpen.ExpressionCollection.ImportMode
    ok, msgs = part.Expressions.ImportFromFile(path, im.Replace if replace else im.DontReplace)
    nxh.update("import expressions")
    msgs = list(msgs or [])
    if not ok and msgs:
        raise RuntimeError("import_expressions: " + "; ".join(str(x) for x in msgs)[:400])
    return msgs


# ====================================================================== feature copies: check and edit
# from nx-patterns-and-body-ops/scripts/cast_checks.py (K1 - K7), re-run in nxf_selftest (copies group)
def copy_check(part, n, seed_delta, body=None, v_base=None, copies=None, seed_faces=None, count_faces=None, tol=1e-3):
    """THE check after every Pattern Feature / Mirror Feature (and after every later edit of its count).

    n            expected number of instances INCLUDING the seed
    seed_delta   volume the COMPLETE seed adds to (+) or cuts from (-) the body: measure it as body volume after
                 the last seed feature minus body volume before the first one. For a seed that makes its own
                 body: the volume of the finished seed body.
    body, v_base copies on one body: its volume now must be v_base + n x seed_delta (v_base = before the seed)
    copies       copies that are bodies of their own: len == n - 1 and every volume == seed_delta
    count_faces  callable -> number of signature faces now (blend faces, cone faces of a chamfer, hole
                 cylinders); must be n x seed_faces
    Third test: no feature carries a message (a failed instance reports only on its Instance feature; the
    pattern itself is not suppressed and nothing raises).
    It catches the three silent failures of a feature copy: an instance that was not built, a copy of the
    uncut / unblended blank, and a dropped detail (a blend missing on the copies).
    Returns {"ok", "problems", ...}; ok is False when any of the tests fails."""
    problems, row = [], {"n": n}
    if body is not None:
        dv = nxh.volume(part, body) - v_base
        row["volume_delta"], row["expected_delta"] = dv, n * seed_delta
        if abs(dv - n * seed_delta) > tol * max(1.0, abs(seed_delta)):
            problems.append("volume delta %.3f, expected %d x %.3f = %.3f" % (dv, n, seed_delta, n * seed_delta))
    if copies is not None:
        vols = [nxh.volume(part, b) for b in copies]
        row["copy_volumes"] = [round(v, 3) for v in vols]
        if len(copies) != n - 1:
            problems.append("%d copies, expected %d" % (len(copies), n - 1))
        bad = [round(v, 3) for v in vols if abs(v - seed_delta) > tol * max(1.0, abs(seed_delta))]
        if bad:
            problems.append("%d copies differ from the finished seed (%.3f): %s" % (len(bad), seed_delta, bad[:4]))
    if count_faces is not None:
        got = count_faces()
        row["faces"], row["expected_faces"] = got, n * seed_faces
        if got != n * seed_faces:
            problems.append("%d signature faces, expected %d x %d" % (got, n, seed_faces))
    errs = nxh.feature_errors(part)
    row["messages"] = errs
    if errs:
        problems.append("feature messages: %s" % "; ".join("%s: %s" % (k, v[0] if v else "") for k, v in list(errs.items())[:3]))
    row.update({"ok": not problems, "problems": problems})
    return row


def pattern_feature(part, features, layout, variational=False):
    """Pattern Feature with a free layout callback: layout(pattern_service) sets type, spacing and options -
    for what pattern_linear / pattern_circular / pattern_along do not offer. Returns the feature."""
    return _pattern_feature(part, features, layout, variational)


def add_to_pattern(part, pattern, seed, make_detail):
    """Add a detail to every copy of an EXISTING pattern: make the seed current (insert point), build the detail
    on the seed with make_detail() -> feature or list of features, add it to the pattern's INPUT, roll forward.
    The detail then sits between the seed and the pattern in the tree and follows a later change of the count.
    Returns the detail features. Follow with copy_check."""
    S.UpdateManager.SetDefaultUpdateFailureAction(NXOpen.Update.FailureOption.AcceptAll)
    end = part.CurrentFeature
    seed.MakeCurrentFeature()                      # everything after the seed reads as suppressed until rolled forward
    try:
        detail = make_detail()
        detail = list(detail) if isinstance(detail, (list, tuple)) else [detail]
        b = part.Features.CreatePatternFeatureBuilder(pattern)
        try:
            for d in detail:
                b.FeatureList.Add(d)
            b.CommitFeature()
        finally:
            b.Destroy()
    finally:
        end.MakeCurrentFeature()                   # roll forward even when the detail failed
        nxh.update("roll forward")
    return detail


def pattern_clock(part, pattern, i, j, delta1=0, delta2=0):
    """Clocking: shift ONE instance [i][j] of an existing Pattern Feature by delta1 / delta2 along its two
    directions (the seed is [0][0]). AddInstance is required - without it the deltas are accepted and nothing
    moves. Returns nxh.feature_errors(part)."""
    b = part.Features.CreatePatternFeatureBuilder(pattern)
    try:
        cb = b.PatternService.CreateClockingBuilder(i, j)
        cb.AddInstance(i, j)
        cb.Direction1Delta.RightHandSide = str(delta1)
        if delta2:
            cb.Direction2Delta.RightHandSide = str(delta2)
        cb.Commit()
        b.CommitFeature()
    finally:
        b.Destroy()
    nxh.update("clocking")
    return nxh.feature_errors(part)


def scale_axisymmetric(part, bodies, along, other, origin=(0, 0, 0), vec=(0, 0, 1)):
    """Scale Body, Axisymmetric: factor `along` the axis (origin, vec), `other` in the directions normal to it
    (a moulding shrinkage that differs with the flow direction). Returns the feature."""
    b = part.Features.CreateScaleBuilder(NF)
    try:
        b.Type = NXOpen.Features.ScaleBuilder.Types.Axisymmetric
        b.BodyCollector = nxh.collector(part, bodies=list(bodies))
        b.Vector = nxh.direction(part, vec)
        b.Point = nxh.point(part, *origin)
        b.ScaleAlongAxis.RightHandSide = str(along)
        b.ScaleOtherDirection.RightHandSide = str(other)
        return b.CommitFeature()
    finally:
        b.Destroy()


def unite_remove_region(part, target, tool, tool_face, keep=False):
    """Unite `tool` to `target` and REMOVE (keep=False) or KEEP (keep=True) the region of the tool that carries
    tool_face - one feature instead of Trim Body + Unite (a post that overshoots the plate: the stub below is
    removed). Do not call SetOwningBody on the tracker: with it the selection is ignored and a plain Unite
    results, with no error. Returns the feature."""
    BR = GU.BooleanRegionSelect
    b = part.Features.CreateBooleanBuilderUsingCollector(NXOpen.Features.BooleanFeature.Null)
    try:
        b.Tolerance = 0.01
        b.Operation = NXOpen.Features.Feature.BooleanType.Unite
        b.Targets.Add(target)
        b.ToolBodyCollector = nxh.collector(part, bodies=[tool])
        rs = b.BooleanRegionSelect
        rs.AssignTargets([target])
        rs.SelectMethod = BR.SelectOption.KeepOrRemove
        rs.KeepRemoveToolMethod = BR.KeepRemoveOption.Keep if keep else BR.KeepRemoveOption.Remove
        tr = rs.AppendOneRegionTracker()
        tr.OnTool = True
        tr.SetOneFaceSelector(tool_face)
        return b.CommitFeature()
    finally:
        b.Destroy()


def extract_body_before(part, bodies, before):
    """An in-process copy: Extract Body fixed at its timestamp, then reordered directly BEFORE the feature
    `before` - the copy is the body as it was at that point of the tree (the blank before the holes, the
    casting before machining) while the original goes on. Returns (extract feature, new bodies)."""
    f, new = extract_body(part, bodies, fix_at_timestamp=True)
    errs = nxh.reorder(part, f, before, after=False)
    if errs:
        raise RuntimeError("extract_body_before: %s" % errs)
    return f, new


# from nx-solid-features/scripts/cast_checks.py (B4), re-run in nxf_selftest (copies group)
def sketch_on_path(part, path_rules, seed, start_xyz, percent=0):
    """Sketch On Path: a sketch plane normal to an edge / curve path at `percent` of its length. path_rules:
    selection-intent rules of the path (one dumb edge, or the tangent chain through `seed`); start_xyz: the end
    of the seed the path starts at. The sketch is left ACTIVE (add geometry in absolute coordinates with
    add(), then finish_sketch) - like new_sketch. Returns the NXOpen.Sketch."""
    auto_dimensioning_off()
    sb = part.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    try:
        nxh.fill_section(part, sb.Section, help_point=start_xyz, seed=seed, rules=path_rules)
        sb.PlaneLocation.IsPercentUsed = True
        sb.PlaneLocation.Expression.RightHandSide = str(percent)
        sk = sb.Commit()
    finally:
        sb.Destroy()
    sk.Activate(SK.ViewReorient.FalseValue)
    return sk


def variational_sweep(part, sketch, help_point=(0, 0, 0), op=None, target=None):
    """Variational Sweep: the curves of a sketch ON A PATH (sketch_on_path) swept along that path - a lip, a
    bead or a groove that stays tied to an edge chain of the body and follows it when the body changes.
    op / target: boolean inside the feature. Returns the feature (FeatureType VARIATIONAL_SWEEP)."""
    b = part.Features.CreateVarsweepBuilder(NF)
    try:
        b.DistanceTolerance = 0.01
        b.Section = nxh.section_feature(part, [sketch.Feature], help_point=help_point)
        if op is not None:
            b.BooleanOperation.Type = op
            b.BooleanOperation.SetTargetBodies([target])
        return b.CommitFeature()
    finally:
        b.Destroy()


# ====================================================================== draft types
# from nx-solid-features/scripts/draft_types.py (D1 - D4), re-run in nxf_selftest (copies group)
def draft_parting(part, faces, pull, above, below=None, parting_datum=None, parting_faces=None):
    """Draft, type Face, references method Parting Face: BOTH sides of a parting reference in one feature.
    below=None: one angle (symmetric); otherwise `above` on the +pull side of the parting reference and `below`
    on the other side. The section AT the parting reference keeps its size; both sides shrink away from it for
    positive angles. parting_datum = a DatumPlane, or parting_faces = faces of a sheet. Angles: numbers (link the
    feature expressions to unitless expressions afterwards). Returns the feature."""
    DB = NXOpen.Features.DraftBuilder
    b = part.Features.CreateDraftBuilder(NF)
    try:
        b.TypeOfDraft = DB.Type.Face
        b.AngleTolerance = 0.1
        b.DistanceTolerance = 0.01
        b.Direction = nxh.direction(part, pull)
        b.DraftReferencesMethod = DB.DraftReferencesMethods.PartingFace
        rf = part.ScRuleFactory
        rule = rf.CreateRuleFaceDatum([parting_datum]) if parting_datum is not None else rf.CreateRuleFaceDumb(list(parting_faces))
        b.PartingReference.ReplaceRules([rule], False)
        b.DraftBothSides = True
        col = nxh.collector(part, faces=list(faces))
        if below is None:
            b.SymmetricAngle = True
            b.FaceSetAngleExpressionList.Append(part.CreateExpressionCollectorSet(col, str(float(above)), "Degrees", 0))
        else:
            b.SymmetricAngle = False
            b.TwoDimensionFaceSetsData.Append(part.CreateTwoExpressionsCollectorSet(col, str(float(above)), str(float(below)), "Degrees", 0))
        return b.CommitFeature()
    finally:
        b.Destroy()


def draft_edges(part, edge_sets, pull, true_draft=False):
    """Draft, type Edge: the picked edges stay, the faces that own them are drafted - for stationary edges that
    do not lie in one plane normal to the pull. edge_sets = [(edges, angle)] (several sets = several angles in
    ONE feature). Returns the feature."""
    DB = NXOpen.Features.DraftBuilder
    b = part.Features.CreateDraftBuilder(NF)
    try:
        b.TypeOfDraft = DB.Type.Edge
        b.AngleTolerance = 0.1
        b.DistanceTolerance = 0.01
        b.Direction = nxh.direction(part, pull)
        if true_draft:
            b.DraftIsoclineOrTruedraft = DB.Method.TrueDraft
        for edges, angle in edge_sets:
            b.EdgeSetAngleExpressionList.Append(part.CreateExpressionCollectorSet(nxh.collector(part, edges=list(edges)), str(float(angle)), "Degrees", 0))
        return b.CommitFeature()
    finally:
        b.Destroy()


def draft_parting_edges(part, edges, pull, angle, stationary_plane):
    """Draft, type Parting Edge: the faces on the +pull side of the parting edges are drafted, the section at
    the stationary datum plane keeps its size, the other side of the edges keeps its shape. Where the parting
    line steps away from the plane NX adds ledge faces normal to the pull. Parting edges are usually made with
    Divide Face (split_edges finds them). Returns the feature."""
    DB = NXOpen.Features.DraftBuilder
    b = part.Features.CreateDraftBuilder(NF)
    try:
        b.TypeOfDraft = DB.Type.PartingEdge
        b.AngleTolerance = 0.1
        b.DistanceTolerance = 0.01
        b.Direction = nxh.direction(part, pull)
        b.StationaryEntity = stationary_plane                 # direct assignment (there is no .Value)
        b.EdgeSetAngleExpressionList.Append(part.CreateExpressionCollectorSet(nxh.collector(part, edges=list(edges)), str(float(angle)), "Degrees", 0))
        return b.CommitFeature()
    finally:
        b.Destroy()


def split_edges(body):
    """Edges whose two faces lie on the same plane = the edges a Divide Face made (a parting line)."""
    def same(f1, f2):
        t1, p1, d1, _r1 = nxh.face_data(f1)
        t2, p2, d2, _r2 = nxh.face_data(f2)
        return (t1 == nxh.PLANE and t2 == nxh.PLANE and all(abs(a - b) < 1e-6 for a, b in zip(d1, d2))
                and abs(sum((a - b) * n for a, b, n in zip(p1, p2, d1))) < 1e-4)
    return [e for e in body.GetEdges() if len(e.GetFaces()) == 2 and same(e.GetFaces()[0], e.GetFaces()[1])]


def divide_faces_by_sheet(part, faces, sheet):
    """Divide Face where the faces of a sheet body cross `faces` (dividing objects = the sheet's faces): the way
    to put a stepped parting line on a body. Returns the feature."""
    b = part.Features.CreateDividefaceBuilder(NF)
    try:
        b.FacesToDivide = nxh.collector(part, faces=list(faces))
        tool = b.SelectDividingObject
        tool.ToolOption = GU.SelectDividingObjectBuilder.ToolType.Object
        tool.DividingObjectsList.Add(nxh.collector(part, faces=list(sheet.GetFaces())))
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-patterns-and-body-ops/scripts/mirror_and_pattern.py (pattern_geometry_tools)
def pattern_geometry(part, bodies, linear=None, circular=None):
    """Pattern Geometry: associative COPIES of whole bodies (tool bodies, lugs).

    linear = dict(xdir=, nx=, px=[, ydir=, ny=, py=])  or  circular = dict(origin=, vec=, count=[, span=, pitch=]).
    feature.GetBodies() is empty: use the returned new bodies, and boolean the whole set with
    nxh.subtract / nxh.unite(part, target, tool_features=[source_feature, pattern_feature]) so the tool set
    follows the count. Returns (feature, new bodies)."""
    before = list(part.Bodies)
    b = part.Features.CreatePatternGeometryBuilder(NXOpen.Features.PatternGeometry.Null)
    try:
        if linear is not None:
            _linear(part, b.PatternService, **linear)
        else:
            _circular(part, b.PatternService, **circular)
        for body in bodies:
            b.GeometryToPattern.Add(body)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(part, before)


def _bool_tool(part, bt, datum_plane=None, plane=None, sheet=None, faces=None, reverse=False):
    TOOL = GU.BooleanToolBuilder.BooleanToolType
    if plane is not None:
        bt.ToolOption = TOOL.NewPlane
        bt.FacePlaneTool.ToolPlane = plane
    else:
        bt.ToolOption = TOOL.FaceOrPlane
        rf = part.ScRuleFactory
        if datum_plane is not None:
            rule = rf.CreateRuleFaceDatum([datum_plane])
        elif sheet is not None:
            rule = rf.CreateRuleFaceBody(sheet)
        else:
            rule = rf.CreateRuleFaceDumb(list(faces))
        bt.FacePlaneTool.ToolFaces.FaceCollector.ReplaceRules([rule], False)
    bt.ReverseDirection = reverse


def _trim(part, bodies, reverse, tool):
    b = part.Features.CreateTrimBody2Builder(NXOpen.Features.TrimBody2.Null)
    try:
        b.Tolerance = 0.01
        b.TargetBodyCollector = nxh.collector(part, bodies=list(bodies))
        _bool_tool(part, b.BooleanTool, reverse=reverse, **tool)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-patterns-and-body-ops/scripts/trim_split_boolean.py (trim_body, trim_keep) and surf_edit.py
def trim_body(part, body, keep_point=None, reverse=False, datum_plane=None, plane=None, sheet=None, faces=None):
    """Trim Body with ONE tool: datum_plane=DatumPlane | plane=smart plane (plane_from_datum) | sheet=sheet body |
    faces=[faces]. The tool must cross the WHOLE target ('complete intersection' error otherwise).

    Side rule: reverse=False removes the side the tool normal points to (datum plane normal / sheet face
    normal). Because the normal of a sheet is not obvious, pass keep_point=(x, y, z), a point of the body that
    must survive: the helper trims, tests that the point is still inside the body's BOUNDING BOX, and retries
    reversed otherwise. It is a bounding-box test, so choose a point near the far end of the wanted side (one
    that the discarded side's removal certainly leaves outside the box of the wrong remainder).
    Returns (feature, reverse flag used). Always check the volume afterwards."""
    tool = {k: v for k, v in (("datum_plane", datum_plane), ("plane", plane), ("sheet", sheet), ("faces", faces))
            if v is not None}
    if keep_point is None:
        return _trim(part, [body], reverse, tool), reverse
    last = None
    for rev in (False, True):
        m = nxh.mark("trim try", False)
        try:
            f = _trim(part, [body], rev, tool)
        except Exception as e:  # noqa: BLE001
            last = e
            nxh.undo_to(m)
            continue
        bb = nxh.bbox(body)
        if all(bb[i] - 1e-6 <= keep_point[i] <= bb[i + 3] + 1e-6 for i in range(3)):
            return f, rev
        nxh.undo_to(m)
    raise RuntimeError("trim_body: keep_point is on neither side (last error: %s)" % last)


# verified in nx-patterns-and-body-ops/scripts/trim_split_boolean.py (split_delete)
def split_body(part, bodies, datum_plane=None, plane=None, sheet=None, faces=None):
    """Split Body with a datum plane / smart plane / sheet / faces; several targets allowed. The solid count
    rises by the number of cuts. Returns (feature, all resulting pieces) - pick pieces by nxh.bbox / volume."""
    tool = {k: v for k, v in (("datum_plane", datum_plane), ("plane", plane), ("sheet", sheet), ("faces", faces))
            if v is not None}
    b = part.Features.CreateSplitBodyBuilderUsingCollector(NXOpen.Features.SplitBody.Null)
    try:
        b.TargetBodyCollector = nxh.collector(part, bodies=list(bodies))
        _bool_tool(part, b.BooleanTool, **tool)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, list(f.GetBodies())


# verified in nx-patterns-and-body-ops/scripts/trim_split_boolean.py (split_delete)
def delete_body(part, bodies):
    """Delete Body feature (associative; the body still exists before this feature's timestamp).
    BodyToDelete is None on a new builder: a collector is assigned. Returns the feature."""
    b = part.Features.CreateDeleteBodyBuilder(NXOpen.Features.DeleteBody.Null)
    try:
        b.BodyToDelete = nxh.collector(part, bodies=list(bodies))
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-patterns-and-body-ops/scripts/trim_split_boolean.py (move_scale)
def move_object(part, objs, kind, value, vec=(1, 0, 0), origin=(0, 0, 0)):
    """Associative Move Object feature on bodies (moves the original).

    kind "distance": value along vec | "angle": value degrees, right-hand about the axis (origin, vec) |
    "delta": value = (dx, dy, dz). Factory lives on part.BaseFeatures. Returns the feature."""
    b = part.BaseFeatures.CreateMoveObjectBuilder(NXOpen.Features.MoveObject.Null)
    try:
        tm = b.TransformMotion
        if kind == "distance":
            tm.Option = MOTION.Distance
            tm.DistanceVector = nxh.direction(part, vec)
            tm.DistanceValue.RightHandSide = str(value)
        elif kind == "angle":
            tm.Option = MOTION.Angle
            tm.AngularAxis = nxh.axis(part, origin, vec)
            tm.Angle.RightHandSide = str(value)
        elif kind == "delta":
            tm.Option = MOTION.DeltaXyz
            tm.DeltaEnum = GU.ModlMotion.Delta.ReferenceWcsWorkPart
            tm.DeltaXc.RightHandSide = str(value[0])
            tm.DeltaYc.RightHandSide = str(value[1])
            tm.DeltaZc.RightHandSide = str(value[2])
        else:
            raise ValueError("move_object kind: " + str(kind))
        for o in objs:
            b.ObjectToMoveObject.Add(o)
        b.MoveObjectResult = NXOpen.Features.MoveObjectBuilder.MoveObjectResultOptions.MoveOriginal
        b.Associative = True
        b.MoveParents = False
        return b.Commit()
    finally:
        b.Destroy()


# verified in nx-patterns-and-body-ops/scripts/sweeps_and_links.py (extract)
def extract_body(part, bodies, fix_at_timestamp=True):
    """Extract Body: associative copy of whole bodies in the same part. fix_at_timestamp=True freezes the copy
    at this point of the tree; False makes it follow later features of the source. Returns (feature, new bodies)."""
    EF = NXOpen.Features.ExtractFaceBuilder
    before = list(part.Bodies)
    b = part.Features.CreateExtractFaceBuilder(NF)
    try:
        b.Type = EF.ExtractType.Body
        b.ParentPart = EF.ParentPartType.WorkPart
        b.Associative = True
        b.FixAtCurrentTimestamp = fix_at_timestamp
        b.HideOriginal = False
        b.ExtractBodyCollector.ReplaceRules([part.ScRuleFactory.CreateRuleBodyDumb(list(bodies), True)], False)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(part, before)


# verified in nx-patterns-and-body-ops/scripts/trim_split_boolean.py (move_scale)
def scale_body(part, bodies, factor, about=(0, 0, 0)):
    """Uniform Scale Body about a point (mould shrinkage: a unitless expression such as 1.005). Returns the feature."""
    b = part.Features.CreateScaleBuilder(NF)
    try:
        b.Type = NXOpen.Features.ScaleBuilder.Types.Uniform
        b.BodyCollector = nxh.collector(part, bodies=list(bodies))
        b.Point = nxh.point(part, *about)
        b.UniformFactor.RightHandSide = str(factor)
        return b.CommitFeature()
    finally:
        b.Destroy()


# ====================================================================== synchronous modelling
# verified in nx-synchronous-modeling/scripts/sync_face_edits.py, sync_relate_reuse.py, sync_imported_body.py
def rule_faces(part, kind, arg):
    """ONE face selection-intent rule, for the `faces` argument of the synchronous helpers.

    "dumb"            arg = [faces]            exactly these faces
    "tangent"         arg = seed face          the seed and every face tangent to it (a wall loop with its blends)
    "connected_blend" arg = seed blend face    the chain of connected blend faces
    "all_blend"       arg = body               every blend face of the body
    "feature"         arg = [features]         all faces of those features (extracted / linked faces: associative)
    "datum"           arg = DatumPlane         a datum plane used as a face (Replace Face target)
    "body"            arg = body               every face of the body
    "boss_pocket"     arg = seed face          the boss or pocket the seed belongs to"""
    rf = part.ScRuleFactory
    if kind == "dumb":
        return rf.CreateRuleFaceDumb(list(arg))
    if kind == "tangent":
        return rf.CreateRuleFaceTangent(arg, [])
    if kind == "connected_blend":
        return rf.CreateRuleFaceConnectedBlend(arg)
    if kind == "all_blend":
        return rf.CreateRuleFaceAllBlend(arg)
    if kind == "feature":
        return rf.CreateRuleFaceFeature(list(arg))
    if kind == "datum":
        return rf.CreateRuleFaceDatum([arg])
    if kind == "body":
        return rf.CreateRuleFaceBody(arg)
    if kind == "boss_pocket":
        return rf.CreateRuleFaceBossPocket(arg)
    raise ValueError("rule_faces kind: " + str(kind))


def _rules(part, faces):
    """faces argument -> rule list: a face, a list of faces, a DatumPlane, one rule, or a list of rules."""
    if isinstance(faces, NXOpen.DatumPlane):
        return [part.ScRuleFactory.CreateRuleFaceDatum([faces])]
    if isinstance(faces, NXOpen.Face):
        return [part.ScRuleFactory.CreateRuleFaceDumb([faces])]
    if not isinstance(faces, (list, tuple)):
        return [faces]                                   # one selection-intent rule
    faces = list(faces)
    if faces and isinstance(faces[0], NXOpen.DatumPlane):
        return [part.ScRuleFactory.CreateRuleFaceDatum(faces)]
    if faces and not isinstance(faces[0], NXOpen.Face):
        return faces                                     # a list of rules
    return [part.ScRuleFactory.CreateRuleFaceDumb(faces)]


# verified in nx-synchronous-modeling/scripts/sync_face_edits.py (c_offset_region*)
def offset_region(part, faces, distance, reverse=False):
    """Offset Region. POSITIVE distance = along the outward normal = ADDS material (a hole gets smaller, a
    boss or the outside gets bigger); negative removes. Neighbouring blends follow. faces: face list or
    rule_faces(...). Factory needs AdmOffsetRegion.Null. Returns the feature (expression-driven distance)."""
    b = part.Features.CreateAdmOffsetRegionBuilder(NXOpen.Features.AdmOffsetRegion.Null)
    try:
        b.FaceToOffset.FaceCollector.ReplaceRules(_rules(part, faces), False)
        b.Distance.RightHandSide = str(distance)
        b.ReverseDirection = reverse
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_face_edits.py (c_move_distance / c_move_angle / c_move_points)
def find_related(recognition, relations):
    """Face Finder from a journal: after the rules are in `recognition.FaceCollector` (the FaceToMove /
    FaceToOffset / FaceToResize of a synchronous builder), pull in the faces NX finds by a relation.
    relations: names out of "offset" (the other side of a thin wall), "coplanar", "equal_diameter",
    "coaxial", "symmetric", "tangent", "parallel", "perpendicular", "thickness_chain".
    Both steps are needed - the <Name>Enabled flag AND Recognize<Name>(True); with False ("far" relations)
    or the flag alone nothing is added (measured). Verified: offset and coplanar on Move Face, equal_diameter
    on Resize Face. Returns the number of faces now in the collector - check it."""
    names = {"offset": "Offset", "coplanar": "Coplanar", "equal_diameter": "EqualDiameter", "coaxial": "Coaxial",
             "symmetric": "Symmetric", "tangent": "Tangent", "parallel": "Parallel", "perpendicular": "Perpendicular",
             "thickness_chain": "ThicknessChain"}
    for r in ([relations] if isinstance(relations, str) else list(relations)):
        n = names[r]
        setattr(recognition, n + "Enabled", True)
        getattr(recognition, "Recognize" + n)(True)
    return len(recognition.FaceCollector.GetObjects())


# verified in nx-synchronous-modeling/scripts/sync_face_edits.py (c_move_distance / c_move_angle / c_move_points);
# finder / cut_paste in sync_thin_walls.py and sync_command_choice.py
def move_face(part, faces, vec=None, distance=None, angle=None, origin=(0, 0, 0), points=None, finder=None,
              cut_paste=False):
    """Move Face. One of:
      distance + vec           translate the faces `distance` along vec (the neighbours extend / trim)
      angle + vec + origin     rotate right-handed by `angle` degrees about the axis (origin, vec)
      points=(from, to)        translate by the vector between two (x, y, z) points (e.g. move a hole)
    finder: Face Finder relations to add to the selection, see find_related - finder="offset" takes the
    inner partner faces of a thin wall along (or pass them yourself: faces + nxh.wall_partners(faces)).
    cut_paste=True: MoveOption Cut and Paste with heal and paste (the faces are cut out, the wound healed,
    the faces pasted at the new place) instead of Move and Adapt.
    Returns the feature."""
    b = part.Features.CreateAdmMoveFaceBuilder(NXOpen.Features.AdmMoveFace.Null)
    try:
        b.FaceToMove.FaceCollector.ReplaceRules(_rules(part, faces), False)
        if finder:
            find_related(b.FaceToMove, finder)
        if cut_paste:
            b.MoveOption = NXOpen.Features.AdmMoveFaceBuilder.MoveOptionType.CutAndPaste
            b.HealOption = True
            b.PasteOption = True
        m = b.Motion
        if points is not None:
            m.Option = MOTION.PointToPoint
            m.FromPoint = nxh.point(part, *points[0])
            m.ToPoint = nxh.point(part, *points[1])
        elif angle is not None:
            m.Option = MOTION.Angle
            m.AngularAxis = nxh.axis(part, origin, vec)
            m.Angle.RightHandSide = str(angle)
        else:
            m.Option = MOTION.Distance
            m.DistanceVector = nxh.direction(part, vec)
            m.DistanceValue.RightHandSide = str(distance)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_round4_checks.py, sync_relate_reuse.py and nxf_selftest (sync)
def pull_face(part, faces, vec, distance):
    """Pull Face: translate the faces `distance` along vec and build NEW side walls between the old boundary
    and the moved face (an extrusion of the face). Move Face / Offset Region instead extend or trim the
    NEIGHBOUR faces - on a face whose neighbours are inclined, blended or cannot be extended those fail or
    change the footprint, Pull Face keeps the footprint and just makes the walls longer. Positive distance
    along the outward normal adds material, against it cuts a pocket of the face's outline.
    faces: face list, one face or rule_faces(...) - also a region-boundary rule (part of a face bounded by
    curves: no Divide Face needed). vec: (x, y, z) or an object (associative direction). Returns the feature."""
    b = part.Features.CreatePullFaceBuilder(NXOpen.Features.PullFace.Null)
    try:
        b.FaceToPull.ReplaceRules(_rules(part, faces), False)
        b.Motion.Option = MOTION.Distance
        b.Motion.DistanceVector = _direction(part, vec)
        b.Motion.DistanceValue.RightHandSide = str(distance)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_round4_checks.py, sync_edit_scope.py and nxf_selftest (sync)
def label_chamfer(part, chamfer_faces, face1, face2):
    """Label Chamfer: tell NX that planar / conical faces of a parameter-less body are a chamfer between face1
    and face2, so that a later synchronous edit of a neighbour carries the chamfer at its size instead of
    stretching it. Measured on a 5 x 5 chamfer of a 60 x 40 x 20 block, Offset Region +3 of the face above:
    54700 with the label (the chamfer moved up). Without the label the result depends on whether NX recognises
    the chamfer by itself: 53920 (chamfer plane stretched) on one parameter-less body, but 54700 on a body
    whose chamfer was made and stripped of parameters in the same session - so label when it matters and
    measure. It does NOT save a chamfer that the edit swallows completely (a bore resized past the chamfer's
    outer edge leaves a plain bore, labelled or not). chamfer_faces: one face or a list. Returns the feature."""
    b = part.Features.CreateLabelChamferBuilder(NXOpen.Features.LabelChamfer.Null)
    try:
        rf = part.ScRuleFactory
        cf = [chamfer_faces] if isinstance(chamfer_faces, NXOpen.Face) else list(chamfer_faces)
        b.ChamferFace.ReplaceRules([rf.CreateRuleFaceDumb(cf)], False)
        b.ConstructionFace1.ReplaceRules([rf.CreateRuleFaceDumb([face1])], False)
        b.ConstructionFace2.ReplaceRules([rf.CreateRuleFaceDumb([face2])], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_face_edits.py (c_replace*), sync_imported_body.py (linked face),
# surf_edit.py and acceptance build 3 (ReverseDirection)
def replace_face(part, faces, replacement, offset=0, offset_reverse=False, reverse=False, accept=None):
    """Replace Face: the faces are re-laid onto `replacement` (a DatumPlane, faces of this or another body, or
    rule_faces("feature", [extract_face / WAVE link feature]) for an associative link); the neighbours extend
    or trim. offset is measured along the normal of the replacement; offset_reverse flips it.

    reverse -> ReplaceFaceBuilder.ReverseDirection. Rule: the replaced face and the replacement must end up
    with the same outward normal.
      * replacement normal points the SAME way as the face (top +Z onto another top face +Z) or it is a datum
        plane -> reverse=False;
      * replacement normal is OPPOSED - the usual case for a MATING face (boss top +Z onto the bottom face -Z
        of the part that sits on it, a linked PCB underside) -> reverse=True; with False NX raises
        'A face does not intersect properly and its edges cannot adapt.'
      * reverse=None tries False, then True, rolling back in between; the first one that commits (and for
        which accept() returns True, when a zero-argument check is given, e.g.
        lambda: abs(nxh.volume(part, body) - want) < 0.01) is kept.
    Returns the feature."""
    def run(rev):
        b = part.Features.CreateReplaceFaceBuilder(NF)
        try:
            b.FaceToReplace.ReplaceRules(_rules(part, faces), False)
            b.ReplacementFaces.ReplaceRules(_rules(part, replacement), False)
            b.OffsetDistance.RightHandSide = str(offset)
            b.OffsetReverseDirection = offset_reverse
            b.ReverseDirection = bool(rev)
            return b.CommitFeature()
        finally:
            b.Destroy()

    if reverse is not None:
        return run(reverse)
    last = None
    for rev in (False, True):
        m = nxh.mark("replace face", False)
        try:
            f = run(rev)
            if accept is None or accept():
                return f
            last = RuntimeError("accept() rejected ReverseDirection=%s" % rev)
        except NXOpen.NXException as e:
            last = e
        nxh.undo_to(m)
    raise RuntimeError("replace_face: neither direction worked (%s)" % last)


# verified in nx-synchronous-modeling/scripts/sync_face_edits.py (c_delete_*)
def delete_face(part, faces, heal=True, cap=None):
    """Delete Face. heal=True closes the wound by extending the neighbours (holes, blends, bosses vanish);
    it raises '... cannot close ...' when the neighbours cannot meet (e.g. a wall of a block).
    cap=<face or DatumPlane>: explicit cap for that case - the neighbours run up to the cap (the body grows
    to it or is cut back to it). heal=False leaves the body OPEN - it becomes a sheet body. Returns the feature."""
    b = part.Features.CreateDeleteFaceBuilder(NF)
    try:
        b.Type = NXOpen.Features.DeleteFaceBuilder.SelectTypes.Face
        b.FaceCollector.ReplaceRules(_rules(part, faces), False)
        b.Heal = heal
        if cap is not None:
            b.CapOption = NXOpen.Features.DeleteFaceBuilder.CapOptionValues.FaceOrPlane
            b.CapFace.Value = cap
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_command_choice.py (simplified copy) and nxf_selftest (sync)
def delete_holes(part, faces, max_diameter):
    """Delete Face, type Hole with the size filter: every hole up to `max_diameter` among `faces` is removed
    and healed, larger ones stay. faces: a face list, a body (all its faces) or rule_faces(...). The way to
    make a SIMPLIFIED copy for analysis: nxf.extract_body first, then delete on the copy. Returns the feature."""
    DF = NXOpen.Features.DeleteFaceBuilder
    b = part.Features.CreateDeleteFaceBuilder(NF)
    try:
        b.Type = DF.SelectTypes.Hole
        rules = [part.ScRuleFactory.CreateRuleFaceBody(faces)] if isinstance(faces, NXOpen.Body) else _rules(part, faces)
        b.FaceCollector.ReplaceRules(rules, False)
        b.UseHoleDiameter = True
        b.MaxHoleDiameter.RightHandSide = str(max_diameter)
        b.Heal = True
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_face_edits.py (c_resize_face); finder in sync_command_choice.py
def resize_face(part, faces, diameter, finder=None):
    """Resize Face: new DIAMETER for cylindrical faces (holes, bosses, pins), axis unchanged.
    finder="equal_diameter" resizes every hole of the same diameter with the selected one (find_related).
    Returns the feature."""
    b = part.Features.CreateAdmResizeFaceBuilder(NXOpen.Features.AdmResizeFace.Null)
    try:
        b.FaceToResize.FaceCollector.ReplaceRules(_rules(part, faces), False)
        if finder:
            find_related(b.FaceToResize, finder)
        b.Diameter.RightHandSide = str(diameter)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_face_edits.py (c_resize_blend, c_resize_blend_chain)
def resize_blend(part, faces, radius):
    """Resize Blend: new RADIUS for existing blend faces (also on imported bodies). faces: blend faces or
    rule_faces("connected_blend", seed). Returns the feature."""
    b = part.Features.CreateResizeBlendBuilder(NF)
    try:
        b.BlendFace.ReplaceRules(_rules(part, faces), False)
        b.Radius.RightHandSide = str(radius)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_command_choice.py (blends) and nxf_selftest (sync)
def blend_census(part, body):
    """Which rounds of a parameter-less body NX recognises as blends - ask BEFORE moving faces next to them.

    Returns {"recognised": {radius: count}, "unrecognised": [faces]}. `recognised` = faces the Resize Blend
    test accepts (they follow a neighbouring face edit at their radius and can be resized). `unrecognised` =
    curved faces that are tangent to at least two different neighbours along their edges but are NOT accepted:
    B-surface blends of a STEP import, conic blends, a fillet in a notch. A face edit next to one of them
    stretches or drags it; Resize Blend on it raises 'The change failed.' Cure: replace_blend (B-surface,
    non-circular section) or label_notch_blend (circular but not tangent-recognised), or delete_face and
    blend again. A tangent run-out that is no blend at all (the round end of a slot wall) is listed too:
    treat the list as candidates and look at the face type and size. Leaves the expression list as found."""
    before = {e.Tag for e in part.Expressions}
    rb = part.Features.CreateResizeBlendBuilder(NF)
    rec, unrec = {}, []
    try:
        for f in body.GetFaces():
            info = nxh.face_info(part, f, rb)
            if info["is_blend"]:
                k = round(info.get("blend_radius", info["radius"]), 3)
                rec[k] = rec.get(k, 0) + 1
                continue
            if info["type"] == nxh.PLANE:
                continue
            nb = set()
            for e in f.GetEdges():
                if edge_convexity(part, e) == "smooth":
                    nb.update(g.Tag for g in e.GetFaces() if g.Tag != f.Tag)
            if len(nb) >= 2:
                unrec.append(f)
    finally:
        rb.Destroy()
        for e in [x for x in part.Expressions if x.Tag not in before]:
            try:
                part.Expressions.Delete(e)
            except Exception:  # noqa: BLE001
                pass
    return {"recognised": rec, "unrecognised": unrec}


# verified in nx-synchronous-modeling/scripts/sync_command_choice.py (blends) and nxf_selftest (sync)
def replace_blend(part, faces, radius=None):
    """Replace Blend: turn blend-like faces NX does not recognise (B-surface blends of an import, conic
    sections) into true rolling-ball blends, so that they can be resized and follow face edits.
    radius=None inherits the radius NX fits to each face (a conic 5 / 3.33 blend became R4.3, volume +0.2);
    radius=<value> sets it. Afterwards resize_blend works on them. faces: face list or rule. Returns the feature."""
    b = part.Features.CreateReplaceBlendBuilder(NXOpen.Features.ReplaceBlend.Null)
    try:
        b.FaceToReblend.ReplaceRules(_rules(part, faces), False)
        if radius is None:
            b.InheritRadiusFromFace = True
        else:
            b.InheritRadiusFromFace = False
            b.ControlRadius.RightHandSide = str(radius)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_course_commands.py (label notch) and nxf_selftest (sync)
def label_notch_blend(part, faces):
    """Label Notch Blend: tell NX that cylindrical faces it does not recognise (a fillet in a step / notch
    corner, tangent on one side only) are blends; resize_blend then works on them ('The change failed.'
    without the label). ResizeBlendBuilder.IsBlendFace stays False after labelling. Returns the feature."""
    b = part.Features.CreateLabelNotchBlendBuilder(NXOpen.Features.LabelNotchBlend.Null)
    try:
        b.FaceToLabel.ReplaceRules(_rules(part, faces), False)
        b.DeleteLabel = False
        return b.CommitFeature()
    finally:
        b.Destroy()


def _pick_point(obj):
    """A point ON an edge (its middle) or a face (a point of the trimmed face), for SelectNXObject.SetValue."""
    if isinstance(obj, NXOpen.Edge):
        return list(UFS.ModlGeneral.AskCurveProps(obj.Tag, 0.5)[0])
    if isinstance(obj, NXOpen.Face):
        return nxh.face_mid_normal(obj)[0]
    return [0.0, 0.0, 0.0]


# verified in nx-synchronous-modeling/scripts/sync_command_choice.py (dimensions) and nxf_selftest (sync)
def linear_dimension(part, origin, measure, faces, value, axis="X", plane=None):
    """Linear Dimension (synchronous): move `faces` until the distance from `origin` (the fixed reference) to
    `measure` (the side that moves), measured along `axis`, reads `value` - a TARGET, stored in the feature
    and editable later through its expression (feature.GetExpressions()[0], descriptor 'Distance').

    origin / measure: linear EDGES (verified); axis: "X", "Y" or "Z"; plane: the OrientXpress plane the
    dimension lies in, "Xy" / "Xz" / "Yz" (default: one that contains the axis). faces: face list (the first
    one is passed to SetFaceToMove).
    Two things make it commit in a batch session: b.GetDimension() (creates the display dimension the
    feature stores) and the OrientXpress plane; without the first NX raises 'An invalid tag was passed to
    the tag module.', without the second 'Vectors are parallel.' Returns the feature."""
    LB = NXOpen.Features.LinearDimensionBuilder
    flist = [faces] if isinstance(faces, NXOpen.Face) else list(faces)
    b = part.Features.CreateLinearDimensionBuilder(NXOpen.Features.LinearDimension.Null)
    try:
        view = part.ModelingViews.WorkView
        b.OriginObject.SetValue(origin, view, P(*_pick_point(origin)))
        b.MeasurementObject.SetValue(measure, view, P(*_pick_point(measure)))
        ox = b.DimensionOrientation
        b.OrientationOption = LB.OrientationOptionType.OrientXpress
        ox.AxisOption = getattr(type(ox).Axis, axis.upper())
        plane = plane or {"X": "Xy", "Y": "Xy", "Z": "Xz"}[axis.upper()]
        ox.PlaneOption = getattr(type(ox).Plane, plane)
        b.FacesToMove.FaceCollector.ReplaceRules(_rules(part, flist), False)
        b.SetFaceToMove(flist[0])
        b.GetDimension()
        b.Value.RightHandSide = str(value)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_command_choice.py (dimensions) and nxf_selftest (sync)
def radial_dimension(part, faces, value, diameter=True, finder=None):
    """Radial Dimension (synchronous): give cylindrical faces the diameter (or radius) `value` - a TARGET
    stored in the feature (expression descriptor 'Diameter' / 'Radius'), so it can be driven by a named
    expression afterwards. faces: face list; finder="equal_diameter" takes equal holes along (find_related).
    Needs b.GetDimension() before the commit in a batch session. Returns the feature."""
    RB = NXOpen.Features.RadialDimensionBuilder
    flist = [faces] if isinstance(faces, NXOpen.Face) else list(faces)
    b = part.Features.CreateRadialDimensionBuilder(NXOpen.Features.RadialDimension.Null)
    try:
        b.FacesToMove.FaceCollector.ReplaceRules(_rules(part, flist), False)
        if finder:
            find_related(b.FacesToMove, finder)
        b.PickPoint = P(*_pick_point(flist[0]))
        b.RadiusDiameterOption = RB.ValueOption.Diameter if diameter else RB.ValueOption.Radius
        b.GetDimension()
        b.Value.RightHandSide = str(value)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_command_choice.py (dimensions) and nxf_selftest (sync)
def angular_dimension(part, origin, measure, faces, value, alternative=False):
    """Angular Dimension (synchronous): rotate `faces` until the angle between the planar faces `origin`
    (fixed) and `measure` (moves) reads `value` degrees; the faces turn about the line where the two planes
    meet. The reading is the angle between the two OUTWARD normals (a wall square to the top reads 90; 100
    leans it 10 deg inward at the far end); alternative=True uses the 360 - angle reading. Measure the
    result (nxh.normal_at). Needs b.GetDimension() before the commit. Returns the feature."""
    flist = [faces] if isinstance(faces, NXOpen.Face) else list(faces)
    b = part.Features.CreateAngularDimensionBuilder(NXOpen.Features.AngularDim.Null)
    try:
        view = part.ModelingViews.WorkView
        b.OriginObject.SetValue(origin, view, P(*_pick_point(origin)))
        b.MeasurementObject.SetValue(measure, view, P(*_pick_point(measure)))
        b.FacesToMove.FaceCollector.ReplaceRules(_rules(part, flist), False)
        if alternative:
            b.AlternativeAngle = True
        b.GetDimension()
        b.Value.RightHandSide = str(value)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_face_edits.py (c_divide_offset); both-direction retry from the acceptance test
def divide_face_offset(part, face, edges, distance):
    """Divide Face with the 'Offset Curve in Face' tool: offsets `edges` (edges of the face, usually all of
    them) by `distance` inside the face and splits it into a rim and an inner region (then offset_region the
    inner region for a boss / recess). One commit adds two features (OFFSET_IN_FACE + DIVIDE_FACE).

    Which OffsetDirection flag lies INSIDE the face is NOT predictable from the loop type: it follows the
    direction of the seed edge (edges[0]), and on identical geometry the flag differed between runs. So the
    flag is not an input and its value means nothing: the contract is try False, then True, and accept the
    direction for which the commit succeeds AND the body gained a face (the wrong side raises 'Dividing
    objects do not divide selected faces'). Find the new region afterwards by position / area, never by the
    flag. The offset of an arc is a spline within the modelling tolerance (R8 measured as 8.002).
    Returns (feature, flip flag used - informational only)."""
    body = face.GetBody()
    n0 = len(body.GetFaces())
    edges = list(edges)
    hp = _mid(edges[0])
    last = None
    for flip in (False, True):
        m = nxh.mark("divide face", False)
        b = part.Features.CreateDividefaceBuilder(NF)
        try:
            b.FacesToDivide = nxh.collector(part, faces=[face])
            tool = b.SelectDividingObject
            tool.ToolOption = GU.SelectDividingObjectBuilder.ToolType.OffsetCurveInFace
            tool.CurvesToOffset.AddToSection([part.ScRuleFactory.CreateRuleEdgeDumb(edges)], edges[0], NULL, NULL,
                                             P(*hp), NXOpen.Section.Mode.Create, False)
            tool.OffsetDistance.RightHandSide = str(distance)
            tool.OffsetDirection = flip
            f = b.CommitFeature()
            ok = True
        except NXOpen.NXException as e:
            last, ok = e, False
        finally:
            b.Destroy()
        if ok and len(body.GetFaces()) > n0:
            return f, flip
        nxh.undo_to(m)
    raise RuntimeError("divide_face_offset: neither offset direction divides the face (%s)" % last)


# verified in nx-synchronous-modeling/scripts/sync_course_commands.py (divide_by_datum)
def divide_face_by_plane(part, faces, datum_plane):
    """Divide Face(s) where a DatumPlane crosses them. The plane must go in through a collector with a
    FaceDatum rule (adding the DatumPlane itself: 'Missing dividing objects'). Returns the feature."""
    b = part.Features.CreateDividefaceBuilder(NF)
    try:
        b.FacesToDivide = nxh.collector(part, faces=list(faces))
        tool = b.SelectDividingObject
        tool.ToolOption = GU.SelectDividingObjectBuilder.ToolType.Object
        tool.DividingObjectsList.Add(nxh.collector(part, datum_planes=[datum_plane]))
        return b.CommitFeature()
    finally:
        b.Destroy()


# from nx-curves-and-sketches/scripts/offset_checks.py (_divide), re-run in nxf_selftest (sync)
def divide_face_by_curves(part, faces, curves=None, curve_features=None, extend=False, vector=None):
    """Divide Face(s) by curves lying on or over them: dumb `curves` and / or all curves of `curve_features`.
    The projection direction is SET to the face normal (vector=(x, y, z): along that vector instead): the
    builder's default is the normal of the CURVE's plane, and for a planar curve lying on the face that divides
    along the rulings through the curve ends, not along the curve - without an error. extend=True runs a curve
    that stops short on to the face boundary. Returns the feature; check that the face count grew."""
    b = part.Features.CreateDividefaceBuilder(NF)
    try:
        b.FacesToDivide = nxh.collector(part, faces=list(faces))
        tool = b.SelectDividingObject
        tool.ToolOption = GU.SelectDividingObjectBuilder.ToolType.Object
        rules = []
        if curves:
            rules.append(part.ScRuleFactory.CreateRuleCurveDumb(list(curves)))
        if curve_features:
            rules.append(part.ScRuleFactory.CreateRuleCurveFeature(list(curve_features)))
        sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        sec.AddToSection(rules, NULL, NULL, NULL, P(0, 0, 0), NXOpen.Section.Mode.Create, False)
        tool.DividingObjectsList.Add(sec)
        b.ExtendOption = bool(extend)
        dt = GU.ProjectionOptions.DirectionType
        if vector is None:
            b.ProjectionOption.ProjectDirectionMethod = dt.FaceNormal
        else:
            b.ProjectionOption.ProjectDirectionMethod = dt.Vector
            b.ProjectionOption.ProjectVector = nxh.direction(part, vector)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_face_edits.py (remove_parameters + BREP edits)
def remove_parameters(part, bodies):
    """Remove Parameters: the bodies become unparameterised BREP features ('Body(n)'), like an imported STEP
    body; their feature history and expressions are gone. Irreversible apart from undo. Returns None."""
    b = part.Features.CreateRemoveParametersBuilder()
    try:
        for body in bodies:
            b.Objects.Add(body)
        b.Commit()
    finally:
        b.Destroy()


# verified in nx-synchronous-modeling/scripts/sync_course_commands.py (optimize) and sync_command_choice.py (blends)
def optimize_face(part, body, tolerance=0.01):
    """Optimize Face on a whole body: merges split faces and re-types faces to simpler surfaces where they fit
    (two half cylinders -> one hole wall; a B-surface that is really an extrusion -> an extruded face). No
    feature is added, and it STRIPS THE PARAMETERS of a native body - imported / parameter-less bodies only.
    It does not by itself make NX recognise a blend: a conic B-surface blend became an extruded face that
    Resize Blend still refuses (use replace_blend). Returns (faces before, faces after)."""
    n0 = len(body.GetFaces())
    b = part.Features.CreateOptimizeFaceBuilder()
    try:
        b.FacesToOptimize.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(body)], False)
        b.CleanBody = True
        b.Report = False
        b.DistanceTolerance = float(tolerance)
        b.Commit()
    finally:
        b.Destroy()
    return n0, len(body.GetFaces())


# ====================================================================== surfaces
# verified in nx-surface-modeling/scripts/surf_build.py (1-4, 11)
def through_curves(part, sections, solid=False, preserve=False, align=None, g1_first=None, g1_last=None):
    """Through Curves (loft) through 2+ section strings = nxh.section(...) objects, in order.

    Every string must START at corresponding points and run the same way (help_point of nxh.section picks the
    start end; repair with sec.ReverseDirection() / SetStartAndDirection / SetStartCurveOfClosedLoop): a
    mismatch gives a VALID but twisted body of the wrong volume - always measure.
    solid=True: closed sections give a solid. preserve=True keeps sharp corners (one face per segment).
    g1_first / g1_last: faces the first / last section must be tangent (G1) to. Returns the feature."""
    TCB = NXOpen.Features.ThroughCurvesBuilder
    b = part.Features.CreateThroughCurvesBuilder(NF)
    try:
        b.PreserveShape = preserve
        b.PatchType = TCB.PatchTypes.Multiple
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.BodyPreference = TCB.BodyPreferenceTypes.Solid if solid else TCB.BodyPreferenceTypes.Sheet
        for s in sections:
            b.SectionsList.Append(s)
        b.Alignment.SetSections(list(sections))
        if align is not None:
            b.Alignment.AlignType = align
        for cont, faces in ((b.FirstSectionContinuity, g1_first), (b.LastSectionContinuity, g1_last)):
            if faces:
                cont.ContinuityType = GU.Continuity.ContinuityTypes.G1
                cont.ConstraintFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-patterns-and-body-ops/scripts/community_checks.py (C8) and nxf_selftest (swept axis)
def helix(part, diameter, pitch, turns, right_hand=True):
    """Helix feature of constant diameter and pitch along +Z from the WCS origin (builder defaults): it starts
    at (diameter/2, 0, 0); length = turns x sqrt((pi x diameter)^2 + pitch^2). Formulas allowed. Use it as the
    guide of tube() (round wire: exact faces) or swept(..., axis=(0, 0, 1)) (any other section).
    Returns the feature; its curve is feature.GetEntities()[0]."""
    HB = NXOpen.Features.HelixBuilder
    b = part.Features.CreateHelixBuilder(NXOpen.Features.Helix.Null)
    try:
        b.Type = HB.Types.AlongVector
        b.SizeOption = HB.SizeOptions.Diameter
        b.SizeLaw.LawType = GU.LawBuilder.Type.Constant
        b.SizeLaw.Value.RightHandSide = str(diameter)
        b.PitchLaw.LawType = GU.LawBuilder.Type.Constant
        b.PitchLaw.Value.RightHandSide = str(pitch)
        b.LengthMethod = HB.LengthMethods.Turns
        b.Turns.RightHandSide = str(turns)
        b.TurnDirection = HB.TurnDirections.RightHand if right_hand else HB.TurnDirections.LeftHand
        b.DistanceTolerance = 0.01
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-surface-modeling/scripts/surf_build.py (7); axis= in community_checks.py (C8) and nxf_selftest
def swept(part, sections, guides, solid=False, scaling=None, axis=None):
    """Swept: 1+ section strings along 1-3 guide strings (nxh.section objects). Two guides need
    scaling=GU.ScalingMethodBuilder.ScalingOptions.Uniform or Lateral. The result is a B-surface body
    (volume ~0.15 % low on arc guides); for exact faces use sweep_along_guide.
    axis=(x, y, z): orientation By Vector Direction - the section keeps its attitude to that vector while it
    travels. NEEDED on a helix or any 3D guide (pass the helix axis): with the default (Fixed) orientation the
    section rolls about the path (measured: a 4 x 2 wire section ends 3.78 x 4.44, a blade is 4 mm off the true
    helicoid). Returns the feature."""
    b = part.Features.CreateSweptBuilder(NXOpen.Features.Swept.Null)
    try:
        b.G0Tolerance = 0.01
        b.G1Tolerance = 0.5
        for s in sections:
            b.SectionList.Append(s)
        b.AlignmentMethod.SetSections(list(sections))
        for g in guides:
            b.GuideList.Append(g)
        if scaling is not None:
            b.ScalingMethod.ScalingOption = scaling
        if axis is not None:
            b.OrientationMethod.OrientationOption = GU.OrientationMethodBuilder.OrientationOptions.ByVectorDirection
            b.OrientationMethod.OrientationVector = _direction(part, axis)        # vector, or a datum axis / edge
        b.BodyPreference.BodyType = SOLID if solid else SHEET
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-surface-modeling/scripts/surf_build.py (10, 11)
def bounded_plane(part, curves=None, edges=None, hp=(0, 0, 0)):
    """Planar sheet from a closed coplanar loop of curves and/or edges; inner closed loops become holes.
    BoundingCurves is builder-owned (filled in place). hp: a point at the start of the first curve. Returns the feature."""
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.BoundingCurves, curves, edges, hp)
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-surface-modeling/scripts/surf_build.py (10)
def fill_surface(part, curves=None, edges=None, hp=(0, 0, 0), g1=False, patch=False):
    """Fill Surface over a closed chain of curves / edges, planar or not. g1=True: tangent to the faces of
    the boundary edges (the default continuity is set BEFORE the chain is filled). patch=True sews the fill
    into the sheet that owns the edges. Factory on part.Features.FreeformSurfaceCollection. Returns the feature."""
    FHB = NXOpen.Features.FillHoleBuilder
    b = part.Features.FreeformSurfaceCollection.CreateFillHoleBuilder(NXOpen.Features.FillHole.Null)
    try:
        b.Tolerance = 0.01
        b.DefaultEdgeContinuity = FHB.ContinuityTypes.G1 if g1 else FHB.ContinuityTypes.G0
        b.CurveChain.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.CurveChain, curves, edges, hp)
        b.Patch = patch
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-surface-modeling/scripts/surf_build.py (11), surf_edit.py (8)
def sew(part, target, tools, tol=0.01):
    """Sew sheet bodies into `target`. A closed set becomes a SOLID. Gaps larger than tol are rejected (raise)
    or left open. Returns the resulting BODY - the caller checks body.IsSolidBody and len(nxh.free_edges(body))."""
    b = part.Features.CreateSewBuilder(NF)
    try:
        b.Tolerance = tol
        b.TargetBodies.Add(target)
        for t in tools:
            b.ToolBodies.Add(t)
        f = b.Commit()
    finally:
        b.Destroy()
    return f.GetBodies()[0]


# verified in nx-surface-modeling/scripts/surf_edit.py (9)
def thicken(part, body, first, second=0, reverse=False):
    """Thicken a sheet body into a NEW solid (the sheet stays). first / second are BOTH offsets measured in the
    same direction along the face normal: the solid spans second..first (0..first by default). 1 mm on each
    side of the sheet is (1, -1); (1, 1) raises "The specified offset values result in a zero thickness
    body". reverse flips the side. Returns the feature."""
    b = part.Features.CreateThickenBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(body)], False)
        b.FirstOffset.RightHandSide = str(first)
        b.SecondOffset.RightHandSide = str(second)
        b.ReverseDirection = reverse
        b.BooleanOperation.Type = BOOL.Create
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-surface-modeling/scripts/surf_edit.py (3)
def extend_sheet(part, edges, dist, as_new_sheet=False):
    """Extend Sheet: grow a sheet across its free boundary edges by `dist`, natural curvature (a cylinder
    stays a cylinder). as_new_sheet=True leaves the original and makes a separate extension.
    Factory on part.Features.TrimFeatureCollection. Returns the feature."""
    ESB = NXOpen.Features.ExtendSheetBuilder
    b = part.Features.TrimFeatureCollection.CreateExtendSheetBuilder(NXOpen.Features.ExtendSheet.Null)
    try:
        b.DistanceTolerance = 0.01
        b.LimitMethod = ESB.Limit.Offset
        b.TargetBoundaryEdges.ReplaceRules([part.ScRuleFactory.CreateRuleEdgeDumb(list(edges))], False)
        b.Offset.RightHandSide = str(dist)
        b.SurfaceShapeOption = ESB.SurfaceShape.NaturalCurvature
        b.BodyOutputOption = ESB.BodyOutput.ExtendasNewSheet if as_new_sheet else ESB.BodyOutput.ExtendOriginalSheet
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-surface-modeling/scripts/surf_edit.py (5)
def trim_sheet(part, body, region_xyz, keep=True, curves=None, faces=None, datum_plane=None, hp=(0, 0, 0), vec=None):
    """Trim Sheet. region_xyz: a point ON the sheet inside the region to keep (keep=True) or to discard.
    Boundary: curves (projected along the face normal, or along vec), faces of another body, or a datum plane
    (through a FaceDatum collector). ExtendBoundaryObject is forced True (a short tool is extended). Returns the feature."""
    TSB = NXOpen.Features.TrimSheetBuilder
    b = part.Features.CreateTrimsheetBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.TargetBodies.Add(body)
        b.Regions.Append(part.CreateRegionPoint(part.Points.CreatePoint(P(*region_xyz)), body))
        b.KeepDiscardMethod = TSB.KeepDiscardOption.Keep if keep else TSB.KeepDiscardOption.Discard
        b.ExtendBoundaryObject = True
        if curves:
            b.BoundaryObjects.Add(nxh.section(part, curves=curves, help_point=hp))
        if faces:
            b.BoundaryObjects.Add(nxh.collector(part, faces=list(faces)))
        if datum_plane is not None:
            b.BoundaryObjects.Add(nxh.collector(part, datum_planes=[datum_plane]))
        if vec is not None:
            b.ProjectionDirection.ProjectDirectionMethod = GU.ProjectionOptions.DirectionType.Vector
            b.ProjectionDirection.ProjectVector = nxh.direction(part, vec)
        return b.Commit()
    finally:
        b.Destroy()


# verified in nx-surface-modeling/scripts/surf_edit.py (2)
def offset_surface(part, faces, dist, flip=False):
    """Offset Surface: a NEW sheet offset from faces; +dist goes along the face normal (outward on a solid).
    Returns the feature."""
    b = part.Features.CreateOffsetSurfaceBuilder(NF)
    try:
        b.Tolerance = 0.01
        b.FaceSets.Append(part.FaceSetOffsets.CreateFaceSet(str(dist), nxh.collector(part, faces=list(faces)), flip, 0))
        return b.CommitFeature()
    finally:
        b.Destroy()


# verified in nx-surface-modeling/scripts/surf_edit.py (1), sync_imported_body.py (linked face)
def extract_face(part, faces, associative=True):
    """Extract Geometry > Face: associative sheet copy of one or several faces (one body; follows the source).
    Use rule_faces("feature", [f]) of the returned feature to reference it. Returns the feature."""
    EFB = NXOpen.Features.ExtractFaceBuilder
    faces = [faces] if isinstance(faces, NXOpen.Face) else list(faces)
    b = part.Features.CreateExtractFaceBuilder(NF)
    try:
        b.ParentPart = EFB.ParentPartType.WorkPart
        b.Type = EFB.ExtractType.Face
        if len(faces) == 1:
            b.FaceOption = EFB.FaceOptionType.SingleFace
            b.ObjectToExtract.Add(faces[0])
        else:
            b.FaceOption = EFB.FaceOptionType.FaceChain
            b.FaceChain.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(faces)], False)
        b.Associative = associative
        b.FixAtCurrentTimestamp = False
        b.HideOriginal = False
        return b.CommitFeature()
    finally:
        b.Destroy()


# ====================================================================== STEP import / export
def step_dir():
    """<NX>\\STEP214UG - the folder with the translator settings files (ugstep214.def, step214ug.def)."""
    return os.path.join(os.environ.get("UGII_BASE_DIR", r"C:\Program Files\Siemens\NX2206"), "STEP214UG")


def step_schema(path):
    """'AP242' | 'AP214' | 'AP203' | None, read from the FILE_SCHEMA entry of a STEP file header."""
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        head = fh.read(20000).upper()
    i = head.find("FILE_SCHEMA")
    if i < 0:
        return None
    j = head.find(";", i)
    txt = head[i:j if j > 0 else i + 400]
    if "AP242" in txt:
        return "AP242"
    if "AUTOMOTIVE_DESIGN" in txt or "AP214" in txt:
        return "AP214"
    if "CONFIG_CONTROL_DESIGN" in txt or "AP203" in txt:
        return "AP203"
    return None


# verified in nx-journal-core/references/import-export.md (AP242), sync_imported_body.py (AP214), acceptance builds
def step_export(part, dest, ap242=True, save=True, timeout=180):
    """Export the part's solids to STEP (AP242, or AP214 with ap242=False). Returns dest.

    The translator reads the part FILE on disk (InputFile = part.FullPath): save=True saves the part first
    (pass False for a part that must not be saved - then only its last saved state is exported).
    LayerMask '1-256' and ObjectTypes.Solids are set (defaults give a STEP without geometry). Commit() can
    return before the translator has finished, so the helper waits until the file exists and stops growing.
    Check the result with step_roundtrip_check()."""
    if save:
        nxh.save(part)
    if os.path.exists(dest):
        os.remove(dest)
    b = S.DexManager.CreateStepCreator()
    try:
        if ap242:
            b.ExportAs = NXOpen.StepCreator.ExportAsOption.Ap242
        else:
            b.ExportAs = NXOpen.StepCreator.ExportAsOption.Ap214
            b.SettingsFile = os.path.join(step_dir(), "ugstep214.def")
        b.InputFile = part.FullPath
        b.OutputFile = dest
        b.LayerMask = "1-256"
        b.ObjectTypes.Solids = True
        b.FileSaveFlag = False
        b.ProcessHoldFlag = True
        b.BsplineTol = 0.001
        b.Commit()
    finally:
        b.Destroy()
    t0, last = time.time(), -1
    while time.time() - t0 < timeout:
        size = os.path.getsize(dest) if os.path.exists(dest) else -1
        if size > 0 and size == last:
            break
        last = size
        time.sleep(1.0)
    if not os.path.exists(dest):
        raise RuntimeError("step_export: no file written: " + dest)
    return dest


# verified in sync_imported_body.py (AP214 importer) and the acceptance builds (AP242 importer, assembly STEP)
def step_import(part, path, scratch_prt):
    """Import a STEP file into `part` (which must be the work part). Returns the new bodies (BREP features;
    edit them with the synchronous helpers).

    The importer is chosen from the file header: an AP242 file needs CreateStep242Importer with NO
    SettingsFile; AP214 / AP203 need CreateStep214Importer WITH SettingsFile = <NX>\\STEP214UG\\step214ug.def -
    the wrong combination imports nothing, silently. scratch_prt: a throwaway .prt path (OutputFile is
    mandatory even for an import into the work part).
    An ASSEMBLY STEP does not arrive as bodies: `part` gets components (new parts named <name>_stp) and the
    function returns [] - read them with instance_solids(part). Raises when neither bodies nor components arrive.
    The STEP importer changes the SESSION load options (Components To Load came back as NotSet: an assembly
    opened afterwards arrived without its components, no message) - they are saved and restored here."""
    schema = step_schema(path)
    before = {b.Tag for b in part.Bodies}
    if os.path.exists(scratch_prt):
        os.remove(scratch_prt)
    lo = S.Parts.LoadOptions
    saved = {}
    for n in ("ComponentsToLoad", "UsePartialLoading"):
        try:
            saved[n] = getattr(lo, n)
        except Exception:  # noqa: BLE001
            pass
    try:
        return _step_import(part, path, scratch_prt, schema, before)
    finally:
        for n, v in saved.items():
            try:
                setattr(lo, n, v)
            except Exception:  # noqa: BLE001
                pass


def _step_import(part, path, scratch_prt, schema, before):
    if schema == "AP242":
        imp = S.DexManager.CreateStep242Importer()
        to_work = NXOpen.Step242Importer.ImportToOption.WorkPart
    else:
        imp = S.DexManager.CreateStep214Importer()
        to_work = NXOpen.Step214Importer.ImportToOption.WorkPart
    try:
        if schema != "AP242":
            imp.SettingsFile = os.path.join(step_dir(), "step214ug.def")
        imp.ImportTo = to_work
        imp.ObjectTypes.Solids = True
        imp.InputFile = path
        imp.OutputFile = scratch_prt
        imp.FileOpenFlag = False
        imp.ProcessHoldFlag = True
        imp.Commit()
    finally:
        imp.Destroy()
    new = [b for b in part.Bodies if b.Tag not in before]
    if not new:
        root = part.ComponentAssembly.RootComponent
        if root is None or not root.GetChildren():
            raise RuntimeError("step_import: nothing imported from %s (schema %s)" % (path, schema))
    return new


# verified in acceptance build 3 (step_probe.py walker)
def instance_solids(part, load=True):
    """Leaf component instances of an assembly part with their visible solids.

    Returns [{"name", "part", "depth", "origin", "bodies", "volumes"}] - one row per leaf INSTANCE (a part
    used four times gives four rows); bodies are the prototype's unblanked solid bodies that are members of
    the component's REFERENCE SET (measured: an assembly STEP exports exactly those - a linked copy taken out
    of MODEL is not exported; the STEP of the piece part alone does NOT follow MODEL).
    load=True calls LoadThisPartFully() on partially loaded prototypes. [] for a part without components."""
    rows = []
    root = part.ComponentAssembly.RootComponent

    def walk(c, depth):
        for ch in c.GetChildren():
            if ch.GetChildren():
                walk(ch, depth + 1)
                continue
            proto = ch.Prototype
            if proto is None:
                rows.append({"name": ch.Name, "part": None, "depth": depth, "origin": None, "bodies": [], "volumes": []})
                continue
            if load and not proto.IsFullyLoaded:
                proto.LoadThisPartFully().Dispose()
            sol = [b for b in proto.Bodies if b.IsSolidBody and not b.IsBlanked]
            try:
                sets = [rs for rs in proto.GetAllReferenceSets() if rs.Name == ch.ReferenceSet]
                if sets:
                    members = {x.Tag for x in sets[0].AskAllDirectMembers()}
                    if any(b.Tag in members for b in sol):
                        sol = [b for b in sol if b.Tag in members]
            except Exception:  # noqa: BLE001
                pass
            o, _m = ch.GetPosition()
            rows.append({"name": ch.Name, "part": proto.Name, "depth": depth, "origin": [o.X, o.Y, o.Z], "bodies": sol,
                         "volumes": [nxh.volume(proto, b) for b in sol]})

    if root is not None:
        walk(root, 0)
    return rows


# verified in the acceptance builds (acc_lib.step_verify, step_probe.py); the comparison logic is nxf's own
def step_roundtrip_check(stp, out_dir, name="stepcheck", restore=None, part=None, bodies=None, rel_tol=1e-4):
    """Deliverable check: re-import a STEP file into a fresh scratch part, measure it and compare it with the model.

    What to compare with (optional): bodies=[...] exactly these bodies, or part=<the exported part>:
      * a piece part -> its UNBLANKED solids (the exporter writes only visible solids: 5 solids with 2 blanked
        give a STEP with 3; the blanked ones are counted in "blanked_skipped");
      * an assembly -> the unblanked solids of every leaf instance (instance_solids).
    Bodies are paired by sorted volume and agree when |got - expected| / expected <= rel_tol (default 1e-4:
    real tolerant geometry showed up to 4.4e-5; analytic bodies agree to 1e-9).

    Returns {"schema", "manifold_solid_brep", "assembly", "bodies", "solids", "volume", "volumes", "bbox",
    "examine", "healthy", "expected", "per_body", "max_rel", "match", "blanked_skipped", "instances", "restored"}.
    "match" is None when nothing was given to compare with; require match and healthy for a deliverable.
    An assembly STEP imports as components ("assembly": True, "instances": [[name, part, origin, n, volume]]).
    Its imported parts (<name>_stp) stay loaded in the session: check each assembly STEP once per session.
    The scratch part becomes the work part; pass restore=<your part> to switch back ("restored")."""
    expected, skipped = None, 0
    if bodies is not None:
        expected = [nxh.volume(b.OwningPart, b) for b in bodies]
    elif part is not None:
        rows = instance_solids(part)
        if rows:
            expected = [v for r_ in rows for v in r_["volumes"]]
        else:
            sol = nxh.solids(part)
            vis = [b for b in sol if not b.IsBlanked]
            skipped = len(sol) - len(vis)
            expected = [nxh.volume(part, b) for b in vis]
    with open(stp, "r", encoding="utf-8", errors="replace") as fh:
        txt = fh.read()
    r = {"schema": step_schema(stp), "manifold_solid_brep": txt.count("MANIFOLD_SOLID_BREP")}
    scratch = nxh.new_part(os.path.join(out_dir, name + "_check.prt"))
    got_bodies = step_import(scratch, stp, os.path.join(out_dir, name + "_check_tmp.prt"))
    r["assembly"] = not got_bodies
    r["instances"] = []
    if got_bodies:
        sol = [(scratch, b) for b in got_bodies if b.IsSolidBody]
        r["bodies"] = len(got_bodies)
        r["bbox"] = nxh.bbox(got_bodies[0])
        r["examine"] = [nxh.examine_geometry(scratch, b) for b in got_bodies]
    else:
        rows = instance_solids(scratch)
        sol = []
        for row in rows:
            proto = [p_ for p_ in S.Parts if p_.Name == row["part"]]
            sol += [(proto[0], b) for b in row["bodies"]] if proto else []
            r["instances"].append([row["name"], row["part"], [round(x, 6) for x in row["origin"]], len(row["bodies"]),
                                   sum(row["volumes"])])
        r["bodies"] = len(sol)
        r["bbox"] = None
        seen, r["examine"] = set(), []
        for owner, b in sol:                     # examine each prototype body once
            if b.Tag not in seen:
                seen.add(b.Tag)
                r["examine"].append(nxh.examine_geometry(owner, b))
    r["solids"] = len(sol)
    r["volumes"] = sorted(nxh.volume(owner, b) for owner, b in sol)
    r["volume"] = sum(r["volumes"])
    r["healthy"] = all(v == 0 for e in r["examine"] for v in e.values())
    r["expected"], r["blanked_skipped"] = (sorted(expected) if expected is not None else None), skipped
    r["per_body"], r["max_rel"], r["match"] = [], None, None
    if expected is not None:
        exp = sorted(expected)
        for e_, g_ in zip(exp, r["volumes"]):
            r["per_body"].append({"expected": e_, "got": g_, "rel": abs(g_ - e_) / e_ if e_ else abs(g_)})
        r["max_rel"] = max((p_["rel"] for p_ in r["per_body"]), default=0.0)
        r["match"] = len(exp) == len(r["volumes"]) and r["max_rel"] <= rel_tol
    r["restored"] = False
    if restore is not None:
        try:
            S.Parts.SetActiveDisplay(restore, NXOpen.DisplayPartOption.AllowAdditional,
                                     NXOpen.PartDisplayPartWorkPartOption.UseLast)
            r["restored"] = S.Parts.Work.Tag == restore.Tag
        except Exception as e:  # noqa: BLE001
            r["restore_error"] = str(e)
    return r
