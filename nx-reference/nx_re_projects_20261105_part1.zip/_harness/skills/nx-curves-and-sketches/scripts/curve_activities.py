"""Four curve tasks rebuilt from the activities of Siemens' NX CAST 8.5 curve courses, on geometry of our own,
measured on NX 2206 (headless). Each one is an end-to-end test of a curve feature that must FOLLOW its parents.

  run_journal.ps1 -Script curve_activities.py -WorkDir <out> -JArgs <out>

  A1  Unwrap: the flat layout of a mitred tube end (R20 tube cut at 45 deg) - end circle -> straight line of
      length 2*pi*r, cut edge -> one period of a sine; follows the cut height; wrapped back it lands on the edge
  A2  Combined Projection of two SKETCHES (top view arc, side view ramp); the 3D curve follows a sketch dimension
  A3  Bridge Curve between EDGES of two sheet bodies, G1; both parents are edited and the bridge stays attached
  A4  lines between body corners: built on smart points they follow a resize, built on coordinates they do not
[cast ecvd / ecvc / ecvb] = the CAST curve courses (tasks in own words, own geometry and numbers).
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])))
import curvekit as ck  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
ONLY = list(sys.argv[2:])
P, V, UPD = nxh.P, nxh.V, nxh.UPD
NF, NULL = nxh.NULL_FEATURE, NXOpen.NXObject.Null
GU, F = NXOpen.GeometricUtilities, NXOpen.Features
SK, A, CP = NXOpen.Sketch, NXOpen.Sketch.AssocType, NXOpen.Sketch.ConstraintPointType
log = nxh.Log(os.path.join(OUT, "curve_activities.log"))
chk = nxh.Check()
res = {"measured": {}, "not_working": {}}
M = res["measured"]
R = None


def block(name, fn, part):
    if ONLY and name not in ONLY:
        return
    m = nxh.mark("block " + name, False)
    try:
        fn(part)
        log("done", name)
    except Exception:  # noqa: BLE001
        err = traceback.format_exc()
        log("FAILED", name, err)
        chk.true(name + " ran to the end", False, err[-900:])
        try:
            s = nxh.S.ActiveSketch
            if s is not None:
                s.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        except Exception:  # noqa: BLE001
            pass
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass


def rnd(v, n=4):
    return [round(x, n) for x in v]


def assoc_arc(part, centre, radius, a0, a1, plane):
    """Associative arc by centre and radius; angles in degrees in the frame of `plane` (fixed plane, normal +Z: 0 = +X)."""
    AB = F.AssociativeArcBuilder
    b = part.BaseFeatures.CreateAssociativeArcBuilder(F.AssociativeArc.Null)
    try:
        b.Type = AB.Types.ArcFromCenter
        b.CenterPoint.Value = nxh.point(part, *centre)
        b.EndPointOptions = AB.EndOption.Radius
        b.Radius.RightHandSide = str(radius)
        b.SupportPlaneData.SupportPlane = plane
        LO = GU.CurveExtendData.LimitOptions
        b.Limits.StartLimit.LimitOption = LO.Value
        b.Limits.EndLimit.LimitOption = LO.Value
        b.Limits.StartLimit.Distance.RightHandSide = str(a0)
        b.Limits.EndLimit.Distance.RightHandSide = str(a1)
        b.Limits.FullCircle = False
        b.Associative = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, ck.curves_of(f)[0]


# ------------------------------------------------------------------ A1 unwrap
def a1(part):
    r = 20.0
    nxh.expr(part, "a1_h", 50)
    _f, body = nxh.cylinder(part, (0, 0, 0), (0, 0, 1), 2 * r, 90)
    _fp, dp_cut = nxh.datum_plane(part, (0, 0, "a1_h"), (1, 0, 1), name="PL_MITRE")
    nxf.trim_body(part, body, keep_point=(0, 0, 5), datum_plane=dp_cut)
    cyl = nxh.one(nxh.faces(body, ftype=nxh.CYLINDER), "tube wall")
    edges = list(cyl.GetEdges())
    base = [e for e in edges if abs(nxh.bbox(e)[2]) < 1e-6 and abs(nxh.bbox(e)[5]) < 1e-6]
    cut = [e for e in edges if e not in base and nxh.bbox(e)[5] - nxh.bbox(e)[2] > 1.0]
    _ft, dp = nxf.datum_plane(part, "tangent", [cyl], name="PL_LAYOUT")
    o, n = dp.Origin, dp.Normal
    # frame of the layout plane: w along the tube axis, u = axis x normal (the direction the wall rolls out in)
    nrm = [n.X, n.Y, n.Z]
    u_dir = ck.cross([0, 0, 1], nrm)
    phi0 = math.atan2(o.Y, o.X)                                                     # angle of the tangent line round the axis

    def unwrap(src_edges, kind="Unwrap", curves=None):
        b = part.Features.CreateWrapBuilder(F.WrapUnwrap.Null)
        try:
            b.Type = getattr(F.WrapBuilder.Types, kind)
            if curves is not None:
                ck.fill(b.Curves, [R.CreateRuleCurveFeature(curves)], (o.X, o.Y, o.Z))
            else:
                ck.fill(b.Curves, [R.CreateRuleEdgeDumb(src_edges)], ck.frame(src_edges[0], 0.5)["point"], src_edges[0])
            b.Faces.ReplaceRules([R.CreateRuleFaceDumb([cyl])], False)
            b.Plane.Value = dp
            b.DistanceTolerance = 0.001
            b.Associative = True
            return b.Commit()
        finally:
            b.Destroy()

    def layout(f):
        cs = ck.curves_of(f)
        pts = [s["point"] for c in cs for s in ck.sample(c, 60)]
        us = [ck.dot(ck.sub(p, [o.X, o.Y, o.Z]), u_dir) for p in pts]
        return cs, pts, us

    f_base = unwrap(base)
    cs, pts, us = layout(f_base)
    rows = {"layout plane": {"origin": rnd([o.X, o.Y, o.Z], 3), "normal": rnd(nrm, 3)},
            "end circle unwrapped": {"feature_type": f_base.FeatureType, "curves": len(cs), "classes": sorted({type(c).__name__ for c in cs}),
                                     "length": round(sum(c.GetLength() for c in cs), 4), "expected": round(2 * math.pi * r, 4),
                                     "off_plane": round(max(abs(ck.dot(ck.sub(p, [o.X, o.Y, o.Z]), nrm)) for p in pts), 6),
                                     "z_range": rnd([min(p[2] for p in pts), max(p[2] for p in pts)], 5), "u_range": rnd([min(us), max(us)], 3)}}
    f_cut = unwrap(cut)

    def cut_state(h):
        cs, pts, us = layout(f_cut)
        # tube point at angle phi: z = h - r*cos(phi); rolled out: u = r*(phi - phi0)
        dev = max(min(abs(p[2] - (h - r * math.cos(phi0 + sgn * u / r))) for sgn in (1, -1)) for p, u in zip(pts, us))
        zs = [p[2] for p in pts]
        return {"curves": len(cs), "classes": sorted({type(c).__name__ for c in cs}), "length": round(sum(c.GetLength() for c in cs), 4),
                "off_plane": round(max(abs(ck.dot(ck.sub(p, [o.X, o.Y, o.Z]), nrm)) for p in pts), 6), "u_range": rnd([min(us), max(us)], 3),
                "z_range": rnd([min(zs), max(zs)], 4), "amplitude": round((max(zs) - min(zs)) / 2, 4), "max_dev_from_sine": round(dev, 5)}
    rows["cut edge unwrapped (h 50)"] = cut_state(50.0)
    nxh.set_expr(part, "a1_h", 40)
    nxh.update()
    rows["cut edge unwrapped after h 50 -> 40"] = dict(cut_state(40.0), errors=nxh.feature_errors(part))
    # wrap the layout back onto the tube: it must land on the cut edge
    back, err = nxh.attempt("wrap back", lambda: unwrap(None, "Wrap", curves=[f_cut]), log=log)
    if err:
        rows["layout wrapped back"] = {"error": err[:300]}
    else:
        cut_now = [e for e in cyl.GetEdges() if nxh.bbox(e)[5] - nxh.bbox(e)[2] > 1.0]
        worst = 0.0
        for c in ck.curves_of(back):
            for s in ck.sample(c, 30):
                worst = max(worst, min(nxh.dist_to(part, e, s["point"]) for e in cut_now))
        rows["layout wrapped back"] = {"curves": len(ck.curves_of(back)), "max_dist_from_cut_edge": round(worst, 5)}
    M["A1 unwrap of a mitred R20 tube"] = rows
    c0, c1, c2 = rows["end circle unwrapped"], rows["cut edge unwrapped (h 50)"], rows["cut edge unwrapped after h 50 -> 40"]
    chk.true("A1 Unwrap of the end circle: straight, in the layout plane, total length 2*pi*r = 125.664",
             abs(c0["length"] - 2 * math.pi * r) < 0.01 and c0["off_plane"] < 1e-3 and abs(c0["z_range"][1] - c0["z_range"][0]) < 1e-3, c0)
    chk.true("A1 Unwrap of the 45 deg cut edge: one period of a sine, amplitude 20 = r, within 0.01 of z = h - r*cos(u/r), spanning +-pi*r = 62.83 about the tangent line",
             abs(c1["amplitude"] - r) < 0.01 and c1["max_dev_from_sine"] < 0.01 and c1["off_plane"] < 1e-3 and abs(c1["u_range"][1] - math.pi * r) < 0.05
             and abs(c1["u_range"][0] + math.pi * r) < 0.05, c1)
    chk.true("A1 the layout follows the model: cut height 50 -> 40 moves the sine down by 10, no feature error",
             abs(c2["z_range"][0] - (c1["z_range"][0] - 10)) < 0.01 and c2["max_dev_from_sine"] < 0.01 and not c2["errors"], c2)
    w = rows["layout wrapped back"]
    chk.true("A1 Wrap of the layout lands back on the cut edge (within 0.01)", w.get("max_dist_from_cut_edge", 1) < 0.01, w)


# ------------------------------------------------------------------ A2 combined projection of two sketches
def a2(part):
    dat = nxh.Datums(part)
    nxh.expr(part, "a2_len", 190.5)
    nxh.expr(part, "a2_rise", 30)
    # TOP_VIEW: an arc of radius 150 from the origin to (a2_len, 0), bulging to +Y
    top = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "TOP_VIEW")
    half = 190.5 / 2
    cyv = -math.sqrt(150.0 ** 2 - half ** 2)
    a0, a1_ = math.atan2(-cyv, half), math.atan2(-cyv, -half)
    arc = part.Curves.CreateArc(P(half, cyv, 0), V(1, 0, 0), V(0, 1, 0), 150.0, a0, a1_)        # from (a2_len, 0) round to (0, 0)
    nxf.add(top, arc, infer=False)
    d0 = top.GetStatus()[1] if False else None
    del d0
    top.Update()
    dd = [nxf.sketch_status(top)[1]]
    end0 = CP.EndVertex if math.dist(ck.frame(arc, 1.0)["point"], (0, 0, 0)) < 1e-6 else CP.StartVertex
    end1 = CP.StartVertex if end0 == CP.EndVertex else CP.EndVertex
    top.CreateCoincidentConstraint(nxf.cg(arc, end0), nxf.cg(dat.origin))
    top.CreatePointOnCurveConstraint(nxf.cg(arc, end1), nxf.cg(dat.x), nxf.help_at(P(190.5, 0, 0)))
    top.Update()
    dd.append(nxf.sketch_status(top)[1])
    nxf.pdim(top, dat.y, P(0, 40, 0), arc, A.StartPoint if end1 == CP.StartVertex else A.EndPoint, P(95, -20, 0), "a2_len")
    nxf.radius_dim(top, arc, P(half, cyv + 150.0, 0), P(half, 30, 0), "150")
    st_top = nxf.finish_sketch(top)
    dd.append(st_top["dof"])
    # SIDE_VIEW: a straight ramp in the XZ plane from the origin to (a2_len, a2_rise)
    side = nxf.new_sketch(part, dat.xz, dat.x, dat.origin, "SIDE_VIEW")
    ramp = part.Curves.CreateLine(P(0, 0, 0), P(190.5, 0, 30))
    nxf.add(side, ramp, infer=False)
    side.CreateCoincidentConstraint(nxf.cg(ramp, CP.StartVertex), nxf.cg(dat.origin))
    nxf.pdim(side, dat.z, P(0, 0, 40), ramp, A.EndPoint, P(95, 0, -15), "a2_len")
    nxf.pdim(side, dat.x, P(40, 0, 0), ramp, A.EndPoint, P(200, 0, 15), "a2_rise")
    st_side = nxf.finish_sketch(side)

    DT = GU.ProjectionOptions.DirectionType
    b = part.Features.CreateCombinedProjectionBuilder(F.CombinedProjection.Null)
    try:
        ck.fill(b.Curve1, [R.CreateRuleCurveFeature([top.Feature])], (1, 1, 0), arc)
        ck.fill(b.Curve2, [R.CreateRuleCurveFeature([side.Feature])], (1, 0, 0.2), ramp)
        b.Direction1.ProjectDirectionMethod = DT.CrvPlaneNormal
        b.Direction2.ProjectDirectionMethod = DT.CrvPlaneNormal
        b.CurveOptions.Associative = True
        f = b.Commit()
    finally:
        b.Destroy()

    def state(length):
        cs = ck.curves_of(f)
        pts = [s["point"] for c in cs for s in ck.sample(c, 40)]
        top_dev = max(nxh.dist_to(part, arc, (p[0], p[1], 0.0)) for p in pts)
        side_dev = max(abs(p[2] - 30.0 * p[0] / length) for p in pts)
        xs = [p[0] for p in pts]
        return {"feature_type": f.FeatureType, "curves": len(cs), "classes": sorted({type(c).__name__ for c in cs}), "x_range": rnd([min(xs), max(xs)], 4),
                "max_dev_from_top_view": round(top_dev, 6), "max_dev_from_side_view": round(side_dev, 6),
                "length": round(sum(c.GetLength() for c in cs), 4), "parents": sorted(p.GetFeatureName() for p in f.GetParents())}
    s0 = state(190.5)
    nxh.set_expr(part, "a2_len", 200)
    nxh.update()
    s1 = dict(state(200.0), errors=nxh.feature_errors(part))
    M["A2 combined projection of two sketches"] = {"top sketch": {"dof_countdown": dd, "status": st_top["status"], "auto_dims": st_top["auto_dims"]},
                                                   "side sketch": {k: st_side[k] for k in ("status", "dof", "auto_dims")}, "len 190.5": s0, "len 200": s1}
    chk.true("A2 both view sketches are fully constrained (top: DOF 5 -> 2 -> 0; side DOF 0), auto_dims 0",
             dd == [5, 2, 0] and st_side["dof"] == 0 and st_top["auto_dims"] == 0 and st_side["auto_dims"] == 0, (dd, st_side["dof"]))
    chk.true("A2 Combined Projection of the two sketches (whole-sketch rules, direction = normal of each curve plane): the 3D curve matches both views within 1e-4",
             s0["feature_type"] == "CPROJ_CMB" and s0["max_dev_from_top_view"] < 1e-4 and s0["max_dev_from_side_view"] < 1e-4 and abs(s0["x_range"][1] - 190.5) < 1e-3, s0)
    chk.true("A2 it follows the sketch dimension: length 190.5 -> 200, still on both views, no feature error",
             abs(s1["x_range"][1] - 200.0) < 1e-3 and s1["max_dev_from_top_view"] < 1e-4 and s1["max_dev_from_side_view"] < 1e-4 and not s1["errors"], s1)


# ------------------------------------------------------------------ A3 bridge between body edges
def a3(part):
    y = 400.0
    pl = part.Planes.CreatePlane(P(0, 0, 0), V(0, 0, 1), UPD)
    nxh.expr(part, "a3_r1", 12.7)
    nxh.expr(part, "a3_r2", 25)
    f1, c1_ = assoc_arc(part, (0, y, 0), "a3_r1", 0, 90, pl)            # ends (r1, y) and (0, y + r1)
    f2, c2_ = assoc_arc(part, (80, y + 10, 0), "a3_r2", 90, 180, pl)    # ends (80, y + 10 + r2) and (80 - r2, y + 10)
    s1 = nxh.extrude(part, nxh.section_feature(part, [f1], help_point=(12.7, y, 0)), (0, 0, 1), 0, 20, sheet=True).GetBodies()[0]
    s2 = nxh.extrude(part, nxh.section_feature(part, [f2], help_point=(80, y + 35, 0)), (0, 0, 1), 0, 20, sheet=True).GetBodies()[0]

    def top_edge(body):
        return [e for e in body.GetEdges() if abs(nxh.bbox(e)[2] - 20) < 1e-6 and abs(nxh.bbox(e)[5] - 20) < 1e-6][0]
    e1, e2 = top_edge(s1), top_edge(s2)
    p1 = ck.frame(e1, ck.end_near(e1, (0, y + 12.7, 20)))["point"]       # the end of edge 1 at (0, y + r1, 20)
    p2 = ck.frame(e2, ck.end_near(e2, (55, y + 10, 20)))["point"]        # the end of edge 2 at (80 - r2, y + 10, 20)
    CT = GU.Continuity.ContinuityTypes
    b = part.Features.CreateBridgeCurveBuilderEx(F.BridgeCurve.Null)
    try:
        ck.fill(b.StartSection, [R.CreateRuleEdgeDumb([e1])], p1, e1)
        ck.fill(b.EndSection, [R.CreateRuleEdgeDumb([e2])], p2, e2)
        b.StartConnectivity.Continuity.ContinuityType = CT.G1
        b.EndConnectivity.Continuity.ContinuityType = CT.G1
        b.IsAssociative = True
        f = b.Commit()
    finally:
        b.Destroy()

    def state(r1, r2):
        ea, eb = top_edge(s1), top_edge(s2)
        c = ck.curves_of(f)[0]
        want1, want2 = (0.0, y + r1, 20.0), (80.0 - r2, y + 10.0, 20.0)
        ta, tb = ck.end_near(ea, want1), ck.end_near(eb, want2)
        sa = ck.end_near(c, want1)
        q = ck.curve_quality(c)
        return {"gap_at_edge_1": round(math.dist(ck.frame(c, sa)["point"], want1), 6), "gap_at_edge_2": round(math.dist(ck.frame(c, 1 - sa)["point"], want2), 6),
                "tangent_angle_1_deg": round(ck.join_angle(ea, ta, c, sa), 4), "tangent_angle_2_deg": round(ck.join_angle(eb, tb, c, 1 - sa), 4),
                "length": round(q["length"], 4), "inflections": q["inflections"], "r_min": round(q["r_min"], 3) if q["r_min"] else None}
    s0 = state(12.7, 25.0)
    nxh.set_expr(part, "a3_r1", 9.5)
    nxh.set_expr(part, "a3_r2", 31.8)
    nxh.update()
    s1_ = dict(state(9.5, 31.8), errors=nxh.feature_errors(part))
    M["A3 bridge between the top edges of two sheets"] = {"feature_type": f.FeatureType, "parents": sorted(p.GetFeatureName() for p in f.GetParents()),
                                                          "as built (r1 12.7, r2 25)": s0, "after r1 9.5, r2 31.8": s1_}
    chk.true("A3 Bridge Curve between two body EDGES (EdgeDumb sections, help point at the end to bridge), G1: attached at both edge ends, tangent to both edges",
             f.FeatureType == "BRIDGE_CURVE" and s0["gap_at_edge_1"] < 1e-5 and s0["gap_at_edge_2"] < 1e-5 and s0["tangent_angle_1_deg"] < 1e-2 and s0["tangent_angle_2_deg"] < 1e-2, s0)
    chk.true("A3 both parents edited (r1 12.7 -> 9.5, r2 25 -> 31.8): the bridge is still attached and tangent, no feature error",
             s1_["gap_at_edge_1"] < 1e-5 and s1_["gap_at_edge_2"] < 1e-5 and s1_["tangent_angle_1_deg"] < 1e-2 and s1_["tangent_angle_2_deg"] < 1e-2
             and not s1_["errors"] and abs(s1_["length"] - s0["length"]) > 0.1, s1_)


# ------------------------------------------------------------------ A4 associative points
def a4(part):
    y = 520.0
    nxh.expr(part, "a4_w", 40)
    _f, body = nxh.block(part, (0, y, 0), ("a4_w", 25, 10))
    vert = sorted([e for e in body.GetEdges() if nxh.bbox(e)[5] - nxh.bbox(e)[2] > 9.9], key=lambda e: (round(nxh.bbox(e)[0], 3), round(nxh.bbox(e)[1], 3)))
    e_near, e_far = vert[0], vert[-1]                                    # vertical edges at (0, y) and (a4_w, y + 25)

    def top_pct(e):
        return 100 if ck.frame(e, 1.0)["point"][2] > 5 else 0
    LB = F.AssociativeLineBuilder

    def line(pa, pb):
        b = part.BaseFeatures.CreateAssociativeLineBuilder(F.AssociativeLine.Null)
        try:
            b.StartPointOptions = LB.StartOption.Point
            b.StartPoint.Value = pa
            b.EndPointOptions = LB.EndOption.Point
            b.EndPoint.Value = pb
            b.Associative = True
            return b.CommitFeature()
        finally:
            b.Destroy()
    f_smart = line(ck.on_curve(part, e_near, top_pct(e_near)), ck.on_curve(part, e_far, top_pct(e_far)))      # points that ride on the edges
    f_fixed = line(nxh.point(part, 0, y, 10), nxh.point(part, 40, y + 25, 10))                                # the same corners as typed coordinates

    def state():
        corner = (nxh.bbox(body)[3], y + 25.0, 10.0)
        out = {}
        for label, f in (("line on smart edge points", f_smart), ("line on typed coordinates", f_fixed)):
            c = ck.curves_of(f)[0]
            t = ck.end_near(c, (40, y + 25, 10))
            out[label] = {"end": rnd(ck.frame(c, t)["point"], 3), "distance_from_the_corner": round(math.dist(ck.frame(c, t)["point"], corner), 4),
                          "length": round(c.GetLength(), 4), "parents": sorted(p.GetFeatureName() for p in f.GetParents())}
        return out
    s0 = state()
    nxh.set_expr(part, "a4_w", 25)
    nxh.update()
    s1 = state()
    M["A4 diagonal across the top of a block, width 40 -> 25"] = {"as built": s0, "after the resize": s1, "errors": nxh.feature_errors(part)}
    chk.true("A4 as built both lines end on the far top corner", all(v["distance_from_the_corner"] < 1e-6 for v in s0.values()), s0)
    chk.true("A4 after the block is resized 40 -> 25 the line on points that ride on the EDGES still ends on the corner (its parent is the Block)",
             s1["line on smart edge points"]["distance_from_the_corner"] < 1e-6 and any("Block" in p for p in s1["line on smart edge points"]["parents"]), s1["line on smart edge points"])
    chk.true("A4 the line on typed coordinates stayed where it was: 15 mm off the corner, no error anywhere - an 'associative' feature with nothing to follow",
             abs(s1["line on typed coordinates"]["distance_from_the_corner"] - 15.0) < 1e-6 and not nxh.feature_errors(part), s1["line on typed coordinates"])


def run():
    global R
    part = nxh.new_part(os.path.join(OUT, "curve_activities.prt"))
    R = part.ScRuleFactory
    for name, fn in (("A1", a1), ("A2", a2), ("A3", a3), ("A4", a4)):
        block(name, fn, part)
    res["errors"] = nxh.feature_errors(part)
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res.update(chk.report())
if "error" in res:
    res["result"] = "FAIL"
nxh.write_json(os.path.join(OUT, "curve_activities.json"), res)
