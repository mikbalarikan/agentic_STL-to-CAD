"""Verified associative curve features for NX 2206 (headless run_journal).

  run.ps1 -Script curve_features.py -WorkDir <out> -JArgs <out>

Associative line / arc, studio spline (through points, by poles, G1 end direction), bridge curve,
project curve, intersection curve, section curve, offset curve, composite curve (edge extract),
curve length, helix, text. Every result is measured (length, end points, end tangents,
planarity). Writes curve_features.json with "result": "PASS" | "FAIL"; a recipe that could not
be made to work is reported under "not_working" and does not fail the run.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import nxh  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
P, V, UPD, UFS = nxh.P, nxh.V, nxh.UPD, nxh.UFS
NF = nxh.NULL_FEATURE
NULL = NXOpen.NXObject.Null
log = nxh.Log(os.path.join(OUT, "curve_features.log"))
res = {"checks": {}, "not_working": {}}
ONLY = [a for a in sys.argv[2:]]          # optional: run only the named recipes


def check(name, ok, **data):
    res["checks"][name] = dict(ok=bool(ok), **data)
    log(("PASS " if ok else "FAIL ") + name, data)
    return ok


# ------------------------------------------------------------------ measurement
_CURVE_PROPS = UFS.ModlGeneral.AskCurveProps       # (tag, t in 0..1) -> point, tangent, p_norm, b_norm, torsion, rad


def at(curve, t):
    r = _CURVE_PROPS(curve.Tag, float(t))
    return [round(x, 6) for x in r[0]], [round(x, 6) for x in r[1]]


def ends(curve):
    return at(curve, 0.0), at(curve, 1.0)


def near(a, b, tol=1e-3):
    return all(abs(x - y) < tol for x, y in zip(a, b))


def par(a, b, tol=1e-4):
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(x * x for x in b))
    return abs(abs(sum(x * y for x, y in zip(a, b)) / (na * nb)) - 1.0) < tol


def curves_of(feat):
    return [e for e in feat.GetEntities() if isinstance(e, NXOpen.Curve)]


def total_length(curves):
    return sum(c.GetLength() for c in curves)


def planarity(curves, n=9):
    """(max deviation from the best plane through 3 sampled points, plane normal) - 0 when planar."""
    pts = [at(c, i / (n - 1.0))[0] for c in curves for i in range(n)]
    p0 = pts[0]
    best, nrm = 0.0, None
    for q in pts[1:]:
        for r in pts[2:]:
            u = [q[i] - p0[i] for i in range(3)]
            v = [r[i] - p0[i] for i in range(3)]
            c = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]
            m = math.sqrt(sum(x * x for x in c))
            if m > best:
                best, nrm = m, [x / m for x in c]
    if nrm is None:
        return 0.0, None
    return max(abs(sum((p[i] - p0[i]) * nrm[i] for i in range(3))) for p in pts), [round(x, 5) for x in nrm]


def zrange(curves, axis=2, n=9):
    v = [at(c, i / (n - 1.0))[0][axis] for c in curves for i in range(n)]
    return round(min(v), 5), round(max(v), 5)


# ------------------------------------------------------------------ section helpers
def fill(sec, rules, help_point, seed=None, types=NXOpen.Section.AllowTypes.OnlyCurves):
    """Populate a builder-owned Section in place (most curve builders expose a read-only Section)."""
    sec.SetAllowedEntityTypes(types)
    sec.AddToSection(rules, seed if seed is not None else NULL, NULL, NULL, P(*help_point), NXOpen.Section.Mode.Create, False)
    return sec


def recipe(name, fn):
    if ONLY and not any(name.startswith(o) for o in ONLY):
        return None
    r, err = nxh.attempt(name, fn, log=log)
    if err:
        res["not_working"][name] = err
        log("NOT WORKING", name, err)
    return r


def run():
    part = nxh.new_part(os.path.join(OUT, "curve_features.prt"))
    dat = nxh.Datums(part)
    R = part.ScRuleFactory
    for n, f, u in (("ln_len", "50", "mm"), ("arc_r", "12", "mm"), ("off_d", "5", "mm"), ("hx_d", "20", "mm"),
                    ("hx_p", "5", "mm"), ("hx_n", "4", None), ("cut_z", "10", "mm")):
        nxh.expr(part, n, f, u)
    _f, blk = nxh.block(part, (0, 0, 0), (60, 40, 20))
    _f, cyl = nxh.cylinder(part, (100, 0, 0), (0, 0, 1), 30, 40)
    top = nxh.faces(blk, ftype=nxh.PLANE, normal=(0, 0, 1))[0]
    cyl_face = nxh.faces(cyl, ftype=nxh.CYLINDER)[0]
    keep = {}

    # ---------------- C1 associative line between two smart points
    def c1():
        b = part.BaseFeatures.CreateAssociativeLineBuilder(NXOpen.Features.AssociativeLine.Null)
        try:
            LB = NXOpen.Features.AssociativeLineBuilder
            b.StartPointOptions = LB.StartOption.Point
            b.StartPoint.Value = nxh.point(part, 0, -30, 0)
            b.EndPointOptions = LB.EndOption.Point
            b.EndPoint.Value = nxh.point(part, "ln_len", -30, 0)
            b.Associative = True
            f = b.CommitFeature()
        finally:
            b.Destroy()
        f.SetName("LINE_A")
        ln = curves_of(f)[0]
        keep["line_a"] = (f, ln)
        check("C1 associative line", abs(ln.GetLength() - 50) < 1e-6 and f.FeatureType == "LINE", length=ln.GetLength(),
              type=f.FeatureType, ends=[e[0] for e in ends(ln)])

    recipe("C1", c1)

    # ---------------- C2 associative arc: centre + radius, full circle and limited arc
    def c2():
        b = part.BaseFeatures.CreateAssociativeArcBuilder(NXOpen.Features.AssociativeArc.Null)
        try:
            AB = NXOpen.Features.AssociativeArcBuilder
            b.Type = AB.Types.ArcFromCenter
            b.CenterPoint.Value = nxh.point(part, 0, -60, 0)
            b.EndPointOptions = AB.EndOption.Radius
            b.Radius.RightHandSide = "arc_r"
            b.Limits.StartLimit.LimitOption = NXOpen.GeometricUtilities.CurveExtendData.LimitOptions.Value
            b.Limits.EndLimit.LimitOption = NXOpen.GeometricUtilities.CurveExtendData.LimitOptions.Value
            b.Limits.StartLimit.Distance.RightHandSide = "0"
            b.Limits.EndLimit.Distance.RightHandSide = "90"
            b.Limits.FullCircle = False
            b.Associative = True
            f = b.CommitFeature()
        finally:
            b.Destroy()
        f.SetName("ARC_A")
        a = curves_of(f)[0]
        keep["arc_a"] = (f, a)
        check("C2 associative arc (centre, radius, 0-90 deg)", abs(a.GetLength() - math.pi * 12 / 2) < 1e-5 and abs(a.Radius - 12) < 1e-9,
              length=a.GetLength(), expect=math.pi * 6, radius=a.Radius, type=f.FeatureType, centre=[a.CenterPoint.X, a.CenterPoint.Y, a.CenterPoint.Z])

    recipe("C2", c2)

    # ---------------- C3 studio spline feature
    SB = NXOpen.Features.StudioSplineBuilderEx

    def spline(points, kind, degree, start_dir=None, end_dir=None, name=None, g2=False):
        b = part.Features.CreateStudioSplineBuilderEx(NULL)
        try:
            b.Type = kind
            b.Degree = degree
            b.IsAssociative = True
            b.IsPeriodic = False
            b.MatchKnotsType = SB.MatchKnotsTypes.NotSet
            b.OrientExpress.ReferenceOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Reference.ProgramDefined
            b.DrawingPlaneOption = SB.DrawingPlaneOptions.General
            n = len(points)
            for i, p in enumerate(points):
                g = b.ConstraintManager.CreateGeometricConstraintData()
                g.Point = nxh.point(part, *p)
                d = start_dir if i == 0 else (end_dir if i == n - 1 else None)
                if d is not None:
                    GC = NXOpen.Features.GeometricConstraintData
                    g.AutomaticConstraintDirection = GC.ParameterDirection.Iso
                    g.AutomaticConstraintType = GC.AutoConstraintType.NotSet
                    g.TangentDirection = nxh.direction(part, d)
                b.ConstraintManager.Append(g)
            f = b.Commit()
            sp = b.Curve
        finally:
            b.Destroy()
        if name:
            f.SetName(name)
        return f, sp

    def c3a():
        pts = [(0, 60, 0), (15, 70, 5), (30, 65, 10), (45, 75, 0)]
        f, sp = spline(pts, SB.Types.ThroughPoints, 3, name="SPL_THROUGH")
        c = curves_of(f)[0]
        e = ends(c)
        mid_ok = min(math.dist(at(c, t / 200.0)[0], pts[1]) for t in range(201)) < 0.05
        dev, _n = planarity([c])
        keep["spl"] = (f, c)
        check("C3a studio spline through 4 points (3D)", near(e[0][0], pts[0]) and near(e[1][0], pts[3]) and mid_ok and dev > 1.0,
              type=f.FeatureType, cls=type(c).__name__, length=c.GetLength(), ends=[e[0][0], e[1][0]], passes_pt2=mid_ok,
              non_planar_dev=round(dev, 3), order=getattr(c, "Order", None), poles=getattr(c, "PoleCount", None))

    recipe("C3a", c3a)

    def c3b():
        pts = [(0, 90, 0), (15, 110, 0), (30, 90, 0), (45, 110, 0)]
        f, sp = spline(pts, SB.Types.ByPoles, 3, name="SPL_POLES")
        c = curves_of(f)[0]
        e = ends(c)
        d2 = min(math.dist(at(c, t / 200.0)[0], pts[1]) for t in range(201))
        dev, n = planarity([c])
        check("C3b studio spline by poles (planar)", near(e[0][0], pts[0]) and near(e[1][0], pts[3]) and d2 > 1.0 and dev < 1e-6
              and par(e[0][1], (15, 20, 0)), ends=[e[0][0], e[1][0]], start_tangent=e[0][1], dist_to_pole2=round(d2, 3),
              planar_dev=dev, normal=n, length=c.GetLength())

    recipe("C3b", c3b)

    def c3c():
        pts = [(0, 130, 0), (20, 140, 0), (40, 130, 0)]
        f, sp = spline(pts, SB.Types.ThroughPoints, 3, start_dir=(0, 1, 0), end_dir=(0, -1, 0), name="SPL_G1")
        c = curves_of(f)[0]
        e = ends(c)
        check("C3c studio spline with G1 end directions", par(e[0][1], (0, 1, 0)) and par(e[1][1], (0, 1, 0))
              and near(e[0][0], pts[0]) and near(e[1][0], pts[2]), start_tangent=e[0][1], end_tangent=e[1][1],
              length=c.GetLength())

    recipe("C3c", c3c)

    # ---------------- C4 bridge curve between two lines, G1 both ends
    def c4():
        l1 = nxh.line(part, (0, -90, 0), (20, -90, 0))
        l2 = nxh.line(part, (40, -80, 0), (40, -60, 0))
        b = part.Features.CreateBridgeCurveBuilderEx(NXOpen.Features.BridgeCurve.Null)
        try:
            # the curves go into the builder-owned StartSection / EndSection; the help point picks the END to bridge from
            fill(b.StartSection, [R.CreateRuleCurveDumb([l1])], (19, -90, 0), l1)
            fill(b.EndSection, [R.CreateRuleCurveDumb([l2])], (40, -79, 0), l2)
            b.IsAssociative = True
            f = b.Commit()
        finally:
            b.Destroy()
        c = curves_of(f)[0]
        e = ends(c)
        pair = sorted([e[0], e[1]], key=lambda q: q[0][0])
        check("C4 bridge curve G1-G1 between two lines", near(pair[0][0], (20, -90, 0)) and near(pair[1][0], (40, -80, 0))
              and par(pair[0][1], (1, 0, 0)) and par(pair[1][1], (0, 1, 0)), type=f.FeatureType, ends=[pair[0][0], pair[1][0]],
              tangents=[pair[0][1], pair[1][1]], length=c.GetLength())

    recipe("C4", c4)

    # ---------------- C5 project curve
    def project(curves, faces=None, plane=None, vector=None, name=None):
        b = part.Features.CreateProjectCurveBuilder(NF)
        try:
            PB = NXOpen.Features.ProjectCurveBuilder
            b.Tolerance = 0.01
            fill(b.SectionToProject, [R.CreateRuleCurveDumb(list(curves))], (0, 0, 0), types=NXOpen.Section.AllowTypes.CurvesAndPoints)
            if faces:
                b.FaceToProjectTo.Add(nxh.collector(part, faces=list(faces)))      # SelectObjectList holding an ScCollector
            if plane is not None:
                b.PlaneToProjectTo = plane
            if vector is None:
                b.ProjectionDirectionMethod = PB.DirectionType.AlongFaceNormal
            else:
                b.ProjectionDirectionMethod = PB.DirectionType.AlongVector
                b.ProjectionVector = nxh.direction(part, vector)
            b.InputCurvesOption.Associative = True
            f = b.Commit()
        finally:
            b.Destroy()
        if name:
            f.SetName(name)
        return f

    def c5a():
        src = nxh.line(part, (5, 5, 50), (55, 35, 50))
        f = project([src], faces=[top], vector=(0, 0, -1), name="PROJ_VEC")
        cs = curves_of(f)
        z = zrange(cs)
        check("C5a project along vector onto a face", len(cs) == 1 and z == (20.0, 20.0) and abs(total_length(cs) - src.GetLength()) < 1e-4,
              type=f.FeatureType, n=len(cs), z=z, length=total_length(cs), expect=src.GetLength())

    recipe("C5a", c5a)

    def c5b():
        src = nxh.line(part, (100, -30, 10), (100, -30, 30))          # outside the cylinder, parallel to its axis
        f = project([src], faces=[cyl_face], name="PROJ_NORMAL")
        cs = curves_of(f)
        e = ends(cs[0])
        check("C5b project along face normal onto a cylinder", len(cs) == 1 and near(sorted([e[0][0], e[1][0]])[0], (100, -15, 10))
              and abs(total_length(cs) - 20) < 1e-4, n=len(cs), ends=[e[0][0], e[1][0]], length=total_length(cs))

    recipe("C5b", c5b)

    def c5c():
        src = nxh.arc(part, (30, 20, 60), (1, 0, 0), (0, 1, 0), 10, 0.0, math.pi)
        pl = part.Planes.CreatePlane(P(0, 0, 0), V(0, 0, 1), UPD)
        f = project([src], plane=pl, vector=(0, 0, -1), name="PROJ_PLANE")
        cs = curves_of(f)
        check("C5c project onto a plane (XY)", len(cs) == 1 and zrange(cs) == (0.0, 0.0) and abs(total_length(cs) - math.pi * 10) < 1e-4,
              n=len(cs), z=zrange(cs), length=total_length(cs), cls=type(cs[0]).__name__)

    recipe("C5c", c5c)

    # ---------------- C6 intersection curve: body x datum plane (expression-driven height)
    def c6():
        fp, dp = nxh.datum_plane(part, (0, 0, "cut_z"), (0, 0, 1), "DP_CUT")
        keep["dp_cut"] = dp
        b = part.Features.CreateIntersectionCurveBuilder(NF)
        try:
            b.Tolerance = 0.01                       # default is 0 -> "Distance Tolerance cannot be zero."
            b.FirstFace.ReplaceRules([R.CreateRuleFaceBody(blk)], False)
            b.SecondFace.ReplaceRules([R.CreateRuleFaceDatum([dp])], False)
            b.Associative = True
            f = b.Commit()
        finally:
            b.Destroy()
        f.SetName("INT_BLOCK")
        cs = curves_of(f)
        keep["int"] = f
        check("C6 intersection curve body x datum plane", len(cs) == 4 and abs(total_length(cs) - 200) < 1e-4 and zrange(cs) == (10.0, 10.0),
              type=f.FeatureType, n=len(cs), length=total_length(cs), z=zrange(cs))

    recipe("C6", c6)

    def c6b():
        b = part.Features.CreateIntersectionCurveBuilder(NF)
        try:
            b.Tolerance = 0.01
            b.FirstFace.ReplaceRules([R.CreateRuleFaceDumb([cyl_face])], False)
            pl = part.Planes.CreatePlane(P(0, 0, 20), V(0, 0, 1), UPD)
            b.SecondPlane = pl
            b.Associative = True
            f = b.Commit()
        finally:
            b.Destroy()
        cs = curves_of(f)
        check("C6b intersection curve face set x specified plane", abs(total_length(cs) - math.pi * 30) < 1e-3 and zrange(cs) == (20.0, 20.0),
              n=len(cs), length=total_length(cs), expect=math.pi * 30)

    recipe("C6b", c6b)

    # ---------------- C7 section curve: body x plane
    def c7():
        b = part.Features.CreateSectionCurveBuilder(NF)
        try:
            b.Type = NXOpen.Features.SectionCurveBuilder.PlaneType.Selected
            b.Tolerance = 0.01
            b.ObjectsToSection.Add(cyl)
            b.SectionPlanes.Add(keep["dp_cut"])
            b.Associative = True
            f = b.Commit()
        finally:
            b.Destroy()
        cs = curves_of(f)
        check("C7 section curve body x datum plane", abs(total_length(cs) - math.pi * 30) < 1e-3 and zrange(cs) == (10.0, 10.0),
              type=f.FeatureType, n=len(cs), length=total_length(cs), expect=math.pi * 30)

    recipe("C7", c7)

    # ---------------- C8 offset curve (planar, distance)
    def c8():
        rect = nxh.rect(part, 0, 160, 60, 200, 0.0)

        def off(reverse):
            b = part.Features.CreateOffsetCurveBuilder(NF)
            try:
                OB = NXOpen.Features.OffsetCurveBuilder
                b.Type = OB.Types.Distance
                b.InputCurvesOptions.InputCurveOption = NXOpen.GeometricUtilities.CurveOptions.InputCurve.Retain
                b.InputCurvesOptions.Associative = True
                b.Tolerance = 0.01
                b.TrimMethod = OB.TrimOption.ExtendTangents
                b.OffsetDistance.RightHandSide = "off_d"
                fill(b.CurvesToOffset, [R.CreateRuleCurveDumb(rect)], (0, 160, 0), rect[0])
                b.ReverseDirection = reverse
                f = b.Commit()
            finally:
                b.Destroy()
            return f

        f1, f2 = off(False), off(True)
        L1, L2 = total_length(curves_of(f1)), total_length(curves_of(f2))
        keep["off"] = (f1, f2)
        check("C8 offset curve distance (both sides)", sorted([round(L1, 4), round(L2, 4)]) == [160.0, 240.0], type=f1.FeatureType,
              length_reverse_false=L1, length_reverse_true=L2, n=len(curves_of(f1)), inward=160.0, outward=240.0)

    recipe("C8", c8)

    # ---------------- C9 composite curve: extract a tangent / dumb edge loop as associative curves
    def c9():
        loop = top.GetEdges()
        b = part.Features.CreateCompositeCurveBuilder(NF)
        try:
            fill(b.Section, [R.CreateRuleEdgeDumb(list(loop))], (0, 0, 20), loop[0])
            b.Associative = True
            b.ParentPart = NXOpen.Features.CompositeCurveBuilder.PartType.WorkPart
            b.FixAtCurrentTimestamp = False
            b.JoinOption = NXOpen.Features.CompositeCurveBuilder.JoinMethod.No
            f = b.Commit()
        finally:
            b.Destroy()
        f.SetName("EDGES_TOP")
        cs = curves_of(f)
        keep["comp"] = f
        check("C9 composite curve from face edges", len(cs) == 4 and abs(total_length(cs) - 200) < 1e-4 and zrange(cs) == (20.0, 20.0),
              type=f.FeatureType, n=len(cs), length=total_length(cs))

    recipe("C9", c9)

    # ---------------- C10 curve length (extend / shorten by increments)
    def c10():
        f0, ln = keep["line_a"]
        b = part.Features.CreateCurvelengthBuilder(NF)
        try:
            sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)      # this builder has NO section of its own
            fill(sec, [R.CreateRuleCurveDumb([ln])], (0, -30, 0), ln)
            b.Section = sec
            b.DistanceTolerance = 0.01
            # defaults are already Incremental / StartEnd / Natural
            b.CurvelengthData.StartDistance.RightHandSide = "3"
            b.CurvelengthData.EndDistance.RightHandSide = "-10"
            b.CurveOptions.Associative = True
            b.CurveOptions.InputCurveOption = NXOpen.GeometricUtilities.CurveOptions.InputCurve.Retain
            f = b.Commit()
        finally:
            b.Destroy()
        cs = curves_of(f)
        check("C10 curve length +3 / -10", abs(total_length(cs) - 43) < 1e-5, type=f.FeatureType, length=total_length(cs), expect=43.0,
              ends=[e[0] for e in ends(cs[0])])

    recipe("C10", c10)

    # ---------------- C11 helix (constant, then tapered by a linear law)
    def helix(taper_to=None):
        b = part.Features.CreateHelixBuilder(NXOpen.Features.Helix.Null)
        try:
            HB = NXOpen.Features.HelixBuilder
            LT = NXOpen.GeometricUtilities.LawBuilder.Type
            b.OrientationOption = HB.OrientationOptions.Specified
            b.StartAngle.RightHandSide = "0"
            b.SizeOption = HB.SizeOptions.Diameter
            if taper_to is None:
                b.SizeLaw.LawType = LT.Constant
                b.SizeLaw.Value.RightHandSide = "hx_d"
            else:
                b.SizeLaw.LawType = LT.Linear
                b.SizeLaw.StartValue.RightHandSide = "hx_d"
                b.SizeLaw.EndValue.RightHandSide = str(taper_to)
            b.PitchLaw.LawType = LT.Constant
            b.PitchLaw.Value.RightHandSide = "hx_p"
            b.LengthMethod = HB.LengthMethods.Turns
            b.Turns.RightHandSide = "hx_n"          # Turns is the Expression; NumberOfTurns is a plain string
            b.TurnDirection = HB.TurnDirections.RightHand
            b.DistanceTolerance = 0.001
            f = b.Commit()
        finally:
            b.Destroy()
        return f

    def c11():
        f = helix()
        f.SetName("HELIX_CONST")
        c = curves_of(f)[0]
        exp = 4 * math.sqrt((math.pi * 20) ** 2 + 25)
        e = ends(c)
        keep["helix"] = (f, c)
        check("C11a helix constant d20 p5 n4", abs(c.GetLength() - exp) < 0.01 and near(e[0][0], (10, 0, 0)) and near(e[1][0], (10, 0, 20)),
              type=f.FeatureType, length=c.GetLength(), expect=exp, ends=[e[0][0], e[1][0]])
        f2 = helix(taper_to=10)
        f2.SetName("HELIX_TAPER")
        c2 = curves_of(f2)[0]
        e2 = ends(c2)
        check("C11b helix linear diameter law 20 -> 10", near(e2[0][0], (10, 0, 0)) and near(e2[1][0], (5, 0, 20)) and c2.GetLength() < c.GetLength(),
              length=c2.GetLength(), ends=[e2[0][0], e2[1][0]])

    recipe("C11", c11)

    # ---------------- C12 text (planar) - part marking curves
    def c12():
        b = part.Features.CreateTextBuilder(NXOpen.Features.Text.Null)
        try:
            TB = NXOpen.Features.TextBuilder
            b.Type = TB.Types.Planar
            b.Script = TB.ScriptOptions.Western
            b.SelectFont("Arial", TB.ScriptOptions.Western)
            b.TextString = "NX 2206"
            b.PlanarFrame.AnchorLocation = NXOpen.GeometricUtilities.RectangularFrameBuilder.AnchorLocationType.BottomCenter
            b.PlanarFrame.Length.RightHandSide = "40"
            b.PlanarFrame.Height.RightHandSide = "8"
            b.PlanarFrame.Shear.RightHandSide = "0"
            xf = part.Xforms.CreateXform(nxh.point(part, 30, 20, 20), nxh.direction(part, (1, 0, 0)), nxh.direction(part, (0, 1, 0)), UPD, 1.0)
            b.PlanarFrame.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
            b.PlanarFrame.UpdateOnCoordinateSystem()
            f = b.Commit()
        finally:
            b.Destroy()
        f.SetName("TEXT_MARK")
        cs = curves_of(f)
        xs = [at(c, t)[0][0] for c in cs for t in (0.0, 0.5, 1.0)]
        ys = [at(c, t)[0][1] for c in cs for t in (0.0, 0.5, 1.0)]
        keep["text"] = f
        check("C12 planar text curves", len(cs) >= 5 and zrange(cs) == (20.0, 20.0) and 9.5 < min(xs) and max(xs) < 50.5
              and 19.5 < min(ys) and max(ys) < 28.5, type=f.FeatureType, n=len(cs), x=[round(min(xs), 2), round(max(xs), 2)],
              y=[round(min(ys), 2), round(max(ys), 2)], z=zrange(cs))
        m = nxh.mark("text emboss", False)
        sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
        sec.AddToSection([R.CreateRuleCurveFeature([f])], NULL, NULL, NULL, P(30, 20, 20), NXOpen.Section.Mode.Create, False)
        v0 = nxh.volume(part, blk)
        nxh.extrude(part, sec, (0, 0, -1), 0, 0.5, nxh.BOOL.Subtract, blk)
        v1 = nxh.volume(part, blk)
        check("C12b engrave the text 0.5 deep (CurveFeature rule on the Text feature)", 5 < v0 - v1 < 160 and len(nxh.solids(part)) == 2,
              removed=round(v0 - v1, 3), solids=len(nxh.solids(part)))
        nxh.undo_to(m)

    recipe("C12", c12)

    # ---------------- C13 offset curve in face (AOCS): face boundary offset inward on the face
    def aocs(edges, face, formula):
        b = part.Features.CreateAocsBuilder(NF)                  # takes Feature.Null, not AOCS.Null
        try:
            sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
            fill(sec, [R.CreateRuleEdgeDumb(list(edges))], (0, 0, 20), edges[0])
            ess = part.CreateExpressionSectionSet(sec, "1", "MilliMeter", 0)   # number first, formula afterwards
            b.Offsets.Append(ess)
            ess.ItemValue.RightHandSide = formula
            b.FaceCollector = nxh.collector(part, faces=[face])  # ASSIGN: the getter returns NULL on a new builder
            b.AssociativeOutputOption = True
            b.DistanceTolerance = 0.01
            f = b.Commit()
        finally:
            b.Destroy()
        return f

    def c13():
        loop = top.GetEdges()
        m = nxh.mark("aocs", False)
        f = aocs(loop, top, "off_d")
        first = round(total_length(curves_of(f)), 4)
        sign = "+"
        if first > 200:            # landed outside the face (on its extension): the side is not predictable -> flip the sign
            nxh.undo_to(m)
            f = aocs(loop, top, "-off_d")
            sign = "-"
        f.SetName("OFFSET_IN_FACE")
        cs = curves_of(f)
        L = total_length(cs)
        keep["aocs"] = f
        check("C13 offset curve in face (edges of top face, 5 inward)", zrange(cs) == (20.0, 20.0) and abs(L - 160) < 1e-3,
              type=f.FeatureType, n=len(cs), length=L, expect_inward=160.0, outward=240.0, first_try_length=first, sign_used=sign)

    recipe("C13", c13)

    # ---------------- parametric proof for the associative curves
    def edit():
        nxh.set_expr(part, "ln_len", "70")
        nxh.set_expr(part, "cut_z", "15")
        nxh.set_expr(part, "off_d", "2")
        nxh.set_expr(part, "hx_n", "6")
        nxh.update()
        out = {"errors": nxh.feature_errors(part)}
        ok = not out["errors"]
        if "line_a" in keep:
            out["line"] = curves_of(keep["line_a"][0])[0].GetLength()
            ok = ok and abs(out["line"] - 70) < 1e-6
        if "int" in keep:
            out["int_z"] = zrange(curves_of(keep["int"]))
            ok = ok and out["int_z"] == (15.0, 15.0)
        if "off" in keep:
            out["off"] = sorted(round(total_length(curves_of(f)), 4) for f in keep["off"])
            ok = ok and out["off"] == [184.0, 216.0]
        if "aocs" in keep:
            out["aocs"] = round(total_length(curves_of(keep["aocs"])), 4)
            ok = ok and out["aocs"] == 184.0
        if "helix" in keep:
            out["helix"] = curves_of(keep["helix"][0])[0].GetLength()
            ok = ok and abs(out["helix"] - 6 * math.sqrt((math.pi * 20) ** 2 + 25)) < 0.02
        check("edit expressions: curve features follow", ok, **out)

    recipe("edit", edit)
    res["features"] = [(f["ts"], f["type"], f["cls"], f["name"]) for f in nxh.feature_table(part)]
    res["errors"] = nxh.feature_errors(part)
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res["result"] = "PASS" if res["checks"] and all(c["ok"] for c in res["checks"].values()) and "error" not in res else "FAIL"
nxh.write_json(os.path.join(OUT, "curve_features.json"), res)
