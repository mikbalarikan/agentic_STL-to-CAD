"""Verified datum recipes for NX 2206 (headless run_journal).

  run.ps1 -Script datum_recipes.py -WorkDir <out> -JArgs <out>

Datum planes (offset from plane / from face, at angle, three points, bisector, tangent to a
cylinder, on curve, coincident), datum axes (point + direction, two points, cylinder axis,
intersection of two planes), an expression-driven datum CSYS, a point feature, and a sketch on
an angled datum plane. Every datum is read back (origin, normal) and compared with the
analytic value. Writes datum_recipes.json with "result": "PASS" | "FAIL".
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import nxh  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
# Continuous Auto Dimensioning off BEFORE any sketch is created: with it on (the batch default) GetStatus() reads
# WellConstrained / 0 for any sketch, so the DOF check below would prove nothing (nx-journal-core section 5).
nxh.S.Preferences.Sketch.ContinuousAutoDimensioning = False
P, V, UPD = nxh.P, nxh.V, nxh.UPD
MT = NXOpen.PlaneTypes.MethodType
SK = NXOpen.Sketch
log = nxh.Log(os.path.join(OUT, "datum_recipes.log"))
res = {"checks": {}}


def check(name, ok, **data):
    res["checks"][name] = dict(ok=bool(ok), **data)
    log(("PASS " if ok else "FAIL ") + name, data)
    return ok


def r3(v):
    return [round(v.X, 5), round(v.Y, 5), round(v.Z, 5)]


def dplane(part, method, geom, formula=None, name=None, alternate=None, flip=False, tweak=None):
    """Datum plane feature from a PlaneTypes.MethodType + defining objects. Returns the feature.

    formula: offset (Distance), angle in degrees (Angle), percent / arc length (Frenet)."""
    b = part.Features.CreateDatumPlaneBuilder(nxh.NULL_FEATURE)
    try:
        pl = b.GetPlane()
        pl.SetUpdateOption(UPD)
        pl.SetMethod(method)
        pl.SetGeometry(list(geom))
        pl.SetFlip(flip)
        if alternate is not None:
            pl.SetAlternate(alternate)
        if tweak:
            tweak(pl)
        if formula is not None:
            pl.Expression.RightHandSide = str(formula)
        pl.Evaluate()
        f = b.CommitFeature()
    finally:
        b.Destroy()
    if name:
        f.SetName(name)
    return f


def pinfo(f):
    dp = f.DatumPlane
    return {"origin": r3(dp.Origin), "normal": r3(dp.Normal), "type": f.FeatureType,
            "exprs": [f"{e.Name}={e.RightHandSide}" for e in f.GetExpressions()]}


def par(n, v, tol=1e-4):
    """normal n parallel (either sense) to v"""
    m = math.sqrt(sum(x * x for x in v))
    return abs(abs(sum(a * b for a, b in zip(n, v)) / m) - 1.0) < tol


def run():
    part = nxh.new_part(os.path.join(OUT, "datum_recipes.prt"))
    dat = nxh.Datums(part)
    for n, f, u in (("dp_off", "15", "mm"), ("dp_ang", "30", "deg"), ("cs_x", "70", "mm"), ("blk_l", "60", "mm")):
        nxh.expr(part, n, f, u)
    _f, blk = nxh.block(part, (0, 0, 0), ("blk_l", 40, 20))
    _f, cyl = nxh.cylinder(part, (100, 0, 0), (0, 0, 1), 20, 30)
    cyl_face = nxh.faces(cyl, ftype=nxh.CYLINDER)[0]
    top = nxh.faces(blk, ftype=nxh.PLANE, normal=(0, 0, 1))[0]
    fx0 = nxh.faces(blk, ftype=nxh.PLANE, normal=(-1, 0, 0))[0]
    fx1 = nxh.faces(blk, ftype=nxh.PLANE, normal=(1, 0, 0))[0]
    res["enums"] = {"AlternateType": nxh.enum_names(NXOpen.PlaneTypes.AlternateType),
                    "FrenetSubtype": nxh.enum_names(NXOpen.PlaneTypes.FrenetSubtype),
                    "DatumAxisTypes": nxh.enum_names(NXOpen.Features.DatumAxisBuilder.Types)}
    keep = {}

    def plane_case(label, ok_fn, *a, **kw):
        def go():
            f = dplane(part, *a, **kw)
            return f
        f, err = nxh.attempt(label, go, log=log)
        if err:
            return check(label, False, error=err)
        info = pinfo(f)
        keep[label] = f
        return check(label, ok_fn(info), **info)

    # D1 offset from a datum plane, expression driven
    plane_case("D1 offset from datum plane", lambda i: abs(i["origin"][2] - 15) < 1e-6 and par(i["normal"], (0, 0, 1)),
               MT.Distance, [dat.xy], "dp_off", "DP_OFFSET")
    # D2 offset from a planar body face (follows the face)
    plane_case("D2 offset from body face", lambda i: abs(i["origin"][2] - 25) < 1e-6 and par(i["normal"], (0, 0, 1)),
               MT.Distance, [top], "5", "DP_FACE_OFFSET")
    # D2b coincident with a face = the user's most common datum plane ("Offset" = 0, 166 of 645)
    plane_case("D2b offset 0 from face x=blk_l", lambda i: abs(i["origin"][0] - 60) < 1e-6 and par(i["normal"], (1, 0, 0)),
               MT.Distance, [fx1], "0", "DP_ON_FACE")
    # D3 at an angle to a plane about an axis
    c30, s30 = math.cos(math.radians(30)), math.sin(math.radians(30))
    plane_case("D3 angle to XY about X axis", lambda i: par(i["normal"], (0, -s30, c30)) or par(i["normal"], (0, s30, c30)),
               MT.Angle, [dat.xy, dat.x], "dp_ang", "DP_ANGLE")
    # D4 through three points
    pts = [nxh.point(part, 0, 0, 30), nxh.point(part, 10, 0, 30), nxh.point(part, 0, 10, "30+10")]
    plane_case("D4 three points", lambda i: par(i["normal"], (0, -1, 1)), MT.ThreePoints, pts, None, "DP_3PT")
    # D5 bisector of two parallel faces
    plane_case("D5 bisector (Center) of two faces", lambda i: abs(i["origin"][0] - 30) < 1e-6 and par(i["normal"], (1, 0, 0)),
               MT.Center, [fx0, fx1], None, "DP_MID")
    # D6 tangent to a cylinder: try the candidate method types, keep what works
    tang = {}
    for label, method, geom, formula in (
            ("Tangent[cyl]", MT.Tangent, [cyl_face], None),
            ("TangentFace[cyl]", MT.TangentFace, [cyl_face], None),
            ("TangentParPlane[cyl,YZ]", MT.TangentParPlane, [cyl_face, dat.yz], None),
            ("TangentPerpPlane[cyl,YZ]", MT.TangentPerpPlane, [cyl_face, dat.yz], None),
            ("TangentAnglePlane[cyl,YZ]", MT.TangentAnglePlane, [cyl_face, dat.yz], "0"),
            ("Tangent[cyl,YZ]", MT.Tangent, [cyl_face, dat.yz], None)):
        f, err = nxh.attempt(label, lambda: dplane(part, method, geom, formula, "DP_TAN"), log=log)
        if err:
            tang[label] = "ERR " + err
            continue
        i = pinfo(f)
        o, n = i["origin"], i["normal"]
        dist = abs((o[0] - 100) * n[0] + o[1] * n[1])          # distance of the plane from the cylinder axis
        i["dist_from_axis"] = round(dist, 5)
        i["ok"] = abs(dist - 10) < 1e-4 and abs(n[2]) < 1e-6
        tang[label] = i
    res["D6_variants"] = tang
    good = [k for k, v in tang.items() if isinstance(v, dict) and v["ok"]]
    check("D6 tangent to cylinder", bool(good), working=good)
    # D7 on curve (normal to the curve at a percentage)
    edge = [e for e in blk.GetEdges() if abs(nxh.bbox(e)[1]) < 1e-6 and abs(nxh.bbox(e)[4]) < 1e-6
            and abs(nxh.bbox(e)[2]) < 1e-6 and abs(nxh.bbox(e)[5]) < 1e-6][0]          # the edge along X at y=0,z=0
    onc = {}
    for label, sub in [(n, getattr(NXOpen.PlaneTypes.FrenetSubtype, n)) for n in nxh.enum_names(NXOpen.PlaneTypes.FrenetSubtype)]:
        def go(sub=sub):
            def tw(pl):
                pl.SetPercent(True)
                pl.SetFrenetSubtype(sub)
            return dplane(part, MT.Frenet, [edge], "25", "DP_ONCURVE", tweak=tw)
        f, err = nxh.attempt("Frenet " + label, go, log=log)
        onc[label] = pinfo(f) if not err else "ERR " + err
    res["D7_variants"] = onc
    good = [k for k, v in onc.items() if isinstance(v, dict) and par(v["normal"], (1, 0, 0)) and abs(v["origin"][0] - 15) < 1e-4]
    check("D7 on curve at 25 % (normal = curve tangent)", bool(good), working=good)
    # D8 coincident
    plane_case("D8 coincident with face", lambda i: abs(i["origin"][2] - 20) < 1e-6 and par(i["normal"], (0, 0, 1)),
               MT.Coincident, [top], None, "DP_COINC")

    # ---------------- datum axes
    AX = NXOpen.Features.DatumAxisBuilder

    def daxis(configure, name):
        b = part.Features.CreateDatumAxisBuilder(nxh.NULL_FEATURE)
        try:
            b.IsAssociative = True
            configure(b)
            f = b.CommitFeature()
        finally:
            b.Destroy()
        f.SetName(name)
        return f

    def ainfo(f):
        da = f.DatumAxis
        return {"origin": r3(da.Origin), "dir": r3(da.Direction), "type": f.FeatureType}

    def axis_case(label, ok_fn, configure, name):
        f, err = nxh.attempt(label, lambda: daxis(configure, name), log=log)
        if err:
            return check(label, False, error=err)
        i = ainfo(f)
        keep[label] = f
        return check(label, ok_fn(i), **i)

    def a1(b):
        b.Type = AX.Types.PointAndDir
        b.Point = nxh.point(part, "cs_x", 0, 0)
        b.Vector = nxh.direction(part, (0, 1, 0))

    axis_case("A1 axis point + direction", lambda i: par(i["dir"], (0, 1, 0)) and abs(i["origin"][0] - 70) < 1e-6, a1, "AX_PT_DIR")

    def a2(b):
        b.Type = AX.Types.TwoPoints
        b.Point1 = nxh.point(part, 0, 0, 40)
        b.Point2 = nxh.point(part, 10, 10, 40)

    axis_case("A2 axis two points", lambda i: par(i["dir"], (1, 1, 0)), a2, "AX_2PT")

    def a3(b):
        b.Type = AX.Types.CurveOrFaceAxis
        b.CurveOrFace.Value = cyl_face

    axis_case("A3 axis of cylinder face", lambda i: par(i["dir"], (0, 0, 1)) and abs(i["origin"][0] - 100) < 1e-6
              and abs(i["origin"][1]) < 1e-6, a3, "AX_CYL")

    def a4(b):
        b.Type = AX.Types.Intersection
        b.Object1.Value = keep["D1 offset from datum plane"].DatumPlane
        b.Object2.Value = dat.xz

    axis_case("A4 axis = intersection of two planes", lambda i: par(i["dir"], (1, 0, 0)) and abs(i["origin"][2] - 15) < 1e-6,
              a4, "AX_INT")

    # ---------------- datum CSYS at an expression-driven origin, rotated 90 deg about Z
    def dcsys():
        o = nxh.point(part, "cs_x", 50, 0)
        xf = part.Xforms.CreateXform(o, nxh.direction(part, (0, 1, 0)), nxh.direction(part, (-1, 0, 0)), UPD, 1.0)
        b = part.Features.CreateDatumCsysBuilder(nxh.NULL_FEATURE)
        try:
            b.Csys = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
            b.DisplayScaleFactor = 1.25
            f = b.CommitFeature()
        finally:
            b.Destroy()
        f.SetName("CSYS_LOCAL")
        return f

    f, err = nxh.attempt("C1 datum csys", dcsys, log=log)
    if err:
        check("C1 datum CSYS (expression origin)", False, error=err)
    else:
        jid = f.JournalIdentifier
        xy = part.Datums.FindObject(f"{jid} XY plane")
        xax = part.Datums.FindObject(f"{jid} X axis")
        o = f.FindObject("POINT 1").Coordinates
        keep["csys"] = f
        check("C1 datum CSYS (expression origin)", abs(o.X - 70) < 1e-6 and abs(o.Y - 50) < 1e-6 and par(r3(xax.Direction), (0, 1, 0))
              and par(r3(xy.Normal), (0, 0, 1)), origin=r3(o), x_axis=r3(xax.Direction), jid=jid)

    # ---------------- point feature
    def pfeat():
        b = part.BaseFeatures.CreatePointFeatureBuilder(nxh.NULL_FEATURE)
        try:
            b.Point = nxh.point(part, "cs_x", "dp_off", 5)
            f = b.Commit()
        finally:
            b.Destroy()
        return f

    f, err = nxh.attempt("P1 point feature", pfeat, log=log)
    if err:
        check("P1 point feature", False, error=err)
    else:
        pt = [e for e in f.GetEntities() if isinstance(e, NXOpen.Point)]
        check("P1 point feature", bool(pt) and r3(pt[0].Coordinates) == [70.0, 15.0, 5.0], type=f.FeatureType,
              xyz=r3(pt[0].Coordinates) if pt else None)
        keep["pt"] = f

    # ---------------- sketch on the angled datum plane, extruded along the plane normal
    def sk_on_angle():
        fa = keep["D3 angle to XY about X axis"]
        dp = fa.DatumPlane
        sb = part.Sketches.CreateSimpleSketchInPlaceBuilder()
        try:
            sb.UseWorkPartOrigin = False
            d = part.Directions.CreateDirection(dat.x, NXOpen.Sense.Forward, UPD)
            xf = part.Xforms.CreateXformByPlaneXDirPoint(dp, d, dat.origin, UPD, 0.625, False, False)
            sb.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
            sb.HorizontalReference.Value = dat.x
            sk = sb.Commit()
        finally:
            sb.Destroy()
        sk.Activate(SK.ViewReorient.FalseValue)
        sk.SetName("SKT_ON_ANGLE")
        c = part.Curves.CreateArc(P(0, 0, 0), V(1, 0, 0), V(dp.Normal.Y * 0 + 0, dp.Normal.Z, -dp.Normal.Y), 5.0, 0.0, 2 * math.pi)
        sk.AddGeometry(c, SK.InferConstraintsOption.InferNoConstraints)
        g1, g2 = SK.ConstraintGeometry(), SK.ConstraintGeometry()
        g1.Geometry, g1.PointType, g1.SplineDefiningPointIndex = c, SK.ConstraintPointType.ArcCenter, 0
        g2.Geometry, g2.PointType, g2.SplineDefiningPointIndex = dat.origin, SK.ConstraintPointType.NotSet, 0
        sk.CreateCoincidentConstraint(g1, g2)
        dgm = SK.DimensionGeometry()
        dgm.Geometry, dgm.AssocType, dgm.AssocValue, dgm.HelpPoint, dgm.View = c, SK.AssocType.NotSet, 0, P(5, 0, 0), NXOpen.NXObject.Null
        sk.CreateDiameterDimension(dgm, P(8, 8, 0), NXOpen.Expression.Null).AssociatedExpression.RightHandSide = "10"
        sk.Update()
        st, dof = sk.GetStatus()
        sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
        sec.AddToSection([part.ScRuleFactory.CreateRuleCurveFeature([sk.Feature])], NXOpen.NXObject.Null, NXOpen.NXObject.Null,
                         NXOpen.NXObject.Null, P(0, 0, 0), NXOpen.Section.Mode.Create, False)
        b = part.Features.CreateExtrudeBuilder(nxh.NULL_FEATURE)
        try:
            b.Section = sec
            b.Direction = part.Directions.CreateDirection(dp, NXOpen.Sense.Forward, UPD)     # plane normal, associative
            b.Limits.StartExtend.Value.RightHandSide = "0"
            b.Limits.EndExtend.Value.RightHandSide = "12"
            b.BooleanOperation.Type = nxh.BOOL.Create
            f = b.CommitFeature()
        finally:
            b.Destroy()
        body = f.GetBodies()[0]
        cf = nxh.faces(body, ftype=nxh.CYLINDER)[0]
        return {"dof": dof, "well": st == SK.Status.WellConstrained, "volume": nxh.volume(part, body),
                "axis": [round(x, 5) for x in nxh.face_data(cf)[2]], "body": body, "cf": cf}

    r, err = nxh.attempt("K1 sketch on angled plane", sk_on_angle, log=log)
    if err:
        check("K1 sketch on angled datum plane", False, error=err)
    else:
        body, cf = r.pop("body"), r.pop("cf")
        check("K1 sketch on angled datum plane", r["dof"] == 0 and r["well"] and abs(r["volume"] - math.pi * 25 * 12) < 0.05
              and (par(r["axis"], (0, -s30, c30)) or par(r["axis"], (0, s30, c30))), expect_volume=math.pi * 25 * 12, **r)

    # ---------------- parametric proof
    nxh.set_expr(part, "dp_off", "25")
    nxh.set_expr(part, "dp_ang", "60")
    nxh.set_expr(part, "blk_l", "80")
    nxh.set_expr(part, "cs_x", "90")
    nxh.update()
    after = {k: (pinfo(f) if f.FeatureType.startswith("DATUM_PLANE") else None) for k, f in keep.items() if hasattr(f, "DatumPlane")}
    c60, s60 = math.cos(math.radians(60)), math.sin(math.radians(60))
    ok = (abs(after["D1 offset from datum plane"]["origin"][2] - 25) < 1e-6
          and abs(after["D2b offset 0 from face x=blk_l"]["origin"][0] - 80) < 1e-6
          and abs(after["D5 bisector (Center) of two faces"]["origin"][0] - 40) < 1e-6
          and (par(after["D3 angle to XY about X axis"]["normal"], (0, -s60, c60))
               or par(after["D3 angle to XY about X axis"]["normal"], (0, s60, c60))))
    extra = {}
    if "csys" in keep:
        o = keep["csys"].FindObject("POINT 1").Coordinates
        extra["csys_origin"] = r3(o)
        ok = ok and abs(o.X - 90) < 1e-6
    if "A4 axis = intersection of two planes" in keep:
        extra["A4_origin"] = r3(keep["A4 axis = intersection of two planes"].DatumAxis.Origin)
        ok = ok and abs(extra["A4_origin"][2] - 25) < 1e-6
    if not err:
        extra["K1_axis"] = [round(x, 5) for x in nxh.face_data(cf)[2]]
        ok = ok and (par(extra["K1_axis"], (0, -s60, c60)) or par(extra["K1_axis"], (0, s60, c60)))
    check("edit expressions: datums follow", ok and not nxh.feature_errors(part), errors=nxh.feature_errors(part),
          d1=after["D1 offset from datum plane"]["origin"], d2b=after["D2b offset 0 from face x=blk_l"]["origin"],
          d3=after["D3 angle to XY about X axis"]["normal"], d5=after["D5 bisector (Center) of two faces"]["origin"], **extra)
    res["features"] = [(f["ts"], f["type"], f["name"]) for f in nxh.feature_table(part)]
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res["result"] = "PASS" if res["checks"] and all(c["ok"] for c in res["checks"].values()) and "error" not in res else "FAIL"
nxh.write_json(os.path.join(OUT, "datum_recipes.json"), res)
