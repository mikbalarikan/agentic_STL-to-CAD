"""Involute spur gear driven by law curves, and Boolean expressions that switch optional features (NX 2206).

    run_journal.ps1 -Script law_curve_gear.py -WorkDir <out> -JArgs <out>   ->  <out>\\law_curve_gear.json

G1  Named expressions (m, z, alpha, b) -> three Law Curves by equation over t (involute flank, tip arc, radial
    line to the base circle) -> Datum Plane at (90/z) + inv(alpha) degrees about Z -> Mirror Curve -> Extrude
    of the closed tooth profile -> Pattern Geometry of the tooth BODY (count z) -> ONE Unite on the root
    cylinder. Checked: tooth thickness at the pitch circle = pi*m/2 (pitch points on the flanks), tip radius,
    z teeth by section, volume against the numerically integrated involute profile.
G2  Regeneration at a second tooth count and module (z 17 -> 24, m 3 -> 2) with the same checks, and back.
G3  Boolean expressions with if / else driving Suppression Status of a Chamfer and an Edge Blend: 4 states.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities as GU  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "law_curve_gear.log"))
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
M0, Z0, ALPHA, B, BORE, DED = 3.0, 17, 20.0, 10.0, 12.0, 1.25


def law_curve(part, fx, fy, fz, name, tol=0.0001):
    """Law Curve by equation: fx / fy / fz are NAMES of expressions written in terms of the parameter
    expression `t` (which NX runs from 0 to 1). FeatureType SPLINE_LAW. Returns (feature, spline)."""
    b = part.Features.CreateLawCurveBuilder(NXOpen.Features.LawCurve.Null)
    try:
        for law, fn in ((b.XLaw, fx), (b.YLaw, fy), (b.ZLaw, fz)):
            law.LawType = GU.LawBuilder.Type.ByEquation
            law.Parameter = "t"
            law.Function = fn
        b.DistanceTolerance = tol
        f = b.CommitFeature()
    finally:
        b.Destroy()
    f.SetName(name)
    return f, [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)][0]


def mirror_curves(part, features, seed, help_point, datum_plane):
    """Mirror Curve feature of whole curve features about a datum plane (smart plane: follows the datum)."""
    b = part.Features.CreateMirrorCurveBuilder(nxh.NULL_FEATURE)
    try:
        nxh.fill_section(part, b.Curve, rules=[part.ScRuleFactory.CreateRuleCurveFeature(list(features))], seed=seed, help_point=help_point)
        b.PlaneOption = NXOpen.Features.MirrorCurveBuilder.PlaneOptions.NewPlane
        b.NewPlane = nxf.plane_from_datum(part, datum_plane)
        return b.Commit()
    finally:
        b.Destroy()


def suppress_by(part, feature, formula):
    """Suppress by Expression: gives the feature its 'Suppression Status' expression (1 = active, 0 = suppressed)
    and links it to `formula` - a number, a Boolean expression (TRUE = active) or an if / else expression."""
    b = part.Expressions.CreateSuppressByExpressionBuilder()
    try:
        b.SuppressAction = NXOpen.SuppressByExpressionBuilder.ExpressionAction.CreateEach
        b.FeatureList.Add(feature)
        b.Commit()
    finally:
        b.Destroy()
    e = NXOpen.TaggedObjectManager.GetTaggedObject(nxh.UFS.ModlGeneral.AskSuppressExpTag(feature.Tag))
    e.RightHandSide = formula
    return e


# ------------------------------------------------------------------ analytic involute gear
def inv(phi):
    return math.tan(phi) - phi


def gear_numbers(m, z, alpha_deg=ALPHA, ded=DED):
    a = math.radians(alpha_deg)
    d = z * m
    g = {"d": d, "ra": d / 2 + m, "rf": d / 2 - ded * m, "rb": d / 2 * math.cos(a), "inv": inv(a),
         "half": math.pi / (2 * z) + inv(a)}                       # half tooth angle measured at the base circle [rad]
    g["u_max"] = math.sqrt((g["ra"] / g["rb"]) ** 2 - 1.0)         # roll angle at the tip circle [rad]

    def theta(r):                                                  # polar angle of the flank at radius r
        return 0.0 if r <= g["rb"] else inv(math.acos(g["rb"] / r))

    n = 20000
    h = (g["ra"] - g["rf"]) / n
    acc = 0.0
    for i in range(n + 1):                                         # Simpson: area of one tooth outside the root circle
        r = g["rf"] + i * h
        acc += (1 if i in (0, n) else (4 if i % 2 else 2)) * 2.0 * (g["half"] - theta(r)) * r
    g["tooth_area"] = acc * h / 3.0
    g["area"] = math.pi * g["rf"] ** 2 + z * g["tooth_area"]
    g["theta_tip"] = theta(g["ra"])
    return g


def lumps_on_cylinder(part, body, radius, z0, z1, wall=0.1):
    """Number of separate pieces of material on the cylinder r = radius (thin tube intersected with a copy)."""
    m = nxh.mark("probe", False)
    try:
        _f, tube = nxh.cylinder(part, (0, 0, z0), (0, 0, 1), 2 * (radius + wall / 2), z1 - z0)
        nxh.cylinder(part, (0, 0, z0), (0, 0, 1), 2 * (radius - wall / 2), z1 - z0, op=nxh.BOOL.Subtract, target=tube)
        return len(nxh.intersect(part, tube, [body], check=False, keep_tool=True).GetBodies())
    finally:
        nxh.undo_to(m)


def measure(part, body, m, z, tag, bore=True):
    g = gear_numbers(m, z)
    zc = B / 2.0
    pitch_r = (g["d"] / 2 * math.cos(g["inv"]), g["d"] / 2 * math.sin(g["inv"]), zc)                    # right flank at the pitch circle
    a2 = 2 * g["half"] - g["inv"]
    pitch_l = (g["d"] / 2 * math.cos(a2), g["d"] / 2 * math.sin(a2), zc)                                # left flank
    tip = (g["ra"] * math.cos(g["half"]), g["ra"] * math.sin(g["half"]), zc)
    base = (g["rb"], 0.0, zc) if g["rb"] > g["rf"] else None
    vol = nxh.volume(part, body)
    expect = (g["area"] - (math.pi * BORE ** 2 / 4.0 if bore else 0.0)) * B
    r_max = 0.0
    for e in body.GetEdges():
        for i in range(5):
            p = nxh.UFS.ModlGeneral.AskCurveProps(e.Tag, i / 4.0)[0]
            r_max = max(r_max, math.hypot(p[0], p[1]))
    out = {"solids": len(nxh.solids(part)), "errors": nxh.feature_errors(part), "volume": vol, "expected_volume": expect,
           "pitch_right": abs(nxh.dist_to(part, body, pitch_r)), "pitch_left": abs(nxh.dist_to(part, body, pitch_l)),
           "tip": abs(nxh.dist_to(part, body, tip)), "base": abs(nxh.dist_to(part, body, base)) if base else None,
           "r_max": r_max, "teeth": lumps_on_cylinder(part, body, g["d"] / 2.0, 1.0, B - 1.0),
           "chordal_thickness_designed": 2 * g["d"] / 2 * math.sin(math.pi / (2 * z)), "arc_thickness_designed": math.pi * m / 2.0,
           "examine": nxh.examine_geometry(part, body)}
    res["notes"][tag] = out
    chk.true(tag + " one solid, no feature errors", out["solids"] == 1 and not out["errors"], out["errors"])
    chk.true(tag + " Examine Geometry clean", all(v == 0 for v in out["examine"].values()), out["examine"])
    chk(tag + " right flank passes through the pitch point at angle inv(alpha)", out["pitch_right"], 0.0, 5e-4)
    chk(tag + " left flank passes through the mirrored pitch point (arc tooth thickness = pi*m/2)", out["pitch_left"], 0.0, 5e-4)
    chk(tag + " tip circle point on the tooth crest", out["tip"], 0.0, 5e-4)
    if base:
        chk(tag + " flank starts on the base circle", out["base"], 0.0, 5e-4)
    chk(tag + " tip radius = d/2 + m", out["r_max"], g["ra"], 5e-4)
    chk.true(tag + " %d teeth on the pitch cylinder" % z, out["teeth"] == z, out["teeth"])
    chk(tag + " volume = numerically integrated involute profile x b (relative)", vol / expect, 1.0, 1e-4)
    return out


def run():
    part = nxh.new_part(os.path.join(OUT, "law_curve_gear.prt"))
    dat = nxh.Datums(part)
    # master parameters; the angle is kept as a plain number in degrees so that the maths stays unitless
    for name, val, unit, note in (
            ("m", M0, "mm", "module"), ("z", Z0, None, "number of teeth"), ("alpha", ALPHA, None, "pressure angle in degrees"),
            ("b", B, "mm", "face width"), ("bore_d", BORE, "mm", ""), ("t", 1, None, "law parameter, NX runs it 0..1"),
            ("d", "z*m", "mm", "pitch diameter"), ("da", "d+2*m", "mm", "tip diameter"), ("df", "d-2*%s*m" % DED, "mm", "root diameter"),
            ("db", "d*cos(alpha)", "mm", "base diameter"), ("rb", "db/2", "mm", ""),
            ("inv_alpha", "tan(alpha)-alpha*pi()/180", None, "involute function of alpha [rad]"),
            ("u_max", "sqrt((da/db)^2-1)", None, "roll angle at the tip circle [rad]"), ("u", "t*u_max", None, ""),
            ("xt", "rb*(cos(u*180/pi())+u*sin(u*180/pi()))", "mm", "flank X"), ("yt", "rb*(sin(u*180/pi())-u*cos(u*180/pi()))", "mm", "flank Y"),
            ("zt", "0", "mm", ""),
            ("mirror_angle", "90/z+inv_alpha*180/pi()", "deg", "half tooth angle at the base circle"),
            ("x_tip", "rb*(cos(u_max*180/pi())+u_max*sin(u_max*180/pi()))", "mm", "flank end on the tip circle"),
            ("y_tip", "rb*(sin(u_max*180/pi())-u_max*cos(u_max*180/pi()))", "mm", ""),
            ("tip_a0", "arctan(y_tip/x_tip)", "deg", "polar angle of the flank at the tip circle"),
            ("tip_a", "tip_a0+t*(2*mirror_angle-2*tip_a0)", "deg", "runs along the tip arc"),
            ("xt_tip", "da/2*cos(tip_a)", "mm", "tip arc X"), ("yt_tip", "da/2*sin(tip_a)", "mm", "tip arc Y"),
            ("xt_base", "t*rb", "mm", "radial line from the centre to the base circle"), ("yt_base", "0", "mm", "")):
        nxh.expr(part, name, val, unit, note)
    g = gear_numbers(M0, Z0)
    ev = {n: part.Expressions.FindObject(n).Value for n in ("d", "da", "df", "db", "inv_alpha", "u_max", "mirror_angle", "tip_a0")}
    res["notes"]["expressions"] = ev
    chk("G1 expression inv_alpha = tan(a) - a", ev["inv_alpha"], g["inv"], 1e-9)
    chk("G1 expression mirror_angle = 90/z + inv(alpha) in degrees", ev["mirror_angle"], math.degrees(g["half"]), 1e-7)
    chk("G1 expression tip_a0 = polar angle of the involute at the tip circle", ev["tip_a0"], math.degrees(g["theta_tip"]), 1e-7)

    _f, body = nxh.cylinder(part, (0, 0, 0), (0, 0, 1), "df", "b")          # root cylinder: the root arc needs no curve

    flank_f, flank = law_curve(part, "xt", "yt", "zt", "TOOTH_FLANK")
    tip_f, tip = law_curve(part, "xt_tip", "yt_tip", "zt", "TOOTH_TIP")
    base_f, base = law_curve(part, "xt_base", "yt_base", "zt", "TOOTH_RADIAL")
    props = nxh.UFS.ModlGeneral.AskCurveProps
    worst = 0.0
    for i in range(11):                                            # the spline against the exact involute
        u = g["u_max"] * i / 10.0
        want = (g["rb"] * (math.cos(u) + u * math.sin(u)), g["rb"] * (math.sin(u) - u * math.cos(u)))
        p = props(flank.Tag, i / 10.0)[0]
        worst = max(worst, math.hypot(p[0] - want[0], p[1] - want[1]))
    res["notes"]["law_curves"] = {"types": [flank_f.FeatureType, tip_f.FeatureType, base_f.FeatureType], "flank_max_error": worst,
                                  "flank_class": type(flank).__name__, "lengths": [flank.GetLength(), tip.GetLength(), base.GetLength()]}
    chk("G1 law curve = exact involute at 11 parameter values (max error)", worst, 0.0, 2e-4)
    chk("G1 radial law curve length = rb", base.GetLength(), g["rb"], 1e-6)
    chk("G1 tip arc length = ra x (2 x half angle - 2 x tip angle)", tip.GetLength(), g["ra"] * 2 * (g["half"] - g["theta_tip"]), 1e-4)

    # mirror plane through Z at mirror_angle from the XZ plane (sign found by measurement)
    fpl, pl = nxf.datum_plane(part, "angle", [dat.xz, dat.z], "mirror_angle", name="PL_TOOTH_MID")
    cm, sm = math.cos(g["half"]), math.sin(g["half"])
    if abs(pl.Normal.X * cm + pl.Normal.Y * sm) > 1e-9:
        fpl.GetExpressions()[0].RightHandSide = "-mirror_angle"
        nxh.update()
    res["notes"]["mirror_plane_formula"] = fpl.GetExpressions()[0].RightHandSide
    chk("G1 mirror plane contains the tooth centre line (cos M, sin M, 0)", abs(pl.Normal.X * cm + pl.Normal.Y * sm), 0.0, 1e-9)
    mir_f = mirror_curves(part, [flank_f, base_f], flank, (g["rb"], 0, 0), pl)
    res["notes"]["mirror_feature"] = mir_f.FeatureType

    sec = nxh.section(part, rules=[part.ScRuleFactory.CreateRuleCurveFeature([flank_f, tip_f, base_f, mir_f])], seed=flank,
                      help_point=(g["rb"], 0, 0))
    tooth_f = nxh.extrude(part, sec, (0, 0, 1), 0, "b")
    tooth = tooth_f.GetBodies()[0]
    area_tooth = g["tooth_area"] + g["half"] * g["rf"] ** 2          # tooth outside the root circle + its wedge inside
    chk.true("G1 tooth profile is closed (Extrude gives a solid)", tooth.IsSolidBody)
    chk("G1 one tooth body volume (relative)", nxh.volume(part, tooth) / (area_tooth * B), 1.0, 1e-4)
    pf, copies = nxf.pattern_geometry(part, [tooth], circular=dict(origin=(0, 0, 0), vec=(0, 0, 1), count="z"))
    chk.true("G1 Pattern Geometry: z - 1 copies of the tooth body", len(copies) == Z0 - 1, len(copies))
    nxh.unite(part, body, tool_features=[tooth_f, pf])
    # the bore comes AFTER the Unite: every tooth body reaches the centre (its profile starts at the origin)
    nxh.cylinder(part, (0, 0, 0), (0, 0, 1), "bore_d", "b", op=nxh.BOOL.Subtract, target=body)
    res["notes"]["census"] = nxh.face_census(body)
    measure(part, body, M0, Z0, "G1 z=17 m=3:")
    v_nom = nxh.volume(part, body)

    # G2 regeneration
    nxh.set_expr(part, "z", 24)
    nxh.set_expr(part, "m", 2)
    nxh.update()
    measure(part, body, 2.0, 24, "G2 z=24 m=2:")
    nxh.set_expr(part, "z", Z0)
    nxh.set_expr(part, "m", M0)
    nxh.update()
    chk("G2 back to z=17 m=3: volume reproduced (relative)", nxh.volume(part, body) / v_nom, 1.0, 1e-6)
    chk.true("G2 back to nominal: no feature errors", not nxh.feature_errors(part), nxh.feature_errors(part))

    # G3 Boolean switches
    part.Expressions.CreateExpression("Boolean", "use_chamfer=true")
    part.Expressions.CreateExpression("Boolean", "use_fillet=false")
    part.Expressions.CreateExpression("Boolean", "chamfer_decider=if (use_chamfer == true && use_fillet == true) (false) else (use_chamfer)")
    r = BORE / 2.0

    def bore_edge(zv):
        return nxh.one([e for e in body.GetEdges() if abs(nxh.bbox(e)[2] - zv) < 1e-6 and abs(nxh.bbox(e)[5] - zv) < 1e-6
                        and abs(nxh.bbox(e)[3] - r) < 1e-4 and abs(nxh.bbox(e)[0] + r) < 1e-4], "bore edge at z=%g" % zv)

    ch_f = nxf.chamfer(part, [bore_edge(B)], 1.0)
    bl_f = nxh.blend(part, [bore_edge(0.0)], 1.0)
    v_both = nxh.volume(part, body)
    dv_ch = math.pi * (r * 1.0 ** 2 + 1.0 ** 3 / 3.0)                # chamfer 1 x 45 deg on a bore edge
    e_ch = suppress_by(part, ch_f, "chamfer_decider")
    e_bl = suppress_by(part, bl_f, "use_fillet")
    res["notes"]["suppression_expressions"] = [(e.Name, e.RightHandSide, str(getattr(e, "Type", "?")), e.GetDescriptor()) for e in (e_ch, e_bl)]
    table = {}
    for uc, uf in ((True, False), (True, True), (False, True), (False, False)):
        part.Expressions.FindObject("use_chamfer").RightHandSide = "true" if uc else "false"
        part.Expressions.FindObject("use_fillet").RightHandSide = "true" if uf else "false"
        nxh.update()
        table["chamfer=%s fillet=%s" % (uc, uf)] = {"chamfer_suppressed": bool(ch_f.Suppressed), "blend_suppressed": bool(bl_f.Suppressed),
                                                    "volume": nxh.volume(part, body), "errors": nxh.feature_errors(part)}
        want_ch = uc and not uf                                       # the decider: the fillet wins
        chk.true("G3 use_chamfer=%s use_fillet=%s: chamfer %s, blend %s" % (uc, uf, "active" if want_ch else "suppressed", "active" if uf else "suppressed"),
                 (not ch_f.Suppressed) == want_ch and (not bl_f.Suppressed) == uf, table["chamfer=%s fillet=%s" % (uc, uf)])
    res["notes"]["suppression_table"] = table
    v_none = table["chamfer=False fillet=False"]["volume"]
    chk("G3 both off: the plain gear volume is back (relative)", v_none / v_nom, 1.0, 1e-6)
    chk("G3 chamfer only: volume = plain - chamfer ring", v_none - table["chamfer=True fillet=False"]["volume"], dv_ch, 1e-3)
    res["features"] = [(f["name"], f["type"], f["suppressed"]) for f in nxh.feature_table(part)]
    part.Expressions.FindObject("use_chamfer").RightHandSide = "true"
    nxh.update()
    stp = nxf.step_export(part, os.path.join(OUT, "law_curve_gear.step"))
    rt = nxf.step_roundtrip_check(stp, OUT, "law_curve_gear", restore=part, part=part)
    res["notes"]["roundtrip"] = {k: rt.get(k) for k in ("solids", "volume", "match", "healthy", "max_rel")}
    chk.true("STEP round trip: one solid, same volume", rt.get("match") and rt.get("healthy") and rt.get("solids") == 1, res["notes"]["roundtrip"])


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-500:])
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "law_curve_gear.json"), res)
