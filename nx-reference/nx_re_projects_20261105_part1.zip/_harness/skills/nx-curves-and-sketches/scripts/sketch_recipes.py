"""Verified sketch recipes for NX 2206 (headless run_journal).

  run.ps1 -Script sketch_recipes.py -WorkDir <out> -JArgs <out>

Builds one part and checks, by measurement:
  S1  sketch on a datum-CSYS plane, fully constrained (DOF 0), expression-driven dimensions
  R*  section rules on that sketch: RegionBoundary (one region of several loops), CurveFeature
      (whole sketch), CurveFeatureChain, CurveFeatureTangent, CurveDumb
  S2  sketch on a planar FACE of the body, edge projected into the sketch (recipe curve), hole
      dimensioned from the projected edge -> follows the body when the plate width changes
  S3  sketch fillet (Sketch.Fillet) with a driving radius dimension
  S4  in-sketch offset curve (SketchOffsetBuilder)
  S6  spline in a sketch (non-associative spline added with AddGeometry; it does NOT follow the points)
Writes sketch_recipes.json with "result": "PASS" | "FAIL".
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import nxh  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
# Continuous Auto Dimensioning off BEFORE any sketch is created: with it on (the batch default) GetStatus() reads
# WellConstrained / 0 for any sketch, so the DOF checks below would prove nothing (nx-journal-core section 5).
nxh.S.Preferences.Sketch.ContinuousAutoDimensioning = False
P, V, UPD, S, UFS = nxh.P, nxh.V, nxh.UPD, nxh.S, nxh.UFS
SK = NXOpen.Sketch
A = SK.AssocType
CP = SK.ConstraintPointType
log = nxh.Log(os.path.join(OUT, "sketch_recipes.log"))
res = {"checks": {}}


def check(name, ok, **data):
    res["checks"][name] = dict(ok=bool(ok), **data)
    log(("PASS " if ok else "FAIL ") + name, data)
    return ok


# ------------------------------------------------------------------ sketch helpers
def new_sketch(part, plane, haxis, origin, name):
    """Sketch on a DatumPlane or planar Face. haxis: DatumAxis / linear Edge used as horizontal reference.

    origin: an NXOpen.Point (e.g. Datums.origin or part.Points.CreatePoint(P(..)))."""
    sb = part.Sketches.CreateSimpleSketchInPlaceBuilder()
    try:
        sb.UseWorkPartOrigin = False
        d = part.Directions.CreateDirection(haxis, NXOpen.Sense.Forward, UPD)
        xf = part.Xforms.CreateXformByPlaneXDirPoint(plane, d, origin, UPD, 0.625, False, False)
        sb.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
        sb.HorizontalReference.Value = haxis
        sk = sb.Commit()
    finally:
        sb.Destroy()
    sk.Activate(SK.ViewReorient.FalseValue)
    sk.SetName(name)
    sk.Feature.SetName(name)
    return sk


def cg(geom, pt=None, idx=0):
    g = SK.ConstraintGeometry()
    g.Geometry = geom
    g.PointType = pt if pt is not None else CP.NotSet
    g.SplineDefiningPointIndex = idx
    return g


def help_at(p):
    h = SK.ConstraintGeometryHelp()
    h.Type = SK.ConstraintGeometryHelpType.Point
    h.Point = p
    h.Parameter = 0.0
    return h


def dg(geom, assoc=None, hp=None):
    d = SK.DimensionGeometry()
    d.Geometry = geom
    d.AssocType = assoc if assoc is not None else A.NotSet
    d.AssocValue = 0
    d.HelpPoint = hp if hp is not None else P(0, 0, 0)
    d.View = NXOpen.NXObject.Null
    return d


def add(sk, *curves, infer=True):
    opt = SK.InferConstraintsOption.InferCoincidentConstraints if infer else SK.InferConstraintsOption.InferNoConstraints
    for c in curves:
        sk.AddGeometry(c, opt)


def pdim(sk, ref, ref_help, geom, assoc, origin, formula):
    """Perpendicular distance from a line-like reference (datum axis, line, projected edge) to a point of geom."""
    c = sk.CreateDimension(SK.ConstraintType.PerpendicularDim, dg(ref, None, ref_help), dg(geom, assoc), origin,
                           NXOpen.Expression.Null)
    c.AssociatedExpression.RightHandSide = formula
    return c


def diameter(sk, arc, on_arc, origin, formula):
    c = sk.CreateDiameterDimension(dg(arc, None, on_arc), origin, NXOpen.Expression.Null)
    c.AssociatedExpression.RightHandSide = formula
    return c


def radius(sk, arc, on_arc, origin, formula):
    c = sk.CreateRadialDimension(dg(arc, None, on_arc), origin, NXOpen.Expression.Null)
    c.AssociatedExpression.RightHandSide = formula
    return c


def finish(sk):
    """Solve, read (status, dof), leave the sketch. Returns dict."""
    sk.Update()
    try:
        sk.CalculateStatus()
    except Exception:  # noqa: BLE001
        pass
    status, dof = status_of(sk)
    sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
    cons = {}
    for t in nxh.enum_names(SK.ConstraintType):
        for cls in ("Geometric", "Dimension"):
            try:
                n = len(sk.GetAllConstraintsOfType(getattr(SK.ConstraintClass, cls), getattr(SK.ConstraintType, t)))
            except Exception:  # noqa: BLE001
                n = 0
            if n:
                cons[t] = cons.get(t, 0) + n
    return {"status": status, "dof": dof, "n_geom": len(sk.GetAllGeometry()), "constraints": cons,
            "dims": [f"{e.Name}={e.RightHandSide}" for e in sk.GetAllExpressions()]}


def status_of(sk):
    """(status name, dof). GetStatus() returns an int-like enum: str() gives '3', so map it by comparison."""
    st, dof = sk.GetStatus()
    name = [n for n in nxh.enum_names(SK.Status) if getattr(SK.Status, n) == st]
    return (name[0] if name else str(st)), dof


# ------------------------------------------------------------------ section helpers
def new_section(part):
    sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
    sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    sec.AllowSelfIntersection(False)
    return sec


def add_rules(sec, rules, help_point, seed=None):
    sec.AddToSection(rules, seed if seed is not None else NXOpen.NXObject.Null, NXOpen.NXObject.Null,
                     NXOpen.NXObject.Null, P(*help_point), NXOpen.Section.Mode.Create, False)
    return sec


def sec_region(part, sk, seed_point, curves=None):
    """ONE closed region of a sketch (the area around seed_point bounded by the nearest curves)."""
    curves = curves if curves is not None else [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Curve)]
    rule = part.ScRuleFactory.CreateRuleRegionBoundary(sk, curves, P(*seed_point), 0.01)
    return add_rules(new_section(part), [rule], seed_point)


def sec_feature(part, feats, help_point=(0, 0, 0)):
    """Every curve of the given curve features (sketch features, associative lines ...)."""
    rule = part.ScRuleFactory.CreateRuleCurveFeature(list(feats))
    return add_rules(new_section(part), [rule], help_point)


def sec_feature_chain(part, feat, seed_curve, help_point):
    """The connected chain through seed_curve inside one curve feature."""
    rule = part.ScRuleFactory.CreateRuleCurveFeatureChain([feat], seed_curve, NXOpen.Curve.Null, True, 0.0095)
    return add_rules(new_section(part), [rule], help_point, seed_curve)


def sec_feature_tangent(part, feat, seed_curve, help_point):
    """The tangent-continuous chain through seed_curve inside one curve feature."""
    rule = part.ScRuleFactory.CreateRuleCurveFeatureTangent([feat], seed_curve, NXOpen.Curve.Null, True, 0.5, 0.0095)
    return add_rules(new_section(part), [rule], help_point, seed_curve)


def sec_dumb(part, curves, help_point):
    rule = part.ScRuleFactory.CreateRuleCurveDumb(list(curves))
    return add_rules(new_section(part), [rule], help_point)


def n_curves(sec):
    try:
        return len(sec.GetOutputCurves())
    except Exception as e:  # noqa: BLE001
        return "?" + str(e)


# ------------------------------------------------------------------ curve measurement
_CURVE_PROPS = [getattr(getattr(UFS, m), "AskCurveProps") for m in dir(UFS)
                if not m.startswith("_") and hasattr(getattr(UFS, m), "AskCurveProps")][0]

def ends(curve):
    """((start xyz, unit tangent), (end xyz, unit tangent)) of any curve or edge."""
    out = []
    for t in (0.0, 1.0):
        r = _CURVE_PROPS(curve.Tag, t)
        out.append((list(r[0]), list(r[1])))
    return out


def near(a, b, tol=1e-3):
    return all(abs(x - y) < tol for x, y in zip(a, b))


def loop_closed(curves, tol=1e-3):
    """True when every end point of the curve set is shared by exactly two curve ends."""
    pts = [e[0] for c in curves for e in ends(c)]
    return all(sum(1 for q in pts if near(p, q, tol)) == 2 for p in pts)


def run():
    part = nxh.new_part(os.path.join(OUT, "sketch_recipes.prt"))
    dat = nxh.Datums(part)
    for n, f, c in (("plate_w", "60", "plate width X"), ("plate_h", "40", "plate depth Y"), ("plate_t", "10", "thickness"),
                    ("bore_d", "20", "centre bore"), ("edge_off", "8", "hole centre from +X edge"),
                    ("pin_d", "5", "edge hole"), ("fil_r", "6", "sketch fillet"), ("wall", "3", "offset wall"),
                    ("pat_pitch", "12", "pattern pitch")):
        nxh.expr(part, n, f, "mm", c)
    hx, hy = P(50, 0, 0), P(0, 50, 0)

    # ---------------- S1: rectangle + concentric circle on the XY datum plane, fully constrained
    w, h, d = 60.0, 40.0, 20.0
    sk1 = new_sketch(part, dat.xy, dat.x, dat.origin, "SKT_PLATE")
    Q = lambda x, y: P(x, y, 0)  # noqa: E731
    e1 = part.Curves.CreateLine(Q(-w / 2, -h / 2), Q(w / 2, -h / 2))
    e2 = part.Curves.CreateLine(Q(w / 2, -h / 2), Q(w / 2, h / 2))
    e3 = part.Curves.CreateLine(Q(w / 2, h / 2), Q(-w / 2, h / 2))
    e4 = part.Curves.CreateLine(Q(-w / 2, h / 2), Q(-w / 2, -h / 2))
    circ = part.Curves.CreateArc(Q(0, 0), V(1, 0, 0), V(0, 1, 0), d / 2, 0.0, 2 * math.pi)
    add(sk1, e1, e2, e3, e4)
    add(sk1, circ, infer=False)
    for ln in (e1, e3):
        sk1.CreateHorizontalConstraint(cg(ln))
    for ln in (e2, e4):
        sk1.CreateVerticalConstraint(cg(ln))
    sk1.CreateCoincidentConstraint(cg(circ, CP.ArcCenter), cg(dat.origin))
    pdim(sk1, dat.y, hy, e2, A.StartPoint, Q(w / 4, -h / 2 - 8), "plate_w/2")
    pdim(sk1, dat.y, hy, e4, A.StartPoint, Q(-w / 4, -h / 2 - 8), "plate_w/2")
    pdim(sk1, dat.x, hx, e1, A.StartPoint, Q(w / 2 + 8, -h / 4), "plate_h/2")
    pdim(sk1, dat.x, hx, e3, A.StartPoint, Q(w / 2 + 8, h / 4), "plate_h/2")
    diameter(sk1, circ, Q(d / 2, 0), Q(d, d), "bore_d")
    s1 = finish(sk1)
    res["S1"] = s1
    check("S1 sketch on datum plane fully constrained", s1["status"] == "WellConstrained" and s1["dof"] == 0, **s1)
    res["tree_after_S1"] = [(f["type"], f["name"]) for f in nxh.feature_table(part)]
    res["S1_internal"] = sk1.IsInternal
    check("S1 outer loop closed", loop_closed([e1, e2, e3, e4]))
    check("S1 circle is one closed curve", near(ends(circ)[0][0], ends(circ)[1][0]), length=circ.GetLength(),
          expect=math.pi * d)

    # ---------------- section rules on S1
    a_plate, a_bore = w * h, math.pi * d * d / 4

    def trial(label, make_sec, expect, tol=0.5):
        m = nxh.mark("trial " + label, False)
        try:
            sec = make_sec()
            n = n_curves(sec)
            f = nxh.extrude(part, sec, (0, 0, 1), 0, "plate_t")
            bodies = f.GetBodies()
            vol = nxh.volume(part, bodies[0]) if bodies and bodies[0].IsSolidBody else 0.0
            ok = abs(vol - expect) < tol
            check(label, ok, volume=round(vol, 3), expect=round(expect, 3), section_curves=n,
                  solid=bool(bodies and bodies[0].IsSolidBody))
        except Exception as e:  # noqa: BLE001
            check(label, False, error=str(e))
        nxh.undo_to(m)

    trial("R1 RegionBoundary: region between rectangle and circle", lambda: sec_region(part, sk1, (25, 15, 0)),
          (a_plate - a_bore) * 10)
    trial("R2 RegionBoundary: only the circle region", lambda: sec_region(part, sk1, (2, 3, 0)), a_bore * 10)
    trial("R3 CurveFeature: whole sketch (inner loop = hole)", lambda: sec_feature(part, [sk1.Feature]),
          (a_plate - a_bore) * 10)
    trial("R4 CurveFeatureChain: outer rectangle only (seed = one line)",
          lambda: sec_feature_chain(part, sk1.Feature, e1, (0, -h / 2, 0)), a_plate * 10)
    trial("R5 CurveFeatureTangent: seed circle -> circle only",
          lambda: sec_feature_tangent(part, sk1.Feature, circ, (d / 2, 0, 0)), a_bore * 10)
    trial("R6 CurveDumb: explicit four lines", lambda: sec_dumb(part, [e1, e2, e3, e4], (0, -h / 2, 0)), a_plate * 10)

    # the real plate: user's habit = RegionBoundary of the sketch region
    plate = nxh.extrude(part, sec_region(part, sk1, (25, 15, 0)), (0, 0, 1), 0, "plate_t")
    plate.SetName("PLATE")
    body = plate.GetBodies()[0]
    check("plate volume", abs(nxh.volume(part, body) - (a_plate - a_bore) * 10) < 0.5, volume=nxh.volume(part, body))

    # ---------------- S2: sketch on the top FACE, project an edge, dimension a hole from it
    top = nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1))[0]
    edge_px = [e for e in top.GetEdges() if abs(nxh.bbox(e)[0] - w / 2) < 1e-3 and abs(nxh.bbox(e)[3] - w / 2) < 1e-3][0]
    sk2 = new_sketch(part, top, dat.x, dat.origin, "SKT_EDGE_HOLE")
    res["S2_origin"] = [sk2.Origin.X, sk2.Origin.Y, sk2.Origin.Z]
    pb = part.Sketches.CreateProjectBuilder(nxh.NULL_FEATURE)
    try:
        pb.Tolerance = 0.01
        psec = pb.Section
        psec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
        psec.AddToSection([part.ScRuleFactory.CreateRuleEdgeDumb([edge_px])], edge_px, NXOpen.NXObject.Null,
                          NXOpen.NXObject.Null, P(w / 2, 0, 10), NXOpen.Section.Mode.Create, False)
        pb.Commit()
    finally:
        pb.Destroy()
    proj = [g for g in sk2.GetAllGeometry() if isinstance(g, NXOpen.Line)]
    res["S2_projected"] = [type(g).__name__ for g in sk2.GetAllGeometry()]
    pl = proj[0]
    xh = w / 2 - 8.0
    hole = part.Curves.CreateArc(P(xh, 0, 10), V(1, 0, 0), V(0, 1, 0), 2.5, 0.0, 2 * math.pi)
    add(sk2, hole, infer=False)
    sk2.CreatePointOnCurveConstraint(cg(hole, CP.ArcCenter), cg(dat.x), help_at(P(xh, 0, 10)))
    pdim(sk2, pl, P(w / 2, 5, 10), hole, A.ArcCenter, P(xh, 12, 10), "edge_off")
    diameter(sk2, hole, P(xh + 2.5, 0, 10), P(xh, -12, 10), "pin_d")
    s2 = finish(sk2)
    res["S2"] = s2
    check("S2 sketch on body face fully constrained", s2["status"] == "WellConstrained" and s2["dof"] == 0, **s2)
    cut = nxh.extrude(part, sec_dumb(part, [hole], (xh + 2.5, 0, 10)), (0, 0, -1), 0, "plate_t", nxh.BOOL.Subtract, body)
    cut.SetName("EDGE_HOLE")
    v_exp = (a_plate - a_bore - math.pi * 2.5 ** 2) * 10
    check("S2 hole cut", abs(nxh.volume(part, body) - v_exp) < 0.5 and len(nxh.solids(part)) == 1,
          volume=nxh.volume(part, body), expect=v_exp)

    def pin_x():
        f = nxh.faces(body, ftype=nxh.CYLINDER, radius=2.5)
        return round(nxh.face_data(f[0])[1][0], 4) if f else None

    check("S2 hole position", abs(pin_x() - xh) < 1e-3, x=pin_x(), expect=xh)
    res["tree_after_S2"] = [(f["type"], f["name"]) for f in nxh.feature_table(part)]

    # parametric proof: widen the plate -> the face sketch follows the projected edge
    nxh.set_expr(part, "plate_w", "80")
    nxh.update()
    v_exp2 = (80 * h - a_bore - math.pi * 2.5 ** 2) * 10
    check("edit plate_w=80: volume and hole follow", abs(nxh.volume(part, body) - v_exp2) < 0.5 and abs(pin_x() - 32.0) < 1e-3
          and not nxh.feature_errors(part), volume=nxh.volume(part, body), expect=v_exp2, x=pin_x(),
          errors=nxh.feature_errors(part), s1=status_of(sk1), s2=status_of(sk2))
    nxh.set_expr(part, "plate_w", "60")
    nxh.update()

    # ---------------- S3: L profile with a sketch fillet (on XZ plane, separate body)
    def s3():
        sk = new_sketch(part, dat.xz, dat.x, dat.origin, "SKT_L_FILLET")
        Z = lambda x, z: P(x, 0, z)  # noqa: E731
        x0, z0 = 100.0, 0.0
        pts = [(x0, z0), (x0 + 30, z0), (x0 + 30, z0 + 8), (x0 + 8, z0 + 8), (x0 + 8, z0 + 25), (x0, z0 + 25)]
        ls = [part.Curves.CreateLine(Z(*pts[i]), Z(*pts[(i + 1) % 6])) for i in range(6)]
        add(sk, *ls)
        for i in (0, 2, 4):
            sk.CreateHorizontalConstraint(cg(ls[i]))
        for i in (1, 3, 5):
            sk.CreateVerticalConstraint(cg(ls[i]))
        hz = P(0, 0, 50)
        pdim(sk, dat.z, hz, ls[5], A.StartPoint, Z(x0 / 2, -6), "100")
        pdim(sk, dat.z, hz, ls[1], A.StartPoint, Z(x0 / 2, -12), "130")
        pdim(sk, dat.z, hz, ls[3], A.StartPoint, Z(x0 / 2, 14), "108")
        pdim(sk, dat.x, hx, ls[0], A.StartPoint, Z(x0 - 8, 0), "0")
        pdim(sk, dat.x, hx, ls[2], A.StartPoint, Z(x0 + 36, 4), "8")
        pdim(sk, dat.x, hx, ls[4], A.StartPoint, Z(x0 - 8, 12), "25")
        pre = list(status_of(sk))
        r = sk.Fillet(ls[2], ls[3], Z(x0 + 14, z0 + 8), Z(x0 + 8, z0 + 14), 6.0, SK.TrimInputOption.TrueValue,
                      SK.CreateDimensionOption.TrueValue, SK.AlternateSolutionOption.FalseValue)
        res["S3_fillet_return"] = str(r)[:300]
        arcs = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Arc)]
        for e in sk.GetAllExpressions():
            if abs(e.Value - 6.0) < 1e-9 and e.RightHandSide.strip() in ("6", "6.0"):
                e.RightHandSide = "fil_r"
        st = finish(sk)
        st["before_fillet"] = pre
        curves = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Curve)]
        f = nxh.extrude(part, sec_feature(part, [sk.Feature]), (0, 1, 0), 0, 5)
        b = f.GetBodies()[0]
        area = 30 * 8 + 8 * 17 + (6 * 6 - math.pi * 36 / 4)
        v = nxh.volume(part, b)
        check("S3 sketch fillet", st["dof"] == 0 and len(arcs) == 1 and abs(v - area * 5) < 0.2 and loop_closed(curves),
              volume=v, expect=area * 5, arc_radius=arcs[0].Radius if arcs else None, **st)
        nxh.set_expr(part, "fil_r", "4")
        nxh.update()
        area2 = 30 * 8 + 8 * 17 + (16 - math.pi * 16 / 4)
        v2 = nxh.volume(part, b)
        check("S3 fillet radius edit 6->4", abs(v2 - area2 * 5) < 0.2, volume=v2, expect=area2 * 5)
        return st

    r, err = nxh.attempt("S3 fillet", s3, log=log)
    if err:
        check("S3 sketch fillet", False, error=err)

    # ---------------- S4: in-sketch offset of a rectangle
    def s4():
        sk = new_sketch(part, dat.xy, dat.x, dat.origin, "SKT_OFFSET")
        x0, y0 = 0.0, 60.0
        pts = [(x0, y0), (x0 + 30, y0), (x0 + 30, y0 + 20), (x0, y0 + 20)]
        ls = [part.Curves.CreateLine(Q(*pts[i]), Q(*pts[(i + 1) % 4])) for i in range(4)]
        add(sk, *ls)
        for i in (0, 2):
            sk.CreateHorizontalConstraint(cg(ls[i]))
        for i in (1, 3):
            sk.CreateVerticalConstraint(cg(ls[i]))
        pdim(sk, dat.y, hy, ls[3], A.StartPoint, Q(-8, y0), "0")
        pdim(sk, dat.y, hy, ls[1], A.StartPoint, Q(38, y0), "30")
        pdim(sk, dat.x, hx, ls[0], A.StartPoint, Q(15, y0 - 6), "60")
        pdim(sk, dat.x, hx, ls[2], A.StartPoint, Q(15, y0 + 26), "80")
        ob = part.Sketches.CreateSketchOffsetBuilder(NXOpen.SketchOffset.Null)
        try:
            osec = ob.CreateSection()              # the builder owns its sections: populate, never assign
            osec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
            osec.AddToSection([part.ScRuleFactory.CreateRuleCurveDumb(ls)], ls[0], NXOpen.NXObject.Null,
                              NXOpen.NXObject.Null, P(15, y0, 0), NXOpen.Section.Mode.Create, False)
            ob.UpdateLoopsAndCopies()
            ob.Distance.RightHandSide = "wall"
            ob.CreateDimension = True
            ob.EvaluateOffset()
            ob.Commit()
        finally:
            ob.Destroy()
        st = finish(sk)
        f = nxh.extrude(part, sec_feature(part, [sk.Feature]), (0, 0, 1), 0, 2)
        b = f.GetBodies()[0]
        v = nxh.volume(part, b)
        outer_in = (30 * 20 - 24 * 14) * 2      # offset went inward
        outer_out = (36 * 26 - 30 * 20) * 2     # offset went outward
        check("S4 sketch offset curve", st["dof"] == 0 and (abs(v - outer_in) < 0.2 or abs(v - outer_out) < 0.2),
              volume=v, inward=outer_in, outward=outer_out, **st)
        return st

    r, err = nxh.attempt("S4 offset", s4, log=log)
    if err:
        check("S4 sketch offset curve", False, error=err)

    # ---------------- S6: studio spline inside a sketch, through sketch points that carry the dimensions
    def s6():
        sk = new_sketch(part, dat.yz, dat.y, dat.origin, "SKT_SPLINE")
        Y = lambda y, z: P(0, y, z)  # noqa: E731
        raw = [(100.0, 0.0), (110.0, 8.0), (125.0, 10.0), (140.0, 4.0)]
        hyy, hzz = P(0, 50, 0), P(0, 0, 50)
        pts = []
        for i, (y, z) in enumerate(raw):          # sketch points carry the dimensions
            pt = part.Points.CreatePoint(Y(y, z))
            add(sk, pt, infer=False)
            pdim(sk, dat.z, hzz, pt, A.StartPoint, Y(y, -6.0 - 3 * i), str(y))     # a Point needs AssocType.StartPoint
            pdim(sk, dat.y, hyy, pt, A.StartPoint, Y(y + 4, z + 4), str(z))
            pts.append(pt)
        sk.Update()
        st_pts = list(status_of(sk))
        sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        b = part.Features.CreateStudioSplineBuilderEx(NXOpen.NXObject.Null)     # non-associative spline made OUTSIDE the sketch
        try:
            b.Type = NXOpen.Features.StudioSplineBuilderEx.Types.ThroughPoints
            b.Degree = 3
            b.IsAssociative = False
            b.MatchKnotsType = NXOpen.Features.StudioSplineBuilderEx.MatchKnotsTypes.NotSet
            for y, z in raw:
                gcd = b.ConstraintManager.CreateGeometricConstraintData()
                gcd.Point = part.Points.CreatePoint(Y(y, z))
                b.ConstraintManager.Append(gcd)
            sp = b.Commit()
            crv = b.Curve
        finally:
            b.Destroy()
        sk.Activate(SK.ViewReorient.FalseValue)
        add(sk, crv, infer=False)
        spl = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Spline)]
        sk.Update()
        st0 = list(status_of(sk))
        notes = []
        if st0[1] != 0 and spl:
            for i, pt in enumerate(pts):
                try:
                    sk.CreateCoincidentConstraint(cg(spl[0], CP.SplineDefiningPoint, i + 1), cg(pt))
                except Exception as e:  # noqa: BLE001
                    notes.append(f"pt{i}: {e}")
        st = finish(sk)
        st["dof_points_only"] = st_pts
        st["dof_after_spline"] = st0
        st["notes"] = notes
        L = spl[0].GetLength() if spl else None
        en = ends(spl[0]) if spl else None
        # does the spline follow its points? edit the first point's dimension and look at the spline start
        first = st["dims"][0].split("=")[0]
        nxh.set_expr(part, first, "105")
        nxh.update()
        st["start_after_point_moved_to_105"] = ends(spl[0])[0][0]
        st["spline_follows_points"] = near(st["start_after_point_moved_to_105"], (0, 105, 0))
        nxh.set_expr(part, first, "100")
        nxh.update()
        check("S6 sketch spline through points", bool(spl) and st["dof"] == 0 and near(en[0][0], (0, 100, 0))
              and near(en[1][0], (0, 140, 4)),
              length=L, ends=[en[0][0], en[1][0]] if en else None, **st)
        return st

    r, err = nxh.attempt("S6 spline", s6, log=log)
    if err:
        check("S6 sketch spline through points", False, error=err)

    res["errors"] = nxh.feature_errors(part)
    res["features"] = [(f["ts"], f["type"], f["name"]) for f in nxh.feature_table(part)]
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res["result"] = "PASS" if res["checks"] and all(c["ok"] for c in res["checks"].values()) and "error" not in res else "FAIL"
nxh.write_json(os.path.join(OUT, "sketch_recipes.json"), res)
