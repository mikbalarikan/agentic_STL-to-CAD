"""Sketch and datum rules from Siemens' NX CAST 8.5 teaching, measured on NX 2206 (headless).

  run_journal.ps1 -Script sketch_rules.py -WorkDir <out> -JArgs <out>

  K1  internal / external sketch: how to tell, how to switch, what a second feature does
  K2  Offset Datum CSYS (translate + rotate by expressions) as ONE positioning feature; a chained child CSYS;
      a boss at a compound angle built on it
  K3  a sketch that references an edge does not follow a LATER feature that moves that edge - order it after
  K4  Make Symmetric (two existing curves) against Mirror Curve (new geometry): curve count and DOF countdown
  K5  a notch driven by a perpendicular (line-to-point) dimension survives the value 0; a line-length dimension does not
  K6  one sketch for one functional element: outline + reference offset loop + hole points -> Extrude by region
      and Hole on the sketch points; the whole-sketch section trap
  K7  Sketch On Path with a fully constrained section (driving dimensions, Continuous Auto Dimensioning off),
      position along the path by an expression, swept along the path
Every sketch is created with Continuous Auto Dimensioning OFF (nxf.new_sketch / nxf.auto_dimensioning_off)
and every DOF quoted is the real count (nxf.sketch_status).
[cast eska / eskb / efmb / eesc] = the CAST sketching and feature-modelling courses (rules in own words).
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])))
import curvekit as ck  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
ONLY = list(sys.argv[2:])
P, V, UPD = nxh.P, nxh.V, nxh.UPD
NF, NULL = nxh.NULL_FEATURE, NXOpen.NXObject.Null
GU, F = NXOpen.GeometricUtilities, NXOpen.Features
SK, A, CP = NXOpen.Sketch, NXOpen.Sketch.AssocType, NXOpen.Sketch.ConstraintPointType
log = nxh.Log(os.path.join(OUT, "sketch_rules.log"))
chk = nxh.Check()
res = {"measured": {}, "not_working": {}, "api": {}}
M = res["measured"]
R = None


def block(name, fn, part):
    if ONLY and name not in ONLY:
        return
    m = nxh.mark("block " + name, False)
    try:
        fn(part)
        log("done", name)
    except Exception:  # noqa: BLE001
        err = traceback.format_exc()
        log("FAILED", name, err)
        chk.true(name + " ran to the end", False, err[-900:])
        try:
            s = nxh.S.ActiveSketch
            if s is not None:
                s.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        except Exception:  # noqa: BLE001
            pass
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass


def rnd(v, n=4):
    return [round(x, n) for x in v]


def dof(sk):
    """(status, real DOF) of the ACTIVE sketch after a solve."""
    sk.Update()
    return nxf.sketch_status(sk)


def census(sk):
    """{constraint type: count} of the geometric constraints of a sketch."""
    out = {}
    for t in nxh.enum_names(SK.ConstraintType):
        if t in ("NoCon", "LastConType") or t.startswith("Reserved") or t.endswith("Dim"):
            continue
        try:
            n = len(sk.GetAllConstraintsOfType(SK.ConstraintClass.Geometric, getattr(SK.ConstraintType, t)))
        except Exception:  # noqa: BLE001
            n = 0
        if n:
            out[t] = n
    return out


def ends2(c):
    return sorted([rnd(ck.frame(c, 0)["point"][:2], 3), rnd(ck.frame(c, 1)["point"][:2], 3)])


def tree(part):
    return [f.GetFeatureName() for f in nxh.top_features(part)[0]]


def reopen(sk):
    sk.Activate(SK.ViewReorient.FalseValue)
    st = dof(sk)
    sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
    return st


# ------------------------------------------------------------------ K1
def k1(part):
    dat = nxh.Datums(part)
    nxh.expr(part, "k1_d", 40)
    nxh.expr(part, "k1_bore", 16)
    sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "K1_PROFILE")
    outer = nxf.sketch_circle(part, sk, dat.origin, "k1_d")
    bore = nxf.sketch_circle(part, sk, dat.origin, "k1_bore")
    st = nxf.finish_sketch(sk)
    ext = nxh.extrude(part, nxh.section(part, rules=[R.CreateRuleCurveDumb([outer])], seed=outer, help_point=(20, 0, 0)), (0, 0, 1), 0, 10)
    body = ext.GetBodies()[0]

    def state():
        return {"Sketch.IsInternal": bool(sk.IsInternal), "sketch feature IsInternal": bool(nxh.is_internal(sk.Feature)),
                "in_top_level_tree": any("K1_PROFILE" in n or "Sketch" in n for n in tree(part)),
                "children_of_sketch": [c.GetFeatureName() for c in sk.Feature.GetChildren()]}
    rows = {"sketch": {k: st[k] for k in ("status", "dof", "auto_dims")}, "as created (external)": state()}
    _r, err = nxh.attempt("internal", lambda: nxf.sketch_internal(ext, True), log=log)
    rows["after MakeSketchInternal on the Extrude"] = dict(state(), error=err)
    cut, err = nxh.attempt("second feature", lambda: nxf.extrude_ex(part, nxh.section(part, rules=[R.CreateRuleCurveDumb([bore])], seed=bore, help_point=(8, 0, 0)),
                                                                   (0, 0, 1), through_all=True, op=nxh.BOOL.Subtract, target=body), log=log)
    rows["second feature built on the INTERNAL sketch"] = dict(state(), error=err, volume=round(nxh.volume(part, body), 3))
    _r, err = nxh.attempt("external", lambda: nxf.sketch_internal(ext, False), log=log)
    rows["after MakeSketchExternal on the owner"] = dict(state(), error=err, tree=tree(part))
    _r, err = nxh.attempt("internal again", lambda: nxf.sketch_internal(ext, True), log=log)
    rows["MakeSketchInternal while two features use the sketch"] = dict(state(), error=err)
    nxh.set_expr(part, "k1_bore", 20)
    nxh.update()
    rows["bore 16 -> 20"] = {"volume": round(nxh.volume(part, body), 3), "errors": nxh.feature_errors(part)}
    M["K1 internal / external sketch"] = rows
    a, b_, c, d, e = (rows[k] for k in ("as created (external)", "after MakeSketchInternal on the Extrude", "second feature built on the INTERNAL sketch",
                                         "after MakeSketchExternal on the owner", "MakeSketchInternal while two features use the sketch"))
    chk.true("K1 a sketch from nxf.new_sketch is EXTERNAL: Sketch.IsInternal False, its own row in the tree",
             not a["Sketch.IsInternal"] and a["in_top_level_tree"] and rows["sketch"]["dof"] == 0 and rows["sketch"]["auto_dims"] == 0, a)
    chk.true("K1 feature.MakeSketchInternal(): Sketch.IsInternal True and the row leaves the top level (it now lives inside the Extrude)",
             b_["error"] is None and b_["Sketch.IsInternal"] and not b_["in_top_level_tree"], b_)
    chk.true("K1 a second feature CAN be built on the internal sketch headless (no error, right volume) - the sketch stays hidden in the first feature with two children",
             c["error"] is None and c["Sketch.IsInternal"] and len(c["children_of_sketch"]) == 2 and abs(c["volume"] - math.pi * (400 - 64) * 10) < 1e-2, c)
    chk.true("K1 MakeSketchExternal() on the owner puts the sketch back in the tree BEFORE both features", d["error"] is None and not d["Sketch.IsInternal"] and d["in_top_level_tree"], d)
    chk.true("K1 making a sketch internal while two features use it is refused ('Parent sketch is referenced by other objects.')",
             e["error"] is not None and not e["Sketch.IsInternal"], e)
    chk("K1 the shared external sketch drives both features (bore 16 -> 20)", rows["bore 16 -> 20"]["volume"] if not rows["bore 16 -> 20"]["errors"] else None,
        math.pi * (400 - 100) * 10, 1e-2)


# ------------------------------------------------------------------ K2
def rot(seq, ax, ay, az):
    """Rotation matrices (rows = images of X, Y, Z) for intrinsic and extrinsic XYZ, to find out which one NX uses."""
    def rx(a):
        c, s = math.cos(a), math.sin(a)
        return [[1, 0, 0], [0, c, -s], [0, s, c]]

    def ry(a):
        c, s = math.cos(a), math.sin(a)
        return [[c, 0, s], [0, 1, 0], [-s, 0, c]]

    def rz(a):
        c, s = math.cos(a), math.sin(a)
        return [[c, -s, 0], [s, c, 0], [0, 0, 1]]

    def mul(a, b):
        return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    mats = {"x": rx(ax), "y": ry(ay), "z": rz(az)}
    m = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    for ch in seq:
        m = mul(m, mats[ch])
    return [[m[0][j], m[1][j], m[2][j]] for j in range(3)]         # columns = axes of the rotated frame


def csys_of(feature):
    return [e for e in feature.GetEntities() if isinstance(e, NXOpen.CartesianCoordinateSystem)][0]


def frame_of(cs):
    o, m = cs.Origin, cs.Orientation.Element
    return [o.X, o.Y, o.Z], [[m.Xx, m.Xy, m.Xz], [m.Yx, m.Yy, m.Yz], [m.Zx, m.Zy, m.Zz]]


def offset_csys(part, base_csys, origin, rx, ry, rz, name=None, sequence="XYZ"):
    """Datum CSYS offset from another CSYS: origin = a smart point, rotations = expression names or numbers
    (degrees) about X, then Y, then Z. ONE feature (DATUM_CSYS) that follows the base CSYS and the expressions."""
    def ang(v):
        e = part.Expressions.CreateSystemExpressionWithUnits(str(v), nxh.units(part)["deg"])
        return part.Scalars.CreateScalarExpression(e, NXOpen.Scalar.DimensionalityType.Angle, UPD)
    xf = part.Xforms.CreateXformEulerTaitBryanAngles(base_csys, origin, getattr(NXOpen.XformCollection.RotationSequence, sequence),
                                                     ang(rx), ang(ry), ang(rz), 1.0, UPD)
    b = part.Features.CreateDatumCsysBuilder(NF)
    try:
        b.Csys = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
        b.DisplayScaleFactor = 1.25
        f = b.CommitFeature()
    finally:
        b.Destroy()
    if name:
        f.SetName(name)
    return f


def k2(part):
    dat = nxh.Datums(part)
    base = csys_of(dat.csys)
    nxh.expr(part, "k2_x", 150)
    nxh.expr(part, "k2_ry", 45, unit="deg")
    nxh.expr(part, "k2_rz", -35, unit="deg")
    n0 = len(list(part.Features.GetFeatures()))
    f = offset_csys(part, base, nxh.point(part, "k2_x", 60, 10), 0, "k2_ry", "k2_rz", name="CS_PORT")
    new = [x.FeatureType for x in list(part.Features.GetFeatures())[n0:]]

    def read(feat):
        o, m = frame_of(csys_of(feat))
        return {"origin": rnd(o), "x": rnd(m[0], 5), "y": rnd(m[1], 5), "z": rnd(m[2], 5)}

    def which(got, ry_, rz_):
        out = {}
        for label, seq in (("intrinsic X-Y-Z (each rotation about the NEW axis)", "xyz"), ("extrinsic X-Y-Z (each about the BASE axis)", "zyx")):
            want = rot(seq, 0.0, math.radians(ry_), math.radians(rz_))
            out[label] = round(max(abs(got[k][i] - want[j][i]) for j, k in enumerate(("x", "y", "z")) for i in range(3)), 6)
        return out
    r0 = read(f)
    rows = {"new features": new, "created (x 150, Ry 45, Rz -35)": r0, "which convention": which(r0, 45, -35)}
    nxh.set_expr(part, "k2_x", 180)
    nxh.set_expr(part, "k2_ry", 30)
    nxh.update()
    r1 = read(f)
    rows["after k2_x 180, k2_ry 30"] = dict(r1, convention=which(r1, 30, -35), errors=nxh.feature_errors(part))
    conv = min(rows["which convention"], key=rows["which convention"].get)
    chk.true("K2 Offset Datum CSYS = ONE feature (DATUM_CSYS) from Xforms.CreateXformEulerTaitBryanAngles; origin at the smart point (150, 60, 10)",
             new == ["DATUM_CSYS"] and r0["origin"] == [150.0, 60.0, 10.0], rows)
    chk.true("K2 rotation convention measured: %s (deviation < 1e-5)" % conv, rows["which convention"][conv] < 1e-5, rows["which convention"])
    chk.true("K2 it follows its expressions: origin x 150 -> 180, Ry 45 -> 30, same convention, no feature error",
             r1["origin"] == [180.0, 60.0, 10.0] and rows["after k2_x 180, k2_ry 30"]["convention"][conv] < 1e-5 and not rows["after k2_x 180, k2_ry 30"]["errors"], rows["after k2_x 180, k2_ry 30"])

    # child CSYS offset from CS_PORT: 20 along its Z, turned 90 about its Z
    child, err = nxh.attempt("child", lambda: offset_csys(part, csys_of(f), part.Points.CreatePoint(csys_of(f), ck.scalar(part, 0), ck.scalar(part, 0), ck.scalar(part, 20), UPD),
                                                           0, 0, 90, name="CS_PORT_FACE"), log=log)
    if err:
        rows["child CSYS"] = {"error": err[:300]}
        res["not_working"]["K2 child CSYS with Points.CreatePoint(csys, sx, sy, sz)"] = err[:300]
    else:
        rc = read(child)
        want_o = [r1["origin"][i] + 20 * r1["z"][i] for i in range(3)]
        rows["child CSYS (0, 0, 20) in CS_PORT, Rz 90"] = dict(rc, expected_origin=rnd(want_o))
        chk.true("K2 a child CSYS given in the PARENT's coordinates (Points.CreatePoint(csys, x, y, z)): origin = parent origin + 20 x parent Z, its X = parent Y",
                 max(abs(rc["origin"][i] - want_o[i]) for i in range(3)) < 1e-4 and max(abs(rc["x"][i] - r1["y"][i]) for i in range(3)) < 1e-5, rows["child CSYS (0, 0, 20) in CS_PORT, Rz 90"])
        nxh.set_expr(part, "k2_rz", -50)
        nxh.update()
        rp, rc2 = read(f), read(child)
        want_o = [rp["origin"][i] + 20 * rp["z"][i] for i in range(3)]
        rows["child after the PARENT turned (Rz -35 -> -50)"] = dict(rc2, expected_origin=rnd(want_o), errors=nxh.feature_errors(part))
        chk.true("K2 ... and the child follows the parent CSYS", max(abs(rc2["origin"][i] - want_o[i]) for i in range(3)) < 1e-4 and not nxh.feature_errors(part),
                 rows["child after the PARENT turned (Rz -35 -> -50)"])

    # a boss at the compound angle: sketch on the XY plane of CS_PORT, extruded along its Z
    pre = f.JournalIdentifier
    pxy, ax = part.Datums.FindObject(pre + " XY plane"), part.Datums.FindObject(pre + " X axis")
    org = f.FindObject("POINT 1")
    sk = nxf.new_sketch(part, pxy, ax, org, "K2_BOSS")
    circ = nxf.sketch_circle(part, sk, org, 12)
    st = nxf.finish_sketch(sk)
    b = part.Features.CreateExtrudeBuilder(NF)
    try:
        b.Section = nxh.section(part, rules=[R.CreateRuleCurveDumb([circ])], seed=circ, help_point=ck.frame(circ, 0.1)["point"])
        b.Direction = part.Directions.CreateDirection(pxy, NXOpen.Sense.Forward, UPD)
        b.Limits.StartExtend.Value.RightHandSide = "0"
        b.Limits.EndExtend.Value.RightHandSide = "15"
        b.BooleanOperation.Type = nxh.BOOL.Create
        boss = b.CommitFeature()
    finally:
        b.Destroy()

    def boss_state():
        body = boss.GetBodies()[0]
        cyl = nxh.one(nxh.faces(body, ftype=nxh.CYLINDER), "boss")
        axis = list(nxh.face_data(cyl)[2])
        z = read(f)["z"]
        return {"axis": rnd(axis, 5), "csys_z": z, "parallel": abs(abs(ck.dot(axis, z)) - 1.0) < 1e-4, "volume": round(nxh.volume(part, body), 4)}
    b0 = boss_state()
    nxh.set_expr(part, "k2_ry", 60)
    nxh.update()
    b1 = boss_state()
    rows["boss on CS_PORT"] = {"sketch": {k: st[k] for k in ("status", "dof", "auto_dims")}, "created": b0, "after k2_ry 60": b1, "errors": nxh.feature_errors(part)}
    M["K2 offset datum CSYS"] = rows
    chk.true("K2 a boss sketched on the offset CSYS (DOF 0) stands along its Z axis and turns with it (Ry 30 -> 60), volume pi*36*15 both times",
             st["dof"] == 0 and b0["parallel"] and b1["parallel"] and b0["axis"] != b1["axis"] and abs(b0["volume"] - math.pi * 36 * 15) < 1e-3
             and abs(b1["volume"] - math.pi * 36 * 15) < 1e-3 and not rows["boss on CS_PORT"]["errors"], rows["boss on CS_PORT"])


# ------------------------------------------------------------------ K3
def k3(part):
    dat = nxh.Datums(part)
    x0, y0 = 300.0, 0.0
    fb, body = nxh.block(part, (x0, y0, 0), (60, 40, 10))
    top = nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1)), "top")
    right = nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(1, 0, 0)), "right")
    edge = [e for e in top.GetEdges() if abs(nxh.bbox(e)[0] - (x0 + 60)) < 1e-6 and abs(nxh.bbox(e)[3] - (x0 + 60)) < 1e-6][0]
    nxh.expr(part, "k3_off", 8)
    sk = nxf.new_sketch(part, top, dat.x, nxh.point(part, x0, y0, 10), "K3_HOLE")
    pb = part.Sketches.CreateProjectBuilder(NF)
    try:
        pb.Tolerance = 0.01
        sec = pb.Section
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
        sec.AddToSection([R.CreateRuleEdgeDumb([edge])], edge, NULL, NULL, P(x0 + 60, y0 + 20, 10), NXOpen.Section.Mode.Create, False)
        pb.Commit()
    finally:
        pb.Destroy()
    proj = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Line)][0]
    circ = part.Curves.CreateArc(P(x0 + 52, y0 + 20, 10), V(1, 0, 0), V(0, 1, 0), 3.0, 0.0, 2 * math.pi)
    nxf.add(sk, circ, infer=False)
    d1 = dof(sk)
    nxf.pdim(sk, proj, P(x0 + 60, y0 + 20, 10), circ, A.ArcCenter, P(x0 + 56, y0 + 26, 10), "k3_off")
    nxf.pdim(sk, dat.x, P(x0 + 10, 0, 0), circ, A.ArcCenter, P(x0 + 40, y0 + 10, 10), "20")
    nxf.diameter_dim(sk, circ, P(x0 + 55, y0 + 20, 10), P(x0 + 45, y0 + 30, 10), "6")
    st = nxf.finish_sketch(sk)
    hole = nxh.extrude(part, nxh.section(part, rules=[R.CreateRuleCurveDumb([circ])], seed=circ, help_point=(x0 + 55, y0 + 20, 10)), (0, 0, -1), 0, 10,
                       op=nxh.BOOL.Subtract, target=body)

    def hole_x():
        cyl = nxh.one(nxh.faces(body, ftype=nxh.CYLINDER), "hole")
        right_x = max(nxh.bbox(body)[3], nxh.bbox(body)[0])
        cx = list(nxh.face_data(cyl)[1])[0]
        return {"hole_x": round(cx - x0, 4), "right_face_x": round(right_x - x0, 4), "edge_distance": round(right_x - cx, 4)}
    rows = {"sketch": {"dof_before_dims": d1[1], "status": st["status"], "dof": st["dof"], "auto_dims": st["auto_dims"]}, "as built": hole_x()}
    off = nxf.offset_region(part, [right], 5)                      # a LATER feature moves the referenced face: x 60 -> 65
    rows["after a LATER Offset Region +5 on the referenced face"] = dict(hole_x(), tree=[n for n in tree(part)][-6:], errors=nxh.feature_errors(part),
                                                                         sketch_warnings=list(sk.Feature.GetFeatureWarningMessages() or []))
    errs, err = nxh.attempt("reorder", lambda: nxh.reorder(part, [off], fb, after=True), log=log)
    rows["after reordering the Offset Region BEFORE the sketch"] = dict(hole_x(), reorder_error=err, errors=errs if errs is not None else nxh.feature_errors(part),
                                                                        tree=[n for n in tree(part)][-6:], sketch=reopen(sk),
                                                                        sketch_warnings=list(sk.Feature.GetFeatureWarningMessages() or []))
    del hole
    M["K3 sketch referencing an edge that a later feature moves"] = rows
    a, b_, c = rows["as built"], rows["after a LATER Offset Region +5 on the referenced face"], rows["after reordering the Offset Region BEFORE the sketch"]
    chk.true("K3 as built: sketch DOF 0 (3 before the dimensions), hole 8 from the edge", rows["sketch"]["dof"] == 0 and rows["sketch"]["dof_before_dims"] == 3
             and abs(a["edge_distance"] - 8) < 1e-6, (rows["sketch"], a))
    chk.true("K3 a feature AFTER the sketch moves the face 60 -> 65: the hole stays at 52, now 13 from the edge - no error, no warning",
             abs(b_["right_face_x"] - 65) < 1e-6 and abs(b_["hole_x"] - 52) < 1e-6 and not b_["errors"] and not b_["sketch_warnings"], b_)
    chk.true("K3 with that feature ordered BEFORE the sketch the hole follows: 57, again 8 from the edge, sketch still DOF 0",
             c["reorder_error"] is None and abs(c["hole_x"] - 57) < 1e-6 and abs(c["edge_distance"] - 8) < 1e-6 and not c["errors"] and c["sketch"][1] == 0, c)


# ------------------------------------------------------------------ K4
def k4(part):
    dat = nxh.Datums(part)
    y = -100.0
    sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "K4_SYMMETRY")
    rows = {}

    def symmetric(primary, secondary):
        b = part.Sketches.CreateMakeSymmetricBuilder()
        try:
            b.PrimaryObject.Value = primary
            b.SecondaryObject.Value = secondary
            b.CenterLine.Value = dat.y
            b.Commit()
        finally:
            b.Destroy()

    # pair A: two free lines; pair B: the same with the roles swapped; pair C: one line dimensioned first
    out = {}
    for label, yy, swap, fix in (("A primary = right line", y, False, False), ("B primary = left line", y + 40, True, False),
                                 ("C right line FIXED first, then primary = left line", y + 80, True, True),
                                 ("D right line FIXED first, then primary = right line", y + 120, False, True)):
        r_ = part.Curves.CreateLine(P(10, yy, 0), P(20, yy + 20, 0))
        l_ = part.Curves.CreateLine(P(-13, yy + 2, 0), P(-22, yy + 17, 0))
        nxf.add(sk, r_, l_, infer=False)
        d0 = dof(sk)[1]
        if fix:                                                        # Fixed on the LINE takes 2 of its 4 freedoms; fix its two end points
            sk.CreateFixedConstraint(nxf.cg(r_, CP.StartVertex))
            sk.CreateFixedConstraint(nxf.cg(r_, CP.EndVertex))
        d1 = dof(sk)[1]
        n0 = len(sk.GetAllGeometry())
        symmetric(l_ if swap else r_, r_ if swap else l_)
        d2 = dof(sk)[1]
        out[label] = {"dof": [d0, d1, d2], "new_curves": len(sk.GetAllGeometry()) - n0, "right_line": ends2(r_), "left_line": ends2(l_),
                      "right_moved": ends2(r_) != [[10.0, yy], [20.0, yy + 20]], "left_moved": ends2(l_) != [[-22.0, yy + 17], [-13.0, yy + 2]]}
        base = d2
    rows["Make Symmetric about the datum Y axis"] = out
    rows["constraints after Make Symmetric x4"] = census(sk)
    l3 = part.Curves.CreateLine(P(30, y + 170, 0), P(45, y + 180, 0))
    nxf.add(sk, l3, infer=False)
    d_l3 = dof(sk)[1]

    def mirror(src, constraint):
        mb = part.Sketches.CreateSketchMirrorPatternBuilder(NXOpen.SketchPattern.Null)
        try:
            mb.Section.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
            mid = ck.frame(src, 0.5)["point"]
            mb.Section.AddToSection([R.CreateRuleCurveDumb([src])], src, NULL, NULL, P(*mid), NXOpen.Section.Mode.Create, False)
            mb.UpdateInputSection()
            mb.DirectionObject.Value = dat.y
            mb.UpdateDirectionObject()
            mb.CreateConstraint = constraint
            mb.Commit()
        finally:
            mb.Destroy()
    n0 = len(sk.GetAllGeometry())
    c0 = census(sk)
    mirror(l3, True)
    rows["Mirror Curve of a free line (CreateConstraint True)"] = {"dof_before": d_l3, "dof": dof(sk)[1], "new_curves": len(sk.GetAllGeometry()) - n0,
                                                                   "new_constraints": {k: v - c0.get(k, 0) for k, v in census(sk).items() if v != c0.get(k, 0)}}
    l4 = part.Curves.CreateLine(P(30, y + 200, 0), P(45, y + 210, 0))
    nxf.add(sk, l4, infer=False)
    d_l4 = dof(sk)[1]
    n0 = len(sk.GetAllGeometry())
    c0 = census(sk)
    _r, err = nxh.attempt("mirror free", lambda: mirror(l4, False), log=log)
    rows["Mirror Curve of a free line (CreateConstraint False)"] = {"error": err, "dof_before": d_l4, "dof": dof(sk)[1], "new_curves": len(sk.GetAllGeometry()) - n0,
                                                                    "new_constraints": {k: v - c0.get(k, 0) for k, v in census(sk).items() if v != c0.get(k, 0)}}
    st = nxf.finish_sketch(sk)
    rows["final status (a measurement sketch: nothing is dimensioned)"] = {k: st[k] for k in ("status", "dof", "auto_dims")}
    M["K4 Make Symmetric vs Mirror Curve"] = rows
    a, b_, c = out["A primary = right line"], out["B primary = left line"], out["C right line FIXED first, then primary = left line"]
    chk.true("K4 Make Symmetric works on EXISTING curves: no new curve, 4 degrees of freedom less per pair (8 -> 4), one Mirror-type constraint each",
             a["new_curves"] == 0 and a["dof"][2] == a["dof"][1] - 4 and b_["dof"][2] == b_["dof"][1] - 4 and rows["constraints after Make Symmetric x4"].get("Mirror") == 4, (a, b_))
    chk.true("K4 WHICH line moves is not set by Primary / Secondary (recorded for both role orders): constrain the one that must stay first",
             (a["right_moved"] != a["left_moved"]) and (b_["right_moved"] != b_["left_moved"]), (a, b_))
    dd = out["D right line FIXED first, then primary = right line"]
    chk.true("K4 with the right line's end points fixed first (DOF -4) the LEFT line moves onto its mirror image, in either role",
             not c["right_moved"] and c["left_line"] == [[-20.0, y + 100], [-10.0, y + 80]] and not dd["right_moved"] and dd["left_line"] == [[-20.0, y + 140], [-10.0, y + 120]]
             and c["dof"][1] == c["dof"][0] - 4, (c, dd))
    d = rows["Mirror Curve of a free line (CreateConstraint True)"]
    chk.true("K4 Mirror Curve makes NEW geometry: one curve more, and the constrained copy adds NO freedom", d["new_curves"] == 1 and d["dof"] == d["dof_before"], d)
    e = rows["Mirror Curve of a free line (CreateConstraint False)"]
    chk.true("K4 Mirror Curve stores a Pattern-type constraint; CreateConstraint False made no difference here (copy still tied, DOF %s -> %s)" % (e["dof_before"], e["dof"]),
             e["error"] is None and e["new_curves"] == 1 and d["new_constraints"] == {"Pattern": 1}, (d, e))
    chk.true("K4 the real DOF is reported (UnderConstrained, auto_dims 0) - this sketch was created with Continuous Auto Dimensioning off",
             st["status"] == "UnderConstrained" and st["auto_dims"] == 0 and st["dof"] > 0, st)
    del base


# ------------------------------------------------------------------ K5
def k5(part):
    dat = nxh.Datums(part)
    rows = {}
    for tag, y0 in (("perpendicular dimension line -> point", -300.0), ("length dimension of the riser line", -400.0)):
        name = "k5a_d" if tag.startswith("perp") else "k5b_d"
        nxh.expr(part, name, 5)
        sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "K5_" + name.upper())
        pts = [(0, y0), (40, y0), (40, y0 + 20), (20, y0 + 20), (20, y0 + 15), (0, y0 + 15)]
        ls = nxf.hv_polygon(part, sk, pts)                                         # bottom, right, top-right, riser, top-left, left
        d0 = dof(sk)[1]
        sk.CreatePointOnCurveConstraint(nxf.cg(ls[5], CP.StartVertex), nxf.cg(dat.y), nxf.help_at(P(0, y0 + 10, 0)))
        nxf.pdim(sk, dat.y, P(0, y0 + 30, 0), ls[1], A.StartPoint, P(20, y0 - 6, 0), "40")
        nxf.pdim(sk, dat.y, P(0, y0 + 30, 0), ls[3], A.StartPoint, P(10, y0 + 24, 0), "20")
        nxf.pdim(sk, dat.x, P(50, 0, 0), ls[0], A.StartPoint, P(-8, y0 / 2, 0), str(abs(y0)))
        nxf.pdim(sk, ls[0], P(20, y0, 0), ls[2], A.StartPoint, P(46, y0 + 10, 0), "20")
        d1 = dof(sk)[1]
        if tag.startswith("perp"):
            nxf.pdim(sk, ls[2], P(30, y0 + 20, 0), ls[4], A.StartPoint, P(14, y0 + 18, 0), name)
        else:
            c = sk.CreateDimension(SK.ConstraintType.ParallelDim, nxf.dg(ls[3], A.StartPoint), nxf.dg(ls[3], A.EndPoint), P(26, y0 + 17, 0), NXOpen.Expression.Null)
            c.AssociatedExpression.RightHandSide = name
        st = nxf.finish_sketch(sk)
        ext = nxh.extrude(part, nxh.section_region(part, sk, (10, y0 + 5, 0)), (0, 0, 1), 0, 10)
        body = ext.GetBodies()[0]
        r = {"dof_countdown": [d0, d1, st["dof"]], "status": st["status"], "auto_dims": st["auto_dims"], "values": {}}
        for v in (5, 0, 9, 5):
            nxh.set_expr(part, name, v)
            nxh.update()
            errs = nxh.feature_errors(part)
            vol = None
            try:
                vol = round(nxh.volume(part, ext.GetBodies()[0] if ext.GetBodies() else body), 3)
            except Exception as ex:  # noqa: BLE001
                vol = "no body: " + str(ex)[:60]
            r["values"]["%s -> expected %s" % (v, (800 - 20 * v) * 10)] = {"volume": vol, "errors": errs, "sketch": reopen(sk)}
        rows[tag] = r
    M["K5 a dimension that may be 0"] = rows
    a, b_ = rows["perpendicular dimension line -> point"], rows["length dimension of the riser line"]
    chk.true("K5 DOF countdown of the notch profile: 6 (H/V polygon) -> 1 (positions) -> 0 (the notch dimension)", a["dof_countdown"] == [6, 1, 0] and a["auto_dims"] == 0, a["dof_countdown"])
    ok = all(abs(v["volume"] - (800 - 20 * d) * 10) < 1e-3 and not v["errors"] for d, v in zip((5, 0, 9, 5), a["values"].values()) if isinstance(v["volume"], float))
    chk.true("K5 notch driven by a PERPENDICULAR dimension (line to point): 5 -> 0 -> 9 -> 5, the Extrude follows every value, no feature error",
             ok and all(isinstance(v["volume"], float) for v in a["values"].values()), a["values"])
    okb = all(isinstance(v["volume"], float) and abs(v["volume"] - (800 - 20 * d) * 10) < 1e-3 and not v["errors"] for d, v in zip((5, 0, 9), b_["values"].values()))
    chk.true("K5 on NX 2206 the notch driven by the LENGTH of the riser line survives 0 as well (a zero-length line is solved): the old-solver warning is not reproduced",
             okb, b_["values"])


# ------------------------------------------------------------------ K6
def k6(part):
    dat = nxh.Datums(part)
    cx, cy = 600.0, -300.0
    nxh.expr(part, "k6_w", 210)
    nxh.expr(part, "k6_h", 125)
    nxh.expr(part, "k6_edge", 14)
    centre = nxh.point(part, cx, cy, 0)
    sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "K6_PLATE")
    outline = nxf.sketch_rect_centered(part, sk, centre, "k6_w", "k6_h")                 # bottom, right, top, left
    d0 = dof(sk)[1]
    def offset_loop(sketch, lines, mid_of_seed, distance="k6_edge", help_end=0.5, reverse_call=False):
        """Sketch Offset of a closed loop of lines. Returns (new lines, largest |x - cx| of their ends)."""
        seed = lines[0]
        hp = ck.frame(seed, help_end)["point"]
        ob = part.Sketches.CreateSketchOffsetBuilder(NXOpen.SketchOffset.Null)
        try:
            osec = ob.CreateSection()
            osec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
            osec.AddToSection([R.CreateRuleCurveDumb(lines)], seed, NULL, NULL, P(*hp), NXOpen.Section.Mode.Create, False)
            ob.UpdateLoopsAndCopies()
            ob.Distance.RightHandSide = distance
            ob.CreateDimension = True
            if reverse_call:
                ob.ReverseOffsetDirection()
            ob.EvaluateOffset()
            ob.Commit()
        finally:
            ob.Destroy()
        new = [g for g in sketch.GetAllGeometry() if isinstance(g, NXOpen.Line) and g not in lines]
        return new, max(abs(ck.frame(c, t)["point"][0] - mid_of_seed) for c in new for t in (0, 1))

    # which way does the offset go, and what turns it? measured on throw-away sketches (40 x 30 rectangles)
    trials = {}
    for i, (label, kw) in enumerate((("default (help point at the middle of the seed)", {}), ("help point near the START of the seed", {"help_end": 0.05}),
                                     ("help point near the END of the seed", {"help_end": 0.95}), ("negative distance", {"distance": "-k6_edge"}),
                                     ("ReverseOffsetDirection()", {"reverse_call": True}))):
        tc = nxh.point(part, cx + 300, cy + 60 * i, 0)
        tsk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "K6_TRIAL_%d" % i)
        tl = nxf.sketch_rect_centered(part, tsk, tc, 40, 30)
        try:
            _new, sp = offset_loop(tsk, tl, cx + 300, **kw)
            trials[label] = {"side": "inside" if sp < 20.0 else "outside", "half_width": round(sp, 3), "dof": dof(tsk)[1]}
        except Exception as ex:  # noqa: BLE001
            trials[label] = {"error": str(ex)[:120]}
        nxf.finish_sketch(tsk)
    sk.Activate(SK.ViewReorient.FalseValue)
    inward = [k for k, v in trials.items() if v.get("side") == "inside"]
    kw = {"default (help point at the middle of the seed)": {}, "help point near the START of the seed": {"help_end": 0.05},
          "help point near the END of the seed": {"help_end": 0.95}, "negative distance": {"distance": "-k6_edge"}}[inward[0]] if inward else {}
    inner, span = offset_loop(sk, outline, cx, **kw)
    offset_side = "inside" if span < 105.0 else "outside"
    d1 = dof(sk)[1]
    nxf.to_reference(part, inner)                                                         # construction loop: sections ignore it
    pts = []
    for ln in inner:                                                                      # one point on the start corner of every loop line
        p = part.Points.CreatePoint(P(*ck.frame(ln, 0.0)["point"]))
        sk.AddGeometry(p, SK.InferConstraintsOption.InferNoConstraints)
        pts.append(p)
    d2 = dof(sk)[1]
    for p, ln in zip(pts, inner):
        sk.CreateCoincidentConstraint(nxf.cg(p), nxf.cg(ln, CP.StartVertex))
    st = nxf.finish_sketch(sk)
    ext = nxh.extrude(part, nxh.section_region(part, sk, (cx, cy, 0), curves=outline), (0, 0, 1), 0, 20)
    body = ext.GetBodies()[0]
    v_plate = nxh.volume(part, body)
    hole = nxf.hole(part, body, pts, 9, vector=(0, 0, 1))

    def state():
        cyls = nxh.faces(body, ftype=nxh.CYLINDER)
        bb = nxh.bbox(body)
        dists = sorted(round(min(nxh.face_data(c)[1][0] - bb[0], bb[3] - nxh.face_data(c)[1][0]), 4) for c in cyls)
        dists_y = sorted(round(min(nxh.face_data(c)[1][1] - bb[1], bb[4] - nxh.face_data(c)[1][1]), 4) for c in cyls)
        return {"holes": len(cyls), "edge_distance_x": dists, "edge_distance_y": dists_y, "size": rnd([bb[3] - bb[0], bb[4] - bb[1]], 3),
                "volume": round(nxh.volume(part, body), 3), "errors": nxh.feature_errors(part)}
    s0 = state()
    nxh.set_expr(part, "k6_w", 250)
    nxh.set_expr(part, "k6_edge", 20)
    nxh.update()
    s1 = state()
    rows = {"sketch offset side trials (rectangle 40 x 30, distance 14)": trials, "variant used for the plate": inward[0] if inward else None, "plate offset side": offset_side,
            "dof_countdown": {"outline centred on a point, 2 dims": d0, "+ offset loop with its dimension": d1, "+ 4 free points": d2, "+ points on the loop corners": st["dof"]},
            "sketch": {k: st[k] for k in ("status", "dof", "auto_dims")}, "children_of_sketch": [c.GetFeatureName() for c in sk.Feature.GetChildren()],
            "plate 210 x 125, edge 14": s0, "plate 250 x 125, edge 20": s1, "features": [hole.FeatureType, ext.FeatureType]}
    chk.true("K6 ONE sketch holds the outline, a reference offset loop and four hole points: DOF 0 (countdown %s), auto_dims 0" % list(rows["dof_countdown"].values()),
             st["dof"] == 0 and st["status"] == "WellConstrained" and st["auto_dims"] == 0 and d2 == d1 + 8 and d0 == 0, rows["dof_countdown"])
    chk.true("K6 sketch Offset: the side is found by trial (recorded); the variant '%s' lies INSIDE the outline" % (inward[0] if inward else None),
             offset_side == "inside" and len(inward) >= 1, trials)
    chk.true("K6 SketchOffsetBuilder.ReverseOffsetDirection() raises 'Sketch is not initialized.' headless", "error" in trials["ReverseOffsetDirection()"], trials["ReverseOffsetDirection()"])
    chk("K6 Extrude takes the outline region only (the reference loop and the points are ignored): 210 x 125 x 20", v_plate, 210 * 125 * 20, 1e-3)
    chk.true("K6 Hole on the sketch points: 4 holes, each 14 from both edges; the one sketch feeds two features",
             s0["holes"] == 4 and s0["edge_distance_x"] == [14.0] * 4 and s0["edge_distance_y"] == [14.0] * 4 and len(rows["children_of_sketch"]) == 2, s0)
    chk.true("K6 change the outline and the edge distance (250, 20): the holes keep their edge distance, no feature error",
             s1["size"] == [250.0, 125.0] and s1["edge_distance_x"] == [20.0] * 4 and s1["edge_distance_y"] == [20.0] * 4 and not s1["errors"], s1)

    # the whole-sketch section trap
    c2 = nxh.point(part, cx, cy - 200, 0)
    sk2 = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "K6_TRAP")
    out2 = nxf.sketch_rect_centered(part, sk2, c2, 40, 30)
    in2 = nxf.sketch_rect_centered(part, sk2, c2, 20, 10)                                  # a construction loop that was left ACTIVE
    nxf.finish_sketch(sk2)
    e2 = nxh.extrude(part, nxh.section_feature(part, [sk2.Feature], help_point=(cx - 20, cy - 200, 0)), (0, 0, 1), 0, 5)
    v_active = nxh.volume(part, e2.GetBodies()[0])
    sk2.Activate(SK.ViewReorient.FalseValue)
    nxf.to_reference(part, in2)
    st2 = nxf.finish_sketch(sk2)
    nxh.update()
    v_ref = nxh.volume(part, e2.GetBodies()[0])
    del out2
    rows["whole-sketch section (CurveFeature rule)"] = {"inner loop active": round(v_active, 3), "inner loop converted to reference": round(v_ref, 3),
                                                        "sketch": {k: st2[k] for k in ("status", "dof")}, "errors": nxh.feature_errors(part)}
    M["K6 one sketch, several features"] = rows
    chk.true("K6 trap: a feature whose section is the WHOLE sketch takes every active curve - the construction loop becomes a window (40x30 - 20x10) x 5 = 5000, no error",
             abs(v_active - 5000) < 1e-3, v_active)
    chk.true("K6 cure: convert the construction loop to reference - the same Extrude regenerates to the full plate 6000",
             abs(v_ref - 6000) < 1e-3 and not nxh.feature_errors(part), v_ref)


# ------------------------------------------------------------------ K7
def k7(part):
    cx, cy, Rr = 0.0, 600.0, 50.0
    pl = part.Planes.CreatePlane(P(0, 0, 0), V(0, 0, 1), UPD)
    AB = F.AssociativeArcBuilder
    b = part.BaseFeatures.CreateAssociativeArcBuilder(F.AssociativeArc.Null)
    try:
        b.Type = AB.Types.ArcFromCenter
        b.CenterPoint.Value = nxh.point(part, cx, cy, 0)
        b.EndPointOptions = AB.EndOption.Radius
        b.Radius.RightHandSide = str(Rr)
        b.SupportPlaneData.SupportPlane = pl
        LO = GU.CurveExtendData.LimitOptions
        b.Limits.StartLimit.LimitOption = LO.Value
        b.Limits.EndLimit.LimitOption = LO.Value
        b.Limits.StartLimit.Distance.RightHandSide = "0"
        b.Limits.EndLimit.Distance.RightHandSide = "90"
        b.Limits.FullCircle = False
        b.Associative = True
        pf = b.CommitFeature()
    finally:
        b.Destroy()
    path = ck.curves_of(pf)[0]
    start = ck.frame(path, 0.0)["point"]
    nxh.expr(part, "k7_pct", 30, unit=None)
    nxh.expr(part, "k7_w", 8)
    nxh.expr(part, "k7_h", 5)
    was_on = nxf.auto_dimensioning_off()                              # BEFORE the builder: the sketch keeps the setting it is created with
    n0 = len(list(part.Features.GetFeatures()))
    sb = part.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    try:
        nxh.fill_section(part, sb.Section, help_point=start, seed=path, rules=[R.CreateRuleCurveFeature([pf])])
        sb.PlaneLocation.Path.Value = path
        sb.PlaneLocation.IsPercentUsed = True
        sb.PlaneLocation.Expression.RightHandSide = "k7_pct"
        sk = sb.Commit()
    finally:
        sb.Destroy()
    sk.Activate(SK.ViewReorient.FalseValue)
    sk.SetName("K7_SECTION")
    sk.Feature.SetName("K7_SECTION")
    new = list(part.Features.GetFeatures())[n0:]
    rows = {"auto dimensioning was on before": was_on, "new features": [f.FeatureType for f in new],
            "datum on path entities": {f.FeatureType: sorted({type(e).__name__ for e in f.GetEntities()}) for f in new if f.FeatureType != "SKETCH"}}
    # the point where the path pierces the sketch plane: the reference everything is positioned from
    ib = part.Sketches.CreateIntersectionPointBuilder(NXOpen.SketchIntersectionPoint.Null)
    try:
        ck.fill(ib.Rail, [R.CreateRuleCurveFeature([pf])], start, path)
        ib.UpdateData()
        ib.Commit()
    finally:
        ib.Destroy()
    ipt = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Point)][0]
    d0 = dof(sk)[1]
    # section: H / V rectangle, centred on the path point by two Midpoint constraints, sized by two driving dimensions
    u0, v0 = nxf._sketch_uv(sk, ipt)
    rect = nxf.hv_polygon(part, sk, [(u0 - 4, v0 - 2.5), (u0 + 4, v0 - 2.5), (u0 + 4, v0 + 2.5), (u0 - 4, v0 + 2.5)])     # bottom, right, top, left
    d1 = dof(sk)[1]
    sk.CreateMidpointConstraint(nxf.cg(ipt), nxf.cg(rect[0]))
    sk.CreateMidpointConstraint(nxf.cg(ipt), nxf.cg(rect[1]))
    d2 = dof(sk)[1]
    to3d = nxf.sketch_to3d(sk)
    for ln, name, org in ((rect[0], "k7_w", to3d(u0, v0 - 6)), (rect[1], "k7_h", to3d(u0 + 8, v0))):
        c = sk.CreateDimension(SK.ConstraintType.ParallelDim, nxf.dg(ln, A.StartPoint), nxf.dg(ln, A.EndPoint), org, NXOpen.Expression.Null)
        c.AssociatedExpression.RightHandSide = name
    st = nxf.finish_sketch(sk)

    def state(pct):
        pp = ck.frame(path, pct / 100.0)
        o, m = sk.Origin, sk.Orientation.Element
        mids = [ck.frame(c, 0.5)["point"] for c in rect]
        centre = [sum(p[i] for p in mids) / 4.0 for i in range(3)]
        return {"sketch_origin_to_path_point": round(math.dist([o.X, o.Y, o.Z], pp["point"]), 6), "normal_vs_path_tangent_deg": round(min(ck.angle([m.Zx, m.Zy, m.Zz], pp["tangent"]),
                180 - ck.angle([m.Zx, m.Zy, m.Zz], pp["tangent"])), 5), "rect_centre_to_path_point": round(math.dist(centre, pp["point"]), 6),
                "side_lengths": sorted(round(c.GetLength(), 4) for c in rect), "planarity": round(ck.planarity(rect), 9)}
    s30 = state(30)
    nxh.set_expr(part, "k7_pct", 70)
    nxh.update()
    s70 = dict(state(70), sketch=reopen(sk), errors=nxh.feature_errors(part))
    nxh.set_expr(part, "k7_pct", 0)
    nxh.update()
    s0 = dict(state(0), sketch=reopen(sk))
    _f, body = nxf.sweep_along_guide(part, rect, [path], ck.frame(rect[0], 0.5)["point"], start)
    L = math.pi / 2 * Rr
    v0 = nxh.volume(part, body)
    nxh.set_expr(part, "k7_w", 12)
    nxh.update()
    v1 = nxh.volume(part, body)
    rows.update({"dof_countdown": {"intersection point of the path": d0, "+ H/V rectangle": d1, "+ 2 Midpoint constraints to the point": d2, "+ 2 driving dimensions": st["dof"]},
                 "sketch": {k: st[k] for k in ("status", "dof", "auto_dims", "dims")}, "at 30 %": s30, "at 70 %": s70, "at 0 %": s0,
                 "sweep along the path": {"volume w 8": round(v0, 4), "expected": round(8 * 5 * L, 4), "volume w 12": round(v1, 4), "expected 12": round(12 * 5 * L, 4),
                                          "solid": bool(body.IsSolidBody), "errors": nxh.feature_errors(part)}})
    M["K7 constrained sketch on path"] = rows
    chk.true("K7 Sketch On Path created with Continuous Auto Dimensioning off: the intersection point of the path adds no freedom (DOF 0), "
             "H/V rectangle 4 -> two Midpoint constraints 2 -> two driving dimensions 0: WellConstrained / DOF 0 / auto_dims 0",
             (d0, d1, d2, st["dof"]) == (0, 4, 2, 0) and st["status"] == "WellConstrained" and st["auto_dims"] == 0, rows["dof_countdown"])
    chk.true("K7 at 30 %% of the path: sketch origin and rectangle centre on the path point, sketch normal = path tangent, sides 8 and 5",
             s30["sketch_origin_to_path_point"] < 1e-6 and s30["rect_centre_to_path_point"] < 1e-6 and s30["normal_vs_path_tangent_deg"] < 1e-4
             and s30["side_lengths"] == [5.0, 5.0, 8.0, 8.0], s30)
    chk.true("K7 position expression 30 -> 70: the constrained section rides along (centre on the path point, normal tangent, still DOF 0, no error)",
             s70["rect_centre_to_path_point"] < 1e-6 and s70["normal_vs_path_tangent_deg"] < 1e-4 and s70["sketch"] == ("WellConstrained", 0) and not s70["errors"], s70)
    chk("K7 section at 0 % swept along the path: volume = w x h x path length (Pappus)", v0, 8 * 5 * L, 1e-2)
    chk("K7 ... and it follows the driving dimension (w 8 -> 12)", v1, 12 * 5 * L, 1e-2)


def run():
    global R
    part = nxh.new_part(os.path.join(OUT, "sketch_rules.prt"))
    R = part.ScRuleFactory
    res["auto_dimensioning_at_session_start"] = bool(nxh.S.Preferences.Sketch.ContinuousAutoDimensioning)
    for name, fn in (("K1", k1), ("K2", k2), ("K3", k3), ("K4", k4), ("K5", k5), ("K6", k6), ("K7", k7)):
        block(name, fn, part)
    res["errors"] = nxh.feature_errors(part)
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res.update(chk.report())
if "error" in res:
    res["result"] = "FAIL"
nxh.write_json(os.path.join(OUT, "sketch_rules.json"), res)
