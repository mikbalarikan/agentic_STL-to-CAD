"""Course-driven checks for sketches and curves on NX 2206 (headless run_journal).

  run.ps1 -Script course_checks.py -WorkDir <out> -JArgs <out>

Each recipe answers one claim or tool from the NX course (days 2, 3a, 4b/5.1, 5a) that the first
three scripts did not cover. A recipe that cannot be made to work is listed under "not_working"
with the NX error text and does not fail the run. Writes course_checks.json.
"""
import math
import os
import re
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import nxh  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
ONLY = list(sys.argv[2:])
# Continuous Auto Dimensioning off BEFORE any sketch is created: with it on (the batch default) GetStatus() reads
# WellConstrained / 0 for any sketch, so the recorded sketch status would prove nothing (nx-journal-core section 5).
nxh.S.Preferences.Sketch.ContinuousAutoDimensioning = False
P, V, UPD, UFS = nxh.P, nxh.V, nxh.UPD, nxh.UFS
NF, NULL = nxh.NULL_FEATURE, NXOpen.NXObject.Null
SK = NXOpen.Sketch
A, CP = SK.AssocType, SK.ConstraintPointType
log = nxh.Log(os.path.join(OUT, "course_checks.log"))
res = {"checks": {}, "not_working": {}, "api": {}}


def check(name, ok, **data):
    res["checks"][name] = dict(ok=bool(ok), **data)
    log(("PASS " if ok else "FAIL ") + name, data)
    return ok


def api(key, obj):
    """{member: return type or signature} - compact API discovery kept in the JSON."""
    out = {}
    cls = type(obj)
    for n in dir(cls):
        if n.startswith("_") or n in ("Tag", "Null", "Validate", "Destroy", "GetObject", "ShowResults", "PreviewBuilder"):
            continue
        try:
            d = getattr(cls, n).__doc__ or ""
        except Exception:  # noqa: BLE001
            d = ""
        m = re.findall(r"Signature ``(.*?)``", d)
        t = re.findall(r":rtype: (.*?)\n", d + "\n")
        out[n] = ((m[0] if m and "(" in m[0] else "") + " -> " + (t[0].strip() if t else "")).strip()[:150]
    res["api"][key] = out


def recipe(name, fn):
    if ONLY and not any(name == o for o in ONLY):
        return None
    r, err = nxh.attempt(name, fn, log=log)
    if err:
        res["not_working"][name] = err
    try:
        sk = nxh.S.ActiveSketch
        if sk is not None:
            sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
    except Exception:  # noqa: BLE001
        pass
    return r


_PROPS = UFS.ModlGeneral.AskCurveProps


def at(c, t):
    r = _PROPS(c.Tag, float(t))
    return list(r[0]), list(r[1])


def rad_at(c, t):
    return _PROPS(c.Tag, float(t))[5]


def near(a, b, tol=1e-3):
    return all(abs(x - y) < tol for x, y in zip(a, b))


def par(a, b, tol=1e-4):
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(x * x for x in b))
    return abs(abs(sum(x * y for x, y in zip(a, b)) / (na * nb)) - 1.0) < tol


def curves_of(f):
    return [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)]


def total_length(cs):
    return sum(c.GetLength() for c in cs)


def new_sketch(part, plane, haxis, origin, name):
    sb = part.Sketches.CreateSimpleSketchInPlaceBuilder()
    try:
        sb.UseWorkPartOrigin = False
        d = part.Directions.CreateDirection(haxis, NXOpen.Sense.Forward, UPD)
        xf = part.Xforms.CreateXformByPlaneXDirPoint(plane, d, origin, UPD, 0.625, False, False)
        sb.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
        sb.HorizontalReference.Value = haxis
        sk = sb.Commit()
    finally:
        sb.Destroy()
    sk.Activate(SK.ViewReorient.FalseValue)
    sk.SetName(name)
    return sk


def cg(geom, pt=None):
    g = SK.ConstraintGeometry()
    g.Geometry, g.PointType, g.SplineDefiningPointIndex = geom, (pt if pt is not None else CP.NotSet), 0
    return g


def dg(geom, assoc=None, hp=None):
    d = SK.DimensionGeometry()
    d.Geometry, d.AssocType, d.AssocValue = geom, (assoc if assoc is not None else A.NotSet), 0
    d.HelpPoint, d.View = (hp if hp is not None else P(0, 0, 0)), NULL
    return d


def pdim(sk, ref, ref_help, geom, assoc, origin, formula):
    c = sk.CreateDimension(SK.ConstraintType.PerpendicularDim, dg(ref, None, ref_help), dg(geom, assoc), origin, NXOpen.Expression.Null)
    c.AssociatedExpression.RightHandSide = formula
    return c


def status_of(sk):
    st, dof = sk.GetStatus()
    name = [n for n in nxh.enum_names(SK.Status) if getattr(SK.Status, n) == st]
    return (name[0] if name else str(st)), dof


def fill(sec, rules, help_point, seed=None, types=NXOpen.Section.AllowTypes.OnlyCurves):
    sec.SetAllowedEntityTypes(types)
    sec.AddToSection(rules, seed if seed is not None else NULL, NULL, NULL, P(*help_point), NXOpen.Section.Mode.Create, False)
    return sec


def run():
    part = nxh.new_part(os.path.join(OUT, "course_checks.prt"))
    dat = nxh.Datums(part)
    R = part.ScRuleFactory
    hx, hy = P(50, 0, 0), P(0, 50, 0)
    Q = lambda x, y: P(x, y, 0)  # noqa: E731
    for n, f, u in (("base_l", "30", "mm"), ("t_end", "100", None), ("path_r", "40", "mm")):
        nxh.expr(part, n, f, u)

    # ---------------- K1 relations: parallel, perpendicular, equal length, midpoint (old Sketch.Create*Constraint API)
    def k1():
        sk = new_sketch(part, dat.xy, dat.x, dat.origin, "SKT_RELATIONS")
        a = part.Curves.CreateLine(Q(0, 0), Q(30, 0))
        b = part.Curves.CreateLine(Q(0, 10), Q(25, 14))
        c = part.Curves.CreateLine(Q(40, 0), Q(43, 20))
        pt = part.Points.CreatePoint(Q(11, 6))
        for g in (a, b, c):
            sk.AddGeometry(g, SK.InferConstraintsOption.InferNoConstraints)
        sk.AddGeometry(pt, SK.InferConstraintsOption.InferNoConstraints)
        sk.CreateHorizontalConstraint(cg(a))
        sk.CreateCoincidentConstraint(cg(a, CP.StartVertex), cg(dat.origin))
        d = sk.CreateDimension(SK.ConstraintType.ParallelDim, dg(a, A.StartPoint), dg(a, A.EndPoint), Q(15, -6), NXOpen.Expression.Null)
        d.AssociatedExpression.RightHandSide = "base_l"
        sk.Update()
        before = {"b_len": b.GetLength(), "b_dir": at(b, 0)[1], "c_dir": at(c, 0)[1], "pt": [pt.Coordinates.X, pt.Coordinates.Y]}
        sk.CreateParallelConstraint(cg(b), cg(a))
        sk.CreateEqualLengthConstraint(cg(b), cg(a))
        sk.CreatePerpendicularConstraint(cg(c), cg(a))
        sk.CreateMidpointConstraint(cg(pt), cg(a))
        sk.Update()
        st = status_of(sk)
        after = {"b_len": b.GetLength(), "b_dir": at(b, 0)[1], "c_dir": at(c, 0)[1], "pt": [pt.Coordinates.X, pt.Coordinates.Y]}
        sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        ok = abs(after["b_len"] - 30) < 1e-6 and par(after["b_dir"], (1, 0, 0)) and par(after["c_dir"], (0, 1, 0)) and abs(after["pt"][0] - 15) < 1e-6
        nxh.set_expr(part, "base_l", "50")
        nxh.update()
        edit = {"b_len": b.GetLength(), "pt_x": pt.Coordinates.X}
        check("K1 parallel / perpendicular / equal length / midpoint relations solve and persist",
              ok and abs(edit["b_len"] - 50) < 1e-6 and abs(edit["pt_x"] - 25) < 1e-6, before=before, after=after,
              after_base_l_50=edit, status=st)
        nxh.set_expr(part, "base_l", "30")
        nxh.update()

    recipe("K1", k1)

    # ---------------- K2 symmetric relation and mirror in sketch (2206 builders) - discovery + attempt
    def k2():
        sk = new_sketch(part, dat.xy, dat.x, dat.origin, "SKT_SYMM")
        l1 = part.Curves.CreateLine(Q(10, 60), Q(25, 80))
        l2 = part.Curves.CreateLine(Q(-12, 58), Q(-20, 85))
        for g in (l1, l2):
            sk.AddGeometry(g, SK.InferConstraintsOption.InferNoConstraints)
        out = {}
        # Make Symmetric: primary = the curve that moves, secondary = the one that stays, centre line = datum axis
        try:
            b = part.Sketches.CreateMakeSymmetricBuilder()
            try:
                b.PrimaryObject.Value = l2
                b.SecondaryObject.Value = l1
                b.CenterLine.Value = dat.y
                b.Commit()
            finally:
                b.Destroy()
            sk.Update()
            e1, e2 = [at(l1, t)[0] for t in (0, 1)], [at(l2, t)[0] for t in (0, 1)]
            mirrored = lambda p, q: abs(p[0] + q[0]) < 1e-6 and abs(p[1] - q[1]) < 1e-6  # noqa: E731
            out["symmetric"] = {"l1": e1, "l2": e2, "l1_unchanged": near(e1[0], (10, 60, 0)) and near(e1[1], (25, 80, 0)),
                                "ok": (mirrored(e1[0], e2[0]) and mirrored(e1[1], e2[1])) or (mirrored(e1[0], e2[1]) and mirrored(e1[1], e2[0]))}
            n_sym = len(sk.GetAllConstraintsOfType(SK.ConstraintClass.Geometric, SK.ConstraintType.Mirror))
            out["symmetric"]["mirror_type_constraints"] = n_sym
        except Exception as e:  # noqa: BLE001
            out["symmetric"] = "ERR " + str(e)
        # Mirror Curve in sketch: section + DirectionObject (centre line)
        try:
            l3 = part.Curves.CreateLine(Q(30, 100), Q(45, 110))
            sk.AddGeometry(l3, SK.InferConstraintsOption.InferNoConstraints)
            n0 = len(sk.GetAllGeometry())
            b = part.Sketches.CreateSketchMirrorPatternBuilder(NXOpen.SketchPattern.Null)
            try:
                b.Section.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
                b.Section.AddToSection([R.CreateRuleCurveDumb([l3])], l3, NULL, NULL, Q(30, 100), NXOpen.Section.Mode.Create, False)
                b.UpdateInputSection()
                b.DirectionObject.Value = dat.y
                b.UpdateDirectionObject()
                b.CreateConstraint = True
                b.Commit()
            finally:
                b.Destroy()
            sk.Update()
            lines = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Line)]
            xs = sorted(round(at(g, t)[0][0], 3) for g in lines for t in (0, 1))
            out["mirror"] = {"n_before": n0, "n_after": len(sk.GetAllGeometry()), "line_end_x": xs, "ok": -30.0 in xs and -45.0 in xs}
        except Exception as e:  # noqa: BLE001
            out["mirror"] = "ERR " + str(e)
        out["status"] = list(status_of(sk))
        sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        res["K2_detail"] = out
        check("K2a Make Symmetric about a datum axis", isinstance(out.get("symmetric"), dict) and out["symmetric"]["ok"], detail=out.get("symmetric"))
        check("K2b Mirror curve in sketch about a datum axis", isinstance(out.get("mirror"), dict) and out["mirror"]["ok"], detail=out.get("mirror"))

    recipe("K2", k2)

    # ---------------- K3 sketch on path (0 % arc length, normal to path) + swept check by sketch frame
    def k3():
        path = nxh.arc(part, (0, -100, 0), (1, 0, 0), (0, 1, 0), 40.0, 0.0, math.pi / 2)      # starts (40,-100,0), tangent +Y
        b = part.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
        try:
            api("SketchAlongPath", b)
            api("SketchAlongPath.PlaneLocation", b.PlaneLocation)
            fill(b.Section, [R.CreateRuleCurveDumb([path])], (40, -100, 0), path)
            b.PlaneLocation.Path.Value = path
            b.PlaneLocation.IsPercentUsed = True
            b.PlaneLocation.Expression.RightHandSide = "0"
            sk = b.Commit()
        finally:
            b.Destroy()
        sk.Activate(SK.ViewReorient.FalseValue)
        o = sk.Origin
        m = sk.Orientation.Element
        normal = [m.Zx, m.Zy, m.Zz]
        circ = part.Curves.CreateArc(P(o.X, o.Y, o.Z), V(m.Xx, m.Xy, m.Xz), V(m.Yx, m.Yy, m.Yz), 3.0, 0.0, 2 * math.pi)
        sk.AddGeometry(circ, SK.InferConstraintsOption.InferNoConstraints)
        sk.Update()
        sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        tree = [(f["type"], f["name"]) for f in nxh.feature_table(part)][-3:]
        check("K3 sketch on path at 0 % normal to path", near([o.X, o.Y, o.Z], (40, -100, 0)) and par(normal, (0, 1, 0)),
              origin=[o.X, o.Y, o.Z], normal=normal, tree=tree, feature=sk.Feature.FeatureType)

    recipe("K3", k3)

    # ---------------- K4 section rules on edges: EdgeTangent, EdgeChain; "stop at intersection"
    def k4():
        _f, blk = nxh.block(part, (100, 0, 0), (40, 30, 10))
        vert = nxh.edges(blk, lambda b: abs(b[5] - b[2] - 10) < 1e-6 and abs(b[3] - b[0]) < 1e-6 and abs(b[4] - b[1]) < 1e-6)
        nxh.blend(part, vert, 5)
        top = nxh.faces(blk, ftype=nxh.PLANE, normal=(0, 0, 1))[0]
        loop = top.GetEdges()
        seed = [e for e in loop if isinstance(e, NXOpen.Edge) and e.SolidEdgeType == NXOpen.Edge.EdgeType.Linear][0]
        area = 40 * 30 - (4 - math.pi) * 25
        out = {"top_edges": len(loop)}
        def touching(e):
            pe = [at(e, 0)[0], at(e, 1)[0]]
            return [o for o in loop if o.Tag != e.Tag and any(near(a, b) for a in pe for b in (at(o, 0)[0], at(o, 1)[0]))]

        nb = touching(seed)
        trials = [("EdgeTangent", lambda: R.CreateRuleEdgeTangent(seed, NXOpen.Edge.Null, True, 0.5, False)),
                  ("EdgeBoundary", lambda: R.CreateRuleEdgeBoundary([top]))]
        for i, end in enumerate(nb):
            for from_start in (True, False):
                trials.append((f"EdgeChain end=neighbour{i} isFromStart={from_start}",
                               lambda end=end, fs=from_start: R.CreateRuleEdgeChain(seed, end, fs, top, False)))
        for label, mk in trials:
            m = nxh.mark("k4 " + label, False)
            try:
                sec = nxh.section(part, rules=[mk()], seed=seed, help_point=at(seed, 0.5)[0])
                n = len(sec.GetOutputCurves())
                f = nxh.extrude(part, sec, (0, 0, 1), 0, 3)
                b = f.GetBodies()[0]
                out[label] = {"n": n, "solid": b.IsSolidBody, "volume": round(nxh.volume(part, b), 3) if b.IsSolidBody else 0.0}
            except Exception as e:  # noqa: BLE001
                out[label] = "ERR " + str(e)
            nxh.undo_to(m)
        ok = lambda k: isinstance(out[k], dict) and out[k]["solid"] and abs(out[k]["volume"] - area * 3) < 0.05  # noqa: E731
        check("K4a EdgeTangent rule (8-edge tangent loop of a blended block top)", ok("EdgeTangent"), expect=round(area * 3, 3), **out)
        chains = {k: v for k, v in out.items() if k.startswith("EdgeChain")}
        check("K4b EdgeChain rule (start edge, end edge, common face) closes the loop", any(ok(k) for k in chains), expect=round(area * 3, 3), **chains)
        res["K4_EdgeBoundary"] = out["EdgeBoundary"]

    recipe("K4", k4)

    def k5():
        z = 0.0
        ls = [nxh.line(part, (190, 0, z), (230, 0, z)), nxh.line(part, (220, -10, z), (220, 30, z)),
              nxh.line(part, (230, 20, z), (190, 20, z)), nxh.line(part, (200, 30, z), (200, -10, z))]
        corners = [(200, 0), (220, 0), (220, 20), (200, 20)]
        out = {}
        m = nxh.mark("k5a", False)
        try:
            f = nxh.extrude(part, nxh.section(part, curves=ls, help_point=(210, 0, 0)), (0, 0, 1), 0, 5)
            bs = f.GetBodies()
            out["all_four_whole_lines"] = {"bodies": len(bs), "solid": [b.IsSolidBody for b in bs]}
        except Exception as e:  # noqa: BLE001
            out["all_four_whole_lines"] = "ERR " + str(e)
        nxh.undo_to(m)
        sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        for i in range(4):
            a, b2 = corners[i], corners[(i + 1) % 4]
            prev_l, next_l = ls[(i - 1) % 4], ls[(i + 1) % 4]
            mid = ((a[0] + b2[0]) / 2, (a[1] + b2[1]) / 2, 0)
            sec.AddChainBetweenIntersectionPoints([R.CreateRuleCurveDumb([ls[i]])], prev_l, P(a[0], a[1], 0), next_l, P(b2[0], b2[1], 0),
                                                  ls[i], P(*mid), NXOpen.Section.Mode.Create, False)
        f = nxh.extrude(part, sec, (0, 0, 1), 0, 5)
        b = f.GetBodies()[0]
        v = nxh.volume(part, b) if b.IsSolidBody else 0.0
        check("K5 stop at intersection: crossing lines -> closed loop -> solid", b.IsSolidBody and abs(v - 2000) < 0.01,
              volume=v, expect=2000.0, **out)

    recipe("K5", k5)

    # ---------------- K6 composite curve with Join: one curve -> one swept face
    def k6():
        l1 = nxh.line(part, (0, 150, 0), (20, 150, 0))
        a1 = nxh.arc(part, (20, 160, 0), (1, 0, 0), (0, 1, 0), 10.0, -math.pi / 2, 0.0)
        l2 = nxh.line(part, (30, 160, 0), (30, 180, 0))
        chain = [l1, a1, l2]
        L = total_length(chain)
        JM = NXOpen.Features.CompositeCurveBuilder.JoinMethod
        res["api"]["CompositeCurve.JoinMethod"] = nxh.enum_names(JM)

        def comp(join):
            b = part.Features.CreateCompositeCurveBuilder(NF)
            try:
                fill(b.Section, [R.CreateRuleCurveDumb(chain)], (0, 150, 0), l1)
                b.Associative = True
                b.ParentPart = NXOpen.Features.CompositeCurveBuilder.PartType.WorkPart
                b.FixAtCurrentTimestamp = False
                b.HideOriginal = False
                b.Tolerance = 0.001
                b.JoinOption = join
                f = b.Commit()
            finally:
                b.Destroy()
            return f

        out = {}
        for name in ("No", "Cubic"):
            f = comp(getattr(JM, name))
            cs = curves_of(f)
            m = nxh.mark("k6", False)
            ex = nxh.extrude(part, nxh.section(part, rules=[R.CreateRuleCurveFeature([f])], help_point=(0, 150, 0)), (0, 0, 1), 0, 10, sheet=True)
            body = ex.GetBodies()[0]
            out[name] = {"curves": len(cs), "types": sorted({type(c).__name__ for c in cs}), "length": round(total_length(cs), 4),
                         "swept_faces": len(body.GetFaces()), "area": round(nxh.sheet_area(part, body)[0], 3)}
            nxh.undo_to(m)
        check("K6 composite curve Join=Cubic gives one curve and one swept face", out["No"]["curves"] == 3 and out["No"]["swept_faces"] == 3
              and out["Cubic"]["curves"] == 1 and out["Cubic"]["swept_faces"] == 1 and abs(out["Cubic"]["length"] - L) < 0.01,
              source_length=round(L, 4), **out)

    recipe("K6", k6)

    # ---------------- K7 bridge curve G1 vs G2 from an arc end to a line end
    def k7():
        a1 = nxh.arc(part, (100, 150, 0), (1, 0, 0), (0, 1, 0), 20.0, math.pi / 2, math.pi)      # ends at (100,170,0) heading +X? start (100,170)
        l2 = nxh.line(part, (140, 185, 0), (170, 185, 0))
        out = {}

        def bridge(cont):
            b = part.Features.CreateBridgeCurveBuilderEx(NXOpen.Features.BridgeCurve.Null)
            try:
                fill(b.StartSection, [R.CreateRuleCurveDumb([a1])], (100.5, 170, 0), a1)
                fill(b.EndSection, [R.CreateRuleCurveDumb([l2])], (141, 185, 0), l2)
                c0 = b.StartConnectivity.Continuity
                if "Continuity" not in res["api"]:
                    api("Continuity", c0)
                    res["api"]["Continuity.enums"] = {k: nxh.enum_names(getattr(type(c0), k)) for k in dir(type(c0))
                                                      if k[0].isupper() and isinstance(getattr(type(c0), k), type)}
                if cont is not None:
                    CT = NXOpen.GeometricUtilities.Continuity.ContinuityTypes
                    b.StartConnectivity.Continuity.ContinuityType = getattr(CT, cont)
                    b.EndConnectivity.Continuity.ContinuityType = getattr(CT, cont)
                b.IsAssociative = True
                f = b.Commit()
            finally:
                b.Destroy()
            return f

        for cont in ("G1", "G2"):
            m = nxh.mark("k7", False)
            try:
                f = bridge(cont)
                c = curves_of(f)[0]
                e0, e1 = at(c, 0), at(c, 1)
                s, e = (0.0, 1.0) if math.dist(e0[0], (100, 170, 0)) < math.dist(e1[0], (100, 170, 0)) else (1.0, 0.0)
                out[cont] = {"start": at(c, s)[0], "start_tangent_parallel_x": par(at(c, s)[1], (1, 0, 0)),
                             "radius_at_arc_end": round(abs(rad_at(c, s)), 3), "radius_at_line_end": round(abs(rad_at(c, e)), 1)}
            except Exception as ex:  # noqa: BLE001
                out[cont] = "ERR " + str(ex)
            nxh.undo_to(m)
        ok = (isinstance(out["G2"], dict) and isinstance(out["G1"], dict) and abs(out["G2"]["radius_at_arc_end"] - 20) < 0.05
              and abs(out["G1"]["radius_at_arc_end"] - 20) > 0.5 and out["G2"]["start_tangent_parallel_x"])
        check("K7 bridge curve G2: curvature radius at the arc end equals the arc radius 20", ok, **out)

    recipe("K7", k7)

    # ---------------- K8 studio spline whose end points ride on existing curves (the user's real usage)
    def k8():
        la = nxh.line(part, (0, 220, 0), (30, 220, 0))
        lb = nxh.line(part, (60, 240, 10), (90, 240, 10))
        mm = nxh.units(part)["mm"]

        def on_curve(curve, formula):
            e = part.Expressions.CreateSystemExpressionWithUnits(str(formula), None)
            sc = part.Scalars.CreateScalarExpression(e, NXOpen.Scalar.DimensionalityType.NotSet, UPD)
            return part.Points.CreatePoint(curve, sc, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, UPD)

        SB = NXOpen.Features.StudioSplineBuilderEx
        b = part.Features.CreateStudioSplineBuilderEx(NULL)
        try:
            b.Type = SB.Types.ThroughPoints
            b.Degree = 5
            b.IsAssociative = True
            b.MatchKnotsType = SB.MatchKnotsTypes.NotSet
            for p in (on_curve(la, "t_end"), on_curve(lb, "0")):
                g = b.ConstraintManager.CreateGeometricConstraintData()
                g.Point = p
                b.ConstraintManager.Append(g)
            f = b.Commit()
        finally:
            b.Destroy()
        c = curves_of(f)[0]
        e = sorted([at(c, 0)[0], at(c, 1)[0]])
        first = [list(x) for x in e]
        nxh.set_expr(part, "t_end", "50")
        nxh.update()
        e2 = sorted([at(curves_of(f)[0], 0)[0], at(curves_of(f)[0], 1)[0]])
        check("K8 studio spline between points ON two curves follows the on-curve parameter", near(first[0], (30, 220, 0)) and near(first[1], (60, 240, 10))
              and near(e2[0], (15, 220, 0)), ends=first, after_t_end_50=[list(x) for x in e2], order=getattr(c, "Order", None), errors=nxh.feature_errors(part))
        nxh.set_expr(part, "t_end", "100")
        nxh.update()

    recipe("K8", k8)

    # ---------------- cylinder used by K9..K13
    _f, cyl = nxh.cylinder(part, (0, 300, 0), (0, 0, 1), 30, 40)
    cface = nxh.faces(cyl, ftype=nxh.CYLINDER)[0]

    def on_cyl(curves, n=21):
        """max |radius - 15| over samples = how far the curves leave the cylinder face"""
        dev = 0.0
        for c in curves:
            for i in range(n):
                p = at(c, i / (n - 1.0))[0]
                dev = max(dev, abs(math.hypot(p[0], p[1] - 300) - 15))
        return dev

    # ---------------- K9 "a spline through points on the face leaves the surface" vs curve on surface
    def k9():
        pts = [(15 * math.cos(math.radians(a)), 300 + 15 * math.sin(math.radians(a)), z) for a, z in ((0, 5), (40, 15), (80, 30))]
        SB = NXOpen.Features.StudioSplineBuilderEx
        b = part.Features.CreateStudioSplineBuilderEx(NULL)
        try:
            b.Type = SB.Types.ThroughPoints
            b.Degree = 2
            b.IsAssociative = True
            b.MatchKnotsType = SB.MatchKnotsTypes.NotSet
            for p in pts:
                g = b.ConstraintManager.CreateGeometricConstraintData()
                g.Point = nxh.point(part, *p)
                b.ConstraintManager.Append(g)
            f = b.Commit()
        finally:
            b.Destroy()
        dev_spline = on_cyl(curves_of(f))
        out = {"spline_through_3_face_points_max_dev": round(dev_spline, 4)}
        b = part.Features.CreateCurveOnSurfaceBuilder(NXOpen.Features.CurveOnSurface.Null)
        step = "api"
        try:
            api("CurveOnSurface", b)
            try:
                step = "faces"
                try:
                    b.Faces.ReplaceRules([R.CreateRuleFaceDumb([cface])], False)
                except Exception:  # noqa: BLE001
                    b.Faces = nxh.collector(part, faces=[cface])
                step = "points"
                for p in pts:
                    g = b.ConstraintManager.CreateGeometricConstraintData()
                    g.Point = nxh.point(part, *p)
                    b.ConstraintManager.Append(g)
                step = "commit"
                f2 = b.Commit()
                out["curve_on_surface_max_dev"] = round(on_cyl(curves_of(f2)), 6)
                out["curve_on_surface_type"] = f2.FeatureType
            except Exception as e:  # noqa: BLE001
                out["curve_on_surface"] = f"ERR step {step}: {e}"
        finally:
            b.Destroy()
        res["K9_detail"] = out
        check("K9a spline through points on a cylinder leaves the face (course claim)", dev_spline > 0.05, **out)
        check("K9b Curve on Surface stays on the face", out.get("curve_on_surface_max_dev", 1) < 1e-3, detail=out)

    recipe("K9", k9)

    # ---------------- K10 isoparametric curves, K11 combined projection, K12 mirror curve, K13 trim curve
    def k10():
        b = part.Features.CreateIsoparametricCurvesBuilder(NXOpen.Features.IsoparametricCurves.Null)
        step = "api"
        try:
            api("IsoparametricCurves", b)
            try:
                step = "face"
                b.SelectObject.Value = cface
                step = "commit"
                f = b.Commit()
            except Exception as e:  # noqa: BLE001
                raise RuntimeError(f"step {step}: {e}")
        finally:
            b.Destroy()
        cs = curves_of(f)
        check("K10 isoparametric curves on a cylinder face", len(cs) >= 1 and on_cyl(cs) < 1e-3, n=len(cs), type=f.FeatureType,
              lengths=[round(c.GetLength(), 3) for c in cs][:6], dev=on_cyl(cs))

    recipe("K10", k10)

    def k11():
        c1 = nxh.arc(part, (200, 300, 0), (1, 0, 0), (0, 1, 0), 20.0, 0.0, math.pi)             # top view: half circle in XY
        c2 = nxh.line(part, (180, 300, 0), (220, 300, 10))                                       # side view: ramp in XZ
        b = part.Features.CreateCombinedProjectionBuilder(NXOpen.Features.CombinedProjection.Null)
        step = "api"
        try:
            api("CombinedProjection", b)
            api("CombinedProjection.Direction1", b.Direction1)
            try:
                step = "curve1"
                fill(b.Curve1, [R.CreateRuleCurveDumb([c1])], (220, 300, 0), c1)
                step = "curve2"
                fill(b.Curve2, [R.CreateRuleCurveDumb([c2])], (180, 300, 0), c2)
                step = "directions"
                DT = NXOpen.GeometricUtilities.ProjectionOptions.DirectionType
                res["api"]["ProjectionOptions.DirectionType"] = nxh.enum_names(DT)
                for d, vec in ((b.Direction1, (0, 0, 1)), (b.Direction2, (0, 1, 0))):
                    d.ProjectDirectionMethod = DT.Vector
                    d.ProjectVector = nxh.direction(part, vec)
                step = "commit"
                b.CurveOptions.Associative = True
                f = b.Commit()
            except Exception as e:  # noqa: BLE001
                raise RuntimeError(f"step {step}: {e}")
        finally:
            b.Destroy()
        cs = curves_of(f)
        dev = 0.0
        for c in cs:
            for i in range(21):
                p = at(c, i / 20.0)[0]
                dev = max(dev, abs(math.hypot(p[0] - 200, p[1] - 300) - 20), abs(p[2] - (p[0] - 180) / 4.0))
        check("K11 combined projection: top-view arc x side-view ramp", len(cs) >= 1 and dev < 0.02, n=len(cs), type=f.FeatureType, max_dev=dev,
              ends=[at(cs[0], 0)[0], at(cs[-1], 1)[0]] if cs else None)

    recipe("K11", k11)

    def k12():
        src = nxh.line(part, (10, 400, 0), (40, 420, 5))
        b = part.Features.CreateMirrorCurveBuilder(NF)
        step = "api"
        try:
            api("MirrorCurve", b)
            try:
                step = "curve"
                fill(b.Curve, [R.CreateRuleCurveDumb([src])], (10, 400, 0), src)
                step = "plane"
                b.PlaneOption = NXOpen.Features.MirrorCurveBuilder.PlaneOptions.NewPlane
                b.NewPlane = part.Planes.CreatePlane(P(0, 0, 0), V(1, 0, 0), UPD)
                step = "commit"
                f = b.Commit()
            except Exception as e:  # noqa: BLE001
                raise RuntimeError(f"step {step}: {e}")
        finally:
            b.Destroy()
        cs = curves_of(f)
        e = sorted([at(cs[0], 0)[0], at(cs[0], 1)[0]])
        check("K12 mirror curve about the YZ plane", near(e[0], (-40, 420, 5)) and near(e[1], (-10, 400, 0)), type=f.FeatureType, ends=[list(x) for x in e])

    recipe("K12", k12)

    def k13():
        target = nxh.line(part, (100, 400, 0), (160, 400, 0))
        bound = nxh.line(part, (140, 390, 0), (140, 410, 0))
        made = [k for k in dir(part.Features) if "TrimCurve" in k]
        res["api"]["TrimCurve.creators"] = made
        b = part.Features.CreateTrimCurve2FeatureBuilder(NXOpen.Features.TrimCurve2.Null)
        step = "api"
        try:
            api("TrimCurve2", b)
            try:
                step = "curve to trim"
                fill(b.CurveToTrim, [R.CreateRuleCurveDumb([target])], (155, 400, 0), target)
                step = "bounding object"
                bo = b.CreateTrimCurveBoundingObjectBuilder()
                api("TrimCurveBoundingObject", bo)
                bo.BoundingObjectList.Add(bound)
                b.BoundingObjectList.Append(bo)
                step = "regions"
                b.UpdateTrimRegionsAndDivideLocations()
                b.SelectTrimRegion(P(150, 400, 0))
                b.CurveOptions.Associative = True
                step = "commit"
                f = b.Commit()
            except Exception as e:  # noqa: BLE001
                raise RuntimeError(f"step {step}: {e}")
        finally:
            b.Destroy()
        cs = curves_of(f)
        check("K13 trim curve at a bounding curve", abs(total_length(cs) - 40) < 1e-4 or abs(total_length(cs) - 20) < 1e-4, type=f.FeatureType,
              length=total_length(cs), ends=[at(cs[0], 0)[0], at(cs[0], 1)[0]] if cs else None)

    recipe("K13", k13)

    # ---------------- K14 text on a cylindrical face (projected) and how to get solid letters
    def k14():
        TB = NXOpen.Features.TextBuilder
        top_edge = [e for e in cface.GetEdges() if abs(nxh.bbox(e)[2] - 40) < 1e-6][0]
        out = {}
        bot_edge = [e for e in cface.GetEdges() if abs(nxh.bbox(e)[2]) < 1e-6][0]

        def text_on_face(edge, offset, project, reverse):
            b = part.Features.CreateTextBuilder(NXOpen.Features.Text.Null)
            try:
                b.Type = TB.Types.OnFace
                b.Script = TB.ScriptOptions.Western
                b.SelectFont("Arial", TB.ScriptOptions.Western)
                b.TextString = "NX"
                b.PlacementFaces.ReplaceRules([R.CreateRuleFaceDumb([cface])], False)
                b.OnFacePlacementMethod = TB.OnFacePlacementMethodOptions.CurvesOnFaces
                fill(b.OnFacePlacementProfile, [R.CreateRuleEdgeDumb([edge])], at(edge, 0.1)[0], edge)
                b.FrameOnPath.AnchorLocation = NXOpen.GeometricUtilities.FrameOnPathBuilder.AnchorLocationType.Center
                b.FrameOnPath.AnchorPosition.IsPercentUsed = True
                b.FrameOnPath.AnchorPosition.Expression.RightHandSide = "25"
                b.FrameOnPath.Offset.RightHandSide = str(offset)
                b.FrameOnPath.Length.RightHandSide = "14"
                b.FrameOnPath.Height.RightHandSide = "8"
                b.FrameOnPath.IsApexReversed = reverse
                b.CanProjectCurves = project
                return b.Commit()
            finally:
                b.Destroy()

        f, tried = None, {}
        for label, args in (("top edge, offset 8", (top_edge, 8, True, False)), ("top edge, offset 8, reversed", (top_edge, 8, True, True)),
                            ("bottom edge, offset 8", (bot_edge, 8, True, False)), ("bottom edge, offset 8, reversed", (bot_edge, 8, True, True)),
                            ("top edge, offset -16", (top_edge, -16, True, False)), ("bottom edge, no project", (bot_edge, 8, False, False))):
            m = nxh.mark("k14 " + label, False)
            try:
                cand = text_on_face(*args)
                cc = curves_of(cand)
                zz = [at(c, t)[0][2] for c in cc for t in (0, 0.5, 1)]
                tried[label] = {"n": len(cc), "max_dev_from_cylinder": round(on_cyl(cc), 5), "z": [round(min(zz), 2), round(max(zz), 2)]}
                if args[2] and tried[label]["max_dev_from_cylinder"] < 0.02 and f is None:
                    f = cand
                    tried[label]["kept"] = True
                    continue
            except Exception as e:  # noqa: BLE001
                tried[label] = "ERR " + str(e)
            nxh.undo_to(m)
        out["variants"] = tried
        res["K14_detail"] = out
        if f is None:
            raise RuntimeError("no projected text variant worked: " + str(tried))
        cs = curves_of(f)
        dev = on_cyl(cs)
        zs = [at(c, t)[0][2] for c in cs for t in (0, 0.5, 1)]
        out["text_on_face"] = {"n": len(cs), "max_dev_from_cylinder": round(dev, 5), "z": [round(min(zs), 2), round(max(zs), 2)]}
        mid = at(cs[0], 0.5)[0]
        radial = (mid[0], mid[1] - 300, 0.0)
        nrm = math.hypot(radial[0], radial[1])
        radial = (radial[0] / nrm, radial[1] / nrm, 0.0)
        # (a) the course's attempt: extrude the projected (non-planar) outlines along the face normal
        m = nxh.mark("k14a", False)
        try:
            ex = nxh.extrude(part, nxh.section(part, rules=[R.CreateRuleCurveFeature([f])], help_point=mid), radial, 0, 1)
            bs = ex.GetBodies()
            out["extrude_projected_text"] = {"bodies": len(bs), "solid": [x.IsSolidBody for x in bs]}
        except Exception as e:  # noqa: BLE001
            out["extrude_projected_text"] = "ERR " + str(e)
        nxh.undo_to(m)
        # (b) what works: flat (un-projected) text outlines are planar closed loops -> solid prisms. Cut them deep,
        #     then unite a core cylinder of radius r - depth back in: the pocket floor is cylindrical, depth uniform.
        try:
            flat = text_on_face(bot_edge, 8, False, False)
            fc = curves_of(flat)
            fmid = at(fc[0], 0.5)[0]
            rad2 = (fmid[0], fmid[1] - 300, 0.0)
            n2 = math.hypot(rad2[0], rad2[1])
            rad2 = (rad2[0] / n2, rad2[1] / n2, 0.0)
            v0 = nxh.volume(part, cyl)
            nxh.extrude(part, nxh.section(part, rules=[R.CreateRuleCurveFeature([flat])], help_point=fmid), rad2, -3, 2, nxh.BOOL.Subtract, cyl)
            v1 = nxh.volume(part, cyl)
            nxh.cylinder(part, (0, 300, 0), (0, 0, 1), 2 * (15 - 0.6), 40, nxh.BOOL.Unite, cyl)
            v2 = nxh.volume(part, cyl)
            floors = nxh.faces(cyl, ftype=nxh.CYLINDER, radius=14.4)
            out["engrave_flat_text_then_core"] = {"cut_deep": round(v0 - v1, 3), "removed_final": round(v0 - v2, 3), "floor_faces_r14.4": len(floors),
                                                  "solids": len(nxh.solids(part)), "errors": nxh.feature_errors(part)}
        except Exception as e:  # noqa: BLE001
            out["engrave_flat_text_then_core"] = "ERR " + str(e)
        res["K14_detail"] = out
        check("K14a text on a cylindrical face with Project Curves lies on the face", len(cs) >= 2 and dev < 0.02, **out["text_on_face"])
        ex = out.get("extrude_projected_text")
        check("K14b extruding the projected (non-planar) text gives sheets, not solids (course failure reproduced)",
              isinstance(ex, dict) and ex["bodies"] >= 1 and not any(ex["solid"]), detail=ex)
        eng = out.get("engrave_flat_text_then_core")
        check("K14c uniform-depth engraving on the cylinder: flat text prisms subtracted, core cylinder united back",
              isinstance(eng, dict) and 0.5 < eng["removed_final"] < eng["cut_deep"] and eng["floor_faces_r14.4"] >= 1 and not eng["errors"], detail=eng)

    recipe("K14", k14)

    res["errors"] = nxh.feature_errors(part)
    res["features"] = [(f["ts"], f["type"], f["name"]) for f in nxh.feature_table(part)]
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res["result"] = "PASS" if res["checks"] and all(c["ok"] for c in res["checks"].values()) and "error" not in res else "FAIL"
nxh.write_json(os.path.join(OUT, "course_checks.json"), res)
