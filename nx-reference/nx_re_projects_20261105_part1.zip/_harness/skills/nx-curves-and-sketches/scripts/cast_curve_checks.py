"""Associative curve commands taught in Siemens' NX CAST 8.5 curve courses, measured on NX 2206 (headless).

  run_journal.ps1 -Script cast_curve_checks.py -WorkDir <out> -JArgs <out>

  C1  Join: Join Curves builder and Composite Curve join - General (exact) / Cubic / Quintic (approximate)
  C2  Bridge Curve shape control: continuity G1 / G2, tangent magnitude, conic (rho)
  C3  Project Curve: exact on a plane only; trimmed at the face boundary and at holes; along vector against
      along face normal; toward point / toward line / angle to vector / both sides; tolerance against poles
  C4  Intersection Curve of two datum planes (the NX 8.5 restriction is gone) and its associativity
  C5  associative Line tangent to two circles (all four solutions), limits; Arc through 2 points + radius
  C6  Point Set: part of a curve from the picked end, geometric progression
  C7  General Conic (anchor + rho, five points)
  C8  Isoparametric Curve options (U / V, number)
  C9  Isocline Curve (constant angle to a pull direction)
  C10 Trim Curve retried with a bounding plane and with points
[cast ecvb / ecvc / ecvd / ecve] = the CAST curve courses (rules in own words); numbers measured here.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])))
import curvekit as ck  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
ONLY = list(sys.argv[2:])
P, V, UPD = nxh.P, nxh.V, nxh.UPD
NF, NULL = nxh.NULL_FEATURE, NXOpen.NXObject.Null
GU, F = NXOpen.GeometricUtilities, NXOpen.Features
log = nxh.Log(os.path.join(OUT, "cast_curve_checks.log"))
chk = nxh.Check()
res = {"measured": {}, "not_working": {}, "api": {}}
M = res["measured"]
R = None


def block(name, fn, part):
    if ONLY and name not in ONLY:
        return
    m = nxh.mark("block " + name, False)
    try:
        fn(part)
        log("done", name)
    except Exception:  # noqa: BLE001
        err = traceback.format_exc()
        log("FAILED", name, err)
        chk.true(name + " ran to the end", False, err[-900:])
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass


def api(key, obj):
    cls = type(obj)
    out = {"class": cls.__name__}
    for n in dir(cls):
        if n.startswith("_") or n in ("Tag", "Null") or "Patch" in n or "ParentFeature" in n:
            continue
        a = getattr(cls, n, None)
        if isinstance(a, type):
            try:
                out[n] = "ENUM " + ", ".join(nxh.enum_names(a))
            except Exception:  # noqa: BLE001
                pass
        else:
            out[n] = ((a.__doc__ or "").strip().split("\n")[0])[:110]
    res["api"][key] = out


def rnd(v, n=4):
    return [round(x, n) for x in v]


# ------------------------------------------------------------------ C1 join
def c1(part):
    y = 0.0
    l1 = nxh.line(part, (0, y, 0), (20, y, 0))
    arc = nxh.arc(part, (20, y + 10, 0), (1, 0, 0), (0, 1, 0), 10.0, -math.pi / 2, 0.0)       # (20, y) -> (30, y + 10), centre (20, y + 10)
    l2 = nxh.line(part, (30, y + 10, 0), (30, y + 30, 0))
    chain = [l1, arc, l2]
    true_len = 20 + math.pi * 5 + 20

    def arc_dev(c):                                                                           # distance of the curve from the exact line-arc-line shape
        worst = 0.0
        for s in ck.sample(c, 300):
            x, yy = s["point"][0], s["point"][1] - y
            if x <= 20:
                d = abs(yy)
            elif yy >= 10:
                d = abs(x - 30)
            else:
                d = abs(math.hypot(x - 20, yy - 10) - 10)
            worst = max(worst, d)
        return worst

    def report(cs, z):
        r = {"curves": len(cs), "classes": sorted({type(c).__name__ for c in cs}), "length": round(sum(c.GetLength() for c in cs), 5)}
        if len(cs) == 1 and isinstance(cs[0], NXOpen.Spline):
            d = ck.spline_data(cs[0])
            r.update(degree=d["degree"], poles=d["poles"], segments=d["segments"], rational=d["rational"], max_dev=round(arc_dev(cs[0]), 6),
                     k_max=round(ck.curve_quality(cs[0])["k_max"], 5))
        e, err = nxh.attempt("sheet", lambda: nxh.extrude(part, nxh.section(part, curves=cs, help_point=(1, y, 0)), (0, 0, 1), z, z + 5, sheet=True), log=log)
        r["sheet_faces"] = ("error: " + err[:120]) if err else sum(len(b.GetFaces()) for b in e.GetBodies())
        return r

    rows = {}
    JB = F.JoinCurvesBuilder
    b0 = part.Features.CreateJoinCurvesBuilder(NF)
    api("JoinCurvesBuilder", b0)
    b0.Destroy()
    for i, kind in enumerate(("General", "Cubic", "Quintic", "Advanced")):
        def join(kind=kind):
            b = part.Features.CreateJoinCurvesBuilder(NF)
            try:
                ck.fill(b.Section, [R.CreateRuleCurveDumb(chain)], (1, y, 0), l1)
                b.OutputCurveType = getattr(JB.OutputCurve, kind)
                b.DistanceTolerance = 0.001
                b.AngleTolerance = 0.5
                b.CurveOptions.Associative = True
                b.CurveOptions.InputCurveOption = GU.CurveOptions.InputCurve.Retain
                return b.CommitFeature()
            finally:
                b.Destroy()
        f, err = nxh.attempt("join " + kind, join, log=log)
        if err:
            rows["Join Curves " + kind] = {"error": err[:200]}
            continue
        r = report(ck.curves_of(f), 10 + 10 * i)
        r["feature_type"] = f.FeatureType
        rows["Join Curves " + kind] = r
    CB = F.CompositeCurveBuilder
    for i, kind in enumerate(nxh.enum_names(CB.JoinMethod)):
        def comp(kind=kind):
            b = part.Features.CreateCompositeCurveBuilder(NF)
            try:
                ck.fill(b.Section, [R.CreateRuleCurveDumb(chain)], (1, y, 0), l1)
                b.Associative = True
                b.ParentPart = CB.PartType.WorkPart
                b.FixAtCurrentTimestamp = False
                b.JoinOption = getattr(CB.JoinMethod, kind)
                b.Tolerance = 0.001
                return b.Commit()
            finally:
                b.Destroy()
        f, err = nxh.attempt("composite " + kind, comp, log=log)
        rows["Composite Curve JoinMethod." + kind] = {"error": err[:200]} if err else report(ck.curves_of(f), 60 + 10 * i)
    M["C1 join line + R10 arc + line (true length %.5f)" % true_len] = rows
    g, c3, q5 = rows.get("Join Curves General", {}), rows.get("Join Curves Cubic", {}), rows.get("Join Curves Quintic", {})
    chk.true("C1 Join Curves builder still commits on NX 2206 (feature type recorded) and returns ONE curve for each output type",
             all(rows.get("Join Curves " + k, {}).get("curves") == 1 for k in ("General", "Cubic", "Quintic")), rows)
    chk.true("C1 General: ONE spline that reproduces the lines and the arc exactly (deviation < 1e-6, exact length)",
             g.get("max_dev", 1) < 1e-6 and abs(g.get("length", 0) - true_len) < 1e-5, g)
    chk.true("C1 Cubic / Quintic: approximations inside the tolerance 0.001 (deviation > 0, degree 3 / 5)",
             0 < c3.get("max_dev", 0) <= 0.0011 and c3.get("degree") == 3 and 0 < q5.get("max_dev", 0) <= 0.0011 and q5.get("degree") == 5, (c3, q5))
    cg = rows.get("Composite Curve JoinMethod.Genernal", {})
    chk.true("C1 Composite Curve JoinMethod.Genernal [sic] gives the same exact single curve", cg.get("curves") == 1 and cg.get("max_dev", 1) < 1e-6, cg)
    chk.true("C1 every joined curve sweeps ONE face (General too); the unjoined chain sweeps three",
             c3.get("sheet_faces") == 1 and q5.get("sheet_faces") == 1 and g.get("sheet_faces") == 1 and rows.get("Composite Curve JoinMethod.No", {}).get("sheet_faces") == 3,
             (g.get("sheet_faces"), c3.get("sheet_faces"), q5.get("sheet_faces")))
    chk.true("C1 General is a RATIONAL cubic with 10 poles; Cubic needs 23 poles and Quintic 21 for 0.001 - exact is also the lighter curve",
             g.get("rational") and g.get("poles", 99) < c3.get("poles", 0) and g.get("poles", 99) < q5.get("poles", 0), (g, c3, q5))
    adv = rows.get("Join Curves Advanced", {})
    chk.true("C1 Advanced with its default limits (one segment, degree 7) misses the chain by millimetres - set MaximumDegree / MaximumSegments or do not use it",
             adv.get("max_dev", 0) > 0.5, adv)


# ------------------------------------------------------------------ C2 bridge shape control
def c2(part):
    y = 120.0
    a1 = nxh.arc(part, (0, y, 0), (1, 0, 0), (0, 1, 0), 20.0, 0.0, math.pi / 2)                # ends (20, y) and (0, y + 20); bridged at (0, y + 20), tangent -X
    l2 = nxh.line(part, (-40, y + 10, 0), (-60, y - 10, 0))                                    # bridged at (-40, y + 10)
    BB = F.BridgeCurveBuilderEx
    CT = GU.Continuity.ContinuityTypes
    b0 = part.Features.CreateBridgeCurveBuilderEx(F.BridgeCurve.Null)
    api("BridgeCurveBuilderEx.TangentMagnitude", b0.TangentMagnitude)
    api("BridgeCurveBuilderEx.DepthSkew", b0.DepthSkew)
    b0.Destroy()

    def bridge(g0=CT.G1, g1=CT.G1, configure=None):
        b = part.Features.CreateBridgeCurveBuilderEx(F.BridgeCurve.Null)
        try:
            ck.fill(b.StartSection, [R.CreateRuleCurveDumb([a1])], (0.5, y + 20, 0), a1)
            ck.fill(b.EndSection, [R.CreateRuleCurveDumb([l2])], (-40.5, y + 9.5, 0), l2)
            b.StartConnectivity.Continuity.ContinuityType = g0
            b.EndConnectivity.Continuity.ContinuityType = g1
            if configure:
                configure(b)
            b.IsAssociative = True
            f = b.Commit()
        finally:
            b.Destroy()
        c = ck.curves_of(f)[0]
        s = ck.end_near(c, (0, y + 20, 0))
        q = ck.curve_quality(c)
        d = ck.spline_data(c) if isinstance(c, NXOpen.Spline) else {}
        return {"class": type(c).__name__, "degree": d.get("degree"), "poles": d.get("poles"), "length": round(q["length"], 4),
                "start_angle_deg": round(ck.join_angle(a1, 1.0, c, s), 4), "end_angle_deg": round(ck.join_angle(l2, 0.0, c, 1.0 - s), 4),
                "r_at_arc": round(ck.frame(c, s)["radius"], 3), "r_min": round(q["r_min"], 3) if q["r_min"] else None, "inflections": q["inflections"], "peaks": q["peaks"],
                "mid": rnd(ck.frame(c, 0.5)["point"][:2], 3)}

    rows = {}
    for label, kw in (("G0 / G0", dict(g0=CT.G0, g1=CT.G0)), ("G1 / G1", {}), ("G2 / G2", dict(g0=CT.G2, g1=CT.G2)), ("G2 / G1", dict(g0=CT.G2))):
        r, err = nxh.attempt(label, lambda kw=kw: bridge(**kw), log=log)
        rows[label] = r if r else {"error": err[:200]}

    for mag in (0.5, 1.0, 2.0):
        def cfg(b, mag=mag):
            b.ShapeControlMethod = BB.ShapeControlMethods.TangentMagnitude
            b.TangentMagnitude.StartTangentMagnitude.RightHandSide = str(mag)
            b.TangentMagnitude.EndTangentMagnitude.RightHandSide = str(mag)
        r, err = nxh.attempt("mag", lambda cfg=cfg: bridge(configure=cfg), log=log)
        rows["G1 / G1, tangent magnitude %s at both ends" % mag] = r if r else {"error": err[:200]}
    for rho in (0.3, 0.5, 0.7):
        def cfg(b, rho=rho):
            b.ShapeControlMethod = BB.ShapeControlMethods.Conic
            b.Rho.RightHandSide = str(rho)
        r, err = nxh.attempt("conic", lambda cfg=cfg: bridge(configure=cfg), log=log)
        rows["G1 / G1, conic rho %s" % rho] = r if r else {"error": err[:200]}
    M["C2 bridge from the end of an R20 arc to a line"] = rows
    g0, g1, g2 = rows["G0 / G0"], rows["G1 / G1"], rows["G2 / G2"]
    chk.true("C2 G0: a straight connection that is NOT tangent to its parents", g0.get("start_angle_deg", 0) > 1.0, g0)
    chk.true("C2 G1: tangent at both ends (0 deg), a degree-3 single segment with 4 poles; radius at the arc end is not the arc's",
             g1.get("start_angle_deg", 9) < 1e-2 and g1.get("end_angle_deg", 9) < 1e-2 and abs(g1.get("r_at_arc", 20) - 20) > 0.5 and (g1.get("degree"), g1.get("poles")) == (3, 4), g1)
    chk.true("C2 G2: tangent and radius 20 at the arc end; the degree goes up with the continuity", g2.get("start_angle_deg", 9) < 1e-2
             and abs(g2.get("r_at_arc", 0) - 20) < 0.01 and (g2.get("degree") or 0) > (g1.get("degree") or 9), (g1.get("degree"), g2))
    m05, m2 = rows["G1 / G1, tangent magnitude 0.5 at both ends"], rows["G1 / G1, tangent magnitude 2.0 at both ends"]
    m1 = rows["G1 / G1, tangent magnitude 1.0 at both ends"]
    chk.true("C2 tangent magnitude is a FACTOR here (1.0 = the default curve); 0.5 and 2.0 both stay G1 but have a much smaller minimum radius than 1.0",
             "error" not in m05 and "error" not in m2 and m1 == g1 and m05["r_min"] < 0.5 * m1["r_min"] and m2["r_min"] < 0.5 * m1["r_min"]
             and m05["start_angle_deg"] < 1e-2 and m2["start_angle_deg"] < 1e-2, (m05, m1, m2))
    chk.true("C2 G2 against a straight parent brings inflections (2 here): judge the bridge by curve_quality, not by the continuity setting", g2.get("inflections", 0) >= 1, g2)
    con = [rows["G1 / G1, conic rho %s" % r] for r in (0.3, 0.5, 0.7)]
    chk.true("C2 conic shape control: still G1; a larger rho pulls the middle of the bridge towards the apex (the mid point moves)",
             all("error" not in c and c["start_angle_deg"] < 1e-2 for c in con) and len({tuple(c["mid"]) for c in con}) == 3, con)


# ------------------------------------------------------------------ C3 project
def project(part, curves, faces=None, plane=None, method="AlongVector", vec=(0, 0, -1), tol=0.01, configure=None, rules=None):
    PB = F.ProjectCurveBuilder
    b = part.Features.CreateProjectCurveBuilder(NF)
    try:
        b.Tolerance = tol
        ck.fill(b.SectionToProject, rules or [R.CreateRuleCurveDumb(list(curves))], (0, 0, 0), types=NXOpen.Section.AllowTypes.CurvesAndPoints)
        if faces:
            b.FaceToProjectTo.Add(nxh.collector(part, faces=list(faces)))
        if plane is not None:
            b.PlaneToProjectTo = plane
        b.ProjectionDirectionMethod = getattr(PB.DirectionType, method)
        if method in ("AlongVector", "AngleToVector"):
            b.ProjectionVector = nxh.direction(part, vec)
        if configure:
            configure(b)
        b.InputCurvesOption.Associative = True
        f = b.Commit()
    finally:
        b.Destroy()
    return f


def c3(part):
    x0, y = 300.0, 0.0
    PB = F.ProjectCurveBuilder
    rows = {}
    # (a) exact on a plane only
    src = nxh.arc(part, (x0, y, 30), (1, 0, 0), (0, 1, 0), 20.0, 0.0, math.pi / 2)
    pl_xy = part.Planes.CreatePlane(P(0, 0, 0), V(0, 0, 1), UPD)
    tilt = math.radians(20)
    pl_tilt = part.Planes.CreatePlane(P(x0, y, 0), V(-math.sin(tilt), 0, math.cos(tilt)), UPD)
    _fc, cyl = nxh.cylinder(part, (x0, y - 10, -45), (0, 1, 0), 100, 50)                          # R50 cylinder, axis along Y, under the arc
    cface = nxh.one(nxh.faces(cyl, ftype=nxh.CYLINDER), "cyl")
    for label, kw in (("onto the XY plane, along -Z", dict(plane=pl_xy)), ("onto a plane tilted 20 deg, along -Z", dict(plane=pl_tilt)),
                      ("onto an R50 cylinder, along -Z, tol 0.01", dict(faces=[cface])), ("onto an R50 cylinder, along -Z, tol 0.001", dict(faces=[cface], tol=0.001)),
                      ("onto an R50 cylinder, along -Z, tol 0.0001", dict(faces=[cface], tol=0.0001)),
                      ("onto an R50 cylinder, along face normal, tol 0.01", dict(faces=[cface], method="AlongFaceNormal"))):
        f, err = nxh.attempt(label, lambda kw=kw: project(part, [src], **kw), log=log)
        if err:
            rows[label] = {"error": err[:200]}
            continue
        cs = ck.curves_of(f)
        r = {"curves": len(cs), "class": type(cs[0]).__name__, "length": round(sum(c.GetLength() for c in cs), 5)}
        if isinstance(cs[0], NXOpen.Spline):
            d = ck.spline_data(cs[0])
            r.update(degree=d["degree"], poles=d["poles"])
            if "cylinder" in label:
                r["max_dist_from_face"] = round(max(nxh.dist_to(part, cface, s["point"]) for s in ck.sample(cs[0], 40)), 6)
                if "along -Z" in label:                                                           # x, y must stay on the source circle
                    r["max_dev_in_plan"] = round(max(abs(math.hypot(s["point"][0] - x0, s["point"][1] - y) - 20.0) for s in ck.sample(cs[0], 40)), 6)
        if isinstance(cs[0], NXOpen.Arc):
            r["radius"] = round(cs[0].Radius, 6)
        rows[label] = r
    M["C3a R20 arc projected"] = rows
    a, t, c01, c0001 = rows["onto the XY plane, along -Z"], rows["onto a plane tilted 20 deg, along -Z"], rows["onto an R50 cylinder, along -Z, tol 0.01"], rows["onto an R50 cylinder, along -Z, tol 0.0001"]
    chk.true("C3 onto a plane square to the direction: the arc stays an Arc of radius 20 (exact)", a.get("class") == "Arc" and abs(a.get("radius", 0) - 20) < 1e-9, a)
    chk.true("C3 onto a tilted plane: class recorded (exact conic or spline), longer than the source", t.get("length", 0) > src.GetLength(), t)
    chk.true("C3 onto a curved face: a Spline inside the tolerance - an approximation", c01.get("class") == "Spline" and c01.get("max_dist_from_face", 1) <= 0.01
             and c01.get("max_dev_in_plan", 1) <= 0.01, c01)
    chk.true("C3 tolerance 0.01 -> 0.0001 on the same projection: more poles (the cost of a tight tolerance)", c0001.get("poles", 0) > c01.get("poles", 99), (c01, c0001))
    nrm, vec = rows["onto an R50 cylinder, along face normal, tol 0.01"], c01
    chk.true("C3 Along Face Normal and Along Vector give DIFFERENT curves on the same face (lengths differ)", "error" not in nrm and abs(nrm["length"] - vec["length"]) > 0.01, (nrm, vec))

    # (b) trimmed at the face boundary and at holes
    _fb, body = nxh.block(part, (x0 + 100, y, 0), (60, 40, 10))
    nxh.cylinder(part, (x0 + 130, y + 20, -1), (0, 0, 1), 10, 12, nxh.BOOL.Subtract, body)
    top = nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1)), "top")
    ln = nxh.line(part, (x0 + 90, y + 20, 30), (x0 + 170, y + 20, 30))                           # 80 long, over the hole centre, longer than the face
    rows = {}
    for label, kw in (("onto the block top with a d10 hole", dict(faces=[top])), ("onto the plane z = 0", dict(plane=pl_xy))):
        f = project(part, [ln], **kw)
        cs = ck.curves_of(f)
        rows[label] = {"curves": len(cs), "length": round(sum(c.GetLength() for c in cs), 5), "x_ranges": sorted(rnd(sorted([ck.frame(c, 0)["point"][0] - x0, ck.frame(c, 1)["point"][0] - x0]), 3) for c in cs)}
    M["C3b 80 mm line projected along -Z"] = rows
    r = rows["onto the block top with a d10 hole"]
    chk.true("C3 a projection onto a FACE is cut at the boundary and at holes: 80 mm line -> 2 curves, 50 in total", r["curves"] == 2 and abs(r["length"] - 50.0) < 1e-6, r)
    chk.true("C3 the same line onto a PLANE: 1 curve of 80", rows["onto the plane z = 0"]["curves"] == 1 and abs(rows["onto the plane z = 0"]["length"] - 80.0) < 1e-6, rows["onto the plane z = 0"])

    # (c) the other directions
    circ = nxh.arc(part, (x0 + 250, y, 50), (1, 0, 0), (0, 1, 0), 10.0, 0.0, 2 * math.pi)
    rows = {}

    def diam(f):
        xs = [s["point"][0] for c in ck.curves_of(f) for s in ck.sample(c, 80)]
        return round(max(xs) - min(xs), 4)
    f, err = nxh.attempt("along", lambda: project(part, [circ], plane=pl_xy), log=log)
    rows["d20 circle at z 50 onto z 0, Along Vector -Z"] = {"error": err[:160]} if err else {"diameter": diam(f), "class": type(ck.curves_of(f)[0]).__name__}
    for ang in ("20", "-20"):
        f, err = nxh.attempt("angle", lambda ang=ang: project(part, [circ], plane=pl_xy, method="AngleToVector",
                                                             configure=lambda b: setattr(b.AngleToProjectionVector, "RightHandSide", ang)), log=log)
        rows["... Angle to Vector %s deg" % ang] = {"error": err[:160]} if err else {"diameter": diam(f), "class": type(ck.curves_of(f)[0]).__name__}
    f, err = nxh.attempt("point", lambda: project(part, [circ], plane=pl_xy, method="TowardPoint",
                                                  configure=lambda b: setattr(b, "PointToProjectToward", nxh.point(part, x0 + 250, y, 100))), log=log)
    rows["... Toward Point, point ABOVE the circle (away from the plane)"] = {"error": err[:160]} if err else {"diameter": diam(f), "class": type(ck.curves_of(f)[0]).__name__}
    f, err = nxh.attempt("point", lambda: project(part, [circ], plane=pl_xy, method="TowardPoint",
                                                  configure=lambda b: setattr(b, "PointToProjectToward", nxh.point(part, x0 + 250, y, -50))), log=log)
    rows["... Toward Point, point 50 BELOW the plane"] = {"error": err[:160]} if err else {"diameter": diam(f), "class": type(ck.curves_of(f)[0]).__name__}
    # toward line: a line 40 off the axis of a d60 cylinder, projected radially onto it
    _fc2, c2_ = nxh.cylinder(part, (x0 + 350, y, 0), (0, 0, 1), 60, 40)
    cf = nxh.one(nxh.faces(c2_, ftype=nxh.CYLINDER), "cyl2")
    ax = nxh.line(part, (x0 + 350, y, -10), (x0 + 350, y, 60))
    src2 = nxh.line(part, (x0 + 390, y - 10, 5), (x0 + 390, y + 10, 35))

    def tl(b):
        b.LineToProjectToward.Value = ax
    f, err = nxh.attempt("line", lambda: project(part, [src2], faces=[cf], method="TowardLine", configure=tl), log=log)
    if err:
        rows["Toward Line (the cylinder axis) onto a d60 cylinder"] = {"error": err[:200]}
    else:
        cs = ck.curves_of(f)
        rr = [math.hypot(s["point"][0] - (x0 + 350), s["point"][1] - y) for c in cs for s in ck.sample(c, 20)]
        zz = [s["point"][2] for c in cs for s in ck.sample(c, 20)]
        rows["Toward Line (the cylinder axis) onto a d60 cylinder"] = {"curves": len(cs), "radius_range": rnd([min(rr), max(rr)]), "z_range": rnd([min(zz), max(zz)], 3)}
    # both sides: a line between two parallel faces of a U block
    f, err = nxh.attempt("both", lambda: project(part, [ln], faces=[top, nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, -1)), "bottom")], vec=(0, 0, 1),
                                                 configure=lambda b: setattr(b, "ProjectionOption", PB.ProjectionOptionType.ProjectBothSides)), log=log)
    one_side, err1 = nxh.attempt("one", lambda: project(part, [ln], faces=[top, nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, -1)), "bottom")], vec=(0, 0, 1)), log=log)
    rows["line at z 30 onto top (z 10) and bottom (z 0) faces, vector +Z"] = {
        "one side": {"error": err1[:160]} if err1 else {"curves": len(ck.curves_of(one_side))},
        "ProjectBothSides": {"error": err[:160]} if err else {"curves": len(ck.curves_of(f)), "z": sorted({round(ck.frame(c, 0)["point"][2], 3) for c in ck.curves_of(f)})}}
    M["C3c other directions"] = rows
    a0 = rows["d20 circle at z 50 onto z 0, Along Vector -Z"]
    ap, am = rows["... Angle to Vector 20 deg"], rows["... Angle to Vector -20 deg"]
    want = 20 + 2 * 50 * math.tan(math.radians(20))
    chk("C3 Along Vector: the circle keeps its diameter 20", a0.get("diameter"), 20.0, 1e-3)
    chk.true("C3 Angle to Vector 20 deg over a height of 50: diameter %.2f for one sign (flared outward)" % want,
             any(abs(v.get("diameter", 0) - want) < 0.05 for v in (ap, am)), (ap, am))
    tp = rows["... Toward Point, point 50 BELOW the plane"]
    chk("C3 Toward Point = every point moves TOWARD the point: circle d20 at z 50, point at z -50, plane z 0 -> diameter 10", tp.get("diameter"), 10.0, 0.01)
    chk.true("C3 ... with the point on the far side of the curve nothing is hit: 'No curve projected.'",
             "error" in rows["... Toward Point, point ABOVE the circle (away from the plane)"], rows["... Toward Point, point ABOVE the circle (away from the plane)"])
    chk.true("C3 Along Vector onto a CLOSED face returns the near and the far side: 2 curves on the full cylinder", c01.get("curves") == 2, c01)
    tl_ = rows["Toward Line (the cylinder axis) onto a d60 cylinder"]
    chk.true("C3 Toward Line: every point moves square to the axis onto the face (radius 30, heights kept 5 .. 35)",
             "error" not in tl_ and abs(tl_["radius_range"][0] - 30) < 0.01 and abs(tl_["radius_range"][1] - 30) < 0.01 and abs(tl_["z_range"][0] - 5) < 0.01
             and abs(tl_["z_range"][1] - 35) < 0.01, tl_)
    bs = rows["line at z 30 onto top (z 10) and bottom (z 0) faces, vector +Z"]
    chk.true("C3 Along Vector only looks ALONG the vector ('No curve projected.' when the faces lie behind it); Project Both Sides reaches them (4 curves at z 0 and 10)",
             "error" in bs["one side"] and bs["ProjectBothSides"].get("curves") == 4, bs)


# ------------------------------------------------------------------ C4 intersection of two datum planes
def c4(part):
    dat = nxh.Datums(part)
    nxh.expr(part, "c4_z", 12)
    _fz, pz = nxf.datum_plane(part, "offset", [dat.xy], "c4_z", name="PL_C4_Z")
    _fy, py = nxf.datum_plane(part, "offset", [dat.xz], "30", name="PL_C4_Y")

    def inter():
        b = part.Features.CreateIntersectionCurveBuilder(NF)
        try:
            b.Tolerance = 0.01
            b.FirstFace.ReplaceRules([R.CreateRuleFaceDatum([pz])], False)
            b.SecondFace.ReplaceRules([R.CreateRuleFaceDatum([py])], False)
            b.Associative = True
            return b.Commit()
        finally:
            b.Destroy()
    before = {c.Tag for c in part.Curves}
    n_feat = len(list(part.Features.GetFeatures()))
    f, err = nxh.attempt("plane x plane", inter, log=log)
    if err:
        M["C4 datum plane x datum plane"] = {"error": err[:300]}
        res["not_working"]["C4 intersection curve of two datum planes"] = err[:300]
        chk.true("C4 Intersection Curve of two datum planes commits", False, err[:200])
        return
    new = [c for c in part.Curves if c.Tag not in before]
    feats = list(part.Features.GetFeatures())
    is_feature = len(feats) > n_feat
    r = {"commit_returned": type(f).__name__, "new_features": [x.FeatureType for x in feats[n_feat:]], "new_curves": [type(c).__name__ for c in new]}
    if new:
        p0 = ck.frame(new[0], 0.5)["point"]
        nxh.set_expr(part, "c4_z", 20)
        nxh.update()
        cur = ck.curves_of(feats[n_feat])[0] if is_feature and ck.curves_of(feats[n_feat]) else new[0]
        p1 = ck.frame(cur, 0.5)["point"]
        r.update(before_yz=rnd(p0[1:], 3), after_yz=rnd(p1[1:], 3), follows=abs(p1[2] - 20) < 1e-6, errors=nxh.feature_errors(part))
    M["C4 datum plane x datum plane"] = r
    chk.true("C4 Intersection Curve of two DATUM PLANES commits on NX 2206 and gives a line at y 30, z 12 (the NX 8.5 text asked for a body or face)",
             len(new) == 1 and r["new_curves"] == ["Line"] and abs(abs(r["before_yz"][0]) - 30) < 1e-6 and abs(r["before_yz"][1] - 12) < 1e-6, r)
    chk.true("C4 ... whether that line is a feature that follows the plane (12 -> 20) is recorded: follows=%s, feature=%s" % (r.get("follows"), is_feature), True, r)


# ------------------------------------------------------------------ C5 tangent lines, arc by 2 points + radius
def assoc_circle(part, centre, radius, plane):
    AB = F.AssociativeArcBuilder
    b = part.BaseFeatures.CreateAssociativeArcBuilder(F.AssociativeArc.Null)
    try:
        b.Type = AB.Types.ArcFromCenter
        b.CenterPoint.Value = nxh.point(part, *centre)
        b.EndPointOptions = AB.EndOption.Radius
        b.Radius.RightHandSide = str(radius)
        b.SupportPlaneData.SupportPlane = plane
        b.Limits.FullCircle = True
        b.Associative = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, ck.curves_of(f)[0]


def c5(part):
    y = 300.0
    pl = part.Planes.CreatePlane(P(0, 0, 0), V(0, 0, 1), UPD)
    nxh.expr(part, "c5_r1", 30)
    _f1, c1_ = assoc_circle(part, (0, y, 0), "c5_r1", pl)
    _f2, c2_ = assoc_circle(part, (100, y, 0), 15, pl)
    LB = F.AssociativeLineBuilder
    view = part.ModelingViews.WorkView
    rows = {}

    def tan_line(h1, h2, limits=None):
        b = part.BaseFeatures.CreateAssociativeLineBuilder(F.AssociativeLine.Null)
        try:
            b.StartPointOptions = LB.StartOption.Tangent
            b.StartTangent.SetValue(c1_, view, P(*h1))
            b.EndPointOptions = LB.EndOption.Tangent
            b.EndTangent.SetValue(c2_, view, P(*h2))
            if limits:
                LO = GU.CurveExtendData.LimitOptions
                b.Limits.StartLimit.LimitOption = LO.Value
                b.Limits.StartLimit.Distance.RightHandSide = str(limits[0])
                b.Limits.EndLimit.LimitOption = LO.Value
                b.Limits.EndLimit.Distance.RightHandSide = str(limits[1])
            b.Associative = True
            f = b.CommitFeature()
        finally:
            b.Destroy()
        return f

    def measure(f, r1=30.0):
        ln = ck.curves_of(f)[0]
        a, b_ = ck.frame(ln, 0)["point"], ck.frame(ln, 1)["point"]
        d = ck.unit(ck.sub(b_, a))
        # distance of the infinite line from the two centres must equal the radii
        def dist(c):
            v = ck.sub(c, a)
            return abs(v[0] * d[1] - v[1] * d[0])
        return {"start": rnd(a[:2], 3), "end": rnd(b_[:2], 3), "length": round(ln.GetLength(), 4), "dist_from_centre_1": round(dist((0, y, 0)), 5),
                "dist_from_centre_2": round(dist((100, y, 0)), 5), "start_on_circle_1": round(abs(math.hypot(a[0], a[1] - y) - r1), 5),
                "end_on_circle_2": round(abs(math.hypot(b_[0] - 100, b_[1] - y) - 15), 5)}

    feats = {}
    for label, h1, h2 in (("outer, above", (0, y + 30, 0), (100, y + 15, 0)), ("outer, below", (0, y - 30, 0), (100, y - 15, 0)),
                          ("inner, above -> below", (10, y + 28, 0), (90, y - 11, 0)), ("inner, below -> above", (10, y - 28, 0), (90, y + 11, 0))):
        f, err = nxh.attempt(label, lambda h1=h1, h2=h2: tan_line(h1, h2), log=log)
        rows[label] = {"error": err[:200]} if err else measure(f)
        feats[label] = f
    ok = {k: v for k, v in rows.items() if "error" not in v}
    distinct = {(tuple(v["start"]), tuple(v["end"])) for v in ok.values()}
    M["C5 line tangent to two circles (R30 at x 0, R15 at x 100)"] = rows
    chk.true("C5 associative Line, Tangent at both ends: tangent to both circles (centre distance = radius) with its ends ON the circles",
             len(ok) >= 1 and all(abs(v["dist_from_centre_1"] - 30) < 1e-4 and abs(v["dist_from_centre_2"] - 15) < 1e-4 and v["start_on_circle_1"] < 1e-4
                                  and v["end_on_circle_2"] < 1e-4 for v in ok.values()), rows)
    chk.true("C5 the help point of each tangency picks the solution: 4 different common tangents from 4 pairs of help points", len(distinct) == 4, sorted(distinct))
    # edit a parent radius: the tangent line follows
    nxh.set_expr(part, "c5_r1", 40)
    nxh.update()
    f = feats.get("outer, above")
    if f is not None:
        r = measure(f, 40.0)
        r["errors"] = nxh.feature_errors(part)
        rows["outer, above after R30 -> R40"] = r
        chk.true("C5 ... and follows its parents: R30 -> R40, still tangent, end still on the circle",
                 abs(r["dist_from_centre_1"] - 40) < 1e-4 and r["start_on_circle_1"] < 1e-4 and not r["errors"], r)
    nxh.set_expr(part, "c5_r1", 30)
    nxh.update()
    f, err = nxh.attempt("limits", lambda: tan_line((0, y + 30, 0), (100, y + 15, 0), limits=(-20, 150)), log=log)
    if err:
        rows["outer, above with limits -20 / 150"] = {"error": err[:200]}
    else:
        r = measure(f)
        rows["outer, above with limits -20 / 150"] = r
        chk.true("C5 limit values on a tangent-tangent line: start limit -20 and end limit 150 are measured from the START tangent point - the line is 170 long, "
                 "still on the common tangent, and no longer ends on the circles",
                 abs(r["length"] - 170.0) < 1e-3 and abs(r["dist_from_centre_1"] - 30) < 1e-4 and abs(r["dist_from_centre_2"] - 15) < 1e-4, r)

    # arc through two points with a radius: the three-point type with Radius as the middle condition
    AB = F.AssociativeArcBuilder
    z = 10.0
    pl10 = part.Planes.CreatePlane(P(0, 0, z), V(0, 0, 1), UPD)
    arcs = {}
    for label, zone, comp in (("zone point above the chord", (0, y + 150, z), False), ("zone point below the chord", (0, y + 50, z), False),
                              ("zone point above the chord + Limits.ComplementArc()", (0, y + 150, z), True)):
        def arc(zone=zone, comp=comp):
            b = part.BaseFeatures.CreateAssociativeArcBuilder(F.AssociativeArc.Null)
            try:
                b.Type = AB.Types.ThreePointArc
                b.StartPointOptions = AB.StartOption.Point
                b.StartPoint.Value = nxh.point(part, -40, y + 100, z)
                b.EndPointOptions = AB.EndOption.Point
                b.EndPoint.Value = nxh.point(part, 40, y + 100, z)
                b.MidPointOptions = AB.MidOption.Radius
                b.Radius.RightHandSide = "200"
                b.SupportPlaneData.SupportPlane = pl10
                b.ZonePoint = P(*zone)
                b.Limits.FullCircle = False
                if comp:
                    b.Limits.ComplementArc()
                b.Associative = True
                return b.CommitFeature()
            finally:
                b.Destroy()
        f, err = nxh.attempt(label, arc, log=log)
        if err:
            arcs[label] = {"error": err[:200]}
            continue
        c = ck.curves_of(f)[0]
        arcs[label] = {"radius": round(c.Radius, 4), "length": round(c.GetLength(), 4), "centre_y": round(c.CenterPoint.Y - y, 3),
                       "ends": sorted([rnd(ck.frame(c, 0)["point"], 3), rnd(ck.frame(c, 1)["point"], 3)]), "mid_y": round(ck.frame(c, 0.5)["point"][1] - y, 3),
                       "planarity_z": round(max(abs(s["point"][2] - z) for s in ck.sample(c, 10)), 6)}
    minor = 2 * 200 * math.asin(40 / 200.0)
    M["C5 arc through (-40, y+100) and (40, y+100), radius 200 (minor arc %.4f, complement %.4f)" % (minor, 2 * math.pi * 200 - minor)] = arcs
    oka = [v for v in arcs.values() if "error" not in v]
    chk.true("C5 three-point Arc with MidOption.Radius = 'two points + radius': radius 200, ends on the two points, in the support plane",
             len(oka) >= 1 and all(abs(v["radius"] - 200) < 1e-6 and v["planarity_z"] < 1e-9 and v["ends"][0][0] == -40.0 and v["ends"][1][0] == 40.0 for v in oka), arcs)
    chk.true("C5 ZonePoint picks the side of the chord the CENTRE lies on (centre above / below)", len({v["centre_y"] > 100 for v in oka}) == 2, arcs)
    lens = sorted({round(v["length"], 3) for v in oka})
    chk.true("C5 which part of the circle comes out is checked by the length: minor arc %.3f or its complement %.3f; Limits.ComplementArc() swaps them" % (minor, 2 * math.pi * 200 - minor),
             all(abs(v - minor) < 1e-2 or abs(v - (2 * math.pi * 200 - minor)) < 1e-2 for v in lens) and len(lens) == 2, (lens, arcs))


# ------------------------------------------------------------------ C6 point set
def c6(part):
    y = 520.0
    ln = nxh.line(part, (0, y, 0), (60, y, 0))
    PS = F.PointSetBuilder
    rows = {}

    def pset(hp, configure):
        b = part.Features.CreatePointSetBuilder(F.PointSet.Null)
        try:
            b.Type = PS.Types.CurvePoints
            ck.fill(b.SingleCurveOrEdgeCollector, [R.CreateRuleCurveDumb([ln])], hp, ln)
            configure(b)
            b.Associative = True
            f = b.Commit()
        finally:
            b.Destroy()
        return sorted(round(p.Coordinates.X, 4) for p in f.GetEntities() if isinstance(p, NXOpen.Point))

    def part_range(b):
        b.CurvePointsBy = PS.CurvePointsType.EqualArcLength
        b.NumberOfPointsExpression.RightHandSide = "5"
        b.StartPercentage.RightHandSide = "10"
        b.EndPercentage.RightHandSide = "75"
    for label, hp in (("help point at the x = 0 end", (1, y, 0)), ("help point at the x = 60 end", (59, y, 0))):
        r, err = nxh.attempt(label, lambda hp=hp: pset(hp, part_range), log=log)
        rows["5 points from 10 % to 75 %, " + label] = r if r else {"error": err[:200]}

    def prog(b):
        b.CurvePointsBy = PS.CurvePointsType.GeometricProgression
        b.NumberOfPointsExpression.RightHandSide = "5"
        b.StartPercentage.RightHandSide = "0"
        b.EndPercentage.RightHandSide = "100"
        b.Ratio.RightHandSide = "1.5"
    r, err = nxh.attempt("progression", lambda: pset((1, y, 0), prog), log=log)
    rows["geometric progression, ratio 1.5, 5 points"] = r if r else {"error": err[:200]}
    M["C6 point set on a 60 mm line"] = rows
    a, b_ = rows["5 points from 10 % to 75 %, help point at the x = 0 end"], rows["5 points from 10 % to 75 %, help point at the x = 60 end"]
    chk.true("C6 percent range is counted from the section START (the end nearest the help point): 6 .. 45 from one end, 15 .. 54 from the other",
             isinstance(a, list) and isinstance(b_, list) and a == [6.0, 15.75, 25.5, 35.25, 45.0] and b_ == [15.0, 24.75, 34.5, 44.25, 54.0], (a, b_))
    g = rows["geometric progression, ratio 1.5, 5 points"]
    if isinstance(g, list) and len(g) == 5:
        gaps = [g[i + 1] - g[i] for i in range(4)]
        ratios = [round(gaps[i + 1] / gaps[i], 4) for i in range(3)]
        rows["geometric progression gaps"] = {"gaps": rnd(gaps), "ratios": ratios}
        chk.true("C6 Geometric Progression: every gap is 1.5 x the one before", all(abs(r - 1.5) < 1e-3 for r in ratios), rows["geometric progression gaps"])
    else:
        chk.true("C6 Geometric Progression commits", False, g)


# ------------------------------------------------------------------ C7 general conic
def c7(part):
    y = 600.0
    GB = F.GeneralConicBuilder
    rows = {}

    def conic(configure):
        b = part.Features.CreateGeneralConicBuilder(F.GeneralConic.Null)
        try:
            configure(b)
            b.AssociativeToggle = True
            f = b.CommitFeature()
        finally:
            b.Destroy()
        return f

    s, e, a = (0, y, 0), (60, y, 0), (30, y + 40, 0)
    for rho in (0.3, 0.5, 0.75):
        def cfg(b, rho=rho):
            b.Type = GB.Types.TwoPointsAnchorRho
            b.StartPoint = nxh.point(part, *s)
            b.EndPoint = nxh.point(part, *e)
            b.AnchorPoint = nxh.point(part, *a)
            b.RhoValue = rho
        f, err = nxh.attempt("rho", lambda cfg=cfg: conic(cfg), log=log)
        if err:
            rows["2 points + anchor + rho %s" % rho] = {"error": err[:200]}
            continue
        c = ck.curves_of(f)[0]
        top = max(sm["point"][1] for sm in ck.sample(c, 200)) - y
        rows["2 points + anchor + rho %s" % rho] = {"feature_type": f.FeatureType, "class": type(c).__name__, "shoulder_height": round(top, 4), "expected": round(rho * 40, 4),
                                                    "start_tangent_to_anchor_deg": round(ck.angle(ck.frame(c, ck.end_near(c, s))["tangent"], ck.sub(a, s)) % 180, 3),
                                                    "inflections": ck.curve_quality(c)["inflections"]}
    # five points on an ellipse 40 x 20
    pts = [(40 * math.cos(t), y + 100 + 20 * math.sin(t), 0) for t in (0.2, 0.8, 1.5, 2.2, 2.9)]

    def cfg5(b):
        b.Type = GB.Types.FivePoints
        b.StartPoint = nxh.point(part, *pts[0])
        b.InteriorPoint1 = nxh.point(part, *pts[1])
        b.InteriorPoint2 = nxh.point(part, *pts[2])
        b.InteriorPoint3 = nxh.point(part, *pts[3])
        b.EndPoint = nxh.point(part, *pts[4])
    f, err = nxh.attempt("five", lambda: conic(cfg5), log=log)
    if err:
        rows["five points on an ellipse 40 x 20"] = {"error": err[:200]}
    else:
        c = ck.curves_of(f)[0]
        dev = max(abs((sm["point"][0] / 40.0) ** 2 + ((sm["point"][1] - y - 100) / 20.0) ** 2 - 1.0) for sm in ck.sample(c, 100))
        rows["five points on an ellipse 40 x 20"] = {"class": type(c).__name__, "max_dev_of_ellipse_equation": round(dev, 9)}
    M["C7 general conic"] = rows
    ok = [rows["2 points + anchor + rho %s" % r] for r in (0.3, 0.5, 0.75)]
    chk.true("C7 General Conic by two points, anchor and rho: the shoulder sits at rho x the anchor height (12 / 20 / 30 of 40), end tangents aim at the anchor",
             all("error" not in v and abs(v["shoulder_height"] - v["expected"]) < 0.01 and min(v["start_tangent_to_anchor_deg"], 180 - v["start_tangent_to_anchor_deg"]) < 0.01
                 and v["inflections"] == 0 for v in ok), ok)
    f5 = rows["five points on an ellipse 40 x 20"]
    chk.true("C7 General Conic through five points of an ellipse: the exact ellipse (equation residual < 1e-6)", f5.get("max_dev_of_ellipse_equation", 1) < 1e-6, f5)


# ------------------------------------------------------------------ C8 isoparametric
def c8(part):
    _fc, cyl = nxh.cylinder(part, (0, 800, 0), (0, 0, 1), 30, 40)
    face = nxh.one(nxh.faces(cyl, ftype=nxh.CYLINDER), "cyl")
    IB = F.IsoparametricCurvesBuilder
    rows = {}
    for d in nxh.enum_names(IB.DirectionTypes):
        def iso(d=d):
            b = part.Features.CreateIsoparametricCurvesBuilder(F.IsoparametricCurves.Null)
            try:
                b.SelectObject.Value = face
                b.Direction = getattr(IB.DirectionTypes, d)
                b.Placement = IB.PlacementTypes.Uniform
                b.Number = 4
                b.Associative = True
                return b.Commit()
            finally:
                b.Destroy()
        f, err = nxh.attempt(d, iso, log=log)
        if err:
            rows[d] = {"error": err[:200]}
            continue
        cs = ck.curves_of(f)
        rows[d] = {"curves": len(cs), "classes": sorted({type(c).__name__ for c in cs}), "lengths": sorted({round(c.GetLength(), 3) for c in cs})}
    M["C8 isoparametric curves on a d30 x 40 cylinder, Number 4"] = rows
    u, v = rows.get("IsoU", {}), rows.get("IsoV", {})
    kinds = {tuple(u.get("lengths", [])), tuple(v.get("lengths", []))}
    chk.true("C8 Direction IsoU / IsoV with Number 4: one gives straight generators (40), the other circles (94.248)",
             (40.0,) in kinds and (round(math.pi * 30, 3),) in kinds, rows)


# ------------------------------------------------------------------ C9 isocline
def c9(part):
    found = {}
    # pure reflection over the NXOpen classes (touching every property of the session crashes NX)
    for mod in (NXOpen, NXOpen.Features, NXOpen.GeometricUtilities):
        for cname in dir(mod):
            cls = getattr(mod, cname, None)
            if not isinstance(cls, type):
                continue
            for n in dir(cls):
                if n.startswith("Create") and ("Isocline" in n or "ShadowCurve" in n):
                    found["%s.%s" % (cname, n)] = (getattr(cls, n).__doc__ or "").strip().split("\n")[0][:120]
    res["api"]["Isocline creators"] = found
    _fb, body = nxh.block(part, (-20, 900, 0), (40, 40, 10))
    # a dome: revolve a quarter circle R20 about Z on top of the block is heavier than needed - blend the top edges instead
    top = nxh.one(nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1)), "top")
    nxh.blend(part, list(top.GetEdges()), 8)
    blends = [f for f in body.GetFaces() if nxh.face_data(f)[0] not in (nxh.PLANE,)]
    rows = {"creators": found, "blend_faces": len(blends)}
    owner = {"FeatureCollection": part.Features, "CurveCollection": part.Curves, "BaseFeatureCollection": part.BaseFeatures,
             "FreeformCurveCollection": getattr(part.Features, "FreeformCurveCollection", None), "Part": part}
    coll = None
    for key in found:
        cname, meth = key.split(".")
        if meth == "CreateIsoclineCurveBuilder" and owner.get(cname) is not None:
            coll = owner[cname]
    if coll is None:
        res["not_working"]["C9 Isocline Curve"] = "no reachable CreateIsoclineCurveBuilder: %s" % sorted(found)
        M["C9 isocline"] = rows
        chk.true("C9 Isocline Curve: where the builder is created (recorded)", True, found)
        return

    def iso(angle, faces=None, family=None):
        b = coll.CreateIsoclineCurveBuilder(F.IsoclineCurve.Null)           # part.Features.FreeformCurveCollection, typed Null
        try:
            b.Face.ReplaceRules([R.CreateRuleFaceDumb(faces or blends)], False)
            b.ReferenceDirection = nxh.direction(part, (0, 0, 1))           # the pull direction
            if family:                                                      # (start, end, interval) in degrees
                b.IsoclineTypes = F.IsoclineCurveBuilder.CurveTypes.Multiple
                b.StartAngle.RightHandSide, b.EndAngle.RightHandSide, b.IntervalAngle.RightHandSide = (str(v) for v in family)
            else:
                b.IsoclineTypes = F.IsoclineCurveBuilder.CurveTypes.Single
                b.IsoclineAngle.RightHandSide = str(angle)
            b.IsAssociative = True
            f = b.Commit()
        finally:
            b.Destroy()
        return f
    for ang in (30, 60):
        f, err = nxh.attempt("isocline %s" % ang, lambda ang=ang: iso(ang), log=log)
        if err:
            rows["angle %s" % ang] = {"error": err[:300]}
            continue
        cs = ck.curves_of(f) if isinstance(f, NXOpen.Features.Feature) else [c for c in part.Curves if False]
        dev, n = 0.0, 0
        for c in cs:
            for s in ck.sample(c, 10):
                face = min(blends, key=lambda fc: nxh.dist_to(part, fc, s["point"]))
                nz = abs(nxh.normal_at(face, s["point"])[2])
                a_surf = 90.0 - math.degrees(math.acos(max(-1, min(1, nz))))      # angle between the face and the pull direction
                dev = max(dev, abs(a_surf - (90 - ang)) if abs(a_surf - (90 - ang)) < abs(a_surf - ang) else abs(a_surf - ang))
                n += 1
        rows["angle %s" % ang] = {"feature_type": getattr(f, "FeatureType", type(f).__name__), "curves": len(cs), "length": round(sum(c.GetLength() for c in cs), 3),
                                  "samples": n, "max_angle_dev_deg": round(dev, 4), "z": sorted({round(ck.frame(c, 0.5)["point"][2], 3) for c in cs})[:6]}
    # the zero-draft line (silhouette / natural parting line) of a lying cylinder: pull +Z, axis along X
    nxh.expr(part, "c9_d", 20)
    _fc, cylb = nxh.cylinder(part, (60, 920, 15), (1, 0, 0), "c9_d", 40)
    cface = nxh.one(nxh.faces(cylb, ftype=nxh.CYLINDER), "lying cylinder")
    for label, kw in (("lying cylinder d20, angle 0", dict(angle=0)), ("lying cylinder d20, angle 30", dict(angle=30)),
                      ("lying cylinder d20, family -60 .. 60 every 30", dict(angle=0, family=(-60, 60, 30)))):
        f, err = nxh.attempt(label, lambda kw=kw: iso(faces=[cface], **kw), log=log)
        if err:
            rows[label] = {"error": err[:300]}
            continue
        cs = ck.curves_of(f)
        rows[label] = {"curves": len(cs), "classes": sorted({type(c).__name__ for c in cs}), "lengths": sorted({round(c.GetLength(), 3) for c in cs}),
                       "z_minus_axis": sorted({round(ck.frame(c, 0.5)["point"][2] - 15.0, 3) for c in cs}),
                       "y_minus_axis": sorted({round(ck.frame(c, 0.5)["point"][1] - 920.0, 3) for c in cs})}
        if label.endswith("angle 0"):
            nxh.set_expr(part, "c9_d", 30)
            nxh.update()
            cs = ck.curves_of(f)
            rows[label]["after d 20 -> 30: y_minus_axis"] = sorted({round(ck.frame(c, 0.5)["point"][1] - 920.0, 3) for c in cs})
            rows[label]["errors"] = nxh.feature_errors(part)
            nxh.set_expr(part, "c9_d", 20)
            nxh.update()
    M["C9 isocline on the R8 blends of a block, reference +Z"] = rows
    z0, z30 = rows.get("lying cylinder d20, angle 0", {}), rows.get("lying cylinder d20, angle 30", {})
    chk.true("C9 Isocline angle 0 on a lying cylinder = the zero-draft (silhouette / parting) lines: 2 lines of 40 at the axis height, 10 either side; "
             "associative (d 20 -> 30 moves them to 15)", z0.get("curves") == 2 and z0.get("lengths") == [40.0] and z0.get("z_minus_axis") == [0.0]
             and z0.get("y_minus_axis") == [-10.0, 10.0] and z0.get("after d 20 -> 30: y_minus_axis") == [-15.0, 15.0] and not z0.get("errors"), z0)
    chk.true("C9 angle 30 = where the face has 30 deg of draft to the pull direction: lines 5 = r*sin(30) above the axis (sign of the angle = side: recorded)",
             "error" not in z30 and all(abs(abs(v) - 5.0) < 1e-3 for v in z30.get("z_minus_axis", [9])), z30)
    ok = [v for k, v in rows.items() if k.startswith("angle") and "error" not in v]
    chk.true("C9 Isocline Curve at 30 and 60 deg to +Z on R8 edge blends: curves where the face has that angle (deviation < 0.5 deg)",
             len(ok) == 2 and all(v["curves"] >= 4 and v["max_angle_dev_deg"] < 0.5 for v in ok), rows)


# ------------------------------------------------------------------ C10 trim curve again
def c10(part):
    y = 1000.0
    rows = {}
    TB = F.TrimCurve2Builder
    dat = nxh.Datums(part)
    nxh.expr(part, "c10_x", 40)

    def assoc_line(a, b_):
        LBf = F.AssociativeLineBuilder
        b = part.BaseFeatures.CreateAssociativeLineBuilder(F.AssociativeLine.Null)
        try:
            b.StartPointOptions = LBf.StartOption.Point
            b.StartPoint.Value = nxh.point(part, *a)
            b.EndPointOptions = LBf.EndOption.Point
            b.EndPoint.Value = nxh.point(part, *b_)
            b.Associative = True
            return b.CommitFeature()
        finally:
            b.Destroy()

    def smart_plane():                                    # NXOpen.Plane offset from the datum YZ plane by an expression: the trim follows it
        pl = part.Planes.CreatePlane(P(0, 0, 0), V(1, 0, 0), UPD)
        pl.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
        pl.SetGeometry([dat.yz])
        pl.Expression.RightHandSide = "c10_x"
        pl.Evaluate()
        return pl

    def trim(kind, yy, pick_x=50.0, keep=False, target=None, seed=None, pick=None):
        lf = target or assoc_line((0, yy, 0), (60, yy, 0))
        ln = seed or ck.curves_of(lf)[0]
        b = part.Features.CreateTrimCurve2FeatureBuilder(F.TrimCurve2.Null)
        try:
            ck.fill(b.CurveToTrim, [R.CreateRuleCurveFeature([lf])], (pick_x, yy, 0), ln)
            bo = b.CreateTrimCurveBoundingObjectBuilder()
            MT_ = GU.TrimCurveBoundingObjectBuilder.Method
            if kind == "fixed plane":
                bo.BoundingObjectMethodType = MT_.SelectPlane
                bo.BoundingPlane = part.Planes.CreatePlane(P(40, yy, 0), V(1, 0, 0), UPD)
            elif kind == "smart plane":
                bo.BoundingObjectMethodType = MT_.SelectPlane
                bo.BoundingPlane = smart_plane()
            elif kind == "datum plane object":
                _fp, dp = nxh.datum_plane(part, (40, yy, 0), (1, 0, 0))
                bo.BoundingObjectMethodType = MT_.SelectObject
                bo.BoundingObjectList.Add(dp)
            elif kind == "point object":
                bo.BoundingObjectMethodType = MT_.SelectObject
                bo.BoundingObjectList.Add(part.Points.CreatePoint(P(40, yy, 0)))
            elif kind == "crossing line object":
                bo.BoundingObjectMethodType = MT_.SelectObject
                bo.BoundingObjectList.Add(ck.curves_of(assoc_line((40, yy - 10, 0), (40, yy + 10, 0)))[0])
            b.BoundingObjectList.Append(bo)
            b.OperationOption = TB.Operation.Trim
            b.KeepOrDiscard = TB.KeepDiscard.Keep if keep else TB.KeepDiscard.Discard
            b.UpdateTrimRegionsAndDivideLocations()
            b.SelectTrimRegion(P(*pick) if pick else P(pick_x, yy, 0))        # a point ON the piece to remove (or keep)
            b.CurveOptions.Associative = True
            f = b.CommitFeature()
        finally:
            b.Destroy()
        cs = ck.curves_of(f)
        return f, {"feature_type": f.FeatureType, "curves": len(cs), "classes": sorted({type(c).__name__ for c in cs}), "length": round(sum(c.GetLength() for c in cs), 4),
                   "x": sorted(rnd(sorted([ck.frame(c, 0)["point"][0], ck.frame(c, 1)["point"][0]]), 3) for c in cs)}

    feats = {}
    for i, kind in enumerate(("fixed plane", "smart plane", "datum plane object", "point object", "crossing line object")):
        r, err = nxh.attempt("trim " + kind, lambda kind=kind, i=i: trim(kind, y + 20 * i), log=log)
        rows["bounding " + kind] = r[1] if r else {"error": err[:300]}
        feats[kind] = r[0] if r else None
    r, err = nxh.attempt("keep", lambda: trim("fixed plane", y + 120, keep=True), log=log)
    rows["fixed plane, region picked at x 50, KeepDiscard.Keep"] = r[1] if r else {"error": err[:300]}
    # a circle cut by the plane: which part stays
    sf, sc = ck.studio_spline(part, [(0, y + 180, 0), (30, y + 195, 0), (60, y + 180, 0)], degree=2)
    r, err = nxh.attempt("spline", lambda: trim("fixed plane", y + 180, pick_x=59.0, target=sf, seed=sc, pick=ck.frame(sc, ck.end_near(sc, (60, y + 180, 0)) * 0.9 + 0.05)["point"]), log=log)
    off, err2 = nxh.attempt("spline off", lambda: trim("fixed plane", y + 180, pick_x=59.0, target=sf, seed=sc), log=log)
    rows["... the same with the region point 0.5 mm OFF the curve"] = off[1] if off else {"error": err2[:300]}
    rows["spline feature 0..60 cut by the plane x = 40, region picked near x 59"] = r[1] if r else {"error": err[:300]}
    # associativity: move the smart plane
    if feats.get("smart plane") is not None:
        nxh.set_expr(part, "c10_x", 25)
        nxh.update()
        cs = ck.curves_of(feats["smart plane"])
        rows["smart plane after c10_x 40 -> 25"] = {"length": round(sum(c.GetLength() for c in cs), 4), "errors": nxh.feature_errors(part)}
        nxh.set_expr(part, "c10_x", 40)
        nxh.update()
    M["C10 Trim Curve of a 60 mm associative line at x = 40 (region picked at x = 50, Discard)"] = rows
    fp, sp = rows["bounding fixed plane"], rows["bounding smart plane"]
    chk.true("C10 Trim Curve commits headless when the boundary is a PLANE (BoundingObjectMethodType SelectPlane + BoundingPlane): TRIM_CURVE2, 60 -> 40",
             fp.get("feature_type") == "TRIM_CURVE2" and abs(fp.get("length", 0) - 40.0) < 1e-6 and fp["x"] == [[0.0, 40.0]], fp)
    chk.true("C10 the picked region is the part REMOVED with Discard and the part kept with Keep (20 left)",
             abs(rows["fixed plane, region picked at x 50, KeepDiscard.Keep"].get("length", 0) - 20.0) < 1e-6, rows["fixed plane, region picked at x 50, KeepDiscard.Keep"])
    spl = rows["spline feature 0..60 cut by the plane x = 40, region picked near x 59"]
    chk.true("C10 a spline feature is trimmed the same way (ends at x 0 and x 40)", spl.get("x") == [[0.0, 40.0]] and spl.get("classes") == ["Spline"], spl)
    mv = rows.get("smart plane after c10_x 40 -> 25", {})
    chk.true("C10 with a smart plane (offset from a datum plane by an expression) the trim follows: 40 -> 25, no feature error",
             abs(sp.get("length", 0) - 40.0) < 1e-6 and abs(mv.get("length", 0) - 25.0) < 1e-6 and not mv.get("errors"), (sp, mv))
    objs = {k: rows["bounding " + k] for k in ("datum plane object", "point object", "crossing line object")}
    chk.true("C10 a bounding OBJECT (datum plane, point, curve through BoundingObjectList) is still refused headless: "
             "'Bounding objects are either suppressed or modeled away.' (recorded per kind)", True, objs)
    res["not_working"]["C10 Trim Curve with a bounding object"] = {k: v.get("error", "works") for k, v in objs.items()}


def run():
    global R
    part = nxh.new_part(os.path.join(OUT, "cast_curve_checks.prt"))
    R = part.ScRuleFactory
    for name, fn in (("C1", c1), ("C2", c2), ("C3", c3), ("C4", c4), ("C5", c5), ("C6", c6), ("C7", c7), ("C8", c8), ("C9", c9), ("C10", c10)):
        block(name, fn, part)
    res["errors"] = nxh.feature_errors(part)
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res.update(chk.report())
if "error" in res:
    res["result"] = "FAIL"
nxh.write_json(os.path.join(OUT, "cast_curve_checks.json"), res)
