"""Studio Spline rules measured on NX 2206 (headless): which type, which degree, how many poles, how to judge it.

  run_journal.ps1 -Script spline_rules.py -WorkDir <out> -JArgs <out>

  S1  Through Points vs By Poles on EXACT points; on NOISY points also Fit Curve - deviation from the points,
      inflections, curvature peaks, max curvature (the decision table of SKILL.md section 6a)
  S2  spline arithmetic: order, poles, segments for both types, single segment, matched knots; the
      curvature-slope jump at the knots of a multi-segment spline against a single segment
  S3  closed curves: periodic (smooth seam) against "first point repeated" (corner at the seam)
  S4  end constraints taken from neighbouring geometry: associative tangent direction, tangent magnitude,
      automatic G1 / G2 from the curve the end point rides on; what By Poles accepts
  S5  By Poles construction rule: pole 2 on the neighbour's tangent = G1, pole 3 at h = k*a^2*p/(p-1) = G2
  S6  measured (noisy) points on a known arc: Fit Curve by degree + segments / by tolerance vs interpolation
  S7  tolerance of an approximated curve (law curve): poles and deviation per decade
  S8  editing the degree of an existing through-points spline feature
[cast ecvc] = Siemens NX CAST 8.5 "Splines" course (rules in own words); numbers measured here.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])))
import curvekit as ck  # noqa: E402
import nxh  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
ONLY = list(sys.argv[2:])
P, V, UPD = nxh.P, nxh.V, nxh.UPD
NULL = NXOpen.NXObject.Null
GU = NXOpen.GeometricUtilities
log = nxh.Log(os.path.join(OUT, "spline_rules.log"))
chk = nxh.Check()
res = {"measured": {}, "not_working": {}}
M = res["measured"]


def block(name, fn, part):
    if ONLY and name not in ONLY:
        return
    m = nxh.mark("block " + name, False)
    try:
        fn(part)
        log("done", name)
    except Exception:  # noqa: BLE001
        err = traceback.format_exc()
        log("FAILED", name, err)
        chk.true(name + " ran to the end", False, err[-900:])
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass


def row(curve, part=None, pts=None, truth=None):
    """Quality numbers of one curve; pts = points it should (or need not) pass through; truth(sample) ->
    distance of a curve sample from the exact shape, for a deviation along the length."""
    q = ck.curve_quality(curve)
    out = {"inflections": q["inflections"], "peaks": q["peaks"], "k_max": round(q["k_max"], 6), "r_min": round(q["r_min"], 3) if q["r_min"] else None,
           "length": round(q["length"], 4)}
    if isinstance(curve, NXOpen.Spline):
        d = ck.spline_data(curve)
        out.update(degree=d["degree"], poles=d["poles"], segments=d["segments"])
    if pts is not None:
        out["dev_points"] = round(ck.max_dev(part, curve, pts), 5)
    if truth is not None:
        out["dev_truth"] = round(max(truth(s) for s in ck.sample(curve, 100)), 5)
    return out


# ------------------------------------------------------------------ S1
def s1(part):
    R = 100.0

    def arc_pts(cy, n, noise=0.0):
        out = []
        for i in range(n):
            a = math.radians(130.0 - 80.0 * i / (n - 1))                                 # 80 deg of an R100 arc, left to right
            e = 0.0 if i in (0, n - 1) else (noise if i % 2 else -noise)                  # alternating radial error
            out.append((60.0 + (R + e) * math.cos(a), cy + (R + e) * math.sin(a), 0.0))
        return out

    def truth(cy):
        return lambda s: abs(math.hypot(s["point"][0] - 60.0, s["point"][1] - cy) - R)

    cy = -70.0
    exact = arc_pts(cy, 7)
    _f, tp = ck.studio_spline(part, exact, degree=3)
    _f, bp = ck.studio_spline(part, exact, degree=3, poles=True)
    r_tp, r_bp = row(tp, part, exact, truth(cy)), row(bp, part, exact[1:-1], truth(cy))
    r_bp["dev_ends"] = round(ck.max_dev(part, bp, [exact[0], exact[-1]]), 6)
    M["S1 exact points (7 on an R100 arc)"] = {"through points d3": r_tp, "by poles d3": r_bp}
    chk("S1 exact points, Through Points: passes through all 7 (max deviation)", r_tp["dev_points"], 0.0, 1e-5)
    chk.true("S1 ... and stays within 0.05 of the arc between them, no inflection", r_tp["dev_truth"] < 0.05 and r_tp["inflections"] == 0, r_tp)
    chk.true("S1 exact points, By Poles: only the END poles are on the curve; the interior poles are off it by millimetres",
             r_bp["dev_ends"] < 1e-5 and r_bp["dev_points"] > 0.5 and r_bp["inflections"] == 0, r_bp)

    # the same arc digitised with +-0.5 mm alternating error, 9 points
    cy = 0.0
    noisy = arc_pts(cy, 9, 0.5)
    rows = {}
    _f, c = ck.studio_spline(part, noisy, degree=3)
    rows["through points d3"] = row(c, part, noisy, truth(cy))
    _f, c = ck.studio_spline(part, noisy, degree=5)
    rows["through points d5"] = row(c, part, noisy, truth(cy))
    _f, c = ck.studio_spline(part, noisy, degree=3, poles=True)
    rows["by poles d3 (9 poles)"] = row(c, part, noisy, truth(cy))
    _f, c = ck.studio_spline(part, noisy, poles=True, single=True)
    rows["by poles single segment (9 poles, d8)"] = row(c, part, noisy, truth(cy))
    # five poles laid out by hand: the ends, two on the end tangents, one above the crown
    t0, t1 = math.radians(130.0), math.radians(50.0)
    five = [noisy[0], (noisy[0][0] + 35 * math.sin(t0), noisy[0][1] - 35 * math.cos(t0), 0.0), (60.0, cy + R + 4.5, 0.0),
            (noisy[-1][0] - 35 * math.sin(t1), noisy[-1][1] + 35 * math.cos(t1), 0.0), noisy[-1]]
    _f, c = ck.studio_spline(part, five, poles=True, single=True)
    rows["by poles single segment (5 poles, d4)"] = row(c, part, noisy, truth(cy))
    _f, c = ck.fit_spline(part, noisy, degree=3, segments=1)
    rows["fit d3, 1 segment"] = row(c, part, noisy, truth(cy))
    _f, c = ck.fit_spline(part, noisy, degree=5, segments=1)
    rows["fit d5, 1 segment"] = row(c, part, noisy, truth(cy))
    M["S1 noisy points (9 on the R100 arc, +-0.5)"] = rows
    tp3, fit3, bp9, bp5 = rows["through points d3"], rows["fit d3, 1 segment"], rows["by poles d3 (9 poles)"], rows["by poles single segment (5 poles, d4)"]
    chk.true("S1 noisy points, Through Points d3: exact through every point and it FOLLOWS the noise (inflections >= 4)",
             tp3["dev_points"] < 1e-5 and tp3["inflections"] >= 4, tp3)
    chk.true("S1 noisy points, Through Points d5: a higher degree makes the interpolation WORSE (larger peak curvature than d3)",
             rows["through points d5"]["k_max"] > tp3["k_max"], (rows["through points d5"]["k_max"], tp3["k_max"]))
    chk.true("S1 noisy points, Fit d3 / 1 segment: 0 inflections, peak curvature within 25 % of 1/R, misses the points by about the noise",
             fit3["inflections"] == 0 and fit3["k_max"] < 0.0125 and 0.2 < fit3["dev_points"] < 0.9, fit3)
    chk.true("S1 noisy points as POLES (9, degree 3): no inflection and a lower peak curvature than through the same points",
             bp9["inflections"] == 0 and bp9["k_max"] < tp3["k_max"], bp9)
    chk.true("S1 five hand-placed poles, one segment: the fairest curve of the set (0 inflections, 0 peaks) - and the one furthest from being exact",
             bp5["inflections"] == 0 and bp5["peaks"] == 0 and bp5["dev_truth"] > fit3["dev_truth"], bp5)


# ------------------------------------------------------------------ S2
def knot_slope_jump(spline):
    """Largest jump of d(curvature)/dt across an interior knot, relative to the curvature range (0 for one segment)."""
    d = ck.spline_data(spline)
    e = 2e-4
    k = lambda t: ck.frame(spline, t)["k"]                                              # noqa: E731
    ks = [s["k"] for s in ck.sample(spline, 100)]
    span = max(ks) - min(ks) or 1.0
    worst = 0.0
    for u in d["inner_knots"]:
        left = (k(u - e) - k(u - 2 * e)) / e
        right = (k(u + 2 * e) - k(u + e)) / e
        worst = max(worst, abs(right - left) / span)
    return round(worst, 4)


def s2(part):
    y = 120.0
    six = [(0, y, 0), (20, y + 15, 0), (40, y + 5, 0), (60, y + 20, 0), (80, y + 10, 0), (100, y + 25, 0)]
    rows = {}

    def one(label, **kw):
        r, err = nxh.attempt(label, lambda: ck.studio_spline(part, kw.pop("pts", six), **kw), log=log)
        if err:
            rows[label] = {"error": err[:200]}
            return None
        d = ck.spline_data(r[1])
        d.pop("inner_knots")
        rows[label] = d
        return r[1]

    one("by poles d3, 6 poles", degree=3, poles=True)
    one("by poles d5, 6 poles", degree=5, poles=True)
    one("by poles d2, 6 poles", degree=2, poles=True)
    one("by poles single segment, 6 poles", poles=True, single=True)
    one("by poles d5, 4 poles (too few)", degree=5, poles=True, pts=six[:4])
    tp3 = one("through points d3, 6 points", degree=3)
    tp5 = one("through points d5, 6 points", degree=5)
    one("through points d1, 6 points", degree=1)
    one("through points d3, matched knots Cubic", degree=3, matched="Cubic")
    one("through points d3, matched knots General", degree=3, matched="General")
    one("through points d5, 9 points", degree=5, pts=[(12.5 * i, y + 40 + (5 if i % 2 else 0), 0) for i in range(9)])
    M["S2 arithmetic"] = rows
    r = rows["by poles d3, 6 poles"]
    chk.true("S2 By Poles degree 3, 6 poles: order 4, 6 poles, 3 segments (= poles - degree)", (r["order"], r["poles"], r["segments"]) == (4, 6, 3), r)
    r = rows["by poles d5, 6 poles"]
    chk.true("S2 By Poles degree 5, 6 poles: ONE segment (poles = degree + 1)", (r["order"], r["poles"], r["segments"]) == (6, 6, 1), r)
    r = rows["by poles single segment, 6 poles"]
    chk.true("S2 Single Segment with 6 poles gives degree 5 whatever Degree says", (r.get("degree"), r.get("segments")) == (5, 1), r)
    r = rows["through points d5, 6 points"]
    chk.true("S2 Through Points degree 5 through 6 points: one segment, 6 poles (Siemens' sample splines)", (r.get("degree"), r.get("segments"), r.get("poles")) == (5, 1, 6), r)
    r = rows["through points d3, 6 points"]
    chk.true("S2 Through Points degree 3 through 6 points: several segments", r.get("segments", 0) >= 3, r)
    if tp3 is not None and tp5 is not None:
        j3, j5 = knot_slope_jump(tp3), knot_slope_jump(tp5)
        q3, q5 = ck.curve_quality(tp3), ck.curve_quality(tp5)
        M["S2 fairness, same 6 points"] = {"d3 multi-segment": {"knot_slope_jump": j3, "peaks": q3["peaks"], "inflections": q3["inflections"], "k_max": round(q3["k_max"], 5)},
                                           "d5 single segment": {"knot_slope_jump": j5, "peaks": q5["peaks"], "inflections": q5["inflections"], "k_max": round(q5["k_max"], 5)}}
        chk.true("S2 the cubic's curvature has a KINK at every interior knot (slope jump > 0), the single segment has none",
                 j3 > 0.5 and j5 == 0.0, (j3, j5))


# ------------------------------------------------------------------ S3
def s3(part):
    cy = 260.0
    loop = [(30, cy, 0), (15, cy + 20, 0), (-15, cy + 20, 0), (-30, cy, 0), (-15, cy - 20, 0), (15, cy - 20, 0)]
    rows = {}

    def seam(c):
        a, b = ck.frame(c, 0.0), ck.frame(c, 1.0)
        return {"gap": round(math.dist(a["point"], b["point"]), 6), "tangent_angle_deg": round(ck.angle(a["tangent"], b["tangent"]), 4),
                "k_start": round(a["k"], 6), "k_end": round(b["k"], 6)}

    def solid(c, z):
        f, err = nxh.attempt("extrude", lambda: nxh.extrude(part, nxh.section(part, curves=[c]), (0, 0, 1), z, z + 5), log=log)
        if err:
            return {"error": err[:160]}
        b = f.GetBodies()[0]
        return {"solid": bool(b.IsSolidBody), "faces": len(b.GetFaces()), "edges": len(b.GetEdges()), "volume": round(nxh.volume(part, b), 3)}

    _f, c = ck.studio_spline(part, loop, degree=3, periodic=True)
    rows["through points periodic"] = dict(seam(c), periodic=bool(c.Periodic), dev_points=round(ck.max_dev(part, c, loop), 6),
                                           inflections=ck.curve_quality(c)["inflections"], **solid(c, 0))
    _f, c2 = ck.studio_spline(part, loop + [loop[0]], degree=3)
    rows["through points, first point repeated"] = dict(seam(c2), periodic=bool(c2.Periodic), **solid(c2, 10))
    _f, c3 = ck.studio_spline(part, loop, degree=3, poles=True, periodic=True)
    rows["by poles periodic"] = dict(seam(c3), periodic=bool(c3.Periodic), dev_poles=round(ck.max_dev(part, c3, loop), 4),
                                     inflections=ck.curve_quality(c3)["inflections"], **solid(c3, 20))
    r, err = nxh.attempt("periodic + matched knots", lambda: ck.studio_spline(part, loop, degree=3, periodic=True, matched="Cubic"), log=log)
    rows["through points periodic + matched knots Cubic"] = {"error": err[:200]} if err else dict(seam(r[1]), periodic=bool(r[1].Periodic))
    M["S3 closed"] = rows
    a, b = rows["through points periodic"], rows["through points, first point repeated"]
    chk.true("S3 periodic through-points spline: closed, tangent and curvature continuous across the seam, passes through all 6 points",
             a["gap"] < 1e-6 and a["tangent_angle_deg"] < 1e-3 and abs(a["k_start"] - a["k_end"]) < 1e-6 and a["dev_points"] < 1e-5 and a["periodic"], a)
    chk.true("S3 ... and extrudes to ONE smooth wall (solid, 3 faces)", a.get("solid") and a.get("faces") == 3, a)
    chk.true("S3 first point repeated instead of periodic: closed but with a CORNER at the seam (tangent angle > 5 deg)",
             b["gap"] < 1e-6 and b["tangent_angle_deg"] > 5.0, b)
    c = rows["by poles periodic"]
    chk.true("S3 periodic by-poles spline: closed and smooth, inside its control polygon (off the poles), no inflection",
             c["gap"] < 1e-6 and c["tangent_angle_deg"] < 1e-3 and c["dev_poles"] > 1.0 and c["inflections"] == 0, c)


# ------------------------------------------------------------------ S4
def s4(part):
    y = 340.0
    rows = {}
    # (a) associative end tangent from a neighbouring line driven by an angle expression
    nxh.expr(part, "s4_ang", 10, unit=None)
    LB = NXOpen.Features.AssociativeLineBuilder
    b = part.BaseFeatures.CreateAssociativeLineBuilder(NXOpen.Features.AssociativeLine.Null)
    try:
        b.StartPointOptions = LB.StartOption.Point
        b.StartPoint.Value = nxh.point(part, 0, y, 0)
        b.EndPointOptions = LB.EndOption.Point
        b.EndPoint.Value = nxh.point(part, "40*cos(s4_ang)", "%s+40*sin(s4_ang)" % y, 0)
        b.Associative = True
        lf = b.CommitFeature()
    finally:
        b.Destroy()
    line = ck.curves_of(lf)[0]
    d_line = part.Directions.CreateDirection(line, NXOpen.Sense.Forward, UPD)          # smart direction: follows the line
    p_end = ck.on_curve(part, line, 100)
    f, sp = ck.studio_spline(part, [p_end, (70, y + 30, 0), (110, y + 20, 0)], degree=3, constraints={0: {"direction": d_line}})

    def state():
        e = ck.frame(line, 1.0)
        return {"gap": round(math.dist(e["point"], ck.frame(sp, 0.0)["point"]), 6), "tangent_angle_deg": round(ck.join_angle(line, 1.0, sp, 0.0), 5),
                "line_dir": [round(v, 4) for v in e["tangent"]]}
    s10 = state()
    nxh.set_expr(part, "s4_ang", 40)
    nxh.update()
    s40 = state()
    s40["errors"] = nxh.feature_errors(part)
    rows["tangent direction = smart Direction of the neighbour line"] = {"angle 10": s10, "angle 40": s40}
    chk.true("S4 end tangent taken from a line (Directions.CreateDirection(line, ...)): G1 at 10 deg",
             s10["gap"] < 1e-6 and s10["tangent_angle_deg"] < 1e-3, s10)
    chk.true("S4 ... and it FOLLOWS the line: angle 10 -> 40, still attached and tangent, no feature error",
             s40["gap"] < 1e-6 and s40["tangent_angle_deg"] < 1e-3 and not s40["errors"] and abs(s40["line_dir"][1] - math.sin(math.radians(40))) < 1e-3, s40)

    # (b) tangent magnitude is a Scalar - and it is an ABSOLUTE derivative length, not the dialog's factor
    mags = {}
    for mag in (None, 1.0, 10.0, 40.0, 80.0, 160.0, 320.0):
        r, err = nxh.attempt("magnitude", lambda mag=mag: ck.studio_spline(part, [(0, y + 60, 0), (40, y + 80, 0), (80, y + 60, 0)], degree=3,
                                                                           constraints={0: {"direction": (0, 1, 0), "magnitude": mag}}), log=log)
        if err:
            mags[str(mag)] = {"error": err[:200]}
            continue
        c = r[1]
        q = ck.curve_quality(c)
        mags[str(mag)] = {"start_tangent": [round(v, 4) for v in ck.frame(c, 0)["tangent"]], "r_start": round(ck.frame(c, 0)["radius"], 4),
                          "r_min": round(q["r_min"], 4), "peaks": q["peaks"], "inflections": q["inflections"], "length": round(q["length"], 3)}
    rows["tangent magnitude (chord of the first span 44.7, curve length about 100)"] = mags
    ok = all("error" not in m for m in mags.values())
    chk.true("S4 TangentMagnitude takes an NXOpen.Scalar and the start direction holds for every value", ok and all(m["start_tangent"] == [0.0, 1.0, 0.0] for m in mags.values()), mags)
    chk.true("S4 a SMALL magnitude (1) is a hook: radius of curvature under 0.01 mm at the start; magnitude left unset gives a natural curve (r_start > 5)",
             ok and mags["1.0"]["r_start"] < 0.01 and mags["None"]["r_start"] > 5.0, (mags["1.0"], mags["None"]))

    # (c) automatic G1 / G2 from the curve the end point rides on (an R20 arc)
    arc = nxh.arc(part, (0, y + 120, 0), (1, 0, 0), (0, 1, 0), 20.0, 0.0, math.pi / 2)   # ends (20, y+120) and (0, y+140)
    auto = {}
    for kind in (None, "Tangent", "Curvature"):
        cons = {0: {"auto": kind}} if kind else None
        r, err = nxh.attempt("auto " + str(kind), lambda cons=cons: ck.studio_spline(part, [ck.on_curve(part, arc, 100), (-25, y + 150, 0), (-50, y + 135, 0)],
                                                                                    degree=3, constraints=cons), log=log)
        if err:
            auto[str(kind)] = {"error": err[:200]}
            continue
        c = r[1]
        auto[str(kind)] = {"tangent_angle_deg": round(ck.join_angle(arc, 1.0, c, 0.0), 4), "radius_at_start": round(ck.frame(c, 0.0)["radius"], 4)}
    rows["automatic constraint from the attachment curve (R20 arc)"] = auto
    chk.true("S4 no constraint: the spline leaves the arc end at an angle (not tangent)", auto["None"].get("tangent_angle_deg", 0) > 1.0, auto["None"])
    chk.true("S4 AutomaticConstraintType = Tangent on an on-curve point: G1 with the arc", auto["Tangent"].get("tangent_angle_deg", 9) < 1e-2, auto["Tangent"])
    chk.true("S4 AutomaticConstraintType = Curvature: G1 and radius 20 at the join (G2)",
             auto["Curvature"].get("tangent_angle_deg", 9) < 1e-2 and abs(auto["Curvature"].get("radius_at_start", 0) - 20.0) < 0.01, auto["Curvature"])

    # (d) explicit direction on a curve + explicit curvature
    expl = {}
    def explicit():
        d = part.Directions.CreateDirection(arc, ck.scalar(part, 1.0), NXOpen.Direction.OnCurveOption.Tangent, NXOpen.Sense.Forward, UPD)
        k = part.Offsets.CreateCurvature(arc, ck.scalar(part, 1.0), UPD)
        return ck.studio_spline(part, [ck.on_curve(part, arc, 100), (-25, y + 170, 0), (-50, y + 155, 0)], degree=3,
                                constraints={0: {"direction": d, "curvature": k}})
    r, err = nxh.attempt("explicit curvature", explicit, log=log)
    if err:
        expl = {"error": err[:300]}
        res["not_working"]["S4 explicit Offsets.CreateCurvature constraint"] = err[:300]
    else:
        expl = {"tangent_angle_deg": round(ck.join_angle(arc, 1.0, r[1], 0.0), 4), "radius_at_start": round(ck.frame(r[1], 0.0)["radius"], 4)}
    rows["explicit direction on curve + Offsets.CreateCurvature"] = expl

    # (e) By Poles: constraints at the ends, and at an interior pole
    poles = [ck.on_curve(part, arc, 100), (-12, y + 150, 0), (-25, y + 165, 0), (-40, y + 160, 0), (-55, y + 140, 0)]
    bp = {}
    for label, cons in (("end pole G1", {0: {"auto": "Tangent"}}), ("end pole G2", {0: {"auto": "Curvature"}}),
                        ("interior pole direction", {2: {"direction": (1, 0, 0)}})):
        r, err = nxh.attempt(label, lambda cons=cons: ck.studio_spline(part, poles, degree=3, poles=True, constraints=cons), log=log)
        if err:
            bp[label] = {"error": err[:200]}
            continue
        c = r[1]
        ps = c.Get3DPoles()
        bp[label] = {"tangent_angle_deg": round(ck.join_angle(arc, 1.0, c, 0.0), 4), "radius_at_start": round(ck.frame(c, 0.0)["radius"], 4),
                     "pole2": [round(ps[1].X, 3), round(ps[1].Y, 3)], "pole3": [round(ps[2].X, 3), round(ps[2].Y, 3)], "poles": c.PoleCount,
                     "tangent_at_mid": [round(v, 3) for v in ck.frame(c, 0.5)["tangent"]]}
    rows["by poles"] = bp
    M["S4 constraints"] = rows
    chk.true("S4 By Poles end pole with Tangent: G1 - NX moved pole 2 from y+150 onto the arc's tangent line (y+140)",
             bp["end pole G1"].get("tangent_angle_deg", 9) < 1e-2 and abs(bp["end pole G1"]["pole2"][1] - (y + 140)) < 1e-3, bp["end pole G1"])
    chk.true("S4 By Poles end pole with Curvature: G2 (radius 20) - poles 2 and 3 are placed by NX",
             bp["end pole G2"].get("tangent_angle_deg", 9) < 1e-2 and abs(bp["end pole G2"].get("radius_at_start", 0) - 20.0) < 0.01, bp["end pole G2"])
    chk.true("S4 By Poles: a constraint on an INTERIOR pole is refused ('Cannot compute bcurve.')", "error" in bp["interior pole direction"], bp["interior pole direction"])
    chk.true("S4 explicit G2: Directions.CreateDirection(curve, t, Tangent) + Offsets.CreateCurvature(curve, t): radius 20 at the join",
             abs(expl.get("radius_at_start", 0) - 20.0) < 0.01 and expl.get("tangent_angle_deg", 9) < 1e-2, expl)


# ------------------------------------------------------------------ S5
def s5(part):
    y = 560.0
    arc = nxh.arc(part, (0, y, 0), (1, 0, 0), (0, 1, 0), 20.0, 0.0, math.pi / 2)        # ends at (0, y+20), tangent -X, centre below
    end = (0.0, y + 20.0, 0.0)
    rows = {}
    for a in (5.0, 10.0, 20.0):                                                          # pole 2 at distance a on the tangent line
        poles = [end, (-a, y + 20, 0), (-30, y + 5, 0), (-45, y + 10, 0), (-60, y - 5, 0)]
        _f, c = ck.studio_spline(part, poles, poles=True, single=True)                    # degree 4, one segment
        rows["pole 2 at %g on the tangent" % a] = {"tangent_angle_deg": round(ck.join_angle(arc, 1.0, c, 0.0), 5), "radius_at_start": round(ck.frame(c, 0.0)["radius"], 3)}
    # G2 by construction: single segment of degree p: k(0) = (p-1)/p * h / a^2  ->  h = k * a^2 * p/(p-1)
    p, a, k = 4, 10.0, 1.0 / 20.0
    h = k * a * a * p / (p - 1)
    poles = [end, (-a, y + 20, 0), (-22, y + 20 - h, 0), (-45, y + 10, 0), (-60, y - 5, 0)]
    _f, c = ck.studio_spline(part, poles, poles=True, single=True)
    rows["pole 3 at h = k a^2 p/(p-1) = %.4f below the tangent" % h] = {"tangent_angle_deg": round(ck.join_angle(arc, 1.0, c, 0.0), 5),
                                                                        "radius_at_start": round(ck.frame(c, 0.0)["radius"], 4), "h": round(h, 4)}
    # multi-segment cubic: the same rule needs the knot factor, so let NX place the poles (S4) or use one segment
    poles3 = [end, (-a, y + 20, 0), (-22, y + 20 - k * a * a * 3 / 2, 0), (-45, y + 10, 0), (-60, y - 5, 0)]
    _f, c3 = ck.studio_spline(part, poles3, degree=3, poles=True)
    rows["same construction on a 2-segment cubic (h = k a^2 3/2)"] = {"radius_at_start": round(ck.frame(c3, 0.0)["radius"], 4), "segments": ck.spline_data(c3)["segments"]}
    M["S5 pole construction"] = rows
    chk.true("S5 pole 2 anywhere on the neighbour's tangent line: tangent (0 deg) for a = 5, 10, 20; the radius differs each time",
             all(rows["pole 2 at %g on the tangent" % a]["tangent_angle_deg"] < 1e-3 for a in (5.0, 10.0, 20.0))
             and len({rows["pole 2 at %g on the tangent" % a]["radius_at_start"] for a in (5.0, 10.0, 20.0)}) == 3, rows)
    key = [k_ for k_ in rows if k_.startswith("pole 3")][0]
    chk("S5 pole 3 placed by h = k*a^2*p/(p-1) (single segment): radius of curvature at the join = 20 = the arc (G2)", rows[key]["radius_at_start"], 20.0, 1e-3)


# ------------------------------------------------------------------ S6
def s6(part):
    cy, R = 700.0, 100.0
    n = 30
    pts = []
    for i in range(n):
        a = math.radians(60.0 + 60.0 * i / (n - 1))                                       # 60 deg span of an R100 arc
        e = 0.05 * math.sin(12.9898 * (i + 1)) * (0 if i in (0, n - 1) else 1)             # deterministic +-0.05 "measuring" noise
        pts.append(((R + e) * math.cos(a), cy + (R + e) * math.sin(a), 0.0))

    def dev_arc(c):
        return round(max(abs(math.hypot(s["point"][0], s["point"][1] - cy) - R) for s in ck.sample(c, 200)), 5)
    rows = {}
    for label, fn in (("through points d3 (interpolation)", lambda: ck.studio_spline(part, pts, degree=3)[1]),
                      ("fit d3, 1 segment", lambda: ck.fit_spline(part, pts, degree=3, segments=1)[1]),
                      ("fit d5, 1 segment", lambda: ck.fit_spline(part, pts, degree=5, segments=1)[1]),
                      ("fit d3, tolerance 0.1", lambda: ck.fit_spline(part, pts, degree=3, tolerance=0.1)[1]),
                      ("fit d3, tolerance 0.01 (tighter than the noise)", lambda: ck.fit_spline(part, pts, degree=3, tolerance=0.01)[1])):
        c, err = nxh.attempt(label, fn, log=log)
        if err:
            rows[label] = {"error": err[:200]}
            continue
        r = row(c, part, pts)
        r["dev_true_arc"] = dev_arc(c)
        r["k_range"] = [round(min(s["k"] for s in ck.sample(c, 100)), 6), r["k_max"]]
        rows[label] = r
    M["S6 measured points on an R100 arc, noise +-0.05"] = rows
    tp, f3 = rows["through points d3 (interpolation)"], rows["fit d3, 1 segment"]
    ratio = lambda r: r["k_range"][1] / r["k_range"][0]                                   # noqa: E731
    for r in rows.values():
        if "k_range" in r:
            r["k_max_over_k_min"] = round(ratio(r), 3)
    chk.true("S6 interpolating 30 noisy points: through every point (27 segments), curvature swings by more than 1.4 : 1 on a true arc",
             tp["dev_points"] < 1e-5 and tp["segments"] >= 20 and ratio(tp) > 1.4, tp)
    chk.true("S6 Fit Curve degree 3, 1 segment: 4 poles, no peak, no inflection, curvature within 1.15 : 1, off the points by up to 2 x the noise",
             f3["poles"] == 4 and f3["inflections"] == 0 and f3["peaks"] == 0 and ratio(f3) < 1.15 and f3["dev_points"] < 0.11, f3)
    chk.true("S6 neither is nearer the TRUE arc than the noise (both about 0.05): a fit buys fairness, not accuracy",
             0.03 < f3["dev_true_arc"] < 0.07 and 0.03 < tp["dev_true_arc"] < 0.07, (f3["dev_true_arc"], tp["dev_true_arc"]))
    tight = rows["fit d3, tolerance 0.01 (tighter than the noise)"]
    loose = rows["fit d3, tolerance 0.1"]
    if "error" not in tight and "error" not in loose:
        chk.true("S6 a fit tolerance below the noise buys segments (and curvature swing), not a truer curve",
                 tight["segments"] > loose["segments"] and ratio(tight) > ratio(loose) and tight["dev_true_arc"] >= loose["dev_true_arc"], (loose, tight))


# ------------------------------------------------------------------ S7
def s7(part):
    # involute of a base circle rb 24 from roll angle 0 to 0.9 rad as a law curve at three tolerances
    nxh.expr(part, "t", 1, unit=None)
    nxh.expr(part, "s7_rb", 24, unit=None)
    nxh.expr(part, "s7_u", "t*0.9", unit=None)
    nxh.expr(part, "s7_x", "s7_rb*(cos(s7_u*180/pi())+s7_u*sin(s7_u*180/pi()))", unit=None)
    nxh.expr(part, "s7_y", "900+s7_rb*(sin(s7_u*180/pi())-s7_u*cos(s7_u*180/pi()))", unit=None)
    nxh.expr(part, "s7_z", "0", unit=None)
    rows = {}
    for tol in (0.01, 0.001, 0.0001):
        b = part.Features.CreateLawCurveBuilder(NXOpen.Features.LawCurve.Null)
        try:
            for law, fn in ((b.XLaw, "s7_x"), (b.YLaw, "s7_y"), (b.ZLaw, "s7_z")):
                law.LawType = GU.LawBuilder.Type.ByEquation
                law.Parameter = "t"
                law.Function = fn
            b.DistanceTolerance = tol
            f = b.CommitFeature()
        finally:
            b.Destroy()
        c = ck.curves_of(f)[0]
        dev = 0.0
        for s in ck.sample(c, 200):                                                       # distance from the base circle must equal rb*u
            x, yv = s["point"][0], s["point"][1] - 900.0
            r = math.hypot(x, yv)
            u = math.sqrt(max(0.0, (r / 24.0) ** 2 - 1.0))
            ex, ey = 24.0 * (math.cos(u) + u * math.sin(u)), 24.0 * (math.sin(u) - u * math.cos(u))
            dev = max(dev, math.hypot(x - ex, yv - ey))
        d = ck.spline_data(c)
        rows[str(tol)] = {"poles": d["poles"], "degree": d["degree"], "segments": d["segments"], "max_dev_from_involute": round(dev, 7)}
    M["S7 law curve tolerance"] = rows
    chk.true("S7 a tighter tolerance costs poles: 0.01 -> 0.0001 adds poles", rows["0.0001"]["poles"] > rows["0.01"]["poles"], rows)
    chk.true("S7 each curve is within its own tolerance of the exact involute; 0.01 is already better than 0.001 mm here",
             all(rows[str(t)]["max_dev_from_involute"] <= t for t in (0.01, 0.001, 0.0001)) and rows["0.01"]["max_dev_from_involute"] < 0.001, rows)


# ------------------------------------------------------------------ S8
def s8(part):
    y = 1000.0
    pts = [(0, y, 0), (20, y + 15, 0), (40, y + 5, 0), (60, y + 20, 0), (80, y + 10, 0), (100, y + 25, 0)]
    f, sp = ck.studio_spline(part, pts, degree=3)
    before = ck.spline_data(sp)
    samples = [s["point"] for s in ck.sample(sp, 50)]

    def edit():
        b = part.Features.CreateStudioSplineBuilderEx(sp)                                  # the Spline object of the feature
        try:
            b.Degree = 5
            b.Commit()
        finally:
            b.Destroy()
    _r, err = nxh.attempt("edit degree", edit, log=log)
    sp2 = ck.curves_of(f)[0]
    after = ck.spline_data(sp2)
    r = {"error": err, "before": {k: before[k] for k in ("degree", "poles", "segments")}, "after": {k: after[k] for k in ("degree", "poles", "segments")},
         "dev_points_after": round(ck.max_dev(part, sp2, pts), 6), "shape_change": round(ck.max_dev(part, sp2, samples), 4),
         "feature_type": f.FeatureType, "errors": nxh.feature_errors(part)}
    M["S8 edit the degree of a through-points spline feature"] = r
    chk.true("S8 re-opening the builder on the feature's spline and setting Degree 3 -> 5: still through all points, one segment now",
             err is None and r["after"]["degree"] == 5 and r["dev_points_after"] < 1e-5 and not r["errors"], r)
    chk.true("S8 ... but the SHAPE between the points changes (deviation of the old curve's samples > 0.05)", r["shape_change"] > 0.05, r["shape_change"])


def run():
    part = nxh.new_part(os.path.join(OUT, "spline_rules.prt"))
    res["api"] = {"Directions.CreateDirection": (type(part.Directions).CreateDirection.__doc__ or "")[:1500],
                  "Offsets.CreateCurvature": (type(part.Offsets).CreateCurvature.__doc__ or "")[:600]}
    for name, fn in (("S1", s1), ("S2", s2), ("S3", s3), ("S4", s4), ("S5", s5), ("S6", s6), ("S7", s7), ("S8", s8)):
        block(name, fn, part)
    res["errors"] = nxh.feature_errors(part)
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res.update(chk.report())
if "error" in res:
    res["result"] = "FAIL"
nxh.write_json(os.path.join(OUT, "spline_rules.json"), res)
