"""Round-3 checks for sketches and curves on NX 2206 (headless run_journal).

  run_journal.ps1 -Script round3_checks.py -WorkDir <out> -JArgs <out>

  A1  associative arc: which direction is angle 0 for each way of making the support plane
  A2  assoc_circle / assoc_rounded_rect at an expression-driven height, ONE CurveFeature rule, regenerates
  A3  a rule-only section without a seed ignores the help point
  B*  sketch pattern (again), instances by dimensions (workaround), trim curve (again)
  C*  sketch tools: ellipse, fixed constraint, reference conversion, mirror about a drawn centre line,
      sketch intersection curve / point, chamfer, polygon
  D1  parametric spline driven by sketch points (spline FEATURE through dimensioned sketch points)
  E*  offset in face: what decides the side; offset curve 3D axial; point set; wrap curve
  F*  helix by limits and with a linear pitch law; text on a curve; bridge G3
  G1  projected sketch curve whose parent edge disappears: how it shows, how it recovers
Recipes that could not be made to work are listed under "not_working" (they do not fail the run).
"""
import math
import os
import re
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import nxh  # noqa: E402
import nxf  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
ONLY = list(sys.argv[2:])
P, V, UPD, UFS = nxh.P, nxh.V, nxh.UPD, nxh.UFS
NF, NULL = nxh.NULL_FEATURE, NXOpen.NXObject.Null
SK, A, CP = NXOpen.Sketch, NXOpen.Sketch.AssocType, NXOpen.Sketch.ConstraintPointType
MT = NXOpen.PlaneTypes.MethodType
log = nxh.Log(os.path.join(OUT, "round3_checks.log"))
res = {"checks": {}, "not_working": {}, "api": {}}


def check(name, ok, **data):
    res["checks"][name] = dict(ok=bool(ok), **data)
    log(("PASS " if ok else "FAIL ") + name, data)
    return ok


def api(key, obj):
    out = {}
    cls = type(obj)
    for n in dir(cls):
        if n.startswith("_") or n in ("Tag", "Null", "Validate", "Destroy", "GetObject", "ShowResults", "PreviewBuilder") or \
                n.startswith(("Hide", "Show", "Unset", "ParentFeature", "Patch", "Surrounding", "SetParent", "GetCommitted", "GetPreview")):
            continue
        try:
            d = getattr(cls, n).__doc__ or ""
        except Exception:  # noqa: BLE001
            d = ""
        m = re.findall(r"Signature ``(.*?)``", d)
        t = re.findall(r":rtype: (.*?)\n", d + "\n")
        out[n] = ((m[0] if m and "(" in m[0] else "") + " -> " + (t[0].strip() if t else "")).strip()[:120]
    res["api"][key] = out


def recipe(name, fn):
    if ONLY and name not in ONLY:
        return None
    r, err = nxh.attempt(name, fn, log=log)
    if err:
        res["not_working"][name] = err
    try:
        sk = nxh.S.ActiveSketch
        if sk is not None:
            sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
    except Exception:  # noqa: BLE001
        pass
    return r


_PROPS = UFS.ModlGeneral.AskCurveProps


def at(c, t):
    r = _PROPS(c.Tag, float(t))
    return [round(x, 6) for x in r[0]], [round(x, 6) for x in r[1]]


def near(a, b, tol=1e-3):
    return all(abs(x - y) < tol for x, y in zip(a, b))


def par(a, b, tol=1e-4):
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(x * x for x in b))
    return na > 0 and nb > 0 and abs(abs(sum(x * y for x, y in zip(a, b)) / (na * nb)) - 1.0) < tol


def curves_of(f):
    return [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)]


def total_length(cs):
    return sum(c.GetLength() for c in cs)


def fill(sec, rules, help_point, seed=None, types=NXOpen.Section.AllowTypes.OnlyCurves):
    sec.SetAllowedEntityTypes(types)
    sec.AddToSection(rules, seed if seed is not None else NULL, NULL, NULL, P(*help_point), NXOpen.Section.Mode.Create, False)
    return sec


# ------------------------------------------------------------------ associative line / arc helpers (A1, A2)
def fixed_plane(part, origin, normal):
    return part.Planes.CreatePlane(P(*origin), V(*normal), UPD)


def offset_plane(part, datum, formula):
    """Smart NXOpen.Plane at an expression-driven offset from a datum plane (follows the expression)."""
    pl = part.Planes.CreatePlane(P(0, 0, 0), V(0, 0, 1), UPD)
    pl.SetMethod(MT.Distance)
    pl.SetGeometry([datum])
    pl.Expression.RightHandSide = str(formula)
    pl.Evaluate()
    return pl


def assoc_line(part, p0, p1):
    LB = NXOpen.Features.AssociativeLineBuilder
    b = part.BaseFeatures.CreateAssociativeLineBuilder(NXOpen.Features.AssociativeLine.Null)
    try:
        b.StartPointOptions = LB.StartOption.Point
        b.StartPoint.Value = nxh.point(part, *p0)
        b.EndPointOptions = LB.EndOption.Point
        b.EndPoint.Value = nxh.point(part, *p1)
        b.Associative = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, curves_of(f)[0]


def assoc_arc(part, centre, radius, a0, a1, plane, full=False):
    """Associative arc by centre + radius in `plane` (an NXOpen.Plane). Angles in degrees in the PLANE's own frame
    (see plane_zero_dir); full=True makes a closed circle."""
    AB = NXOpen.Features.AssociativeArcBuilder
    LO = NXOpen.GeometricUtilities.CurveExtendData.LimitOptions
    b = part.BaseFeatures.CreateAssociativeArcBuilder(NXOpen.Features.AssociativeArc.Null)
    try:
        b.Type = AB.Types.ArcFromCenter
        b.CenterPoint.Value = nxh.point(part, *centre)
        b.EndPointOptions = AB.EndOption.Radius
        b.Radius.RightHandSide = str(radius)
        if plane is not None:
            b.SupportPlaneData.SupportPlane = plane
        b.Limits.StartLimit.LimitOption = LO.Value
        b.Limits.EndLimit.LimitOption = LO.Value
        b.Limits.StartLimit.Distance.RightHandSide = str(a0)
        b.Limits.EndLimit.Distance.RightHandSide = str(a1)
        b.Limits.FullCircle = bool(full)
        b.Associative = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, curves_of(f)[0]


def arc_frame(part, plane, centre=(0.0, 0.0, 0.0)):
    """Measure the arc frame of a support plane: (direction of angle 0, direction of angle 90) as unit vectors.
    Costs one throw-away arc that is undone."""
    m = nxh.mark("arc frame", False)
    f, c = assoc_arc(part, centre, 10, 0, 90, plane)
    p0, p1 = at(c, 0)[0], at(c, 1)[0]
    cp = c.CenterPoint
    d0 = [round((p0[i] - (cp.X, cp.Y, cp.Z)[i]) / 10, 6) for i in range(3)]
    d1 = [round((p1[i] - (cp.X, cp.Y, cp.Z)[i]) / 10, 6) for i in range(3)]
    nxh.undo_to(m)
    return d0, d1


def plane_angles(frame, th0, th1):
    """Limits (degrees, in the support plane's own frame) for an arc that runs counter-clockwise about +Z from the
    absolute angle th0 to th1 (measured from +X). Works for any plane parallel to XY, whatever its frame."""
    d0, d1 = frame

    def to_plane(th):
        u = (math.cos(math.radians(th)), math.sin(math.radians(th)), 0.0)
        return math.degrees(math.atan2(sum(a * b for a, b in zip(u, d1)), sum(a * b for a, b in zip(u, d0))))

    right_handed = (d0[0] * d1[1] - d0[1] * d1[0]) > 0          # plane X x plane Y along +Z ?
    start = to_plane(th0) if right_handed else to_plane(th1)
    start = start % 360.0
    return round(start, 9), round(start + (th1 - th0), 9)


def assoc_circle(part, centre, radius, plane):
    """Closed associative circle (ONE ARC feature, FullCircle). Returns ([feature], seed curve)."""
    f, c = assoc_arc(part, centre, radius, 0, 360, plane, full=True)
    return [f], c


def assoc_rounded_rect(part, w, h, r, z, plane):
    """Rounded rectangle w x h (formulas), corner radius r, centred on the Z axis in the plane Z = z (plane parallel
    to XY, e.g. offset_plane(part, datum_xy, z)). 4 LINE + 4 ARC features. Returns (features, seed curve = bottom line)."""
    frame = arc_frame(part, plane)
    X, Y = f"({w})/2", f"({h})/2"
    feats = []
    f, seed = assoc_line(part, (f"-{X}+({r})", f"-{Y}", z), (f"{X}-({r})", f"-{Y}", z))
    feats.append(f)
    for p0, p1 in (((X, f"-{Y}+({r})", z), (X, f"{Y}-({r})", z)), ((f"{X}-({r})", Y, z), (f"-{X}+({r})", Y, z)),
                   ((f"-{X}", f"{Y}-({r})", z), (f"-{X}", f"-{Y}+({r})", z))):
        feats.append(assoc_line(part, p0, p1)[0])
    for cx, cy, a0 in ((f"{X}-({r})", f"-{Y}+({r})", 270), (f"{X}-({r})", f"{Y}-({r})", 0),
                       (f"-{X}+({r})", f"{Y}-({r})", 90), (f"-{X}+({r})", f"-{Y}+({r})", 180)):
        s0, s1 = plane_angles(frame, a0, a0 + 90)
        feats.append(assoc_arc(part, (cx, cy, z), r, s0, s1, plane)[0])
    return feats, seed


def run():
    part = nxh.new_part(os.path.join(OUT, "round3_checks.prt"))
    dat = nxh.Datums(part)
    R = part.ScRuleFactory
    for n, f, u in (("z1", "10", "mm"), ("rr_w", "40", "mm"), ("rr_h", "24", "mm"), ("rr_r", "5", "mm"), ("c_r", "8", "mm"),
                    ("pitch", "12", "mm"), ("hx_h", "20", "mm")):
        nxh.expr(part, n, f, u)

    # ---------------- A1 angle-zero rule
    def a1():
        cases = {
            "no support plane": None,
            "fixed plane normal +Z": fixed_plane(part, (0, 0, 0), (0, 0, 1)),
            "fixed plane normal -Z": fixed_plane(part, (0, 0, 0), (0, 0, -1)),
            "fixed plane normal +Y": fixed_plane(part, (0, 0, 0), (0, 1, 0)),
            "fixed plane normal +X": fixed_plane(part, (0, 0, 0), (1, 0, 0)),
            "smart offset from datum XY": offset_plane(part, dat.xy, "z1"),
            "smart offset from datum XZ": offset_plane(part, dat.xz, "z1"),
            "smart offset from datum YZ": offset_plane(part, dat.yz, "z1"),
        }
        out = {}
        for k, pl in cases.items():
            try:
                d0, d1 = arc_frame(part, pl)
                row = {"angle0": d0, "angle90": d1}
                if pl is not None:
                    m = pl.Matrix
                    m = getattr(m, "Element", m)
                    row["plane_X"] = [round(m.Xx, 6), round(m.Xy, 6), round(m.Xz, 6)]
                    row["plane_Y"] = [round(m.Yx, 6), round(m.Yy, 6), round(m.Yz, 6)]
                    row["plane_normal"] = [round(pl.Normal.X, 6), round(pl.Normal.Y, 6), round(pl.Normal.Z, 6)]
                    row["angle0_is_plane_X"] = near(d0, row["plane_X"], 1e-5)
                    row["angle90_is_plane_Y"] = near(d1, row["plane_Y"], 1e-5)
                out[k] = row
            except Exception as e:  # noqa: BLE001
                out[k] = "ERR " + str(e)
        res["A1_table"] = out
        rows = [v for v in out.values() if isinstance(v, dict) and "plane_X" in v]
        check("A1 arc angle 0 = X axis of the support plane's own matrix, 90 = its Y axis (all plane kinds)",
              len(rows) == 7 and all(r["angle0_is_plane_X"] and r["angle90_is_plane_Y"] for r in rows),
              **{k: (v if isinstance(v, str) else {"angle0": v["angle0"], "angle90": v["angle90"]}) for k, v in out.items()})

    recipe("A1", a1)

    # ---------------- A2 closed associative sections at an expression-driven height, ONE CurveFeature rule
    def a2():
        pl = offset_plane(part, dat.xy, "z1")
        feats, seed = assoc_rounded_rect(part, "rr_w", "rr_h", "rr_r", "z1", pl)
        hp = at(seed, 0.5)[0]
        sec = nxh.section(part, rules=[R.CreateRuleCurveFeature(feats)], seed=seed, help_point=hp)
        ex = nxh.extrude(part, sec, (0, 0, 1), 0, 3)
        b1 = ex.GetBodies()[0]
        area = lambda w, h, r: w * h - (4 - math.pi) * r * r  # noqa: E731
        v1 = nxh.volume(part, b1) if b1.IsSolidBody else 0.0
        cf, cseed = assoc_circle(part, (100, 0, "z1"), "c_r", pl)
        sec2 = nxh.section(part, rules=[R.CreateRuleCurveFeature(cf)], seed=cseed, help_point=at(cseed, 0.1)[0])
        ex2 = nxh.extrude(part, sec2, (0, 0, 1), 0, 3)
        b2 = ex2.GetBodies()[0]
        v2 = nxh.volume(part, b2) if b2.IsSolidBody else 0.0
        ok1 = abs(v1 - area(40, 24, 5) * 3) < 0.01 and abs(v2 - math.pi * 64 * 3) < 0.01 and nxh.bbox(b1)[2] == 10.0
        for n, val in (("z1", 25), ("rr_w", 50), ("rr_r", 8), ("c_r", 5)):
            nxh.set_expr(part, n, val)
        nxh.update()
        v1b, v2b = nxh.volume(part, b1), nxh.volume(part, b2)
        errs = nxh.feature_errors(part)
        check("A2 assoc_rounded_rect + assoc_circle: one CurveFeature rule each, solid, regenerates",
              ok1 and abs(v1b - area(50, 24, 8) * 3) < 0.01 and abs(v2b - math.pi * 25 * 3) < 0.01 and nxh.bbox(b1)[2] == 25.0 and not errs,
              rect_features=len(feats), rect_volume=v1, rect_expect=area(40, 24, 5) * 3, circle_volume=v2, circle_expect=math.pi * 64 * 3,
              after_edit=[v1b, area(50, 24, 8) * 3, v2b, math.pi * 25 * 3], z_after=nxh.bbox(b1)[2], errors=errs)
        for n, val in (("z1", 10), ("rr_w", 40), ("rr_r", 5), ("c_r", 8)):
            nxh.set_expr(part, n, val)
        nxh.update()
        # A3: help point with and without a seed
        out = {}
        for label, sd in (("no seed", None), ("seed = bottom line", seed)):
            row = []
            for hp2 in ((-14.0, -12.0, 10.0), (14.0, -12.0, 10.0), (20.0, 5.0, 10.0)):
                s = part.Sections.CreateSection(0.0095, 0.01, 0.5)
                s.AddToSection([R.CreateRuleCurveFeature(feats)], sd if sd is not None else NULL, NULL, NULL, P(*hp2), NXOpen.Section.Mode.Create, False)
                try:
                    st = s.GetStartAndDirection()
                    row.append({"help": hp2, "start": [round(st[1].X, 3), round(st[1].Y, 3), round(st[1].Z, 3)],
                                "dir": [round(st[2].X, 3), round(st[2].Y, 3), round(st[2].Z, 3)]})
                except Exception as e:  # noqa: BLE001
                    row.append({"help": hp2, "err": str(e)})
            out[label] = row
        res["A3_table"] = out
        ns = {str(r.get("start")) + str(r.get("dir")) for r in out["no seed"]}
        ws = {str(r.get("start")) + str(r.get("dir")) for r in out["seed = bottom line"]}
        check("A3 rule-only section: without a seed the help point changes nothing; with a seed it picks the start end",
              len(ns) == 1 and len(ws) >= 2, no_seed_variants=len(ns), with_seed_variants=len(ws), **out)

    recipe("A2", a2)

    hx, hy = P(50, 0, 0), P(0, 50, 0)
    Q = lambda x, y: P(x, y, 0)  # noqa: E731

    def circle_sketch(name, x0, y0):
        sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, name)
        c = part.Curves.CreateArc(Q(x0, y0), V(1, 0, 0), V(0, 1, 0), 2.0, 0.0, 2 * math.pi)
        nxf.add(sk, c, infer=False)
        nxf.pdim(sk, dat.y, hy, c, A.ArcCenter, Q(x0 / 2, y0 - 6), str(x0))
        nxf.pdim(sk, dat.x, hx, c, A.ArcCenter, Q(x0 - 8, y0 / 2), str(y0))
        nxf.diameter_dim(sk, c, Q(x0 + 2, y0), Q(x0 + 6, y0 + 8), "4")
        sk.Update()
        return sk, c

    # ---------------- B1 sketch pattern: focused variants
    def b1():
        out = {}
        PD = NXOpen.GeometricUtilities.PatternDefinition
        SP = NXOpen.GeometricUtilities.PatternSpacing.SpacingType

        def variant(label, configure):
            m = nxh.mark("b1 " + label, False)
            step = "sketch"
            try:
                sk, c = circle_sketch("SKT_PAT", 10.0, 200.0)
                pb = part.Sketches.CreateSketchPatternBuilder(NXOpen.SketchPattern.Null)
                try:
                    if "api" not in out:
                        api("SketchPattern", pb)
                        out["api"] = True
                    step = configure(pb, sk, c) or "commit"
                    pb.Commit()
                finally:
                    pb.Destroy()
                sk.Update()
                arcs = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Arc)]
                out[label] = {"arcs": len(arcs), "x": sorted(round(a.CenterPoint.X, 3) for a in arcs), "status": list(nxf.sketch_status(sk))}
                sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
                return True
            except Exception as e:  # noqa: BLE001
                out[label] = f"ERR step {step}: {e}"
                try:
                    if nxh.S.ActiveSketch is not None:
                        nxh.S.ActiveSketch.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
                except Exception:  # noqa: BLE001
                    pass
                nxh.undo_to(m)
                return False

        def sec_first(pb, c, types):
            pb.Section.SetAllowedEntityTypes(types)
            pb.Section.AddToSection([R.CreateRuleCurveDumb([c])], c, NULL, NULL, P(12, 200, 0), NXOpen.Section.Mode.Create, False)
            pb.UpdateInputSection()

        def linear(direction_of, updates=("UpdateLinearDirectionObject", "UpdateCopies", "EvaluatePattern"), constraint=True):
            def cfg(pb, sk, c):
                sec_first(pb, c, NXOpen.Section.AllowTypes.OnlyCurves)
                ps = pb.PatternService
                ps.PatternType = PD.PatternEnum.Linear
                rd = ps.RectangularDefinition
                rd.UseYDirectionToggle = False
                rd.XDirection = direction_of(sk)
                rd.XSpacing.SpaceType = SP.Offset
                rd.XSpacing.NCopies.RightHandSide = "4"
                rd.XSpacing.PitchDistance.RightHandSide = "pitch"
                pb.CreateConstraint = constraint
                for u in updates:
                    getattr(pb, u)()
            return cfg

        def circular(pb, sk, c):
            sec_first(pb, c, NXOpen.Section.AllowTypes.OnlyCurves)
            ps = pb.PatternService
            ps.PatternType = PD.PatternEnum.Circular
            cd = ps.CircularDefinition
            api("CircularDefinition", cd)
            cd.RotationCenter = dat.origin
            pb.UpdateCenterPoint()
            cd.AngularSpacing.SpaceType = SP.Offset
            cd.AngularSpacing.NCopies.RightHandSide = "4"
            cd.AngularSpacing.PitchAngle.RightHandSide = "90"
            pb.CreateConstraint = True
            pb.UpdateCopies()
            pb.EvaluatePattern()

        def ref_line_dir(sk):
            ln = part.Curves.CreateLine(Q(0, 190), Q(30, 190))
            nxf.add(sk, ln, infer=False)
            sk.Update()
            return part.Directions.CreateDirection(ln, NXOpen.Sense.Forward, UPD)

        ok = False
        # Linear layout: every variant tried (direction from datum axis / sketch line, with and without the Update* calls,
        # with and without a persistent relation) fails at Commit with "Incorrect object for this operation." and makes
        # run_journal exit 1, so only the circular layout is exercised here. linear() is kept for reference.
        for label, cfg in (("circular about the datum origin", circular),):
            ok = variant(label, cfg) or ok
        out.pop("api", None)
        res["B1_variants"] = out
        if not ok:
            raise RuntimeError(str(out))
        good = [k for k, v in out.items() if isinstance(v, dict) and v["arcs"] == 4]
        circ = out.get("circular about the datum origin")
        check("B1 sketch CIRCULAR pattern commits headless (4 instances at 90 deg, DOF 0)", isinstance(circ, dict) and circ["arcs"] == 4
              and circ["x"] == [-200.0, -10.0, 10.0, 200.0] and circ["status"] == ["WellConstrained", 0], working=good, **out)

    recipe("B1", b1)

    # ---------------- B2 workaround: instances as ordinary curves, positions by formula dimensions
    def b2():
        sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "SKT_INSTANCES")
        arcs = []
        for i in range(4):
            x0 = 10.0 + 12.0 * i
            c = part.Curves.CreateArc(Q(x0, 230), V(1, 0, 0), V(0, 1, 0), 2.0, 0.0, 2 * math.pi)
            nxf.add(sk, c, infer=False)
            nxf.pdim(sk, dat.y, hy, c, A.ArcCenter, Q(x0, 222 - 3 * i), f"10+{i}*pitch")
            nxf.pdim(sk, dat.x, hx, c, A.ArcCenter, Q(x0 - 6, 236), "230")
            if i == 0:
                nxf.diameter_dim(sk, c, Q(x0 + 2, 230), Q(x0 + 5, 240), "4")
            else:
                sk.CreateEqualRadiusConstraint(nxf.cg(c), nxf.cg(arcs[0]))
            arcs.append(c)
        st = nxf.finish_sketch(sk)
        nxh.set_expr(part, "pitch", "15")
        nxh.update()
        xs = sorted(round(a.CenterPoint.X, 3) for a in arcs)
        check("B2 pattern workaround: 4 circles, formula dimensions + equal radius, DOF 0, follows the pitch",
              st["dof"] == 0 and st["status"] == "WellConstrained" and xs == [10.0, 25.0, 40.0, 55.0], x_after_pitch_15=xs, **st)
        nxh.set_expr(part, "pitch", "12")
        nxh.update()

    recipe("B2", b2)

    # ---------------- B3 trim curve with associative features as input
    def b3():
        ft, target = assoc_line(part, (100, 400, 0), (160, 400, 0))
        fb, bound = assoc_line(part, (140, 390, 0), (140, 410, 0))
        out = {}
        for label, mode in (("regions selected", 1), ("commit without region call", 0), ("bounding via BoundingObject.Value", 2)):
            m = nxh.mark("b3", False)
            step = "create"
            try:
                b = part.Features.CreateTrimCurve2FeatureBuilder(NXOpen.Features.TrimCurve2.Null)
                try:
                    step = "curve to trim"
                    fill(b.CurveToTrim, [R.CreateRuleCurveFeature([ft])], (155, 400, 0), target)
                    step = "bounding object"
                    bo = b.CreateTrimCurveBoundingObjectBuilder()
                    if mode == 2:
                        bo.BoundingObject.Value = bound
                    else:
                        bo.BoundingObjectList.Add(bound)
                    b.BoundingObjectList.Append(bo)
                    if mode:
                        step = "regions"
                        b.UpdateTrimRegionsAndDivideLocations()
                        b.SelectTrimRegion(P(150, 400, 0))
                    b.CurveOptions.Associative = True
                    step = "commit"
                    f = b.Commit()
                finally:
                    b.Destroy()
                cs = curves_of(f)
                out[label] = {"type": f.FeatureType, "length": round(total_length(cs), 4), "ends": [at(cs[0], 0)[0], at(cs[0], 1)[0]]}
            except Exception as e:  # noqa: BLE001
                out[label] = f"ERR step {step}: {e}"
            nxh.undo_to(m)
        res["B3_variants"] = out
        good = [k for k, v in out.items() if isinstance(v, dict) and v["length"] in (40.0, 20.0)]
        if not good:
            raise RuntimeError(str(out))
        check("B3 trim curve at a bounding curve", True, working=good, **out)

    recipe("B3", b3)

    # ---------------- C1 ellipse, fixed, reference conversion, mirror about a drawn centre line
    def c1():
        sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "SKT_TOOLS")
        out = {}
        m3 = NXOpen.Matrix3x3()
        m3.Xx, m3.Xy, m3.Xz, m3.Yx, m3.Yy, m3.Yz, m3.Zx, m3.Zy, m3.Zz = 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0
        el = part.Curves.CreateEllipse(Q(0, 300), 12.0, 6.0, 0.0, 2 * math.pi, 0.0, part.NXMatrices.Create(m3))
        nxf.add(sk, el, infer=False)
        sk.Update()
        out["ellipse_free"] = list(nxf.sketch_status(sk))
        sk.CreateFixedConstraint(nxf.cg(el))
        sk.Update()
        out["ellipse_fixed"] = list(nxf.sketch_status(sk))
        out["ellipse_length"] = round(el.GetLength(), 3)
        # centre line (vertical, on the datum Y axis) drawn in the sketch, converted to reference, used as mirror line
        cl = part.Curves.CreateLine(Q(0, 320), Q(0, 360))
        ln = part.Curves.CreateLine(Q(10, 330), Q(25, 350))
        nxf.add(sk, cl, ln, infer=False)
        sk.CreateVerticalConstraint(nxf.cg(cl))
        sk.CreatePointOnCurveConstraint(nxf.cg(cl, CP.StartVertex), nxf.cg(dat.y), nxf.help_at(Q(0, 320)))
        cb = part.Sketches.CreateConvertToFromReferenceBuilder()
        try:
            api("ConvertToFromReference", cb)
            cb.InputObjects.Add(cl)
            enums = {k: nxh.enum_names(getattr(type(cb), k)) for k in dir(type(cb)) if k[0].isupper() and isinstance(getattr(type(cb), k), type)}
            res["api"]["ConvertToFromReference.enums"] = enums
            cb.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Reference
            cb.Commit()
        finally:
            cb.Destroy()
        out["centre_line_is_reference"] = bool(cl.IsReference) if hasattr(cl, "IsReference") else "no IsReference"
        mb = part.Sketches.CreateSketchMirrorPatternBuilder(NXOpen.SketchPattern.Null)
        try:
            mb.Section.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
            mb.Section.AddToSection([R.CreateRuleCurveDumb([ln])], ln, NULL, NULL, Q(10, 330), NXOpen.Section.Mode.Create, False)
            mb.UpdateInputSection()
            mb.DirectionObject.Value = cl
            mb.UpdateDirectionObject()
            mb.CreateConstraint = True
            mb.Commit()
        finally:
            mb.Destroy()
        sk.Update()
        lines = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Line) and g.Tag not in (cl.Tag, ln.Tag)]
        # persistent? move the source line end by a dimension and see the image follow
        nxf.pdim(sk, dat.y, hy, ln, A.EndPoint, Q(30, 356), "25")
        sk.Update()
        d = [c for c in sk.GetAllExpressions() if c.RightHandSide.strip() == "25"][0]
        d.RightHandSide = "32"
        sk.Update()
        img = sorted(round(at(lines[0], t)[0][0], 3) for t in (0, 1)) if lines else None
        out["mirror_image_x_after_source_end_moved_to_32"] = img
        out["status_end"] = list(nxf.sketch_status(sk))
        sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        res["C1_detail"] = out
        check("C1a ellipse in sketch + Fixed constraint: DOF drops to 0", out["ellipse_free"][1] > 0 and out["ellipse_fixed"][1] == 0, **{k: out[k] for k in ("ellipse_free", "ellipse_fixed", "ellipse_length")})
        check("C1b convert a centre line to reference and mirror about it; image follows the source", out["centre_line_is_reference"] is True
              and img is not None and img[0] == -32.0, reference=out["centre_line_is_reference"], image_x=img, status=out["status_end"])

    recipe("C1", c1)

    # ---------------- C2 sketch intersection curve / point, chamfer, polygon
    _f, blk = nxh.block(part, (200, 0, 0), (40, 30, 20))
    top = nxh.faces(blk, ftype=nxh.PLANE, normal=(0, 0, 1))[0]
    side = nxh.faces(blk, ftype=nxh.PLANE, normal=(0, -1, 0))[0]

    def c2():
        fp, dp = nxf.datum_plane(part, "offset", [dat.yz], 220)
        sk = nxf.new_sketch(part, dp, dat.y, dat.origin, "SKT_SECTION")
        out = {}
        try:
            b = part.Sketches.CreateIntersectionCurveBuilder(NXOpen.SketchIntersectionCurve.Null)
            try:
                api("SketchIntersectionCurve", b)
                b.FaceCollector.ReplaceRules([R.CreateRuleFaceDumb([top])], False)
                b.CollectorUpdated()
                b.DistanceTolerance = 0.01
                b.Associative = True
                b.Commit()
            finally:
                b.Destroy()
            sk.Update()
            ls = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Line)]
            out["intersection_curve"] = {"n": len(ls), "ends": [at(ls[0], 0)[0], at(ls[0], 1)[0]] if ls else None, "status": list(nxf.sketch_status(sk))}
        except Exception as e:  # noqa: BLE001
            out["intersection_curve"] = "ERR " + str(e)
        try:
            edge = [e for e in blk.GetEdges() if abs(nxh.bbox(e)[1]) < 1e-6 and abs(nxh.bbox(e)[4]) < 1e-6 and abs(nxh.bbox(e)[2] - 20) < 1e-6 and abs(nxh.bbox(e)[5] - 20) < 1e-6][0]
            b = part.Sketches.CreateIntersectionPointBuilder(NXOpen.SketchIntersectionPoint.Null)
            try:
                api("SketchIntersectionPoint", b)
                fill(b.Rail, [R.CreateRuleEdgeDumb([edge])], (210, 0, 20), edge, NXOpen.Section.AllowTypes.OnlyCurves)
                b.UpdateData()
                b.Commit()
            finally:
                b.Destroy()
            sk.Update()
            pts = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Point)]
            out["intersection_point"] = {"n": len(pts), "xyz": [[round(p.Coordinates.X, 3), round(p.Coordinates.Y, 3), round(p.Coordinates.Z, 3)] for p in pts]}
        except Exception as e:  # noqa: BLE001
            out["intersection_point"] = "ERR " + str(e)
        sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        res["C2_detail"] = out
        ic = out["intersection_curve"]
        check("C2a sketch Intersection Curve: face x sketch plane", isinstance(ic, dict) and ic["n"] == 1 and near(sorted(ic["ends"])[0], (220, 0, 20))
              and near(sorted(ic["ends"])[1], (220, 30, 20)), detail=ic)
        ip = out["intersection_point"]
        check("C2b sketch Intersection Point: edge pierces the sketch plane", isinstance(ip, dict) and [220.0, 0.0, 20.0] in ip["xyz"], detail=ip)

    recipe("C2", c2)

    def c3():
        sk = nxf.new_sketch(part, dat.xy, dat.x, dat.origin, "SKT_CHAMFER")
        l1 = part.Curves.CreateLine(Q(100, 300), Q(130, 300))
        l2 = part.Curves.CreateLine(Q(130, 300), Q(130, 320))
        nxf.add(sk, l1, l2)
        nxf.horizontal(sk, l1)
        nxf.vertical(sk, l2)
        b = part.Sketches.CreateSketchChamferBuilder()
        try:
            res["api"]["SketchChamfer.options"] = nxh.enum_names(NXOpen.SketchChamferBuilder.ChamferOptions)
            b.CurvesToChamfer.Add(l1)
            b.CurvesToChamfer.Add(l2)
            b.ChamferOption = NXOpen.SketchChamferBuilder.ChamferOptions.Symmetric
            b.Distance1.RightHandSide = "4"
            b.CreateDistance1Dimension = True
            b.TrimInputCurves = True
            b.HelpPoint = part.Points.CreatePoint(Q(128, 302))
            b.Commit()
        finally:
            b.Destroy()
        sk.Update()
        lines = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Line)]
        ch = [g for g in lines if g.Tag not in (l1.Tag, l2.Tag)]
        st = list(nxf.sketch_status(sk))
        sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
        check("C3 sketch chamfer 4 x 45 between two lines", len(ch) == 1 and abs(ch[0].GetLength() - 4 * math.sqrt(2)) < 1e-6 and abs(l1.GetLength() - 26) < 1e-6,
              chamfer_length=ch[0].GetLength() if ch else None, l1_length=l1.GetLength(), l2_length=l2.GetLength(), status=st)

    recipe("C3", c3)

    # ---------------- D1 parametric spline: spline FEATURE through dimensioned sketch points
    def d1():
        dq = nxh.Datums(part)
        sk = nxf.new_sketch(part, dq.yz, dq.y, dq.origin, "SKT_SPLINE_PTS")
        Y = lambda y, z: P(0, y, z)  # noqa: E731
        raw = [(300.0, 0.0), (310.0, 8.0), (325.0, 10.0), (340.0, 4.0)]
        pts = []
        for i, (y, z) in enumerate(raw):
            pt = part.Points.CreatePoint(Y(y, z))
            nxf.add(sk, pt, infer=False)
            nxf.pdim(sk, dq.z, P(0, 0, 50), pt, A.StartPoint, Y(y, -6.0 - 3 * i), str(y))
            nxf.pdim(sk, dq.y, P(0, 50, 0), pt, A.StartPoint, Y(y + 4, z + 4), str(z))
            pts.append(pt)
        st = nxf.finish_sketch(sk)
        SB = NXOpen.Features.StudioSplineBuilderEx
        b = part.Features.CreateStudioSplineBuilderEx(NULL)
        try:
            b.Type = SB.Types.ThroughPoints
            b.Degree = 3
            b.IsAssociative = True
            b.MatchKnotsType = SB.MatchKnotsTypes.NotSet
            for pt in pts:
                g = b.ConstraintManager.CreateGeometricConstraintData()
                g.Point = pt
                b.ConstraintManager.Append(g)
            f = b.Commit()
        finally:
            b.Destroy()
        c = curves_of(f)[0]
        e0 = at(c, 0)[0]
        first = [e for e in sk.GetAllExpressions() if e.RightHandSide.strip() in ("300", "300.0")][0]
        first.RightHandSide = "290"
        nxh.update()
        e1 = at(curves_of(f)[0], 0)[0]
        errs = nxh.feature_errors(part)
        parents = [p.GetFeatureName() for p in f.GetParents()]
        check("D1 spline feature through dimensioned sketch points follows the sketch", st["dof"] == 0 and near(e0, (0, 300, 0)) and near(e1, (0, 290, 0)) and not errs,
              start_before=e0, start_after=e1, parents=parents, type=f.FeatureType, sketch=st["status"], errors=errs)

    recipe("D1", d1)

    # ---------------- E1 offset in face: the side follows the section direction
    def e1():
        loop = top.GetEdges()
        seed = [e for e in loop if abs(nxh.bbox(e)[1]) < 1e-6 and abs(nxh.bbox(e)[4]) < 1e-6][0]          # the y = 0 edge of the top face
        out = []
        for hp in ((201.0, 0.0, 20.0), (239.0, 0.0, 20.0)):
            for sign in ("5", "-5"):
                m = nxh.mark("e1", False)
                b = part.Features.CreateAocsBuilder(NF)
                try:
                    sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
                    fill(sec, [R.CreateRuleEdgeDumb([seed])], hp, seed)
                    st = sec.GetStartAndDirection()
                    d = [round(st[2].X, 3), round(st[2].Y, 3), round(st[2].Z, 3)]
                    ess = part.CreateExpressionSectionSet(sec, "1", "MilliMeter", 0)
                    b.Offsets.Append(ess)
                    ess.ItemValue.RightHandSide = sign
                    b.FaceCollector = nxh.collector(part, faces=[top])
                    b.AssociativeOutputOption = True
                    b.DistanceTolerance = 0.01
                    f = b.Commit()
                    y = at(curves_of(f)[0], 0.5)[0][1]
                    # face normal x section direction = the "left" of the direction on the face
                    left_y = 1.0 * d[0]          # (0,0,1) x (dx,dy,0) = (-dy, dx, 0)
                    out.append({"help": hp, "value": sign, "section_dir": d, "curve_y": round(y, 3), "inside_face": 0 < y < 30,
                                "normal_x_dir_y": left_y})
                except Exception as e:  # noqa: BLE001
                    out.append({"help": hp, "value": sign, "err": str(e)})
                finally:
                    b.Destroy()
                nxh.undo_to(m)
        res["E1_table"] = out
        rows = [r for r in out if "err" not in r]
        # hypothesis: a positive value offsets towards (section direction x face normal), i.e. to the RIGHT of the direction
        rule = all((r["curve_y"] > 0) == ((-r["normal_x_dir_y"]) * float(r["value"]) > 0) for r in rows)
        rule_left = all((r["curve_y"] > 0) == ((r["normal_x_dir_y"]) * float(r["value"]) > 0) for r in rows)
        check("E1 offset in face: side = sign x (section direction, face normal) - deterministic once the section direction is read",
              len(rows) == 4 and (rule or rule_left), positive_goes="right of direction (dir x normal)" if rule else ("left of direction (normal x dir)" if rule_left else "no rule"),
              rows=rows)

    recipe("E1", e1)

    # ---------------- E2 offset curve 3D axial, E3 point set, E4 wrap curve
    def e2():
        src = nxh.line(part, (300, 0, 0), (340, 30, 10))
        OB = NXOpen.Features.OffsetCurveBuilder
        res["api"]["OffsetCurve.Types"] = nxh.enum_names(OB.Types)
        b = part.Features.CreateOffsetCurveBuilder(NF)
        try:
            b.Type = getattr(OB.Types, [n for n in nxh.enum_names(OB.Types) if "xial" in n][0])
            b.InputCurvesOptions.Associative = True
            b.Tolerance = 0.01
            fill(b.CurvesToOffset, [R.CreateRuleCurveDumb([src])], (300, 0, 0), src)
            b.Offset3dDistance.RightHandSide = "6"
            b.AxialOffsetDirection = nxh.direction(part, (0, 0, 1))
            f = b.Commit()
        finally:
            b.Destroy()
        c = curves_of(f)[0]
        e = sorted([at(c, 0)[0], at(c, 1)[0]])
        dmin = nxh.min_dist(c, src)
        check("E2 offset curve 3D Axial commits; minimum distance to the source ~ 6 (not a rigid translation)", abs(dmin - 6) < 0.02, ends=e, min_dist=dmin, length=c.GetLength(), source_length=src.GetLength())

    recipe("E2", e2)

    def e3():
        src = nxh.line(part, (300, 60, 0), (360, 60, 0))
        b = part.Features.CreatePointSetBuilder(NXOpen.Features.PointSet.Null)
        try:
            res["api"]["PointSet.defaults"] = [str(b.Type), str(b.CurvePointsBy)]      # user read-back: CurvePoints / EqualArcLength
            fill(b.SingleCurveOrEdgeCollector, [R.CreateRuleCurveDumb([src])], (300, 60, 0), src, NXOpen.Section.AllowTypes.OnlyCurves)
            b.NumberOfPointsExpression.RightHandSide = "5"
            b.StartPercentage.RightHandSide = "0"
            b.EndPercentage.RightHandSide = "100"
            b.Associative = True
            f = b.Commit()
        finally:
            b.Destroy()
        pts = sorted(round(p.Coordinates.X, 3) for p in f.GetEntities() if isinstance(p, NXOpen.Point))
        check("E3 point set: 5 points at equal arc length on a curve", pts == [300.0, 315.0, 330.0, 345.0, 360.0], x=pts, type=f.FeatureType)

    recipe("E3", e3)

    def e4():
        _f, cyl = nxh.cylinder(part, (400, 0, 0), (0, 0, 1), 30, 40)
        cface = nxh.faces(cyl, ftype=nxh.CYLINDER)[0]
        made = [k for k in dir(part.Features) if "Wrap" in k]
        res["api"]["Wrap.creators"] = made
        fp, dp = nxf.datum_plane(part, "tangent", [cface])
        info = {"origin": [round(dp.Origin.X, 3), round(dp.Origin.Y, 3), round(dp.Origin.Z, 3)], "normal": [round(dp.Normal.X, 3), round(dp.Normal.Y, 3), round(dp.Normal.Z, 3)]}
        o = dp.Origin
        # a slanted line lying in the tangent plane (the plane contains the Z direction and the tangent direction t)
        t = (-dp.Normal.Y, dp.Normal.X, 0.0)
        src = nxh.line(part, (o.X, o.Y, 5.0), (o.X + 20 * t[0], o.Y + 20 * t[1], 25.0))
        b = part.Features.CreateWrapBuilder(NXOpen.Features.WrapUnwrap.Null)
        step = "api"
        try:
            api("Wrap", b)
            try:
                res["api"]["Wrap.Types"] = nxh.enum_names(NXOpen.Features.WrapBuilder.Types)
                step = "type"
                b.Type = NXOpen.Features.WrapBuilder.Types.Wrap
                step = "curves"
                fill(b.Curves, [R.CreateRuleCurveDumb([src])], (o.X, o.Y, 5.0), src)
                step = "face"
                b.Faces.ReplaceRules([R.CreateRuleFaceDumb([cface])], False)
                step = "plane"
                b.Plane.Value = dp
                b.DistanceTolerance = 0.01
                b.Associative = True
                step = "commit"
                f = b.Commit()
            except Exception as e:  # noqa: BLE001
                raise RuntimeError(f"step {step}: {e} plane={info}")
        finally:
            b.Destroy()
        cs = curves_of(f)
        dev = max(abs(math.hypot(at(c, i / 20.0)[0][0] - 400, at(c, i / 20.0)[0][1]) - 15) for c in cs for i in range(21))
        zs = [at(c, tt)[0][2] for c in cs for tt in (0, 1)]
        check("E4 wrap a planar line from the tangent plane onto the cylinder (helix segment)", dev < 0.01 and abs(total_length(cs) - src.GetLength()) < 0.01,
              type=f.FeatureType, dev=dev, length=total_length(cs), source_length=src.GetLength(), z=[round(min(zs), 3), round(max(zs), 3)], plane=info)

    recipe("E4", e4)

    # ---------------- F1 helix by limits, constant and linear pitch
    def f1():
        HB = NXOpen.Features.HelixBuilder
        LT = NXOpen.GeometricUtilities.LawBuilder.Type

        def helix(p0, p1):
            b = part.Features.CreateHelixBuilder(NXOpen.Features.Helix.Null)
            try:
                b.OrientationOption = HB.OrientationOptions.Specified
                b.StartAngle.RightHandSide = "0"
                b.SizeOption = HB.SizeOptions.Diameter
                b.SizeLaw.LawType = LT.Constant
                b.SizeLaw.Value.RightHandSide = "20"
                if p1 is None:
                    b.PitchLaw.LawType = LT.Constant
                    b.PitchLaw.Value.RightHandSide = str(p0)
                else:
                    b.PitchLaw.LawType = LT.Linear
                    b.PitchLaw.StartValue.RightHandSide = str(p0)
                    b.PitchLaw.EndValue.RightHandSide = str(p1)
                b.LengthMethod = HB.LengthMethods.Limits
                b.StartLimit.Expression.RightHandSide = "0"
                b.EndLimit.Expression.RightHandSide = "hx_h"
                b.TurnDirection = HB.TurnDirections.RightHand
                b.DistanceTolerance = 0.001
                f = b.Commit()
            finally:
                b.Destroy()
            return f

        f = helix(4, None)
        c = curves_of(f)[0]
        exp = 5 * math.sqrt((math.pi * 20) ** 2 + 16)
        e = [at(c, 0)[0], at(c, 1)[0]]
        L1 = c.GetLength()
        f2 = helix(2, 6)
        c2 = curves_of(f2)[0]
        e2 = [at(c2, 0)[0], at(c2, 1)[0]]
        L2 = c2.GetLength()
        # pitch linear in HEIGHT: turns = (H/(p1-p0)) ln(p1/p0); pitch linear in TURNS: turns = 2H/(p0+p1)
        n_height = 20 / 4 * math.log(3)
        n_turns = 2 * 20 / 8
        turns_measured = (L2 ** 2 - 20 ** 2) ** 0.5 / (math.pi * 20)
        nxh.set_expr(part, "hx_h", "30")
        nxh.update()
        e3 = at(curves_of(f)[0], 1)[0]
        check("F1a helix by limits 0..hx_h, pitch 4: 5 turns, end z follows hx_h", abs(L1 - exp) < 0.02 and near(e[1], (10, 0, 20)) and near(e3, (-10, 0, 30)),
              length=L1, expect=exp, ends=e, end_after_hx_h_30=e3)
        check("F1b helix with a linear pitch law 2 -> 6 over the height", abs(e2[1][2] - 20) < 1e-3 and min(abs(turns_measured - n_height), abs(turns_measured - n_turns)) < 0.15,
              ends=e2, length=L2, turns_estimated_from_length=round(turns_measured, 3), turns_if_pitch_linear_in_height=round(n_height, 3),
              turns_if_pitch_linear_in_turns=round(n_turns, 3))
        nxh.set_expr(part, "hx_h", "20")
        nxh.update()

    recipe("F1", f1)

    # ---------------- F2 text on a curve
    def f2():
        TB = NXOpen.Features.TextBuilder
        path = nxh.arc(part, (500, 0, 0), (1, 0, 0), (0, 1, 0), 40.0, 0.0, math.pi)
        out = {}
        for label, orient in (("Natural", None), ("Vector +Z", (0, 0, 1))):
            m = nxh.mark("f2", False)
            b = part.Features.CreateTextBuilder(NXOpen.Features.Text.Null)
            try:
                b.Type = TB.Types.OnCurve
                b.Script = TB.ScriptOptions.Western
                b.SelectFont("Arial", TB.ScriptOptions.Western)
                b.TextString = "NX 2206"
                fill(b.OnCurvePlacementProfile, [R.CreateRuleCurveDumb([path])], (540, 0, 0), path)
                if orient is not None:
                    b.OrientationMethod = TB.OrientationMethodOptions.Vector
                    b.OrientationVector = nxh.direction(part, orient)
                b.FrameOnPath.AnchorLocation = NXOpen.GeometricUtilities.FrameOnPathBuilder.AnchorLocationType.Center
                b.FrameOnPath.AnchorPosition.IsPercentUsed = True
                b.FrameOnPath.AnchorPosition.Expression.RightHandSide = "50"
                b.FrameOnPath.Offset.RightHandSide = "0"
                b.FrameOnPath.Length.RightHandSide = "40"
                b.FrameOnPath.Height.RightHandSide = "8"
                f = b.Commit()
                cs = curves_of(f)
                rad = [math.hypot(at(c, t)[0][0] - 500, at(c, t)[0][1]) for c in cs for t in (0, 0.5, 1)]
                zz = [at(c, t)[0][2] for c in cs for t in (0, 0.5, 1)]
                out[label] = {"n": len(cs), "radius_range": [round(min(rad), 2), round(max(rad), 2)], "z_range": [round(min(zz), 2), round(max(zz), 2)]}
            except Exception as e:  # noqa: BLE001
                out[label] = "ERR " + str(e)
            finally:
                b.Destroy()
            nxh.undo_to(m)
        good = [k for k, v in out.items() if isinstance(v, dict) and v["n"] >= 5]
        check("F2 text on a curve (R40 arc)", bool(good), working=good, **out)

    recipe("F2", f2)

    # ---------------- G1 projected sketch curve loses its parent edge
    def g1():
        _f, b2 = nxh.block(part, (600, 0, 0), (40, 30, 10))
        e = [x for x in b2.GetEdges() if abs(nxh.bbox(x)[0] - 640) < 1e-6 and abs(nxh.bbox(x)[3] - 640) < 1e-6 and abs(nxh.bbox(x)[1]) < 1e-6 and abs(nxh.bbox(x)[4]) < 1e-6][0]
        cham = nxf.chamfer(part, [e], 4)
        topf = nxh.faces(b2, ftype=nxh.PLANE, normal=(0, 0, 1))[0]
        # the chamfer's edge on the top face: runs from (640,4,10) to ... no: chamfer on the vertical edge x=640,y=0 -> new top edge from (636,0,10) to (640,4,10)
        ce = [x for x in topf.GetEdges() if abs(nxh.bbox(x)[0] - 636) < 1e-6 and abs(nxh.bbox(x)[4] - 4) < 1e-6][0]
        sk = nxf.new_sketch(part, topf, dat.x, dat.origin, "SKT_ON_CHAMFER")
        pb = part.Sketches.CreateProjectBuilder(NF)
        try:
            pb.Tolerance = 0.01
            pb.Section.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
            pb.Section.AddToSection([R.CreateRuleEdgeDumb([ce])], ce, NULL, NULL, P(638, 2, 10), NXOpen.Section.Mode.Create, False)
            pb.Commit()
        finally:
            pb.Destroy()
        pl = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Line)][0]
        c = part.Curves.CreateArc(P(630, 8, 10), V(1, 0, 0), V(0, 1, 0), 1.5, 0.0, 2 * math.pi)
        nxf.add(sk, c, infer=False)
        nxf.pdim(sk, pl, P(638, 2, 10), c, A.ArcCenter, P(632, 4, 10), "6")
        nxf.pdim(sk, dat.x, hx, c, A.ArcCenter, P(626, 4, 10), "8")
        nxf.diameter_dim(sk, c, P(631.5, 8, 10), P(628, 12, 10), "3")
        st0 = nxf.finish_sketch(sk)
        x0 = round(c.CenterPoint.X, 4)
        out = {"before": {"status": st0["status"], "dof": st0["dof"], "centre_x": x0}}
        cham.Suppress()
        nxh.update()
        out["parent_suppressed"] = {"status": list(nxf.sketch_status(sk)), "errors": nxh.feature_errors(part, recheck=False),
                                    "sketch_feature_suppressed": sk.Feature.Suppressed,
                                    "feature_states": [(f.GetFeatureName(), f.Suppressed) for f in part.Features.GetFeatures()][-4:],
                                    "centre_x": round(c.CenterPoint.X, 4)}
        try:
            out["parent_suppressed"]["alerts"] = [str(f.GetFeatureWarningMessages()) for f in (sk.Feature,)]
        except Exception as e:  # noqa: BLE001
            out["parent_suppressed"]["alerts"] = "?" + str(e)
        cham.Unsuppress()
        nxh.update()
        out["restored"] = {"status": list(nxf.sketch_status(sk)), "errors": nxh.feature_errors(part), "centre_x": round(c.CenterPoint.X, 4),
                           "sketch_feature_suppressed": sk.Feature.Suppressed}
        res["G1_detail"] = out
        check("G1 projected curve loses its parent (chamfer suppressed): shows ONLY as a sketch warning + suppressed CPROJ; restored by unsuppress",
              out["before"]["dof"] == 0 and out["restored"]["status"] == ["WellConstrained", 0] and out["restored"]["centre_x"] == x0
              and "failed recipe" in str(out["parent_suppressed"]["alerts"])
              and any(n.startswith("Projected Curve") and sup for n, sup in out["parent_suppressed"]["feature_states"]), **out)

    recipe("G1", g1)

    # ---------------- F3 bridge G3
    def f3():
        a1_ = nxh.arc(part, (500, 150, 0), (1, 0, 0), (0, 1, 0), 20.0, math.pi / 2, math.pi)
        l2 = nxh.line(part, (540, 185, 0), (570, 185, 0))
        b = part.Features.CreateBridgeCurveBuilderEx(NXOpen.Features.BridgeCurve.Null)
        try:
            fill(b.StartSection, [R.CreateRuleCurveDumb([a1_])], (500.5, 170, 0), a1_)
            fill(b.EndSection, [R.CreateRuleCurveDumb([l2])], (541, 185, 0), l2)
            CT = NXOpen.GeometricUtilities.Continuity.ContinuityTypes
            b.StartConnectivity.Continuity.ContinuityType = CT.G3
            b.EndConnectivity.Continuity.ContinuityType = CT.G3
            b.IsAssociative = True
            f = b.Commit()
        finally:
            b.Destroy()
        c = curves_of(f)[0]
        s = 0.0 if math.dist(at(c, 0)[0], (500, 170, 0)) < math.dist(at(c, 1)[0], (500, 170, 0)) else 1.0
        r0 = abs(_PROPS(c.Tag, s)[5])
        r1 = abs(_PROPS(c.Tag, abs(s - 0.02))[5])
        check("F3 bridge G3 commits: curvature radius 20 at the arc end (same as the arc)",
              abs(r0 - 20) < 0.05 and f.FeatureType == "BRIDGE_CURVE", radius_at_end=r0, radius_2pct_inside=r1, order=getattr(c, "Order", None))

    recipe("F3", f3)

    res["errors"] = nxh.feature_errors(part)
    res["features"] = [(f["ts"], f["type"], f["name"]) for f in nxh.feature_table(part)]
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res["result"] = "PASS" if res["checks"] and all(c["ok"] for c in res["checks"].values()) and "error" not in res else "FAIL"
nxh.write_json(os.path.join(OUT, "round3_checks.json"), res)
