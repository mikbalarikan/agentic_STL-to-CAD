"""Inclined port on a housing, and a hole pattern about the port axis (NX 2206, headless).

    run_journal.ps1 -Script inclined_port.py -WorkDir <out> -JArgs <out>   ->  <out>\\inclined_port.json

The case where a Datum Axis FEATURE is the right tool (the axes of the Datum CSYS do not reach):
  A1  Datum Axis through two points (and the same axis by point + direction) - the hinge of the port
  P1  Datum Plane at an angle about A1         P2  Datum Plane offset from P1 = the port face
  sketch on P2 -> Extrude towards the body, end limit Until Selected (the housing wall), Unite
  bore: Extrude Subtract Until Selected (the housing bore)
  A2  Datum Axis of the port cylinder -> axis of the circular hole pattern on the inclined face
Everything follows the expressions port_ang, port_z, port_len: regenerated at 30 -> 45 deg.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities as GU  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "inclined_port.log"))
chk = nxh.Check()
res = {"result": "FAIL", "notes": {}}
P = nxh.P
BODY_D, BODY_ID, BODY_H = 60.0, 44.0, 90.0
PORT_OD, PORT_ID, PORT_LEN, PORT_Z, PORT_ANG = 26.0, 14.0, 48.0, 35.0, 30.0
HOLE_D, HOLE_PCD, HOLE_DEPTH, N_HOLES = 3.0, 20.0, 6.0, 4


def extrude_along(part, sec, direction, start=0, end=None, until=None, op=None, target=None):
    """Extrude along an ASSOCIATIVE direction (e.g. the normal of a datum plane) so that the feature follows
    when the plane turns. until = face for the end limit Until Selected."""
    b = part.Features.CreateExtrudeBuilder(nxh.NULL_FEATURE)
    try:
        b.Section = sec
        b.Direction = direction
        b.Limits.StartExtend.Value.RightHandSide = str(start)
        if until is not None:
            b.Limits.EndExtend.TrimType = GU.Extend.ExtendType.UntilSelected
            b.Limits.EndExtend.Target = until
        else:
            b.Limits.EndExtend.Value.RightHandSide = str(end)
        op = nxh.BOOL.Create if op is None else op
        b.BooleanOperation.Type = op
        if op != nxh.BOOL.Create:
            b.BooleanOperation.SetTargetBodies([target])
        return b.CommitFeature()
    finally:
        b.Destroy()


def pattern_about_axis(part, features, datum_axis, count):
    """Circular Pattern Feature about a DATUM AXIS object (stays associative to it)."""
    def layout(ps):
        ps.PatternType = nxf.PAT.Circular
        cd = ps.CircularDefinition
        cd.RotationAxis = nxf.axis_from(part, datum_axis)
        cd.AngularSpacing.NCopies.RightHandSide = str(count)
        cd.AngularSpacing.SpaceType = nxf.SPACE.Span
        cd.AngularSpacing.SpanAngle.RightHandSide = "360"
    return nxf._pattern_feature(part, list(features), layout, False)


def unit(v):
    m = math.sqrt(sum(x * x for x in v))
    return [x / m for x in v]


def measure(part, body, ang, pz, plen, tag):
    """Checks that depend on the port angle, height and length."""
    a = math.radians(ang)
    n = (math.cos(a), 0.0, math.sin(a))                    # designed port direction
    c = (0.0, 0.0, pz)                                     # the hinge point on the housing axis
    # min_coverage=0: the census estimates a cylinder's length from its bounding box, which is too long for an
    # inclined cylinder, so the port would be filed under "partial"
    cen = nxh.hole_census(part, body, min_coverage=0.0)
    port = [h for h in cen["bosses"] if abs(h["diameter"] - PORT_OD) < 1e-6]
    bore = [h for h in cen["holes"] if abs(h["diameter"] - PORT_ID) < 1e-6]
    holes = [h for h in cen["holes"] if abs(h["diameter"] - HOLE_D) < 1e-6]
    m = {"solids": len(nxh.solids(part)), "errors": nxh.feature_errors(part), "examine": nxh.examine_geometry(part, body),
         "port_axis": port[0]["axis"] if port else None, "bore_axis": bore[0]["axis"] if bore else None,
         "n_holes": len(holes), "hole_axes": [h["axis"] for h in holes], "volume": nxh.volume(part, body)}
    res["notes"][tag] = m
    chk.true(tag + " one solid, no feature errors", m["solids"] == 1 and not m["errors"], m["errors"])
    chk.true(tag + " Examine Geometry clean", all(v == 0 for v in m["examine"].values()), m["examine"])
    par = lambda ax: ax is not None and abs(abs(sum(p * q for p, q in zip(ax, n))) - 1.0) < 1e-9    # noqa: E731
    chk.true(tag + " port cylinder axis = designed direction (cos a, 0, sin a)", par(m["port_axis"]), m["port_axis"])
    chk.true(tag + " port bore axis = designed direction", par(m["bore_axis"]), m["bore_axis"])
    # port face: annulus at port_len from the hinge point, normal = port direction
    q = [c[i] + n[i] * plen for i in range(3)]
    ring = (q[0], q[1] + (HOLE_PCD + HOLE_D + PORT_OD) / 4.0, q[2])     # between the hole circle and the rim
    face = [f for f in body.GetFaces() if nxh.face_data(f)[0] == nxh.PLANE and abs(nxh.dist_to(part, f, ring)) < 1e-6]
    chk.true(tag + " port face lies port_len from the hinge point", len(face) == 1, len(face))
    if face:
        chk.true(tag + " port face normal = port direction", par(nxh.face_data(face[0])[2]), nxh.face_data(face[0])[2])
    # Until Selected: the bore is open into the housing, the boss is solid up to the housing wall
    t_wall = (BODY_D + BODY_ID) / 4.0 / math.cos(a)                               # where the port axis crosses the wall
    chk.true(tag + " bore passes through the housing wall (point on the port axis in the wall is void)",
             nxh.dist_to(part, body, [c[i] + n[i] * t_wall for i in range(3)]) > 0.5)
    t_out = BODY_D / 2.0 / math.cos(a) + 1.0                                       # just outside the housing wall
    probe = [c[i] + n[i] * t_out for i in range(3)]
    probe[1] += (PORT_OD + PORT_ID) / 4.0
    chk.true(tag + " boss reaches the housing wall (point in the boss wall next to the housing is material)",
             nxh.dist_to(part, body, probe) < -0.5, nxh.dist_to(part, body, probe))
    chk.true(tag + " hole pattern: %d holes, all parallel to the port axis" % N_HOLES, m["n_holes"] == N_HOLES and all(par(ax) for ax in m["hole_axes"]),
             m["hole_axes"])
    # hole centres sit on the pitch circle around the port axis
    rad = []
    for h in holes:
        d = [h["point"][i] - c[i] for i in range(3)]
        k = sum(d[i] * n[i] for i in range(3))
        rad.append(math.sqrt(max(0.0, sum((d[i] - k * n[i]) ** 2 for i in range(3)))))
    chk.true(tag + " hole axes on the pitch circle around the port axis", bool(rad) and all(abs(r - HOLE_PCD / 2.0) < 1e-6 for r in rad), rad)
    return m


def run():
    part = nxh.new_part(os.path.join(OUT, "inclined_port.prt"))
    dat = nxh.Datums(part)
    for name, val, u in (("body_d", BODY_D, "mm"), ("body_id", BODY_ID, "mm"), ("body_h", BODY_H, "mm"), ("port_od", PORT_OD, "mm"),
                         ("port_id", PORT_ID, "mm"), ("port_len", PORT_LEN, "mm"), ("port_z", PORT_Z, "mm"), ("port_ang", PORT_ANG, "deg"),
                         ("hole_d", HOLE_D, "mm"), ("hole_pcd", HOLE_PCD, "mm"), ("n_holes", N_HOLES, None)):
        nxh.expr(part, name, val, u)
    _f, body = nxh.cylinder(part, (0, 0, 0), (0, 0, 1), "body_d", "body_h")
    nxh.cylinder(part, (0, 0, 0), (0, 0, 1), "body_id", "body_h", op=nxh.BOOL.Subtract, target=body)
    v0 = nxh.volume(part, body)
    outer = nxh.one(nxh.faces(body, ftype=nxh.CYLINDER, radius=BODY_D / 2), "housing outer wall")
    inner = nxh.one(nxh.faces(body, ftype=nxh.CYLINDER, radius=BODY_ID / 2), "housing bore")

    # A1: datum axis through two points; the same axis by point + direction
    fa1, a1 = nxf.datum_axis(part, "two_points", (0, -20, "port_z"), (0, 20, "port_z"), name="AX_PORT_HINGE")
    fa1b, a1b = nxf.datum_axis(part, "point_dir", (0, 0, "port_z"), (0, 1, 0), name="AX_PORT_HINGE_PD")
    d1, d1b = a1.Direction, a1b.Direction
    chk.true("A1 datum axis through two points: direction +Y at z = port_z", abs(abs(d1.Y) - 1) < 1e-12 and abs(a1.Origin.Z - PORT_Z) < 1e-9
             and abs(a1.Origin.X) < 1e-9, (d1.X, d1.Y, d1.Z, a1.Origin.Z))
    chk.true("A1 point + direction gives the same line", abs(abs(d1b.Y) - 1) < 1e-12 and abs(a1b.Origin.Z - PORT_Z) < 1e-9, (d1b.Y, a1b.Origin.Z))

    # P1: plane through A1 at port_ang to the YZ plane; its normal is the port direction
    fp1, p1 = nxf.datum_plane(part, "angle", [dat.yz, a1], "port_ang", name="PL_PORT_ANGLE")
    n1 = (p1.Normal.X, p1.Normal.Y, p1.Normal.Z)
    a = math.radians(PORT_ANG)
    res["notes"]["P1_normal"] = n1
    up = abs(abs(n1[0]) - math.cos(a)) < 1e-9 and abs(n1[1]) < 1e-12 and n1[0] * n1[2] > 0
    if not up:                                              # the other rotation sense: use the negative angle
        nxh.set_expr(part, "port_ang", PORT_ANG)           # (kept positive; the plane formula is negated instead)
        fp1.GetExpressions()[0].RightHandSide = "-port_ang"
        nxh.update()
        n1 = (p1.Normal.X, p1.Normal.Y, p1.Normal.Z)
    res["notes"]["P1_formula"] = fp1.GetExpressions()[0].RightHandSide
    chk.true("P1 plane at port_ang about A1: normal = (cos a, 0, sin a) up to sign",
             abs(abs(n1[0]) - math.cos(a)) < 1e-9 and abs(abs(n1[2]) - math.sin(a)) < 1e-9 and n1[0] * n1[2] > 0, n1)
    chk.true("P1 contains the hinge axis", abs(n1[0] * (p1.Origin.X) + n1[2] * (p1.Origin.Z - PORT_Z)) < 1e-9, (p1.Origin.X, p1.Origin.Z))

    # P2: the port face plane, port_len out along the port direction (sign of the offset found by measurement)
    sign = "" if n1[0] > 0 else "-"
    fp2, p2 = nxf.datum_plane(part, "offset", [p1], sign + "port_len", name="PL_PORT_FACE")
    o2 = (p2.Origin.X, p2.Origin.Y, p2.Origin.Z)
    want = (math.cos(a) * PORT_LEN, math.sin(a) * PORT_LEN + PORT_Z)
    dist = abs((o2[0] - want[0]) * math.cos(a) + (o2[2] - want[1]) * math.sin(a))
    chk("P2 offset plane passes through hinge point + port_len x port direction", dist, 0.0, 1e-9)
    n2 = (p2.Normal.X, p2.Normal.Y, p2.Normal.Z)
    inward = NXOpen.Sense.Reverse if n2[0] > 0 else NXOpen.Sense.Forward          # towards the housing
    d_in = part.Directions.CreateDirection(p2, inward, nxh.UPD)

    # port boss: circle on P2, centre = projection of the hinge point, Extrude Until Selected (outer wall), Unite
    hinge = nxh.point(part, 0, 0, "port_z")
    sk = nxf.new_sketch(part, p2, dat.y, hinge, "SK_PORT")
    c_od = nxf.sketch_circle(part, sk, hinge, "port_od")
    st1 = nxf.finish_sketch(sk)
    chk.true("port sketch on the inclined plane fully constrained", st1["status"] == "WellConstrained" and st1["dof"] == 0, st1)
    q = [0 + math.cos(a) * PORT_LEN, 0.0, PORT_Z + math.sin(a) * PORT_LEN]
    f_boss = extrude_along(part, nxh.section(part, rules=[part.ScRuleFactory.CreateRuleCurveFeature([sk.Feature])], seed=c_od, help_point=q),
                           d_in, until=outer, op=nxh.BOOL.Unite, target=body)
    v1 = nxh.volume(part, body)
    chk.true("port boss: Extrude Until Selected + Unite added material, one solid", v1 > v0 and len(nxh.solids(part)) == 1, v1 - v0)
    res["notes"]["boss_limits"] = [(e.GetDescriptor(), e.RightHandSide) for e in f_boss.GetExpressions()]

    # bore: second sketch, Extrude Subtract Until Selected (the housing bore)
    sk2 = nxf.new_sketch(part, p2, dat.y, hinge, "SK_PORT_BORE")
    c_id = nxf.sketch_circle(part, sk2, hinge, "port_id")
    st2 = nxf.finish_sketch(sk2)
    extrude_along(part, nxh.section(part, rules=[part.ScRuleFactory.CreateRuleCurveFeature([sk2.Feature])], seed=c_id, help_point=q),
                  d_in, until=inner, op=nxh.BOOL.Subtract, target=body)
    v2 = nxh.volume(part, body)
    chk.true("port bore: Extrude Subtract Until Selected removed material", v2 < v1 and st2["dof"] == 0, v1 - v2)

    # A2: datum axis of the port cylinder; one hole on the inclined face; circular pattern about A2
    port_face = nxh.one(nxh.faces(body, ftype=nxh.CYLINDER, radius=PORT_OD / 2), "port outer cylinder")
    fa2, a2 = nxf.datum_axis(part, "face_axis", port_face, name="AX_PORT")
    d2 = (a2.Direction.X, a2.Direction.Y, a2.Direction.Z)
    chk.true("A2 datum axis of the port cylinder = port direction", abs(abs(d2[0] * math.cos(a) + d2[2] * math.sin(a)) - 1) < 1e-9, d2)
    sk3 = nxf.new_sketch(part, p2, dat.y, hinge, "SK_PORT_HOLE")
    to3d = nxf.sketch_to3d(sk3)
    u0, v0s = nxf._sketch_uv(sk3, hinge)
    hole = part.Curves.CreateArc(to3d(u0 + HOLE_PCD / 2.0, v0s), nxh.V(sk3.Orientation.Element.Xx, sk3.Orientation.Element.Xy, sk3.Orientation.Element.Xz),
                                 nxh.V(sk3.Orientation.Element.Yx, sk3.Orientation.Element.Yy, sk3.Orientation.Element.Yz), HOLE_D / 2.0, 0.0, 2 * math.pi)
    nxf.add(sk3, hole, infer=False)
    # centre: on the line through the hinge point along the sketch horizontal (= model Y), hole_pcd/2 from it
    line = part.Curves.CreateLine(to3d(u0, v0s), to3d(u0 + HOLE_PCD / 2.0, v0s))
    nxf.add(sk3, line, infer=False)
    sk3.CreateCoincidentConstraint(nxf.cg(line, nxf.CP.StartVertex), nxf.cg(hinge))
    sk3.CreateCoincidentConstraint(nxf.cg(line, nxf.CP.EndVertex), nxf.cg(hole, nxf.CP.ArcCenter))
    nxf.horizontal(sk3, line)
    d = sk3.CreateDimension(nxf.SK.ConstraintType.ParallelDim, nxf.dg(line, nxf.A.StartPoint), nxf.dg(line, nxf.A.EndPoint),
                            to3d(u0 + HOLE_PCD / 4.0, v0s - 3), NXOpen.Expression.Null)
    d.AssociatedExpression.RightHandSide = "hole_pcd/2"
    nxf.diameter_dim(sk3, hole, to3d(u0 + HOLE_PCD / 2.0 + HOLE_D / 2.0, v0s), to3d(u0 + HOLE_PCD / 2.0 + 4, v0s + 4), "hole_d")
    cb = part.Sketches.CreateConvertToFromReferenceBuilder()
    try:
        cb.InputObjects.Add(line)
        cb.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Reference
        cb.Commit()
    finally:
        cb.Destroy()
    st3 = nxf.finish_sketch(sk3)
    chk.true("hole sketch fully constrained", st3["status"] == "WellConstrained" and st3["dof"] == 0, st3)
    hq = to3d(u0 + HOLE_PCD / 2.0 + HOLE_D / 2.0, v0s)
    f_hole = extrude_along(part, nxh.section(part, curves=[hole], help_point=(hq.X, hq.Y, hq.Z)), d_in, 0, HOLE_DEPTH, op=nxh.BOOL.Subtract, target=body)
    v3 = nxh.volume(part, body)
    chk("first hole: volume removed", v2 - v3, math.pi * HOLE_D ** 2 / 4.0 * HOLE_DEPTH, 1e-3)
    pattern_about_axis(part, [f_hole], a2, "n_holes")
    v4 = nxh.volume(part, body)
    chk("circular pattern about the datum axis A2: n holes removed", v2 - v4, N_HOLES * math.pi * HOLE_D ** 2 / 4.0 * HOLE_DEPTH, 1e-3)
    measure(part, body, PORT_ANG, PORT_Z, PORT_LEN, "nominal 30 deg:")
    v_nom = v4

    # the limit of Until Selected, measured: at 45 deg the port face circle (still port_len 48 from the hinge)
    # dips into the housing wall and the Extrude fails - the whole section must start outside the limit face:
    #     port_len * cos(a) - port_od/2 * sin(a) > body_d/2
    nxh.set_expr(part, "port_ang", 45)
    nxh.update()
    err = nxh.feature_errors(part)
    res["notes"]["until_selected_limit"] = {"port_ang": 45, "port_len": PORT_LEN,
                                            "clearance": PORT_LEN * math.cos(math.radians(45)) - PORT_OD / 2 * math.sin(math.radians(45)) - BODY_D / 2,
                                            "errors": err}
    chk.true("port face circle inside the limit face: Extrude Until Selected fails with 'Cannot trim with the limit face'",
             any("limit face" in " ".join(v) for v in err.values()), err)

    # regeneration: turn the port to 45 deg, lengthen it so that its face clears the wall, move it down
    nxh.set_expr(part, "port_len", 60)
    nxh.set_expr(part, "port_z", 30)
    nxh.update()
    measure(part, body, 45.0, 30.0, 60.0, "port_ang 45, port_len 60, port_z 30:")
    nxh.set_expr(part, "port_ang", PORT_ANG)
    nxh.set_expr(part, "port_len", PORT_LEN)
    nxh.set_expr(part, "port_z", PORT_Z)
    nxh.update()
    chk("back to nominal: volume reproduced (relative)", nxh.volume(part, body) / v_nom, 1.0, 1e-6)
    chk.true("back to nominal: no feature errors", not nxh.feature_errors(part), nxh.feature_errors(part))
    res["features"] = [(f["name"], f["type"]) for f in nxh.feature_table(part)]
    stp = nxf.step_export(part, os.path.join(OUT, "inclined_port.step"))
    rt = nxf.step_roundtrip_check(stp, OUT, "inclined_port", restore=part, part=part)
    res["notes"]["roundtrip"] = {k: rt.get(k) for k in ("solids", "volume", "match", "healthy", "max_rel")}
    chk.true("STEP round trip: one solid, same volume", rt.get("match") and rt.get("healthy") and rt.get("solids") == 1, res["notes"]["roundtrip"])


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    chk.true("journal ran without an exception", False, traceback.format_exc()[-400:])
res.update(chk.report())
nxh.write_json(os.path.join(OUT, "inclined_port.json"), res)
