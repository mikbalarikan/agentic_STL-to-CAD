"""Offset Curve and Offset Curve in Face on NX 2206 (headless): corners, short ends, the checks that catch them.

  run_journal.ps1 -Script offset_checks.py -WorkDir <out> -JArgs <out>

  O1  Offset Curve corner handling (TrimMethod NotSet / ExtendTangents / Fillet) on a Z-shaped open chain:
      pieces, gaps at the joints, total length, and whether the result can be offset again
  O2  Offset Curve of ONE straight line: the offset plane is undefined - PointOnOffsetPlane
  O3  inward offset of a closed spline with a tight nose: self-intersection, RoughOffset, the solid test
  O4  Offset Curve types Draft (height + angle), Law Control (linear distance), 3D Axial (always a spline)
  O5  Offset Curve in Face on a contoured face that widens / narrows: the curve ends SHORT of the boundary or
      runs PAST it; ExtendToFaceOption / TrimToFaceEdgesOption; ends_on_boundary() and Divide Face as proof
  O6  Offset Curve in Face distance measured as chord or along the face (arc length); two offsets in one feature
[cast ecvd] = Siemens NX CAST 8.5 "Additional curves" course (rules in own words); numbers measured here.
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])))
import curvekit as ck  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
ONLY = list(sys.argv[2:])
P, V, UPD = nxh.P, nxh.V, nxh.UPD
NF, NULL = nxh.NULL_FEATURE, NXOpen.NXObject.Null
GU = NXOpen.GeometricUtilities
OB = NXOpen.Features.OffsetCurveBuilder
log = nxh.Log(os.path.join(OUT, "offset_checks.log"))
chk = nxh.Check()
res = {"measured": {}, "not_working": {}, "api": {}}
M = res["measured"]


def block(name, fn, part):
    if ONLY and name not in ONLY:
        return
    m = nxh.mark("block " + name, False)
    try:
        fn(part)
        log("done", name)
    except Exception:  # noqa: BLE001
        err = traceback.format_exc()
        log("FAILED", name, err)
        chk.true(name + " ran to the end", False, err[-900:])
        try:
            nxh.undo_to(m)
        except Exception:  # noqa: BLE001
            pass


def api(key, obj):
    cls = type(obj)
    out = {"class": cls.__name__}
    for n in dir(cls):
        if n.startswith("_"):
            continue
        a = getattr(cls, n, None)
        if isinstance(a, type):
            try:
                out[n] = "ENUM " + ", ".join(nxh.enum_names(a))
            except Exception:  # noqa: BLE001
                pass
        elif not callable(a) or n.startswith(("Set", "Create", "Update")):
            out[n] = ((a.__doc__ or "").strip().split("\n")[0])[:120]
    res["api"][key] = out


R = None


# ------------------------------------------------------------------ helpers
def offset_curve(part, curves, distance, trim=OB.TrimOption.ExtendTangents, reverse=False, seed=None, help_point=None, rough=False,
                 plane_point=None, kind="Distance", configure=None, rules=None):
    """Offset Curve feature (planar offset). Returns the feature. The side is decided by measuring: see side()."""
    b = part.Features.CreateOffsetCurveBuilder(NF)
    try:
        b.Type = getattr(OB.Types, kind)
        b.InputCurvesOptions.InputCurveOption = GU.CurveOptions.InputCurve.Retain
        b.InputCurvesOptions.Associative = True
        b.Tolerance = 0.01
        b.TrimMethod = trim
        b.RoughOffset = bool(rough)
        seed = seed or curves[0]
        hp = help_point or ck.frame(seed, 0.5)["point"]
        ck.fill(b.CurvesToOffset, rules or [R.CreateRuleCurveDumb(list(curves))], hp, seed)
        if plane_point is not None:
            b.PointOnOffsetPlane = nxh.point(part, *plane_point)
        if kind == "Distance":
            b.OffsetDistance.RightHandSide = str(distance)
        if configure:
            configure(b)
        b.ReverseDirection = bool(reverse)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f


def chain_report(curves, tol=1e-4):
    """Pieces of an offset result: how many, what, total length, and the gaps between ends that should meet.

    joints: for every curve end the distance to the nearest end of ANOTHER curve - 0 where the chain is
    connected, the gap where it is not; an open chain has two free ends (their nearest distance is large)."""
    ends = []
    for i, c in enumerate(curves):
        ends.append((i, ck.frame(c, 0.0)["point"]))
        ends.append((i, ck.frame(c, 1.0)["point"]))
    near = []
    for i, p in ends:
        d = [math.dist(p, q) for j, q in ends if j != i]
        near.append(min(d) if d else None)
    near_s = sorted(round(x, 4) for x in near if x is not None)
    return {"pieces": len(curves), "classes": sorted(type(c).__name__ for c in curves), "length": round(sum(c.GetLength() for c in curves), 4),
            "end_gaps": near_s, "connected_ends": sum(1 for x in near_s if x < tol), "ends": [[round(v, 3) for v in p] for _i, p in ends]}


def ends_on_boundary(part, face, curve, tol=1e-3):
    """THE check before Divide Face / Trim Sheet: distance of both ends of a curve on a face from the nearest
    boundary edge of that face. (0, 0) = the curve reaches the boundary at both ends; > 0 = it ends short
    (or it runs past the face: then its end is not on the face either - check nxh.dist_to(part, face, end))."""
    out = []
    for t in (0.0, 1.0):
        p = ck.frame(curve, t)["point"]
        pt = part.Points.CreatePoint(P(*p))
        try:
            out.append((round(min(nxh.min_dist(pt, e) for e in face.GetEdges()), 5), round(nxh.min_dist(pt, face), 5)))
        finally:
            nxh.S.UpdateManager.AddToDeleteList(pt)
    return {"edge_gap": [o[0] for o in out], "off_face": [o[1] for o in out], "ok": all(o[0] < tol for o in out)}


def aocs(part, face, edges, values, help_point, seed=None, configure=None):
    """Offset Curve in Face: one feature, one section, len(values) offsets (formulas). configure(builder) sets options."""
    b = part.Features.CreateAocsBuilder(NF)
    try:
        for v in values:
            sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
            ck.fill(sec, [R.CreateRuleEdgeDumb(list(edges))], help_point, seed or edges[0])
            ess = part.CreateExpressionSectionSet(sec, "1", "MilliMeter", 0)
            b.Offsets.Append(ess)
            ess.ItemValue.RightHandSide = str(v)
        b.FaceCollector = nxh.collector(part, faces=[face])
        b.AssociativeOutputOption = True
        b.DistanceTolerance = 0.01
        if configure:
            configure(b)
        f = b.Commit()
    finally:
        b.Destroy()
    return f


# ------------------------------------------------------------------ O1
def o1(part):
    y = 0.0
    zc = nxh.polyline(part, [(0, y, 0), (40, y, 0), (40, y + 30, 0), (80, y + 30, 0)], closed=False)   # one convex and one concave corner per side
    rows = {}
    for name, trim in (("NotSet (dialog: None)", OB.TrimOption.NotSet), ("ExtendTangents", OB.TrimOption.ExtendTangents), ("Fillet", OB.TrimOption.Fillet)):
        for rev in (False, True):
            f, err = nxh.attempt(name, lambda trim=trim, rev=rev: offset_curve(part, zc, 5, trim=trim, reverse=rev, seed=zc[0], help_point=(1, y, 0)), log=log)
            if err:
                rows["%s reverse=%s" % (name, rev)] = {"error": err[:200]}
                continue
            cs = ck.curves_of(f)
            r = chain_report(cs)
            r["side"] = "below / right (y < 0 on the first line)" if min(e[1] for e in r["ends"]) < y - 1 else "above / left"
            r["arc_radii"] = [round(c.Radius, 3) for c in cs if isinstance(c, NXOpen.Arc)]
            # offset the result again by 2 on the same side
            f2, err2 = nxh.attempt("again", lambda f=f, cs=cs, trim=trim, rev=rev: offset_curve(part, cs, 2, trim=trim, reverse=rev, seed=cs[0],
                                                                                              rules=[R.CreateRuleCurveFeature([f])]), log=log)
            r["offset_again"] = ("error: " + err2[:150]) if err2 else chain_report(ck.curves_of(f2))["pieces"]
            rows["%s reverse=%s" % (name, rev)] = r
    M["O1 corner handling, Z chain 40 + 30 + 40, offset 5"] = rows
    below = {k.split(" reverse")[0]: v for k, v in rows.items() if "error" not in v and v["side"].startswith("below")}
    n, e, fl = below.get("NotSet (dialog: None)"), below.get("ExtendTangents"), below.get("Fillet")
    chk.true("O1 NotSet: three separate lines of the source lengths (110), not connected - a gap at the convex corner and a crossing at the concave one",
             n is not None and n["pieces"] == 3 and abs(n["length"] - 110.0) < 1e-3 and n["connected_ends"] == 0, n)
    chk.true("O1 ExtendTangents: three lines that meet (4 connected ends), total length still 110 (one corner +5 +5, the other -5 -5)",
             e is not None and e["pieces"] == 3 and e["connected_ends"] == 4 and abs(e["length"] - 110.0) < 1e-3, e)
    chk.true("O1 Fillet: an R5 arc closes the convex corner (4 pieces, 6 connected ends), the concave corner is trimmed",
             fl is not None and fl["pieces"] == 4 and fl["arc_radii"] == [5.0] and fl["connected_ends"] == 6 and abs(fl["length"] - (40 + 30 - 5 + 35 + math.pi * 2.5)) < 1e-2, fl)


# ------------------------------------------------------------------ O2
def o2(part):
    y = 100.0
    ln = nxh.line(part, (0, y, 0), (50, y, 0))
    rows = {}
    for name, pp in (("no plane point", None), ("plane point (0, y+10, 0)", (0, y + 10, 0)), ("plane point (0, y, 10)", (0, y, 10))):
        f, err = nxh.attempt(name, lambda pp=pp: offset_curve(part, [ln], 5, plane_point=pp, help_point=(1, y, 0)), log=log)
        if err:
            rows[name] = {"error": err[:200]}
            continue
        c = ck.curves_of(f)[0]
        p = ck.frame(c, 0.5)["point"]
        rows[name] = {"mid": [round(v, 3) for v in p], "shift": [round(p[1] - y, 3), round(p[2], 3)], "length": round(c.GetLength(), 3)}
    M["O2 single line"] = rows
    a, b_ = rows["plane point (0, y+10, 0)"], rows["plane point (0, y, 10)"]
    chk.true("O2 one straight line + a point on the offset plane in the XY plane: the copy is shifted 5 in y", "error" not in a and abs(abs(a["shift"][0]) - 5) < 1e-6 and abs(a["shift"][1]) < 1e-6, a)
    chk.true("O2 the same line + a point above it: the copy is shifted 5 in z", "error" not in b_ and abs(abs(b_["shift"][1]) - 5) < 1e-6 and abs(b_["shift"][0]) < 1e-6, b_)
    chk.true("O2 without the point the offset plane of a single line is undefined: error or an arbitrary plane (recorded)", True, rows["no plane point"])


# ------------------------------------------------------------------ O3
def clean_offset(part, result_curves, source_curves, d, n=60):
    """Smallest distance of sampled points of an offset result from the source. A true offset is nowhere nearer
    than d; a folded-over (self-intersecting) offset has points nearer than d."""
    worst = 1e9
    for c in result_curves:
        for s in ck.sample(c, n):
            worst = min(worst, min(nxh.dist_to(part, src, s["point"]) for src in source_curves))
    return round(worst, 4)


def o3(part):
    d = 3.0
    rows = {}
    # (a) closed drop with a tight nose; (b) open hairpin; both offset by more than their smallest radius
    cy = 200.0
    loop = [(40, cy, 0), (26, cy + 5, 0), (0, cy + 12, 0), (-15, cy, 0), (0, cy - 12, 0), (26, cy - 5, 0)]
    _f, drop = ck.studio_spline(part, loop, degree=3, periodic=True)
    _f, pin = ck.studio_spline(part, [(88, cy + 24, 0), (95, cy + 7, 0), (100, cy, 0), (105, cy + 7, 0), (112, cy + 24, 0)], degree=3)
    src = nxh.extrude(part, nxh.section(part, curves=[drop]), (0, 0, 1), 0, 1)
    area = nxh.volume(part, src.GetBodies()[0])
    for label, c, hp in (("closed drop", drop, loop[2]), ("open hairpin", pin, (100, cy, 0))):
        q = ck.curve_quality(c, 400)
        rows[label + ", source"] = {"r_min": round(q["r_min"], 3), "length": round(q["length"], 3), "offset": d}
        got = {}
        for rough in (False, True):
            for rev in (False, True):
                def one(c=c, hp=hp, rough=rough, rev=rev, label=label):
                    f = offset_curve(part, [c], d, rough=rough, reverse=rev, help_point=hp)
                    cs = ck.curves_of(f)
                    r = {"pieces": len(cs), "classes": sorted({type(x).__name__ for x in cs}), "length": round(sum(x.GetLength() for x in cs), 4), "reverse": rev,
                         "min_dist_to_source": clean_offset(part, cs, [c], d)}
                    if label == "closed drop":
                        e, err = nxh.attempt("solid", lambda: nxh.extrude(part, nxh.section_feature(part, [f], help_point=hp), (0, 0, 1), 5, 6), log=log)
                        r["extrude"] = ("error: " + err[:160]) if err else {"bodies": len(e.GetBodies()), "solid": bool(e.GetBodies()[0].IsSolidBody),
                                                                              "area": round(sum(nxh.volume(part, b) for b in e.GetBodies()), 3)}
                    return r
                r, err = nxh.attempt("o3", one, log=log)
                got[(rough, rev)] = r if r else {"error": err[:200], "reverse": rev}
        # the inside of the bend is the side whose ROUGH result is shorter (the rough result is clean on both curves)
        inner = min((False, True), key=lambda rev: got[(True, rev)].get("length", 1e9))
        for rough in (False, True):
            rows["%s, inside of the bend, RoughOffset %s" % (label, rough)] = got[(rough, inner)]
            rows["%s, outside, RoughOffset %s" % (label, rough)] = got[(rough, not inner)]
    rows["closed drop, source"]["area"] = round(area, 3)
    M["O3 offset 3 to the inside of a bend tighter than 3"] = rows
    for label in ("closed drop", "open hairpin"):
        chk.true("O3 %s: the smallest radius is below the offset distance" % label, rows[label + ", source"]["r_min"] < d, rows[label + ", source"])
        rough = rows[label + ", inside of the bend, RoughOffset True"]
        chk.true("O3 %s, RoughOffset on: ONE curve, nowhere nearer the source than the distance" % label,
                 rough.get("pieces") == 1 and rough.get("min_dist_to_source", 0) > d - 0.05, rough)
    plain = rows["closed drop, inside of the bend, RoughOffset False"]
    chk.true("O3 closed drop, plain offset: NX 2206 cuts the fold off by itself (clean, one solid smaller than the source)",
             plain.get("pieces") == 1 and plain.get("min_dist_to_source", 0) > d - 0.02 and isinstance(plain.get("extrude"), dict)
             and plain["extrude"]["solid"] and plain["extrude"]["bodies"] == 1 and plain["extrude"]["area"] < area, plain)
    plain, rough = rows["open hairpin, inside of the bend, RoughOffset False"], rows["open hairpin, inside of the bend, RoughOffset True"]
    chk.true("O3 open hairpin, plain offset: the result FOLDS OVER - points nearer the source than the distance, and longer than the clean result",
             plain.get("min_dist_to_source", 9) < d - 0.3 and plain.get("length", 0) > rough.get("length", 1e9), (plain, rough))


# ------------------------------------------------------------------ O4
def o4(part):
    y = 300.0
    rect = nxh.rect(part, 0, y, 60, y + 40, 0.0)
    rows = {}
    for rev in (False, True):
        def draft(b):
            b.DraftHeight.RightHandSide = "10"
            b.DraftAngle.RightHandSide = "5"
        f, err = nxh.attempt("draft", lambda rev=rev: offset_curve(part, rect, 0, kind="Draft", reverse=rev, configure=draft, help_point=(1, y, 0)), log=log)
        if err:
            rows["Draft reverse=%s" % rev] = {"error": err[:200]}
            continue
        cs = ck.curves_of(f)
        r = chain_report(cs)
        zs = sorted({round(e[2], 4) for e in r["ends"]})
        xs = [e[0] for e in r["ends"]]
        rows["Draft reverse=%s" % rev] = {"pieces": r["pieces"], "classes": r["classes"], "perimeter": r["length"], "z": zs, "x_range": [round(min(xs), 4), round(max(xs), 4)]}
    t = 10 * math.tan(math.radians(5))
    M["O4 Draft height 10, angle 5 (10 tan 5 = %.4f)" % t] = rows
    ok = [v for v in rows.values() if "error" not in v]
    chk.true("O4 Draft: a copy of the 60 x 40 loop in a parallel plane 10 away, each side moved by 10*tan(5 deg) = 0.875 (one direction grows, the other shrinks)",
             len(ok) == 2 and all(len(v["z"]) == 1 and abs(abs(v["z"][0]) - 10) < 1e-6 for v in ok)
             and sorted(round(v["perimeter"], 2) for v in ok) == [round(200 - 8 * t, 2), round(200 + 8 * t, 2)], rows)

    ln = nxh.line(part, (0, y + 80, 0), (60, y + 80, 0))
    rows = {}

    def law(b):
        lw = b.LawControl
        lw.LawType = GU.LawBuilder.Type.Linear
        lw.StartValue.RightHandSide = "2"
        lw.EndValue.RightHandSide = "6"
    for hp, label in (((1, y + 80, 0), "help point at the x = 0 end"), ((59, y + 80, 0), "help point at the x = 60 end")):
        f, err = nxh.attempt("law", lambda hp=hp: offset_curve(part, [ln], 0, kind="LawControl", configure=law, help_point=hp, plane_point=(0, y + 90, 0)), log=log)
        if err:
            rows[label] = {"error": err[:200]}
            continue
        c = ck.curves_of(f)[0]
        a, b_ = ck.frame(c, 0)["point"], ck.frame(c, 1)["point"]
        lo, hi = (a, b_) if a[0] < b_[0] else (b_, a)
        rows[label] = {"class": type(c).__name__, "distance_at_x0": round(abs(lo[1] - (y + 80)), 4), "distance_at_x60": round(abs(hi[1] - (y + 80)), 4)}
    M["O4 Law Control, linear 2 -> 6 on a 60 mm line"] = rows
    vals = [v for v in rows.values() if "error" not in v]
    chk.true("O4 Law Control linear 2 -> 6: the distance is 2 at one end and 6 at the other; the START is the end of the section nearest the help point",
             len(vals) == 2 and (vals[0]["distance_at_x0"], vals[0]["distance_at_x60"]) == (2.0, 6.0) and (vals[1]["distance_at_x0"], vals[1]["distance_at_x60"]) == (6.0, 2.0), rows)

    src = nxh.line(part, (0, y + 120, 0), (40, y + 150, 10))

    def ax(b):
        b.Offset3dDistance.RightHandSide = "6"
        b.AxialOffsetDirection = nxh.direction(part, (0, 0, 1))
    f, err = nxh.attempt("axial", lambda: offset_curve(part, [src], 0, kind="Axial3d", configure=ax), log=log)
    if err:
        M["O4 3D Axial"] = {"error": err[:200]}
    else:
        c = ck.curves_of(f)[0]
        M["O4 3D Axial"] = {"class": type(c).__name__, "length": round(c.GetLength(), 4), "source_length": round(src.GetLength(), 4),
                            "min_dist_to_source": round(nxh.min_dist(c, src), 4)}
        chk.true("O4 3D Axial of a LINE returns a Spline (always a spline: not a rigid shift)", M["O4 3D Axial"]["class"] == "Spline", M["O4 3D Axial"])


# ------------------------------------------------------------------ O5 / O6 bodies
def wedge_with_cylindrical_top(part, x0):
    """Plan = trapezoid 60 wide at y = 0 and 90 wide at y = 40; top = cylinder R80 with its axis along Y.
    Returns (body, top face, edge at y = 0, edge at y = 40)."""
    plan = nxh.polyline(part, [(x0 - 30, 0, 0), (x0 + 30, 0, 0), (x0 + 45, 40, 0), (x0 - 45, 40, 0)])
    a = nxh.extrude(part, nxh.section(part, curves=plan), (0, 0, 1), 0, 60)
    zc = 40.0 - 80.0                                                              # crown at z = 40
    half = math.asin(55.0 / 80.0)
    arc = nxh.arc(part, (x0, -10, zc), (1, 0, 0), (0, 0, 1), 80.0, math.pi / 2 - half, math.pi / 2 + half)
    e0, e1 = ck.frame(arc, 0)["point"], ck.frame(arc, 1)["point"]
    prof = [arc, nxh.line(part, e0, (e0[0], -10, 0)), nxh.line(part, (e0[0], -10, 0), (e1[0], -10, 0)), nxh.line(part, (e1[0], -10, 0), e1)]
    b = nxh.extrude(part, nxh.section(part, curves=prof), (0, 1, 0), 0, 60, op=nxh.BOOL.Intersect, target=a.GetBodies()[0])
    body = b.GetBodies()[0] if b.GetBodies() else a.GetBodies()[0]
    top = nxh.one(nxh.faces(body, ftype=nxh.CYLINDER), "cylindrical top")
    lo = hi = None
    for e in top.GetEdges():
        bb = nxh.bbox(e)
        if abs(bb[1]) < 1e-6 and abs(bb[4]) < 1e-6:
            lo = e
        if abs(bb[1] - 40) < 1e-6 and abs(bb[4] - 40) < 1e-6:
            hi = e
    return body, top, lo, hi


def o5(part):
    x0 = 300.0
    body, top, lo, hi = wedge_with_cylindrical_top(part, x0)
    b0 = part.Features.CreateAocsBuilder(NF)
    api("AocsBuilder", b0)
    AB = type(b0)
    b0.Destroy()
    res["api"]["Aocs defaults"] = _aocs_defaults(part)
    side = [e for e in top.GetEdges() if e not in (lo, hi) and nxh.bbox(e)[0] > x0][0]          # the leaning edge on the +x side
    w10 = 2 * 80.0 * math.asin(33.75 / 80.0)                                                    # face width along the surface at y = 10
    w30 = 2 * 80.0 * math.asin(41.25 / 80.0)
    a_top = nxh.sheet_area(part, [top])[0]
    rows = {"face": {"edges": len(top.GetEdges()), "area": round(a_top, 2), "edge_y0_length": round(lo.GetLength(), 4), "edge_y40_length": round(hi.GetLength(), 4),
                     "width_on_surface_at_y10": round(w10, 4), "width_on_surface_at_y30": round(w30, 4)}}

    def run(edges, hp, label, configure=None, divide=None):
        out = {}
        for sign in ("10", "-10"):
            m = nxh.mark("o5", False)
            f, err = nxh.attempt(label, lambda sign=sign: aocs(part, top, edges, [sign], hp, configure=configure), log=log)
            if err:
                out[sign] = {"error": err[:200]}
                continue
            cs = ck.curves_of(f)
            mid = ck.frame(cs[0], 0.5)["point"]
            inside = nxh.dist_to(part, top, mid) < 0.02 and 0.5 < mid[1] < 39.5
            r = {"pieces": len(cs), "length": round(sum(c.GetLength() for c in cs), 4), "mid_y": round(mid[1], 3), "inside_face": inside}
            if inside:
                if len(cs) == 1:
                    r.update(ends_on_boundary(part, top, cs[0]))
                else:
                    r.update(chain_report(cs))
                    r.pop("ends")
                for ext in (divide or ()):
                    n0 = len(body.GetFaces())
                    m2 = nxh.mark("div", False)
                    proj = "default" if ext == "default projection" else "face normal"
                    _d, derr = nxh.attempt("divide", lambda f=f, ext=ext, proj=proj: _divide(part, top, f, ext is True, proj), log=log)
                    r["divide_face, ExtendOption %s" % ext] = ("error: " + derr[:160]) if derr else {
                        "faces_before": n0, "faces_after": len(body.GetFaces()),
                        "top_pieces_area": sorted(round(nxh.sheet_area(part, [fc])[0], 2) for fc in nxh.faces(body, ftype=nxh.CYLINDER)),
                        "top_area_before": round(a_top, 2)}
                    nxh.undo_to(m2)
            out[sign] = r
            nxh.undo_to(m)
        good = [v for v in out.values() if v.get("inside_face")]
        rows[label] = good[0] if good else out
        return rows[label]

    def opt(**kw):
        def cfg(b):
            for k, v in kw.items():
                setattr(b, k, v)
        return cfg

    hp_lo, hp_hi = (x0 - 29, 0, 40), (x0 - 44, 40, 40)
    a = run([lo], hp_lo, "widening side (edge y=0): defaults (ExtendToFaceOption NotSet)", divide=(False, True))
    b_ = run([lo], hp_lo, "widening side: ExtendToFaceOption = Boundary", opt(ExtendToFaceOption=AB.ExtendToFace.Boundary), divide=(False, "default projection"))
    strip = sum(2 * 80.0 * math.asin((30 + 0.375 * (i + 0.5) * 0.01) / 80.0) * 0.01 for i in range(1000))      # area of the face between y = 0 and y = 10
    rows["face"]["strip_area_y0_to_y10"] = round(strip, 2)
    res["api"]["ProjectionOptions.DirectionType"] = nxh.enum_names(GU.ProjectionOptions.DirectionType)
    c = run([hi], hp_hi, "narrowing side (edge y=40): defaults (TrimToFaceEdgesOption False)")
    d = run([hi], hp_hi, "narrowing side: TrimToFaceEdgesOption = True", opt(TrimToFaceEdgesOption=True))
    e = run([hi], hp_hi, "narrowing side: TrimToFaceEdgesOption False, SplitCurveOption False", opt(TrimToFaceEdgesOption=False, SplitCurveOption=False))
    f = run([lo, side], hp_lo, "two edges round a corner: defaults (Trim / Extend WithinSection)")
    g = run([lo, side], hp_lo, "two edges round a corner: TrimMethod / ExtendMethod NotSet", opt(TrimMethod=AB.Trim.NotSet, ExtendMethod=AB.Extend.NotSet))
    h = run([lo, side], hp_lo, "two edges round a corner: defaults + ExtendToFaceOption = Boundary", opt(ExtendToFaceOption=AB.ExtendToFace.Boundary))
    M["O5 offset in face 10 on a cylindrical top with leaning side edges"] = rows
    chk.true("O5 widening face, defaults: the offset has the length of the EDGE (61.50) and ends 3.78 short of the boundary at both ends",
             abs(a.get("length", 0) - lo.GetLength()) < 0.01 and not a["ok"] and all(abs(v - 3.78) < 0.02 for v in a["edge_gap"]), a)
    chk.true("O5 ... ExtendToFaceOption = Boundary: it reaches the boundary at both ends, length = the face width there (%.2f)" % w10,
             b_.get("ok") and abs(b_["length"] - w10) < 0.05, b_)
    chk.true("O5 Divide Face with the SHORT curve, ExtendOption False: 'Dividing objects do not divide selected faces'",
             isinstance(a.get("divide_face, ExtendOption False"), str) and "do not divide" in a["divide_face, ExtendOption False"], a)
    dv_ext, dv_short = b_.get("divide_face, ExtendOption False"), a.get("divide_face, ExtendOption True")
    chk.true("O5 the curve extended to the boundary divides the face ALONG the curve: 2 pieces, the strip has the area between y 0 and y 10 (%.1f)" % strip,
             isinstance(dv_ext, dict) and dv_ext["faces_after"] == 7 and abs(min(dv_ext["top_pieces_area"]) - strip) < 1.0, dv_ext)
    chk.true("O5 the SHORT curve with DividefaceBuilder.ExtendOption True also divides along the curve (the edges are extended to the boundary)",
             isinstance(dv_short, dict) and dv_short["faces_after"] == 7 and abs(min(dv_short["top_pieces_area"]) - strip) < 8.0, dv_short)
    dflt = b_.get("divide_face, ExtendOption default projection")
    chk.true("O5 TRAP: with the default projection (normal of the curve plane) the planar offset curve divides the face along the rulings through its ENDS - "
             "3 pieces, none of them the strip, no error", isinstance(dflt, dict) and dflt["faces_after"] == 8 and abs(min(dflt["top_pieces_area"]) - strip) > 50, dflt)
    chk.true("O5 narrowing face, defaults: the offset is CUT at the face boundary (length = face width %.2f, both ends on boundary edges)" % w30,
             c.get("ok") and abs(c["length"] - w30) < 0.05, c)
    dd = d.get("10", d) if "pieces" not in d else d
    dd = dd if "pieces" in dd else [v for v in d.values() if abs(v.get("mid_y", 0) - 30) < 1][0]
    chk.true("O5 narrowing face, TrimToFaceEdgesOption True: the curve crosses the boundary - full edge length (95.59) in 3 pieces split at the face edges",
             dd.get("pieces") == 3 and abs(dd["length"] - hi.GetLength()) < 0.01, d)
    chk.true("O5 two edges round a corner, defaults (Trim / Extend WithinSection): the two offsets meet (gap under 0.01); with NotSet they end 11 mm apart",
             f.get("pieces") == 2 and f["end_gaps"][0] < 0.01 and g["end_gaps"][0] > 5.0, (f, g, h))


def o6(part):
    x0, r = 520.0, 15.0
    arc = nxh.arc(part, (x0, 0, 0), (1, 0, 0), (0, 0, 1), r, 0.0, math.pi)
    prof = [arc, nxh.line(part, (x0 - r, 0, 0), (x0 + r, 0, 0))]
    body = nxh.extrude(part, nxh.section(part, curves=prof), (0, 1, 0), 0, 40).GetBodies()[0]
    cyl = nxh.one(nxh.faces(body, ftype=nxh.CYLINDER), "half cylinder")
    gen = [e for e in cyl.GetEdges() if abs(nxh.bbox(e)[0] - (x0 + r)) < 1e-6 and abs(nxh.bbox(e)[3] - (x0 + r)) < 1e-6][0]   # straight generator at x0 + r
    b0 = part.Features.CreateAocsBuilder(NF)
    AB = type(b0)
    b0.Destroy()
    rows = {}

    def ang(c):
        p = ck.frame(c, 0.5)["point"]
        return round(math.degrees(math.atan2(p[2], p[0] - x0)), 4)

    for mode in nxh.enum_names(AB.OffsetType):
        got = {}
        for sign in ("10", "-10"):
            m = nxh.mark("o6", False)
            f, err = nxh.attempt(mode, lambda sign=sign, mode=mode: aocs(part, cyl, [gen], [sign], (x0 + r, 1, 0),
                                                                        configure=lambda b: setattr(b, "OffsetMode", getattr(AB.OffsetType, mode))), log=log)
            if err:
                got[sign] = {"error": err[:160]}
            else:
                c = ck.curves_of(f)[0]
                a = ang(c)
                got[sign] = {"angle_deg": a, "on_face": 1.0 < a < 179.0, "class": type(c).__name__, "length": round(c.GetLength(), 3)}
            nxh.undo_to(m)
        ok = [v for v in got.values() if v.get("on_face")]
        rows[mode] = ok[0] if ok else got
    chord, arcl = 2 * math.degrees(math.asin(10.0 / (2 * r))), math.degrees(10.0 / r)
    rows["analytic"] = {"chordal": round(chord, 4), "arc length": round(arcl, 4)}
    # two offsets of the same edge in ONE feature
    two = None
    for signs in (("6", "12"), ("-6", "-12")):
        m = nxh.mark("o6b", False)
        f, err = nxh.attempt("two sets", lambda signs=signs: aocs(part, cyl, [gen], list(signs), (x0 + r, 1, 0)), log=log)
        if not err:
            cs = ck.curves_of(f)
            t = {"feature_type": f.FeatureType, "curves": len(cs), "angles": sorted(ang(c) for c in cs)}
            if all(1.0 < a < 179.0 for a in t["angles"]):
                two = t
        nxh.undo_to(m)
    rows["two offsets (6 and 12) in one feature"] = two
    M["O6 offset in face of a straight generator of an R15 half cylinder, distance 10"] = rows
    chk("O6 Chordal (the default): 10 is the straight 3D distance -> %.2f deg round the axis" % chord, rows["Chordal"].get("angle_deg"), chord, 0.02)
    chk("O6 Arclength: 10 measured ALONG the face -> %.2f deg (nearer the source than chordal)" % arcl, rows["Arclength"].get("angle_deg"), arcl, 0.02)
    chk.true("O6 two section sets in one builder: ONE feature with two curves", two is not None and two["curves"] == 2
             and abs(two["angles"][1] - 2 * math.degrees(math.asin(12.0 / 30.0))) < 0.05, two)


def _aocs_defaults(part):
    b = part.Features.CreateAocsBuilder(NF)
    out = {}
    try:
        for n in dir(type(b)):
            if n.startswith("_") or not any(k in n for k in ("Option", "Method", "Type", "Trim", "Extend", "Mode", "RemoveSelf")):
                continue
            try:
                v = getattr(b, n)
                if not callable(v):
                    out[n] = str(v)
            except Exception as e:  # noqa: BLE001
                out[n] = "ERR " + str(e)[:60]
    finally:
        b.Destroy()
    return out


def _divide(part, face, curve_feature, extend=False, project="face normal"):
    """Divide Face by the curves of a curve feature (tool type Object), projected along the face normal."""
    b = part.Features.CreateDividefaceBuilder(NF)
    try:
        b.FacesToDivide = nxh.collector(part, faces=[face])
        tool = b.SelectDividingObject
        tool.ToolOption = GU.SelectDividingObjectBuilder.ToolType.Object
        sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
        ck.fill(sec, [part.ScRuleFactory.CreateRuleCurveFeature([curve_feature])], (0, 0, 0))
        tool.DividingObjectsList.Add(sec)
        b.ExtendOption = bool(extend)
        # the default projection is along the normal of the CURVE's plane: for a planar curve that lies on the face
        # it divides along the rulings through the curve ends, not along the curve (measured) - set it
        DT = GU.ProjectionOptions.DirectionType
        if project == "face normal" and hasattr(DT, "FaceNormal"):
            b.ProjectionOption.ProjectDirectionMethod = DT.FaceNormal
        elif project != "default":
            b.ProjectionOption.ProjectDirectionMethod = DT.Vector
            b.ProjectionOption.ProjectVector = nxh.direction(part, (0, 0, 1))
        return b.CommitFeature()
    finally:
        b.Destroy()


def run():
    global R
    part = nxh.new_part(os.path.join(OUT, "offset_checks.prt"))
    R = part.ScRuleFactory
    res["api"]["DivideTool.ToolType"] = nxh.enum_names(GU.SelectDividingObjectBuilder.ToolType)
    b = part.Features.CreateDividefaceBuilder(NF)
    api("DividefaceBuilder", b)
    api("SelectDividingObject", b.SelectDividingObject)
    b.Destroy()
    for name, fn in (("O1", o1), ("O2", o2), ("O3", o3), ("O4", o4), ("O5", o5), ("O6", o6)):
        block(name, fn, part)
    res["errors"] = nxh.feature_errors(part)
    nxh.save(part)


try:
    run()
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
res.update(chk.report())
if "error" in res:
    res["result"] = "FAIL"
nxh.write_json(os.path.join(OUT, "offset_checks.json"), res)
