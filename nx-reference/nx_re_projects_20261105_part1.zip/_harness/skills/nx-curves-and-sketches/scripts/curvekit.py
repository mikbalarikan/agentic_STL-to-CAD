"""curvekit - curve measurement and spline helpers of the nx-curves-and-sketches examples (NX 2206 headless).

Import it from an example journal in this folder:

    sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])))
    import curvekit as ck

  ck.frame(curve, t)            point, unit tangent, principal normal, binormal, torsion, radius, curvature at t 0..1
  ck.curve_quality(curve)       the curvature comb as numbers: inflections, curvature peaks, max curvature,
                                min radius, max |torsion| - the check for a spline ALONG its length
  ck.max_dev(part, curve, pts)  largest distance of given coordinates from a curve (0 = the curve passes through)
  ck.join_angle(c1, t1, c2, t2) angle in degrees between two tangents (0 or 180 = tangent continuous)
  ck.studio_spline(...)         Studio Spline feature: through points / by poles, degree, single segment,
                                periodic, matched knots, per-point tangent / curvature constraints
  ck.spline_data(spline)        order, degree, poles, segments, knots, periodic, rational
  ck.fit_spline(...)            Fit Curve spline on points (degree + segments, or degree + tolerance)
  ck.on_curve(part, curve, pct) smart point at a percent parameter of a curve or edge
  ck.fill(section, rules, help_point, seed)

Run directly (run_journal.ps1 -Script curvekit.py -WorkDir <out> -JArgs <out>) it measures itself on curves
with known answers and writes curvekit.json (result PASS / FAIL).
"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
import nxh  # noqa: E402
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402

P, V, UPD, UFS = nxh.P, nxh.V, nxh.UPD, nxh.UFS
NF, NULL = nxh.NULL_FEATURE, NXOpen.NXObject.Null
PROPS = UFS.ModlGeneral.AskCurveProps
SB = NXOpen.Features.StudioSplineBuilderEx
GC = NXOpen.Features.GeometricConstraintData
FC = NXOpen.Features.FitCurveBuilder


# ------------------------------------------------------------------ vectors
def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def sub(a, b):
    return [x - y for x, y in zip(a, b)]


def norm(a):
    return math.sqrt(dot(a, a))


def unit(a):
    n = norm(a)
    return [x / n for x in a] if n > 0 else [0.0, 0.0, 0.0]


def cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def angle(a, b):
    """Angle in degrees between two vectors, 0..180."""
    na, nb = norm(a), norm(b)
    if na == 0 or nb == 0:
        return None
    return math.degrees(math.acos(max(-1.0, min(1.0, dot(a, b) / (na * nb)))))


# ------------------------------------------------------------------ measuring a curve
def curves_of(feature):
    return [e for e in feature.GetEntities() if isinstance(e, NXOpen.Curve)]


def frame(curve, t):
    """Frenet data of a curve or edge at the normalised parameter t (0 = start, 1 = end).

    k is the curvature in 1/mm, 0 on a straight piece (AskCurveProps answers radius 3.937e8 for a line -
    measured - so every radius above 1e8 mm counts as straight). The binormal turns over where the curve
    changes the side it bends to."""
    r = PROPS(curve.Tag, float(t))
    rad = abs(float(r[5]))
    k = 0.0 if rad < 1e-9 or rad > 1e8 else 1.0 / rad
    return {"t": float(t), "point": list(r[0]), "tangent": unit(list(r[1])), "normal": list(r[2]), "binormal": list(r[3]),
            "torsion": float(r[4]), "radius": rad, "k": k}


def at(curve, t):
    f = frame(curve, t)
    return f["point"], f["tangent"]


def sample(curve, n=200):
    return [frame(curve, i / float(n)) for i in range(n + 1)]


def curve_quality(curve, n=200, k_min=1e-7):
    """The curvature comb of a curve as numbers (n + 1 samples in the parameter).

    inflections : places where the curve changes the side it bends to (the binormal turns over between two
                  samples whose curvature is above k_min). A fair guide or section has exactly the
                  inflections the design calls for - usually 0, an S-curve 1.
    peaks       : interior local maxima of the curvature (each one is a visible "knuckle").
    k_max, r_min: largest curvature and the radius there; t_k_max where.
    k_end       : curvature at the two ends (compare with the neighbour for G2).
    torsion_max : 0 for a planar curve.
    """
    rows = sample(curve, n)
    ks = [r["k"] for r in rows]
    k_max = max(ks)
    infl, last, where = 0, None, []
    for r in rows:
        if r["k"] < k_min:
            continue
        if last is not None and dot(last["binormal"], r["binormal"]) < 0:
            infl += 1
            where.append(round((last["t"] + r["t"]) / 2, 4))
        last = r
    eps = 1e-6 * k_max if k_max > 0 else 0.0
    peaks = [rows[i]["t"] for i in range(1, n) if ks[i] > k_min and ks[i] > ks[i - 1] + eps and ks[i] > ks[i + 1] + eps]
    i_max = ks.index(k_max)
    return {"inflections": infl, "inflection_t": where, "peaks": len(peaks), "peak_t": [round(t, 4) for t in peaks],
            "k_max": k_max, "r_min": (1.0 / k_max if k_max > 0 else None), "t_k_max": rows[i_max]["t"],
            "k_end": [ks[0], ks[-1]], "torsion_max": max(abs(r["torsion"]) for r in rows), "length": curve.GetLength()}


def max_dev(part, curve, pts):
    """Largest distance of the coordinates pts from the curve (0 = the curve passes through all of them)."""
    return max(nxh.dist_to(part, curve, p) for p in pts)


def join_angle(c1, t1, c2, t2):
    """Angle in degrees between the tangents of two curves at the given parameters, folded to 0..90
    (0 = tangent continuous, whichever way the two curves run)."""
    a = angle(frame(c1, t1)["tangent"], frame(c2, t2)["tangent"])
    return min(a, 180.0 - a)


def end_near(curve, xyz):
    """0.0 or 1.0: the parameter of the curve end nearest xyz."""
    return 0.0 if math.dist(frame(curve, 0)["point"], xyz) <= math.dist(frame(curve, 1)["point"], xyz) else 1.0


def planarity(curves, n=20):
    """Largest distance of sampled points from the plane through three of them (0 = planar)."""
    pts = [frame(c, i / float(n))["point"] for c in curves for i in range(n + 1)]
    p0 = pts[0]
    nrm = None
    for i in range(1, len(pts)):
        for j in range(i + 1, len(pts)):
            c = cross(sub(pts[i], p0), sub(pts[j], p0))
            if norm(c) > 1e-6 * max(1.0, norm(sub(pts[i], p0)) * norm(sub(pts[j], p0))):
                nrm = unit(c)
                break
        if nrm:
            break
    if nrm is None:
        return 0.0
    return max(abs(dot(sub(p, p0), nrm)) for p in pts)


# ------------------------------------------------------------------ building blocks
def fill(sec, rules, help_point, seed=None, types=NXOpen.Section.AllowTypes.OnlyCurves):
    """Fill a builder-owned Section in place (seed + help point fix the start end and the direction)."""
    sec.SetAllowedEntityTypes(types)
    sec.AddToSection(rules, seed if seed is not None else NULL, NULL, NULL, P(*help_point), NXOpen.Section.Mode.Create, False)
    return sec


def scalar(part, value):
    return part.Scalars.CreateScalar(float(value), NXOpen.Scalar.DimensionalityType.NotSet, UPD)


def on_curve(part, curve, percent):
    """Smart point at a percent parameter (0..100, number or formula) of a curve or edge."""
    e = part.Expressions.CreateSystemExpressionWithUnits(str(percent), None)
    sc = part.Scalars.CreateScalarExpression(e, NXOpen.Scalar.DimensionalityType.NotSet, UPD)
    return part.Points.CreatePoint(curve, sc, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, UPD)


def _point(part, p):
    return p if isinstance(p, NXOpen.Point) else nxh.point(part, *p)


def studio_spline(part, pts, degree=3, poles=False, periodic=False, single=False, matched=None, constraints=None, assoc=True):
    """Studio Spline. Returns (feature or None, NXOpen.Spline).

    pts         : coordinates (numbers or formulas) or NXOpen.Point objects (smart points keep it associative).
    poles       : False = Through Points (the curve passes through every point),
                  True  = By Poles (pts are the control polygon; only the first and last are on the curve).
    degree      : poles >= degree + 1; segments = poles - degree.
    single      : By Poles only - one segment, degree = poles - 1 (the Degree setting is ignored).
    periodic    : closed and smooth across the seam (do not repeat the first point).
    matched     : None | "Cubic" | "General" (Through Points: knots at the defining points).
    constraints : {index: {...}} per defining point (Through Points: any point; By Poles: the two ends):
                  "direction": NXOpen.Direction or (vx, vy, vz)   G1 direction
                  "magnitude": number                               how far the tangency acts (default 1)
                  "auto": "Tangent" | "Curvature"                   take G1 / G2 from the curve the point rides on
                  "curvature": NXOpen.Offset                        explicit curvature (Offsets.CreateCurvature)
    """
    b = part.Features.CreateStudioSplineBuilderEx(NULL)
    try:
        b.Type = SB.Types.ByPoles if poles else SB.Types.ThroughPoints
        if poles:
            b.IsSingleSegment = bool(single)
        if not (poles and single):
            b.Degree = int(degree)
        b.IsAssociative = bool(assoc)
        b.IsPeriodic = bool(periodic)
        b.MatchKnotsType = getattr(SB.MatchKnotsTypes, matched) if matched else SB.MatchKnotsTypes.NotSet
        b.OrientExpress.ReferenceOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Reference.ProgramDefined
        b.DrawingPlaneOption = SB.DrawingPlaneOptions.General
        for i, p in enumerate(pts):
            g = b.ConstraintManager.CreateGeometricConstraintData()
            g.Point = _point(part, p)
            c = (constraints or {}).get(i)
            if c:
                if c.get("auto"):
                    g.CanInferConstraintFromAttachmentParent = True
                    g.AutomaticConstraintDirection = GC.ParameterDirection.Iso
                    g.AutomaticConstraintType = getattr(GC.AutoConstraintType, c["auto"])
                if c.get("direction") is not None:
                    d = c["direction"]
                    g.AutomaticConstraintDirection = GC.ParameterDirection.Iso
                    if not c.get("auto"):
                        g.AutomaticConstraintType = GC.AutoConstraintType.NotSet
                    g.TangentDirection = d if isinstance(d, NXOpen.Direction) else nxh.direction(part, d)
                if c.get("magnitude") is not None:
                    g.TangentMagnitude = scalar(part, c["magnitude"])
                if c.get("curvature") is not None:
                    g.Curvature = c["curvature"]
            b.ConstraintManager.Append(g)
        f = b.Commit()
        spline = b.Curve
    finally:
        b.Destroy()
    return (f if isinstance(f, NXOpen.Features.Feature) else None), spline


def spline_data(spline):
    """Order, degree, pole count, segments (= poles - degree for a non-periodic spline), knots, flags."""
    order = spline.Order
    knots = list(spline.GetKnots())
    lo, hi = knots[0], knots[-1]
    inner = sorted({round((k - lo) / (hi - lo), 9) for k in knots if lo < k < hi}) if hi > lo else []
    return {"order": order, "degree": order - 1, "poles": spline.PoleCount, "segments": len(inner) + 1, "inner_knots": inner,
            "n_knots": len(knots), "periodic": bool(spline.Periodic), "rational": bool(spline.Rational)}


def fit_spline(part, pts, degree=3, segments=1, tolerance=None, assoc=True):
    """Fit Curve (spline) through NOISY points: least squares, passes through none of them.
    segments given -> Degree and Segments; tolerance given -> Degree and Tolerance (NX chooses the segments).
    Returns (feature, spline)."""
    objs = [part.Points.CreatePoint(P(*p)) for p in pts]
    b = part.Features.CreateFitCurveBuilder(NXOpen.Features.FitCurve.Null)
    try:
        b.Type = FC.Types.FitSpline
        b.TargetSourceType = FC.TargetSourceTypes.SpecifiedPoints
        for o in objs:
            b.Target.Add(o)
        b.Degree = int(degree)
        if tolerance is not None:
            b.FittingParameters = FC.FittingParametersOptions.DegreeAndTolerance
            b.Tolerance = float(tolerance)
        else:
            b.FittingParameters = FC.FittingParametersOptions.DegreeAndSegments
            b.Segments = int(segments)
        b.IsAssociative = bool(assoc)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, curves_of(f)[0]


# ------------------------------------------------------------------ self-test
def _selftest(out):
    chk = nxh.Check()
    res = {"measured": {}}
    part = nxh.new_part(os.path.join(out, "curvekit.prt"))
    # 1 arc R25: curvature 1/25 everywhere, no inflection, no peak, planar
    arc = nxh.arc(part, (0, 0, 0), (1, 0, 0), (0, 1, 0), 25.0, 0.0, math.pi / 2)
    q = curve_quality(arc)
    res["measured"]["arc R25"] = q
    chk("arc R25: k_max = 1/25", q["k_max"], 0.04, 1e-9)
    chk.true("arc R25: 0 inflections, 0 peaks, torsion 0", q["inflections"] == 0 and q["peaks"] == 0 and q["torsion_max"] < 1e-9, q)
    # 2 line: curvature 0
    ln = nxh.line(part, (0, 50, 0), (40, 60, 0))
    q = curve_quality(ln)
    res["measured"]["line"] = {"k_max": q["k_max"], "raw_radius": PROPS(ln.Tag, 0.5)[5]}
    chk.true("line: curvature 0, no inflection", q["k_max"] == 0.0 and q["inflections"] == 0, res["measured"]["line"])
    # 3 S-curve through 5 points: exactly one inflection, found near the middle
    _f, s = studio_spline(part, [(0, 100, 0), (20, 108, 0), (40, 110, 0), (60, 112, 0), (80, 120, 0)], degree=3)
    q = curve_quality(s)
    res["measured"]["S curve"] = q
    chk.true("S-curve: exactly 1 inflection near the middle", q["inflections"] == 1 and abs(q["inflection_t"][0] - 0.5) < 0.05, q)
    chk("max_dev: the through-points spline passes through its points", max_dev(part, s, [(20, 108, 0), (60, 112, 0)]), 0.0, 1e-6)
    # 4 the curve curvature equals the face curvature of the sheet extruded from it (nxh.max_curvature)
    ext = nxh.extrude(part, nxh.section(part, curves=[s]), (0, 0, 1), 0, 5, sheet=True)
    face = ext.GetBodies()[0].GetFaces()[0]
    fr = frame(s, 0.2)
    kf = nxh.max_curvature(face, fr["point"])
    res["measured"]["curve k vs face k at t 0.2"] = [fr["k"], kf]
    chk("curve curvature = nxh.max_curvature of the extruded sheet at the same point", fr["k"], kf, 1e-7)
    # 5 helix-like 3D spline: torsion is not 0
    _f, h = studio_spline(part, [(0, 200, 0), (10, 210, 5), (0, 220, 10), (-10, 210, 15), (0, 200, 20)], degree=3)
    q = curve_quality(h)
    chk.true("3D spline: torsion_max > 0, planarity > 0", q["torsion_max"] > 1e-4 and planarity([h]) > 1.0, (q["torsion_max"], planarity([h])))
    chk("planarity of the planar S-curve", planarity([s]), 0.0, 1e-9)
    res.update(chk.report())
    nxh.save(part)
    return res


if os.path.basename(sys.argv[0]).lower() == "curvekit.py":
    _out = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
    try:
        _res = _selftest(_out)
    except Exception:  # noqa: BLE001
        _res = {"result": "FAIL", "error": traceback.format_exc()}
    nxh.write_json(os.path.join(_out, "curvekit.json"), _res)
