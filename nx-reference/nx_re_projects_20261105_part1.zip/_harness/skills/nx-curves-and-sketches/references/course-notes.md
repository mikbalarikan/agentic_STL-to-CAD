# Course notes - sketches, datums and curves (condensed)

Source: the user's 6-day NX course, English notes in `C:\NX_MCP_WORKSPACE\nx_course\notes\`
(`day2a.md`, `day2b.md`, `day3a.md`, `day4b.md`, `day5a.md`). Timestamps are `[CADx.y hh:mm]` of the
recording. The sketch day was recorded on **NX 2212** (new sketch solver UI); this machine runs
NX 2206 - differences are listed in section 5. "Probe" = what `scripts/course_checks.py` or the
other three scripts measured on NX 2206; unmarked statements are the instructor's only.

## 1. Method rules (instructor)

Sketch placement
- Keep sketch X the same as the model CSYS X when picking the horizontal reference; a different X
  works but makes CAM zero-setting painful later. [CAD2.1 00:06]
- If the sketch may move later, create a Datum Plane at the location (even at offset 0 on the face)
  and sketch on the plane, not directly on the face - the plane stays editable. [CAD2.1 00:12]
- On a face the origin snaps to the corner nearest the pick; for a centred sketch set the origin
  with Between Two Points on two opposite corners. [CAD2.1 00:04-00:06]
- When the plane you need is not a face, make a datum plane first: Bisector for a mid / diagonal
  plane, At Distance for an offset level. [CAD2.3 00:39, 00:45]
- Sketch On Path is for sweep sections: plane on the path at % arc length, normal to path; the
  origin cannot leave the path. [CAD2.1 00:09-00:12]
- Name sketches when a model has many. [CAD2.1 00:15]

Definition
- Reach "Sketch is fully defined" before making the solid; NX does not enforce it. [CAD2.4 00:30]
- Judge by the status line, not by colour: brown/black only means something with Show Movable on.
  [CAD2.4 00:32]
- Locate from the sketch origin first, then size, then drag to see what still moves and close that
  freedom. [CAD2.4 00:31]
- Fix Curve is a shortcut for geometry whose size and position are certain, not the normal way.
  Fix the first element while building relations, release it at the end. [CAD2.4 00:33-00:36]
- Type values while creating polygons / chamfers; free-clicked sizes are not parametric. [CAD2.3 00:08]

Relations
- Relations are directional: first pick moves, second stays. Pick placed geometry as stationary.
  [CAD2.4 00:11]
- Constrain before relating: an undimensioned line satisfies a relation by stretching. [CAD2.4 00:11-00:12]
- Make Coincident point-to-point only; use the dedicated command for anything else. [CAD2.4 00:13]
- Tangent is not touching - add a coincident to close the profile. [CAD2.4 00:21]
- Equal Length does not fix direction - add Parallel. [CAD2.4 00:25]
- Relations are stored only with Create Persistent Relations on. [CAD2.4 00:16] (2212 UI, see 5)

Reuse of 3D geometry in a sketch
- Intersection Curve (faces x sketch plane), Intersection Point (curve pierces the plane, the
  curve is extended if needed), Project Curve (curves / edges / points, not faces) instead of
  re-measuring. [CAD2.3 00:41-00:48]

Profiles and sections
- Choose the Curve Rule before picking: Infer Curves on crossing lines gave four sheets, Single
  Curve + Stop at Intersection gave the closed loop and a solid. [CAD3.1 00:05-00:08]
- Profile for connected outlines, Line for independent lines; no Slot command - Profile
  line/arc/line/arc. Tangent arc between two circles = Fillet. [CAD2.1 00:20, 00:33; CAD2.2 00:20]
- A profile of several curves gives a wall of several faces (seams = tool marks). Join it first:
  Composite Curve, Join = Cubic, Hide Original. Composite copies, it never edits the originals.
  [CAD5.1 00:12-00:17]

3D curves
- Surface work starts with curves; never place 3D curve points in empty space - snap to an axis or
  set the Support Plane. Pick the drawing plane of a Studio Spline (not View) when it matters.
  [CAD5.1 00:20-00:26; CAD5.2 00:02]
- Degree n spline needs n + 1 points; keep splines out of simple sketches. [CAD2.1 00:39; CAD5.2 00:04]
- Bridge: continuity per end, G0 position / G1 tangent / G2 curvature / G3 flow; higher is not
  automatically better; pick near the end to connect; start 0.1-0.2 mm inside the parent and trim
  the stub. [CAD5.1 00:02-00:09]
- A curve that must lie on a freeform face = Curve on Surface; a spline through points on the face
  leaves the surface between them. [CAD5.2 00:25-00:28]
- Projection = what, onto what, along which direction; Along Vector and Along Face Normal differ;
  verify by looking along the vector. [CAD5.2 00:41]
- 3D curve from a top view and a side view = Combined Projection (or two extruded sheets +
  Intersection Curve). [CAD5.2 00:44-00:46]
- Offset in Face ending short of / past the boundary: Trim and Extend to Face Edges. [CAD5.2 00:38]
- A face with no usable edge: make one with Isoparametric Curve or Section Curve. [CAD5.2 00:55-00:57]
- Text on a curved face: Text type On Face with Project Curves on; size by height + W Scale.
  [CAD5.2 00:11-00:20]
- Curve-edit commands act on a copy (Input Curves = Keep / Hide). [CAD5.3 00:20]
- Check direction arrows before OK (Combined Projection, Offset in Face, Text). [CAD5.2 00:37, 00:44]

Coordinate systems
- Absolute (fixed, invisible), WCS (one, movable), Datum CSYS (a feature, any number). Point and
  primitive dialogs default to WCS coordinates. [CAD4.3 00:46-00:51]

## 2. Tool cards - sketch

| Tool [time] | What the instructor shows | NXOpen on NX 2206 | Probe |
|---|---|---|---|
| Create Sketch On Plane [CAD2.1 00:00] | plane or face, horizontal reference, origin point, reverse normal | `Sketches.CreateSimpleSketchInPlaceBuilder` | DOF 0 on datum plane, face, angled plane |
| Create Sketch On Path [CAD2.1 00:09] | path, % arc length, normal to path | `Sketches.CreateSketchAlongPathBuilder(Sketch.Null)` | origin (40,-100,0) = path start, normal = tangent; tree `DATUM_ON_PATH`, `SKETCH` |
| Profile / Line / Arc / Circle / Rectangle [CAD2.1 00:16-00:37] | on-screen input, typed values become dimensions | `Curves.CreateLine/CreateArc` + `Sketch.AddGeometry` | verified |
| Studio Spline in sketch [CAD2.1 00:37] | through points / by poles, degree | no working in-sketch builder found | frozen spline in the sketch; parametric route = spline feature through dimensioned sketch points (verified) |
| Point [CAD2.2 00:00] | Point dialog, Between Two Points | `Points.CreatePoint` + `AddGeometry`; dimension with `AssocType.StartPoint` | verified |
| Fillet [CAD2.2 00:16] | trim on/off, alternate fillet | `Sketch.Fillet(...)` | verified |
| Chamfer [CAD2.2 00:23] | symmetric / asymmetric / offset+angle | `Sketches.CreateSketchChamferBuilder`, `CurvesToChamfer` | verified (4 x 45) |
| Offset Curve [CAD2.2 00:29] | distance, copies, symmetric | `Sketches.CreateSketchOffsetBuilder` | verified |
| Pattern Curve [CAD2.2 00:35] | linear / circular, count includes the seed, circular by span | `Sketches.CreateSketchPatternBuilder` | circular verified; linear NOT WORKING headless (draw instances by formula) |
| Mirror Curve [CAD2.2 00:44] | centre line, convert to reference | `Sketches.CreateSketchMirrorPatternBuilder`, `DirectionObject` | verified (datum axis, and a drawn centre line converted to reference) |
| Derived Lines, Conic, Ellipse, Polygon [CAD2.3 00:00-00:12] | - | `Curves.CreateEllipse` + `AddGeometry`; `CreateSketchPolygonBuilder`, `CreateSketchConicBuilder` | ellipse verified; polygon, conic, derived lines not probed |
| Trim / Extend / Corner [CAD2.3 00:19-00:24] | - | `CreateQuickTrimBuilder`, `CreateQuickExtendBuilder`, `CreateCornerBuilder` | not probed (a journal computes the trimmed geometry itself) |
| Intersection Curve / Point [CAD2.3 00:41] | faces or a curve against the sketch plane | `Sketches.CreateIntersectionCurveBuilder(SketchIntersectionCurve.Null)`, `CreateIntersectionPointBuilder(SketchIntersectionPoint.Null)` | both verified |
| Project Curve [CAD2.3 00:46] | curves, edges, points onto the sketch plane | `Sketches.CreateProjectBuilder` | verified |
| Dimensions [CAD2.4 00:01-00:10] | on-canvas dimensioning; Rapid Dimension is legacy | `Sketch.CreateDimension / CreateDiameterDimension / CreateRadialDimension` | verified |
| Make Parallel / Perpendicular / Equal / Midpoint [CAD2.4 00:22-00:30] | motion + stationary pick | `Sketch.CreateParallel/Perpendicular/EqualLength/MidpointConstraint` | verified, persist through an edit |
| Make Symmetric [CAD2.4 00:26] | motion, stationary, symmetry line | `Sketches.CreateMakeSymmetricBuilder` | verified; `SecondaryObject` is the one that moved |
| Fix Curve [CAD2.4 00:33] | pins curves | `Sketch.CreateFixedConstraint` | verified (DOF 3 -> 0 on an ellipse) |
| Relax Dimensions / Relations, Work Region, Persistent Relations Browser [CAD2.4 00:36-00:45] | interactive aids | none needed in a journal | - |

## 3. Tool cards - curves and datums

| Tool [time] | What the instructor shows | Builder (NX 2206) | Probe |
|---|---|---|---|
| Bridge Curve [CAD5.1 00:01] | start / end object, continuity per end, location, tangent magnitude | `Features.CreateBridgeCurveBuilderEx` | G1, G2 measured; G3 commits |
| Composite Curve [CAD5.1 00:13] | Associative, Hide Original, Join = No / Cubic / General / Quintic | `Features.CreateCompositeCurveBuilder` | 3 curves -> 1 spline, 3 faces -> 1 face |
| Line / Arc 3D [CAD5.1 00:19-00:30] | start / end options, Support Plane, limits | `BaseFeatures.CreateAssociativeLineBuilder / ArcBuilder` | verified with smart points |
| Point Set [CAD5.1 00:32] | curve / spline / face points as scaffolding | `Features.CreatePointSetBuilder(PointSet.Null)` | verified (curve points) |
| Studio Spline 3D [CAD5.2 00:00] | through points / by poles, degree, drawing plane | `Features.CreateStudioSplineBuilderEx` | verified incl. points on curves |
| Text [CAD5.2 00:08] | Planar / On Curve / On Face, Project Curves, W Scale | `Features.CreateTextBuilder` | planar, on-face and on-curve verified; W Scale not probed |
| Curve on Surface [CAD5.2 00:24] | spline that stays in the face | `Features.CreateCurveOnSurfaceBuilder` | deviation 0.0 vs 0.34 for a plain spline |
| Offset Curve [CAD5.2 00:31] | Distance; 3D Axial changes shape with distance | `Features.CreateOffsetCurveBuilder` | Distance verified; 3D Axial commits but is not a rigid shift (partial) |
| Offset Curve in Face [CAD5.2 00:35] | distance over the face, Trim / Extend to Face Edges | `Features.CreateAocsBuilder` | verified incl. the side rule (+ = right of the section direction); extend / trim to face edges, distance method and several offsets verified (recipes 46) |
| Project Curve [CAD5.2 00:39] | onto face or plane, along vector / face normal | `Features.CreateProjectCurveBuilder` | verified, three variants |
| Combined Projection [CAD5.2 00:42] | two planar curves, two directions | `Features.CreateCombinedProjectionBuilder` | verified |
| Intersection Curve [CAD5.2 00:46] | face set x face set / plane | `Features.CreateIntersectionCurveBuilder` | verified |
| Isoparametric Curve [CAD5.2 00:46] | U / V lines on a face | `Features.CreateIsoparametricCurvesBuilder` | verified (defaults) |
| Section Curve [CAD5.2 00:57] | body x selected planes | `Features.CreateSectionCurveBuilder` | verified |
| Datum Plane Tangent [CAD5.3 00:00] | tangent to a cylinder / cone, subtypes | `PlaneTypes.MethodType.Tangent...` | verified, four variants |
| Wrap / Unwrap Curve [CAD5.3 00:05] | planar curve on the tangent plane is the master | `Features.CreateWrapBuilder(WrapUnwrap.Null)` | Wrap and Unwrap verified (recipes 34, 48) |
| Trim Curve [CAD5.3 00:17] | curve to trim, bounding object | `Features.CreateTrimCurve2FeatureBuilder(TrimCurve2.Null)` | works with a bounding PLANE (recipes 48); bounding curve / point / datum object NOT WORKING - then Curve Length |
| Curve Length [CAD5.3 00:19] | incremental start / end | `Features.CreateCurvelengthBuilder` | verified |

## 4. Course vs mined data vs probes

- **Fully defined sketches**: the instructor insists; the user's own parts are 60 % under-constrained
  and 71 % without a dimension [mined]. A journal can reach DOF 0 every time [verified].
- **Sketch on a datum plane rather than on the face**: the user mostly sketches straight on a
  face (64 % of sketches) but also places 166 offset-0 datum planes on faces [mined] - both habits exist.
- **Named sketches**: recommended by the instructor, never done by the user (2280 default names) [mined].
- **Splines of low degree by n + 1 points**: the user's studio splines are all degree 5 through 2
  points on curves [mined]; a degree-5 through-2-points spline committed and followed its curves [verified].
- **Composite Curve Join**: the instructor always joins; all 92 read-back user composites have
  `JoinOption = No` [mined].
- **Text on a curved face**: the course could not get solids from the projected text; the probe
  reproduces that (sheet bodies) and gives a working route (section 14 of `nxopen-recipes.md`).

## 5. NX 2212 recording vs NX 2206 API

- **Create Persistent Relations toggle** (off by default in the 2212 UI, Make-X is then a one-off
  move): no counterpart was needed on 2206 - `Sketch.Create...Constraint` and
  `CreateMakeSymmetricBuilder` always store the relation (it survived an expression edit and shows in
  `GetAllConstraintsOfType`). No API switch for the toggle was found.
- **Motion vs stationary pick**: the old `Create...Constraint(geom1, geom2)` calls have no such
  notion; the solver decides what moves from what is already dimensioned. Measured:
  `CreateParallelConstraint(free, base)` + `CreateEqualLengthConstraint(free, base)` moved the free
  line onto the dimensioned base's direction and length (the reverse argument order was not
  tested). In `MakeSymmetricBuilder` the **`SecondaryObject` moved** and `PrimaryObject` stayed
  (both lines were undimensioned).
- **"Sketch is fully defined / partially defined with N movable curves"** status line: the API
  equivalent is `Sketch.GetStatus()` -> `(WellConstrained, 0)`; there is no "movable curve" count,
  only the DOF number.
- **Show Movable colours, Relax Dimensions / Relations, Work Region, Ignore Relation, Persistent
  Relations Browser, Relation Finder settings, on-canvas dimensioning**: interactive aids; the
  matching builders (`CreateRelationBuilder`, `CreateWorkRegionBuilder`, `CreateIgnoreRelationBuilder`,
  `CreateFindMovableObjectsBuilder`, `CreateRelationFinderSettingsBuilder`) exist on 2206 but were
  not exercised and a journal does not need them.
- **`CreateSketchSymmetricBuilder`** exists on 2206 but raises "Sketch is not initialized." in an
  active sketch; use `CreateMakeSymmetricBuilder`.
- **Scene-bar "Stop at Intersection" toggle**: the API form is
  `Section.AddChainBetweenIntersectionPoints(...)`, one call per trimmed piece.
