# NXOpen recipes - sketches, datums, curve features (NX 2206, run_journal)

Measured on NX 2206 batch, 2026-10-04. Runnable sources: `scripts/sketch_recipes.py` (18 checks
PASS), `scripts/datum_recipes.py` (17 PASS), `scripts/curve_features.py` (21 PASS),
`scripts/course_checks.py` (18 PASS, sections 14-25), `scripts/round3_checks.py` (20 PASS, sections
7, 7b, 27-37), `scripts/inclined_port.py` (36 PASS, section 39), `scripts/law_curve_gear.py` (37
PASS, sections 40-41; both measured 2026-10-06), and the CAST round of 2026-10-06, sections 42-50:
`scripts/curvekit.py` (helper module with a self-test, 8 PASS), `scripts/spline_rules.py` (39),
`scripts/offset_checks.py` (27), `scripts/cast_curve_checks.py` (49), `scripts/sketch_rules.py` (37),
`scripts/curve_activities.py` (12). All pass with the final helpers
`nx-journal-core/scripts/nxh.py` + `nxf.py` (launcher `run_journal.ps1`), exit code 0. Snippets use
`nxh` (`P`, `V`, `UPD`, `point`, `direction`, `collector`, `extrude`, `Datums`) and
`NF = nxh.NULL_FEATURE`, `NULL = NXOpen.NXObject.Null`, `R = part.ScRuleFactory`,
`SK = NXOpen.Sketch`.

## Contents
1. Sketch on a datum plane or body face, DOF 0 - VERIFIED
2. Sketch relations and dimensions reference - VERIFIED
3. Project body edges into a sketch - VERIFIED
4. Sketch fillet / offset - VERIFIED; sketch pattern - NOT WORKING; sketch spline - PARTIAL
5. Section rules - VERIFIED
6. Datum planes, axes, CSYS, point - VERIFIED
7. Associative line / arc - VERIFIED
8. Studio spline, bridge curve - VERIFIED
9. Project / intersection / section curve - VERIFIED
10. Offset curve, offset curve in face, composite curve, curve length - VERIFIED
11. Helix, text - VERIFIED; law curve - section 40
12. Curve measurement helpers - VERIFIED
14. Sketch On Path - VERIFIED
15. Parallel / perpendicular / equal length / midpoint, Make Symmetric, sketch Mirror - VERIFIED
16. EdgeTangent / EdgeChain / EdgeBoundary rules, stop at intersection - VERIFIED
17. Composite Curve with Join - VERIFIED
18. Bridge Curve G2 - VERIFIED
19. Studio spline on existing curves - VERIFIED
20. Curve on Surface - VERIFIED
21. Isoparametric Curves - VERIFIED (defaults)
22. Combined Projection - VERIFIED
23. Mirror Curve - VERIFIED
24. Text on a cylindrical face, solid letters - VERIFIED
25. Trim Curve - NOT WORKING
27. Sketch pattern: circular VERIFIED, linear NOT WORKING, instance workaround VERIFIED
28. Ellipse, Fixed, reference conversion, mirror about a centre line, chamfer - VERIFIED
29. Sketch Intersection Curve / Point - VERIFIED
30. Parametric spline driven by a sketch - VERIFIED
31. Offset Curve in Face: what decides the side - VERIFIED
32. Offset Curve 3D Axial - PARTIAL
33. Point Set - VERIFIED
34. Wrap Curve - VERIFIED
35. Helix by limits / linear pitch, text on a curve, bridge G3 - VERIFIED
36. Projected sketch curve loses its parent - VERIFIED
37. Section help point without a seed - VERIFIED
38. Still not probed
39. Inclined port: datum axis + plane at an angle + Until Selected - VERIFIED
40. Law curve by equation; involute spur gear - VERIFIED
41. Boolean expressions with if / else that switch optional features - VERIFIED
42. Measuring a curve along its length: `curvekit.py` - VERIFIED
43. Studio Spline: type, degree, segments, periodic, end constraints, pole construction - VERIFIED
44. Fit Curve on noisy points; tolerance against poles - VERIFIED
45. Offset Curve: trim options, single line, rough offset, draft, law - VERIFIED
46. Offset Curve in Face: extend / trim to face edges, distance method, several offsets; Divide Face - VERIFIED
47. Join Curves, Bridge shape control, Project directions, Intersection of datum planes - VERIFIED
48. Tangent lines, arc by two points and radius, point set ranges, general conic, isoparametric options,
    isocline, Trim Curve with a bounding plane, Unwrap - VERIFIED
49. Offset Datum CSYS - VERIFIED
50. Sketch rules measured: internal / external, order, symmetric / mirror, zero dimensions, shared sketch,
    constrained Sketch On Path - VERIFIED

---

## 1. Sketch on a datum plane or planar face - VERIFIED

```python
def new_sketch(part, plane, haxis, origin, name):
    """plane: DatumPlane or planar Face; haxis: DatumAxis or linear Edge; origin: NXOpen.Point."""
    sb = part.Sketches.CreateSimpleSketchInPlaceBuilder()
    try:
        sb.UseWorkPartOrigin = False
        d = part.Directions.CreateDirection(haxis, NXOpen.Sense.Forward, UPD)
        xf = part.Xforms.CreateXformByPlaneXDirPoint(plane, d, origin, UPD, 0.625, False, False)
        sb.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
        sb.HorizontalReference.Value = haxis
        sk = sb.Commit()
    finally:
        sb.Destroy()
    sk.Activate(SK.ViewReorient.FalseValue)
    sk.SetName(name); sk.Feature.SetName(name)
    return sk
```

- Tree result: `DATUM_CSYS` + `SKETCH` at the same timestamp (`Datum Coordinate System(1)`,
  `SKT_PLATE:Sketch(1)`) - identical to the user's parts. `sk.IsInternal` is False.
- On a face: `new_sketch(part, top_face, dat.x, dat.origin, ...)` gave sketch origin (0, 0, 10) on
  the z = 10 face - the origin point is projected onto the plane.
- On an angled datum plane (30 deg about X): circle extruded with
  `Directions.CreateDirection(datumPlane, Sense.Forward, UPD)` -> cylinder axis (0, -0.5, -0.866),
  volume 942.478 = pi*25*12; angle 30 -> 60 moved the axis to (0, -0.866, -0.5).

Geometry is created at absolute 3D coordinates lying in the sketch plane, then added:

```python
e1 = part.Curves.CreateLine(P(-30, -20, 0), P(30, -20, 0))
circ = part.Curves.CreateArc(P(0, 0, 0), V(1, 0, 0), V(0, 1, 0), 10.0, 0.0, 2 * math.pi)   # one full arc
sk.AddGeometry(e1, SK.InferConstraintsOption.InferCoincidentConstraints)   # joins touching end points
sk.AddGeometry(circ, SK.InferConstraintsOption.InferNoConstraints)
```

Finish and prove:

```python
def status_of(sk):
    st, dof = sk.GetStatus()            # str(st) is '3' - map by comparison
    name = [n for n in nxh.enum_names(SK.Status) if getattr(SK.Status, n) == st]
    return (name[0] if name else str(st)), dof

sk.Update()                             # status is stale before this
status, dof = status_of(sk)             # ('WellConstrained', 0)
sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
```

**This bare read is only a real count in a sketch created with Continuous Auto Dimensioning off.**
A batch session starts with `nxh.S.Preferences.Sketch.ContinuousAutoDimensioning == True`; a sketch
created then is auto-dimensioned at `Update()` and `GetStatus()` returns `(WellConstrained, 0)` for
a single free point (real DOF 2). Put `nxh.S.Preferences.Sketch.ContinuousAutoDimensioning = False`
(= `nxf.auto_dimensioning_off()`) BEFORE the sketch builder - afterwards is too late for that
sketch - or use `nxf.new_sketch` / `nxf.finish_sketch`, which do it and also count the automatic
dimensions of a sketch created the other way (`nxf.auto_dimensions`). Measured in
`nx-journal-core/scripts/nxf_selftest.py` (sketch group).

Evidence (S1): rectangle + concentric circle, 5 dimensions (`p0=plate_w/2`, `p1=plate_w/2`,
`p2=plate_h/2`, `p3=plate_h/2`, `p4=bore_d`), relations Coincident 5, Horizontal 2, Vertical 2 ->
WellConstrained, DOF 0. `plate_w` 60 -> 80: volume 20662.06 -> 28662.06 (analytic 28662.06), sketches
still DOF 0, `feature_errors == {}`.

## 2. Relations and dimensions - VERIFIED

```python
def cg(geom, pt=None, idx=0):                      # constraint geometry
    g = SK.ConstraintGeometry(); g.Geometry = geom
    g.PointType = pt if pt is not None else SK.ConstraintPointType.NotSet
    g.SplineDefiningPointIndex = idx; return g

def help_at(p):
    h = SK.ConstraintGeometryHelp(); h.Type = SK.ConstraintGeometryHelpType.Point
    h.Point = p; h.Parameter = 0.0; return h

def dg(geom, assoc=None, hp=None):                 # dimension geometry
    d = SK.DimensionGeometry(); d.Geometry = geom
    d.AssocType = assoc if assoc is not None else SK.AssocType.NotSet
    d.AssocValue = 0; d.HelpPoint = hp if hp is not None else P(0, 0, 0); d.View = NULL; return d

sk.CreateHorizontalConstraint(cg(line)); sk.CreateVerticalConstraint(cg(line))
sk.CreateCoincidentConstraint(cg(circ, SK.ConstraintPointType.ArcCenter), cg(dat.origin))
sk.CreatePointOnCurveConstraint(cg(circ, SK.ConstraintPointType.ArcCenter), cg(dat.x), help_at(P(22, 0, 10)))
sk.CreateTangentConstraint(cg(arc), help_at(p), cg(line), help_at(p))
# also: CreateCollinear / Parallel / Perpendicular / Concentric / EqualRadius / EqualLength / Midpoint / Fixed

c = sk.CreateDimension(SK.ConstraintType.PerpendicularDim, dg(dat.y, None, P(0, 50, 0)),
                       dg(line, SK.AssocType.StartPoint), P(15, -28, 0), NXOpen.Expression.Null)
c.AssociatedExpression.RightHandSide = "plate_w/2"
sk.CreateDiameterDimension(dg(circ, None, P(10, 0, 0)), P(20, 20, 0), NXOpen.Expression.Null) \
  .AssociatedExpression.RightHandSide = "bore_d"
sk.CreateRadialDimension(dg(arc, None, on_arc), origin, NXOpen.Expression.Null)
```

- `PerpendicularDim` = distance from a line-like reference (datum axis, sketch line, projected
  edge) to a point of the second object. `AssocType`: `StartPoint`, `EndPoint`, `ArcCenter`,
  `Midpoint`, `CurvePoint`, `AnchorPoint`, `Tangency`, `NotSet`.
- Dimension to a sketch **Point** object: use `AssocType.StartPoint`. `NotSet` ->
  "The second object associativity type is invalid."
- Enum names: `ConstraintPointType` = Anchor, ArcCenter, EndVertex, MidVertex, NotSet,
  SplineDefiningPoint, SplinePole, StartVertex. `ConstraintClass` = Any, Dimension, Geometric,
  NotConstraint (`GetAllConstraintsOfType(cls, type)`).
- Symmetric rectangle without a symmetry relation: two dimensions `w/2` from the datum Y axis to
  the two vertical lines (the pattern used throughout).

## 3. Project body edges into the sketch (recipe curves) - VERIFIED

```python
pb = part.Sketches.CreateProjectBuilder(NF)          # sketch must be active
try:
    pb.Tolerance = 0.01
    psec = pb.Section
    psec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
    psec.AddToSection([R.CreateRuleEdgeDumb([edge])], edge, NULL, NULL, P(30, 0, 10),
                      NXOpen.Section.Mode.Create, False)
    pb.Commit()
finally:
    pb.Destroy()
proj_line = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Line)][0]
pdim(sk, proj_line, P(30, 5, 10), hole, SK.AssocType.ArcCenter, P(22, 12, 10), "edge_off")
```

Tree: `DATUM_CSYS(3)`, `CPROJ Projected Curve(3)`, `SKETCH(3)` - the same `CPROJ > SKETCH` pair the
user has 119 times. The projected line counts as fully defined (sketch DOF 0 with only the hole's
two dimensions and one point-on-curve). Evidence: hole centre x = 22 = 30 - `edge_off`; after
`plate_w` = 80 it is at x = 32 and the cut volume matches.

## 4. In-sketch tools

**Fillet - VERIFIED**

```python
arcs, cons = sk.Fillet(l1, l2, P(on l1), P(on l2), 6.0, SK.TrimInputOption.TrueValue,
                       SK.CreateDimensionOption.TrueValue, SK.AlternateSolutionOption.FalseValue)
for e in sk.GetAllExpressions():                      # re-point the auto radius dimension
    if e.RightHandSide.strip() in ("6", "6.0"): e.RightHandSide = "fil_r"
```
Returns `([Arc], [dimension, tangent, tangent, ...])`, trims both lines. L-profile: DOF 0, area
extrude 1918.63 (analytic 1918.63); `fil_r` 6 -> 4 gave 1897.17 (analytic 1897.17).

**Offset curve in sketch - VERIFIED**

```python
ob = part.Sketches.CreateSketchOffsetBuilder(NXOpen.SketchOffset.Null)
try:
    osec = ob.CreateSection()                         # no arguments; returns the section to fill
    osec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    osec.AddToSection([R.CreateRuleCurveDumb(lines)], lines[0], NULL, NULL, P(15, 60, 0), NXOpen.Section.Mode.Create, False)
    ob.UpdateLoopsAndCopies()
    ob.Distance.RightHandSide = "wall"; ob.CreateDimension = True
    ob.EvaluateOffset()
    ob.Commit()
finally:
    ob.Destroy()
```
30x20 rectangle, `wall` = 3: one `Offset` relation, one dimension `p24=wall`, DOF 0, ring volume
672 = (36*26 - 30*20)*2 -> the offset went **outward**. Five variants measured on 40 x 30
rectangles (`sketch_rules.py` K6): help point at the middle, near the start, near the end of the
seed line: all outward; `ob.Distance.RightHandSide = "-wall"` (negative): **inward**, sketch still
DOF 0; `ob.ReverseOffsetDirection()` (before or after `EvaluateOffset`): raises "Sketch is not
initialized." - the earlier note that it flips the side was never measured.
Failures met: `ob.Section` does not exist; `CreateSection(sec)` -> "takes no arguments".

**Sketch pattern - linear NOT WORKING, circular VERIFIED (section 27)** (`Sketches.CreateSketchPatternBuilder(NXOpen.SketchPattern.Null)`), linear layout:
section filled + `UpdateInputSection()`, `PatternService.PatternType = Linear`,
`RectangularDefinition.XDirection` (from datum axis and from a plain direction), `XSpacing` copies /
pitch, `UpdateLinearDirectionObject/UpdateCopies/UpdateData/EvaluatePattern` -> `Commit()` raises
"Incorrect object for this operation." in all three orderings tried. Workaround: add the instances
as ordinary curves with dimensions / equal-radius relations, or use a Pattern Feature on the result.

**Spline in a sketch - PARTIAL (the parametric alternative is section 30)**
- `Features.CreateSketchSplineBuilder(Spline.Null)` and `CreateStudioSplineBuilderEx(NULL)` called
  with a sketch active: commit succeeds but the sketch holds no spline and every later sketch call
  raises "Sketch is not initialized."
- What works: build a non-associative spline outside the sketch
  (`StudioSplineBuilderEx`, `IsAssociative = False`, take `b.Curve`), `Activate`, `AddGeometry`.
  With Continuous Auto Dimensioning off the sketch then reads UnderConstrained / DOF 8 (4
  through-points); `sk.CreateCoincidentConstraint(cg(spline, CP.SplineDefiningPoint, i + 1),
  cg(point))` for each of the 4 dimensioned sketch points brings it to WellConstrained / DOF 0, the
  spline is usable in sections (length 44.63, ends exact) and **follows its points**: moving a
  through-point by its dimension (100 -> 105) moved the spline start to (0, 105, 0).
  (Measured earlier with the preference on: the status read a false 0 after `AddGeometry`, the
  coincident constraints were skipped and the spline stayed frozen at 100 - that was the
  auto-dimensioning trap, not a property of sketch splines.) The feature in section 8 stays the
  simpler route.

## 5. Section rules - VERIFIED

```python
def new_section(part):
    sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)      # chaining tol, distance tol, angle tol
    sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    sec.AllowSelfIntersection(False)
    return sec

def add_rules(sec, rules, help_point, seed=None):
    sec.AddToSection(rules, seed if seed is not None else NULL, NULL, NULL, P(*help_point),
                     NXOpen.Section.Mode.Create, False)
    return sec

# ONE region of a sketch that holds several closed loops
curves = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Curve)]
rule = R.CreateRuleRegionBoundary(sk, curves, P(25, 15, 0), 0.01)       # seed point inside the region
# whole sketch (or any curve feature: Text, Associative Line ...)
rule = R.CreateRuleCurveFeature([sk.Feature])
# connected loop through a seed curve / tangent chain through a seed curve
rule = R.CreateRuleCurveFeatureChain([sk.Feature], seed, NXOpen.Curve.Null, True, 0.0095)
rule = R.CreateRuleCurveFeatureTangent([sk.Feature], seed, NXOpen.Curve.Null, True, 0.5, 0.0095)
# explicit objects
rule = R.CreateRuleCurveDumb([c1, c2]); rule = R.CreateRuleEdgeDumb(list(face.GetEdges()))
```

Measured on sketch S1 (60x40 rectangle + d20 circle), extruded 10:

| Rule | Section curves | Volume | Analytic |
|---|---|---|---|
| RegionBoundary, seed (25,15,0) between the loops | 5 | 20858.407 | (2400 - 314.159)*10 |
| RegionBoundary, seed (2,3,0) inside the circle | 1 | 3141.593 | 314.159*10 |
| CurveFeature (whole sketch) | 5 | 20858.407 | inner loop = hole |
| CurveFeatureChain, seed = one rectangle line | 4 | 24000.0 | rectangle only |
| CurveFeatureTangent, seed = circle | 1 | 3141.593 | circle only |
| CurveDumb, four lines | 4 | 24000.0 | - |

Edge rules (`EdgeTangent`, `EdgeChain`, `EdgeBoundary`) and stop-at-intersection are measured in
section 16. Other factory calls present on NX 2206 (signatures from the docstrings, not all exercised):
`CreateRuleEdgeTangent(startEdge, endEdge, isFromStart, angleTolerance, hasSameConvexity[, allowLaminarEdge])`,
`CreateRuleEdgeChain(startEdge, endEdge, isFromStart[, commonFace, allowLaminarEdge])`,
`CreateRuleEdgeBoundary(faces)`, `CreateRuleEdgeFace(faces)`, `CreateRuleEdgeBody(body)`,
`CreateRuleEdgeSheetBoundary(sheet)`, `CreateRuleCurveChain(seed, end, isFromSeedStart, gapTol)`,
`CreateRuleCurveTangent(seed, end, isFromSeedStart, angleTol, gapTol)`,
`CreateRuleCurveDumbFromPoints(points)`, `CreateRuleFeaturePoints(features)`,
`CreateRuleFaceDumb / FaceDatum / FaceBody / FaceFeature / FaceTangent(seed, boundaryFaces)`.
Faces go into an `ScCollector` (`ReplaceRules(rules, False)`), curves and edges into a `Section`.
`Section.Mode` has only `Create` and `Edit`. `sec.GetOutputCurves()` lists what a section resolved to.

## 6. Datums - VERIFIED

```python
MT = NXOpen.PlaneTypes.MethodType

def dplane(part, method, geom, formula=None, name=None, tweak=None):
    b = part.Features.CreateDatumPlaneBuilder(NF)
    try:
        pl = b.GetPlane()
        pl.SetUpdateOption(UPD); pl.SetMethod(method); pl.SetGeometry(list(geom)); pl.SetFlip(False)
        if tweak: tweak(pl)
        if formula is not None: pl.Expression.RightHandSide = str(formula)
        pl.Evaluate()
        f = b.CommitFeature()
    finally:
        b.Destroy()
    if name: f.SetName(name)
    return f                                         # f.DatumPlane.Origin / .Normal to read back
```

| Call | Result read back | After edit |
|---|---|---|
| `dplane(part, MT.Distance, [dat.xy], "dp_off")` | origin z 15, normal (0,0,1), expr `p8=dp_off` | `dp_off` 25 -> z 25 |
| `dplane(part, MT.Distance, [top_face], "5")` | z 25 (face at 20) | - |
| `dplane(part, MT.Distance, [face_x], "0")` | x 60 | block 60 -> 80: x 80 |
| `dplane(part, MT.Angle, [dat.xy, dat.x], "dp_ang")` | normal (0, 0.5, 0.866) | 60 deg: (0, 0.866, 0.5) |
| `dplane(part, MT.ThreePoints, [p1, p2, p3])` | normal (0,-0.707,0.707) | - |
| `dplane(part, MT.Center, [face_x0, face_x1])` | x 30 | x 40 |
| `dplane(part, MT.Tangent, [cyl_face])` | (110,0,0), normal X, 10.0 from axis | - |
| `MT.TangentParPlane` / `MT.TangentPerpPlane` / `MT.TangentAnglePlane` with `[cyl_face, dat.yz]` | tangent, parallel / perpendicular / at angle "0" to YZ | - |
| `dplane(part, MT.Frenet, [edge], "25", tweak=lambda pl: pl.SetPercent(True))` | origin x 15 (25 % of 60), normal = edge tangent | - |
| `dplane(part, MT.Coincident, [top_face])` | z 20 | - |

Failures: `MT.TangentFace` with `[cyl]` -> "The selected constraints are not valid or supported.";
`MT.Tangent` with `[cyl, plane]` -> "Datum plane undefinable." `PlaneTypes.FrenetSubtype` (Tangent,
Normal, Binormal, ThruPoint...) made no difference on a straight edge - untested on a curved one.

```python
AX = NXOpen.Features.DatumAxisBuilder
b = part.Features.CreateDatumAxisBuilder(NF); b.IsAssociative = True
b.Type = AX.Types.PointAndDir;      b.Point = smart_pt; b.Vector = nxh.direction(part, (0, 1, 0))
b.Type = AX.Types.TwoPoints;        b.Point1 = p1; b.Point2 = p2
b.Type = AX.Types.CurveOrFaceAxis;  b.CurveOrFace.Value = cyl_face          # axis of a cylinder
b.Type = AX.Types.Intersection;     b.Object1.Value = datum_plane; b.Object2.Value = dat.xz
f = b.CommitFeature()               # f.DatumAxis.Origin / .Direction
```
All four measured (directions (0,1,0), (0.707,0.707,0), (0,0,1) through (100,0), (-1,0,0) at z 15 ->
25 after the plane moved). Types enum: CurveOrFaceAxis, Fixed, Inferred, Intersection,
OnCurveVector, PointAndDir, TwoPoints, XcAxis, YcAxis, ZcAxis.

```python
o = nxh.point(part, "cs_x", 50, 0)                                           # expression-driven origin
xf = part.Xforms.CreateXform(o, nxh.direction(part, (0, 1, 0)), nxh.direction(part, (-1, 0, 0)), UPD, 1.0)
b = part.Features.CreateDatumCsysBuilder(NF)
b.Csys = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD); b.DisplayScaleFactor = 1.25
f = b.CommitFeature()
xy = part.Datums.FindObject(f"{f.JournalIdentifier} XY plane")               # also "X axis", f.FindObject("POINT 1")
```
Origin (70,50,0), X axis (0,1,0); `cs_x` 90 -> origin (90,50,0).

```python
b = part.BaseFeatures.CreatePointFeatureBuilder(NF); b.Point = nxh.point(part, "cs_x", "dp_off", 5); f = b.Commit()
```
Feature type `POINT`, coordinates (70,15,5). (`part.Features.CreatePointFeatureBuilder` does not exist.)

## 7. Associative line / arc - VERIFIED

```python
LB = NXOpen.Features.AssociativeLineBuilder
b = part.BaseFeatures.CreateAssociativeLineBuilder(NXOpen.Features.AssociativeLine.Null)   # typed Null, not Feature.Null
b.StartPointOptions = LB.StartOption.Point; b.StartPoint.Value = nxh.point(part, 0, -30, 0)
b.EndPointOptions = LB.EndOption.Point;     b.EndPoint.Value = nxh.point(part, "ln_len", -30, 0)
b.Associative = True; f = b.CommitFeature()                 # type LINE; length 50 -> 70 on edit

AB = NXOpen.Features.AssociativeArcBuilder
b = part.BaseFeatures.CreateAssociativeArcBuilder(NXOpen.Features.AssociativeArc.Null)
b.Type = AB.Types.ArcFromCenter; b.CenterPoint.Value = nxh.point(part, 0, -60, 0)
b.EndPointOptions = AB.EndOption.Radius; b.Radius.RightHandSide = "arc_r"
LO = NXOpen.GeometricUtilities.CurveExtendData.LimitOptions
b.Limits.StartLimit.LimitOption = LO.Value; b.Limits.EndLimit.LimitOption = LO.Value
b.Limits.StartLimit.Distance.RightHandSide = "0"; b.Limits.EndLimit.Distance.RightHandSide = "90"   # degrees
b.Limits.FullCircle = False; b.Associative = True; f = b.CommitFeature()      # type ARC
```
Arc: radius 12, length 18.8496 = pi*12/2. Curves of any curve feature:
`[e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)]`.

**Always give the arc its support plane, and read the plane's frame** [verified, `round3_checks.py` A1].
Limit angles are measured in the support plane's OWN frame: angle 0 is the X axis of
`plane.Matrix`, angle 90 its Y axis. That frame depends on how the plane was made:

| Support plane | angle 0 | angle 90 |
|---|---|---|
| none (batch default) | -Z | +Y (the arc stands in the YZ plane) |
| `Planes.CreatePlane(P, V(0,0,1), UPD)` fixed, normal +Z | +X | +Y |
| fixed, normal -Z | +X | -Y |
| fixed, normal +Y | -Z | -X |
| fixed, normal +X | -Z | +Y |
| smart, `SetMethod(Distance)` from the datum XY plane | **-X** | -Y |
| smart, offset from the datum XZ plane | -Z | -X |
| smart, offset from the datum YZ plane | -Y | -Z |

So "+X is angle 0" holds only for a fixed plane with normal +Z or -Z; on the smart XY offset plane
every angle is shifted by 180 degrees. Do not memorise the table: either read
`m = plane.Matrix` (`m.Xx, m.Xy, m.Xz` = angle 0, `m.Yx, ...` = angle 90; all eight rows above matched
it) or measure it with one throw-away arc (`arc_frame` in the script) and convert with
`plane_angles(frame, th0, th1)`. Always confirm with the arc's end points.

```python
def offset_plane(part, datum, formula):            # smart NXOpen.Plane that follows an expression
    pl = part.Planes.CreatePlane(nxh.P(0, 0, 0), nxh.V(0, 0, 1), nxh.UPD)
    pl.SetMethod(NXOpen.PlaneTypes.MethodType.Distance); pl.SetGeometry([datum])
    pl.Expression.RightHandSide = str(formula); pl.Evaluate()
    return pl
b.SupportPlaneData.SupportPlane = plane             # on the AssociativeArcBuilder
```

### 7b. Associative closed section at an expression-driven height - VERIFIED
The parametric input for Through Curves / Swept / Extrude when a sketch per section is overkill.
`scripts/round3_checks.py` holds the helper pair (with `assoc_line`, `assoc_arc`, `arc_frame`,
`plane_angles`):

```python
def assoc_circle(part, centre, radius, plane):      # ONE ARC feature: b.Limits.FullCircle = True, limits 0..360
    ...; return [feature], seed_curve
def assoc_rounded_rect(part, w, h, r, z, plane):    # 4 LINE + 4 ARC features, centred on the Z axis at height z
    ...; return features, seed_curve                # seed = the bottom line

pl = offset_plane(part, dat.xy, "z1")
feats, seed = assoc_rounded_rect(part, "rr_w", "rr_h", "rr_r", "z1", pl)
sec = nxh.section(part, rules=[R.CreateRuleCurveFeature(feats)], seed=seed, help_point=mid_of_seed)   # ONE rule
```
Measured: rounded rectangle 40 x 24, r 5 at z 10 extruded 3 -> solid 2815.619 (analytic
2815.619); circle r 8 -> 603.186 (analytic 603.186). After `z1` 10 -> 25, `rr_w` 50, `rr_r` 8,
`c_r` 5: 3435.186 and 235.619 (both analytic), body at z 25, no feature errors. A full circle needs
no second arc. Start points and directions of several sections must still agree (section 37 and
`nx-surface-modeling`).

## 8. Studio spline and bridge curve - VERIFIED

```python
SB = NXOpen.Features.StudioSplineBuilderEx
b = part.Features.CreateStudioSplineBuilderEx(NULL)
b.Type = SB.Types.ThroughPoints            # or SB.Types.ByPoles
b.Degree = 3; b.IsAssociative = True; b.IsPeriodic = False
b.MatchKnotsType = SB.MatchKnotsTypes.NotSet
b.OrientExpress.ReferenceOption = NXOpen.GeometricUtilities.OrientXpressBuilder.Reference.ProgramDefined
b.DrawingPlaneOption = SB.DrawingPlaneOptions.General
for i, p in enumerate(points):
    g = b.ConstraintManager.CreateGeometricConstraintData()
    g.Point = nxh.point(part, *p)
    if end_dir_for_this_point:                                  # G1 direction at a point
        GC = NXOpen.Features.GeometricConstraintData
        g.AutomaticConstraintDirection = GC.ParameterDirection.Iso
        g.AutomaticConstraintType = GC.AutoConstraintType.NotSet
        g.TangentDirection = nxh.direction(part, (0, 1, 0))
    b.ConstraintManager.Append(g)
f = b.Commit(); spline = b.Curve                                # feature type SPLINE
```
- Through 4 points in 3D: ends exact, passes the 2nd point, 6.87 mm out of plane, order 4, 4 poles.
- By poles: ends on the first / last pole, start tangent parallel to pole1 - pole0, 10.29 mm away
  from pole 2, planar.
- G1: end tangents (0,1,0) and (0,-1,0) as specified. Setting `g.TangentMagnitude = 1.0` raises
  "Expecting NXOpen.Scalar type, found float" - leave it out. (It takes
  `part.Scalars.CreateScalar(v, NotSet, UPD)` and is an absolute derivative length, not a factor of
  1 - section 43.)
- The user's own splines: degree 5, through 2 points.

```python
b = part.Features.CreateBridgeCurveBuilderEx(NXOpen.Features.BridgeCurve.Null)
sec = b.StartSection; sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
sec.AddToSection([R.CreateRuleCurveDumb([l1])], l1, NULL, NULL, P(19, -90, 0), NXOpen.Section.Mode.Create, False)
sec = b.EndSection;   sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
sec.AddToSection([R.CreateRuleCurveDumb([l2])], l2, NULL, NULL, P(40, -79, 0), NXOpen.Section.Mode.Create, False)
b.IsAssociative = True; f = b.Commit()                          # feature type BRIDGE_CURVE
```
The help point decides which END of each curve is bridged. Result: ends at (20,-90,0) and
(40,-80,0), tangents (1,0,0) and (0,1,0) = G1 with both lines (the default continuity), length
24.83. Failure when only `StartObject.SetValue(curve, view, point)` was set: "Unable to create
bridge curve due to lack of start section". Continuity per end: section 18.

## 9. Project / intersection / section curve - VERIFIED

```python
PB = NXOpen.Features.ProjectCurveBuilder
b = part.Features.CreateProjectCurveBuilder(NF); b.Tolerance = 0.01
sec = b.SectionToProject; sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.CurvesAndPoints)
sec.AddToSection([R.CreateRuleCurveDumb(curves)], NULL, NULL, NULL, P(0, 0, 0), NXOpen.Section.Mode.Create, False)
b.FaceToProjectTo.Add(nxh.collector(part, faces=[face]))        # SelectObjectList holding an ScCollector
# or: b.PlaneToProjectTo = part.Planes.CreatePlane(P(0, 0, 0), V(0, 0, 1), UPD)
b.ProjectionDirectionMethod = PB.DirectionType.AlongVector; b.ProjectionVector = nxh.direction(part, (0, 0, -1))
# or: b.ProjectionDirectionMethod = PB.DirectionType.AlongFaceNormal
b.InputCurvesOption.Associative = True; f = b.Commit()          # feature type CPROJ
```
Along vector onto the block top: z 20, length 58.3095 = source. Along face normal onto a d30
cylinder from a line 30 off-axis: line at radius 15, length 20. Onto the XY plane: half circle
stays an `Arc`, length 31.4159. Failure: `b.FaceToProjectTo.ReplaceRules` -> "'SelectObjectList'
object has no attribute 'ReplaceRules'".

```python
b = part.Features.CreateIntersectionCurveBuilder(NF)
b.Tolerance = 0.01                                              # default 0 -> "Distance Tolerance cannot be zero."
b.FirstFace.ReplaceRules([R.CreateRuleFaceBody(body)], False)
b.SecondFace.ReplaceRules([R.CreateRuleFaceDatum([datum_plane])], False)     # or b.SecondPlane = NXOpen.Plane
b.Associative = True; f = b.Commit()                            # INTERSECTION_CURVES
```
Block x plane z 10: 4 lines, 200.0; plane driven by `cut_z` 10 -> 15 moved the curves to z 15.
Cylinder face x `SecondPlane`: 94.2478 = pi*30.

```python
b = part.Features.CreateSectionCurveBuilder(NF)
b.Type = NXOpen.Features.SectionCurveBuilder.PlaneType.Selected  # also Parallel, Radial, PerpendicularToCurve
b.Tolerance = 0.01; b.ObjectsToSection.Add(body); b.SectionPlanes.Add(datum_plane)
b.Associative = True; f = b.Commit()                            # SECTION_CURVES, 94.2478
```
(`SectionCurveBuilder.Types` does not exist - the enum is `PlaneType`.)

## 10. Offset curve, offset in face, composite curve, curve length - VERIFIED

```python
OB = NXOpen.Features.OffsetCurveBuilder
b = part.Features.CreateOffsetCurveBuilder(NF); b.Type = OB.Types.Distance
b.InputCurvesOptions.InputCurveOption = NXOpen.GeometricUtilities.CurveOptions.InputCurve.Retain
b.InputCurvesOptions.Associative = True; b.Tolerance = 0.01
b.TrimMethod = OB.TrimOption.ExtendTangents; b.OffsetDistance.RightHandSide = "off_d"
sec = b.CurvesToOffset; sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
sec.AddToSection([R.CreateRuleCurveDumb(rect)], rect[0], NULL, NULL, P(0, 160, 0), NXOpen.Section.Mode.Create, False)
b.ReverseDirection = False; f = b.Commit()                      # OFFSET_CURVE
```
60x40 rectangle, 5: `ReverseDirection=False` gave 160 (inward), `True` 240 (outward); `off_d` = 2 ->
184 / 216. Always decide the side by measuring.

```python
def aocs(edges, face, formula):                                  # Offset Curve in Face
    b = part.Features.CreateAocsBuilder(NF)                      # Feature.Null; AOCS.Null -> "error return without exception set"
    try:
        sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        sec.AddToSection([R.CreateRuleEdgeDumb(list(edges))], edges[0], NULL, NULL, P(0, 0, 20), NXOpen.Section.Mode.Create, False)
        ess = part.CreateExpressionSectionSet(sec, "1", "MilliMeter", 0)     # number first ...
        b.Offsets.Append(ess)
        ess.ItemValue.RightHandSide = formula                                # ... formula afterwards
        b.FaceCollector = nxh.collector(part, faces=[face])                  # ASSIGN: the getter returns NULL
        b.AssociativeOutputOption = True; b.DistanceTolerance = 0.01
        return b.Commit()                                                    # OFFSET_IN_FACE
    finally:
        b.Destroy()
```
Top-face boundary (60x40), `off_d` = 5: 4 curves at z 20. **The side depends on the section direction (rule in section 31)**: the same
code gave 160 (inside the face) when run alone and 240 (outside, on the face's extension) when run
after the other curve features. The script measures and, when outside, undoes and re-creates with
`"-off_d"` -> 160; `off_d` = 2 -> 184. Failure: `b.FaceCollector.ReplaceRules(...)` -> "error return
without exception set".

```python
b = part.Features.CreateCompositeCurveBuilder(NF)
sec = b.Section; sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
sec.AddToSection([R.CreateRuleEdgeDumb(list(face.GetEdges()))], edge0, NULL, NULL, P(0, 0, 20), NXOpen.Section.Mode.Create, False)
b.Associative = True; b.ParentPart = NXOpen.Features.CompositeCurveBuilder.PartType.WorkPart
b.FixAtCurrentTimestamp = False; b.JoinOption = NXOpen.Features.CompositeCurveBuilder.JoinMethod.No
f = b.Commit()                                                  # EXTRACTED_CURVE, 4 curves, 200.0
```

```python
b = part.Features.CreateCurvelengthBuilder(NF)
sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)            # b.Section is None until assigned
sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
sec.AddToSection([R.CreateRuleCurveDumb([line])], line, NULL, NULL, P(0, -30, 0), NXOpen.Section.Mode.Create, False)
b.Section = sec; b.DistanceTolerance = 0.01
b.CurvelengthData.StartDistance.RightHandSide = "3"; b.CurvelengthData.EndDistance.RightHandSide = "-10"
b.CurveOptions.Associative = True
b.CurveOptions.InputCurveOption = NXOpen.GeometricUtilities.CurveOptions.InputCurve.Retain
f = b.Commit()                                                  # CURVE_LENGTH: 50 -> 43, ends x -3 .. 40
```
Defaults are already Incremental / StartEnd / Natural (the user's settings).
`GeometricUtilities.CurveLengthData.ExtensionMethodType` does not exist.

## 11. Helix, text, law curve

**Helix - VERIFIED**
```python
HB = NXOpen.Features.HelixBuilder; LT = NXOpen.GeometricUtilities.LawBuilder.Type
b = part.Features.CreateHelixBuilder(NXOpen.Features.Helix.Null)
b.OrientationOption = HB.OrientationOptions.Specified; b.StartAngle.RightHandSide = "0"
b.SizeOption = HB.SizeOptions.Diameter
b.SizeLaw.LawType = LT.Constant; b.SizeLaw.Value.RightHandSide = "hx_d"
# taper: b.SizeLaw.LawType = LT.Linear; b.SizeLaw.StartValue.RightHandSide = "hx_d"; b.SizeLaw.EndValue.RightHandSide = "10"
b.PitchLaw.LawType = LT.Constant; b.PitchLaw.Value.RightHandSide = "hx_p"
b.LengthMethod = HB.LengthMethods.Turns; b.Turns.RightHandSide = "hx_n"      # Turns = Expression
b.TurnDirection = HB.TurnDirections.RightHand; b.DistanceTolerance = 0.001
f = b.Commit()                                                               # HELIX
```
d 20, pitch 5, 4 turns: length 252.1214 (analytic 252.1219), from (10,0,0) to (10,0,20). Linear
diameter 20 -> 10: ends (10,0,0) and (5,0,20), length 189.66. `hx_n` 6 -> 378.18. Failure:
`b.NumberOfTurns.RightHandSide` -> "'str' object has no attribute 'RightHandSide'". The builder
ignores `CoordinateSystem` (memory gotcha): always +Z from the absolute origin. The user sets the
length by limits (16 of 17) rather than turns - section 35.

**Text - VERIFIED**
```python
TB = NXOpen.Features.TextBuilder
b = part.Features.CreateTextBuilder(NXOpen.Features.Text.Null)
b.Type = TB.Types.Planar; b.Script = TB.ScriptOptions.Western
b.SelectFont("Arial", TB.ScriptOptions.Western); b.TextString = "NX 2206"
b.PlanarFrame.AnchorLocation = NXOpen.GeometricUtilities.RectangularFrameBuilder.AnchorLocationType.BottomCenter
b.PlanarFrame.Length.RightHandSide = "40"; b.PlanarFrame.Height.RightHandSide = "8"; b.PlanarFrame.Shear.RightHandSide = "0"
xf = part.Xforms.CreateXform(nxh.point(part, 30, 20, 20), nxh.direction(part, (1, 0, 0)), nxh.direction(part, (0, 1, 0)), UPD, 1.0)
b.PlanarFrame.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
b.PlanarFrame.UpdateOnCoordinateSystem(); f = b.Commit()                     # TEXT
```
8 joined curves at z 20, x 13.97..45.33, y 20..28 (inside the 40x8 frame anchored bottom-centre).
Engraving: section `R.CreateRuleCurveFeature([f])`, extrude 0.5 subtract -> 43.2 mm3 removed, solid
count unchanged. Text on a curve / on faces was not probed (the user only uses Planar).

**Law curve - VERIFIED, section 40**: `CreateLawCurveBuilder(LawCurve.Null)`, per axis
`LawType = ByEquation`, `Parameter = "t"`, `Function = "xt"`, `DistanceTolerance = 0.0001`.

## 12. Curve measurement helpers - VERIFIED

```python
props = nxh.UFS.ModlGeneral.AskCurveProps      # (tag, t 0..1) -> point, tangent, p_norm, b_norm, torsion, radius
def at(c, t):   r = props(c.Tag, float(t)); return list(r[0]), list(r[1])
def ends(c):    return at(c, 0.0), at(c, 1.0)                    # works for Line, Arc, Spline and Edge
length = curve.GetLength()
def loop_closed(curves, tol=1e-3):                               # every end point is shared by two ends
    pts = [e[0] for c in curves for e in ends(c)]
    return all(sum(1 for q in pts if all(abs(a - b) < tol for a, b in zip(p, q))) == 2 for p in pts)
# tangency at a join: the tangents of the two meeting ends are parallel (|cos| ~ 1)
# planarity: sample points with at(), take a normal from three of them, max |(p - p0) . n|
```
`AskCurveProps` is under `UFS.ModlGeneral` (not `Modl`, not `Modeling`). The returned tangent is
not unit length (it is the derivative) - compare directions, not components.

---

# Round 2 - course-driven recipes (`scripts/course_checks.py`, 18 checks PASS)

## 14. Sketch On Path - VERIFIED

```python
b = part.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
try:
    sec = b.Section; sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    sec.AddToSection([R.CreateRuleCurveDumb([path])], path, NULL, NULL, P(40, -100, 0), NXOpen.Section.Mode.Create, False)
    b.PlaneLocation.Path.Value = path
    b.PlaneLocation.IsPercentUsed = True                 # % arc length
    b.PlaneLocation.Expression.RightHandSide = "0"       # the course's sweep-section position
    sk = b.Commit()
finally:
    b.Destroy()
sk.Activate(SK.ViewReorient.FalseValue)
o, m = sk.Origin, sk.Orientation.Element               # frame of the sketch: X (m.Xx..), Y, normal (m.Zx, m.Zy, m.Zz)
```
Path = R40 arc starting at (40,-100,0) with tangent +Y: sketch origin (40,-100,0), normal (0,1,0).
Tree: `DATUM_ON_PATH Datum On Path(3)` + `SKETCH` - the pair the user has 25 times. Default
orientation is normal to path (`PlaneOrientation`), other builder members: `Axis`,
`OrientingFace`, `ReversePlaneNormal`, `SketchOrient`. Draw the section with the frame vectors
(`CreateArc(P(o), V(X), V(Y), r, 0, 2*pi)`); constraining it to the path point was not probed.

## 15. More sketch relations, Make Symmetric, sketch Mirror - VERIFIED

```python
sk.CreateParallelConstraint(cg(free_line), cg(base_line))
sk.CreateEqualLengthConstraint(cg(free_line), cg(base_line))
sk.CreatePerpendicularConstraint(cg(other_line), cg(base_line))
sk.CreateMidpointConstraint(cg(point), cg(base_line))            # point aligned with the line's midpoint
d = sk.CreateDimension(SK.ConstraintType.ParallelDim, dg(line, SK.AssocType.StartPoint), dg(line, SK.AssocType.EndPoint),
                       origin, NXOpen.Expression.Null)            # length of a line
```
Base line horizontal, start on the origin, length `base_l` = 30. Free line (25.32 long, direction
(25,4)) became 30.000 long with direction (30,0); the third line became (0,1); the point moved from
x 11 to x 15. After `base_l` = 50: free line 50.000, point x 25 - the relations are stored
(no "Create Persistent Relations" switch is needed through this API).

```python
b = part.Sketches.CreateMakeSymmetricBuilder()
b.PrimaryObject.Value = l2; b.SecondaryObject.Value = l1; b.CenterLine.Value = dat.y     # ConvertToReference: bool
b.Commit(); b.Destroy(); sk.Update()
```
Two undimensioned lines: afterwards l1 = (12,58)-(20,85) and l2 = (-12,58)-(-20,85): here the
SecondaryObject (l1) moved onto the mirror image of the PrimaryObject. **That is not a rule**: in
`sketch_rules.py` K4 the same line moved with either role order (section 50) - fix or dimension the
line that must stay before relating. One `Mirror`-type constraint is reported by
`GetAllConstraintsOfType`. `Sketches.CreateSketchSymmetricBuilder()` ->
"Sketch is not initialized." on NX 2206.

```python
b = part.Sketches.CreateSketchMirrorPatternBuilder(NXOpen.SketchPattern.Null)
b.Section.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
b.Section.AddToSection([R.CreateRuleCurveDumb([l3])], l3, NULL, NULL, P(30, 100, 0), NXOpen.Section.Mode.Create, False)
b.UpdateInputSection()
b.DirectionObject.Value = dat.y; b.UpdateDirectionObject()       # the property is DirectionObject, not Centerline
b.CreateConstraint = True
b.Commit(); b.Destroy()
```
Line (30,100)-(45,110) mirrored about the datum Y axis: a new line with ends at x -30 and -45;
whole sketch WellConstrained / DOF 0 afterwards.

## 16. Edge rules and "stop at intersection" - VERIFIED

Block 40x30x10 with four R5 vertical blends; top face loop = 8 edges, area 1178.54, extruded 3:

| Rule | Curves | Result |
|---|---|---|
| `R.CreateRuleEdgeTangent(seed, NXOpen.Edge.Null, True, 0.5, False)` | 8 | solid 3535.619 |
| `R.CreateRuleEdgeBoundary([top_face])` | 8 | solid 3535.619 |
| `R.CreateRuleEdgeChain(seed, neighbour, isFromStart, top_face, False)` | 8 or 2 | solid 3535.619 with the right `isFromStart`, 2-edge open sheet with the other |
| `R.CreateRuleEdgeChain(seed, NXOpen.Edge.Null, True, top_face, False)` | 1 | seed only, sheet |

For `EdgeChain` the end edge is the loop neighbour of the seed; of the four (neighbour, sense)
combinations two close the loop the long way and two take the short way - check
`len(sec.GetOutputCurves())`.

```python
# four whole lines that cross like '#': one CurveDumb rule is refused
#   "Selected objects will result in a self intersecting section"
sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)
sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
for i in range(4):                                   # corners[i] -> corners[i+1] lies on lines[i]
    a, b2 = corners[i], corners[(i + 1) % 4]
    sec.AddChainBetweenIntersectionPoints([R.CreateRuleCurveDumb([lines[i]])],
        lines[i - 1], P(a[0], a[1], 0),              # start connector curve + intersection point
        lines[(i + 1) % 4], P(b2[0], b2[1], 0),      # end connector curve + intersection point
        lines[i], P((a[0] + b2[0]) / 2, (a[1] + b2[1]) / 2, 0), NXOpen.Section.Mode.Create, False)
```
Inner 20x20 square extruded 5: solid, 2000.0. (The course's interactive result for the un-trimmed
pick was four sheet walls; headless NX refuses the section instead.)

## 17. Composite Curve with Join - VERIFIED

`b.JoinOption = NXOpen.Features.CompositeCurveBuilder.JoinMethod.Cubic` (members: `No`, `Cubic`,
`Genernal` [sic], `Quintic`), `b.Tolerance = 0.001`, `b.HideOriginal = True/False`. Line + R10 arc +
line (55.708): `No` -> 3 curves (Arc, Line), sheet extrude has 3 faces; `Cubic` -> 1 `Spline` of
55.7079, sheet extrude has **1 face**, area 557.079 vs 557.080. The Cubic (and Quintic) joined
curve is an approximation within the tolerance, no longer an exact arc; `Genernal` is exact
(section 47).

## 18. Bridge Curve continuity G0..G3 - VERIFIED (G1, G2)

```python
CT = NXOpen.GeometricUtilities.Continuity.ContinuityTypes        # Free, G0, G1, G2, G3
b.StartConnectivity.Continuity.ContinuityType = CT.G2
b.EndConnectivity.Continuity.ContinuityType = CT.G2
```
From the end of an R20 arc to a line: radius of curvature of the bridge at the arc end
(`AskCurveProps(tag, t)[5]`) = 20.000 with G2, 21.633 with G1; at the line end 3.9e8 (flat) with
G2. Start tangent parallel to the arc tangent in both. G3, tangent magnitude and the course's
"start 0.1-0.2 mm inside the parent" location were not probed.

## 19. Studio spline between points ON existing curves - VERIFIED

```python
def on_curve(curve, formula):                                    # formula = percent 0..100, may be an expression name
    e = part.Expressions.CreateSystemExpressionWithUnits(str(formula), None)
    sc = part.Scalars.CreateScalarExpression(e, NXOpen.Scalar.DimensionalityType.NotSet, UPD)
    return part.Points.CreatePoint(curve, sc, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, UPD)

g = b.ConstraintManager.CreateGeometricConstraintData(); g.Point = on_curve(line_a, "t_end"); b.ConstraintManager.Append(g)
```
Degree 5 through 2 points (the user's own pattern): ends at (30,220,0) = 100 % of line A and
(60,240,10) = 0 % of line B, order 6; `t_end` 100 -> 50 moved the end to (15,220,0), no errors.

## 20. Curve on Surface - VERIFIED

```python
b = part.Features.CreateCurveOnSurfaceBuilder(NXOpen.Features.CurveOnSurface.Null)
try:
    b.Faces.ReplaceRules([R.CreateRuleFaceDumb([face])], False)
except Exception:
    b.Faces = nxh.collector(part, faces=[face])                   # which branch ran was not recorded
for p in pts:                                                     # points lying on the face
    g = b.ConstraintManager.CreateGeometricConstraintData(); g.Point = nxh.point(part, *p); b.ConstraintManager.Append(g)
f = b.Commit()                                                    # CURVE_ON_SURFACE
```
Three points on an R15 cylinder: maximum distance of the curve from the face 0.000; a degree-2
studio spline through the same three points is up to 0.338 off the face (the course's claim).

## 21. Isoparametric Curves - VERIFIED (defaults)

```python
b = part.Features.CreateIsoparametricCurvesBuilder(NXOpen.Features.IsoparametricCurves.Null)
b.SelectObject.Value = face; f = b.Commit()                      # feature type "Isoparametric Curve"
```
Cylinder face: 5 straight curves of 40.0 on the face. `Direction`, `Number`, `Placement`,
`Spacing` exist but were left at their defaults.

## 22. Combined Projection - VERIFIED

```python
b = part.Features.CreateCombinedProjectionBuilder(NXOpen.Features.CombinedProjection.Null)
fill(b.Curve1, [R.CreateRuleCurveDumb([top_view_curve])], help1, top_view_curve)
fill(b.Curve2, [R.CreateRuleCurveDumb([side_view_curve])], help2, side_view_curve)
DT = NXOpen.GeometricUtilities.ProjectionOptions.DirectionType   # CrvPlaneNormal (the user's default), Vector
b.Direction1.ProjectDirectionMethod = DT.Vector; b.Direction1.ProjectVector = nxh.direction(part, (0, 0, 1))
b.Direction2.ProjectDirectionMethod = DT.Vector; b.Direction2.ProjectVector = nxh.direction(part, (0, 1, 0))
b.CurveOptions.Associative = True; f = b.Commit()                # CPROJ_CMB
```
Half circle R20 in XY x ramp line in XZ: one curve whose samples satisfy both views to 3e-14
(radius 20 about the axis and z = (x - 180)/4), from (180,300,0) to (220,300,10).

## 23. Mirror Curve - VERIFIED

```python
b = part.Features.CreateMirrorCurveBuilder(NF)
fill(b.Curve, [R.CreateRuleCurveDumb([src])], help_point, src)   # Curve is a Section
b.PlaneOption = NXOpen.Features.MirrorCurveBuilder.PlaneOptions.NewPlane
b.NewPlane = part.Planes.CreatePlane(P(0, 0, 0), V(1, 0, 0), UPD)
f = b.Commit()                                                    # MIRROR_CURVE
```
(10,400,0)-(40,420,5) -> (-10,400,0)-(-40,420,5).

## 24. Text on a cylindrical face, and solid letters - VERIFIED

```python
TB = NXOpen.Features.TextBuilder
b = part.Features.CreateTextBuilder(NXOpen.Features.Text.Null)
b.Type = TB.Types.OnFace; b.Script = TB.ScriptOptions.Western; b.SelectFont("Arial", TB.ScriptOptions.Western)
b.TextString = "NX"
b.PlacementFaces.ReplaceRules([R.CreateRuleFaceDumb([cyl_face])], False)
b.OnFacePlacementMethod = TB.OnFacePlacementMethodOptions.CurvesOnFaces
fill(b.OnFacePlacementProfile, [R.CreateRuleEdgeDumb([edge])], point_on_edge, edge)    # an edge of that face
b.FrameOnPath.AnchorLocation = NXOpen.GeometricUtilities.FrameOnPathBuilder.AnchorLocationType.Center
b.FrameOnPath.AnchorPosition.IsPercentUsed = True; b.FrameOnPath.AnchorPosition.Expression.RightHandSide = "25"
b.FrameOnPath.Offset.RightHandSide = "8"; b.FrameOnPath.Length.RightHandSide = "14"; b.FrameOnPath.Height.RightHandSide = "8"
b.FrameOnPath.IsApexReversed = False        # which side of the edge the text grows to
b.CanProjectCurves = True                   # dialog "Project Curves"
f = b.Commit()
```
R15 x 40 cylinder: with the bottom edge the text sits at z 8..16 and is 0.005 from the face
(projected); with `CanProjectCurves = False` it is flat and up to 0.388 off. With the top edge the
same settings raise "Unable to project text curves." (the frame is above the face) - set
`IsApexReversed = True` or `Offset = -16`.

Solid letters:
- Extruding the projected outlines along the local normal gives **2 sheet bodies**, and with a
  boolean: "Solid tool body is required for current Boolean option." - the course's unsolved
  failure, reproduced.
- Working engraving of uniform depth: create the text **un-projected** (planar loops), Extrude it
  along the local outward normal from -3 to +2 as Subtract (removes 113.59), then
  `nxh.cylinder(part, axis_point, axis, 2 * (r - depth), height, nxh.BOOL.Unite, body)`: final
  removal 24.88 mm3, two new cylindrical floor faces of radius 14.4, body count unchanged, no
  feature errors. Raised letters by the mirrored idea (unite prisms, then intersect with a
  cylinder of r + height) and the Emboss feature were not probed.

## 25. Trim Curve - NOT WORKING

`part.Features.CreateTrimCurve2FeatureBuilder(NXOpen.Features.TrimCurve2.Null)`; members:
`CurveToTrim` (Section), `BoundingObjectList` + `CreateTrimCurveBoundingObjectBuilder()` (which has
`BoundingObject`, `BoundingObjectList`, `BoundingObjectMethodType`, `BoundingPlane`),
`SelectTrimRegion(point)`, `UpdateTrimRegionsAndDivideLocations()`, `KeepOrDiscard`,
`OperationOption`, `DirectionOption`, `CurveExtensionOption`. Attempt: section filled with the
target line, `bo.BoundingObjectList.Add(bounding_line)`, `b.BoundingObjectList.Append(bo)`,
`b.UpdateTrimRegionsAndDivideLocations()` -> "Bounding objects are either suppressed or modeled
away." Earlier attempt `b.BoundingObjectList.Add(curve)` -> "'ObjectList' object has no attribute
'Add'". Workaround: build the shortened curve directly (Curve Length with a negative increment, or
an associative line between on-curve / intersection points).
Round 3 retried with associative Line features as input (`CreateRuleCurveFeature` in `CurveToTrim`,
`bo.BoundingObjectList.Add(curve)`): the same "Bounding objects are either suppressed or modeled
away." both with and without the region calls; `bo.BoundingObject` is `None`. The user's 30 Trim
Curve features have no builder read-back. NOT WORKING after five variants with a bounding OBJECT.
**It works with a bounding PLANE** (`BoundingObjectMethodType = SelectPlane`, `BoundingPlane`):
section 48.

---

# Round 3 (`scripts/round3_checks.py`, run with the final `nx-journal-core/scripts/nxh.py` + `nxf.py`)

The sketch helpers used throughout this file (`new_sketch`, `cg`, `dg`, `help_at`, `add`,
`horizontal`, `vertical`, `pdim`, `diameter_dim`, `radius_dim`, `sketch_status`, `finish_sketch`) and
`datum_plane` / `datum_axis` are available verified as `nxf.<name>`; `nxh.section(..., seed=, rules=)`,
`nxh.section_region`, `nxh.section_feature` build the sections. Do not copy them - import them.

## 27. Sketch pattern - circular VERIFIED, linear NOT WORKING

```python
PD = NXOpen.GeometricUtilities.PatternDefinition
SP = NXOpen.GeometricUtilities.PatternSpacing.SpacingType
pb = part.Sketches.CreateSketchPatternBuilder(NXOpen.SketchPattern.Null)        # sketch active
pb.Section.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
pb.Section.AddToSection([R.CreateRuleCurveDumb([circle])], circle, NULL, NULL, P(12, 200, 0), NXOpen.Section.Mode.Create, False)
pb.UpdateInputSection()
ps = pb.PatternService; ps.PatternType = PD.PatternEnum.Circular
cd = ps.CircularDefinition
cd.RotationCenter = dat.origin; pb.UpdateCenterPoint()                          # an NXOpen.Point
cd.AngularSpacing.SpaceType = SP.Offset
cd.AngularSpacing.NCopies.RightHandSide = "4"; cd.AngularSpacing.PitchAngle.RightHandSide = "90"
pb.CreateConstraint = True; pb.UpdateCopies(); pb.EvaluatePattern()
pb.Commit(); pb.Destroy()
```
Circle at (10,200) -> 4 circles at (10,200), (-200,10), (-10,-200), (200,-10); sketch WellConstrained / DOF 0.
**Linear** (`PatternEnum.Linear`, `RectangularDefinition.XDirection`, `XSpacing`): `Commit()` raises
"Incorrect object for this operation." in every variant tried over three rounds (direction from the
datum X axis or from a sketch line; with `UpdateLinearDirectionObject` / `UpdateCopies` /
`EvaluatePattern`, with `UpdateRectangularDirectionObjects` / `UpdateData`, with no update call;
with and without `CreateConstraint`). A failed pattern commit also makes `run_journal` exit 1.

Verified replacement for a linear pattern - draw the instances, position them by formula:
```python
for i in range(4):
    c = part.Curves.CreateArc(P(10 + 12 * i, 230, 0), V(1, 0, 0), V(0, 1, 0), 2.0, 0.0, 2 * math.pi)
    nxf.add(sk, c, infer=False)
    nxf.pdim(sk, dat.y, P(0, 50, 0), c, A.ArcCenter, origin_i, f"10+{i}*pitch")
    nxf.pdim(sk, dat.x, P(50, 0, 0), c, A.ArcCenter, origin_j, "230")
    nxf.diameter_dim(sk, c, on_arc, origin_k, "4") if i == 0 else sk.CreateEqualRadiusConstraint(nxf.cg(c), nxf.cg(first))
```
WellConstrained / DOF 0; `pitch` 12 -> 15 moved the centres to x 10 / 25 / 40 / 55. When the count
itself must be a parameter, pattern the downstream feature instead (`nxf.pattern_linear`).

## 28. Ellipse, Fixed, reference conversion, mirror about a drawn centre line, chamfer - VERIFIED

```python
m3 = NXOpen.Matrix3x3(); m3.Xx, m3.Xy, m3.Xz, m3.Yx, m3.Yy, m3.Yz, m3.Zx, m3.Zy, m3.Zz = 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0
el = part.Curves.CreateEllipse(P(0, 300, 0), 12.0, 6.0, 0.0, 2 * math.pi, 0.0, part.NXMatrices.Create(m3))
nxf.add(sk, el, infer=False)                       # status UnderConstrained, DOF 3
sk.CreateFixedConstraint(nxf.cg(el)); sk.Update()  # status WellConstrained, DOF 0   (course "Fix Curve")
```
Fixed is the course's shortcut for geometry of certain size and position [CAD2.4 00:33]; it is also
what fills the user's projected / pasted sketches (37 923 Fixed relations in 261 sketches).

```python
cb = part.Sketches.CreateConvertToFromReferenceBuilder()
cb.InputObjects.Add(centre_line)
cb.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Reference       # or .Active
cb.Commit(); cb.Destroy()                          # centre_line.IsReference -> True
```
Mirror about that drawn line: the builder of section 15 with `mb.DirectionObject.Value = centre_line`
and `mb.CreateConstraint = True`. Persistent: re-dimensioning the source line's end from x 25 to
x 32 moved the image end to x -32; sketch DOF 0.

```python
b = part.Sketches.CreateSketchChamferBuilder()
b.CurvesToChamfer.Add(l1); b.CurvesToChamfer.Add(l2)
b.ChamferOption = NXOpen.SketchChamferBuilder.ChamferOptions.Symmetric           # Asymmetric, OffsetandAngle
b.Distance1.RightHandSide = "4"; b.CreateDistance1Dimension = True; b.TrimInputCurves = True
b.HelpPoint = part.Points.CreatePoint(P(128, 302, 0))                             # near the corner
b.Commit(); b.Destroy()
```
30 and 20 long lines meeting at a right angle: new line of 5.657 (= 4*sqrt(2)), lines trimmed to
26 and 16, sketch DOF 0. Without the two `Add` calls: "Chamfer requires two lines".
Polygon (`CreateSketchPolygonBuilder`, needs one argument) and Derived Lines were not probed -
a polygon is n lines with equal-length relations, a derived line is a line + parallel relation +
distance dimension.

## 29. Sketch Intersection Curve / Intersection Point - VERIFIED

```python
b = part.Sketches.CreateIntersectionCurveBuilder(NXOpen.SketchIntersectionCurve.Null)   # typed Null; sketch active
b.FaceCollector.ReplaceRules([R.CreateRuleFaceDumb([face])], False)
b.CollectorUpdated()                                   # without it: "Internal error" at Commit
b.DistanceTolerance = 0.01; b.Associative = True
b.Commit(); b.Destroy()

b = part.Sketches.CreateIntersectionPointBuilder(NXOpen.SketchIntersectionPoint.Null)
fill(b.Rail, [R.CreateRuleEdgeDumb([edge])], point_on_edge, edge)                       # Rail is a Section
b.UpdateData(); b.Commit(); b.Destroy()
```
Sketch on a datum plane x = 220 through a block: the top face (z 20) gave one sketch line
(220,0,20)-(220,30,20), sketch WellConstrained / DOF 0; the block edge along X at y 0, z 20 gave a
sketch point at (220,0,20). These are the user's 15 "Intersection Curve" and 67
"Intersection Point" sketch children [mined] and the course's Include tools [CAD2.3 00:41].

## 30. Parametric spline driven by a sketch - VERIFIED

The in-sketch spline stays frozen (section 4). What works: dimension **points** in the sketch,
finish it, then build an associative Studio Spline feature through those very `NXOpen.Point`
objects (`g.Point = sketch_point`).
Measured: sketch WellConstrained / DOF 0, spline feature `SPLINE` with the sketch as its only
parent, start at (0,300,0); editing the first point's dimension 300 -> 290 moved the spline start
to (0,290,0), no feature errors. Consume it with `R.CreateRuleCurveFeature([spline_feature])`
(add the sketch feature to the same rule when sketch lines close the profile).

## 31. Offset Curve in Face - what decides the side - VERIFIED

One edge of a planar face, help point near either end, value +5 / -5:

| section direction (`sec.GetStartAndDirection()[2]`) | value | result |
|---|---|---|
| +X (help point near the edge start) | 5 | y = -5, outside the face |
| +X | -5 | y = +5, inside |
| -X (help point near the other end) | 5 | y = +5, inside |
| -X | -5 | y = -5, outside |

Rule: a **positive value goes to the right of the section direction** when looking against the
face normal from outside, i.e. along `direction x face_normal`. The side "flipping between runs" in
round 1 was the section starting at a different end. Deterministic recipe: fill the section with a
seed and help point, read `sec.GetStartAndDirection()`, compute
`right = cross(direction, nxh.normal_at(face, start))`, test whether `start + eps * right` lies on
the face (`nxh.dist_to(part, face, p) < tol`), and use `+d` or `-d` accordingly.
The dialog's Trim / Extend to Face Edges options (`TrimToFaceEdgesOption`, `ExtendToFaceOption`)
are measured in section 46.

## 32. Offset Curve 3D Axial - PARTIAL

`b.Type = OffsetCurveBuilder.Types.Axial3d` (members `Axial3d`, `Distance`, `Draft`, `LawControl`),
`b.Offset3dDistance.RightHandSide = "6"`, `b.AxialOffsetDirection = nxh.direction(part, (0, 0, 1))`.
Commits; for a slanted 3D line the result is NOT the line translated by 6 along Z: ends
(300,0,6.119) and (340,30,16.0), length 50.975 vs 50.990, minimum distance to the source 5.996.
The course also saw the shape change with distance [CAD5.2 00:32]. What the construction is was
not established - measure before relying on it; for a plain shift use Move Object or smart points.

## 33. Point Set - VERIFIED

```python
b = part.Features.CreatePointSetBuilder(NXOpen.Features.PointSet.Null)           # defaults: CurvePoints, EqualArcLength
fill(b.SingleCurveOrEdgeCollector, [R.CreateRuleCurveDumb([curve])], help_point, curve)
b.NumberOfPointsExpression.RightHandSide = "5"
b.StartPercentage.RightHandSide = "0"; b.EndPercentage.RightHandSide = "100"
b.Associative = True; f = b.Commit()                                             # feature type "PointSet"
```
60 mm line: points at x 300 / 315 / 330 / 345 / 360.

## 34. Wrap / Unwrap Curve - VERIFIED (Wrap)

```python
fp, dp = nxf.datum_plane(part, "tangent", [cyl_face])                  # the wrap plane must be tangent to the face
b = part.Features.CreateWrapBuilder(NXOpen.Features.WrapUnwrap.Null)   # CreateWrapUnwrapBuilder does not exist
b.Type = NXOpen.Features.WrapBuilder.Types.Wrap                        # or .Unwrap
fill(b.Curves, [R.CreateRuleCurveDumb([planar_curve])], help_point, planar_curve)
b.Faces.ReplaceRules([R.CreateRuleFaceDumb([cyl_face])], False)
b.Plane.Value = dp                                                      # SelectISurface: datum plane
b.DistanceTolerance = 0.01; b.Associative = True
f = b.Commit()                                                          # feature type WRAP
```
R15 cylinder, tangent plane at x = 415; a slanted line in that plane (20 along the tangent, 20 up,
length 28.284) wrapped into a helix segment: 0.0005 from the face, length 28.2840, z 5..25 - the
course's "helix from a planar line" [CAD5.3 00:05]. `CutLineAngle` (Expression) sets the seam.
Unwrap is measured in section 48; the cone flat-blank example was not probed.

## 35. Helix by limits, linear pitch law; text on a curve; bridge G3 - VERIFIED

```python
b.LengthMethod = HB.LengthMethods.Limits                    # the user's way (16 of 17)
b.StartLimit.Expression.RightHandSide = "0"; b.EndLimit.Expression.RightHandSide = "hx_h"
b.PitchLaw.LawType = LT.Linear; b.PitchLaw.StartValue.RightHandSide = "2"; b.PitchLaw.EndValue.RightHandSide = "6"
```
Constant pitch 4, limits 0..20, d 20: length 314.7946 (analytic 314.7952 = 5 turns), end (10,0,20);
`hx_h` 30 -> end (-10,0,30) = 7.5 turns. Linear pitch 2 -> 6 over 20 mm: 5.00 turns - the pitch is
linear along the turns (mean pitch 4), not along the height (that would be 5.49 turns).

Text on a curve: `b.Type = TB.Types.OnCurve`, fill `b.OnCurvePlacementProfile`, `FrameOnPath`
as in section 24. On an R40 arc: `OrientationMethod` Natural -> letters in the arc's plane,
radius 40.07..48.1 (growing outward); `TB.OrientationMethodOptions.Vector` +
`b.OrientationVector = nxh.direction(part, (0, 0, 1))` -> letters standing up, z 0..8. (The
course's no-preview failure was on a straight line with Natural - not reproduced on an arc.)

Bridge G3: `ContinuityType = CT.G3` commits (order 8 spline); curvature radius 20.000 at the R20
arc end, 20.96 two percent further in. The constraint-face option was not probed.

## 36. A projected sketch curve loses its parent - VERIFIED (suppression case)

Sketch on a face, the edge of a chamfer projected in, a hole dimensioned from the projected line;
then the chamfer is suppressed:

| Check | Before | Parent suppressed | Unsuppressed |
|---|---|---|---|
| `nxf.sketch_status(sk)` | WellConstrained, 0 | **WellConstrained, 0** | WellConstrained, 0 |
| `nxh.feature_errors(part)` | {} | **{}** | {} |
| `Projected Curve(n).Suppressed` | False | **True** | False |
| `sk.Feature.GetFeatureWarningMessages()` | - | **'Sketch contains failed recipe curves.'** | - |
| hole centre | 635.515 | 635.515 (frozen) | 635.515 |

So neither the sketch status nor the error scan reveals it. After any edit that can remove
referenced edges run:
```python
for f in part.Features.GetFeatures():
    w = list(f.GetFeatureWarningMessages() or [])
    if w or (f.FeatureType == "CPROJ" and f.Suppressed): ...        # stale sketch reference
```
Recovery measured: restore the parent (unsuppress). Re-pointing the projection to another edge
(`Sketches.CreateProjectBuilder(cproj_feature)` and replacing its section rules) and the case of an
edge consumed by a later model change (not suppression) were not probed.

## 37. Section help point without a seed - VERIFIED

Rounded rectangle of 8 associative features in one `CreateRuleCurveFeature` rule:

| seed argument | help point | start point, direction |
|---|---|---|
| `Null` | (-14,-12,10) / (14,-12,10) / (20,5,10) | always (-20,7,10), (0,-1,0) |
| bottom line | (-14,-12,10) | (-15,-12,10), +X |
| bottom line | (14,-12,10) or (20,5,10) | (15,-12,10), -X |

Without a seed the help point is ignored; with a seed the section starts at the end of the seed
curve nearest the help point. Always pass both when the start point or direction matters (lofts,
sweeps, offset side).

## 38. Still not probed

(Worked in sections 43-48 since: Offset Curve Draft / Law, Offset in Face trim / extend, Unwrap,
Fit and Isocline curve, isoparametric options.) Still open: the cone flat blank, Shadow Curve,
Smooth Spline / X-Form on curves, Divide Curve, sketch Polygon / Conic / Derived Lines, text
W Scale, Emboss, bridge constraint faces, Depth / Skew and location offsets, helix along a spine,
WAVE-linked composites, re-attaching a projected curve to another edge, law curves by
`ByLawCurve` / `MultiTransition`, Offset in Face `Variable` (law) and `Projectdistance`.

## 39. Inclined port: datum axis + plane at an angle + Until Selected - VERIFIED

`scripts/inclined_port.py` (36 checks). A feature that is neither parallel nor square to the datum
CSYS hangs on a Datum Axis feature; so does a pattern whose axis is not a CSYS axis.

```python
# A1 hinge: a line through the housing axis at the port height (two points, or point + direction)
fa1, a1 = nxf.datum_axis(part, "two_points", (0, -20, "port_z"), (0, 20, "port_z"), name="AX_PORT_HINGE")
# P1 through A1 at port_ang to the YZ plane: its NORMAL is the port direction (cos a, 0, sin a)
fp1, p1 = nxf.datum_plane(part, "angle", [dat.yz, a1], "port_ang", name="PL_PORT_ANGLE")
# P2 = the port face: offset from P1 (measure p1.Normal: use "-port_len" if it points into the body)
fp2, p2 = nxf.datum_plane(part, "offset", [p1], "port_len", name="PL_PORT_FACE")
# sketch on P2; the circle centre is the PROJECTION of a point on the hinge axis
hinge = nxh.point(part, 0, 0, "port_z")
sk = nxf.new_sketch(part, p2, dat.y, hinge, "SK_PORT"); c = nxf.sketch_circle(part, sk, hinge, "port_od")
nxf.finish_sketch(sk)                                             # WellConstrained, DOF 0
# Extrude along the plane normal (ASSOCIATIVE direction), end limit Until Selected = the housing wall
d_in = part.Directions.CreateDirection(p2, NXOpen.Sense.Reverse, nxh.UPD)      # Reverse / Forward: towards the body
b = part.Features.CreateExtrudeBuilder(nxh.NULL_FEATURE)
b.Section = section; b.Direction = d_in; b.Limits.StartExtend.Value.RightHandSide = "0"
b.Limits.EndExtend.TrimType = GU.Extend.ExtendType.UntilSelected; b.Limits.EndExtend.Target = outer_wall_face
b.BooleanOperation.Type = nxh.BOOL.Unite; b.BooleanOperation.SetTargetBodies([body]); boss = b.CommitFeature()
# bore: the same with a second sketch, Subtract, Target = the housing bore face
# A2 = the port axis as a datum; a hole on the port face patterned about it
fa2, a2 = nxf.datum_axis(part, "face_axis", port_cylinder_face, name="AX_PORT")
cd = ps.CircularDefinition; cd.RotationAxis = nxf.axis_from(part, a2)          # inside a PatternFeatureBuilder
```

`nxf.extrude_ex(..., until=face)` takes a numeric vector, which does not follow the plane; use the
builder with `Directions.CreateDirection(datum_plane, sense, UPD)` when the direction is a parameter.

Measured (housing dia 60 / bore 44, port dia 26 / bore 14, `port_len` 48, `port_z` 35, `port_ang` 30):
A1 direction (0,1,0) at z 35 by both definitions; P1 normal (0.866, 0, 0.5) with the formula
`port_ang` (no sign flip needed); P2 through hinge + 48 x direction (0.0 mm); port and bore cylinder
axes = (0.866, 0, 0.5); the bore is open into the housing and the boss is solid up to the wall; first
hole removes pi d^2/4 x depth exactly, the pattern 4 x that; all 4 hole axes parallel to the port axis
on the pitch circle; one solid 121458.13 mm3, Examine Geometry clean, STEP round trip 3e-7.
Regeneration `port_ang` 45, `port_len` 60, `port_z` 30: every check again, no feature errors; back
to nominal: volume to 1e-6.

**Limit of Until Selected, measured**: with `port_ang` 45 and `port_len` still 48 the port-face circle
dips into the housing wall and the update fails with "Cannot trim with the limit face. The extruded
body may not completely intersect the limit face." (the features after it fail with "Parent features
failed to update" / "Tool body completely outside target body."). The whole section must start
outside the limit face: `port_len*cos(a) - port_od/2*sin(a) > body_d/2` for this layout (clearance
-5.25 mm in the failing case). Check that inequality at both ends of the angle range.

`nxh.hole_census` files an inclined cylinder under `"partial"` at the default `min_coverage` (its
length is estimated from the bounding box): call it with `min_coverage=0` to find inclined ports.

## 40. Law curve by equation; involute spur gear - VERIFIED

`scripts/law_curve_gear.py` (37 checks). Source of the method: one fully read gear template of the
third-party collection `[community: 1 author]`, rebuilt and measured here.

```python
def law_curve(part, fx, fy, fz, name, tol=0.0001):     # fx, fy, fz = NAMES of expressions in terms of t
    b = part.Features.CreateLawCurveBuilder(NXOpen.Features.LawCurve.Null)
    try:
        for law, fn in ((b.XLaw, fx), (b.YLaw, fy), (b.ZLaw, fz)):
            law.LawType = GU.LawBuilder.Type.ByEquation; law.Parameter = "t"; law.Function = fn
        b.DistanceTolerance = tol
        f = b.CommitFeature()                              # FeatureType SPLINE_LAW, one Spline
    finally:
        b.Destroy()
    return f, [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)][0]
```

- The parameter is a named, unitless expression `t = 1`; NX runs it from 0 to 1. Every coordinate is an
  expression that depends on `t` (directly or through others, e.g. `u = t*u_max`). Several law curves
  share the one `t`.
- Trig functions take degrees: a roll angle in radians goes in as `u*180/pi()`.
- Keep the pressure angle a plain NUMBER in degrees (`alpha = 20`, unitless) so that
  `inv_alpha = tan(alpha) - alpha*pi()/180` stays unitless; type the angles that feed a datum plane or
  `cos()` / `sin()` as Degrees (`mirror_angle`, `tip_a0`, `tip_a`). `arctan(y/x)` returns degrees.

Expression set (m = module, z = teeth, alpha, b = face width):

```
d = z*m      da = d+2*m      df = d-2*1.25*m      db = d*cos(alpha)      rb = db/2
inv_alpha = tan(alpha)-alpha*pi()/180            u_max = sqrt((da/db)^2-1)      u = t*u_max
xt = rb*(cos(u*180/pi())+u*sin(u*180/pi()))      yt = rb*(sin(u*180/pi())-u*cos(u*180/pi()))     zt = 0     <- flank
mirror_angle = 90/z+inv_alpha*180/pi()  [deg]    <- half tooth angle at the base circle
x_tip, y_tip = xt, yt at u_max                   tip_a0 = arctan(y_tip/x_tip) [deg]
tip_a = tip_a0+t*(2*mirror_angle-2*tip_a0) [deg] xt_tip = da/2*cos(tip_a)       yt_tip = da/2*sin(tip_a)         <- tip arc
xt_base = t*rb                                   yt_base = 0                                                     <- radial line 0 -> rb
```

Feature sequence: `Cylinder(df, b)` (the root circle needs no curve) -> three law curves (flank, tip
arc, radial line) -> Datum Plane `Angle` `[dat.xz, dat.z]` -> Mirror Curve of flank + radial line about
it (`MirrorCurveBuilder`, `NewPlane = nxf.plane_from_datum(part, plane)`) -> Extrude of the closed
profile, one `CurveFeature` rule over the four curve features, as its own body -> `nxf.pattern_geometry`
of the tooth BODY, count `"z"` -> ONE `nxh.unite(part, cyl, tool_features=[tooth_extrude, pattern])` ->
bore and details afterwards (every tooth body reaches the centre: a bore cut before the Unite is
filled again).

Measured, m 3 / z 17 / alpha 20 / b 10:
- flank spline against the exact involute at 11 parameters: 1.2e-5 mm (tolerance 0.0001); radial
  line length = rb; tip arc length = ra x (2 x half angle - 2 x tip angle) to 1e-4.
- The Angle plane needed the formula **`-mirror_angle`** to contain the tooth centre line
  (cos M, sin M, 0) - the same sign the template uses. Create with `mirror_angle`, test
  `plane.Normal . (cos M, sin M, 0) == 0`, negate the formula if not.
- pitch points: (d/2, angle inv(alpha)) and its mirror image lie on the two flanks (0.000 mm) =
  arc tooth thickness pi*m/2 = 4.7124; tip circle point on the crest; tip radius 28.500.
- 17 lumps on the pitch cylinder; volume 18686.6130 against 18686.6145 from the numerically
  integrated involute profile (8e-8 relative); Examine Geometry clean; STEP round trip 2e-6.
- **Regeneration z 17 -> 24, m 3 -> 2**: all checks again (24 teeth, volume 16623.0591 / 16623.0596),
  no feature errors; back to nominal to 1e-6.

The template joins the profile into one spline (Composite Curve, Join) before extruding, blends the
root (`0.38*m`) and tip (`0.1*m`) and patterns the whole body; none of that is needed for a correct
tooth. For z above about 41 (alpha 20, dedendum 1.25) the base circle lies inside the root circle:
the recipe still holds (the flank simply starts inside the cylinder).

## 41. Boolean expressions with if / else that switch optional features - VERIFIED

`scripts/law_curve_gear.py` G3 `[community: 1 author]`, measured here in batch.

```python
part.Expressions.CreateExpression("Boolean", "use_chamfer=true")
part.Expressions.CreateExpression("Boolean", "use_fillet=false")
part.Expressions.CreateExpression("Boolean", "chamfer_decider=if (use_chamfer == true && use_fillet == true) (false) else (use_chamfer)")
b = part.Expressions.CreateSuppressByExpressionBuilder()
b.SuppressAction = NXOpen.SuppressByExpressionBuilder.ExpressionAction.CreateEach
b.FeatureList.Add(chamfer_feature); b.Commit(); b.Destroy()
e = NXOpen.TaggedObjectManager.GetTaggedObject(nxh.UFS.ModlGeneral.AskSuppressExpTag(chamfer_feature.Tag))
e.RightHandSide = "chamfer_decider"            # a Number expression, descriptor "Suppression Status": 1 active, 0 suppressed
part.Expressions.FindObject("use_fillet").RightHandSide = "true"; nxh.update()
```

The suppression expression is a plain Number; a Boolean expression (or an if / else of Booleans) as
its right-hand side works: TRUE = active. Measured on a Chamfer (`chamfer_decider`) and an Edge Blend
(`use_fillet`), all four states after `nxh.update()`:

| use_chamfer | use_fillet | Chamfer | Edge Blend | Volume |
|---|---|---|---|---|
| true | false | active | suppressed | 18666.716 (= plain - chamfer ring, exact) |
| true | true | **suppressed** (the decider lets the fillet win) | active | 18678.222 |
| false | true | suppressed | active | 18678.222 |
| false | false | suppressed | suppressed | 18686.613 (the plain gear) |

No feature errors in any state. `NXOpen.Utilities` cannot be imported in NX 2206 batch
(`ImportError`): turn a tag into an object with `NXOpen.TaggedObjectManager.GetTaggedObject(tag)`.

---

# CAST round (2026-10-06) - findings of Siemens' NX CAST 8.5 curve and sketch courses, re-measured on NX 2206

Sources: `[cast ecva .. ecve]` curve courses, `[cast eska, eskb]` sketching, `[cast eesc, efmb]`
feature modelling (rules in own words; CAST is from 2012 - every statement below was measured on
NX 2206 first). Helper module: `scripts/curvekit.py` (`import curvekit as ck`).

## 42. Measuring a curve along its length - VERIFIED (`curvekit.py`, 8 checks)

```python
sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0]))); import curvekit as ck
fr = ck.frame(curve, t)            # point, unit tangent, normal, binormal, torsion, radius, k (1/mm) at t 0..1
q = ck.curve_quality(curve, n=200) # inflections, inflection_t, peaks, peak_t, k_max, r_min, k_end, torsion_max, length
ck.max_dev(part, curve, pts)       # largest distance of coordinates from the curve
ck.join_angle(c1, t1, c2, t2)      # 0 = tangent continuous
ck.planarity(curves); ck.spline_data(spline)   # order, degree, poles, segments, periodic, rational
```
An inflection is counted where the binormal of `AskCurveProps` turns over between two samples
(works for planar and 3D curves); a peak is an interior local maximum of the curvature. Self-test:
arc R25 -> k_max 0.04, 0 inflections, 0 peaks, torsion 0; line -> `AskCurveProps` radius 3.937e8
(every radius above 1e8 is treated as straight, k = 0); S-curve through 5 points -> exactly 1
inflection at t 0.5; curve curvature against `nxh.max_curvature` of the sheet extruded from it:
0.016637544 / 0.016637544; a 3D spline -> torsion 0.038, 19 mm out of plane.

## 43. Studio Spline rules - VERIFIED (`spline_rules.py`, 39 checks) [cast ecvc]

```python
f, sp = ck.studio_spline(part, pts, degree=3)                               # Through Points
f, sp = ck.studio_spline(part, pts, poles=True, single=True)                # By Poles, one segment, degree = poles - 1
f, sp = ck.studio_spline(part, loop, degree=3, periodic=True)               # closed: do NOT repeat the first point
f, sp = ck.studio_spline(part, [ck.on_curve(part, arc, 100), p1, p2], constraints={0: {"auto": "Curvature"}})   # G2 to the arc
f, sp = ck.studio_spline(part, pts, constraints={0: {"direction": part.Directions.CreateDirection(line, NXOpen.Sense.Forward, UPD)}})
# inside: b.IsSingleSegment (By Poles), b.IsPeriodic, b.MatchKnotsType (NotSet | Cubic | General);
#   g = b.ConstraintManager.CreateGeometricConstraintData(); g.Point = point
#   g.CanInferConstraintFromAttachmentParent = True; g.AutomaticConstraintType = GC.AutoConstraintType.Tangent | Curvature
#   g.TangentDirection = NXOpen.Direction; g.TangentMagnitude = part.Scalars.CreateScalar(v, NotSet, UPD)
#   g.Curvature = part.Offsets.CreateCurvature(curve, scalar_t, UPD)
```

Type (S1). 7 exact points of an R100 arc: Through Points passes through all (0.0000), 0.0067 off
the arc between them, no inflection; the same points as poles: only the END poles are on the curve,
the interior ones 1.18 off. 9 points with +-0.5 mm alternating error: the table of SKILL.md 6a
(through d3: 6 inflections, r_min 34.5; through d5: r_min 14.6; 9 poles d3: 0 inflections, 4 peaks;
5 poles single segment: 0 / 0; fit d3 one segment: 0 / 0, 0.19 off the true arc).

Arithmetic (S2), 6 points / poles:

| Spline | Order | Poles | Segments |
|---|---|---|---|
| By Poles degree 3 / 5 / 2 | 4 / 6 / 3 | 6 | 3 / 1 / 4 |
| By Poles `IsSingleSegment`, 6 poles | 6 | 6 | 1 |
| By Poles degree 5, 4 poles | "Insufficient number of poles specified for a given degree" | | |
| Through Points degree 3 / 5 / 1 | 4 / 6 / 2 | 6 | 3 / 1 / 5 |
| Through Points degree 3, `MatchKnotsType` Cubic or General | 4 | 8 | 5 |
| Through Points degree 5, 9 points | 6 | 9 | 4 |

Curvature slope across the interior knots (same 6 points): degree 3 jumps by 15.3 x the curvature
range, degree 5 (one segment) has no knot and no jump. None of the curves is rational.

Closed (S3), 6 points on a 60 x 40 oval: periodic through points - gap 0, seam tangent angle 0,
curvature 0.076747 on both sides of the seam, through all points, solid with 3 faces; first point
repeated, not periodic - closed, seam tangent angle 25.04 deg, solid with 4 faces (a corner edge);
periodic by poles - smooth, 5.0 inside its poles, no inflection. Periodic + matched knots commits
and reads the same as periodic alone.

End constraints (S4):
- direction = smart Direction of an associative line driven by an angle expression: gap 0, tangent
  angle 0.000 at 10 deg and again after the edit to 40 deg, no feature error;
- `TangentMagnitude` (points (0,0) (40,20) (80,0), start direction +Y), radius of curvature at the
  start: unset 31.83 (natural) | 1 -> 0.0021 | 10 -> 0.208 | 40 -> 3.33 | 80 -> 13.3 | 160 -> 53.3 |
  320 -> 213 (and an inflection). r = magnitude^2 / 480: the value is the length of the derivative
  vector, the natural one is about 124 = 1.25 x the curve length;
- end point on an R20 arc: no constraint 39.6 deg off tangent; `Tangent` 0.000 deg, radius 19.2;
  `Curvature` 0.000 deg, radius 20.000; explicit `CreateDirection(curve, t, Tangent)` +
  `Offsets.CreateCurvature(curve, t)`: 0.000 deg, 20.000;
- By Poles, 5 poles, first pole on the arc end: `Tangent` moved pole 2 from y+150 onto the tangent
  line y+140; `Curvature` moved pole 3 as well (radius 20.000); a direction on pole 3 (interior):
  "Cannot compute bcurve."

Pole construction (S5), single segment of degree 4 from the end of an R20 arc: pole 2 at 5 / 10 / 20
on the tangent line -> tangent every time, start radius 2.22 / 8.89 / 35.56 (= a^2 * 4 / (3 h) with
pole 3 at h 15); pole 3 at h = k a^2 p/(p-1) = 6.667 -> radius 20.000. The same h on a 2-segment
cubic (h = k a^2 3/2): radius 40 - the first knot span enters; use the automatic constraint there.

Editing (S8): `b = part.Features.CreateStudioSplineBuilderEx(spline)` (the Spline object of the
feature), `b.Degree = 5`, `Commit()`: still through its 6 points, 3 segments -> 1, shape between the
points moved 5.72 mm.

## 44. Fit Curve on noisy points; tolerance against poles - VERIFIED (`spline_rules.py` S6, S7) [cast ecvc]

```python
f, sp = ck.fit_spline(part, pts, degree=3, segments=1)         # FitCurveBuilder, FitSpline, SpecifiedPoints, DegreeAndSegments
f, sp = ck.fit_spline(part, pts, degree=3, tolerance=0.1)      # DegreeAndTolerance: NX chooses the segments
```
30 points on 60 deg of an R100 arc with +-0.05 "measuring" error:

| Curve | Poles / segments | Off the points | Off the true arc | Curvature max / min | Peaks |
|---|---|---|---|---|---|
| Through Points degree 3 | 30 / 27 | 0 | 0.050 | 1.52 | 2 |
| Fit degree 3, 1 segment | 4 / 1 | 0.100 | 0.054 | 1.12 | 0 |
| Fit degree 5, 1 segment | 6 / 1 | 0.025 | 0.059 | 1.56 | 1 |
| Fit degree 3, tolerance 0.1 | 5 / 2 | 0.038 | 0.043 | 1.15 | 1 |
| Fit degree 3, tolerance 0.01 | 7 / 4 | 0.008 | 0.054 | 1.29 | 1 |

No curve is nearer the true arc than the noise; what the low-degree fit buys is the even curvature.
A tolerance below the noise only adds segments. (For a measured ARC use Fit Circle -
`nx-reverse-engineering`.)

Tolerance of an approximated curve: involute law curve (rb 24, roll 0..0.9 rad) at
`DistanceTolerance` 0.01 / 0.001 / 0.0001 -> 11 / 13 / 15 poles, 0.00024 / 0.00024 / 0.000014 off
the exact involute. R20 arc projected along -Z onto an R50 cylinder at 0.01 / 0.001 / 0.0001 ->
7 / 8 / 28 poles, 0.0038 / 0.0008 / 0.000015 off in plan.

## 45. Offset Curve options - VERIFIED (`offset_checks.py` O1-O4) [cast ecvd]

```python
OB = NXOpen.Features.OffsetCurveBuilder
b.TrimMethod = OB.TrimOption.ExtendTangents      # NotSet (dialog None) | ExtendTangents | Fillet
b.RoughOffset = True                             # cuts fold-overs of spline offsets
b.PointOnOffsetPlane = nxh.point(part, 0, 10, 0) # needed for ONE straight line
b.Type = OB.Types.Draft;      b.DraftHeight.RightHandSide = "10"; b.DraftAngle.RightHandSide = "5"
b.Type = OB.Types.LawControl; b.LawControl.LawType = GU.LawBuilder.Type.Linear
b.LawControl.StartValue.RightHandSide = "2"; b.LawControl.EndValue.RightHandSide = "6"
```
Z chain (0,0)-(40,0)-(40,30)-(80,30), distance 5, both sides give the mirrored result:
`NotSet` 3 lines 40 / 30 / 40 whose ends are 7.071 apart at both corners (on one side of each
corner a gap, on the other a crossing), and a second offset of that result fails with "The section
contains multiple loops."; `ExtendTangents` 3 lines 35 / 30 / 45 that meet; `Fillet` 4 pieces with
one R5 arc (7.854), total 107.854, all joints closed; both can be offset again.
Single line: without the plane point "Input curves form straight line, unable to determine offset
plane."; with a point beside it in XY the copy is shifted 5 in y, with a point above it 5 in z.
Beyond the smallest radius (distance 3): closed drop (r_min 0.40) plain inward offset = one spline
of 99.58, nowhere nearer the source than 2.996, extrudes to one solid (area 509.6 against 852.1);
open hairpin (r_min 0.19) plain offset to the inside = 71.66 long with points 0.68 from the source
(folded over); with `RoughOffset` 57.26 long, 2.995 everywhere. The check:

```python
def clean_offset(part, result_curves, source_curves, d, n=60):     # must be >= d - tolerance
    return min(nxh.dist_to(part, src, s["point"]) for c in result_curves for s in ck.sample(c, n) for src in source_curves)
```
Draft 10 / 5 deg on a 60 x 40 loop: 4 lines at z 10, perimeter 193.001 (`ReverseDirection` False)
or 206.999 (True) = 200 -+ 8 x 10 tan 5. Law Linear 2 -> 6 on a 60 mm line (with a plane point):
a Spline, 2 at the end nearest the help point and 6 at the other. 3D Axial of a line: a Spline of
50.975 for a source of 50.990.

## 46. Offset Curve in Face: reaching the boundary; Divide Face - VERIFIED (`offset_checks.py` O5, O6) [cast ecvd]

```python
b = part.Features.CreateAocsBuilder(NF); AB = type(b)              # class AOCSBuilder
b.ExtendToFaceOption = AB.ExtendToFace.Boundary                    # default NotSet: the offset keeps the edge's extent
b.TrimToFaceEdgesOption = False                                    # default: cut at the face boundary; True = let it cross
b.TrimMethod = AB.Trim.WithinSection; b.ExtendMethod = AB.Extend.WithinSection      # defaults: neighbours meet at corners
b.OffsetMode = AB.OffsetType.Arclength                             # Chordal (default) | Arclength | Geodesic | Tangential | Projectdistance
b.Offsets.Append(ess1); b.Offsets.Append(ess2)                     # several offsets of one string = ONE feature
# other defaults read back: SplitCurveOption True, RemoveSelfIntersections True, AssociativeOutputOption True
```
Test face: cylindrical top (R80, axis Y) of a wedge whose plan is 60 wide at y 0 and 90 wide at
y 40, offset 10:

| Edge, options | Curve | Ends |
|---|---|---|
| y = 0 edge (face widens), defaults | 61.504 = the edge length | 3.779 short of the boundary at both ends |
| same, `ExtendToFaceOption = Boundary` | 69.682 = face width at y 10 | on boundary edges (0.000) |
| y = 40 edge (face narrows), defaults | 86.678 = face width at y 30 | on boundary edges |
| same, `TrimToFaceEdgesOption = True` | 3 pieces, 95.585 in total | two pieces lie beyond the face |
| y = 0 edge + a side edge, defaults | 2 curves, joint gap 0.0013 | - |
| same, `TrimMethod` / `ExtendMethod` NotSet | 2 curves, 11.19 apart at the corner | - |

```python
def ends_on_boundary(part, face, curve, tol=1e-3):                 # the check before Divide Face / Trim Sheet
    gaps = []
    for t in (0.0, 1.0):
        pt = part.Points.CreatePoint(nxh.P(*ck.frame(curve, t)["point"]))
        gaps.append(min(nxh.min_dist(pt, e) for e in face.GetEdges())); nxh.S.UpdateManager.AddToDeleteList(pt)
    return gaps                                                    # [0, 0] = reaches the boundary at both ends

b = part.Features.CreateDividefaceBuilder(NF)
b.FacesToDivide = nxh.collector(part, faces=[face])
tool = b.SelectDividingObject; tool.ToolOption = GU.SelectDividingObjectBuilder.ToolType.Object
tool.DividingObjectsList.Add(section_of_the_curve_feature)         # a Section with CreateRuleCurveFeature([offset_feature])
b.ExtendOption = False                                             # True: a short curve is extended to the boundary
b.ProjectionOption.ProjectDirectionMethod = GU.ProjectionOptions.DirectionType.FaceNormal   # default is CrvPlaneNormal!
f = b.CommitFeature()
```
Divide Face measured (face area 3128.82, strip between y 0 and y 10 = 655.78 analytic):
short curve, `ExtendOption` False -> "Dividing objects do not divide selected faces"; short curve,
`ExtendOption` True -> 2 pieces 655.78 + 2473.05; extended curve -> the same 2 pieces; extended
curve with the DEFAULT projection (`CrvPlaneNormal`: the curve is planar, its plane normal is the
cylinder axis) -> 3 pieces 191.29 + 191.29 + 2746.24, i.e. cuts along the rulings through the two
curve ends, no error. `DirectionType` members: CrvPlaneNormal, FaceNormal, Vector.

Distance method, straight generator of an R15 half cylinder, 10: Chordal 38.942 deg round the axis
(= 2 asin(10/30)), Arclength 38.197 (= 10/15 rad), Geodesic 38.197, Tangential 41.810 (= asin(10/15)),
Projectdistance "Cannot create offset. Modify input parameters." (needs `ProjectPlaneNormal`).
Two section sets 6 and 12: one `OFFSET_IN_FACE` feature, 2 curves at 23.07 and 47.16 deg.

## 47. Join, Bridge shape control, Project directions, Intersection of datum planes - VERIFIED (`cast_curve_checks.py` C1-C4)

```python
b = part.Features.CreateJoinCurvesBuilder(NF)                      # FeatureType JOIN_CURVE; no button in the NX 2206 menu
ck.fill(b.Section, [R.CreateRuleCurveDumb(chain)], help_point, chain[0])
b.OutputCurveType = NXOpen.Features.JoinCurvesBuilder.OutputCurve.General        # General | Cubic | Quintic | Advanced
b.DistanceTolerance = 0.001; b.AngleTolerance = 0.5; b.CurveOptions.Associative = True; f = b.CommitFeature()
```
Line 20 + R10 quarter arc + line 20 (55.70796), tolerance 0.001; Join Curves and Composite Curve
(`JoinMethod.Genernal` / `Cubic` / `Quintic`) give identical curves:

| Output | Result | Deviation | Sheet extrude |
|---|---|---|---|
| none (Composite `No`) | 3 curves | 0 | 3 faces |
| General | 1 rational cubic, 10 poles, 3 segments, length 55.70796 | 0.000000 | 1 face |
| Cubic | 1 spline, 23 poles, 20 segments | 0.00049 | 1 face |
| Quintic | 1 spline, degree 5, 21 poles | 0.00055 | 1 face |
| Advanced (defaults: degree 7, 1 segment) | 54.28 long | **2.42** | 1 face |

Bridge shape control (from the end of an R20 arc to a line 40 away):
```python
BB = NXOpen.Features.BridgeCurveBuilderEx
b.ShapeControlMethod = BB.ShapeControlMethods.TangentMagnitude     # TangentMagnitude | Conic | DepthSkew | TemplateCurve
b.TangentMagnitude.StartTangentMagnitude.RightHandSide = "1"; b.TangentMagnitude.EndTangentMagnitude.RightHandSide = "1"
b.ShapeControlMethod = BB.ShapeControlMethods.Conic; b.Rho.RightHandSide = "0.5"
```
| Setting | Degree / poles | Radius at the arc end | r_min | Inflections |
|---|---|---|---|---|
| G0 / G0 | 3 / 4 (straight) | - | - | 0; 14 and 31 deg off tangent |
| G1 / G1 (magnitude 1 = default) | 3 / 4 | 2443 | 27.05 | 0 |
| G2 / G2 | 5 / 6 | 20.000 | 18.22 | 2 |
| G1, magnitude 0.5 / 2.0 | 3 / 4 | 16.2 / 135 | 4.57 / 6.82 | 0 / 1 |
| G1, conic rho 0.3 / 0.5 / 0.7 | 3 / 4 | 33 / 180 / 980 | 3.46 / 18.86 / 18.75 | 0 |
Here the magnitude IS a factor (1.0 reproduces the default) - unlike the Studio Spline constraint.
Between the top edges of two extruded sheets (`CreateRuleEdgeDumb`, help point at the edge end to
bridge; `curve_activities.py` A3): gap 0 and tangent angle 0.000 at both edges, and again after
both parent radii changed (12.7 -> 9.5, 25 -> 31.8), no feature error.

Project Curve directions (`PB = NXOpen.Features.ProjectCurveBuilder`):
```python
b.ProjectionDirectionMethod = PB.DirectionType.AngleToVector; b.ProjectionVector = dir; b.AngleToProjectionVector.RightHandSide = "20"
b.ProjectionDirectionMethod = PB.DirectionType.TowardPoint;   b.PointToProjectToward = nxh.point(part, x, y, z)
b.ProjectionDirectionMethod = PB.DirectionType.TowardLine;    b.LineToProjectToward.Value = line_or_axis
b.ProjectionOption = PB.ProjectionOptionType.ProjectBothSides  # with AlongVector
```
R20 quarter arc: onto the XY plane along -Z an `Arc` r 20.000000; onto a plane tilted 20 deg a
degree-3 spline with 4 poles, 32.43 long; onto an R50 cylinder along -Z TWO splines (near and far
side), 0.0013 off the face; along the face normal one spline of 26.30 (a different curve).
80 mm line over a 60 x 40 block top with a d10 hole, along -Z: 2 curves x 100..125 and 135..160,
50.0 in total; onto the plane z 0: 1 curve of 80.
d20 circle 50 above the plane z 0: Along Vector d 20.000 (an Arc); Angle to Vector +20 -> d 56.397
(= 20 + 2 x 50 tan 20, flared outward), -20 -> 16.397; Toward Point with the point 50 BELOW the
plane -> d 10.000, with the point above the circle "No curve projected."; Toward Line (the axis of a
d60 cylinder, source line 40 from the axis) -> radius 30.000, heights kept. Faces lying behind the
vector: "No curve projected."; with `ProjectBothSides` 4 curves on the faces at z 0 and z 10.

Intersection Curve of two datum planes (`FirstFace` and `SecondFace` by `CreateRuleFaceDatum`):
`Commit()` returns `None`, no feature is added, one plain `Line` appears at the right place
(y 30, z 12) and it does NOT move when the plane goes to z 20. NX 8.5's "plane x plane gives a
non-associative line" still holds; the 8.5 refusal of planes as input does not. For an associative
line use a Datum Axis of type `Intersection` (section 6).

## 48. More associative curve commands - VERIFIED (`cast_curve_checks.py` C5-C10, `curve_activities.py`)

Line tangent to two circles [cast ecvb]:
```python
LB = NXOpen.Features.AssociativeLineBuilder; view = part.ModelingViews.WorkView
b.StartPointOptions = LB.StartOption.Tangent; b.StartTangent.SetValue(circle1, view, nxh.P(*help1))
b.EndPointOptions = LB.EndOption.Tangent;     b.EndTangent.SetValue(circle2, view, nxh.P(*help2))
b.Limits.StartLimit.LimitOption = GU.CurveExtendData.LimitOptions.Value; b.Limits.StartLimit.Distance.RightHandSide = "-20"   # optional
```
Circles R30 at x 0 and R15 at x 100: the four pairs of help points (above / above, below / below,
above / below, below / above) gave the four common tangents (98.869 x2 outer, 89.303 x2 inner),
each at distance 30.000 / 15.000 from the centres with its ends on the circles; R30 -> R40: still
tangent, end on the circle. Limits -20 / 150: both are measured from the START tangent point - the
line is 170 long, still on the common tangent, and no longer ends on the circles.

Arc through two points with a radius [cast ecvb]:
```python
AB = NXOpen.Features.AssociativeArcBuilder
b.Type = AB.Types.ThreePointArc
b.StartPointOptions = AB.StartOption.Point; b.StartPoint.Value = p_start
b.EndPointOptions = AB.EndOption.Point;     b.EndPoint.Value = p_end
b.MidPointOptions = AB.MidOption.Radius;    b.Radius.RightHandSide = "200"
b.SupportPlaneData.SupportPlane = plane;    b.ZonePoint = nxh.P(0, 150, 10)     # the side of the chord the CENTRE lies on
b.Limits.FullCircle = False                 # b.Limits.ComplementArc() swaps minor arc and complement
```
Chord 80, radius 200: the zone point above / below the chord puts the centre above / below; as
committed the arc is the COMPLEMENT (1176.094), with `Limits.ComplementArc()` the minor arc
(80.543 = 2 x 200 asin(40/200)). Always check the length.

Point Set ranges [cast ecva]: `StartPercentage` / `EndPercentage` 10 / 75 with 5 points on a 60 mm
line: x 6 .. 45 with the help point at one end, 15 .. 54 at the other (the range counts from the
section start). `b.CurvePointsBy = PS.CurvePointsType.GeometricProgression; b.Ratio.RightHandSide =
"1.5"`: gaps 7.385, 11.077, 16.615, 24.923 (each 1.5 x the last).

General Conic:
```python
GB = NXOpen.Features.GeneralConicBuilder
b = part.Features.CreateGeneralConicBuilder(NXOpen.Features.GeneralConic.Null)
b.Type = GB.Types.TwoPointsAnchorRho          # also FivePoints, FourPointsOneSlope, ThreePointsTwoSlopes, ThreePointsAnchor, TwoPointsTwoSlopesRho, Coefficients
b.StartPoint = p0; b.EndPoint = p1; b.AnchorPoint = apex; b.RhoValue = 0.5; b.AssociativeToggle = True
f = b.CommitFeature()                         # FeatureType "General Conic"
```
Ends (0,0), (60,0), anchor (30,40): the shoulder is at rho x 40 (12.0 / 20.0 / 30.0 for rho 0.3 /
0.5 / 0.75), the end tangents aim at the anchor, no inflection; the curve class is `Ellipse` /
`Parabola` / `Hyperbola`. `FivePoints` (`InteriorPoint1..3`) through five points of an ellipse 40 x
20 returns that ellipse exactly.

Isoparametric options: `b.Direction = IB.DirectionTypes.IsoU | IsoV | IsoUV`, `b.Number = 4`,
`b.Placement = IB.PlacementTypes.Uniform`: cylinder d30 x 40 -> IsoU 4 lines of 40, IsoV 4 circles
of 94.248, IsoUV both.

Isocline Curve [cast ecvd]:
```python
b = part.Features.FreeformCurveCollection.CreateIsoclineCurveBuilder(NXOpen.Features.IsoclineCurve.Null)
b.Face.ReplaceRules([R.CreateRuleFaceDumb(faces)], False)
b.ReferenceDirection = nxh.direction(part, (0, 0, 1))              # the pull direction
b.IsoclineTypes = NXOpen.Features.IsoclineCurveBuilder.CurveTypes.Single; b.IsoclineAngle.RightHandSide = "0"
# family: CurveTypes.Multiple + b.StartAngle / b.EndAngle / b.IntervalAngle
b.IsAssociative = True; f = b.Commit()                             # FeatureType ISOCLINE_CURVE
```
The angle is the DRAFT of the face to the direction (0 = face parallel to it = silhouette /
zero-draft / natural parting line). Lying cylinder d20 (axis X), direction +Z: angle 0 -> 2 lines
of 40 at the axis height, y -+10 (d 20 -> 30: y -+15, no error); 30 -> 2 lines 5.000 = r sin 30
above the axis, -30 below; family -60 .. 60 every 30 -> 10 lines. R8 blends on the top edges of a
block: 30 deg -> 4 curves at z 6.0, 60 deg -> z 8.928, the face normal is at that angle along the
whole curve (deviation 0.0). Negative angles = the undercut side. (`CreateShadowCurveBuilder` sits
on `CurveFeatureCollection`; not probed.)

Trim Curve with a bounding plane [cast ecve]:
```python
TB = NXOpen.Features.TrimCurve2Builder
b = part.Features.CreateTrimCurve2FeatureBuilder(NXOpen.Features.TrimCurve2.Null)
ck.fill(b.CurveToTrim, [R.CreateRuleCurveFeature([curve_feature])], pick, curve)
bo = b.CreateTrimCurveBoundingObjectBuilder()
bo.BoundingObjectMethodType = GU.TrimCurveBoundingObjectBuilder.Method.SelectPlane
bo.BoundingPlane = plane                       # NXOpen.Plane; a smart plane (SetMethod(Distance) from a datum plane) keeps it associative
b.BoundingObjectList.Append(bo)
b.OperationOption = TB.Operation.Trim; b.KeepOrDiscard = TB.KeepDiscard.Discard
b.UpdateTrimRegionsAndDivideLocations(); b.SelectTrimRegion(nxh.P(*point_ON_the_piece))
b.CurveOptions.Associative = True; f = b.CommitFeature()          # FeatureType TRIM_CURVE2
```
60 mm associative line cut at x 40, region picked at x 50: Discard -> 0..40 (40.0), Keep -> 40..60
(20.0); a spline feature is cut the same way; plane offset from the datum YZ plane by an
expression 40 -> 25: the trimmed line follows (25.0), no error. Region point 0.5 mm OFF the curve:
the feature is created and the curve is NOT trimmed (68.87 = the source length) - compare lengths.
Bounding OBJECTS through `bo.BoundingObjectList.Add(...)` (a datum plane, a point, a crossing
line): "Bounding objects are either suppressed or modeled away." in all three.

Unwrap (`curve_activities.py` A1) [cast ecvd]: the builder of section 34 with
`b.Type = WrapBuilder.Types.Unwrap` and the EDGES of the face in `b.Curves` (`CreateRuleEdgeDumb`).
R20 tube cut by a plane at 45 deg, tangent datum plane at x 20: the end circle unwraps into ONE
line of 125.6637 (= 2 pi r) in the plane; the cut edge into one spline of 152.81 spanning
u -62.83 .. 62.83 about the tangent line, z 30 .. 70 (amplitude 20.000 = r), 0.0004 from
z = h - r cos(u/r); cut height 50 -> 40: the layout moves down 10, no error; Wrap of the layout
(`CreateRuleCurveFeature([unwrap_feature])`) lands 0.0004 from the cut edge. FeatureType `UNWRAP`.

Combined Projection of two sketches (`curve_activities.py` A2) [cast ecvd]: `Curve1` / `Curve2`
filled with `CreateRuleCurveFeature([sketch.Feature])`, both directions `DT.CrvPlaneNormal`:
TOP_VIEW (arc R150 from the origin to (len, 0), DOF 5 -> 2 -> 0) x SIDE_VIEW (ramp to (len, 30)):
one `Ellipse` curve matching both views to 0.000000, parents = the two sketches; `len` 190.5 -> 200:
x extent 200, still on both views, no error.

Associative points (`curve_activities.py` A4) [cast ecvb]: a diagonal across the top of a block,
once on points riding on the vertical EDGES (`ck.on_curve(part, edge, 100)`, parent = `Block`),
once on typed coordinates (no parent). Block width 40 -> 25: the first still ends on the corner,
the second is 15.0 mm off - and nothing reports it.

## 49. Offset Datum CSYS - VERIFIED (`sketch_rules.py` K2) [cast efmb]

```python
def offset_csys(part, base_csys, origin, rx, ry, rz, name=None):
    def ang(v):                                                     # number or expression name, degrees
        e = part.Expressions.CreateSystemExpressionWithUnits(str(v), nxh.units(part)["deg"])
        return part.Scalars.CreateScalarExpression(e, NXOpen.Scalar.DimensionalityType.Angle, UPD)
    xf = part.Xforms.CreateXformEulerTaitBryanAngles(base_csys, origin, NXOpen.XformCollection.RotationSequence.XYZ,
                                                     ang(rx), ang(ry), ang(rz), 1.0, UPD)
    b = part.Features.CreateDatumCsysBuilder(NF)
    try:
        b.Csys = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD); b.DisplayScaleFactor = 1.25
        f = b.CommitFeature()
    finally:
        b.Destroy()
    if name: f.SetName(name)
    return f

base = [e for e in nxh.Datums(part).csys.GetEntities() if isinstance(e, NXOpen.CartesianCoordinateSystem)][0]
f = offset_csys(part, base, nxh.point(part, "k2_x", 60, 10), 0, "k2_ry", "k2_rz", name="CS_PORT")
child_origin = part.Points.CreatePoint(csys_of(f), sx, sy, sz, UPD)      # scalars = coordinates IN the parent CSYS
```
One `DATUM_CSYS` feature. (150, 60, 10), Ry 45, Rz -35: origin exact; axes X (0.57923, -0.57358,
-0.57923), Y (0.40558, 0.81915, -0.40558), Z (0.70711, 0, 0.70711) = rotations about X, then the
NEW Y, then the NEW Z (intrinsic X-Y-Z, deviation 4e-6; the extrinsic reading is 0.41 off).
Expressions edited (x 180, Ry 30): follows. Child CSYS at (0, 0, 20) of the parent with Rz 90:
origin = parent origin + 20 x parent Z (1e-4), child X = parent Y; parent Rz -35 -> -50: the child
turns with it. A circle sketched on `"<JournalIdentifier> XY plane"` with `"X axis"` as horizontal
reference and `f.FindObject("POINT 1")` as origin (DOF 0), extruded along
`Directions.CreateDirection(xy_plane, Sense.Forward, UPD)`: cylinder axis = the CSYS Z axis at
Ry 30 and at Ry 60, volume pi 36 x 15 both times. `RotationSequence` has 12 members (XYZ ... ZYZ).

## 50. Sketch rules measured - VERIFIED (`sketch_rules.py`, 37 checks) [cast eska, eskb, eesc, efmb]

Internal / external (K1; the same was measured by the solid-features package):

| State | `sketch.IsInternal` | Row in the tree | Children of the sketch |
|---|---|---|---|
| from `nxf.new_sketch` | False | `K1_PROFILE:Sketch(1)` | Extrude |
| after `extrude.MakeSketchInternal()` | True | none (inside the Extrude) | Extrude |
| second feature built while internal | True | none | 2 - commits, volume right |
| after `MakeSketchExternal()` on the owner | False | before both features | 2 |
| `MakeSketchInternal()` with 2 children | False | - | "Parent sketch is referenced by other objects." |

Order (K3): block 60 wide, sketch on the top face with the right edge projected in, hole 8 from
it (DOF 3 -> 0), Extrude-Subtract; then `nxf.offset_region(part, [right_face], 5)`:
hole x 52, face x 65, edge distance 13, `feature_errors` {} and no sketch warning.
`nxh.reorder(part, [offset_feature], block_feature, after=True)`: hole x 57, distance 8, sketch
still DOF 0. (Not the same as section 36: there the parent edge disappears; here it only moves.)

Make Symmetric / Mirror Curve (K4), real DOF with auto dimensioning off:

| Step | Curves | DOF |
|---|---|---|
| two free lines | 2 | 8 |
| Make Symmetric about the datum Y axis | 2 | 4 (one `Mirror` constraint) |
| one more free line | 3 | +4 |
| Mirror Curve of it | 4 | +0 (one `Pattern` constraint; `CreateConstraint` False made no difference) |

Roles: with Primary = right line and with Primary = left line the RIGHT line (the first one
created) moved both times. With the right line's two end points fixed first
(`CreateFixedConstraint(cg(line, CP.StartVertex))` and `EndVertex`, DOF -4) the left line moved onto
(-10, y)-(-20, y + 20) in either role. `CreateFixedConstraint(cg(line))` on the line alone takes 2
of its 4 freedoms and both lines moved.

A dimension that becomes 0 (K5): H/V notch profile, DOF 6 -> 1 -> 0. Notch depth by
`PerpendicularDim` (line -> point of the lower line): 5 -> 0 -> 9 -> 5 gives 7000 / 8000 / 6200 /
7000 mm3, no error, sketch DOF 0 throughout. Notch depth by `ParallelDim` of the riser line
(its length): the same four results - the zero-length line is solved on NX 2206.

One sketch, several features (K6): rectangle centred on a smart point (`nxf.sketch_rect_centered`,
DOF 0) + Sketch Offset `"-k6_edge"` (inward, DOF still 0) converted to reference
(`nxf.to_reference`) + 4 sketch points (DOF 8) made coincident with the loop corners
(`cg(point)` / `cg(line, CP.StartVertex)`, DOF 0). `nxh.section_region(part, sk, centre,
curves=outline)` -> Extrude 210 x 125 x 20 exactly; `nxf.hole(part, body, sketch_points, 9,
vector=(0, 0, 1))` -> 4 holes 14.0 from both edges; the sketch has 2 children. Outline 250 and
edge distance 20: holes 20.0 from both edges, no error. Trap: a second sketch with an ACTIVE inner
loop extruded with `nxh.section_feature` (whole sketch): 5000 = (40 x 30 - 20 x 10) x 5, no error;
after `nxf.to_reference` of the inner loop the same Extrude regenerates to 6000.

Constrained Sketch On Path (K7) - the section for Swept, Variational Sweep, Sweep Along Guide:
```python
nxf.auto_dimensioning_off()                                        # BEFORE the builder
sb = part.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
nxh.fill_section(part, sb.Section, help_point=path_start, seed=path, rules=[R.CreateRuleCurveFeature([path_feature])])
sb.PlaneLocation.Path.Value = path; sb.PlaneLocation.IsPercentUsed = True
sb.PlaneLocation.Expression.RightHandSide = "sec_pct"              # % arc length, an expression name
sk = sb.Commit(); sb.Destroy(); sk.Activate(SK.ViewReorient.FalseValue)
ib = part.Sketches.CreateIntersectionPointBuilder(NXOpen.SketchIntersectionPoint.Null)   # where the path pierces the plane
ck.fill(ib.Rail, [R.CreateRuleCurveFeature([path_feature])], path_start, path); ib.UpdateData(); ib.Commit(); ib.Destroy()
ipt = [g for g in sk.GetAllGeometry() if isinstance(g, NXOpen.Point)][0]                 # DOF still 0
u0, v0 = nxf._sketch_uv(sk, ipt)
rect = nxf.hv_polygon(part, sk, [(u0 - 4, v0 - 2.5), (u0 + 4, v0 - 2.5), (u0 + 4, v0 + 2.5), (u0 - 4, v0 + 2.5)])   # DOF 4
sk.CreateMidpointConstraint(nxf.cg(ipt), nxf.cg(rect[0])); sk.CreateMidpointConstraint(nxf.cg(ipt), nxf.cg(rect[1]))   # DOF 2
for ln, name in ((rect[0], "sec_w"), (rect[1], "sec_h")):                                # two driving dimensions: DOF 0
    c = sk.CreateDimension(SK.ConstraintType.ParallelDim, nxf.dg(ln, A.StartPoint), nxf.dg(ln, A.EndPoint), text_origin, NXOpen.Expression.Null)
    c.AssociatedExpression.RightHandSide = name
st = nxf.finish_sketch(sk)                                         # WellConstrained, dof 0, auto_dims 0
```
Tree: `DATUM_ON_PATH` (a point, datum axes, a datum plane) + `SKETCH`. Path = associative R50
quarter arc. At 30 %: sketch origin and rectangle centre on the path point (0.000), sketch normal =
path tangent (0.000 deg), sides 8 and 5. `sec_pct` 30 -> 70 -> 0: the same at each position,
`("WellConstrained", 0)` after each update, no feature error. `nxf.sweep_along_guide` of the
rectangle along the path: 3141.593 = 8 x 5 x (pi/2 x 50); `sec_w` 8 -> 12: 4712.389.
`nxf.sketch_rect_centered` / `nxf.pdim(..., centre, None, ...)` cannot be used with a SKETCH point
as centre (the dimension to a sketch point needs `AssocType.StartPoint`); the Midpoint route above
needs no dimension to the point at all.

How Siemens' own sketching-course parts are constrained (read-only pass over the 34 `skt*` parts,
63 sketches, NX 8.5 solver, nothing saved): `GetStatus()` says WellConstrained for 32, DOF 0 for 34;
10 of those 32 hold AUTOMATIC dimensions (26 in total, `DimensionState` Automatic) - really fully
constrained with driving dimensions only: 24 of 63 (38 %), and only 6 of 33 parts have every sketch
that way. 15 sketches have no dimension; 7 are internal; children: none 15, one 38, two or more 10;
`Mirror` constraints 0, `Pattern` 5; dimension kinds: perpendicular 60, horizontal 35, parallel 31,
radius 24, vertical 24, angular 16, diameter 8; 16 of 172 dimensions carry a formula. They are
start states of constraint exercises - not a model of a finished sketch.
