# User practice - sketches, datums and curve features

Source: 691 mined parts under `H:\My Drive\111 UP UP UP\`, of which 38 are agent-built and
excluded -> **653 user parts**. Numbers come from the raw dumps (`deep0|1|2\*.json`, lists
`features` and `sketches`) and `extracts\by_class\*.jsonl`. "Builder read-back" rows exist only
for part of the instances, so rule histograms are counts of read-back rows, not of all features.

## 1. Sketches (2337 sketches in 433 parts)

**How many**: median 3 sketches per part (mean 5.4, max 47). Parts containing an imported body
(`Brep`): 229 parts, median 5; parts without: 204 parts, median 2.

**Constraint status**

| | Well constrained | Under | Over | Inconsistent | Not evaluated |
|---|---|---|---|---|---|
| all 2337 | 811 (35 %) | 1400 (60 %) | 39 | 71 | 16 |
| parts with an imported body (1776) | 489 (28 %) | 1186 (67 %) | 25 | 60 | 16 |
| parts without (561) | 322 (57 %) | 214 (38 %) | 14 | 11 | 0 |

49 parts with three or more sketches have every sketch well constrained (examples:
`ARCHIVED\Retro Console - Enis E\NX Files _ ikbal\Assembly-Console.prt` 16 sketches,
`ARCHIVED\PLDR\Assembly_Final.prt` 10, `ARCHIVED\PLDR\Shell_V2.prt` 9,
`POOL TIME Mark Toth\Milestones\1 - ...\HUMAN\Board.prt` 7, `ARCHIVED\Haptic_Ring\CAD\Ring_2.prt` 7).

**Dimensions**: 2088 driving dimensions in total. 1652 sketches (71 %) have none, 218 have one,
197 two, 84 three, 73 four; only 113 have five or more. 306 dimension expressions are renamed
(`HATA_1..7`, `RADYUS_1`, `TOPLAM_UZUNLUK`, `IC_CAP`, `DIS_CAP`, `D1_CAP`, `OVERALL_LENGTH`,
`BODY_HEIGHT`, `KAMA_GENISLIK` ...) and 57 are formulas of other expressions (`p7=Carr_Ring`,
`p5=Carr_W`, `p1=IB_OD`, `p77=magnet_L`, `HATA_2=HATA_1*3`, `p64=p63/2`,
`DELIK_ARALIGI=UST_DAYAMA_MESAFESI*140/180`). Typical dimension kinds in the feature expressions:
diameter on arc, parallel / perpendicular distance between lines or line and point, and
`Offset Constraint` values (1, 85, -90, -1.3, 0.5, 1.3, 2).

**Geometry**: lines 16 903, arcs 7 171, splines 4 262, ellipses 91, points 33 193 (mostly the
end / centre points NX counts as geometry).

**Relations** (number of sketches using the relation / total instances):
Coincident 970 / 6129, Horizontal 562 / 1150, Point on curve 432 / 1793, Vertical 355 / 949,
Perpendicular 334 / 1539, Tangent 286 / 1179, Fixed 261 / 37 923, type "45" 248 / 427 (an NX 2206
relation the Python enum does not name), Offset 176 / 340, Pattern 156 / 288, Parallel 40,
Normal 36, Collinear 31, Concentric 28, Equal radius 27, Midpoint 24, Recipe trim 11.
The huge Fixed count sits in 261 sketches: projected / pasted / imported geometry that NX pins,
not hand-applied fixes.

**Names**: 2280 sketches keep the default `SKETCH_nnn`; the remaining 57 are NX-generated variants
(`SKETCH_TOP1_000`, `SKETCH_009_0`). The user does not name sketches.

**Placement** (2313 sketch features; category from the parents of the sketch's own Datum CSYS):

| Placement | Count | Well constrained | Mean dims |
|---|---|---|---|
| own CSYS on a face / edge of a body modelled earlier (Extrude, Thicken, Blend, Shell ...) | 1124 | 367 (33 %) | 0.40 |
| own CSYS on a plane of the base Datum CSYS | 549 | 197 (36 %) | 1.85 |
| own CSYS on a face of an imported body | 357 | 174 (49 %) | 0.70 |
| own CSYS on a datum plane feature | 171 | 46 (27 %) | 1.00 |
| own CSYS with no parent (absolute) | 86 | 18 | 2.05 |
| sketch on path (`DATUM_ON_PATH`) | 25 | 4 | 0.4 |

2143 of 2313 sketches are directly preceded by a `DATUM_CSYS` feature (the sketch's own); 119 by a
`CPROJ` (edges projected into the sketch), 25 by `DATUM_ON_PATH`, 15 by an associative
intersection. Parents besides the CSYS: none 1479, Extrude 199, another sketch 117, Thicken 68,
Brep 68.

**Consumers** (first later feature that has the sketch as a parent): Extrude 1587 (68 %),
none 282 (12 %), Sweep `SWP104` 117, Hole 48, Rib 42, Project Curve 40, `SKIN` 38 (the type string of
Bounded Plane, Ruled and Swept - NOT Through Curves, which is `THRU_CURVE`; the earlier label was wrong),
another sketch 34, Datum Plane 19. Children per sketch: one 1574, none 282, two 254, three or more 203.

## 2. How the user's features pick curves (builder read-back)

Extrude sections (1540 rows): `RegionBoundary` 886 (58 %), `CurveDumb` 194, `CurveFeature` 143,
`CurveFeatureChain` 111, `EdgeDumb` 96, `CurveFeatureTangent` 38, `EdgeBoundary` 30,
`EdgeTangent` 28, mixed 10. One rule group in 1163 sections, 2-8 groups in 323 (several regions
picked one by one), 12 groups in 24.

Other classes: Revolve `RegionBoundary` 49, `CurveFeatureChain` 12, `CurveDumb` 7, `CurveFeature` 5.
Tube path `CurveFeatureTangent` 53 (+8 multi), `EdgeTangent` 44. Rib `CurveFeature` 20, `CurveDumb`
19. Bounded plane `EdgeChain` 168, `CurveFeatureChain` 22. Sweep along guide `EdgeDumb` 14x4,
`CurveFeature` 10, `RegionBoundary` 5. Hole positions `CurveDumb` 279 (sketch points),
`FeaturePoints` 41. Project Curve input `CurveFeatureTangent` 36, `EdgeTangent` 31, `EdgeDumb` 29,
`CurveFeature` 29, `CurveDumb` 22. Offset Curve input `CurveFeatureTangent` 7, `CurveFeature` 3,
`EdgeTangent` 2. Curve Length `CurveDumb` 8. Composite Curve `EdgeTangent` 12, `EdgeDumb` 4.

Totals across all classes for curve / edge rules: EdgeDumb 822, CurveDumb 783, EdgeTangent 691,
EdgeChain 237, CurveFeatureTangent 209, CurveFeature 105, RegionBoundary 54 outside Extrude,
CurveFeatureChain 46.

## 3. Datums

- **Datum CSYS**: 2854 in 522 parts - almost all are the per-sketch CSYS (next feature SKETCH
  2143). Only 13 carry expressions (plane offset, X/Y/Z, location between points).
- **Datum planes**: 645 in 199 parts (633 `DATUM_PLANE`, 12 fixed `ABSOLUTE_DATUM_PLANE`), 21 with
  errors. Expressions: `Offset` 366 - value **0 in 166**, then 10, 1, -2, 16, 80, 150, 24;
  no expression 223 (coincident, through geometry, bisector, tangent); `Angle` 17 (90 x7, -29,
  25, 135, ...); `Curve parameter` 4.
  Parents: base Datum CSYS 174, imported body 76, Fit Surface (plane fitted to a scan) 54,
  Extrude 32, another datum plane 28, Shell 22, Cylinder 21, Extract Face 19, Sketch 17,
  Through Curves 13, Helix 6.
  Next feature: Datum CSYS (= a sketch on that plane) 238, another datum plane 92, Divide Face 58,
  Trim Body 56, Replace Face 44, Split Body 24, Trim Curve 13, Section Curves 8.
- **Datum axis features**: 1 in all parts (a fixed axis). Axes are taken from Datum CSYS features.
- **Point features**: 88 in 33 parts, usually in runs (`POINT` -> `POINT` 37): on-curve parameter
  (50, 7.5, 60), explicit X/Y/Z, between two points 0.5. Consumers: Project Curve 26, associative
  Line 16, Hole 12, Arc 7, Spline 3.
- **Sketch on path** (`DatumFeature` / `DATUM_ON_PATH`): 25, always `LINKED_CURVE` or
  `EXTRACT_STRING` -> `DATUM_ON_PATH` -> `SKETCH`; arc length 13 at 100 % in 21 of them.
- WAVE datum 14 (12 from another part, non-associative).

## 4. Curve features (instances / parts)

| Class (tree type) | Count | Typical settings | First consumer |
|---|---|---|---|
| ProjectCurve (`CPROJ`) | 287 / 105 | along face normal 179, along vector 68 (Y 31, Z 13, X 6), toward line 1; onto faces 69, onto a plane 24; input retained, associative; both sides 39 | Extrude 105, none 72, Law Extension 18, Sweep 12, Hole 10 |
| AOCS (`OFFSET_IN_FACE`) | 205 / 76 | value offset 193 (1 x26, 2 x22, 1.5 x11, 0.5 x10, 0.1, 0.7, 4, 0.2; 10 negative), one face (`FaceDumb`) 165, planar / cylindrical / freeform, trim + extend within section, no fillet | Divide Face 143, Extrude 20, Through Curves 12 |
| CompositeCurve (`EXTRACTED_CURVE` / `LINKED_CURVE`) | 94 / 53 | 72 linked from another part (not associative, fixed at timestamp); 20 in the work part, associative, `EdgeTangent` | Extrude 24, Project 22, Datum on path 21, Sketch 12 |
| AssociativeLine (`LINE`) | 83 / 29 | ends on curves (parameter 100 / 0 / 50), lengths by limit | Line 16, Extrude 11, Sweep 8, Through Curves 6, Divide Face 6 |
| TrimCurve2 | 45 / 14 | in runs after intersection curves and datum planes | Sweep 11 |
| IntersectionCurve | 35 / 13 | first set = whole body (`FaceBody` 34; 33 convergent scan bodies), second = plane at X / Y offsets (7, 5, 38, 39.6, 36.5) | Trim Curve 14, none 16 |
| StudioSpline (`SPLINE`) | 31 / 27 | through points 31, degree 5, 2 points (28), points on curves / faces (U parameter 1 and 0), end directions set in ~6 | Trimmed Sheet 18, Trim Curve 4 |
| AssociativeArc (`ARC`) | 31 / 18 | three points on curves, or centre + radius (0.4, 0.6, 47/2), limit angles 282 / 360 | Project 9, Sweep 7 |
| SectionCurve | 30 / 11 | type Selected, 1-3 faces or a body, plane normals X / Y / Z or a datum plane | Sweep 5, Curve on Surface 4, Extrude 4 |
| BridgeCurve | 30 / 12 | G1 both ends, tangent magnitude 1 (0.6, 1.2), start / end location 0 % | Studio Surface 14 |
| Helix | 17 / 15 | diameter constant (6, 30, 9, 18), pitch constant (1, 10, 2, 0.8), length by limits 16 (end 6, 5, 4.2), by turns 1 | Sweep 10, Datum Plane 7 |
| OffsetCurve | 13 / 11 | distance 1 x8, 0.5 x4, 0.7; reverse direction 6 of 13; input blanked | Sweep 3, Through Curves 2, Extrude 2 |
| Text | 10 / 8 | planar, Arial Regular, anchor bottom centre, height 1.2-10.8, length 8.7-88; "KAUST", "TENDA Router", "UGREEN", "PowerBank" | Extrude 10 |
| CurveLength | 8 / 7 | incremental, start 0.35 / end 0.65 typical; after Offset in Face | Sweep 5, Extrude 3 |
| Others | CurveOnSurface 27 / 6, FitCurve 13 / 10, IsoparametricCurves 10 / 4, IsoclineCurve 9 / 6, CombinedProjection 8 / 3, LawCurve 3 / 1, ShadowCurve 3 / 2, MirrorCurve 2 / 2, SketchIntersectionPoint 29 / 6, SketchIntersectionCurve 13 / 6 | | |

## 5. Representative trees

1. `ARCHIVED\PLDR\camera_adjusting_plate.prt` - clean prismatic part.
   `DATUM_CSYS > CYLINDER > DATUM_CSYS > CPROJ > SKETCH > EXTRUDEx2 > DATUM_CSYS > SKETCH > EXTRUDE > UNITE > POINTx6 > HOLE PACKAGE > SIMPLE HOLEx2`
   Reading: sketch on the cylinder's face with its edge projected in, extruded twice; hole centres
   are six Point features, not a sketch.
2. `ARCHIVED\PLDR\Shell_V2.prt` - clean freeform housing, 9 sketches, all well constrained.
   `DATUM_CSYS > DATUM_PLANEx2 > DATUM_CSYS > SKETCH > DATUM_CSYS > SKETCH > SKINx2 > EXTRUDE > THRU_CURVE > UNITE > BLEND > DATUM_CSYS > CPROJ > SKETCH > THRU_CURVE > ...`
   Reading: offset datum planes first, one section sketch per plane, lofted through the sketches.
3. `ARCHIVED\NFC ENCLOSURE\May-23 Delivery\Button_Cap.prt` - imported-body rework.
   `DATUM_CSYS > BREP > MOVE_FACE > OFFSET_IN_FACE > DIVIDE_FACE > OFFSET_REGION`
   Reading: offset a face boundary inside the face, split the face with it, then push the new
   region - a local step without any sketch. The pattern repeats 143 times.
4. `REMAKE AI - DIY\A8S previous project\CAD DATA\H- Hardware - Fasteners & Springs\A8S-H03\A8S-H03.prt` - spring.
   `DATUM_CSYS > HELIX > SWP104 > BREPx4 > MOVE_OBJECT`
   Reading: helix at the origin, a profile swept along it, the body moved into place afterwards
   (consistent with the helix always sitting on the absolute Z axis).
5. `ARCHIVED\PLDR\Tenda MF6 4G SIM Router.prt` - marking.
   `DATUM_CSYS > BLOCK > BLEND > TEXT > EXTRUDE > TEXT > EXTRUDE`
   Reading: planar Text feature, extruded straight away; one text per extrude.
6. `ARCHIVED\NFC ENCLOSURE\NX - Copy\assembly - Copy - Copy.prt` - sweep profile on a path.
   `... > BREPx5 > LINKED_CURVE > EXTRUDE > BREP > DATUM_ON_PATH > SKETCH`
   Reading: an edge loop is WAVE-linked as a composite curve, a sketch-on-path carries the gasket /
   lip profile at 100 % of the path.
7. `Watch - Indsutrial Design\...\AP-Saat\export\Trace_obj.prt` - scan tracing.
   `BREPx14 > DATUM_CSYS > DATUM_PLANE > INTERSECTION_CURVES`
   Reading: an offset datum plane cuts the convergent scan body; the intersection curves are the
   traced profile (followed elsewhere by Trim Curve and offset curves).

## 6. What to copy, what not

- Copy: sketch on the face being modified with projected edges; one sketch per feature;
  `RegionBoundary` for multi-loop sketches; named dimension expressions with formulas; datum plane
  at offset 0 on a face as a cut / sketch reference; Offset in Face -> Divide Face for local
  regions; Text -> Extrude for marking; Helix -> Sweep, then move.
- Do not copy: leaving sketches under-constrained (60 %) or without dimensions (71 %) - that is
  the interactive shortcut on reverse-engineered bodies, where the profile is dragged to fit; a
  journal has the numbers and must dimension them.
