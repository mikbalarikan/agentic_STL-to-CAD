---
name: nx-curves-and-sketches
description: Build the wireframe that drives NX solids and surfaces from an NXOpen Python journal on NX 2206 - fully constrained sketches on datum planes, body faces or a path, datum planes / axes / CSYS (offset CSYS, angled plane for inclined ports), associative curve features (line, arc, studio spline, fit, bridge, join, project, combined projection, intersection, section, isoparametric, isocline, curve on surface, offset, offset in face, composite, mirror, trim, curve length, wrap / unwrap, helix, conic, text, law curve by equation - involute gear teeth, cams) and the Section / selection-intent rules every downstream feature needs. Use when a journal must create or edit a sketch, a datum, a guide/profile curve, a fair spline (type, degree, how to judge it), a gear tooth or other equation-driven profile, part-marking text, or must pick which curves of a sketch a feature consumes (RegionBoundary, CurveFeature, chains), and when checking that a sketch is DOF 0, a profile is closed or an offset reaches the face boundary.
---

# NX curves, sketches and datums (NXOpen Python, NX 2206 headless)

> Data-set note: `[mined]` counts in this skill come from the first extraction (691 part dumps = 653 user files, a few of them repeated session snapshots of the same part). De-duplicated totals for the 639 distinct user parts are in `nx-modeling-strategy/references/user-practice-overview.md`; rankings and proportions agree, absolute counts differ.

Evidence tags: `[verified]` = created and measured by the journals in `scripts/` on NX 2206
(`nx-journal-core/scripts/run_journal.ps1 -Script <script> -WorkDir <out> -JArgs <out>`; PASS counts
18 / 17 / 21 / 18 / 20, `inclined_port.py` 36, `law_curve_gear.py` 37, and the CAST round:
`spline_rules.py` 39, `offset_checks.py` 27, `cast_curve_checks.py` 49, `sketch_rules.py` 37,
`curve_activities.py` 12, `curvekit.py` 8);
`[mined]` = the user's 653 own parts; `[course CADx.y hh:mm]` = the user's NX training course;
`[community]` = a collection of third-party NX parts (author count given; never a rule by itself);
`[cast <course>]` = Siemens' NX CAST 8.5 training library (2012; rule in own words, re-measured on
NX 2206 before it was written here - where NX 2206 behaves differently it says so).
- Code, measured numbers, failure messages: [references/nxopen-recipes.md](references/nxopen-recipes.md)
- User statistics and tree excerpts: [references/user-practice.md](references/user-practice.md)
- Course tool cards with timestamps, 2212-vs-2206 notes: [references/course-notes.md](references/course-notes.md)
- **Curve measuring and spline helpers**: `scripts/curvekit.py` (`import curvekit as ck` from a journal in
  that folder): `ck.curve_quality` (inflections, curvature peaks, min radius), `ck.frame`, `ck.max_dev`,
  `ck.join_angle`, `ck.studio_spline`, `ck.fit_spline`, `ck.spline_data`, `ck.on_curve`.
- **Helpers**: the sketch and datum helpers shown here are available verified as `nxf.<name>`
  (`new_sketch`, `cg`, `dg`, `help_at`, `add`, `horizontal`, `vertical`, `pdim`, `diameter_dim`,
  `radius_dim`, `hv_polygon`, `sketch_status`, `finish_sketch`, `auto_dimensioning_off`,
  `auto_dimensions`, `datum_plane`, `datum_axis`) and the
  section builders as `nxh.section`, `nxh.section_region`, `nxh.section_feature`, `nxh.fill_section` -
  import them (`nx-journal-core/references/nxf-helpers.md`), do not copy code out of the recipes.

## 1. Pick the right kind of wireframe

| Need | Use | Editability |
|---|---|---|
| Planar profile for extrude / revolve / rib / hole positions | **Sketch**, DOF 0, dimensions = expression formulas [verified] | edited in the sketcher; tree reads like the user's own |
| Profile that must follow existing geometry | Sketch on the face or plane + **Project Curve** of the edges into it; dimension from the projected curve [verified] [course CAD2.3 00:46] | follows the body |
| Section of a sweep | **Sketch On Path** at 0 % arc length, normal to path [verified] [course CAD2.1 00:09] | follows the path |
| A few 3D lines / arcs between known points | Associative Line / Arc on smart points; arcs need a support plane [verified] | expressions drive the points |
| Closed loft / sweep section at a parametric height | `assoc_circle` / `assoc_rounded_rect` (associative features) in ONE `CurveFeature` rule [verified] | regenerates with z, sizes |
| Spline whose points the user edits in a sketch | sketch of dimensioned points + Studio Spline feature through those points [verified] | sketch dimensions |
| Free 3D path, trim boundary | Studio Spline feature; points may ride on existing curves [verified] [mined: 28 of 31] | on-curve parameter |
| Curve through EXACT locations / a fair styling curve / measured points | Studio Spline Through Points / By Poles (few poles, one segment) / Fit Curve - decision table in section 6a [verified] [cast ecvc] | points or poles |
| Conic with a known fullness (duct, fairing, blend section) | General Conic: two ends + anchor + rho [verified] | anchor point, rho |
| Parting / zero-draft line, map of the draft on a face | Isocline Curve, angle 0 = silhouette to the pull direction [verified] [cast ecvd] | follows the faces |
| Flat layout of a curve on a cylinder / cone (mitred tube end) | Unwrap to the tangent datum plane [verified] [cast ecvd] | follows the cut |
| Helix-like curve on a cylinder / cone from a flat layout | Wrap Curve from the tangent datum plane [verified] [course CAD5.3 00:05] | the planar curve is the master |
| Repeated sketch geometry | circular: sketch Pattern [verified]; linear: draw the instances with formula dimensions, or pattern the feature (`nxf.pattern_linear`) - the linear sketch pattern does not commit headless | dimensions / pattern count |
| Shorten or extend a curve | Curve Length (negative increment shortens); cut it AT something: Trim Curve with a bounding PLANE (smart plane = associative) - bounding curves / points / datum objects do not commit headless [verified] | increments / the plane |
| Smooth link between two curve ends | Bridge Curve, G1 or G2 per end [verified] [course CAD5.1 00:04] | associative |
| Curve that must lie ON a face | Project, Intersection, Section, Isoparametric, Offset in Face, **Curve on Surface** [verified] | associative to the faces |
| 3D curve known from a top view and a side view | Combined Projection [verified] [course CAD5.2 00:44] | follows both curves |
| Several curves that must sweep ONE face | Composite Curve (or Join Curves) with Join = General - exact and the lightest; Cubic / Quintic only when a plain polynomial is required [verified] [course CAD5.1 00:12] [cast ecvc] | associative copy |
| Spring / thread path | Helix (always along absolute +Z from the origin) [verified] | turns / pitch / diameter expressions |
| Profile given by an equation (involute gear flank, cam, spiral) | **Law Curve by equation** over the parameter expression `t` [verified, section 6] | the named expressions (module, teeth, pressure angle ...) |
| Part marking | Text feature, then Extrude with a `CurveFeature` rule [verified] [mined: 10 of 10] | text and frame are parameters |
| Throw-away tool profile | dumb `part.Curves.CreateLine/CreateArc` + `CurveDumb` [verified] | **none** - not in the tree, frozen coordinates |

- Dumb curves are Claude's old habit, not the user's: of 1540 read-back extrudes 194 (13 %) use
  `CurveDumb`, 886 (58 %) pick a sketch region [mined]. Default to a sketch.
- Dumb curves are not Siemens' way either: the course text itself says a few associative lines /
  arcs tied to earlier geometry, a sketch for any real profile [cast ecvb] - the dumb wireframe in
  half of its curve parts is lesson scaffolding. And "associative" only helps when the points ride
  on geometry: a line on edge points followed a block resize, the same line on typed coordinates
  stayed 15 mm off with no error [verified, `curve_activities.py` A4].
- "Projection is three answers: what, onto what, along which direction" [course CAD5.2 00:41] -
  set all three explicitly; Along Vector and Along Face Normal give different curves.
- **Only a projection onto a plane square to the direction is exact** (an arc stays an Arc); onto a
  tilted plane or any curved face the result is a spline within the tolerance. When the result must
  stay a line / arc (sketch dimension, hole centre, drawing) project onto a datum plane
  [verified] [cast ecvd]. A projection onto a FACE is cut at the boundary and at holes (80 mm line
  over a d10 hole: 2 curves, 50 in total) and, along a vector onto a closed face, lands on the near
  AND the far side: always read the curve count and the total length.
- A spline through points that lie on a face leaves the face between them (0.34 mm on an R15
  cylinder); Curve on Surface stays on it (0.000) [verified] [course CAD5.2 00:25].
- When a face has no usable edge, make the reference with Isoparametric or Section Curve
  [course CAD5.2 00:55]. Never place 3D curve points in empty space: build them from smart points
  on real references (the journal equivalent of the Support Plane rule) [course CAD5.1 00:20].
- Datum Axis features: do not create one where an axis of a Datum CSYS already is the line you
  need (the user: 1 in 653 parts [mined]). Create one when the line is NOT a CSYS axis: the hinge
  of an inclined port or boss, the axis of a pattern on an inclined or offset feature, a draft or
  sketch reference through a boss [community: 2 authors, opened parts] [verified,
  `scripts/inclined_port.py`] - section 5.

## 2. Sketch method

Where and how to place it
- Keep sketch X = model X: pass the datum CSYS X axis (or an edge along X) as horizontal reference
  [course CAD2.1 00:06]. All verified sketches do this.
- If the sketch location may change, create a Datum Plane there (offset 0 on the face is fine) and
  sketch on the plane; a sketch placed directly on a face leaves nothing to re-reference
  [course CAD2.1 00:12]. The user does both: 64 % of sketches sit straight on a body face, and 166
  datum planes are offset 0 on a face [mined]. Rule: face when the sketch belongs to that face for
  good (local cut, boss), datum plane when the level is a design parameter.
- Choose the origin deliberately: interactively it snaps to the nearest face corner; use a
  Between-Two-Points centre for a centred sketch [course CAD2.1 00:04]. In a journal pass the
  origin point explicitly (`dat.origin` or a smart point); measured origin on a z = 10 face:
  (0, 0, 10) [verified].
- No face in the right place: Bisector / At Distance datum plane first [course CAD2.3 00:39].
- Every user sketch has its own Datum CSYS right before it (2143 of 2313) [mined];
  `SimpleSketchInPlaceBuilder` produces exactly that `DATUM_CSYS` + `SKETCH` pair [verified].
- One sketch feeds one feature (1574 of 2313 have one child); first consumer Extrude 68 % [mined].
  Siemens: one sketch per FUNCTIONAL ELEMENT - outline, a reference offset loop and the hole points
  may share a sketch and each feature picks its curves by rule (10 of 63 sketches of the sketching
  course feed two or more features) [cast eska]. Measured: outline + reference loop + 4 points,
  DOF 0; Extrude by region + Hole on the points; outline and edge distance changed, holes still at
  the edge distance [verified, `sketch_rules.py` K6]. Construction curves must be REFERENCE curves:
  a feature whose section is the whole sketch turns an active inner loop into a window (5000
  instead of 6000 mm3, no error).
- Position from the Datum CSYS and named datum planes, never from the WCS (a journal never moves the
  WCS): base sketch on a plane of the Datum CSYS, interface / centre-line planes created and NAMED
  before the first sketch, a feature at a compound angle on ONE Offset Datum CSYS (section 5)
  [cast eesc, efmb]. For the user's own parts the user's habit stays (sketch + own CSYS on the face).
- **Internal or external**: a sketch from `nxf.new_sketch` is external (own row in the tree).
  `feature.MakeSketchInternal()` (`nxf.sketch_internal`) hides it inside its feature;
  `sketch.IsInternal` tells which; `MakeSketchExternal()` on the owner brings it back. Siemens' rule:
  internal only while ONE feature uses it - make it external before a second feature needs it
  [cast eska]. In a journal that is readability, not a limit: a second feature commits on an
  internal sketch (the sketch then sits hidden in the first feature with two children); the reverse
  is refused - "Parent sketch is referenced by other objects." [verified, `sketch_rules.py` K1].
- **A sketch does not follow features that come AFTER it.** Hole 8 from a projected edge; a later
  Offset Region moved that face 5: hole still at 52, now 13 from the edge, no error, no warning.
  Reordered before the sketch (`nxh.reorder`): 57, 8 from the edge again [verified, K3] [cast efmb].
  Create (or reorder) a sketch after every feature that shapes what it references.

Constraining
- Reach fully defined before making the solid, and judge by status, not colour
  [course CAD2.4 00:30]. API: `nxf.finish_sketch(sk)` (or `sk.Update()` + `nxf.sketch_status(sk)`)
  must give `WellConstrained`, DOF 0, `auto_dims` 0 [verified]. A bare `sk.GetStatus()` is **not**
  that check: in a sketch created while Continuous Auto Dimensioning is on - the state every batch
  session starts in - it answers `(WellConstrained, 0)` for anything, one free point included
  (section 7, first pitfall).
- Order: locate from the origin / datum axes first, then size, then test what still moves
  [course CAD2.4 00:31]. Journal equivalent: add dimensions until DOF is 0, then change one
  expression and re-measure. The DOF must come DOWN on the way (free point 2 -> on an axis 1 ->
  dimensioned 0); a read-out that is 0 before the last dimension is the auto-dimensioning trap.
- Constrain before relating - an undimensioned line satisfies a relation by stretching
  [course CAD2.4 00:11]. Relations are directional in the UI (first pick moves); the classic API
  has no motion/stationary argument, the solver moves whatever is not yet dimensioned [verified:
  the free line became parallel and equal to the dimensioned base].
- Tangent is not coincident: a tangent relation alone leaves the end off the curve; add
  point-on-curve / coincident to close the profile [course CAD2.4 00:21]. Equal Length does not
  fix direction; add Parallel [course CAD2.4 00:25] (the probe applied both together; Equal Length alone was not isolated).
- Pull existing 3D geometry into the sketch (Project Curve, Intersection Curve, Intersection
  Point) instead of re-typing its coordinates [course CAD2.3 00:41]; all three are verified
  (recipes 3 and 29).
- Name the dimension expressions and drive them by formulas - the user's habit (`Carr_W`,
  `IC_CAP`, `p7=Carr_Ring`) [mined]; name the sketch too [course CAD2.1 00:15] (the user never does).
- **Intent goes into relations, the drawing's numbers into dimensions** [cast eska, eskb]: centre
  with Midpoint / Point on Curve to the datum instead of two half-dimensions, Equal instead of a
  repeated value, a datum axis as horizontal reference so the shape turns with it. A driving
  dimension records intent; an automatic one does not - Siemens' 2012 habit of letting auto
  dimensions "fully constrain" is the trap of section 7 (10 of the 32 "well constrained" sketches of
  its own sketching course are held by automatic dimensions; really fully constrained: 24 of 63)
  [verified, read-only pass over the 34 `skt*` parts].
- Make Symmetric relates two EXISTING curves (no new curve, DOF -4 per line pair, one `Mirror`
  constraint); Mirror Curve makes NEW geometry that adds no freedom (`Pattern` constraint). Which of
  the two lines moves is NOT decided by Primary / Secondary: fix or dimension the one that must
  stay first (Fixed on both END POINTS - Fixed on the line takes only 2 of its 4 freedoms)
  [verified, `sketch_rules.py` K4] [cast eska].
- A value that may become 0 (a notch that closes): on NX 2206 both a line-to-point perpendicular
  dimension and the length of the riser line survive 5 -> 0 -> 9 with the Extrude following; the
  CAST advice to use the perpendicular one belongs to the old solver - keep it as the tidier
  choice, not as a must [verified, K5] [cast eskb].

**Where course and user disagree**: the instructor insists on fully defined sketches; 60 % of the
user's sketches are under-constrained and 71 % carry no dimension (clean parts 57 % well
constrained, imported-body rework 28 %) [mined]. Rule for Claude: **fully constrain every sketch
it creates; never "repair", re-dimension or re-solve the user's existing sketches** unless asked -
adding relations to a loose sketch can move geometry that downstream features depend on.

## 3. Sketch recipe [verified, `scripts/sketch_recipes.py`, `scripts/course_checks.py`]

1. `new_sketch(part, plane_or_face, horizontal_ref, origin_point, name)` -
   `SimpleSketchInPlaceBuilder` with `Xforms.CreateXformByPlaneXDirPoint`. Plane = `DatumPlane` or
   planar `Face`. On a path: `Sketches.CreateSketchAlongPathBuilder(Sketch.Null)`, fill
   `b.Section`, `PlaneLocation.Path.Value`, `IsPercentUsed = True`, `Expression = "0"`.
   `nxf.new_sketch` switches Continuous Auto Dimensioning off before the builder runs; with any
   other builder (on path, your own copy) call `nxf.auto_dimensioning_off()` first - the sketch
   keeps the setting it was created with.
   **Constrained section on a path** [verified, `sketch_rules.py` K7, recipes 50]: position
   expression in `PlaneLocation.Expression` (% arc length); in the sketch a sketch Intersection
   Point of the path (`CreateIntersectionPointBuilder`, DOF 0) is the reference; H/V rectangle
   (DOF 4) -> two Midpoint constraints to that point (2) -> two driving dimensions (0). Position
   30 -> 70 %: the section rides along, normal = path tangent, still DOF 0; swept along the path
   the volume is w x h x path length. Use it for Swept / Variational Sweep / Sweep Along Guide.
2. `sk.Activate(...)`; create curves at solved 3D positions with `part.Curves.CreateLine/CreateArc`
   and `sk.AddGeometry(curve, InferCoincidentConstraints)`. A circle is one arc `0..2*pi`.
3. Relations: `CreateHorizontal/Vertical/Tangent/PointOnCurve/Coincident/Parallel/Perpendicular/
   EqualLength/Midpoint...Constraint` with `Sketch.ConstraintGeometry` structs. Symmetry:
   `Sketches.CreateMakeSymmetricBuilder` (`PrimaryObject`, `SecondaryObject`, `CenterLine` = datum
   axis; the roles do not decide which one moves - section 2). Mirror copy:
   `CreateSketchMirrorPatternBuilder` (`Section`, `DirectionObject` = datum axis).
4. Dimensions: `CreateDimension(PerpendicularDim, ref, geom, origin, Expression.Null)` then
   `dim.AssociatedExpression.RightHandSide = "plate_w/2"`; `CreateDiameterDimension`,
   `CreateRadialDimension`. References: datum axes, sketch lines, projected edges.
5. `sk.Update()`, check status (`nxf.sketch_status`, not a bare `GetStatus()`),
   `sk.Deactivate(..., UpdateLevel.Model)` - `nxf.finish_sketch(sk)` does all three.
   **In a part that was modelled in the NX user interface the sketch is a new-solver sketch**
   (`nxf.legacy_solver(sk)` False; every sketch of a new batch part is legacy): a smart point
   (`nxh.point`) then takes ONE constraint or dimension - the second raises "Invalid object type",
   on any plane - and `sk.Update()` does not re-solve (`sk.LocalUpdate()` does, `finish_sketch`
   calls it). Reference `nxf.sketch_anchor(part, sk, point)` instead of the point;
   `nxf.sketch_rect_centered` / `nxf.sketch_circle` do so themselves [verified; `nx-journal-core`
   section 5, "Two sketch solvers"].
6. Project edges: `Sketches.CreateProjectBuilder` + `EdgeDumb` rule -> a `CPROJ` child and a
   dimensionable line. Plate 60 -> 80 moved the dependent hole from x 22 to x 32.
7. Also working: `Sketch.Fillet`, `SketchOffsetBuilder`, `CreateSketchChamferBuilder`
   (`CurvesToChamfer.Add` x2), circular `SketchPatternBuilder`, mirror about a datum axis or a drawn
   centre line converted to reference (`CreateConvertToFromReferenceBuilder`), ellipse via
   `Curves.CreateEllipse` + `AddGeometry`, `CreateFixedConstraint` (DOF 3 -> 0), sketch Intersection
   Curve (`FaceCollector` + `CollectorUpdated()`) and Intersection Point (`Rail` section).
   Sketch Offset of a closed loop goes OUTWARD for a positive distance whatever the help point; a
   NEGATIVE distance (`"-wall"`) goes inward; `ReverseOffsetDirection()` raises "Sketch is not
   initialized." headless [verified, `sketch_rules.py` K6] - measure the side every time.

## 4. Sections and selection-intent rules [verified]

`sec = part.Sections.CreateSection(0.0095, 0.01, 0.5)`, then
`sec.AddToSection([rule], seed_or_Null, Null, Null, help_point, Section.Mode.Create, False)`
(`nxh.section(part, rules=[...], seed=, help_point=)`, `nxh.section_region`, `nxh.section_feature`).

| Rule | Factory call | Selects | Measured | User's use [mined] |
|---|---|---|---|---|
| `RegionBoundary` | `CreateRuleRegionBoundary(sketch, curves, seedPoint, 0.01)` | the ONE region around the seed point | ring 20858.4; circle only 3141.6 | Extrude 886, Revolve 49 |
| `CurveFeature` | `CreateRuleCurveFeature([feat])` | all curves of the feature; inner loops = holes. An ACTIVE sketch point is taken in too ("Cannot extrude..."): reference point, or `nxh.section_feature(..., curves_only=True)` | 20858.4 | Extrude 143, Rib 20 |
| `CurveFeatureChain` | `CreateRuleCurveFeatureChain([feat], seed, Curve.Null, True, 0.0095)` | connected chain through the seed | 24000 | Extrude 111, Bounded plane 22 |
| `CurveFeatureTangent` | `CreateRuleCurveFeatureTangent([feat], seed, Curve.Null, True, 0.5, 0.0095)` | tangent chain through the seed | 3141.6 | Tube path 72, Project 36 |
| `CurveDumb` | `CreateRuleCurveDumb(curves)` | exactly the listed curves | 24000 | Extrude 194, Hole positions 279 |
| `EdgeDumb` | `CreateRuleEdgeDumb(edges)` | listed edges | composite 200.0 | Extrude 96 |
| `EdgeTangent` | `CreateRuleEdgeTangent(seed, Edge.Null, True, 0.5, False)` | tangent edge loop | 8 edges, 3535.62 | Tube 44, Chamfer 327 |
| `EdgeChain` | `CreateRuleEdgeChain(seed, endEdge, isFromStart, commonFace, False)` | loop on a face from seed to end edge | 8 edges, 3535.62 (2 with the wrong sense) | Bounded plane 168 |
| `EdgeBoundary` | `CreateRuleEdgeBoundary([face])` | all boundary edges of the face | 8 edges, 3535.62 | Extrude 30 |

- `RegionBoundary` seed point must lie inside the wanted region; chain / tangent rules take the
  seed curve as 2nd argument and a help point on it.
- **A rule-only section without a seed ignores the help point**: three different help points gave
  the same start; with a seed curve the section starts at the seed's end nearest the help point
  [verified]. Pass both whenever start or direction matters (lofts, sweeps, offset side).
- `EdgeChain` needs a real end edge (the neighbour of the seed on the far side of the loop);
  `Edge.Null` selects the seed only, and the wrong `isFromStart` gives the short 2-edge way round.
- **Stop at intersection** [course CAD3.1 00:05]: crossing whole lines in one `CurveDumb` rule are
  refused ("Selected objects will result in a self intersecting section"). Use
  `sec.AddChainBetweenIntersectionPoints(rules, startConnector, startPoint, endConnector, endPoint,
  seed, helpPoint, Mode.Create, False)` once per trimmed piece: four crossing lines -> closed loop
  -> solid 2000.0 [verified]. In a sketch, `RegionBoundary` does the same job in one rule.
- Which rule: region of a multi-loop sketch -> `RegionBoundary` (the user's default); whole
  sketch / text / curve feature -> `CurveFeature`; one loop of several -> `CurveFeatureChain`; a
  filleted path -> `CurveFeatureTangent` / `EdgeTangent`; a face outline -> `EdgeBoundary`.
- Builder-owned sections are filled in place (`b.SectionToProject`, `b.CurvesToOffset`,
  `CompositeCurveBuilder.Section`, `Bridge...StartSection/EndSection`, `MirrorCurveBuilder.Curve`,
  `CombinedProjectionBuilder.Curve1/Curve2`); `CurvelengthBuilder.Section` is `None` - assign one.
- A multi-curve profile sweeps a multi-face wall; join it first when one face matters (3 curves ->
  3 faces, joined -> 1 spline -> 1 face, same area) [verified] [course CAD5.1 00:12].
  Join output, line + R10 arc + line at tolerance 0.001 [verified, `cast_curve_checks.py` C1]
  [cast ecvc]: **General = exact** (rational cubic, 10 poles, deviation 0, still ONE face);
  Cubic 23 poles / Quintic 21 poles, 0.0005 off; `Advanced` with its defaults misses by 2.4 mm.
  The user never joins (92 of 92 `JoinOption = No`) [mined] - do it only when face count matters.
- `body.GetEdges()` has no fixed order between NX sessions: pick edges by geometry (bounding box,
  face, length) and give seed + help point, never "the first edge" [verified by another package].
- Closed? Extrude and assert `body.IsSolidBody` + volume, or `loop_closed(curves)` from the scripts.

## 5. Datums [verified, `scripts/datum_recipes.py`]

`DatumPlaneBuilder.GetPlane()` -> `SetMethod(PlaneTypes.MethodType.X)`, `SetGeometry([...])`,
`Expression.RightHandSide`, `Evaluate()`:

| Plane | Method + geometry | Read back |
|---|---|---|
| offset from datum plane or planar face | `Distance`, `[plane or face]`, formula | z 15 -> 25 after edit |
| on a face (offset 0: 166 of 645 [mined]) | `Distance` `[face]` `"0"`, or `Coincident` `[face]` | follows the face 60 -> 80 |
| at angle about an axis | `Angle`, `[plane, datum axis]`, degrees | normal (0, 0.5, 0.866) at 30 deg |
| three points | `ThreePoints`, three smart points | normal (0,-0.707,0.707) |
| bisector [course CAD2.3 00:39] | `Center`, `[face1, face2]` | x 30 -> 40 |
| tangent to cylinder [course CAD5.3 00:00] | `Tangent` `[cyl]`; `TangentParPlane` / `TangentPerpPlane` / `TangentAnglePlane` `[cyl, plane]` | 10.000 from the axis of a d20 cylinder |
| on curve | `Frenet`, `[edge]`, `SetPercent(True)`, percent | origin at 25 %, normal = tangent |
| point + direction | `PointDir` (`nxh.datum_plane`) | - |

Datum axis: `DatumAxisBuilder.Type` = `PointAndDir`, `TwoPoints`, `CurveOrFaceAxis`, `Intersection`.

**Inclined port / boss, pattern about a non-CSYS axis** [verified, `scripts/inclined_port.py`, recipes 39]:
1. Datum Axis A1 through two points (or point + direction) = the hinge, e.g. across the housing axis
   at the port height.
2. Datum Plane P1 `Angle` `[reference plane, A1]`, formula = the angle expression. Its normal is the
   port direction; read `Normal` once and negate the formula if it turned the other way.
3. Datum Plane P2 `Distance` `[P1]` = the port face. Sketch on P2, circle centre = the projection of
   a point on A1 (DOF 0).
4. Extrude along `Directions.CreateDirection(P2, sense, UPD)` (associative, not a typed vector), end
   limit **Until Selected** = the wall face (boss, Unite) and the bore face (bore, Subtract).
5. Datum Axis A2 `CurveOrFaceAxis` of the port cylinder = rotation axis of the bolt-hole pattern on
   the port face (`nxf.axis_from(part, A2)`).
Measured: port axis (cos a, 0, sin a) at 30 and at 45 degrees, bore open into the housing, 4 holes
parallel to the port axis on their pitch circle, one solid. Until Selected fails with "Cannot trim
with the limit face ..." as soon as part of the section starts inside the limit face (port too short
for its angle): keep `port_len*cos(a) - port_od/2*sin(a) > body radius` over the whole angle range.

**Offset Datum CSYS - the positioning skeleton** [verified, `sketch_rules.py` K2, recipes 49]
[cast efmb]: `Xforms.CreateXformEulerTaitBryanAngles(base_csys, origin_point, RotationSequence.XYZ,
rx, ry, rz, 1.0, UPD)` -> `DatumCsysBuilder.Csys` = ONE `DATUM_CSYS` feature whose origin is a smart
point and whose angles are expression scalars. Convention measured: rotations about X, then the NEW
Y, then the NEW Z (intrinsic). A child CSYS in the parent's coordinates
(`Points.CreatePoint(parent_csys, sx, sy, sz, UPD)`) follows the parent. A boss sketched on its XY
plane (DOF 0) and extruded along the plane normal stands on its Z axis and turns with the angle
(Ry 30 -> 60). Use one Offset CSYS for a feature at a compound angle; the axis + angled plane
recipe above when only one angle is involved.

Datum CSYS: `CreateDatumCsysBuilder`, `Csys` from `Xforms.CreateXform(smartPoint, xDir, yDir, ...)`;
planes via `part.Datums.FindObject(f"{feat.JournalIdentifier} XY plane")`. Point feature:
`BaseFeatures.CreatePointFeatureBuilder`. User order: datum plane -> sketch 238, Divide Face 58,
Trim Body 56, Replace Face 44, Split Body 24 [mined]. Three coordinate systems exist - Absolute,
WCS, Datum CSYS [course CAD4.3 00:46]; journals work in absolute coordinates and never move the WCS.

## 6. Curve features [verified, `scripts/curve_features.py`, `course_checks.py`, `law_curve_gear.py`, `cast_curve_checks.py`, `offset_checks.py`, `spline_rules.py`, `curve_activities.py`]

| Feature (type string) | Key settings | Measured | User practice [mined] |
|---|---|---|---|
| Associative Line / Arc (`LINE`, `ARC`) | smart points, `Associative = True`; line `StartOption/EndOption.Tangent` + `StartTangent.SetValue(curve, view, help point)`; arc `ThreePointArc` + `MidOption.Radius` + `ZonePoint` | 50 -> 70; r 12 arc 18.85; 4 common tangents of two circles from 4 help-point pairs, follow R30 -> R40; arc by 2 points + R200 | 83 / 31, ends on curves |
| Studio Spline (`SPLINE`) | ThroughPoints / ByPoles, `Degree`, `IsSingleSegment`, `IsPeriodic`, per-point `TangentDirection` / `AutomaticConstraintType` - section 6a | ends exact; end follows 100 % -> 50 % | 31, degree 5, 2 on-curve points -> Trimmed Sheet |
| Fit Curve (`Fit Curve`) | `FitSpline`, `SpecifiedPoints`, `DegreeAndSegments` or `DegreeAndTolerance` | noisy arc: 4 poles, no curvature peak | see nx-reverse-engineering |
| Bridge Curve (`BRIDGE_CURVE`) | `StartSection` / `EndSection` (curves or EDGES); `...Connectivity.Continuity.ContinuityType` = G0..G3; `ShapeControlMethod` TangentMagnitude / Conic (`Rho`) | G1: degree 3, 4 poles; G2: degree 5, radius 20.000 at an R20 arc end, 2 inflections against a straight parent; magnitude 1.0 = default, 0.5 and 2.0 both tighten r_min 27 -> 4.6 / 6.8; between two sheet edges it stays attached and tangent after both parents change | 30, G1, magnitude 1 -> Studio Surface |
| Project Curve (`CPROJ`) | faces as `ScCollector` in `FaceToProjectTo`, or `PlaneToProjectTo`; `DirectionType` AlongVector / AlongFaceNormal / AngleToVector / TowardPoint / TowardLine; `ProjectionOption = ProjectBothSides` | exact on a square plane only; d20 circle 50 above a plane: angle +20 deg -> d 56.40, toward a point 50 below the plane -> d 10; toward the axis onto a d60 cylinder -> radius 30; Along Vector sees only faces AHEAD ("No curve projected." otherwise), Both Sides reaches them | 287 -> Extrude 105 (normal 179, vector 68, both sides 39) |
| Combined Projection (`CPROJ_CMB`) | `Curve1`, `Curve2` (whole sketches by `CurveFeature` rule), `Direction1/2.ProjectDirectionMethod` = CrvPlaneNormal or Vector | deviation 3e-14 from both views; two sketches: follows a sketch dimension 190.5 -> 200 | 8 in 3 parts |
| Intersection Curve (`INTERSECTION_CURVES`) | `Tolerance = 0.01` mandatory | 200.0; follows 10 -> 15. Two DATUM PLANES: commits, but returns a plain line that is NOT a feature and does not follow | 35, scan body x plane |
| Section Curve (`SECTION_CURVES`) | `Type = PlaneType.Selected` | 94.248 | 30 |
| Isoparametric Curve | `SelectObject.Value = face`; `Direction` IsoU / IsoV / IsoUV, `Number`, `Placement` | cylinder, Number 4: IsoU 4 generators of 40, IsoV 4 circles | 10 -> Sketch 9 |
| Isocline Curve (`ISOCLINE_CURVE`) | `part.Features.FreeformCurveCollection.CreateIsoclineCurveBuilder(IsoclineCurve.Null)`; `Face`, `ReferenceDirection`, `IsoclineAngle` or Multiple `StartAngle/EndAngle/IntervalAngle` | angle = DRAFT of the face to the direction: 0 -> the two silhouette lines of a lying cylinder (follows d 20 -> 30), 30 -> r sin 30 above the axis, -30 below; family -60..60 / 30: 10 lines | 9 in 6 parts |
| General Conic (`General Conic`) | `TwoPointsAnchorRho`: `StartPoint`, `EndPoint`, `AnchorPoint`, `RhoValue`; `FivePoints` | shoulder at rho x anchor height (rho 0.3 Ellipse, 0.5 Parabola, 0.75 Hyperbola); 5 points of an ellipse -> that ellipse | - |
| Curve on Surface (`CURVE_ON_SURFACE`) | `Faces` collector + `ConstraintManager` points | 0.000 off the face | 27 -> Trimmed Sheet 14 |
| Offset Curve (`OFFSET_CURVE`) | `Type` Distance / Draft / LawControl / Axial3d, `TrimMethod`, `ReverseDirection`, `RoughOffset`, `PointOnOffsetPlane` - section 6b | 160 / 240 | 13 |
| Offset Curve in Face (`OFFSET_IN_FACE`) | `Offsets.Append(CreateExpressionSectionSet)` (several = several offsets in one feature), assign `FaceCollector`; `ExtendToFaceOption`, `OffsetMode` - section 6b | 160; side rule 4 of 4 | 205 -> Divide Face 143 |
| Wrap / Unwrap Curve (`WRAP`, `UNWRAP`) | `CreateWrapBuilder(WrapUnwrap.Null)`, `Type`, `Curves`, `Faces`, `Plane.Value` = tangent datum plane | wrap: 0.0005 off the cylinder, length kept; unwrap of a 45 deg mitred R20 tube: end circle -> line of 125.664, cut edge -> one sine period, amplitude 20, 0.0004 off; follows the cut height; wrapped back 0.0004 from the edge | 4 |
| Point Set (`PointSet`) | `SingleCurveOrEdgeCollector`, `NumberOfPointsExpression`, `Start/EndPercentage`, `CurvePointsBy` GeometricProgression + `Ratio` | 5 points every 15.0; 10..75 % counts from the end nearest the help point; ratio 1.5: each gap 1.5 x the last | 1 |
| Composite Curve (`EXTRACTED_CURVE`) | rule in `Section`; `JoinOption` No / Genernal [sic] / Cubic / Quintic | 4 curves 200.0; joined: 1 spline | 94 (72 WAVE links), never joined |
| Join Curves (`JOIN_CURVE`) | `CreateJoinCurvesBuilder`, `OutputCurveType` General / Cubic / Quintic / Advanced | same results as the Composite Curve join; no menu button in NX 2206, the builder works | - |
| Mirror Curve (`MIRROR_CURVE`) | `Curve` section, `NewPlane` | ends mirrored exactly | 2 |
| Trim Curve (`TRIM_CURVE2`) | `CurveToTrim`, bounding object with `BoundingObjectMethodType = SelectPlane` + `BoundingPlane`, `SelectTrimRegion(point ON the piece)`, `KeepOrDiscard` | line 60 -> 40; Keep -> 20; smart plane: follows 40 -> 25; region point 0.5 off the curve: feature created, nothing trimmed | 45 in 14 parts |
| Curve Length (`CURVE_LENGTH`) | start / end increments | 50 -> 43 | 8, after Offset in Face |
| Helix (`HELIX`) | `SizeLaw`, `PitchLaw`; `Turns`, or `LengthMethods.Limits` + `StartLimit/EndLimit.Expression` | 252.121 vs 252.122; by limits 314.795 vs 314.795; linear pitch 2->6 = 5.00 turns | 17 (16 by limits) -> Sweep 10 |
| Text (`TEXT`) | Planar frame; On Face + `CanProjectCurves`; On Curve (Natural / Vector) | planar in frame; on cylinder 0.005 off; on an R40 arc | 10, planar, Arial -> Extrude |
| Law Curve (`SPLINE_LAW`) | `XLaw` / `YLaw` / `ZLaw`: `LawType = ByEquation`, `Parameter = "t"`, `Function = "<expression name>"`, `DistanceTolerance = 0.0001` | involute flank 1.2e-5 mm off the exact curve; follows z and m | 0 (community: 1 gear template) |

**Equation-driven profiles and the involute gear** [verified, `scripts/law_curve_gear.py`, recipes 40]
[community: 1 author, part opened]: one unitless expression `t = 1` is the parameter NX runs 0..1;
each coordinate is a named expression in terms of `t`; trig takes degrees (`u*180/pi()` for a roll
angle in radians); keep the pressure angle a plain number so the involute maths stays unitless.
Gear: master expressions `m`, `z`, `alpha`, `b` -> root Cylinder `df` -> law curves for the flank,
the tip arc and the radial line to the base circle -> Datum Plane through the axis at
`(90/z) + inv(alpha)` degrees (formula came out as `-mirror_angle`: test the normal, negate if
needed) -> Mirror Curve -> Extrude the closed tooth as its own body -> Pattern Geometry of the
BODY, count `z` -> one Unite -> bore afterwards. Measured: pitch points on both flanks (tooth
thickness pi*m/2), volume equal to the integrated involute profile to 8e-8, regenerates from
z 17 / m 3 to z 24 / m 2 and back with no error.
Optional features (chamfer or fillet, with or without a detail) are switched by Boolean expressions:
Suppress by Expression gives the feature a `Suppression Status` expression whose right-hand side may be
a Boolean or `if (a == true && b == true) (false) else (a)`; all four states measured (recipes 41).

Text on a curved face [course CAD5.2 00:19]: the projected outlines are non-planar, so Extrude
returns **sheet** bodies (reproduced: 2 sheets, booleans refuse them). Working route [verified]:
make the same text un-projected (flat loops), Extrude-Subtract it deep along the local normal,
then Unite a core cylinder of radius r - depth: uniform 0.6 mm pockets with cylindrical floors.

Associative Arc: angles are measured in the support plane's own frame (angle 0 = `plane.Matrix`
X axis): +X on a fixed plane with normal +Z, **-X on a smart plane offset from the datum XY plane**,
-Z with no plane at all (the arc then stands in YZ). Read the matrix or use `arc_frame` /
`plane_angles` from `round3_checks.py` [verified, 8 plane kinds].
Not working: Trim Curve with a bounding OBJECT (curve, point, datum plane: "Bounding objects are
either suppressed or modeled away." - a bounding PLANE works), linear sketch pattern,
`SketchOffsetBuilder.ReverseOffsetDirection()`. Partial: Offset Curve 3D Axial (commits; the result
is always a spline, not a rigid shift); Intersection Curve of two datum planes (a dumb line).
Not probed: bridge constraint faces and Depth / Skew, Shadow Curve, Smooth Spline / X-Form on
curves, Divide Curve, sketch Polygon / Derived Lines, law curves other than By Equation.

### 6a. Splines: which type, which degree, how to judge [verified, `scripts/spline_rules.py`] [cast ecvc]

Nine points of an R100 arc "digitised" with +-0.5 mm error - the same points, seven ways:

| Spline | Off the points | Inflections | Curvature peaks | r_min (true 100) | Off the true arc |
|---|---|---|---|---|---|
| Through Points, degree 3 | 0 | **6** | 7 | 34.5 | 0.82 |
| Through Points, degree 5 | 0 | 6 | 7 | **14.6** | 1.89 |
| By Poles, the 9 points as poles, degree 3 | 0.96 | 0 | 4 | 59.9 | 0.71 |
| By Poles, 9 poles, single segment (degree 8) | 3.31 | 0 | 1 | 77.8 | 3.00 |
| By Poles, 5 hand-placed poles, single segment | 1.97 | 0 | **0** | 81.9 | 1.69 |
| Fit Curve, degree 3, 1 segment | 0.61 | 0 | **0** | 86.7 | **0.19** |
| Fit Curve, degree 5, 1 segment | 0.57 | 0 | 1 | 68.2 | 0.22 |

| The curve must ... | Use |
|---|---|
| pass through given locations (dimensioned, on other geometry, trusted) | **Through Points**, degree 3; degree 5 only up to 6 points (= one segment, Siemens' sample splines). It reproduces every error of its points - never feed it measured data, and never raise the degree to "smooth" it |
| be fair, only its ends are fixed (styling curve, guide, section) | **By Poles**, 4-6 poles, `IsSingleSegment = True` (degree = poles - 1); shape it with the inner poles |
| follow measured / digitised points | **Fit Curve**, degree 3, 1 segment; add segments only while the error is above the noise. A fit buys fairness, not accuracy: on 30 points with +-0.05 noise both the fit and the interpolation stay 0.05 off the true arc, but the curvature swings 1.12 : 1 instead of 1.52 : 1; a tolerance below the noise (0.01) only buys segments (2 -> 4) |
| be closed | `IsPeriodic = True`, first point NOT repeated: tangent and curvature continuous across the seam, extrudes to one wall. First point repeated instead: a 25 deg corner at the seam |

- Arithmetic (`ck.spline_data`): By Poles needs poles >= degree + 1, segments = poles - degree.
  Through Points on NX 2206: poles = points, segments = points - degree, knots NOT at the points
  (6 points: degree 3 -> 3 segments, degree 5 -> 1); `MatchKnotsType` puts a knot at every point.
  Across each interior knot of a cubic the curvature has a kink (slope jump 15 x its range on the
  test curve), one segment has none: fewer poles = fewer places to wiggle.
- **Judge a spline along its length, not by its ends**: `q = ck.curve_quality(curve)` ->
  `inflections` (0, or exactly those the design calls for - an S has 1), `peaks` (each a visible
  knuckle), `r_min` (must exceed every later offset / blend / tool radius), `k_end` (compare with
  the neighbour for G2). It equals `nxh.max_curvature` of the sheet extruded from the curve (1e-7).
- End conditions from neighbouring geometry (Through Points: any point; By Poles: the two ends
  only - an interior pole raises "Cannot compute bcurve."): on-curve end point (`ck.on_curve`) +
  `AutomaticConstraintType = Tangent` / `Curvature` -> G1 (0.000 deg) / G2 (radius 20.000 at an R20
  arc; on a pole spline NX moves poles 2 and 3 for it); `TangentDirection =
  Directions.CreateDirection(line, Sense.Forward, UPD)` follows the line (10 -> 40 deg).
  `TangentMagnitude` takes an `NXOpen.Scalar` and is an ABSOLUTE derivative length, not the
  dialog's factor: 1.0 gave a 0.002 mm hook - leave it unset.
- By-poles construction: pole 2 on the neighbour's tangent line = G1; on ONE segment of degree p,
  pole 3 at h = k a^2 p/(p-1) off that line (a = distance pole 1-2, k = neighbour curvature) = G2
  (R20, a 10, p 4: h 6.667 -> radius 20.000). Never move those poles afterwards.
- Tolerance [cast ecvc: do not chase data with a tiny tolerance]: involute law curve 11 / 13 / 15
  poles at 0.01 / 0.001 / 0.0001 (already 0.0002 accurate at 0.01); projection onto a cylinder
  7 / 8 / 28 poles. Default 0.01, tighten a decade at a time, read `PoleCount`.
- Editing: `CreateStudioSplineBuilderEx(spline)` re-opens the feature; Degree 3 -> 5 kept the
  points but moved the curve 5.7 mm between them - re-measure after any spline edit (recipes 43).

### 6b. Offset curves: corners, short ends, the checks [verified, `scripts/offset_checks.py`] [cast ecvd]

Offset Curve, `TrimMethod`, Z-shaped chain 40 + 30 + 40 offset 5:

| `TrimOption` | Result | Use |
|---|---|---|
| `NotSet` (dialog: None) | 3 lines of the SOURCE lengths, 7.07 apart at both corners; offsetting it again: "The section contains multiple loops." | never when the result feeds a section |
| `ExtendTangents` | 3 lines that meet (one corner +5 +5, the other -5 -5) | sharp-cornered profiles |
| `Fillet` | an arc of radius = distance closes the convex corner, the concave one is trimmed | constant distance round corners (gasket, tool path, wall) |

- One straight line: "Input curves form straight line, unable to determine offset plane." - set
  `PointOnOffsetPlane`. `Types.Draft` (height, angle), `LawControl` (start = the section end
  nearest the help point) and `Axial3d` (always a spline): recipes 45.
- Offset beyond the smallest radius of a spline: a CLOSED loop is cleaned by NX 2206 itself; an
  OPEN curve folds over (points 0.68 from the source for distance 3) unless `RoughOffset = True`.
  Check every spline offset: no sample of the result nearer the source than the distance
  (`clean_offset` in the script); a closed result extrudes to ONE solid.
- **Offset Curve in Face ends where its own construction ends, not at the face boundary.** On a
  face that widens away from the edge the offset has the EDGE's length (61.50) and stops 3.78 short
  at both ends; `ExtendToFaceOption = Boundary` -> 69.68 = the face width, ends on boundary edges.
  On a face that narrows it is cut at the boundary by default. Neighbouring offsets meet at corners
  by default (Trim / Extend `WithinSection`). The check before Divide Face / Trim Sheet:
  `ends_on_boundary(part, face, curve)` - a short curve makes Divide Face answer "Dividing objects
  do not divide selected faces" (or set `DividefaceBuilder.ExtendOption = True`).
- **Divide Face by a curve: set the projection.** The default is the normal of the CURVE's plane;
  a planar offset curve lying on a cylinder then divides along the rulings through its END points
  (3 pieces, no error). `ProjectionOption.ProjectDirectionMethod = DirectionType.FaceNormal` gives
  the strip (area 655.78 = analytic); check the AREA of the pieces, not the face count.
- `OffsetMode` on an R15 face, distance 10: `Chordal` (default) 38.94 deg round the axis,
  `Arclength` = `Geodesic` 38.20, `Tangential` 41.81. Chordal for a true distance (seal land, lip),
  Arclength for a width measured on the surface (film, label, flat-pattern work). Several
  `Offsets.Append` = several offsets in ONE feature.

### 6c. Names you meet in old parts (NX 8.5 and earlier) [cast; NX 2206 menu files]

| Old name / feature | In NX 2206 | Journal route |
|---|---|---|
| Basic Curves, curve Fillet / Chamfer / Rectangle / Polygon / Ellipse, Trim Corner, Stretch | "(Legacy)", hidden | sketch tools; associative Line / Arc |
| Spline (By Poles, Through Points, Fit, Perpendicular to Planes) | "Spline (to be retired)" | Studio Spline, Fit Curve |
| Edit Curve Parameters (spline degree, stiffness, poles, smooth) | "Parameters (Legacy)" | re-open the Studio Spline builder; Smooth Spline / X-Form exist, not probed |
| Join Curves (`JOIN_CURVE`) | no button; a search synonym of Composite Curve | Composite Curve join, or `CreateJoinCurvesBuilder` |
| Extract Curve (edge, silhouette, isocline, shadow) | "Extract (Legacy)" | Composite Curve, Isocline Curve, Shadow Curve |
| Simplify Curve | still in the menu, no builder | Fit Curve (line / circle) on sampled points |
| Wrap/Unwrap Curve, Offset Curve, Offset in Face, Project, Combined Projection, Intersection, Text, Bridge, Divide, Length, Trim | current, same names (Trim redesigned as `TrimCurve2`) | this section |
| dumb curves and points with no feature | still load and select | reference only: `CurveDumb` rule, or rebuild as a sketch |

## 7. Pitfalls and the check to run

- **The auto-dimensioning trap: bare `GetStatus()` says DOF 0 for any sketch.** A batch session
  starts with the session preference Continuous Auto Dimensioning ON
  (`Session.Preferences.Sketch.ContinuousAutoDimensioning`). A sketch created in that state gets
  one automatic dimension per open degree of freedom at `Update()` (no expression, drives
  nothing), and `sk.GetStatus()` returns `(WellConstrained, 0)`: one free point 0 (real 2), free
  line 0 (4), circle 0 (3), H/V rectangle without dimensions 0 (4) [verified,
  `nx-journal-core/scripts/nxf_selftest.py`, sketch group]. The setting is taken over when the
  sketch is created; switching the preference afterwards does not change that sketch. What to do:
  - create sketches with `nxf.new_sketch` (it switches the preference off first), or call
    `nxf.auto_dimensioning_off()` before your own builder;
  - read the status with `nxf.sketch_status` / `nxf.finish_sketch`: for a sketch that was created
    with the preference on they count the automatic dimensions back in
    (`nxf.auto_dimensions(sk)`, `auto_dims` in the result) and report `UnderConstrained`;
  - prove a "fully constrained" claim by the countdown (DOF after each group of constraints =
    hand count, ending at 0) and one expression edit, never by a single 0.

  The DOF values quoted in this skill were first read with the preference on. They were read
  again with it off (`sketch_recipes.py`, `course_checks.py` and `datum_recipes.py` now switch it
  off themselves; `round3_checks.py` and `inclined_port.py` go through `nxf.new_sketch`): every
  "DOF 0" in this skill held, and one entry changed - the spline in a sketch, below.
- `GetStatus()`'s enum prints as `'3'`; compare with `Sketch.Status.WellConstrained`, after `sk.Update()`.
- **Spline in a sketch**: a non-associative spline added with `AddGeometry` brings its own
  freedom (4 through-points: `UnderConstrained`, DOF 8). Tie every defining point to a dimensioned
  sketch point - `sk.CreateCoincidentConstraint(cg(spline, CP.SplineDefiningPoint, i + 1),
  cg(point))` - and the sketch is `WellConstrained`, 0 and the spline follows its points (point
  dimension 100 -> 105 moved the spline start to (0, 105, 0)) [verified, `sketch_recipes.py` S6].
  The earlier entry here ("reports DOF 0 yet does not follow its points") was the
  auto-dimensioning trap: the false 0 made the recipe skip these constraints, so the spline stayed
  frozen. `CreateSketchSplineBuilder` / `CreateStudioSplineBuilderEx` inside an active sketch
  leave it "Sketch is not initialized."; so does `CreateSketchSymmetricBuilder`. A spline feature
  through dimensioned sketch points stays the simpler route (the instructor also keeps splines
  out of simple sketches [course CAD2.1 00:39]).
- Linear `SketchPatternBuilder` cannot be committed headless ("Incorrect object for this
  operation.") and the failed commit makes `run_journal` exit 1; the circular layout works.
- **A sketch can be stale while reporting DOF 0**: when the parent of a projected curve is
  suppressed, `GetStatus()` stays WellConstrained / 0 and `nxh.feature_errors` stays empty; the
  only signs are the `Projected Curve` feature turning suppressed and
  `sketch.Feature.GetFeatureWarningMessages()` = "Sketch contains failed recipe curves." Scan both
  after any edit that can remove referenced edges [verified].
- Dimension to a sketch **point** needs `AssocType.StartPoint`.
- Offset side: for Offset in Face a positive value goes to the right of the section direction
  (`direction x face normal`), so fix the direction with seed + help point and read
  `sec.GetStartAndDirection()` [verified]; for Offset Curve measure, then flip
  (`ReverseDirection`); the sketch offset goes outward for a positive and inward for a negative
  distance (`ReverseOffsetDirection()` raises headless). Instructor: check the arrow before OK
  [course CAD5.2 00:37].
- Silent curve results - each of these commits without an error [verified, CAST round]:
  Trim Curve whose region point is not ON the curve (feature made, nothing trimmed: compare the
  length); Offset in Face that stops short of the boundary (6b); Divide Face along the wrong lines
  with the default projection (6b); a plain open-spline offset that folds over (6b); Project Curve
  cut at a hole or doubled on a closed face (count the curves); Intersection Curve of two datum
  planes (a dumb line that never updates); a through-points spline that carries the noise of its
  points (count the inflections, 6a); a spline `TangentMagnitude` of 1.0 (a hook, 6a); a line on
  typed coordinates that "is associative" and follows nothing; a sketch that references geometry
  shaped by a later feature (section 2).
- Text On Face: "Unable to project text curves." means the frame fell off the face - flip
  `FrameOnPath.IsApexReversed` or the sign of `Offset`.
- `IntersectionCurveBuilder` default tolerance 0 -> "Distance Tolerance cannot be zero."
- `HelixBuilder`: `Turns` is the expression; the helix ignores any CSYS.
- Typed `Null` arguments: `Helix.Null`, `LawCurve.Null`, `Text.Null`, `BridgeCurve.Null`, `CombinedProjection.Null`,
  `IsoparametricCurves.Null`, `CurveOnSurface.Null`, `TrimCurve2.Null`, `PointSet.Null`, `WrapUnwrap.Null`,
  `IsoclineCurve.Null`, `GeneralConic.Null`, `FitCurve.Null`, `SketchOffset.Null`, `SketchPattern.Null`,
  `NXOpen.SketchIntersectionCurve.Null`, `NXOpen.SketchIntersectionPoint.Null`, `Sketch.Null` (on path);
  `CreateAocsBuilder` and `CreateMirrorCurveBuilder` take `Feature.Null`.
- `run_journal` exit code 1 with a complete JSON: seen in every run that contained a failed
  `SketchPatternBuilder` commit and in none without one (other caught failures exit 0). Trust the
  JSON; still deactivate `S.ActiveSketch` after a failed in-sketch step.
- Never run pick-based curve edits or Remove Parameters on curves a feature consumes - change the
  parent expression or re-open the curve feature's builder [cast ecve].
- Verification kit: `scripts/curvekit.py` (`ck.curve_quality`, `ck.max_dev`, `ck.join_angle`,
  `ck.planarity`, `ck.spline_data`); `curve.GetLength()`; `UFS.ModlGeneral.AskCurveProps(tag, t)` -> point,
  tangent, ..., radius of curvature (index 5; 3.937e8 on a straight piece) for lines, arcs, splines, edges;
  `planarity(curves)`; `loop_closed(curves)`; distance of samples from the target face; feature
  type strings; one expression edit + `nxh.update()` + `nxh.feature_errors(part) == {}`.
