---
name: nx-modeling-strategy
description: How to PLAN a Siemens NX model before writing any journal - classify the job (new parametric part, part from an engineering drawing, imported-body rework, enclosure in assembly context, freeform, scan rebuild, sheet metal), choose the base-shape approach and feature family, order the features, check the feature budget, decide what is driven by sketches/expressions versus direct (synchronous) edits, and define the checks. Use at the start of every NX modelling or model-editing task, and whenever a part is more than one extrude. Built from the user's own 639 parametric parts, a 6-day professional NX course, a 14-author collection of third-party NX parts, Siemens' own NX CAST training models, and recipes verified on NX 2206.
---

# NX modelling strategy

Evidence tags: `[mined]` = statistics from the user's own parametric parts (639 distinct user
parts, 46 631 features; session snapshots and agent-built parts excluded), `[course]` = the 6-day NX CAD course the user supplied, `[verified]` =
measured in headless NX 2206, `[community, n authors]` = 241 third-party NX parts of 14 authors
(tutorial and student models; 79 parts of 6 authors could be opened with their history - an
observation, not a rule, unless several authors agree or it was re-measured here), `[bench]` =
the first CADGenBench run with these skills, `[cast <course> / <lesson>]` = Siemens' NX CAST 8.5
training library (2012): lesson text in own words and counts over 121 distinct Siemens-built
models of its feature-modelling courses - the reference for how a part is built from a drawing
where it differs from the user's habits, re-measured on NX 2206 before it became a rule here.
Details per feature family are in the sibling skills; start with `nx-journal-core` for how
journals are run and verified.

**Whose rule applies.** The user's own parts and the parts other people build from drawings
differ in four habits: the user copies bodies, places blends late, edits faces directly and
keeps booleans as separate features. Where this file gives two rules, the user's rule is the
default for the USER'S work (extending or imitating the user's parts, classes B and C); the
other applies to a new part built from an engineering drawing (section 1a).

## 0. Before anything: write the modelling plan

Never start with code. Write a plan of at most a page and keep it next to the journal:

```
PART        what it is, process (moulded / machined / printed / sheet metal / turned), units
CLASS       one of section 1
MASTERS     named expressions: name = value (unit) - the dimensions a human would want to change
DATUMS      origin and orientation on the Datum CSYS (which face/axis is the datum, where the symmetry
            planes are); the NAMED datum planes for interfaces and centre lines; what must stay
            central, what stays with which edge, which limits mean "up to that face"
FEATURES    ordered list: #, feature type, purpose, references (sketch / face / datum), key values
BUDGET      number of history steps in FEATURES against the usual size for this kind of part (below)
CHECKS      per feature: the number that proves it (volume, face position, wall, count of solids)
REGEN       which masters will be changed to prove the model updates, and the expected results
```
A feature without a check, or a dimension typed twice instead of referenced, is a planning error.

**Feature budget** - count the top-level history steps of the plan (sketches and datum planes
included, pattern instances and hole child rows not) and compare:

| Kind of part | Usual size | Evidence |
|---|---|---|
| turned part (shaft, bush, plug, washer) | 4-6 steps: sketch, Revolve, chamfer / blend, thread | `[community, 4 authors]` exactly one Revolve in 49 of 69 turned parts; folder medians 6 and 7 |
| plate, fork, jaw, bracket | 8-11 steps | `[community, 4 authors]` medians 8, 8, 8, 8, 10, 10, 11 in seven folders |
| cast or machined housing with ports and bosses | 24-42 steps | `[community, 3 authors]` 24, 39, 41, 42 in four opened housings; `[verified]` the two-port example housing: 18 |

A plan with twice the usual number is probably sketching what a Hole feature, a pattern, a
Revolve profile or one multi-point feature would do: a chain of extruded circles for a bolt
circle, stacked cylinders for a turned shape, one blend feature per instance. A plan far below
it has probably skipped detail the drawing shows. The ranges are counts from tutorial-style
models, a sanity check and not a target (the turned and plate figures are row counts of parts
that could not be opened and include a few internal rows; the housing figures are true
top-level steps).

## 1. Classify the job - it decides the whole approach

| Class | Recognise it by | Approach | Skills |
|---|---|---|---|
| A. New native part | brief / drawing, no input geometry | datums -> constrained sketches -> base -> detail features, all driven by named expressions | curves-and-sketches, solid-features, patterns-and-body-ops |
| B. Imported body rework | STEP / Parasolid input, or a parameter-less body feature at the top of the tree (class `Brep`; type `BREP`, or the STEP product name after an AP242 import) | health check, then **synchronous edits** on faces; add new native features after | synchronous-modeling |
| C. Enclosure / part in assembly context | must fit a PCB, connector, mating part | link the neighbour's geometry (WAVE linked body/face), offset, subtract/unite, Replace Face to linked faces | patterns-and-body-ops, synchronous-modeling, assemblies |
| D. Freeform skin | curvature-continuous shapes, ergonomic or aerodynamic | curves -> surfaces (reference patches first) -> trim/extend -> Sew -> solid | curves-and-sketches, surface-modeling |
| E. Rebuild from scan | STL / convergent body input | align the scan on fitted datums, fit planes / cylinders / curves, snap to design values, rebuild as native features, prove by scan-to-CAD deviation | reverse-engineering (inside NX, editable result on top of the scan); the `stl-re-*` skills for fully automatic mesh-to-STEP outside NX |
| F. Sheet metal | constant thickness, bends, flat pattern needed | Sheet Metal application from the start | sheet-metal |
| G. Assembly | several parts, joints, clearances | components + constraints + interference check | assemblies |

The user's parts `[mined]`: 332 native solids, 238 imported bodies reworked (143 of them mostly by
synchronous edits), 66 scan rebuilds, 3 surfacing-heavy natives. Classes B and C are the daily work, not the exception.

### 1a. Class A from an engineering drawing

The job "here is a dimensioned drawing, build the part" has its own defaults. They differ from
the user's house style (section 5) because nothing exists yet that could be edited directly.

1. **No synchronous features.** The expected count of Move / Offset / Replace / Delete Face in
   such a tree is zero: every face is still under a sketch or feature parameter, so change that
   parameter. `[community]` 8 of 14 authors use none at all; the other 6 have them in 11 of
   225 parts (4.9 %), on imported bodies and as rare late fixes; `[cast]` 9 of 121 Siemens
   modelling parts (the user: 56 % of parts - that is classes B and C). Synchronous edits remain the right tool for classes B and C and for
   edits of a finished body.
2. **Fully constrained sketches**, each a single simple profile feeding one feature
   `[course]`; `[community, 6 authors]` 81 % of 299 sketches at DOF 0, 93 % feed one feature;
   `[cast]` 248 of 298 Siemens sketches report DOF 0, 170 on a plane of the Datum CSYS. That
   248 was not re-counted for automatic dimensions: in the sketching course's own parts 10 of
   32 "well constrained" sketches are held by automatic dimensions (24 of 63 really
   constrained), so read the CAST share as an upper bound, not as a target reached.
3. **The drawing's numbers are the masters.** One named expression per drawing dimension;
   arithmetic that mirrors the drawing goes into the dimension: a radius as `d_flange/2`, a
   chained height as `t_flange+h_barrel`, a remainder as `h_total-h_step`. Do not precompute:
   a reader must find the drawing's own value in the model. `[community, 8 authors]` type such
   arithmetic straight into the field (typed names occur in only 2 of 219 non-library parts;
   named masters stay our rule for what Claude builds); `[verified]`
   `nx-solid-features/scripts/flanged_housing.py`.
4. **Read threads as tap-drill holes**: "M10" is a dia 8.5 cylinder with a symbolic thread and,
   when the drawing shows a second ring, a start chamfer to the nominal diameter
   (`nx-solid-features`, HolePackage) `[bench]` `[verified]`.
5. **Feature copies, booleans inside the feature, local blends with their feature** (sections
   2 and 3 say when), and the feature budget of section 0 as a check on the plan.
6. **Worked examples.** When the benchmark harness is present, its `harness\golden\` folder
   holds high-scoring parts built from drawings, each with plan, journal, part, STEP and
   checks (`golden\README.md` lists them with their scores): read one of the same kind before
   planning. In the skills: `nx-solid-features/scripts/flanged_housing.py` (housing) and the
   turned knob in `examples/`.

## 2. Choosing the base shape (class A and D)

| The shape is... | Build it as | Evidence |
|---|---|---|
| axisymmetric (knob, bush, bottle, pulley, flange) | one **Revolve** of a closed half-profile about a datum axis; grooves as Revolve-Subtract | `[mined]` 129 revolves in 78 parts, 114 are full 0-360, early in the tree (median position 0.29); `[verified]` |
| prismatic | sketch on a datum plane -> **Extrude**; one region per feature | `[mined]` 774 of 1 477 extrudes select a sketch region (RegionBoundary); only 258 use dumb curves |
| a constant-wall housing, cover, tray, cap | model the **outside** as a solid, then **Shell** (never model inner and outer walls separately) | `[mined]` parent of a Shell is an Extrude in 63 of 114; `[course]` "an L or thin-wall profile comes from Block -> Shell" |
| a thick-walled cast or machined housing of revolution (valve body, bearing housing, pump casing, flanged cone) | **ONE Revolve** of a closed half-profile that already contains the cavity; ports and bosses from datum planes outside the body with Extrude Until Selected / Until Next; no Shell | `[community, 3 authors]` 3 of 4 opened housings; Shell in none of 12 valve / housing folders; `[verified]` `nx-solid-features/scripts/flanged_housing.py`, `housing_rules.py` |
| symmetric about a plane | model **half**, then **Mirror Geometry** + Unite (finish the half first: the mirror is a snapshot) | `[mined]` Mirror Geometry 335x in 100 parts vs Mirror Feature 28x; a Unite follows within three features 186 times; `[verified]` |
| the same detail repeated | one detail + **Pattern Feature** (holes) or **Pattern Geometry** + boolean (bodies). On a part from a drawing: Pattern / Mirror **Feature** of the whole set - the boss, its own blend, its hole | `[mined]` the user copies bodies (Mirror Geometry 335 vs Mirror Feature 28; Pattern Geometry 97 vs 35); `[community]` feature copies: Mirror Feature 8 authors vs Mirror Geometry 1, Pattern Feature 9 vs 5; `[cast]` feature copies in 26 of 121 Siemens models, body copies in 2; `[verified]` count-driven update both ways, Pattern Feature of [Extrude, Edge Blend] 4 -> 6. After EVERY feature copy run `copy_check` (`nx-patterns-and-body-ops` section 1): three measured failures are silent |
| a constant section along a path | **Sweep Along Guide** (sharp corners allowed, exact faces) or **Tube** for round sections | `[mined]` Tube 153, Sweep Along Guide 45, Swept 32; `[course]` Swept fails on sharp-cornered guides |
| a transition between different sections | **Through Curves** (sections) / **Through Curve Mesh** (sections + guides) | `[course]` capability ladder Ruled -> Through Curves -> Mesh |
| a blade set: impeller, propeller, fan, turbine wheel | hub by Revolve; ONE blade (thin: helix + Swept oriented by the axis + Thicken; profiled: Through Curves over station sketches), copy the blade BODY, unite, root blends | `[verified]` `nx-surface-modeling`, section "Blades and blade sets" (4 journals, helper `nxblade.py`) |
| a profile given by an equation: involute gear, cam, spiral | master expressions (module, teeth, pressure angle) -> Law Curves by equation -> one tooth body -> pattern, one Unite; optional features switched by Boolean expressions | `[verified]` `nx-curves-and-sketches` section 6 and recipe 40 (`law_curve_gear.py`); `[community, 1 author]` |
| a port or boss inclined to the principal planes | skeleton line or datum axis -> angled datum plane -> sketch -> Extrude along the plane's own normal (associative direction) Until Selected; its bolt circle patterned about the port's datum axis | `[verified]` `nx-curves-and-sketches/scripts/inclined_port.py`; `nxf.extrude_ex(vec=<plane>)`, `nxf.pattern_circular(vec=<datum axis>)`; `[community]` two opened parts |
| prismatic with ONE curved or freeform top / side | extrude the plan outline as a full block, extrude or build the curved face as a SHEET wider than the block, **Trim Body** - do not draw the side profile into the base sketch; the sheet stays, hidden | `[cast efmg, efmd, efmq / stapler housing]` Trim Body 27 times in 15 Siemens models, parents Extrude + sheet; `[verified]` `nx-patterns-and-body-ops` (Trim Body with sheets), surfaced-grip example |
| simple blocks and cylinders only | primitives with booleans are fine for quick, non-critical bodies | `[course]` "no sketches today"; but a design-critical profile belongs in a constrained sketch |

**Shell or cavity in the profile?** Shell when the inside is an offset of the outside: one
constant wall everywhere, thin against the part (moulded, printed, die-cast). Draw the cavity
into the Revolve profile when the drawing gives it by its own diameters and depths (bores,
steps, seats), when flanges or end walls stay solid (the wall varies), or when the wall is
thick against the part. `[verified]` the same flanged housing both ways (wall 15 on a dia 80
barrel): the Shell makes a straight bore and loses the bore step (9 % of the volume wrong) and
ties the bore to the outside diameter; with a wall of 5 it also hollows the flange. The two
verified end points are a wall of 2-2.5 on an 80 x 60 x 30 tray (Shell) and 15 on a dia 80
barrel (profile); between them decide by the first two criteria, not by a ratio.

**Boolean: inside the feature or a separate one?** For a new part the default is the boolean
INSIDE the feature (Extrude / Revolve / Cylinder with Unite or Subtract) - one step instead of
two. A separate Unite / Subtract feature is right when the bodies are built apart on purpose:
a tool body that is mirrored, patterned, linked or offset first, a half that is mirrored, a
tool that is kept. `[verified]` a plate with two bosses: 3 steps inside, 5 with one Unite per
boss, 4 with one Unite of both; same volume. `[community]` inside the feature in 53 % of 282
extrudes - always for the two authors on NX 2206 / 2027; one Unite per body is one NX 10
author's habit (104 Unite features). `[cast]` 137 of 258 Siemens Extrudes carry their boolean;
the 44 separate booleans always join ONE tool built apart (a mirrored half: original = target,
copy = tool). `[mined]` the user builds bodies apart (Create 68 % of
extrudes, 1 721 separate booleans) because the user thinks in tool bodies and mirrored halves:
keep that for the user's own parts.

Bodies to be united must share **volume or a whole face**: face-to-face contact (a half model and
its mirror meeting on the symmetry plane) unites cleanly, but bodies that are disjoint or touch
only along an edge, a point or a tangent line fail **silently** - no error, the feature simply
owns two bodies `[verified]`. `nxh.unite` raises in that case. The same happens INSIDE an
Extrude: a boss extruded by a typed length that only reaches the crest of a round wall stays a
loose body with no error `[verified]` - use End = Until Selected / Until Next there.

## 3. Feature order

Canonical order for a moulded / cast / printed part (`[mined]` + `[cast]` + `[verified]`; the
user's course states no order rule, Siemens' parts and projects follow this one):

```
1  Datum CSYS first; named datum planes / axes for interfaces and centre lines; master expressions
2  base solid(s): Revolve / Extrude / united primitives          (median tree position 0.3-0.4)
3  main Draft of the outside walls
4  large structural Edge Blends (radius > wall)                   (they must survive the shell offset)
5  Shell                                                          (0.36)
6  Split Body into halves if it is a two-part housing; Delete Body for scrap
7  bosses, pockets, cut-outs; linked neighbour bodies subtracted / united   (booleans 0.57)
8  Ribs (sketch on a datum plane)                                 (0.70)
9  Holes (Hole feature on sketch points), then Pattern / Mirror   (0.64)
10 general Edge Blends and Chamfers, largest radius first         (0.61-0.67)
11 Threads (symbolic unless the helix must be printed)            (0.77)
```
- Shell comes before Rib in 8 of 8 of the user's parts and before holes in 19 of 20; 274 of 334
  blends in shelled parts come after the shell, the 60 before it are the big corner radii.
- `[cast, 121 models]` Siemens' own parts: the first Draft before the first Shell in 8 of 11
  models that have both (the 4 later drafts taper later bosses), a blend before the first Shell
  in 14 of 17, holes after the Shell in 8 of 8 (0 before, 21 after); the Shell sits at 0.44 of
  the tree and is the last row in only 6 of 21.
- **The reason for each step, measured** (`nx-solid-features/scripts/moulded_order.py`, 80 x 60 x
  30 box, wall 2) `[verified]`: blend then Shell - the Shell offsets the blend, inside radius =
  R - wall, corner wall 2.000; Shell then blend - the same radius is refused, a smaller one leaves
  sharp cavity corners and a 2.06 - 2.21 corner wall. Draft then Shell - both faces of the wall
  taper, wall 2.000; Shell then draft - only the outside tapers, the wall runs 2.000 -> 1.022.
  Hole then Shell - the Shell walls the hole in (a chimney up to the rim, no error). A blend
  forgotten before the Shell goes in at the insert point before the Shell, not onto the shelled
  wall `[cast efme]`.
- **Where blends go.** Three kinds, three places:
  1. structural blends that must survive a Shell or carry a Draft: early (step 4);
  2. the blend that **belongs to one boss, rib, lug, port or pocket**: directly after that
     feature (inside steps 7-8), and INTO the Pattern / Mirror Feature set with it when the
     feature is repeated;
  3. general blends that run across several features, and cosmetic edge breaks: last (step 10),
     largest radius first.
  One radius per Edge Blend feature in all three (`[mined]` 99 %, `[community, 7 authors]` 97 %
  of 91). Evidence for 2: `[verified]` `housing_rules.py` R4 - a lug with a root blend, count
  4 -> 6: patterned together gives 6 blended lugs; patterned alone and blended afterwards in
  one feature gives 6 lugs of which 2 stay unblended, without an error. `[community]` an Extrude
  is directly followed by its Edge Blend in 20 parts of 4 authors; blends sit at 0.41-0.47 of
  the tree for 3 of 6 authors, the other 3 put all of them after the last base feature.
  `[cast]` settles it for parts from a drawing: `Extrude > Edge Blend` directly adjacent 33
  times in 27 of 62 Siemens models with blends; 103 of 238 blends and chamfers come BEFORE the
  last base feature; feature groups boss = [Extrude, Edge Blend, Hole] as mirror input. Edges
  of different radius that meet at a vertex share one feature as separate sets `[cast efme]`.
  **The user's own parts keep blends late** (`[mined]` median position 0.67, radii decreasing
  in 106 of 147 parts): when extending the user's part, or building in the user's body-copy
  style (blend the half, then Mirror Geometry), follow that. Kind 2 is for native parts built
  from a drawing with Pattern / Mirror Feature.
- **"Last" never means "optional".** On a part built from a drawing every blend and chamfer the
  drawing shows, including a general note (all edges R0.5, R2 TYP, break sharp edges), is part
  of the shape and is built. `[bench]` sharp edges where the truth is blended cost surface score
  even at a volume overlap of 1.000 (block with R0.5 on all edges against the sharp block: F1
  0.649; any edge break, also a chamfer in place of a refused blend, recovers nearly all of it;
  1.0 point over 17 fixtures of the first run). If a blend is refused, fall back - smaller radius,
  single edges, chamfer - with `nxf.blend_chains` / `nxf.break_edges` (`nx-solid-features`), and
  write into the plan what was built instead of the nominal radius.
- Before changing a blend radius in somebody else's tree, check what was built on it:
  `[community]` later sketches reference blended edges in 10 sketches of one project.
- Step 3 is `[cast]` + `[verified]`, not a habit of the user: the user's 108 drafts are mostly
  local or on imported bodies (median position 0.51). Draft before Shell because a draft applied
  after the shell tapers only one side of the wall; a blend must be larger than the wall to
  survive the shell offset; a rib needs the finished inner walls to cap against. When ALL walls
  taper from the sketch plane, put the draft into the base Extrude (one feature; `[cast]` 50 of
  258 Siemens Extrudes; `[verified]` same body).
- For machined parts drop steps 3-6; for turned parts step 2 is one Revolve and most detail is
  grooves, chamfers and threads. Machined or cast part from a drawing `[community, 3 authors,
  4 housings]` + `[verified]` `flanged_housing.py`: base (hollow Revolve or Extrude) -> per boss
  or port: datum plane, sketch, Extrude, its own blend -> bores and holes -> Pattern / Mirror
  Feature -> general fillets -> edge chamfers -> threads. (The community parts could not test
  the moulded order - 3 Shells and 4 Drafts in 51 opened parts; Siemens' parts do, see above.
  They hold no thick-walled housing of revolution and no Rib feature, so the hollow-profile rule
  and the rib step rest on `[community]` + `[verified]` and `[mined]` + `[verified]` as before.)
- **Symmetric part built as a half** `[verified, acceptance build]`: do steps 2-9 on the half
  (the Shell removes the open face AND the symmetry-plane face, so the cavity is open towards
  the mirror), then Mirror Geometry + Unite (tool = the mirror feature via the body-feature
  rule), then everything that crosses or closes around the symmetry plane: rim lips made with
  Divide Face on the now-closed rim loop, centred cut-outs, features that exist on one side
  only. The mirror is a snapshot of the half at its timestamp - nothing added to the half later
  appears in the copy.
- Surfacing order `[course]` + `[mined]`: curves -> reference patches -> constrained patch between
  them (G1/G2 needs an existing neighbour) -> Extend -> Trim -> Sew one joint at a time -> blend
  the quilt -> Thicken or close and Sew to a solid, last.

## 4. Sketches and parameters

- **What Claude creates is fully constrained** (`nxf.finish_sketch` = `WellConstrained`, DOF 0,
  `auto_dims` 0 on a sketch made with `nxf.new_sketch`; a bare `GetStatus()` says 0 for any sketch
  while Continuous Auto Dimensioning is on, the batch default - `nx-journal-core` section 5) and
  driven by named expressions `[course: "do not go to the solid before the sketch is fully
  defined"]`. Locate the profile from the sketch origin first, then size it.
- Sketch X follows the model X; put the sketch origin on the part datum or a symmetry centre; if
  the sketch position may change, sketch on a **datum plane**, not directly on a face `[course]`.
- Pull existing geometry into a sketch with Project / Intersection curves instead of retyping
  numbers `[course]`; 64 % of the user's sketches sit on body faces `[mined]`.
- One sketch per functional element; keep blends, chamfers and holes as features, not sketch
  detail (the user's blends: 3 873 features; holes: Hole feature on sketch points). A profile
  and the points or construction loop that belong to it may share a sketch, each feature then
  picking its curves by rule (`[cast]` 59 of 274 Siemens sketches feed two or more features;
  `[community]` 7 %). **A sketch that feeds a second feature must be EXTERNAL**: ours are
  (`nxf.new_sketch`); in a part where it is internal to its first feature (`[cast]` 115 of 298
  sketches), call `owner.MakeSketchExternal()` first. A journal can use an internal sketch
  without an error, but the tree then hides what the second feature depends on `[verified]`
  `nx-solid-features/scripts/cast_checks.py` B6.
- **Design intent goes into references, not into numbers** `[cast eesc, efmb, efmc, efmf, efmq]`:
  1. *Position from the Datum CSYS and from named datum planes, never from the WCS.* The Datum
     CSYS is the first feature (104 of 121 Siemens models) and there is ONE at the top level;
     further references are relative datum planes (113 in 56 models: offset 58, bisector 14,
     angle 10), named when they carry intent - a housing gets its interface and centre-line
     planes, named, BEFORE the first sketch (the compressor housing: nine planes, two axes).
     Reference a datum rather than a face that a later edit may remove.
  2. *Tie a limit to the face it means.* "Through", "up to that face", "between these walls" =
     Through All / Until Selected / Until Extended, not today's thickness typed as a value:
     `[verified]` a typed cut through a 10 mm flange is silently blind when the flange becomes 14
     (`moulded_order.py` O6); `[cast]` 55 of 258 Siemens Extrudes end on geometry.
  3. *Place by what must stay.* Concentric = on the arc centre; with an edge = distances from
     that edge; central = bisector planes or `len/2`, not a typed half-value; equal = one
     expression or an equal constraint, not the number twice.
  4. *List the intent before modelling and prove it at the end*: what must be variable (the
     MASTERS), what must stay central or with an edge (DATUMS), then edit each once (REGEN).
- **House-style caveat** `[mined]`: the user rarely names expressions (47 of 577 parts have any
  name a person typed; an earlier figure of 117 counted NX's own `p12_x`, `ASSO_BLEND_n` and
  pattern names) and leaves 63 % of 2 834 sketches under-constrained (68 % carry no dimension),
  typing numbers directly. The third-party authors do not name them either (`[community]` 2 of
  219 non-library parts); Siemens teaches named drivers and uses them in 24 of 118 of its
  modelling parts and in 17 of 22 parts of its expression courses (`[cast eexa]`: drivers
  first, then point the feature expressions at them, a comment on each; never address a system
  expression by its p-number - it differs from session to session, find it through the owning
  feature). So named masters are a taught practice that most parts you open will not show, and
  OUR rule because an agent's model must be editable and checkable by expression. Claude's own models
  still get named masters and constrained sketches (an agent-built model must be editable by
  expression); when **editing the user's part**, do not rename, re-constrain or reorganise what
  is already there - add features in their style.

## 5. The user's house style: hybrid direct modelling `[mined]`

The user does not go back and re-sketch. After the base and the shell, the design is developed
with face edits and linked geometry. Reproduce this when extending their parts, and use it
whenever the alternative is rewriting upstream sketches:

| Idiom (tree excerpt) | Meaning |
|---|---|
| `EXTRUDE > SHELL > OFFSET_REGION xN > REPLACE_FACE` | tune walls and clearances by face, typical 0.1-3 mm |
| `LINKED_BODY > SUBTRACT` (136x) / `LINKED_BODY > UNITE` (71x) | cut clearance for, or merge, a neighbouring component linked from the assembly |
| `LINKED_FACE > REPLACE_FACE` (147x) | make a wall end exactly on the mating part's face |
| `OFFSET_IN_FACE > DIVIDE_FACE` (212x) `> OFFSET_REGION` (304x) | raise or sink a land / lip / step inset from a face boundary |
| `TRIM BODY > Geometry Instance (mirror) > UNITE` | half model, mirror, join |
| `SPLIT BODY > Delete Body`, `SPLIT BODY > SHELL` | cut a body into parts; closed shell split into two halves |
| `DELETE FACE > ... > BLEND` | strip blends, edit, re-blend |
| `BREP > DELETE FACE > OFFSET_REGION > Resize Face > HOLE PACKAGE` | de-feature an import, re-dimension, add native features |
| `Pattern Geometry > SUBTRACT` | repeated cut-outs as tool bodies |

Synchronous features are 9 068 of the user's 46 631 features, in 357 of 639 parts (Replace Face
3 518 and Offset Region 2 862 are the 3rd and 6th most used feature types). They are normal, time-stamped history features
in this style. It is the user's own: `[community]` 6 of 14 other authors use any synchronous
feature, in 11 of 225 parts (4.9 %) and 0.46 % of all feature rows - on imported bodies and as
rare late fixes. So: house style for classes B and C and for edits of existing bodies; none
in a new part built from a drawing (section 1a).

**Editing one of the user's existing parts**: copy it, run `inspect_part.py` and follow
`nx-journal-core/references/existing-parts.md` first - which body is the product, what is
suppressed, which links are broken, how to compare the feature state before and after. A
change to an early dimension of a hybrid tree can break a dozen later face edits (measured: +0.5
on an early blend radius broke 11 features of a watch housing); when it does, make the change as
a synchronous edit at the end of the tree, as the user would.

**Parametric edit or synchronous edit?**
- You built the body and a sketch/expression controls the face -> change the expression.
- No parameter controls it (import, face produced by a boolean/shell/mirror), or changing the
  sketch would ripple through many dependants -> synchronous edit, driven by a named expression.
- A face must follow another part -> link the face and Replace Face to it.

## 6. Imported bodies: first five minutes `[course]` + `[verified]`

1. Check what arrived: solid or sheet, body count, units (the course's sample parts are inch).
2. `nxh.examine_geometry(part, body)` - a healthy solid reports zero everywhere; an open body
   reports `BodySheetBoundaries` > 0. Patch a missing face (extrude the open edge as a sheet or
   Bounded Plane) and Sew until it is a solid.
3. Census: `nxh.hole_census(part, body)` - real holes vs bosses vs blends (most cylinders of an
   import are blends), with diameter, axis and length.
4. Optimize Face only if faces are fragmented: it merges split faces but re-types faces, can move
   the volume in the 1e-6 range and strips parameters - never on a body whose history matters.
5. De-feature what is in the way (Delete Face on holes and blends - select every face of the
   feature: wall, countersink, chamfer), then edit, then re-apply blends. Pick faces by geometry
   with a tolerance of ~0.01 on imports.
6. Add new native features (Hole, Edge Blend, Chamfer, Thread) on top.

## 7. Verification is part of the plan

After every feature: the planned number (volume vs analytic value, face position, wall
thickness, solid count). Where no closed form exists (draft + blend + shell together) check the
exact things instead - the volume **delta** of each added feature (a boss, a rib, a hole, a cut
are exact even on a complicated body), point-on-face probes at designed coordinates, wall and
angle measurements - and give whole-body volumes a stated tolerance (see `nx-journal-core` §5). After the last feature: `feature_errors` empty, Examine Geometry clean,
regeneration test on the masters with a round trip back to nominal, STEP re-read. See
`nx-journal-core` section 5. A model that was never regenerated is not parametric.

## 8. Worked plans (short form)

- **Moulded tray** `[verified: nx-solid-features/scripts/molded_tray.py]`: masters `len, wid, hgt,
  wall_t, draft_a, r_corner, rib_t` -> Block/Extrude outside -> Draft walls (stationary = rim,
  pull -Z) -> Edge Blend corners (r > wall) -> Shell (remove top) -> sketch on mid datum plane ->
  Rib -> small blends. Checks: volume after each step; wall = `min_dist(outer, inner)`; regen
  wall 2 -> 2.5, draft 2 -> 3. The stationary face is where the drawing dimensions the part:
  dimensioned at the rim -> stationary = rim, pull -Z; dimensioned at the bottom (larger at the
  open top) -> stationary = bottom face, pull -Z, positive angle (sign table in `nx-solid-features`).
- **Vessel with holes in the floor** `[cast efmq / Create a vessel]` `[verified:
  nx-solid-features/scripts/moulded_order.py O4]`: intent first - diameter, height, wall, hole
  diameter, hole radius and hole count must be variable -> masters `d_out, h_out, r_floor, wall,
  d_hole, r_holes, n_holes` -> Cylinder / Extrude on the Datum CSYS -> Edge Blend `r_floor` on
  the floor edge -> Shell `wall` (top removed) -> ONE Hole on the floor at `r_holes` on the X
  axis, Through Body -> Pattern Feature circular about the Datum CSYS Z axis, `n_holes`. Checks:
  volume 7 963 008.29 = closed form, inside floor radius = `r_floor - wall`, hole count; regen
  wall 10 -> 8, holes 4 -> 6. Three more of Siemens' project plans (pivot plate, stapler housing,
  mitre housing) and its thin-walled part, with what each teaches: `references/cast-project-plans.md`.
- **Symmetric enclosure half with lip** `[verified: acceptance build, 157 checks, first run]`:
  half sketch -> Extrude -> Draft -> Edge Blend corners -> Edge Blend floor -> Shell (top +
  symmetry face removed) -> boss Cylinders (Unite) -> datum plane + sketch -> Rib -> Hole
  feature on points -> Mirror Geometry -> Unite -> Offset Curve in Face + Divide Face on the
  rim -> Offset Region (`-lip_drop`) -> notch sketch -> Extrude Subtract.
- **Flanged housing with two ports** `[verified: nx-solid-features/scripts/flanged_housing.py,
  51 checks, 18 steps]`: masters = the drawing's diameters and heights -> hollow half-profile
  sketch (DOF 0, radii as `d/2`, height as a sum) -> Revolve -> per port: offset datum plane
  outside the body, circle sketch, Extrude Until Selected / Until Next with Unite, root blend,
  port bore as a Hole Until Selected (main bore face) -> one M8 threaded Hole with start and end
  chamfer + Pattern Feature (`n_bolt`) -> four M6 blind threaded holes as one feature -> flange
  fillet -> edge chamfers. Checks: exact volume delta of every feature (cylinder-to-cylinder
  volumes by a one-line integral), tap-drill cylinders 6.8 / 5.0 and no cylinder at 8 or 6,
  regeneration of port length, bolt count, bore and barrel diameter, STEP through the gate.
- **Turned knob** `[verified: acceptance build, 64 checks, first run]`: profile sketch (bore
  included) -> Revolve -> groove sketch -> Revolve Subtract -> Cylinder Subtract (one flute) ->
  Pattern Feature circular (count expression) -> Chamfer.
- **Turned bush with O-ring groove** `[verified]`: half-profile sketch on XZ, fully constrained ->
  Revolve 360 about Z -> Revolve-Subtract groove (profile overshoots the surface) -> Chamfers ->
  symbolic Thread. Check volumes against Pappus.
- **Two-part enclosure around a PCB** `[mined]` idiom, `[verified: acceptance build 3, 239 checks]`:
  assembly with the PCB fixed and the master expressions (envelope = board + 2 x (gap + wall)) ->
  in each part file (base, lid): envelope sketch -> Extrude -> corner blends -> closed Shell ->
  datum plane at the split height -> Split Body -> Delete Body of the other half -> WAVE-link the
  PCB face / connector / button bodies -> bosses and Hole features on arc-centre points of the
  linked hole edges -> Offset Region on the linked body copies for clearance -> Subtract ->
  tongue (base) and groove (lid) by Offset Curve in Face + Divide Face + Offset Region -> small
  outside blends. Then the associativity test: move the PCB holes, the button and the board
  size; everything must follow. In ONE multi-body part file the user's own variant is the same
  up to the split, keeping both halves as bodies. Details: `nx-assemblies` section 3.
- **Imported bracket, move a hole pattern and thicken a wall** `[verified]`: Examine Geometry ->
  Delete Face (old holes) -> Offset Region on the wall (+t, named expression) -> new Hole feature
  + Pattern Feature -> Edge Blend. Checks: volume delta = area x distance is exact for Offset
  Region between prismatic neighbours; when blends or tapered neighbours follow the face (Replace
  Face on a blended side moved 28 % more volume than area x distance in the acceptance build)
  check the face position, the blend count and radii, and Examine Geometry instead.
- **Imported bracket, acceptance build** `[verified, 33 checks]`: STEP242 import -> Examine
  Geometry -> hole census -> Delete Face (2 countersunk holes, 6 faces) -> Offset Region base
  (`base_add`) -> Resize Face bore (`bore_d`) -> datum plane + Replace Face side (`side_add`) ->
  Hole feature + Chamfer -> regeneration of all three expressions -> STEP round trip.
- **Surfaced grip, acceptance build** `[verified, 68 checks]`: associative line/arc sections on
  expression-driven planes -> Through Curves solid (starts aligned, twist test) -> spline mesh ->
  Through Curve Mesh -> Extend Sheet -> Trim Body of a block -> Shell; sheet Revolve -> Bounded
  Planes -> Sew to solid; G0 vs G1 loft joints measured with `nxh.g1_deviation`.
- **Smooth transition between two tubes** `[course]`: end patches / existing faces -> Through
  Curves with G1 at both ends (sections picked at corresponding points, arrows aligned) or Face
  Blend between the bodies -> Bounded Plane on the openings -> Sew to a solid. Check G1 by
  comparing normals across the shared edge; free-edge count 0.

## 9. Where the rest lives

`nx-journal-core` (run, helper, selection rules, verification) - `nx-curves-and-sketches` -
`nx-solid-features` - `nx-patterns-and-body-ops` - `nx-surface-modeling` -
`nx-synchronous-modeling` - `nx-assemblies` - `nx-reverse-engineering` - `nx-sheet-metal` -
`nx-drafting` (drawings of the finished model).
Evidence behind this file: `references/user-practice-overview.md`, `references/course-method.md`
and `references/cast-project-plans.md` (Siemens' worked project parts as plans).
Complete verified builds for every job class (plan, journal, checks, regeneration, STEP):
`examples/README.md`.
