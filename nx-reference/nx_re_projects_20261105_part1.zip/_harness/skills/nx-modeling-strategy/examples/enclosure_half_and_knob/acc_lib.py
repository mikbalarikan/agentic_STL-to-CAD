"""Recipes copied from the nx-* skills (acceptance test). Nothing here comes from outside the skills folder."""
import math
import os

import NXOpen
import NXOpen.Features
import NXOpen.GeometricUtilities
import nxh

P, V, UPD, S, UFS, BOOL = nxh.P, nxh.V, nxh.UPD, nxh.S, nxh.UFS, nxh.BOOL
SK = NXOpen.Sketch
A = SK.AssocType
CP = SK.ConstraintPointType
NULL = NXOpen.NXObject.Null
GU = NXOpen.GeometricUtilities
PAT = GU.PatternDefinition.PatternEnum
SPACE = GU.PatternSpacing.SpacingType
BT = NXOpen.Features.Feature.BooleanType


# ------------------------------------------------------------- sketches (nx-curves-and-sketches/scripts/sketch_recipes.py)
def new_sketch(part, plane, haxis, origin, name):
    # Continuous Auto Dimensioning off BEFORE the sketch is created: with it on (the batch default) GetStatus() reads
    # WellConstrained / 0 for any sketch, so the "fully constrained" checks would prove nothing (nx-journal-core section 5).
    S.Preferences.Sketch.ContinuousAutoDimensioning = False
    sb = part.Sketches.CreateSimpleSketchInPlaceBuilder()
    try:
        sb.UseWorkPartOrigin = False
        d = part.Directions.CreateDirection(haxis, NXOpen.Sense.Forward, UPD)
        xf = part.Xforms.CreateXformByPlaneXDirPoint(plane, d, origin, UPD, 0.625, False, False)
        sb.CoordinateSystem = part.CoordinateSystems.CreateCoordinateSystem(xf, UPD)
        sb.HorizontalReference.Value = haxis
        sk = sb.Commit()
    finally:
        sb.Destroy()
    sk.Activate(SK.ViewReorient.FalseValue)
    sk.SetName(name)
    sk.Feature.SetName(name)
    return sk


def cg(geom, pt=None, idx=0):
    g = SK.ConstraintGeometry()
    g.Geometry = geom
    g.PointType = pt if pt is not None else CP.NotSet
    g.SplineDefiningPointIndex = idx
    return g


def dg(geom, assoc=None, hp=None):
    d = SK.DimensionGeometry()
    d.Geometry = geom
    d.AssocType = assoc if assoc is not None else A.NotSet
    d.AssocValue = 0
    d.HelpPoint = hp if hp is not None else P(0, 0, 0)
    d.View = NXOpen.NXObject.Null
    return d


def add(sk, *curves, infer=True):
    opt = SK.InferConstraintsOption.InferCoincidentConstraints if infer else SK.InferConstraintsOption.InferNoConstraints
    for c in curves:
        sk.AddGeometry(c, opt)


def pdim(sk, ref, ref_help, geom, assoc, origin, formula):
    c = sk.CreateDimension(SK.ConstraintType.PerpendicularDim, dg(ref, None, ref_help), dg(geom, assoc), origin,
                           NXOpen.Expression.Null)
    c.AssociatedExpression.RightHandSide = formula
    return c


def auto_dims(sk):
    """Automatic dimensions NX added to close open degrees of freedom (0 in a sketch created with the preference off)."""
    n = 0
    for c in sk.GetAllConstraintsOfType(SK.ConstraintClass.Dimension, SK.ConstraintType.NoCon):
        st = getattr(c, "DimensionState", None)
        if st is not None and st == type(c).DimensionStateType.Automatic:
            n += 1
    return n


def status_of(sk):
    st, dof = sk.GetStatus()
    n_auto = auto_dims(sk)
    if n_auto:                                          # each automatic dimension hides one open degree of freedom
        return "UnderConstrained", dof + n_auto
    name = [n for n in nxh.enum_names(SK.Status) if getattr(SK.Status, n) == st]
    return (name[0] if name else str(st)), dof


def finish(sk):
    sk.Update()
    try:
        sk.CalculateStatus()
    except Exception:  # noqa: BLE001
        pass
    status, dof = status_of(sk)
    n_auto = auto_dims(sk)
    sk.Deactivate(SK.ViewReorient.FalseValue, SK.UpdateLevel.Model)
    return {"status": status, "dof": dof, "auto_dims": n_auto, "n_geom": len(sk.GetAllGeometry()),
            "dims": [f"{e.Name}={e.RightHandSide}" for e in sk.GetAllExpressions()]}


def hv_polygon(part, sk, pts, to3d):
    """Closed polygon of alternating H / V lines; pts are 2D sketch coordinates, to3d maps to absolute."""
    n = len(pts)
    ls = [part.Curves.CreateLine(to3d(*pts[i]), to3d(*pts[(i + 1) % n])) for i in range(n)]
    add(sk, *ls)
    for i, ln in enumerate(ls):
        (u0, v0), (u1, v1) = pts[i], pts[(i + 1) % n]
        if abs(v0 - v1) < 1e-9:
            sk.CreateHorizontalConstraint(cg(ln))
        else:
            sk.CreateVerticalConstraint(cg(ln))
    return ls


# ------------------------------------------------------------- solid features (nx-solid-features)
def draft_faces(part, faces, pull, angle, stationary_faces):
    DB = NXOpen.Features.DraftBuilder
    b = part.Features.CreateDraftBuilder(nxh.NULL_FEATURE)
    try:
        b.TypeOfDraft = DB.Type.Face
        b.AngleTolerance = 0.1
        b.DistanceTolerance = 0.01
        b.Direction = nxh.direction(part, pull)
        b.DraftReferencesMethod = DB.DraftReferencesMethods.StationaryFace
        b.StationaryReference.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(stationary_faces))], False)
        ecs = part.CreateExpressionCollectorSet(nxh.collector(part, faces=faces), str(float(angle)), "Degrees", 0)
        b.FaceSetAngleExpressionList.Append(ecs)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, f.GetExpressions()[0]


def shell(part, body, removed_faces, thickness, inward=True):
    b = part.Features.CreateShellBuilder(nxh.NULL_FEATURE)
    try:
        b.Tolerance = 0.01
        b.Body = body
        if removed_faces:
            b.RemovedFacesCollector = nxh.collector(part, faces=removed_faces)
        b.DefaultThickness.RightHandSide = str(thickness)
        b.DefaultThicknessFlip = bool(inward)
        return b.CommitFeature()
    finally:
        b.Destroy()


def rib(part, body, sketch, help_point, thickness, reverse):
    RB = NXOpen.Features.RibBuilder
    b = part.Features.DesignFeatureCollection.CreateRibBuilder(NXOpen.Features.Rib.Null)
    try:
        b.TargetBody.ReplaceRules([part.ScRuleFactory.CreateRuleBodyDumb([body], True)], False)
        sec = b.Section
        sec.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        sec.AddToSection([part.ScRuleFactory.CreateRuleCurveFeature([sketch.Feature])], NULL, NULL, NULL,
                         P(*help_point), NXOpen.Section.Mode.Create, False)
        b.RibType = RB.RibTypes.PerpendiculartoSectionPlane
        b.RibThickness.RightHandSide = str(thickness)
        b.RibThicknessOffsetOption = RB.RibThicknessOffsetOptions.Symmetric
        b.ReverseRibDirection = reverse
        b.CombineRibWithTarget = True
        return b.CommitFeature()
    finally:
        b.Destroy()


def hole(part, body, points, dia, depth, vec=(0, 0, -1), tip="0"):
    HPB = NXOpen.Features.HolePackageBuilder
    h = part.Features.CreateHolePackageBuilder(NXOpen.Features.HolePackage.Null)
    try:
        h.Type = HPB.Types.GeneralHole
        h.GeneralHoleForm = HPB.HoleForms.Simple
        h.GeneralSimpleHoleDiameter.RightHandSide = str(dia)
        h.GeneralSimpleHoleDepth.RightHandSide = str(depth)
        h.GeneralTipAngle.RightHandSide = str(tip)
        h.HoleDepthLimitOption = HPB.HoleDepthLimitOptions.Value
        h.Tolerance = 0.01
        h.StartExtensionEnabled = False
        h.BooleanOperation.Type = BOOL.Subtract
        h.BooleanOperation.SetTargetBodies([body])
        h.HolePosition.AddToSection([part.ScRuleFactory.CreateRuleCurveDumbFromPoints(points)], NULL, NULL, NULL,
                                    P(0, 0, 0), NXOpen.Section.Mode.Create, False)
        h.ProjectionDirection.ProjectDirectionMethod = GU.ProjectionOptions.DirectionType.Vector
        h.ProjectionDirection.ProjectVector = nxh.direction(part, vec)
        return h.CommitFeature()
    finally:
        h.Destroy()


def revolve(part, sec, ax, start, end, op=None, target=None):
    b = part.Features.CreateRevolveBuilder(nxh.NULL_FEATURE)
    try:
        b.Tolerance = 0.01
        b.Section = sec
        b.Axis = ax
        b.Limits.StartExtend.Value.RightHandSide = str(start)
        b.Limits.EndExtend.Value.RightHandSide = str(end)
        op = BOOL.Create if op is None else op
        b.BooleanOperation.Type = op
        if op != BOOL.Create:
            b.BooleanOperation.SetTargetBodies([target])
        return b.CommitFeature()
    finally:
        b.Destroy()


def axis_from(part, obj):
    d = part.Directions.CreateDirection(obj, NXOpen.Sense.Forward, UPD)
    return part.Axes.CreateAxis(NXOpen.Point.Null, d, UPD)


def chamfer(part, edges, offset):
    CB = NXOpen.Features.ChamferBuilder
    b = part.Features.CreateChamferBuilder(nxh.NULL_FEATURE)
    try:
        b.Option = CB.ChamferOption.SymmetricOffsets
        b.Method = CB.OffsetMethod.EdgesAlongFaces
        b.FirstOffset = str(offset)
        b.Tolerance = 0.01
        b.SmartCollector = nxh.collector(part, edges=edges)
        return b.CommitFeature()
    finally:
        b.Destroy()


# ------------------------------------------------------------- patterns and body ops (nx-patterns-and-body-ops)
def plane_from_datum(part, datum_plane, offset="0"):
    pl = part.Planes.CreatePlane(P(0, 0, 0), V(0, 0, 1), UPD)
    pl.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    pl.SetGeometry([datum_plane])
    pl.SetFlip(False)
    pl.SetReverseSide(False)
    pl.Expression.RightHandSide = str(offset)
    pl.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    pl.Evaluate()
    return pl


def mirror_geometry(part, bodies, datum_plane, offset="0"):
    before = list(part.Bodies)
    b = part.Features.CreateGeomcopyBuilder(nxh.NULL_FEATURE)
    try:
        b.Type = NXOpen.Features.GeomcopyBuilder.TransformTypes.Mirror
        b.MirrorPlane = plane_from_datum(part, datum_plane, offset)
        for body in bodies:
            b.GeometryToInstance.Add(body)
        b.Associative = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(part, before)


def boolean(part, op, target, tools=None, tool_features=None):
    b = part.Features.CreateBooleanBuilderUsingCollector(NXOpen.Features.BooleanFeature.Null)
    try:
        b.Tolerance = 0.01
        b.Operation = op
        b.Targets.Add(target)
        if tool_features:
            sc = part.ScCollectors.CreateCollector()
            sc.ReplaceRules([part.ScRuleFactory.CreateRuleBodyFeature(list(tool_features), True,
                                                                      NXOpen.DisplayableObject.Null)], False)
            b.ToolBodyCollector = sc
        else:
            b.ToolBodyCollector = nxh.collector(part, bodies=tools)
        return b.CommitFeature()
    finally:
        b.Destroy()


def pattern_circular(part, features, origin, vec, count, span="360"):
    b = part.Features.CreatePatternFeatureBuilder(nxh.NULL_FEATURE)
    try:
        ps = b.PatternService
        ps.PatternType = PAT.Circular
        cd = ps.CircularDefinition
        cd.RotationAxis = nxh.axis(part, origin, vec)
        cd.AngularSpacing.NCopies.RightHandSide = str(count)
        cd.AngularSpacing.SpaceType = SPACE.Span
        cd.AngularSpacing.SpanAngle.RightHandSide = str(span)
        b.PatternMethod = NXOpen.Features.PatternFeatureBuilder.PatternMethodOptions.Simple
        b.FeatureList.Add(list(features))
        return b.CommitFeature()
    finally:
        b.Destroy()


# ------------------------------------------------------------- synchronous (nx-synchronous-modeling)
def divide_face_offset(part, face, edges, dist, help_point, flip=False):
    b = part.Features.CreateDividefaceBuilder(nxh.NULL_FEATURE)
    try:
        b.FacesToDivide = nxh.collector(part, faces=[face])
        tool = b.SelectDividingObject
        tool.ToolOption = GU.SelectDividingObjectBuilder.ToolType.OffsetCurveInFace
        tool.CurvesToOffset.AddToSection([part.ScRuleFactory.CreateRuleEdgeDumb(list(edges))], edges[0], NULL, NULL,
                                         P(*help_point), NXOpen.Section.Mode.Create, False)
        tool.OffsetDistance.RightHandSide = str(dist)
        tool.OffsetDirection = flip
        return b.CommitFeature()
    finally:
        b.Destroy()


def offset_region(part, faces, distance):
    b = part.Features.CreateAdmOffsetRegionBuilder(NXOpen.Features.AdmOffsetRegion.Null)
    try:
        b.FaceToOffset.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        b.Distance.RightHandSide = str(distance)
        return b.CommitFeature()
    finally:
        b.Destroy()


# ------------------------------------------------------------- STEP (nx-journal-core/references/import-export.md)
def step_export(part, dest):
    if os.path.exists(dest):
        os.remove(dest)
    b = S.DexManager.CreateStepCreator()
    try:
        b.ExportAs = NXOpen.StepCreator.ExportAsOption.Ap242
        b.InputFile = part.FullPath
        b.OutputFile = dest
        b.LayerMask = "1-256"
        b.ObjectTypes.Solids = True
        b.FileSaveFlag = False
        b.ProcessHoldFlag = True
        b.BsplineTol = 0.001
        b.Commit()
    finally:
        b.Destroy()


def _step_import(part, stp_path, scratch_prt, factory, settings, info):
    before = {b.Tag for b in part.Bodies}
    imp = getattr(S.DexManager, factory)()
    try:
        info["members_" + factory] = sorted(nxh.builder_doc(imp).keys())
        if settings:
            imp.SettingsFile = settings
        imp.ImportTo = type(imp).ImportToOption.WorkPart
        imp.ObjectTypes.Solids = True
        imp.InputFile = stp_path
        imp.OutputFile = scratch_prt
        imp.FileOpenFlag = False
        imp.ProcessHoldFlag = True
        imp.Commit()
    finally:
        imp.Destroy()
    return [b for b in part.Bodies if b.Tag not in before]


def step_verify(out_dir, stp, name, log=None):
    """Text check + re-import into a scratch part; returns dict."""
    r = {"exists": os.path.exists(stp), "tries": []}
    if not r["exists"]:
        return r
    with open(stp, "r", encoding="utf-8", errors="replace") as fh:
        txt = fh.read()
    r["size"] = len(txt)
    r["manifold_solid_brep"] = txt.count("MANIFOLD_SOLID_BREP")
    r["closed_shell"] = txt.count("CLOSED_SHELL")
    r["advanced_face"] = txt.count("ADVANCED_FACE")
    m = [ln for ln in txt.splitlines() if "FILE_SCHEMA" in ln or "AP242" in ln.upper()]
    r["schema_lines"] = m[:4]
    r["dex_names"] = [n for n in dir(S.DexManager) if "tep" in n]
    step_dir = os.path.join(os.environ.get("UGII_BASE_DIR", r"C:\Program Files\Siemens\NX2206"), "STEP214UG")
    def214 = os.path.join(step_dir, "step214ug.def")
    scratch = nxh.new_part(os.path.join(out_dir, name + "_stepcheck.prt"))
    bodies = None
    for label, factory, settings in (("Step242Importer, no SettingsFile", "CreateStep242Importer", None),
                                     ("Step242Importer + step214ug.def", "CreateStep242Importer", def214),
                                     ("Step214Importer + step214ug.def (skill recipe)", "CreateStep214Importer", def214)):
        if not hasattr(S.DexManager, factory):
            r["tries"].append([label, "no such factory", None])
            continue
        got, err = nxh.attempt(label, _step_import, scratch, stp, os.path.join(out_dir, name + "_stepcheck_tmp.prt"),
                               factory, settings, r, log=log)
        r["tries"].append([label, err, len(got) if got is not None else None])
        if got:
            bodies = got
            r["import_route"] = label
            break
    bodies = bodies or []
    r["bodies"] = len(bodies)
    r["solid_bodies"] = len([b for b in bodies if b.IsSolidBody])
    if bodies:
        r["volume"] = sum(nxh.volume(scratch, b) for b in bodies if b.IsSolidBody)
        r["bbox"] = nxh.bbox(bodies[0])
        r["examine"] = nxh.examine_geometry(scratch, bodies[0])
    return r


class Checks(nxh.Check):
    def __init__(self, log):
        super().__init__()
        self.log = log

    def __call__(self, name, got, want, tol=1e-3):
        if got is None:
            self.rows.append({"name": name, "got": None, "want": want, "tol": tol, "ok": False})
            self.log("FAIL", name, "got None want", want)
            return False
        ok = super().__call__(name, got, want, tol)
        self.log("PASS" if ok else "FAIL", name, "got", round(float(got), 5), "want", round(float(want), 5), "tol", tol)
        return ok

    def true(self, name, cond, note=""):
        ok = super().true(name, cond, note)
        self.log("PASS" if ok else "FAIL", name, note)
        return ok
