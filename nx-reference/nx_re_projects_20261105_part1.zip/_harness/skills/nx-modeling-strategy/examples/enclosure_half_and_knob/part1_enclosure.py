"""Part 1 - moulded enclosure base (acceptance test of the nx-* skills). Half model -> mirror -> unite."""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
OUT = sys.argv[1]
sys.path.insert(0, OUT)
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import nxh  # noqa: E402
import acc_lib as L  # noqa: E402

P, BOOL, BT = nxh.P, nxh.BOOL, L.BT
log = nxh.Log(os.path.join(OUT, "part1.log"))
chk = L.Checks(log)
res = {"result": "FAIL", "notes": []}

NOM = dict(len_x=90.0, len_y=60.0, hgt=28.0, wall_t=2.0, draft_a=2.0, r_corner=8.0, r_floor=3.0, rib_t=1.5, rib_h=14.0,
           boss_d=7.0, boss_h=22.0, hole_d=2.6, hole_depth=10.0, lip_w=1.0, lip_drop=1.5,
           rib_x=18.0, boss_x=32.0, boss_y=20.0, notch_w=12.0, notch_d=6.0)


# ------------------------------------------------------------------ analytic model (independent of NX)
def expected(p):
    a = math.radians(p["draft_a"])
    t, c, s = math.tan(a), math.cos(a), math.sin(a)
    Lx, W, H, w = p["len_x"], p["len_y"], p["hgt"], p["wall_t"]
    R, rf = p["r_corner"], p["r_floor"]
    k = math.sqrt(1 + 2 * t * t)                       # 1 / cos(tilt of the corner edge)
    phi_c = math.pi - math.acos(s * s)                 # dihedral between two drafted walls
    phi_f = math.pi / 2 + a                            # dihedral floor / drafted wall

    def fil(r, phi):                                   # area between a corner of angle phi and its fillet
        return r * r * (1 / math.tan(phi / 2) - (math.pi - phi) / 2)

    def Ac(r):                                         # horizontal-section area removed by one corner blend (exact)
        return fil(r, phi_c) * k

    def i4xy(x0, y0, z0, z1):                          # integral of 4 (x0 + z t)(y0 + z t) dz
        F = lambda z: 4 * (x0 * y0 * z + (x0 + y0) * t * z * z / 2 + t * t * z ** 3 / 3)  # noqa: E731
        return F(z1) - F(z0)

    def floor_blend(r, lc, wc, rc):                    # APPROXIMATE at the four corners (Pappus with the 90 deg centroid)
        return fil(r, phi_f) * (2 * (lc + wc) - 8 * rc + 2 * math.pi * (rc - 0.2234 * r))

    e = {}
    e["block"] = i4xy(Lx / 2, W / 2, 0, H)
    e["after_corner"] = e["block"] - 4 * Ac(R) * H
    e["after_floor"] = e["after_corner"] - floor_blend(rf, Lx, W, R)
    xo, yo = Lx / 2 - w / c, W / 2 - w / c
    cav = i4xy(xo, yo, w, H) - 4 * Ac(R - w) * (H - w) - floor_blend(rf - w, 2 * (xo + w * t), 2 * (yo + w * t), R - w)
    e["shell"] = e["after_floor"] - cav
    e["boss_each"] = math.pi * (p["boss_d"] / 2) ** 2 * (p["boss_h"] - w)
    rh = p["rib_h"]
    e["rib_each"] = p["rib_t"] * (2 * (yo * (rh - w) + t * (rh * rh - w * w) / 2) - 2 * fil(rf - w, phi_f))
    e["hole_each"] = math.pi * (p["hole_d"] / 2) ** 2 * p["hole_depth"]
    d, lw = p["lip_drop"], p["lip_w"]
    XH, YH = Lx / 2 + H * t, W / 2 + H * t
    Re = R * (1 + k) / 2
    per = 4 * (XH + YH) - 8 * Re + 2 * math.pi * Re
    e["lip"] = i4xy(Lx / 2, W / 2, H - d, H) - 4 * XH * YH * d + d * (per * lw - math.pi * lw * lw)
    e["notch"] = p["notch_w"] * (p["notch_d"] * w / c - (d * lw - t * d * d / 2))
    e["half_done"] = e["shell"] / 2 + 2 * e["boss_each"] + e["rib_each"] - 2 * e["hole_each"]
    e["total"] = 2 * e["half_done"] - e["lip"] - e["notch"]
    e["XH"], e["YH"], e["t"], e["c"] = XH, YH, t, c
    return e


# ------------------------------------------------------------------ measurement
def planar(body):
    out = []
    for f in body.GetFaces():
        ty, _pt, n, _r = nxh.face_data(f)
        if ty == nxh.PLANE:
            out.append((f, n, nxh.bbox(f)))
    return out


def cyls(body, radius, tol=1e-3):
    return [f for f in body.GetFaces() if nxh.face_data(f)[0] == nxh.CYLINDER and abs(abs(nxh.face_data(f)[3]) - radius) < tol]


def measure(part, body, p, full=True):
    m = {"solids": len(nxh.solids(part)), "volume": nxh.volume(part, body), "bbox": nxh.bbox(body)}
    bb = m["bbox"]
    pl = planar(body)
    outer = [x for x in pl if x[1][1] > 0.9 and abs(x[2][4] - bb[4]) < 1e-3]
    if outer:
        fo, n, _ = outer[0]
        m["draft_deg"] = math.degrees(math.asin(abs(n[2])))
        inner = [x[0] for x in pl if all(abs(u + v) < 1e-6 for u, v in zip(n, x[1]))]
        m["wall"] = min((nxh.min_dist(fo, f) for f in inner), default=None)
    bot = [x[0] for x in pl if x[1][2] < -0.999]
    floors = [x for x in pl if x[1][2] > 0.999 and abs(x[2][2] - p["wall_t"]) < 1e-3 and abs(x[2][5] - p["wall_t"]) < 1e-3]
    m["n_bottom_faces"] = len(bot)
    if bot and floors:
        m["floor"] = min(nxh.min_dist(bot[0], x[0]) for x in floors)
    hs = cyls(body, p["hole_d"] / 2)
    m["holes"] = len(hs)
    if hs:
        m["hole_z"] = [min(nxh.bbox(f)[2] for f in hs), max(nxh.bbox(f)[5] for f in hs)]
        m["hole_xy"] = sorted([round(nxh.face_data(f)[1][0], 3), round(nxh.face_data(f)[1][1], 3)] for f in hs)
        m["hole_dia"] = 2 * abs(nxh.face_data(hs[0])[3])
    bs = cyls(body, p["boss_d"] / 2)
    m["bosses"] = len(bs)
    if bs:
        m["boss_top"] = max(nxh.bbox(f)[5] for f in bs)
    rx = sorted({round(x[2][0], 4) for x in pl if abs(x[1][0]) > 0.999 and abs(x[2][0] - x[2][3]) < 1e-4
                 and 10 < abs(x[2][0]) < 30 and x[2][5] < p["rib_h"] + 1e-3})
    m["rib_face_x"] = rx
    rt = [x for x in pl if x[1][2] > 0.999 and abs(x[2][2] - p["rib_h"]) < 1e-3 and abs(x[2][5] - p["rib_h"]) < 1e-3]
    m["rib_tops"] = len(rt)
    if rt:
        m["rib_span_y"] = [min(x[2][1] for x in rt), max(x[2][4] for x in rt)]
    if full:
        H = p["hgt"]
        low = [x for x in pl if x[1][2] > 0.999 and abs(x[2][2] - (H - p["lip_drop"])) < 1e-3 and abs(x[2][5] - (H - p["lip_drop"])) < 1e-3]
        top = [x for x in pl if x[1][2] > 0.999 and abs(x[2][2] - H) < 1e-3 and abs(x[2][5] - H) < 1e-3]
        m["lip_low_faces"], m["rim_top_faces"] = len(low), len(top)
        if top:
            m["rim_top_ymax_bbox"] = max(x[2][4] for x in top)
        if low:
            m["lip_low_ymax"] = max(x[2][4] for x in low)
        # step wall between the two rim bands: NX makes it an EXTRUDED face (UF type 20), not a plane, and the
        # bounding box of the band faces is padded, so probe it with point-to-face distances instead
        ext = [f for f in body.GetFaces() if nxh.face_data(f)[0] == 20]
        m["type20_faces"] = len(ext)
        ex = expected(p)
        zc = H - p["lip_drop"] / 2
        probes = {"+Y": (0.0, ex["YH"] - p["lip_w"], zc), "-Y": (0.0, -(ex["YH"] - p["lip_w"]), zc),
                  "-X": (-(ex["XH"] - p["lip_w"]), 0.0, zc)}
        m["lip_step_dist"] = {}
        for k, xyz in probes.items():
            ds = [(nxh.dist_to(part, f, xyz), f) for f in ext]
            if ds:
                dmin, fmin = min(ds, key=lambda t: t[0])
                m["lip_step_dist"][k] = dmin
                m.setdefault("lip_step_normal", {})[k] = [round(v, 6) for v in nxh.normal_at(fmin, xyz)]
        ny = sorted({round(x[2][1], 4) for x in pl if abs(x[1][1]) > 0.999999 and x[2][0] > 35 and abs(x[2][1] - x[2][4]) < 1e-4})
        m["notch_y"] = ny
        nb = [x for x in pl if x[1][2] > 0.999 and x[2][0] > 35 and abs(x[2][2] - (H - p["notch_d"])) < 1e-3 and abs(x[2][5] - (H - p["notch_d"])) < 1e-3]
        m["notch_floor_faces"] = len(nb)
    m["errors"] = nxh.feature_errors(part)
    return m


def check_full(tag, part, body, p, vol_tol=4.0):
    e = expected(p)
    m = measure(part, body, p)
    res["measure_" + tag] = m
    res["expected_" + tag] = {k: round(v, 4) for k, v in e.items()}
    chk(tag + ": solids", m["solids"], 1, 0)
    chk.true(tag + ": no feature errors", not m["errors"], m["errors"])
    chk(tag + ": volume vs analytic (floor-blend corners approximate)", m["volume"], e["total"], vol_tol)
    chk(tag + ": wall thickness (min_dist outer/inner +Y wall)", m.get("wall"), p["wall_t"], 1e-4)
    chk(tag + ": floor thickness", m.get("floor"), p["wall_t"], 1e-4)
    chk(tag + ": draft angle of +Y wall", m.get("draft_deg"), p["draft_a"], 1e-4)
    bb = m["bbox"]
    d = p["lip_drop"]
    chk(tag + ": bbox z max = hgt", bb[5], p["hgt"], 1e-3)
    chk(tag + ": bbox x max = len_x/2 + (hgt-lip_drop) tan(draft)", bb[3], p["len_x"] / 2 + (p["hgt"] - d) * e["t"], 2e-3)
    chk(tag + ": bbox y max = len_y/2 + (hgt-lip_drop) tan(draft)", bb[4], p["len_y"] / 2 + (p["hgt"] - d) * e["t"], 2e-3)
    chk(tag + ": bbox x min mirrored", bb[0], -(p["len_x"] / 2 + (p["hgt"] - d) * e["t"]), 2e-3)
    chk(tag + ": 4 hole faces dia hole_d", m["holes"], 4, 0)
    if m["holes"]:
        chk(tag + ": hole diameter", m["hole_dia"], p["hole_d"], 1e-4)
        chk(tag + ": hole bottom z = boss_h - hole_depth", m["hole_z"][0], p["boss_h"] - p["hole_depth"], 1e-3)
        chk(tag + ": hole top z = boss_h", m["hole_z"][1], p["boss_h"], 1e-3)
        want = sorted([sx * p["boss_x"], sy * p["boss_y"]] for sx in (-1, 1) for sy in (-1, 1))
        chk.true(tag + ": hole axes at (+-boss_x, +-boss_y)", m["hole_xy"] == want, m["hole_xy"])
    chk(tag + ": 4 boss faces", m["bosses"], 4, 0)
    chk(tag + ": boss top z", m.get("boss_top"), p["boss_h"], 1e-3)
    want_rx = [-p["rib_x"] - p["rib_t"] / 2, -p["rib_x"] + p["rib_t"] / 2, p["rib_x"] - p["rib_t"] / 2, p["rib_x"] + p["rib_t"] / 2]
    chk.true(tag + ": rib side faces at +-rib_x +- rib_t/2", len(m["rib_face_x"]) == 4 and all(abs(u - v) < 1e-3 for u, v in zip(m["rib_face_x"], want_rx)),
             m["rib_face_x"])
    chk(tag + ": 2 rib top faces at z = rib_h", m["rib_tops"], 2, 0)
    if m["rib_tops"]:
        yi = p["len_y"] / 2 + p["rib_h"] * e["t"] - p["wall_t"] / e["c"]
        chk(tag + ": rib reaches +Y inner wall", m["rib_span_y"][1], yi, 2e-3)
        chk(tag + ": rib reaches -Y inner wall", m["rib_span_y"][0], -yi, 2e-3)
    chk.true(tag + ": lip lowered band exists at z = hgt - lip_drop", m["lip_low_faces"] >= 1, m["lip_low_faces"])
    for k in ("+Y", "-Y", "-X"):
        chk(tag + ": lip step wall passes through the point lip_w inside the rim edge, side " + k,
            m.get("lip_step_dist", {}).get(k), 0.0, 1e-4)
    chk.true(tag + ": lip step wall is vertical (normal_at +Y probe)", abs(abs(m.get("lip_step_normal", {}).get("+Y", [0, 0, 0])[1]) - 1) < 1e-5,
             m.get("lip_step_normal"))
    chk(tag + ": lowered band y max = Y(hgt - lip_drop)", m.get("lip_low_ymax"), p["len_y"] / 2 + (p["hgt"] - d) * e["t"], 2e-3)
    chk.true(tag + ": notch side faces at y = +-notch_w/2", m["notch_y"] == [-p["notch_w"] / 2, p["notch_w"] / 2], m["notch_y"])
    chk.true(tag + ": notch floor at z = hgt - notch_d", m["notch_floor_faces"] >= 1, m["notch_floor_faces"])
    return m, e


try:
    part = nxh.new_part(os.path.join(OUT, "enclosure_base.prt"))
    D = nxh.Datums(part)
    for n in ("len_x", "len_y", "hgt", "wall_t", "r_corner", "r_floor", "rib_t", "rib_h", "boss_d", "boss_h", "hole_d",
              "hole_depth", "lip_w", "lip_drop", "rib_x", "boss_x", "boss_y", "notch_w", "notch_d"):
        nxh.expr(part, n, NOM[n], "mm")
    nxh.expr(part, "draft_a", NOM["draft_a"], "deg", "wall draft")
    nxh.expr(part, "draft_n", "draft_a", None, "unitless copy for the Draft feature")
    p = dict(NOM)
    e = expected(p)
    res["expected_nominal"] = {k: round(v, 4) for k, v in e.items()}
    H = p["hgt"]

    # 1 base sketch (half, x >= 0) on the XY datum plane, fully constrained
    sk = L.new_sketch(part, D.xy, D.x, D.origin, "SK_BASE_HALF")
    ls = L.hv_polygon(part, sk, [(0, -30), (45, -30), (45, 30), (0, 30)], lambda x, y: P(x, y, 0))
    hx, hy = P(50, 0, 0), P(0, 50, 0)
    L.pdim(sk, D.x, hx, ls[0], L.A.StartPoint, P(20, -38, 0), "len_y/2")
    L.pdim(sk, D.y, hy, ls[1], L.A.StartPoint, P(52, 0, 0), "len_x/2")
    L.pdim(sk, D.x, hx, ls[2], L.A.StartPoint, P(20, 38, 0), "len_y/2")
    L.pdim(sk, D.y, hy, ls[3], L.A.StartPoint, P(-8, 0, 0), "0")
    st = res["sk_base"] = L.finish(sk)
    chk.true("base sketch fully constrained", st["status"] == "WellConstrained" and st["dof"] == 0, st)

    # 2 extrude
    f_ext = nxh.extrude(part, nxh.section_region(part, sk, (20, 0, 0)), (0, 0, 1), 0, "hgt")
    body = f_ext.GetBodies()[0]
    chk("extrude half volume = len_x/2*len_y*hgt", nxh.volume(part, body), 45 * 60 * 28, 1e-3)

    # 3 draft the three outer walls: stationary = bottom, pull -Z, +angle -> top grows
    walls = [f for f, n, _b in planar(body) if abs(n[2]) < 0.5 and n[0] > -0.9]
    bottom = nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, -1))
    chk("3 walls to draft", len(walls), 3, 0)
    f_draft, e_draft = L.draft_faces(part, walls, (0, 0, -1), 2.0, bottom)
    e_draft.RightHandSide = "draft_n"
    nxh.update()
    chk("draft: half volume = prismatoid", nxh.volume(part, body), e["block"] / 2, 1e-3)
    chk("draft: top x max", nxh.bbox(body)[3], e["XH"], 1e-3)
    chk("draft: bottom stays len_x/2", nxh.bbox(bottom[0])[3], 45.0, 1e-3)

    # 4 corner blends (r_corner), then floor blend (r_floor)
    corner = nxh.edges(body, lambda b: b[2] < 1e-3 and abs(b[5] - H) < 1e-3 and b[0] > 1.0)
    chk("2 corner edges", len(corner), 2, 0)
    nxh.blend(part, corner, "r_corner")
    chk("corner blend: half volume (exact oblique-prism formula)", nxh.volume(part, body), e["after_corner"] / 2, 1e-2)
    floor_edges = [ed for ed in nxh.edges_at(body, 2, 0.0) if nxh.bbox(ed)[3] > 1e-3]
    res["n_floor_edges"] = len(floor_edges)
    nxh.blend(part, floor_edges, "r_floor")
    chk("floor blend: half volume (corner part approximate)", nxh.volume(part, body), e["after_floor"] / 2, 1.5)
    res["census_after_blends"] = nxh.face_census(body)

    # 5 shell: remove top + symmetry face
    top = nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1))
    sym = nxh.faces(body, ftype=nxh.PLANE, normal=(-1, 0, 0))
    chk("shell: 1 top + 1 symmetry face to remove", len(top) + len(sym), 2, 0)
    L.shell(part, body, top + sym, "wall_t", inward=True)
    v_shell = nxh.volume(part, body)
    chk("shell: half volume (floor-blend corners approximate)", v_shell, e["shell"] / 2, 2.0)
    m = measure(part, body, p, full=False)
    chk("shell: wall thickness", m.get("wall"), 2.0, 1e-4)
    chk("shell: floor thickness", m.get("floor"), 2.0, 1e-4)
    chk("shell: bbox unchanged (inward)", nxh.bbox(body)[3], e["XH"], 1e-3)

    # 6 bosses (Cylinder + Unite), starting inside the floor so the bodies overlap
    for sgn in ("", "-"):
        v0 = nxh.volume(part, body)
        nxh.cylinder(part, ("boss_x", sgn + "boss_y", "wall_t/2"), (0, 0, 1), "boss_d", "boss_h-wall_t/2", BOOL.Unite, body)
        chk("boss y%s: added volume = pi r^2 (boss_h - wall_t)" % (sgn or "+"), nxh.volume(part, body) - v0, e["boss_each"], 1e-3)
    chk("bosses: 1 solid", len(nxh.solids(part)), 1, 0)

    # 7 rib: datum plane at z = rib_h, fully constrained one-line sketch, Rib perpendicular
    _fp, rib_plane = nxh.datum_plane(part, (0, 0, "rib_h"), (0, 0, 1), "RIB_TOP_PLANE")
    nxh.expr(part, "rib_len", 20, "mm", "sketched rib line length (rib extends to the walls)")

    def mk_rib_sketch():
        s2 = L.new_sketch(part, rib_plane, D.x, D.origin, "SK_RIB")
        ln = part.Curves.CreateLine(P(18, -10, 14), P(18, 10, 14))
        L.add(s2, ln)
        s2.CreateVerticalConstraint(L.cg(ln))
        L.pdim(s2, D.y, P(0, 50, 0), ln, L.A.StartPoint, P(9, -14, 14), "rib_x")
        L.pdim(s2, D.x, P(50, 0, 0), ln, L.A.StartPoint, P(24, -5, 14), "rib_len/2")
        L.pdim(s2, D.x, P(50, 0, 0), ln, L.A.EndPoint, P(24, 5, 14), "rib_len/2")
        res["sk_rib"] = L.finish(s2)
        return s2

    v0 = nxh.volume(part, body)
    f_rib = None
    for rev in (True, False):
        mk = nxh.mark("rib attempt", False)
        try:
            f_rib = L.rib(part, body, mk_rib_sketch(), (18, -10, 14), "rib_t", rev)
            res["rib_reverse"] = rev
            break
        except NXOpen.NXException as ex:
            res["notes"].append("rib reverse=%s failed: %s" % (rev, ex))
            nxh.undo_to(mk)
    chk.true("rib sketch fully constrained", res["sk_rib"]["status"] == "WellConstrained" and res["sk_rib"]["dof"] == 0, res["sk_rib"])
    chk("rib: added volume = rib_t * cavity section area", nxh.volume(part, body) - v0, e["rib_each"], 2e-2)
    chk("rib: 1 solid", len(nxh.solids(part)), 1, 0)

    # 8 holes: one HolePackage, two points on the boss tops
    v0 = nxh.volume(part, body)
    pts = [nxh.point(part, "boss_x", "boss_y", "boss_h"), nxh.point(part, "boss_x", "-boss_y", "boss_h")]
    f_hole = L.hole(part, body, pts, "hole_d", "hole_depth")
    res["hole_feature"] = f_hole.GetFeatureName()
    chk("holes: removed volume = 2 pi r^2 depth", v0 - nxh.volume(part, body), 2 * e["hole_each"], 1e-3)
    v_half = nxh.volume(part, body)
    chk("half finished: volume", v_half, e["half_done"], 2.5)

    # 9 mirror geometry about YZ + unite
    f_mir, copies = L.mirror_geometry(part, [body], D.yz)
    chk("mirror: 1 new body", len(copies), 1, 0)
    if copies:
        chk("mirror: copy volume = source", nxh.volume(part, copies[0]), v_half, 1e-4)
        chk("mirror: copy bbox x min", nxh.bbox(copies[0])[0], -e["XH"], 1e-3)
    f_uni = L.boolean(part, BT.Unite, body, tool_features=[f_mir])
    chk("unite: 1 solid", len(nxh.solids(part)), 1, 0)
    chk("unite: feature owns 1 body", len(f_uni.GetBodies()), 1, 0)
    v_full = nxh.volume(part, body)
    chk("unite: volume = 2 x half", v_full, 2 * v_half, 1e-3)

    # 10 lip: Divide Face (offset curve in face) + Offset Region on the outer band
    rim = [f for f in nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1)) if abs(nxh.bbox(f)[2] - H) < 1e-3]
    res["rim_faces_before_divide"] = len(rim)
    rim = rim[0]
    rb = nxh.bbox(rim)
    outer_edges = [ed for ed in rim.GetEdges() if any(abs(nxh.bbox(ed)[i] - rb[i]) < 1e-3 for i in (0, 1, 3, 4))]
    res["rim_edges"] = len(rim.GetEdges())
    res["rim_outer_edges"] = len(outer_edges)
    f_div = None
    for flip in (False, True):
        r, err = nxh.attempt("divide face flip=%s" % flip, L.divide_face_offset, part, rim, outer_edges, "lip_w",
                             (rb[3], 0.0, H), flip, log=log)
        if err:
            res["notes"].append("divide flip=%s: %s" % (flip, err))
            continue
        tops = [f for f in nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1)) if abs(nxh.bbox(f)[2] - H) < 1e-3]
        if len(tops) == 2:
            f_div = r
            res["divide_flip"] = flip
            break
        res["notes"].append("divide flip=%s gave %d rim faces" % (flip, len(tops)))
    chk.true("divide face committed with 2 rim bands", f_div is not None, res["notes"])
    tops = [f for f in nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, 1)) if abs(nxh.bbox(f)[2] - H) < 1e-3]
    tops.sort(key=lambda f: nxh.bbox(f)[3])
    inner_band, outer_band = tops[0], tops[-1]
    res["divide_inner_band_ymax_bbox"] = nxh.bbox(inner_band)[4]
    res["divide_inner_band_ymax_expected"] = e["YH"] - 1.0
    try:
        res["divide_inner_band_edge_types"] = sorted(str(ed.SolidEdgeType) for ed in inner_band.GetEdges())
    except Exception as ex:  # noqa: BLE001
        res["divide_inner_band_edge_types"] = str(ex)
    chk("divide: volume unchanged", nxh.volume(part, body), v_full, 1e-4)
    L.offset_region(part, [outer_band], "-lip_drop")
    chk("lip: removed volume (Steiner offset formula)", v_full - nxh.volume(part, body), e["lip"], 0.3)
    v_lip = nxh.volume(part, body)

    # 11 cable notch through the +X wall: sketch on YZ, Extrude-Subtract along +X
    sk3 = L.new_sketch(part, D.yz, D.y, D.origin, "SK_NOTCH")
    n3 = L.hv_polygon(part, sk3, [(-6, 22), (6, 22), (6, 29), (-6, 29)], lambda y, z: P(0, y, z))
    L.pdim(sk3, D.y, P(0, 50, 0), n3[0], L.A.StartPoint, P(0, 12, 20), "hgt-notch_d")
    L.pdim(sk3, D.z, P(0, 0, 50), n3[1], L.A.StartPoint, P(0, 10, 25), "notch_w/2")
    L.pdim(sk3, D.y, P(0, 50, 0), n3[2], L.A.StartPoint, P(0, 12, 31), "hgt+1")
    L.pdim(sk3, D.z, P(0, 0, 50), n3[3], L.A.StartPoint, P(0, -10, 25), "notch_w/2")
    st = res["sk_notch"] = L.finish(sk3)
    chk.true("notch sketch fully constrained", st["status"] == "WellConstrained" and st["dof"] == 0, st)
    nxh.extrude(part, nxh.section_feature(part, [sk3.Feature], help_point=(0, -6, 25)), (1, 0, 0), "len_x/2-3*wall_t", "len_x/2+5",
                BOOL.Subtract, body)
    chk("notch: removed volume = notch_w * wall section", v_lip - nxh.volume(part, body), e["notch"], 2e-2)
    chk("notch: 1 solid", len(nxh.solids(part)), 1, 0)

    # ---------------- final checks at nominal
    nxh.update()
    m_nom, _ = check_full("nominal", part, body, p)
    v_nom = m_nom["volume"]
    eg = res["examine_geometry"] = nxh.examine_geometry(part, body)
    chk.true("Examine Geometry clean", all(v == 0 for v in eg.values()), eg)
    res["tree"] = [(x["ts"], x["name"], x["type"]) for x in nxh.feature_table(part)]
    res["face_census"] = nxh.face_census(body)

    # ---------------- regeneration test, one master at a time
    for name, val in (("wall_t", 2.5), ("hgt", 34.0), ("draft_a", 3.0)):
        nxh.set_expr(part, name, val)
        nxh.update()
        q = dict(NOM)
        q[name] = val
        check_full("regen %s=%s" % (name, val), part, body, q)
        nxh.set_expr(part, name, NOM[name])
        nxh.update()
    v_back = nxh.volume(part, body)
    chk("round trip: nominal volume returns (rel 1e-6)", v_back, v_nom, 1e-6 * v_nom)
    chk.true("round trip: no feature errors", not nxh.feature_errors(part), nxh.feature_errors(part))
    chk("round trip: 1 solid", len(nxh.solids(part)), 1, 0)
    res["volume_nominal"] = v_nom
    res["bbox_nominal"] = nxh.bbox(body)
    res["sketch_status_final"] = {s.Name: L.status_of(s) for s in part.Sketches}
    nxh.save(part)

    # ---------------- STEP AP242
    stp = os.path.join(OUT, "enclosure_base.step")
    r, err = nxh.attempt("step export", L.step_export, part, stp, log=log)
    res["step_export_error"] = err
    sv, err = nxh.attempt("step verify", L.step_verify, OUT, stp, "enclosure_base", log, log=log)
    res["step"] = sv
    res["step_verify_error"] = err
    if sv:
        chk.true("STEP file exists with MANIFOLD_SOLID_BREP", sv.get("exists") and sv.get("manifold_solid_brep", 0) >= 1,
                 {k: sv.get(k) for k in ("exists", "size", "manifold_solid_brep", "schema_lines")})
        chk("STEP re-import: 1 solid body", sv.get("solid_bodies"), 1, 0)
        chk("STEP re-import: volume = NX volume (rel 1e-5: blend faces go through B-splines)", sv.get("volume"), v_nom, 1e-5 * v_nom)
    else:
        chk.true("STEP verify ran", False, err)
    res.update(chk.report())
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    log("EXCEPTION", res["error"])
    res.update({"checks": chk.rows, "result": "FAIL"})
    try:
        res["tree"] = [(x["ts"], x["name"], x["type"]) for x in nxh.feature_table(nxh.S.Parts.Work)]
        res["feature_errors"] = nxh.feature_errors(nxh.S.Parts.Work)
    except Exception:  # noqa: BLE001
        pass
nxh.write_json(os.path.join(OUT, "part1_result.json"), res)
