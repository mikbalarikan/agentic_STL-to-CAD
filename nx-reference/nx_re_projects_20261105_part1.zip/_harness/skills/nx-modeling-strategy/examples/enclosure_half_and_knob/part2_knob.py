"""Part 2 - turned knob (acceptance test of the nx-* skills). Revolve -> groove (Revolve-Subtract) -> flute + circular pattern -> chamfer."""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ.get("NXH_DIR") or os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[0])))), "nx-journal-core", "scripts"))
OUT = sys.argv[1]
sys.path.insert(0, OUT)
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import nxh  # noqa: E402
import acc_lib as L  # noqa: E402

P, BOOL = nxh.P, nxh.BOOL
log = nxh.Log(os.path.join(OUT, "part2.log"))
chk = L.Checks(log)
res = {"result": "FAIL", "notes": []}

NOM = dict(base_d=40.0, base_h=6.0, grip_d=30.0, knob_h=24.0, bore_d=8.0, bore_depth=15.0, chamfer_c=2.0, groove_w=2.4,
           groove_dp=1.5, groove_z=15.0, flute_r=2.0, flute_z0=8.0, flute_len=14.0, n_flutes=12)


def pappus(poly_rz):
    a = cx = 0.0
    n = len(poly_rz)
    for i in range(n):
        (r0, z0), (r1, z1) = poly_rz[i], poly_rz[(i + 1) % n]
        cr = r0 * z1 - r1 * z0
        a += cr
        cx += (r0 + r1) * cr
    a *= 0.5
    return abs(2.0 * math.pi * (cx / (6.0 * a)) * a)


def lens(R, r, d):
    """Area common to two circles of radius R and r whose centres are d apart."""
    if d >= R + r:
        return 0.0
    return (r * r * math.acos((d * d + r * r - R * R) / (2 * d * r)) + R * R * math.acos((d * d + R * R - r * r) / (2 * d * R))
            - 0.5 * math.sqrt((-d + r + R) * (d + r - R) * (d - r + R) * (d + r + R)))


def profile(p):
    rb, rg, r0 = p["base_d"] / 2, p["grip_d"] / 2, p["bore_d"] / 2
    return [(r0, 0), (rb, 0), (rb, p["base_h"]), (rg, p["base_h"]), (rg, p["knob_h"]), (0, p["knob_h"]),
            (0, p["bore_depth"]), (r0, p["bore_depth"])]


def expected(p):
    rg = p["grip_d"] / 2
    e = {"revolve": pappus(profile(p))}
    e["revolve_cylinders"] = math.pi * ((p["base_d"] / 2) ** 2 * p["base_h"] + rg ** 2 * (p["knob_h"] - p["base_h"])
                                        - (p["bore_d"] / 2) ** 2 * p["bore_depth"])
    e["groove"] = math.pi * (rg ** 2 - (rg - p["groove_dp"]) ** 2) * p["groove_w"]
    e["flute_each"] = (lens(rg, p["flute_r"], rg) * (p["flute_len"] - p["groove_w"])
                       + lens(rg - p["groove_dp"], p["flute_r"], rg) * p["groove_w"])
    c = p["chamfer_c"]
    e["chamfer"] = 2 * math.pi * (rg - c / 3) * c * c / 2          # Pappus: triangle area c^2/2, centroid at rg - c/3
    e["total"] = e["revolve"] - e["groove"] - p["n_flutes"] * e["flute_each"] - e["chamfer"]
    return e


def cyl_faces(body, radius, tol=1e-3):
    return [f for f in body.GetFaces() if nxh.face_data(f)[0] == nxh.CYLINDER and abs(abs(nxh.face_data(f)[3]) - radius) < tol]


def check_full(tag, part, body, p):
    e = expected(p)
    m = {"solids": len(nxh.solids(part)), "volume": nxh.volume(part, body), "bbox": nxh.bbox(body),
         "errors": nxh.feature_errors(part), "census": nxh.face_census(body)}
    fl = cyl_faces(body, p["flute_r"])
    m["flute_axes"] = sorted({(round(nxh.face_data(f)[1][0], 3), round(nxh.face_data(f)[1][1], 3)) for f in fl})
    m["flute_axis_radius"] = sorted({round(math.hypot(nxh.face_data(f)[1][0], nxh.face_data(f)[1][1]), 4) for f in fl})
    m["flute_z"] = [min(nxh.bbox(f)[2] for f in fl), max(nxh.bbox(f)[5] for f in fl)] if fl else None
    gf = cyl_faces(body, p["grip_d"] / 2 - p["groove_dp"])
    m["groove_floor_z"] = [min(nxh.bbox(f)[2] for f in gf), max(nxh.bbox(f)[5] for f in gf)] if gf else None
    bf = cyl_faces(body, p["bore_d"] / 2)
    m["bore_z"] = [min(nxh.bbox(f)[2] for f in bf), max(nxh.bbox(f)[5] for f in bf)] if bf else None
    m["grip_faces"] = len(cyl_faces(body, p["grip_d"] / 2))
    m["cone_faces"] = m["census"]["types"].get(nxh.CONE, 0)
    res["measure_" + tag] = m
    res["expected_" + tag] = {k: round(v, 4) for k, v in e.items()}
    chk(tag + ": solids", m["solids"], 1, 0)
    chk.true(tag + ": no feature errors", not m["errors"], m["errors"])
    chk(tag + ": volume = Pappus revolve - groove - n*flute - chamfer", m["volume"], e["total"], 2e-2)
    chk(tag + ": flute count (distinct R%g axes)" % p["flute_r"], len(m["flute_axes"]), p["n_flutes"], 0)
    chk.true(tag + ": flute axes on the grip surface r = grip_d/2", m["flute_axis_radius"] == [p["grip_d"] / 2], m["flute_axis_radius"])
    if m["flute_z"]:
        chk(tag + ": flute z start", m["flute_z"][0], p["flute_z0"], 1e-3)
        chk(tag + ": flute z end", m["flute_z"][1], p["flute_z0"] + p["flute_len"], 1e-3)
    chk.true(tag + ": groove floor cylinder r = grip_d/2 - groove_dp present", bool(gf), len(gf))
    if gf:
        chk(tag + ": groove z min", m["groove_floor_z"][0], p["groove_z"] - p["groove_w"] / 2, 1e-3)
        chk(tag + ": groove z max", m["groove_floor_z"][1], p["groove_z"] + p["groove_w"] / 2, 1e-3)
    chk.true(tag + ": bore dia bore_d present", bool(bf), len(bf))
    if bf:
        chk(tag + ": bore depth", m["bore_z"][1] - m["bore_z"][0], p["bore_depth"], 1e-3)
    chk.true(tag + ": chamfer cone face present", m["cone_faces"] >= 1, m["cone_faces"])
    chk(tag + ": bbox x max = base_d/2", m["bbox"][3], p["base_d"] / 2, 1e-3)
    chk(tag + ": bbox z max = knob_h", m["bbox"][5], p["knob_h"], 1e-3)
    return m, e


try:
    part = nxh.new_part(os.path.join(OUT, "knob.prt"))
    D = nxh.Datums(part)
    for n, v in NOM.items():
        if n == "n_flutes":
            nxh.expr(part, n, v, None, "number of grip flutes")
        else:
            nxh.expr(part, n, v, "mm")
    p = dict(NOM)
    e = expected(p)
    res["expected_nominal_parts"] = {k: round(v, 4) for k, v in e.items()}
    chk("analytic self-check: Pappus = sum of cylinders", e["revolve"], e["revolve_cylinders"], 1e-6)
    to3 = lambda x, z: P(x, 0, z)  # noqa: E731
    hx, hz = P(50, 0, 0), P(0, 0, 50)

    # 1 half-profile sketch on XZ, fully constrained
    sk = L.new_sketch(part, D.xz, D.x, D.origin, "SK_PROFILE")
    ls = L.hv_polygon(part, sk, profile(p), to3)
    L.pdim(sk, D.x, hx, ls[0], L.A.StartPoint, to3(12, -5), "0")
    L.pdim(sk, D.z, hz, ls[1], L.A.StartPoint, to3(26, 3), "base_d/2")
    L.pdim(sk, D.x, hx, ls[2], L.A.StartPoint, to3(26, 8), "base_h")
    L.pdim(sk, D.z, hz, ls[3], L.A.StartPoint, to3(22, 15), "grip_d/2")
    L.pdim(sk, D.x, hx, ls[4], L.A.StartPoint, to3(8, 30), "knob_h")
    L.pdim(sk, D.z, hz, ls[5], L.A.StartPoint, to3(-6, 20), "0")
    L.pdim(sk, D.x, hx, ls[6], L.A.StartPoint, to3(-6, 12), "bore_depth")
    L.pdim(sk, D.z, hz, ls[7], L.A.StartPoint, to3(8, 6), "bore_d/2")
    st = res["sk_profile"] = L.finish(sk)
    chk.true("profile sketch fully constrained", st["status"] == "WellConstrained" and st["dof"] == 0, st)

    # 2 revolve 360 about the datum Z axis
    f_rev = L.revolve(part, nxh.section_region(part, sk, (10, 0, 3)), L.axis_from(part, D.z), 0, 360)
    body = f_rev.GetBodies()[0]
    chk.true("revolve: solid body", body.IsSolidBody)
    chk("revolve: volume = Pappus", nxh.volume(part, body), e["revolve"], 1e-3)
    chk("revolve: 1 solid", len(nxh.solids(part)), 1, 0)

    # 3 O-ring groove: sketch (fully constrained) + Revolve-Subtract, profile overshoots the surface by 1
    sk2 = L.new_sketch(part, D.xz, D.x, D.origin, "SK_GROOVE")
    g = L.hv_polygon(part, sk2, [(13.5, 13.8), (16.0, 13.8), (16.0, 16.2), (13.5, 16.2)], to3)
    L.pdim(sk2, D.x, hx, g[0], L.A.StartPoint, to3(24, 13), "groove_z-groove_w/2")
    L.pdim(sk2, D.z, hz, g[1], L.A.StartPoint, to3(24, 15), "grip_d/2+1")
    L.pdim(sk2, D.x, hx, g[2], L.A.StartPoint, to3(24, 17), "groove_z+groove_w/2")
    L.pdim(sk2, D.z, hz, g[3], L.A.StartPoint, to3(10, 15), "grip_d/2-groove_dp")
    st = res["sk_groove"] = L.finish(sk2)
    chk.true("groove sketch fully constrained", st["status"] == "WellConstrained" and st["dof"] == 0, st)
    v0 = nxh.volume(part, body)
    L.revolve(part, nxh.section_feature(part, [sk2.Feature], help_point=(13.5, 0, 15)), L.axis_from(part, D.z), 0, 360,
              BOOL.Subtract, body)
    chk("groove: removed volume = pi (R^2 - (R-dp)^2) w", v0 - nxh.volume(part, body), e["groove"], 1e-3)
    chk("groove: 1 solid", len(nxh.solids(part)), 1, 0)

    # 4 one flute: Cylinder + Subtract, axis on the grip surface
    v0 = nxh.volume(part, body)
    f_flute, _ = nxh.cylinder(part, ("grip_d/2", 0, "flute_z0"), (0, 0, 1), "2*flute_r", "flute_len", BOOL.Subtract, body)
    chk("flute: removed volume = lens areas x heights", v0 - nxh.volume(part, body), e["flute_each"], 1e-3)

    # 5 circular pattern about Z, count = n_flutes, span 360
    f_pat = L.pattern_circular(part, [f_flute], (0, 0, 0), (0, 0, 1), "n_flutes")
    chk("pattern: removed volume = n_flutes x flute", v0 - nxh.volume(part, body), 12 * e["flute_each"], 5e-3)
    chk("pattern: 1 solid", len(nxh.solids(part)), 1, 0)

    # 6 chamfer on the top edge, last
    v0 = nxh.volume(part, body)
    top_edges = [ed for ed in nxh.edges_at(body, 2, 24.0)]
    res["top_edges"] = len(top_edges)
    L.chamfer(part, top_edges, "chamfer_c")
    chk("chamfer: removed volume = Pappus of the 2x2 triangle", v0 - nxh.volume(part, body), e["chamfer"], 1e-3)

    nxh.update()
    m_nom, _ = check_full("nominal", part, body, p)
    v_nom = m_nom["volume"]
    eg = res["examine_geometry"] = nxh.examine_geometry(part, body)
    chk.true("Examine Geometry clean", all(v == 0 for v in eg.values()), eg)
    res["tree"] = [(x["ts"], x["name"], x["type"], x["suppressed"]) for x in nxh.feature_table(part)]

    for name, val in (("n_flutes", 8), ("grip_d", 34.0)):
        nxh.set_expr(part, name, val)
        nxh.update()
        q = dict(NOM)
        q[name] = val
        check_full("regen %s=%s" % (name, val), part, body, q)
        res["tree_len_regen_" + name] = len(nxh.feature_table(part))
        nxh.set_expr(part, name, NOM[name])
        nxh.update()
    chk("round trip: nominal volume returns (rel 1e-6)", nxh.volume(part, body), v_nom, 1e-6 * v_nom)
    chk.true("round trip: no feature errors", not nxh.feature_errors(part), nxh.feature_errors(part))
    chk("round trip: 1 solid", len(nxh.solids(part)), 1, 0)
    res["volume_nominal"] = v_nom
    res["sketch_status_final"] = {s.Name: L.status_of(s) for s in part.Sketches}
    nxh.save(part)

    stp = os.path.join(OUT, "knob.step")
    r, err = nxh.attempt("step export", L.step_export, part, stp, log=log)
    res["step_export_error"] = err
    sv, err = nxh.attempt("step verify", L.step_verify, OUT, stp, "knob", log, log=log)
    res["step"] = sv
    res["step_verify_error"] = err
    if sv:
        chk.true("STEP file exists with MANIFOLD_SOLID_BREP", sv.get("exists") and sv.get("manifold_solid_brep", 0) >= 1,
                 {k: sv.get(k) for k in ("exists", "size", "manifold_solid_brep", "schema_lines")})
        chk("STEP re-import: 1 solid body", sv.get("solid_bodies"), 1, 0)
        chk("STEP re-import: volume = NX volume", sv.get("volume"), v_nom, 0.01)
    else:
        chk.true("STEP verify ran", False, err)
    res.update(chk.report())
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    log("EXCEPTION", res["error"])
    res.update({"checks": chk.rows, "result": "FAIL"})
    try:
        res["tree"] = [(x["ts"], x["name"], x["type"]) for x in nxh.feature_table(nxh.S.Parts.Work)]
        res["feature_errors"] = nxh.feature_errors(nxh.S.Parts.Work)
    except Exception:  # noqa: BLE001
        pass
nxh.write_json(os.path.join(OUT, "part2_result.json"), res)
