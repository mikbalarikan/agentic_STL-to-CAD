# Worked examples: complete, verified builds

These journals were written by fresh agents that had ONLY the nx-* skills (acceptance tests,
NX 2206 batch). They are kept as end-to-end references: a plan, a build, measured checks after
every feature, a regeneration test and a STEP round trip. Read them for structure; for new work
call the shared helpers (`nxh`, `nxf`, `nxa` in `nx-journal-core/scripts`) instead of the local
`acc_lib.py` / `acc3_lib.py` copies they carry - those libraries are what `nxf.py` / `nxa.py`
were consolidated from.

| Folder | What it builds | Result | Shows |
|---|---|---|---|
| `enclosure_half_and_knob/part1_enclosure.py` | moulded enclosure base: half model, draft, corner + floor blends, shell, bosses, rib, Hole feature, Mirror Geometry + Unite, rim lip (Divide Face + Offset Region), notch | 157 / 157 checks, correct on the first NX run | class A plan with the half-and-mirror order; exact per-feature volume deltas; regen of wall, height, draft |
| `enclosure_half_and_knob/part2_knob.py` | turned knob: Revolve, groove by Revolve-Subtract, flute + circular Pattern Feature, Chamfer | 64 / 64, first run | Pappus checks; pattern count expression |
| `imported_bracket_and_surfaced_grip/a1_census.py`, `a2_build.py` | STEP (AP242) import of a cast bracket, health check and hole/blend census, Delete Face, Offset Region, Resize Face, Replace Face to a datum, new Hole + Chamfer | 33 / 33 | class B: import -> census -> de-feature -> edit -> native features; honest checks where area x distance is not exact |
| `imported_bracket_and_surfaced_grip/b1_build.py` | surfaced grip: associative sections, Through Curves solid with twist test, Through Curve Mesh crown, Extend Sheet, Trim Body, Shell, sheet Revolve + Bounded Plane + Sew, G0 vs G1 joint | 68 / 68 | class D: section alignment, continuity measured headless |
| `topdown_enclosure_around_pcb/PLAN.md`, `build.py` | PCB + screws assembly with constraints; base and lid designed in context: WAVE-linked faces and bodies, bosses and holes on linked arc-centre points, clearance cuts, tongue and groove; associativity test; reopen; assembly STEP | 178 + 61 checks | class C: the user's daily job, incl. what must be reloaded after reopen |
| `extend_existing_parts/edits.py` | extends copies of two real production parts (watch housing, small enclosure): Offset Region, raised land, boss + pilot hole + root blend, gusset rib, slot, Delete Face - with a tag-keyed before/after state comparison | every edit PASS | editing somebody else's hybrid tree without disturbing it (see `nx-journal-core/references/existing-parts.md`) |

| `battery_dock_and_scan_rebuild/a_build.py`, `a_reopen.py` | wall dock designed top-down around a linked battery cell with the shipped helpers (`nxf`, `nxa`): linked faces and points, sketches tied to linked points, gusset ribs, counterbored holes on a curved floor, clips constrained to DOF 0, a larger cell format regenerated, reopen | 178 + 23 checks, 3 NX runs | class C with the final helper set; which load call matters after reopen |
| `battery_dock_and_scan_rebuild/b_probe.py`, `b_rebuild.py` | an UNKNOWN noisy scan described, its datum frame checked, 13 primitives fitted and snapped with residuals, rebuilt as sketch + extrude + cylinder + Hole features, signed scan-to-CAD deviation | 20 checks, correct on the first rebuild run; RMS 0.0204 mm = the scan noise | class E: census of an unknown part, fit-and-snap table, deviation percentiles |

The last row pair is the final confirmation test: 5 NX runs for two jobs, one of them caused by a
skill gap (earlier comparable jobs needed 10). `acceptance_builds.png` shows six of the builds.

Sketch DOF in the `enclosure_half_and_knob` pair: `acc_lib.py` has its own sketch builder and status
read, so it now switches Continuous Auto Dimensioning off before each sketch and counts automatic
dimensions (`auto_dims` in the sketch results). Run again that way: 157 / 157 and 64 / 64, all five
sketches `WellConstrained`, DOF 0, `auto_dims` 0 - the "fully constrained" checks of the first run
held (`nx-journal-core/SKILL.md`, "Sketch DOF").

Running one: `run_journal.ps1 -Script <journal> -WorkDir <out> -JArgs <out>` with the journal's
helper library copied next to it or into `<out>` (each journal puts `<out>` on `sys.path`). The
imported-bracket and existing-part examples need their input files (a STEP file; copies of the
user's parts) in `<out>` - they are references, not part of the regression suite.

Lessons these builds fed back into the skills: AP242 files need the 242 importer; a tangent join
between sheets with opposite normals; bounding boxes of freeform and rim-idiom faces are padded;
face-to-face contact unites; positions from linked geometry need WAVE points, not interpart
expressions; Replace Face onto a mating face needs the reverse flag; after reopen, load linked
parts fully; compare feature states by tag on parts with a suppressed tail.
