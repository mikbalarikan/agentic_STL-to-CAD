"""Task A step 1: import STEP, health check, geometry census. Args: <out dir>"""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1]
NF = NXOpen.Features
STEP_DIR = os.path.join(os.environ.get("UGII_BASE_DIR", r"C:\Program Files\Siemens\NX2206"), "STEP214UG")
res = {"result": "FAIL"}
log = nxh.Log(os.path.join(OUT, "a1_census.log"))


def import_step(part, path, scratch_prt):
    """AP242 file: Step214Importer refuses it -> Step242Importer (found by dir(DexManager))."""
    before = {b.Tag for b in part.Bodies}
    res["dex_step_members"] = [n for n in dir(nxh.S.DexManager) if "tep" in n]
    imp = nxh.S.DexManager.CreateStep242Importer()
    res["step242_doc"] = nxh.builder_doc(imp)
    res["step242_defaults"] = {}
    for n in ("SettingsFile", "ImportTo", "InputFile", "OutputFile", "FileOpenFlag", "ProcessHoldFlag", "Optimize", "SewSurfaces", "SimplifyGeometry", "FlattenAssembly", "LayerDefault"):
        try:
            res["step242_defaults"][n] = str(getattr(imp, n))
        except Exception as e:  # noqa: BLE001
            res["step242_defaults"][n] = "ERR " + str(e)
    try:
        imp.SettingsFile = os.path.join(os.path.dirname(STEP_DIR), "TRANSLATORS", "step242", "step242ug.def")
        imp.ImportTo = NXOpen.Step242Importer.ImportToOption.WorkPart
        imp.ObjectTypes.Solids = True
        imp.InputFile = path
        imp.OutputFile = scratch_prt
        imp.FileOpenFlag = False
        imp.ProcessHoldFlag = True
        imp.Commit()
    finally:
        imp.Destroy()
    return [b for b in part.Bodies if b.Tag not in before]


def r(v, n=4):
    return [round(x, n) for x in v]


def face_row(part, f, rb):
    t, pt, d, box, rad, rd, nd = nxh.UFS.Modeling.AskFaceData(f.Tag)
    bb = nxh.bbox(f)
    row = {"tag": f.Tag, "type": t, "pt": r(pt), "dir": r(d), "rad": round(rad, 4), "rad_data": round(rd, 4), "norm_dir": nd,
           "bbox": bb, "area": round(nxh.sheet_area(part, [f])[0], 4), "n_edges": len(f.GetEdges())}
    try:
        isb = rb.IsBlendFace([f])
        row["is_blend"] = bool(isb[0]) if isinstance(isb, (list, tuple)) else bool(isb)
        if row["is_blend"]:
            row["blend_r"] = round(rb.GetBlendFaceRadius(f), 4)
    except Exception as e:  # noqa: BLE001
        row["blend_err"] = str(e)
    if t == nxh.CYLINDER:
        # hole or boss: face normal against the radial direction at a point on the face
        c = [(bb[i] + bb[i + 3]) / 2 for i in range(3)]
        parm, pnt = nxh.UFS.Modeling.AskFaceParm(f.Tag, c)
        n = nxh.normal_at(f, pnt)
        v = [pnt[i] - pt[i] for i in range(3)]
        k = sum(v[i] * d[i] for i in range(3))
        rad_v = [v[i] - k * d[i] for i in range(3)]
        row["concave"] = sum(rad_v[i] * n[i] for i in range(3)) < 0
        # extent along the axis
        row["axis_extent"] = round(sum(abs(d[i]) * (bb[i + 3] - bb[i]) for i in range(3)), 4)
    return row


try:
    part = nxh.new_part(os.path.join(OUT, "a1_census.prt"))
    new = import_step(part, os.path.join(OUT, "CAPTURE_NOMINAL.step"), os.path.join(OUT, "a1_scratch.prt"))
    res["n_new_bodies"] = len(new)
    res["bodies"] = [{"solid": b.IsSolidBody, "faces": len(b.GetFaces())} for b in new]
    res["tree"] = nxh.feature_table(part)
    body = new[0]
    res["examine_geometry"] = nxh.examine_geometry(part, body)
    res["mass"] = nxh.mass(part, [body])
    res["bbox"] = nxh.bbox(body)
    res["census_before_optimize"] = nxh.face_census(body)

    # Optimize Face (skill: first step on every imported body)
    v0 = nxh.volume(part, body)
    b = part.Features.CreateOptimizeFaceBuilder()
    try:
        b.FacesToOptimize.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(body)], False)
        b.CleanBody = True
        b.Report = False
        b.DistanceTolerance = 0.01
        b.Commit()
    finally:
        b.Destroy()
    res["census_after_optimize"] = nxh.face_census(body)
    res["volume_after_optimize"] = nxh.volume(part, body)
    res["volume_before_optimize"] = v0
    res["tree_after_optimize"] = nxh.feature_table(part)
    res["examine_geometry_after_optimize"] = nxh.examine_geometry(part, body)

    rb = part.Features.CreateResizeBlendBuilder(nxh.NULL_FEATURE)
    try:
        rows = [face_row(part, f, rb) for f in body.GetFaces()]
    finally:
        rb.Destroy()
    res["faces"] = rows
    res["cylinders"] = [x for x in rows if x["type"] == nxh.CYLINDER]
    res["holes"] = [x for x in rows if x["type"] == nxh.CYLINDER and x.get("concave") and not x.get("is_blend")]
    res["blends"] = [x for x in rows if x.get("is_blend")]
    res["planes_by_area"] = sorted([x for x in rows if x["type"] == nxh.PLANE], key=lambda x: -x["area"])
    nxh.save(part)
    res["result"] = "PASS"
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "a1_census.json"), res)
