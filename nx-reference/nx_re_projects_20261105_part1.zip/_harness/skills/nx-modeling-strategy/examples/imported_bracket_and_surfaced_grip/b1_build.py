"""Task B: surfaced hand-grip transition piece + crowned shelled pad + sheet-to-solid + continuity check.
Args: <out dir>"""
import math
import os
import sys
import time
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1]
GU = NXOpen.GeometricUtilities
NF = nxh.NULL_FEATURE
NULLO = NXOpen.NXObject.Null
TCB = NXOpen.Features.ThroughCurvesBuilder
SHEET = GU.FeatureOptions.BodyStyle.Sheet
NXROOT = os.environ.get("UGII_BASE_DIR", r"C:\Program Files\Siemens\NX2206")
res = {"result": "FAIL", "sections": {}, "notes": {}}
log = nxh.Log(os.path.join(OUT, "b1_build.log"))
chk = nxh.Check()
E = dict(sec_w=40.0, sec_h=24.0, sec_r=6.0, z2=35.0, d2=30.0, x2=4.0, z3=70.0, d3=20.0, x3=10.0,
         pad_l=60.0, pad_w=40.0, pad_h=30.0, crown=8.0, crown_z=15.0, wall=2.0, ext=5.0)
X0 = 100.0        # pad block origin x (BlockFeatureBuilder origin is a plain Point3d)


def start_of(sec):
    _c, p, v = sec.GetStartAndDirection()
    return [round(p.X, 3), round(p.Y, 3), round(p.Z, 3)], [round(v.X, 3), round(v.Y, 3), round(v.Z, 3)]


def through_curves(part, sections, solid=False, align=None, g1_first=None):
    b = part.Features.CreateThroughCurvesBuilder(NF)
    try:
        b.PreserveShape = False
        b.PatchType = TCB.PatchTypes.Multiple
        b.PositionTolerance = 0.01
        b.TangentTolerance = 0.5
        b.BodyPreference = TCB.BodyPreferenceTypes.Solid if solid else TCB.BodyPreferenceTypes.Sheet
        for s in sections:
            b.SectionsList.Append(s)
        b.Alignment.SetSections(list(sections))
        if align is not None:
            b.Alignment.AlignType = align
        if g1_first:
            b.FirstSectionContinuity.ContinuityType = GU.Continuity.ContinuityTypes.G1
            b.FirstSectionContinuity.ConstraintFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(g1_first))], False)
        return b.CommitFeature()
    finally:
        b.Destroy()


def studio_spline(part, pts, degree=2):
    SB = NXOpen.Features.StudioSplineBuilderEx
    b = part.Features.CreateStudioSplineBuilderEx(NULLO)
    try:
        b.Type = SB.Types.ThroughPoints
        b.Degree = degree
        b.IsAssociative = True
        b.IsPeriodic = False
        b.MatchKnotsType = SB.MatchKnotsTypes.NotSet
        b.OrientExpress.ReferenceOption = GU.OrientXpressBuilder.Reference.ProgramDefined
        b.DrawingPlaneOption = SB.DrawingPlaneOptions.General
        for p in pts:
            g = b.ConstraintManager.CreateGeometricConstraintData()
            g.Point = nxh.point(part, *p)
            b.ConstraintManager.Append(g)
        f = b.Commit()
        return f, b.Curve
    finally:
        b.Destroy()


def curve_mesh(part, primaries, crosses):
    b = part.Features.CreateThroughCurveMeshBuilder(NF)
    try:
        b.PositionTolerance = 0.01
        b.IntersectionTolerance = 0.01
        b.TangentTolerance = 0.5
        for s in primaries:
            b.PrimaryCurvesList.Append(s)
        for s in crosses:
            b.CrossCurvesList.Append(s)
        return b.CommitFeature()
    finally:
        b.Destroy()


def extend_sheet(part, edges, dist):
    ESB = NXOpen.Features.ExtendSheetBuilder
    b = part.Features.TrimFeatureCollection.CreateExtendSheetBuilder(NXOpen.Features.ExtendSheet.Null)
    try:
        b.DistanceTolerance = 0.01
        b.LimitMethod = ESB.Limit.Offset
        b.TargetBoundaryEdges.ReplaceRules([part.ScRuleFactory.CreateRuleEdgeDumb(list(edges))], False)
        b.Offset.RightHandSide = str(dist)
        b.SurfaceShapeOption = ESB.SurfaceShape.NaturalCurvature
        b.BodyOutputOption = ESB.BodyOutput.ExtendOriginalSheet
        return b.CommitFeature()
    finally:
        b.Destroy()


def trim_body_with_sheet(part, solid, tool_sheet, reverse=False):
    b = part.Features.CreateTrimBody2Builder(NXOpen.Features.TrimBody2.Null)
    try:
        b.Tolerance = 0.01
        b.BooleanTool.ToolOption = GU.BooleanToolBuilder.BooleanToolType.FaceOrPlane
        b.BooleanTool.FacePlaneTool.ToolFaces.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(tool_sheet)], False)
        b.TargetBodyCollector = nxh.collector(part, bodies=[solid])
        b.BooleanTool.ReverseDirection = reverse
        return b.CommitFeature()
    finally:
        b.Destroy()


def shell(part, body, removed_faces, thickness):
    b = part.Features.CreateShellBuilder(nxh.NULL_FEATURE)
    try:
        b.Tolerance = 0.01
        b.Body = body
        b.RemovedFacesCollector = nxh.collector(part, faces=removed_faces)
        b.DefaultThickness.RightHandSide = str(thickness)
        b.DefaultThicknessFlip = True
        return b.CommitFeature()
    finally:
        b.Destroy()


def revolve_sheet(part, curves, hp, origin, vec):
    b = part.Features.CreateRevolveBuilder(NF)
    try:
        b.Section = nxh.section(part, curves=curves, help_point=hp)
        b.Axis = nxh.axis(part, origin, vec)
        b.Limits.StartExtend.Value.RightHandSide = "0"
        b.Limits.EndExtend.Value.RightHandSide = "360"
        b.FeatureOptions.BodyType = SHEET
        b.BooleanOperation.Type = nxh.BOOL.Create
        b.Tolerance = 0.01
        return b.CommitFeature()
    finally:
        b.Destroy()


def bounded_plane(part, edges, hp):
    b = part.Features.CreateBoundedPlaneBuilder(NXOpen.Features.BoundedPlane.Null)
    try:
        b.BoundingCurves.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
        nxh.fill_section(part, b.BoundingCurves, edges=edges, help_point=hp)
        return b.CommitFeature()
    finally:
        b.Destroy()


def sew(part, target, tools, tol=0.01):
    b = part.Features.CreateSewBuilder(NF)
    try:
        b.Tolerance = tol
        b.TargetBodies.Add(target)
        for t in tools:
            b.ToolBodies.Add(t)
        return b.Commit()
    finally:
        b.Destroy()


def assoc_line(part, p0, p1):
    LB = NXOpen.Features.AssociativeLineBuilder
    b = part.BaseFeatures.CreateAssociativeLineBuilder(NXOpen.Features.AssociativeLine.Null)
    try:
        b.StartPointOptions = LB.StartOption.Point
        b.StartPoint.Value = nxh.point(part, *p0)
        b.EndPointOptions = LB.EndOption.Point
        b.EndPoint.Value = nxh.point(part, *p1)
        b.Associative = True
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)][0]


def assoc_arc(part, centre, radius, a0, a1, plane):
    AB = NXOpen.Features.AssociativeArcBuilder
    LO = GU.CurveExtendData.LimitOptions
    b = part.BaseFeatures.CreateAssociativeArcBuilder(NXOpen.Features.AssociativeArc.Null)
    try:
        b.Type = AB.Types.ArcFromCenter
        b.CenterPoint.Value = nxh.point(part, *centre)
        b.EndPointOptions = AB.EndOption.Radius
        b.Radius.RightHandSide = str(radius)
        b.Limits.StartLimit.LimitOption = LO.Value
        b.Limits.EndLimit.LimitOption = LO.Value
        # measured: on a smart plane offset from the datum XY plane the angle origin is -X (CCW about +Z);
        # on a fixed Planes.CreatePlane(point, +Z) it is +X. Angles here are given from +X, hence the 180 shift.
        s0 = (a0 + 180) % 360
        b.Limits.StartLimit.Distance.RightHandSide = str(s0)
        b.Limits.EndLimit.Distance.RightHandSide = str(s0 + (a1 - a0))
        b.Limits.FullCircle = False
        b.Associative = True
        b.SupportPlaneData.SupportPlane = plane      # without it the batch default plane is YZ (angle 0 at -Z)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, [e for e in f.GetEntities() if isinstance(e, NXOpen.Curve)][0]


def zplane(part, zexpr, zval):
    """Plane normal +Z at height zexpr: smart (offset from the datum XY plane by an expression) or fixed."""
    try:
        d = nxh.Datums(part)
        pl = part.Planes.CreatePlane(nxh.P(0, 0, 0), nxh.V(0, 0, 1), nxh.UPD)
        pl.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
        pl.SetGeometry([d.xy])
        pl.Expression.RightHandSide = str(zexpr)
        pl.Evaluate()
        res["notes"].setdefault("zplane", "smart offset plane")
        return pl
    except Exception as e:  # noqa: BLE001
        res["notes"]["zplane"] = "fixed plane: " + str(e)
        return part.Planes.CreatePlane(nxh.P(0, 0, zval), nxh.V(0, 0, 1), nxh.UPD)


def export_step(part, dest):
    b = nxh.S.DexManager.CreateStepCreator()
    try:
        b.ExportAs = NXOpen.StepCreator.ExportAsOption.Ap242
        b.InputFile = part.FullPath
        b.OutputFile = dest
        b.LayerMask = "1-256"
        b.ObjectTypes.Solids = True
        b.FileSaveFlag = False
        b.ProcessHoldFlag = True
        b.BsplineTol = 0.001
        b.Commit()
    finally:
        b.Destroy()
    t0, last = time.time(), -1
    while time.time() - t0 < 180:
        sz = os.path.getsize(dest) if os.path.exists(dest) else -1
        if sz > 0 and sz == last:
            break
        last = sz
        time.sleep(2)


def import_step242(part, path, scratch_prt):
    before = {b.Tag for b in part.Bodies}
    imp = nxh.S.DexManager.CreateStep242Importer()
    try:
        imp.SettingsFile = os.path.join(NXROOT, "TRANSLATORS", "step242", "step242ug.def")
        imp.ImportTo = NXOpen.Step242Importer.ImportToOption.WorkPart
        imp.ObjectTypes.Solids = True
        imp.InputFile = path
        imp.OutputFile = scratch_prt
        imp.FileOpenFlag = False
        imp.ProcessHoldFlag = True
        imp.Commit()
    finally:
        imp.Destroy()
    return [b for b in part.Bodies if b.Tag not in before]


# ---------------------------------------------------------------- analytic crown
def zf(x, y, c):
    u = 1 - ((x - X0) / (E["pad_l"] / 2) - 1) ** 2
    v = 1 - (y / (E["pad_w"] / 2) - 1) ** 2
    return E["crown_z"] + c / 2 * (u + v)


def grad(x, y, c):
    return (-c / 2 * 2 * ((x - X0) / (E["pad_l"] / 2) - 1) / (E["pad_l"] / 2),
            -c / 2 * 2 * (y / (E["pad_w"] / 2) - 1) / (E["pad_w"] / 2))


def offset_point(x, y, c, t):
    """Point of the crown at (x, y) moved t along the inward (downward) normal."""
    gx, gy = grad(x, y, c)
    n = math.sqrt(1 + gx * gx + gy * gy)
    return (x + t * gx / n, y + t * gy / n, zf(x, y, c) - t / n)


def cavity_volume(c, t, n=160):
    """Volume under the t-offset of the crown over the inner footprint (fixed-point inversion of the offset map)."""
    x0, x1, y0, y1 = X0 + t, X0 + E["pad_l"] - t, t, E["pad_w"] - t
    dx, dy, s = (x1 - x0) / n, (y1 - y0) / n, 0.0
    for i in range(n):
        for j in range(n):
            x, y = x0 + (i + 0.5) * dx, y0 + (j + 0.5) * dy
            a, b = x, y
            for _ in range(6):
                gx, gy = grad(a, b, c)
                m = math.sqrt(1 + gx * gx + gy * gy)
                a, b = x - t * gx / m, y - t * gy / m
            gx, gy = grad(a, b, c)
            m = math.sqrt(1 + gx * gx + gy * gy)
            s += (zf(a, b, c) - t / m) * dx * dy
    return s


def section_try(name, fn):
    log("SECTION", name)
    try:
        fn()
        res["sections"][name] = "done"
    except Exception:  # noqa: BLE001
        res["sections"][name] = traceback.format_exc()
        chk.true(name + " ran without exception", False, traceback.format_exc()[-400:])
        log(traceback.format_exc())


part = None
bodies = {}
state = {}
try:
    part = nxh.new_part(os.path.join(OUT, "b1_grip.prt"))
    for n, v in E.items():
        nxh.expr(part, n, v, "mm")

    # ============================================================ 1+2 loft through three closed sections
    def loft():
        w2, h2, r = E["sec_w"] / 2, E["sec_h"] / 2, E["sec_r"]
        hp = math.pi / 2
        X, Y = (1, 0, 0), (0, 1, 0)
        feats = {}
        mk0 = nxh.mark("assoc curves", False)
        try:    # associative Line / Arc features on smart points: the sections follow the expressions
            W, H, R = "sec_w/2", "sec_h/2", "sec_r"
            WR, HR = "(sec_w/2-sec_r)", "(sec_h/2-sec_r)"
            pl0, pl2, pl3 = zplane(part, "0", 0.0), zplane(part, "z2", E["z2"]), zplane(part, "z3", E["z3"])
            la = [assoc_line(part, (W, 0, 0), (W, HR, 0)),
                  assoc_arc(part, (WR, HR, 0), R, 0, 90, pl0),
                  assoc_line(part, (WR, H, 0), ("-" + WR, H, 0)),
                  assoc_arc(part, ("-" + WR, HR, 0), R, 90, 180, pl0),
                  assoc_line(part, ("-" + W, HR, 0), ("-" + W, "-" + HR, 0)),
                  assoc_arc(part, ("-" + WR, "-" + HR, 0), R, 180, 270, pl0),
                  assoc_line(part, ("-" + WR, "-" + H, 0), (WR, "-" + H, 0)),
                  assoc_arc(part, (WR, "-" + HR, 0), R, 270, 360, pl0),
                  assoc_line(part, (W, "-" + HR, 0), (W, 0, 0))]
            a2 = [assoc_arc(part, ("x2", 0, "z2"), "d2/2", 0, 180, pl2), assoc_arc(part, ("x2", 0, "z2"), "d2/2", 180, 360, pl2)]
            a3 = [assoc_arc(part, ("x3", 0, "z3"), "d3/2", 0, 180, pl3), assoc_arc(part, ("x3", 0, "z3"), "d3/2", 180, 360, pl3)]
            rr, c2, c3 = [c for _f, c in la], [c for _f, c in a2], [c for _f, c in a3]
            ends = lambda c: [[round(v, 4) for v in nxh.UFS.ModlGeneral.AskCurveProps(c.Tag, t)[0]] for t in (0.0, 1.0)]  # noqa: E731
            res["notes"]["assoc_curve_ends"] = {"rr": [ends(c) for c in rr], "c2": [ends(c) for c in c2], "c3": [ends(c) for c in c3]}
            res["notes"]["assoc_types"] = [la[0][0].FeatureType, la[1][0].FeatureType]
            for loop in (rr, c2, c3):
                for i, c in enumerate(loop):
                    e1, s2 = ends(c)[1], ends(loop[(i + 1) % len(loop)])[0]
                    if max(abs(a - b) for a, b in zip(e1, s2)) > 1e-4:
                        raise RuntimeError("associative loop not closed/ordered at curve %d: %s -> %s" % (i, e1, s2))
            feats = {"rr": [f for f, _c in la], "c2": [f for f, _c in a2], "c3": [f for f, _c in a3]}
            state["loft_assoc"] = True
        except Exception:  # noqa: BLE001
            res["notes"]["assoc_error"] = traceback.format_exc()[-700:]
            nxh.undo_to(mk0)
            feats = {}
            state["loft_assoc"] = False
            rr = [nxh.line(part, (w2, 0, 0), (w2, h2 - r, 0)),
                  nxh.arc(part, (w2 - r, h2 - r, 0), X, Y, r, 0.0, hp),
                  nxh.line(part, (w2 - r, h2, 0), (-(w2 - r), h2, 0)),
                  nxh.arc(part, (-(w2 - r), h2 - r, 0), X, Y, r, hp, 2 * hp),
                  nxh.line(part, (-w2, h2 - r, 0), (-w2, -(h2 - r), 0)),
                  nxh.arc(part, (-(w2 - r), -(h2 - r), 0), X, Y, r, 2 * hp, 3 * hp),
                  nxh.line(part, (-(w2 - r), -h2, 0), (w2 - r, -h2, 0)),
                  nxh.arc(part, (w2 - r, -(h2 - r), 0), X, Y, r, 3 * hp, 4 * hp),
                  nxh.line(part, (w2, -(h2 - r), 0), (w2, 0, 0))]
            c2 = nxh.circle(part, (E["x2"], 0, E["z2"]), E["d2"] / 2)
            c3 = nxh.circle(part, (E["x3"], 0, E["z3"]), E["d3"] / 2)

        def mk(key, curves, hpt, seed):
            if feats:
                return nxh.section(part, help_point=hpt, seed=seed, rules=[part.ScRuleFactory.CreateRuleCurveFeature(feats[key])])
            return nxh.section(part, curves=curves, help_point=hpt, seed=seed)
        p2, p3 = (E["x2"] + E["d2"] / 2, 0, E["z2"]), (E["x3"] + E["d3"] / 2, 0, E["z3"])
        ARC = GU.AlignmentMethodBuilder.Type.ArcLength

        # deliberately twisted variant (middle section started 180 deg away) - measured, then rolled back
        m = nxh.mark("twisted", False)
        try:
            s1 = mk("rr", rr, (w2, 0, 0), rr[0])
            s2 = mk("c2", c2, (E["x2"] - E["d2"] / 2, 0, E["z2"]), c2[1])
            s3 = mk("c3", c3, p3, c3[0])
            res["notes"]["twisted_starts"] = [start_of(s) for s in (s1, s2, s3)]
            tb = through_curves(part, [s1, s2, s3], solid=True, align=ARC).GetBodies()[0]
            res["notes"]["twisted"] = {"volume": nxh.volume(part, tb), "area": nxh.mass(part, [tb])["area"], "solid": tb.IsSolidBody}
        except Exception as e:  # noqa: BLE001
            res["notes"]["twisted"] = {"error": str(e)}
        nxh.undo_to(m)

        s1 = mk("rr", rr, (w2, 0, 0), rr[0])
        s2 = mk("c2", c2, p2, c2[0])
        s3 = mk("c3", c3, p3, c3[0])
        st = [start_of(s) for s in (s1, s2, s3)]
        res["notes"]["starts"] = st
        chk.true("B2 section starts on the +X side at y=0", st[0][0] == [w2, 0.0, 0.0] and st[1][0] == [p2[0], 0.0, p2[2]] and st[2][0] == [p3[0], 0.0, p3[2]], st)
        chk.true("B2 section directions all +Y", all(s[1] == [0.0, 1.0, 0.0] for s in st), st)
        f = through_curves(part, [s1, s2, s3], solid=True, align=ARC)
        body = f.GetBodies()[0]
        bodies["loft"] = body
        state["v_loft"] = nxh.volume(part, body)
        mp = nxh.mass(part, [body])
        A1 = E["sec_w"] * E["sec_h"] - (4 - math.pi) * r * r
        A2, A3 = math.pi * E["d2"] ** 2 / 4, math.pi * E["d3"] ** 2 / 4
        simpson = E["z3"] / 6 * (A1 + 4 * A2 + A3)
        res["notes"]["loft"] = {"volume": mp["volume"], "area": mp["area"], "centroid": mp["centroid"], "simpson_estimate": simpson,
                                "census": nxh.face_census(body), "bbox": nxh.bbox(body)}
        chk.true("B2 loft is a solid", body.IsSolidBody)
        chk("B2 loft volume vs Simpson estimate through the 3 section areas (3 %)", mp["volume"], simpson, 0.03 * simpson)
        chk("B2 centroid y = 0 (symmetric, untwisted)", mp["centroid"][1], 0.0, 0.01)
        tw = res["notes"]["twisted"].get("volume")
        chk.true("B2 twisted variant differs measurably (volume)", tw is not None and abs(tw - mp["volume"]) > 0.02 * mp["volume"], "twisted %s vs %s" % (tw, mp["volume"]))
        # the three sections lie on the body; the y=0 generator on the +X side passes the three start points
        for i, p in enumerate([(w2, 0, 0), (0, h2, 0), (E["x2"], E["d2"] / 2, E["z2"]), (E["x2"] - E["d2"] / 2, 0, E["z2"]), (E["x3"], -E["d3"] / 2, E["z3"])]):
            chk("B1 section point %d on the body" % i, nxh.dist_to(part, body, p), 0.0, 0.01)
        chk.true("B2 Examine Geometry clean", nxh.body_ok(part, body), nxh.examine_geometry(part, body))
    section_try("loft", loft)

    # ============================================================ 3 crowned pad: mesh -> extend -> trim body -> shell

    def crown_pad():
        L, W, c, ze = E["pad_l"], E["pad_w"], E["crown"], E["crown_z"]
        xs = [("%g" % X0, X0), ("%g+pad_l/2" % X0, X0 + L / 2), ("%g+pad_l" % X0, X0 + L)]
        ys = [("0", 0.0), ("pad_w/2", W / 2), ("pad_w", W)]
        hz = ["crown_z", "crown_z+crown/2", "crown_z+crown"]          # index = number of mid coordinates
        prim, cross = [], []
        for j in range(3):          # primaries run along X at y_j
            f, crv = studio_spline(part, [(xs[i][0], ys[j][0], hz[(i == 1) + (j == 1)]) for i in range(3)])
            prim.append((f, crv, (xs[0][1], ys[j][1], zf(xs[0][1], ys[j][1], c))))
        for i in range(3):          # crosses run along Y at x_i
            f, crv = studio_spline(part, [(xs[i][0], ys[j][0], hz[(i == 1) + (j == 1)]) for j in range(3)])
            cross.append((f, crv, (xs[i][1], ys[0][1], zf(xs[i][1], ys[0][1], c))))
        res["notes"]["spline_types"] = [prim[0][0].FeatureType, type(prim[0][0]).__name__]
        res["notes"]["spline_len"] = prim[1][1].GetLength()

        def sec_of(f, crv, hp):
            try:
                s = nxh.section(part, help_point=hp, seed=crv, rules=[part.ScRuleFactory.CreateRuleCurveFeature([f])])
                res["notes"].setdefault("sec_rule", "CurveFeature (associative)")
                return s
            except Exception as e:  # noqa: BLE001
                res["notes"]["sec_rule"] = "dumb fallback: " + str(e)
                return nxh.section(part, curves=[crv], help_point=hp)
        ps = [sec_of(*t) for t in prim]
        cs = [sec_of(*t) for t in cross]
        res["notes"]["mesh_starts"] = {"primaries": [start_of(s) for s in ps], "crosses": [start_of(s) for s in cs]}
        mf = curve_mesh(part, ps, cs)
        sheet = mf.GetBodies()[0]
        state["sheet"] = sheet
        res["notes"]["mesh"] = {"type": mf.FeatureType, "area": nxh.sheet_area(part, sheet)[0], "census": nxh.face_census(sheet), "free_edges": len(nxh.free_edges(sheet))}
        chk("B3 mesh: apex on the surface (crown 8 above the corners)", nxh.dist_to(part, sheet, (X0 + L / 2, W / 2, ze + c)), 0.0, 0.01)
        chk("B3 mesh: corner on the surface", nxh.dist_to(part, sheet, (X0, 0, ze)), 0.0, 0.01)
        chk("B3 mesh: quarter point matches z = ze + c/2 (u+v)", nxh.dist_to(part, sheet, (X0 + 15, 10, zf(X0 + 15, 10, c))), 0.0, 0.01)
        chk("B3 mesh footprint 60 x 40 (bbox dx)", nxh.bbox(sheet)[3] - nxh.bbox(sheet)[0], L, 0.05)
        ef = extend_sheet(part, nxh.free_edges(sheet), "ext")
        bb = nxh.bbox(sheet)
        res["notes"]["extended_bbox"] = bb
        chk.true("B3 Extend Sheet: sheet overshoots the block on all four sides", bb[0] < X0 - 4 and bb[3] > X0 + L + 4 and bb[1] < -4 and bb[4] > W + 4, bb)
        _bf, blk = nxh.block(part, (X0, 0, 0), ("pad_l", "pad_w", "pad_h"))
        bodies["pad"] = blk
        want = L * W * (ze + 2 * c / 3)
        used = None
        for rev in (False, True):
            m = nxh.mark("trim", False)
            trim_body_with_sheet(part, blk, sheet, rev)
            v = nxh.volume(part, blk)
            res["notes"].setdefault("trim_tries", []).append({"reverse": rev, "volume": v})
            if abs(v - want) < 0.01 * want:
                used = rev
                break
            nxh.undo_to(m)
        res["notes"]["trim_reverse_used"] = used
        chk("B3 Trim Body: volume under the crown = L W (ze + 2c/3)", nxh.volume(part, blk), want, 2.0)
        chk("B3 solids after trim (tool sheet stays a sheet)", len([b for b in nxh.solids(part) if b.Tag == blk.Tag]), 1, 0)
        res["notes"]["pad_census_trim"] = nxh.face_census(blk)
        state["v_trim"] = nxh.volume(part, blk)
        bottom = nxh.faces(blk, ftype=nxh.PLANE, normal=(0, 0, -1))
        shell(part, blk, bottom, "wall")
        res["notes"]["pad_census_shell"] = nxh.face_census(blk)

    def pad_checks(tag, c):
        blk, t, L, W = bodies["pad"], E["wall"], E["pad_l"], E["pad_w"]
        v = nxh.volume(part, blk)
        want = L * W * (E["crown_z"] + 2 * c / 3) - cavity_volume(c, t)
        chk("B3 %s shell volume = solid - cavity under the 2 mm offset crown" % tag, v, want, 3.0)
        # NOT by bbox z: the B-surface bbox is loose (inner face reported zmax 23.78, true 21.0) - pick by area
        bs = sorted(nxh.faces(blk, ftype=nxh.BSURF), key=lambda f: -nxh.sheet_area(part, [f])[0])
        res["notes"]["bsurf_faces_" + tag] = [nxh.bbox(f) for f in bs]
        if len(bs) >= 2:
            outer, inner = bs[0], bs[1]
            chk("B3 %s top wall thickness (min distance outer/inner crown faces)" % tag, nxh.min_dist(outer, inner), t, 0.01)
            devs = []
            for (x, y) in ((X0 + 30, 20), (X0 + 15, 10), (X0 + 45, 30), (X0 + 8, 20), (X0 + 30, 34), (X0 + 52, 8)):
                devs.append(nxh.dist_to(part, inner, offset_point(x, y, c, t)))
                devs.append(abs(nxh.dist_to(part, inner, (x, y, zf(x, y, c))) - t))
            res["notes"]["cavity_follow_dev_" + tag] = [round(d, 5) for d in devs]
            chk("B3 %s cavity top follows the crown (max dev of 6 offset points + 6 thickness samples)" % tag, max(devs), 0.0, 0.02)
            chk("B3 %s outer apex height" % tag, nxh.dist_to(part, outer, (X0 + 30, 20, E["crown_z"] + c)), 0.0, 0.01)
        else:
            chk.true("B3 %s two crowned faces (outer + cavity)" % tag, False, len(bs))
        xo = nxh.faces(blk, ftype=nxh.PLANE, normal=(-1, 0, 0))
        xi = nxh.faces(blk, ftype=nxh.PLANE, normal=(1, 0, 0))
        outer_x = [f for f in xo if abs(nxh.bbox(f)[0] - X0) < 0.01]
        inner_x = [f for f in xi if abs(nxh.bbox(f)[0] - (X0 + t)) < 0.01]
        chk.true("B3 %s side wall faces found" % tag, len(outer_x) == 1 and len(inner_x) == 1, (len(outer_x), len(inner_x)))
        if outer_x and inner_x:
            chk("B3 %s side wall thickness" % tag, nxh.min_dist(outer_x[0], inner_x[0]), t, 1e-4)
        chk.true("B3 %s Examine Geometry clean" % tag, nxh.body_ok(part, blk), nxh.examine_geometry(part, blk))
        return v
    section_try("crown pad", crown_pad)
    section_try("crown pad checks", lambda: state.__setitem__("v8", pad_checks("crown8", 8.0)))

    # ============================================================ 4 open sheet -> caps -> sew -> solid
    def sheet_to_solid():
        yc = 150.0
        prof = [nxh.line(part, (20, yc, 0), (10, yc, 40)), nxh.line(part, (10, yc, 40), (10, yc, 55))]
        tube = revolve_sheet(part, prof, (20, yc, 0), (0, yc, 0), (0, 0, 1)).GetBodies()[0]
        fe = nxh.free_edges(tube)
        res["notes"]["tube"] = {"solid": tube.IsSolidBody, "free_edges": len(fe), "area": nxh.sheet_area(part, tube)[0],
                                "examine": nxh.examine_geometry(part, tube), "census": nxh.face_census(tube)}
        chk.true("B4 revolve as sheet is a sheet", not tube.IsSolidBody)
        chk("B4 open sheet area (cone + cylinder)", nxh.sheet_area(part, tube)[0], math.pi * 30 * math.sqrt(1700) + 2 * math.pi * 10 * 15, 0.01)
        chk.true("B4 open sheet has free edges", len(fe) >= 2, len(fe))
        lo = [e for e in fe if abs(nxh.bbox(e)[5]) < 1e-3]
        hi = [e for e in fe if abs(nxh.bbox(e)[2] - 55) < 1e-3]
        caps = [bounded_plane(part, lo, (20, yc, 0)).GetBodies()[0], bounded_plane(part, hi, (10, yc, 55)).GetBodies()[0]]
        chk("B4 cap areas", sum(nxh.sheet_area(part, c)[0] for c in caps), math.pi * 500, 0.01)
        n_sheets = len(nxh.sheets(part))
        sewn = sew(part, tube, caps).GetBodies()[0]
        bodies["sewn"] = sewn
        chk.true("B4 sewn body IsSolidBody", sewn.IsSolidBody)
        chk("B4 free edges after sew", len(nxh.free_edges(sewn)), 0, 0)
        chk("B4 volume = frustum + cylinder", nxh.volume(part, sewn), math.pi * 40 / 3 * 700 + math.pi * 100 * 15, 0.01)
        chk("B4 sew consumed 3 sheets", n_sheets - len(nxh.sheets(part)), 3, 0)
        eg = nxh.examine_geometry(part, sewn)
        chk.true("B4 Examine Geometry clean (BodySheetBoundaries 0)", all(v == 0 for v in eg.values()), eg)
    section_try("sheet to solid", sheet_to_solid)

    # ============================================================ 5 continuity: G0 vs G1 at a shared edge
    def continuity():
        out = {}
        for tag, y0, g1 in (("G0", 300.0, False), ("G1", 400.0, True)):
            base_f = nxh.extrude(part, nxh.section(part, curves=[nxh.line(part, (300, y0, 0), (340, y0, 0))], help_point=(300, y0, 0)),
                                 (0, -1, 0), 0, 30, sheet=True)
            base = base_f.GetBodies()[0]
            edge = [e for e in base.GetEdges() if abs(nxh.bbox(e)[1] - y0) < 1e-6 and abs(nxh.bbox(e)[4] - y0) < 1e-6][0]
            s1 = nxh.section(part, edges=[edge], help_point=(300, y0, 0))
            s2 = nxh.section(part, curves=[nxh.line(part, (300, y0 + 30, 20), (340, y0 + 30, 20))], help_point=(300, y0 + 30, 20))
            res["notes"]["cont_starts_" + tag] = [start_of(s1), start_of(s2)]
            lf = through_curves(part, [s1, s2], g1_first=base.GetFaces() if g1 else None)
            loft_b = lf.GetBodies()[0]
            fa, fb = base.GetFaces()[0], loft_b.GetFaces()[0]
            pts = [(305, y0, 0), (320, y0, 0), (335, y0, 0)]
            na, nb = nxh.normal_at(fa, pts[1]), nxh.normal_at(fb, pts[1])
            raw = nxh.g1_deviation(fa, fb, pts)
            folded = max(min(nxh.angle_deg(nxh.normal_at(fa, p), nxh.normal_at(fb, p)), 180 - nxh.angle_deg(nxh.normal_at(fa, p), nxh.normal_at(fb, p))) for p in pts)
            out[tag] = {"g1_deviation_nxh": raw, "g1_deviation_sign_free": folded, "normal_base": na, "normal_loft": nb,
                        "curv_base": nxh.max_curvature(fa, pts[1]), "curv_loft": nxh.max_curvature(fb, pts[1]),
                        "area": nxh.sheet_area(part, loft_b)[0], "separate_bodies": base.Tag != loft_b.Tag}
        res["notes"]["continuity"] = out
        chk("B5 G0 join: normal deviation = atan(20/30)", out["G0"]["g1_deviation_sign_free"], math.degrees(math.atan2(20, 30)), 0.01)
        chk("B5 G1 join: normal deviation 0", out["G1"]["g1_deviation_sign_free"], 0.0, 0.01)
        chk.true("B5 G1 loft is longer than the flat G0 one", out["G1"]["area"] > out["G0"]["area"] + 10, (out["G0"]["area"], out["G1"]["area"]))
    section_try("continuity", continuity)

    # ============================================================ 6 regeneration: crown 8 -> 12 -> 8
    def regen():
        nxh.set_expr(part, "crown", 12)
        nxh.update()
        res["notes"]["errors_crown12"] = nxh.feature_errors(part)
        chk("B6 crown 12: no feature errors", len(res["notes"]["errors_crown12"]), 0, 0)
        v12 = pad_checks("crown12", 12.0)
        chk.true("B6 crown 12: volume changed", abs(v12 - state["v8"]) > 100, (state["v8"], v12))
        nxh.set_expr(part, "crown", 8)
        nxh.update()
        chk("B6 round trip to crown 8", nxh.volume(part, bodies["pad"]), state["v8"], state["v8"] * 1e-6)
        # a second master: wall 2 -> 3 -> 2
        nxh.set_expr(part, "wall", 3)
        nxh.update()
        E["wall"] = 3.0
        pad_checks("wall3", 8.0)
        E["wall"] = 2.0
        nxh.set_expr(part, "wall", 2)
        nxh.update()
        chk("B6 round trip to wall 2", nxh.volume(part, bodies["pad"]), state["v8"], state["v8"] * 1e-6)
        chk("B6 no feature errors at the end", len(nxh.feature_errors(part)), 0, 0)
        if state.get("loft_assoc"):          # the loft sections are associative arc/line features: d3 20 -> 24, z2 35 -> 40
            lb = bodies["loft"]
            nxh.set_expr(part, "d3", 24)
            nxh.set_expr(part, "z2", 40)
            nxh.update()
            chk("B6 loft regen: top circle now dia 24", nxh.dist_to(part, lb, (E["x3"] + 12, 0, E["z3"])), 0.0, 0.01)
            chk("B6 loft regen: middle section now at z 40", nxh.dist_to(part, lb, (E["x2"], 15, 40)), 0.0, 0.01)
            a1 = E["sec_w"] * E["sec_h"] - (4 - math.pi) * E["sec_r"] ** 2
            # sections at z 0 / 40 / 70 are not equally spaced: integrate the quadratic through the three areas
            z0, z1, z2_ = 0.0, 40.0, 70.0
            A = [a1, math.pi * 225, math.pi * 144]
            est = 0.0
            for i, (za, zb, zc) in enumerate(((z0, z1, z2_), (z1, z0, z2_), (z2_, z0, z1))):
                # integral over 0..70 of the Lagrange basis polynomial of node za
                f3 = lambda z: (z ** 3 / 3 - (zb + zc) * z ** 2 / 2 + zb * zc * z) / ((za - zb) * (za - zc))  # noqa: E731
                est += A[i] * (f3(70.0) - f3(0.0))
            v = nxh.volume(part, lb)
            res["notes"]["loft_regen"] = {"volume": v, "estimate": est, "errors": nxh.feature_errors(part)}
            chk("B6 loft regen: volume vs quadratic-area estimate (4 %)", v, est, 0.04 * est)
            chk("B6 loft regen: no feature errors", len(nxh.feature_errors(part)), 0, 0)
            nxh.set_expr(part, "d3", 20)
            nxh.set_expr(part, "z2", 35)
            nxh.update()
            chk("B6 loft round trip", nxh.volume(part, lb), state["v_loft"], state["v_loft"] * 1e-6)
        chk.true("B6 loft sections are associative (expression driven)", bool(state.get("loft_assoc")), res["notes"].get("assoc_error", ""))
    section_try("regen", regen)

    # ============================================================ 7 save + STEP of the solids
    def export():
        res["tree"] = nxh.feature_table(part)
        res["feature_errors"] = nxh.feature_errors(part)
        sol = nxh.solids(part)
        res["notes"]["solids"] = [{"volume": nxh.volume(part, b), "bbox": nxh.bbox(b)} for b in sol]
        res["notes"]["n_sheets"] = len(nxh.sheets(part))
        chk("B7 three solids in the part", len(sol), 3, 0)
        vsum = sum(nxh.volume(part, b) for b in sol)
        nxh.save(part)
        stp = os.path.join(OUT, "b1_grip.step")
        if os.path.exists(stp):
            os.remove(stp)
        export_step(part, stp)
        txt = open(stp, errors="ignore").read() if os.path.exists(stp) else ""
        res["notes"]["step"] = {"size": len(txt), "n_solid_brep": txt.count("MANIFOLD_SOLID_BREP")}
        chk("B7 STEP: 3 MANIFOLD_SOLID_BREP", txt.count("MANIFOLD_SOLID_BREP"), 3, 0)
        p2 = nxh.new_part(os.path.join(OUT, "b1_reimport.prt"))
        back = import_step242(p2, stp, os.path.join(OUT, "b1_scratch.prt"))
        chk("B7 STEP re-import: 3 bodies", len(back), 3, 0)
        chk.true("B7 STEP re-import: all solid", all(b.IsSolidBody for b in back))
        chk("B7 STEP re-import: total volume (rel 1e-5)", sum(nxh.volume(p2, b) for b in back), vsum, vsum * 1e-5)
    section_try("export", export)
    res.update(chk.report())
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    res["checks"] = chk.rows
nxh.write_json(os.path.join(OUT, "b1_build.json"), res)

