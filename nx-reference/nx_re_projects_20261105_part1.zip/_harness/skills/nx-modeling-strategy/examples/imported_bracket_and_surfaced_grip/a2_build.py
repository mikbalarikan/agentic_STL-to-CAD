"""Task A: rework the imported CAPTURE_NOMINAL body. Args: <out dir>"""
import math
import os
import sys
import time
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen  # noqa: E402
import NXOpen.Features  # noqa: E402
import NXOpen.GeometricUtilities  # noqa: E402
import nxh  # noqa: E402

OUT = sys.argv[1]
NF = NXOpen.Features
NULL = nxh.NULL_FEATURE
NULLO = NXOpen.NXObject.Null
NXROOT = os.environ.get("UGII_BASE_DIR", r"C:\Program Files\Siemens\NX2206")
res = {"result": "FAIL", "steps": {}}
log = nxh.Log(os.path.join(OUT, "a2_build.log"))
chk = nxh.Check()


def import_step242(part, path, scratch_prt):
    before = {b.Tag for b in part.Bodies}
    imp = nxh.S.DexManager.CreateStep242Importer()
    try:
        imp.SettingsFile = os.path.join(NXROOT, "TRANSLATORS", "step242", "step242ug.def")
        imp.ImportTo = NXOpen.Step242Importer.ImportToOption.WorkPart
        imp.ObjectTypes.Solids = True
        imp.InputFile = path
        imp.OutputFile = scratch_prt
        imp.FileOpenFlag = False
        imp.ProcessHoldFlag = True
        imp.Commit()
    finally:
        imp.Destroy()
    return [b for b in part.Bodies if b.Tag not in before]


def optimize_face(part, body):
    b = part.Features.CreateOptimizeFaceBuilder()
    try:
        b.FacesToOptimize.ReplaceRules([part.ScRuleFactory.CreateRuleFaceBody(body)], False)
        b.CleanBody = True
        b.Report = False
        b.DistanceTolerance = 0.01
        b.Commit()
    finally:
        b.Destroy()


def delete_face(part, faces):
    b = part.Features.CreateDeleteFaceBuilder(NULL)
    try:
        b.Type = NF.DeleteFaceBuilder.SelectTypes.Face
        b.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        b.Heal = True
        return b.CommitFeature()
    finally:
        b.Destroy()


def offset_region(part, faces, distance):
    b = part.Features.CreateAdmOffsetRegionBuilder(NF.AdmOffsetRegion.Null)
    try:
        b.FaceToOffset.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        b.Distance.RightHandSide = str(distance)
        return b.CommitFeature()
    finally:
        b.Destroy()


def resize_face(part, faces, diameter):
    b = part.Features.CreateAdmResizeFaceBuilder(NF.AdmResizeFace.Null)
    try:
        b.FaceToResize.FaceCollector.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        b.Diameter.RightHandSide = str(diameter)
        return b.CommitFeature()
    finally:
        b.Destroy()


def replace_face(part, faces, datum):
    b = part.Features.CreateReplaceFaceBuilder(NULL)
    try:
        b.FaceToReplace.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDumb(list(faces))], False)
        b.ReplacementFaces.ReplaceRules([part.ScRuleFactory.CreateRuleFaceDatum([datum])], False)
        b.OffsetDistance.RightHandSide = "0"
        return b.CommitFeature()
    finally:
        b.Destroy()


def hole_through(part, body, pt, vec, dia):
    HPB = NF.HolePackageBuilder
    h = part.Features.CreateHolePackageBuilder(NF.HolePackage.Null)
    try:
        h.Type = HPB.Types.GeneralHole
        h.GeneralHoleForm = HPB.HoleForms.Simple
        h.GeneralSimpleHoleDiameter.RightHandSide = str(dia)
        h.HoleDepthLimitOption = HPB.HoleDepthLimitOptions.ThroughBody
        h.Tolerance = 0.01
        h.StartExtensionEnabled = False
        h.BooleanOperation.Type = nxh.BOOL.Subtract
        h.BooleanOperation.SetTargetBodies([body])
        h.HolePosition.AddToSection([part.ScRuleFactory.CreateRuleCurveDumbFromPoints([pt])], NULLO, NULLO, NULLO,
                                    nxh.P(0, 0, 0), NXOpen.Section.Mode.Create, False)
        h.ProjectionDirection.ProjectDirectionMethod = NXOpen.GeometricUtilities.ProjectionOptions.DirectionType.Vector
        h.ProjectionDirection.ProjectVector = nxh.direction(part, vec)
        return h.CommitFeature()
    finally:
        h.Destroy()


def chamfer(part, edges, offset):
    CB = NF.ChamferBuilder
    b = part.Features.CreateChamferBuilder(NULL)
    try:
        b.Option = CB.ChamferOption.SymmetricOffsets
        b.Method = CB.OffsetMethod.EdgesAlongFaces
        b.FirstOffset = str(offset)
        b.Tolerance = 0.01
        b.SmartCollector = nxh.collector(part, edges=edges)
        return b.CommitFeature()
    finally:
        b.Destroy()


def export_step(part, dest):
    b = nxh.S.DexManager.CreateStepCreator()
    try:
        b.ExportAs = NXOpen.StepCreator.ExportAsOption.Ap242
        b.InputFile = part.FullPath
        b.OutputFile = dest
        b.LayerMask = "1-256"
        b.ObjectTypes.Solids = True
        b.FileSaveFlag = False
        b.ProcessHoldFlag = True
        b.BsplineTol = 0.001
        b.Commit()
    finally:
        b.Destroy()
    t0, last = time.time(), -1
    while time.time() - t0 < 180:
        sz = os.path.getsize(dest) if os.path.exists(dest) else -1
        if sz > 0 and sz == last:
            break
        last = sz
        time.sleep(2)


def countersunk_hole_volume(k):
    """chamfer 0.6 (r 5.1 -> 4.5) + cylinder r 4.5, x 0.6..6.375 + 45 deg countersink up to the roof x = 11 - k|y|."""
    v = math.pi * 0.6 / 3 * (5.1 ** 2 + 5.1 * 4.5 + 4.5 ** 2) + math.pi * 4.5 ** 2 * 5.775
    v += 4.625 * math.pi * 4.5 ** 2 - k * 4 * 4.5 ** 3 / 3            # column over rho <= 4.5 up to the roof
    n, s = 20000, 0.0
    for i in range(n):                                                  # annulus rho 4.5 .. R(theta)
        th = (i + 0.5) * 2 * math.pi / n
        c = 1 + k * abs(math.sin(th))
        R = 9.125 / c
        s += (9.125 * R * R / 2 - c * R ** 3 / 3) - (9.125 * 4.5 ** 2 / 2 - c * 4.5 ** 3 / 3)
    return v + s * 2 * math.pi / n


def bore_resize_dv(r0, r1, half_angle):
    """Revolved difference when the bore r0 -> r1: 45 deg entry chamfer (r 5 at z0) and a drill-point cone stay."""
    t = math.tan(half_angle)
    n, s = 290000, 0.0
    dz = 29.0 / n                                         # z from the boss end face into the hole; old cylinder ends at 29

    def prof(z, r):
        return min(max(5.0 - z, r), r0 + (29.0 - z) * t)  # chamfer cone | cylinder | drill-point cone through (29, r0)
    for i in range(n):
        z = (i + 0.5) * dz
        s += math.pi * (prof(z, r1) ** 2 - prof(z, r0) ** 2) * dz
    return s


def step(name, fn):
    log("STEP", name)
    out, err = nxh.attempt(name, fn, log=log)
    res["steps"][name] = {"ok": err is None, "error": err}
    return out, err


try:
    part = nxh.new_part(os.path.join(OUT, "a2_bracket.prt"))
    RF = part.ScRuleFactory
    new = import_step242(part, os.path.join(OUT, "CAPTURE_NOMINAL.step"), os.path.join(OUT, "a2_scratch.prt"))
    chk("1 one body imported", len(new), 1, 0)
    body = new[0]
    chk.true("1 imported body is solid", body.IsSolidBody)
    eg0 = nxh.examine_geometry(part, body)
    res["examine_import"] = eg0
    chk.true("1 Examine Geometry clean on import", all(v == 0 for v in eg0.values()), eg0)
    V_import = nxh.volume(part, body)
    res["V_import"] = V_import
    optimize_face(part, body)
    V0 = nxh.volume(part, body)
    res["V_after_optimize"] = V0
    res["optimize_dV"] = V0 - V_import
    res["census_0"] = nxh.face_census(body)
    vol = lambda: nxh.volume(part, body)  # noqa: E731
    for n, v in (("base_add", 2), ("bore_d", 9.5), ("side_add", 3), ("hole_d", 6), ("cham", 0.5)):
        nxh.expr(part, n, v, "mm")

    # ---- 2 de-feature: the two dia 9 countersunk through holes in the base (axis X)
    def is_base_hole_face(f):
        t, pt, d, rad = nxh.face_data(f)
        bb = nxh.bbox(f)
        return t in (nxh.CYLINDER, nxh.CONE) and abs(abs(d[0]) - 1) < 1e-6 and bb[0] > -0.01 and bb[3] < 11.01 and abs(pt[1]) < 0.01
    hf = [f for f in body.GetFaces() if is_base_hole_face(f)]
    res["hole_faces"] = [{"type": nxh.face_data(f)[0], "rad": round(nxh.face_data(f)[3], 4), "bbox": nxh.bbox(f)} for f in hf]
    roof = [f for f in nxh.faces(body, ftype=nxh.PLANE) if nxh.face_data(f)[2][0] > 0.99 and nxh.bbox(f)[5] < -60]
    nrm = nxh.face_data(roof[0])[2]
    k = abs(nrm[1]) / nrm[0]
    res["roof_slope_deg"] = math.degrees(math.atan(k))
    v_hole = countersunk_hole_volume(k)
    res["v_one_countersunk_hole"] = v_hole
    chk("2 six hole faces found (2 x chamfer+cyl+csk)", len(hf), 6, 0)
    step("delete holes", lambda: delete_face(part, hf))
    V2 = vol()
    chk("2 Delete Face holes: dV = 2 x analytic hole volume", V2 - V0, 2 * v_hole, 0.05)
    res["census_2"] = nxh.face_census(body)
    chk("2 faces removed", res["census_0"]["faces"] - res["census_2"]["faces"], 6, 0)

    # ---- 3 thicken the base: Offset Region on the largest planar face
    planes = sorted(nxh.faces(body, ftype=nxh.PLANE), key=lambda f: -nxh.sheet_area(part, [f])[0])
    base = planes[0]
    A_base = nxh.sheet_area(part, [base])[0]
    res["base_face"] = {"area": A_base, "normal": nxh.face_data(base)[2], "bbox": nxh.bbox(base)}
    step("offset region base", lambda: offset_region(part, [base], "base_add"))
    V3 = vol()
    chk("3 Offset Region base +2: dV = area x 2", V3 - V2, A_base * 2, 0.02)
    chk("3 base face now at x = -2", nxh.bbox(body)[0], -2.0, 0.01)

    # ---- 4 enlarge the boss bore dia 8.5 -> 9.5
    bore = [f for f in nxh.faces(body, ftype=nxh.CYLINDER, radius=4.25) if abs(abs(nxh.face_data(f)[2][2]) - 1) < 1e-6]
    chk("4 one bore face r 4.25", len(bore), 1, 0)
    cone = [f for f in nxh.faces(body, ftype=nxh.CONE) if abs(nxh.bbox(f)[5] + 90.2266) < 0.01 and abs(nxh.bbox(f)[2] + 91.0) < 0.01]
    half = nxh.UFS.Modeling.AskFaceData(cone[0].Tag)[5] if cone else math.radians(59)
    res["bore_tip_half_angle_deg"] = math.degrees(half)
    dv_bore = bore_resize_dv(4.25, 4.75, half)
    res["bore_dv_expected"] = dv_bore
    step("resize bore", lambda: resize_face(part, bore, "bore_d"))
    V4 = vol()
    chk("4 Resize Face bore: dV = -(revolved profile difference)", V4 - V3, -dv_bore, 0.05)
    chk("4 bore radius now 4.75", len([f for f in nxh.faces(body, ftype=nxh.CYLINDER, radius=4.75) if abs(abs(nxh.face_data(f)[2][2]) - 1) < 1e-6]), 1, 0)

    # ---- 5 Replace Face: side face y = +15 -> datum plane y = 15 + side_add
    side = nxh.faces(body, ftype=nxh.PLANE, normal=(0, 1, 0), at=(1, 15.0), tol=0.01)
    res["side_candidates"] = [{"area": nxh.sheet_area(part, [f])[0], "bbox": nxh.bbox(f)} for f in side]
    _df, dpl = nxh.datum_plane(part, (0, "15+side_add", 0), (0, 1, 0), name="SIDE_TARGET")
    A_side = nxh.sheet_area(part, side)[0] if side else 0.0
    _f, err = step("replace side face y15", lambda: replace_face(part, side, dpl))
    V5 = vol()
    res["replace_choice"] = "y=+15 side face"
    if err is None:
        got = nxh.faces(body, ftype=nxh.PLANE, normal=(0, 1, 0), at=(1, 18.0), tol=0.01)
        chk.true("5 Replace Face: side face lies on y = 18", len(got) >= 1, [nxh.bbox(f) for f in got])
        res["replace_dV"] = V5 - V4
        res["replace_area_x3"] = A_side * 3
        res["replace_new_area"] = nxh.sheet_area(part, got)[0] if got else None
        chk.true("5 Replace Face: volume grew (approx area x 3)", V5 - V4 > 0.8 * A_side * 3, "dV %.3f vs area x 3 %.3f" % (V5 - V4, A_side * 3))
        chk("5 bbox ymax = 18", nxh.bbox(body)[4], 18.0, 0.01)
    else:
        chk.true("5 Replace Face y=+15", False, err)
    res["errors_after_5"] = nxh.feature_errors(part)
    res['census_5'] = nxh.face_census(body)
    res['blend_r15_faces_after_5'] = len(nxh.faces(body, ftype=nxh.CYLINDER, radius=1.5))

    # ---- 6 native Hole dia 6 through the base at (y 0, z -90) + 0.5 chamfer on the entry edge
    pt = nxh.point(part, "-base_add", 0, 0)   # z -90 failed: ThroughBody also runs through the web (y +-3 = tangent) and the boss
    step("hole", lambda: hole_through(part, body, pt, (1, 0, 0), "hole_d"))
    V6 = vol()
    v_newhole = math.pi * 9 * 13 - k * 36.0
    chk("6 Hole dia 6 through: dV = cylinder to the roofed top", V6 - V5, -v_newhole, 0.02)
    hcyl = [f for f in nxh.faces(body, ftype=nxh.CYLINDER, radius=3.0) if abs(abs(nxh.face_data(f)[2][0]) - 1) < 1e-6
            and abs(nxh.face_data(f)[1][2]) < 0.01 and abs(nxh.face_data(f)[1][1]) < 0.01]
    chk("6 hole face r 3 on axis (y 0, z 0)", len(hcyl), 1, 0)
    entry = [e for e in hcyl[0].GetEdges() if abs(nxh.bbox(e)[0] + 2) < 0.01 and abs(nxh.bbox(e)[3] + 2) < 0.01] if hcyl else []
    res["entry_edges"] = len(entry)
    step("chamfer", lambda: chamfer(part, entry, "cham"))
    V7 = vol()
    v_cham = math.pi * ((3.5 ** 3 - 27) / 3 - 4.5)
    chk("6 Chamfer 0.5: dV", V7 - V6, -v_cham, 0.005)
    res["errors_after_6"] = nxh.feature_errors(part)
    res["V"] = {"V0": V0, "V2": V2, "V3": V3, "V4": V4, "V5": V5, "V6": V6, "V7": V7}

    # ---- 7 regeneration base_add 2 -> 4 -> 2
    nxh.set_expr(part, "base_add", 4)
    nxh.update()
    V8 = vol()
    res["errors_regen_4"] = nxh.feature_errors(part)
    res["V"]["V_base_add_4"] = V8
    # the side face was replaced too, so the base face is wider by the replaced strip: use the CURRENT base face area
    base_now = sorted(nxh.faces(body, ftype=nxh.PLANE), key=lambda f: -nxh.sheet_area(part, [f])[0])
    xneg = [f for f in base_now if nxh.face_data(f)[2][0] < -0.99][0]
    A_now = nxh.sheet_area(part, [xneg])[0]                 # annulus area: face minus the chamfered hole (r 3.5)
    res["A_base_now"] = A_now
    want = (A_now + math.pi * 3.5 ** 2) * 2 - math.pi * 9 * 2
    chk("7 regen base_add 4: dV = (base outline area) x 2 - hole lengthening", V8 - V7, want, 0.05)
    chk("7 regen base_add 4: bbox xmin -4", nxh.bbox(body)[0], -4.0, 0.01)
    chk("7 regen base_add 4: no feature errors", len(res["errors_regen_4"]), 0, 0)
    nxh.set_expr(part, "base_add", 2)
    nxh.update()
    V9 = vol()
    res["V"]["V_back_to_2"] = V9
    chk("7 round trip to base_add 2", V9, V7, abs(V7) * 1e-6)
    # 7b the other masters: side_add 3 -> 5, bore_d 9.5 -> 9, and back
    nxh.set_expr(part, "side_add", 5)
    nxh.set_expr(part, "bore_d", 9)
    nxh.update()
    chk("7b side_add 5: bbox ymax 20", nxh.bbox(body)[4], 20.0, 0.01)
    chk("7b bore_d 9: bore radius 4.5", len([f for f in nxh.faces(body, ftype=nxh.CYLINDER, radius=4.5) if abs(abs(nxh.face_data(f)[2][2]) - 1) < 1e-6]), 1, 0)
    chk("7b no feature errors", len(nxh.feature_errors(part)), 0, 0)
    res["V"]["V_side5_bore9"] = vol()
    nxh.set_expr(part, "side_add", 3)
    nxh.set_expr(part, "bore_d", 9.5)
    nxh.update()
    chk("7b round trip side_add / bore_d", vol(), V7, abs(V7) * 1e-6)
    res["errors_final"] = nxh.feature_errors(part)
    chk("7 no feature errors at the end", len(res["errors_final"]), 0, 0)

    # ---- 8 final
    chk("8 one solid", len(nxh.solids(part)), 1, 0)
    egf = nxh.examine_geometry(part, body)
    res["examine_final"] = egf
    chk.true("8 Examine Geometry clean", all(v == 0 for v in egf.values()), egf)
    res["tree"] = nxh.feature_table(part)
    res["census_final"] = nxh.face_census(body)
    res["bbox_final"] = nxh.bbox(body)
    res["expressions"] = {n: part.Expressions.FindObject(n).RightHandSide for n in ("base_add", "bore_d", "side_add", "hole_d", "cham")}
    nxh.save(part)
    stp = os.path.join(OUT, "a2_bracket.step")
    if os.path.exists(stp):
        os.remove(stp)
    export_step(part, stp)
    txt = open(stp, errors="ignore").read() if os.path.exists(stp) else ""
    res["step_size"] = len(txt)
    res["step_schema"] = [ln for ln in txt.splitlines()[:40] if "FILE_SCHEMA" in ln]
    chk.true("8 STEP contains MANIFOLD_SOLID_BREP", "MANIFOLD_SOLID_BREP" in txt, txt.count("MANIFOLD_SOLID_BREP"))
    chk.true("8 STEP schema is AP242", "AP242" in txt[:3000], res["step_schema"])
    # re-read the STEP in a fresh part
    p2 = nxh.new_part(os.path.join(OUT, "a2_reimport.prt"))
    back = import_step242(p2, stp, os.path.join(OUT, "a2_scratch2.prt"))
    chk("8 STEP re-import: one body", len(back), 1, 0)
    if back:
        chk.true("8 STEP re-import: solid", back[0].IsSolidBody)
        chk("8 STEP re-import: volume (rel 5e-6: blend faces travel as B-surfaces)", nxh.volume(p2, back[0]), V9, V9 * 5e-6)
        res['reimport_census'] = nxh.face_census(back[0])
    res.update(chk.report())
except Exception:  # noqa: BLE001
    res["error"] = traceback.format_exc()
    res["checks"] = chk.rows
nxh.write_json(os.path.join(OUT, "a2_build.json"), res)

