PART        sensor box: box_base + box_lid (moulded/printed housings, mm) designed top-down around pcb + 4 screws
CLASS       C (enclosure in assembly context) + G (assembly)
MASTERS     in sensor_box_asm: pcb_len/pcb_w (interpart from pcb), gap_xy=4, wall=2, env_x=pcb_len+2*(gap_xy+wall)=72,
            env_y=pcb_w+2*(gap_xy+wall)=52, env_z=24, r_corner=6, split_h=14, pcb_z=6, boss_d=6, pilot_d=2.1, pilot_depth=5,
            usb_clear=0.4, btn_clear=0.3, lip_w=1, lip_h=1.2, lip_clear=0.1, r_small=0.5
            in pcb: pcb_len=60 pcb_w=40 pcb_t=1.6 hole_dx=26 hole_dy=16 hole_d=2.7 btn_x=15 btn_y=-12 usb_over=1.5 ...
DATUMS      assembly origin = box centre on the bottom face; PCB component at (0,0,pcb_z), fixed
FEATURES    base / lid (each, work part in context, interpart masters):
            1 sketch SK_ENV (centred rectangle, 4 pdims env_x/2, env_y/2) -> Extrude env_z
            2 Edge Blend 4 vertical edges r_corner (bigger than wall, before shell)
            3 Shell, no removed face, wall
            4 Datum plane split_h -> Split Body -> Delete Body (other half)
            base: 5 WAVE LINKED_FACE (pcb bottom face, carries the 4 hole edges)
                  6 Cylinder x4 Unite on associative arc-centre points of the linked hole edges, axis -Z into the floor
                  7 Hole (HolePackage) on the same 4 points, pilot_d x pilot_depth
                  (v1, build_v1_interpart_bosses.py: bosses at interpart hole_dx/hole_dy + LINKED_FACE > REPLACE_FACE -
                   passed too, but did not follow a repositioned PCB component)
                  8 WAVE LINKED_BODY (USB) -> OFFSET_REGION usb_clear -> OFFSET_REGION +X face through wall -> SUBTRACT
                  9 OFFSET_IN_FACE/DIVIDE_FACE x2 on the rim -> OFFSET_REGION +lip_h (tongue, centred in the wall)
                  10 Edge Blend r_small bottom outer loop
            lid:  5 WAVE LINKED_BODY (button) -> OFFSET_REGION btn_clear (wall) -> OFFSET_REGION top +env_z -> SUBTRACT
                  6 DIVIDE_FACE x2 on the rim -> OFFSET_REGION -(lip_h+lip_clear) (groove)
                  7 Edge Blend r_small top outer loop
CHECKS      volume after each feature vs analytic (A(x,y,r)=x*y-(4-pi)r^2); solids==1; boss tops z=6; cyl axes at hole
            positions; Examine Geometry; feature_errors; assembly: clearance analysis, pairwise interference,
            min distances (pcb-wall 4.0>=1.5, tall-lid 5.4>=0.8, usb 0.4, lip 0.1), screw DOF 1/0 (Concentric)
REGEN       pcb: hole_dx 24, hole_dy 15, btn (10,-10), pcb_len 62, pcb_w 42 -> env 74x54; then nominal (1e-6 rel)
            save / close / fresh NX process / reopen / load fully / change / update
