"""acc3_lib - assembly helpers COPIED from nx-assemblies/references/nxopen-recipes.md and scripts/topdown_wave.py,
clearance_check.py (they are not in nxf). Only the marked functions are new."""
import math
import os

import NXOpen
import NXOpen.Assemblies
import NXOpen.Features
import NXOpen.Positioning
import nxh

S = nxh.S
PZ = NXOpen.Positioning
T = PZ.Constraint.Type
AL = PZ.Constraint.Alignment
NA = NXOpen.Assemblies
IDENT = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]


def to_nx(r):
    m = NXOpen.Matrix3x3()
    m.Xx, m.Xy, m.Xz = r[0][0], r[1][0], r[2][0]
    m.Yx, m.Yy, m.Yz = r[0][1], r[1][1], r[2][1]
    m.Zx, m.Zy, m.Zz = r[0][2], r[1][2], r[2][2]
    return m


def frame(comp):
    p, m = comp.GetPosition()
    return [p.X, p.Y, p.Z], [[m.Xx, m.Yx, m.Zx], [m.Xy, m.Yy, m.Zy], [m.Xz, m.Yz, m.Zz]]


def axis_of(comp, k=2):
    _o, r = frame(comp)
    return [r[i][k] for i in range(3)]


def enum_name(cls, v):
    for n in nxh.enum_names(cls):
        try:
            if getattr(cls, n) == v:
                return n
        except Exception:  # noqa: BLE001
            pass
    return str(v)


def circ_edge(body, centre, radius):
    hits = []
    for e in body.GetEdges():
        if e.SolidEdgeType != NXOpen.Edge.EdgeType.Circular:
            continue
        bb = nxh.bbox(e)
        c = [(bb[i] + bb[i + 3]) / 2 for i in range(3)]
        r = max(bb[i + 3] - bb[i] for i in range(3)) / 2
        if abs(r - radius) < 1e-3 and all(abs(c[i] - centre[i]) < 1e-3 for i in range(3)):
            hits.append(e)
    if len(hits) != 1:
        raise RuntimeError(f"{len(hits)} circular edges at {centre} r {radius}")
    return hits[0]


def occ(comp, obj):
    o = comp.FindOccurrence(obj)
    if o is None:
        raise RuntimeError(f"{comp.Name}: no occurrence of {obj}")
    return o


def status_name(c):
    return enum_name(PZ.Constraint.SolverStatus, c.GetConstraintStatus())


class Session:
    def __init__(self, assy, move=False):
        self.assy, self.move = assy, move

    def __enter__(self):
        ca = self.assy.ComponentAssembly
        self.pos = ca.Positioner
        self.pos.ClearNetwork()
        self.pos.PrimaryArrangement = ca.ActiveArrangement
        if self.move:
            self.pos.BeginMoveComponent()
        else:
            self.pos.BeginAssemblyConstraints()
        self.net = self.pos.EstablishNetwork()
        self.net.MoveObjectsState = True
        self.net.NetworkArrangementsMode = PZ.ComponentNetwork.ArrangementsMode.Existing
        if not self.move:
            self.net.DisplayComponent = NXOpen.Assemblies.Component.Null
        return self

    def __exit__(self, *exc):
        self.pos.ClearNetwork()
        S.UpdateManager.AddToDeleteList(self.net)
        S.UpdateManager.DoUpdate(nxh.mark("positioner", False))
        if self.move:
            self.pos.EndMoveComponent()
        else:
            self.pos.EndAssemblyConstraints()
        return False


def constrain(assy, ctype, refs, align=None, expr=None, name=None, tweak=None):
    with Session(assy) as s:
        c = s.pos.CreateConstraint(True)
        c.ConstraintType = ctype
        if align is not None:
            c.ConstraintAlignment = align
        made = []
        for comp, geom, uses_axis in refs:
            made.append(c.CreateConstraintReference(comp, geom, uses_axis, False, False))
        if tweak:
            tweak(c, made)
        if expr is not None:
            c.SetExpression(expr)
        s.net.AddConstraint(c)
        if name:
            c.SetName(name)
        s.net.Solve()
    return c


def flip(assy, c):
    with Session(assy) as s:
        c.FlipAlignment()
        s.net.Solve()


def add(assy, path, name, origin, r=None, refset="MODEL"):
    comp, st = assy.ComponentAssembly.AddComponent(path, refset, name, nxh.P(*origin), to_nx(r or IDENT), -1)
    st.Dispose()
    return comp


def set_work(comp):
    if comp is None:
        comp = NXOpen.Assemblies.Component.Null
    st = S.Parts.SetWorkComponent(comp, NXOpen.PartCollection.RefsetOption.Entire,
                                  NXOpen.PartCollection.WorkComponentOption.Visible)
    try:
        st.Dispose()
    except Exception:  # noqa: BLE001
        pass
    return S.Parts.Work


def new_component(assy, path, name):
    if os.path.exists(path):
        os.remove(path)
    fn = S.Parts.FileNew()
    fn.TemplateFileName = nxh.TEMPLATE
    fn.UseBlankTemplate = False
    fn.ApplicationName = "ModelTemplate"
    fn.Units = NXOpen.Part.Units.Millimeters
    fn.TemplateType = NXOpen.FileNewTemplateType.Item
    fn.TemplatePresentationName = "Model"
    fn.NewFileName = path
    fn.MasterFileName = ""
    fn.MakeDisplayedPart = False
    fn.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    b = assy.AssemblyManager.CreateNewComponentBuilder()
    try:
        b.ReferenceSet = NXOpen.Assemblies.CreateNewComponentBuilder.ComponentReferenceSetType.Model
        b.NewComponentName = name
        b.ReferenceSetName = "MODEL"
        b.NewFile = fn
        b.Commit()
    finally:
        b.Destroy()
    for c in assy.ComponentAssembly.RootComponent.GetChildren():
        if c.DisplayName.lower() == os.path.splitext(os.path.basename(path))[0].lower() or c.Name == name:
            return c
    raise RuntimeError("new component not found")


def wave_link(wp, source_occurrence, kind="body", fix_ts=False, pos_indep=False, associative=True):
    EF, WT = NXOpen.Features.ExtractFaceBuilder, NXOpen.Features.WaveLinkBuilder.Types
    before = list(wp.Bodies)
    b = wp.BaseFeatures.CreateWaveLinkBuilder(nxh.NULL_FEATURE)
    try:
        b.Type = WT.BodyLink if kind == "body" else WT.FaceLink
        ef = b.ExtractFaceBuilder
        ef.ParentPart = EF.ParentPartType.OtherPart
        for o in (b, ef):
            o.Associative = associative
            o.FixAtCurrentTimestamp = fix_ts
            o.MakePositionIndependent = pos_indep
        ef.HideOriginal = False
        ef.InheritDisplayProperties = False
        if kind == "body":
            ef.ExtractBodyCollector.ReplaceRules([wp.ScRuleFactory.CreateRuleBodyDumb([source_occurrence], True)], False)
        else:
            ef.FaceOption = EF.FaceOptionType.SingleFace
            ef.ObjectToExtract.Add(source_occurrence)
        f = b.CommitFeature()
    finally:
        b.Destroy()
    return f, nxh.new_bodies(wp, before)


def clearance_set(assy, name, zone=0.0):
    b = assy.AssemblyManager.CreateClearanceAnalysisBuilder(NA.ClearanceSet.Null)
    try:
        b.ClearanceSetName = name
        b.CalculationMethod = NA.ClearanceAnalysisBuilder.CalculationMethodType.Exact
        b.ClearanceBetween = NA.ClearanceAnalysisBuilder.ClearanceBetweenEntity.Components
        b.TotalCollectionCount = NA.ClearanceAnalysisBuilder.NumberOfCollections.One
        b.CollectionOneRange = NA.ClearanceAnalysisBuilder.CollectionRange.AllObjects
        mm = assy.UnitCollection.FindObject("MilliMeter")
        b.SetDefaultClearanceZone(assy.Expressions.CreateSystemExpressionWithUnits(str(zone), mm))
        return b.Commit()
    finally:
        b.Destroy()


def run_clearance(cs):
    cs.PerformAnalysis(NA.ClearanceSet.ReanalyzeOutOfDateExcludedPairs.FalseValue)
    out = []
    a = b = NXOpen.DisplayableObject.Null
    for _ in range(cs.GetNumberOfInterferences()):
        nxt = cs.GetNextInterference(a, b)
        a, b = nxt[0], nxt[1]
        if a is None or b is None:
            break
        data = cs.GetInterferenceData(a, b)
        out.append({"pair": sorted([a.Name, b.Name]), "type": enum_name(NA.ClearanceSet.InterferenceType, data[0])})
    return sorted(out, key=lambda r: r["pair"])


def simple_interference(assy, body_a, body_b):
    import NXOpen.GeometricAnalysis as GA
    si = assy.AnalysisManager.CreateSimpleInterferenceObject()
    try:
        si.InterferenceType = GA.SimpleInterference.InterferenceMethod.InterferenceSolid
        si.FirstBody.Value = body_a
        si.SecondBody.Value = body_b
        r = si.PerformCheck()
        vols = []
        if r == GA.SimpleInterference.Result.InterferenceExists:
            for obj in si.GetInterferenceResults():
                vols.append(nxh.volume(assy, obj))
                nxh.UFS.Obj.DeleteObject(obj.Tag)
        return enum_name(GA.SimpleInterference.Result, r), vols
    finally:
        si.Destroy()


# ------------------------------------------------------------------ NEW (not in the skills)
def area(x, y, r):
    """Area of a rounded rectangle."""
    return x * y - (4.0 - math.pi) * r * r


def named_body(part, name):
    for b in part.Bodies:
        if b.IsSolidBody and b.Name == name:
            return b
    raise RuntimeError(f"no solid {name}")


def cyl_axes(body, radius, tol=1e-3):
    """Sorted [(x, y)] of the axes of all cylindrical faces with this radius (vertical axes)."""
    out = set()
    for f in nxh.faces(body, ftype=nxh.CYLINDER, radius=radius, tol=tol):
        _t, pt, d, _r = nxh.face_data(f)
        if abs(abs(d[2]) - 1.0) < 1e-6:
            out.add((round(pt[0], 4) + 0.0, round(pt[1], 4) + 0.0))
    return sorted(out)
