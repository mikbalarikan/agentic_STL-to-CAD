"""Acceptance test 3: sensor box designed top-down around a PCB. Journal 1: parts, assembly, base, lid, checks,
associativity test, restore, save.  args: <out folder> <lib folder>"""
import math
import os
import sys
import time
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
OUT = sys.argv[1]
sys.path.insert(0, sys.argv[2])
import NXOpen  # noqa: E402
import nxh  # noqa: E402
import nxf  # noqa: E402
import acc3_lib as L  # noqa: E402

S = nxh.S
pi = math.pi
log = nxh.Log(os.path.join(OUT, (sys.argv[3] if len(sys.argv) > 3 else "build") + ".log"))
chk = nxh.Check()
res = {"steps": {}, "notes": {}}
T0 = time.time()

NOM = {"pcb_len": 60.0, "pcb_w": 40.0, "hole_dx": 26.0, "hole_dy": 16.0, "btn_x": 15.0, "btn_y": -12.0}
CHG = {"pcb_len": 62.0, "pcb_w": 42.0, "hole_dx": 24.0, "hole_dy": 15.0, "btn_x": 10.0, "btn_y": -10.0}
M = {"gap_xy": 4.0, "wall": 2.0, "env_z": 24.0, "r_corner": 6.0, "split_h": 14.0, "pcb_z": 6.0, "boss_d": 6.0,
     "pilot_d": 2.1, "pilot_depth": 5.0, "usb_clear": 0.4, "btn_clear": 0.3, "lip_w": 1.0, "lip_h": 1.2,
     "lip_clear": 0.1, "r_small": 0.5}
PCB = {"pcb_t": 1.6, "hole_d": 2.7, "usb_over": 1.5, "usb_len": 9.0, "usb_w": 7.4, "usb_h": 3.2, "btn_d": 6.0,
       "btn_h": 5.0}
SIGNS = [(1, 1), (-1, 1), (-1, -1), (1, -1)]


def env(p):
    return p["pcb_len"] + 2 * (M["gap_xy"] + M["wall"]), p["pcb_w"] + 2 * (M["gap_xy"] + M["wall"])


def blend_removed(r, ex, ey, rc):
    a = (1 - pi / 4) * r * r
    c = r * (5.0 / 6.0 - pi / 4) / (1 - pi / 4)
    return a * 2 * ((ex - 2 * rc) + (ey - 2 * rc)) + a * 2 * pi * (rc - c)


def ring(ex, ey, rc, a, b):
    return L.area(ex - 2 * a, ey - 2 * a, rc - a) - L.area(ex - 2 * b, ey - 2 * b, rc - b)


def shell_half(p, lower):
    ex, ey = env(p)
    w, rc, sh, ez = M["wall"], M["r_corner"], M["split_h"], M["env_z"]
    ao, ai = L.area(ex, ey, rc), L.area(ex - 2 * w, ey - 2 * w, rc - w)
    return ao * sh - ai * (sh - w) if lower else ao * (ez - sh) - ai * (ez - sh - w)


def base_expected(p):
    ex, ey = env(p)
    w, rc = M["wall"], M["r_corner"]
    v = shell_half(p, True)
    v += 4 * pi * (M["boss_d"] / 2) ** 2 * (M["pcb_z"] - w)
    v -= 4 * pi * (M["pilot_d"] / 2) ** 2 * M["pilot_depth"]
    v -= (PCB["usb_w"] + 2 * M["usb_clear"]) * (PCB["usb_h"] + 2 * M["usb_clear"]) * w
    a = (w - M["lip_w"]) / 2
    v += ring(ex, ey, rc, a, a + M["lip_w"]) * M["lip_h"]
    v -= blend_removed(M["r_small"], ex, ey, rc)
    return v


def lid_expected(p):
    ex, ey = env(p)
    w, rc = M["wall"], M["r_corner"]
    v = shell_half(p, False)
    v -= pi * (PCB["btn_d"] / 2 + M["btn_clear"]) ** 2 * w
    a = (w - M["lip_w"]) / 2 - M["lip_clear"]
    v -= ring(ex, ey, rc, a, a + M["lip_w"] + 2 * M["lip_clear"]) * (M["lip_h"] + M["lip_clear"])
    v -= blend_removed(M["r_small"], ex, ey, rc)
    return v


def rect_sketch(part, d, name, x0, x1, y0, y1, fx0, fx1, fy0, fy1):
    """Fully constrained H/V rectangle on the XY datum plane; each edge dimensioned from the datum axes."""
    sk = nxf.new_sketch(part, d.xy, d.x, d.origin, name)
    ls = nxf.hv_polygon(part, sk, [(x0, y0), (x1, y0), (x1, y1), (x0, y1)])
    hx, hy = nxh.P(200, 0, 0), nxh.P(0, 200, 0)
    xm, ym = (x0 + x1) / 2, (y0 + y1) / 2
    nxf.pdim(sk, d.y, hy, ls[1], nxf.A.StartPoint, nxh.P(x1 + 5, ym, 0), fx1)
    nxf.pdim(sk, d.y, hy, ls[3], nxf.A.StartPoint, nxh.P(x0 - 5, ym, 0), fx0)
    nxf.pdim(sk, d.x, hx, ls[0], nxf.A.StartPoint, nxh.P(xm, y0 - 5, 0), fy0)
    nxf.pdim(sk, d.x, hx, ls[2], nxf.A.StartPoint, nxh.P(xm, y1 + 5, 0), fy1)
    r = nxf.finish_sketch(sk)
    return sk, r


def build_pcb(path):
    p = nxh.new_part(path)
    for n, v in list(NOM.items()) + list(PCB.items()):
        nxh.expr(p, n, v)
    d = nxh.Datums(p)
    sk, r = rect_sketch(p, d, "SK_BOARD", -30, 30, -20, 20, "pcb_len/2", "pcb_len/2", "pcb_w/2", "pcb_w/2")
    chk.true("pcb: board sketch fully constrained", r["status"] == "WellConstrained" and r["dof"] == 0, r)
    board = nxh.extrude(p, nxh.section_region(p, sk, (1, 1, 0)), (0, 0, 1), 0, "pcb_t").GetBodies()[0]
    chk("pcb: board volume", nxh.volume(p, board), 60 * 40 * 1.6, 1e-6)
    pts = [(("" if sx > 0 else "-") + "hole_dx", ("" if sy > 0 else "-") + "hole_dy", "pcb_t") for sx, sy in SIGNS]
    nxf.hole(p, board, pts, "hole_d", vector=(0, 0, -1))
    chk("pcb: 4 mounting holes", nxh.volume(p, board), 3840 - 4 * pi * 1.35 ** 2 * 1.6, 1e-4)
    sk2, r2 = rect_sketch(p, d, "SK_USB", 22.5, 31.5, -3.7, 3.7, "pcb_len/2+usb_over-usb_len", "pcb_len/2+usb_over",
                          "usb_w/2", "usb_w/2")
    chk.true("pcb: usb sketch fully constrained", r2["status"] == "WellConstrained" and r2["dof"] == 0, r2)
    usb = nxh.extrude(p, nxh.section_region(p, sk2, (27, 0, 0)), (0, 0, 1), "pcb_t", "pcb_t+usb_h").GetBodies()[0]
    chk("pcb: usb block volume", nxh.volume(p, usb), 9 * 7.4 * 3.2, 1e-6)
    chk("pcb: usb overhang (xmax)", nxh.bbox(usb)[3], 31.5, 1e-6)
    _f, tall = nxh.block(p, (-18, 0, 1.6), (12, 12, 9))
    chk("pcb: tall block volume", nxh.volume(p, tall), 1296.0, 1e-6)
    _f, btn = nxh.cylinder(p, ("btn_x", "btn_y", "pcb_t"), (0, 0, 1), "btn_d", "btn_h")
    chk("pcb: button volume", nxh.volume(p, btn), pi * 9 * 5, 1e-4)
    for b, n in ((board, "BOARD"), (usb, "USB"), (tall, "TALL"), (btn, "BUTTON")):
        b.SetName(n)
    chk("pcb: 4 solids", len(nxh.solids(p)), 4, 0)
    chk.true("pcb: no feature errors", not nxh.feature_errors(p), nxh.feature_errors(p))
    nxh.save(p)
    return p


def build_screw(path):
    p = nxh.new_part(path)
    for n, v in (("scr_d", 2.5), ("scr_l", 8), ("head_d", 4.5), ("head_h", 1.7)):
        nxh.expr(p, n, v)
    _f, b = nxh.cylinder(p, (0, 0, "-scr_l"), (0, 0, 1), "scr_d", "scr_l")
    nxh.cylinder(p, (0, 0, 0), (0, 0, 1), "head_d", "head_h", op=nxh.BOOL.Unite, target=b)
    chk("screw: volume", nxh.volume(p, b), pi * 1.25 ** 2 * 8 + pi * 2.25 ** 2 * 1.7, 1e-4)
    chk("screw: 1 solid", len(nxh.solids(p)), 1, 0)
    b.SetName("SCREW")
    nxh.save(p)
    return p


def link_exprs(wp, names, src):
    mm = wp.UnitCollection.FindObject("MilliMeter")
    for n in names:
        wp.Expressions.CreateWithUnits(f'{n}="{src}"::{n}', mm)


def val(part, name):
    return part.Expressions.FindObject(name).Value


def shell_and_split(wp, tag, keep_lower):
    """Steps 1-4 of the plan in the work part wp. Returns (kept body, datums)."""
    d = nxh.Datums(wp)
    ex, ey, ez = val(wp, "env_x"), val(wp, "env_y"), val(wp, "env_z")
    w, rc, sh = M["wall"], M["r_corner"], M["split_h"]

    def by_sketch():
        sk, r = rect_sketch(wp, d, "SK_ENV", -ex / 2, ex / 2, -ey / 2, ey / 2, "env_x/2", "env_x/2", "env_y/2", "env_y/2")
        f = nxh.extrude(wp, nxh.section_region(wp, sk, (1, 1, 0)), (0, 0, 1), 0, "env_z")
        return f.GetBodies()[0], r

    out, err = nxh.attempt(tag + " envelope sketch in context", by_sketch, log=log)
    if out is None:
        res["notes"][tag + "_sketch_in_context_failed"] = err
        _f, body = nxh.block(wp, (0, 0, 0), ("env_x", "env_y", "env_z"))
        nxf.move_object(wp, [body], "delta", ("-env_x/2", "-env_y/2", "0"))
    else:
        body, r = out
        chk.true(tag + ": envelope sketch (work part in assembly context) fully constrained",
                 r["status"] == "WellConstrained" and r["dof"] == 0, r)
    chk(tag + ": envelope block", nxh.volume(wp, body), ex * ey * ez, 1e-4)
    bb = nxh.bbox(body)
    chk(tag + ": envelope centred (xmin)", bb[0], -ex / 2, 1e-6)
    ved = nxh.edges(body, lambda b: abs(b[0] - b[3]) < 1e-6 and abs(b[1] - b[4]) < 1e-6 and b[5] - b[2] > 1.0)
    chk(tag + ": 4 vertical edges", len(ved), 4, 0)
    nxf.edge_blend(wp, [(ved, "r_corner")])
    chk(tag + ": corner blend R6", nxh.volume(wp, body), L.area(ex, ey, rc) * ez, 1e-3)
    nxf.shell(wp, body, [], "wall")
    v_shell = L.area(ex, ey, rc) * ez - L.area(ex - 2 * w, ey - 2 * w, rc - w) * (ez - 2 * w)
    chk(tag + ": closed shell (no removed face)", nxh.volume(wp, body), v_shell, 1e-3)
    _f, dp = nxf.datum_plane(wp, "offset", [d.xy], "split_h", name="DP_SPLIT")
    n0 = len(nxh.solids(wp))
    _f, pieces = nxf.split_body(wp, [body], datum_plane=dp)
    chk(tag + ": split -> solids +1", len(nxh.solids(wp)), n0 + 1, 0)
    low = [b for b in pieces if nxh.bbox(b)[5] < sh + 1e-3]
    up = [b for b in pieces if nxh.bbox(b)[2] > sh - 1e-3]
    chk.true(tag + ": one lower and one upper piece", len(low) == 1 and len(up) == 1, [nxh.bbox(b) for b in pieces])
    keep, scrap = (low[0], up[0]) if keep_lower else (up[0], low[0])
    nxf.delete_body(wp, [scrap])
    chk(tag + ": delete body -> 1 solid", len(nxh.solids(wp)), 1, 0)
    chk(tag + ": half shell volume", nxh.volume(wp, keep), shell_half(NOM, keep_lower), 1e-3)
    return keep, d


def rim_step(wp, body, tag, normal, inset_f, inset, height_f):
    """The user's rim idiom: OFFSET_IN_FACE > DIVIDE_FACE (twice: from the outer and the inner loop) > OFFSET_REGION."""
    ex, ey, w, sh = val(wp, "env_x"), val(wp, "env_y"), M["wall"], M["split_h"]
    rim = nxh.faces(body, nxh.PLANE, normal=normal, at=(2, sh))
    chk(tag + ": one rim face at the split", len(rim), 1, 0)
    rim = rim[0]

    def far(e):
        bb = nxh.bbox(e)
        return max(abs(bb[0]), abs(bb[3])), max(abs(bb[1]), abs(bb[4]))

    outer = [e for e in rim.GetEdges() if abs(far(e)[0] - ex / 2) < 0.02 or abs(far(e)[1] - ey / 2) < 0.02]
    res["notes"][tag + "_rim_edges"] = {"all": len(rim.GetEdges()), "outer": len(outer)}
    f1, flip1 = nxf.divide_face_offset(wp, rim, outer, inset_f)
    rings = nxh.faces(body, at=(2, sh), tol=0.01)
    chk(tag + ": divide 1 -> 2 rim faces", len(rings), 2, 0)
    inner_ring = [f for f in rings if abs(nxh.bbox(f)[3] - (ex / 2 - inset)) < 0.02][0]
    inner = [e for e in inner_ring.GetEdges()
             if abs(far(e)[0] - (ex / 2 - w)) < 0.02 or abs(far(e)[1] - (ey / 2 - w)) < 0.02]
    f2, flip2 = nxf.divide_face_offset(wp, inner_ring, inner, inset_f)
    rings = nxh.faces(body, at=(2, sh), tol=0.01)
    chk(tag + ": divide 2 -> 3 rim faces", len(rings), 3, 0)
    mid = [f for f in rings if abs(nxh.bbox(f)[3] - (ex / 2 - inset)) < 0.02]
    chk(tag + ": one middle ring", len(mid), 1, 0)
    a_mid = nxh.sheet_area(wp, mid)[0]
    v0 = nxh.volume(wp, body)
    nxf.offset_region(wp, mid, height_f)
    res["notes"][tag + "_rim"] = {"flip1": flip1, "flip2": flip2, "mid_area": a_mid, "inner_edges": len(inner)}
    return a_mid, nxh.volume(wp, body) - v0


def build_base(assy, comp, pcb_c, pcb):
    wp = L.set_work(comp)
    chk.true("base: work part is box_base, display part is the assembly",
             wp.Name.lower() == "box_base" and S.Parts.Display.Tag == assy.Tag, wp.Name)
    link_exprs(wp, ["env_x", "env_y", "env_z", "wall", "r_corner", "split_h", "pcb_z", "boss_d", "pilot_d",
                    "pilot_depth", "usb_clear", "lip_w", "lip_h", "lip_clear", "r_small", "gap_xy"], "sensor_box_asm")
    base, _d = shell_and_split(wp, "base", True)
    w = M["wall"]
    # ---- LINKED_FACE (PCB bottom, with its 4 hole edges) > smart points at the hole centres > bosses > pilot holes
    board = L.named_body(pcb, "BOARD")
    bottom = nxh.faces(board, nxh.PLANE, normal=(0, 0, -1))[0]
    f_lf, sheets = L.wave_link(wp, L.occ(pcb_c, bottom), kind="face")
    chk("base: linked PCB bottom face at assembly z = pcb_z", nxh.bbox(sheets[0])[2], M["pcb_z"], 1e-6)
    circ = [e for e in sheets[0].GetEdges() if e.SolidEdgeType == NXOpen.Edge.EdgeType.Circular]
    chk("base: 4 circular hole edges on the linked face", len(circ), 4, 0)
    pts = [wp.Points.CreatePoint(e, nxh.UPD) for e in circ]                 # associative arc-centre points
    res["notes"]["hole_centre_points"] = sorted([round(q.Coordinates.X, 6), round(q.Coordinates.Y, 6), round(q.Coordinates.Z, 6)] for q in pts)
    v0 = nxh.volume(wp, base)
    for q in pts:                                                           # nxh.cylinder cannot take an NXOpen.Point
        cb = wp.Features.CreateCylinderBuilder(nxh.NULL_FEATURE)
        try:
            cb.Type = NXOpen.Features.CylinderBuilder.Types.AxisDiameterAndHeight
            cb.Axis = wp.Axes.CreateAxis(q, nxh.direction(wp, (0, 0, -1)), nxh.UPD)
            cb.Diameter.RightHandSide = "boss_d"
            cb.Height.RightHandSide = "pcb_z-wall/2"                        # down into the floor: the unite shares volume
            cb.BooleanOption.Type = nxh.BOOL.Unite
            cb.BooleanOption.SetTargetBodies([base])
            cb.CommitFeature()
        finally:
            cb.Destroy()
    chk("base: 4 bosses dia 6 from the floor to the linked PCB face (delta)", nxh.volume(wp, base) - v0, 4 * pi * 9 * (M["pcb_z"] - w), 1e-3)
    chk("base: still 1 solid after bosses", len(nxh.solids(wp)), 1, 0)
    chk("base: 4 boss tops at z = 6", len(nxh.faces(base, nxh.PLANE, normal=(0, 0, 1), at=(2, M["pcb_z"]))), 4, 0)
    v0 = nxh.volume(wp, base)
    nxf.hole(wp, base, pts, "pilot_d", depth="pilot_depth", vector=(0, 0, -1))
    chk("base: 4 pilot holes dia 2.1 x 5 (delta)", nxh.volume(wp, base) - v0, -4 * pi * 1.05 ** 2 * 5, 1e-3)
    chk.true("base: boss axes at the PCB holes", L.cyl_axes(base, 3.0) == sorted((sx * 26.0, sy * 16.0) for sx, sy in SIGNS),
             L.cyl_axes(base, 3.0))
    chk.true("base: pilot axes at the PCB holes", L.cyl_axes(base, 1.05) == sorted((sx * 26.0, sy * 16.0) for sx, sy in SIGNS),
             L.cyl_axes(base, 1.05))
    # ---- LINKED_BODY (USB) > OFFSET_REGION > OFFSET_REGION (+X face through the wall) > SUBTRACT
    usb = L.named_body(pcb, "USB")
    f_lb, linked = L.wave_link(wp, L.occ(pcb_c, usb), kind="body")
    tool = linked[0]
    chk("base: linked USB body volume", nxh.volume(wp, tool), 9 * 7.4 * 3.2, 1e-6)
    chk("base: linked USB body at assembly z (zmin)", nxh.bbox(tool)[2], 7.6, 1e-6)
    nxf.offset_region(wp, nxf.rule_faces(wp, "body", tool), "usb_clear")
    chk("base: USB copy grown by usb_clear", nxh.volume(wp, tool), 9.8 * 8.2 * 4.0, 1e-4)
    xf = [f for f in tool.GetFaces() if abs(nxh.bbox(f)[0] - nxh.bbox(tool)[3]) < 1e-4 and abs(nxh.bbox(f)[3] - nxh.bbox(tool)[3]) < 1e-4]
    chk("base: one +X face on the tool", len(xf), 1, 0)
    nxf.offset_region(wp, xf, "gap_xy+wall")
    chk("base: tool reaches through the wall (xmax)", nxh.bbox(tool)[3], 31.5 + 0.4 + 6.0, 1e-4)
    v0 = nxh.volume(wp, base)
    nxh.subtract(wp, base, [tool])
    chk("base: USB opening (delta)", nxh.volume(wp, base) - v0, -8.2 * 4.0 * w, 1e-3)
    chk("base: 1 solid after subtract", len(nxh.solids(wp)), 1, 0)
    # ---- tongue
    ex, ey = env(NOM)
    a = (w - M["lip_w"]) / 2
    a_mid, dv = rim_step(wp, base, "base", (0, 0, 1), "(wall-lip_w)/2", a, "lip_h")
    chk("base: tongue ring area (offset arcs are splines)", a_mid, ring(ex, ey, M["r_corner"], a, a + 1.0), 0.05)
    chk("base: tongue volume delta = area x lip_h", dv, a_mid * M["lip_h"], 1e-3)
    chk("base: tongue top at z 15.2 (dist to body)", nxh.dist_to(wp, base, (ex / 2 - 1.0, 0, 15.2)), 0.0, 1e-6)
    chk("base: tongue outer side at x = env/2 - 0.5", nxh.dist_to(wp, base, (ex / 2 - 0.5, 0, 14.6)), 0.0, 1e-6)
    chk("base: tongue inner side at x = env/2 - 1.5", nxh.dist_to(wp, base, (ex / 2 - 1.5, 0, 14.6)), 0.0, 1e-6)
    # ---- small blend, last
    seed = [e for e in nxh.edges_at(base, 2, 0.0) if abs(nxh.bbox(e)[4] - ey / 2) < 1e-6 and abs(nxh.bbox(e)[1] - ey / 2) < 1e-6]
    chk("base: seed edge for the bottom blend", len(seed), 1, 0)
    v0 = nxh.volume(wp, base)
    nxf.edge_blend(wp, [(nxf.tangent_edges(wp, seed[0]), "r_small")])
    chk("base: R0.5 bottom blend (delta, exact by Pappus)", nxh.volume(wp, base) - v0,
        -blend_removed(0.5, ex, ey, M["r_corner"]), 1e-3)
    nxh.update()
    chk("base: final volume", nxh.volume(wp, base), base_expected(NOM), 0.1)
    chk("base: 1 solid", len(nxh.solids(wp)), 1, 0)
    chk.true("base: no feature errors", not nxh.feature_errors(wp), nxh.feature_errors(wp))
    chk.true("base: Examine Geometry clean", nxh.body_ok(wp, base), nxh.examine_geometry(wp, base))
    res["steps"]["base_tree"] = [[r["name"], r["type"]] for r in nxh.feature_table(wp)]
    return wp, base


def build_lid(assy, comp, pcb_c, pcb):
    wp = L.set_work(comp)
    link_exprs(wp, ["env_x", "env_y", "env_z", "wall", "r_corner", "split_h", "btn_clear", "lip_w", "lip_h",
                    "lip_clear", "r_small"], "sensor_box_asm")
    lid, _d = shell_and_split(wp, "lid", False)
    w = M["wall"]
    ex, ey = env(NOM)
    # ---- LINKED_BODY (button) > OFFSET_REGION (wall) > OFFSET_REGION (top) > SUBTRACT
    btn = L.named_body(pcb, "BUTTON")
    f_lb, linked = L.wave_link(wp, L.occ(pcb_c, btn), kind="body")
    tool = linked[0]
    chk("lid: linked button volume", nxh.volume(wp, tool), pi * 9 * 5, 1e-4)
    nxf.offset_region(wp, nxh.faces(tool, nxh.CYLINDER), "btn_clear")
    chk("lid: button copy dia 6.6", nxh.volume(wp, tool), pi * 3.3 ** 2 * 5, 1e-4)
    nxf.offset_region(wp, nxh.faces(tool, nxh.PLANE, normal=(0, 0, 1)), "env_z")
    chk("lid: button tool top above the lid (zmax)", nxh.bbox(tool)[5], 12.6 + 24.0, 1e-4)
    v0 = nxh.volume(wp, lid)
    nxh.subtract(wp, lid, [tool])
    chk("lid: button opening dia 6.6 through the top (delta)", nxh.volume(wp, lid) - v0, -pi * 3.3 ** 2 * w, 1e-3)
    chk.true("lid: opening axis at the button", L.cyl_axes(lid, 3.3) == [(15.0, -12.0)], L.cyl_axes(lid, 3.3))
    # ---- groove
    a = (w - M["lip_w"]) / 2 - M["lip_clear"]
    a_mid, dv = rim_step(wp, lid, "lid", (0, 0, -1), "(wall-lip_w)/2-lip_clear", a, "-(lip_h+lip_clear)")
    chk("lid: groove ring area", a_mid, ring(ex, ey, M["r_corner"], a, a + 1.2), 0.05)
    chk("lid: groove volume delta = -area x 1.3", dv, -a_mid * 1.3, 1e-3)
    chk("lid: groove bottom at z 15.3", nxh.dist_to(wp, lid, (ex / 2 - 1.0, 0, 15.3)), 0.0, 1e-6)
    # ---- small blend, last
    seed = [e for e in nxh.edges_at(lid, 2, M["env_z"]) if abs(nxh.bbox(e)[4] - ey / 2) < 1e-6 and abs(nxh.bbox(e)[1] - ey / 2) < 1e-6]
    chk("lid: seed edge for the top blend", len(seed), 1, 0)
    v0 = nxh.volume(wp, lid)
    nxf.edge_blend(wp, [(nxf.tangent_edges(wp, seed[0]), "r_small")])
    chk("lid: R0.5 top blend (delta)", nxh.volume(wp, lid) - v0, -blend_removed(0.5, ex, ey, M["r_corner"]), 1e-3)
    nxh.update()
    chk("lid: final volume", nxh.volume(wp, lid), lid_expected(NOM), 0.1)
    chk("lid: 1 solid", len(nxh.solids(wp)), 1, 0)
    chk.true("lid: no feature errors", not nxh.feature_errors(wp), nxh.feature_errors(wp))
    chk.true("lid: Examine Geometry clean", nxh.body_ok(wp, lid), nxh.examine_geometry(wp, lid))
    res["steps"]["lid_tree"] = [[r["name"], r["type"]] for r in nxh.feature_table(wp)]
    return wp, lid


def measure(ctx, p):
    """All assembly-level numbers for the PCB parameter set p."""
    assy, pcb_c, pcb, base_c, bp, base, lid_c, lp, lid, screws = ctx
    ex, ey = env(p)
    w, sh = M["wall"], M["split_h"]
    board, usb, tall = L.named_body(pcb, "BOARD"), L.named_body(pcb, "USB"), L.named_body(pcb, "TALL")
    m = {"env": [val(assy, "env_x"), val(assy, "env_y")],
         "base_volume": nxh.volume(bp, base), "lid_volume": nxh.volume(lp, lid),
         "base_solids": len(nxh.solids(bp)), "lid_solids": len(nxh.solids(lp)),
         "base_errors": nxh.feature_errors(bp), "lid_errors": nxh.feature_errors(lp),
         "boss_axes": L.cyl_axes(base, 3.0), "pilot_axes": L.cyl_axes(base, 1.05), "button_opening": L.cyl_axes(lid, 3.3),
         "boss_tops_at_6": len(nxh.faces(base, nxh.PLANE, normal=(0, 0, 1), at=(2, M["pcb_z"]))),
         "base_bbox": nxh.bbox(base), "lid_bbox": nxh.bbox(lid)}
    # PCB outline to the inner walls
    walls = [f for f in base.GetFaces() if abs(nxh.bbox(f)[2] - w) < 0.01 and abs(nxh.bbox(f)[5] - sh) < 0.01]
    ob = L.occ(pcb_c, board)
    m["inner_wall_faces"] = len(walls)
    m["pcb_to_wall"] = min(nxh.min_dist(ob, L.occ(base_c, f)) for f in walls)
    m["tall_to_lid"] = nxh.min_dist(L.occ(pcb_c, tall), L.occ(lid_c, lid))
    m["usb_to_base_3d"] = nxh.min_dist(L.occ(pcb_c, usb), L.occ(base_c, base))
    # USB opening: its four faces against the connector box (assembly coordinates)
    ub = nxh.bbox(usb)
    oz = L.frame(pcb_c)[0][2]
    win = [nxh.bbox(f) for f in base.GetFaces()
           if abs(nxh.bbox(f)[0] - (ex / 2 - w)) < 0.01 and abs(nxh.bbox(f)[3] - ex / 2) < 0.01 and nxh.bbox(f)[2] > w + 0.1
           and nxh.bbox(f)[5] < sh - 0.1]
    ys = sorted(b[1] for b in win if abs(b[1] - b[4]) < 1e-6)
    zs = sorted(b[2] for b in win if abs(b[2] - b[5]) < 1e-6)
    m["usb_window_faces"] = len(win)
    if len(ys) == 2 and len(zs) == 2:
        m["usb_gaps"] = [ub[1] - ys[0], ys[1] - ub[4], (ub[2] + oz) - zs[0], zs[1] - (ub[5] + oz)]
    else:
        m["usb_gaps"] = None
        m["usb_window"] = win
    # lip / groove: probe points ON the tongue (sides at mid height, top), distance to the lid occurrence
    rc, q = M["r_corner"], math.sqrt(0.5)
    lo, bo = L.occ(lid_c, lid), L.occ(base_c, base)
    m["lip"] = {}
    for name, d, z in (("outer", 0.5, sh + 0.6), ("inner", 1.5, sh + 0.6), ("top", 1.0, sh + 1.2)):
        pts = [(ex / 2 - d, 0, z), (-(ex / 2 - d), 0, z), (0, ey / 2 - d, z), (0, -(ey / 2 - d), z)]
        pts += [(sx * (ex / 2 - rc + (rc - d) * q), sy * (ey / 2 - rc + (rc - d) * q), z) for sx, sy in SIGNS]
        on = [nxh.dist_to(assy, bo, pt) for pt in pts]
        to = [nxh.dist_to(assy, lo, pt) for pt in pts]
        m["lip"][name] = {"on_tongue_max": max(on), "min": min(to), "max": max(to)}
    m["screws"] = [{"origin": [round(v, 6) + 0.0 for v in L.frame(c)[0]], "axis_z": round(L.axis_of(c)[2], 9),
                    "status": [L.status_name(k) for k in c.GetConstraints()],
                    "dof": [c.GetDegreesOfFreedom().NumRotational, c.GetDegreesOfFreedom().NumTranslational]}
                   for c in screws]
    m["pcb_frame"] = L.frame(pcb_c)[0]
    return m


def judge(tag, m, p):
    ex, ey = env(p)
    hx, hy = p["hole_dx"], p["hole_dy"]
    want = sorted((sx * hx, sy * hy) for sx, sy in SIGNS)
    chk(tag + ": env_x", m["env"][0], ex, 1e-9)
    chk(tag + ": env_y", m["env"][1], ey, 1e-9)
    chk(tag + ": base volume vs analytic", m["base_volume"], base_expected(p), 0.1)
    chk(tag + ": lid volume vs analytic", m["lid_volume"], lid_expected(p), 0.1)
    chk.true(tag + ": one solid each, no feature errors", m["base_solids"] == 1 and m["lid_solids"] == 1
             and not m["base_errors"] and not m["lid_errors"], [m["base_errors"], m["lid_errors"]])
    chk.true(tag + ": bosses at the PCB holes", m["boss_axes"] == want, m["boss_axes"])
    chk.true(tag + ": pilot holes at the PCB holes", m["pilot_axes"] == want, m["pilot_axes"])
    chk.true(tag + ": button opening over the button", m["button_opening"] == [(p["btn_x"], p["btn_y"])], m["button_opening"])
    chk(tag + ": boss tops on the PCB bottom (count at z 6)", m["boss_tops_at_6"], 4, 0)
    chk(tag + ": PCB outline to wall = gap_xy 4.0 (>= 1.5)", m["pcb_to_wall"], 4.0, 1e-6)
    chk(tag + ": tall component to lid 5.4 (>= 0.8)", m["tall_to_lid"], 5.4, 1e-6)
    chk.true(tag + ": USB opening = connector + 0.4 on all four sides",
             m["usb_gaps"] is not None and all(abs(g - 0.4) < 1e-6 for g in m["usb_gaps"]), m["usb_gaps"])
    for k in ("outer", "inner", "top"):
        chk(tag + ": lip probe points lie on the tongue (" + k + ")", m["lip"][k]["on_tongue_max"], 0.0, 0.005)
        chk(tag + ": lip/groove clearance min, 8 points (" + k + ")", m["lip"][k]["min"], 0.1, 0.005)
        chk(tag + ": lip/groove clearance max, 8 points (" + k + ")", m["lip"][k]["max"], 0.1, 0.005)
    for i, s in enumerate(m["screws"]):
        sx, sy = SIGNS[i]
        ok = (abs(s["origin"][0] - sx * hx) < 1e-6 and abs(s["origin"][1] - sy * hy) < 1e-6 and abs(s["origin"][2] - 7.6) < 1e-6
              and abs(s["axis_z"] - 1.0) < 1e-9 and all(x == "Solved" for x in s["status"]) and s["dof"] == [1, 0])
        chk.true(f"{tag}: screw {i + 1} seated in its hole, Solved, DOF 1/0", ok, s)
    chk.true(tag + ": PCB (ground) unmoved", all(abs(a - b) < 1e-9 for a, b in zip(m["pcb_frame"], (0, 0, 6.0))), m["pcb_frame"])


def main():
    nxh.close_all()
    p_pcb, p_scr = os.path.join(OUT, "pcb.prt"), os.path.join(OUT, "screw.prt")
    pcb = build_pcb(p_pcb)
    scr = build_screw(p_scr)
    log("parts built", round(time.time() - T0, 1))
    # ------------------------------------------------------------ assembly
    assy = nxh.new_part(os.path.join(OUT, "sensor_box_asm.prt"), "assembly-mm-template.prt")
    for n, v in M.items():
        nxh.expr(assy, n, v)
    nxh.save(assy)
    pcb_c = L.add(assy, p_pcb, "PCB", (0, 0, M["pcb_z"]))
    c = L.constrain(assy, L.T.Fix, [(pcb_c, pcb_c, False)], name="FIX_PCB")
    chk.true("asm: PCB Fix solved, IsFixed, DOF 0/0", L.status_name(c) == "Solved" and pcb_c.IsFixed
             and pcb_c.GetDegreesOfFreedom().NumRotational == 0 and pcb_c.GetDegreesOfFreedom().NumTranslational == 0,
             L.status_name(c))
    chk("asm: PCB origin at z = 6", L.frame(pcb_c)[0][2], 6.0, 1e-9)
    res["notes"]["occurrence_bbox_board"] = nxh.bbox(L.occ(pcb_c, L.named_body(pcb, "BOARD")))
    # envelope follows the PCB through interpart expressions in the assembly
    out, err = nxh.attempt("asm interpart from pcb", link_exprs, assy, ["pcb_len", "pcb_w"], "pcb", log=log)
    if err:
        res["notes"]["asm_interpart_from_child_failed"] = err
        nxh.expr(assy, "pcb_len", 60)
        nxh.expr(assy, "pcb_w", 40)
    nxh.expr(assy, "env_x", "pcb_len+2*(gap_xy+wall)", comment="outside X")
    nxh.expr(assy, "env_y", "pcb_w+2*(gap_xy+wall)", comment="outside Y")
    chk("asm: env_x", val(assy, "env_x"), 72.0, 1e-9)
    chk("asm: env_y", val(assy, "env_y"), 52.0, 1e-9)
    # ------------------------------------------------------------ screws
    board, sbody = L.named_body(pcb, "BOARD"), L.named_body(scr, "SCREW")
    e_s = L.circ_edge(sbody, (0, 0, 0), 1.25)
    screws = []
    for i, (sx, sy) in enumerate(SIGNS):
        sc = L.add(assy, p_scr, f"SCREW{i + 1}", (sx * 26.0 + 3, sy * 16.0 + 2, 15.0))
        d0 = sc.GetDegreesOfFreedom()
        e_h = L.circ_edge(board, (sx * 26.0, sy * 16.0, 1.6), 1.35)
        c = L.constrain(assy, L.T.Concentric, [(sc, L.occ(sc, e_s), False), (pcb_c, L.occ(pcb_c, e_h), False)],
                        name=f"SCREW{i + 1}_IN_HOLE")
        flipped = False
        if L.axis_of(sc)[2] < 0:
            L.flip(assy, c)
            flipped = True
        d1 = sc.GetDegreesOfFreedom()
        o = L.frame(sc)[0]
        res["steps"][f"screw{i + 1}"] = {"status": L.status_name(c), "origin": o, "axis": L.axis_of(sc), "flipped": flipped,
                                         "dof_before": [d0.NumRotational, d0.NumTranslational],
                                         "dof_after": [d1.NumRotational, d1.NumTranslational]}
        chk.true(f"asm: screw {i + 1} Concentric solved, head seated at z 7.6, axis +Z, DOF 1/0",
                 L.status_name(c) == "Solved" and abs(o[0] - sx * 26) < 1e-6 and abs(o[1] - sy * 16) < 1e-6
                 and abs(o[2] - 7.6) < 1e-6 and abs(L.axis_of(sc)[2] - 1) < 1e-9
                 and [d1.NumRotational, d1.NumTranslational] == [1, 0], res["steps"][f"screw{i + 1}"])
        screws.append(sc)
    nxh.save(assy)
    log("assembly + screws", round(time.time() - T0, 1))
    # ------------------------------------------------------------ top-down parts
    base_c = L.new_component(assy, os.path.join(OUT, "box_base.prt"), "BASE")
    bp, base = build_base(assy, base_c, pcb_c, pcb)
    log("base built", round(time.time() - T0, 1))
    L.set_work(None)
    lid_c = L.new_component(assy, os.path.join(OUT, "box_lid.prt"), "LID")
    lp, lid = build_lid(assy, lid_c, pcb_c, pcb)
    log("lid built", round(time.time() - T0, 1))
    L.set_work(None)
    nxh.update()
    ctx = (assy, pcb_c, pcb, base_c, bp, base, lid_c, lp, lid, screws)
    # ------------------------------------------------------------ nominal checks in the assembly
    m0 = measure(ctx, NOM)
    res["steps"]["nominal"] = m0
    judge("nominal", m0, NOM)
    # clearance analysis + pairwise interference
    cs = L.clearance_set(assy, "CS_BOX", 0.0)
    res["steps"]["clearance_analysis"] = L.run_clearance(cs)
    hard = [r for r in res["steps"]["clearance_analysis"] if r["type"] == "Hard"]
    res["steps"]["clearance_hard"] = hard
    ob = {"BASE": L.occ(base_c, base), "LID": L.occ(lid_c, lid)}
    for n in ("BOARD", "USB", "TALL", "BUTTON"):
        ob["PCB." + n] = L.occ(pcb_c, L.named_body(pcb, n))
    for i, sc in enumerate(screws):
        ob[f"SCREW{i + 1}"] = L.occ(sc, sbody)
    names = list(ob)
    pw = {}
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = names[i], names[j]
            if a.startswith("PCB.") and b.startswith("PCB."):
                continue
            r, vols = L.simple_interference(assy, ob[a], ob[b])
            if r != "NoInterference":
                pw[a + " | " + b] = [r, [round(v, 4) for v in vols]]
    res["steps"]["pairwise_interference"] = pw
    thread = pi * (1.25 ** 2 - 1.05 ** 2) * 5 + pi * 1.25 ** 2 * 1.0     # shank dia 2.5 in pilot dia 2.1 x 5, then 1 mm of floor
    for k, (r, vols) in pw.items():
        if r == "InterferenceExists":
            is_thread = k.startswith("BASE | SCREW")
            chk.true("interference " + k + (" = thread engagement of the spec" if is_thread else " UNEXPECTED"),
                     is_thread and abs(sum(vols) - thread) < 1e-2, [vols, thread])
    chk.true("no hard interference box-box, box-PCB, PCB-screw, lid-screw",
             not [k for k, (r, _v) in pw.items() if r == "InterferenceExists" and not k.startswith("BASE | SCREW")], pw)
    log("nominal checks", round(time.time() - T0, 1))

    # ------------------------------------------------------------ associativity test
    def set_pcb(p):
        for n in ("hole_dx", "hole_dy", "btn_x", "btn_y", "pcb_len", "pcb_w"):
            nxh.set_expr(pcb, n, p[n])

    def close(m, p):
        return abs(m["base_volume"] - base_expected(p)) < 0.1 and abs(m["lid_volume"] - lid_expected(p)) < 0.1

    def regen(p, tag):
        trace = []
        set_pcb(p)
        e = nxh.update()
        m = measure(ctx, p)
        trace.append(["set_expr in pcb (work part = assembly) + one nxh.update()", e, m["base_volume"], m["lid_volume"], close(m, p)])
        if not close(m, p):
            e = 0
            for c in (pcb_c, None, base_c, lid_c, None):
                L.set_work(c)
                e += nxh.update()
            m = measure(ctx, p)
            trace.append(["work part pcb / asm / base / lid / asm, nxh.update() each", e, m["base_volume"], m["lid_volume"], close(m, p)])
        res["steps"][tag + "_trace"] = trace
        return m

    m1 = regen(CHG, "changed")
    res["steps"]["changed"] = m1
    judge("changed", m1, CHG)
    chk("changed: base outside follows (xmax 37)", m1["base_bbox"][3], 37.0, 1e-6)
    chk("changed: lid outside follows (ymax 27)", m1["lid_bbox"][4], 27.0, 1e-6)
    r, vols = L.simple_interference(assy, ob["BASE"], ob["LID"])
    chk.true("changed: base/lid do not interfere", r != "InterferenceExists", [r, vols])
    log("changed checks", round(time.time() - T0, 1))
    m2 = regen(NOM, "restored")
    res["steps"]["restored"] = m2
    judge("restored", m2, NOM)
    chk("restored: base volume returns (relative)", m2["base_volume"] / m0["base_volume"], 1.0, 1e-6)
    chk("restored: lid volume returns (relative)", m2["lid_volume"] / m0["lid_volume"], 1.0, 1e-6)
    chk.true("restored: Examine Geometry clean on both", nxh.body_ok(bp, base) and nxh.body_ok(lp, lid))
    L.set_work(None)
    nxh.save(assy)
    res["steps"]["saved"] = [p.FullPath for p in S.Parts]
    log("saved", round(time.time() - T0, 1))


def main_reopen():
    """Journal 2 (fresh NX process): reopen, which load / update calls make a PCB change propagate, restore, STEP."""
    import json
    nominal = json.load(open(os.path.join(OUT, "build.json"), encoding="utf-8"))["steps"]["nominal"]
    nxh.close_all()
    lo = S.Parts.LoadOptions
    res["steps"]["load_options"] = {n: str(getattr(lo, n)) for n in ("ComponentsToLoad", "UsePartialLoading") if hasattr(lo, n)}
    assy = nxh.open_part(os.path.join(OUT, "sensor_box_asm.prt"))
    comps = {c.Name: c for c in assy.ComponentAssembly.RootComponent.GetChildren()}
    res["steps"]["components"] = sorted(comps)
    pcb_c, base_c, lid_c = comps["PCB"], comps["BASE"], comps["LID"]
    screws = [comps[f"SCREW{i + 1}"] for i in range(4)]
    pcb, bp, lp, scr = pcb_c.Prototype, base_c.Prototype, lid_c.Prototype, screws[0].Prototype

    def loaded():
        return {n: [p.IsFullyLoaded, len(list(p.Features.GetFeatures()))] for n, p in (("asm", assy), ("pcb", pcb), ("base", bp), ("lid", lp), ("screw", scr))}

    def big(part):
        return max(nxh.solids(part), key=lambda x: nxh.volume(part, x))

    trace = []

    def tr(label, e=None):
        vb, vl = nxh.volume(bp, big(bp)), nxh.volume(lp, big(lp))
        trace.append({"step": label, "update_errors": e, "env_x": val(assy, "env_x"), "base": vb, "lid": vl,
                      "base_followed": abs(vb - base_expected(CHG)) < 0.1, "lid_followed": abs(vl - lid_expected(CHG)) < 0.1,
                      "fully_loaded/features": loaded()})
        log(label, vb, vl)

    tr("OpenBaseDisplay(sensor_box_asm.prt)")
    chk("reopened: base volume as saved", trace[0]["base"] / nominal["base_volume"], 1.0, 1e-9)
    chk("reopened: lid volume as saved", trace[0]["lid"] / nominal["lid_volume"], 1.0, 1e-9)
    pcb.LoadThisPartFully().Dispose()
    tr("pcb.LoadThisPartFully()")
    for n in ("hole_dx", "hole_dy", "btn_x", "btn_y", "pcb_len", "pcb_w"):
        nxh.set_expr(pcb, n, CHG[n])
    tr("nxh.set_expr x6 in pcb", None)
    tr("nxh.update()  [DoUpdate]", nxh.update())
    try:
        S.UpdateManager.DoInterpartUpdate(nxh.mark("interpart"))
        tr("UpdateManager.DoInterpartUpdate(mark)")
    except Exception as ex:  # noqa: BLE001
        tr("DoInterpartUpdate ERR " + str(ex))
    tr("nxh.update()", nxh.update())
    bp.LoadThisPartFully().Dispose()
    tr("base.LoadThisPartFully()")
    lp.LoadThisPartFully().Dispose()
    tr("lid.LoadThisPartFully()")
    tr("nxh.update()", nxh.update())
    scr.LoadThisPartFully().Dispose()
    tr("screw.LoadThisPartFully() + nxh.update()", nxh.update())
    res["steps"]["reopen_trace"] = trace
    res["steps"]["first_step_base_followed"] = next((t["step"] for t in trace if t["base_followed"]), None)
    res["steps"]["first_step_lid_followed"] = next((t["step"] for t in trace if t["lid_followed"]), None)
    base, lid = big(bp), big(lp)
    ctx = (assy, pcb_c, pcb, base_c, bp, base, lid_c, lp, lid, screws)
    m1 = measure(ctx, CHG)
    res["steps"]["reopened_changed"] = m1
    judge("reopened+changed", m1, CHG)
    for n in ("hole_dx", "hole_dy", "btn_x", "btn_y", "pcb_len", "pcb_w"):
        nxh.set_expr(pcb, n, NOM[n])
    res["steps"]["restore_update_errors"] = nxh.update()
    m2 = measure(ctx, NOM)
    res["steps"]["reopened_restored"] = m2
    judge("reopened+restored", m2, NOM)
    chk("reopened+restored: base volume = nominal of journal 1 (relative)", m2["base_volume"] / nominal["base_volume"], 1.0, 1e-6)
    chk("reopened+restored: lid volume = nominal of journal 1 (relative)", m2["lid_volume"] / nominal["lid_volume"], 1.0, 1e-6)
    chk.true("reopened+restored: Examine Geometry clean on both", nxh.body_ok(bp, base) and nxh.body_ok(lp, lid))
    res["steps"]["base_tree"] = [[r["name"], r["type"]] for r in nxh.feature_table(bp)]
    res["steps"]["lid_tree"] = [[r["name"], r["type"]] for r in nxh.feature_table(lp)]
    res["steps"]["pcb_tree"] = [[r["name"], r["type"]] for r in nxh.feature_table(pcb)]
    res["steps"]["exprs_asm"] = sorted(f"{e.Name}={e.RightHandSide}" for e in assy.Expressions if not e.Name.startswith("p"))
    res["steps"]["exprs_base"] = sorted(f"{e.Name}={e.RightHandSide}" for e in bp.Expressions if not e.Name[1:2].isdigit())
    # ---- STEP AP242 of each box part and of the assembly, each re-imported
    L.set_work(None)
    nxh.save(assy)
    step = {}
    for name, part, body in (("box_base", bp, base), ("box_lid", lp, lid)):
        stp = os.path.join(OUT, name + ".stp")
        nxf.step_export(part, stp)
        r = nxf.step_roundtrip_check(stp, OUT, name, restore=assy)
        r["nx_volume"] = nxh.volume(part, body)
        step[name] = r
        chk.true(name + ".stp: AP242, 1 solid, healthy", r["schema"] == "AP242" and r["solids"] == 1 and r["healthy"], r)
        chk(name + ".stp: volume round trip (relative)", r["volume"] / r["nx_volume"], 1.0, 1e-5)
        log("step", name, r["solids"], r["volume"])
    res["steps"]["step"] = step
    try:
        stp = os.path.join(OUT, "sensor_box_asm.stp")
        nxf.step_export(assy, stp)
        with open(stp, "r", encoding="utf-8", errors="replace") as fh:
            txt = fh.read()
        step["sensor_box_asm"] = {"schema": nxf.step_schema(stp), "manifold_solid_brep": txt.count("MANIFOLD_SOLID_BREP"),
                                  "next_assembly_usage": txt.count("NEXT_ASSEMBLY_USAGE_OCCURRENCE"), "bytes": len(txt)}
        want = (m2["base_volume"] + m2["lid_volume"] + sum(nxh.volume(pcb, b) for b in nxh.solids(pcb))
                + 4 * nxh.volume(scr, nxh.solids(scr)[0]))
        step["sensor_box_asm"]["nx_volume_all_instances"] = want
        r = nxf.step_roundtrip_check(stp, OUT, "sensor_box_asm", restore=assy)
        step["sensor_box_asm"].update(r)
    except Exception as ex:  # noqa: BLE001
        step.setdefault("sensor_box_asm", {})["ERROR"] = [str(ex)] + traceback.format_exc().splitlines()[-6:]
    log("done", round(time.time() - T0, 1))


MODE = sys.argv[3] if len(sys.argv) > 3 else "build"
try:
    main() if MODE == "build" else main_reopen()
except Exception as e:  # noqa: BLE001
    res["FATAL"] = [str(e)] + traceback.format_exc().splitlines()
    chk.true("no fatal error", False, e)
    log("FATAL", traceback.format_exc())
res["seconds"] = round(time.time() - T0, 1)
res.update(chk.report())
nxh.write_json(os.path.join(OUT, MODE + ".json"), res)
