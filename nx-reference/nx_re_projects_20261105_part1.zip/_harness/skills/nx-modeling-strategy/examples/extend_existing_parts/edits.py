import os, sys, traceback, shutil, math
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen, NXOpen.Features, NXOpen.UF
import nxh, nxf

S, UFS, P, BOOL = nxh.S, nxh.UFS, nxh.P, nxh.BOOL
A = nxf.A
W = sys.argv[1]
MODES = sys.argv[2:] or ["MH", "JE"]
OUT = os.path.join(W, "out")
log = nxh.Log(os.path.join(OUT, "edits_%s.log" % "_".join(MODES)))


def state(part):
    out = {}
    for i, f in enumerate(part.Features.GetFeatures()):
        try:
            err = tuple(f.GetFeatureErrorMessages() or [])
        except Exception as e:
            err = ("EXC",)
        out[f.Tag] = (bool(f.Suppressed), err, f.FeatureType)
    return out


def vols(part):
    return {b.Tag: (nxh.volume(part, b) if b.IsSolidBody else -nxh.sheet_area(part, b)[0]) for b in part.Bodies}


NAMES = {}


def ftab(part):
    return [(f.Timestamp, f.GetFeatureName(), bool(f.Suppressed)) for f in part.Features.GetFeatures()]


class Run:
    def __init__(self, part, tag):
        self.part, self.tag = part, tag
        self.pre = state(part)
        NAMES.update({f.Tag: f.GetFeatureName() for f in part.Features.GetFeatures()})
        self.table_before = ftab(part)
        self.nbodies = len(list(part.Bodies))
        self.res = {"edits": {}, "n_features_before": len(self.pre), "n_bodies_before": self.nbodies}
        self.chk = nxh.Check()

    def edit(self, label, target, fn):
        """fn() -> expected dV of target (or None). Measures, compares, rolls back on exception."""
        part = self.part
        m = nxh.mark(label)
        v0 = vols(part)
        r = {"result": "FAIL"}
        self.res["edits"][label] = r
        c = nxh.Check()
        try:
            exp, extra = fn(c)
            v1 = vols(part)
            dv = v1[target.Tag] - v0[target.Tag]
            r.update(v_before=v0[target.Tag], v_after=v1[target.Tag], dV=dv, dV_expected=exp)
            if exp is not None:
                tol = extra.get("tol", 1e-3)
                c("dV " + label, dv, exp, tol)
            others = {t: (v0[t], v1.get(t)) for t in v0 if t != target.Tag and (v1.get(t) is None or abs(v1[t] - v0[t]) > 1e-9)}
            c.true("other bodies unchanged", not others, others)
            c.true("body count unchanged", len(list(part.Bodies)) == self.nbodies, len(list(part.Bodies)))
            cur = state(part)
            changed = {NAMES.get(k, k): (self.pre[k], cur.get(k)) for k in self.pre if cur.get(k) != self.pre[k]}
            c.true("pre-existing features unchanged", not changed, changed)
            new_err = {str(k): v for k, v in cur.items() if k not in self.pre and v[1]}
            c.true("no errors on new features", not new_err, new_err)
            ex = nxh.examine_geometry(part, target)
            c.true("examine geometry clean", all(v == 0 for v in ex.values()), ex)
            r.update(extra)
            r.update(c.report())
        except Exception:
            r["error"] = traceback.format_exc()
            try:
                nxh.undo_to(m)
            except Exception as e:
                r["undo_error"] = str(e)
        log(self.tag, label, r.get("result"), "dV", r.get("dV"), "exp", r.get("dV_expected"), (r.get("error") or "")[-600:])
        for row in r.get("checks", []):
            if not row["ok"]:
                log("    FAILED CHECK", row)
        return r.get("result") == "PASS"


def face_at(part, body, xyz, tol=1e-6):
    return [f for f in body.GetFaces() if nxh.dist_to(part, f, xyz) < tol]


def open_copy(src, name):
    dst = os.path.join(OUT, name)
    if os.path.exists(dst):
        os.remove(dst)
    shutil.copyfile(src, dst)
    part, st = S.Parts.OpenBaseDisplay(dst)
    st.Dispose()
    return part


def deliver(part, run, bodies, stem):
    res = run.res
    nxh.save(part)
    stp = os.path.join(OUT, stem + ".stp")
    vsum = sum(nxh.volume(part, b) for b in nxh.solids(part))
    res["step"] = {"nx_solids": len(nxh.solids(part)), "nx_volume_all_solids": vsum}
    try:
        nxf.step_export(part, stp, ap242=True, save=False)
        res["step"]["size"] = os.path.getsize(stp)
        rt = nxf.step_roundtrip_check(stp, OUT, stem, restore=part)
        res["step"]["roundtrip"] = rt
        run.chk("STEP solids", rt["solids"], len(nxh.solids(part)), 0)
        run.chk("STEP volume rel", rt["volume"] / vsum, 1.0, 1e-5)
        run.chk.true("STEP healthy", rt["healthy"], rt["examine"])
        run.chk.true("STEP schema AP242", rt["schema"] == "AP242", rt["schema"])
    except Exception:
        res["step"]["error"] = traceback.format_exc()
        run.chk.true("STEP export", False, res["step"]["error"][-300:])


def regen(part, run, target, changes, label):
    """changes: [(name, nominal, new, expected dV of target)]"""
    r = run.res.setdefault("regen", {})
    v_nom = nxh.volume(part, target)
    pre = state(part)
    for name, nom, new, exp in changes:
        nxh.set_expr(part, name, new)
        nxh.update("regen " + name)
        v = nxh.volume(part, target)
        cur = state(part)
        changed = {NAMES.get(k, k): (pre[k], cur.get(k)) for k in pre if cur.get(k) != pre[k]}
        r[name] = {"new": new, "dV": v - v_nom, "expected": exp, "changed_features": changed, "errors": nxh.feature_errors(part)}
        run.chk("regen %s -> %s dV" % (name, new), v - v_nom, exp, 2e-3)
        run.chk.true("regen %s feature states unchanged" % name, not changed, changed)
        nxh.set_expr(part, name, nom)
        nxh.update("restore " + name)
        v2 = nxh.volume(part, target)
        run.chk("regen %s restore rel" % name, v2 / v_nom, 1.0, 1e-6)
        log(label, "regen", name, new, "dV", v - v_nom, "exp", exp, "restored", v2 - v_nom)


# =============================================================================== MAIN HOUSING
def do_mh():
    part = open_copy(os.path.join(W, "input", "Main Housing.prt"), "Main_Housing_ext.prt")
    run = Run(part, "MH")
    res = run.res
    body = max(nxh.solids(part), key=lambda b: len(b.GetFaces()))
    dat = nxh.Datums(part)
    res["target"] = {"tag": body.Tag, "faces": len(body.GetFaces()), "volume": nxh.volume(part, body)}
    E = lambda n, v, c, u="mm": nxh.expr(part, n, v, u, c)

    # ---- a. pocket wall clearance (Offset Region, the user's linked-body-pocket tweak)
    def ed_a(c):
        E("pocket_clr", 0.2, "extra clearance of the floor pocket wall at -Y")
        fs = [f for f in nxh.faces(body, ftype=nxh.PLANE, normal=(0, 1, 0), ntol=1e-3)
              if abs(nxh.bbox(f)[1] + 7.6846) < 0.01 and abs(nxh.bbox(f)[2] - 3.0) < 0.02]
        assert len(fs) == 1, "pocket wall faces: %d" % len(fs)
        area = nxh.sheet_area(part, fs)[0]
        bb = nxh.bbox(fs[0])
        y0 = nxh.face_data(fs[0])[1][1]
        nxf.offset_region(part, fs, "-pocket_clr")
        c.true("face at new position y0-0.2", len(face_at(part, body, (0.0, y0 - 0.2, 3.5))) == 1, y0)
        c.true("no face at old position", len(face_at(part, body, (0.0, y0, 3.5))) == 0)
        nf = face_at(part, body, (0.0, y0 - 0.2, 3.5))
        return -0.2 * 31.28 * 1.0, {"tol": 0.02, "face_area": area, "face_bbox": bb, "area_x_d": area * 0.2,
                                    "new_face_bbox": nxh.bbox(nf[0]) if nf else None}
    run.edit("a_offset_region_pocket_wall", body, ed_a)

    # ---- d. raised land on the outer bottom (Divide Face offset-in-face + Offset Region)
    def ed_d(c):
        E("land_inset", 2.0, "inset of the bottom land from the face boundary")
        E("land_h", 0.2, "height of the bottom land")
        fs = nxh.faces(body, ftype=nxh.PLANE, normal=(0, 0, -1), at=(2, 2.5), tol=1e-3)
        assert len(fs) == 1, "bottom faces %d" % len(fs)
        n0 = len(body.GetFaces())
        _f, flip = nxf.divide_face_offset(part, fs[0], list(fs[0].GetEdges()), "land_inset")
        inner = [f for f in face_at(part, body, (0.0, -1.5, 2.5))]
        assert len(inner) == 1
        area = nxh.sheet_area(part, inner)[0]
        c("inner land area vs analytic", area, 25.368 * 25.0, 0.05)
        nxf.offset_region(part, inner, "land_h")
        c.true("land face at z=2.3", len(face_at(part, body, (0.0, -1.5, 2.3))) == 1)
        c.true("rim still at z=2.5", len(face_at(part, body, (13.6, -1.5, 2.5))) == 1)
        return area * 0.2, {"tol": 1e-3, "flip": flip, "inner_area": area, "faces_added": len(body.GetFaces()) - n0,
                            "analytic_dV": 25.368 * 25.0 * 0.2}
    run.edit("d_divide_face_offset_region_land", body, ed_d)

    # ---- c. screw boss + pilot hole + root blend
    E("floor_z", 4.0, "measured inner floor level")
    E("boss_x", -6.0, "screw boss centre x")
    E("boss_y", -12.0, "screw boss centre y")
    E("boss_d", 3.2, "screw boss diameter")
    E("boss_h", 3.0, "screw boss height above the floor")
    E("pilot_d", 1.2, "pilot hole diameter")
    E("pilot_depth", 2.5, "pilot hole depth")
    E("boss_r", 0.3, "boss root blend")

    def ed_c1(c):
        n0 = len(nxh.solids(part))
        nxh.cylinder(part, ("boss_x", "boss_y", "floor_z-0.5"), (0, 0, 1), "boss_d", "boss_h+0.5", op=BOOL.Unite, target=body)
        c.true("solid count", len(nxh.solids(part)) == n0)
        c.true("boss top at z=7", len(face_at(part, body, (-6.0, -11.0, 7.0))) == 1)
        return math.pi * 1.6 ** 2 * 3.0, {}
    ok = run.edit("c1_boss_cylinder_unite", body, ed_c1)

    def ed_c2(c):
        nxf.hole(part, body, [("boss_x", "boss_y", "floor_z+boss_h")], "pilot_d", depth="pilot_depth", tip=0, vector=(0, 0, -1))
        c.true("hole bottom at z=4.5", len(face_at(part, body, (-6.0, -12.0, 4.5))) == 1)
        return -math.pi * 0.6 ** 2 * 2.5, {}
    if ok:
        run.edit("c2_pilot_hole", body, ed_c2)

    def ed_c3(c):
        es = nxh.edges(body, lambda b: abs(b[2] - 4) < 1e-3 and abs(b[5] - 4) < 1e-3 and b[0] > -7.62 and b[3] < -4.38
                       and b[1] > -13.62 and b[4] < -10.38 and (b[3] - b[0]) > 3.0)
        assert es, "no root edge"
        nxf.edge_blend(part, [(es, "boss_r")])
        R, r = 1.6, 0.3
        exp = 2 * math.pi * (r * r * (R + r / 2) - (math.pi * r * r / 4) * (R + r - 4 * r / (3 * math.pi)))
        return exp, {"n_edges": len(es)}
    if ok:
        run.edit("c3_boss_root_blend", body, ed_c3)

    # ---- b. gusset rib between the -Y end wall and the floor (sketch on a datum plane)
    E("gus_x", 6.0, "gusset plane position")
    E("gus_h", 3.5, "gusset height up the wall")
    E("gus_l", 4.0, "gusset length along the floor")
    E("gus_t", 0.8, "gusset thickness")
    E("wall_y", 17.5, "measured |y| of the inner -Y end wall")

    def ed_b(c):
        _pf, plane = nxf.datum_plane(part, "offset", [dat.yz], "gus_x", name="GUSSET_PLANE")
        sk = nxf.new_sketch(part, plane, dat.y, dat.origin)
        a, b = (6.0, -17.5, 7.5), (6.0, -13.5, 4.0)
        ln = nxh.line(part, a, b)
        nxf.add(sk, ln, infer=False)
        dims = []
        for nm, ref, rh, assoc, org, formula in (
                ("start_y", dat.z, P(0, 0, 5), A.StartPoint, P(6, -19, 9), "wall_y"),
                ("start_z", dat.y, P(0, -5, 0), A.StartPoint, P(6, -19, 6), "floor_z+gus_h"),
                ("end_y", dat.z, P(0, 0, 5), A.EndPoint, P(6, -12, 9), "wall_y-gus_l"),
                ("end_z", dat.y, P(0, -5, 0), A.EndPoint, P(6, -12, 3), "floor_z")):
            try:
                nxf.pdim(sk, ref, rh, ln, assoc, org, formula)
                dims.append(nm + " ok")
            except Exception as e:
                dims.append(nm + " FAIL " + str(e)[:80])
        fin = nxf.finish_sketch(sk)
        nxf._rib(part, body, sk, a, False, "gus_t", False, None)
        exp = 0.8 * (3.5 * 4.0 / 2 - 1.5 ** 2 * (1 - math.pi / 4))
        c.true("one solid kept", len(nxh.solids(part)) == 2)
        c.true("gusset sketch fully constrained", fin["dof"] == 0, fin)
        mid = (6.4, -15.0, 4.5)
        c.true("gusset side face at x=6.4", len(face_at(part, body, mid)) == 1)
        return exp, {"tol": 5e-3, "dims": dims, "sketch": fin}
    run.edit("b_gusset_rib", body, ed_b)

    # ---- g. slot through the +Y end wall + edge blends
    E("slot_w", 6.0, "vent slot width")
    E("slot_h", 1.2, "vent slot height")
    E("slot_z", 10.2, "vent slot centre height")
    E("slot_y0", 14.0, "cut start (inside the cavity, inner wall measured at y 14.5)")
    E("slot_y1", 16.5, "cut end (outside, outer wall measured at y 16.0)")
    E("slot_r", 0.3, "slot corner blend")

    def ed_g1(c):
        inner = face_at(part, body, (0.0, 14.5, 10.2))
        outer = face_at(part, body, (0.0, 16.0, 10.2))
        n_out = len(nxh.faces(body, ftype=nxh.PLANE, normal=(0, 1, 0), at=(1, 16.0), tol=1e-3))
        assert len(inner) == 1 and len(outer) == 1, (len(inner), len(outer))
        wall = nxh.min_dist(inner[0], outer[0])
        c("end wall thickness", wall, 1.5, 1e-6)
        sk = nxf.new_sketch(part, dat.xz, dat.x, dat.origin)
        ls = nxf.hv_polygon(part, sk, [(-3, 9.6), (3, 9.6), (3, 10.8), (-3, 10.8)], to3d=lambda u, v: P(u, 0, v))
        nxf.pdim(sk, dat.z, P(0, 0, 5), ls[1], A.StartPoint, P(5, 0, 9), "slot_w/2")
        nxf.pdim(sk, dat.z, P(0, 0, 5), ls[3], A.StartPoint, P(-5, 0, 9), "slot_w/2")
        nxf.pdim(sk, dat.x, P(5, 0, 0), ls[0], A.StartPoint, P(0, 0, 8), "slot_z-slot_h/2")
        nxf.pdim(sk, dat.x, P(5, 0, 0), ls[2], A.StartPoint, P(0, 0, 12), "slot_z+slot_h/2")
        fin = nxf.finish_sketch(sk)
        c.true("slot sketch fully constrained", fin["status"] == "WellConstrained" and fin["dof"] == 0, fin)
        sec = nxh.section_region(part, sk, (0.0, 0.0, 10.2))
        nxh.extrude(part, sec, (0, 1, 0), "slot_y0", "slot_y1", op=BOOL.Subtract, target=body)
        c.true("slot floor face at z=9.6", len(face_at(part, body, (0.0, 15.25, 9.6))) == 1)
        c.true("slot side face at x=3", len(face_at(part, body, (3.0, 15.25, 10.2))) == 1)
        c.true("one housing solid", len(nxh.solids(part)) == 2)
        return -6.0 * 1.2 * 1.5, {"sketch": fin, "wall": wall, "planar_faces_at_y16": n_out}
    ok = run.edit("g1_slot_cut", body, ed_g1)

    def ed_g2(c):
        es = nxh.edges(body, lambda b: abs(abs(b[0]) - 3) < 1e-3 and abs(b[0] - b[3]) < 1e-3 and abs(b[2] - b[5]) < 1e-3
                       and b[1] > 14.4 and b[4] < 16.1 and (abs(b[2] - 9.6) < 1e-3 or abs(b[2] - 10.8) < 1e-3))
        assert len(es) == 4, len(es)
        nxf.edge_blend(part, [(es, "slot_r")])
        return 4 * (1 - math.pi / 4) * 0.09 * 1.5, {}
    if ok:
        run.edit("g2_slot_blends", body, ed_g2)

    # ---- helper probe on a real part: nxf.gusset_rib as published (then rolled back)
    m = nxh.mark("probe gusset_rib helper")
    try:
        v0 = nxh.volume(part, body)
        nxf.gusset_rib(part, body, dat, (-8.0, 0.0, 0.0), (1.0, 0.0, 0.0), (-8.0, -17.5, 7.5), (-8.0, -13.5, 4.0), (-8.0, -17.5, 4.0), 0.8)
        res["probe_gusset_rib_helper"] = {"dV": nxh.volume(part, body) - v0}
    except Exception as e:
        res["probe_gusset_rib_helper"] = {"error": str(e)}
    nxh.undo_to(m)

    res["final"] = {"volume": nxh.volume(part, body), "n_features": len(part.Features.GetFeatures()),
                    "errors": nxh.feature_errors(part), "examine": nxh.examine_geometry(part, body),
                    "new_features": [f.GetFeatureName() for f in part.Features.GetFeatures()][len(run.pre):],
                    "sketches": [(sk.Name,) + tuple(nxf.sketch_status(sk)) for sk in part.Sketches]}
    # ---- regeneration of two new expressions
    try:
        regen(part, run, body, [("boss_h", "3", "4", math.pi * 1.6 ** 2 * 1.0), ("slot_w", "6", "8", -2.0 * 1.2 * 1.5)], "MH")
    except Exception:
        res["regen_error"] = traceback.format_exc()
    cur = state(part)
    run.chk.true("final: every pre-existing feature unchanged", all(cur.get(k) == v for k, v in run.pre.items()))
    run.chk.true("final: body count", len(list(part.Bodies)) == run.nbodies)
    deliver(part, run, [body], "Main_Housing_ext")
    res["table_before"] = run.table_before
    res["table_after"] = ftab(part)
    res["overall"] = run.chk.report()
    res["all_edits_pass"] = all(e.get("result") == "PASS" for e in res["edits"].values())
    nxh.write_json(os.path.join(OUT, "MH_edits.json"), res)
    S.Parts.CloseAll(NXOpen.BasePart.CloseModified.CloseModified, None)


# =============================================================================== JUNI ENCLOSURE
def do_je():
    part = open_copy(os.path.join(W, "input", "Juni_Enclosure_Small.prt"), "Juni_Enclosure_Small_ext.prt")
    run = Run(part, "JE")
    res = run.res
    sol = nxh.solids(part)
    cup = [b for b in sol if abs(nxh.bbox(b)[2] + 5.1) < 0.01][0]
    lid = [b for b in sol if abs(nxh.bbox(b)[5] - 6.0) < 0.01 and abs(nxh.bbox(b)[2] - 4.25) < 0.01][0]
    res["target"] = {"cup": cup.Tag, "lid": lid.Tag, "cup_volume": nxh.volume(part, cup), "lid_volume": nxh.volume(part, lid)}
    E = lambda n, v, c, u="mm": nxh.expr(part, n, v, u, c)
    fr = lambda h: math.pi * h / 3 * (9.7 ** 2 + 9.7 * (9.7 - h) + (9.7 - h) ** 2)

    # ---- a. floor clearance (Offset Region)
    E("floor_clr", 0.3, "extra depth of the cup floor (floor wall 1.5 -> 1.2)")

    def ed_a(c):
        fs = nxh.faces(cup, ftype=nxh.PLANE, normal=(0, 0, 1), at=(2, -3.6), tol=1e-3)
        assert len(fs) == 1, len(fs)
        bot = nxh.faces(cup, ftype=nxh.PLANE, normal=(0, 0, -1), at=(2, -5.1), tol=1e-3)
        c("floor wall before", nxh.min_dist(fs[0], bot[0]), 1.5, 1e-6)
        nxf.offset_region(part, fs, "-floor_clr")
        nf = face_at(part, cup, (0.0, 0.0, -3.9))
        c.true("floor at z=-3.9", len(nf) == 1)
        c.true("no face at z=-3.6 centre", len(face_at(part, cup, (0.0, 0.0, -3.6))) == 0)
        c("floor wall after", nxh.min_dist(nf[0], bot[0]), 1.2, 1e-6)
        c("floor area unchanged = pi*9.7^2 (the 0.8 chamfer follows)", nxh.sheet_area(part, nf)[0], math.pi * 9.7 ** 2, 1e-3)
        c.true("wall r10.5 extended down to z=-3.0", len(face_at(part, cup, (10.5, 0.0, -3.0))) == 1)
        c.true("chamfer still 45 deg at mid height", len(face_at(part, cup, (10.1, 0.0, -3.5))) == 1)
        return -math.pi * 10.5 ** 2 * 0.3, {"tol": 1e-3, "first_guess_cone_extends": -fr(0.3)}
    run.edit("a_offset_region_floor", cup, ed_a)

    # ---- d. label recess on the outer bottom (Divide Face + Offset Region)
    E("lbl_inset", 1.5, "label recess inset from the bottom edge")
    E("lbl_depth", 0.2, "label recess depth")

    def ed_d(c):
        fs = nxh.faces(cup, ftype=nxh.PLANE, normal=(0, 0, -1), at=(2, -5.1), tol=1e-3)
        assert len(fs) == 1
        _f, flip = nxf.divide_face_offset(part, fs[0], list(fs[0].GetEdges()), "lbl_inset")
        inner = face_at(part, cup, (0.0, 0.0, -5.1))
        assert len(inner) == 1
        area = nxh.sheet_area(part, inner)[0]
        c("recess area vs pi*8.5^2", area, math.pi * 8.5 ** 2, 0.2)
        nxf.offset_region(part, inner, "-lbl_depth")
        nf = face_at(part, cup, (0.0, 0.0, -4.9))
        c.true("recess floor at z=-4.9", len(nf) == 1)
        c.true("rim still at z=-5.1", len(face_at(part, cup, (9.3, 0.0, -5.1))) == 1)
        fl = face_at(part, cup, (0.0, 0.0, -3.9))
        c("bottom wall at the recess", nxh.min_dist(nf[0], fl[0]), 1.0, 1e-6)
        return -area * 0.2, {"tol": 1e-3, "flip": flip, "inner_area": area, "analytic_dV": -math.pi * 8.5 ** 2 * 0.2}
    run.edit("d_divide_face_offset_region_recess", cup, ed_d)

    # ---- c. screw boss + pilot hole + root blend on the cup floor
    E("cup_floor_z", "-3.6-floor_clr", "inner floor level, follows floor_clr")
    E("jb_x", 0.0, "boss centre x")
    E("jb_y", -7.4, "boss centre y")
    E("jb_d", 3.0, "boss diameter")
    E("jb_h", 2.0, "boss height")
    E("jp_d", 1.0, "pilot diameter")
    E("jp_depth", 1.6, "pilot depth")
    E("jb_r", 0.3, "boss root blend")

    def ed_c1(c):
        n0 = len(nxh.solids(part))
        nxh.cylinder(part, ("jb_x", "jb_y", "cup_floor_z-0.5"), (0, 0, 1), "jb_d", "jb_h+0.5", op=BOOL.Unite, target=cup)
        c.true("solid count", len(nxh.solids(part)) == n0)
        c.true("boss top at z=-1.9", len(face_at(part, cup, (0.0, -6.4, -1.9))) == 1)
        return math.pi * 1.5 ** 2 * 2.0, {}
    ok = run.edit("c1_boss_cylinder_unite", cup, ed_c1)

    def ed_c2(c):
        nxf.hole(part, cup, [("jb_x", "jb_y", "cup_floor_z+jb_h")], "jp_d", depth="jp_depth", tip=0, vector=(0, 0, -1))
        c.true("hole bottom at z=-3.5", len(face_at(part, cup, (0.0, -7.4, -3.5))) == 1)
        return -math.pi * 0.5 ** 2 * 1.6, {}
    if ok:
        run.edit("c2_pilot_hole", cup, ed_c2)

    def ed_c3(c):
        es = nxh.edges(cup, lambda b: abs(b[2] + 3.9) < 1e-3 and abs(b[5] + 3.9) < 1e-3 and b[0] > -1.52 and b[3] < 1.52
                       and b[1] > -8.92 and b[4] < -5.88 and (b[3] - b[0]) > 2.9)
        assert es, "no root edge"
        nxf.edge_blend(part, [(es, "jb_r")])
        R, r = 1.5, 0.3
        return 2 * math.pi * (r * r * (R + r / 2) - (math.pi * r * r / 4) * (R + r - 4 * r / (3 * math.pi))), {"n_edges": len(es)}
    if ok:
        run.edit("c3_boss_root_blend", cup, ed_c3)

    # ---- e. remove the two small holes of the lid (Delete Face + heal)
    def ed_e(c):
        hc = nxh.hole_census(part, lid)
        hs = [h for h in hc["holes"] if abs(h["diameter"] - 2.2) < 0.01]
        assert len(hs) == 2, [h["diameter"] for h in hc["holes"]]
        faces = [f for h in hs for f in h["faces"]]
        n0 = len(lid.GetFaces())
        nxf.delete_face(part, faces)
        c("lid face count", len(lid.GetFaces()), n0 - 2, 0)
        c.true("lid top closed at the old hole", len(face_at(part, lid, (6.1799, 7.0001, 6.0))) == 1)
        c.true("lid inside closed at the old hole", len(face_at(part, lid, (-6.8203, 6.9999, 5.5))) == 1)
        return 2 * math.pi * 1.1 ** 2 * 0.5, {"tol": 1e-3, "holes": [(h["diameter"], h["point"], h["length"]) for h in hs]}
    run.edit("e_delete_face_lid_holes", lid, ed_e)

    res["final"] = {"cup_volume": nxh.volume(part, cup), "lid_volume": nxh.volume(part, lid),
                    "n_features": len(part.Features.GetFeatures()), "errors": nxh.feature_errors(part),
                    "examine_cup": nxh.examine_geometry(part, cup), "examine_lid": nxh.examine_geometry(part, lid),
                    "new_features": [f.GetFeatureName() for f in part.Features.GetFeatures()][len(run.pre):]}
    try:
        regen(part, run, cup, [("floor_clr", "0.3", "0.4", -math.pi * 10.5 ** 2 * 0.1), ("jb_h", "2", "2.5", math.pi * 1.5 ** 2 * 0.5)], "JE")
    except Exception:
        res["regen_error"] = traceback.format_exc()
    cur = state(part)
    run.chk.true("final: every pre-existing feature unchanged", all(cur.get(k) == v for k, v in run.pre.items()))
    run.chk.true("final: body count", len(list(part.Bodies)) == run.nbodies)
    deliver(part, run, [cup, lid], "Juni_Enclosure_Small_ext")
    res["table_before"] = run.table_before
    res["table_after"] = ftab(part)
    res["overall"] = run.chk.report()
    res["all_edits_pass"] = all(e.get("result") == "PASS" for e in res["edits"].values())
    nxh.write_json(os.path.join(OUT, "JE_edits.json"), res)
    S.Parts.CloseAll(NXOpen.BasePart.CloseModified.CloseModified, None)


# =============================================================================== ORIGINAL DRIVERS (robustness reading)
def do_orig():
    out = {}
    for tag, src, tests in (
            ("MH", "Main Housing.prt", [("p0", "43"), ("p3", "15.4"), ("p20", "1.3"), ("p16", "3.5")]),
            ("JE", "Juni_Enclosure_Small.prt", [("p0", "26"), ("p5", "1.3"), ("p27", "17"), ("p22", "0.6")])):
        for name, new in tests:
            key = "%s %s->%s" % (tag, name, new)
            r = out.setdefault(key, {})
            try:
                part = open_copy(os.path.join(W, "input", src), "orig_%s_%s.prt" % (tag, name))
                pre = state(part)
                NAMES.clear()
                NAMES.update({f.Tag: f.GetFeatureName() for f in part.Features.GetFeatures()})
                v0 = vols(part)
                e = part.Expressions.FindObject(name)
                r["owner"] = [f.GetFeatureName() for f in part.Features.GetFeatures() if any(x.Name == name for x in f.GetExpressions())][:3]
                old = e.RightHandSide
                r["old"] = old
                e.RightHandSide = new
                try:
                    r["update_rc"] = nxh.update("orig " + name)
                except Exception as ex:
                    r["update_exc"] = str(ex)
                cur = state(part)
                r["changed"] = {NAMES.get(k, k): {"before": pre[k], "after": cur.get(k)} for k in pre if cur.get(k) != pre[k]}
                v1 = vols(part)
                r["volumes"] = {str(t): (v0.get(t), v1.get(t)) for t in set(v0) | set(v1)}
                r["n_bodies"] = (len(v0), len(v1))
                r["examine"] = {str(b.Tag): nxh.examine_geometry(part, b) for b in nxh.solids(part)}
                e.RightHandSide = old
                try:
                    nxh.update("restore " + name)
                except Exception as ex:
                    r["restore_exc"] = str(ex)
                cur2 = state(part)
                v2 = vols(part)
                r["restore_changed"] = {NAMES.get(k, k): {"before": pre[k], "after": cur2.get(k)} for k in pre if cur2.get(k) != pre[k]}
                r["restore_volumes"] = {str(t): (v0.get(t), v2.get(t)) for t in set(v0) | set(v2) if v0.get(t) is None or v2.get(t) is None or abs(v0[t] - v2[t]) > 1e-6}
            except Exception:
                r["error"] = traceback.format_exc()
            log(key, "changed", len(r.get("changed", {})), "restore_changed", len(r.get("restore_changed", {})), r.get("error", "")[-300:])
            try:
                S.Parts.CloseAll(NXOpen.BasePart.CloseModified.CloseModified, None)
            except Exception:
                pass
            nxh.write_json(os.path.join(OUT, "orig_drivers.json"), out)


for mode, fn in (("MH", do_mh), ("JE", do_je), ("ORIG", do_orig)):
    if mode in MODES:
        try:
            fn()
        except Exception:
            log(mode, "FATAL", traceback.format_exc())
            nxh.write_json(os.path.join(OUT, mode + "_FATAL.json"), {"tb": traceback.format_exc()})
            try:
                S.Parts.CloseAll(NXOpen.BasePart.CloseModified.CloseModified, None)
            except Exception:
                pass
