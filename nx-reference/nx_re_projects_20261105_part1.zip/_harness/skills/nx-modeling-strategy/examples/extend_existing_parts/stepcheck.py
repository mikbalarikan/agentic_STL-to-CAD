import os, sys, traceback
sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh, nxf
S = nxh.S
OUT = os.path.join(sys.argv[1], "out")
res = {}
for stem in ("Main_Housing_ext", "Juni_Enclosure_Small_ext"):
    r = res.setdefault(stem, {})
    try:
        part, st = S.Parts.OpenBaseDisplay(os.path.join(OUT, stem + ".prt"))
        st.Dispose()
        r["reopen_errors"] = nxh.feature_errors(part)
        r["nx"] = sorted([{"vol": nxh.volume(part, b), "blanked": b.IsBlanked, "layer": b.Layer, "bbox": nxh.bbox(b)} for b in nxh.solids(part)], key=lambda d: d["vol"])
        r["n_features"] = len(part.Features.GetFeatures())
        r["n_suppressed"] = sum(1 for f in part.Features.GetFeatures() if f.Suppressed)
        r["user_expressions"] = sorted(e.Name for e in part.Expressions if not (e.Name.startswith("p") and e.Name[1:].isdigit()))
        scratch = nxh.new_part(os.path.join(OUT, stem + "_pb_check.prt"))
        bodies = nxf.step_import(scratch, os.path.join(OUT, stem + ".stp"), os.path.join(OUT, stem + "_pb_tmp.prt"))
        r["step"] = sorted([{"vol": nxh.volume(scratch, b), "solid": b.IsSolidBody, "bbox": nxh.bbox(b), "ok": nxh.body_ok(scratch, b)} for b in bodies], key=lambda d: d["vol"])
        vis = [d for d in r["nx"] if not d["blanked"]]
        r["pairs"] = [{"nx": a["vol"], "step": b["vol"], "rel": b["vol"] / a["vol"] - 1} for a, b in zip(vis, r["step"])] if len(vis) == len(r["step"]) else "count mismatch %d vs %d" % (len(vis), len(r["step"]))
    except Exception:
        r["error"] = traceback.format_exc()
    S.Parts.CloseAll(NXOpen.BasePart.CloseModified.CloseModified, None)
nxh.write_json(os.path.join(OUT, "step_per_body.json"), res)
