"""Job A run 3 - fresh session: reopen the assembly, cell_gap 0.6 -> 0.8, which load / update calls are needed."""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import nxh
import nxf
import nxa

OUT = sys.argv[1]
log = nxh.Log(os.path.join(OUT, "a_reopen.log"))
res = {"result": "FAIL", "steps": []}
chk = nxh.Check()
pi = math.pi
src = open(os.path.join(os.path.dirname(OUT.rstrip("\\/")), "a_build.py"), encoding="utf-8").read()
exec(src[src.index("# ------------------------------------------------------------------ analytic expectations"):src.index("def hole_ext(")], globals())
KEYS = ["base", "cyl", "topcut", "open", "cavity", "relief", "slot_c", "slot_r", "ribs", "holes", "blend_long", "blend_rim_out", "blend_rim_in"]


def vexp(vals):
    E, _G = expected(vals)
    return sum(E[k] for k in KEYS)


try:
    S = nxh.S
    assy = nxh.open_part(os.path.join(OUT, "dock_asm.prt"))
    res["load_status"] = list(nxh.LOAD_STATUS)
    comps = nxa.components(assy)
    res["components"] = sorted(comps)
    cell, dockc, clipA, clipB = comps["CELL"], comps["DOCK"], comps["CLIP_A"], comps["CLIP_B"]
    cellp, dp = cell.Prototype, dockc.Prototype

    def dock_body():
        return [b for b in dp.Bodies if b.IsSolidBody][0]

    def state(label):
        b = dock_body()
        cb = [x for x in cellp.Bodies if x.IsSolidBody][0]
        row = {"step": label, "dock_fully_loaded": dp.IsFullyLoaded, "cell_fully_loaded": cellp.IsFullyLoaded,
               "dock_features": len(list(dp.Features.GetFeatures())) if dp.IsFullyLoaded else 0,
               "dock_volume": nxh.volume(dp, b), "min_dist_cell_dock": nxh.min_dist(nxa.occ(cell, cb), nxa.occ(dockc, b)),
               "asm_cell_gap": assy.Expressions.FindObject("cell_gap").Value}
        res["steps"].append(row)
        log(row)
        return row

    V06, V08 = vexp(NOM), vexp(dict(NOM, cell_gap=0.8))
    res["expected_volume_gap06"], res["expected_volume_gap08"] = V06, V08
    r0 = state("0 reopened (OpenBaseDisplay), nothing else")
    chk("reopened: dock volume = nominal", r0["dock_volume"], V06, 0.05)
    chk.true("reopened: components partially loaded", not r0["dock_fully_loaded"], r0)

    nxh.set_expr(assy, "cell_gap", 0.8)
    nxh.update()
    r1 = state("1 set cell_gap=0.8 in the assembly + nxh.update() (DoUpdate)")
    S.UpdateManager.DoInterpartUpdate(nxh.mark("interpart"))
    r2 = state("2 + UpdateManager.DoInterpartUpdate")
    nxh.update()
    r3 = state("3 + nxh.update() again")
    done = nxa.load_fully([dockc], update=False)
    res["loaded_a"] = done
    r4 = state("4 + dock.LoadThisPartFully() (nxa.load_fully([dock], update=False))")
    nxh.update()
    r5 = state("5 + nxh.update()")
    done = nxa.load_fully([cell, clipA, clipB], update=True)
    res["loaded_b"] = done
    r6 = state("6 + nxa.load_fully([cell, clips]) incl. update")
    first_ok = next((r["step"] for r in res["steps"] if abs(r["dock_volume"] - V08) < 0.05), None)
    res["first_step_with_updated_dock"] = first_ok
    chk.true("dock did NOT follow while partially loaded (steps 1-3)", all(abs(r["dock_volume"] - V06) < 0.05 for r in (r1, r2, r3)),
             [r["dock_volume"] for r in (r1, r2, r3)])
    chk("final: dock volume = analytic for cell_gap 0.8", r6["dock_volume"], V08, 0.05)
    chk("final: min distance cell - dock = 0.8", r6["min_dist_cell_dock"], 0.8, 1e-6)

    # verification at 0.8
    nxa.set_work(dockc)
    body = dock_body()
    cb = [x for x in cellp.Bodies if x.IsSolidBody][0]
    fe = nxh.feature_errors(dp)
    res["feature_errors_gap08"] = fe
    chk.true("gap 0.8: no feature errors", not fe, fe)
    chk.true("gap 0.8: one solid", len(nxh.solids(dp)) == 1)
    inner = nxh.faces(body, ftype=nxh.CYLINDER, radius=10.0)
    outer = nxh.faces(body, ftype=nxh.CYLINDER, radius=12.0)
    chk.true("gap 0.8: cradle inner radius 10.0 (= 9.2 + 0.8), outer 12.0", len(inner) >= 1 and len(outer) >= 1, (len(inner), len(outer)))
    bb = nxh.bbox(body)
    res["bbox_gap08"] = bb
    chk("gap 0.8: half width = r_out + flange = 16", bb[4], 16.0, 1e-3)
    chk("gap 0.8: length unchanged 71.2", bb[3] - bb[0], 71.2, 1e-3)
    res["examine_gap08"] = nxh.examine_geometry(dp, body)
    chk.true("gap 0.8: Examine Geometry clean", all(v == 0 for v in res["examine_gap08"].values()), res["examine_gap08"])
    res["link_status"] = {f.GetFeatureName(): nxh.link_status(f) for f in dp.Features.GetFeatures() if "Linked" in f.GetFeatureName()}
    chk.true("links not broken", all(v["broken"] is False for v in res["link_status"].values()), res["link_status"])
    nxa.set_work(None)
    cyl_cell = nxh.faces(cb, ftype=nxh.CYLINDER, radius=9.2)
    rad = min(nxh.min_dist(nxa.occ(cell, cyl_cell[0]), nxa.occ(dockc, i_)) for i_ in inner)
    res["radial_clearance_gap08"] = rad
    chk("gap 0.8: radial clearance cell-cradle (assembly)", rad, 0.8, 1e-6)
    for nm, comp, sign in (("A", clipA, -1), ("B", clipB, 1)):
        org, _r = nxa.frame(comp)
        res["clip_%s_origin_gap08" % nm] = org
        chk("gap 0.8: clip %s x" % nm, org[0], sign * 36.0, 1e-6)
        chk("gap 0.8: clip %s z" % nm, org[2], 17.0, 1e-6)
        chk.true("gap 0.8: clip %s dof [0,0]" % nm, nxa.dof(comp) == [0, 0], nxa.dof(comp))

    # Clearance Analysis: the unexpected CELL/DOCK Touch of run 2 - linked sheets in the MODEL reference set?
    cs = nxa.clearance_set(assy, "REOPEN_CLR", 0.0)
    res["clearance_before_refset_fix"] = nxa.run_clearance(cs)
    sheets = [b for b in dp.Bodies if not b.IsSolidBody]
    res["dock_sheets"] = [{"blanked": b.IsBlanked, "faces": len(b.GetFaces())} for b in sheets]
    model = [rs for rs in dp.GetAllReferenceSets() if rs.Name == "MODEL"]
    res["refsets"] = [rs.Name for rs in dp.GetAllReferenceSets()]
    occ_before = [dockc.FindOccurrence(b) is not None for b in sheets]
    res["linked_sheet_has_occurrence_before"] = occ_before
    nxa.set_work(dockc)
    if model and sheets:
        try:
            model[0].RemoveObjectsFromReferenceSet(sheets)
            res["refset_fix"] = "removed %d linked sheets from MODEL" % len(sheets)
        except Exception as e:  # noqa: BLE001
            res["refset_fix"] = "FAILED: " + str(e)[:200]
    nxa.set_work(None)
    nxh.update()
    res["linked_sheet_has_occurrence_after"] = [dockc.FindOccurrence(b) is not None for b in sheets]
    cs2 = nxa.clearance_set(assy, "REOPEN_CLR2", 0.0)
    res["clearance_after_refset_fix"] = nxa.run_clearance(cs2)
    chk.true("Clearance Analysis: no Hard", all(p["type"] != "Hard" for p in res["clearance_after_refset_fix"]), res["clearance_after_refset_fix"])
    chk.true("Clearance Analysis after refset fix: only the two clip seats Touch",
             [p["pair"] for p in res["clearance_after_refset_fix"]] == [["CLIP_A", "DOCK"], ["CLIP_B", "DOCK"]], res["clearance_after_refset_fix"])

    # back to nominal and save
    nxh.set_expr(assy, "cell_gap", 0.6)
    nxh.update()
    r7 = state("7 cell_gap back to 0.6 + nxh.update() (all fully loaded)")
    chk("restored: dock volume nominal", r7["dock_volume"], V06, 0.05)
    chk("restored: min distance 0.6", r7["min_dist_cell_dock"], 0.6, 1e-6)
    nxh.save(assy)
    res.update(chk.report())
except Exception:
    res["error"] = traceback.format_exc()
    res["checks"] = chk.rows
    res["result"] = "FAIL"
res["failed"] = [r for r in chk.rows if not r["ok"]]
res["n_checks"] = len(chk.rows)
nxh.write_json(os.path.join(OUT, "a_reopen.json"), res)
