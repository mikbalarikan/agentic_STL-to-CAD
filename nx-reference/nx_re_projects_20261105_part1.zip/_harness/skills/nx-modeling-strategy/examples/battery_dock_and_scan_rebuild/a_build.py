"""Job A - wall-mount dock for a cylindrical cell, top-down. Run 1: build, check, regen, STEP."""
import math
import os
import sys
import traceback

sys.path.insert(0, os.environ["NXH_DIR"])
import NXOpen
import NXOpen.Features
import nxh
import nxf
import nxa

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "a_build.log"))
res = {"result": "FAIL", "features": [], "notes": []}
chk = nxh.Check()
P, V = nxh.P, nxh.V
pi = math.pi
NULL = NXOpen.NXObject.Null


# ------------------------------------------------------------------ analytic expectations
def seg_area(r, h):
    if h <= 0:
        return 0.0
    return r * r * math.acos((r - h) / r) - (r - h) * math.sqrt(2 * r * h - h * h)


def simpson(fn, a, b, n=4000):
    h = (b - a) / n
    s = fn(a) + fn(b)
    for i in range(1, n):
        s += fn(a + i * h) * (4 if i % 2 else 2)
    return s * h / 3


def shoelace(pts):
    s = 0.0
    for i in range(len(pts)):
        x0, y0 = pts[i]
        x1, y1 = pts[(i + 1) % len(pts)]
        s += x0 * y1 - x1 * y0
    return abs(s) / 2


def blend_area_out(R, rho, n=4000):
    """corner between the line v=0 and the circle R (material inside), fillet rho"""
    yc = math.sqrt((R - rho) ** 2 - rho ** 2)
    phi = math.atan2(rho, yc)
    pts = [(yc, 0.0), (R, 0.0)]
    pts += [(R * math.cos(-phi * i / n), R * math.sin(-phi * i / n)) for i in range(1, n + 1)]
    a0, a1 = -phi, pi / 2
    pts += [(yc + rho * math.cos(a0 + (a1 - a0) * i / n), -rho + rho * math.sin(a0 + (a1 - a0) * i / n)) for i in range(1, n)]
    return shoelace(pts)


def blend_area_in(R, rho, n=4000):
    """corner between the line v=0 and the circle R (material OUTSIDE the circle), fillet rho"""
    yc = math.sqrt((R + rho) ** 2 - rho ** 2)
    phi = math.atan2(rho, yc)
    pts = [(yc, 0.0), (R, 0.0)]
    pts += [(R * math.cos(-phi * i / n), R * math.sin(-phi * i / n)) for i in range(1, n + 1)]
    a0, a1 = pi - phi, pi / 2
    pts += [(yc + rho * math.cos(a0 + (a1 - a0) * i / n), -rho + rho * math.sin(a0 + (a1 - a0) * i / n)) for i in range(1, n)]
    return shoelace(pts)


def expected(v):
    cd, cl, wt, gap, eg, rt, cz = v["cell_d"], v["cell_len"], v["wall_t"], v["cell_gap"], v["end_gap"], v["rib_t"], v["cell_z"]
    bt, fl, wu, sw, bd, bh = v["base_t"], v["flange"], v["wall_up"], v["slot_w"], v["btn_d"], v["btn_h"]
    hd, cbd, cbh, rl, rs_ = v["hole_d"], v["cb_d"], v["cb_h"], v["r_long"], v["r_small"]
    r_in = cd / 2 + gap
    r_out = r_in + wt
    L = cl + 2 * (eg + wt)
    Lin = L - 2 * wt
    hw = r_out + fl
    d = {}
    d["base"] = 2 * hw * bt * L
    d["cyl"] = (pi * r_out ** 2 - seg_area(r_out, bt - (cz - r_out))) * L
    segtop = seg_area(r_out, r_out - wu)
    d["topcut"] = -segtop * L
    d["open"] = -(pi * r_out ** 2 / 2 - segtop) * Lin
    d["cavity"] = -(pi * r_in ** 2 / 2) * Lin
    rr = bd / 2 + gap
    d["relief"] = -pi * rr ** 2 * bh
    rs = sw / 2
    d["slot_c"] = -pi * rs ** 2 * (2 * wt - bh)
    a_ov = simpson(lambda y: math.sqrt(rr * rr - y * y), -rs, rs) - pi * rs * rs / 2
    d["slot_r"] = -((sw * wu - pi * rs * rs / 2) * 2 * wt - a_ov * bh)
    yn = math.sqrt(r_out ** 2 - (cz - bt) ** 2)
    N, a, b = (yn, bt), (r_out + fl / 2, bt), (0.8660254 * r_out, cz - 0.5 * r_out)
    c = math.hypot(N[0] - b[0], N[1] - b[1])
    th = 2 * math.asin(c / (2 * r_out))
    a_g = shoelace([N, a, b]) - r_out ** 2 / 2 * (th - math.sin(th))
    d["ribs"] = 4 * a_g * rt
    cres = simpson(lambda y: 2 * math.sqrt(max(0.0, (cbd / 2) ** 2 - y * y)) * (r_in - math.sqrt(r_in * r_in - y * y)), -cbd / 2, cbd / 2)
    plain = pi * (cbd / 2) ** 2 * cbh + pi * (hd / 2) ** 2 * (cz - r_in - cbh)
    d["holes_noext"] = -2 * plain
    d["holes"] = -2 * (plain + cres)
    d["blend_long"] = -2 * (1 - pi / 4) * rl * rl * L
    d["blend_rim_out"] = -2 * blend_area_out(r_out, rl) * Lin
    d["blend_rim_in"] = -2 * blend_area_in(r_in, rs_) * Lin
    geo = {"r_in": r_in, "r_out": r_out, "L": L, "Lin": Lin, "hw": hw, "cz": cz}
    return d, geo


NOM = {"cell_d": 18.4, "cell_len": 65.2, "wall_t": 2.0, "cell_gap": 0.6, "end_gap": 1.0, "rib_t": 1.6, "cell_z": 14.0,
       "base_t": 3.0, "flange": 4.0, "wall_up": 4.0, "slot_w": 3.2, "btn_d": 6.0, "btn_h": 1.2, "hole_d": 4.2, "cb_d": 8.0,
       "cb_h": 2.0, "hole_in": 12.0, "r_long": 1.0, "r_small": 0.5}


def hole_ext(part, body, points, diameter, vector, cbore, start_ext):
    """copy of nxf.hole (counterbore, through) with StartExtensionEnabled selectable"""
    HPB = NXOpen.Features.HolePackageBuilder
    pts = [nxh.point(part, *p) for p in points]
    h = part.Features.CreateHolePackageBuilder(NXOpen.Features.HolePackage.Null)
    try:
        h.Type = HPB.Types.GeneralHole
        h.GeneralHoleForm = HPB.HoleForms.Counterbored
        h.GeneralCounterboreDiameter.RightHandSide = str(cbore[0])
        h.GeneralCounterboreDepth.RightHandSide = str(cbore[1])
        h.GeneralCounterboreHoleDiameter.RightHandSide = str(diameter)
        h.HoleDepthLimitOption = HPB.HoleDepthLimitOptions.ThroughBody
        h.Tolerance = 0.01
        h.StartExtensionEnabled = start_ext
        h.BooleanOperation.Type = nxh.BOOL.Subtract
        h.BooleanOperation.SetTargetBodies([body])
        h.HolePosition.AddToSection([part.ScRuleFactory.CreateRuleCurveDumbFromPoints(pts)], NULL, NULL, NULL,
                                    P(0, 0, 0), NXOpen.Section.Mode.Create, False)
        h.ProjectionDirection.ProjectDirectionMethod = nxf.GU.ProjectionOptions.DirectionType.Vector
        h.ProjectionDirection.ProjectVector = nxh.direction(part, vector)
        return h.CommitFeature()
    finally:
        h.Destroy()


def hole_ext2(part, body, points, diameter, cbore, start_ext):
    HPB = NXOpen.Features.HolePackageBuilder
    pts = [nxh.point(part, *p) for p in points]
    h = part.Features.CreateHolePackageBuilder(NXOpen.Features.HolePackage.Null)
    try:
        h.Type = HPB.Types.GeneralHole
        h.GeneralHoleForm = HPB.HoleForms.Counterbored
        h.GeneralCounterboreDiameter.RightHandSide = str(cbore[0])
        h.GeneralCounterboreDepth.RightHandSide = str(cbore[1])
        h.GeneralCounterboreHoleDiameter.RightHandSide = str(diameter)
        h.HoleDepthLimitOption = HPB.HoleDepthLimitOptions.ThroughBody
        h.Tolerance = 0.01
        h.StartExtensionEnabled = start_ext
        h.BooleanOperation.Type = nxh.BOOL.Subtract
        h.BooleanOperation.SetTargetBodies([body])
        h.HolePosition.AddToSection([part.ScRuleFactory.CreateRuleCurveDumbFromPoints(pts)], NULL, NULL, NULL,
                                    P(0, 0, 0), NXOpen.Section.Mode.Create, False)
        return h.CommitFeature()
    finally:
        h.Destroy()


try:
    # ================================================================ cell.prt, clip.prt
    cellp = nxh.new_part(os.path.join(OUT, "cell.prt"))
    nxh.expr(cellp, "cell_d", 18.4, "mm", "cell diameter")
    nxh.expr(cellp, "cell_len", 65.2, "mm", "cell length")
    nxh.expr(cellp, "btn_d", 6, "mm", "terminal button diameter")
    nxh.expr(cellp, "btn_h", 1.2, "mm", "terminal button height")
    _f, cellb = nxh.cylinder(cellp, ("-cell_len/2", 0, 0), (1, 0, 0), "cell_d", "cell_len")
    nxh.cylinder(cellp, ("cell_len/2", 0, 0), (1, 0, 0), "btn_d", "btn_h", nxh.BOOL.Unite, cellb)
    chk("cell volume", nxh.volume(cellp, cellb), pi * 9.2 ** 2 * 65.2 + pi * 9 * 1.2, 1e-3)
    bb = nxh.bbox(cellb)
    chk("cell bbox xmin", bb[0], -32.6, 1e-3)
    chk("cell bbox xmax (button)", bb[3], 33.8, 1e-3)
    nxh.save(cellp)

    clipp = nxh.new_part(os.path.join(OUT, "clip.prt"))
    for n, val in (("clip_w", 8), ("clip_l", 10), ("clip_t", 0.4), ("clip_hole_d", 3), ("clip_hole_off", 3)):
        nxh.expr(clipp, n, val)
    _f, clipb = nxh.block(clipp, (0, 0, 0), ("clip_w", "clip_l", "clip_t"))
    nxf.hole(clipp, clipb, [("clip_w/2", "clip_hole_off", "clip_t")], "clip_hole_d", vector=(0, 0, -1))
    chk("clip volume", nxh.volume(clipp, clipb), 8 * 10 * 0.4 - pi * 1.5 ** 2 * 0.4, 1e-4)
    chk.true("clip one solid", len(nxh.solids(clipp)) == 1)
    nxh.save(clipp)
    log("cell + clip built")

    # ================================================================ assembly
    assy = nxa.new_assembly(os.path.join(OUT, "dock_asm.prt"))
    for n, val, c in (("wall_t", 2.0, "cradle wall"), ("cell_gap", 0.6, "radial clearance"), ("end_gap", 1.0, "axial clearance"),
                      ("rib_t", 1.6, "rib thickness"), ("cell_z", 14, "cell axis height above the wall face")):
        nxh.expr(assy, n, val, "mm", c)
    nxh.save(assy)
    cz0 = assy.Expressions.FindObject("cell_z").Value
    cell = nxa.add_component(assy, os.path.join(OUT, "cell.prt"), "CELL", (0, 0, cz0))
    nxa.fix(assy, cell)
    chk.true("cell fixed, dof [0,0]", nxa.dof(cell) == [0, 0], nxa.dof(cell))
    dockc = nxa.new_component(assy, os.path.join(OUT, "dock.prt"), "DOCK")
    dp = nxa.set_work(dockc)
    res["work_part"] = dp.Leaf
    res["display_part"] = nxh.S.Parts.Display.Leaf
    log("assembly, work part", dp.Leaf)

    # ---------------- expressions in the dock
    for n in ("wall_t", "cell_gap", "end_gap", "rib_t", "cell_z"):
        nxa.interpart_expr(dp, n, assy)
    for n in ("cell_d", "cell_len", "btn_d", "btn_h"):
        nxa.interpart_expr(dp, n, cellp)
    for n in ("base_t", "flange", "wall_up", "slot_w", "hole_d", "cb_d", "cb_h", "hole_in", "r_long", "r_small"):
        nxh.expr(dp, n, NOM[n])
    nxh.expr(dp, "r_in", "cell_d/2+cell_gap")
    nxh.expr(dp, "r_out", "r_in+wall_t")
    nxh.expr(dp, "dock_len", "cell_len+2*(end_gap+wall_t)")
    E0, G0 = expected(NOM)
    dat = nxh.Datums(dp)
    cz, r_in, r_out, L, hw = G0["cz"], G0["r_in"], G0["r_out"], G0["L"], G0["hw"]

    # ---------------- linked cell geometry
    fA = nxh.faces(cellb, ftype=nxh.PLANE, normal=(-1, 0, 0))
    fB = nxh.faces(cellb, ftype=nxh.PLANE, normal=(1, 0, 0), at=(0, 32.6))
    chk.true("cell end faces found", len(fA) == 1 and len(fB) == 1, (len(fA), len(fB)))
    lfA, shA = nxa.wave_link(dp, nxa.occ(cell, fA[0]), "face")
    lfB, shB = nxa.wave_link(dp, nxa.occ(cell, fB[0]), "face")
    PA = nxa.arc_centre_points(dp, shA[0], radius=9.2)[0]
    PB = nxa.arc_centre_points(dp, shB[0], radius=9.2)[0]
    chk("linked point A x", PA.Coordinates.X, -32.6, 1e-6)
    chk("linked point A z (= cell_z)", PA.Coordinates.Z, 14.0, 1e-6)
    chk("linked point B x", PB.Coordinates.X, 32.6, 1e-6)
    faceA, faceB = shA[0].GetFaces()[0], shB[0].GetFaces()[0]

    def end_plane(face, want_sign, name):
        n = nxh.face_data(face)[2]
        f = "end_gap+wall_t" if n[0] * want_sign > 0 else "-(end_gap+wall_t)"
        _ft, dpl = nxf.datum_plane(dp, "offset", [face], f, name)
        return dpl, n
    DPA, nA = end_plane(faceA, -1, "DP_END_A")
    DPB, nB = end_plane(faceB, +1, "DP_END_B")
    res["linked_face_normals"] = [nA, nB]
    chk("datum plane A x (from linked face)", DPA.Origin.X, -L / 2, 1e-6)
    chk("datum plane B x (from linked face)", DPB.Origin.X, L / 2, 1e-6)
    xA = DPA.Origin.X

    # ---------------- sketch helpers (all sketches on DP_END_A)
    def rect_sketch(name, yh_f, yh, zlo_f, zlo, zhi_f, zhi):
        sk = nxf.new_sketch(dp, DPA, dat.y, dat.origin, name)
        ls = nxf.hv_polygon(dp, sk, [(-yh, zlo), (yh, zlo), (yh, zhi), (-yh, zhi)], to3d=lambda u, w: P(xA, u, w))
        if abs(zlo) < 1e-9:
            sk.CreatePointOnCurveConstraint(nxf.cg(ls[0], nxf.CP.StartVertex), nxf.cg(dat.y), nxf.help_at(P(xA, -yh, 0)))
        else:
            nxf.pdim(sk, dat.y, P(0, 50, 0), ls[0], nxf.A.StartPoint, P(xA, yh + 5, zlo), zlo_f)
        nxf.pdim(sk, dat.y, P(0, 50, 0), ls[2], nxf.A.StartPoint, P(xA, yh + 5, zhi), zhi_f)
        nxf.pdim(sk, dat.z, P(0, 0, 50), ls[1], nxf.A.StartPoint, P(xA, yh, zhi + 5), yh_f)
        nxf.pdim(sk, dat.z, P(0, 0, 50), ls[3], nxf.A.StartPoint, P(xA, -yh, zhi + 5), yh_f)
        r = nxf.finish_sketch(sk)
        chk.true(name + " WellConstrained DOF 0", r["status"] == "WellConstrained" and r["dof"] == 0, r)
        return sk, nxh.section_region(dp, sk, (xA, 0.0, (zlo + zhi) / 2))

    circle_mode = {}

    def circle_sketch(name, dia_f, rad):
        sk = nxf.new_sketch(dp, DPA, dat.y, dat.origin, name)
        c = dp.Curves.CreateArc(P(xA, 0, cz), V(0, 1, 0), V(0, 0, 1), float(rad), 0.0, 2 * pi)
        nxf.add(sk, c, infer=False)
        mode = "coincident with linked arc-centre point"
        try:
            sk.CreateCoincidentConstraint(nxf.cg(c, nxf.CP.ArcCenter), nxf.cg(PA))
        except Exception as e:  # noqa: BLE001
            mode = "datum axes + cell_z (coincident failed: %s)" % str(e)[:80]
        nxf.diameter_dim(sk, c, P(xA, rad, cz), P(xA, rad + 5, cz + 5), dia_f)
        sk.Update()
        st, dof = nxf.sketch_status(sk)
        if dof != 0:
            mode += " | dof %s -> added datum constraints" % dof
            sk.CreatePointOnCurveConstraint(nxf.cg(c, nxf.CP.ArcCenter), nxf.cg(dat.z), nxf.help_at(P(xA, 0, cz)))
            nxf.pdim(sk, dat.y, P(0, 50, 0), c, nxf.A.ArcCenter, P(xA, 5, cz / 2), "cell_z")
        r = nxf.finish_sketch(sk)
        circle_mode[name] = mode
        chk.true(name + " WellConstrained DOF 0", r["status"] == "WellConstrained" and r["dof"] == 0, r)
        return sk, nxh.section_region(dp, sk, (xA, 0.0, cz))

    state = {"v": 0.0}

    def step(name, key=None, tol=1e-3, body=None, want=None):
        v = nxh.volume(dp, body or BODY)
        got = v - state["v"]
        want = E0[key] if want is None else want
        ok = chk("feature %s: volume delta" % name, got, want, tol)
        res["features"].append({"feature": name, "delta": round(got, 5), "expected": round(want, 5), "ok": ok,
                                "solids": len(nxh.solids(dp))})
        log(name, round(got, 5), round(want, 5), ok)
        state["v"] = v
        return got

    # ---------------- features
    sk, sec = rect_sketch("SK_BASE", "r_out+flange", hw, "0", 0.0, "base_t", 3.0)
    f = nxh.extrude(dp, sec, (1, 0, 0), 0, "dock_len")
    BODY = f.GetBodies()[0]
    step("base plate (extrude)", "base")

    sk, sec = circle_sketch("SK_OUTER", "2*r_out", r_out)
    nxh.extrude(dp, sec, (1, 0, 0), 0, "dock_len", nxh.BOOL.Unite, BODY)
    step("outer cylinder (extrude unite)", "cyl")

    sk, sec = rect_sketch("SK_TOPCUT", "r_out+flange+2", hw + 2, "cell_z+wall_up", cz + 4, "cell_z+r_out+5", cz + r_out + 5)
    nxh.extrude(dp, sec, (1, 0, 0), "-1", "dock_len+1", nxh.BOOL.Subtract, BODY)
    step("top cut at axis + wall_up", "topcut")

    sk, sec = rect_sketch("SK_OPEN", "r_out+flange+2", hw + 2, "cell_z", cz, "cell_z+r_out+5", cz + r_out + 5)
    nxh.extrude(dp, sec, (1, 0, 0), "wall_t", "dock_len-wall_t", nxh.BOOL.Subtract, BODY)
    step("open top between end walls", "open")

    sk, sec = circle_sketch("SK_CAVITY", "2*r_in", r_in)
    nxh.extrude(dp, sec, (1, 0, 0), "wall_t", "dock_len-wall_t", nxh.BOOL.Subtract, BODY)
    step("cradle cavity r_in", "cavity")
    chk.true("one solid after cavity", len(nxh.solids(dp)) == 1, len(nxh.solids(dp)))

    nxa.cylinder_at_point(dp, PB, (1, 0, 0), "btn_d+2*cell_gap", "btn_h+end_gap", nxh.BOOL.Subtract, BODY)
    step("button relief on linked point B", "relief")

    sk, sec = circle_sketch("SK_SLOT_C", "slot_w", 1.6)
    nxh.extrude(dp, sec, (1, 0, 0), "-1", "dock_len+1", nxh.BOOL.Subtract, BODY)
    step("slot round bottom (both walls)", "slot_c")

    sk, sec = rect_sketch("SK_SLOT_R", "slot_w/2", 1.6, "cell_z", cz, "cell_z+wall_up+2", cz + 6)
    nxh.extrude(dp, sec, (1, 0, 0), "-1", "dock_len+1", nxh.BOOL.Subtract, BODY)
    step("slot straight part (both walls)", "slot_r")
    res["circle_sketch_mode"] = circle_mode

    # ribs: 4 gussets (2 planes x 2 sides)
    rib_info = []
    for xf in ("-dock_len/6", "dock_len/6"):
        for s in (1, -1):
            sg = "" if s > 0 else "-"
            info = {}
            a = (xf, "%s(r_out+flange/2)" % sg, "base_t")
            b = (xf, "%s(0.8660254*r_out)" % sg, "cell_z-0.5*r_out")
            toward = (xf, "%s(0.7*r_out)" % sg, "base_t+0.5")
            nxf.gusset_rib(dp, BODY, dat, (xf, 0, 0), (1, 0, 0), a, b, toward, "rib_t", info)
            rib_info.append([xf, s, info.get("status"), info.get("dof")])
    res["rib_sketches"] = rib_info
    chk.true("rib sketches DOF 0", all(r[3] == 0 for r in rib_info), rib_info)
    step("4 gusset ribs (Rib, parallel type)", "ribs")
    chk.true("one solid after ribs", len(nxh.solids(dp)) == 1)

    # holes
    hpts = [("-(cell_len/2+end_gap-hole_in)", 0, "cell_z-r_in"), ("cell_len/2+end_gap-hole_in", 0, "cell_z-r_in")]
    v_before = nxh.volume(dp, BODY)
    res["hole_expected_clean"] = E0["holes"]
    res["hole_expected_overhang"] = E0["holes_noext"]
    z_rim = "cell_z-sqrt(r_in^2-(cb_d/2)^2)"
    hpts_hi = [(hpts[0][0], 0, z_rim), (hpts[1][0], 0, z_rim)]
    ladder = [
        ("nxf.hole as shipped (cbore, vector -Z)", lambda: nxf.hole(dp, BODY, hpts, "hole_d", vector=(0, 0, -1), cbore=("cb_d", "cb_h"))),
        ("copy of nxf.hole, StartExtensionEnabled=True, vector -Z", lambda: hole_ext(dp, BODY, hpts, "hole_d", (0, 0, -1), ("cb_d", "cb_h"), True)),
        ("nxf.hole as shipped, vector=None (face normal)", lambda: nxf.hole(dp, BODY, hpts, "hole_d", cbore=("cb_d", "cb_h"))),
        ("copy of nxf.hole, StartExtension True, vector None", lambda: hole_ext2(dp, BODY, hpts, "hole_d", ("cb_d", "cb_h"), True)),
        ("nxf.hole simple through from the curved floor (diagnostic)", lambda: nxf.hole(dp, BODY, hpts, "hole_d", vector=(0, 0, -1))),
        ("nxf.hole cbore, points raised to the counterbore rim height", lambda: nxf.hole(dp, BODY, hpts_hi, "hole_d", vector=(0, 0, -1), cbore=("cb_d", "cb_h+r_in-sqrt(r_in^2-(cb_d/2)^2)"))),
    ]
    trials, hole_mode = [], None
    for label, fn in ladder:
        m = nxh.mark("hole trial")
        try:
            fn()
            dv = nxh.volume(dp, BODY) - v_before
            row = {"trial": label, "delta": dv, "clean": abs(dv - E0["holes"]) < 0.01, "overhang": abs(dv - E0["holes_noext"]) < 0.01,
                   "solids": len(nxh.solids(dp))}
        except Exception as e:  # noqa: BLE001
            row = {"trial": label, "error": str(e)[:200]}
        trials.append(row)
        log("hole trial", row)
        if row.get("clean") and "diagnostic" not in label:
            hole_mode = label
            break
        nxh.undo_to(m)
    res["hole_trials"] = trials
    if hole_mode is None:
        # fallback: counterbore = Cylinder subtract from the seat upwards, through hole = Hole feature from the flat wall face
        for xh in (hpts[0][0], hpts[1][0]):
            nxh.cylinder(dp, (xh, 0, "cell_z-r_in-cb_h"), (0, 0, 1), "cb_d", "r_in", nxh.BOOL.Subtract, BODY)
        nxf.hole(dp, BODY, [(hpts[0][0], 0, 0), (hpts[1][0], 0, 0)], "hole_d", vector=(0, 0, 1))
        hole_mode = "FALLBACK: Cylinder-subtract counterbores + nxf.hole simple through from the flat wall face (z=0, vector +Z)"
    res["hole_mode"] = hole_mode
    hole_key = "holes"
    step("2 counterbored mounting holes", hole_key, 0.01)
    chk.true("counterbored holes made with ONE HolePackage feature", not hole_mode.startswith("FALLBACK"), hole_mode)

    # blends, last
    def long_edges(z, yabs, xspan):
        return nxh.edges(BODY, lambda b_: abs(b_[2] - z) < 1e-3 and abs(b_[5] - z) < 1e-3 and abs(abs(b_[1]) - yabs) < 1e-3
                         and abs(abs(b_[4]) - yabs) < 1e-3 and abs((b_[3] - b_[0]) - xspan) < 1e-3)
    blends = {}
    for name, key, z, yabs, span, rad in (("blend R1 base long edges", "blend_long", 3.0, hw, L, "r_long"),
                                          ("blend R1 cradle rim outer edges", "blend_rim_out", cz, r_out, G0["Lin"], "r_long"),
                                          ("blend R0.5 cradle rim inner edges", "blend_rim_in", cz, r_in, G0["Lin"], "r_small")):
        ed = long_edges(z, yabs, span)
        blends[name] = {"edges": len(ed)}
        if len(ed) != 2:
            chk.true(name + ": 2 edges found", False, len(ed))
            continue
        _r, err = nxh.attempt(name, nxf.edge_blend, dp, [(ed, rad)], log=log)
        blends[name]["error"] = err
        if err is None:
            step(name, key, 0.02)
        else:
            chk.true(name, False, err)
    res["blends"] = blends

    for sh in (shA[0], shB[0]):
        sh.Blank()
    res["feature_errors_nominal"] = nxh.feature_errors(dp)
    chk.true("no feature errors (nominal)", not res["feature_errors_nominal"], res["feature_errors_nominal"])
    res["examine_nominal"] = nxh.examine_geometry(dp, BODY)
    chk.true("Examine Geometry clean", all(x == 0 for x in res["examine_nominal"].values()), res["examine_nominal"])
    res["feature_tree"] = [(r["ts"], r["name"]) for r in nxh.feature_table(dp)]
    V_NOM = nxh.volume(dp, BODY)
    res["dock_volume_nominal"] = V_NOM

    # ================================================================ clips with constraints
    def expr_val(n):
        return dp.Expressions.FindObject(n).Value

    def dock_refs(sign):
        xw = sign * expr_val("dock_len") / 2
        czv = expr_val("cell_z")
        outer = nxh.face_at(dp, BODY, (xw, 5.0, czv))
        slot = [f_ for f_ in nxh.faces(BODY, ftype=nxh.CYLINDER, radius=expr_val("slot_w") / 2)
                if (nxh.bbox(f_)[0] + nxh.bbox(f_)[3]) / 2 * sign > 0]
        side = nxh.faces(BODY, ftype=nxh.PLANE, normal=(0, 1, 0))
        return outer, slot, side
    REFS = {-1: dock_refs(-1), 1: dock_refs(1)}
    nxa.set_work(None)
    nxa.fix(assy, dockc)
    clip_path = os.path.join(OUT, "clip.prt")
    RA = [[0.0, 0.0, 1.0], [-1.0, 0.0, 0.0], [0.0, -1.0, 0.0]]      # columns: x_c=-Y, y_c=-Z, z_c=+X
    RB = [[0.0, 0.0, -1.0], [1.0, 0.0, 0.0], [0.0, -1.0, 0.0]]      # columns: x_c=+Y, y_c=-Z, z_c=-X
    clipA = nxa.add_component(assy, clip_path, "CLIP_A", (-L / 2 - 2.5, 5.0, cz + 4.5), RA)
    clipB = nxa.add_component(assy, clip_path, "CLIP_B", (L / 2 + 2.5, -5.0, cz + 4.5), RB)
    chk.true("free clip dof [3,3]", nxa.dof(clipA) == [3, 3], nxa.dof(clipA))
    c_top = nxh.faces(clipb, ftype=nxh.PLANE, normal=(0, 0, 1))[0]
    c_hole = nxh.faces(clipb, ftype=nxh.CYLINDER, radius=1.5)[0]
    c_side = nxh.faces(clipb, ftype=nxh.PLANE, normal=(1, 0, 0))[0]

    cons = {}
    for nm, comp, sign in (("A", clipA, -1), ("B", clipB, 1)):
        outer, slot, side = REFS[sign]
        chk.true("clip %s: dock references unique" % nm, len(outer) == 1 and len(slot) == 1 and len(side) >= 1,
                 (len(outer), len(slot), len(side)))
        c1 = nxa.touch(assy, (comp, c_top), (dockc, outer[0]), name="CLIP_%s_SEAT" % nm)
        d1 = nxa.dof(comp)
        c2 = nxa.center_axis(assy, (comp, c_hole), (dockc, slot[0]), name="CLIP_%s_AXIS" % nm)
        d2 = nxa.dof(comp)
        c3 = nxa.parallel(assy, (comp, c_side), (dockc, side[0]), name="CLIP_%s_SQUARE" % nm)
        d3 = nxa.dof(comp)
        cons[nm] = [c1, c2, c3]
        res["clip_%s_dof_after_each" % nm] = [d1, d2, d3]
        chk.true("clip %s dof after touch [1,2]" % nm, d1 == [1, 2], d1)
        chk.true("clip %s dof after touch + centre/axis [1,0]" % nm, d2 == [1, 0], d2)
        chk.true("clip %s dof after + parallel [0,0]" % nm, d3 == [0, 0], d3)
    log("clips constrained")

    # ================================================================ verification (used for nominal and regen)
    cs = nxa.clearance_set(assy, "DOCK_CLR", 0.0)

    def verify(tag, vals):
        E, G = expected(vals)
        out = {}
        r_in_, r_out_, L_, hw_, cz_ = G["r_in"], G["r_out"], G["L"], G["hw"], G["cz"]
        wt, eg = vals["wall_t"], vals["end_gap"]
        cl = vals["cell_len"]
        nxa.set_work(dockc)
        chk.true(tag + ": dock one solid", len(nxh.solids(dp)) == 1, len(nxh.solids(dp)))
        fe = nxh.feature_errors(dp)
        out["feature_errors"] = fe
        chk.true(tag + ": no feature errors", not fe, fe)
        keys = ["base", "cyl", "topcut", "open", "cavity", "relief", "slot_c", "slot_r", "ribs", hole_key] + \
               [k for n_, k in (("blend R1 base long edges", "blend_long"), ("blend R1 cradle rim outer edges", "blend_rim_out"),
                                ("blend R0.5 cradle rim inner edges", "blend_rim_in")) if blends.get(n_, {}).get("error", 1) is None]
        vexp = sum(E[k] for k in keys)
        vol = nxh.volume(dp, BODY)
        out["volume"], out["volume_expected"] = vol, vexp
        chk(tag + ": dock volume vs analytic sum", vol, vexp, 0.05)
        bb_ = nxh.bbox(BODY)
        out["bbox"] = bb_
        chk(tag + ": overall length = cell_len + 2(end_gap+wall_t)", bb_[3] - bb_[0], L_, 1e-3)
        chk(tag + ": xmin", bb_[0], -L_ / 2, 1e-3)
        chk(tag + ": base on wall face zmin", bb_[2], 0.0, 1e-3)
        chk(tag + ": top = axis + 4", bb_[5], cz_ + 4.0, 1e-3)
        chk(tag + ": half width", bb_[4], hw_, 1e-3)
        inner = nxh.faces(BODY, ftype=nxh.CYLINDER, radius=r_in_)
        outerc = nxh.faces(BODY, ftype=nxh.CYLINDER, radius=r_out_)
        chk.true(tag + ": cradle inner face radius r_in found", len(inner) >= 1, len(inner))
        if inner:
            pt = nxh.face_data(inner[0])[1]
            chk(tag + ": cradle axis y", pt[1], 0.0, 1e-6)
            chk(tag + ": cradle axis z", pt[2], cz_, 1e-6)
        if inner and outerc:
            chk(tag + ": cradle wall = wall_t", min(nxh.min_dist(i_, o_) for i_ in inner for o_ in outerc), wt, 1e-6)
        # ribs
        nrib = 0
        for xr in (-L_ / 6, L_ / 6):
            for off, nrm in ((vals["rib_t"] / 2, (1, 0, 0)), (-vals["rib_t"] / 2, (-1, 0, 0))):
                nrib += len(nxh.faces(BODY, ftype=nxh.PLANE, normal=nrm, at=(0, xr + off)))
        out["rib_side_faces"] = nrib
        chk.true(tag + ": 8 rib side faces at L/3, 2L/3 +- rib_t/2", nrib == 8, nrib)
        # holes
        hx = cl / 2 + eg - vals["hole_in"]
        hf = nxh.faces(BODY, ftype=nxh.CYLINDER, radius=vals["hole_d"] / 2)
        cbf = nxh.faces(BODY, ftype=nxh.CYLINDER, radius=vals["cb_d"] / 2)
        hxs = sorted(round(nxh.face_data(f_)[1][0], 6) for f_ in hf)
        out["hole_x"] = hxs
        chk.true(tag + ": 2 hole faces dia 4.2, >=2 cbore faces dia 8", len(hf) == 2 and len(cbf) >= 2, (len(hf), len(cbf)))
        if len(hxs) == 2:
            chk(tag + ": hole 1 x (12 inside end wall)", hxs[0], -hx, 1e-6)
            chk(tag + ": hole 2 x", hxs[1], hx, 1e-6)
            chk(tag + ": hole y on axis line", nxh.face_data(hf[0])[1][1], 0.0, 1e-6)
        # slots
        sf = nxh.faces(BODY, ftype=nxh.CYLINDER, radius=vals["slot_w"] / 2)
        chk.true(tag + ": 2 slot bottoms r 1.6", len(sf) == 2, len(sf))
        if sf:
            chk(tag + ": slot centre z = cell axis", nxh.face_data(sf[0])[1][2], cz_, 1e-6)
        # assembly clearances
        cyl_cell = nxh.faces(cellb, ftype=nxh.CYLINDER, radius=vals["cell_d"] / 2)
        cA = nxh.faces(cellb, ftype=nxh.PLANE, normal=(-1, 0, 0))
        cB = nxh.faces(cellb, ftype=nxh.PLANE, normal=(1, 0, 0), at=(0, cl / 2))
        tip = nxh.faces(cellb, ftype=nxh.PLANE, normal=(1, 0, 0), at=(0, cl / 2 + vals["btn_h"]))
        wA = nxh.face_at(dp, BODY, (-L_ / 2 + wt, 5.0, cz_ - 3.0))
        wB = nxh.face_at(dp, BODY, (L_ / 2 - wt, 5.0, cz_ - 3.0))
        rf = nxh.face_at(dp, BODY, (cl / 2 + vals["btn_h"] + eg, 2.5, cz_ - 2.5))
        nxa.set_work(None)
        chk.true(tag + ": clearance reference faces found", all(len(x) == 1 for x in (cyl_cell, cA, cB, tip, wA, wB, rf)),
                 [len(x) for x in (cyl_cell, cA, cB, tip, wA, wB, rf)])
        o = nxa.occ
        if inner and cyl_cell:
            rad = min(nxh.min_dist(o(cell, cyl_cell[0]), o(dockc, i_)) for i_ in inner)
            out["radial_clearance"] = rad
            chk(tag + ": radial clearance cell-cradle = cell_gap (assembly)", rad, vals["cell_gap"], 1e-6)
        if cA and wA:
            out["axial_A"] = nxh.min_dist(o(cell, cA[0]), o(dockc, wA[0]))
            chk(tag + ": axial clearance -X = end_gap", out["axial_A"], eg, 1e-6)
        if cB and wB:
            out["axial_B"] = nxh.min_dist(o(cell, cB[0]), o(dockc, wB[0]))
            chk(tag + ": axial clearance +X (cell end face) = end_gap", out["axial_B"], eg, 1e-6)
        if tip and rf:
            out["axial_button"] = nxh.min_dist(o(cell, tip[0]), o(dockc, rf[0]))
            chk(tag + ": axial clearance button tip - relief floor = end_gap", out["axial_button"], eg, 1e-6)
        out["min_dist_cell_dock"] = nxh.min_dist(o(cell, cellb), o(dockc, BODY))
        chk(tag + ": min distance cell body - dock body", out["min_dist_cell_dock"], min(vals["cell_gap"], eg), 1e-6)
        si = nxa.simple_interference(assy, o(cell, cellb), o(dockc, BODY))
        out["simple_interference_cell_dock"] = si
        chk.true(tag + ": cell/dock NoInterference", si[0] == "NoInterference", si)
        pairs = nxa.run_clearance(cs)
        out["clearance_pairs"] = pairs
        chk.true(tag + ": Clearance Analysis no Hard", all(p_["type"] != "Hard" for p_ in pairs), pairs)
        # clips
        for nm, comp, sign in (("A", clipA, -1), ("B", clipB, 1)):
            org, _r = nxa.frame(comp)
            want = (sign * (L_ / 2 + 0.4), -sign * 4.0, cz_ + 3.0)
            out["clip_%s_origin" % nm] = org
            for i_, ax in enumerate("xyz"):
                chk(tag + ": clip %s origin %s" % (nm, ax), org[i_], want[i_], 1e-6)
            hc = nxa.to_assy(comp, (4.0, 3.0, 0.2))
            chk(tag + ": clip %s hole centre on cell axis (y)" % nm, hc[1], 0.0, 1e-6)
            chk(tag + ": clip %s hole centre on cell axis (z)" % nm, hc[2], cz_, 1e-6)
            out["clip_%s_dof" % nm] = nxa.dof(comp)
            chk.true(tag + ": clip %s dof [0,0]" % nm, nxa.dof(comp) == [0, 0], nxa.dof(comp))
            sts = [nxa.status_name(c_) for c_ in cons[nm]]
            chk.true(tag + ": clip %s constraints Solved" % nm, all(s_ == "Solved" for s_ in sts), sts)
        org, _r = nxa.frame(cell)
        chk(tag + ": ground (cell) unmoved z", org[2], cz_, 1e-9)
        res[tag] = out
        log(tag, "volume", vol, "expected", vexp)
        return out

    verify("nominal", NOM)

    # ================================================================ regeneration: larger cell
    def set_cell(d_, l_):
        nxa.set_work(cell)
        nxh.set_expr(cellp, "cell_d", d_)
        nxh.set_expr(cellp, "cell_len", l_)
        nxh.update()
        nxa.set_work(None)
        nxh.update()

    BIG = dict(NOM, cell_d=21.5, cell_len=70.5)
    set_cell(21.5, 70.5)
    chk("regen: cell volume", nxh.volume(cellp, cellb), pi * 10.75 ** 2 * 70.5 + pi * 9 * 1.2, 1e-3)
    verify("big_cell", BIG)
    nxa.set_work(dockc)
    res["examine_big"] = nxh.examine_geometry(dp, BODY)
    nxa.set_work(None)
    chk.true("big cell: Examine Geometry clean", all(x == 0 for x in res["examine_big"].values()), res["examine_big"])
    set_cell(18.4, 65.2)
    nxa.set_work(dockc)
    v_back = nxh.volume(dp, BODY)
    nxa.set_work(None)
    res["dock_volume_restored"] = v_back
    chk("restore: nominal volume returns (rel 1e-6)", (v_back - V_NOM) / V_NOM, 0.0, 1e-6)
    verify("restored", NOM)

    # ================================================================ save + STEP
    nxh.save(assy)
    r1 = nxf.step_export(dp, os.path.join(OUT, "dock.stp"))
    rc = nxf.step_roundtrip_check(r1, OUT, "dock_step", restore=assy, part=dp)
    res["step_dock"] = {k: rc[k] for k in ("schema", "manifold_solid_brep", "solids", "volume", "max_rel", "match", "healthy",
                                           "restored", "blanked_skipped")}
    chk.true("dock STEP AP242 round trip", rc["schema"] == "AP242" and rc["match"] and rc["healthy"] and rc["solids"] == 1, res["step_dock"])
    ra = nxa.step_roundtrip(assy, os.path.join(OUT, "dock_asm.stp"), OUT, "dock_asm_step")
    res["step_asm"] = {k: ra[k] for k in ("schema", "assembly", "solids", "volume", "max_rel", "match", "healthy", "restored", "instances")}
    chk.true("assembly STEP AP242 round trip (4 instances)", ra["schema"] == "AP242" and ra["match"] and ra["healthy"]
             and len(ra["instances"]) == 4, res["step_asm"])
    nxa.set_work(None)
    nxh.save(assy)
    res["asm_expressions"] = {n: assy.Expressions.FindObject(n).Value for n in ("wall_t", "cell_gap", "end_gap", "rib_t", "cell_z")}
    res.update(chk.report())
except Exception:
    res["error"] = traceback.format_exc()
    res["checks"] = chk.rows
    res["result"] = "FAIL"
res["n_checks"] = len(chk.rows)
res["failed"] = [r for r in chk.rows if not r["ok"]]
nxh.write_json(os.path.join(OUT, "a_build.json"), res)
try:
    nxh.close_all()
except Exception:  # noqa: BLE001
    pass
