"""Job B run 1 - import the scan, describe it, auto-align with fitted planes, census of planes / cylinders."""
import math
import os
import sys
import time
import traceback

NXH = os.environ["NXH_DIR"]
sys.path.insert(0, NXH)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(NXH)), "nx-reverse-engineering", "scripts"))
import NXOpen
import nxh
import nxf
import nxre

OUT = sys.argv[1]
STL = sys.argv[2]
os.makedirs(OUT, exist_ok=True)
log = nxh.Log(os.path.join(OUT, "b_probe.log"))
res = {"result": "FAIL"}


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def unit(a):
    n = math.sqrt(dot(a, a)) or 1.0
    return (a[0] / n, a[1] / n, a[2] / n)


def tri_area(vs):
    u = [vs[1][i] - vs[0][i] for i in range(3)]
    v = [vs[2][i] - vs[0][i] for i in range(3)]
    c = cross(u, v)
    return 0.5 * math.sqrt(dot(c, c))


def facets(sc):
    """[(centroid, normal, area, row)]"""
    return [(r[1], r[2], tri_area(r[3]), r) for r in sc.rows]


def normal_clusters(fs, n_max=14, cos_tol=0.9962):          # 5 deg
    bins = {}
    for c, n, a, _r in fs:
        k = (round(n[0] * 20), round(n[1] * 20), round(n[2] * 20))
        bins[k] = bins.get(k, 0.0) + a
    used = [False] * len(fs)
    out = []
    order = sorted(bins.items(), key=lambda kv: -kv[1])
    for k, _a in order:
        if len(out) >= n_max:
            break
        seed = unit(k)
        if any(dot(seed, o["dir"]) > 0.996 for o in out):
            continue
        sx = sy = sz = area = 0.0
        idx = []
        for i, (c, n, a, _r) in enumerate(fs):
            if not used[i] and dot(n, seed) > cos_tol:
                sx += n[0] * a
                sy += n[1] * a
                sz += n[2] * a
                area += a
                idx.append(i)
        if area <= 0:
            continue
        for i in idx:
            used[i] = True
        out.append({"dir": unit((sx, sy, sz)), "area": area, "idx": idx})
    return out


def offset_peaks(fs, idx, d, win=0.3, n_max=10, min_area=3.0):
    h = {}
    for i in idx:
        s = dot(fs[i][0], d)
        k = round(s / 0.05)
        h[k] = h.get(k, 0.0) + fs[i][2]
    peaks = []
    taken = set()
    for k, _a in sorted(h.items(), key=lambda kv: -kv[1]):
        if k in taken or len(peaks) >= n_max:
            continue
        ks = [j for j in h if abs(j - k) * 0.05 <= win and j not in taken]
        area = sum(h[j] for j in ks)
        if area < min_area:
            continue
        off = sum(h[j] * j * 0.05 for j in ks) / area
        for j in ks:
            taken.add(j)
        peaks.append({"offset": off, "area": area})
    return peaks


def rot_axis_angle(R):
    tr = R[0][0] + R[1][1] + R[2][2]
    ang = math.acos(max(-1.0, min(1.0, (tr - 1) / 2)))
    ax = (R[2][1] - R[1][2], R[0][2] - R[2][0], R[1][0] - R[0][1])
    s = math.sqrt(dot(ax, ax))
    if s < 1e-9:
        if ang < 1e-6:
            return (0.0, 0.0, 1.0), 0.0
        # 180 deg: axis from the largest diagonal of (R + I)
        m = [[R[i][j] + (1.0 if i == j else 0.0) for j in range(3)] for i in range(3)]
        j = max(range(3), key=lambda q: m[q][q])
        return unit((m[0][j], m[1][j], m[2][j])), math.degrees(ang)
    return unit(ax), math.degrees(ang)


def kasa(pts2):
    """algebraic circle fit -> (cx, cy, r)"""
    n = len(pts2)
    sx = sum(p[0] for p in pts2) / n
    sy = sum(p[1] for p in pts2) / n
    suu = suv = svv = suuu = svvv = suvv = svuu = 0.0
    for x, y in pts2:
        u, v = x - sx, y - sy
        suu += u * u
        suv += u * v
        svv += v * v
        suuu += u * u * u
        svvv += v * v * v
        suvv += u * v * v
        svuu += v * u * u
    det = suu * svv - suv * suv
    if abs(det) < 1e-12:
        return None
    b1, b2 = 0.5 * (suuu + suvv), 0.5 * (svvv + svuu)
    uc = (b1 * svv - b2 * suv) / det
    vc = (b2 * suu - b1 * suv) / det
    return sx + uc, sy + vc, math.sqrt(uc * uc + vc * vc + (suu + svv) / n)


def cylinder_votes(fs, ax, plane_dirs, n_peaks=14):
    """cylinders with axis along principal axis ax (0/1/2) by centre voting"""
    u, v = [i for i in range(3) if i != ax]
    cand = []
    for c, n, a, _r in fs:
        if abs(n[ax]) > 0.12:
            continue
        if any(dot(n, d) > 0.985 for d in plane_dirs):
            continue
        ln = math.hypot(n[u], n[v])
        cand.append((c[u], c[v], c[ax], n[u] / ln, n[v] / ln, a))
    votes = {}
    for cu, cv, _w, nu, nv, a in cand:
        for ir in range(2, 121):                 # r 1.0 .. 60.0 step 0.5
            r = ir * 0.5
            for sg in (1, -1):                   # +1: boss (centre = c - r n), -1: hole (centre = c + r n)
                k = (round((cu - sg * r * nu) * 2), round((cv - sg * r * nv) * 2), ir, sg)
                votes[k] = votes.get(k, 0.0) + a
    peaks = []
    for k, a in sorted(votes.items(), key=lambda kv: -kv[1])[:400]:
        cu0, cv0, r0, sg = k[0] / 2.0, k[1] / 2.0, k[2] * 0.5, k[3]
        if any(abs(p["c"][0] - cu0) < 1.6 and abs(p["c"][1] - cv0) < 1.6 and abs(p["r"] - r0) < 1.6 and p["sign"] == sg for p in peaks):
            continue
        sup = []
        for cu, cv, w, nu, nv, ar in cand:
            du, dv = cu - cu0, cv - cv0
            dist = math.hypot(du, dv)
            if abs(dist - r0) < 0.6 and dist > 1e-6 and sg * (du * nu + dv * nv) / dist > 0.9:
                sup.append((cu, cv, w, ar))
        if len(sup) < 12:
            continue
        fit = kasa([(s_[0], s_[1]) for s_ in sup])
        if fit is None:
            continue
        sect = set(int((math.degrees(math.atan2(s_[1] - fit[1], s_[0] - fit[0])) % 360) // 10) for s_ in sup)
        area = sum(s_[3] for s_ in sup)
        ws = [s_[2] for s_ in sup]
        rms = math.sqrt(sum((math.hypot(s_[0] - fit[0], s_[1] - fit[1]) - fit[2]) ** 2 for s_ in sup) / len(sup))
        peaks.append({"c": [round(fit[0], 4), round(fit[1], 4)], "r": round(fit[2], 4), "sign": sg, "kind": "boss" if sg > 0 else "hole",
                      "area": round(area, 2), "n": len(sup), "axial": [round(min(ws), 3), round(max(ws), 3)],
                      "sectors36": len(sect), "rms_centroids": round(rms, 4),
                      "coverage": round(area / (2 * math.pi * fit[2] * max(1e-6, max(ws) - min(ws))), 3)})
        if len(peaks) >= n_peaks:
            break
    return {"n_candidates": len(cand), "peaks": peaks}


try:
    t0 = time.time()
    part = nxh.new_part(os.path.join(OUT, "b_probe.prt"))
    bodies = nxre.stl_import(part, STL)
    scan = bodies[0]
    d = {"bodies": len(bodies), "solid": scan.IsSolidBody, "convergent": scan.IsConvergentBody,
         "facets": scan.GetNumberOfFacets(), "bbox_raw": nxh.bbox(scan), "faces": len(scan.GetFaces()),
         "edges": len(scan.GetEdges()), "file_bytes": os.path.getsize(STL)}
    if scan.IsSolidBody:
        m = nxh.mass(part, [scan])
        d["volume"], d["area"], d["centroid_raw"] = m["volume"], m["area"], m["centroid"]
    res["describe"] = d
    log("imported", d)
    sc = nxre.Scan(part, scan)
    fs = facets(sc)
    log("cached", len(fs), time.time() - t0)
    edge_len = []
    for _c, _n, _a, r in fs[::50]:
        vs = r[3]
        edge_len.append(math.dist(vs[0], vs[1]))
    edge_len.sort()
    d["edge_len_median"] = edge_len[len(edge_len) // 2]
    d["mesh_area"] = sum(f[2] for f in fs)

    cl = normal_clusters(fs)
    raw = []
    for c in cl:
        pk = offset_peaks(fs, c["idx"], c["dir"])
        c["peaks"] = pk
        raw.append({"dir": [round(x, 5) for x in c["dir"]], "area": round(c["area"], 2),
                    "peaks": [{"offset": round(p["offset"], 4), "area": round(p["area"], 2)} for p in pk[:6]]})
    res["raw_normal_clusters"] = raw

    # primary datum = the largest single planar face; secondary = largest planar face square to it
    best = max(((c, p) for c in cl for p in c["peaks"]), key=lambda cp: cp[1]["area"])
    c1, p1 = best
    sec = [(c, p) for c in cl for p in c["peaks"] if abs(dot(c["dir"], c1["dir"])) < 0.05]
    c2, p2 = max(sec, key=lambda cp: cp[1]["area"])
    res["primary_raw"] = {"dir": c1["dir"], "offset": p1["offset"], "area": p1["area"]}
    res["secondary_raw"] = {"dir": c2["dir"], "offset": p2["offset"], "area": p2["area"]}

    def fit_plane(c, p, tag):
        rows = [fs[i][3] for i in c["idx"] if abs(dot(fs[i][0], c["dir"]) - p["offset"]) < 0.25]
        f = nxre.fit_surface(part, [nxre.rule_facets(part, rows)], "plane", reject=0.1)
        face, data = nxre.fit_face(f, nxh.PLANE)
        n = data["dir"]
        if dot(n, c["dir"]) < 0:
            n = [-x for x in n]
        dev = nxre.deviation(part, [face], [r[3][0] for r in rows[::max(1, len(rows) // 500)]])
        res["fit_" + tag] = {"n_facets": len(rows), "normal": n, "pt": data["pt"], "residual": dev,
                             "angle_to_cluster_deg": nxh.angle_deg(n, c["dir"])}
        return n, data["pt"], dev
    n1, pt1, dev1 = fit_plane(c1, p1, "primary")
    n2, pt2, dev2 = fit_plane(c2, p2, "secondary")
    res["angle_primary_secondary_deg"] = nxh.angle_deg(n1, n2)
    d1 = unit(n1)
    k = dot(n2, d1)
    d2 = unit([n2[i] - k * d1[i] for i in range(3)])
    d3 = cross(d1, d2)
    R = [[-d3[0], -d3[1], -d3[2]], [-d2[0], -d2[1], -d2[2]], [-d1[0], -d1[1], -d1[2]]]
    axis, ang = rot_axis_angle(R)
    res["rotation"] = {"R_rows": R, "axis": axis, "angle_deg": ang}
    log("rotation", axis, ang)
    if ang > 1e-4:
        nxf.move_object(part, [scan], "angle", ang, vec=axis, origin=(0, 0, 0))
    sc = nxre.Scan(part, scan)
    fs = facets(sc)
    # check the move really is R: seating normal must now be -Z
    cl = normal_clusters(fs)
    for c in cl:
        c["peaks"] = offset_peaks(fs, c["idx"], c["dir"])
    d["bbox_rotated"] = nxh.bbox(scan)
    al = []
    for c in cl:
        al.append({"dir": [round(x, 5) for x in c["dir"]], "area": round(c["area"], 2),
                   "peaks": [{"offset": round(p["offset"], 4), "area": round(p["area"], 2)} for p in c["peaks"][:8]]})
    res["aligned_normal_clusters"] = al

    # plane table with extents for principal directions
    planes = []
    for c in cl:
        dd = c["dir"]
        ax = max(range(3), key=lambda i: abs(dd[i]))
        principal = abs(dd[ax]) > 0.999
        for p in c["peaks"][:8]:
            idx = [i for i in c["idx"] if abs(dot(fs[i][0], dd) - p["offset"]) < 0.3]
            if not idx:
                continue
            ext = [[round(min(fs[i][0][q] for i in idx), 3), round(max(fs[i][0][q] for i in idx), 3)] for q in range(3)]
            sd = math.sqrt(sum((dot(fs[i][0], dd) - p["offset"]) ** 2 for i in idx) / len(idx))
            planes.append({"normal": [round(x, 5) for x in dd], "principal": principal, "offset": round(p["offset"], 4),
                           "area": round(p["area"], 2), "extent_xyz": ext, "sd_centroids": round(sd, 4), "n": len(idx)})
    res["planes_aligned"] = planes
    pdirs = [c["dir"] for c in cl if c["area"] > 20.0]
    res["cylinders"] = {}
    for ax, nm in ((2, "axis_Z"), (0, "axis_X"), (1, "axis_Y")):
        res["cylinders"][nm] = cylinder_votes(fs, ax, pdirs)
        log("cyl votes", nm, time.time() - t0)
    # area accounted for
    res["area_in_plane_peaks"] = sum(p["area"] for p in planes)
    res["time_s"] = time.time() - t0
    nxh.save(part)
    res["result"] = "PASS"
except Exception:
    res["error"] = traceback.format_exc()
nxh.write_json(os.path.join(OUT, "b_probe.json"), res)
