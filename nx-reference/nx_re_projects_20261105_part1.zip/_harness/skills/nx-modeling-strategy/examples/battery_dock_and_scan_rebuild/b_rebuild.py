"""Job B run 2 - datum check, fits, snapping, parametric rebuild, scan-to-CAD deviation, STEP."""
import math
import os
import sys
import time
import traceback

NXH = os.environ["NXH_DIR"]
sys.path.insert(0, NXH)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(NXH)), "nx-reverse-engineering", "scripts"))
import NXOpen
import nxh
import nxf
import nxre

OUT = sys.argv[1]
STL = sys.argv[2]
log = nxh.Log(os.path.join(OUT, "b_rebuild.log"))
res = {"result": "FAIL"}
chk = nxh.Check()
P = nxh.P
GRID, TOL = 0.5, 0.05


def hyp(c, i, j, ci, cj):
    return math.hypot(c[i] - ci, c[j] - cj)


def rms(v):
    return math.sqrt(sum(x * x for x in v) / max(1, len(v)))


def pct(v, q):
    s = sorted(v)
    return s[min(len(s) - 1, int(q * len(s)))]


# regions from the probe run census (run 1), raw scan frame; >= 1 mm from edges, hole mouths and the boss footprint excluded
PLANES = {
    # name: (axis index, approx position, predicate on the centroid, outward normal sign)
    "bottom (datum A)": (2, 0.0, lambda c: 1 < c[0] < 59 and 1 < c[1] < 39 and hyp(c, 0, 1, 26, 10) > 5.5 and hyp(c, 0, 1, 26, 30) > 5.5, -1),
    "wall outer (datum B)": (0, 0.0, lambda c: 1 < c[1] < 39 and 1 < c[2] < 39 and hyp(c, 1, 2, 20, 26) > 6.5, -1),
    "side y- (datum C)": (1, 0.0, lambda c: (1 < c[0] < 59 and 1 < c[2] < 7) or (1 < c[0] < 7 and 1 < c[2] < 39), -1),
    "side y+": (1, 40.0, lambda c: (1 < c[0] < 59 and 1 < c[2] < 7) or (1 < c[0] < 7 and 1 < c[2] < 39), 1),
    "base top": (2, 8.0, lambda c: 9.5 < c[0] < 59 and 1 < c[1] < 39 and hyp(c, 0, 1, 44, 20) > 11.5 and hyp(c, 0, 1, 26, 10) > 5.5
                 and hyp(c, 0, 1, 26, 30) > 5.5, 1),
    "wall inner": (0, 8.0, lambda c: 1 < c[1] < 39 and 9.5 < c[2] < 39 and hyp(c, 1, 2, 20, 26) > 6.5, 1),
    "end x+": (0, 60.0, lambda c: 1 < c[1] < 39 and 1 < c[2] < 7, 1),
    "wall top": (2, 40.0, lambda c: 1 < c[0] < 7 and 1 < c[1] < 39, 1),
    "boss top": (2, 18.0, lambda c: hyp(c, 0, 1, 44, 20) < 9, 1),
}
CYLS = {
    # name: (axis index, (centre on the two other axes), approx radius, axial range)
    "boss": (2, (44.0, 20.0), 10.0, (9.5, 17.0)),
    "hole 1": (2, (26.0, 10.0), 4.0, (1.0, 7.0)),
    "hole 2": (2, (26.0, 30.0), 4.0, (1.0, 7.0)),
    "wall hole": (0, (20.0, 26.0), 5.0, (1.0, 7.0)),
}

try:
    t0 = time.time()
    part = nxh.new_part(os.path.join(OUT, "scan_rebuild.prt"))
    scan = nxre.stl_import(part, STL)[0]
    res["scan"] = {"facets": scan.GetNumberOfFacets(), "solid": scan.IsSolidBody, "convergent": scan.IsConvergentBody,
                   "bbox": nxh.bbox(scan), "volume": nxh.volume(part, scan), "area": nxh.mass(part, [scan])["area"]}
    sc = nxre.Scan(part, scan)
    res["cache_s"] = time.time() - t0
    log("scan cached", len(sc.rows), res["cache_s"])

    # ---------------------------------------------------------------- plane fits
    table, val, regions = [], {}, {}
    for name, (k, pos, pred, sgn) in PLANES.items():
        rows = sc.pick(lambda c, n, k=k, pos=pos, pred=pred: abs(c[k] - pos) < 0.3 and pred(c))
        regions[name] = rows
        pts = [r[3][0] for r in rows[::max(1, len(rows) // 500)]]
        rule = [nxre.rule_facets(part, rows)]
        f_free = nxre.fit_surface(part, rule, "plane", reject=0.1)
        face, d = nxre.fit_face(f_free, nxh.PLANE)
        n = d["dir"]
        cu = [sum(p[i] for p in pts) / len(pts) for i in range(3)]
        free_pos = cu[k] + sum(n[i] * (d["pt"][i] - cu[i]) for i in range(3)) / n[k]
        ax = [0.0, 0.0, 0.0]
        ax[k] = 1.0
        tilt = min(nxh.angle_deg(n, ax), 180 - nxh.angle_deg(n, ax))
        dev_free = nxre.deviation(part, [face], pts)
        f_con = nxre.fit_surface(part, [nxre.rule_facets(part, rows)], "plane", reject=0.1, axis=tuple(ax))
        face_c, dc = nxre.fit_face(f_con, nxh.PLANE)
        con_pos = dc["pt"][k]
        snapped, ok = nxre.snap(con_pos, GRID, TOL)
        res_snap = [p[k] - snapped for p in pts]
        f_free.SetName("FIT_" + name.split(" (")[0].upper().replace(" ", "_"))
        for ft in (f_free, f_con):
            for b in ft.GetBodies():
                b.Blank()
        val[name] = snapped
        table.append({"feature": name, "kind": "plane " + "xyz"[k], "n_facets": len(rows), "fitted_free": round(free_pos, 4),
                      "tilt_deg": round(tilt, 4), "fitted_square": round(con_pos, 4), "snapped": snapped, "snap_ok": ok,
                      "fit_minus_snap": round(con_pos - snapped, 4), "rms_free_fit": round(dev_free["rms"], 4),
                      "max_free_fit": round(dev_free["max"], 4), "rms_snapped": round(rms(res_snap), 4),
                      "mean_snapped": round(sum(res_snap) / len(res_snap), 4), "max_snapped": round(max(abs(x) for x in res_snap), 4)})
        log(table[-1])

    # ---------------------------------------------------------------- cylinder fits
    for name, (k, (cu0, cv0), r0, (a0, a1)) in CYLS.items():
        u, v = [i for i in range(3) if i != k]
        rows = sc.pick(lambda c, n, k=k, u=u, v=v, cu0=cu0, cv0=cv0, r0=r0, a0=a0, a1=a1:
                       abs(math.hypot(c[u] - cu0, c[v] - cv0) - r0) < 0.3 and a0 < c[k] < a1)
        regions[name] = rows
        pts = [r[3][0] for r in rows[::max(1, len(rows) // 500)]]
        sect = len(set(int((math.degrees(math.atan2(p[v] - cv0, p[u] - cu0)) % 360) // 10) for p in pts))
        f_free = nxre.fit_surface(part, [nxre.rule_facets(part, rows)], "cylinder", reject=0.1)
        face, d = nxre.fit_face(f_free, nxh.CYLINDER)
        ax = [0.0, 0.0, 0.0]
        ax[k] = 1.0
        tilt = min(nxh.angle_deg(d["dir"], ax), 180 - nxh.angle_deg(d["dir"], ax))
        mid = (a0 + a1) / 2
        t = (mid - d["pt"][k]) / d["dir"][k]
        cfree = [d["pt"][i] + t * d["dir"][i] for i in range(3)]
        dev_free = nxre.deviation(part, [face], pts)
        r_snap, ok_r = nxre.snap(d["radius"], GRID, TOL)
        f_con = nxre.fit_surface(part, [nxre.rule_facets(part, rows)], "cylinder", reject=0.1, radius=r_snap, axis=tuple(ax))
        face_c, dc = nxre.fit_face(f_con, nxh.CYLINDER)
        dev_con = nxre.deviation(part, [face_c], pts)
        cu_s, ok_u = nxre.snap(dc["pt"][u], GRID, TOL)
        cv_s, ok_v = nxre.snap(dc["pt"][v], GRID, TOL)
        res_snap = [math.hypot(p[u] - cu_s, p[v] - cv_s) - r_snap for p in pts]
        f_free.SetName("FIT_" + name.upper().replace(" ", "_"))
        for ft in (f_free, f_con):
            for b in ft.GetBodies():
                b.Blank()
        val[name] = {"r": r_snap, "u": cu_s, "v": cv_s}
        common = {"n_facets": len(rows), "sectors36": sect, "tilt_deg": round(tilt, 4), "rms_free_fit": round(dev_free["rms"], 4),
                  "max_free_fit": round(dev_free["max"], 4), "rms_fixed_radius_axis_fit": round(dev_con["rms"], 4),
                  "rms_snapped": round(rms(res_snap), 4), "mean_snapped": round(sum(res_snap) / len(res_snap), 4),
                  "max_snapped": round(max(abs(x) for x in res_snap), 4)}
        table.append(dict({"feature": name + " radius", "kind": "cylinder axis " + "xyz"[k], "fitted_free": round(d["radius"], 4),
                           "snapped": r_snap, "snap_ok": ok_r, "fit_minus_snap": round(d["radius"] - r_snap, 4)}, **common))
        for lab, i_, sv, ok_ in (("xyz"[u], u, cu_s, ok_u), ("xyz"[v], v, cv_s, ok_v)):
            table.append({"feature": "%s centre %s" % (name, lab), "kind": "axis position", "fitted_free": round(cfree[i_], 4),
                          "fitted_square": round(dc["pt"][i_], 4), "snapped": sv, "snap_ok": ok_,
                          "fit_minus_snap": round(dc["pt"][i_] - sv, 4)})
        log(name, d["radius"], cfree, dc["pt"])
    res["fit_table"] = table
    res["fit_s"] = time.time() - t0
    chk.true("every fitted value snapped to the 0.5 grid within 0.05", all(r["snap_ok"] for r in table),
             [r["feature"] for r in table if not r["snap_ok"]])

    # ---------------------------------------------------------------- datum frame decision
    A, B, C = table[0], table[1], table[2]
    res["datum_decision"] = {
        "A bottom": {"position": A["fitted_free"], "tilt_deg": A["tilt_deg"]},
        "B wall outer": {"position": B["fitted_free"], "tilt_deg": B["tilt_deg"]},
        "C side y-": {"position": C["fitted_free"], "tilt_deg": C["tilt_deg"]},
        "rule": "no Move Object when the three fitted datum planes are within 0.01 mm of the absolute planes and within 0.02 deg",
    }
    aligned = all(abs(r["fitted_free"]) < 0.01 and r["tilt_deg"] < 0.02 for r in (A, B, C))
    res["datum_decision"]["already_in_datum_frame"] = aligned
    chk.true("scan already in a datum frame (3 fitted datum planes on the absolute planes)", aligned, res["datum_decision"])
    if not aligned:
        raise RuntimeError("scan not aligned - alignment branch needed")

    # ---------------------------------------------------------------- design values -> named expressions
    x0, y0, z0 = val["wall outer (datum B)"], val["side y- (datum C)"], val["bottom (datum A)"]
    design = {
        "re_len": val["end x+"] - x0, "re_wid": val["side y+"] - y0, "re_base_t": val["base top"] - z0,
        "re_wall_t": val["wall inner"] - x0, "re_wall_h": val["wall top"] - z0, "re_boss_h": val["boss top"] - val["base top"],
        "re_boss_d": 2 * val["boss"]["r"], "re_boss_x": val["boss"]["u"] - x0, "re_boss_y": val["boss"]["v"] - y0,
        "re_hole_d": 2 * val["hole 1"]["r"], "re_hole_x": val["hole 1"]["u"] - x0, "re_hole_y1": val["hole 1"]["v"] - y0,
        "re_hole_y2": val["hole 2"]["v"] - y0, "re_wall_hole_d": 2 * val["wall hole"]["r"],
        "re_wall_hole_y": val["wall hole"]["u"] - y0, "re_wall_hole_z": val["wall hole"]["v"] - z0,
    }
    res["design_values"] = design
    res["hole_pattern_note"] = {"hole2_x_fit": val["hole 2"]["u"], "hole1_x_fit": val["hole 1"]["u"],
                                "hole2_d": 2 * val["hole 2"]["r"]}
    chk.true("holes 1 and 2 share x and diameter (one pattern)", val["hole 1"]["u"] == val["hole 2"]["u"]
             and val["hole 1"]["r"] == val["hole 2"]["r"], res["hole_pattern_note"])
    for n, v in design.items():
        nxh.expr(part, n, v, "mm", "recovered from scan fit, snapped to %.1f grid" % GRID)

    # ---------------------------------------------------------------- rebuild (constrained sketch + features)
    dat = nxh.Datums(part)
    L_, T_, WT, WH = design["re_len"], design["re_base_t"], design["re_wall_t"], design["re_wall_h"]
    sk = nxf.new_sketch(part, dat.xz, dat.x, dat.origin, "SK_L_PROFILE")
    ls = nxf.hv_polygon(part, sk, [(0, 0), (L_, 0), (L_, T_), (WT, T_), (WT, WH), (0, WH)], to3d=lambda u, w: P(u, 0, w))
    sk.CreateCoincidentConstraint(nxf.cg(ls[0], nxf.CP.StartVertex), nxf.cg(dat.origin))
    nxf.pdim(sk, dat.z, P(0, 0, 50), ls[1], nxf.A.StartPoint, P(L_ + 5, 0, T_ / 2), "re_len")
    nxf.pdim(sk, dat.x, P(50, 0, 0), ls[2], nxf.A.StartPoint, P(L_ / 2, 0, T_ + 5), "re_base_t")
    nxf.pdim(sk, dat.z, P(0, 0, 50), ls[3], nxf.A.StartPoint, P(WT + 5, 0, WH / 2), "re_wall_t")
    nxf.pdim(sk, dat.x, P(50, 0, 0), ls[4], nxf.A.StartPoint, P(WT / 2, 0, WH + 5), "re_wall_h")
    st = nxf.finish_sketch(sk)
    res["sketch"] = st
    chk.true("L-profile sketch WellConstrained, DOF 0", st["status"] == "WellConstrained" and st["dof"] == 0, st)
    f = nxh.extrude(part, nxh.section_region(part, sk, (WT / 2, 0.0, T_ / 2)), (0, 1, 0), 0, "re_wid")
    solid = f.GetBodies()[0]
    v1 = nxh.volume(part, solid)
    bb = nxh.bbox(solid)
    chk("L extrude volume", v1, (L_ * T_ + WT * (WH - T_)) * design["re_wid"], 1e-3)
    chk("L extrude on +Y side (ymax)", bb[4], design["re_wid"], 1e-6)
    nxh.cylinder(part, ("re_boss_x", "re_boss_y", "re_base_t"), (0, 0, 1), "re_boss_d", "re_boss_h", nxh.BOOL.Unite, solid)
    v2 = nxh.volume(part, solid)
    chk("boss volume delta", v2 - v1, math.pi * (design["re_boss_d"] / 2) ** 2 * design["re_boss_h"], 1e-3)
    nxf.hole(part, solid, [("re_hole_x", "re_hole_y1", "re_base_t"), ("re_hole_x", "re_hole_y2", "re_base_t")], "re_hole_d",
             vector=(0, 0, -1))
    v3 = nxh.volume(part, solid)
    chk("2 base holes volume delta", v3 - v2, -2 * math.pi * (design["re_hole_d"] / 2) ** 2 * T_, 1e-3)
    nxf.hole(part, solid, [(0, "re_wall_hole_y", "re_wall_hole_z")], "re_wall_hole_d", vector=(1, 0, 0))
    v4 = nxh.volume(part, solid)
    chk("wall hole volume delta", v4 - v3, -math.pi * (design["re_wall_hole_d"] / 2) ** 2 * WT, 1e-3)
    chk.true("one rebuilt solid (+ the scan)", len(nxh.solids(part)) == 2, len(nxh.solids(part)))
    res["cad"] = {"volume": v4, "area": nxh.mass(part, [solid])["area"], "bbox": nxh.bbox(solid), "faces": nxh.face_census(solid)}
    res["volume_scan_vs_cad_rel"] = (res["scan"]["volume"] - v4) / v4
    res["area_scan_vs_cad_rel"] = (res["scan"]["area"] - res["cad"]["area"]) / res["cad"]["area"]
    chk("scan volume vs CAD volume (relative)", res["volume_scan_vs_cad_rel"], 0.0, 3e-4)
    fe = nxh.feature_errors(part)
    res["feature_errors"] = fe
    chk.true("no feature errors", not fe, fe)
    res["examine"] = nxh.examine_geometry(part, solid)
    chk.true("Examine Geometry clean", all(x == 0 for x in res["examine"].values()), res["examine"])

    # ---------------------------------------------------------------- scan -> CAD deviation (signed)
    def deviation(tag):
        pts = sc.vertices(n=3000)
        ds = [nxh.dist_to(part, solid, p) for p in pts]
        ab = [abs(x) for x in ds]
        worst = max(range(len(ds)), key=lambda i: ab[i])
        out = {"n": len(ds), "signed_min": min(ds), "signed_max": max(ds), "signed_mean": sum(ds) / len(ds), "rms": rms(ds),
               "abs_max": max(ab), "p50": pct(ab, 0.5), "p95": pct(ab, 0.95), "p99": pct(ab, 0.99),
               "worst_point": [round(x, 3) for x in pts[worst]], "frac_over_3sigma_0.06": sum(1 for x in ab if x > 0.06) / len(ab)}
        per = {}
        for name, rows in regions.items():
            rp = [r[3][0] for r in rows[::max(1, len(rows) // 150)]]
            s = nxre.signed_deviation(part, solid, rp)
            per[name] = {"n": s["n"], "signed_mean": round(s["mean"], 4), "rms": round(s["rms"], 4), "min": round(s["min"], 4),
                         "max": round(s["max"], 4)}
        out["per_feature"] = per
        res["deviation_" + tag] = out
        log("deviation", tag, {k: v for k, v in out.items() if k != "per_feature"})
        return out
    d1 = deviation("first_rebuild")
    noise = d1["rms"]
    off = {n: s for n, s in d1["per_feature"].items() if abs(s["signed_mean"]) > 0.015}
    res["features_flagged_off"] = off
    res["iteration"] = "not needed: no feature with |signed mean| > 0.015 mm" if not off else "see deviation_iterated"
    if off:
        # iterate once: the flagged faces take their fitted (unsnapped, 0.01) values
        fitted = {r["feature"]: r for r in table}
        changes = {}
        amap = {"base top": ("re_base_t", lambda p: p - z0), "boss top": ("re_boss_h", lambda p: p - val["base top"]),
                "wall inner": ("re_wall_t", lambda p: p - x0), "end x+": ("re_len", lambda p: p - x0),
                "wall top": ("re_wall_h", lambda p: p - z0), "side y+": ("re_wid", lambda p: p - y0)}
        for n in off:
            if n in amap:
                en, fn = amap[n]
                changes[en] = round(fn(fitted[n]["fitted_square"]), 2)
        res["iteration_changes"] = changes
        for en, v in changes.items():
            nxh.set_expr(part, en, v)
        nxh.update()
        d2 = deviation("iterated")
        better = d2["rms"] < d1["rms"] - 0.0005
        res["iteration"] = "kept" if better else "reverted (no improvement: rms %.4f -> %.4f)" % (d1["rms"], d2["rms"])
        if not better:
            for en in changes:
                nxh.set_expr(part, en, design[en])
            nxh.update()
    dfin = res.get("deviation_iterated") if res["iteration"] == "kept" else d1
    chk("deviation: signed mean ~ 0", dfin["signed_mean"], 0.0, 0.01)
    chk.true("deviation: p95 < 3 x rms", dfin["p95"] < 3 * dfin["rms"], (dfin["p95"], dfin["rms"]))
    chk.true("deviation: max < 0.15 mm", dfin["abs_max"] < 0.15, dfin["abs_max"])

    # ---------------------------------------------------------------- parametric proof, deliverables
    v_nom = nxh.volume(part, solid)
    nxh.set_expr(part, "re_boss_d", design["re_boss_d"] + 4)
    nxh.update()
    r_now, h_now = design["re_boss_d"] / 2, part.Expressions.FindObject("re_boss_h").Value
    chk("regen: re_boss_d +4 volume delta", nxh.volume(part, solid) - v_nom, math.pi * ((r_now + 2) ** 2 - r_now ** 2) * h_now, 1e-3)
    nxh.set_expr(part, "re_boss_d", design["re_boss_d"])
    nxh.update()
    chk("regen: nominal volume returns (rel)", (nxh.volume(part, solid) - v_nom) / v_nom, 0.0, 1e-6)
    chk.true("no feature errors after regen", not nxh.feature_errors(part))
    scan.Blank()
    res["feature_tree"] = [(r["ts"], r["name"]) for r in nxh.feature_table(part)]
    stp = nxf.step_export(part, os.path.join(OUT, "scan_rebuild.stp"))
    rc = nxf.step_roundtrip_check(stp, OUT, "scan_rebuild_step", restore=part, part=part)
    res["step"] = {k: rc[k] for k in ("schema", "manifold_solid_brep", "solids", "volume", "max_rel", "match", "healthy", "restored",
                                      "blanked_skipped", "bbox")}
    chk.true("STEP AP242 round trip: 1 solid, volume match, healthy", rc["schema"] == "AP242" and rc["solids"] == 1 and rc["match"]
             and rc["healthy"], res["step"])
    nxh.save(part)
    res["time_s"] = time.time() - t0
    res.update(chk.report())
except Exception:
    res["error"] = traceback.format_exc()
    res["checks"] = chk.rows
    res["result"] = "FAIL"
res["failed"] = [r for r in chk.rows if not r["ok"]]
res["n_checks"] = len(chk.rows)
nxh.write_json(os.path.join(OUT, "b_rebuild.json"), res)
