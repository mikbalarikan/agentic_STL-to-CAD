# The instructor's method (6-day NX CAD course, condensed)

Source: 26 screen recordings (about 22 h; Turkish narration transcribed with Whisper, frames
sampled every 30 s plus targeted full-resolution captures; two recordings have no audio and
were read from frames). The instructor's NX is 2212 on the days where the version is visible
(day 1 shows it in Help > About; the sketch day uses the 2212 sketch solver); the user's machine
has NX 2206, so a few dialog options have no 2206 counterpart (noted in the family skills).
The course folder contains videos only - no exercise part files. References are
`CADd.n hh:mm` = day.video, time. `[said]` = stated, `[shown]` = done consistently.
Detailed tool cards per command are in each family skill's `references/course-notes.md`; the
full notes are kept in `C:\NX_MCP_WORKSPACE\nx_course\notes\`.

Course map: day 1 interface, files, coordinate systems - day 2 sketch - day 3 solid features -
day 4 imported data repair and synchronous modelling - day 5 curves and surfaces - day 6 assemblies.

## General working method
- **Reset every dialog before using it**; dialogs remember the last type and values `[shown, every command]`.
  For a journal this means: set every option explicitly, never rely on a builder default.
- **Read what NX inferred before accepting**: the Boolean "Inferred" label, the curve rule, the
  preview's open-section markers, the status line `[shown CAD3.1]`. A journal sets these explicitly.
- **Check before OK**: Show Result / Undo Result, body count via the Solid Body / Sheet Body type
  filter, wireframe or section view for inner geometry `[shown CAD3.3-3.4]`.
- **Never experiment on the master body**: Extract Geometry > Body with Hide Original, work on
  the copy `[said CAD3.5]`. (Journal equivalent: undo marks and `nxh.attempt`.)
- **Undo immediately on a wrong step** rather than patching it with more features `[said CAD3.4 00:22]`.
- Start files from the Model template; ASCII file names without spaces; Import (not Open) for
  STEP / Parasolid / IGES; work fully loaded; save often - NX has no autosave `[said CAD1.1-1.2]`.
- Absolute CSYS is fixed and invisible; the WCS is movable and many dialogs default to it; Datum
  CSYS features are what you create and reference `[said CAD1.2, CAD4.3]`.
- **A feature only sees what is above it in the timestamp order**: an associative mass
  measurement ignored a later Chamfer until it was dragged below it `[shown CAD1.5]`. Suppress
  (not Hide) to take a feature out; hiding one feature of a body hides the body `[said CAD1.3]`.
- Datum planes are the foundation of most models: try Inferred, use Bisector of two parallel
  faces for a symmetry plane, check the plane normal before sketching on it, never build on a
  View Plane; datum axes are rarely needed - edges and cylinder axes serve `[said CAD1.4]`.
- Bring an imported body onto the absolute origin before working on it: Datum CSYS on a corner
  (origin, X point, Y point), then Move Object CSYS-to-CSYS to Absolute `[said CAD1.5, CAD4.3]`.
- Measuring: a body without a material measures as steel (7.83e-6 kg/mm3), so assign a material
  before quoting mass; a sheet body returns no volume - a quick solid-or-sheet test; the bounding
  box measurement gives the stock size `[said CAD1.5]`.
- When a pick fails, check the Type Filter and the Selection Scope first (inside a sketch the
  scope is "Within Active Sketch Only") `[said CAD1.4]`.

## Sketching (day 2)
- Keep sketch X aligned with the model X (CAM zero-setting later) `[said CAD2.1 00:06]`.
- If the sketch location may change, put a **datum plane** there and sketch on it; a sketch
  directly on a face leaves no editable reference `[said CAD2.1 00:12]`. Mid-planes come from
  Datum Plane > Inferred / Bisector of two faces, not from typed offsets `[shown CAD3.4]`.
- Choose the sketch origin deliberately (face corner vs centre via Between Two Points) `[said CAD2.1 00:04]`.
- **Do not go to the solid before the status line says "Sketch is fully defined"** `[said CAD2.4 00:30]`.
  Judge by the status line, not by colour.
- Order: locate the profile from the sketch origin, then size it, then drag to find what still
  moves and close that freedom `[shown CAD2.4 00:31]`.
- Relations are directional: first pick moves, second stays. Constrain (length, angle) before
  relating, or geometry deforms instead of moving `[said CAD2.4 00:11]`.
- Tangent is not coincident; Equal Length does not fix direction `[said CAD2.4 00:21, 00:25]`.
- Reference existing 3D geometry with Project Curve / Intersection Curve / Intersection Point
  instead of re-measuring it `[said CAD2.3 00:43]`.
- Profile for connected outlines; a tangent arc between circles is a sketch Fillet; circular
  patterns by count + 360 span; pattern count includes the seed `[said CAD2.1-2.2]`.
- Choose the Curve Rule before picking a section: Infer Curves on crossing lines gave four
  sheets, Single Curve + Stop at Intersection gave the intended closed loop `[shown CAD3.1 00:05]`.

## Solid features (day 3)
- Closed section = solid, open section = sheet; a thin wall from an open curve uses the Offset
  group; Body Type = Sheet forces walls only `[shown CAD3.1 00:40]`.
- Geometry-referencing limits (Until Next / Until Selected / Until Extended) once a body exists;
  if Until Selected fails use Until Extended `[shown CAD3.1 00:23]`.
- Holes with the Hole command, several points in one feature, positions from sketch dimensions;
  Depth To Shoulder vs Tip `[shown CAD3.2]`. A threaded hole is symbolic; real helices need a
  Detailed Thread.
- "No sketches today": primitives with their built-in Boolean for simple cuts and bosses; an L or
  thin-wall profile from Block -> Shell `[said CAD3.3 00:29, CAD3.4 00:42]`.
- Any dialog with a List + Add New Set takes different values per selection in one feature
  (blend radii, chamfers, draft angles, shell alternate thickness) `[said CAD3.3]`.
- A draft needs a stationary face or edge: vector -> stationary reference -> faces -> angle.
  Draft tilts from one fixed face; Draft Body tilts both sides about a parting plane `[said CAD3.3 00:23, CAD3.4 00:48]`.
- Trim Body when one side is scrap; Split Body + Delete Body when both pieces matter `[said CAD3.4 00:21]`.
- Rib sections must be sketch curves on a real datum plane `[said CAD3.4 00:51]`.
- Patterns: reference point independent of the seed; point layouts by sketch points + General;
  pattern anyway and edit the odd instance `[said CAD3.3]`. Mirror what belongs together in one
  Mirror Feature `[said CAD3.4 00:05]`.
- Solid blends: G1 + Circular; full round = Face Blend three-face `[said CAD3.3]`.
- **No feature-order rule is stated anywhere in the course** (no "draft before shell", no "blends
  last"); the order in `SKILL.md` section 3 rests on the user's parts and on verified behaviour.

## Imported data and synchronous modelling (day 4)
- Every import: Optimize Face once, check solid vs sheet, Examine Geometry on the body with the
  matching filter, patch leaks (extrude the open edge as a sheet, Sew) `[said CAD4.1]`.
- Mould makers strip parameters routinely; do not do that in part design `[said CAD4.1]`.
- "Synchronous commands are accelerators, not new capability" - first ask which known command
  would do the job `[said CAD4.3]`.
- Move relocates with one vector; Offset moves each face along its own normal and is the robust
  choice for growing or sinking faces `[said CAD4.1-4.2]`.
- Use the resize tool that matches what NX recognises (blend, hole, chamfer, other cylinder);
  label an unrecognised fillet (Label Notch Blend) before Resize Blend `[said CAD4.2]`.
- Delete Face with Heal = "restore"; select every face of a multi-face feature `[said CAD4.2]`.
- Relate commands: motion face changes, stationary face is the reference; add Through Point at
  the vertex that must stay `[said CAD4.3]`. Type a target with Linear / Angular / Radial
  Dimension instead of computing a delta (not available headless on 2206 - compute the delta).
- Synchronous edits silently swallow features in the way; check the result `[shown CAD4.3]`.
- Replace Face is the shortest way to conform a face to any face or sheet, with an offset `[said CAD4.2]`.

## Curves and surfaces (day 5)
- Fix the spline's drawing plane; degree n needs n + 1 points; never place 3D curve points in
  empty space (axis snap or Support Plane) `[said CAD5.1-5.2]`.
- A curve that must lie on a freeform face is a Curve on Surface; projection = what, onto what,
  along which direction; a 3D curve from two views = Combined Projection `[said CAD5.2]`.
- Join a multi-curve profile into one curve (Composite Curve, Join = Cubic, Hide Original) so the
  wall is one face - several faces show as tool marks `[said CAD5.1]`.
- Higher continuity is not automatically better; set it per end `[said CAD5.1]`.
- Section arrows and start points must correspond; select whole sections with Connected Curves;
  cure a creased loft with Alignment: Parameter -> Arc Length -> By Points `[said CAD5.4]`.
- Capability ladder Ruled (G0 only) -> Through Curves -> Through Curve Mesh: "the more you tie to
  the neighbours, the better the surface". G1/G2 needs an existing face, so build the reference
  patches first; only the first and last section of Through Curves can be constrained `[said CAD5.4]`.
- Never judge a surface by eye: Reflection analysis, look for broken lines at patch edges `[said CAD5.4]`.
- Tangent is not joined: Sew; a closed sewn set becomes a solid. Sheet to solid: Bounded Plane on
  each opening + Sew, or Thicken, or Fill Surface with Patch into Part `[said CAD5.4-5.6]`.
- Swept sections are sketched normal to the guide (Sketch On Path at 0 %); Swept fails on
  sharp-cornered guides - use Sweep Along Guide `[said CAD5.5]`.
- A closed hole next to faces: Fill Surface (G1 per edge), not N-Sided; Bounded Plane for flat caps `[said CAD5.5]`.
- Two sheets that must meet: Extend Sheet then Trim Sheet each with the other, or Trim and
  Extend > Make Corner with the free EDGES as target `[said CAD5.6]`.
- Face Blend builds in the quadrant where the two face arrows meet; it also joins two disjoint
  bodies `[said CAD5.6]`.

## Where the course and the user's own practice differ
| Topic | Course | User's parts | Rule for Claude |
|---|---|---|---|
| Sketch definition | fully defined before the solid | 63 % under-constrained, 68 % without dimensions | fully constrain what Claude creates; do not rework the user's sketches |
| Copies | Mirror Feature / Pattern Feature | Mirror Geometry 335 vs 28; Pattern Geometry 97 vs 35 | copy bodies (finish the half first) unless a hole pattern must stay a hole feature |
| Resizing holes | Resize Hole | Resize Face 199 vs 1 | either; both verified |
| Target values | Linear / Radial / Angular Dimension | delta arithmetic typed into Offset Region | measure, compute the delta, drive it by an expression |
| Removing parameters | not in part design | 2 142 of 4 153 files have none | never remove parameters from a model Claude delivers unless asked |
| Primitives | preferred for simple shapes | Cylinder 346, Block 17; sketches 2 809 | primitives for tool bodies, sketches for design-critical profiles |
| Synchronous edits | accelerators on dumb bodies | also used inside native trees (86 % of Offset Regions have a parametric parent) | follow the user: sync edits are a normal design tool |
