# Siemens' worked project parts as modelling plans

Source: the two project courses of the NX CAST 8.5 library (`[cast efmq]` Modeling projects, `[cast eesc]`
Create a model from scratch), rewritten as plans in the format of SKILL.md section 0. Own words; values are the
ones the activities type. NX 8.5 menus and the old sketch solver are not adopted - only the order, the
references and the intent. "Verified" = built and measured on NX 2206 in these skills; the others are plans to
read, not measured builds.

What all five have in common:
- The Datum CSYS of the template is the first feature; the base sketch lies on one of its planes and is tied
  to its origin; later sketches use another plane of the SAME CSYS. Nothing is positioned from the WCS.
- The design intent is written first as a list of what must be variable; exactly those become drivers; the
  build ends by editing each of them once.
- Booleans are made inside the Extrude. One hole is modelled and patterned; several holes of one kind on one
  face are one Hole feature with several points.
- Hollow parts: outside solid -> (draft) -> outside blends -> Shell -> blends on edges the Shell made -> holes
  -> pattern.

## 1. Vessel - VERIFIED (`nx-solid-features/scripts/moulded_order.py` O4)

```
PART      open round vessel, moulded, mm
INTENT    diameter, height, wall, hole diameter, hole radius, hole count variable
MASTERS   d_out 600, h_out 300, r_floor 25, wall 10, d_hole 50, r_holes 230, n_holes 4
FEATURES  1 Extrude / Cylinder d_out x h_out on the XY plane of the Datum CSYS, centre on the origin
          2 Edge Blend r_floor on the bottom edge            (before the Shell: the wall follows it)
          3 Shell wall, top face removed
          4 Hole d_hole on the floor, point on the X axis at r_holes, Through Body    (after the Shell)
          5 Pattern Feature circular about the Datum CSYS Z axis, n_holes
CHECKS    volume 7 963 008.29; inside floor radius r_floor - wall = 15; wall through the floor radius 10.000
REGEN     wall 10 -> 8, n_holes 4 -> 6: exact
```
Teaches: blend before Shell; hole after Shell (a hole made first gets a wall round it); one hole + pattern, the
count is one number; a hole on a round part = one point on a datum axis and one radius.

## 2. Thin-walled container that stays centred

```
INTENT    square container centred in its mould whatever its size
FEATURES  1 Sketch on XY: rectangle with four corner fillets; equal length on the four sides, equal radius on
            the four fillets, the Datum CSYS point at the midpoint of one side in each direction;
            TWO driving dimensions only: side 60, fillet 18
          2 Extrude 100 with the draft IN the feature (from the start limit, 1 deg opening upward)
          3 Edge Blend 8 on the bottom edge
          4 Shell 3.5, top face removed
CHECKS    sketch DOF 0 with two dimensions; inside bottom radius 8 - 3.5 = 4.5; centroid stays on Z when 60 changes
```
Teaches: symmetry by constraints, not by two half-dimensions; draft inside the base Extrude; draft -> blend ->
Shell. In a journal the same intent is one expression `side` used for both directions and a rectangle centred
on the origin (`nxf.sketch_rect_centered`).

## 3. Pivot plate (machined)

```
INTENT    plate length variable with the holes keeping their EDGE distances; cut-out and boss hole stay
          CENTRAL; chamfer size variable
FEATURES  1 Sketch on XY: outline 480 x 260 with a 200 x 75 cut-out in one long edge; the outline is centred
            on the origin by a midpoint constraint, the cut-out symmetric about the Y axis; four dimensions
          2 Extrude 50
          3 Sketch on YZ: 100 x 100 rectangle under the plate, 60 from the plate edge
          4 Extrude symmetric 100 each way (the boss stays centred on YZ), Unite in the feature
          5 two bisector datum planes: plate bottom / boss bottom, boss front / boss back
          6 Hole dia 60 through the boss, its point on BOTH bisector planes
          7 Hole dia 12.5 through the plate, 32 / 32 from its corner (tooling hole)
          8 ONE Hole feature, three counterbores 35 x 12.5 / dia 18: two at 70 / 70 from their edges, one 28
            from the other long edge and central
          9 Chamfer 20 on the two long bottom edges of the boss
          10-12 Edge Blends 6: vertical edges, rim chain, boss edges   (general blends, last)
REGEN     length 480 -> longer: holes keep 32 / 70 from their edges, cut-out and boss stay central;
          thickness: holes still through (Through Body); boss size: its hole stays in the middle
```
Teaches: position by what must stay - edge distances, bisector planes, symmetric limits; several points in one
Hole; general blends at the end, largest structure first. In a journal: point formulas such as
`("len/2-32", ...)` and `nxf.datum_plane(part, "bisector", [face, face])`.

## 4. Stapler housing (moulded, curved top)

```
FEATURES  1 Sketch on XY, symmetric about Y: 25 wide for 35, a 10 long taper, 20 wide, 150 long
          2 Extrude 25                                       (a full block, flat top)
          3 Sketch on YZ: ONE arc R350, tangent to the top edge 100 from the narrow end, ending on the
            vertical edge of the narrow end (tied to the block's edges, so it follows size changes)
          4 Extrude the arc symmetric 40 each way as a SHEET wider than the block
          5 Trim Body: block by the sheet, the material above removed; the sheet stays hidden
          6-8 Edge Blends 4 (wide-end corners), 25 (taper edges), 2 (top chain)    (before the Shell)
          9 Shell 1.5, bottom face and narrow-end face removed
          10 Edge Blend 5 on the two lower front corners of the side walls        (edges the Shell made)
          11 Hole dia 3 on the arc centre of one R5 blend, Through Body (through both side walls)
CHECKS    height at the narrow end 25 - (350 - sqrt(350^2 - 100^2)) = 10.41; wall 1.5
```
Teaches: a curved top is CUT with a sheet (Trim Body), not drawn into the base sketch; three outside blends
before the Shell, one blend after it on edges that did not exist before; a hole concentric with a corner sits on
its arc centre; holes last.

## 5. Mitre housing (cast-like, two openings)

```
FEATURES  1 Extrude the base (half disc) 15
          2 Extrude the back profile 15, away from the base, Unite in the feature
          3 Extrude the slot outline 20 as a pad 5 above the base, Unite in the feature
          4-6 Chamfers: asymmetric 20 / 12 on the base rim; offset + angle 40 / 20 deg on two end edges
          7-10 Edge Blends 5, 10, 10, 1 (conic) - the last on the root of the pad
          11 Shell 2.5, the pad top AND the bottom face removed (two openings)
```
Teaches: every chamfer and blend of the outside comes before the Shell, so the 2.5 wall follows them; a Shell
may remove several faces; check which face got which leg of an asymmetric chamfer (it can come out mirrored).

## What these parts do not cover

No thick-walled housing of revolution with its own bores and no Rib feature occur in Siemens' training parts:
for those follow SKILL.md section 2 (hollow-profile Revolve) and `nx-solid-features` (Rib), which rest on the
third-party housings, the user's parts and the measurements made here.
