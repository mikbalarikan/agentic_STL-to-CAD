# What the user's own NX parts show (overview)

## The data set
- Source: every `.prt` under the user's project root (4 935 files, 4 153 unique by name + size).
- Census (NX 2206 batch, read-only): 894 parametric (>= 3 real features), 194 thinly parametric,
  2 142 with parameters removed (only `BREP`/datum features), 921 empty or assembly-only files,
  1 unreadable (path too long), 1 not finished (a very large STEP-converted board).
- Deep dump (ordered tree, expressions with descriptors, sketches, edit-builder read-back of every
  feature): one file per part name, 763 dumps. Statistics below use the **639 distinct user parts**
  left after removing 38 parts Claude built earlier and the session-capture snapshots
  (`...\artifacts\session-*`, repeated saves of the same part).
- Counts quoted inside the feature-family skills come from the first 691 dumps (before the 72
  largest parts were added and before snapshot de-duplication); they are indicative, the ranking
  and proportions are the same.

## Shape of the work
| Kind of part | Parts |
|---|---|
| native parametric solid (no imported body) | 332 |
| imported `BREP` body, edited mostly with synchronous features | 143 |
| imported `BREP` body with native features added | 95 |
| reverse engineering on scan data (Fit Surface / Fit Curve) | 66 |
| native, surfacing-heavy | 3 |

- 46 631 features; median 15 per part, mean 73, maximum 1 808. 4.4 % are suppressed (the user
  leaves abandoned attempts suppressed in the tree).
- 232 parts hold more than one solid body; 262 hold sheet bodies: multi-body modelling is normal.
- First real feature: `BREP` 224, Extrude 92, Cylinder 53, Tube 34, linked face/body 30, Block 10.
- Main projects: REMAKE AI (147 parts), revart archive (97), TempVault (46), NFC enclosure (31),
  I LOUPE (29), watch design (26 + 20 + 8), POOL TIME (26), PLDR (19), retro console (18).

## Most used feature types (instances / parts)
Brep 3 905 / 304 - Edge Blend 3 873 / 249 - **Replace Face 3 518 / 245** - Extrude 3 333 / 357 -
**Offset Region 2 862 / 251** - Sketch 2 809 / 411 - Extract Face (incl. WAVE links) 2 460 / 222 -
Boolean 1 721 / 233 - **Delete Face 1 249 / 150** - Datum Plane 1 020 / 202 - Trim Body 1 016 / 135 -
Move Object 922 / 113 - **Move Face 868 / 174** - Extend Sheet 607 / 60 - Divide Face 597 / 111 -
Trim Sheet 507 / 34 - Sew 506 / 67 - Offset Curve in Face 425 / 99 - Project Curve 410 / 110 -
Chamfer 406 / 138 - Fit Surface 394 / 60 - Cylinder 346 / 138 - Trim and Extend 342 / 37 -
**Mirror Geometry 335 / 100** - Studio Spline 330 / 28 - Delete Body 311 / 138 - Hole 250 / 131 -
Resize Face 199 / 72 - Through Curves 188 / 32 - Split Body 180 / 88 - Thread 166 / 71 - Tube 153 / 56 -
Bounded Plane 146 / 40 - Law Extension 134 / 29 - Revolve 129 / 78 - Shell 114 / 58 - Draft 108 / 28 -
Pattern Geometry 97 / 49 - Studio Surface 85 / 21 - Thicken 62 / 31 - Rib 47 / 8 - Sweep Along Guide 45 / 18 -
Pattern Feature 35 / 23 - Swept 32 / 8 - Through Curve Mesh 29 / 10 - Mirror Feature 28 / 22.

Synchronous features in total: 9 068 in 357 parts (56 % of the parts).

## Recurring sequences (adjacent in the tree / within three features)
| Sequence | Adjacent | Within 3 | Reading |
|---|---|---|---|
| Divide Face > Offset Region | 304 | 379 | raise / sink a land |
| Mirror Geometry > Extract Body | 323 | 323 | the mirror's own child feature |
| Offset Curve in Face > Divide Face | 212 | 232 | inset boundary as the dividing curve |
| Linked Face > Replace Face | 147 | 148 | wall ends on the mating part |
| Linked Body > Subtract | 136 | 175 | clearance for a neighbour component |
| Extract Body (mirror copy) > Unite | 120 | 186 | half + mirror + unite |
| Trim Sheet > Sew | 119 | 226 | grow a quilt joint by joint |
| Extend Sheet > Trim Body | 100 | 175 | extend the tool sheet, then cut the solid |
| Pattern Geometry > Extract Body | 95 | 95 | pattern's child feature |
| Linked Body > Unite | 71 | 106 | merge a neighbour body |
| Delete Face > Edge Blend | 50 | 162 | strip, edit, re-blend |
| Trim Body > Mirror Geometry | 47 | 95 | cut at the symmetry plane, mirror |
| Extrude > Shell | 26 | 59 | outside solid, then shell |
| Shell > Offset Region | 23 | 38 | tune walls after the shell |
| Split Body > Delete Body | 16 | 24 | cut apart, drop the scrap |

## Median position in the tree (0 = first feature, 1 = last; parts with >= 10 features)
Studio Surface 0.23 - Revolve 0.29 - Trim Sheet 0.33 - Bounded Plane 0.34 - Shell 0.36 - Sketch 0.38 -
Sew 0.40 - Split Body 0.40 - Extrude 0.41 - Trim Body 0.42 - Datum Plane 0.42 - Through Curves 0.44 -
Extend Sheet 0.47 - Mirror Geometry 0.51 - Draft 0.51 - Pattern Geometry 0.52 - Thicken 0.53 -
Delete Face 0.54 - Divide Face 0.55 - Offset Region 0.56 - Boolean 0.57 - Move Face 0.58 -
Replace Face 0.59 - Chamfer 0.61 - Delete Body 0.63 - Hole 0.64 - Edge Blend 0.67 - Rib 0.70 -
Thread 0.77 - Pattern Face 0.78.

## Sketches and parameters
- 2 834 sketches: 866 well constrained (31 %), 1 775 under-constrained (63 %), 105 inconsistent,
  57 over-constrained. 1 931 (68 %) carry no dimension at all.
- Extrude sections (1 477 read back): Region Boundary 774, dumb curves 258, whole curve feature 125,
  feature chain 103, edges 91, tangent feature chain 66, tangent edges 42.
- Revolves: 129, of which 114 are full 0-360.
- Shell parents: Extrude 63, Split Body 28, Through Curves 10, Cylinder 5, Trim Body 5 (of 114).
- User-named expressions exist in **47 of 577** parts with expressions (955 names; the most
  frequent are `HATA_n`, `EXTRUDE_n`, `EDGE_BLEND_n`, `RADYUS_n`, `TOPLAM_UZUNLUK`, `D1_CAP`,
  `DIS_CAP`); the median share of typed names per part is 0 %. An earlier version of this file
  said 117 parts: that test counted every name that is not `p<digits>`, which includes NX's own
  `p12_x` / `_y` / `_z` point coordinates, `ASSO_BLEND_n`, `Sheet_Metal_*` and
  `p8_CircularPattern_...` names (1 517 names by the loose test, 955 by the strict one,
  `nxh.user_named`). Sketches are never renamed.
- Formulas: 219 parts hold at least one; 284 are arithmetic on numbers typed into the field,
  623 reference another expression or use a function.

## What this means for Claude
1. Imported-body rework and enclosure design in assembly context are the main work; synchronous
   modelling and WAVE links are core tools, not exceptions.
2. The user thinks in bodies: tool bodies, mirror/pattern of bodies, split/delete, booleans.
3. Blends are single-radius features placed late; holes are Hole features on sketch points.
   (Late blends and body copies are the user's style. Third-party parts built from drawings
   blend a boss right after it and copy features, see SKILL.md sections 0 and 3.)
4. The user's numeric, lightly constrained style is a speed choice by an expert at the screen.
   An agent cannot rely on eyeballing: keep named masters, constrained sketches and measured
   checks for anything Claude builds, and leave the user's existing structure alone.
